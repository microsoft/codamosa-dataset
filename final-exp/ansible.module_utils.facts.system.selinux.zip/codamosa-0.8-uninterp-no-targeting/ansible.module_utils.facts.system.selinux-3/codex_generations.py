

# Generated at 2022-06-20 19:53:35.330735
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    mock_module = None
    mock_collected_facts = None
    selinux_collector = SelinuxFactCollector(mock_module, mock_collected_facts)
    collected_facts = selinux_collector.collect(mock_module, mock_collected_facts)

    # Check that the SelinuxFactCollector has collected the selinux facts
    assert 'selinux' in collected_facts.keys()

    # Check that the SelinuxFactCollector has collected the status, config_mode and mode selinux facts
    assert 'status' in collected_facts['selinux'].keys()
    assert 'type' in collected_facts['selinux'].keys()
    assert 'config_mode' in collected_facts['selinux'].keys()

# Generated at 2022-06-20 19:53:39.347461
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()


# Generated at 2022-06-20 19:53:41.503875
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-20 19:53:44.356038
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    selinux_facts = collector.collect()
    assert selinux_facts['selinux']['status'] == 'enabled'

# Generated at 2022-06-20 19:53:46.152436
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-20 19:53:47.473479
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-20 19:53:58.366471
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_module = module_mock('selinux')
    collector = SelinuxFactCollector(module=selinux_module)
    facts = collector.collect()

    # Check that the facts dict is populated
    assert facts
    assert 'selinux' in facts
    selinux_facts = facts['selinux']

    # Check that the selinux dict is populated
    assert selinux_facts['status'] == 'enabled'
    assert selinux_facts['policyvers'] == '27'
    assert selinux_facts['config_mode'] == 'enforcing'
    assert selinux_facts['mode'] == 'permissive'
    assert selinux_facts['type'] == 'targeted'

# Generated at 2022-06-20 19:54:01.822408
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfact_collector = SelinuxFactCollector()
    assert selinuxfact_collector.name is 'selinux'
    assert selinuxfact_collector._fact_ids is not None

# Generated at 2022-06-20 19:54:03.548679
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-20 19:54:09.462330
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxfact = SelinuxFactCollector()
    assert selinuxfact.collect() == {
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }

    selinuxfact.HAVE_SELINUX = False
    assert selinuxfact.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-20 19:54:28.152038
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModule()
    selinux_facts = SelinuxFactCollector().collect(module=module)

    # Assert SELinux module exists in collected_facts
    assert 'selinux' in selinux_facts

    # Assert SELinux status exists in collected_facts
    assert 'status' in selinux_facts['selinux']

    # Assert SELinux status is not None in collected_facts
    assert selinux_facts['selinux']['status'] is not None

    # Assert selinux_python_present module exists in collected_facts
    assert 'selinux_python_present' in selinux_facts

    # Assert selinux_python_present is not None in collected_facts
    assert selinux_facts['selinux_python_present'] is not None


# Generated at 2022-06-20 19:54:35.605018
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    orig_selinux = selinux
    selinux_mock = Mock()
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = 2
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, 'targeted')
    selinux_mock.is_selinux_enabled.return_value = True
    selinux = selinux_mock
    test_obj = SelinuxFactCollector()
    test_obj.collect()
    selinux = orig_selinux

# Generated at 2022-06-20 19:54:40.747714
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the Selinux collect method
    :return:
    """
    # Create instance of SelinuxFactCollector
    sfc = SelinuxFactCollector()

    # call the collect method
    facts = sfc.collect(None, None)

    assert 'selinux_python_present' in facts



# Generated at 2022-06-20 19:54:42.542393
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None
    obj = SelinuxFactCollector()
    obj.collect(module, collected_facts)

# Generated at 2022-06-20 19:54:49.484487
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import facts, FactCollector
    from ansible.module_utils.facts.collectors import SelinuxFactCollector
    from ansible.module_utils.facts.collectors.selinux import HAVE_SELINUX

    # Test for case where selinux module is not present
    HAVE_SELINUX = False
    module = None
    collected_facts = {}
    expected_collect_result = {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }
    test_fact_collector = SelinuxFactCollector()
    collected_facts = test_fact_collector.collect(module, collected_facts)
    assert collected_facts == expected_collect_result

    # Test for case

# Generated at 2022-06-20 19:54:54.352914
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert isinstance(obj.collect(), dict)
    assert obj.collect() == dict(selinux=dict(status='Missing selinux Python library'), selinux_python_present=False)

# Generated at 2022-06-20 19:54:56.231724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert isinstance(sfc, SelinuxFactCollector)


# Generated at 2022-06-20 19:55:00.705836
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert SelinuxFactCollector().collect() == {
        'selinux_python_present': True,
        'selinux': {
            'config_mode': 'unknown',
            'policyvers': 'unknown',
            'mode': 'unknown',
            'type': 'unknown',
            'status': 'enabled'
        }
    }

# Generated at 2022-06-20 19:55:01.603590
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-20 19:55:03.097998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-20 19:55:27.650955
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Return information without selinux library
    collector = SelinuxFactCollector()
    result = collector.collect()
    assert result['selinux_python_present'] == False

    # Return information with selinux library present but disabled
    collector = SelinuxFactCollector()
    result = collector.collect()
    assert result['selinux']['status'] == 'disabled'
    assert result['selinux']['config_mode'] is None
    assert result['selinux']['mode'] is None
    assert result['selinux']['policyvers'] is None
    assert result['selinux']['type'] is None
    assert result['selinux_python_present'] == True

# Generated at 2022-06-20 19:55:30.598239
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This method will test the collect method of class SelinuxFactCollector.
    :return:
    """
    selinux_facts = SelinuxFactCollector()
    selinux_facts.collect()

# Generated at 2022-06-20 19:55:33.938715
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test constructor of SelinuxFactCollector
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:55:46.355129
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a class instance
    selinux_fact_collector = SelinuxFactCollector()

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}

    # Create a mock ansible module object
    mock_ansible_module = MockModule()

    # Call collect on the instance
    collected_facts = selinux_fact_collector.collect(mock_ansible_module)

    # Assert that the proper facts were collected
    assert 'selinux_python_present' in collected_facts
    assert 'selinux' in collected_facts
    assert 'status' in collected_facts['selinux']
    assert 'policyvers' in collected_facts['selinux']
    assert 'config_mode' in collected_facts['selinux']

# Generated at 2022-06-20 19:55:48.625832
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()
    assert obj._fact_class is None

# Generated at 2022-06-20 19:55:54.756675
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Source code for the mock module can be found in the file unit_test_selinux_mocks.py
    m = __import__('unit_test_selinux_mocks')

    # Create an instance of the SelinuxFactCollector class
    sfc = SelinuxFactCollector()

    # Collect the facts only related to SELinux
    sfc.collect(module=m, collected_facts={})

    # Check the facts we expect
    assert sfc.get_facts()['selinux_python_present'] is True
    assert sfc.get_facts()['selinux']['status'] == 'enabled'
    assert sfc.get_facts()['selinux']['policyvers'] == '23'

# Generated at 2022-06-20 19:55:59.285051
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc.collect() == {'selinux': {'config_mode': 'unknown', 'mode': 'unknown', 'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-20 19:56:04.445387
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collected_facts = dict()
    collector = SelinuxFactCollector('selinux_fact_collector', collected_facts)
    assert collector.name == 'selinux_fact_collector'
    assert collector._fact_ids == set()
    assert isinstance(collector.collect(collected_facts), dict)
    assert isinstance(collector.collect(), dict)
    assert collected_facts['selinux']

# Generated at 2022-06-20 19:56:14.714544
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import sys
    import platform

    # Create the class we are going to test
    selinux_fact_collector = SelinuxFactCollector()

    # The class we are testing uses  a static variable _fact_ids
    # to store the ids of the collected facts. This variable is
    # shared by all instances of the class.
    # Here we make sure this variable is empty
    selinux_fact_collector._fact_ids = set()

    # Mock the module and return the class we are testing
    selinux_fact_collector.collect(module=mock.MagicMock())

    # Check that the class used the method 'fail_json' of the mocked module
    # The fail_json method of the module has been called with the appropriate
    # arguments
    assert selinux_fact_collector.module.fail_

# Generated at 2022-06-20 19:56:25.536931
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    real_selinux = selinux
    real_HAVE_SELINUX = HAVE_SELINUX
    selinux = None
    HAVE_SELINUX = False

    try:
        fact_collector = SelinuxFactCollector()
        system_facts = fact_collector.collect()
        assert system_facts['selinux']['status'] == 'Missing selinux Python library'
        assert system_facts['selinux_python_present'] == False

        selinux = real_selinux
        HAVE_SELINUX = real_HAVE_SELINUX

        system_facts = fact_collector.collect()
        assert system_facts['selinux']['status'] == 'disabled'
        assert system_facts['selinux_python_present'] == True

    finally:
        selinux

# Generated at 2022-06-20 19:57:06.003325
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    a = SelinuxFactCollector()
    assert a.name == 'selinux'
    assert not a._fact_ids

# Generated at 2022-06-20 19:57:10.837216
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Unit test for constructor of class SelinuxFactCollector"""

    # Constructor without parameters
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:57:12.901992
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-20 19:57:23.328890
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test that the appropriate SELinux facts are collected.
    """

    # Define a test class to manage the selinux library.
    class TestSelinux(object):
        def __init__(self):
            self.is_selinux_enabled = False
            self.security_policyvers = [1,2,3]
            self.selinux_getenforcemode_rc = 0
            self.selinux_getenforcemode_configmode = 1
            self.security_getenforce_mode = 0
            self.selinux_getpolicytype_rc = 0
            self.selinux_getpolicytype_type = 'targeted'

        def is_selinux_enabled(self):
            return self.is_selinux_enabled


# Generated at 2022-06-20 19:57:30.999306
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    sys.modules['selinux'] = sys.modules['ansible.module_utils.compat.selinux']
    module = sys.modules['ansible.module_utils.facts.system.selinux']
    facts_dict = {}
    collector = module.SelinuxFactCollector(module, facts_dict)

    # Call the collect method on the class.
    collector.collect()

    # Test that the method does not return None.
    assert collector.collect() is not None

    # Test that 'selinux' is a key in the results.
    assert 'selinux' in collector.collect()

# Generated at 2022-06-20 19:57:32.571615
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_collector = SelinuxFactCollector()
    assert test_collector.name == 'selinux'

# Generated at 2022-06-20 19:57:36.620585
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:57:39.769568
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''Unit test for constructor of class SelinuxFactCollector'''
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert 'selinux_python_present' in fact_collector.collect()

# Generated at 2022-06-20 19:57:51.590199
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.utils import get_all_facts
    from ansible.module_utils.facts.collector import collector_import_failure_exception
    from copy import deepcopy
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    try:
        from ansible.module_utils.compat import selinux
        selinux_present = True
    except ImportError:
        selinux_present = False

    all_facts = get_all_facts()


# Generated at 2022-06-20 19:57:56.526106
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Calling SelinuxFactCollector.collect() for unit testing.
    """
    selinux_facts_collector = SelinuxFactCollector()
    selinux_facts = selinux_facts_collector.collect()
    print(selinux_facts)

# Invoking the module execution
if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-20 19:59:27.098456
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-20 19:59:37.756602
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    fact_collector = SelinuxFactCollector()

    # Simple test - selinux not enabled
    selinux_facts = {}
    selinux_facts['status'] = 'disabled'
    facts_dict = {}
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = True
    assert fact_collector.collect() == facts_dict

    # Simple test - selinux enabled
    selinux_facts = {}
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = 'unknown'
    selinux_facts['config_mode'] = 'unknown'
    selinux_facts['mode'] = 'unknown'
    selinux_facts['type'] = 'unknown'
    facts_dict = {}

# Generated at 2022-06-20 19:59:39.237391
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()
    assert selinux.collect() == {}

# Generated at 2022-06-20 19:59:44.351209
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

    assert selinux_collector.name == 'selinux'
    assert selinux_collector.collect()['selinux_python_present'] == HAVE_SELINUX

# Generated at 2022-06-20 19:59:44.916970
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-20 19:59:52.314122
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # mock facts.dhcp_servers, expected to be updated in the looked up result
    global HAVE_SELINUX
    global SELINUX_MODE_DICT
    facts_dict = {'dhcp_servers': 'dpkg'}
    SELINUX_MODE_DICT = {
        1: 'enforcing',
        0: 'permissive',
        -1: 'disabled'
    }
    HAVE_SELINUX = True
    selinux_facts = {
        'status': 'enabled',
        'policyvers': 'unknown',
        'config_mode': 'unknown',
        'mode': 'unknown',
        'type': 'unknown'
    }

# Generated at 2022-06-20 19:59:53.650088
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts = SelinuxFactCollector().collect()
    assert 'selinux' in facts

# Generated at 2022-06-20 19:59:57.074110
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:59:58.197622
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector

# Generated at 2022-06-20 20:00:00.684887
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {}

# Generated at 2022-06-20 20:01:48.624401
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Unit test for testing the collect method of class SelinuxFactCollector
    """
    collected_facts = dict()

    # Test if the selinux Python library is present
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)
    
    if HAVE_SELINUX:
        assert selinux_facts['selinux_python_present'] == True
    else:
        assert selinux_facts['selinux_python_present'] == False

    # Test if the selinux Python library is present
    def mock_selinux_enabled(self):
        return True

    selinux.is_selinux_enabled = mock_selinux_enabled
    selinux_facts = selinux_fact_collector

# Generated at 2022-06-20 20:01:51.455957
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 20:01:54.268639
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 20:02:00.173343
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Return empty dict if the selinux module isn't present.
    """
    mock_selinux = None
    mock_HAVE_SELINUX = False
    module = None

    with patch.object(selinux, 'HAVE_SELINUX') as mock_HAVE_SELINUX:
        mock_HAVE_SELINUX = False
        fact_collector = SelinuxFactCollector()
        result = fact_collector.collect(module)
        assert result == {'selinux': {'status': 'Missing selinux Python library'},
                          'selinux_python_present': False}

# Generated at 2022-06-20 20:02:03.434237
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect()

    # Check if selinux key exists in facts_dict
    assert 'selinux' in facts_dict
    selinux_dict = facts_dict.get('selinux')

    # Check if selinux_python_present key exists in facts_dict
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-20 20:02:08.025772
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create test SelinuxFactCollector
    collector = SelinuxFactCollector()

    # Validate name property
    assert collector.name == 'selinux'

    # Validate set of fact names
    assert collector._fact_ids == set()

# Generated at 2022-06-20 20:02:13.110459
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fc = SelinuxFactCollector()
    facts_dict = fc.collect()
    assert facts_dict is not None
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert 'config_mode' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']
    assert 'type' in facts_dict['selinux']
    assert 'policyvers' in facts_dict['selinux']

# Generated at 2022-06-20 20:02:18.844515
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test that SelinuxFactCollector was created and has valid attributes
    """
    def mock_selinux():
        """
        Mock selinux module
        """
        mod = 'ansible.module_utils.compat.selinux'

# Generated at 2022-06-20 20:02:21.671221
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create an object of the SelinuxFactCollector class
    selinux_fact_collector = SelinuxFactCollector()

    # Assert that the object name is correct
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 20:02:25.641595
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxfact = SelinuxFactCollector()
    result = selinuxfact.collect()
    assert(isinstance(result, dict))