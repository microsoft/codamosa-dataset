

# Generated at 2022-06-20 19:53:30.464765
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector.collect()

# Generated at 2022-06-20 19:53:34.160557
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    selinux_facts_dict = selinux_facts.collect()
    assert selinux_facts_dict['selinux'] # test if selinux is present


# Generated at 2022-06-20 19:53:35.419854
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 19:53:35.963001
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 19:53:46.812841
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create an instance of SelinuxFactCollector() for testing
    selinux_fc = SelinuxFactCollector()

    # Unit test implementation details
    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == set()

    # Test that collector works when selinux library is missing
    selinux_python_present = selinux_fc.collect()['selinux_python_present']
    assert selinux_python_present is False

    # Test that collector works when selinux library is present
    selinux_fc = SelinuxFactCollector()
    selinux_python_present = selinux_fc.collect()['selinux_python_present']
    assert selinux_python_present is True

# Generated at 2022-06-20 19:53:47.386936
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 19:54:00.059674
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux module is only present if selinux is available
    try:
        from ansible.module_utils.compat import selinux
    except ImportError:
        return

    # These tests assume the selinux Python module is present
    if selinux.has_selinux():
        selinux_fact_collector = SelinuxFactCollector()

        # Get selinux facts
        selinux_facts = selinux_fact_collector.collect()

        # Check that the selinux information is provided
        assert 'selinux' in selinux_facts

        # Check that the selinux Python library is present
        assert selinux_facts['selinux_python_present']

        # Status should be 'enabled' or 'disabled'
        assert selinux_facts['selinux']['status'] in ['enabled', 'disabled']

        # If

# Generated at 2022-06-20 19:54:06.699181
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    result_facts = selinux_facts.collect()
    assert 'selinux' in result_facts
    assert 'status' in result_facts['selinux']
    assert 'mode' in result_facts['selinux']
    assert 'policyvers' in result_facts['selinux']
    assert 'config_mode' in result_facts['selinux']
    assert 'type' in result_facts['selinux']
    assert 'selinux_python_present' in result_facts

# Generated at 2022-06-20 19:54:11.262699
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:54:13.969739
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert 'selinux' in collected_facts

# Generated at 2022-06-20 19:54:28.261152
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is missing, only
    # set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or
    # disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        module = None
        collected_facts = {}
        sfc = SelinuxFactCollector()
        facts = sfc.collect(module=module, collected_facts=collected_facts)
        assert facts['selinux_python_present'] is False
        assert facts['selinux']['status'] == 'Missing selinux Python library'
        return

    module = None
    collected_facts = {}
    sfc = SelinuxFactCollector()
    facts = sfc.collect(module=module, collected_facts=collected_facts)
   

# Generated at 2022-06-20 19:54:32.791578
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    sfc = SelinuxFactCollector()
    res = sfc.collect()

    assert 'selinux' in res
    assert 'status' in res['selinux']
    assert res['selinux']['status'] == 'disabled'
    assert res['selinux_python_present'] == True

# Generated at 2022-06-20 19:54:43.002961
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    list_of_fact_ids = ['selinux_python_present', 'selinux']
    obj_selinux_fact_collector = SelinuxFactCollector()
    assert hasattr(obj_selinux_fact_collector, 'name') and obj_selinux_fact_collector.name == 'selinux'
    assert set(obj_selinux_fact_collector._fact_ids) == set(list_of_fact_ids)
    obj_selinux_fact_collector_collect = obj_selinux_fact_collector.collect()
    assert set(obj_selinux_fact_collector_collect.keys()) == set(list_of_fact_ids)

# Generated at 2022-06-20 19:54:43.757668
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector() is not None

# Generated at 2022-06-20 19:54:50.208619
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    test_collector = SelinuxFactCollector()

    # For testing disabling of selinux
    # import selinux
    # selinux.is_selinux_enabled = lambda: False

    test_ansible_module = basic.AnsibleModule(
        argument_spec = dict()
    )
    test_ansible_module.params = {}

    test_collected_facts = collector.collect_fact(test_ansible_module)

    # In actual facts collected, selinux['status'] is set to 'disabled' when selinux is disabled

# Generated at 2022-06-20 19:54:59.336634
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.complex_ds import FactManager

    facts_collector = FactsCollector()
    selinux_collector = SelinuxFactCollector()

    facts_collector.register_collector(selinux_collector)

    facts_collector.collect(module=None)

    complex_ds_manager = FactManager()

    complex_ds_manager.add_complex_ds('selinux', 'dict', {'status': 'disabled', 'python_present': False})

    complex_ds_manager.add_simple_ds('selinux_python_present', 'boolean', False)

    complex_ds_manager

# Generated at 2022-06-20 19:55:05.962722
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test for method collect of class SelinuxFactCollector
    '''
    # Setup a mocked module
    module = type('module', (object,), dict(selinux_python_present=False))
    collected_facts = type('collected_facts', (object,), dict(selinux={'status': 'disabled'}))
    # Call the collect method of SelinuxFactCollector
    fact_collector = SelinuxFactCollector()
    collect_result = fact_collector.collect(module, collected_facts)
    # Assert the result
    assert collect_result['selinux_python_present'] == False

# Generated at 2022-06-20 19:55:08.115221
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''Create an object of SelinuxFactCollector and asserts its name attribute'''
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-20 19:55:12.882182
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SELINUXCOLLECTOR = SelinuxFactCollector()
    assert SELINUXCOLLECTOR.name == "selinux"
    assert SELINUXCOLLECTOR._fact_ids == set()
    assert SELINUXCOLLECTOR.collect() == {}

# Generated at 2022-06-20 19:55:23.576061
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = None
    mock_collected_facts = None
    selinux_fact_collector = SelinuxFactCollector()

    if HAVE_SELINUX:
        result_dict = selinux_fact_collector.collect(mock_module, mock_collected_facts)['selinux']
        assert result_dict['type'] != 'unknown'
        assert result_dict['policyvers'] != 'unknown'
        assert result_dict['config_mode'] != 'unknown'
        assert result_dict['mode'] != 'unknown'
        assert result_dict['status'] == 'enabled'
    else:
        result_dict = selinux_fact_collector.collect(mock_module, mock_collected_facts)['selinux']
        assert result_dict['status'] == 'Missing selinux Python library'

# Generated at 2022-06-20 19:55:35.116910
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test instantiation of SelinuxFactCollector class
    SelinuxFactCollector()


# Generated at 2022-06-20 19:55:37.316039
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector().collect()

# Generated at 2022-06-20 19:55:38.682683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:55:47.463720
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a new SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Set the selinux module to the value of the mock selinux module
    selinux_fact_collector.selinux = selinux

    # Create a mock collected_facts dict
    collected_facts = dict()

    # Set the value of the boolean selinux_python_present using the fact collector
    selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the value of selinux_python_present is True
    assert collected_facts['selinux_python_present']

# Generated at 2022-06-20 19:55:49.992287
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect(None, {})

    assert selinux_facts['selinux']['status'] == "enabled"

# Generated at 2022-06-20 19:55:53.269088
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_info = SelinuxFactCollector()
    assert selinux_info.name == 'selinux'

# Generated at 2022-06-20 19:56:03.684293
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('Module', (), {'params': {}})()

    # Create a mock collected_facts
    collected_facts = type('CollectedFacts', (), {'selinux': {}})()

    # Create a SelinuxFactCollector object
    selinuxfact = SelinuxFactCollector(module=module, collected_facts=collected_facts)

    # Create a test dictionary for the selinux fact
    temp_dict = {'selinux': {'status': 'enabled', 'mode': 'enforcing', 'policyvers': '28', 'type': 'targeted', 'config_mode': 'enforcing'}, 'selinux_python_present': True}

    # Change the status, mode, policyvers, type and config_mode values to test collect method

# Generated at 2022-06-20 19:56:14.508655
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test: ansible.module_utils.facts.system.selinux.SelinuxFactCollector.collect
    '''
    selinux_fc = SelinuxFactCollector()

    # Test when HAVE_SELINUX is False
    old_have_selinux = selinux_fc.HAVE_SELINUX
    selinux_fc.HAVE_SELINUX = False
    assert selinux_fc.collect() == {
        'selinux': {'status': 'Missing selinux Python library'},
        'selinux_python_present': False
    }
    selinux_fc.HAVE_SELINUX = old_have_selinux

    # Test when HAVE_SELINUX is True and selinux is present
    old_selinux_present = selinux_

# Generated at 2022-06-20 19:56:17.339283
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-20 19:56:26.171295
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # If the selinux library is not available, status should be a string
    selinux_facts = SelinuxFactCollector().collect()
    assert isinstance(selinux_facts['selinux']['status'], str)
    assert 'Missing selinux Python library' in selinux_facts['selinux']['status']

    # If the selinux library is available, status should be a string
    selinux_facts = SelinuxFactCollector().collect({}, {'selinux_python_present': True})
    assert isinstance(selinux_facts['selinux']['status'], str)
    assert 'enabled' in selinux_facts['selinux']['status']

# Generated at 2022-06-20 19:56:47.406798
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:56:58.342698
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    import mock
    from ansible.module_utils._text import to_bytes

    # Set up test import
    sys.modules['selinux'] = selinux
    sys.modules['selinux.security_policyvers'] = selinux.security_policyvers
    sys.modules['selinux.selinux_getenforcemode'] = selinux.selinux_getenforcemode
    sys.modules['selinux.security_getenforce'] = selinux.security_getenforce
    sys.modules['selinux.selinux_getpolicytype'] = selinux.selinux_getpolicytype

    # Collect the facts
    collector = SelinuxFactCollector()
    facts = collector.collect()

    # Test the values

# Generated at 2022-06-20 19:57:02.576018
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    expected_facts = {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'status': 'enabled',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }
    assert SelinuxFactCollector().collect() == expected_facts

# Generated at 2022-06-20 19:57:13.864196
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test that selinux facts are returned as a dict when all checks pass."""

    # Raise an exception in the selinux library to simulate it not being present
    import ansible.module_utils.compat.selinux as selinux
    import ansible.module_utils.compat.six as six

    # If the selinux library is not present, the utility will return a dict with only
    # a boolean for whether the Python library is present and a status of 'Missing selinux Python library'.
    with six.assertRaisesRegex(Exception, "SELinux Python library is missing"):
        selinux.is_selinux_enabled()
        collector = SelinuxFactCollector()
        collected_facts = collector.collect()
        assert type(collected_facts) is dict

# Generated at 2022-06-20 19:57:14.755053
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-20 19:57:19.213007
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    FACT_SUBSET = dict(selinux=dict(
        status='disabled',
        config_mode='unknown',
        mode='unknown',
        type='unknown',
        policyvers='unknown'
    ))

    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect(module=None, collected_facts=None)

    assert FACT_SUBSET == collected_facts['selinux']

# Generated at 2022-06-20 19:57:21.781116
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    assert SelinuxFactCollector.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-20 19:57:22.791780
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-20 19:57:29.589995
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_lib_path = '/usr/lib/python2.7/site-packages/selinux/selinux.py'

    def mock_is_selinux_enabled(selinux_lib_path):
        return False

    def mock_is_selinux_enabled_enabled(selinux_lib_path):
        return True

    def mock_security_policyvers(selinux_lib_path):
        return '28'

    def mock_selinux_getenforcemode(selinux_lib_path):
        return (0, 1)

    def mock_security_getenforce(selinux_lib_path):
        return 1

    def mock_selinux_getpolicytype(selinux_lib_path):
        return (0, 'targeted')


# Generated at 2022-06-20 19:57:31.694251
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector_ins = SelinuxFactCollector()
    assert fact_collector_ins.name == 'selinux'

# Generated at 2022-06-20 19:58:31.827005
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        expected = dict(
            selinux=dict(
                status='Missing selinux Python library',
            ),
            selinux_python_present=False,
        )
        collector = SelinuxFactCollector()
        result = collector.collect()
        assert result == expected
        return

    # Set a boolean for testing whether the Python library is present
    result = SelinuxFactCollector().collect()
    assert "selinux_python_present" in result


# Generated at 2022-06-20 19:58:38.599677
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    import ansible.module_utils.facts.collector
    collector = ansible.module_utils.facts.collector.BaseFactCollector()

    def mock_warn(msg):
        pass

    def mock_is_selinux_enabled():
        return True

    def mock_security_policyvers():
        return '1'

    def mock_selinux_getenforcemode():
        return 0, 1

    def mock_security_getenforce():
        return 1

    def mock_selinux_getpolicytype():
        return 0, 'mock'

    monkeypatch = pytest.Fixture()
    monkeypatch.setattr(collector, '_warn_once', mock_warn)

# Generated at 2022-06-20 19:58:48.646720
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import selinux_collector

    # Collect facts when selinux Python library is missing (usually caused by
    # selinux-python being installed)
    fact_collector.collectors['selinux'] = selinux_collector.SelinuxFactCollector()
    facts = fact_collector.collect(['selinux'])
    assert facts['selinux']['status'] == 'Missing selinux Python library'
    assert facts['selinux_python_present'] == False

    # Add the mock for the selinux library
    def mock_HAVE_SELINUX_FUNCTION():
        return True
    selinux_collector.HA

# Generated at 2022-06-20 19:58:53.582061
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Returns a boolean if the init method was successfully
    """
    selinuxfactcollector = SelinuxFactCollector()

    assert selinuxfactcollector is not None

# Generated at 2022-06-20 19:59:06.606846
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    env_dict = dict(
        SELINUX_ENABLE='1',
        SELINUX_CONFIG_MODE='1',
        SELINUX_POLICYVERS='26',
        SELINUX_MODE='1',
        SELINUX_TYPE='targeted'
    )
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def selinux_is_selinux_enabled():
        if os.environ.get('SELINUX_ENABLE') == '1':
            return True
        return False

    def selinux_security_policyvers():
        return os.environ.get('SELINUX_POLICYVERS')


# Generated at 2022-06-20 19:59:09.369922
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:59:18.620741
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    with patch('ansible.module_utils.compat.selinux.is_selinux_enabled', return_value=0):
        SelinuxFactCollector().collect() == dict(
            selinux_python_present=True,
            selinux=dict(
                status='disabled'
            )
        )

# Generated at 2022-06-20 19:59:22.430907
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collected_facts = SelinuxFactCollector()
    assert selinux_collected_facts.name == 'selinux'
    assert selinux_collected_facts._fact_ids == set()

# Generated at 2022-06-20 19:59:29.230724
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect()

    assert isinstance(facts_dict, dict)
    if HAVE_SELINUX:
        assert 'selinux_python_present' in facts_dict
        assert facts_dict['selinux_python_present'] == True

        assert 'selinux' in facts_dict
        selinux_facts = facts_dict['selinux']
        assert 'status' in selinux_facts

        if selinux_facts['status'] == 'enabled':
            assert 'policyvers' in selinux_facts
            assert 'config_mode' in selinux_facts
            assert 'type' in selinux_facts
            assert 'mode' in selinux_facts

            # Check that values for the defined selinux keys are 'unknown'


# Generated at 2022-06-20 19:59:31.464657
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.__class__.__name__ == 'SelinuxFactCollector'


# Generated at 2022-06-20 20:01:08.728133
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 20:01:10.446207
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()

    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 20:01:11.602292
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 20:01:22.345670
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import Facts

    collector = SelinuxFactCollector(module=Facts())
    collected_facts = collector.collect()
    assert collected_facts is not None
    assert 'selinux' in collected_facts
    assert isinstance(collected_facts['selinux'], dict)

    selinux_facts = collected_facts['selinux']
    assert isinstance(selinux_facts, dict)

    if selinux_facts.get('status') == 'enabled':
        assert isinstance(selinux_facts['mode'], str)
        assert isinstance(selinux_facts['type'], str)
        assert isinstance(selinux_facts['config_mode'], str)

# Generated at 2022-06-20 20:01:25.687207
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactcollector = SelinuxFactCollector()
    assert selinuxfactcollector.name == 'selinux'
    assert selinuxfactcollector._fact_ids == set()

# Make sure that the class can be instantiated.

# Generated at 2022-06-20 20:01:32.352644
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector.

    This method is a private method. A test method was created by copying the
    method definition to test_selinux.py and modifying it to return the values
    that are set.

    """
    # Disable pylint warning for accessing protected members of a class.
    # This is done for testing purposes.
    # pylint: disable=protected-access
    selinux_fact = SelinuxFactCollector()
    results = selinux_fact.collect()
    assert results['selinux_python_present']

# Generated at 2022-06-20 20:01:43.528755
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        pytest.skip("Skipping test. Ansible fact module selinux is currently not supported with Python 2.6")

    selinux_facts = dict(
        status='disabled',
        mode='disabled',
        config_mode='disabled',
        type='unknown',
        policyvers='unknown'
    )
    if 'selinux' in sys.modules:
        selinux_facts['status'] = 'enabled'
        selinux_facts['config_mode'] = 'permissive'
        selinux_facts['mode'] = 'permissive'
        selinux_facts['type'] = 'targeted'
        selinux_facts['policyvers'] = '24'


# Generated at 2022-06-20 20:01:44.675558
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-20 20:01:47.465415
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'
    assert selinux_obj._fact_ids == set()

# Generated at 2022-06-20 20:01:50.785782
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None