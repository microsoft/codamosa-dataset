

# Generated at 2022-06-20 19:53:30.116549
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.collect()['selinux']['status'] == 'disabled'

# Generated at 2022-06-20 19:53:31.708542
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-20 19:53:36.597798
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # SelinuxFactCollector.collect will return None if the selinux library is not present.
    # In that case, we do not need to do any testing other than basic import.
    if HAVE_SELINUX:

        # Test to make sure that we can retrieve selinux information.
        assert SelinuxFactCollector().collect()['selinux']['status'] == 'enabled'

# Generated at 2022-06-20 19:53:38.228614
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-20 19:53:40.179434
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact = SelinuxFactCollector()
    assert fact.name == 'selinux'
    assert fact._fact_ids == set()


# Generated at 2022-06-20 19:53:42.494135
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
     selinuxfactcollector = SelinuxFactCollector()
     assert selinuxfactcollector.collect()

# Generated at 2022-06-20 19:53:45.434329
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:53:57.467821
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()

    # Default to empty selinux facts if Python library is not found
    if not HAVE_SELINUX:
        assert facts_dict['selinux_python_present'] == False
        assert facts_dict['selinux'] == {'status': 'Missing selinux Python library'}
        return

    # If selinux Python library is present, then other facts should be present
    assert facts_dict['selinux_python_present'] == True
    assert facts_dict['selinux'] is not None
    assert facts_dict['selinux']['status'] == 'enabled'
    assert facts_dict['selinux']['policyvers'] is not None
    assert facts_dict['selinux']['config_mode'] == 'enforcing'


# Generated at 2022-06-20 19:54:06.058122
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import Collector

    if not HAVE_SELINUX:
        return

    fact_collector = Collector.get_fact_collector('selinux')
    fact_collector.collect()

    facts = fact_collector.get_fact_dict()
    expected_facts = {
        'selinux': {
            'type': 'targeted',
            'mode': 'permissive',
            'config_mode': 'permissive',
            'policyvers': '28',
            'status': 'enabled'
        },
        'selinux_python_present': True
    }
    assert facts == expected_facts

# Generated at 2022-06-20 19:54:08.077123
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-20 19:54:19.483546
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-20 19:54:23.235537
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """SelinuxFactCollector class constructor test stub"""

    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:54:25.407915
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == "selinux", 'Failed to create SelinuxFactCollector object'

# Generated at 2022-06-20 19:54:34.356417
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Set up selinux module import
    selinux_original = __import__('selinux')
    selinux_mock = MagicMock()

    # Disable SELinux
    selinux_mock.is_selinux_enabled.return_value = False
    selinux_mock.security_policyvers.side_effect = AttributeError
    selinux_mock.selinux_getenforcemode.side_effect = OSError
    selinux_mock.security_getenforce.side_effect = AttributeError
    selinux_mock.selinux_getpolicytype.side_effect = OSError

    selinux_original.is_selinux_enabled = selinux_mock.is_selinux_enabled
    selinux_original.security_policyvers = selinux_mock

# Generated at 2022-06-20 19:54:36.807330
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()


test_SelinuxFactCollector()

# Generated at 2022-06-20 19:54:46.080400
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Check to make sure the SelinuxFactCollector collect method is working
    as expected.

    It tests the following cases:
        1) When selinux Python library is not present
        2) When selinux is disabled
        3) When selinux is enabled and policy mode is set to enforcing
        4) When selinux is enabled and policy mode is set to permissive
        5) When selinux is enabled and policy mode is set to disabled
        6) When selinux is enabled and policy mode is set to an unknown value
    """

    test_collector = SelinuxFactCollector()

    # Test case 1: When selinux Python library is not present
    test_collector.HAVE_SELINUX = False
    # Simulate a selinux.security_getenforce() call that returns -1
    test_collector.selinux.security_

# Generated at 2022-06-20 19:54:48.312755
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    expected_facts = ['status']
    if HAVE_SELINUX:
        expected_facts.extend(['policyvers', 'config_mode', 'mode', 'type'])
    assert set(sfc._fact_ids) == set(expected_facts)

# Generated at 2022-06-20 19:54:50.705152
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ml = SelinuxFactCollector()
    ml.collect()

# Generated at 2022-06-20 19:54:51.394011
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-20 19:54:54.975410
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_SelinuxFactCollector = SelinuxFactCollector()
    assert test_SelinuxFactCollector.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-20 19:55:17.656656
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()

    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-20 19:55:20.470408
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfc = SelinuxFactCollector()
    assert selinuxfc.name == 'selinux'
    assert selinuxfc._fact_ids == set()


# Generated at 2022-06-20 19:55:24.658063
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect()
    assert type(facts) == dict
    assert 'selinux' in facts
    selinux = facts['selinux']
    assert type(selinux) == dict
    assert 'status' in selinux
    assert 'python_present' in facts

# Generated at 2022-06-20 19:55:38.022438
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_info = dict()

    if HAVE_SELINUX:
        try:
            (rc, mode) = selinux.selinux_getenforcemode()
            if rc == 0:
                selinux_info['config_mode'] = SELINUX_MODE_DICT.get(mode, 'unknown')
            else:
                selinux_info['config_mode'] = 'unknown'
        except (AttributeError, OSError):
            selinux_info['config_mode'] = 'unknown'

        try:
            mode = selinux.security_getenforce()
            selinux_info['mode'] = SELINUX_MODE_DICT.get(mode, 'unknown')
        except (AttributeError, OSError):
            selinux_info['mode'] = 'unknown'


# Generated at 2022-06-20 19:55:39.891682
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert SelinuxFactCollector.collect() == {'selinux': {'status': 'Missing selinux Python library'}}

# Generated at 2022-06-20 19:55:43.518350
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_object = SelinuxFactCollector()
    assert selinux_fact_collector_object.name == 'selinux'
    assert selinux_fact_collector_object._fact_ids == set()


# Generated at 2022-06-20 19:55:46.310724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:55:47.207206
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-20 19:55:48.499124
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test empty constructor
    SelinuxFactCollector()


# Generated at 2022-06-20 19:55:49.687800
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == "selinux"

# Generated at 2022-06-20 19:56:34.300195
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:56:38.959153
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Create the SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Check the name
    assert selinux_fact_collector.name == 'selinux'
    # Check the _fact_ids
    assert 'selinux' in selinux_fact_collector._fact_ids
    assert 'selinux_python_present' in selinux_fact_collector._fact_ids

# Generated at 2022-06-20 19:56:42.483690
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Create an instance of the module and test if it works
    """

    collectors = [c.name for c in BaseFactCollector._fact_collectors]
    assert "selinux" in collectors

# Generated at 2022-06-20 19:56:44.737257
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = SelinuxFactCollector().collect()
    assert 'selinux' in facts_dict

# Generated at 2022-06-20 19:56:55.027872
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # configure fact collection
    fact_collector = SelinuxFactCollector()
    test_facts = {}

    # test missing Python selinux library
    HAVE_SELINUX = False
    fact_collector.collect(collected_facts=test_facts)
    assert test_facts['selinux']['status'] == 'Missing selinux Python library'
    assert test_facts['selinux_python_present'] == False

    # test SELinux is not enabled
    HAVE_SELINUX = True
    selinux.is_selinux_enabled = lambda: False
    fact_collector.collect(collected_facts=test_facts)
    assert test_facts['selinux']['status'] == 'disabled'
    assert test_facts['selinux_python_present'] == True

    # test S

# Generated at 2022-06-20 19:57:03.759086
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    # Test that it works when selinux python library is not present
    selinuxfacts = collector.collect()
    assert selinuxfacts['selinux_python_present'] is False
    assert selinuxfacts['selinux']['status'] == 'Missing selinux Python library'

    # Try it with the library present
    module = MagicMock(return_value=True)
    with patch.object(selinux.__builtin__, '__import__', new=module):
        selinuxfacts = collector.collect()

        assert selinuxfacts['selinux_python_present'] is True
        # selinux_is_selinux_enabled returns True if selinux is enabled
        # and False if it is not.  In this case, we are not mocking the
        # selinux library so the status

# Generated at 2022-06-20 19:57:06.451205
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-20 19:57:11.243657
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = object()
    base_collected_facts = dict()
    selinux_fact_collector = SelinuxFactCollector(module, base_collected_facts)
    assert(selinux_fact_collector.name == 'selinux')
    assert(selinux_fact_collector._fact_ids == set())


# Generated at 2022-06-20 19:57:16.547340
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert hasattr(selinux_fact_collector, '_fact_ids') is True
    assert isinstance(selinux_fact_collector._fact_ids, set)
    assert hasattr(selinux_fact_collector, 'collect') is True
    assert callable(selinux_fact_collector.collect) is True

# Generated at 2022-06-20 19:57:22.376357
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Mock the selinux library
    sys.modules['selinux'] = MagicMock(name='selinux')
    if sys.version_info[0] < 3:
        builtins = __import__('__builtin__')
    else:
        builtins = __import__('builtins')
    setattr(builtins, 'selinux', MagicMock(name='selinux'))
    selinux = sys.modules['selinux']

    # Instantiate the object
    selinux_fact_collector = SelinuxFactCollector()

    # Check inheritance
    assert isinstance(selinux_fact_collector, BaseFactCollector)

# Generated at 2022-06-20 19:58:14.883485
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    collector = get_collector_instance(SelinuxFactCollector)
    assert isinstance(collector, Collector)

# Generated at 2022-06-20 19:58:21.251575
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

    # Testing the constructor of SelinuxFactCollector
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

    # behavior of expand_hostvars should be False for this collector
    assert selinux_collector.expand_hostvars == False


# Generated at 2022-06-20 19:58:25.113798
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # NOTE: fact_cache, module and collected_facts are not used but are
    #       required for the argument signature
    selinux_fact_collector = SelinuxFactCollector(None, None, None)
    assert selinux_fact_collector.collect()

# Generated at 2022-06-20 19:58:29.617077
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

    assert selinux_collector._fact_ids == set() and selinux_collector.name == 'selinux'



# Generated at 2022-06-20 19:58:32.511723
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:58:38.894009
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test method collect of class SelinuxFactCollector"""

    # Mock module_utils.compat.selinux.is_selinux_enabled
    mod_compat = mock.MagicMock()
    module_utils = mock.MagicMock()
    module_utils.compat = mod_compat
    module_utils.compat.selinux.is_selinux_enabled = mock.MagicMock(return_value=True)
    module_utils.compat.selinux.security_getenforce = mock.MagicMock(return_value=1)
    module_utils.compat.selinux.selinux_getpolicytype = mock.MagicMock(return_value=(0, 'targeted'))
    module_utils.compat.selinux.selinux_getenforcemode = mock

# Generated at 2022-06-20 19:58:41.292692
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-20 19:58:44.251961
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts.get('selinux', {}).get('status') == 'Missing selinux Python library'

# Generated at 2022-06-20 19:58:51.678488
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    selinux_facts_dict = {
        'selinux_python_present': True,
        'selinux': {
            'status': 'enabled',
            'policyvers': 27,
            'config_mode': 'permissive',
            'mode': 'permissive',
            'type': 'targeted'
        }
    }
    selinux_facts_dict_missing_python_lib = {
        'selinux_python_present': False,
        'selinux': {
            'status': 'Missing selinux Python library'
        }
    }

    selinux = SelinuxFactCollector()
    mock_module = basic.AnsibleModule(
        argument_spec = dict()
    )
    collected

# Generated at 2022-06-20 19:59:04.704165
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Unit test for method SelinuxFactCollector.collect. """
    import imp
    import tempfile
    import os
    import json

    mod = imp.load_source('module_selinux', 'module_utils/facts/selinux.py')
    fd, tmp_path = tempfile.mkstemp()
    os.close(fd)
    if os.path.exists('/usr/lib/python2.7/site-packages/selinux'):
        os.rename('/usr/lib/python2.7/site-packages/selinux', tmp_path)


# Generated at 2022-06-20 20:00:44.121430
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    info = {'selinux': {'config_mode': 'permissive',
                        'mode': 'permissive',
                        'policyvers': '26',
                        'status': 'enabled',
                        'type': 'targeted'},
            'selinux_python_present': True}
    obj = SelinuxFactCollector()
    obj.collect()
    assert obj.get_facts() == info

# Generated at 2022-06-20 20:00:47.325117
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 20:00:48.677188
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    assert 'selinux' in collector.collect()

# Generated at 2022-06-20 20:00:50.357864
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_collector = SelinuxFactCollector()
    facts_collector.collect()
    assert facts_collector.name == 'selinux'

# Generated at 2022-06-20 20:01:02.135738
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect()
    if not HAVE_SELINUX:
        assert 'selinux' in facts_dict, 'Result dict should contain the key `selinux`'
        assert isinstance(facts_dict['selinux'], dict), 'selinux is not instance of dict'
        assert 'status' in facts_dict['selinux'], 'Result dict should contain the key `status`'
        assert 'Missing selinux Python library' == facts_dict['selinux']['status'], \
            'The value of `status` key is not `Missing selinux Python library`'

# Generated at 2022-06-20 20:01:12.001791
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # mock selinux module methods
    selinux = sys.modules['ansible.module_utils.compat.selinux']
    selinux.is_selinux_enabled = MagicMock(return_value=True)
    selinux_enforce = 1
    selinux.security_getenforce = MagicMock(return_value=selinux_enforce)
    selinux_enforcemode = 0
    selinux.selinux_getenforcemode = MagicMock(return_value=(0, selinux_enforcemode))
    selinux_policytype = "targeted"
    selinux.selinux_getpolicytype = MagicMock(return_value=(0, selinux_policytype))
    selinux_securityvers = 2

# Generated at 2022-06-20 20:01:14.821882
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 20:01:23.184179
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import CachingFactCollector
    from ansible.module_utils.facts.collector import FetchAllCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.cache

    # Capture all module methods
    selinux_collector = ansible.module_utils.facts.collector.SelinuxFactCollector()
    assert selinux_collector.collect()
    assert 'selinux' and 'selinux_python_present' in ansible.module_utils.facts.cache.CACHE
    ansible.module_utils.facts.collector.FetchAllCollector.fetch_all()

# Generated at 2022-06-20 20:01:27.371182
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # GIVEN initialized instance of class SelinuxFactCollector
    selinux_obj = SelinuxFactCollector()

    # WHEN name attribute is evaluated
    selinux_name = selinux_obj.name
    selinux_fact_ids = selinux_obj._fact_ids

    # THEN verify name attribute assetions
    assert selinux_name == 'selinux'
    assert selinux_fact_ids == set()

# Generated at 2022-06-20 20:01:30.786053
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert 'selinux' in fact_collector._fact_ids