

# Generated at 2022-06-20 19:53:30.812513
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    # dict for input to collect function
    module = {}
    collected_facts = {}
    result = collector.collect(module, collected_facts)
    # assert that the result from collect method exists
    assert 'selinux' in result
    assert result['selinux_python_present'] is True

# Generated at 2022-06-20 19:53:34.201516
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    test_dict = fact_collector.collect()
    assert 'selinux' in test_dict
    assert 'status' in test_dict['selinux']

# Generated at 2022-06-20 19:53:34.764803
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-20 19:53:38.917785
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:53:50.317992
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    import sys

    # Set the following
    # Python module selinux
    # Test if selinux.py is installed
    module_selinux = SelinuxFactCollector().collect()['selinux_python_present']

    class mock_selinux:

        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return '28'

        @staticmethod
        def selinux_getenforcemode():
            return (0, 0)

        @staticmethod
        def security_getenforce():
            return 0

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')

    # Return True if selinux.py is not installed

# Generated at 2022-06-20 19:53:53.927583
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollectorObject = SelinuxFactCollector(None)
    assert selinuxFactCollectorObject.name == "selinux"
    assert len(selinuxFactCollectorObject._fact_ids) == 0

# Generated at 2022-06-20 19:54:05.294620
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.compat import selinux
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY2

    # do not include original parameters

    BaseFactCollector.collect = BaseFactCollector.collect_orig

    # Include parameters

    m = __import__('ansible.module_utils.facts.collector', globals(), locals(), ['BaseFactCollector'], 0)
    m.BaseFactCollector.collect = BaseFactCollector.collect_orig

    # mocks

    def mock_is_selinux_enabled():
        return True


# Generated at 2022-06-20 19:54:12.013996
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.pycompat24 import get_exception

# Generated at 2022-06-20 19:54:15.073139
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    assert SelinuxFactCollector.collect.__doc__


# Generated at 2022-06-20 19:54:19.189842
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:54:25.993885
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:54:29.827182
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    res = fact_collector.collect()
    assert res['selinux_python_present'] is True
    assert res['selinux']['status'] == 'enabled'

# Generated at 2022-06-20 19:54:32.000894
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sfc = SelinuxFactCollector()
    assert set(['status', 'config_mode', 'policyvers', 'mode', 'type']) == set(sfc.collect().keys())

# Generated at 2022-06-20 19:54:43.314088
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import os

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    # Configure mock for selinux module because it is not installed by
    # default.
    import sys
    from ansible.module_utils.compat import selinux
    sys.modules['ansible.module_utils.compat.selinux'] = selinux

    if sys.version_info[0] == 3:
        from unittest.mock import patch
        from io import StringIO
    else:
        from mock import patch
        from StringIO import StringIO

    # Collector should return an empty dictionary in case
    # the selinux module is not present.

# Generated at 2022-06-20 19:54:47.743334
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Verify that if a selinux Python library is not present,
    the status is set to 'Missing selinux Python library'
    """
    facts_dict = {'ansible_selinux_python_present': False}
    selinux_facts_dict = {'ansible_selinux': {'status': 'Missing selinux Python library'}}
    selinux_obj = SelinuxFactCollector()
    assert(selinux_obj.collect() == selinux_facts_dict)

# Generated at 2022-06-20 19:54:58.559920
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Build a test object
    test = SelinuxFactCollector()

    # Test with selinux library present
    test.HAVE_SELINUX = True

    # Test with selinux enabled
    test.selinux_enabled = True

    # Test with selinux in enforcing mode
    test.mode = 1

    # Test with Red Hat policy type
    test.policytype = 'targeted'

    # Test with basic SELinux policy version
    test.policyvers = 20

    # Get the output and compare it to the expected

# Generated at 2022-06-20 19:55:00.527395
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:55:03.057105
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts is not None
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-20 19:55:05.962694
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    collected_facts = {}
    actual = fact_collector.collect(None, collected_facts)

    expected = {
        'selinux': {
            'mode': 'enforcing'
        }
    }

# Generated at 2022-06-20 19:55:07.238467
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 19:55:19.547938
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    SelinuxFactCollector.collect should return a dict with following keys
    """
    sfc = SelinuxFactCollector()

    assert sfc.collect()[sfc.name] is not None

# Generated at 2022-06-20 19:55:27.415923
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Given
    selinux_facts = {'facts_dict':
        {
            'selinux_python_present': True,
            'selinux': {
                'config_mode': ' ',
                'mode': ' ',
                'status': ' ',
                'type': ' '
            }
        }
    }

    class MockSelinuxModule:
        def __init__(self):
            self.params = {}

    class MockSelinux:
        def __init__(self):
            self.MockSelinuxModule = MockSelinuxModule()
        def is_selinux_enabled(self):
            return True
        def security_policyvers(self):
            return 2
        def selinux_getenforcemode(self):
            return 0

# Generated at 2022-06-20 19:55:28.804476
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact = SelinuxFactCollector()
    assert fact.name == 'selinux'

# Generated at 2022-06-20 19:55:34.521658
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        import selinux
    except ImportError:
        selinux = None
    sc = SelinuxFactCollector
    assert sc

    if selinux is None:
        assert sc.name == 'selinux'
        assert sc._fact_ids == set()
    else:
        assert sc.name == 'selinux'
        assert sc._fact_ids == set()


# Generated at 2022-06-20 19:55:46.910125
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Test 1: Missing selinux Python library
    sys_module = {
        "HAVE_SELINUX": False,
        "SELINUX_MODE_DICT": {1: "enforcing", 0: "permissive", -1: "disabled"}
    }

    selinux_module = {
        "is_selinux_enabled": None,
        "security_policyvers": None,
        "selinux_getenforcemode": None,
        "security_getenforce": None,
        "selinux_getpolicytype": None
    }

    selinux_facts = {
        "HAVE_SELINUX": False,
        "SELINUX_MODE_DICT": {1: "enforcing", 0: "permissive", -1: "disabled"}
    }

    selinux_facts_

# Generated at 2022-06-20 19:55:48.835996
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactcollector = SelinuxFactCollector()
    assert selinuxfactcollector.name == 'selinux'


# Generated at 2022-06-20 19:55:57.133493
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    # Test name variable
    assert(selinux_fact_collector.name == 'selinux')

    # Test the fact ID's
    assert(len(selinux_fact_collector._fact_ids) == 2)
    assert('selinux_python_present' in selinux_fact_collector._fact_ids)
    assert('selinux' in selinux_fact_collector._fact_ids)


# Generated at 2022-06-20 19:56:01.217972
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = SelinuxFactCollector()
    if HAVE_SELINUX:
        assert 'selinux' in fact.collect()
        assert 'status' in fact.collect()['selinux']
    else:
        assert 'selinux' not in fact.collect()

# Generated at 2022-06-20 19:56:08.416903
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Given a SelinuxFactCollector object
    cfg = [{'domain': 'test.com'}]

    # And a list of facts

# Generated at 2022-06-20 19:56:15.605218
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    setattr(module, 'fail_json', fail_json)  # set fail_json function of module as fail_json
    selinux_facts_collector = SelinuxFactCollector()
    selinux_facts_dict = selinux_facts_collector.collect(module)
    assert getattr(selinux_facts_dict, 'selinux') != None
    assert getattr(selinux_facts_dict, 'selinux_python_present') != None


############################################################################
# Mocks
############################################################################

# Generated at 2022-06-20 19:56:38.037860
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {'selinux': {}, 'selinux_python_present': True}

# Generated at 2022-06-20 19:56:50.024367
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_present_selinux_enabled_facts = {
        'selinux':{
            'status':'enabled'
        },
        'selinux_present':True,
        'selinux_python_present':True
    }
    selinux_present_selinux_disabled_facts = {
        'selinux':{
            'status':'disabled'
        },
        'selinux_present':True,
        'selinux_python_present':True
    }
    selinux_missing_facts = {
        'selinux':{
            'status':'Missing selinux Python library'
        },
        'selinux_python_present':False
    }

    class MockSelinuxLibrary(object):
        def __init__(self):
            pass


# Generated at 2022-06-20 19:56:51.627421
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    f = SelinuxFactCollector()
    facts = f.collect()
    assert 'selinux' in facts

# Generated at 2022-06-20 19:56:55.026971
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert isinstance(x, SelinuxFactCollector)


# Generated at 2022-06-20 19:57:03.757595
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test case for method collect of class SelinuxFactCollector."""
    # Setup the test parameters
    collected_facts = {}
    # Set the selinux python library to missing
    HAVE_SELINUX = False
    SelinuxFactCollector._fact_ids.add('selinux')
    # Perform the unit test
    SelinuxFactCollector.collect(None, collected_facts)
    # Assert the unit test results
    assert collected_facts['selinux_python_present'] == False
    assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    # Assert that we did not set selinux configuration information when selinux Python library was missing
    assert 'config_mode' not in collected_facts['selinux']
    assert 'mode' not in collected_facts['selinux']

# Generated at 2022-06-20 19:57:07.242475
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s
    assert s.name == 'selinux'
    assert s._fact_ids == set()



# Generated at 2022-06-20 19:57:09.319970
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfc = SelinuxFactCollector()
    assert selinuxfc.name == 'selinux'

# Generated at 2022-06-20 19:57:13.207545
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert isinstance(x, SelinuxFactCollector)
    assert isinstance(x._fact_ids, set)
    assert isinstance(x.name, str)
    assert x.name == 'selinux'
    assert isinstance(x.collect(), dict)

# Generated at 2022-06-20 19:57:15.131078
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    facts = SelinuxFactCollector()
    assert facts.name == 'selinux'
    assert facts._fact_ids == set()

# Generated at 2022-06-20 19:57:18.936065
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-20 19:58:00.296564
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test SelinuxFactCollector"""
    SelinuxFactCollector()


# Generated at 2022-06-20 19:58:04.288339
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'
    assert isinstance(selinux_fact_collector.collect(), dict)

# Generated at 2022-06-20 19:58:13.878384
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class MockOpt(object):
        def __init__(self):
            self.gather_subset = ['!all', 'selinux']
            self.gather_timeout = 10

    class MockModule(object):
        def __init__(self):
            self.params = MockOpt()

    class MockFacts(object):
        def __init__(self):
            self.facts = {}
            self.legacy_facts = {}

    mock_module = MockModule()
    mock_facts = MockFacts()

    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect(module=mock_module, collected_facts=mock_facts)

    selinux_facts = mock_facts.facts.get('selinux')

# Generated at 2022-06-20 19:58:18.221947
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test method which return the name of the class."""
    selinux_fact_col = SelinuxFactCollector()
    assert selinux_fact_col.name == 'selinux'

# Generated at 2022-06-20 19:58:30.022787
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test that collect method provides expected values for selinux facts dictionary
    """

    # Create a SelinuxFactCollector object to exercise the code
    selinux_collector = SelinuxFactCollector()

    # Populate the selinux facts dictionary with mock values
    selinux_facts_dict = {
        'selinux': {
            'status': 'enabled',
            'config_mode': 'enforcing',
            'policyvers': '28',
            'mode': 'enforcing',
            'type': 'targeted'
        },
        'selinux_python_present': True
    }

    # Create a mock module object with a mock run_command method
    mock_module = MockModule()

    # Create a mock selinux module with a mock is_selinux_enabled method and mock security_policyvers method
    mock

# Generated at 2022-06-20 19:58:31.211711
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None

# Generated at 2022-06-20 19:58:33.705424
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-20 19:58:35.940343
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:58:42.203343
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == 'set()'

    y = SelinuxFactCollector()
    assert y.name == 'selinux'
    assert y._fact_ids == 'set()'

# Generated at 2022-06-20 19:58:50.923123
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test for method collect of class SelinuxFactCollector
    '''
    class MockSelinux(object):
        '''
        Mock SELinux module
        '''
        def __init__(self):
            self.status = True

        def is_selinux_enabled(self):
            return self.status

        def security_policyvers(self):
            return 1

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 0

        def selinux_getpolicytype(self):
            return (0, 'targeted')

    class MockSelModule(object):
        '''
        Mock module for testing
        '''
        def __init__(self):
            self.selinux = MockSelinux

# Generated at 2022-06-20 20:00:10.531498
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'



# Generated at 2022-06-20 20:00:12.263061
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc.collect() == {'selinux': {}}

# Generated at 2022-06-20 20:00:14.172395
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-20 20:00:19.953135
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Make sure method selinux.is_selinux_enabled cannot be mocked (it's a function not a method)
    selinux.is_selinux_enabled = lambda: True

    # Mock out methods on the selinux module
    selinux.security_policyvers = lambda: 'Mocked policyvers'
    selinux.selinux_getenforcemode = lambda: (0, 0)
    selinux.security_getenforce = lambda: 1
    selinux.selinux_getpolicytype = lambda: (0, 'Mocked policy type')

    collector = SelinuxFactCollector()
    facts = collector.collect()

    assert facts['selinux_python_present'] is True
    assert facts['selinux']['status'] == 'enabled'

# Generated at 2022-06-20 20:00:23.066974
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    tfc = SelinuxFactCollector()
    facts = tfc.collect()
    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    if facts['selinux_python_present']:
        assert facts['selinux']['mode'] in ['enforcing', 'permissive', 'disabled']
        assert facts['selinux']['config_mode'] in ['enforcing', 'permissive', 'disabled']

# Generated at 2022-06-20 20:00:30.494299
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Namespace
    from ansible.module_utils.facts.collector import get_collector

    # GIVEN: A class instance of class SelinuxFactCollector
    selinux_collector_instance = get_collector('selinux')

    # WHEN: We set selinux module
    selinux_collector_instance.set_module_name('selinux')

    # AND: We create a temporary Namespace object
    test_object = Namespace()

    # AND: We set keys and values in the temporary Namespace object
    test_object.collector_name = 'selinux'
    test_object.collector_instance = selinux_collector_instance

    # WHEN: We execute the collect method
    selinux_facts = selinux_collector_instance.collect

# Generated at 2022-06-20 20:00:38.092751
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {'config_mode': 'unknown', 'type': 'unknown', 'mode': 'unknown', 'status': 'enabled', 'policyvers': 'unknown'}
    class MockModuleExit(object):
        def __init__(self, *args):
            pass
    class MockSelinux(object):
        def __init__(self, *args):
            pass
        def is_selinux_enabled(self):
            return True
        def security_policyvers(self):
            return 'refpolicy-2.20140421'
        def selinux_getenforcemode(self):
            return 0, 1
        def security_getenforce(self):
            return 1
        def selinux_getpolicytype(self):
            return 0, 'targeted'

# Generated at 2022-06-20 20:00:48.433536
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        from ansible.module_utils.compat import selinux
    except ImportError:
        # If the selinux library is not present, this fact should return data about the missing library
        ob = SelinuxFactCollector()
        result = ob.collect()
        assert result['selinux_python_present'] is False
        assert result['selinux']['status'] == 'Missing selinux Python library'
        return

    # Method collect of class SelinuxFactCollector should return the correct data when SELinux is enabled
    selinux.is_selinux_enabled = lambda: True
    selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux.security_policyvers = lambda: '24'

# Generated at 2022-06-20 20:00:50.138845
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 20:00:54.273949
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    Selinux = SelinuxFactCollector()
    collector_return = Selinux.collect()
    assert collector_return.get('selinux') is not None
    assert collector_return.get('selinux_python_present') is not None