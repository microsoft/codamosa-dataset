

# Generated at 2022-06-20 19:53:31.970835
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Ansible facts for selinux."""
    module = None
    collected_facts = {}
    selinux_facts = SelinuxFactCollector()

    # Test that selinux facts are added to the collected_facts
    selinux_facts.collect(module, collected_facts)
    assert collected_facts['selinux']
    assert collected_facts['selinux_python_present']

# Generated at 2022-06-20 19:53:39.916141
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_dict = {}
    selinux_facts = {}

    # Create an instance of the SelinuxFactCollector class
    sfc = SelinuxFactCollector(module='test')

    # If the selinux Python library is not imported, only set the status and selinux_python_present
    # in the selinux facts
    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
        assert sfc.collect(module='test', collected_facts=facts_dict) == facts_dict
    else:
        # Set a boolean for testing whether the Python library is present
        facts_dict['selinux_python_present'] = True

        # Test if

# Generated at 2022-06-20 19:53:45.338967
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        import selinux
    except ImportError:
        print("FAILED: ansible.module_utils.selinux selinux library not installed")

    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect()
    assert result['selinux']['status'] in ('disabled', 'enabled'), \
        "Failed to collect selinux status facts using SelinuxFactCollector"

# Generated at 2022-06-20 19:53:47.297658
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # This will raise an exception if constructor did not set self.name to 'selinux'
    SelinuxFactCollector()


# Generated at 2022-06-20 19:53:47.884880
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-20 19:53:51.258227
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:53:54.427729
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = object
    collected_facts = object
    selinux_facts = SelinuxFactCollector()
    selinux_facts.collect(module,collected_facts)

# Generated at 2022-06-20 19:53:59.386669
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert len(selinux_fact_collector._fact_ids) == 0

# Unit tests for function collect of class SelinuxFactCollector

# Generated at 2022-06-20 19:54:08.369273
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # We only have a few facts to test as without the selinux Python library
    # there is no way to know if selinux is enabled or not. All we can test
    # is if the library is present.

    fact_col = SelinuxFactCollector()
    facts_dict = {}
    fact_col.collect(collected_facts=facts_dict)
    assert 'selinux_python_present' in facts_dict
    assert 'selinux' not in facts_dict

    # When we have the Python library
    fact_col = SelinuxFactCollector()
    fact_col._collect = MagicMock(return_value={'selinux': {}})
    fact_col.collect(collected_facts=facts_dict)
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-20 19:54:16.769017
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test for method collect of class SelinuxFactCollector
    """
    # Initialize
    module = BaseFactCollector()

    # Initialize SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector(module)
    assert selinux_fact_collector is not None

    # TODO : selinux.is_selinux_enabled() returns True when invoked locally.
    # How can this be tested?
    # assert selinux_fact_collector.collect() == {}
    selinux_fact_collector.collect()

# Generated at 2022-06-20 19:54:29.749967
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    # Test with missing selinux Python library
    selinux_collector.HAVE_SELINUX = False
    assert selinux_collector.collect() == {
        'selinux_python_present': False,
        'selinux': {'status': 'Missing selinux Python library'}
    }
    # Test with selinux enabled
    selinux_collector.HAVE_SELINUX = True

# Generated at 2022-06-20 19:54:38.839129
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import collect
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collector

    collected_facts = ansible.module_utils.facts.collector.get_collected_facts()

    # Test if method 'collect' is a method of class BaseFactCollector
    assert isinstance(SelinuxFactCollector(collected_facts=collected_facts).collect, collections.Callable)


# Generated at 2022-06-20 19:54:44.329138
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    # Check instance
    assert isinstance(selinux, SelinuxFactCollector)
    # Check inheritance
    assert isinstance(selinux, BaseFactCollector)
    # Check the name is set correctly
    assert selinux.name == 'selinux'
    # Check the selinux_python_present fact is not present in the facts_ids set
    # as it is set directly in the facts collect method.
    assert selinux._fact_ids == set()


# Generated at 2022-06-20 19:54:55.641622
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    from ansible.module_utils.facts import FactCollector
    # Mock the selinux python module
    selinux_mock = mock.MagicMock()
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = "sefcontext"
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, "targeted")
    selinux_m

# Generated at 2022-06-20 19:55:02.618968
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = SelinuxFactCollector().collect()
    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['selinux'], dict)
    assert isinstance(facts_dict['selinux_python_present'], bool)
    assert 'status' in facts_dict['selinux']
    assert 'policyvers' in facts_dict['selinux']
    assert 'config_mode' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']
    assert 'type' in facts_dict['selinux']

# Generated at 2022-06-20 19:55:03.447096
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector() is not None

# Generated at 2022-06-20 19:55:08.309465
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Arrange
    class MockSelinux(object):
        __version__ = '0.0.0'

        def is_selinux_enabled():
            return False

    with patch('selinux.is_selinux_enabled', new=MockSelinux.is_selinux_enabled):
        selinux_collector = SelinuxFactCollector()

    # Act
    result = selinux_collector.collect()

    # Assert
    assert result['selinux']['status'] == 'disabled'
    assert not result['selinux_python_present']

# Generated at 2022-06-20 19:55:13.437948
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
    assert hasattr(selinux_fact_collector, 'collect')


# Generated at 2022-06-20 19:55:15.979752
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert isinstance(x, SelinuxFactCollector)

# Generated at 2022-06-20 19:55:23.851471
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        from ansible.module_utils.compat import selinux
        selinux.__name__ = "selinux"
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    # Constructor for class SelinuxFactCollector with empty variable facts_dict
    selinux_fact_collector = SelinuxFactCollector()

    # Assert the value of name and _fact_id of object selinux_fact_collector
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()



# Generated at 2022-06-20 19:55:38.990887
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_fact_collector = SelinuxFactCollector()
    test_fact_collector._module = {'run_once': True}
    test_fact_collector._collected_facts = {}
    test_fact_collector.collect()
    assert test_fact_collector._collected_facts

# Generated at 2022-06-20 19:55:40.545491
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-20 19:55:45.067167
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None
    instance = SelinuxFactCollector()
    result = instance.collect(module, collected_facts)

    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert result['selinux_python_present'] is True

# Generated at 2022-06-20 19:55:51.180604
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    my_selinux_fact_collector = SelinuxFactCollector()
    collected_facts = my_selinux_fact_collector.collect()
    assert isinstance(collected_facts, dict)
    assert 'selinux_python_present' in collected_facts.keys()
    if HAVE_SELINUX:
        assert 'selinux' in collected_facts.keys()
        assert 'status' in collected_facts['selinux'].keys()
    else:
        assert 'selinux' not in collected_facts.keys()

# Generated at 2022-06-20 19:56:03.003124
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This test is checking the method collect of the class SelinuxFactCollector
    """
    # Mock the selinux library functions and constants
    def mock_is_selinux_enabled():
        """
        Mock function returning True
        """
        return True

    def mock_selinux_getenforcemode():
        """
        Mock function returning a tuple (0,1)
        """
        return (0, 1)

    def mock_security_getenforce():
        """
        Mock function returning 1
        """
        return 1

    def mock_selinux_getpolicytype():
        """
        Mock function returning a tuple (0, 'targeted')
        """
        return (0, 'targeted')

    def mock_security_policyvers():
        """
        Mock function returning 24
        """
        return 24

# Generated at 2022-06-20 19:56:04.240693
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-20 19:56:05.084184
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-20 19:56:07.232893
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:56:13.109368
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Run the collect method of the SelinuxFactCollector.
    x = SelinuxFactCollector()
    x.collect()

    # Check some of the data to see if the library selinux is included
    assert not x.facts['selinux_python_present']
    assert 'status' in x.facts['selinux']

# Generated at 2022-06-20 19:56:15.859748
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.collect()


# Generated at 2022-06-20 19:56:45.191403
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test collect method of SelinuxFactCollector."""
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = dict()
    expected_facts = dict(
        selinux=dict(
            config_mode='disabled',
            mode='disabled',
            policyvers='unknown',
            status='disabled',
            type='unknown'
        ),
        selinux_python_present=False
    )
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)
    assert selinux_facts == expected_facts


# Generated at 2022-06-20 19:56:48.270115
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:56:55.315020
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Mock base class
    class BaseFactCollector():
        name = 'base'
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {
                'base': 'base fact'
            }

    # Create instance of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Create mock class Module and mock class Dictionary
    class MockModule:
        def __init__(self):
            self.name = 'ansible.module_utils.facts.system.selinux'

    class MockDictionary:
        def __init__(self):
            self.gather_subset = 'all'

    # Create mock class selinux

# Generated at 2022-06-20 19:57:01.316002
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    testObj = SelinuxFactCollector()
    assert testObj.name == 'selinux'
    assert 'selinux' in testObj._fact_ids
    assert 'selinux_python_present' in testObj._fact_ids
    assert 'status' in testObj._fact_ids
    assert 'policyvers' in testObj._fact_ids
    assert 'config_mode' in testObj._fact_ids
    assert 'mode' in testObj._fact_ids
    assert 'type' in testObj._fact_ids

# Generated at 2022-06-20 19:57:07.843018
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    selinux_facts = SelinuxFactCollector.collect()

    assert set(selinux_facts) == {'selinux', 'selinux_python_present'}
    assert set(selinux_facts.get('selinux')) == {'status', 'policyvers', 'config_mode', 'mode',
                                                 'type'}

# Generated at 2022-06-20 19:57:10.322322
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:57:18.564797
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Set a global for testing if the Python library is present
    global HAVE_SELINUX
    HAVE_SELINUX = True

    # Save the import to fake_selinux
    selinux_import = selinux

    # Create a fake selinux module that raises an AttributeError
    # on function calls to test the selinux code's exception handling.
    class fake_selinux:
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            raise AttributeError

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def security_getenforce():
            raise AttributeError


# Generated at 2022-06-20 19:57:23.929400
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()

    assert selinux_facts.name == 'selinux'
    assert selinux_facts.collect() == {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'status': 'Missing selinux Python library',
            'type': 'unknown'
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-20 19:57:35.047285
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # test with selinux is not enabled
    def mock_selinux_is_enabled():
        return False

    def mock_selinux_is_selinux_enabled():
        return False

    def mock_selinux_getpolicytype():
        return False

    def mock_selinux_getenforcemode():
        return False

    def mock_selinux_security_policyvers():
        return False

    try:
        from ansible.module_utils.compat import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    facts_dict = {}
    selinux_facts = {}

    # Case 1
    selinux_ = SelinuxFactCollector()
    if HAVE_SELINUX:
        selinux.is_selinux_

# Generated at 2022-06-20 19:57:38.932387
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    collected_facts = selinux_collector.collect()
    assert collected_facts == {
        'selinux': {
            'status': 'Missing selinux Python library',
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-20 19:58:34.718700
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Patch the selinux library
    def mock_is_selinux_enabled(self):
        return True

    def mock_security_policyvers(self):
        return '28'

    def mock_selinux_getenforcemode(self):
        return (0, 1)

    def mock_security_getenforce(self):
        return 1

    def mock_selinux_getpolicytype(self):
        return (0, 'targeted')

    SelinuxFactCollector._selinux = mock.MagicMock()
    SelinuxFactCollector._selinux.is_selinux_enabled = mock_is_selinux_enabled
    SelinuxFactCollector._selinux.security_policyvers = mock_security_policyvers
    SelinuxFactCollector._selinux.selinux

# Generated at 2022-06-20 19:58:35.520184
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-20 19:58:41.154494
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    mc = SelinuxFactCollector()
    assert mc.name == 'selinux'
    assert mc._fact_ids == set()
    # check that it is a subclass of BaseFactCollector
    assert isinstance(mc, BaseFactCollector)

# Generated at 2022-06-20 19:58:43.087822
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert 'selinux' in x._fact_ids

# Generated at 2022-06-20 19:58:50.138529
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux_python_present' in selinux_facts
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-20 19:58:54.685266
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    f = SelinuxFactCollector()

    assert f.collect() == {'selinux_python_present': True, 'selinux': {'status': 'Missing selinux Python library'}}

# Generated at 2022-06-20 19:59:01.999728
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    collector = SelinuxFactCollector()
    collector.collect()
    Collector._add_fact(collector)

    # Add a selinux fact to the existing set of system facts
    assert 'selinux' in Collector.get_system_facts()['ansible_local']['facts']

# Generated at 2022-06-20 19:59:13.417512
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Function to test collect method of class SelinuxFactCollector
    :return: None
    """
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.depends == set()
    assert not hasattr(selinux_fact_collector, '_fact_ids')
    assert isinstance(facts_dict, dict)
    assert 'selinux' in facts_dict
    assert isinstance(facts_dict['selinux'], dict)
    if HAVE_SELINUX:
        assert facts_dict['selinux_python_present'] == True
        assert 'status' in facts_dict['selinux']


# Generated at 2022-06-20 19:59:16.930368
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    module = sys.modules['ansible.module_utils.facts.collector.selinux']
    module.HAVE_SELINUX = False
    module.selinux = None
    collected_facts = {}
    fact_collector = SelinuxFactCollector()
    collected_facts = fact_collector.collect(module, collected_facts)
    assert collected_facts['selinux_python_present'] == False
    assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    del module.HAVE_SELINUX
    del module.selinux

# Generated at 2022-06-20 19:59:19.468135
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # create object of class SelinuxFactCollector
    obj = SelinuxFactCollector()

    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 20:01:04.158470
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for SelinuxFactCollector.collect"""
    # pylint: disable=no-self-use
    c = SelinuxFactCollector()
    collected_facts = {'some' : 'fact'}
    module = None
    facts_dict = c.collect(module=module, collected_facts=collected_facts)
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-20 20:01:07.997535
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector._fact_ids = set()
    SelinuxFactCollector.collect()
    assert 'selinux_python_present' in SelinuxFactCollector._fact_ids



# Generated at 2022-06-20 20:01:09.556242
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-20 20:01:14.488095
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
        Unit test for the method collect of class SelinuxFactCollector
        using a mocked object.
        :return: None
    """
    from ansible.module_utils.facts import collector
    mock_module = collector.BaseFactCollector()
    mock_collected_facts = {}
    live_facts_dict = {}
    mock_SelinuxFactCollector = collector.SelinuxFactCollector()
    live_facts_dict = mock_SelinuxFactCollector.collect(mock_module, mock_collected_facts)
    assert live_facts_dict is not None

# Generated at 2022-06-20 20:01:19.649295
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxfactcollector = SelinuxFactCollector()

    selinuxfactcollector._module = None
    selinuxfactcollector.collect()
    selinux_python_present = selinuxfactcollector.get_fact('selinux_python_present')
    assert selinux_python_present

    # TODO: Add tests with selinux library present

# Generated at 2022-06-20 20:01:24.649665
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert isinstance(selinux, SelinuxFactCollector)
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()


# Generated at 2022-06-20 20:01:25.237243
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect(): pass

# Generated at 2022-06-20 20:01:31.645559
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_module = SelinuxFactCollector()
    facts = selinux_fact_module.collect()
    assert facts['selinux_python_present'] == True
    assert type(facts['selinux']) is dict
    assert facts['selinux']['status'] == 'enabled'
    assert facts['selinux']['type'] == 'unknown'
    assert facts['selinux']['policyvers'] == 'unknown'
    assert facts['selinux']['mode'] == 'permissive'

# Generated at 2022-06-20 20:01:37.775150
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.platform == 'all'
    assert selinux_fact_collector.required_module is None
    assert selinux_fact_collector._fact_ids == set(['selinux'])

# Generated at 2022-06-20 20:01:44.475002
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}

    module = MockModule()

    # Test that status is set to missing if selinux library is missing
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect(module)
    a_dict = {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    assert facts_dict == a_dict