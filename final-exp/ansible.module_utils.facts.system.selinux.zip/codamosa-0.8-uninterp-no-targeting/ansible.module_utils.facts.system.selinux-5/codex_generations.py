

# Generated at 2022-06-20 19:53:22.222767
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 19:53:24.349102
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test if method exists
    assert callable(getattr(SelinuxFactCollector, 'collect', None))
    # Test return type
    assert isinstance(SelinuxFactCollector().collect(), dict)

# Generated at 2022-06-20 19:53:36.157822
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()

    # Test with a similar dictionary as returned by the selinux library
    class TestSelinux(object):
        def __init__(self, rc, mode=1, policyvers=8, type='targeted', configmode=0):
            self.rc = rc
            self.mode = mode
            self.policyvers = policyvers
            self.type = type
            self.configmode = configmode

        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return self.policyvers

        def selinux_getenforcemode(self):
            return (self.rc, self.configmode)

        def security_getenforce(self):
            return self.mode

        def selinux_getpolicytype(self):
            return

# Generated at 2022-06-20 19:53:39.153511
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:53:42.823421
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        sfc = SelinuxFactCollector()
        assert sfc.name == 'selinux'
        assert sfc._fact_ids == set()
    else:
        pass

# Generated at 2022-06-20 19:53:45.062082
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-20 19:53:47.038845
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:53:59.685126
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_mock = {
        'is_selinux_enabled': lambda: True,
        'security_policyvers': lambda: 'selinux-2.9-4.el7_6',
        'selinux_getenforcemode': lambda: (0, 1),
        'security_getenforce': lambda: 1,
        'selinux_getpolicytype': lambda: (0, 'targeted')
    }


# Generated at 2022-06-20 19:54:03.679264
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    # Verify class attribute name
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:54:10.494844
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Disable selinux for the test
    selinux.is_selinux_enabled = lambda:False
    selinux.security_policyvers = lambda:12345
    selinux.selinux_getenforcemode = lambda: (1, 2)
    selinux.security_getenforce = lambda: 0
    selinux.selinux_getpolicytype = lambda: (1, 'targeted')
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux']['status'] == 'disabled'
    assert selinux_facts['selinux']['policyvers'] == 12345
    assert selinux_facts['selinux']['config_mode'] == 'enforcing'
    assert selinux_facts['selinux']['mode'] == 'permissive'
    assert se

# Generated at 2022-06-20 19:54:27.151466
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ''' Unit test for method collect of class SelinuxFactCollector '''

    fact_collector = SelinuxFactCollector({})
    result = fact_collector.collect({}, None)

    assert 'selinux' in result

    if HAVE_SELINUX:
        assert result['selinux']['status'] == 'enabled'
        assert result['selinux']['policyvers'] != 'unknown'
        assert result['selinux']['config_mode'] != 'unknown'
        assert result['selinux']['mode'] != 'unknown'
        assert result['selinux']['type'] != 'unknown'
    else:
        assert 'policyvers' not in result['selinux']
        assert 'config_mode' not in result['selinux']
        assert 'mode' not in result

# Generated at 2022-06-20 19:54:28.820236
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'


# Generated at 2022-06-20 19:54:35.554978
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  # Instantiate the class
  inst = SelinuxFactCollector()

  # Check attribute 'name' is equal to 'selinux'
  assert inst.name == 'selinux'

  # Check attribute '_fact_ids' is an empty set
  assert inst._fact_ids == set()

  # Check method 'collect' raises NotImplementedError
  # assert inst.collect() == NotImplementedError

  # Check method 'collect' does not raise an exception
  try:
    collected_facts = {}
    inst.collect(collected_facts=collected_facts)
  except Exception as e:
    assert False

  # Check collected_facts['selinux'] exists
  assert 'selinux' in collected_facts

# Generated at 2022-06-20 19:54:38.229295
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:54:39.740590
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:54:47.327713
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # import os
    # os.environ['ANSIBLE_CACHE_PLUGIN'] = 'memory'

    # init collector
    from ansible.module_utils.facts.collector import Collector
    collector = Collector()

    # create object to collect from
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import SelinuxFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector, AnsibleFactCollector, Collector
    object_to_collect_from = collector.Collector()

    # init collector to test and add it to object_to_collect_from
    test_collector = Selin

# Generated at 2022-06-20 19:54:54.973917
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # 1. Create mock objects
    fact_collector = SelinuxFactCollector()

    # 2. Call method collect of class SelinuxFactCollector
    result = fact_collector.collect()

    # 3. Assert result
    assert result['selinux_python_present'] is True
    assert result['selinux'] is not None

# Generated at 2022-06-20 19:54:58.093022
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = SelinuxFactCollector().collect()
    assert facts_dict.get('selinux_python_present') is True

# Generated at 2022-06-20 19:55:00.750494
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector.platform  == "All"

# Generated at 2022-06-20 19:55:03.255186
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:55:16.038944
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:55:20.860005
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)
    assert isinstance(selinux_fact_collector, BaseFactCollector)
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:55:21.946271
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set(['selinux'])

# Generated at 2022-06-20 19:55:23.201640
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector

# Generated at 2022-06-20 19:55:28.010768
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Test collect from SelinuxFactCollector when Python selinux library is not present

# Generated at 2022-06-20 19:55:31.778818
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    result = SelinuxFactCollector().collect(module=module, collected_facts={})
    assert result['selinux_python_present'] is True

# Generated at 2022-06-20 19:55:42.837086
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxCollector = SelinuxFactCollector()
    # Create a fake module to use with the method
    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
    fakeModule = FakeModule()
    # Retrieve facts
    facts_dict = selinuxCollector.collect(fakeModule)
    # Check facts
    assert facts_dict['selinux'] == {
        'mode': 'unknown',
        'policyvers': 'unknown',
        'status': 'enabled',
        'type': 'unknown',
        'config_mode': 'unknown'
    }
    assert facts_dict['selinux_python_present'] is True

# Generated at 2022-06-20 19:55:46.700037
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:55:48.284491
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == "selinux"

# Generated at 2022-06-20 19:55:54.655242
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create an instance of class SelinuxFactCollector
    fc = SelinuxFactCollector()

    # Unit test using selinux mock from Ansible
    import os

    def mock_security_getenforce(self):
        return 0

    def mock_security_policyvers(self):
        return 199

    def mock_selinux_getpolicytype(self):
        return (0, 'mockpolicy')

    def mock_is_selinux_enabled(self):
        return True

    def mock_selinux_getenforcemode():
        return (0, 1)

    def mock_os_path_isdir(path):
        return True

    # Mock module(s) to be imported by the python fact module
    m = type('module', (object,), {})()

    m.security_getenforce

# Generated at 2022-06-20 19:56:18.153502
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Setup mock selinux library
    mock_selinux_lib = Mock()
    mock_selinux_lib.is_selinux_enabled.return_value = True
    mock_selinux_lib.security_policyvers.return_value = 1
    mock_selinux_lib.selinux_getenforcemode.return_value = [0, 1]
    mock_selinux_lib.security_getenforce.return_value = 0
    mock_selinux_lib.selinux_getpolicytype.return_value = [0, 'targeted']

    # Setup the module_utils.facts.selinux_collector
    facts_collector = SelinuxFactCollector()
    selinux_facts = facts_collector.collect()


# Generated at 2022-06-20 19:56:20.555997
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_obj = SelinuxFactCollector()
    selinux_fact_collector_obj.collect()

# Generated at 2022-06-20 19:56:23.501801
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-20 19:56:27.456065
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import make_hashable
    result = SelinuxFactCollector.collect()
    assert result['selinux_python_present'] == True
    result = make_hashable(result)
    assert isinstance(result, dict)
    assert isinstance(result['selinux'], dict)

# Generated at 2022-06-20 19:56:31.097344
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c.fact_ids == set()

# Generated at 2022-06-20 19:56:31.707188
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 19:56:34.719272
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:56:37.348327
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = selinux.SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()



# Generated at 2022-06-20 19:56:38.421977
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 19:56:43.561694
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Unit test for constructor of class SelinuxFactCollector using Mock.
    """
    selinux_collector = SelinuxFactCollector({})
    assert selinux_collector
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-20 19:57:02.871118
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    object = SelinuxFactCollector()
    assert object.name == 'selinux'

# Generated at 2022-06-20 19:57:10.567031
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()

    assert "selinux" in selinux_facts
    assert "status" in selinux_facts["selinux"]
    assert "config_mode" in selinux_facts["selinux"]
    assert "mode" in selinux_facts["selinux"]
    assert "policyvers" in selinux_facts["selinux"]
    assert "type" in selinux_facts["selinux"]

# Generated at 2022-06-20 19:57:18.765070
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # mock module_utils.selinux
    sys_module = sys.modules['ansible.module_utils.selinux']
    if sys_module is None:
        sys_module = sys.modules['ansible.module_utils.selinux'] = mock.Mock()
    sys_module.selinux._state = mock.Mock()

# Generated at 2022-06-20 19:57:20.648483
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()
    collected_facts = selinux.collect()
    assert collected_facts.get('selinux')

# Generated at 2022-06-20 19:57:22.671389
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj_SelinuxFactCollector = SelinuxFactCollector()
    assert obj_SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 19:57:25.098406
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    c = SelinuxFactCollector()
    facts = c.collect()

    assert type(facts['selinux']) == dict
    assert type(facts['selinux_python_present']) == bool

# Generated at 2022-06-20 19:57:27.957741
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'
    assert hasattr(selinux_obj, 'collect')

# Generated at 2022-06-20 19:57:35.305033
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test for selinux.security_getenforce function not available
    if not hasattr(selinux, 'security_getenforce'):
        setattr(selinux, 'security_getenforce', None)
    result = SelinuxFactCollector().collect()
    assert result['selinux']['status'] == 'Missing selinux Python library'

    result = SelinuxFactCollector().collect()
    assert result['selinux_python_present'] is True

# Generated at 2022-06-20 19:57:38.283092
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This test unit does not make sense.
    # As its content is moved to the test file test_selinux_facts.py.
    # The test_module will raise a ImportError and skip the testing.
    pass

# Generated at 2022-06-20 19:57:41.245190
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector.name
    assert 0 == len(selinux_fact_collector._fact_ids)

# Generated at 2022-06-20 19:58:31.588458
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:58:38.465451
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import FactsCollector
    from ansible.module_utils.facts.system.selinux import SelinuxFactCollector

    # Create a fake module and mock the selinux module
    module = FactsCollector()
    module.selinux = SelinuxFactCollector()

    # Set mock selinux return values
    module.selinux.HAVE_SELINUX = True
    module.selinux.is_selinux_enabled.return_value = True
    module.selinux.security_policyvers.return_value = 32
    module.selinux.selinux_getenforcemode.return_value = (0, 1)
    module.selinux.security_getenforce.return_value = 1
    module.selinux.selinux_getpolicytype

# Generated at 2022-06-20 19:58:45.280226
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a helper object of class SelinuxFactCollector
    selinuxFactCollector = SelinuxFactCollector()

    # Call method collect, store the result in a new variable
    collectionResult = selinuxFactCollector.collect()

    # Check if the value of 'selinux_python_present' is True
    if collectionResult['selinux_python_present']:
        print('Module selinux already imported')
    else:
        print('Module selinux not imported')

# Generated at 2022-06-20 19:58:58.590459
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Set up the test environment
    global HAVE_SELINUX
    HAVE_SELINUX = True
    selinux_old = selinux
    class selinux_new:
        def is_selinux_enabled(self):
            return True
    selinux = selinux_new()

    # Construct a SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()

    # Test the name and fact_ids of the SelinuxFactCollector
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

    # Test the 'collect' function

# Generated at 2022-06-20 19:59:02.073844
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"
    assert obj.collect() == {'selinux_python_present': True}

# Generated at 2022-06-20 19:59:09.910839
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector.collect(None)

    assert selinux_facts['selinux_python_present'] is True
    assert 'status' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-20 19:59:11.141277
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 19:59:12.019136
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-20 19:59:13.777178
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'


# Generated at 2022-06-20 19:59:15.171859
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'



# Generated at 2022-06-20 20:00:46.131181
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Collect facts regarding Selinux
    #
    # Execute the module
    SelinuxFactCollector.collect(module=None, collected_facts=None)


# Generated at 2022-06-20 20:00:49.423257
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_test_fact_collector = SelinuxFactCollector()
    test_dict = selinux_test_fact_collector.collect()
    for key in ['status', 'config_mode', 'mode', 'type']:
        assert key in test_dict['selinux']
    return True

# Generated at 2022-06-20 20:00:54.682456
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Tests for method collect of class SelinuxFactCollector
    # without selinux library
    # We will mock selinux library here so we can control it's behaviour
    # for different tests

    import mock

    # Check when selinux library is missing
    collected_facts = {}
    facts_dict = {}
    selinux_facts = {}
    selinux_facts['status'] = 'Missing selinux Python library'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = False

    with mock.patch('ansible.module_utils.compat.selinux', None):
        sfc = SelinuxFactCollector()
        sfc.collect(collected_facts=collected_facts)
        assert collected_facts == facts_dict
        assert sfc._fact_ids

# Generated at 2022-06-20 20:01:06.070055
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Validates that the SELinux facts are properly collected and added to ansible_facts.
    This unit test does not validate that the facts are correct, it only validates that the
    facts were added to the ansible_facts dictionary. Validation of each fact is a separate unit
    test."""
    from ansible.module_utils.facts.collector import AnsibleFactCollector
    from ansible.module_utils.facts import timeout

    mock_selinux = None

    # On Python 2.6, mock_selinux = mock.Mock()
    try:
        import unittest.mock as mock
    except ImportError:
        # Python 2.6
        import mock


# Generated at 2022-06-20 20:01:09.572994
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.collector == 'SelinuxFactCollector'

# Generated at 2022-06-20 20:01:11.896975
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 20:01:14.822273
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)

# Generated at 2022-06-20 20:01:16.886443
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    # Load the class information
    selinux_facts.collect()


# Generated at 2022-06-20 20:01:19.758166
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 20:01:29.599391
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # In order to test the SelinuxFactCollector, a new instance of the
    # SelinuxFactCollector is created.
    # Arguments (module) are passed to the constructor.
    # If the module is not available, then the exception
    # Exception is raised.
    # If the module is available and can be imported, then the test is passed.
    if not HAVE_SELINUX:
        # Test when the selinux library is not available
        test_obj = SelinuxFactCollector(module=None, collected_facts=None)
        assert('selinux_python_present' in test_obj.collect())
        assert('status' in test_obj.collect()['selinux'])