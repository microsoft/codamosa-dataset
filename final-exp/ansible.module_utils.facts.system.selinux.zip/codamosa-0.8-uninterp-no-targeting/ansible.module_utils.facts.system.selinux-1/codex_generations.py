

# Generated at 2022-06-20 19:53:26.897073
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-20 19:53:32.505603
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Simulate the selinux module library not being present
    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect()
    assert selinux_collector.collect()['selinux_python_present'] == False
    assert selinux_collector.collect()['selinux']['status'] == 'Missing selinux Python library'


# Generated at 2022-06-20 19:53:39.128516
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Import of SelinuxFactCollector will fail if the selinux Python library is not installed
    try:
        from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    except ImportError:
        pass
    else:
        assert(SelinuxFactCollector.name == 'selinux')
        fact_collector = SelinuxFactCollector()
        assert(fact_collector._fact_ids == set())
        assert(fact_collector.name == 'selinux')
        assert(not fact_collector.collected_facts)

# Generated at 2022-06-20 19:53:50.808010
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import unittest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import selinux
    selinux.HAVE_SELINUX=True
    selinux.selinux_python_present=True
    selinux.is_selinux_enabled=lambda: True
    selinux.security_policyvers=lambda: 1
    selinux.selinux_getenforcemode=lambda: (0,'enforcing')
    selinux.security_getenforce=lambda: 1
    selinux.selinux_getpolicytype=lambda: (0,'targeted')
    selinux.SELINUX_MODE_DICT={0:'permissive',1:'enforcing'}

# Generated at 2022-06-20 19:54:02.671218
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Mock the AnsibleModule class
    mock_ansible_module = MagicMock()
    mock_ansible_module.params = {'gather_subset': '!all'}

    # Mock the facts_dict
    mock_facts_dict = {'selinux_python_present': False}

    # Create instance of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Call method collect of class SelinuxFactCollector
    selinux_fact_collector.collect(module=mock_ansible_module, collected_facts=mock_facts_dict)

    # Assert that the AnsibleModule class's params attribute is set to {'gather_subset': '!all'}

# Generated at 2022-06-20 19:54:08.740469
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = SelinuxFactCollector.collect()

    assert(selinux_dict['selinux']['status'] == 'disabled')
    assert(selinux_dict['selinux']['mode'] == 'disabled')
    assert(selinux_dict['selinux']['config_mode'] == 'disabled')
    assert(selinux_dict['selinux']['policyvers'] == 'disabled')
    assert(selinux_dict['selinux']['type'] == 'disabled')

    assert(selinux_dict['selinux_python_present'] == False)

# Generated at 2022-06-20 19:54:18.929700
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector class with the module
    # argument set to None and collected_facts set to None
    selinux_collector = SelinuxFactCollector(module=None, collected_facts=None)

    # Parse the output from the collect method.  There is no output so
    # the parse method should return None
    selinux_facts_dict = selinux_collector.collect()

    assert selinux_facts_dict is not None
    assert type(selinux_facts_dict).__name__ == 'dict'
    assert len(selinux_facts_dict.keys()) == 2
    assert 'selinux' in selinux_facts_dict.keys()
    assert type(selinux_facts_dict['selinux']).__name__ == 'dict'

# Generated at 2022-06-20 19:54:24.838495
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test collect method of SelinuxFactCollector
    """
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    assert collected_facts['selinux_python_present'] == False

# Generated at 2022-06-20 19:54:33.951834
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    m_setup = BaseFactCollector.setup

    def m_module_setup():
        return an_module

    def m_selinux_is_selinux_enabled():
        return True

    def m_selinux_security_policyvers():
        return 42

    def m_selinux_selinux_getenforcemode():
        return (0, 1)

    def m_selinux_security_getenforce():
        return 0

    def m_selinux_selinux_getpolicytype():
        return (0, "targeted")

    an_module = object()
    an_module.params = {}

    m_selinux = object()
    m_selinux.is_selinux_enabled = m_selinux_is_selinux_enabled
    m_selin

# Generated at 2022-06-20 19:54:43.805927
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect({}, {})
    assert facts_dict is not None, "Did not return any facts!"
    assert type(facts_dict) == dict, "Unable to get an dictionary instance!"
    assert 'selinux' in facts_dict, "Unable to find a selinux instance!"
    assert 'selinux_python_present' in facts_dict, "Unable to find selinux_python_present instance!"
    assert 'status' in facts_dict['selinux'], "Unable to find a selinux instance!"
    assert type(facts_dict['selinux']['status']) == str, "Unable to return a string!"

# Generated at 2022-06-20 19:54:56.383296
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert ('selinux_python_present' in facts_dict)
    assert ('selinux' in facts_dict)
    assert ('status' in facts_dict['selinux'])

# Generated at 2022-06-20 19:54:58.662063
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    myfc = SelinuxFactCollector()
    assert myfc.name == 'selinux'
    assert myfc._fact_ids == set()

# Generated at 2022-06-20 19:55:00.663834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    selinux_fact_collector_obj.collect()

# Generated at 2022-06-20 19:55:06.118960
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Use a mock module to collect facts for selinux, since there is no way to
    # tell whether or not SELinux is enabled or disabled on the system
    # without the Python library. Only the 'selinux_python_present' fact should
    # be set
    selinux_mock = SelinuxFactCollector(None)
    facts = selinux_mock.collect()
    assert 'selinux_python_present' in facts
    assert 'selinux' not in facts
    assert not facts['selinux_python_present']

# Generated at 2022-06-20 19:55:07.986745
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:55:09.392141
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:55:17.114092
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None

    # Instantiate a SelinuxFactCollector object
    result = SelinuxFactCollector.collect(module, collected_facts)
   
    if not HAVE_SELINUX:
        assert result == {
            'selinux': {
                'status': 'Missing selinux Python library'
            },
            'selinux_python_present': False
        }
    else:
        assert result != {}

# Generated at 2022-06-20 19:55:26.138275
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = dict(status='enabled')

    def selinux_getpolicytype(a=None):
        return 0, 'targeted'

    def security_getenforce():
        return 1

    def selinux_getenforcemode():
        return 0, 1

    def security_policyvers():
        return 28

    def is_selinux_enabled():
        return True

    class MockSelinuxModule(object):
        pass

    selinux.is_selinux_enabled = is_selinux_enabled
    selinux.security_policyvers = security_policyvers
    selinux.selinux_getenforcemode = selinux_getenforcemode
    selinux.security_getenforce = security_getenforce
    selinux.selinux_getpolicytype = selinux_getpolicytype
    se

# Generated at 2022-06-20 19:55:28.602736
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() != None

# Generated at 2022-06-20 19:55:32.024423
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect()
    """
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict

# Generated at 2022-06-20 19:55:52.180595
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert len(selinux._fact_ids) == 0
    assert hasattr(selinux, 'name')
    assert hasattr(selinux, '_fact_ids')
    assert hasattr(selinux, 'collect')

# Generated at 2022-06-20 19:55:56.871533
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This will test if the method "collect" of class SelinuxFactCollector
    is properly returning the SELinux facts.
    """
    selinux_collector = SelinuxFactCollector()
    facts = selinux_collector.collect()
    assert 'selinux' in facts.keys()

# Generated at 2022-06-20 19:56:03.908356
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  selinux_collector = SelinuxFactCollector()
  selinux_facts = selinux_collector.collect()
  print(selinux_facts)

  selinux_facts = selinux_collector.collect(True)
  print(selinux_facts)

  selinux_facts = selinux_collector.collect(True,{'test': 'test_facts'})
  print(selinux_facts)



if __name__ == '__main__':
  test_SelinuxFactCollector_collect()

# Generated at 2022-06-20 19:56:10.841983
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ''' Unit test for method collect of class SelinuxFactCollector '''
    selinux_collector_absent = SelinuxFactCollector()
    facts_dict = selinux_collector_absent.collect()
    assert (facts_dict['selinux'] == {'status': 'Missing selinux Python library'})
    assert (facts_dict['selinux_python_present'] == False)

# Generated at 2022-06-20 19:56:17.746886
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector_instance = SelinuxFactCollector()
    assert SelinuxFactCollector_instance.collect() == {'selinux': {'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown', 'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-20 19:56:20.203925
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-20 19:56:28.173017
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # create mock fact data for selinux
    selinux_facts = {}
    selinux_facts['status'] = 'disabled'

    # create mock fact data for selinux_python_present
    selinux_python_present = False

    # create mock ansible module
    mock_ansible_module = MagicMock()
    
    # create mock selinux library
    mock_selinux = MagicMock()
    mock_selinux.is_selinux_enabled.return_value = False
    
    # import module
    from ansible.modules.system.selinux import selinux_python_present
    from ansible.modules.system.selinux import facts

    # create SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # set selinux library to mock_sel

# Generated at 2022-06-20 19:56:35.384111
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect()
    """
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    assert type(selinux_facts) is dict
    assert len(selinux_facts) == 2
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-20 19:56:36.965033
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    sfc = SelinuxFactCollector()

    assert sfc.name == 'selinux'

# Generated at 2022-06-20 19:56:42.984224
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAVE_SELINUX:
        # Test no exceptions are raised if we have the selinux library and
        # selinux is enabled
        m = SelinuxFactCollector()
        result = m.collect(module=None, collected_facts=None)
        assert result['selinux_python_present'] == True
        assert result['selinux']['status'] == 'enabled'
        assert result['selinux']['type'] != 'unknown'
        assert result['selinux']['config_mode'] != 'unknown'
    else:
        # Test no exceptions are raised if we don't have the selinux library
        m = SelinuxFactCollector()
        result = m.collect(module=None, collected_facts=None)
        assert result['selinux_python_present'] == False

# Generated at 2022-06-20 19:57:21.810831
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    from ansible.module_utils._selinux import is_selinux_enabled
    from ansible.module_utils._selinux import security_getenforce
    from ansible.module_utils._selinux import security_policyvers
    from ansible.module_utils._selinux import security_python_present
    from ansible.module_utils._selinux import selinux_getenforcemode
    from ansible.module_utils._selinux import selinux_getpolicytype

    import sys

    saved_environ = None
    saved_enforcemode = None
    saved_policytype = None
    selinux_python_modules = ['selinux', '_selinux']

    def mock__init__(self, *args):
        pass
    SavedPolicyType = None


# Generated at 2022-06-20 19:57:24.443598
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fc = SelinuxFactCollector()
    result = fc.collect()

    assert result.get('selinux')
    assert result.get('selinux_python_present') is not None

# Generated at 2022-06-20 19:57:27.797194
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test if Selinux is enabled and the status is either enabled or disabled."""
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    selinux_facts = SelinuxFactCollector()
    facts = selinux_facts.collect()
    assert facts['selinux']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-20 19:57:38.970139
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector, get_collector_instance
    from ansible.module_utils.facts import aux_facts

    class BaseFactCollectorWrapper(BaseFactCollector):
        _fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            return {}

    class TestSelinuxCollector(SelinuxFactCollector):
        def collect(self, module=None, collected_facts=None):
            collected_facts = {'selinux': {'status': 'enabled'}}
            return super(TestSelinuxCollector, self).collect(module=module, collected_facts=collected_facts)

    class TestFactCollector(FactCollector):
        _fact_ids = set()

# Generated at 2022-06-20 19:57:50.555577
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Check that the SelinuxFactCollector class has the attribute
    # name == selinux
    assert selinux_fact_collector.name == 'selinux'

    # Check that the SelinuxFactCollector class has the attribute
    # _fact_ids == set()
    assert selinux_fact_collector._fact_ids == set()

    # Check that the facts dictionary contains the correct SELinux
    # information
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict

# Generated at 2022-06-20 19:57:55.410733
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Unit test for constructor of class SelinuxFactCollector.
    """
    assert SelinuxFactCollector.name is not None
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids is not None
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:58:06.140405
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector({'selinux': {}})

    # Disable SELinux
    selinux_collector.module_commands['selinux_python_present'] = False
    assert selinux_collector.collect()['selinux'] == {'status': 'Missing selinux Python library'}

    # Enable SELinux but disable Python library
    selinux_collector.module_commands['selinux_python_present'] = True
    selinux_collector.module_commands['is_selinux_enabled'] = True
    assert selinux_collector.collect()['selinux'] == {'status': 'enabled', 'policyvers': 'unknown',
                                                      'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}

# Generated at 2022-06-20 19:58:09.237949
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    result = SelinuxFactCollector().collect()
    assert result == {'selinux': {'status': 'disabled'}, 'selinux_python_present': True}

# Test helper function

# Generated at 2022-06-20 19:58:12.052012
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:58:17.369423
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_dict = SelinuxFactCollector().collect()
    assert 'selinux' in facts_dict
    assert facts_dict['selinux'] == {'status': 'disabled'}

# Generated at 2022-06-20 19:59:36.236100
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # mock the facts collector
    SelinuxFactCollector = SelinuxFactCollector()

    # mock the facts
    facts_dict = {
        'ansible_selinux': {
            'config_mode': 'enforcing',
            'mode': 'enforcing',
            'policyvers': '28',
            'status': 'enabled',
            'type': 'targeted'
        },
        'selinux_python_present': True
    }

    # call the function and test results
    true_dict = SelinuxFactCollector.collect()
    assert facts_dict == true_dict

# Generated at 2022-06-20 19:59:38.169299
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    collector.collect()

# Generated at 2022-06-20 19:59:49.093090
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for ansible.module_utils.facts.system.selinux.SelinuxFactCollector.collect"""
    #
    # 1. Test if all values are present when selinux is not missing
    #
    # Create a SelinuxFactCollector object
    selinux_fact_collector_object = SelinuxFactCollector()

    # Set selinux.is_selinux_enabled return value to return true
    selinux.is_selinux_enabled = MagicMock(return_value=True)

    # Set selinux.security_policyvers return value to return some integer
    selinux.security_policyvers = MagicMock(return_value=1234)

    # Set selinux.selinux_getenforcemode return value to return 0 and use the same value for
    # configmode

# Generated at 2022-06-20 19:59:50.643959
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert 'status' in facts['selinux']

# Generated at 2022-06-20 19:59:53.204056
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    assert selinux_fact_collector_obj.name == 'selinux'
    assert not selinux_fact_collector_obj._fact_ids


# Generated at 2022-06-20 20:00:04.662966
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Check that method collect return the correct dictionary of
    selinux facts.
    """

    # Mock selinux library
    temp_selinux = selinux
    selinux = object()
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: 42
    selinux.selinux_getenforcemode = lambda: (0, 0)
    selinux.security_getenforce = lambda: 1
    selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()
    selinux_facts = facts_dict.get('selinux')

    assert facts_dict.get('selinux_python_present') is True
    assert selinux_

# Generated at 2022-06-20 20:00:06.300677
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 20:00:09.218199
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create a SelinuxFactCollector object
    selinux_fc = SelinuxFactCollector()

    # Assert that the values are set
    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == set()


# Generated at 2022-06-20 20:00:12.113927
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Skip this test if the selinux library is not available
    if not HAVE_SELINUX:
        return

    selinux_collector = SelinuxFactCollector()

    facts_dict = selinux_collector.collect()

    assert facts_dict['selinux']['status'] == 'enabled'

# Generated at 2022-06-20 20:00:20.033183
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {
        'config_mode': 'enabled',
        'mode': 'enforcing',
        'status': 'enabled',
        'type': 'targeted',
    }
    # TODO: move this function to an external library
    import sys
    import os.path
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    from ansible.module_utils.facts.collectors import selinux
    try:
        collector = selinux.SelinuxFactCollector()
        result = collector.collect({})
    except Exception as e:
        print(e)

    assert result is not None
    assert result['selinux'] == selinux_facts