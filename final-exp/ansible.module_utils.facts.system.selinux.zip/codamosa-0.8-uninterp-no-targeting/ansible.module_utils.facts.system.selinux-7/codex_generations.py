

# Generated at 2022-06-20 19:53:36.002690
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import json
    import selinux
    class MockSelinux:
        @staticmethod
        def is_selinux_enabled():
            return True
        @staticmethod
        def security_policyvers():
            return 1
        @staticmethod
        def selinux_getenforcemode():
            return (0,2)
        @staticmethod
        def security_getenforce():
            return 1
        @staticmethod
        def selinux_getpolicytype():
            return 'targeted'
    facts_dict = SelinuxFactCollector().collect()

# Generated at 2022-06-20 19:53:43.016766
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    ret = fact_collector.collect()

    assert 'selinux' in ret
    assert 'selinux_python_present' in ret

    if HAVE_SELINUX:
        assert 'status' in ret['selinux']
    else:
        assert 'Missing selinux Python library' == ret['selinux']['status']

# Generated at 2022-06-20 19:53:45.227174
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Create an instance of SelinuxFactCollector
    """
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-20 19:53:47.586303
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-20 19:53:49.765410
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:53:53.792971
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the collect method of the SelinuxFactCollector
    """
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    # Should return selinux and selinux_python_present keys
    assert sorted(selinux_facts.keys()) == ['selinux', 'selinux_python_present']

# Generated at 2022-06-20 19:54:05.212427
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test when selinux python module is present
    try:
        import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    if HAVE_SELINUX:
        result = SelinuxFactCollector().collect()
        expected = {
            "selinux": {
                "type": "targeted",
                "config_mode": "enforcing",
                "mode": "enforcing",
                "policyvers": "28",
            },
            "selinux_python_present": True,
        }
    else:
        result = SelinuxFactCollector().collect()
        expected = {
            "selinux": {
                "status": "Missing selinux Python library",
            },
            "selinux_python_present": False,
        }

# Generated at 2022-06-20 19:54:10.638287
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:54:19.628339
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def mock_is_selinux_enabled():
        return True
    def mock_selinux_getenforcemode():
        return (0,1)
    def mock_security_getenforce():
        return 1
    def mock_selinux_getpolicytype():
        return (0, 'targeted')

    facts_dict = {}
    selinux_facts = {}
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = '26'
    selinux_facts['config_mode'] = 'enforcing'
    selinux_facts['mode'] = 'enforcing'
    selinux_facts['type'] = 'targeted'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = True


# Generated at 2022-06-20 19:54:21.637516
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact = SelinuxFactCollector()
    assert fact
    assert fact.name == 'selinux'

# Generated at 2022-06-20 19:54:32.345332
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 19:54:38.890370
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfc = SelinuxFactCollector()
    assert selinuxfc.name == 'selinux'
    assert selinuxfc._fact_ids == set()
    # test if SelinuxFactCollector was included in facts_collected
    assert selinuxfc.name in SelinuxFactCollector.__all__


# Generated at 2022-06-20 19:54:41.585491
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    f = SelinuxFactCollector()
    assert f.name == "selinux"
    assert f.provides() == "selinux"
    assert f._fact_ids == set()


# Generated at 2022-06-20 19:54:48.370447
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from collections import namedtuple
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts.collector import Collector

    # Build selinuxcollector object
    selinux_collector = SelinuxFactCollector(namedtuple('Module', [])(), {})

    # Build empty facts dictionary
    collected_facts = {}

    # Call method collect and check returned result is as expected
    result = selinux_collector.collect(module=None, collected_facts=collected_facts)
    assert result == {'selinux_python_present': True, 'selinux': {'type': 'unknown', 'status': 'enabled', 'mode': 'unknown', 'config_mode': 'unknown', 'policyvers': 'unknown'}}


# Generated at 2022-06-20 19:54:56.345272
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'selinux' in facts
    assert isinstance(facts['selinux'], dict)
    assert 'policyvers' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'type' in facts['selinux']
    assert 'status' in facts['selinux']

# Generated at 2022-06-20 19:55:05.230228
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    facts_dict = {}
    selinux_facts = {}

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
        return facts_dict

    # Set a boolean for testing whether the Python library is present
    facts_dict['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        selinux_facts['status'] = 'disabled'
    else:
        se

# Generated at 2022-06-20 19:55:09.614702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    my_selinux = SelinuxFactCollector()
    selinux_facts = my_selinux.collect()

    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts.keys()
    assert 'status' in selinux_facts['selinux'].keys()
    assert 'selinux_python_present' in selinux_facts.keys()

# Generated at 2022-06-20 19:55:18.807842
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the object, and collect selinux facts
    sfc = SelinuxFactCollector()
    facts_dict = sfc.collect()

    # Assert result is of type dict
    assert isinstance(facts_dict, dict)

    # Assert result for key 'selinux' is of type dict
    assert isinstance(facts_dict['selinux'], dict)

    # Assert result for key 'selinux_python_present' is of type bool
    assert isinstance(facts_dict['selinux_python_present'], bool)

# Generated at 2022-06-20 19:55:27.149965
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # set up
    selinux_facts_dict = {
        'selinux': {
            'status': 'enabled',
            'mode': 'enforcing',
            'type': 'targeted',
            'config_mode': 'enforcing',
            'policyvers': '28'
        },
        'selinux_python_present': True
    }
    # test without selinux Python library and without selinux enabled
    with mock.patch.dict(selinux.__dict__, {'is_selinux_enabled': lambda: False}):
        selinuxFactCollector = SelinuxFactCollector()
        assert selinuxFactCollector.collect() == {'selinux': {'status': 'disabled'}, 'selinux_python_present': True}

    # test with selinux Python library and selinux enabled
   

# Generated at 2022-06-20 19:55:29.363834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_info = SelinuxFactCollector()
    assert selinux_info.name == 'selinux'



# Generated at 2022-06-20 19:55:48.669223
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import pytest
    info = SelinuxFactCollector()
    assert isinstance(info, BaseFactCollector)
    assert info.name == 'selinux'
    assert info.priority == 101
    assert isinstance(info._fact_ids, set)
    assert info._fact_ids == set()
    if sys.version_info[0] == 2:
        assert isinstance(info.collect()['selinux'], dict)
    else:
        assert isinstance(info.collect()['selinux'], dict)
        assert isinstance(info.collect()['selinux_python_present'], bool)
    # assert info.collect()['selinux'].keys() == ['status']


# Generated at 2022-06-20 19:55:52.757814
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids is not None

# Generated at 2022-06-20 19:55:55.147044
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'


# Generated at 2022-06-20 19:55:58.923788
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Create a placeholder object of class SelinuxFactCollector
    obj = SelinuxFactCollector()

    # Check if the class variables are assigned correctly
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:56:03.128056
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert 'selinux_python_present' in selinux_facts._fact_ids
    assert not selinux_facts._legacy_warnings
    assert not selinux_facts._warning

# Generated at 2022-06-20 19:56:05.314248
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)


# Generated at 2022-06-20 19:56:06.701034
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    f = SelinuxFactCollector()
    assert f.name == 'selinux'

# Generated at 2022-06-20 19:56:16.106509
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This method tests that the
    SelinuxFactCollector.collect() method
    returns the expected data
    """

    import ansible.module_utils.facts.fact_collector

    # below is what we would need to mock
    # for the collect() method
    class MockSelinux(object):
        def is_selinux_enabled(self):
            return True

        def getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 0

        def getpolicytype(self):
            return (0, 'targeted')

        def security_policyvers(self):
            return 29

    selinux_mock = MockSelinux()

    # mock the selinux module
    class MockModule(object):
        def __init__(self):
            self

# Generated at 2022-06-20 19:56:23.971220
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Given
    SELINUX_FACTS = dict(
        selinux=dict(
            status='enabled',
            mode='enforcing',
            config_mode='enforcing',
            policyvers=32,
            type='targeted',
        ),
        selinux_python_present=True
    )
    selinux_collector = SelinuxFactCollector()

    # When
    selinux_collector.collect()

    # Then
    assert selinux_collector._facts == SELINUX_FACTS

# Generated at 2022-06-20 19:56:32.496552
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    res = collector.collect()

    assert 'selinux' in res
    assert 'selinux_python_present' in res

    if selinux.is_selinux_enabled():
        assert res['selinux']['status'] == 'enabled'
    else:
        assert res['selinux']['status'] == 'disabled'
    assert 'config_mode' in res['selinux']
    assert 'policyvers' in res['selinux']
    assert 'mode' in res['selinux']
    assert 'type' in res['selinux']

# Generated at 2022-06-20 19:57:00.202696
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Test a successful instantiation without selinux library
    if not HAVE_SELINUX:
        test_obj = SelinuxFactCollector()
        assert test_obj

    # Test a successful instantiation with selinux library
    # Need to mock selinux.is_selinux_enabled(). Since this is a static method,
    # selinux can be mocked as the class itself
    if HAVE_SELINUX:
        import mock
        with mock.patch.object(selinux, 'is_selinux_enabled', return_value=True):
            test_obj = SelinuxFactCollector()
            assert test_obj

    return

# Generated at 2022-06-20 19:57:06.637602
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()

    if HAVE_SELINUX:
        assert facts_dict['selinux_python_present'] is True
        assert 'policyvers' in facts_dict['selinux']
        assert 'config_mode' in facts_dict['selinux']
        assert 'mode' in facts_dict['selinux']
        assert 'type' in facts_dict['selinux']
    else:
        assert facts_dict['selinux_python_present'] is False
        assert 'config_mode' not in facts_dict['selinux']
        assert 'mode' not in facts_dict['selinux']
        assert 'type' not in facts_dict['selinux']

# Generated at 2022-06-20 19:57:11.041437
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    import platform
    import sys

    # Detect Linux platform
    if platform.system() != 'Linux':
        pytest.skip('Skipping selinux tests on non-Linux platform')

    # Detect and skip over Python 3.7 as the selinux module has some bugs on this platform
    if sys.version_info[0:3] == (3, 7, 0):
        pytest.skip('Skipping selinux tests on Python 3.7 due to bugs in the module')

    def test_collect():
        sf = SelinuxFactCollector()
        facts = sf.collect()
        assert isinstance(facts, dict)
        assert 'selinux_python_present' in facts
        assert isinstance(facts['selinux_python_present'], bool)

# Generated at 2022-06-20 19:57:15.173599
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts_collector = SelinuxFactCollector()
    facts_dict = selinux_facts_collector.collect()

    # The following keys should be returned in the facts dictionary
    # by the collect method of the SelinuxFactCollector class.
    assert('selinux' in facts_dict)
    assert('selinux_python_present' in facts_dict)

# Unit tests for class SelinuxFactCollector

# Generated at 2022-06-20 19:57:19.672086
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-20 19:57:24.669628
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test_SelinuxFactCollector_collect"""

    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()

    # Check for each returned key that it is non-empty
    for key in facts_dict['selinux']:
        assert facts_dict['selinux'][key] is not None, "Key '%s' was None" % (key)


# Generated at 2022-06-20 19:57:30.609673
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Creating a mock module and a mock selinux module.
    module = Mock()
    selinux_mock = Mock()

    # Set an attribute of the mock selinux module if Python library is present.
    selinux_mock.is_selinux_enabled = lambda: True
    selinux_mock.security_policyvers = lambda: '30'
    selinux_mock.selinux_getenforcemode = lambda: (0, 1)
    selinux_mock.security_getenforce = lambda: 1
    selinux_mock.selinux_getpolicytype = lambda: (0, 'targeted')
    module.selinux = selinux_mock

    # If selinux library is missing, set the status and selinux_python_present
    # to return False.

# Generated at 2022-06-20 19:57:40.401834
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector


# Generated at 2022-06-20 19:57:42.590043
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-20 19:57:45.922128
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-20 19:58:40.041879
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:58:49.522843
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test case:
    # Create an instance of SelinuxFactCollector.  Verify that the
    # class and name members are correct.
    sfc = SelinuxFactCollector()
    assert sfc.__class__.__name__ == 'SelinuxFactCollector'
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

    # Test case:
    # Create an instance of SelinuxFactCollector.  Verify that
    # facts about selinux are returned when selinux is installed.
    # In this test, we will not mock selinux.is_selinux_enabled().
    # We will just return a dictionary with the expected facts.
    sfc = SelinuxFactCollector()
    sfc.HAVE_SELINUX = True
    sfc.selin

# Generated at 2022-06-20 19:59:03.002635
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    class StubFactsCollector(FactsCollector):
        name = "StubFactsCollector"

        def __init__(self, module=None, collected_facts=None):
            self.collected_facts = collected_facts

        def collect(self, module=None, collected_facts=None):
            return collected_facts

        def post_process_facts(self, facts):
            return facts

    # Check the availability of the selinux Python library is unknown
    # if the library cannot be imported.

# Generated at 2022-06-20 19:59:14.318872
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = {}
    selinux_facts = {}

    assert (HAVE_SELINUX == True)

    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
        return facts_dict

    # Set a boolean for testing whether the Python library is present
    facts_dict['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        selinux_facts['status'] = 'disabled'
    else:
        selinux_facts['status'] = 'enabled'


# Generated at 2022-06-20 19:59:16.571297
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"

# Generated at 2022-06-20 19:59:18.805668
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    obj = SelinuxFactCollector()
    result = obj.collect()
    assert result['selinux_python_present'] is not None

# Generated at 2022-06-20 19:59:21.490863
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:59:28.747948
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    import ansible.module_utils.selinux as selinux
    import selinux as selinux_sys

    sfc = SelinuxFactCollector()

    class MockSelinux(object):
        """Mock class for selinux module"""
        def __init__(self):
            pass

        def __getattr__(self, _):
            def method():
                return

            return method

    class MockSelinuxSys(object):
        """Mock class for selinux module"""
        def __init__(self):
            pass

        def __getattr__(self, _):
            def method(*_, **__):
                return 0

            return method


    # Mock selinux module
    selinux.old_sys

# Generated at 2022-06-20 19:59:31.421720
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:59:37.942752
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Do not fail if selinux Python library is missing
    import sys
    import imp
    for path in sys.path:
        if path is not None:
            (file, pathname, description) = imp.find_module('selinux', [path])
            if file:
                imp.load_module('selinux', file, pathname, description)
                break
    else:
        imp.find_module('selinux')

    selinux_facts = SelinuxFactCollector().collect()
    assert "selinux" in selinux_facts

# Generated at 2022-06-20 20:01:26.965032
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert 'selinux' not in selinux_fact_collector._fact_ids

# Generated at 2022-06-20 20:01:29.273339
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-20 20:01:39.567810
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import tempfile
    import shutil
    import os
    import stat

    def touch(path):
        with open(path, 'a'):
            os.utime(path, None)
            os.chmod(path, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    # Create directory for test
    tempdir = tempfile.mkdtemp()
    # Change directory
    os.chdir(tempdir)

    class MockModule(object):
        def __init__(self):
            self.params = ''

    # init class and test if selinux_python_present is true
    obj = SelinuxFactCollector(MockModule(), {})
    assert obj.collect()['selinux_python_present'] is True

    # Create stub for missing se

# Generated at 2022-06-20 20:01:43.480827
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == { 'selinux', 'selinux_python_present' }


# Generated at 2022-06-20 20:01:44.531523
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-20 20:01:55.430217
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_facts = SelinuxFactCollector()

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        selinux_facts.collect()
        assert selinux_facts.collect() == {
            'selinux': {
                'status': 'Missing selinux Python library'
            },
            'selinux_python_present': False
        }

    # Test the case where SELinux is disabled
    if HAVE_SELINUX:
        selinux.selinux_getenforcemode = lambda: (1, 0)
        selinux.selinux_getpolicytype = lambda: (1, 'MLS')

# Generated at 2022-06-20 20:01:57.782633
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-20 20:01:59.097905
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'

# Generated at 2022-06-20 20:02:04.850972
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    # Construct instance of SelinuxFactCollector
    obj = SelinuxFactCollector()

    # Verify instance of SelinuxFactCollector created successfully
    assert isinstance(obj, SelinuxFactCollector)

    # Verify inheritance
    assert issubclass(SelinuxFactCollector, BaseFactCollector)

    # Verify that SelinuxFactCollector is registered as a fact collector
    assert SelinuxFactCollector in collector._fact_collectors

    # Verify that the fact_ids set is as expected
    assert obj._fact_ids == set()



# Generated at 2022-06-20 20:02:08.128629
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    ans = collector.collect()
    assert isinstance(ans, dict)