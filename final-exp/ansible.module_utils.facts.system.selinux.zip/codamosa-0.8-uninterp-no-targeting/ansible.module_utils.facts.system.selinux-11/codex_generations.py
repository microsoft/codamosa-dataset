

# Generated at 2022-06-20 19:53:23.448966
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'

# Generated at 2022-06-20 19:53:35.101137
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import platform
    import os
    os_name = platform.system()
    if os_name == 'Linux':
        distro = platform.dist()[0].lower()
        if distro == 'redhat' or distro == 'scientific' or distro == 'fedora':
            module = 'ansible.module_utils.facts.collector.redhat_subscription'
            try:
                module = __import__(module, fromlist=['redhat_subscription'])
            except ImportError:
                pass
        elif distro == 'debian' or distro == 'ubuntu':
            module = 'ansible.module_utils.facts.collector.lsb'
            try:
                module = __import__(module, fromlist=['lsb'])
            except ImportError:
                pass

# Generated at 2022-06-20 19:53:43.940360
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup module class Mock
    module = Mock()

    # Setup a mock selinux library.
    # Force the selinux Python library to be missing
    if HAVE_SELINUX:
        selinux = Mock()
        selinux.is_selinux_enabled = Mock(return_value=1)
        selinux.security_policyvers = Mock(return_value=25)
        selinux.selinux_getenforcemode = Mock(return_value=(0, 1))
        selinux.security_getenforce = Mock(return_value=1)
        selinux.selinux_getpolicytype = Mock(return_value=(0, 'targeted'))
        selinux.security_policyvers.__name__ = 'security_policyvers'

# Generated at 2022-06-20 19:53:55.590255
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Setup the module and required imports
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.six.moves import builtins

    # Setup AnsibleModule for testing
    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    # AnsibleModule calls import_module to import the module code
    # In other words, this is the module code under test
    builtins.__import__ = lambda x: None

    # Create an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector(module)

    # Create a mock of selinux module to return returned_dict
    selinux_mock = Mock()

# Generated at 2022-06-20 19:54:06.350206
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create object of class SelinuxFactCollector
    selinux_fc = SelinuxFactCollector()

    # create empty dict
    collected_facts = {}

    # call method collect
    facts_dict = selinux_fc.collect(collected_facts=collected_facts)

    # test if selinux_python_present is set in facts_dict
    assert isinstance(facts_dict['selinux_python_present'], bool)

    # if selinux Python library is not present, test if selinux fact is None
    if facts_dict['selinux_python_present'] is False:
        assert facts_dict['selinux'] is None

    # if selinux Python library is present, test if selinux fact is not None
    if facts_dict['selinux_python_present'] is True:
        assert facts_dict

# Generated at 2022-06-20 19:54:13.754458
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    import sys

    if sys.version_info[0] >= 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    from ansible.module_utils.facts.collector import BaseFactCollector

    x = SelinuxFactCollector()
    assert x
    assert isinstance(x, BaseFactCollector)
    assert x.name == 'selinux'



# Generated at 2022-06-20 19:54:20.957941
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.utils.selinux import MockSelinux
    selinux = MockSelinux()
    fact_collector = SelinuxFactCollector(None, None)
    facts_dict = fact_collector.collect(None, None)
    assert 'selinux' in facts_dict
    assert 'selinux' not in facts_dict
    assert 'selinux_python_present' not in facts_dict

    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = 0
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1

# Generated at 2022-06-20 19:54:26.919614
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Check whether facts dict is empty or not,
    # if empty then return empty dict else return dict with key selinux
    collector = SelinuxFactCollector()
    assert not collector.collect()

    # If selinux Python library is not present, then it should return dict
    # with selinux_python_present key.
    collector.HAVE_SELINUX = False
    result = collector.collect()
    assert result.get('selinux_python_present') == False

# Generated at 2022-06-20 19:54:30.216795
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    facts = {'selinux_python_present': True}
    result = collector.collect(collected_facts=facts)

    assert result['selinux']['status'] == 'disabled'

# Generated at 2022-06-20 19:54:32.614500
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()
    assert x.fact_subset == dict()


# Generated at 2022-06-20 19:54:48.465387
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    if sys.platform.startswith('darwin'):
        # no selinux on OSX
        return

    import platform
    if platform.machine().startswith('s390'):
        # no selinux on s390
        return

    import os
    if os.system('which getenforce >/dev/null 2>&1') != 0:
        return

    import subprocess
    import tempfile
    if not os.path.exists('/sys/fs/selinux'):
        saved_path = os.environ['PATH']
        restore_path = False

# Generated at 2022-06-20 19:54:58.680833
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module_mock = None
    facts_dicts = []

    # mock for HAVE_SELINUX
    original_have_selinux = __import__('ansible.module_utils.facts.system.selinux').HAVE_SELINUX
    __import__('ansible.module_utils.facts.system.selinux').HAVE_SELINUX = True

    # mock for selinux.is_selinux_enabled()
    original_is_selinux_enabled = __import__('ansible.module_utils.facts.system.selinux').selinux.is_selinux_enabled
    __import__('ansible.module_utils.facts.system.selinux').selinux.is_selinux_enabled = lambda: True

    # mock for selinux.security_policyvers()

# Generated at 2022-06-20 19:55:00.665234
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.collect() == {}

# Generated at 2022-06-20 19:55:05.247625
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create new SelinuxFactCollector object
    obj = SelinuxFactCollector()

    # Check name, _fact_ids and _fact_class attributes
    assert obj.name == "selinux"
    assert obj._fact_ids == set()
    assert obj._fact_class is None

    # Check if collect method exists
    assert callable(obj.collect)


# Generated at 2022-06-20 19:55:06.479200
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:55:10.082812
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sfc = SelinuxFactCollector()
    facts = sfc.collect()
    if facts['selinux']['mode'] == 'unknown':
        print("selinux:  mode is unknown")
    else:
        print("selinux:  mode = ", facts['selinux']['mode'])

    if facts['selinux']['config_mode'] == 'unknown':
        print("selinux:  config_mode is unknown")
    else:
        print("selinux:  config_mode = ", facts['selinux']['config_mode'])

    if facts['selinux']['type'] == 'unknown':
        print("selinux:  type is unknown")
    else:
        print("selinux:  type = ", facts['selinux']['type'])

# Generated at 2022-06-20 19:55:21.727286
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector instance
    selinux_fact = SelinuxFactCollector()

    # Create a test dictionary
    collected_facts = dict()

    # Get the facts from the class
    test_facts = selinux_fact.collect(collected_facts=collected_facts)

    # Test the results and verify we can get expected results
    assert test_facts is not None
    assert 'selinux' in test_facts

    # Test the results for a python library present and selinux disabled
    assert 'status' in test_facts['selinux']
    assert 'disabled' in test_facts['selinux']['status']
    assert 'policyvers' in test_facts['selinux']
    assert 'unknown' in test_facts['selinux']['policyvers']
    assert 'config_mode'

# Generated at 2022-06-20 19:55:28.519206
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()['selinux']

    # Check status
    assert facts['status'] in ('enabled', 'disabled', 'Missing selinux Python library')

    # Check that we don't try to collect policyvers when selinux is not enabled
    assert not ('policyvers' in facts and facts['status'] == 'disabled')

    # Check that we don't try to collect mode when selinux is not enabled
    assert not ('mode' in facts and facts['status'] == 'disabled')

    # Check that we don't try to collect policyvers when selinux is not enabled
    assert not ('type' in facts and facts['status'] == 'disabled')

    # Check that we don't try to collect config_mode when selinux is not enabled

# Generated at 2022-06-20 19:55:33.108955
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    prt_object = SelinuxFactCollector()
    assert prt_object.name == 'selinux'
    assert 'selinux' in prt_object._fact_ids
    assert 'selinux_python_present' in prt_object._fact_ids


# Generated at 2022-06-20 19:55:36.753944
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    se = SelinuxFactCollector()
    assert se.name == 'selinux'
    assert se._fact_ids == set()

# Generated at 2022-06-20 19:55:55.188759
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactcollector = SelinuxFactCollector()
    assert selinuxfactcollector


# Generated at 2022-06-20 19:56:05.274529
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {
        'config_mode': 'disabled',
        'status': 'disabled',
        'type': 'targeted',
        'mode': 'disabled',
        'policyvers': '28'
    }

    # Make sure selinux_python_present is not in selinux_facts
    assert 'selinux_python_present' not in selinux_facts

    # Make sure the selinux facts are set in the selinux_facts returned from collect
    selinux_facts_returned = SelinuxFactCollector().collect()['selinux']
    for (key, value) in selinux_facts.items():
        assert key in selinux_facts_returned
        assert selinux_facts_returned[key] == value

    # Make sure selinux_python_present is set in the selinux_facts returned from collect

# Generated at 2022-06-20 19:56:07.736506
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-20 19:56:10.098296
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector

# Generated at 2022-06-20 19:56:15.153416
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a test instance of SelinuxFactCollector and check that
    # the result from calling method collect on it is correct
    f = SelinuxFactCollector()
    selinux_facts = f.collect()

    # For the moment the test is only checking that the result is a dict
    assert isinstance(selinux_facts, dict)
    for key in ['selinux', 'selinux_python_present']:
        assert key in selinux_facts



# Generated at 2022-06-20 19:56:25.792531
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxMacros = {
        'security_getenforce.retval': '0',
        'security_getenforce.return_value': 'enforcing',
        'security_policyvers.retval': '0',
        'security_policyvers.return_value': '20.0',
        'selinux_getenforcemode.retval': '0',
        'selinux_getenforcemode.configmode': 'enforcing',
        'selinux_getpolicytype.retval': '0',
        'selinux_getpolicytype.policytype': 'targeted',
    }
    selinuxCollector = SelinuxFactCollector(None, None, selinuxMacros)
    selinuxResult = selinuxCollector.collect()
    print(selinuxResult)

# Generated at 2022-06-20 19:56:27.103557
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-20 19:56:30.601209
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # A class object is returned when constructing class SelinuxFactCollector
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)

# Generated at 2022-06-20 19:56:35.543152
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # (1) If selinux is not present, set error
    selinux_info = SelinuxFactCollector()
    result = selinux_info.collect()
    assert result['selinux']['status'] == 'Missing selinux Python library'
    assert result['selinux_python_present'] == False

# Generated at 2022-06-20 19:56:38.129230
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Set up SelinuxFactCollector object
    sfc = SelinuxFactCollector()

    # Check whether the collect method returns a dict object
    assert isinstance(sfc.collect(), dict)

# Generated at 2022-06-20 19:57:16.584468
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        import selinux
    except ImportError:
        raise
    # Constructor function of class SelinuxFactCollector
    sfc = SelinuxFactCollector()
    # Check the name of the instance and whether the selinux module is present
    assert sfc.name == 'selinux'
    assert sfc.HAVE_SELINUX == True

# Generated at 2022-06-20 19:57:19.217036
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    selinux_fact_collector.collect()

# Generated at 2022-06-20 19:57:22.129820
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector_obj = SelinuxFactCollector()
    assert selinux_collector_obj.name == 'selinux'
    assert selinux_collector_obj._fact_ids == set()


# Generated at 2022-06-20 19:57:26.128679
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    keys = [
        'selinux',
        'selinux_python_present'
    ]
    for key in keys:
        assert key in facts
    assert 'enabled' in facts['selinux']['status'] or 'disabled' in facts['selinux']['status']


# Generated at 2022-06-20 19:57:39.153160
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    if not HAVE_SELINUX:
        pytest.skip('Selinux module is not installed')
    import ansible.module_utils.facts.system.selinux
    from ansible.module_utils.facts.system.selinux import (
        OFF,
        ENABLED,
        PERMISSIVE,
        ENABLING,
        ENFORCING,
        DISABLING,
        SELINUX_CONFIG_FILE,
    )
    from ansible.module_utils import facts

    # Mockup the module utils functions
    # Return the current value of enforcing
    def mock_selinux_getenforce():
        if facts.SELINUX_MODE == OFF:
            return -1

# Generated at 2022-06-20 19:57:41.102106
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector(None)
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:57:47.481518
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Tests SelinuxFactCollector constructor
    """
    myselinux = SelinuxFactCollector()

    # Test if instance is created successfully
    assert myselinux is not None

    # Test if instance has the right variables
    assert myselinux.name == 'selinux'

# Unit tests for the collect() method of class SelinuxFactCollector

# Generated at 2022-06-20 19:57:53.249947
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''Unit test for method collect of class SelinuxFactCollector'''
    selinux = SelinuxFactCollector()
    facts_dict = selinux.collect()

    assert "selinux" in facts_dict
    assert "selinux_python_present" in facts_dict

# Generated at 2022-06-20 19:58:00.285260
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Testing collect method when is_selinux_enabled returns False
    selinux_instance = SelinuxFactCollector()
    selinux_instance.collect()
    return selinux_instance.fact_list == [{'selinux': {}, 'selinux_python_present': False}]

# Test case to check return value of collect when is_selinux_enabled returns a value

# Generated at 2022-06-20 19:58:03.985179
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:58:51.341572
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Set up the parameters for input to the collect method
    module = None
    collected_facts = {}

    # Initalize a new collector object
    Selinux = SelinuxFactCollector()
    collected_facts = Selinux.collect(module, collected_facts)
    assert collected_facts['selinux_python_present'] == True
    assert collected_facts['selinux']['status'] == 'enabled'
    assert collected_facts['selinux']['policyvers'] == 'unknown'
    assert collected_facts['selinux']['config_mode'] == 'unknown'
    assert collected_facts['selinux']['mode'] == 'unknown'
    assert collected_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-20 19:58:53.481613
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:58:55.925507
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:59:01.382593
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_obj = SelinuxFactCollector()
    result = selinux_obj.collect()
    assert result['selinux']['status'] == 'unknown'
    assert result['selinux_python_present'] == False

if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-20 19:59:07.720333
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test selinux fact collection"""
    collector = SelinuxFactCollector()
    fact_dict = collector.collect()
    assert 'selinux_python_present' in fact_dict, \
        'selinux fact collector failed to collect python library presence'
    assert 'selinux' in fact_dict, \
        'selinux fact collector failed to collect facts'

# Generated at 2022-06-20 19:59:10.773737
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:59:21.113640
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {'config_mode': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown', 'status': 'Missing selinux Python library'}
    # If the selinux library is missing, only run the test to check for the missing library message.
    # The rest of the tests fail without the library.
    if not HAVE_SELINUX:
        test_collector = SelinuxFactCollector()
        facts_dict = test_collector.collect()
        assert facts_dict['selinux'] == selinux_facts
        assert not facts_dict['selinux_python_present']
    else:
        test_collector = SelinuxFactCollector()
        facts_dict = test_collector.collect()
        assert facts_dict['selinux_python_present']

# Generated at 2022-06-20 19:59:32.253540
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # if the library is present and selinux is enabled
    selinux_present = True
    selinux_enabled = True

    #test with selinux enabled
    selinux_fact = SelinuxFactCollector(None, None, None, None)
    selinux_fact._module = MagicMock()
    selinux_fact._module.HAVE_SELINUX = selinux_present
    selinux_fact._module.selinux.is_selinux_enabled = MagicMock(return_value=selinux_enabled)
    selinux_fact._module.selinux.security_policyvers = MagicMock(return_value="1.0")
    selinux_fact._module.selinux.selinux_getenforcemode = MagicMock(return_value=(0,1))
    selinux_fact._module

# Generated at 2022-06-20 19:59:33.787202
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector

# Generated at 2022-06-20 19:59:36.418643
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_dict = selinux_collector.collect(None, None)
    assert('selinux' in selinux_dict)

# Generated at 2022-06-20 20:00:26.270818
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    name = selinux_fact_collector.name
    assert name == 'selinux'
    _fact_ids = selinux_fact_collector._fact_ids

# Generated at 2022-06-20 20:00:31.069105
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_ins = SelinuxFactCollector()
    assert selinux_ins.name == 'selinux'
    assert selinux_ins._fact_ids == set()


# Generated at 2022-06-20 20:00:36.125410
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Setup
    selinux_coll = SelinuxFactCollector()
    selinux_coll.collect()

    # Test assertions
    # Test that the selinux_collector adds 'selinux_python_present'
    assert 'selinux_python_present' in selinux_coll.collect()

    # Test that the selinux_collector adds 'selinux_python_present'
    assert 'selinux' in selinux_coll.collect()

# Generated at 2022-06-20 20:00:47.401860
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        selinux.is_selinux_enabled
    except AttributeError:
        # The fact collector is not tested if selinux library is missing
        # or if it doesn't include the is_selinux_enabled function.
        return

    selinux_enabled = selinux.is_selinux_enabled()

    facts_dict = SelinuxFactCollector().collect()

    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['selinux'], dict)
    assert isinstance(facts_dict['selinux_python_present'], bool)

    if selinux_enabled:
        assert 'status' in facts_dict['selinux']
        assert 'config_mode' in facts_dict['selinux']
        assert 'mode' in facts_dict['selinux']
       

# Generated at 2022-06-20 20:00:49.974958
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set() # pylint: disable=protected-access

# Generated at 2022-06-20 20:01:02.098401
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six import PY2
    import selinux
    import socket

    collector = SelinuxFactCollector()
    facts_dict = {}
    expected_dict = {
        'selinux': {
            'type': 'targeted',
            'config_mode': 'enforcing',
            'status': 'enabled',
            'mode': 'enforcing',
            'policyvers': 28
        },
        'selinux_python_present': True

    }

    # Code to run when library is present
    if PY2:
        selinux.security_setenforce = lambda mode: 0

# Generated at 2022-06-20 20:01:03.023175
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 20:01:11.857244
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test that SelinuxFactCollector.collect() method works as expected """
    # Create temporary module
    module = AnsibleModule(argument_spec={})

    # Create temporary facts
    collected_facts = {}

    # Create SelinuxFactCollector instance
    selinux_fact_collector = SelinuxFactCollector()

    # Test that SelinuxFactCollector.collect() works
    selinux_facts = selinux_fact_collector.collect(module, collected_facts)
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts
    assert selinux_facts['selinux_python_present'] is True

# Generated at 2022-06-20 20:01:15.540858
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector
    assert selinuxFactCollector.name == 'selinux'

# Generated at 2022-06-20 20:01:16.500597
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-20 20:02:54.725076
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 20:03:04.337287
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Testing with enabled SELinux
    enable_selinux = True
    selinux_status = 'enabled'
    selinux_mode = 'enforcing'
    selinux_config_mode = 'enforcing'
    selinux_policyvers = 3
    selinux_type = 'targeted'

    real_selinux_enabled = selinux.is_selinux_enabled
    real_selinux_security_getenforce = selinux.security_getenforce
    real_selinux_selinux_getpolicytype = selinux.selinux_getpolicytype
    real_selinux_security_policyvers = selinux.security_policyvers
    real_selinux_selinux_getenforcemode = selinux.selinux_getenforcemode


# Generated at 2022-06-20 20:03:06.876541
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-20 20:03:09.914662
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None

# Generated at 2022-06-20 20:03:13.859398
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts = SelinuxFactCollector()
    assert facts.name == 'selinux'
    assert len(facts._fact_ids) == 1
    assert isinstance(facts._fact_ids, set)
    assert 'selinux' in facts._fact_ids
