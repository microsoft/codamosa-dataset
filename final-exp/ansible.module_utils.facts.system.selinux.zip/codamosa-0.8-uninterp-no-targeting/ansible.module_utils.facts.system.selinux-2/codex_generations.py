

# Generated at 2022-06-20 19:53:23.057452
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_obj = SelinuxFactCollector()

    assert test_obj.name == 'selinux'
    assert test_obj._fact_ids == set()
    assert test_obj.collect() == {}


# Generated at 2022-06-20 19:53:24.180901
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"

# Generated at 2022-06-20 19:53:26.827081
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector is not None

# Generated at 2022-06-20 19:53:29.013485
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect(): 
    SelinuxFactCollector().collect()

# Generated at 2022-06-20 19:53:30.232893
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:53:34.632404
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    failed_msg = "Failed to collect selinux facts"
    collector = SelinuxFactCollector()
    ansible_selinux_facts = collector.collect()
    assert ansible_selinux_facts['selinux_python_present'] == HAVE_SELINUX, failed_msg

# Generated at 2022-06-20 19:53:39.128587
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    selinux_obj = SelinuxFactCollector()
    assert type(selinux_obj) == SelinuxFactCollector
    assert selinux_obj._fact_ids == set()
    assert selinux_obj.name == 'selinux'
    assert selinux_obj.collect() == {'selinux_python_present': True}



# Generated at 2022-06-20 19:53:50.860623
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    # Test for systems without SELinux enabled
    with patch('ansible.module_utils.facts.collectors.selinux.is_selinux_enabled',
               Mock(return_value=False)):
        facts = selinux_fact_collector.collect()
        assert 'selinux_python_present' in facts
        assert facts['selinux_python_present']
        assert facts['selinux']['status'] == 'disabled'

    # Test for systems with SELinux enabled
    with patch('ansible.module_utils.facts.collectors.selinux.is_selinux_enabled',
               Mock(return_value=True)):
        facts = selinux_fact_collector.collect()

# Generated at 2022-06-20 19:53:55.692084
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Given a module
    module = MockModule()

    # Given a SelinuxFactCollector
    selinux_collector = SelinuxFactCollector(module)

    # Return a dict with selinux data
    dict = selinux_collector.collect()

    assert dict['selinux_python_present'] is True

# Generated at 2022-06-20 19:53:56.995071
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts is not None

# Generated at 2022-06-20 19:54:17.568115
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert isinstance(selinux_facts,dict)
    assert isinstance(selinux_facts['selinux'],dict)
    assert isinstance(selinux_facts['selinux']['status'],str)
    assert isinstance(selinux_facts['selinux']['config_mode'],str)
    assert isinstance(selinux_facts['selinux']['type'],str)
    assert isinstance(selinux_facts['selinux']['mode'],str)

# Generated at 2022-06-20 19:54:19.347120
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-20 19:54:25.487360
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    if sys.version_info[0] == 2:
        module = AnsibleModuleMock(platform='Linux', distro='RedHat')
    else:
        module = AnsibleModuleMock(platform='Linux', distro='RedHat', selinux=selinux)
    s = SelinuxFactCollector(module=module)
    assert s.name == 'selinux'

# Generated at 2022-06-20 19:54:34.385141
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import json

    class MyModule:
        def get_bin_path(self, arg1, opt_args=None, fail_on_None=False, opt_dirs=None):
            print("get_bin_path")
            if arg1 == 'getenforce':
                return "/usr/bin/getenforce"
            elif arg1 == 'sestatus':
                return "/usr/sbin/sestatus"

        def run_commands(self, arg1, opt_args=None, check_rc=False):
            print("run_commands")
            if arg1 == ['sestatus'] or arg1 == ['getenforce']:
                return [{"rc": 0, "stdout": "Running"}]
            else:
                return [{"rc": 1, "stdout": "Not running"}]


# Generated at 2022-06-20 19:54:45.055794
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        collector = SelinuxFactCollector()
        facts_dict = collector.collect()
        assert facts_dict.get('selinux', {}).get('status') == 'Missing selinux Python library'

        assert facts_dict.get('selinux_python_present') == False
        return

    collector = SelinuxFactCollector()
    # It is not possible to guess if SELinux is enabled or disabled without the library
    collector.selinux = None
    facts_dict = collector.collect()

# Generated at 2022-06-20 19:54:47.284649
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:54:48.949007
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This test must be written
    assert False

# Generated at 2022-06-20 19:54:51.615995
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    #Check if the class SelinuxFactCollector is created
    assert SelinuxFactCollector

# Generated at 2022-06-20 19:54:54.974130
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:54:59.774565
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector({})
    assert selinux_fc.collect() == {}
    selinux_fc.name = 'selinux'
    assert selinux_fc.collect() == {}
    selinux_fc._fact_ids = set()
    assert selinux_fc.collect() == {}

# Generated at 2022-06-20 19:55:13.731095
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    # dict of facts related to selinux
    selinux_facts = selinux_collector.collect()

    assert 'selinux_python_present' in selinux_facts
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']

# Generated at 2022-06-20 19:55:16.649021
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact.name == 'selinux'


# Generated at 2022-06-20 19:55:19.891443
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux_python_present']

# Generated at 2022-06-20 19:55:21.229180
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()


# Generated at 2022-06-20 19:55:25.277778
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    setattr(selinux, 'security_getenforce', lambda : 0)
    setattr(selinux, 'is_selinux_enabled', lambda : True)
    facts = SelinuxFactCollector()
    data = facts.collect()
    assert data['selinux'] == {'config_mode': 'permissive', 'mode': 'permissive', 'status': 'enabled'}

# Generated at 2022-06-20 19:55:29.104425
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector(None)
    assert sfc.name == "selinux"
    assert sfc._fact_ids == set()
    assert sfc.collect() == {}

# Generated at 2022-06-20 19:55:41.198180
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a mock module
    class MockModule(object):
        pass

    module = MockModule()
    module.check_mode = False
    module.params = ''

    # Create a mock BaseFactCollector
    collect_method_name = 'collect_known_facts'
    try:
        collect_method = getattr(BaseFactCollector, collect_method_name)
    except Exception:
        collect_method = None

    if collect_method is not None:
        setattr(BaseFactCollector, collect_method_name, lambda self: dict())

    # Create a mocked selinux module
    class MockSelenium(object):
        def security_policyvers(self):
            return '24'
        def selinux_getenforcemode(self):
            return (0, 1)

# Generated at 2022-06-20 19:55:44.801187
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector
    assert selinux_collector.name == 'selinux'
    assert not selinux_collector._fact_ids


# Generated at 2022-06-20 19:55:52.853441
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import os
    import sys
    import platform

    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    test_obj = SelinuxFactCollector()

    test_facts = {}
    test_facts['os_name'] = platform.system()
    test_facts['os_family'] = platform.system()

    # Test case : When selinux library is not present, the status should be 'Missing selinux python library'
    try:
        del sys.modules['selinux']
        test_fact_data = test_obj.collect(collected_facts=test_facts)
    except Exception:
        pass
    finally:
        # Reset the selinux library
        sys.modules['selinux'] = __import__('selinux')


# Generated at 2022-06-20 19:55:57.020747
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    collected_facts = {}

    # selinux library is not present
    collected_facts['ansible_python_selinux'] = False

    # Disable selinux
    result = fact_collector.collect(None, collected_facts)
    assert result['selinux']['status'] == 'Missing selinux Python library'
    assert result['selinux_python_present'] == False

    collected_facts['ansible_python_selinux'] = True
    # Disable selinux
    result = fact_collector.collect(None, collected_facts)
    assert result['selinux']['status'] == 'disabled'
    assert result['selinux_python_present'] == True

    # Enable selinux
    collected_facts['ansible_selinux'] = True


# Generated at 2022-06-20 19:56:25.503898
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic

    inline_dict = {'ansible_selinux': {'config_mode': 'permissive', 'status': 'enabled', 'type': 'targeted'}}
    expected_dict = {'ansible_selinux': {'config_mode': 'permissive', 'status': 'enabled', 'type': 'targeted', 'mode': 'permissive'}}

    class MyModule(object):
        def __init__(self):
            self.params = {}

    aModule = MyModule()

    # set mode to permissive
    selinux.security_setenforce(0)
    # set config_mode to permissive
    selinux.selinux_setenforcemode(0)

    aFactCollector = SelinuxFactCollector(aModule)
    results = aFactCollector

# Generated at 2022-06-20 19:56:29.326981
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    obj = SelinuxFactCollector()
    collected_facts = {}
    collected_facs = obj.collect(collected_facts)
    print(collected_facs)

# Generated at 2022-06-20 19:56:30.281758
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()

# Generated at 2022-06-20 19:56:31.842418
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-20 19:56:40.601271
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Check if collect method returns expected results"""
    from ansible.module_utils.facts.collector import VirtualFactsCollector, Collector
    from ansible.module_utils.compat import selinux
    import sys
    sys.modules['selinux'] = selinux

    # Create FactCollector
    facts_collector = Collector()
    # Create Selinux fact collector
    fact_collector = SelinuxFactCollector(None, facts_collector)
    # Assert the required attributes and methods are available
    assert isinstance(fact_collector, VirtualFactsCollector)
    assert isinstance(fact_collector, Collector)
    assert hasattr(fact_collector, 'collect')
    assert hasattr(fact_collector, 'name')
    assert hasattr(fact_collector, '_fact_ids')

   

# Generated at 2022-06-20 19:56:43.707384
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert isinstance(selinux_fact_collector._fact_ids, set)

# Generated at 2022-06-20 19:56:53.460017
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    from ansible.module_utils.facts import collector

    # For testing, patch the selinux library to be missing and
    # set the fact list of the selinux class to be empty
    # because the `selinux_python_present` fact is not set
    # until the class is instantiated
    collector.HAVE_SELINUX = False
    SelinuxFactCollector._fact_ids = set()

    # Create instance of class
    sf = SelinuxFactCollector()

    # Call method collect of class SelinuxFactCollector
    sf_facts = sf.collect()

    # Assert that this fact was collected as expected
    assert 'selinux' in sf_facts
    assert 'status' in sf_facts['selinux']
    assert sf_facts['selinux']['status']

# Generated at 2022-06-20 19:56:58.028766
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == set(['selinux_python_present'])



# Generated at 2022-06-20 19:57:00.423604
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-20 19:57:02.463392
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    gfc = SelinuxFactCollector()
    assert gfc.name == 'selinux'

# Generated at 2022-06-20 19:57:42.579918
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setting up test variables
    selinux_facts = {}
    facts_dict = {}

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    try:
        import selinux
    except ImportError:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False

    # Test for enabled SELinux
    else:
        selinux_facts['status'] = 'enabled'

        try:
            selinux_facts['policyvers'] = selinux.security_policyvers()
        except (AttributeError, OSError):
            se

# Generated at 2022-06-20 19:57:45.922235
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_obj = SelinuxFactCollector()
    assert test_obj.name == 'selinux'
    assert len(test_obj._fact_ids) == 0


# Generated at 2022-06-20 19:57:50.909736
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Since all the methods of the class relies on library, we
    # test the constructor method only.

    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert isinstance(selinux_collector._fact_ids, set)

# Generated at 2022-06-20 19:57:58.187008
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    facts_dict = {}
    collected_facts = ansible_facts.AnsibleFacts(module=None, facts=facts_dict,
                                                 collected_facts=None)

    selinux_collector = SelinuxFactCollector()

    # Test the collect method by mocking out the values returned by the selinux
    # library, set status to disabled, then test each of the other values when
    # status is disabled.
    selinux_collector.selinux = MockSelinux()
    selinux_collector.selinux.security_getenforce.return_value = 0

    facts = selinux_collector.collect(collected_facts=collected_facts)
   

# Generated at 2022-06-20 19:58:06.165900
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector
    selinux_fc = SelinuxFactCollector()
    
    # Run the collect method and check that the attributes are set correctly
    selinux_collect = selinux_fc.collect()
    assert selinux_collect['selinux']['status'] == 'disabled'
    assert selinux_collect['selinux']['policyvers'] == 'unknown'
    assert selinux_collect['selinux']['config_mode'] == 'unknown'
    assert selinux_collect['selinux']['type'] == 'unknown'
    assert selinux_collect['selinux']['mode'] == 'unknown'

# Generated at 2022-06-20 19:58:14.849949
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAVE_SELINUX:
        selinux_status = 'enabled'
        selinux_policyvers = selinux.security_policyvers()
        selinux_type = selinux.selinux_getpolicytype()[1]
        selinux_mode = selinux.security_getenforce()
        selinux_config_mode = selinux.selinux_getenforcemode()[1]
    else:
        selinux_status = 'disabled'
        selinux_policyvers = 'unknown'
        selinux_type = 'unknown'
        selinux_mode = -1
        selinux_config_mode = -1


# Generated at 2022-06-20 19:58:25.972389
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Collect selinux facts
    selinux_facts_dict = selinux_fact_collector.collect()

    # There should be a key called selinux in the facts dict
    assert 'selinux' in selinux_facts_dict

    # There should be a selinux_python_present boolean in the facts dict
    assert 'selinux_python_present' in selinux_facts_dict

    # If there is a selinux key in the dict, then either the selinux library is
    # present and SELinux is enabled, or the library is missing and an error
    # message has been set
    if 'selinux' in selinux_facts_dict:
        assert 'status' in selinux_facts_dict

# Generated at 2022-06-20 19:58:29.492367
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'

# Generated at 2022-06-20 19:58:31.331911
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:58:35.593058
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()

    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == {'selinux', 'selinux_python_present'}

    assert selinux_fc.collect() == {
        'selinux': {},
        'selinux_python_present': False
    }


# Generated at 2022-06-20 19:59:17.958189
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    sys.path.append('..')
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collectors.system import SystemFactCollector
    import unittest

    class Dummy(object):
        pass


    class DummySelinux(object):
        def __init__(self):
            self.is_selinux_enabled_value = True
            self.policyvers_value = 'policyvers_value'
            self.selinux_getenforcemode_return = 0
            self.selinux_getenforcemode_value = 1
            self.security_getenforce_value = 1
            self.selinux_getpolicytype_return = 0
            self.selinux_getpolicytype_

# Generated at 2022-06-20 19:59:21.708382
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector(None, None, None)
    assert selinux_fact_collector
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:59:26.033345
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = {'osx_defaults': {'macosx_productversion_major': '10.15',
                                   'macosx_productversion_minor': '8'}}
    test_obj = SelinuxFactCollector(None)
    test_obj.collect(collected_facts=facts_dict)
    assert test_obj.name == 'selinux'

# Generated at 2022-06-20 19:59:35.102892
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Set up the object we're testing
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    # Assert that the correct keys are in the dictionary
    assert 'selinux' in selinux_facts
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts


# Generated at 2022-06-20 19:59:39.291099
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCache
    from ansible.module_utils.facts.collector.network import NetworkCollector

    c = SelinuxFactCollector()
    facts = c.collect()
    assert 'selinux' in facts

    cache = FactsCache()
    cache.update(facts)
    assert c.get_fact_names() == getattr(c, "_fact_ids", set())

    c.collect(cache)

# Generated at 2022-06-20 19:59:44.351105
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    assert Collector.__subclasses__() == [SelinuxFactCollector]

# Generated at 2022-06-20 19:59:50.286215
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    import mock
    from module_utils.selinux import selinux

    collector = Collector.get_collector(SelinuxFactCollector.name, {})
    assert isinstance(collector, SelinuxFactCollector)

    def mock_selinux_present():
        return True

    def mock_not_present():
        return False


# Generated at 2022-06-20 19:59:53.549501
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert isinstance(sfc._fact_ids, set)

# Generated at 2022-06-20 20:00:04.950353
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with SELinux enabled but missing Python library
    selinuxFactCollector = SelinuxFactCollector()
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: '21'
    selinux.security_getenforce = lambda: 1
    selinux.selinux_getpolicytype = lambda: (0, 'targeted')
    facts_dict = selinuxFactCollector.collect()
    assert facts_dict['selinux_python_present'] is False
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'

    # Test with SELinux disabled and missing Python library
    selinux.is_selinux_enabled = lambda: False
    facts_dict = selinuxFactCollector.collect()
    assert facts_dict

# Generated at 2022-06-20 20:00:09.266792
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    collected_facts = dict()
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect(module, collected_facts)
    assert 'selinux' in facts
    assert 'policyvers' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'type' in facts['selinux']

# Generated at 2022-06-20 20:01:51.013291
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 20:01:54.760572
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        from ansible.module_utils.compat import selinux
    except ImportError:
        # Dummy class to avoid import error for selinux module
        class selinux:
            def is_selinux_enabled():
                return False
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-20 20:02:04.405287
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    selinux.getenforce() returns value between 0 and 2, indicating whether SELinux is enabled or disabled
    """
    from unittest.mock import Mock, patch

    selinux_mock = Mock()
    selinux_mock.is_selinux_enabled.return_value = 1
    selinux_mock.security_policyvers.return_value = 20180315
    selinux_mock.selinux_getenforcemode.return_value = (0, 0)
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, 'targeted')

    with patch.dict('sys.modules', selinux=selinux_mock):
        import ansible.module_utils.facts

# Generated at 2022-06-20 20:02:06.783543
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    selinuxFactCollector.collect()

# Generated at 2022-06-20 20:02:14.500411
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Prepare mock data for testing collect method of class SelinuxFactCollector
    mock_selinux = 'selinux'
    mock_selinux_python_present = True
    mock_policyvers = 'policyvers'
    mock_config_mode = 'config_mode'
    mock_mode = 'mode'
    mock_type = 'type'
    mock_data = {'selinux': {'policyvers': mock_policyvers, 'config_mode': mock_config_mode, 'mode': mock_mode, 'type': mock_type}}
    mock_have_selinux = False
    mock_selinux_facts = {}
    mock_selinux_facts['status'] = 'Missing selinux Python library'
    mock_selinux_facts_selinux_python_present = False

# Generated at 2022-06-20 20:02:23.519332
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test dict containing the mock data returned from the selinux functions
    selinux_enforce_data = {
        'policyvers': '28',
        'config_mode': 'enforcing',
        'mode': 'enforcing',
        'type': 'targeted'
    }
    selinux_disabled_data = {
        'config_mode': 'unknown',
        'mode': 'unknown',
        'type': 'unknown',
        'policyvers': 'unknown'
    }

    # Test dict containing the mock method values

# Generated at 2022-06-20 20:02:32.742682
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = {'config_mode': 'permissive', 'mode': 'permissive',
                     'status': 'enabled', 'type': 'targeted'}
    selinux_facts_with_policyvers = selinux_facts.copy()
    selinux_facts_with_policyvers['policyvers'] = '28'
    selinux_facts_with_policyvers['selinux_python_present'] = True

    if HAVE_SELINUX:
        assert SelinuxFactCollector().collect() == selinux_facts_with_policyvers
    else:
        assert SelinuxFactCollector().collect() == {'selinux': {'status': 'Missing selinux Python library'}}

# Generated at 2022-06-20 20:02:35.022876
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-20 20:02:37.669924
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-20 20:02:42.799304
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
    assert isinstance(selinux_fact_collector, BaseFactCollector)

