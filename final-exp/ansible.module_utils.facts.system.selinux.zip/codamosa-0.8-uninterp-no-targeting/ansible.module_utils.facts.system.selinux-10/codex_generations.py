

# Generated at 2022-06-20 19:53:30.774981
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This test is to simulate missing selinux Python library
    fake_module = type('module', (), {})()
    fake_module.selinux = None
    sfc = SelinuxFactCollector(fake_module)
    assert sfc.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # This test is to simulate selinux Python library with selinux not enabled
    fake_module = type('module', (), {})()
    fake_module.selinux = True
    sfc = SelinuxFactCollector(fake_module)
    sfc.HAVE_SELINUX = True
    assert sfc.collect() == {"selinux_python_present": True, "selinux": {"status": "disabled"}}

# Generated at 2022-06-20 19:53:32.399910
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts is not None


# Generated at 2022-06-20 19:53:36.634193
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    selinux_facts = selinux_fact.collect()
    selinux_status = selinux_facts['selinux']['status']

    # check if the selinux status is either enabled or disabled
    assert selinux_status in ['enabled', 'disabled']

# Generated at 2022-06-20 19:53:42.491840
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    # Set up the 'selinux' module for use in the test
    sys.modules['selinux'] = selinux_mock
    # Run the test
    selinux_collector.collect()
    # Teardown
    selinux_collector = None
    del sys.modules['selinux']

# Generated at 2022-06-20 19:53:48.288528
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux_python_present' in selinux_facts
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']

# Generated at 2022-06-20 19:53:54.683362
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == "selinux"
    assert isinstance(selinux_facts.collect(), dict)
    assert selinux_facts.collect()['selinux'].keys() == ['status']
    assert selinux_facts.collect()['selinux_python_present'] == False

# Generated at 2022-06-20 19:54:05.688947
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class FakeModule:
        def __init__(self):
            self.params = {}

    # First test
    # When the selinux library is missing, the method collect()
    # should return a dict with the keys 'selinux' and selinux_python_present.
    # 'selinux_python_present' should be false and 'selinux' should
    # be set to the value of selinux_facts below.
    fm = FakeModule()
    fc = SelinuxFactCollector(fm)

    selinux_facts = {'status': 'Missing selinux Python library'}
    expected_result = {}
    expected_result['selinux'] = selinux_facts
    expected_result['selinux_python_present'] = False

    # Change the name of the selinux package so that it will not be found.

# Generated at 2022-06-20 19:54:17.225035
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()
    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['selinux'], dict)
    assert isinstance(facts_dict['selinux']['status'], str)
    assert isinstance(facts_dict['selinux']['policyvers'], str)
    assert isinstance(facts_dict['selinux']['config_mode'], str)
    assert isinstance(facts_dict['selinux']['mode'], str)
    assert isinstance(facts_dict['selinux']['type'], str)
    assert isinstance(facts_dict['selinux_python_present'], bool)

# Generated at 2022-06-20 19:54:19.191090
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_collector = SelinuxFactCollector()
    facts_collector.collect()

# Generated at 2022-06-20 19:54:28.478594
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # initialize test
    module = basic.AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: kwargs
    facts_dict = {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'status': 'unknown',
            'type': 'unknown'
        }
    }
    SelinuxFactCollector._fact_ids.clear()

    def mock_is_selinux_enabled():
        return False

    def mock_is_selinux_disabled():
        return True

    def mock_security_policyvers():
        return 1


# Generated at 2022-06-20 19:54:37.130596
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact.name == 'selinux'
    assert selinux_fact._fact_ids == set()

# Generated at 2022-06-20 19:54:40.621404
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert set(selinux_fc._fact_ids) == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-20 19:54:48.142074
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class FakeModule():
        def __init__(self):
            self.params = {}

    # test when selinux is disabled
    class FakeSelinux():
        def is_selinux_enabled(self):
            return False

    fake_module = FakeModule()
    fake_selinux = FakeSelinux()
    selinux_collector = SelinuxFactCollector(fake_module, fake_selinux)
    facts_dict = selinux_collector.collect()
    assert facts_dict['selinux']['status'] == 'disabled'
    assert 'mode' not in facts_dict['selinux']
    assert 'config_mode' not in facts_dict['selinux']
    assert 'type' not in facts_dict['selinux']

# Generated at 2022-06-20 19:54:58.632820
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test that collect method will return selinux facts dict and boolean for
    presence of selinux Python library for known path on Linux.
    """
    def getenforcemode(path):
        return (0, 0)

    def security_getenforce(path):
        return 0

    def is_selinux_enabled(path):
        return True

    def selinux_getpolicytype():
        return (0, 'MCS')

    def security_policyvers(path):
        return 28

    selinux.selinux_getenforcemode = getenforcemode
    selinux.security_getenforce = security_getenforce
    selinux.is_selinux_enabled = is_selinux_enabled
    selinux.selinux_getpolicytype = selinux_getpolicytype
    selinux.security_policy

# Generated at 2022-06-20 19:55:00.618673
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:55:05.266341
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if not HAVE_SELINUX:
        return

    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)
    selinux_status = selinux_facts.get('selinux').get('status')
    assert selinux_status == 'enabled' or selinux_status == 'disabled'

# Generated at 2022-06-20 19:55:08.458788
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_collector._module = MockModule()
    selinux_collector.collect()

# Unit test: verify that the selinux_python_present fact is set to False when
# the selinux python library is not imported

# Generated at 2022-06-20 19:55:14.808163
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_namespace

    f_collector = FactCollector()
    m_collector = MagicMock(spec=BaseFactCollector)

    # test if the call of the collect method returns the expected result
    with f_collector:
        get_collector_namespace()['ansible.module_utils.facts.plugins.selinux'] = m_collector

# Generated at 2022-06-20 19:55:19.942601
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == frozenset()
    assert selinux_fact_collector.collect_fn_names == ['collect']

# Generated at 2022-06-20 19:55:21.274611
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()

    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:55:41.987432
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import platform
    import tempfile

    def mock_security_policyvers():
        return 'abc'

    def mock_selinux_getenforcemode(self):
        return (0, 1)

    def mock_selinux_getpolicytype():
        return (0, 'some_policy')

    def mock_security_getenforce():
        return 1

    def mock_is_selinux_enabled():
        return True

    selinux_facts_py2 = {
        'selinux': {
            'config_mode': 'enforcing',
            'mode': 'enforcing',
            'status': 'enabled',
            'type': 'some_policy',
            'policyvers': 'abc'
        },
        'selinux_python_present': True
    }


# Generated at 2022-06-20 19:55:43.791168
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'

# Generated at 2022-06-20 19:55:47.943290
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    asser_obj = SelinuxFactCollector()
    data = asser_obj.collect()
    assert 'selinux' in data
    assert 'status' in data['selinux']
    assert 'selinux_python_present' in data


# Generated at 2022-06-20 19:55:52.802183
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    unit test class SelinuxFactCollector
    """

    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set([])


# Unit tests for collect of class SelinuxFactCollector

# Generated at 2022-06-20 19:55:54.370597
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:56:02.970228
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import tempfile
    import subprocess
    import shutil
    import os
    import os.path

    my_path = os.path.dirname(os.path.realpath(__file__))
    module_path = os.path.join(my_path, '../../../../library')
    subprocess.call(['ansible-test', 'units', '--module-path', module_path],
                    stdout=subprocess.PIPE)

    subprocess.call(['ansible-test', 'units', '--module-path', module_path,
                     'collector/selinux.py'], stdout=subprocess.PIPE)

# Generated at 2022-06-20 19:56:05.148136
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector is not None


# Generated at 2022-06-20 19:56:12.174116
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts_collector = SelinuxFactCollector()
    facts_dict = selinux_facts_collector.collect(module=None, collected_facts=None)
    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict

    for fact in ['status', 'policyvers', 'config_mode', 'mode', 'type']:
        assert fact in facts_dict['selinux']

# Generated at 2022-06-20 19:56:17.120765
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert 'selinux_python_present' in facts_dict
    assert 'selinux' in facts_dict

# Generated at 2022-06-20 19:56:19.274951
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'

# Generated at 2022-06-20 19:56:35.300435
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()
    assert obj.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-20 19:56:38.591960
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert len(selinux_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:56:50.123625
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Import necessary module function
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create the instance of SelinuxFactCollector
    selinuxfactcollector = SelinuxFactCollector()

    # Check if instance is created properly
    if not isinstance(selinuxfactcollector, SelinuxFactCollector):
        print("Error: SelinuxFactCollector instance not created properly")
        return False
    print("Success: SelinuxFactCollector instance created properly")

    # Check if the class inherited from BaseFactCollector properly
    if not issubclass(SelinuxFactCollector, BaseFactCollector):
        print("Error: SelinuxFactCollector class does not inherited from BaseFactCollector")
        return False

# Generated at 2022-06-20 19:57:00.638079
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector_selinux import SelinuxFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import pytest
    import shutil
    import tempfile
    import time

    temp_dir = tempfile.mkdtemp()

    selinux_status_file_path = os.path.join(temp_dir, 'selinux_status')
    selinux_policyvers_file_path = os.path.join(temp_dir, 'selinux_policyvers')
    selinux_config_mode_file_path = os.path.join(temp_dir, 'selinux_config_mode')
    selinux_mode_file_path = os.path.join(temp_dir, 'selinux_mode')
   

# Generated at 2022-06-20 19:57:11.377382
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_module = {'module_name': 'selinux'}
    test_collected_facts = {}
    collector = SelinuxFactCollector()
    collected_facts = collector.collect(test_module, test_collected_facts)
    assert collected_facts['selinux_python_present'] == True
    assert collected_facts['selinux']['mode'] == 'unknown'
    assert collected_facts['selinux']['status'] == 'enabled'
    assert collected_facts['selinux']['type'] == 'unknown'
    assert collected_facts['selinux']['config_mode'] == 'unknown'

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 19:57:19.327313
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create instance of SelinuxFactCollector
    selinux_fact_module = SelinuxFactCollector()

    # Create stubs
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: 'test_policyvers'
    selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux.security_getenforce = lambda: 1
    selinux.selinux_getpolicytype = lambda: (0, 'test_policytype')

    # Get collected facts
    facts = selinux_fact_module.collect(collected_facts=None)

    # Assert the collected facts
    assert facts['selinux'].keys() == ['status', 'policyvers', 'config_mode', 'mode', 'type']

# Generated at 2022-06-20 19:57:27.350908
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        import selinux
        selinux_python_present = True
    except ImportError:
        selinux_python_present = False

    # If the selinux Python library is not present, only selinux_python_present should be set.
    if not selinux_python_present:
        facts = {
            'selinux_python_present': False,
            'selinux': {
                'status': 'Missing selinux Python library'
            }
        }
    else:
        # If selinux is not enabled, only selinux_python_present and selinux status should be set.
        if not selinux.is_selinux_enabled():
            facts = {
                'selinux_python_present': True,
                'selinux': {
                    'status': 'disabled'
                }
            }
       

# Generated at 2022-06-20 19:57:31.176557
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This method is used to unit test the collect method of class SelinuxFactCollector
    :return:
    """
    s = SelinuxFactCollector()
    s.collect()

# Generated at 2022-06-20 19:57:38.744053
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    selinux_fact_collector = SelinuxFactCollector()
    fact_collector = SelinuxFactCollector()
    return_value = fact_collector.collect()
    assert return_value['selinux_python_present'] == True
    assert return_value['selinux']['mode'] == 'unknown'

# Generated at 2022-06-20 19:57:42.281932
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # Check the class name
    assert selinux_fact_collector.name == 'selinux'
    # Check the class's attribute
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:58:09.355029
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"

# Generated at 2022-06-20 19:58:16.965971
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ansible_module = MagicMock()
    ansible_module.params = {'gather_subset': '!all', 'gather_timeout': 10}
    ansible_module.get_bin_path = MagicMock(return_value='/bin/ls')

    # selinux library is missing
    with patch('ansible.module_utils.compat.selinux', None):
        with pytest.raises(Exception):
            SelinuxFactCollector(ansible_module).collect()

    # selinux library is not missing

# Generated at 2022-06-20 19:58:20.203161
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:58:31.628775
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test that AnsibleModule dependency is not required for collect() """
    from ansible.module_utils.facts.collectors import BaseFactCollector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.utils import get_collector_instance
    from ansible.module_utils.compat import selinux
    # Create a mock AnsibleModule object with a temporary in-memory filesystem
    am = AnsibleModuleMock()
    # Create a fake selinux object to use instead of the real selinux library
    # that cannot be imported on Windows.
    class FakeSelinux(object):
        class SELinuxError(Exception):
            pass

        def is_selinux_enabled(self):
            return False


# Generated at 2022-06-20 19:58:34.664597
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Arrange
    # Act
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()

    # Assert
    assert facts['selinux'] is not None
    assert facts['selinux_python_present'] is not None

# Generated at 2022-06-20 19:58:36.007481
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-20 19:58:48.124062
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is available, test if the selinux facts are returned
    if HAVE_SELINUX:
        collector = SelinuxFactCollector()
        result = collector.collect(None)
        assert 'selinux' in result
        assert 'status' in result['selinux']
        assert result['selinux']['status'] in ['disabled', 'enabled']
        if result['selinux']['status'] == 'disabled':
            assert 'policyvers' not in result['selinux']
            assert 'config_mode' not in result['selinux']
            assert 'mode' not in result['selinux']
            assert 'typr' not in result['selinux']
        else:
            assert 'policyvers' in result['selinux']

# Generated at 2022-06-20 19:58:53.408427
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    # Unit test code
    result = selinux_fact_collector.collect()
    #
    # Assertion logic
    assert result['selinux_python_present'] == True
    assert result['selinux'] != None
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']
    assert 'policyvers' in result['selinux']
    assert 'status' in result['selinux']
    assert 'type' in result['selinux']
    #print(result)

if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-20 19:58:56.610384
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids is not None

# Generated at 2022-06-20 19:59:08.787972
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    selinux_facts = dict(
        status='enabled',
        policyvers=28,
        config_mode='enforcing',
        mode='enforcing',
        type='targeted',
    )
    facts_dict = dict(selinux=selinux_facts)
    collected_facts = dict(ansible_facts=dict(selinux=selinux_facts))
    sfc = SelinuxFactCollector(module=module, collected_facts=collected_facts)
    sfc.collect()
    # assertEqual does not support comparing dicts
    assert dict(module.exit_json.call_args[0][0]['ansible_facts']) == dict(facts_dict)

# Generated at 2022-06-20 19:59:59.910824
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a temporary class
    class TestClass(object):
        name = 'selinux'

    # Create the object and save the original selinux library
    test_obj = TestClass()
    original_selinux = test_obj.selinux

    # Overwrite the selinux library with a fake one
    test_obj.selinux = mock.MagicMock()
    test_obj.selinux.is_selinux_enabled.return_value = True

    test_obj.selinux.security_policyvers.return_value = None
    test_obj.selinux.selinux_getenforcemode.return_value = (0, 0)
    test_obj.selinux.security_getenforce.return_value = 1

# Generated at 2022-06-20 20:00:04.006569
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'
    assert s._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-20 20:00:11.510409
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    selinux_fact_collector = SelinuxFactCollector(module)

    # Unit test when the Python selinux library is installed.
    def selinux_is_selinux_enabled_side_effect():
        return True

    def selinux_security_policyvers_side_effect():
        return '24'

    def selinux_selinux_getenforcemode_side_effect():
        return (0, 1)

    def selinux_security_getenforce_side_effect():
        return 1

    def selinux_selinux_getpolicytype_side_effect():
        return (0, "targeted")

    selinux.is_selinux_enabled = Mock(side_effect=selinux_is_selinux_enabled_side_effect)
    selinux

# Generated at 2022-06-20 20:00:20.457628
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test collect() method of SelinuxFactCollector"""

    # Mock out selinux module
    import sys
    import collections
    import selinux
    if sys.version_info.major >= 3:
        import_module = 'builtins.__import__'
    else:
        import_module = '__builtin__.__import__'
    mocked_selinux = {
        'is_selinux_enabled': lambda: True,
        'security_policyvers': lambda: 42,
        'security_getenforce': lambda: 0,
        'selinux_getpolicytype': lambda: (0, 'targeted'),
        'selinux_getenforcemode': lambda: (0, 1),
    }

# Generated at 2022-06-20 20:00:25.312245
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj1 = SelinuxFactCollector().collect()
    obj2 = SelinuxFactCollector().collect()
    assert obj1 == obj2

# Generated at 2022-06-20 20:00:28.586446
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    # Test fact IDs of SelinuxFactCollector
    assert selinux_fact_collector.fact_ids == set(['selinux_python_present'])

    # Test the name of the SelinuxFactCollector
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 20:00:36.263825
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the collect method of the SelinuxFactCollector class.
    """
    # Create a mock module
    mock_module = 'fake_module'
    # Create a mock collected_facts
    mock_collected_facts = {'selinux': {'status': 'enabled', 'mode': 'enforcing', 'type': 'targeted', 'policyvers': '27', 'config_mode': 'permissive'}}

    selinux_fact_col = SelinuxFactCollector()
    # collect facts and assert that no exception is thrown and that the base class returns a dictionary
    assert isinstance(selinux_fact_col.collect(mock_module, mock_collected_facts), dict)


# Generated at 2022-06-20 20:00:42.827320
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    obj = SelinuxFactCollector()
    res = obj.collect()

    assert 'selinux' in res
    assert 'status' in res['selinux']
    assert res['selinux']['status'] in ['enabled', 'disabled', 'Missing selinux Python library']
    assert 'selinux_python_present' in res

# Generated at 2022-06-20 20:00:44.360147
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 20:00:45.986233
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test for instantiating empty class
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'
    assert selinux_obj._fact_ids == set()


# Generated at 2022-06-20 20:02:33.160269
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Tests the collect function of class SelinuxFactCollector."""
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts
    if HAVE_SELINUX:
        assert 'selinux_python_present' in selinux_facts
    else:
        assert 'selinux_python_present' not in selinux_facts

# Generated at 2022-06-20 20:02:36.247523
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'
    assert s._fact_ids is None

# Generated at 2022-06-20 20:02:38.267113
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'

# Generated at 2022-06-20 20:02:41.379484
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize class
    SelinuxFactCollector()

# We need to stub the selinux library

# Generated at 2022-06-20 20:02:47.689356
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Insert non-modified values into the facts returned by selinux.
    def getenforcemode():
        return 0, 1
    def security_policyvers():
        return '28'
    def security_getenforce():
        return 1
    def selinux_getpolicytype():
        return 0, 'targeted'
    selinux.selinux_getenforcemode = getenforcemode
    selinux.security_policyvers = security_policyvers
    selinux.security_getenforce = security_getenforce
    selinux.selinux_getpolicytype = selinux_getpolicytype

    selinux_facts = {
        'config_mode': 'enforcing',
        'mode': 'permissive',
        'policyvers': '28',
        'status': 'enabled',
        'type': 'targeted'
    }

# Generated at 2022-06-20 20:02:54.932875
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest

    @pytest.fixture
    def selinux_fact_collector():
        selinux_fact_collector = SelinuxFactCollector()
        return selinux_fact_collector

    def test_selinux_status(selinux_fact_collector):
        selinux_facts_dict = selinux_fact_collector.collect()
        assert 'status' in selinux_facts_dict['selinux']

# Generated at 2022-06-20 20:02:59.291465
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None
    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect(module, collected_facts)
    assert 'selinux' in result
    assert 'status' in result['selinux']

# Generated at 2022-06-20 20:03:03.508529
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModuleMock()
    # Constructor test
    module.params = {}
    selinux_constructor = SelinuxFactCollector(module)
    assert selinux_constructor.name == 'selinux'
    assert selinux_constructor._fact_ids == set()
    assert selinux_constructor._module == module



# Generated at 2022-06-20 20:03:06.200601
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert 'SELINUX' == selinux_fc.env_vars[0]
    assert 'selinux' in selinux_fc.collect()

# Generated at 2022-06-20 20:03:11.064055
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
