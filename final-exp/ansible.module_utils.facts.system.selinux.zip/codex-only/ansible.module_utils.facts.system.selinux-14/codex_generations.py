

# Generated at 2022-06-23 01:39:58.811173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:40:01.593901
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """ Test the constructor of class SelinuxFactCollector to return an instance of the class """
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)

# Generated at 2022-06-23 01:40:11.001271
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()

    # Check if 'selinux_python_present' is set to False,
    # if the selinux module is not imported
    if HAVE_SELINUX:
        assert facts_dict['selinux_python_present']
    else:
        assert not facts_dict['selinux_python_present']

    # Check if the values of selinux_facts are of the right type 
    assert isinstance(facts_dict['selinux']['status'], str)
    assert isinstance(facts_dict['selinux']['config_mode'], str)
    assert isinstance(facts_dict['selinux']['mode'], str)

# Generated at 2022-06-23 01:40:13.833525
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-23 01:40:17.289942
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:40:21.057738
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:40:24.017033
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert set(selinux_fact_collector._fact_ids) == set()


# Generated at 2022-06-23 01:40:34.407877
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def mock_selinux_enabled():
        return "True"

    def mock_security_enforce():
        return 1

    def mock_security_policyvers():
        return 1

    def mock_selinux_getenforcemode():
        return 0,"1"

    def mock_selinux_getpolicytype():
        return 0,"targeted"

    result = {'ansible_selinux': {'config_mode': 'enforcing',
                                  'mode': 'enforcing',
                                  'policyvers': 1,
                                  'status': 'enabled',
                                  'type': 'targeted'},
              'ansible_selinux_python_present': True}

    m_selinux = __import__("selinux")
    m_selinux.is_selinux_enabled = mock_sel

# Generated at 2022-06-23 01:40:37.757401
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    foo = SelinuxFactCollector()
    assert foo.name == 'selinux'
    assert hasattr(foo, 'collect')

# Generated at 2022-06-23 01:40:43.389189
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    real_selinux = selinux

    class FakeSelinux(object):
        def is_selinux_enabled(self):
            return True

    selinux.is_selinux_enabled = FakeSelinux().is_selinux_enabled

    collector = SelinuxFactCollector(None, None)
    res = collector.collect()
    assert res['selinux']['status'] == 'enabled'

    selinux = real_selinux

# Generated at 2022-06-23 01:40:50.727753
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()
    import os
    import stat
    file_path = '/usr/bin/ls'
    file_mode = os.stat(file_path).st_mode
    if stat.S_ISLNK(file_mode):
        print ('Is a symbolic link')
    if stat.S_ISREG(file_mode):
        print ('Is a regular file')
    if stat.S_ISDIR(file_mode):
        print ('Is a directory')

# Generated at 2022-06-23 01:40:53.893420
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector is not None

# Generated at 2022-06-23 01:40:56.046156
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:40:58.861308
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:41:00.789447
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:41:02.567443
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == "selinux"

# Generated at 2022-06-23 01:41:13.681852
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import os
    import sys
    import tempfile
    try:
        from ansible.module_utils.compat import selinux
    except ImportError:
        pytest.skip("selinux library not installed")
    else:
        if not hasattr(selinux, 'is_selinux_enabled'):
            pytest.skip("selinux library is too old to be used in a unit test")

    orig_selinux = selinux

# Generated at 2022-06-23 01:41:18.078397
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # test selinux_python_present set to True
    collector = SelinuxFactCollector()
    collector.collect()
    assert collector.get_facts()['ansible_selinux_python_present'] == True



# Generated at 2022-06-23 01:41:19.340790
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None

# Generated at 2022-06-23 01:41:20.791209
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:41:24.430062
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts import collector
    c = collector.get_collector('SelinuxFactCollector')
    assert isinstance(c, SelinuxFactCollector)

# Generated at 2022-06-23 01:41:25.480425
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()

# Generated at 2022-06-23 01:41:29.547514
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert SelinuxFactCollector().collect() == [
        {
            'selinux': {
                'config_mode': 'unknown',
                'mode': 'unknown',
                'policyvers': 'unknown',
                'status': 'disabled',
                'type': 'unknown'
            },
            'selinux_python_present': False
        },
    ]

# Generated at 2022-06-23 01:41:37.617620
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import collections
    
    module = sys.modules['__main__']
    config = collections.namedtuple('config', ['functions'])
    setattr(module, 'ansible_facts', {})
    setattr(module, 'ansible_module_args', {})
    setattr(module, 'config', config(functions=['selinux.cookbook']))
    delattr(module, 'selinux')
    obj = SelinuxFactCollector()
    result = obj.collect(module=module, collected_facts={})
    assert 'selinux' in result
    assert 'selinux_python_present' in result


# Generated at 2022-06-23 01:41:38.527212
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    a

# Generated at 2022-06-23 01:41:45.251713
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Define a dict of facts with mode, config_mode and policyvers values.
    facts = dict(selinux=dict(mode='enforcing', config_mode='enforcing', policyvers='1'), selinux_python_present=True)

    # Generate an instance of the SelinuxFactCollector class with the defined facts.
    selinux_fact_collector = SelinuxFactCollector(module=None, collected_facts=facts)

    # Test the collect function of the SelinuxFactCollector class.
    assert selinux_fact_collector.collect() == facts

# Generated at 2022-06-23 01:41:51.666233
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert collected_facts['selinux'] == {'status': 'disabled', 'mode': 'unknown', 'policyvers': 'unknown',
                                          'type': 'unknown', 'config_mode': 'unknown'}
    assert collected_facts['selinux_python_present'] == False

# Generated at 2022-06-23 01:42:01.941890
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import selinux
    import sys
    import tempfile
    if sys.hexversion < 0x02070000:
        return
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.linux import LinuxFactCollector
    from ansible.module_utils.facts.collector.systemd import SystemdFactCollector
    from ansible.module_utils.facts.collector.posix import PosixFactCollector
    from ansible.module_utils._text import to_bytes

    selinux_mode = "/tmp/selinux_mode"
   

# Generated at 2022-06-23 01:42:13.843666
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Validating that the method collect of class SelinuxFactCollector returns
    # an empty dictionary if the library selinux is not present.
    mod_utils = Mock()
    mod_utils.HAVE_SELINUX = False
    mod_utils.security_getenforce.return_value = None
    mod_utils.security_policyvers.return_value = None
    mod_utils.is_selinux_enabled.return_value = None
    mod_utils.selinux_getenforcemode.return_value = None

    with patch("ansible.module_utils.facts.selinux.selinux") as selinux_mod:
        selinux_mod.security_getenforce.return_value = None
        selinux_mod.security_policyvers.return_value = None
        selinux_mod.is_

# Generated at 2022-06-23 01:42:19.044054
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts_output = {
        'selinux': {
            'type': 'unknown',
            'status': 'enabled',
            'mode': 'unknown',
            'config_mode': 'unknown'
        }
    }

    selinux_collector = SelinuxFactCollector()
    selinux_facts_output_actual = selinux_collector.collect()
    assert selinux_facts_output == selinux_facts_output_actual

# Generated at 2022-06-23 01:42:27.237517
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fake_module = 999
    fake_collector = 999
    selinux_facts = SelinuxFactCollector().collect(fake_module, fake_collector)
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    if HAVE_SELINUX:
        assert selinux_facts['selinux_python_present'] == True, \
            "SELinux Python library was not found"
    else:
        assert selinux_facts['selinux_python_present'] == False, \
            "SELinux Python library was found"
        assert 'status' in selinux_facts['selinux']

# Generated at 2022-06-23 01:42:36.637315
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect(None)
    if selinux_facts['selinux']['status'] == 'enabled':
        assert selinux_facts['selinux']['config_mode'] in ['enforcing', 'permissive', 'disabled']
        assert selinux_facts['selinux']['mode'] in ['enforcing', 'permissive', 'disabled']
        assert selinux_facts['selinux']['type'] in ['targeted', 'strict', 'mls']

# Generated at 2022-06-23 01:42:42.632078
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collected_facts = dict()
    selinux_fact_collector = SelinuxFactCollector()
    
    # Note that this test is not idempotent. If Ansible SELinux python module is not installed
    # then the selinux_python_present fact is set to False, but if the module is installed, then
    # the selinux_python_present fact is set to True.
    selinux_fact_collector.collect(collected_facts)
    assert 'selinux_python_present' in collected_facts

# Generated at 2022-06-23 01:42:44.404915
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SELinuxFactCollector().collect()

# Generated at 2022-06-23 01:42:47.938859
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert result['selinux']['status'] == 'enabled'
    assert result['selinux_python_present'] == True

# Generated at 2022-06-23 01:42:55.186267
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''
    Create instance of SelinuxFactCollector
    '''

    selinux_fac_obj = SelinuxFactCollector()
    assert isinstance(selinux_fac_obj, SelinuxFactCollector)
    assert selinux_fac_obj.name == 'selinux'

# Generated at 2022-06-23 01:42:56.857228
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # *** Note that this is an example test, not necessarily a working test
    collector = SelinuxFactCollector()
    results = collector.collect()
    print("RESULTS: %s" % results)

# Generated at 2022-06-23 01:42:57.816154
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:43:09.844374
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Arrange
    # Assume selinux is enabled
    HAVE_SELINUX = True
    # Assume selinux library is present
    selinux_python_present = True
    # Assume status = enabled
    status = 'enabled'
    # Assume type = targeted
    type = 'targeted'
    # Assume mode = enforcing
    mode = 'enforcing'
    # Assume config mode = enforcing
    config_mode = 'enforcing'
    # Assume policyvers = 24
    policyvers = 24
    # Construct mock selinux Python library
    # that returns the above values when called appropriately
    # Note: mocking object creation is beyond scope of this unit test
    #       so just assume we have the necessary mock object.
    # Arrange
    # Act
    # Instantiate SelinuxFactCollector and call collect
    f

# Generated at 2022-06-23 01:43:13.515204
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_class  = SelinuxFactCollector()
    assert selinux_fact_collector_class.name == 'selinux'
    assert selinux_fact_collector_class._fact_ids == set()

# Generated at 2022-06-23 01:43:16.292003
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    instance = SelinuxFactCollector()
    assert instance.collect() == {'selinux': {'status': 'disabled'}, 'selinux_python_present': False}


# Generated at 2022-06-23 01:43:17.825081
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts is not None

# Generated at 2022-06-23 01:43:24.105155
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()

    # When the selinux module is not present, collect method should
    # return a dictionary with selinux_python_present set to false.
    facts_dict = {}
    selinux_facts = {}
    selinux_facts['status'] = 'Missing selinux Python library'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = False

    assert selinux.collect() == facts_dict


# Generated at 2022-06-23 01:43:33.052984
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create an instance of the SelinuxFactCollector class
    selinux_fact_collector = SelinuxFactCollector()

    # Create the result for parameter 'collected_facts'
    collected_facts = {
        'ansible_all_ipv4_addresses': [
            '10.0.0.33',
            '10.0.1.33'
        ],
        'ansible_architecture': 'x86_64',
        'ansible_all_ipv6_addresses': [
            'fe80::250:56ff:fe90:7b4e',
            'fe80::250:56ff:fea1:baa'
        ]
    }

    # Test return value

# Generated at 2022-06-23 01:43:37.625095
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)
    assert isinstance(selinux_fact_collector, BaseFactCollector)


# Generated at 2022-06-23 01:43:47.889046
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a fake module
    fake_module = None

    # Create a fake collected_facts dict
    fake_collected_facts = {'ansible_facts': {'selinux': {}}}

    fake_method = type('', (object, ), dict(run=lambda self: (0, 'permissive')))

    module_map = {
        'selinux': selinux,
        'selinux.security_policyvers': lambda: 10,
        'selinux.selinux_getenforcemode': lambda: (0, 0),
        'selinux.selinux_getpolicytype': lambda: (0, 'targeted'),
        'selinux.security_getenforce': fake_method,
    }


# Generated at 2022-06-23 01:43:50.470984
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup
    collector = SelinuxFactCollector()
    results = collector.collect()

    # Verify
    assert type(results) == dict
    assert 'selinux' in results

# Generated at 2022-06-23 01:43:58.620081
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import Collector

    def mock_check_extras():
        return True

    try:
        from ansible.module_utils.compat import selinux
        mock_selinux_python_present = True
    except ImportError:
        mock_selinux_python_present = False
    mock_selinux_fact_collector = SelinuxFactCollector()

    # Create the mock selinux library
    if mock_selinux_python_present == True:
        import mock
        mock_python_selinux = mock.Mock(spec=selinux)
        selinux = mock_python_selinux
        mock_python_selinux.is_selinux_enabled.return_value = False
       

# Generated at 2022-06-23 01:44:02.832100
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    collected_facts = collector.collect()
    assert 'selinux_python_present' in collected_facts
    assert 'selinux' in collected_facts
    assert 'status' in collected_facts['selinux']

# Generated at 2022-06-23 01:44:07.883101
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids


# Generated at 2022-06-23 01:44:18.300780
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Define test class for determining if collect method of class BaseFactCollector is called.
    class TestFactCollector(BaseFactCollector):

        def __init__(self):
            self.collect_called = False

        def collect(self, module=None, collected_facts=None):
            self.collect_called = True

    # Register test collector.
    fact_collector.add_collector(TestFactCollector())

    # Initialize fact collector.
    fact_collector.init_fact_collector()

    # Collect facts.
    fact_collector.collect(module=None, collected_facts=None)

    # Assert that collect method of class BaseFactCollector has been

# Generated at 2022-06-23 01:44:27.927965
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    A = SelinuxFactCollector()
    results = A.collect(module=None, collected_facts={'ansible_selinux': {}})
    assert results == {'ansible_selinux': {'ansible_selinux_python_present': True, 'ansible_selinux_status': 'disabled'}}

if __name__ == "__main__":
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:44:38.057442
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test with selinux library
    import selinux
    selinuxbackup = selinux.__dict__.copy()
    test_object = SelinuxFactCollector()
    test_fact = test_object.collect(module=None, collected_facts=None)

    # Test without selinux library
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.selinux = None
    test_object = SelinuxFactCollector()
    test_fact_noselinux = test_object.collect(module=None, collected_facts=None)

    # Reset selinux library
    ansible.module_utils.facts.collector.selinux = selinuxbackup

    return test_fact, test_fact_noselinux

# Generated at 2022-06-23 01:44:39.945002
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.collect() is not None

# Generated at 2022-06-23 01:44:42.579831
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Constructor test
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:44:46.767287
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == "selinux"
    assert s._fact_ids == set()

# Unit tests for collect method of class SelinuxFactCollector

# Generated at 2022-06-23 01:44:49.527747
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:44:56.632503
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of class SelinuxFactCollector
    selinux_fact = SelinuxFactCollector()

    # Create the facts to be returned
    facts_dict = dict(selinux=dict(status='enabled', policyvers='31', config_mode='permissive',
                                   mode='permissive', type='targeted'))

    # Set the module_utils/selinux.py is_selinux_enabled() and test_selinux_enabled methods to return true.
    # The other methods in selinux.py are not set so they will fail and the method will return default values.
    selinux.is_selinux_enabled = lambda: True
    selinux.selinux_getenforcemode = lambda: (0, 0)
    selinux.security_getenforce = lambda: 0
    selinux.selin

# Generated at 2022-06-23 01:45:01.446190
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector_module = SelinuxFactCollector()
    evidence = fact_collector_module.collect()

    assert isinstance(evidence, dict)
    assert 'selinux' in evidence
    assert isinstance(evidence['selinux'], dict)
    assert isinstance(evidence['selinux_python_present'], bool)

# Generated at 2022-06-23 01:45:02.838765
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-23 01:45:13.071098
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import unittest

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: sys.exit(0)
            self.fail_json = lambda x: sys.exit(1)

    class MockCollector(object):
        def __init__(self):
            self.collect = lambda x: {'collected_facts_1': 'collected_facts_1_val'}

    if 'ansible.module_utils.facts.collectors.selinux.HAVE_SELINUX' in sys.modules:
        MOCK_HAVE_SELINUX = sys.modules['ansible.module_utils.facts.collectors.selinux.HAVE_SELINUX']

# Generated at 2022-06-23 01:45:17.487409
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Mock input parameters
    module = None
    collected_facts = {}

    # Create a SelinuxFactCollector object and invoke its collect method
    fc = SelinuxFactCollector(module, collected_facts)
    fc.collect()


# Generated at 2022-06-23 01:45:19.879730
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:45:22.731276
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = None
    collected_facts = None
    obj1 = SelinuxFactCollector()
    obj1.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-23 01:45:29.515551
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == "selinux"
    assert "_fact_ids" in selinux_facts.__dict__
    assert len(selinux_facts._fact_ids) == 0

# Generated at 2022-06-23 01:45:31.983323
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize the 'SelinuxFactCollector' object
    selinux_collector = SelinuxFactCollector()

    # Test the 'collect' method with valid/invalid parameters
    selinux_collector.collect()

# Generated at 2022-06-23 01:45:39.953607
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Dictionary and lists to hold our test data
    # test_collected_facts will have the collected facts from our test
    # test_facts_dict will have the expected facts we want to assert against
    # test_selinux_facts will have the test data for the selinux subdict
    test_collected_facts = {}
    test_facts_dict = {}
    test_selinux_facts = {}

    # We will use these to patch the AnsibleModule
    test_params = {}

    class AnsibleModuleMock():
        def __init__(self, params=None):
            self.params = {}
            if params:
                self.params = params
            self.exit_json = exit_json

        def fail_json(self, msg):
            raise RuntimeError(msg)


# Generated at 2022-06-23 01:45:46.836819
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids is not None
    assert isinstance(collector._fact_ids, set)
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-23 01:45:54.746460
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    import mock
    import tempfile
    import shutil
    import os.path

    def fake_selinux_getpolicytype():
        return (0, "targeted")

    def fake_selinux_getenforcemode():
        return (0, 1)

    def fake_selinux_is_selinux_enabled():
        return True

    def fake_security_getenforce():
        return 1

    def fake_security_policyvers():
        return 30

    def fake_selinux_getenforcemode_error():
        raise OSError()

    def fake_selinux_getpolicytype_error():
        raise OSError()


# Generated at 2022-06-23 01:45:59.494485
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys

    mock_module = type('MockModule', (), {})()
    mock_module.params = {'gather_subset': [], 'gather_timeout': 1}
    mock_module.run_command = lambda x, y: (0, 'SELinux status: enabled')

    collecter = SelinuxFactCollector()
    returned_dict = collecter.collect(mock_module, None)

    assert returned_dict == {
        'selinux': {'status': 'enabled'}
    }

# Generated at 2022-06-23 01:46:00.085204
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:46:02.017401
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-23 01:46:03.950319
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:46:08.596162
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = {}
    selinux_facts = {}
    selinux_facts['status'] = 'disabled'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = False

    assert SelinuxFactCollector().collect() == facts_dict

# Generated at 2022-06-23 01:46:16.972994
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Set a mock True or False value for the SELinux presence
    mock_selinux_present = True
    if mock_selinux_present:
        # If SELinux is present, also mock its status and test the mode.
        mock_selinux_status = 'enabled'
        mock_selinux_mode_value = 1
        mock_selinux_mode = SELINUX_MODE_DICT[mock_selinux_mode_value]
    else:
        # If SELinux is not present, set all the variables to None.
        mock_selinux_status = None
        mock_selinux_mode = None

    # Define the expected ansible_facts for the SELinux module

# Generated at 2022-06-23 01:46:19.576042
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector.name
    assert set() == selinux_fact_collector._fact_ids

# Generated at 2022-06-23 01:46:21.374600
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collected_facts = dict()
    assert("selinux_python_present" in SelinuxFactCollector.collect(collected_facts=collected_facts))

# Generated at 2022-06-23 01:46:22.712394
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-23 01:46:25.990250
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert 'selinux_python_present' in collector.collect()['selinux']

# Generated at 2022-06-23 01:46:32.232011
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This is a bit tricky to test without selinux being present.  In this test
    # an exception will be thrown but it won't be handled by the code path that
    # answers our question.  Ideally, we'd do something with mock but it doesn't
    # appear to be supported for the selinux library.  For now, this test is good
    # enough.
    module = None
    collected_facts = None
    result = SelinuxFactCollector().collect(module, collected_facts)
    # The problem is that when the selinux Python library is not present, the
    # result will be None.  This could change in the future but for now this is
    # the behavior
    assert result is not None

# Generated at 2022-06-23 01:46:41.131328
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This unit test needs to mock the selinux module functions to
    # prevent the unit test from being dependent on the filesystem
    # being in a certain state.  The selinux module is only imported
    # on first use so importing the module prevents the mock decorators
    # from being applied.
    #
    # This import is safe because the unit test setup below mocks out
    # the functions in ansible.module_utils.compat.selinux so that they
    # don't affect the unit test.
    from ansible.module_utils.compat import selinux

    # Setup selinux.is_selinux_enabled mock to return False
    # and selinux.security_getenforce mock to raise an OSError exception
    # which should be mapped to a return code of -1
    selinux.is_selinux_enabled = Mock

# Generated at 2022-06-23 01:46:42.688018
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:46:53.175984
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Check with all selinux functions disabled
    selinux.is_selinux_enabled = lambda: False
    selinux.security_getenforce = lambda: None
    selinux.selinux_getenforcemode = lambda: None
    selinux.selinux_getpolicytype = lambda: None
    selinux.security_policyvers = lambda: None
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect()
    selinux_info = facts_dict.get('selinux')
    assert selinux_info['status'] == 'disabled'

    # Check with all selinux functions enabled
    selinux.is_selinux_enabled = lambda: True
    selinux.security_getenforce = lambda: 1

# Generated at 2022-06-23 01:46:56.645857
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Instantiate the class
    selinux_fact = SelinuxFactCollector()
    # Test the name of the class
    assert (selinux_fact.name == 'selinux')

# Generated at 2022-06-23 01:47:06.616643
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def mock_is_selinux_enabled():
        return True

    def mock_security_policyvers():
        return 'Mocked selinux policy version'

    def mock_selinux_getenforcemode():
        return 0, 1

    def mock_security_getenforce():
        return 0

    def mock_selinux_getpolicytype():
        return 0, 'mock_type'

    selinux_collector = SelinuxFactCollector()
    selinux_collector._module = MockModule()
    setattr(selinux_collector, 'is_selinux_enabled', mock_is_selinux_enabled)
    setattr(selinux_collector, 'security_policyvers', mock_security_policyvers)

# Generated at 2022-06-23 01:47:11.900059
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert(selinux_fact_collector.name == 'selinux')
    assert(selinux_fact_collector._fact_ids == set())
    assert(selinux_fact_collector.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False})

# Generated at 2022-06-23 01:47:15.735210
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = None
    collected_facts = None
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()
    assert sfc.collect(module, collected_facts) is not None

# Generated at 2022-06-23 01:47:23.711326
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup selinux facts collector
    selinux_facts_collector = SelinuxFactCollector()

    # Call method collect
    selinux_facts = selinux_facts_collector.collect()

    # Validate output
    assert selinux_facts['selinux']
    assert selinux_facts['selinux']['status']
    assert selinux_facts['selinux']['policyvers']
    assert selinux_facts['selinux']['config_mode']
    assert selinux_facts['selinux']['mode']
    assert selinux_facts['selinux']['type']

# Generated at 2022-06-23 01:47:24.260602
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert True

# Generated at 2022-06-23 01:47:26.738210
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert isinstance(selinux_collector, SelinuxFactCollector)


# Generated at 2022-06-23 01:47:31.076443
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test collector class 'SelinuxFactCollector'."""
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect()

# Generated at 2022-06-23 01:47:34.025446
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:47:44.015678
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import string
    import random
    import pytest
    if sys.version_info[0] < 3:
        pytestmark = pytest.mark.skip
    # Importing the module should work without the selinux library
    if HAVE_SELINUX:
        from ansible.module_utils.compat import selinux
        # If selinux.is_selinux_enabled() doesn't exist, then fake that SELinux is disabled
        # Otherwise, return a random value for its existence.
        if not hasattr(selinux, 'is_selinux_enabled'):
            selinux.is_selinux_enabled = lambda: False
        else:
            selinux.is_selinux_enabled = lambda: random.choice([True, False])
        # If selinux.security_policyvers() doesn

# Generated at 2022-06-23 01:47:46.685891
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the collect method of SelinuxFactCollector
    """
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()


# Generated at 2022-06-23 01:47:50.629663
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test collect method of SelinuxFactCollector
    """
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:47:56.027859
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = SelinuxFactCollector()
    assert fact.collect() == {
        'selinux_python_present': True,
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        }
    }

# Generated at 2022-06-23 01:47:59.576590
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert 'selinux' in SelinuxFactCollector._fact_ids
    assert not SelinuxFactCollector.extra_options

# Generated at 2022-06-23 01:48:04.376967
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import os
    sys.path.append(".")
    from ansible.module_utils.facts import collector
    selinux_fact_collector = collector.get_collector("selinux")
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-23 01:48:14.938591
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-23 01:48:22.507661
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_info = {
        "status": "enabled",
        "config_mode": "enforcing",
        "mode": "enforcing",
        "policyvers": "28",
        "type": "targeted"
    }

    # mock selinux.is_selinux_enabled to return True
    mock_is_selinux_enabled = lambda: True
    selinux.is_selinux_enabled = mock_is_selinux_enabled

    # mock selinux.security_policyvers to return '28'
    mock_security_policyvers = lambda: '28'
    selinux.security_policyvers = mock_security_policyvers

    # mock selinux.selinux_getenforcemode to return (0, 1)
    mock_selinux_getenforcemode = lambda: (0, 1)


# Generated at 2022-06-23 01:48:25.711973
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-23 01:48:31.230584
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    results = selinux_fact_collector.collect()
    assert results['selinux']['status'] in [ 'disabled', 'enabled', 'Missing selinux Python library' ]

    results = selinux_fact_collector.collect(module=None, collected_facts=None)
    assert results['selinux']['status'] in [ 'disabled', 'enabled', 'Missing selinux Python library' ]

# Generated at 2022-06-23 01:48:33.458011
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:48:34.970809
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-23 01:48:37.499408
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Construct a instance of class SelinuxFactCollector and make sure
    # the result is not empty
    sf = SelinuxFactCollector()
    assert sf is not None
    assert sf.name == 'selinux'



# Generated at 2022-06-23 01:48:43.456567
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == "selinux"
    assert selinux._fact_ids == set()

# Generated at 2022-06-23 01:48:45.998414
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = SelinuxFactCollector()
    assert isinstance(facts_dict, SelinuxFactCollector)

# Generated at 2022-06-23 01:48:51.776876
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert 'selinux' in result
    assert 'type' in result['selinux']
    assert 'config_mode' in result['selinux']
    assert 'policyvers' in result['selinux']
    assert 'status' in result['selinux']
    assert 'mode' in result['selinux']
    assert 'selinux_python_present' in result

# Generated at 2022-06-23 01:48:58.140675
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Unit test for constructor of class SelinuxFactCollector
    """
    selinux_fact = SelinuxFactCollector()

    # Test _fact_ids value
    assert selinux_fact._fact_ids == set(), 'SelinuxFactCollector._fact_ids value error'

    # Test name value
    assert selinux_fact.name == 'selinux', 'SelinuxFactCollector.name value error'

# Generated at 2022-06-23 01:49:01.701373
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' ==  selinux_fact_collector.name
    # This is a set, not a list
    assert (isinstance(selinux_fact_collector._fact_ids, set))

# Generated at 2022-06-23 01:49:05.619722
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-23 01:49:10.772139
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sef = SelinuxFactCollector()
    assert sef.name == "selinux"

# Generated at 2022-06-23 01:49:21.666996
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""
    # Mimic selinux is not present
    old = selinux.HAVE_SELINUX
    selinux.HAVE_SELINUX = False

    # test if selinux library is missing
    if selinux.is_selinux_enabled():
        selinux.HAVE_SELINUX = old
        assert False, "Unit test for method collect of class SelinuxFactCollector failed! There is no selinux library installed on the system, but selinux.is_selinux_enabled() returned True."
    selinux_facts = SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:49:24.587023
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:49:29.878168
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''Unit test for constructor of class SelinuxFactCollector'''
    selinux_fact_collector = SelinuxFactCollector()

    # check if selinux_fact_collector.name is 'selinux'
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-23 01:49:33.406515
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:49:38.391555
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    col = SelinuxFactCollector()
    collected_facts = {}

    try:
        col.collect(collected_facts=collected_facts)
    except NameError:
        pass
    else:
        assert 'selinux' in collected_facts.keys()

# Generated at 2022-06-23 01:49:41.325388
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert isinstance(obj, SelinuxFactCollector)
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:49:50.396371
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect(collected_facts={})
    assert 'selinux' in selinux_facts
    if HAVE_SELINUX:
        assert 'status' in selinux_facts['selinux']
        assert 'type' in selinux_facts['selinux']
        assert 'mode' in selinux_facts['selinux']
        assert 'policyvers' in selinux_facts['selinux']
        assert 'config_mode' in selinux_facts['selinux']
    else:
        assert selinux_facts['selinux'] == {'status': 'Missing selinux Python library'}

# Generated at 2022-06-23 01:49:52.374493
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-23 01:49:59.279894
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a mock module and collected_facts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.facts.selinux

    # Load the facts about missing selinux python library