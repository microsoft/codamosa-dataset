

# Generated at 2022-06-23 01:39:57.060491
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:40:01.932488
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        result = SelinuxFactCollector()
        assert result.name == 'selinux'
        assert result._fact_ids == set()
    else:
        result = SelinuxFactCollector()
        assert result.name == 'selinux'
        assert result._fact_ids == set()


# Generated at 2022-06-23 01:40:04.511880
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        selinux_collector = SelinuxFactCollector
        selinux_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-23 01:40:07.848805
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:40:16.772673
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    m_module = MagicMock()
    m_collected_facts = MagicMock()
    m_selinux = MagicMock()

    test_obj = SelinuxFactCollector()
    test_obj.collect_module_facts = MagicMock()
    test_obj.collect_subset_facts = MagicMock()
    test_obj.collect_distribution_facts = MagicMock()
    test_obj.get_file_content = MagicMock(return_value='SELINUX=enforcing')
    selinux_result = {
        'status': 'enabled',
        'policyvers': 'unknown',
        'config_mode': 'unknown',
        'mode': 'enforcing',
        'type': 'unknown'
    }


# Generated at 2022-06-23 01:40:19.232478
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:40:29.620394
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test fixture
    class mock_selinux(object):
        "Mock class to replace selinux library"
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return '28'

        @staticmethod
        def selinux_getenforcemode():
            return 0, 1

        @staticmethod
        def security_getenforce():
            return 1

        @staticmethod
        def selinux_getpolicytype():
            return 0, 'targeted'

    # Create instance of SelinuxFactCollector class
    s = SelinuxFactCollector()
    # Mock the selinux library
    s.collect._selinux = mock_selinux()
    # Run the collect method and test the results

# Generated at 2022-06-23 01:40:31.855847
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:40:40.582846
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys

    # Remove "ansible.module_utils.facts.system.selinux" from sys.modules
    # to prevent interfering with the unit test.
    try:
        # Python 3.5
        if sys.modules['ansible.module_utils.facts.system.selinux'] is not None:
            del sys.modules['ansible.module_utils.facts.system.selinux']
    except KeyError:
        # Python 2.7
        if sys.modules['ansible.module_utils.facts.system.selinux'] is not None:
            del sys.modules['ansible.module_utils.facts.system.selinux']

    # Collect facts without the selinux module
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-23 01:40:50.037633
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    module.platform = 'linux'

    test_object = SelinuxFactCollector(module)

    # Test if there is a selinux python library
    # If no selinux library is present, only test that two keys are returned and that
    # the selinux library is not present.
    if not HAVE_SELINUX:
        facts_dict = test_object.collect(module)
        assert isinstance(facts_dict, dict)
        assert len(facts_dict) == 2
        assert facts_dict['selinux_python_present'] == False
        assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
        # Return so we don't proceed with testing the rest of the method
        return

    # Test the collect method where selinux is not enable
    #

# Generated at 2022-06-23 01:40:51.797991
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:40:55.475282
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # These calls may fail if code gets refactored
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-23 01:41:03.713439
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector

    # Init Collector with SelinuxFactCollector class
    collector = Collector()
    selinux_collector = SelinuxFactCollector(collector)

    # Creating a mock module used for calling the collect method
    class MockModule():
        def __init__(self):
            self.params = {}
    module = MockModule()
    collected_facts = {}

    selinux_facts = selinux_collector.collect(module=module, collected_facts=collected_facts)

    # Test if the python selinux library is imported
    if HAVE_SELINUX:
        assert selinux_facts.get('selinux_python_present') == True
    else:
        assert selinux_facts.get

# Generated at 2022-06-23 01:41:05.829554
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_instance = SelinuxFactCollector()
    selinux_facts = selinux_instance.collect()
    assert 'selinux' in selinux_facts and 'status' in selinux_facts['selinux']

# Generated at 2022-06-23 01:41:08.896929
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:41:14.079226
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert len(selinux_fact_collector._fact_ids) == 0

# Generated at 2022-06-23 01:41:25.598715
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Mock the facts collected by the base class
    collected_facts = {
        'distribution': 'Fedora',
        'distribution_version': '28',
        'distribution_major_version': '28',
        'os_family': 'RedHat',
        'system': 'Linux',
        'system_info': {
            'distribution': 'Fedora',
            'distribution_version': '28',
            'distribution_major_version': '28',
            'os_family': 'RedHat',
            'system': 'Linux',
        }
    }

    # Create a new instance of the SelinuxFactCollector class
    test_coll = SelinuxFactCollector()

    # Set the module_setup flag to false
    test_coll.module_setup = False

    # Mock the selinux library to return the

# Generated at 2022-06-23 01:41:27.553476
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    tmp = SelinuxFactCollector()
    assert(tmp.name == 'selinux')
    assert(tmp._fact_ids == set())

# Generated at 2022-06-23 01:41:31.999551
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:41:42.130758
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    facts_to_collect = {
        'all': [],
        'network': [],
        'hardware': [],
        'virtual': [],
        'fips':[],
        'system': ['system', 'selinux'],
        'selinux': ['selinux']
    }


# Generated at 2022-06-23 01:41:46.859014
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collector = SelinuxFactCollector()
    # Invoke collect
    collected_facts = test_collector.collect()

    assert isinstance(collected_facts, dict)
    assert isinstance(collected_facts.get('selinux'), dict)
    assert isinstance(collected_facts.get('selinux_python_present'), bool)

# Generated at 2022-06-23 01:41:50.125797
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux_python_present' in selinux_fact_collector.collect()

# Generated at 2022-06-23 01:41:52.270222
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-23 01:41:54.839544
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    col = SelinuxFactCollector()
    assert col.name == 'selinux'
    assert col.collect() is None

# Generated at 2022-06-23 01:42:02.648497
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    selinux_facts = selinux_fact.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'python_present' in selinux_facts
    if selinux_facts['selinux']['status'] == 'enabled':
        assert 'mode' in selinux_facts['selinux']
        assert 'config_mode' in selinux_facts['selinux']
        assert 'policyvers' in selinux_facts['selinux']
        assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-23 01:42:03.317264
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:42:04.644633
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_collector.name

# Generated at 2022-06-23 01:42:16.160899
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test class SelinuxFactCollector, method collect."""
    # Create a SelinuxFactCollector object
    selinux_collector = SelinuxFactCollector()

    # Create a module
    module = AnsibleModule()

    # Get selinux facts
    selinux_facts = selinux_collector.collect(module=module, collected_facts=None)

    # Verify the selinux_python_present fact is set
    if 'selinux_python_present' not in selinux_facts:
        raise Exception('Selinux python present not set')

    # Verify the selinux fact is set
    if 'selinux' not in selinux_facts:
        raise Exception('Selinux fact not set')

    # Verify the selinux fact has status

# Generated at 2022-06-23 01:42:20.618224
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert 'selinux' not in selinux_collector.collected_facts

# Generated at 2022-06-23 01:42:27.934665
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    try:
        from ansible.module_utils.compat import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False
    collector = SelinuxFactCollector()
    if HAVE_SELINUX:
        selinux.is_selinux_enabled = lambda: False
    facts = collector.collect()
    assert facts['selinux'] is not None
    assert 'status' in facts['selinux']
    assert 'status' in facts['selinux']

# Generated at 2022-06-23 01:42:32.437051
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector is not None

# Generated at 2022-06-23 01:42:36.716850
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert hasattr(SelinuxFactCollector, 'name')
    assert hasattr(SelinuxFactCollector, 'collect')

# Generated at 2022-06-23 01:42:39.708806
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    ''' Test the constructor of class SelinuxFactCollector '''
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:42:41.295903
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'

# Generated at 2022-06-23 01:42:43.579492
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux is not None

# Generated at 2022-06-23 01:42:46.705228
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()


# Generated at 2022-06-23 01:42:54.645174
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    test_obj = SelinuxFactCollector()
    response_expected = {
        'selinux': {
            'config_mode': 'disabled',
            'mode': 'disabled',
            'status': 'disabled',
            'policyvers': 1,
            'type': 'targeted'
        },
        'selinux_python_present': True
    }

    def getenforcemode():
        return (0, -1)

    def security_policyvers():
        return 1

    def security_getenforce():
        return -1

    def selinux_getpolicytype():
        return (0, 'targeted')

    def is_selinux_enabled():
        return True


# Generated at 2022-06-23 01:42:58.646321
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    collected_facts = fact_collector.collect()
    print(collected_facts)

if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:43:00.873072
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:43:14.500158
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-23 01:43:23.947461
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = Mock()
    mock_module.params = {}
    mock_module.params['gather_subset'] = ['all']

    mock_collected_facts = {'ansible_env': {'key1': 'value1', 'key2': 'value2'}}

    test_collector = SelinuxFactCollector()

    # Test that the collector returns the correct facts and that the ansible_env collected facts were not changed
    result = test_collector.collect(module=mock_module, collected_facts=mock_collected_facts)
    assert result == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:43:24.562660
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
     pass

# Generated at 2022-06-23 01:43:25.913617
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.__name__ == 'SelinuxFactCollector'

# Generated at 2022-06-23 01:43:30.017260
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:43:41.121282
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAVE_SELINUX:
        selinux.is_selinux_enabled = lambda: True
        selinux.selinux_getenforcemode = lambda: (0, 1)
        selinux.security_getenforce = lambda: 1
        selinux.selinux_getpolicytype = lambda: (0, 'targeted')
        selinux.security_policyvers = lambda: 30
    else:
        selinux.is_selinux_enabled = lambda: False

    # Mock the setresuid method to reset the Saved UID to the Real UID
    selinux.setresuid = lambda x, y, z: None

    facts_dict = SelinuxFactCollector().collect()

    if HAVE_SELINUX:
        assert facts_dict['selinux']['status'] == 'enabled'
        assert facts

# Generated at 2022-06-23 01:43:46.769258
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """ Unit test for constructor of SelinuxFactCollector """
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:43:49.999880
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  collector = SelinuxFactCollector()
  assert collector.collect() == {
    'selinux': {
      'status': 'disabled'
    },
    'selinux_python_present': True,
  }


# Generated at 2022-06-23 01:43:55.088893
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test with Python library present
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set(), 'Initialized _fact_ids should be empty'

    # Test with Python library not present
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()
    assert 'selinux_python_present' in selinux_fact_collector.collect()

# Generated at 2022-06-23 01:43:57.823317
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    assert collector.collect()

# Generated at 2022-06-23 01:44:00.521228
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids is not None

# Generated at 2022-06-23 01:44:03.953252
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    result = collector.collect()
    assert result['selinux_python_present']
    assert 'enabled' in result['selinux']['status'] or 'disabled' in result['selinux']['status']

# Generated at 2022-06-23 01:44:13.402825
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Set some dummy facts to test that the Selinux facts are collected
    # even though they may be present in the given facts dict.
    test_facts = {
        'domain': 'example.com',
        'selinux': {
            'config_mode': 'permissive',
            'mode': 'enforcing',
            'policyvers': '28',
            'status': 'enabled',
            'type': 'targeted'
        }
    }

    collected_facts = {}

    # Create instance of the SelinuxFactCollector. We will test the overridden method collect()
    selinux_facts = SelinuxFactCollector(collected_facts, test_facts)
    selinux_facts.collect()

    # Confirm that the selinux facts have been collected.
    assert 'selinux' in collected_facts

# Generated at 2022-06-23 01:44:15.555898
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case = SelinuxFactCollector()
    assert isinstance(test_case, SelinuxFactCollector)


# Generated at 2022-06-23 01:44:21.755285
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts import Collector

    # Check that this collector has a corresponding test class
    try:
        test_class = Collector.test_classes['selinux']
    except KeyError:
        raise AssertionError('The selinux fact collector does not have a corresponding test class.')

    # Instantiate the collector
    collector = SelinuxFactCollector(None, Collector)

    # Make sure the collector's name is 'selinux'
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:44:26.142966
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxfactscollector = SelinuxFactCollector()
    assert 'selinux' in selinuxfactscollector.collect()


if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:44:29.087566
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == set()


# Generated at 2022-06-23 01:44:39.394310
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class EmptyModule(object):
        pass

    class EmptyFacts(object):
        pass

    mock_module = EmptyModule()
    mock_facts = EmptyFacts()
    mock_facts.selinux = {
        'status': 'disabled',
        'policyvers': '28',
        'config_mode': 'disabled',
        'mode': 'disabled',
        'type': 'targeted'
    }
    expected_result = {
        'selinux': {
            'status': 'disabled',
            'policyvers': '28',
            'config_mode': 'disabled',
            'mode': 'disabled',
            'type': 'targeted'
        }
    }

    _SelinuxFactCollector = SelinuxFactCollector()

# Generated at 2022-06-23 01:44:41.517969
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-23 01:44:50.920024
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Get everything we need by mocking the selinux library """
    # Mock the selinux module and make sure it's importable
    class SelinuxObj(object):
        @classmethod
        def is_selinux_enabled(cls):
            return True

        @classmethod
        def security_getenforce(cls):
            return 0

        @classmethod
        def security_policyvers(cls):
            return 30

        @classmethod
        def selinux_getenforcemode(cls):
            return (0, 0)

        @classmethod
        def selinux_getpolicytype(cls):
            return (0, 'targeted')

        @classmethod
        def security_getenforce(cls):
            return 0

    module = None
    collected_facts = {}

    selinux = SelinuxObj

# Generated at 2022-06-23 01:44:55.343107
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:44:58.909686
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert facts['selinux']['status'] == 'Missing selinux Python library'
    assert not facts['selinux_python_present']

# Generated at 2022-06-23 01:44:59.969280
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:45:01.241315
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()

# Generated at 2022-06-23 01:45:05.070124
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    This is a unit test to ensure that the constructor of class
    SelinuxFactCollector initializes the correct class variables
    """
    assert SelinuxFactCollector._fact_ids == set()
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:45:06.108625
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:45:09.204315
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert 'selinux' in facts
    assert 'status' in facts['selinux']

# Generated at 2022-06-23 01:45:13.241625
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector()
    selinux_facts = selinux_fc.collect()
    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts


# Generated at 2022-06-23 01:45:14.639341
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:45:23.035759
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import SelinuxFactCollector

    my_selinux_fact_collector = SelinuxFactCollector()
    # Before testing, add myself to the list of fact collectors
    Collector._fact_collectors.append(my_selinux_fact_collector)

    # Run the tests
    my_selinux_fact_collector.collect()

    # Remove myself from the list of fact collectors
    Collector._fact_collectors.remove(my_selinux_fact_collector)

# Generated at 2022-06-23 01:45:25.663152
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create SelinuxFactCollector object
    obj = SelinuxFactCollector()

    obj.collect()

# Generated at 2022-06-23 01:45:29.837167
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = {'selinux_python_present': True, 'selinux': {'mode': 'unknown', 'config_mode': 'unknown', 'status': 'unknown', 'policyvers': 'unknown', 'type': 'unknown'}}

    selinux_mock = SelinuxFactCollector()
    assert selinux_dict == selinux_mock.collect()

# Generated at 2022-06-23 01:45:32.626680
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert set == type(selinux_fact_collector._fact_ids)
    assert 'selinux' in selinux_fact_collector._fact_ids

# Generated at 2022-06-23 01:45:35.134818
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:45:46.619449
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Mock library selinux
    class MockSelinux:
        def __init__(self):
            self.is_selinux_enabled = Mock(return_value=True)
            self.security_policyvers = Mock(return_value=1)
            self.selinux_getenforcemode = Mock(return_value=(0, 1))
            self.security_getenforce = Mock(return_value=1)
            self.selinux_getpolicytype = Mock(return_value=(0, 'dummy'))

    # Override the imported selinux library to use the mocked module
    global selinux
    selinux = MockSelinux()

    # Patch the BaseFactCollector.collect_platform_facts method to return a
    # dictionary so the method SelinuxFactCollector.collect will return a dict
    # according to

# Generated at 2022-06-23 01:45:48.850631
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids is not None

# Generated at 2022-06-23 01:45:54.425459
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    collector.collect()
    #assert_equal(SelinuxFactCollector.name, 'selinux')
    assert SelinuxFactCollector.name == 'selinux'
    #assert_equal(SelinuxFactCollector._fact_ids, set())
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:45:55.797583
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'

# Generated at 2022-06-23 01:45:57.461831
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    sfc.collect()

# Generated at 2022-06-23 01:46:06.169351
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    test_facts_dict = {}

    # No selinux library, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        selinux_facts = {}
        selinux_facts['status'] = 'Missing selinux Python library'
        test_facts_dict['selinux'] = selinux_facts
        test_facts_dict['selinux_python_present'] = False
        assert test_facts_dict == SelinuxFactCollector().collect()

    # selinux library present, status enabled.
    selinux_facts = {}
    selinux_facts['policyvers'] = '28'
    selinux_facts['config_mode'] = 'enforcing'
    selinux_

# Generated at 2022-06-23 01:46:11.069182
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = MockModule()
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect(module=module)
    assert facts_dict['selinux_python_present'] == False
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-23 01:46:12.842152
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxCollector = SelinuxFactCollector()
    assert selinuxCollector.name == 'selinux'

# Generated at 2022-06-23 01:46:21.874505
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    The selinux_python_present fact value is determined by the presence of selinux library.
    Set selinux library flag to False to test cases when the library is missing.
    Set status values to what they should be if the library is missing.
    """

    # Initialize class
    facts_dict = {}
    selinux_facts = {}
    global HAVE_SELINUX
    global SELINUX_MODE_DICT

    HAVE_SELINUX = False
    SELINUX_MODE_DICT = {
        1: 'enforcing',
        0: 'permissive',
        -1: 'disabled'
    }
    test_collector = SelinuxFactCollector()

    # Gather facts
    facts_dict = test_collector.collect(collected_facts=facts_dict)

    # Assert

# Generated at 2022-06-23 01:46:24.677483
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:46:27.403514
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.collect() == { 'selinux': {}, 'selinux_python_present': True }

# Generated at 2022-06-23 01:46:30.387928
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:46:33.789071
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Object instantiation
    SelinuxFactCollector_obj = SelinuxFactCollector()

    # Calling function collect of object SelinuxFactCollector_obj
    SelinuxFactCollector_obj.collect()

# Generated at 2022-06-23 01:46:38.945390
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
    assert isinstance(selinux_fact_collector._fact_ids, set)


# Generated at 2022-06-23 01:46:47.436782
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This test is dependent on having the selinux module available.
    # When the test is run against a system with the selinux library installed
    # it will include the selinux facts.
    # The test also verifies that none of the other facts are present.
    #
    # When run on a system without the selinux module available, it will
    # include the selinux_python_present fact with a value of False and will
    # not include the selinux facts.
    facts = {}
    env = {}
    collector = SelinuxFactCollector(facts, env)
    facts = collector.collect()
    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    assert 'selinux_python_present' in facts
    if facts['selinux_python_present']:
        assert 'policyvers'

# Generated at 2022-06-23 01:46:55.816800
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = dict()
    selinux_facts['status'] = 'enabled'
    if HAVE_SELINUX:
        selinux_facts['policyvers'] = selinux.security_policyvers()
        (rc, configmode) = selinux.selinux_getenforcemode()
        if rc == 0:
            selinux_facts['config_mode'] = SELINUX_MODE_DICT.get(configmode, 'unknown')
        else:
            selinux_facts['config_mode'] = 'unknown'
        mode = selinux.security_getenforce()
        selinux_facts['mode'] = SELINUX_MODE_DICT.get(mode, 'unknown')
        (rc, policytype) = selinux.selinux_getpolicytype()
        if rc == 0:
            selinux_

# Generated at 2022-06-23 01:47:03.595446
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # mock module only imports the module to be tested
    from ansible.module_utils.facts import selinux
    import ansible.module_utils.facts.collector

    fake_ansible_module = type('FakeModule', (object,), {'exit_json':exit_json})()
    fake_collector = type('FakeCollector', (object,), {'name':'selinux', '_fact_ids':set()})()

    # mock selinux module

# Generated at 2022-06-23 01:47:10.151438
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import platform
    import os
    import mock
    import pytest

    # Initialize module to test
    mod = SelinuxFactCollector()

    # Make Mock objects of os.path and platform for testing
    m_path = mock.Mock()
    m_platform = mock.Mock()
    m_platform.dist.return_value = ('redhat', '7.0', '', '', '')
    m_platform.linux_distribution.return_value = ('redhat', '7.0', '', '', '')

    selinux_data_is_disabled = {
        'selinux': {
            'status': 'disabled'
        }
    }


# Generated at 2022-06-23 01:47:16.433054
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Run the collect method of SelinuxFactCollector and verify the result
    """
    fact_collector = SelinuxFactCollector()

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library and there is no way to test without altering how Ansible imports the Selinux module.
    if HAVE_SELINUX:
        assert 'policyvers' in fact_collector.collect(collected_facts={'ansible_local': {}})['selinux']
    else:
        assert 'policyvers' not in fact_collector.collect(collected_facts={'ansible_local': {}})['selinux']

# Generated at 2022-06-23 01:47:19.632971
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:47:22.200775
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # test instantiation of class
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:47:25.469613
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxFactCollector = SelinuxFactCollector()

    assert selinuxFactCollector.collect() == {'selinux_python_present': True, 'selinux': {'type': 'unknown', 'mode': 'unknown'}}

# Generated at 2022-06-23 01:47:30.720190
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    # Test some facts are set in selinux facts
    assert isinstance(selinux_facts['selinux'], dict)
    assert 'mode' in selinux_facts['selinux']
    assert 'status' in selinux_facts['selinux']
    assert 'python_present' in selinux_facts

# Generated at 2022-06-23 01:47:34.458248
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_class_instance = SelinuxFactCollector()
    assert selinux_fact_collector_class_instance.name == 'selinux'
    assert not selinux_fact_collector_class_instance._fact_ids


# Generated at 2022-06-23 01:47:37.916764
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-23 01:47:47.076373
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Make sure the selinux library is not present and hence cannot be imported
    module = AnsibleModule(argument_spec={})
    module_class_name = 'SelinuxFactCollector'

    try:
        module.get_bin_path('selinuxenabled')
    except ValueError:
        # If selinuxenabled is not present assume selinux library is not present
        # or /sbin or /usr/sbin are not on the path
        have_selinux_lib = False
    else:
        have_selinux_lib = True

    # Create an instance of class SelinuxFactCollector
    selinux_module = SelinuxFactCollector(module=module)

    # Populate the facts_dict return value with the facts returned by SelinuxFactCollector.collect
    facts_dict = selinux_module.collect

# Generated at 2022-06-23 01:47:50.202987
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert len(selinux_facts._fact_ids) == 0
    assert selinux_facts.collect()['selinux']['status'] == 'disabled'

# Generated at 2022-06-23 01:47:53.004843
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:47:59.279621
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts = SelinuxFactCollector()
    assert facts.name == 'selinux'
    assert hasattr(facts, 'collect')

# Generated at 2022-06-23 01:48:02.667376
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert isinstance(collector, SelinuxFactCollector)
    assert isinstance(collector.collect(), dict)

# Generated at 2022-06-23 01:48:08.324629
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""

    # Initializing fact collector object
    fact_collector = SelinuxFactCollector()

    # Collecting facts
    fact_collector.collect()

    # Verifying if the method collect is returning a dictionary
    assert isinstance(fact_collector.collect(), dict)

# Generated at 2022-06-23 01:48:17.393717
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup a mock version of the selinux module that returns a
    # specific value
    class MockModule(object):
        def __init__(self):
            self.is_selinux_enabled = True
            self.security_policyvers = 64
            self.security_getenforce = 1
            self.selinux_getpolicytype = (0, 'targeted')
            self.selinux_getenforcemode = (0, 1)

    # Import module into our namespace
    import ansible.module_utils.facts.collector.selinux
    ansible.module_utils.facts.collector.selinux.selinux = MockModule()

    selinux_fc = SelinuxFactCollector()
    selinux_facts = selinux_fc.collect(collected_facts={})


# Generated at 2022-06-23 01:48:19.895803
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c._fact_ids == set()

# Generated at 2022-06-23 01:48:22.391936
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()

    test_facts = fact_collector.collect()

    assert 'selinux' in test_facts
    assert 'status' in test_facts['selinux']

# Generated at 2022-06-23 01:48:26.014789
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.collect_subset(['selinux'])

# Generated at 2022-06-23 01:48:34.750361
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test SelinuxFactCollector.collect() """
    # The selinux module is imported in the SelinuxFactCollector class, and
    # if it fails to import, only `facts_dict['selinux_python_present']` is
    # set to False.  Because of that, the following checks are made on the
    # dictionary to ensure that the class without the selinux module works
    # correctly, even if there seems to be a lot of unnecessary checks.
    import sys
    import types

    # No selinux module
    # If no selinux module is available and the selinux Python library is
    # installed, the module_utils.compat.selinux module will be imported
    # instead.  In that case, the selinux module must be tested to make sure
    # it is the compatibility module, not the real one.
    old_

# Generated at 2022-06-23 01:48:38.040877
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:48:41.494286
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # Assert that the name and fact_ids is setup correctly
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:48:45.759461
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    o = SelinuxFactCollector()
    assert isinstance(o.collect(), dict)
    assert isinstance(o.collect(collected_facts=dict(ansible_selinux=dict())), dict)

# Generated at 2022-06-23 01:48:46.735291
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:48:51.163385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert 'selinux' == selinuxFactCollector.name
    assert 'selinux' in selinuxFactCollector.collect().keys()
    assert 'selinux_python_present' in selinuxFactCollector.collect().keys()

# Generated at 2022-06-23 01:48:55.010847
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()

    assert fc is not None
    assert fc.name == 'selinux'
    assert fc._fact_ids is not None


# Generated at 2022-06-23 01:48:56.509067
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:48:58.671930
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert type(collector) == SelinuxFactCollector
    assert collector


# Generated at 2022-06-23 01:49:04.445699
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''
    Test the SelinuxFactCollector class for a simple instantiation
    '''
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert 'selinux' in collector.collected_facts

# Generated at 2022-06-23 01:49:15.605929
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    if HAVE_SELINUX:
        assert 'status' in selinux_facts['selinux']
        if selinux_facts['selinux']['status'] == 'disabled':
            assert len(selinux_facts['selinux']) == 2
        else:
            assert 'policyvers' in selinux_facts['selinux']
            assert 'mode' in selinux_facts['selinux']
            assert 'type' in selinux_facts['selinux']
            assert 'config_mode' in selinux_facts['selinux']


# Generated at 2022-06-23 01:49:17.657655
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'

# Generated at 2022-06-23 01:49:25.758405
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create the class object
    SelinuxFactCollectorObj = SelinuxFactCollector(None, None)

    # Set up the return value for method selinux.is_selinux_enabled()
    selinux.is_selinux_enabled = lambda : False

    # Call method collect
    facts_dict = SelinuxFactCollectorObj.collect()

    # Verify the expected results
    assert facts_dict == dict(selinux_python_present=True,
                              selinux=dict(status='disabled'))

    # Set up the return value for method selinux.is_selinux_enabled()
    selinux.is_selinux_enabled = lambda : True

    # Call method collect
    facts_dict = SelinuxFactCollectorObj.collect()

    # Verify the expected results
    assert facts_dict == dict

# Generated at 2022-06-23 01:49:30.364863
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']
    assert 'type' in result['selinux']

# Generated at 2022-06-23 01:49:33.259866
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    obj = SelinuxFactCollector()

    #assert obj.name == "selinux"
    assert obj.name == "selinux"
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:49:38.240168
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Ensure that we can instantiate the class SelinuxFactCollector
    """
    result = SelinuxFactCollector()
    assert result is not None
    assert result.__class__.__name__ == 'SelinuxFactCollector'


# Generated at 2022-06-23 01:49:48.879461
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    fc = SelinuxFactCollector()

    # create mock object for module, selinux, and selinux.selinux module
    class MockModule(object):
        pass

    module = MockModule()
    module.selinux = None
    module.selinux.selinux = None

    # create mock object for module.selinux.selinux
    class MockSelinux(object):
        pass

    module.selinux.selinux = MockSelinux()

    # get status when selinux is disabled on system
    module.selinux.selinux.is_selinux_enabled = lambda: False
    selinux_facts = fc.collect()
    assert (selinux_facts['selinux']['status'] == 'disabled')

    # get status when selinux is enabled on system


# Generated at 2022-06-23 01:49:53.282848
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect(module=None, collected_facts={})
    assert selinux_facts['selinux_python_present']
    assert selinux_facts['selinux']['status'] == 'disabled'

# Generated at 2022-06-23 01:49:58.065933
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    # Execute the code we are testing
    selinux_fact = SelinuxFactCollector()
    selinux_fact.collect()

    # We should have the selinux facts.
    assert("selinux" in selinux_fact.facts)
    assert("selinux_python_present" in selinux_fact.facts)
    assert("status" in selinux_fact.facts['selinux'])
