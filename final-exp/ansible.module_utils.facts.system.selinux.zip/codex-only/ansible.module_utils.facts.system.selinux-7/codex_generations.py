

# Generated at 2022-06-23 01:39:59.049756
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert 'selinux' in result
    assert 'status' in result['selinux']

# Generated at 2022-06-23 01:40:01.806740
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Check module attributes and methods
    assert SelinuxFactCollector.name == 'selinux'
    assert type(SelinuxFactCollector._fact_ids) is set

# Generated at 2022-06-23 01:40:09.560808
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the method collect of SelinuxFactCollector, including:
    1. Test if the collected facts are correct;
    2. Test if the correct facts are collected when selinux Python library is missing;
    """
    # Test for class SelinuxFactCollector

    # TODO: mock the selinux Python library

    # Test for class SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()
    assert selinux_facts.get('selinux') is not None
    assert selinux_facts.get('selinux_python_present') is not None

# Generated at 2022-06-23 01:40:11.927899
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    assert 'selinux' in selinux_facts

# Generated at 2022-06-23 01:40:19.782537
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.collector import collector_singleton
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import list_collectors
    import mock
    from ansible.module_utils.compat import selinux
    import pkgutil
    import pytest

    orig_import = __import__

    def import_mock(name, *args):
        if name == 'selinux':
            raise ImportError
        return orig_import(name, *args)

    # Test for selinux library being present

# Generated at 2022-06-23 01:40:28.332515
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    collected_facts = {}
    facts_dict = selinux_collector.collect(collected_facts=collected_facts)

    assert facts_dict['selinux']['status'] == 'disabled'
    assert facts_dict['selinux']['policyvers'] == 'unknown'
    assert facts_dict['selinux']['config_mode'] == 'unknown'
    assert facts_dict['selinux']['mode'] == 'unknown'
    assert facts_dict['selinux']['type'] == 'unknown'
    assert facts_dict['selinux_python_present'] == False

# Generated at 2022-06-23 01:40:29.934588
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    selinux_obj.collect()

# Generated at 2022-06-23 01:40:31.401479
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'


# Generated at 2022-06-23 01:40:35.870211
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector

    ac = collector.get_collector('selinux')
    result = ac.collect()

    assert result is not None
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert 'selinux_python_present' in result

    assert result['selinux_python_present'] == True

# Generated at 2022-06-23 01:40:45.616683
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sys_module = type('module', (), {})
    sys_module.__file__ = '/path/to/module/selinux.py'
    module_mock = type('module', (), {})
    module_mock.__spec__ = sys_module

    selinux_mock = type('selinux', (), {})
    selinux_mock.is_selinux_enabled = lambda: False
    module_mock.selinux = selinux_mock

    facts_dict = SelinuxFactCollector().collect(module = module_mock)
    assert type(facts_dict) == dict
    assert 'selinux_python_present' in facts_dict
    assert 'selinux' in facts_dict
    assert type(facts_dict['selinux']) == dict

# Generated at 2022-06-23 01:40:56.047824
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()

# Generated at 2022-06-23 01:41:04.252843
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ This test module is to test function 'collect' of class
    'SelinuxFactCollector'.This test case will create an object of
    'SelinuxFactCollector' and call the method 'collect'.
    """

    from ansible_collections.os.posix.plugins.module_utils.facts.collectors.system.selinux import SelinuxFactCollector
    import sys
    import pytest

    selinux_facts_dict = {'policyvers': '28', 'config_mode': 'enforcing', 'type': 'targeted', 'mode': 'enforcing', 'status': 'enabled'}
    selinux_python_present = True
    global HAVE_SELINUX
    if sys.platform == 'darwin':
        HAVE_SELINUX = False

# Generated at 2022-06-23 01:41:13.910981
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If the selinux library is unavailable, the status ansible_selinux
    # variable should be present with a value of "Missing selinux Python library".
    # The selinux_python_present variable should be present with a value of False.
    class FakeSelinuxModule(object):
        def __init__(self):
            self.fail_json = lambda *args, **kwargs: None

    class FakeSelinuxSeLiteException(Exception):
        pass

    class FakeSelinuxSeLite(object):
        def is_selinux_enabled(self):
            raise FakeSelinuxSeLiteException

    class FakeSelinuxOSError(Exception):
        pass

    class FakeSelinux(object):
        def __init__(self):
            self.selinux = FakeSelinuxSeLite()

       

# Generated at 2022-06-23 01:41:16.389422
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    testObj = SelinuxFactCollector()
    assert testObj.name == 'selinux'
    assert len(testObj._fact_ids) == 0

# Generated at 2022-06-23 01:41:18.651036
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-23 01:41:21.826819
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    selinux_facts.SelinuxFactCollector.collect()
    Unit test for method collect of class SelinuxFactCollector
    '''

    # Get facts based on selinux library
    selinux_facts = SelinuxFactCollector().collect()
    status = selinux_facts.get('selinux', {}).get('status')
    assert status == 'disabled' or status == 'enabled'

# Generated at 2022-06-23 01:41:30.889126
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class fake_module(object):
        def __init__(self):
            pass

    class fake_selinux(object):
        def __init__(self):
            pass

        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return 28

        @staticmethod
        def security_getenforce():
            return 1

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')

    module = fake_module()
    selinux = fake_selinux()
    sfc = SelinuxFactCollector()

    # SELinux enabled

# Generated at 2022-06-23 01:41:35.282159
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    #
    #  Make sure that constructor sets the name and _fact_ids correctly
    #
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:41:38.137712
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    a = SelinuxFactCollector()
    assert a.collect()['selinux_python_present'] == True

# Generated at 2022-06-23 01:41:45.654113
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = SelinuxFactCollector().collect()
    if 'selinux' in facts_dict:
        # Tests that valid keys are present in the dictionary
        assert all(key in facts_dict['selinux'] for key in ['status', 'mode',
                    'config_mode', 'policyvers', 'type'])
        assert 'selinux_python_present' in facts_dict
    else:
        # Test that the key 'selinux' is not present in the dictionary
        assert 'selinux' not in facts_dict
        assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-23 01:41:55.061662
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest_ansible
    import ansible.module_utils.facts.collector.selinux
    import ansible.module_utils.facts.collector

    collector = ansible.module_utils.facts.collector.selinux.SelinuxFactCollector()

    selinux_present = pytest_ansible.lib.mocks.MockLibrary("selinux")
    selinux_present.is_selinux_enabled = pytest_ansible.lib.mocks.MockFunction("is_selinux_enabled", return_value=True)
    selinux_present.security_policyvers = pytest_ansible.lib.mocks.MockFunction("security_policyvers", return_value=4)
    selinux_present.selinux_getenforcemode = pytest_ansible.lib.m

# Generated at 2022-06-23 01:41:58.078844
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactcollector = SelinuxFactCollector()
    assert selinuxfactcollector.name == 'selinux'
    assert selinuxfactcollector._fact_ids == set(['selinux'])

# Generated at 2022-06-23 01:42:05.404678
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    print("Constructor test for class SelinuxFactCollector")
    my_obj = SelinuxFactCollector()
    if isinstance(my_obj, SelinuxFactCollector):
        print("Constructor test for class SelinuxFactCollector: Passed")
    else:
        print("Constructor test for class SelinuxFactCollector: Failed")


# Generated at 2022-06-23 01:42:06.345252
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:42:14.341213
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test with library present and SELinux enabled
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set(['selinux', 'selinux_python_present'])

    # Test with library missing and SELinux enabled
    collector.HAVE_SELINUX = False
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set(['selinux', 'selinux_python_present'])


# Generated at 2022-06-23 01:42:15.977760
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:42:19.107559
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """unit test for constructor of class SelinuxFactCollector."""
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:42:26.661810
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create a temporary object of the class SelinuxFactCollector
    selinux_instance = SelinuxFactCollector()

    # create a temporary object of class Dictionary
    # to pass None as collected_facts input to the collect method of the class SelinuxFactCollector
    class Dict():
        def __init__(self):
            self.facts = {}
            self.ansible_facts = {}
    dict_instance = Dict()

    # call the collect method of the class SelinuxFactCollector
    # by passing the required object of class Dictionary
    selinux_instance.collect(collected_facts=dict_instance)

# Generated at 2022-06-23 01:42:33.685869
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert 'selinux' in result
    assert result['selinux_python_present']
    assert 'status' in result['selinux']
    assert result['selinux']['status'] in ['enabled', 'disabled', 'Missing selinux Python library']

# Generated at 2022-06-23 01:42:44.394941
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = dict()

    # Test setup:
    # Selinux enabled, no access to selinux file system (to return policyvers and config_mode)
    selinux.is_selinux_enabled = lambda: True
    selinux.security_getenforce = lambda: 1
    selinux.selinux_getpolicytype = lambda: (0, 'targeted')
    selinux.security_policyvers = lambda: 'not found'
    selinux.selinux_getenforcemode = lambda: ('not found', 'unknown')


# Generated at 2022-06-23 01:42:50.476102
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test method collect with missing module
    selinuxFactCollector = SelinuxFactCollector()
    print(selinuxFactCollector.collect())

    # Test method collect on system without selinux (missing selinux library)
    selinuxFactCollector = SelinuxFactCollector()
    facts_dict = selinuxFactCollector.collect()
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict['selinux_python_present'] == False

# Generated at 2022-06-23 01:42:53.550170
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:43:04.598572
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {
        'status': 'enabled',
        'policyvers': '29',
        'config_mode': 'enforcing',
        'mode': 'enforcing',
        'type': 'targeted'
    }

    (rc, policytype) = selinux.selinux_getpolicytype()
    if rc == 0:
        selinux_facts['type'] = policytype
    else:
        selinux_facts['type'] = 'unknown'

    SELINUX_MODE_DICT = {
        1: 'enforcing',
        0: 'permissive',
        -1: 'disabled'
    }

    selinux_facts_check = {}
    selinux_facts_check['selinux'] = selinux_facts
    selinux_facts_check['selinux_python_present'] = True

# Generated at 2022-06-23 01:43:08.654190
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert 'selinux' in facts
    assert 'selinux_python_present' in facts
    assert facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:43:11.153352
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:43:13.362837
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_object = SelinuxFactCollector()
    assert selinux_object.name == 'selinux'
    assert selinux_object.collect()

# Generated at 2022-06-23 01:43:15.480646
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:43:16.952856
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collect_se_linux = SelinuxFactCollector()
    assert collect_se_linux.name == 'selinux'

# Generated at 2022-06-23 01:43:18.551463
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'

# Generated at 2022-06-23 01:43:20.649702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect."""
    SelinuxFactCollector.collect()
    assert False, 'Test not implemented'

# Generated at 2022-06-23 01:43:30.634961
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    module = None
    collected_facts = None

    # Initiating the collector class object
    selinux_facts = SelinuxFactCollector()

    # Testing the collect method with selinux library present
    module_utils_compat_selinux = {
         'is_selinux_enabled': lambda: True,
         'security_policyvers': lambda: 'unknown',
         'security_getenforce': lambda: 'unknown',
         'selinux_getpolicytype': lambda: (0, 'targeted'),
         'selinux_getenforcemode': lambda: (0, 1)
    }

    class MockModuleImportSELinux(object):
        selinux = selinux_facts
        _ansible_module_imported_from = True


# Generated at 2022-06-23 01:43:36.860919
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector.collect() == dict()

    # TODO: Verify that the various os.path.exists calls are
    #       tested as well as the return values.

# Generated at 2022-06-23 01:43:42.192738
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()

    assert facts['selinux']
    assert 'status' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'policyvers' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'type' in facts['selinux']

# Generated at 2022-06-23 01:43:45.137993
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:43:48.652417
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x_SelinuxFactCollector = SelinuxFactCollector()
    assert x_SelinuxFactCollector.name == 'selinux'
    assert 'selinux_python_present' in x_SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:43:55.478961
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    test = SelinuxFactCollector()

    module = None
    collected_facts = None

    result = test.collect(module, collected_facts)
    assert result['selinux_python_present'] == True
    assert result['selinux']['status'] == 'enabled'
    assert result['selinux']['policyvers'] != ''
    assert result['selinux']['config_mode'] != ''
    assert result['selinux']['mode'] != ''
    assert result['selinux']['type'] != ''

# Generated at 2022-06-23 01:43:58.344039
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    slfc = SelinuxFactCollector()
    assert slfc.name == 'selinux'

# Generated at 2022-06-23 01:44:07.704269
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fixture = {
        "selinux": {
            "config_mode": "disabled",
            "mode": "disabled",
            "policyvers": "28",
            "status": "enabled",
            "type": "targeted"
        },
        "selinux_python_present": True
    }

    test_collector = SelinuxFactCollector()

    def selinux_is_selinux_enabled():
        return False

    def selinux_security_policyvers():
        return 28

    def selinux_selinux_getenforcemode():
        return (0, 1)

    def selinux_security_getenforce():
        return 1

    def selinux_selinux_getpolicytype():
        return (0, 'targeted')

    test_collector.collect.__gl

# Generated at 2022-06-23 01:44:09.973642
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:44:13.762103
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()

    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set(['selinux_python_present', 'selinux'])


# Generated at 2022-06-23 01:44:24.060406
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils import basic
    import pytest
    c = SelinuxFactCollector()
    assert c.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # Import the selinux module, turn it on and test the collect method
    pytest.importorskip('selinux')

    # Set selinux to permissive
    if not selinux.is_selinux_enabled():
        selinux.setenforce(0)
        selinux.security_setenforce(0)

    # Collect facts from SelinuxFactCollector

# Generated at 2022-06-23 01:44:34.809851
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector

    # Missing selinux library
    collector.collectors['selinux'] = SelinuxFactCollector
    facts_dict = collector.collect(None, None)
    assert 'selinux' in facts_dict
    selinux = facts_dict['selinux']
    assert 'status' in selinux
    assert 'Missing selinux Python library' == selinux['status']
    assert 'selinux_python_present' in facts_dict
    assert not facts_dict['selinux_python_present']

    # Present selinux library
    HAVE_SELINUX = True
    import ansible.module_utils.facts.selinux
    ansible.module_utils.facts.selinux.security_policyvers = lambda: 1

# Generated at 2022-06-23 01:44:36.248609
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:44:38.404769
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)

# Generated at 2022-06-23 01:44:40.856691
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """ selinux.py: test class SelinuxFactCollector """
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:44:44.635748
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library',
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-23 01:44:53.791102
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # These are variables used for testing the method collect of class SelinuxFactCollector
    # Number: 1
    test_collect_variables_1 = {'ansible_selinux': {'status': 'enabled',
                                                    'mode': 'enforcing',
                                                    'policyvers': 33,
                                                    'type': 'targeted',
                                                    'config_mode': 'enforcing'}}

    # Number: 2
    test_collect_variables_2 = {'ansible_selinux': {'status': 'enabled',
                                                    'mode': 'permissive',
                                                    'policyvers': 33,
                                                    'type': 'targeted',
                                                    'config_mode': 'enforcing'}}

    # Number: 3

# Generated at 2022-06-23 01:45:04.066233
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Here we have the unit test for method collect of the class SelinuxFactCollector.
    """

    from ansible.module_utils.facts import collector

    # Creation of the object of class SelinuxFactCollector
    obj = collector.get_collector("SelinuxFactCollector")

    # Creation of the dictionary which will be passed to method collect as an argument
    collected_facts = {}
    collected_facts['ansible_facts'] = {'selinux': {'config_mode': 'enforcing', 'status': 'disabled'}, 'selinux_python_present': False}

    # Call of method collect passing the created dictionary
    result = obj.collect(collected_facts)

    # Test of the result

# Generated at 2022-06-23 01:45:05.955178
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-23 01:45:10.664361
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = type('module', (object,), {'params': {}, 'is_executable': lambda x, *args, **kwargs: True})
    mock_collector = SelinuxFactCollector()
    mock_collector.collect(mock_module)
    assert 'selinux' in mock_collector.collect(mock_module)

# Generated at 2022-06-23 01:45:14.581501
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set([])

# Generated at 2022-06-23 01:45:16.575601
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector(None, None)
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:45:18.907992
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == "selinux"
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:45:26.933265
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect()['selinux_python_present'] == HAVE_SELINUX
    selinux_fact_collector._fact_ids = 'test'
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect()['selinux_python_present'] == HAVE_SELINUX

# Generated at 2022-06-23 01:45:32.546732
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        from ansible.module_utils import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    tc_factory = SelinuxFactCollector()
    tc_collect = tc_factory()
    selinux_facts = tc_collect.collect()
    assert selinux_facts['selinux_python_present'] == HAVE_SELINUX

# Generated at 2022-06-23 01:45:40.499825
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import os

    try:
        from ansible.module_utils.compat import selinux
    except ImportError:
        from ansible.module_utils.facts.collector import SelinuxFactCollector

        # Fake that the selinux library is not present by setting the module
        # to None and then calling collect
        SelinuxFactCollector.collect(module=None, collected_facts={})

        return

    facts_dict = {}
    fake_selinux_mode = 'disabled'
    fake_selinux_config_mode = 'enforcing'
    fake_selinux_policyvers = '28'
    fake_selinux_policytype = 'targeted'
    fake_selinux_enforce_mode = 'enforcing'


# Generated at 2022-06-23 01:45:43.321844
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids != x.name
    assert len(x._fact_ids) == 1

# Generated at 2022-06-23 01:45:50.399634
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the functionality of the collect method
    of the SelinuxFactCollector.
    """
    # expected value for collect method
    expected_selinux_facts = {
        'status': 'enabled',
        'policyvers': 59,
        'config_mode': 'enforcing',
        'mode': 'enforcing',
        'type': 'targeted'
    }
    returned_selinux_facts = SelinuxFactCollector().collect()
    assert expected_selinux_facts == returned_selinux_facts['selinux']

# Generated at 2022-06-23 01:45:53.620106
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector._fact_ids == set()

# Unit tests for method collect

# Generated at 2022-06-23 01:45:57.838948
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    expected_result = {
        'selinux_python_present': True,
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        }
    }

    obj = SelinuxFactCollector()
    result = obj.collect()
    assert result == expected_result

# Generated at 2022-06-23 01:45:59.806675
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:46:10.938643
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import ansible_collected_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    SELinuxFactCollector = SelinuxFactCollector()
    BaseFactCollector = BaseFactCollector(None, None, None)

    test_facts_info = ansible_collected_facts()
    test_facts_info['ansible_system'] = 'Linux'

    # Case 1: test when selinux library is missing
    test_collect_result = SELinuxFactCollector.collect(collected_facts=test_facts_info)
    assert test_collect_result == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # Case 2: test when selinux is not enabled


# Generated at 2022-06-23 01:46:18.180914
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_dict = {
        'selinux': {
            'config_mode': 'permissive',
            'mode': 'permissive',
            'status': 'enabled',
            'type': 'targeted'},
        'selinux_python_present': True}
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == facts_dict

# Generated at 2022-06-23 01:46:24.740203
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    #Test with missing selinux python library
    selinux_fc = SelinuxFactCollector(None, None)
    selinux_facts = selinux_fc.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'Missing selinux Python library' in selinux_facts['selinux']['status']
    assert 'selinux_python_present' in selinux_facts
    assert selinux_facts['selinux_python_present'] is False


# Generated at 2022-06-23 01:46:28.707067
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:46:30.762293
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Create an instance of SelinuxFactCollector
    """
    _ = SelinuxFactCollector()

# Generated at 2022-06-23 01:46:34.565173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:46:37.709976
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collect = SelinuxFactCollector().collect()
    assert not collect['selinux_python_present']
    assert collect['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-23 01:46:43.156050
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module_mock = None
    collected_facts_mock = None
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect(module_mock, collected_facts_mock)
    assert 'selinux' in facts_dict
    assert 'type' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']

# Generated at 2022-06-23 01:46:48.257052
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:46:56.496659
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import os

    if not HAVE_SELINUX:
        os.environ['SELINUX_LIB_PATH'] = '/tmp'

    addr = None
    with mock.patch('selinux.is_selinux_enabled') as is_selinux_enabled:
        with mock.patch('selinux.security_policyvers') as security_policyvers:
            with mock.patch('selinux.selinux_getenforcemode') as selinux_getenforcemode:
                with mock.patch('selinux.security_getenforce') as security_getenforce:
                    with mock.patch('selinux.selinux_getpolicytype') as selinux_getpolicytype:
                        is_selinux_enabled.return_value = False
                        collecto

# Generated at 2022-06-23 01:46:59.902347
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'
    assert len(selinux_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:47:09.415820
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and mock selinux
    module = selinux = {}

    # Create a mock object and mock getenforcemode() and getpolicytype()
    mock_obj = selinux.selinux = object()
    mock_obj.selinux_getpolicytype = lambda: (0, 'targeted')
    mock_obj.selinux_getenforcemode = lambda: (0, 0)

    # Create a mock object and mock is_selinux_enabled, getenforce, security_policyvers
    mock_obj = selinux.security = object()
    mock_obj.security_policyvers = lambda: 24
    mock_obj.security_getenforce = lambda: 0
    mock_obj.is_selinux_enabled = lambda: True

    # Create a mock object and mock is_selinux_enabled, get

# Generated at 2022-06-23 01:47:12.609425
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector('test')
    assert selinux_fact_collector.name == 'test'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:47:14.941215
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:47:18.191174
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:47:25.892553
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # We want to be able to send in a different name for the module
    # to mimic the behavior of the internal Ansible module
    class FakeAnsibleModule():
        def __init__(self):
            self.params = {}

    c = SelinuxFactCollector()
    # Pass in a fake AnsibleModule to the collect method so it
    # will be used instead of AnsibleModule.
    facts = c.collect(module=FakeAnsibleModule())
    assert not facts['selinux_python_present']
    assert facts['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-23 01:47:35.422310
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    base_collector = BaseFactCollector()
    base_collector.collect()

    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect()

    assert 'selinux' in base_collector.collect(), 'selinux key not in base_collector.collect()'
    assert 'selinux' in selinux_collector.collect(), 'selinux key not in selinux_collector.collect()'


# Generated at 2022-06-23 01:47:42.949320
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector1 = SelinuxFactCollector()
    assert selinuxFactCollector1.name == "selinux"
    assert selinuxFactCollector1._fact_ids == set()
    assert selinuxFactCollector1.collect() == {'selinux':{'status':'Missing selinux Python library'}, 'selinux_python_present': False}

    # Test if selinux library is present/installed
    HAVE_SELINUX = True
    selinuxFactCollector2 = SelinuxFactCollector()
    assert selinuxFactCollector2.name == "selinux"
    assert selinuxFactCollector2._fact_ids == set()



# Generated at 2022-06-23 01:47:52.996495
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux module is not present
    # returns a dictionary with status disabled and selinux_python_present set to False
    if not HAVE_SELINUX:
        fc = SelinuxFactCollector()
        data = fc.collect()
        assert data['selinux']['status'] == 'Missing selinux Python library'
        assert data['selinux_python_present'] is False
    # selinux module is present, but selinux is disabled
    # returns a dictionary with status disabled and selinux_python_present set to True
    else:
        # Mock selinux.is_selinux_enabled() so no other selinux methods are called
        selinux.is_selinux_enabled = lambda : False
        fc = SelinuxFactCollector()
        data = fc.collect()

# Generated at 2022-06-23 01:47:56.027132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test constructor for class SelinuxFactCollector"""

    # initialize object
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-23 01:48:01.963794
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert 'selinux' in selinux_collector._fact_ids
    assert hasattr(selinux_collector, 'collect')
    assert callable(selinux_collector.collect)

# Generated at 2022-06-23 01:48:03.646132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert(selinux_obj.name == 'selinux')

# Generated at 2022-06-23 01:48:05.642736
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:48:10.115078
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert facts_dict == {'selinux': {'type': 'unknown', 'mode': 'unknown', 'status': 'disabled',
                                      'config_mode': 'unknown', 'policyvers': 'unknown'}}

# Generated at 2022-06-23 01:48:12.587812
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()

    assert fact_collector.name == 'selinux'
    assert fact_collector.collect() is not None

# Generated at 2022-06-23 01:48:14.893785
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:48:16.845196
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set(['seLinux', 'selinux'])

# Generated at 2022-06-23 01:48:25.429834
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    SelinuxFactCollector.collect with an empty dict
    '''
    facts_dict = dict()
    selinux_facts = dict()

    # Set a boolean for testing whether the Python library is present
    facts_dict['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        selinux_facts['status'] = 'disabled'
    else:
        selinux_facts['status'] = 'enabled'

        try:
            selinux_facts['policyvers'] = selinux.security_policyvers()
        except (AttributeError, OSError):
            selinux_facts['policyvers'] = 'unknown'


# Generated at 2022-06-23 01:48:27.771766
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()


# Generated at 2022-06-23 01:48:35.643906
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    This method will check if the class is instantiateing or not.
    """
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# test for collect method for class SelinuxFactCollector

# Generated at 2022-06-23 01:48:45.652087
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import unittest

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']

    class MockSession(object):
        def __init__(self, module_args=None):
            self.module_args = module_args

    class MockSelinuxLibrary(object):
        def __init__(self):
            self.fake_status = 'disabled'
            self.fake_policyvers = -1
            self.fake_config_mode = -1
            self.fake_mode = 'disabled'
            self.fake_type = 'unknown'

        def is_selinux_enabled(self):
            if self.fake_status == 'enabled':
                return True
            else:
                return False

       

# Generated at 2022-06-23 01:48:47.546626
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:48:48.699818
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:48:50.972852
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collected_facts['selinux'] == collector.collect()
    assert collected_facts['ansible_facts'] == collector.collect()

# Generated at 2022-06-23 01:48:55.240308
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    #
    # test constructor
    #
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    assert (isinstance(SelinuxFactCollector, BaseFactCollector))



# Generated at 2022-06-23 01:48:58.328209
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import Collector
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, Collector)

# Generated at 2022-06-23 01:49:08.145036
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test that the method collect for the class SelinuxFactCollector will add
    the expected selinux facts to a facts dictionary. """

    from ansible.module_utils._text import to_bytes
    test_module = None
    test_ansible_facts = {'sysname': to_bytes('Linux')}
    test_collector = SelinuxFactCollector(test_module, test_ansible_facts)

    collect_results = test_collector.collect()
    assert set(collect_results.keys()) == {'selinux', 'selinux_python_present'}

    # test the value in the facts dictionary
    assert collect_results['selinux_python_present'] is True


# Generated at 2022-06-23 01:49:09.332121
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()

# Generated at 2022-06-23 01:49:18.470077
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_ansible_module = {}
    test_ansible_module['ansible_facts'] = {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'disabled',
            'status': 'disabled',
            'type': 'unknown'
        },
        'selinux_python_present': False
    }

    test_selinux_fact_collector = SelinuxFactCollector()
    result = test_selinux_fact_collector.collect(
        module=test_ansible_module,
        collected_facts={}
    )
    assert result == test_ansible_module['ansible_facts']

# Generated at 2022-06-23 01:49:29.985497
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Facts
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create a Facts object to return the Selinux Collector interface
    test_facts = Facts(None, None)
    selinux_collector = get_collector_instance('selinux', test_facts, None, None)

    # Mock collect function to return test data
    selinux_collector_collect = selinux_collector.collect

    def mock_collect(*args, **kwargs):
        return {'selinux': {'status': 'enabled', 'policyvers': '30', 'type': 'targeted', 'mode': 'enforcing', 'config_mode': 'enforcing'},
                'selinux_python_present': True}
    selinux_collector.collect

# Generated at 2022-06-23 01:49:38.248666
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a mock module and a fake selinux library that returns the values
    # we want for the selinux facts tests
    module = Mock()
    class FakeSelinux():
        is_selinux_enabled = Mock(return_value=1)
        security_policyvers = Mock(return_value=2)
        security_getenforce = Mock(return_value=0)
        selinux_getpolicytype = Mock(return_value=(0, 'targeted'))
        selinux_getenforcemode = Mock(return_value=(0, 0))

    # Mock the import selinux call if it isn't already
    if not HAVE_SELINUX:
        _orig_import = __import__
        def import_mock(name, *args):
            if name == 'selinux':
                return FakeSelinux
           

# Generated at 2022-06-23 01:49:48.879351
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import collector_registry as registry
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    import ansible.module_utils.facts.collector.selinux

    # run the module code with a fake module object and test that the result
    # matches the expected structure
    test_module = basic.AnsibleModule(argument_spec={})

    # selinux.is_selinux_enabled() is stubbed as False and the rest of the
    # module code is skipped as a result, so just test the stubbed result
    facts_collector = Selinux

# Generated at 2022-06-23 01:49:54.323777
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()

    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert 'policyvers' in result['selinux']
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']
    assert 'type' in result['selinux']
    assert 'selinux_python_present' in result

# Generated at 2022-06-23 01:50:02.450007
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Use selinux Python library mocks to prevent test from working like actual code
    from ansible.test.unit.module_utils.facts.test_collector import MockSel
    from mock import MagicMock

    MockSel.is_selinux_enabled = MagicMock(return_value=True)
    MockSel.security_policyvers = MagicMock(return_value=1)
    MockSel.selinux_getenforcemode = MagicMock(return_value=(0, 1))
    MockSel.security_getenforce = MagicMock(return_value=1)
    MockSel.selinux_getpolicytype = MagicMock(return_value=(0, 'targeted'))

    test_collector = SelinuxFactCollector()
    assert test_collector.name == 'selinux'
    assert test