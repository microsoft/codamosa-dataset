

# Generated at 2022-06-23 01:39:57.568805
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert selinuxFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:40:07.023110
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collected_facts = {}
    facts_dict = {}
    selinux_facts = {}

    class selinux(object):
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return 2

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def security_getenforce():
            return 0

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')

    def set_module_args(args):
        pass

    selinux_obj = selinux()
    selinux_fact_collector_obj = SelinuxFactCollector(module=None, collected_facts=collected_facts)

    selinux_fact_collector_

# Generated at 2022-06-23 01:40:16.336145
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import DictFactCollector

    # create a collector and register
    SelinuxFactCollector.collectors = Collectors()
    SelinuxFactCollector.register_collectors()
    fact_collector = SelinuxFactCollector.collectors.get('selinux')

    # explicitly disable selinux on the system, check selinux_facts dict
    fact_collector.selinux = None
    fact_collector.selinux.is_selinux_enabled = lambda: False
    fact_collector.selinux.is_selinux_mls_enabled = lambda: False
    fact_collector.sel

# Generated at 2022-06-23 01:40:25.345692
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is missing, skip the test
    if not HAVE_SELINUX:
        return

    col = SelinuxFactCollector()
    ret = col.collect()

    assert 'selinux' in ret
    assert 'policyvers' in ret['selinux']
    assert 'config_mode' in ret['selinux']
    assert 'mode' in ret['selinux']
    assert 'type' in ret['selinux']
    assert 'status' in ret['selinux']
    assert 'selinux_python_present' in ret
    assert isinstance(ret['selinux_python_present'], bool)

# Generated at 2022-06-23 01:40:27.929552
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This is a pretty horrible test as it uses a real system's SELinux facts
    sfc = SelinuxFactCollector()
    assert sfc.collect()

# Generated at 2022-06-23 01:40:31.610596
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:40:33.810314
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxCollector = SelinuxFactCollector()
    assert selinuxCollector is not None
    assert selinuxCollector.name == 'selinux'

# Generated at 2022-06-23 01:40:38.755605
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()

    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'type' in facts['selinux']
    assert 'policyvers' in facts['selinux']
    assert 'selinux_python_present' in facts

# Generated at 2022-06-23 01:40:45.790201
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()
    assert isinstance(selinux_collector, BaseFactCollector)
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-23 01:40:48.613283
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert(isinstance(selinux_fact_collector, SelinuxFactCollector))


# Generated at 2022-06-23 01:40:52.957079
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # This is not a complete set of tests
    # The main tests of the collector are in test_core.py
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:41:05.694003
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import inspect

    # test if SelinuxFactCollector() raises Exception when selinux library is missing
    if 'selinux' in sys.modules:
        del sys.modules['selinux']
    if 'ansible.module_utils.compat.selinux' in sys.modules:
        del sys.modules['ansible.module_utils.compat.selinux']
    assert 'selinux' not in sys.modules
    assert 'ansible.module_utils.compat.selinux' not in sys.modules
    assert not HAVE_SELINUX
    c = SelinuxFactCollector()
    assert c is not None
    assert 'selinux' not in dir(c)
    assert c.name == 'selinux'

# Generated at 2022-06-23 01:41:07.574767
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-23 01:41:11.903903
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_var = SelinuxFactCollector()
    assert selinux_var.name == 'selinux'
    assert selinux_var._fact_ids == {'selinux', 'selinux_python_present'}

# Generated at 2022-06-23 01:41:20.499823
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts_dict = SelinuxFactCollector().collect()

    assert 'selinux' in selinux_facts_dict
    assert type(selinux_facts_dict['selinux']) == dict
    assert 'status' in selinux_facts_dict['selinux']
    assert 'policyvers' in selinux_facts_dict['selinux']
    assert 'config_mode' in selinux_facts_dict['selinux']
    assert 'mode' in selinux_facts_dict['selinux']
    assert 'type' in selinux_facts_dict['selinux']


# Generated at 2022-06-23 01:41:22.806126
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:41:27.363564
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert len(selinuxFactCollector._fact_ids) == 0
    assert selinuxFactCollector.has_fact('selinux')
    assert selinuxFactCollector.has_fact('selinux_python_present')

# Generated at 2022-06-23 01:41:31.374675
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collector = SelinuxFactCollector()
    assert len(test_collector) == len(SelinuxFactCollector._fact_ids)

# Generated at 2022-06-23 01:41:41.543980
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Test SelinuxFactCollector.collect()
    '''
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # Setup mock for selinux
    fake_selinux = basic.AnsibleModule(argument_spec={})
    fake_selinux.selinux_python_present = True
    fake_selinux.is_selinux_enabled = lambda: True
    fake_selinux.security_policyvers = lambda: '24'
    fake_selinux.selinux_getenforcemode = lambda: (0, 1)
    fake_selinux.security_getenforce = lambda: 0
    fake_selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    # Setup mock for BaseFact

# Generated at 2022-06-23 01:41:44.480143
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector(None,None)
    assert sfc.name == 'selinux'
    assert repr(sfc._fact_ids) == set().__repr__()

# Generated at 2022-06-23 01:41:47.961571
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.collect() is not None
    assert isinstance(selinux_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:42:00.136734
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_mock = mock.Mock()
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.selinux_getpolicytype.return_value = (0, 'targeted')
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.security_policyvers.return_value = 28
    with mock.patch('ansible.module_utils.facts.collector.SelinuxFactCollector.selinux', selinux_mock):
        selinux_fact_collector = SelinuxFactCollector()
        result = selinux_fact_collector.collect()
        assert result['selinux']

# Generated at 2022-06-23 01:42:02.970162
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import ansible.module_utils.facts.collectors.selinux as selinux
    # Check that the function returns a dict
    assert isinstance (selinux.collect(), dict)


# Generated at 2022-06-23 01:42:08.642872
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system.selinux import (
        SelinuxFactCollector
    )
    from ansible.module_utils.facts.system.selinux import _selinux_version
    selinux_facts = {
        'config_mode': 'permissive',
        'mode': 'permissive',
        'status': 'enabled',
        'type': 'targeted'
    }
    selinux_facts['policyvers'] = str(_selinux_version())
    selinux_python_present = True

    collector = SelinuxFactCollector()
    # Mock the get_file_content method to return a specific output and not
    # read data from the filesystem

# Generated at 2022-06-23 01:42:14.564462
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert 'config_mode' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']
    assert 'type' in facts_dict['selinux']
    assert 'policyvers' in facts_dict['selinux']

# Generated at 2022-06-23 01:42:16.543291
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:42:28.920654
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import os

    selinux_data = [
        {'config_mode': 'permissive', 'status': 'enabled', 'type': 'targeted', 'policyvers': '28', 'mode': 'permissive'},
        {'config_mode': 'enforcing', 'status': 'enabled', 'type': 'targeted', 'policyvers': '28', 'mode': 'enforcing'},
        {'status': 'disabled'},
        {'policyvers': '28', 'status': 'enabled', 'config_mode': 'targeted', 'type': 'unknown', 'mode': 'unknown'}
    ]

    selinux_facts = {
        'selinux': selinux_data[0],
        'selinux_python_present': True
    }

    def selinux_is_enabled(*args):
        return True

# Generated at 2022-06-23 01:42:32.778818
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set(['selinux_python_present'])

# Generated at 2022-06-23 01:42:38.461115
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    expected_fact_ids = set()
    assert fact_collector._fact_ids == expected_fact_ids



# Generated at 2022-06-23 01:42:39.838523
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:42:44.766154
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    with patch.object(SelinuxFactCollector, '_is_selinux_enabled'):
        instance = SelinuxFactCollector()
        instance._is_selinux_enabled.return_value = True
        result = instance.collect()
        assert 'selinux' in result

        instance = SelinuxFactCollector()
        instance._is_selinux_enabled.return_value = False
        result = instance.collect()
        assert 'selinux' in result


# Generated at 2022-06-23 01:42:47.893528
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:42:59.498544
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This should return the results for a system with SELinux enabled
    # or disabled, with or without the SELinux library
    selinux_facts = SelinuxFactCollector().collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts

    if selinux_facts.get('selinux_python_present'):
        assert 'status' in selinux_facts['selinux']
        assert selinux_facts['selinux']['status'] in ['enabled', 'disabled']

        if selinux_facts['selinux']['status'] == 'enabled':
            assert 'config_mode' in selinux_facts['selinux']
            assert 'mode' in selinux_facts['selinux']
            assert 'type' in selinux_

# Generated at 2022-06-23 01:43:01.764212
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  collector = SelinuxFactCollector()
  # tests whether type of object is correct
  assert type(collector) == SelinuxFactCollector

# Generated at 2022-06-23 01:43:04.861841
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()



# Generated at 2022-06-23 01:43:14.164618
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        selinux_facts = {
            'status': 'Missing selinux Python library',
            'selinux_python_present': False
        }
        return selinux_facts

    # Set a boolean for testing whether the Python library is present
    selinux_facts = {}
    selinux_facts['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        selinux_facts['status'] = 'disabled'
    else:
        selinux_facts['status'] = 'enabled'


# Generated at 2022-06-23 01:43:16.238508
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    obj = SelinuxFactCollector()
    facts_dict = obj.collect()

    assert 'selinux' in facts_dict


# Generated at 2022-06-23 01:43:17.096334
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:43:19.796594
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_object = SelinuxFactCollector()
    assert selinux_object.name == 'selinux'
    assert isinstance(selinux_object._fact_ids, set)



# Generated at 2022-06-23 01:43:24.944183
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert facts_dict == {
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }

# Generated at 2022-06-23 01:43:29.098490
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()
    assert selinux_facts['selinux']
    assert selinux_facts['selinux_python_present']

# Generated at 2022-06-23 01:43:40.698658
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    global HAVE_SELINUX
    global SELINUX_MODE_DICT

    # Set up for selinux library not present
    HAVE_SELINUX = False
    selinux_fact_collector = SelinuxFactCollector()

    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux']['status'] == 'Missing selinux Python library'
    assert selinux_facts['selinux_python_present'] == False

    # Set up for selinux library is present
    HAVE_SELINUX = True
    selinux_fact_collector = SelinuxFactCollector()

    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:43:47.983365
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for SelinuxFactCollector.collect
    """
    collector = SelinuxFactCollector()
    collected_facts = collector.collect()
    assert 'selinux' in collected_facts
    selinux_facts = collected_facts['selinux']
    assert 'status' in selinux_facts
    assert 'mode' in selinux_facts
    assert 'type' in selinux_facts
    assert 'config_mode' in selinux_facts
    assert 'policyvers' in selinux_facts
    assert 'selinux_python_present' in collected_facts

# Generated at 2022-06-23 01:43:53.221461
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""
    cmd = SelinuxFactCollector()
    result = cmd.collect()
    intf = result.get("interface_ipv4")
    myassert("selinux_python_present" in result)
    myassert("selinux" in result)
    # myassert("interface_ipv4" in result)

test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:44:04.050437
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    result = collector.collect()

    # Check that the result contains the status of the SELinux library
    assert 'selinux_python_present' in result
    selinux_status = result['selinux_python_present']

    if selinux_status:
        # Check that the result contains the module dictionary
        assert 'selinux' in result
        selinux_dict = result['selinux']

        # Check that the dictionary contains the right number of facts
        assert len(selinux_dict) == 4

        # Check that the dictionary contains the right facts
        assert 'status' in selinux_dict
        assert 'config_mode' in selinux_dict
        assert 'mode' in selinux_dict
        assert 'type' in selinux_dict

# Generated at 2022-06-23 01:44:06.508251
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x is not None

# Generated at 2022-06-23 01:44:12.721706
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()

    # Test without the selinux Python library present
    selinux_collector._have_selinux = False
    expected = {
        'selinux_python_present': False,
        'selinux': {
            'status': 'Missing selinux Python library'
        }
    }
    assert expected == selinux_collector.collect()

# Generated at 2022-06-23 01:44:14.597290
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector

# Generated at 2022-06-23 01:44:16.330004
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'

# Generated at 2022-06-23 01:44:22.393366
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of a trivial subclass of BaseFactCollector.
    base_fact_collector = SelinuxFactCollector()

    # Call collect() method and check the result.
    result = base_fact_collector.collect()
    assert result == {'selinux_python_present': True, 'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}}

# Generated at 2022-06-23 01:44:26.675386
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModuleFake()
    assert not HAS_SELINUX
    c = SelinuxFactCollector(module)
    assert c.name == 'selinux'
    assert not c._fact_ids
    return

# Generated at 2022-06-23 01:44:35.320898
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModule(argument_spec=dict())

    # should be able to instantiate the class
    fact_collector = SelinuxFactCollector(module)

    # name should be 'selinux'
    assert fact_collector.name == 'selinux'

    # the class should be a subclass of BaseFactCollector
    assert issubclass(SelinuxFactCollector, BaseFactCollector)

    # _fact_ids should be a set
    assert isinstance(fact_collector._fact_ids, set)

    # _fact_ids should be a empty
    assert len(fact_collector._fact_ids) == 0



# Generated at 2022-06-23 01:44:37.857693
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-23 01:44:40.544683
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    m = SelinuxFactCollector()
    results = m.collect()
    assert 'selinux' in results
    assert 'selinux_python_present' in results

# Generated at 2022-06-23 01:44:50.152670
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = 'selinux'
    expected_facts = {
        fact: {
            'config_mode': 'enforcing',
            'mode': 'enforcing',
            'policyvers': '28',
            'status': 'enabled',
            'type': 'targeted',
        },
        'selinux_python_present': True
    }
    # Mock the selinux module
    selinux_mock = mock.Mock(spec=selinux)
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = '28'
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.security_getenforce.return_value = 1
   

# Generated at 2022-06-23 01:44:53.293883
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collection_class = SelinuxFactCollector()
    assert collection_class.name == 'selinux'
    assert collection_class._fact_ids == set()


# Generated at 2022-06-23 01:44:55.871732
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collector = SelinuxFactCollector()
    res = test_collector.collect()
    assert 'selinux' in res

# Generated at 2022-06-23 01:44:58.170780
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_obj = SelinuxFactCollector()
    selinux_fact_collector_obj.collect()

# Generated at 2022-06-23 01:45:01.401567
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.collect() == {}

# Generated at 2022-06-23 01:45:03.982929
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_col = SelinuxFactCollector()
    selinux_col_name = selinux_col.name

    assert(selinux_col_name == 'selinux')

# Generated at 2022-06-23 01:45:13.680766
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Arrange
    import sys
    import os

    # set up constants
    test_collector = SelinuxFactCollector()
    test_string = ['enforcing', 'permissive', 'disabled']
    test_name = 'selinux'
    test_set = set()
    test_dict = {}

    # Act & Assert
    assert test_collector.name == 'selinux'

    # Assert
    try:
        if sys.version_info[0] >= 3:
            assert test_collector._fact_ids == test_set
        else:
            print("Test Skipped because this version of Python is not supported")
    except AttributeError:
        print("Test Skipped because this version of Python is not supported")



# Generated at 2022-06-23 01:45:25.575583
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create test class object
    test_obj = SelinuxFactCollector()

    # Create mock and stubs
    mock_selinux_lib = Mock()
    mock_selinux_lib.selinux_getenforcemode.return_value = (0, 0)
    mock_selinux_lib.security_policyvers.return_value = 3
    mock_selinux_lib.selinux_getpolicytype.return_value = (0, "targeted")
    mock_selinux_lib.security_getenforce.return_value = 1
    mock_selinux_lib.is_selinux_enabled.return_value = True

    sys.modules['selinux'] = mock_selinux_lib

    # Run the class method
    test_obj.collect()

    # Assert if

# Generated at 2022-06-23 01:45:33.708609
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Method collect of class SelinuxFactCollector is unit tested.
    This test requires that the selinux Python library is installed in order to
    verify the output of the collect method. If the selinux library is not installed,
    the test is skipped.
    """
    import sys
    if not HAVE_SELINUX:
        pytest.skip("selinux Python library is not available")

    fact_collector = SelinuxFactCollector()

    # Expected output when selinux is not enabled
    result = fact_collector.collect()
    expected_result = {}
    expected_result['selinux'] = {}
    expected_result['selinux']['status'] = 'disabled'
    expected_result['selinux_python_present'] = True
    assert result == expected_result

    # Expected output when

# Generated at 2022-06-23 01:45:36.863532
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    coll = SelinuxFactCollector()

    assert coll is not None
    assert coll.name == 'selinux'
    assert len(coll._fact_ids) == 0


# Generated at 2022-06-23 01:45:41.575438
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:45:48.929097
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import facts
    from ansible.module_utils.facts import collector

    # initialize the collector
    SelinuxFactCollector.init_fetch(False)

    # Get all the facts collected
    collected_facts = collector.collect(None, facts.Facts())
    # Assert against the test results.
    assert collected_facts['selinux'] is None
    assert collected_facts['selinux_python_present'] is False

# Generated at 2022-06-23 01:45:50.045015
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Unit test to verify selinux facts.

# Generated at 2022-06-23 01:45:51.739239
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact = SelinuxFactCollector()
    assert fact.name == 'selinux'
    assert fact._fact_ids == set()


# Generated at 2022-06-23 01:45:56.105955
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ''' Unit test stub for class SelinuxFactCollector '''
    ret = SelinuxFactCollector.collect()
    assert ('selinux' in ret)

# Generated at 2022-06-23 01:45:58.787663
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Unit test for constructor of class SelinuxFactCollector"""
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'


# Generated at 2022-06-23 01:46:00.632520
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinx = SelinuxFactCollector()
    selinx.collect()

# Generated at 2022-06-23 01:46:05.470457
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Create a instance of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Check instance attribute name
    assert selinux_fact_collector.name == 'selinux'

    # Check instance attribute _fact_ids
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:46:15.889799
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    import_mock = MagicMock()
    import_mock.selinux = Mock()
    # selinux module not present
    import_mock.selinux.is_selinux_enabled.side_effect = ImportError
    with patch('ansible.module_utils.compat.selinux', new=import_mock.selinux):
        selinux_fact_collector = SelinuxFactCollector()
        result = selinux_fact_collector.collect()
        assert result == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # selinux module present
    import_mock.selinux.is_selinux_enabled.side_effect = None
    import_mock.selinux.is_selinux_

# Generated at 2022-06-23 01:46:19.502748
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj.collect() == {'selinux': {'status': 'Missing selinux Python library', 'type': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:46:23.135177
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"
    assert obj._fact_ids == set(['selinux', 'selinux_python_present'])
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-23 01:46:26.029074
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    slx_fact = SelinuxFactCollector()

    assert slx_fact.name == 'selinux'
    assert slx_fact._fact_ids == set()

# Generated at 2022-06-23 01:46:35.351012
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector_instance = SelinuxFactCollector()
    test_facts_dict = selinux_collector_instance.collect()
    assert test_facts_dict.get('selinux_python_present')
    assert 'selinux' in test_facts_dict
    assert 'status' in test_facts_dict['selinux']
    assert 'mode' in test_facts_dict['selinux']
    assert 'type' in test_facts_dict['selinux']
    assert 'config_mode' in test_facts_dict['selinux']

# Generated at 2022-06-23 01:46:42.598936
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_dict = dict()
    selinux_facts = dict()
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = 'unknown'
    selinux_facts['config_mode'] = 'unknown'
    selinux_facts['mode'] = 'unknown'
    selinux_facts['type'] = 'unknown'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = True

    instance = SelinuxFactCollector()
    assert instance.collect() == facts_dict

# Generated at 2022-06-23 01:46:45.891054
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-23 01:46:47.218195
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect()

# Generated at 2022-06-23 01:46:58.034146
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test without the selinux library present
    c1 = SelinuxFactCollector()
    c1.collect()
    selinux_facts_dict = c1.collect()
    assert selinux_facts_dict['selinux_python_present'] == False

    if HAVE_SELINUX:
        # Test with the selinux library present
        c2 = SelinuxFactCollector()
        selinux_facts_dict = c2.collect()
        if selinux.is_selinux_enabled():
            assert selinux_facts_dict['selinux']['status'] == 'enabled'
        else:
            assert selinux_facts_dict['selinux']['status'] == 'disabled'
        assert selinux_facts_dict['selinux_python_present'] == True

# Generated at 2022-06-23 01:47:01.125437
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:47:02.104898
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:47:07.995952
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object for testing
    selinux_collector = SelinuxFactCollector()
    # Test when selinux is not installed
    module = None
    collected_facts = None
    selinux_collector.collect(module, collected_facts)
    # Create a temp module for testing when selinux is installed
    module = None
    collected_facts = None
    # Test when selinux is installed
    selinux_collector.collect(module, collected_facts)

# Generated at 2022-06-23 01:47:11.846708
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Collect facts
    c = SelinuxFactCollector()
    facts_dict = c.collect()

    # Test that selinux facts are collected
    assert 'selinux_python_present' in facts_dict
    assert 'selinux' in facts_dict

# Generated at 2022-06-23 01:47:12.901742
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:47:21.135479
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    m_selinux = MockSELinux()
    SelinuxFactCollector.collect(m_selinux)

    m_selinux.is_selinux_enabled.assert_called_once()
    m_selinux.security_policyvers.assert_called_once()
    m_selinux.selinux_getenforcemode.assert_called_once()
    m_selinux.security_getenforce.assert_called_once()
    m_selinux.selinux_getpolicytype.assert_called_once()


# Mock SELinux class

# Generated at 2022-06-23 01:47:29.733378
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create the facts collector
    selinux_fact_collector = SelinuxFactCollector()

    # Create the facts dictionary
    facts_dict = {}

    # Set up test values
    selinux_facts = {
      "config_mode": "unknown",
      "mode": "unknown",
      "status": "disabled",
      "policyvers": "unknown",
      "type": "unknown"
    }

    # Get the facts
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = True

    # Collect facts
    collected_facts = selinux_fact_collector.collect(collected_facts=facts_dict)

    # Check results
    assert collected_facts == facts_dict

# Generated at 2022-06-23 01:47:36.844656
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''
    Test that the constructor of the class SelinuxFactCollector
    is working as expected.
    '''
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Assert that the name of the object is 'selinux'
    assert selinux_fact_collector.name == 'selinux'

    # Assert that the name of the object is 'selinux'
    assert selinux_fact_collector.fact == 'selinux'


# Generated at 2022-06-23 01:47:38.493334
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-23 01:47:42.546826
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector class
    selinux_collector = SelinuxFactCollector()
    # Call method collect of the instance
    selinux_facts_dict = selinux_collector.collect()

# Generated at 2022-06-23 01:47:52.957854
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class MockSelinuxModule(object):
        def __init__(self):
            self.return_value = 0

        def is_selinux_enabled(self):
            return True

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 1

        def selinux_getpolicytype(self):
            return (0, 'unknown')

        def security_policyvers(self):
            return 3

    class MockMissingSelinuxModule(object):
        def __init__(self):
            self.return_value = 1

        def is_selinux_enabled(self):
            return False

    with_selinux_mock = MockSelinuxModule()
    without_selinux_mock = MockMissingSelinuxModule()


# Generated at 2022-06-23 01:47:58.420510
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    tester = SelinuxFactCollector()
    assert tester.name == 'selinux'

# Generated at 2022-06-23 01:47:59.386931
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:48:11.722500
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors

    selinux_collector = Collectors().fetch_collector('selinux')
    collected_facts = selinux_collector.collect()

    if not HAVE_SELINUX:
        # Check that selinux facts were added
        assert 'selinux' in collected_facts
        assert 'selinux_python_present' in collected_facts
        # Check that the status is 'Missing selinux Python library' since
        # the library is missing
        assert 'Missing selinux Python library' == collected_facts['selinux']['status']

        # Check that the selinux_python_present is a boolean
        assert isinstance(collected_facts['selinux_python_present'], bool)

# Generated at 2022-06-23 01:48:16.985043
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    collected_facts = {}
    facts = collector.collect(collected_facts=collected_facts)
    expected_facts = {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'status': 'disabled',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }
    assert facts['selinux'] == expected_facts['selinux']

# Generated at 2022-06-23 01:48:25.483114
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    class mock_module:
        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return '/bin/false'

    class mock_selinux:
        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return 23

        def security_getenforce(self):
            return 1

        def selinux_getpolicytype(self):
            return (0, 'mock_selinux_policytype')

        def selinux_getenforcemode(self):
            return (0, 0)

    old_selinux = sys.modules.get('selinux')
   

# Generated at 2022-06-23 01:48:28.212291
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method: SelinuxFactCollector.collect
    """
    sc = SelinuxFactCollector()
    facts_dict = sc.collect()
    assert facts_dict is not None

# Generated at 2022-06-23 01:48:41.956659
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Add the current module here since it will get removed by ansible-test
    import sys
    sys.modules['ansible.module_utils.selinux'] = selinux
    import ansible.module_utils.facts.collector.selinux

    selinux.security_getenforce = lambda: -1
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: '3.13.1'
    selinux.selinux_getpolicytype = lambda: (0, 'targeted')
    selinux.selinux_getenforcemode = lambda: (0, 1)

    selinux = ansible.module_utils.facts.collector.selinux.SelinuxFactCollector()

# Generated at 2022-06-23 01:48:45.206852
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = {
        "status": "enabled",
        "config_mode": "enforcing",
        "mode": "enforcing",
        "type": "targeted"
    }
    collector = SelinuxFactCollector()
    results = collector.collect()
    assert results.get('selinux') == selinux_dict

# Generated at 2022-06-23 01:48:46.731945
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  selinux_facts_collector = SelinuxFactCollector()
  assert selinux_facts_collector is not None

# Generated at 2022-06-23 01:48:49.315096
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts_collector = SelinuxFactCollector()
    assert selinux_facts_collector is not None
    assert selinux_facts_collector.name == 'selinux'

# Generated at 2022-06-23 01:48:51.349124
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:49:01.126959
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux library available
    if HAVE_SELINUX:
        selinux_fact_collector = SelinuxFactCollector()
        selinux_facts = selinux_fact_collector.collect()

        # Have a look if selinux facts available
        assert selinux_facts['selinux']
        assert selinux_facts['selinux_python_present']

    # Test with selinux library missing
    if not HAVE_SELINUX:
        selinux_fact_collector = SelinuxFactCollector()
        selinux_facts = selinux_fact_collector.collect()

        # Test if selinux python library is not present
        assert not selinux_facts['selinux_python_present']

# Generated at 2022-06-23 01:49:05.021752
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-23 01:49:11.988874
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    x = SelinuxFactCollector()

    assert isinstance(x, BaseFactCollector)
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:49:22.898737
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    m = 'collect'
    selinux_collector = SelinuxFactCollector()
    returned_facts = selinux_collector.collect()
    assert returned_facts is not None
    assert type(returned_facts['selinux_python_present']) == bool
    assert type(returned_facts['selinux']) == dict
    assert type(returned_facts['selinux']['mode']) == str or type(returned_facts['selinux']['mode']) == unicode
    assert type(returned_facts['selinux']['status']) == str or type(returned_facts['selinux']['status']) == unicode

# Generated at 2022-06-23 01:49:23.754061
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:49:27.802249
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts = SelinuxFactCollector(None, None, 'localhost', None, None).collect()
    assert 'selinux_python_present' in facts

# Generated at 2022-06-23 01:49:37.273647
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup
    module = DummyModule()
    collected_facts = {}

    # Mock attributes on the selinux module
    selinux.is_selinux_enabled = mock.MagicMock(return_value=True)
    selinux.security_policyvers = mock.MagicMock(return_value='28')
    selinux.selinux_getenforcemode = mock.MagicMock(return_value=(0, 1))
    selinux.security_getenforce = mock.MagicMock(return_value=1)
    selinux.selinux_getpolicytype = mock.MagicMock(return_value=(0, 'targeted'))

    # Test
    selinux_collector = SelinuxFactCollector(module, collected_facts)
    results = selinux_collector.collect()

    # Verify
   

# Generated at 2022-06-23 01:49:39.336864
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-23 01:49:41.763834
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    status_list = ['disabled', 'enabled']
    assert result['selinux']['status'] in status_list

# Generated at 2022-06-23 01:49:46.305055
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create instance of class SelinuxFactCollector
    collected_facts = {}
    collector = SelinuxFactCollector()

    # Run method collect of class SelinuxFactCollector
    returned_facts = collector.collect(collected_facts=collected_facts)

    # Check that returned_facts is not empty
    assert returned_facts

# Generated at 2022-06-23 01:49:48.678022
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:49:52.881176
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create object of SelinuxFactCollector
    obj = SelinuxFactCollector()
    # Assert name of object is selinux
    assert obj.name == 'selinux'
    # Assert that the instance of SelinuxFactCollector is a subclass of BaseFactCollector
    assert isinstance(obj, BaseFactCollector)

# Generated at 2022-06-23 01:49:54.476307
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()