

# Generated at 2022-06-23 01:40:00.127361
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Unit Tests should have the following method.
    # Method should return a dictionary object with keys equal
    # to the facts collected
    pass

# Generated at 2022-06-23 01:40:02.979437
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector
    assert collector.name == 'selinux'
    assert collector._fact_ids == set(['selinux_python_present'])

# Generated at 2022-06-23 01:40:05.012223
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    assert selinux_fact_collector_obj.name == 'selinux'

# Generated at 2022-06-23 01:40:08.458144
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert 'selinux' == sfc.name
    assert 'selinux' in sfc._fact_ids

# Generated at 2022-06-23 01:40:12.748385
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = SelinuxFactCollector()
    facts = fact.collect()
    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'type' in facts['selinux']

# Generated at 2022-06-23 01:40:17.454618
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:40:19.025196
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Validate the SelinuxFactCollector.collect() method"""

    assert True

# Generated at 2022-06-23 01:40:21.300379
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector(None)
    assert x.name == 'selinux'
    assert x.collect() == {}

# Generated at 2022-06-23 01:40:24.734944
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-23 01:40:27.344832
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact.name == "selinux"
    assert selinux_fact.collect() == {}

# Generated at 2022-06-23 01:40:29.807589
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj.collect()

# Generated at 2022-06-23 01:40:33.539061
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = type('module', (object,), {})
    mock_module.params = {}
    mock_module.fail_json = lambda *args, **kwargs: None

    mock_collector = SelinuxFactCollector()
    assert mock_collector.collect(module=mock_module)


# Generated at 2022-06-23 01:40:34.392037
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:40:38.363773
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxvar = SelinuxFactCollector()
    assert selinuxvar
    assert selinuxvar.name == 'selinux'
    assert selinuxvar.collect() == {'selinux_python_present': True, 'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'type': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown'}}

# Generated at 2022-06-23 01:40:46.681481
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_dict = {}

    def mock_is_selinux_enabled():
        return True

    def mock_security_policyvers():
        return '1'

    def mock_getenforce():
        return 1

    def mock_getpolicytype():
        return (0, 'targeted')

    def mock_getenforcemode():
        return (0, '0')

    patch_is_selinux_enabled = patch.object(selinux, 'is_selinux_enabled', mock_is_selinux_enabled)
    patch_security_policyvers = patch.object(selinux, 'security_policyvers', mock_security_policyvers)
    patch_getenforce = patch.object(selinux, 'security_getenforce', mock_getenforce)
    patch_getpolicytype = patch.object

# Generated at 2022-06-23 01:40:51.557932
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxCollector = SelinuxFactCollector()
    assert selinuxCollector
    assert hasattr(selinuxCollector, 'name')
    assert selinuxCollector.name == 'selinux'
    assert hasattr(selinuxCollector, '_fact_ids')
    assert selinuxCollector._fact_ids == set()


# Generated at 2022-06-23 01:41:05.199769
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Dummy class for unit testing
    class DummyCollector():
        def __init__(self, module=None, collected_facts=None, name='test'):
            self.name = name
            self.module = module
            self.collected_facts = collected_facts

    # Dummy Module for unit testing
    class DummyModule():
        def __init__(self, params={}):
            self.params = params

        def fail_json(self, msg=None, **kwargs):
            self._failed = True
            self.exit_args = kwargs
            self.exit_args['failed'] = True
            if 'msg' in kwargs:
                self.exit_msg = kwargs['msg']
            else:
                self.exit_msg = msg
            raise Exception(self.exit_msg)



# Generated at 2022-06-23 01:41:10.897998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert not selinux._fact_ids

# Generated at 2022-06-23 01:41:15.852495
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.collectors['selinux'] = SelinuxFactCollector()
    res = collector.collector.collect(None)
    assert res.get('selinux')
    assert res.get('selinux_python_present')

# Generated at 2022-06-23 01:41:26.989943
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    fact_collector = collector.get_collector("SelinuxFactCollector")
    fact_collector.collect()
    result = basic.AnsibleModule(argument_spec={}).run_command("python -c 'import selinux'")
    try:
        if result[1].startswith("Traceback") and HAVE_SELINUX:
            raise Exception("Error: unable to load python module selinux")
        elif not result[1].startswith("Traceback") and not HAVE_SELINUX:
            raise Exception("Error: python module selinux should not be available")
    except AttributeError:
        if HAVE_SELINUX:
            raise Exception("Error: unable to load python module selinux")

# Generated at 2022-06-23 01:41:35.775760
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    global HAVE_SELINUX

    # Setup test case
    HAVE_SELINUX = True

    selinux_collector = SelinuxFactCollector()

    # Call the method under test
    result = selinux_collector.collect()

    # Verify results
    assert result['selinux_python_present'] == True

    # Setup test case
    HAVE_SELINUX = False

    selinux_collector = SelinuxFactCollector()

    # Call the method under test
    result = selinux_collector.collect()

    # Verify results
    assert result['selinux_python_present'] == False

# Generated at 2022-06-23 01:41:40.709661
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    # Test selinux_python_present present
    sfc = SelinuxFactCollector()
    sfc.collect()
    assert sfc.name in sfc.collect()


# Generated at 2022-06-23 01:41:50.179487
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    selinux_facts = {
            'status': 'enabled',
            'config_mode': 'disabled',
            'type': 'targeted',
            'mode': 'enforcing',
            'policyvers': '28'
    }

    # pretend selinux library is installed
    HAVE_SELINUX = True
    selinux.is_selinux_enabled = lambda : True

    # pretend selinux policy version is 28
    selinux.security_policyvers = lambda : 28

    # pretend config mode is disabled
    selinux.selinux_getenforcemode = lambda : (0, 1)

    # pretend enforcing mode is 1
    selinux.security_getenforce = lambda : 1

    # pretend policy type is 'targeted'
    selinux.selin

# Generated at 2022-06-23 01:42:00.623195
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Patch module_utils.compat.SELinux for testing
    SELinux = selinux
    selinux = MockSELinux()
    # Collect selinux facts
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect(module=None, collected_facts=None)
    assert collected_facts['selinux_python_present']
    assert collected_facts['selinux']['status'] == 'enabled'
    assert collected_facts['selinux']['policyvers'] == 'unknown'
    assert collected_facts['selinux']['config_mode'] == 'enforcing'
    assert collected_facts['selinux']['mode'] == 'enforcing'

# Generated at 2022-06-23 01:42:12.440423
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a class object
    selinux_fact_collector = SelinuxFactCollector()
    result_dict = selinux_fact_collector.collect()
    assert result_dict['selinux_python_present'] == True or False
    assert result_dict['selinux']['status'] == 'missing Python library' or 'enabled' or 'disabled'
    assert result_dict['selinux']['config_mode'] == 'unknown' or 'permissive' or 'enforcing'
    assert result_dict['selinux']['mode'] == 'unknown' or 'permissive' or 'enforcing'
    assert result_dict['selinux']['type'] == 'unknown' or 'targeted'
    assert result_dict['selinux']['policyvers'] == 'unknown' or 'integer'

# Generated at 2022-06-23 01:42:13.831986
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = SelinuxFactCollector()
    result = fact.collect()
    assert result

# Generated at 2022-06-23 01:42:18.426238
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert isinstance(selinux_facts, dict)
    assert selinux_facts['selinux_python_present'] is True
    assert isinstance(selinux_facts['selinux'], dict)

# Generated at 2022-06-23 01:42:19.463552
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:42:22.623366
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert len(x._fact_ids) == 0
    assert isinstance(x, BaseFactCollector)

# Generated at 2022-06-23 01:42:25.854158
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test that the constructor sets the correct name
    assert SelinuxFactCollector().name == 'selinux'

    # Test that the constructor sets the correct fact_ids
    assert SelinuxFactCollector().fact_ids == set()

# Generated at 2022-06-23 01:42:27.953410
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    m = SelinuxFactCollector()
    assert m.name == 'selinux'
    assert m._fact_ids == set()

# Generated at 2022-06-23 01:42:39.779996
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False
    facts_dict = {}
    for k in ('selinux', 'selinux_python_present'):
        del(facts_dict[k])

    if HAVE_SELINUX:
        selinux.is_selinux_enabled = lambda: True
        selinux.security_getenforce = lambda: 0
        selinux.selinux_getpolicytype = lambda: (0, 'targeted')
        selinux.selinux_getenforcemode = lambda: (0, 0)
        selinux.security_policyvers = lambda: 21

    fact_collector = SelinuxFactCollector()
    fact_collector.collect(collected_facts=facts_dict)

# Generated at 2022-06-23 01:42:42.347905
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    facts = selinux_collector.collect()
    assert not facts['selinux']
    assert facts['selinux_python_present'] is False

# Generated at 2022-06-23 01:42:52.200191
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    import mock
    import os
    import pytest
    import selinux

    module_mock = mock.MagicMock()
    module_mock.params = {'gather_subset': ['!all', '!min']}
    selinux.is_selinux_enabled.return_value = False
    selinux.security_getenforce.return_value = -1
    selinux_facts = SelinuxFactCollector().collect(module=module_mock)
    if os.path.exists('/usr/bin/selinuxenabled'):
        assert selinux_facts['selinux']['status'] == 'disabled'

# Generated at 2022-06-23 01:43:03.253823
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test case for method collect of class SelinuxFactCollector. A test case is created with the
    test fixture collect of class SelinuxFactCollector. The method collect of class SelinuxFactCollector is
    called with the parameter module to be None and the parameter collected_facts to be None.
    The method returns a dictionary facts_dict containing selinux and selinux_python_present as keys.
    """

    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' in selinux_fact_collector.collect()
    assert 'selinux_python_present' in selinux_fact_collector.collect()

# Generated at 2022-06-23 01:43:04.620770
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:43:08.275868
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:43:18.140598
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def selinux_is_selinux_enabled(self):
        return True
    selinux.is_selinux_enabled = selinux_is_selinux_enabled

    def selinux_security_policyvers(self):
        return 1
    selinux.security_policyvers = selinux_security_policyvers

    def selinux_security_getenforce(self):
        return -1
    selinux.security_getenforce = selinux_security_getenforce

    def selinux_security_check_passwd_access(self, context1, context2=None):
        return 1
    selinux.security_check_passwd_access = selinux_security_check_passwd_access

    def selinux_getenforcemode(self):
        return (0,1)
    selinux.selinux_get

# Generated at 2022-06-23 01:43:20.555113
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-23 01:43:30.415721
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Patch out selinux
    real_selinux = __import__('selinux')
    fake_selinux = type(real_selinux)()
    fake_selinux.is_selinux_enabled = lambda : True
    fake_selinux.selinux_getenforcemode = lambda : (0, 1)
    fake_selinux.selinux_getpolicytype = lambda : (0, 'targeted')
    fake_selinux.security_getenforce = lambda : 0
    fake_selinux.security_policyvers = lambda : '24'
    patched_modules = {
        real_selinux.__name__: fake_selinux,
    }

# Generated at 2022-06-23 01:43:39.629308
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'network']
            self.params['filter'] = 'ansible_distribution_*'

    class MockFacts:
        def __init__(self):
            self.ansible_facts = {}

    selinux = SelinuxFactCollector(module=MockModule(), facts=MockFacts())
    print('Testing constructor of class SelinuxFactCollector with MockModule and MockFacts')
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-23 01:43:41.502815
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:43:43.482751
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'


# Generated at 2022-06-23 01:43:46.626578
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts is not None

# Generated at 2022-06-23 01:43:49.491502
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test normal functioning of constructor
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()
    assert x._collect_subset == set()

# Generated at 2022-06-23 01:43:51.518171
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact = SelinuxFactCollector()
    assert fact.name == 'selinux'
    assert fact._fact_ids == set()


# Generated at 2022-06-23 01:43:52.710571
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:43:54.755795
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-23 01:43:58.524696
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert hasattr(SelinuxFactCollector, '_fact_ids')

# Generated at 2022-06-23 01:44:02.440125
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    assert selinux_fact_collector_obj.name == 'selinux'
    assert selinux_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:44:11.558919
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None

    # Test case when selinux is disabled
    with patch('selinux.is_selinux_enabled', return_value=False):
        collector = SelinuxFactCollector()
        facts_dict = collector.collect(module, collected_facts)
        assert facts_dict['selinux']['status'] == 'disabled'
        assert facts_dict['selinux_python_present'] is True

    # Test case when selinux is enabled

# Generated at 2022-06-23 01:44:15.295999
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import os
    import pytest

    if 'SELINUX_INIT' not in os.environ:
        pytest.skip("SELinux not installed")

    assert SelinuxFactCollector.collect()['selinux']['status'] == "enabled"

# Generated at 2022-06-23 01:44:18.341068
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts_collector = SelinuxFactCollector()
    assert selinux_facts_collector.name == 'selinux'

# Generated at 2022-06-23 01:44:21.081375
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert isinstance(selinux_collector, SelinuxFactCollector)
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:44:32.816883
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()
    assert isinstance(facts_dict, dict)

    if HAVE_SELINUX:
        selinux_facts = facts_dict['selinux']

        assert isinstance(selinux_facts, dict)
        assert isinstance(selinux_facts['status'], basestring)
        assert selinux_facts['status'] == 'disabled' or selinux_facts['status'] == 'enabled'

        assert isinstance(selinux_facts['policyvers'], basestring)
        assert selinux_facts['policyvers'] != 'unknown'

        assert isinstance(selinux_facts['config_mode'], basestring)
        assert selinux_facts['config_mode'] == 'unknown' or selinux_facts

# Generated at 2022-06-23 01:44:34.492575
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:44:36.339382
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_class = SelinuxFactCollector()
    assert (selinux_class.name == 'selinux')

# Generated at 2022-06-23 01:44:40.139746
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux']
    assert selinux_facts['selinux_python_present']


# Generated at 2022-06-23 01:44:40.789497
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:44:48.012739
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()
    facts_dict = {}
    selinux_facts = {}

    selinux_facts['status'] = 'disabled'
    selinux_facts['policyvers'] = 'unknown'
    selinux_facts['config_mode'] = 'unknown'
    selinux_facts['mode'] = 'unknown'
    selinux_facts['type'] = 'unknown'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = True

    assert selinux.collect() == facts_dict

# Generated at 2022-06-23 01:44:50.595730
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts import get_collector_facts
    facts = get_collector_facts('SelinuxFactCollector')
    assert len(facts) == 2

# Generated at 2022-06-23 01:45:02.125172
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    #
    # Configure test environment
    #
    # Mock module
    class MockModule:
        pass
    module = MockModule()
    module.params = {}
    module.params['gather_subset'] = ['all']

    # Collected facts prior to execution of SelinuxFactCollector
    collected_facts = dict()

    #
    # Instantiate SelinuxFactCollector object
    #
    fact_collector = SelinuxFactCollector(module=module,
                                          collected_facts=collected_facts)

    #
    # Execute method collect
    #
    facts_dict = fact_collector.collect()

    #
    # Assert results
    #

    # If selinux library is missing, only set the status and selinux_python_present

# Generated at 2022-06-23 01:45:03.526056
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    selinux_fact.collect()

# Generated at 2022-06-23 01:45:13.642033
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils import basic

    # Test when selinux library is not present
    module = TestModule()
    fc = SelinuxFactCollector(module, TestModule())
    result = fc.collect()
    assert result['selinux']['status'] == 'Missing selinux Python library'
    assert result['selinux_python_present'] == False

    # Test when selinux library is present
    # Mock the import of selinux library
    pytest.importorskip("selinux")
    module = TestModule()
    fc = SelinuxFactCollector(module, TestModule())
    result = fc.collect()
    assert result['selinux']['status'] == 'disabled'

# Generated at 2022-06-23 01:45:17.573759
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc
    assert isinstance(sfc, BaseFactCollector)
    assert hasattr(sfc, 'name')
    assert hasattr(sfc, '_fact_ids')


# Generated at 2022-06-23 01:45:19.935888
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert (selinux_fact_collector.name == 'selinux')

# Generated at 2022-06-23 01:45:30.211320
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Arrange

    # Monkey patch the selinux module
    selinux.is_selinux_enabled = lambda : True
    selinux.security_policyvers = lambda : '1.0'
    selinux.selinux_getenforcemode = lambda : (0, 1)
    selinux.security_getenforce = lambda : 0
    selinux.selinux_getpolicytype = lambda : (0, 'MLS')
    selinux_module = SelinuxFactCollector()

    # Act
    facts_dict = selinux_module.collect(None, None)

    # Assert
    assert facts_dict['selinux']['status'] == 'enabled'
    assert facts_dict['selinux']['policyvers'] == '1.0'

# Generated at 2022-06-23 01:45:32.338066
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'
    assert fc._fact_ids == set()


# Generated at 2022-06-23 01:45:34.811691
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collected_facts = {}
    fake_module = {}
    SelinuxFactCollector().collect(fake_module, collected_facts)
    assert 'selinux' in collected_facts

# Generated at 2022-06-23 01:45:46.619606
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    have_selinux = HAVE_SELINUX
    HAVE_SELINUX = True
    selinux.security_getenforce = lambda: 0
    selinux.selinux_getpolicytype = lambda: (0, 'targeted')
    selinux.selinux_getenforcemode = lambda: (0, 0)
    selinux.security_policyvers = lambda: 28

    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect(None)
    assert facts['selinux']['status'] == 'enabled'
    assert facts['selinux']['policyvers'] == 28
    assert facts['selinux']['config_mode'] == 'permissive'
    assert facts['selinux']['mode'] == 'permissive'

# Generated at 2022-06-23 01:45:56.524453
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collectors.distribution import SelinuxFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import utils
    myFactCollector = SelinuxFactCollector()

    # check if collect method exists
    assert hasattr(myFactCollector, 'collect')
    # check if collect method is callable
    assert callable(myFactCollector.collect)

    # test collect with status = disabled
    def selinux_is_selinux_enabled_retval(*args):
        return False

    selinux.is_selinux_enabled = selinux_is_selinux_enabled_retval
    selinux_facts = myFactCollector.collect()


# Generated at 2022-06-23 01:46:01.792191
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.mandatory_facts == set()
    assert selinux_facts.collected_facts == set()
    assert selinux_facts.optional_facts == set()
    assert selinux_facts.depends_on_facts == set()
    assert selinux_facts._cache_expiration == 3600


# Generated at 2022-06-23 01:46:04.911677
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:46:06.441536
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:46:08.366667
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:46:09.858348
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector()
    selinux_fc.collect()

# Generated at 2022-06-23 01:46:13.234365
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector.collect() == {'selinux_python_present': True, 'selinux': {}}

# Generated at 2022-06-23 01:46:15.791822
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    current_platform = 'Linux'
    check_platform = True
    test_obj = SelinuxFactCollector()
    test_obj.collect()

# Generated at 2022-06-23 01:46:21.332609
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:46:24.966525
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux_python_present'] == True
    assert facts_dict.get('selinux') is not None

# Generated at 2022-06-23 01:46:27.548857
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test class SelinuxFactCollector constructor"""
    instance = SelinuxFactCollector()
    assert instance.name == 'selinux'
    assert isinstance(instance._fact_ids, set)

# Generated at 2022-06-23 01:46:28.902180
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-23 01:46:32.898678
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = {'selinux': {'status': 'disabled', 'config_mode': 'disabled', 'mode': 'disabled', 'type': 'unknown'}}

    assert (SelinuxFactCollector().collect()) == facts_dict

# Generated at 2022-06-23 01:46:36.874235
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert selinuxFactCollector._fact_ids is not None
    assert type(selinuxFactCollector._fact_ids) == set


# Generated at 2022-06-23 01:46:44.381007
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test to check return value and type of return value
    of method collect of class SelinuxFactCollector
    """
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert isinstance(selinux_facts, dict)
    assert "selinux" in selinux_facts
    assert "selinux_python_present" in selinux_facts
    assert isinstance(selinux_facts.get("selinux"), dict)
    assert isinstance(selinux_facts.get("selinux_python_present"), bool)

# Generated at 2022-06-23 01:46:46.605033
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# Generated at 2022-06-23 01:46:54.055128
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    assert SelinuxFactCollector.name == "selinux"
    assert SelinuxFactCollector._fact_ids == {"selinux", "selinux_python_present"}
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == {"selinux", "selinux_python_present"}


# Generated at 2022-06-23 01:46:56.456515
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'


# Generated at 2022-06-23 01:47:02.781364
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    collector = SelinuxFactCollector({}, None)
    # Run the method in case the local system has selinux enabled
    # which will return a dictionary
    results = collector.collect()

    assert 'status' in results.get('selinux')
    assert 'config_mode' in results.get('selinux')
    assert 'mode' in results.get('selinux')
    assert 'policyvers' in results.get('selinux')
    assert 'type' in results.get('selinux')
    assert 'selinux_python_present' in results

# Generated at 2022-06-23 01:47:05.720000
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:47:09.989900
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-23 01:47:16.571301
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test case for method collect of class SelinuxFactCollector"""

    # Test with a machine that doesn't have the selinux Python library
    module = None
    collected_facts = {}
    selinux_collector = SelinuxFactCollector()
    expected_facts_dict = {'selinux': {'status': 'Missing selinux Python library'},
                           'selinux_python_present': False}
    facts_dict = selinux_collector.collect(module, collected_facts)
    assert facts_dict == expected_facts_dict
    assert 'selinux' in selinux_collector._fact_ids

    # Test with a machine that has the selinux Python library
    module = None
    collected_facts = {}
    selinux_collector = SelinuxFactCollector()
    selinux_collector.HA

# Generated at 2022-06-23 01:47:19.733349
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()
    assert not collector.enabled
    assert collector.depends

# Generated at 2022-06-23 01:47:29.219700
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import cache

    collector.FACT_CACHE = cache.FactCache()

    facts_dict = {}
    selinux_facts = {}

    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
        return facts_dict

    facts_dict['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        selinux_facts['status'] = 'disabled'
    else:
        selinux_facts['status'] = 'enabled'


# Generated at 2022-06-23 01:47:40.010604
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''SelinuxFactCollector_collect unit test'''

    if HAVE_SELINUX:
        # Create a class instance and test the collect method
        fact_collector = SelinuxFactCollector()
        ret = fact_collector.collect(module=None, collected_facts=None)

        # We don't capture any variables so we expect a return code of an empty dict
        assert(ret == {})
    else:
        # Create a class instance and test the collect method
        fact_collector = SelinuxFactCollector()
        ret = fact_collector.collect(module=None, collected_facts=None)

        # The selinux Python library is missing so we expect a return code of an empty dict

# Generated at 2022-06-23 01:47:46.576995
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    data = SelinuxFactCollector.collect()
    assert isinstance(data, dict)
    assert 'selinux' in data
    assert isinstance(data['selinux'], dict)
    assert set(['selinux_python_present']).issubset(set(data.keys()))

# Generated at 2022-06-23 01:47:58.807792
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = type('mock_module', (), {})()
    mock_collected_facts = {}

    # Initialize the object
    collectorObj = SelinuxFactCollector()

    # Get the facts and assert the result is dictionay with key
    # selinux and selinux_python_present
    result = collectorObj.collect(mock_module, mock_collected_facts)
    assert isinstance(result, dict)
    assert 'selinux' in result
    assert 'selinux_python_present' in result

    # Get the facts with mising selinux Python library and assert
    # the result is dictionary with key selinux and selinux_python_present
    with_selinux_false = SelinuxFactCollector()
    with_selinux_false.HAVE_SELINUX = False
    result

# Generated at 2022-06-23 01:48:11.067841
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This function is used to test the collect function of class SelinuxFactCollector.
    The function will first set the selinux library to be missing and then test that the
    selinux_python_present variable is set to False and the status variable is set to
    'Missing selinux Python library'.  Then it will set the selinux library to be present
    and then test that the selinux_python_present variable is set to True and the status
    variable is set to 'enabled'
    """

    global HAVE_SELINUX

    collected_facts = dict()
    factcollector = SelinuxFactCollector()

    # First test when selinux library is missing, status and selinux_python_present should
    # be set due to fallback to set these two variables if selinux library is missing
    if HAVE_SELINUX:
        HAVE

# Generated at 2022-06-23 01:48:15.766879
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    # Test if selinux_python_present is set correctly when the selinux python library is installed
    assert selinux_fact.collect()['selinux_python_present'] == HAVE_SELINUX
    # Test if selinux is set correctly when the selinux python library is installed
    if HAVE_SELINUX:
        assert selinux_fact.collect()['selinux']

# Generated at 2022-06-23 01:48:21.021658
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class Args(object):
        pass

    class Module(object):
        def __init__(self):
            self.args = Args()
            self.params = {}

    # If selinux library is not present, just set status and selinux_python_present
    selinux_facts_dict = {'status': 'Missing selinux Python library', 'selinux_python_present': False}
    selinux_fc = SelinuxFactCollector()
    facts_dict = selinux_fc.collect(module=Module())
    assert facts_dict['selinux'] == selinux_facts_dict

# Generated at 2022-06-23 01:48:25.388814
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert set(selinux_collector._fact_ids) == set()

# Generated at 2022-06-23 01:48:27.344474
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:48:41.923530
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class MockSel(object):
        def __init__(self):
            self.rc = 0

        def is_selinux_enabled(self):
            return True

        def security_getenforce(self):
            return 1

        def security_policyvers(self):
            return 2

        def selinux_getenforcemode(self):
            self.rc += 1
            return (self.rc % 2, self.rc % 3)

        def selinux_getpolicytype(self):
            return (self.rc % 2, 'targeted')

    module = object()
    collected_facts = object()

    selinux_mock = MockSel()
    facts_dict = SelinuxFactCollector(module=module, collected_facts=collected_facts).collect(selinux=selinux_mock)

    assert facts

# Generated at 2022-06-23 01:48:44.425723
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert type(selinux) == SelinuxFactCollector
    assert selinux.name == 'selinux'
    assert len(selinux._fact_ids) == 0

# Generated at 2022-06-23 01:48:46.179225
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector

# Generated at 2022-06-23 01:48:56.946590
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import os
    import tempfile

    my_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(my_path, "..", "..", "library"))

    from module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.sestatus import SelinuxFactCollector

    temp_dir = tempfile.mkdtemp()
    test_file = os.path.join(temp_dir, "test_file")

    f = open(test_file, 'w+')
    f.close()

    sfc = SelinuxFactCollector()
    bfc = BaseFactCollector()


# Generated at 2022-06-23 01:48:59.250444
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'
    assert len(sf._fact_ids) == 0
    assert isinstance(sf._fact_ids, set)

# Generated at 2022-06-23 01:49:05.633611
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
# Test if selinux Python library is not present

# Generated at 2022-06-23 01:49:11.100748
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    se = SelinuxFactCollector()
    assert se.name == 'selinux'
    assert len(se._fact_ids) == 0

# Generated at 2022-06-23 01:49:13.826718
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Check object creation for class SelinuxFactCollector"""

    clscollector = SelinuxFactCollector()
    assert clscollector.name == 'selinux'

# Generated at 2022-06-23 01:49:18.926855
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the method 'collect' of class SelinuxFactCollector
    """
    p = SelinuxFactCollector()
    assert p.collect() == {'selinux': {'type': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'status': 'disabled'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:49:25.803349
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect() == {}

# Generated at 2022-06-23 01:49:35.908236
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Mock selinux library since the library
    # is not available in this environment
    class MockSelinux(object):
        def is_selinux_enabled(self):
            return True
        def getenforcemode(self):
            return 0, 1
        def security_getenforce(self):
            return 0
        def selinux_getpolicytype(self):
            return 1, "targeted"
        def security_policyvers(self):
            return 28
    _selinux = MockSelinux()
    try:
        _SelinuxFactCollector = SelinuxFactCollector()
        _SelinuxFactCollector.get_module = lambda: None
        _SelinuxFactCollector.collect()
    except ImportError:
        pass

# Generated at 2022-06-23 01:49:37.215971
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:49:40.543359
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert isinstance(x._fact_ids, set)
    assert x._fact_ids == set()



# Generated at 2022-06-23 01:49:46.689590
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def mock_is_selinux_enabled():
        return True

    def mock_security_policyvers():
        return 1

    def mock_selinux_getenforcemode():
        return True, 1

    def mock_security_getenforce():
        return 1

    def mock_selinux_getpolicytype():
        return True, 'targeted'

    selinux_collector_class = SelinuxFactCollector()
    selinux_collector_class.collect()

# Generated at 2022-06-23 01:49:54.365145
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import GatheringPolicy

    module = None
    collected_facts = {}
    fc = SelinuxFactCollector(module=module, collected_facts=collected_facts)

    facts = fc.collect(module=module, gathered_facts=GatheringPolicy())
    assert isinstance(facts['ansible_selinux'], dict)
    assert isinstance(facts['ansible_selinux']['config_mode'], str)
    assert isinstance(facts['ansible_selinux']['mode'], str)
    assert isinstance(facts['ansible_selinux']['type'], str)

# Generated at 2022-06-23 01:50:02.477556
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import tempfile
    import os

    selinux_file_body = 'SELINUX=disabled'
    facts_dict = {'ansible_distribution': 'CentOS',
                  'ansible_distribution_release': '5.5',
                  'ansible_distribution_version': '5.5',
                  'ansible_os_family': 'RedHat',
                  'ansible_pkg_mgr': 'yum',
                  'ansible_system': 'Linux',
                  'ansible_system_vendor': 'in-target',
                  'ansible_userspace_architecture': 'x86_64'}
    module = None
    collected_facts = facts_dict

    # Save a copy of sys.modules and temporarily remove selinux.  This
    # allows us to test the case where the se