

# Generated at 2022-06-23 01:39:57.769007
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'

# Generated at 2022-06-23 01:40:02.619752
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    fqc = FactCollector()
    fqc._collectors = dict([
        ('selinux', Collector(SelinuxFactCollector()))
    ])

    fqc.collect()

# Generated at 2022-06-23 01:40:10.489506
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-23 01:40:14.000735
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    # These assertions will fail if any of the required variables
    # in the SelinuxFactCollector class are changed.
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()



# Generated at 2022-06-23 01:40:15.850856
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:40:24.129249
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    fake_module = object()  # object that supports __getattr__
    fake_collected_facts = object()  # object that supports __getattr__

    collector = SelinuxFactCollector()
    facts_dict = collector.collect(fake_module, fake_collected_facts)

    # Since the selinux library is not guaranteed to be present, check only
    # the selinux_python_present fact
    expected_dict = {
        'selinux_python_present': True
    }

    assert facts_dict == expected_dict

# Generated at 2022-06-23 01:40:29.322957
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    collected_facts = dict()

    selinux_fact.collect(module=None, collected_facts=collected_facts)
    assert collected_facts == {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-23 01:40:37.655363
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    import os

    # Create a fact collector object and run the collect method
    selinux = SelinuxFactCollector(gather_subset, SystemFactCollector, os.environ)
    result = selinux.collect()

    # Assert that the result contains the expected key
    assert 'selinux' in result

    # Assert that the result contains the expected keys in the nested selinux dictionary
    assert 'status' in result['selinux']
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']

# Generated at 2022-06-23 01:40:40.900404
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()
    assert collector.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:40:50.075583
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import collector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.selinux import SelinuxFactCollector

    class Object(object):
        pass

    module = Object()
    module.params = {}

    collected_facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'RedHat',
        'ansible_distribution_version': '6'
    }

    selinux_fact_collector = SelinuxFactCollector()

    # Test selinux facts when the Python library is not present
    collector.module_utils.compat.selinux = None
    collector.module_utils.compat.HAVE_SELINUX = False


# Generated at 2022-06-23 01:40:54.404926
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect()"""
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)
    assert 'selinux' in selinux_facts

# Generated at 2022-06-23 01:41:04.476931
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    GATHERER = SelinuxFactCollector()
    my_collected_facts = {
        'selinux': {
            'status': 'enabled',
            'mode': 'enforcing',
            'policyvers': '28',
            'type': 'targeted',
            'config_mode': 'permissive'
        },
        'selinux_python_present': True
    }
    my_module = None
    actual = GATHERER.collect(my_module, collected_facts=my_collected_facts)
    assert actual == my_collected_facts


# Generated at 2022-06-23 01:41:06.640713
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    coll = SelinuxFactCollector()
    collected_facts = dict()
    coll.collect(collected_facts=collected_facts)
    assert isinstance(collected_facts, dict)


# Generated at 2022-06-23 01:41:18.255139
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    FactCollector: Selinux
    """
    collector = SelinuxFactCollector(None, None)
    os_facts = {'selinux': {'config_mode': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown', 'status': 'enabled', 'type': 'unknown'}, 'selinux_python_present': True}
    collected_facts = collector.collect()
    assert isinstance(collected_facts, dict)
    assert collected_facts.keys() == ['selinux', 'selinux_python_present']
    assert collected_facts['selinux'] == os_facts['selinux']

# Generated at 2022-06-23 01:41:22.330104
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''
    United test for constructor of class SelinuxFactCollector.
    There is no assert statement since if the constructor for the class
    is called and does not throw an exception, then the test passes.
    '''
    SelinuxFactCollector()

# Generated at 2022-06-23 01:41:23.203837
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert True

# Generated at 2022-06-23 01:41:26.652733
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:41:29.921592
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    result = SelinuxFactCollector.collect()

    assert result['selinux']['status'] == 'disabled'
    assert result['selinux_python_present'] == True

# Generated at 2022-06-23 01:41:31.297734
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"

# Generated at 2022-06-23 01:41:34.921369
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
    assert selinux_fact_collector.priority == 80


# Generated at 2022-06-23 01:41:43.881664
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    resultdict = {}
    selinux_facts = {}
    resultdict['selinux'] = selinux_facts
    resultdict['selinux_python_present'] = True

    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = 28
    selinux_facts['config_mode'] = 'enforcing'
    selinux_facts['mode'] = 'enforcing'
    selinux_facts['type'] = 'targeted'


    selinux_fc = SelinuxFactCollector()
    result = selinux_fc.collect()

    assert resultdict == result

# Generated at 2022-06-23 01:41:46.686262
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert 'selinux' in selinux_fact_collector._fact_ids

# Generated at 2022-06-23 01:41:50.015302
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:41:56.531692
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()

    assert facts_dict is not None
    assert 'selinux_python_present' in facts_dict
    assert 'selinux' in facts_dict
    assert facts_dict['selinux'] is not None
    assert facts_dict['selinux']['status'] == 'disabled' or facts_dict['selinux']['status'] == 'enabled'

# Generated at 2022-06-23 01:42:05.302976
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import selinux

    # Importing selinux module will yield "enabled" status.
    assert SelinuxFactCollector().collect(None, None) == {'selinux': {'status': 'enabled'}, 'selinux_python_present': True}

    # unimport selinux module
    selinux_var = selinux
    del selinux

    # Without having selinux module, the status will be "disabled".
    # selinux_python_present = False
    assert SelinuxFactCollector().collect(None, None) == {'selinux': {'status': 'disabled'}, 'selinux_python_present': False}
    selinux = selinux_var
    del selinux_var

# Generated at 2022-06-23 01:42:08.764051
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()

    assert selinux_facts['selinux']
    assert selinux_facts['selinux']['status']

# Generated at 2022-06-23 01:42:18.461894
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Testing without the selinux library present
    import sys

    # Create a dummy class to represent the module/system module that imports the selinux module
    sys.modules['selinux'] = None

    selinux_collector = SelinuxFactCollector()

    facts_dict = selinux_collector.collect()

    assert facts_dict['selinux'] == {'status': 'Missing selinux Python library'}
    assert facts_dict['selinux_python_present'] is False

    # Testing with the selinux library present and SELinux enabled
    # Create a dummy class to represent the selinux module
    class selinux_dummy():
        class SELINUX_ENFORCING():
            pass
        security_getenforce = lambda: selinux_dummy.SELINUX_ENFORCING()

# Generated at 2022-06-23 01:42:25.391480
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect()

    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict
    selinux_dict = facts_dict['selinux']
    assert 'status' in selinux_dict
    assert 'policyvers' in selinux_dict
    assert 'config_mode' in selinux_dict
    assert 'mode' in selinux_dict
    assert 'type' in selinux_dict

# Generated at 2022-06-23 01:42:28.582485
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids

# Generated at 2022-06-23 01:42:38.112326
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup Ansible module mock
    module = AnsibleModuleMock(params={'gather_subset': ['all'], 'gather_timeout': 10})

    # Set selinux_python_present and selinux attributes to None
    module.ansible_facts['selinux_python_present'] = None
    module.ansible_facts['selinux'] = None

    # Instance of SelinuxFactCollector
    selinux_fc = SelinuxFactCollector()

    # Set selinux library to None
    global HAVE_SELINUX
    HAVE_SELINUX = None

    # Test method collect from class SelinuxFactCollector

# Generated at 2022-06-23 01:42:41.509319
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc.priority == -1
    assert sfc.requirements == set()
    assert hasattr(sfc, 'collect')

# Unit test when selinux python library is missing

# Generated at 2022-06-23 01:42:46.223410
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert facts_dict['selinux_python_present'] is True
    assert facts_dict['selinux']['type'] != 'unknown'

# Generated at 2022-06-23 01:42:54.345027
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import platform
    import sys

    # Create a dictionary of values to be returned by platforms.dist() when calling sys.platform
    # and platform.dist()

# Generated at 2022-06-23 01:43:01.887614
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    SelinuxFactCollector.collect() return a dictionary where the keys are
    selinux related facts.

    It should be a dictionary with a single key.
    That key should be a dictionary.
    """
    selinux_fact = SelinuxFactCollector(None).collect()

    assert isinstance(selinux_fact, dict)
    assert 'selinux' in selinux_fact

    assert isinstance(selinux_fact['selinux'], dict)

# Generated at 2022-06-23 01:43:14.550357
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        # test collect when library is present
        test_instance = SelinuxFactCollector()
        output = test_instance.collect()
        assert 'selinux_python_present' in output and output['selinux_python_present'] is True
        assert 'selinux' in output
        selinux_facts = output['selinux']
        assert 'status' in selinux_facts
        assert 'policyvers' in selinux_facts
        assert 'config_mode' in selinux_facts
        assert 'mode' in selinux_facts
        assert 'type' in selinux_facts
        assert selinux_facts['status'] in ['enabled', 'disabled']
    except ImportError:
        # test collect when library is missing
        test_instance = SelinuxFactCollector()
        output = test_instance.collect()


# Generated at 2022-06-23 01:43:19.463610
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = dict (selinux = {'config_mode': 'permissive',
                                    'mode': 'permissive',
                                    'status': 'enabled',
                                    'type': 'targeted'},
                         selinux_python_present=True)
    selinux_facts = SelinuxFactCollector()
    local_facts = selinux_facts.collect()
    assert local_facts == selinux_dict

# Generated at 2022-06-23 01:43:22.830661
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    # Keys in selinux_fact should be present in SelinuxFactCollector._fact_ids
    assert selinux_fact._fact_ids == set(selinux_fact.collect().keys())

# Generated at 2022-06-23 01:43:26.497786
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert type(fact_collector) == SelinuxFactCollector
    assert fact_collector.name == 'selinux'
    assert len(fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:43:35.805234
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = {'all_ipv4_addresses': ['1.1.1.1'], 'all_ipv6_addresses': ['::1']}

    sfc = SelinuxFactCollector()

    # if HAVE_SELINUX is false, only status and selinux_python_present are set:
    if not HAVE_SELINUX:
        HAVE_SELINUX = True
        res = sfc.collect(module, collected_facts)
        result = res.get('selinux')
        assert result.get('status') == 'Missing selinux Python library'

    # if HAVE_SELINUX is True, all keys are set
    HAVE_SELINUX = True
    res = sfc.collect(module, collected_facts)

# Generated at 2022-06-23 01:43:39.488097
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:43:40.852488
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_object = SelinuxFactCollector()
    assert test_object.collect()

# Generated at 2022-06-23 01:43:45.287547
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-23 01:43:48.320204
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFC = SelinuxFactCollector()
    assert selinuxFC.name == 'selinux'
    assert selinuxFC._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:43:53.417284
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {'config_mode': 'unknown',
    'mode': 'unknown',
    'policyvers': 'unknown',
    'status': 'disabled',
    'type': 'unknown'
    }

    fc = SelinuxFactCollector()
    facts_dict = fc.collect()
    assert facts_dict == {'selinux': selinux_facts,
    'selinux_python_present': True}

# Generated at 2022-06-23 01:43:58.372398
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    selinux_facts = selinux_fact.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert 'status' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-23 01:44:00.647863
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
	collector = SelinuxFactCollector()
	assert collector.name == 'selinux'
	assert collector._fact_ids == set()


# Generated at 2022-06-23 01:44:03.433432
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect()

    assert 'selinux_python_present' in result
    assert 'selinux' in result

# Generated at 2022-06-23 01:44:15.403141
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test to ensure that the collect method of the class SelinuxFactCollector
    returns the expected results, based on the function is_selinux_enabled.
    """
    class mockselinux(object):
        @staticmethod
        def is_selinux_enabler():
            return True

        @staticmethod
        def security_getenforce():
            return -1

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def security_policyvers():
            return 28

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')

    fact_collector = SelinuxFactCollector()

    original_selinux = fact_collector.__dict__['_selinux']
    fact_

# Generated at 2022-06-23 01:44:16.758896
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect(collected_facts={})

# Generated at 2022-06-23 01:44:25.622880
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    def mock_is_selinux_enabled(self):
        return False

    mock_collector = pytest.create_autospec(BaseFactCollector)
    mock_collector.name = 'mock_fact_collector'
    mock_collectors = {'mock_fact_collector': mock_collector}
    collector.fact_collector_classes['mock_fact_collector'] = mock_collector.__class__
    collector.all_collectors['mock_fact_collector'] = mock_collector

    SelinuxFactCollector('mock_fact_collector', mock_collectors)

    selinux = pytest.importorsk

# Generated at 2022-06-23 01:44:28.991756
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:44:31.192540
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactcollector = SelinuxFactCollector()
    assert selinuxfactcollector.name == 'selinux'

# Generated at 2022-06-23 01:44:35.530203
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""
    GCCollector = SelinuxFactCollector()
    GCCollector.collect()

# Generated at 2022-06-23 01:44:38.047171
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:44:48.104368
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create the SelinuxFactCollector object
    selinuxfc = SelinuxFactCollector()

    # Set new values for the module_utils.compat.selinux functions
    selinux._selinux_enabled = lambda: False
    selinux_getenforcemode = lambda: (1, 1)
    selinux.selinux_getenforcemode = selinux_getenforcemode
    selinux_getpolicytype = lambda: (1, 1)
    selinux.selinux_getpolicytype = selinux_getpolicytype

    # Get the selinux facts
    selinux_facts = selinuxfc.collect()

    # Check if the values returned by the collect method are correct

# Generated at 2022-06-23 01:44:51.284180
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:44:56.300484
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    collector = SelinuxFactCollector()
    result = collector.collect(module, None)
    assert 'status' in result['selinux']
    assert 'selinux_python_present' in result
    assert result['selinux_python_present'] is True

# Generated at 2022-06-23 01:44:57.333561
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:45:02.149822
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """This is to test SelinuxCollector class"""
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts.get('selinux') != None

# Generated at 2022-06-23 01:45:06.518698
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector

    obj = SelinuxFactCollector()

    assert obj.name == "selinux"

    assert isinstance(obj, BaseFactCollector)

    assert isinstance(obj._fact_ids, set)


# Generated at 2022-06-23 01:45:09.261949
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-23 01:45:11.694433
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Unit test for constructor of class SelinuxFactCollector."""
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    assert SelinuxFactCollector.collect() == {
        'selinux': {'status': 'Missing selinux Python library'},
        'selinux_python_present': False
    }

# Generated at 2022-06-23 01:45:15.696076
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set(['selinux'])


# Generated at 2022-06-23 01:45:21.671594
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()


# Generated at 2022-06-23 01:45:30.897574
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxCollector = SelinuxFactCollector()
    if HAVE_SELINUX:
        assert SelinuxCollector.collect()['selinux']['status'] == 'enabled'
    else:
        assert SelinuxCollector.collect()['selinux']['status'] == 'Missing selinux Python library'
        assert SelinuxCollector.collect()['selinux_python_present'] == False

# Generated at 2022-06-23 01:45:33.587221
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    actual = SelinuxFactCollector()
    assert actual.name == 'selinux'
    assert isinstance(actual._fact_ids, set)
    assert actual._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:45:37.969275
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    sys.modules['selinux'] = __import__('selinux')
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-23 01:45:41.132240
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:45:44.345889
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'


# Generated at 2022-06-23 01:45:52.724666
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys

    import pytest
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector import FactsCollector

    # Mock out the rely on selinux module and
    # selinux.is_selinux_enabled()
    IS_SELINUX_ENABLED = True
    SECURITY_GETENFORCE_MODE = 1
    POLICYVERS = 123
    CONFIGMODE = 1
    POLICYTYPE = 'targeted'

    mock_selinux = type('mock_selinux', (object,), {})

    def mock_is_selinux_enabled(*args, **kwargs):
        return IS_SELINUX_ENABLED

    def mock_security_getenforce(*args, **kwargs):
        return SECURITY_GETENFORCE_

# Generated at 2022-06-23 01:46:03.095920
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = {}
    if HAVE_SELINUX:
        selinux_facts = SelinuxFactCollector()
    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
    else:
        facts_dict['selinux_python_present'] = True
        if not selinux.is_selinux_enabled():
            selinux_facts['status'] = 'disabled'
        else:
            selinux_facts['status'] = 'enabled'
            if selinux.security_policyvers() == '-1':
                selinux_facts['policyvers'] = 'unknown'
            else:
                selinux_facts['policyvers']

# Generated at 2022-06-23 01:46:08.928633
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    facts_collector = FactsCollector()
    collected_facts = facts_collector.collect(module=None, collected_facts={'selinux': None})

    for key in collected_facts['ansible_facts']:
        assert key in ['selinux', 'selinux_python_present']

# Generated at 2022-06-23 01:46:10.270501
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:46:11.812321
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.collect() == {'selinux_python_present': True,
                                       'selinux': {}}

# Generated at 2022-06-23 01:46:14.770495
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Dummy class just to test
    class DummyModule:
        pass

    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect(module=DummyModule())

# Generated at 2022-06-23 01:46:16.553602
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:46:24.366024
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    selinux_python_present is set to False if the module doesn't import.
    :return:
    """
    # we can't use mock here since it doesn't support nested imports
    saved_import = __import__

    def mock_import(name, *args):
        if name == "ansible.module_utils.compat":
            raise ImportError("No module named 'ansible.module_utils.compat'")
        else:
            return saved_import(name, *args)


# Generated at 2022-06-23 01:46:36.161191
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector on platforms
    with or without SELinux support.
    """
    import sys
    import os

    # Get the module directory.
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Get the facts module, so that the SelinuxFactCollector class can be instantiated.
    # Note that we need to ensure that the actual facts are not collected,
    # which is why we use a custom path for the facts module.
    sys.path.insert(0, os.path.join(current_dir, '../../..', 'lib/ansible/module_utils/facts'))
    import ansible.module_utils.facts.facts as facts_module

    # Instantiate the SelinuxFactCollector and call

# Generated at 2022-06-23 01:46:42.885396
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    res = SelinuxFactCollector().collect()
    assert res == {'selinux': {'config_mode': 'disabled',
                               'mode': 'disabled',
                               'policyvers': 'unknown',
                               'status': 'disabled',
                               'type': 'unknown'},
                   'selinux_python_present': False}

# Generated at 2022-06-23 01:46:45.679347
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact = SelinuxFactCollector()
    assert fact.name == 'selinux'

# Generated at 2022-06-23 01:46:50.946929
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    global HAVE_SELINUX

    HAVE_SELINUX = True
    selinux.is_selinux_enabled = lambda: True

    # If selinux library is present, test the values of returned dictionary
    selinux.security_policyvers = lambda: '2.2'
    selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux.security_getenforce = lambda: 0
    selinux.selinux_getpolicytype = lambda: (0, 'mls')
    fact_collector = SelinuxFactCollector()
    selinux_facts = fact_collector.collect()['selinux']
    assert 'Missing selinux Python library' not in selinux_facts['status']
    assert selinux_facts['status'] == 'enabled'

# Generated at 2022-06-23 01:46:54.301522
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class DummyModule:
        pass

    test_module = DummyModule()

    test_collector = SelinuxFactCollector(test_module)
    result = test_collector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-23 01:46:55.267527
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector(None)

# Generated at 2022-06-23 01:46:58.224341
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set() or x._fact_ids == set()


# Generated at 2022-06-23 01:47:04.232715
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    facts_dict = selinux_fact.collect()
    assert facts_dict['selinux']
    assert facts_dict['selinux']['status'] == 'disabled'

# Generated at 2022-06-23 01:47:06.141903
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:47:16.092144
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = SelinuxFactCollector().collect()
    assert 'selinux' in selinux_dict
    assert 'selinux_python_present' in selinux_dict
    # selinux_python_present will be False if the selinux Python library is missing
    assert selinux_dict['selinux_python_present'] is True
    assert selinux_dict['selinux']['status'] == 'enabled'
    assert selinux_dict['selinux']['policyvers'] == '28'
    assert selinux_dict['selinux']['config_mode'] == 'enforcing'
    assert selinux_dict['selinux']['mode'] == 'enforcing'
    assert selinux_dict['selinux']['type'] == 'targeted'

# Generated at 2022-06-23 01:47:17.798747
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().fact_subset == set()

# Generated at 2022-06-23 01:47:20.921888
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test constructor of class SelinuxFactCollector.
    """

    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-23 01:47:22.299625
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    selinux.collect()

# Generated at 2022-06-23 01:47:24.468335
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Check the instance of the class
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)

# Generated at 2022-06-23 01:47:36.816452
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    The test_SelinuxFactCollector_collect unit test for the
    SelinuxFactCollector class' collect method tests the return value
    of the collect method by missing Python selinux library and
    with Python selinux library available.

    :return: no return value
    """
    selinux_collector = SelinuxFactCollector()

    # set the selinux Python library to be missing, then execute
    # collect method
    SelinuxFactCollector.HAVE_SELINUX = False
    selinux_facts = selinux_collector.collect(None, None)

    # check if the return data structure is a dict
    assert isinstance(selinux_facts, dict)
    # check if the return data structure has 2 items
    assert len(selinux_facts) == 2
    # check if the return data

# Generated at 2022-06-23 01:47:46.797883
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the SelinuxFactCollector.collect() method with a stub for the
    selinux python library.
    """

    # Return values for stubs
    stub_is_selinux_enabled = True
    stub_security_policyvers = 9
    stub_selinux_getenforcemode_return_code = 0
    stub_selinux_getenforcemode_mode = 1
    stub_security_getenforce = 0
    stub_selinux_getpolicytype_return_code = 0
    stub_selinux_getpolicytype_policy = 'targeted'

    # Create a mock AnsibleModule object
    mock_module = mock.Mock(spec=['add_fact'])

    # Create stubs for selinux library imports

# Generated at 2022-06-23 01:47:48.546453
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Call method collect of class SelinuxFactCollector
    SelinuxFactCollector().collect()


# Generated at 2022-06-23 01:47:56.739163
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    sys.path.insert(1, '/etc/ansible/module_utils')
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect(module=module, collected_facts=dict())
    assert type(result) == dict
    assert 'selinux' in result

    result_selinux = result['selinux']
    assert type(result_selinux) == dict
    assert 'status' in result_selinux
    assert 'config_mode' in result_selinux
    assert 'mode' in result_selinux
    assert 'type' in result_selinux
    assert 'policyvers' in result_selin

# Generated at 2022-06-23 01:47:59.198724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    ''' Create object of SelinuxFactCollector and return object. '''
    obj = SelinuxFactCollector()
    assert obj is not None

# Generated at 2022-06-23 01:48:00.365952
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:48:03.783323
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'

# Generated at 2022-06-23 01:48:14.414263
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    fake_selinux = {
        'is_selinux_enabled': lambda: True,
        'security_policyvers': lambda: 202,
        'selinux_getenforcemode': lambda: (0, 1),
        'selinux_getpolicytype': lambda: (0, 'targeted'),
        'security_getenforce': lambda: 1
    }

    module_mock = MagicMock()
    selinux.is_selinux_enabled = fake_selinux.get('is_selinux_enabled')
    selinux.security_policyvers = fake_selinux.get('security_policyvers')
    selinux.selinux_getenforcemode = fake_selinux.get('selinux_getenforcemode')
    selinux.selinux_getpolicytype = fake_sel

# Generated at 2022-06-23 01:48:17.461195
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts_collector = SelinuxFactCollector()
    result = selinux_facts_collector.collect()
    selinux_python_present = result.get('selinux_python_present', 'unknown')
    assert selinux_python_present in ('unknown', True, False)

# Generated at 2022-06-23 01:48:22.242480
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert facts_dict['selinux_python_present'] == True or facts_dict['selinux_python_present'] == False

# Generated at 2022-06-23 01:48:31.514013
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None

    # Testing when the module if missing
    try:
        selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    selinux_facts = SelinuxFactCollector()
    facts_dict = selinux_facts.collect(module, collected_facts)
    assert facts_dict.get('selinux') is not None
    if not HAVE_SELINUX:
        assert facts_dict['selinux_python_present'] is False
    else:
        assert facts_dict['selinux_python_present'] is True


# Generated at 2022-06-23 01:48:43.439756
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_ext_module_names

    c = Collector()
    ext_list = get_collector_ext_module_names()

    # check that the fact collector is present in the extension list
    assert 'selinux' in ext_list

    # get an instance of the fact collector
    instance = get_collector_instance('selinux', c)

    # the instance should be an instance of the fact collector
    assert isinstance(instance, SelinuxFactCollector)

    # the facts are collected properly
    facts = instance.collect()
    assert isinstance(facts, dict)
    assert 'selinux'

# Generated at 2022-06-23 01:48:45.548979
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == "selinux"

# Generated at 2022-06-23 01:48:47.943696
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_collector = SelinuxFactCollector()
    assert test_collector.name == 'selinux'
    assert test_collector._fact_ids == set()

# Generated at 2022-06-23 01:48:58.626482
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector
    import inspect

    # Test selinux constructor
    c = SelinuxFactCollector()
    assert c.name == 'selinux'

    # Test selinux constructor class hierarchy
    assert issubclass(SelinuxFactCollector, Collector)
    assert issubclass(SelinuxFactCollector, FactCollector)

    # Test selinux constructor call signature
    sig = inspect.signature(SelinuxFactCollector)
    params = list(sig.parameters.keys())
    assert len(params) == 1
    assert params[0] == 'module'

    # Test selinux constructor call
    c = SelinuxFactCollector()
    assert c.name == 'selinux'



# Generated at 2022-06-23 01:49:00.439211
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    print(selinux_fact.collect())


# Generated at 2022-06-23 01:49:10.564467
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert hasattr(selinux_fact_collector, 'collect')
    assert selinux_fact_collector.name == 'selinux'

# Unit tests for function collect

# Generated at 2022-06-23 01:49:21.408522
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test for method collect of class SelinuxFactCollector
    '''
    selinux_collector = SelinuxFactCollector()
    # Test when the selinux Python library is missing
    result = selinux_collector.collect()
    assert result == {'selinux': {'status': 'Missing selinux Python library'},
                      'selinux_python_present': False}
    # Test when the selinux Python library is present
    # Test when selinux is disabled on the system
    def is_selinux_enabled_mock_disabled():
        '''
        Mocked method for selinux.is_selinux_enabled() when selinux is disabled on the system
        '''
        return False
    selinux.is_selinux_enabled = is_selinux_enabled_mock_disabled

# Generated at 2022-06-23 01:49:23.636350
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == "selinux"

# Generated at 2022-06-23 01:49:27.226827
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from importlib import import_module
    module_name = 'ansible.module_utils.facts.collector.selinux'
    collector = import_module(module_name)
    assert isinstance(collector.SelinuxFactCollector().collect(), dict)

# Generated at 2022-06-23 01:49:35.985540
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()

    # Test if selinux_python_present is default set to False
    result = selinux_collector.collect()
    assert (result['selinux_python_present'] == False)

    # Test if collect method returns a dict with selinux as key
    assert (type(result) == dict)
    assert ('selinux' in result.keys())

    # Test if selinux_python_present value is set to True when fact
    # is available
    selinux_collector.HAVE_SELINUX = True
    result = selinux_collector.collect()
    assert (result['selinux_python_present'] == True)

# Generated at 2022-06-23 01:49:43.051684
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = {}
    selinux_fact_collector = SelinuxFactCollector()

    # return values of mocked functions
    selinux_is_selinux_enabled_return_value = True
    selinux_security_policyvers_return_value = 42
    selinux_getenforcemode_return_value = 0
    selinux_getenforcemode_configmode_return_value = 1
    selinux_security_getenforce_return_value = 1
    selinux_getpolicytype_return_value = 0
    selinux_getpolicytype_policytype_return_value = 'targeted'

    # mock functions
    selinux_is_selinux_enabled = lambda: selinux_is_selinux_enabled_return_value
    selinux_security_policyvers = lambda: se

# Generated at 2022-06-23 01:49:51.645301
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test selinux.collect fact
    """
    selinux_data = {'status': 'enabled', 'policyvers': '28', 'config_mode': 'enforcing', 'mode': 'enforcing', 'type': 'targeted'}
    if HAVE_SELINUX:
        assert (SelinuxFactCollector().collect())['selinux'] == selinux_data
    else:
        assert (SelinuxFactCollector().collect())['selinux']['status'] == 'Missing selinux Python library'



# Generated at 2022-06-23 01:49:56.880096
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    :return: None
    """
    selinux_obj = SelinuxFactCollector()
    selinux_obj.collect()