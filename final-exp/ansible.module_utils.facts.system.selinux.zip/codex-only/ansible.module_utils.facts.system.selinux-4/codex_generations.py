

# Generated at 2022-06-23 01:39:59.038393
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect() == {'selinux': {'status': 'Missing selinux Python library'},
                                                'selinux_python_present': False}

# Generated at 2022-06-23 01:40:01.462421
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert(SelinuxFactCollector().name == 'selinux')
    assert(SelinuxFactCollector()._fact_ids == set())

# Generated at 2022-06-23 01:40:03.725576
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:40:06.686008
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert 'selinux' == SelinuxFactCollector.name

# Generated at 2022-06-23 01:40:12.653784
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Class SelinuxFactCollector: non-coverage test of method collect
    """

    # Setup
    selinux_facts = {}
    facts_dict = {}
    _collector = SelinuxFactCollector()
    selinux_facts['status'] = 'disabled'
    facts_dict['selinux'] = selinux_facts

    # Execution
    collected_facts = _collector.collect()

    # Verification
    assert collected_facts == facts_dict

# Generated at 2022-06-23 01:40:14.648893
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert set(obj._fact_ids) == set()

# Generated at 2022-06-23 01:40:16.085014
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:40:18.869608
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert(isinstance(selinux_obj, SelinuxFactCollector))

# Generated at 2022-06-23 01:40:29.120863
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    fact_dict = selinux_fact_collector.collect()
    assert 'selinux' in fact_dict.keys()
    # On the systems without SELinux enabled, the following two keys
    # will be defined.
    assert 'status' in fact_dict['selinux'].keys()
    assert 'selinux_python_present' in fact_dict.keys()

    # On the systems with SELinux enabled, the following keys will be defined

# Generated at 2022-06-23 01:40:30.909968
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'

# Generated at 2022-06-23 01:40:34.699442
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    selinux_fact = SelinuxFactCollector()
    selinux_facts = selinux_fact.collect()
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-23 01:40:37.665949
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFacts = SelinuxFactCollector()
    assert selinuxFacts.name == 'selinux'

# Generated at 2022-06-23 01:40:42.973523
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    facts = selinux_fact_collector.collect(collected_facts)
    if HAVE_SELINUX:
        assert facts['selinux_python_present'] == True
        assert 'selinux' in facts
    else:
        assert facts['selinux_python_present'] == False
        assert 'selinux' not in facts

# Generated at 2022-06-23 01:40:47.941314
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    resultdict = SelinuxFactCollector().collect(None,None)
    assert resultdict == {}

# Generated at 2022-06-23 01:40:48.570756
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-23 01:40:54.075571
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {
        'config_mode': 'permissive',
        'mode': 'enforcing',
        'status': 'enabled',
        'type': 'targeted'
    }
    if HAVE_SELINUX:
        selinux_facts['policyvers'] = selinux.security_policyvers()

    assert SelinuxFactCollector.collect()['selinux'] == selinux_facts

# Generated at 2022-06-23 01:40:57.139738
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()
    assert result['selinux']['status'] == 'enabled'


# Generated at 2022-06-23 01:40:58.734461
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-23 01:41:08.985782
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test with selinux library missing, just verify selinux status is set to Missing selinux library
    # and selinux_python_present is set to False
    module = None
    collected_facts = None
    orig_HAVE_SELINUX = HAVE_SELINUX
    HAVE_SELINUX = False
    selinux_fact_collector = SelinuxFactCollector()

    facts_dict = selinux_fact_collector.collect(module, collected_facts)
    assert facts_dict["selinux"]["status"] == "Missing selinux Python library"
    assert not facts_dict["selinux_python_present"]

    # Test with selinux library present, but SELinux disabled

    # Since the selinux library cannot be mocked, set the HAVE_SELINUX flag to True
    # and first test when

# Generated at 2022-06-23 01:41:12.440541
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_selinuxFactCollector = SelinuxFactCollector()
    test_dict = test_selinuxFactCollector.collect()
    assert isinstance(test_dict, dict)
    assert 'selinux' in test_dict.keys()

# Generated at 2022-06-23 01:41:24.429812
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """

    sec_enforce_dict = {}
    selinux_getenforcemode_dict = {}
    selinux_getpolicytype_dict = {}
    security_policyvers_dict = {}
    selinux_dict = {}

    def dummy_selinux_getenforcemode():
        return (
            selinux_getenforcemode_dict['selinux.selinux_getenforcemode.return_value.rc'],
            selinux_getenforcemode_dict['selinux.selinux_getenforcemode.return_value.configmode']
        )


# Generated at 2022-06-23 01:41:26.726119
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    col = SelinuxFactCollector()
    assert col.name == 'selinux'

# Generated at 2022-06-23 01:41:33.432338
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    assert(selinux_facts['selinux_python_present'])

    if selinux_facts['selinux']['type'] != 'unknown':
        for key, value in selinux_facts['selinux'].items():
            assert(value != 'unknown')
    else:
        assert(selinux_facts['selinux']['status'] == 'disabled')


# Generated at 2022-06-23 01:41:35.438723
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:41:46.271004
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux library is missing, only set the status and selinux_python_present
    # no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    def mock_import_error(name, *args, **kwargs):
        if name == 'selinux':
            raise ImportError
        else:
            return 1
    import_mock = mock.Mock(side_effect=mock_import_error)
    with mock.patch('ansible.module_utils.facts.collector.import_module', import_mock):
        selinux_fact_collector = SelinuxFactCollector()
        selinux_facts = selinux_fact_collector.collect()

# Generated at 2022-06-23 01:41:50.838479
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:41:55.761477
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a mock class where the method collect of the class SelinuxFactCollector
    # can be mocked

    class MockModule(object):
        pass

    module = MockModule()

    # Create a mock class where the method is_selinux_enabled of the class selinux
    # can be mocked

    class MockSelinux(object):
        def __init__(self):
            self.is_selinux_enabled_return_value = 'enabled'
            self.selinux_getenforcemode_return_value = 0
            self.selinux_getenforcemode_return_value_mode = 1
            self.security_getenforce_return_value = 1
            self.selinux_getpolicytype_return_value = 0

# Generated at 2022-06-23 01:41:57.590600
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:42:06.022830
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create an instance of class SelinuxFactCollector
    selinux = SelinuxFactCollector()
    # call method collect with valid params
    result = selinux.collect(module='Linux')
    assert 'selinux' in result
    assert result['selinux']['status'] == 'disabled'
    # selinux is disabled on my local Linux system, so test passes if result == expected
    # result
    assert result['selinux']['mode'] == 'unknown'
    assert result['selinux']['type'] == 'unknown'
    assert result['selinux']['config_mode'] == 'unknown'
    # test passes if result == expected result
    assert result['selinux_python_present'] == True
    # selinux is present, so test passes if result == expected result

# Generated at 2022-06-23 01:42:10.756908
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert len(selinux_fact_collector._fact_ids) == 0
    assert hasattr(selinux_fact_collector, 'collect')

# Generated at 2022-06-23 01:42:14.184612
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    class_initialization = SelinuxFactCollector()
    assert type(class_initialization) == SelinuxFactCollector
    assert class_initialization.name is not None
    assert class_initialization._fact_ids is not None


# Generated at 2022-06-23 01:42:24.504446
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test for method collect of class SelinuxFactCollector.
    '''
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()

    # Test that all facts were collected
    if selinux_facts['selinux_python_present']:
        assert 'selinux' in selinux_facts
        assert 'status' in selinux_facts['selinux']
        assert 'policyvers' in selinux_facts['selinux']
        assert 'config_mode' in selinux_facts['selinux']
        assert 'mode' in selinux_facts['selinux']
        assert 'type' in selinux_facts['selinux']
    else:
        assert 'status' in selinux_facts['selinux']

# Generated at 2022-06-23 01:42:35.287298
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.selinux import selinux
    import ansible.module_utils.selinux
    import pytest

    module_mock = pytest.Mock()
    module_mock.params.get.return_value = None

    # selinux module is not present
    selinux_fact_collector = SelinuxFactCollector(module_mock)
    selinux_fact_collector.collect()

    assert selinux_fact_collector.seinfo == {}
    assert selinux_fact_collector.seperms == {}

    # selinux module is present
    selinux_fact_collector.selinux_python_present = True

# Generated at 2022-06-23 01:42:37.739674
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    c = SelinuxFactCollector()
    assert c.collect()

# Generated at 2022-06-23 01:42:39.033809
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()

# Generated at 2022-06-23 01:42:41.707416
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:42:46.988791
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:42:50.337928
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    tmp_collector = SelinuxFactCollector()
    tmp_collector.collect()

# Generated at 2022-06-23 01:42:53.549903
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector

# Generated at 2022-06-23 01:42:55.218687
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:43:02.576842
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()

    assert isinstance(result, dict)
    assert 'selinux' in result
    assert isinstance(result['selinux'], dict)
    assert 'status' in result['selinux']
    assert isinstance(result['selinux']['status'], str)

# Generated at 2022-06-23 01:43:12.795564
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_dict = selinux_fact_collector.collect()
    # Check the selinux_python_present boolean is set
    assert 'selinux_python_present' in selinux_fact_dict
    # Check the selinux facts are present in the collected facts
    assert 'selinux' in selinux_fact_dict
    selinux_facts = selinux_fact_dict['selinux']
    # Always check these facts even if the selinux Python library is missing
    assert 'status' in selinux_facts
    if not HAVE_SELINUX:
        assert selinux_facts['status'] == 'Missing selinux Python library'
    else:
        assert selinux_facts['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 01:43:14.294614
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:43:17.844530
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"
    assert obj.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }


# Generated at 2022-06-23 01:43:27.016324
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import json
    import platform
    import os

    if os.path.exists('/usr/bin/selinuxenabled'):
        selinux_enabled = True
    else:
        selinux_enabled = False

    # Create mock module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=('tmpdir', 'tmpdir', 0))
    module.get_bin_path = MagicMock(return_value='/usr/bin/file')

    # Create mock object
    collected_facts = {}
    selinux_collector = SelinuxFactCollector(module=module)

    if platform.system() == "Linux" and selinux_enabled:
        results = selinux_collector.collect(module=module, collected_facts=collected_facts)
        results

# Generated at 2022-06-23 01:43:34.956004
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """This test case checks for constructor of class SelinuxFactCollector"""
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert type(selinux_collector._fact_ids) == set

# Generated at 2022-06-23 01:43:45.001443
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Make the selinux library unavailable to get the missing library test
    # output
    selinux_orig = None
    if HAVE_SELINUX:
        selinux_orig = selinux
        del selinux

    import ansible.module_utils.facts.system.selinux

    selinux_collector = ansible.module_utils.facts.system.selinux.SelinuxFactCollector()
    facts_dict = selinux_collector.collect()

    # Make sure we have the right keys
    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict

    assert not facts_dict['selinux_python_present']

    # Make sure we have the right results
    assert 'status' in facts_dict['selinux']

# Generated at 2022-06-23 01:43:49.670544
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()
    assert result == {'selinux_python_present': True, 'selinux': {'status': 'enabled', 'policyvers': 31, 'config_mode': 'permissive', 'mode': 'permissive', 'type': 'targeted'}}

# Generated at 2022-06-23 01:43:55.123926
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_info = selinux_fact_collector.collect()
    assert 'selinux_python_present' in selinux_info
    assert 'status' in selinux_info['selinux']
    assert 'config_mode' in selinux_info['selinux']
    assert 'mode' in selinux_info['selinux']
    assert 'type' in selinux_info['selinux']

# Generated at 2022-06-23 01:44:01.352705
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collectors.network.selinux import SelinuxFactCollector

    selinux_facts = SelinuxFactCollector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-23 01:44:08.151341
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = Mock()

    mock_module.params = {}

    selinux_info = {
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        }
    }

    selinux_factcollector = SelinuxFactCollector()
    selinux_factcollector.collect(module=mock_module)

    # test with Python selinux library present
    module_facts = selinux_factcollector.collect(module=mock_module)
    assert module_facts == selinux_info

# Mock out selinux

# Generated at 2022-06-23 01:44:10.255026
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:44:18.190566
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

  class FakeModule:
      def __init__(self):
          self.params = {}

  #Case: selinux library is installed
  facts_collector = SelinuxFactCollector()
  res_dict = facts_collector.collect()
  assert res_dict['selinux_python_present'] == True

  #Case: selinux library is not installed
  class FakeSelinux:
      def __init__(self):
          raise Exception()
  selinux = FakeSelinux()
  res_dict = facts_collector.collect()
  assert res_dict['selinux_python_present'] == False

# Generated at 2022-06-23 01:44:24.890725
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == collector.name
    assert collector._fact_ids == collector._fact_ids


# Generated at 2022-06-23 01:44:25.892125
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:44:35.332540
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for selinux fact collector"""

    collect_se_linux_facts = SelinuxFactCollector(
        module=None,
        collected_facts=None
    )

    se_linux_facts = collect_se_linux_facts.collect()

    assert 'selinux' in se_linux_facts
    assert 'status' in se_linux_facts['selinux']

    if HAVE_SELINUX:
        assert 'config_mode' in se_linux_facts['selinux']
        assert 'mode' in se_linux_facts['selinux']
        assert 'type' in se_linux_facts['selinux']

    assert 'selinux_python_present' in se_linux_facts

# Generated at 2022-06-23 01:44:44.115717
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup module parameters for test
    module_params = {}

    # Setup test for when selinux module is not installed.
    def mock_import_selinux_isselinuxenabled_notpresent(module):
        raise ImportError()

    # Stub out selinux function is_selinux_enabled() when selinux
    # module is not present.
    selinux_isselinuxenabled_notpresent = dict(
        selinux=dict(
            is_selinux_enabled=mock_import_selinux_isselinuxenabled_notpresent)
    )
    selinux_notpresent = dict(selinux=dict())

    # Setup test for when selinux module is installed.
    def mock_sysconfig_selinux_status_enabled(module):
        return 'enabled'


# Generated at 2022-06-23 01:44:53.457523
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class FakeModule(object):
        pass

    module = FakeModule()
    module.params = {}
    module.run_command = lambda x: (0, '', '')

    selinux_fc = SelinuxFactCollector()

    # test with SELinux enabled
    returned_facts = selinux_fc.collect(module=module)
    assert returned_facts is not None
    assert 'selinux' in returned_facts
    assert 'policyvers' in returned_facts['selinux']
    assert 'config_mode' in returned_facts['selinux']
    assert 'mode' in returned_facts['selinux']
    assert 'type' in returned_facts['selinux']
    assert 'status' not in returned_facts['selinux']

    # test with SELinux disabled
    module.run_

# Generated at 2022-06-23 01:44:56.870037
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert isinstance(result['selinux_python_present'], bool)

# Generated at 2022-06-23 01:45:02.049256
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert isinstance(selinux_facts._fact_ids, set)
    assert isinstance(selinux_facts.collect(), dict)


# Generated at 2022-06-23 01:45:05.533145
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    mock_module = type('module', (object,), {})()
    selinux_collector = SelinuxFactCollector(module=mock_module)
    assert isinstance(selinux_collector, SelinuxFactCollector)

# Generated at 2022-06-23 01:45:11.057814
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    my_facts = fact_collector.collect()

    if 'selinux' in my_facts:
        assert my_facts['selinux']['status'] == 'disabled' or \
               my_facts['selinux']['status'] == 'enabled'

    assert my_facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:45:22.681218
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts import collector

    module = AnsibleModuleMock()
    facts_dict = {}

    selinux_collector = collector.get_collector('selinux')
    selinux_collector.collect(module=module, collected_facts=facts_dict)
    facts_dict['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        assert facts_dict['selinux']['status'] == 'disabled'
    else:
        assert facts_dict['selinux']['status'] == 'enabled'


# Generated at 2022-06-23 01:45:26.339449
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-23 01:45:35.885912
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectFailure
    from ansible.module_utils.facts.collector import Collector
    import os

    def test_fact_collector_collect(collector, module=None, collected_facts=None):
        if module is None:
            module = Collector()
            module.exit_json = lambda: None
            module.fail_json = lambda msg: os._exit(1)
        if collected_facts is None:
            collected_facts = {}
        return collector.collect(module=module, collected_facts=collected_facts)

    selinux_facts = {
        'status': 'disabled',
        'config_mode': 'unknown',
        'policyvers': 'unknown',
        'mode': 'unknown',
        'type': 'unknown'
    }


# Generated at 2022-06-23 01:45:41.204769
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'
    assert sf._fact_ids == set()


# Generated at 2022-06-23 01:45:43.251262
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector_obj = SelinuxFactCollector()
    SelinuxFactCollector_obj.collect()


# Generated at 2022-06-23 01:45:52.865595
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    data = collector.collect()
    assert 'selinux_python_present' in data
    assert 'selinux' in data

    # If selinux Python library is not present, status of selinux fact is
    # 'Missing selinux Python library' and value for selinux_python_present
    # is False.
    if not HAVE_SELINUX:
        assert data['selinux']['status'] == 'Missing selinux Python library'
        assert data['selinux_python_present'] == False
        return

    # selinux_python_present should be True if selinux Python library is present
    assert data['selinux_python_present'] == True
    assert 'config_mode' in data['selinux']
    assert 'mode' in data['selinux']
   

# Generated at 2022-06-23 01:46:03.156042
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.augeas.community.tests.unit.compat.mock import patch, mock_open
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.base import Collector, get_collector_name
    selinux_fact_collector = SelinuxFactCollector()
    # mock base_collect
    my_base_collect = _my_base_collect = lambda _: None
    with patch.object(BaseFactCollector, '_base_collect', my_base_collect):
        selinux_fact_collector._base_collect()

    # mock selinux.is_selinux_enabled
    if HAVE_SELINUX:
        my_security_geten

# Generated at 2022-06-23 01:46:08.575950
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collector = SelinuxFactCollector()
    assert test_collector.collect() == {'selinux_python_present': True, 'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}}



# Generated at 2022-06-23 01:46:14.818672
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    selinux_module = collector._get_collector_module(SelinuxFactCollector)
    assert isinstance(selinux_module, SelinuxFactCollector)
    assert isinstance(selinux_module, BaseFactCollector)

# Generated at 2022-06-23 01:46:27.512837
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    # create mock module object
    results = selinux_fact_collector.collect(module=None, collected_facts=None)
    assert type(results.get('selinux_python_present')) is bool
    assert type(results.get('selinux')) is dict
    assert 'status' in results['selinux']
    assert type(results['selinux']['status']) is str
    assert 'policyvers' in results['selinux']
    assert type(results['selinux']['policyvers']) is str
    assert 'mode' in results['selinux']
    assert type(results['selinux']['mode']) is str
    assert 'type' in results['selinux']

# Generated at 2022-06-23 01:46:28.307667
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:46:30.972558
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-23 01:46:33.112644
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_instance = SelinuxFactCollector()
    assert selinux_instance
    assert selinux_instance.collect()

# Generated at 2022-06-23 01:46:34.981919
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact


# Generated at 2022-06-23 01:46:37.276565
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()

    assert x.name == 'selinux'
    assert 'selinux' in x._fact_ids

# Generated at 2022-06-23 01:46:40.479172
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:46:42.201871
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactcollector = SelinuxFactCollector()
    assert selinuxfactcollector.name == 'selinux'

# Generated at 2022-06-23 01:46:52.897176
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    try:
        selinux_fact_collector.collect()
        assert False # Should have thrown an exception due to missing selinux Python library
    except ImportError:
        pass

    # First test when selinux is disabled on the system.
    selinux.is_selinux_enabled = lambda: False
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts["selinux"]["status"] == "disabled"

    # Now test when selinux is enabled on the system.
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: 5
    selinux.selinux_getenforcemode = lambda: (0, 0)
    selinux.security_getenforce

# Generated at 2022-06-23 01:47:00.266088
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()
    private_rtn = selinux.collect()
    assert private_rtn is not None
    assert type(private_rtn) is dict
    assert 'selinux' in private_rtn
    assert 'status' in private_rtn['selinux']
    assert 'selinux_python_present' in private_rtn
    if HAVE_SELINUX:
        assert private_rtn['selinux_python_present'] is True
    else:
        assert private_rtn['selinux_python_present'] is False

# Generated at 2022-06-23 01:47:03.933105
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test 1: If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library
    fc = SelinuxFactCollector()
    fc.collect()

# Generated at 2022-06-23 01:47:07.181975
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()



# Generated at 2022-06-23 01:47:17.896466
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import pytest

    # Mock sys.platform
    if sys.platform == 'darwin':
        import platform
        platform_uname = platform.uname()
        platform.uname = lambda: platform_uname

    m_module = Mock(params={})

    # Mock module_utils.selinux
    m_selinux = Mock()
    m_selinux.is_selinux_enabled.return_value = False
    m_selinux.security_policyvers.return_value = 0
    m_selinux.selinux_getenforcemode.return_value = (0, -1)
    m_selinux.security_getenforce.return_value = -1
    m_selinux.selinux_getpolicytype.return_value = (0, 'unknown')

# Generated at 2022-06-23 01:47:21.156092
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:47:30.382710
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import mock
    import sys

    x = SelinuxFactCollector()

    assert x.name == 'selinux'
    assert x._fact_ids == set()

    # Constructor will not raise an exception if selinux module missing
    # because the library is not always present.
    # From the documentation for module_utils.compat.selinux:
    #
    #   SELinux is not available on systems that are not using SELinux.
    #   This compatibility layer will automatically disable itself if it is
    #   not available on the system.
    #
    # So, we test by mocking a missing library (if HAVE_SELINUX is False)
    # or mock an import error (if HAVE_SELINUX is True)

# Generated at 2022-06-23 01:47:32.520682
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:47:33.975490
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert SelinuxFactCollector.collect() is not None


# Generated at 2022-06-23 01:47:38.480306
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModuleMock()
    obj = SelinuxFactCollector(module=module)
    assert obj.name == 'selinux'


# Generated at 2022-06-23 01:47:40.479978
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-23 01:47:44.730204
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-23 01:47:53.957190
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()

    assert selinux_fact_collector_obj.name == 'selinux'
    assert selinux_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:48:02.359590
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    FAKE_FACTS = {'foo': 'bar'}
    fact_collector = SelinuxFactCollector(None)
    fact_collector.collect(None, FAKE_FACTS)
    assert FAKE_FACTS == {'foo': 'bar', 'selinux': {'status': 'disabled'}, 'selinux_python_present': True}

# Generated at 2022-06-23 01:48:05.525863
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.priority == 50

# Generated at 2022-06-23 01:48:06.794561
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-23 01:48:16.246084
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Store config mode and type before mocking the selinux library
    config_mode = selinux.selinux_getenforcemode()[1]
    policy_type = selinux.selinux_getpolicytype()[1]

    # Create a mock for the selinux library
    selinux_mock = {}
    selinux_mock['security_policyvers'] = lambda: 0
    selinux_mock['security_getenforce'] = lambda: 0
    selinux_mock['selinux_getenforcemode'] = lambda: (0, config_mode)
    selinux_mock['selinux_getpolicytype'] = lambda: (0, policy_type)

    # Create mock for the selinux module
    def is_selinux_enabled_mock():
        return True

    # Set up the selinux mock

# Generated at 2022-06-23 01:48:20.786505
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test the constructor of class SelinuxFactCollector."""
    module = None
    collected_facts = None
    selinux_fc = SelinuxFactCollector()
    selinux_fc.collect(collected_facts=collected_facts, module=module)

# Generated at 2022-06-23 01:48:23.771850
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids is not None

# Generated at 2022-06-23 01:48:26.667105
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert isinstance(sfc._fact_ids, set)
    assert hasattr(sfc, 'collect')

# Generated at 2022-06-23 01:48:34.669204
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Test results of selinux collect method with and without
    selinux library
    '''
    import sys

    s = SelinuxFactCollector()
    selinux_present = True
    sys.modules['selinux'] = None
    assert s.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    sys.modules['selinux'] = object()
    s._collect_platform_facts()
    assert s.collect() == {'selinux': {'config_mode': 'unknown', 'status': 'disabled', 'mode': 'unknown', 'type': 'unknown', 'policyvers': 'unknown'}, 'selinux_python_present': True}

# Generated at 2022-06-23 01:48:44.560597
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.processor.selinux import SelinuxFactProcessor
    from ansible.module_utils.facts.processors import Processor

    selinux_dict = {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'status': 'disabled',
            'type': 'unknown'
        },
        'selinux_python_present': False
    }

    # Patch the selinux module
    import sys
    if not HAS_SELINUX:
        sys.modules['selinux'] = None

    # Mock the Collector class

# Generated at 2022-06-23 01:48:45.956622
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:48:47.160710
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None

# Generated at 2022-06-23 01:48:52.007515
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys

    if sys.version_info[0] >= 3:
        # Note: selinux does not support Python 3
        assert not HAVE_SELINUX
    else:
        assert HAVE_SELINUX
        selinuxfactcol = SelinuxFactCollector()
        assert selinuxfactcol.name == 'selinux'
        assert selinuxfactcol._fact_ids == set()

# Generated at 2022-06-23 01:48:57.928736
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = dict(
        SELINUX_python_present=True,
        selinux=dict(
            status=None,
            policyvers=None,
            config_mode=None,
            mode=None,
            type=None
        )
    )
    c = SelinuxFactCollector()
    assert c.collect() == selinux_facts

# Generated at 2022-06-23 01:49:01.213675
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    test_collector = SelinuxFactCollector()

    assert test_collector.name == 'selinux'
    assert len(test_collector._fact_ids) == 0

    test_collector.collect()

# Generated at 2022-06-23 01:49:15.150515
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic

    selinux_python_present = False
    environ_ = {}
    basic._ANSIBLE_ARGS = None

    # Testing status when selinux python library is not present
    module = basic.AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=[], required=False),
        )
    )
    mock_module = module
    collector = SelinuxFactCollector(module=mock_module)
    facts = collector.collect()
    assert facts['selinux'] == {'status': 'Missing selinux Python library'}
    assert facts['selinux_python_present'] == False

    # Testing when selinux is enabled and selinux Python library is present
    environ_['SELINUXENABLED'] = '1'
    se

# Generated at 2022-06-23 01:49:20.875708
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test with selinux library present
    x = SelinuxFactCollector()
    assert x.collect()['selinux_python_present'] == True

    # Test with selinux library not present
    class MockSelinuxModule(object):
        pass
    x = SelinuxFactCollector()
    assert x.collect()['selinux_python_present'] == False
# End Unit test for constructor of class SelinuxFactCollector

# Generated at 2022-06-23 01:49:27.782656
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.selinux import selinux

    module_mock = Mock()
    collected_facts_mock = Mock()
    
    fact_collector = SelinuxFactCollector(module_mock, collected_facts_mock)

    # if selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    # In this case, the test does not execute the 'else' clause
    selinux_collector_mock = Mock(side_effect=ImportError)

# Generated at 2022-06-23 01:49:37.236568
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import tempfile

    module = None

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 01:49:47.878446
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import CollectorsRegistry
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.network.selinux

    # Check that the FactCollector class is registered in the CollectorsRegistry
    # assert FactCollector not in CollectorsRegistry.classes
    assert SelinuxFactCollector in CollectorsRegistry.classes

    # Check that the class is a subclass of BaseFactCollector
    assert issubclass(SelinuxFactCollector, BaseFactCollector)

    # Create a new object
    selinux_fact_collector = SelinuxFactCollector()

    # Check that it is an object of the class
    assert isinstance

# Generated at 2022-06-23 01:49:56.715915
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collection_not_possible = {'status': 'Missing selinux Python library', 'python_present': False}
    collection_missing_selinux_library = {
        'status': 'disabled',
        'python_present': True
    }
    collection_disabled = {
        'status': 'enabled',
        'policyvers': 'unknown',
        'config_mode': 'unknown',
        'type': 'unknown',
        'mode': 'unknown',
        'python_present': True
    }
    collection_enabled = {
        'status': 'enabled',
        'policyvers': '29',
        'config_mode': 'permissive',
        'type': 'targeted',
        'mode': 'permissive',
        'python_present': True
    }

    original_import = __import__
