

# Generated at 2022-06-23 01:40:04.984178
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    fake_selinux_collector = SelinuxFactCollector()
    facts_dict = {}
    selinux_facts = {}

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        selinux_facts['status'] = 'disabled'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
        return facts_dict

    # Set a boolean for testing whether the Python library is present
    facts_dict['selinux_python_present'] = True


# Generated at 2022-06-23 01:40:09.211622
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    # assert isinstance(s, SelinuxFactCollector)
    assert s.name == 'selinux'
    assert isinstance(s._fact_ids, set)
    assert not s._fact_ids

# Generated at 2022-06-23 01:40:17.806196
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # mock the selinux library
    selinux_mock = Mock()
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = 'policysetversion'
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, 'target')
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    sys.modules['ansible.module_utils.compat.selinux'] = selinux_mock

    # mock the value returned from super class
    basefactcollector_mock = Mock()
    basefactcollector_mock.collect.return_value = {}



# Generated at 2022-06-23 01:40:28.132872
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  import mock

  def selinux_getpolicytype(self):
    return 0, 'targeted'

  def selinux_getenforcemode(self):
    return 0, 1

  def security_policyvers(self):
    return 30

  def security_getenforce(self):
    return 1

  def is_selinux_enabled(self):
    return True

  selinux_dict = {
    'selinux_getpolicytype' : selinux_getpolicytype,
    'selinux_getenforcemode' : selinux_getenforcemode,
    'security_policyvers' : security_policyvers,
    'security_getenforce' : security_getenforce,
    'is_selinux_enabled' : is_selinux_enabled,
  }


# Generated at 2022-06-23 01:40:38.018621
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    # Set up a module with a dummy directory
    module = AnsibleModule(argument_spec={})
    collected_facts = {}
    selinux_facts = selinux_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts   # This will be set to False if the selinux library is missing
    if selinux_facts['selinux'] != 'disabled':
        assert 'policyvers' in selinux_facts['selinux']
        assert 'config_mode' in selinux_facts['selinux']
        assert 'mode' in selinux_

# Generated at 2022-06-23 01:40:40.175293
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:40:47.452706
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
    assert selinux_fact_collector.collect() == dict()

# Generated at 2022-06-23 01:40:57.588520
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    c = SelinuxFactCollector()

    # Test without the selinux library present
    facts_dict = {}
    selinux.is_selinux_enabled = None
    facts_dict = c.collect(collected_facts=facts_dict)
    assert facts_dict['selinux']
    assert facts_dict['selinux_python_present'] == False
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    selinux.is_selinux_enabled = is_selinux_enabled = selinux.is_selinux_enabled()

    # Test with the selinux library present
    facts_dict['selinux'] = None
    facts_dict['selinux_python_present'] = None

# Generated at 2022-06-23 01:41:03.209779
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    test = SelinuxFactCollector()
    assert test.name == 'selinux'
    assert isinstance(test._fact_ids, set)
    assert test._fact_ids == set()

# Generated at 2022-06-23 01:41:14.184023
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux is not installed on the system, then only status and selinux_python_present
    # will be set.
    with mock.patch.dict(sys.modules, {'selinux':None}):
        s = SelinuxFactCollector()
        result = s.collect()

        assert result['selinux_python_present'] == False
        assert 'status' in result['selinux']
        assert result['selinux']['status'] == 'Missing selinux Python library'
        assert 'config_mode' not in result['selinux']
        assert 'mode' not in result['selinux']
        assert 'policyvers' not in result['selinux']
        assert 'type' not in result['selinux']

    # If selinux is installed, then check to see if the module library is imported
   

# Generated at 2022-06-23 01:41:16.639459
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-23 01:41:18.941633
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'
    assert s._fact_ids == {'selinux', 'selinux_python_present'}

# Generated at 2022-06-23 01:41:20.452333
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # check if instance is created for class SelinuxFactCollector
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:41:22.106772
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:41:26.989663
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxCollector = SelinuxFactCollector()
    assert selinuxCollector.name == 'selinux'
    assert not selinuxCollector._fact_ids
    assert selinuxCollector.collect()['selinux']['status'] == 'disabled'
    assert selinuxCollector.collect()['selinux_python_present'] == True

# Generated at 2022-06-23 01:41:37.101239
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test the output of the collect method on a SelinuxFactCollector """
    # Create the object
    selinux_fc = SelinuxFactCollector()

    # Test only the selinux facts are present
    selinux_facts = selinux_fc.collect()
    # The selinux fact should be present
    assert 'selinux' in selinux_facts
    # The selinux_python_present fact should be present
    assert 'selinux_python_present' in selinux_facts
    # There should only be 2 facts
    assert len(selinux_facts.keys()) == 2

    # Test the selinux_python_present fact is the correct value
    if HAVE_SELINUX:
        assert selinux_facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:41:40.857658
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-23 01:41:43.301115
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert "selinux" in fact_collector._fact_ids


# Generated at 2022-06-23 01:41:54.895916
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect()
    """

    def mock_selinux_is_selinux_enabled(self):
        return False

    if HAVE_SELINUX:
        # Overwrite selinux.is_selinux_enabled() to make the unit test pick the code path of
        # the non-HAVE_SELINUX case.
        selinux.is_selinux_enabled = mock_selinux_is_selinux_enabled

    sfc = SelinuxFactCollector()

    # Unit test for when there is no selinux library
    facts_dict = sfc.collect()
    assert facts_dict['selinux_python_present'] is False

    # Unit test for other cases
    selinux_facts = facts_dict['selinux']
    assert 'status'

# Generated at 2022-06-23 01:41:57.940458
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux_python_present'] == True

# Generated at 2022-06-23 01:42:00.944074
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.collect()['selinux']['status'] == 'enabled'
    assert sfc.collect()['selinux_python_present'] == True

# Generated at 2022-06-23 01:42:08.138911
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # a minimal fake selinux module
    class FakeSelinux:
        def is_selinux_enabled(self):
            return True

        def security_getenforce(self):
            return 1

        def selinux_getenforcemode(self):
            return (0, 0)

        def security_policyvers(self):
            return 28

        def selinux_getpolicytype(self):
            return (0, "targeted")

    # patch selinux module and module_utils.facts.collector.BaseFactCollector.collect
    monkeypatch.setattr(selinux, "is_selinux_enabled", FakeSelinux.is_selinux_enabled)
    monkeypatch.setattr(selinux, "security_getenforce", FakeSelinux.security_getenforce)
    monkeypatch.setattr

# Generated at 2022-06-23 01:42:17.590016
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collectors.selinux

    # Test for the case where the selinux library is present
    # This test does not test for the case where the library is actually
    # missing. Just for the case where it is present
    collector.collectors['selinux'] = ansible.module_utils.facts.collectors.selinux.SelinuxFactCollector()
    ansible.module_utils.facts.collectors.selinux.HAVE_SELINUX = True
    selinux_facts_dict = collector.collectors['selinux'].collect()

    assert 'selinux' in selinux_facts_dict
    assert 'status' in selinux_facts_dict['selinux']
    assert 'policyvers' in selinux

# Generated at 2022-06-23 01:42:27.540215
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test if the collect method of class SelinuxFactCollector returns
    the right facts when the selinux Python library is present.
    """
    # Test with selinux enabled
    if HAVE_SELINUX:
        selinux_facts = {}

        selinux_facts['status'] = 'enabled'

        selinux_facts['policyvers'] = selinux.security_policyvers()

        (rc, configmode) = selinux.selinux_getenforcemode()
        if rc == 0:
            selinux_facts['config_mode'] = SELINUX_MODE_DICT.get(configmode, 'unknown')
        else:
            selinux_facts['config_mode'] = 'unknown'

        mode = selinux.security_getenforce()
        selinux_facts['mode'] = SELINUX_MODE

# Generated at 2022-06-23 01:42:34.327815
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    assert SelinuxFactCollector.collector == SelinuxFactCollector.collect

# Generated at 2022-06-23 01:42:39.935200
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux', 'SelinuxFactCollector.name return incorrect value'
    assert obj._fact_ids == set(), 'SelinuxFactCollector._fact_ids return incorrect value'

# Generated at 2022-06-23 01:42:42.551209
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:42:52.340384
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = {}
    selinux_facts = {}

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
        print("The result of test_SelinuxFactCollector is ", facts_dict)
        return facts_dict

    # Set a boolean for testing whether the Python library is present
    facts_dict['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        selinux

# Generated at 2022-06-23 01:42:56.456080
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:42:58.807497
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()
    facts_dict = selinux.collect()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 01:42:59.686269
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:43:00.776020
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:43:10.233942
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = type('module', (object,), {'exit_json': lambda self, **kwargs: None, 'fail_json': lambda self, msg: None})
    mock_module_instance = mock_module()
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect(module=mock_module_instance)
    assert 'status' in facts['selinux'].keys(), "Status not set in selinux fact if selinux module is not present"

# Generated at 2022-06-23 01:43:17.403981
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

    selinux_fact_collector = SelinuxFactCollector(name='test_name',
                                                  fact_ids=set(['test_fact_id']))
    assert selinux_fact_collector.name == 'test_name'
    assert selinux_fact_collector._fact_ids == set(['test_fact_id'])

if __name__ == '__main__':
    test_SelinuxFactCollector()

# Generated at 2022-06-23 01:43:19.367345
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector_obj = SelinuxFactCollector()
    assert isinstance(SelinuxFactCollector_obj.collect(), dict)

# Generated at 2022-06-23 01:43:22.736332
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:43:30.338658
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    sepath = os.path.join(tmpdir, 'selinux')
    os.mkdir(sepath)

    # Create selinux config file in the temporary directory
    selinux_config_file = os.path.join(sepath, 'config')
    selinux_config_mode = 'disabled'
    f = open(selinux_config_file, 'w')
    f.write('SELINUX=' + selinux_config_mode)
    f.close()

    # Create sepolicy file in the temporary directory
    selinux_policy_file = os.path.join(sepath, 'policy.30')
    f = open(selinux_policy_file, 'w')

# Generated at 2022-06-23 01:43:32.823973
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj != None

# Generated at 2022-06-23 01:43:42.074301
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()

    if HAVE_SELINUX:
        assert 'selinux_python_present' in selinux_facts
        assert 'selinux' in selinux_facts
        assert 'status' in selinux_facts['selinux'].keys()
        assert 'policyvers' in selinux_facts['selinux'].keys()
        assert 'config_mode' in selinux_facts['selinux'].keys()
        assert 'mode' in selinux_facts['selinux'].keys()
        assert 'type' in selinux_facts['selinux'].keys()
        assert True == selinux_facts['selinux_python_present']
        assert True == selinux_facts['selinux']['status'] in ['enabled', 'disabled']

# Generated at 2022-06-23 01:43:45.442496
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = {}
    collected_facts = {}
    obj = SelinuxFactCollector()
    obj.collect(module, collected_facts)


# Generated at 2022-06-23 01:43:48.067522
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test that the name is set to selinux
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:43:55.686213
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fake_collector = SelinuxFactCollector()
    data = fake_collector.collect()
    assert data['ansible_facts']['selinux']['type'] != 'unknown'
    assert data['ansible_facts']['selinux']['status'] != 'unknown'
    assert data['ansible_facts']['selinux']['policyvers'] != 'unknown'
    assert data['ansible_facts']['selinux']['mode'] != 'unknown'
    assert data['ansible_facts']['selinux']['config_mode'] != 'unknown'
    assert data['ansible_facts']['selinux_python_present'] is True

# Generated at 2022-06-23 01:43:59.396472
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:44:01.474168
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:44:04.620773
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # selinux library not present
    global HAVE_SELINUX
    HAVE_SELINUX = False
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:44:09.028249
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()
    assert collector.has_all_required_facts('anyhost')


# Generated at 2022-06-23 01:44:17.422197
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    test_facts_dict =  selinux_fact_collector.collect()

    assert 'selinux_python_present' in test_facts_dict

    if test_facts_dict['selinux_python_present']:
        assert 'selinux' in test_facts_dict
        assert 'status' in test_facts_dict['selinux']
        assert 'mode' in test_facts_dict['selinux']
        assert 'policyvers' in test_facts_dict['selinux']
        assert 'type' in test_facts_dict['selinux']

# Generated at 2022-06-23 01:44:23.167902
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:44:28.170720
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create a test SelinuxFactCollector object
    selinux_fact_collector_obj = SelinuxFactCollector()
    # call the method collect
    selinux_fact_collector_obj.collect()
    #assert the data returned by the collect method
    assert selinux_fact_collector_obj.collect() == {'selinux': {'config_mode': 'unknown', 'type': 'unknown', 'mode': 'unknown'}, 'selinux_python_present': True}

# Generated at 2022-06-23 01:44:33.779097
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = dict(selinux=dict(status='enabled',
                                      mode='enforcing',
                                      config_mode='permissive',
                                      policyvers='42',
                                      type='base'
                                     ),
                         selinux_python_present=True
                        )
    sfc = SelinuxFactCollector()
    assert (selinux_facts == sfc.collect())


# Generated at 2022-06-23 01:44:39.343701
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']

# Generated at 2022-06-23 01:44:42.848245
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:44:47.096397
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test SelinuxFactCollector
    """
    selinux_collector = SelinuxFactCollector()

    assert selinux_collector.name == 'selinux', \
        'Incorrect constructor for SelinuxFactCollector'

# Generated at 2022-06-23 01:44:55.157529
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import os
    if selinux.is_selinux_enabled():
        facts_dict = SelinuxFactCollector().collect()
        assert 'selinux_python_present' in facts_dict
        assert 'selinux' in facts_dict
        assert facts_dict['selinux']['status'] in ['enabled', 'disabled']
        assert facts_dict['selinux']['config_mode'] in ['enforcing', 'permissive']
        assert facts_dict['selinux']['mode'] in ['enforcing', 'permissive']
        assert facts_dict['selinux']['type'] in os.listdir('/selinux')
    else:
        facts_dict = SelinuxFactCollector().collect()
        assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-23 01:45:05.154891
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock ansible_facts
    ansible_facts = {}

    # Create a mock module
    module = None

    # Create a SelinuxFactCollector object to get the facts from selinux
    sfc = SelinuxFactCollector()

    # Collect the facts
    sfc.collect(module=module, collected_facts=ansible_facts)

    # Verify the facts are correct
    if HAVE_SELINUX:
        expected_facts = {'selinux': {'status': 'enabled',
                                      'config_mode': 'unknown',
                                      'mode': 'unknown',
                                      'type': 'unknown'},
                          'selinux_python_present': True}

# Generated at 2022-06-23 01:45:07.849635
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector."""
    x = SelinuxFactCollector()
    assert type(x.collect()) == dict

# Generated at 2022-06-23 01:45:09.310422
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    result = SelinuxFactCollector()

    assert result is not None

# Generated at 2022-06-23 01:45:11.493527
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:45:22.986180
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Make sure the fact collector methods are working as expected.
    """
    facts_dict = dict()
    # Try with the selinux library present
    if HAVE_SELINUX:
        my_collector = SelinuxFactCollector()
        facts_dict = my_collector.collect()
        expected_output = {
            'selinux': {
                'status': 'enabled',
                'policyvers': '29',
                'config_mode': 'permissive',
                'mode': 'permissive',
                'type': 'targeted'
            },
            'selinux_python_present': True
        }
        assert facts_dict == expected_output
    # Try with the selinux library missing
    if not HAVE_SELINUX:
        my_collector = SelinuxFactCollector()
       

# Generated at 2022-06-23 01:45:25.970678
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:45:31.105690
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # For now, just check that the method runs without error.
    # It's hard to do good unit testing of this code since it depends
    # on having a live system with SELinux enabled to check the values.
    # TODO: write a better test
    collector = SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:45:35.449359
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This method tests the collect method of Ansible's Selinux Fact Collector. The
    collect method is responsible for gathering facts related to SELinux.

    The facts are tested against a known result to make sure they are gathered correctly.
    """
    fake_module = object()
    fake_collected_facts = {}
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect(module=fake_module, collected_facts=fake_collected_facts)
    assert type(result) is dict
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert 'policyvers' in result['selinux']
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']


# Generated at 2022-06-23 01:45:41.974827
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux', 'The name of the instance should be selinux'
    assert fact_collector._fact_ids == set(), '_fact_ids should be empty set'

# Generated at 2022-06-23 01:45:50.735097
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import cached
    from ansible.module_utils.compat import sys_info

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Importing selinux will import module_utils.selinux, which is patched by selinux/test_selinux.py
    # to return some fake values.  This patch is done for any selinux/ test file and any selinux related
    # code in basic/ to prevent needing to actually configure SELinux.
    try:
        import selinux
    except ImportError:
        selinux = None

    # Save the original os.uname value in case it is needed elsewhere

# Generated at 2022-06-23 01:45:57.808953
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # print(selinux.is_selinux_enabled())
    print('Test: test_SelinuxFactCollector_collect')
    sfc = SelinuxFactCollector()
    print(sfc.collect())
    print('End test: test_SelinuxFactCollector_collect')


# Generated at 2022-06-23 01:46:02.332983
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""
    # pylint: disable=line-too-long
    data = {'selinux': {'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown', 'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    assert SelinuxFactCollector().collect() == data


# Generated at 2022-06-23 01:46:04.890053
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'



# Generated at 2022-06-23 01:46:07.336247
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:46:09.651921
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    print(SelinuxFactCollector.__name__)



# Generated at 2022-06-23 01:46:12.662942
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    r = SelinuxFactCollector().collect()

    # test if variable r is not empty
    assert r != {}
    assert r['selinux_python_present'] == True

    # test the return if selinux library is not present
    import sys
    sys.modules['ansible.module_utils.compat'].selinux = None
    r = SelinuxFactCollector().collect()
    assert r['selinux_python_present'] == False

# Generated at 2022-06-23 01:46:15.529360
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:46:17.305647
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == {'selinux_python_present'}

# Generated at 2022-06-23 01:46:24.369979
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Test case for unit testing method collect of class SelinuxFactCollector
    '''
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact = selinux_fact_collector.collect()

    assert type(selinux_fact) == type({})
    assert 'selinux' in selinux_fact
    assert type(selinux_fact['selinux']) == type({})
    assert 'selinux_python_present' in selinux_fact

# Generated at 2022-06-23 01:46:32.333451
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        from ansible.module_utils.compat import selinux
    except ImportError:
        SELINUX_LIBRARY_PRESENT = False
    else:
        SELINUX_LIBRARY_PRESENT = True

    # Test for selinux Python library present
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'
    assert sf._fact_ids == set()

    facts_dict = sf.collect()
    assert 'selinux_python_present' in facts_dict
    assert facts_dict['selinux_python_present'] == SELINUX_LIBRARY_PRESENT
    if SELINUX_LIBRARY_PRESENT:
        assert 'selinux' in facts_dict

        # Test for status: disabled when selinux is disabled

# Generated at 2022-06-23 01:46:39.387698
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_object = SelinuxFactCollector()
    selinux_facts = {}

    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = '28'
    selinux_facts['config_mode'] = 'enforcing'
    selinux_facts['mode'] = 'enforcing'
    selinux_facts['type'] = 'targeted'

    selinux_facts_dict = {'selinux': selinux_facts}
    assert selinux_object.collect() == selinux_facts_dict

# Generated at 2022-06-23 01:46:44.797246
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  x = SelinuxFactCollector()
  assert x
  assert x.name == 'selinux'
  assert x._fact_ids == set()
  assert isinstance(x._fact_ids, set)


# Generated at 2022-06-23 01:46:47.359469
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test case for method collect of class SelinuxFactCollector"""
    collector = SelinuxFactCollector()

    # Get the facts
    facts = collector.collect()

    # Assert the facts
    assert facts['selinux_python_present'] is True

# Generated at 2022-06-23 01:46:48.794316
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'

# Generated at 2022-06-23 01:46:54.639587
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest

    selinux_facts = {'config_mode': 'enforcing',
                     'mode': 'enforcing',
                     'status': 'enabled',
                     'type': 'targeted'}
    testcfg = {'selinux': selinux_facts,
               'selinux_python_present': True}

    collector_mock = SelinuxFactCollector()
    assert collector_mock.collect() == testcfg


# Generated at 2022-06-23 01:46:55.903435
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:47:03.391191
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''
    Test constructor of SelinuxFactCollector.

    Ansible facts modules are instantiated by passing a dict to their class
    constructor.  By calling the class constructor, information about the
    available processor architectures are determined at runtime.  We have added
    a test for this which uses the internal Ansible facts module for processors
    to get all available architectures.  The internal facts module prints its
    output to stdout, so we save the output so we can test the results.

    :return:
    '''

    selinux_fact_collector = SelinuxFactCollector({})
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids
    assert selinux_fact_collector.options is None

# Generated at 2022-06-23 01:47:06.003676
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:47:11.309446
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''test SelinuxFactCollector constructor'''
    x = SelinuxFactCollector()
    assert x is not None

# Generated at 2022-06-23 01:47:13.185657
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_factcollector = SelinuxFactCollector()
    selinux_factcollector.collect()

# Generated at 2022-06-23 01:47:18.063946
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector.collect() == {'selinux': {'status': 'disabled'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:47:22.349773
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module_mock = Mock()
    selinux_collector = SelinuxFactCollector()

    # Method collect called without args
    selinux_collector.collect(module_mock, None)

    # Method collect called with args
    selinux_collector.collect(module_mock, None)

# Generated at 2022-06-23 01:47:24.871442
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfact = SelinuxFactCollector()
    assert selinuxfact
    assert selinuxfact.name == 'selinux'
    assert selinuxfact._fact_ids == set()


# Generated at 2022-06-23 01:47:28.543808
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# vim: expandtab:ts=4:sw=4

# Generated at 2022-06-23 01:47:30.711720
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:47:32.472519
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect(collector=None, module=None, collected_facts=None)

# Generated at 2022-06-23 01:47:42.802956
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Verify that SelinuxFactCollector can collect facts
    """
    # Create the SelinuxFactCollector object
    collector = SelinuxFactCollector()

    # Run the collect method
    collected_facts = collector.collect()

    # Expected dictionary based on the return from selinux.is_selinux_enabled
    expected_dict = {
        'selinux': {
            'status': 'enabled',
            'config_mode': 'permissive',
            'mode': 'permissive',
            'type': 'targeted',
            'policyvers': '28'
        },
        'selinux_python_present': True
    }

    # Compare the collected facts and the expected dictionary
    assert collected_facts == expected_dict

    # Run the collect method using a mocked sys.platform

# Generated at 2022-06-23 01:47:52.957892
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Boolean to indicate if the SELinux Python library is present
    selinux_python_present = True

    # SELinux status
    status = 'disabled'

    # Dictionary of SELinux facts
    selinux_facts_dict = {
        'status': status,
        'mode': 'unknown',
        'config_mode': 'unknown',
        'policyvers': 'unknown',
        'type': 'unknown'
    }

    # Dictionary of all collected facts
    collected_facts = {'selinux': selinux_facts_dict}

    # Create SelinuxFactCollector object with mock selinux library
    selinux_facts = SelinuxFactCollector(module=None, collected_facts=collected_facts)

    # Call collect method from SelinuxFactCollector object
    return_facts = selinux_facts

# Generated at 2022-06-23 01:47:58.421449
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector(None)
    assert 'selinux' in c.name


# Generated at 2022-06-23 01:48:02.189100
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-23 01:48:03.731260
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:48:06.477549
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect()


# Generated at 2022-06-23 01:48:09.301086
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()

    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids is not None

# Generated at 2022-06-23 01:48:11.339871
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:48:19.811464
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class FakeModule(object):
        def __init__(self, params={}):
            self.params = params

        def get_bin_path(self, arg, opt_dirs=[]):
            bins = {
                'getenforce': 'getenforce',
                'sestatus': 'sestatus',
                'selinuxenabled': 'selinuxenabled',
                'semanage': 'semanage'
            }
            return bins.get(arg)

    # if Python library is missing, only check if the status and selinux_python_present are set
    if not HAVE_SELINUX:
        # test that collect method sets correct status and selinux_python_present if selinux
        # Python library is not installed
        m = FakeModule()
        n = SelinuxFactCollector()
        facts = n

# Generated at 2022-06-23 01:48:20.743937
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:48:32.087232
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Reset the SElinux state
    selinux.setenforce(0)

    # SELinux is disabled
    selinux_facts = {}
    selinux_facts['status'] = 'disabled'
    selinux_facts['config_mode'] = 'unknown'
    selinux_facts['mode'] = 'unknown'
    selinux_facts['type'] = 'unknown'
    selinux_facts['policyvers'] = 'unknown'
    collected_facts = {'selinux': selinux_facts, 'selinux_python_present': True}
    assert collected_facts == SelinuxFactCollector().collect()

    # SELinux is enabled
    selinux.setenforce(1)
    selinux_facts = {}
    selinux_facts['status'] = 'enabled'

# Generated at 2022-06-23 01:48:37.243051
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.compat import selinux

    if selinux.is_selinux_enabled():
        selinux_instance = SelinuxFactCollector()
        assert isinstance(selinux_instance, SelinuxFactCollector)
        assert isinstance(selinux_instance, BaseFactCollector)

# Generated at 2022-06-23 01:48:44.649472
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector.collect() == {}
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:48:50.674762
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    from ansible.module_utils.facts import collector
    import sys

    # load the available collectors
    collector.load_collectors([])

    # create an instance of SelinuxFactCollector
    sfc = collector._get_collector('selinux')
    assert type(sfc) is SelinuxFactCollector

    # call the collect method
    facts = sfc.collect(module=None)

    # verify that the selinux fact is in the fact dict
    assert 'selinux' in facts

# Generated at 2022-06-23 01:49:01.540004
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test with selinux module mock
    fact_collector = SelinuxFactCollector()

    selinux_facts = {}
    expected_selinux_facts = {
        'status': 'enabled',
        'policyvers': '28',
        'config_mode': 'permissive',
        'mode': 'permissive',
        'type': 'targeted'
    }
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = '28'
    selinux_facts['config_mode'] = 'permissive'
    selinux_facts['mode'] = 'permissive'
    selinux_facts['type'] = 'targeted'

    facts_dict = fact_collector.collect()

    assert facts_dict['selinux'] == expected_selinux_facts


# Generated at 2022-06-23 01:49:05.618862
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:49:10.921522
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test class constructor"""
    obj = SelinuxFactCollector()
    assert obj
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-23 01:49:21.824633
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # noinspection PyUnresolvedReferences
    selinux = SelinuxFactCollector()

    # If there is no library, selinux_python_present is set to True
    # and selinux.selinux_is_enabled() is set to False.
    if HAVE_SELINUX:
        # noinspection PyUnusedLocal
        def mock_is_selinux_enabled(self):
            return True

        # noinspection PyUnusedLocal
        def mock_security_policyvers(self):
            return "24"

        selinux.is_selinux_enabled = mock_is_selinux_enabled
        selinux.security_policyvers = mock_security_policyvers
    selinux_facts = selinux.collect()

    # Verify the contents of the selinux facts

# Generated at 2022-06-23 01:49:23.255619
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector

# Generated at 2022-06-23 01:49:26.388504
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Call the constructor and make sure it returns an object
    assert SelinuxFactCollector()

# Unit test cases for fact collection,
# testing the dictionary returned with key 'selinux'

# Generated at 2022-06-23 01:49:31.237586
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Set HAVE_SELINUX to False to indicate the selinux library is not present
    global HAVE_SELINUX
    HAVE_SELINUX = False

    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert len(sfc._fact_ids) == 0


# Generated at 2022-06-23 01:49:33.587293
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    fact_dict = selinux_fact_collector.collect()
    assert isinstance(fact_dict, dict)

# Generated at 2022-06-23 01:49:45.321341
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collection import FactsCollector

    mod_mock = MagicMock()

    fact_collector = SelinuxFactCollector(module=mod_mock)

    # If HAVE_SELINUX is False, the status will be set to disabled
    # and there will be no other fact keys.
    facts = fact_collector.collect(module=mod_mock)
    assert facts['selinux']['status'] == 'disabled'
    selinux_keys = list(facts['selinux'].keys())
    assert len(selinux_keys) == 1

    # Set HAVE_SELINUX to True so we can test the method
    # using the selinux Python library.
    HAVE_SELINUX = True

    # Set up the selinux module.
    mock_sel

# Generated at 2022-06-23 01:49:47.303750
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = SelinuxFactCollector()
    assert fact.collect() is not None

# Generated at 2022-06-23 01:49:50.122939
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    collected_facts = fact_collector.collect()
    assert collected_facts['selinux'] is not None

# Generated at 2022-06-23 01:49:52.238819
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    t = SelinuxFactCollector()
    assert t.name == 'selinux'
    assert t._fact_ids is not None

# Generated at 2022-06-23 01:49:56.288918
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()