

# Generated at 2022-06-23 01:39:58.797993
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-23 01:40:02.556626
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Construct an instance of the SelinuxFactCollector class
    selinux_collector = SelinuxFactCollector()

    # Unit test for constructor of SelinuxFactCollector class
    assert isinstance(selinux_collector, SelinuxFactCollector)


# Generated at 2022-06-23 01:40:11.718171
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    # Mock the selinux library
    import sys
    sys.modules['selinux'] = None
    # Expecting the status to be 'Missing selinux Python library' and
    # selinux_python_present to be False
    expected = {
        'selinux': {'status': 'Missing selinux Python library'},
        'selinux_python_present': False
    }
    assert collector.collect() == expected

    # Reset the selinux library
    # Mock the selinux is_selinux_enabled function
    class MockSelLinux(object):
        @staticmethod
        def is_selinux_enabled():
            return False

    sys.modules['selinux'] = MockSelLinux
    # Expecting the status to be 'disabled' and
    # selinux_python_present

# Generated at 2022-06-23 01:40:14.482329
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == {'selinux', 'selinux_python_present'}


# Generated at 2022-06-23 01:40:18.148848
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Constructor of class SelinuxFactCollector should accept
    # BaseFactCollector
    selinux_fact_collector = SelinuxFactCollector(BaseFactCollector)

# Generated at 2022-06-23 01:40:25.014488
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test the constructor of the class SelinuxFactCollector"""
    selinux_fact_collector = SelinuxFactCollector()

    assert ('selinux' in selinux_fact_collector.name)
    assert (selinux_fact_collector._fact_ids == set())

    selinux_fact_collector.collect()
    assert (selinux_fact_collector._fact_ids == set())

# Generated at 2022-06-23 01:40:25.622443
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-23 01:40:35.854745
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Constructor creates empty fact_ids set
    # Mocked version of selinux module isn't actually used, just needs to be present to
    # avoid early exit when checking if selinux library is present
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = 543
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'Targeted')
    collector = SelinuxFactCollector({}, selinux)
    # Empty facts_dict
    facts_dict = {}
    # Empty selinux_facts
    selinux_facts = {}
    # Expected

# Generated at 2022-06-23 01:40:38.046223
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)

# Generated at 2022-06-23 01:40:45.136871
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # get an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # print facts collected
    selinux_facts = selinux_fact_collector.collect()
    print(selinux_facts)
    assert('selinux' in selinux_facts)
    assert('status' in selinux_facts['selinux'])
    assert('mode' in selinux_facts['selinux'])
    assert('config_mode' in selinux_facts['selinux'])
    assert('type' in selinux_facts['selinux'])


# Generated at 2022-06-23 01:40:48.846981
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    # Assert that _fact_ids is a set
    assert isinstance(selinux_collector._fact_ids, set)
    # Assert that _fact_ids is empty
    assert not selinux_collector._fact_ids


# Generated at 2022-06-23 01:40:54.328692
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None
    SelinuxFactCollector = SelinuxFactCollector()
    facts_dict = SelinuxFactCollector.collect(module,collected_facts)
    print("facts_dict:")
    print(facts_dict)

if __name__ == '__main__':
    # Unit test
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:41:06.472930
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import Facts
    import ansible.utils.selinux as selinux
    import ansible.module_utils.selinux as selinux_mod

    # Initialize the Facts class with a dictionary so Ansible modules can use it
    facts = Facts({})
    fact_collector = facts.collectors['selinux']

    # Create a mock SELinux module to override the actual one
    # _is_selinux_enabled method will return True
    mock_selinux = type('MockSELinux', (object,), {'is_selinux_enabled': lambda *args: True})
    selinux.SELinux = mock_selinux

    # Create a mock selinux_mod module so we can mock the selinux_getenforcemode function
    # and selinux_

# Generated at 2022-06-23 01:41:09.439867
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_collector = SelinuxFactCollector()
    assert test_collector.name == 'selinux'
    assert test_collector._fact_ids == set()


# Generated at 2022-06-23 01:41:14.557667
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'


# Generated at 2022-06-23 01:41:26.115564
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'

# Generated at 2022-06-23 01:41:27.682194
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:41:36.857462
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    mocked_selinux_lib = mock.MagicMock()

    mocked_selinux_lib.is_selinux_enabled.return_value = True
    mocked_selinux_lib.security_policyvers.return_value = 3
    mocked_selinux_lib.selinux_getenforcemode.return_value = (0, 2)
    mocked_selinux_lib.security_getenforce.return_value = 0
    mocked_selinux_lib.selinux_getpolicytype.return_value = (0, 'targeted')

    with mock.patch('ansible.module_utils.compat.selinux', new=mocked_selinux_lib):
        test_obj = SelinuxFactCollector()

# Generated at 2022-06-23 01:41:41.428514
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = SelinuxFactCollector().collect()
    assert selinux_dict['selinux_python_present'] == True
    assert sorted(selinux_dict['selinux'].keys()) == ['config_mode', 'mode', 'policyvers', 'status', 'type']

# Generated at 2022-06-23 01:41:44.020373
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:41:48.370716
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert isinstance(sfc, SelinuxFactCollector)

# Generated at 2022-06-23 01:41:52.967022
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'
    assert fc._fact_ids is not None

# Generated at 2022-06-23 01:41:54.960452
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    my_obj = SelinuxFactCollector()
    assert my_obj.name == 'selinux'

# Generated at 2022-06-23 01:42:04.253981
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = None
    mock_collected_facts = None
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect(mock_module, mock_collected_facts)

    assert 'selinux_python_present' in facts_dict
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    if facts_dict['selinux_python_present']:
        if facts_dict['selinux']['status'] == 'enabled':
            assert 'config_mode' in facts_dict['selinux']
            assert 'type' in facts_dict['selinux']
            assert 'mode' in facts_dict['selinux']

# Generated at 2022-06-23 01:42:08.993289
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_obj = SelinuxFactCollector()
    assert test_obj.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:42:18.623310
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Test case for SelinuxFactCollector's collect method
    '''
    collector = SelinuxFactCollector()

    # test if status is set to 'Missing selinux Python library'
    # and no other fields of the dict are set
    test_collector = SelinuxFactCollector()
    test_collector.HAVE_SELINUX = False
    test_dict = test_collector.collect()
    assert test_dict['selinux'] == {'status':'Missing selinux Python library'}
    assert len(test_dict['selinux']) == 1
    assert test_dict['selinux_python_present'] == False

    # test if status is set to 'enabled' and other fields are set
    # even if no library is present to set their values
    test_collector = Selin

# Generated at 2022-06-23 01:42:30.355591
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ''' selinux facts are a list of dicts
        [ { 'name': 'selinux',
            'status': 'enabled',
            'config_mode': 'enforcing',
            'mode': 'enforcing',
            'policyvers': 31,
            'type': 'targeted'
          },
        ]
    '''

    # In order to detect SELinux as enabled or disabled,
    # there are different commands used by the Python library
    # depending on the operating system.
    # In order to test this fact collection without the real commands,
    # the Python library has to be monkey patched to use what the test
    # wants, rather than the system commands.
    # This import is here because it must be after the python library patching
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollect

# Generated at 2022-06-23 01:42:38.639682
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # create the test object
    test_obj = SelinuxFactCollector()

    # test missing selinux python library
    mock_HAVE_SELINUX = False
    mock_selinux_is_selinux_enabled = None
    retval = test_obj.collect()
    assert retval['selinux']['status'] == 'Missing selinux Python library'
    assert retval['selinux_python_present'] == False

    # test selinux disabled
    mock_HAVE_SELINUX = True
    mock_selinux_is_selinux_enabled = lambda: False
    mock_selinux_getenforcemode = lambda: (0, None)
    mock_selinux_security_getenforce = lambda: None

# Generated at 2022-06-23 01:42:47.132452
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    return_values = [True, 0, 'targeted', '1.2.4', 0, 'targeted', 0, '1.2.4', 0]

    test_ansible_module = {
        'selinux.is_selinux_enabled': lambda: return_values.pop(0),
        'selinux.security_policyvers': lambda: return_values.pop(0),
        'selinux.selinux_getenforcemode': lambda: (return_values.pop(0), return_values.pop(0)),
        'selinux.security_getenforce': lambda: return_values.pop(0),
        'selinux.selinux_getpolicytype': lambda: (return_values.pop(0), return_values.pop(0))
    }

    collector = SelinuxFactCollect

# Generated at 2022-06-23 01:42:53.051561
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SELinux = SelinuxFactCollector()
    selinux_facts = SELinux.collect()
    selinux_keys = set(selinux_facts.keys())
    assert selinux_keys == set(['selinux_python_present', 'selinux']), 'collect method of class SelinuxFactCollector does not return the expected keys.'

# Generated at 2022-06-23 01:42:54.953382
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-23 01:42:56.724835
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert(SelinuxFactCollector.name == 'selinux')

# Generated at 2022-06-23 01:43:05.030350
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    mocked_collector = SelinuxFactCollector()
    mocked_collector.collect(collected_facts={'selinux': {}})

    # No exception raised when selinux is unavailable
    mocked_collector = SelinuxFactCollector()
    mocked_collector.collect(collected_facts={}, module={})

    # Asserts that status is set in facts dictionary
    mocked_collector = SelinuxFactCollector()
    mocked_collector.collect(collected_facts={'selinux': {}}, module={})

    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:43:08.227151
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test if constructor of class SelinuxFactCollector works
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector.name

# Generated at 2022-06-23 01:43:09.346034
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:43:16.707897
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()

    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'status' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-23 01:43:21.746434
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    call_dict = SelinuxFactCollector.collect()
    assert 'status' in call_dict['selinux']
    assert 'policyvers' in call_dict['selinux']
    assert 'config_mode' in call_dict['selinux']
    assert 'mode' in call_dict['selinux']
    assert 'type' in call_dict['selinux']

# Generated at 2022-06-23 01:43:30.580965
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    # input dict, output dict, expected dict
    data = ({}, {}, {'selinux': {}, 'selinux_python_present': True})
    # test without selinux python library
    selinux_fact_collector.HAVE_SELINUX = False
    assert selinux_fact_collector.collect(collected_facts=data[0]) == data[2]
    # test with selinux python library
    selinux_fact_collector.HAVE_SELINUX = True
    selinux_fact_collector.selinux = selinux
    assert selinux_fact_collector.collect(collected_facts=data[0]) == data[2]

# Generated at 2022-06-23 01:43:33.436675
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''
    Test SelinuxFactCollector
    '''
    SelinuxFactCollector()

# Generated at 2022-06-23 01:43:37.923803
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.__class__.__name__ == 'SelinuxFactCollector'


# Generated at 2022-06-23 01:43:40.758159
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.fact_class_name == 'Selinux'


# Generated at 2022-06-23 01:43:42.821318
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-23 01:43:44.938139
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:43:54.266397
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Helper method to validate output of collect method of
    SelinuxFactCollector class
    '''
    selinux_facts = {}

    # Call the collect method without selinux python library
    fact_collector = SelinuxFactCollector()
    assert fact_collector.collect() == {'selinux': {'status': 'Missing selinux Python library'},
                                        'selinux_python_present': False}

    # Call the collect method with selinux python library
    fact_collector = SelinuxFactCollector()
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = 'unknown'
    selinux_facts['config_mode'] = 'unknown'
    selinux_facts['mode'] = 'unknown'
    selinux_facts['type'] = 'unknown'

# Generated at 2022-06-23 01:43:59.003026
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == "selinux"
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-23 01:44:01.604007
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-23 01:44:02.520041
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()


# Generated at 2022-06-23 01:44:11.660989
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Note: We have to mock selinux module because we are using it in the
    # constructor.
    import ansible.module_utils.facts.collector.selinux as selinux_module_mock
    selinux_module_mock.selinux = None
    selinux_module_mock.HAVE_SELINUX = True
    # Test with selinux module not present
    selinux_collector = SelinuxFactCollector()
    facts = selinux_collector.collect()
    assert facts['selinux_python_present'] is False
    assert facts['selinux']['status'] == 'Missing selinux Python library'
    # Test with selinux module present but selinux disabled
    selinux_collector = SelinuxFactCollector()
    facts = selinux_collector.collect()

# Generated at 2022-06-23 01:44:15.116724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Make sure the internal class selinux exists.
    assert(SelinuxFactCollector)


if __name__ == '__main__':
    # Unit test for constructor of class SelinuxFactCollector
    test_SelinuxFactCollector()

# Generated at 2022-06-23 01:44:25.010576
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    selinux_collector = SelinuxFactCollector()

    # Case when selinux library is missing
    if HAS_SELINUX is False:
        selinux_collector.collect()
        assert selinux_collector.content == {'selinux': {'status': 'Missing selinux Python library'},
                                             'selinux_python_present': False}
        return

    # Case when selinux library is present
    selinux_collector.collect()

# Generated at 2022-06-23 01:44:27.880241
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-23 01:44:31.309087
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test constructor of class SelinuxFactCollector"""
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert 'selinux_python_present' in x._fact_ids
    assert 'selinux' in x._fact_ids

# Generated at 2022-06-23 01:44:33.404593
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:44:34.759408
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:44:35.802567
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:44:39.078750
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:44:41.382785
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids is not None

# Generated at 2022-06-23 01:44:48.578155
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = type('module', (object,), {'params': {}})
    mock_module.params = {}
    collector = SelinuxFactCollector()
    facts_dict = collector.collect(mock_module, None)

    expected = {
        'selinux_python_present': True,
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        }
    }

    assert facts_dict == expected

# Generated at 2022-06-23 01:44:50.955368
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:44:56.194505
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux Python library present
    test_collector = SelinuxFactCollector()
    test_collector._collect()
    assert test_collector.collect() == {
        'selinux': {},
        'selinux_python_present': True
    }


# Generated at 2022-06-23 01:44:57.229759
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:45:06.980662
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    from ansible.module_utils._text import to_text
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()
    assert facts_dict is not None
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert 'policyvers' in facts_dict['selinux']
    assert 'config_mode' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']
    assert 'type' in facts_dict['selinux']
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-23 01:45:09.310303
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-23 01:45:12.511894
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxFactCollector = SelinuxFactCollector()
    result = selinuxFactCollector.collect()
    assert result['ansible_facts']['selinux'] == {'status' : 'disabled'}
    assert result['ansible_facts']['selinux_python_present'] == True

# Generated at 2022-06-23 01:45:15.233027
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'
    assert fc.collect() == {}

# Generated at 2022-06-23 01:45:32.536189
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Selinux library is present.
    # No exception raised when calling selinux.is_selinux_enabled()
    def selinux_is_selinux_enabled():
        return True

    def selinux_getenforcemode():
        return 0, 0

    def selinux_security_policyvers():
        return 1

    def selinux_security_getenforce():
        return 0

    def selinux_getpolicytype():
        return 0, 'targeted'


# Generated at 2022-06-23 01:45:40.463113
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    c = SelinuxFactCollector()
    collected_facts = {}
    collected_facts['selinux_python_present'] = True
    collected_facts['selinux'] = {}
    collected_facts['selinux']['status'] = ''
    collected_facts['selinux']['policyvers'] = ''
    collected_facts['selinux']['config_mode'] = ''
    collected_facts['selinux']['mode'] = ''
    collected_facts['selinux']['type'] = ''

    test_facts = c.collect(collected_facts)

    assert test_facts['selinux_python_present'] == True
    assert test_facts['selinux']['status'] == 'enabled'
    assert test_facts['selinux']['policyvers'] == 'unknown'

# Generated at 2022-06-23 01:45:45.559098
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test when the selinux library is missing
    # TODO: Once unit test for selinux module have been implemented,
    # add a test for when the selinux module is available
    c = SelinuxFactCollector()
    facts = c.collect()
    assert facts['selinux_python_present'] == False
    assert facts['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-23 01:45:47.505030
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts._fact_ids == set()



# Generated at 2022-06-23 01:45:53.193898
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Test for SelinuxFactCollector.collect
    '''
    fact_collector = SelinuxFactCollector()

    facts_dict = fact_collector.collect()
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    if facts_dict['selinux_python_present']:
        assert 'config_mode' in facts_dict['selinux']
        assert 'mode' in facts_dict['selinux']
        assert 'type' in facts_dict['selinux']

# Generated at 2022-06-23 01:45:58.211049
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    # Check that the name of the fact is stored correctly
    assert sfc.name == "selinux"
    # Check that the fact_ids is set to an empty set.
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:45:59.805125
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact.collect()

# Generated at 2022-06-23 01:46:02.867389
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.platforms == []
    assert collector.collections == ['selinux']

# Generated at 2022-06-23 01:46:11.171611
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    collector.collectors.pop('selinux', None)
    c = SelinuxFactCollector()
    facts = c.collect()
    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'type' in facts['selinux']
    assert 'policyvers' in facts['selinux']
    assert 'selinux_python_present' in facts

# Generated at 2022-06-23 01:46:17.725579
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    test_basefact_collector = SelinuxFactCollector()
    test_basefact_collector._module = None

    test_basefact_collector._module = None
    test_basefact_collector.collect()


# Generated at 2022-06-23 01:46:27.852944
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        selinux
        selinux_available = True
    except NameError:
        selinux_available = False

    class FakeModule(object):
        def __init__(self):
            self.selinux_python_present = selinux_available

    if selinux_available:
        class FakeSecurityContext(object):
            def __init__(self):
                self.type = 'SELINUXTYPE'
        selinux.selinux_getpolicytype = lambda: (0, 'SELINUXTYPE')

        class FakeSelinux(object):
            def __init__(self):
                self.is_selinux_enabled = lambda: True
                self.security_policyvers = lambda: 'SELINUXPOLICYVERS'

# Generated at 2022-06-23 01:46:39.273799
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This is the expected output when running on a system with no selinux library present
    FACT_1 = {'selinux_python_present': False,
              'selinux': {
                'status': 'Missing selinux Python library'
              }
             }
    # This is the expected output when running on a system with selinux enabled
    FACT_2 = {'selinux': {
                'type': 'targeted',
                'mode': 'enforcing',
                'config_mode': 'enforcing',
                'status': 'enabled',
                'policyvers': '28'
              },
              'selinux_python_present': True
             }
    # This is the expected output when running on a system with selinux enabled
    # in permissive mode and selinux is set to very permissive

# Generated at 2022-06-23 01:46:42.322704
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:46:50.844803
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()

    # Check that the 'selinux' fact is in the results
    assert 'selinux' in result
    assert 'selinux_python_present' in result

    # Check that the facts that are always expected to be populated
    # are populated
    assert 'status' in result['selinux']
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']
    assert 'type' in result['selinux']
    assert 'policyvers' in result['selinux']

# Generated at 2022-06-23 01:46:51.830500
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collector = SelinuxFactCollector()
    test_collector.collect()

# Generated at 2022-06-23 01:46:54.005667
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:46:57.740910
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set([])

# Generated at 2022-06-23 01:47:02.415620
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test class constructor"""
    SelinuxFactCollector()

# Generated at 2022-06-23 01:47:07.811995
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest

    from ansible.module_utils.facts.collector import BaseFactCollector

    module = pytest.Mock()
    collected_facts = pytest.Mock()
    obj = SelinuxFactCollector()

    obj.collect(module, collected_facts)

    obj.name == 'selinux'

    assert isinstance(obj, BaseFactCollector)

# Generated at 2022-06-23 01:47:15.298370
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if not HAVE_SELINUX:
        return True
    # Build a fake module object to pass to the collect method
    module = type('FakeModuleObject',(object,),dict(params=dict()))()

    output = SelinuxFactCollector(module).collect()

    assert output['selinux']['status'] == 'enabled'
    assert output['selinux']['mode'] == 'enforcing'
    assert output['selinux']['config_mode'] == 'enforcing'
    assert output['selinux']['policyvers'] == 1
    assert output['selinux']['type'] in [ 'targeted', 'minimum', 'mls' ]

# Generated at 2022-06-23 01:47:17.338993
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'

# Generated at 2022-06-23 01:47:27.384409
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    selinux_facts = collector.collect()
    assert selinux_facts['selinux_python_present']

    import selinux
    selinux.is_selinux_enabled = lambda: True # Enable SELinux
    selinux.selinux_getenforcemode = lambda: (0, 1) # Enforcing
    selinux.selinux_getpolicytype = lambda: (0, 'targeted') # targeted
    selinux.security_getenforce = lambda: 1 # Enforcing
    selinux.security_policyvers = lambda: 27
    fact = collector.collect()
    assert fact['selinux_python_present']
    assert fact['selinux']['status'] == 'enabled'
    assert fact['selinux']['policyvers'] == 27

# Generated at 2022-06-23 01:47:30.809608
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:47:35.575037
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import get_facts
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    facts = get_facts(SelinuxFactCollector)
    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    assert facts['selinux_python_present']

# Generated at 2022-06-23 01:47:37.565148
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

# Generated at 2022-06-23 01:47:44.226785
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Constructor test of class SelinuxFactCollector
    """
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert len(x.collect()) > 0
    assert len(x._fact_ids) == 0
    assert len(x._fact_ids.intersection(x._legacy_fact_names)) == 0


# Generated at 2022-06-23 01:47:56.513668
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert collected_facts['selinux']['status'] == 'enabled'
    assert collected_facts['selinux']['policyvers'] == 'unknown'
    assert collected_facts['selinux']['config_mode'] == 'unknown'
    assert collected_facts['selinux']['mode'] == 'unknown'
    assert collected_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-23 01:47:58.671623
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:48:03.173397
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library',
        },
        'selinux_python_present': False,
    }

# Generated at 2022-06-23 01:48:05.589145
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sefact = SelinuxFactCollector()
    assert sefact.name == "selinux"

# Generated at 2022-06-23 01:48:15.463783
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test SelinuxFactCollector collect function"""
    module = AnsibleModuleMock({'selinux_python_present': True})
    selinux_facts = SelinuxFactCollector.collect(module=module)
    assert 'selinux_python_present' in selinux_facts
    assert selinux_facts['selinux_python_present'] == True
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']

# Mock class for AnsibleModule

# Generated at 2022-06-23 01:48:19.471315
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()
    assert x.collect()


# Generated at 2022-06-23 01:48:26.415962
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {
        'config_mode': 'disabled',
        'mode': 'disabled',
        'status': 'disabled',
        'type': 'unknown',
        'policyvers': 'unknown'
    }
    facts_dict = {
        'selinux': {
            'config_mode': 'disabled',
            'mode': 'disabled',
            'status': 'disabled',
            'type': 'unknown',
            'policyvers': 'unknown'
        },
        'selinux_python_present': False
    }

    obj = SelinuxFactCollector()

    def mock_is_selinux_enabled():
        return False

    selinux.is_selinux_enabled = mock_is_selinux_enabled

    assert obj.collect() == facts_dict


# Generated at 2022-06-23 01:48:29.416619
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test constructor of class SelinuxFactCollector.

    This is tested to ensure the name property is set.
    """
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"

# Generated at 2022-06-23 01:48:42.015024
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Unit test for case where selinux library is not present.
    # Only status and selinux_python_present should be returned
    def test_collect_without_selinux_lib(monkeypatch):
        def mock_is_selinux_enabled():
            raise ImportError

        def mock_selinux_getpolicytype():
            return -1, 'test_policy_type'

        def mock_selinux_getenforcemode():
            return -1, 1

        def mock_security_policyvers():
            raise OSError

        def mock_security_getenforce():
            raise OSError

        monkeypatch.setattr(selinux, 'is_selinux_enabled', mock_is_selinux_enabled)

# Generated at 2022-06-23 01:48:44.490562
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:48:54.911543
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    sfc = collector.get_collector('SelinuxFactCollector')

    # This test should pass since SELinux Python library is present
    facts_dict = sfc.collect()
    assert facts_dict['selinux_python_present']
    assert 'selinux' in facts_dict.keys()

    # Now break the selinux library and try to run the collector
    module = basic.AnsibleModule(argument_spec={})
    module.selinux = None
    facts_dict = sfc.collect(module=module)

    # This test should pass since selinux library is broken
    assert facts_dict['selinux_python_present']
    assert 'selinux' in facts_dict.keys()
   

# Generated at 2022-06-23 01:48:58.025068
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert result['selinux'].keys().sort() == ['config_mode', 'mode', 'policyvers', 'status', 'type'].sort()

# Generated at 2022-06-23 01:49:08.593994
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    # Check if selinux Python library is present by setting it to True
    selinux_fact_collector.HAVE_SELINUX = True
    # Assign the mode to enforcing and run the collect method
    selinux_fact_collector.selinux = selinux
    selinux.security_getenforce = lambda: SELINUX_MODE_DICT[1]
    facts_dict = selinux_fact_collector.collect(None, None)
    assert facts_dict['selinux']['status'] == "enabled"
    assert facts_dict['selinux']['mode'] == "enforcing"
    # Assign the mode to permissive and run the collect method
    selinux.security

# Generated at 2022-06-23 01:49:15.670738
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    ansible_module.exit_json = MagicMock()
    selinux_fact_collector = SelinuxFactCollector()

    with patch('ansible.module_utils.facts.collector.selinux.is_selinux_enabled', return_value=False):
        selinux_fact_collector.collect(ansible_module)

    ansible_module.exit_json.assert_called_once_with(changed=False, ansible_facts={'selinux': {'status': 'disabled'}, 'selinux_python_present': True})

# Generated at 2022-06-23 01:49:17.965443
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.collect()
    assert collector._fact_ids

# Generated at 2022-06-23 01:49:19.905489
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector is not None

# Generated at 2022-06-23 01:49:25.464889
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # This is here to help with testing since this module is not simply
    # instantiable
    class MockModule(object):
        def __init__(self, params):
            self.params = params

    module = MockModule({"gather_subset": ["all"]})
    facts = SelinuxFactCollector(module).collect()
    assert len(facts) > 0

# Generated at 2022-06-23 01:49:27.940130
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-23 01:49:36.533447
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    import ansible.module_utils.selinux

    module = type('', (object,), {'selinux': ansible.module_utils.selinux})()
    ansible.module_utils.selinux.is_selinux_enabled = lambda: False
    exp_dict = {'selinux': {'status': 'disabled'}, 'selinux_python_present': True}
    actual_dict = SelinuxFactCollector.collect(Collector(), module)
    assert actual_dict == exp_dict


# Generated at 2022-06-23 01:49:43.552046
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fake_module = FakeModule()
    selinux_fc = SelinuxFactCollector(fake_module)

    assert selinux_fc.collect()['selinux']['status'] == 'enabled'
    assert selinux_fc.collect()['selinux']['type'] == 'targeted'
    assert selinux_fc.collect()['selinux']['mode'] == 'disabled'

    selinux.security_getenforce = mock.MagicMock(return_value=-1)
    assert selinux_fc.collect()['selinux']['mode'] == 'disabled'

    selinux.security_getenforce = mock.MagicMock(return_value=0)
    assert selinux_fc.collect()['selinux']['mode'] == 'permissive'

    selinux.security_getenforce

# Generated at 2022-06-23 01:49:53.367773
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector as acol
    from ansible.module_utils.facts import get_collector_instance as gci
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.compat import selinux

    class TestModule(object):
        def __init__(self):
            self.params = {}

    acol.setup('selinux')
    collector = gci('selinux')

    assert isinstance(collector, SelinuxFactCollector)
    assert isinstance(collector, BaseFactCollector)


# Generated at 2022-06-23 01:49:57.884932
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test for checking the selinux_python_present key for missing selinux Python library
    selinux_python_present = None
    try:
        from ansible.module_utils.compat import selinux
        selinux_python_present = True
    except ImportError:
        selinux_python_present = False

    collect_res = SelinuxFactCollector().collect()
    assert collect_res['selinux_python_present'] is selinux_python_present