

# Generated at 2022-06-23 01:40:03.692132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Only run if selinux library is present
    if HAVE_SELINUX:
        # Assign the default value
        selinux_facts = SelinuxFactCollector()
        assert selinux_facts.name == 'selinux'
        assert selinux_facts._fact_ids == set()

        # Assign altered values
        selinux_facts.name = 'other'
        selinux_facts._fact_ids = set(['a', 'b'])
        assert selinux_facts.name == 'other'
        assert selinux_facts._fact_ids == set(['a', 'b'])

        # Assign invalid values
        try:
            selinux_facts.name = 1
            selinux_facts._fact_ids = 1
        except TypeError:
            assert True

# Generated at 2022-06-23 01:40:12.617677
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Mock object for selinux library
    mock_selinux = mock.MagicMock()
    selinux_facts = {}

    # Create a mock class for selinux
    mock_selinux_class = mock.MagicMock()

    # Set the mock class for selinux
    selinux.selinux = mock_selinux_class

    # Create an objet for SelinuxFactCollector class
    selinux_fc = SelinuxFactCollector()

    # Check if selinux_python_present is present in the facts collected
    facts = selinux_fc.collect()
    assert 'selinux_python_present' in facts

    selinux_fc._HAS_SELINUX = True

    # Check if status is present in the facts collected
    facts = selinux_fc.collect()

# Generated at 2022-06-23 01:40:24.841006
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_facts = {'config_mode': 'enforcing', 'status': 'enabled',
                     'mode': 'enforcing', 'type': 'targeted'}
    selinux_facts_without_underlying_lib = {'status': 'Missing selinux Python library'}
    selinux_facts_with_missing_lib = {'config_mode': 'unknown', 'status': 'enabled',
                                      'mode': 'unknown', 'type': 'unknown'}

    # Create an instance of the Collector class
    collector = SelinuxFactCollector()

    # Set the status of HAVE_SELINUX to True and test that the collector
    # returns the expected values for selinux_facts
    collector.set_module_utils_libraries_available({'selinux': True})

# Generated at 2022-06-23 01:40:35.196567
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create object SelinuxFactCollector and call function collect
    selinux_facts = SelinuxFactCollector().collect()

    # Check if version, mode and status of SELinux is present in the facts
    assert 'selinux' in selinux_facts.keys()
    assert 'version' in selinux_facts['selinux'].keys()
    assert 'mode' in selinux_facts['selinux'].keys()
    assert 'status' in selinux_facts['selinux'].keys()
    assert 'python_present' in selinux_facts.keys()
    assert 'config_mode' in selinux_facts['selinux'].keys()
    assert 'type' in selinux_facts['selinux'].keys()
    assert 'policyvers' in selinux_facts['selinux'].keys()

# Generated at 2022-06-23 01:40:36.077614
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:40:45.726799
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os.path
    import tempfile

    # Create fake selinux module
    fake_selinux_module_path = tempfile.mkstemp()[1]
    fake_selinux_module = '''
        def is_selinux_enabled():
            return False
    '''
    with open(fake_selinux_module_path, 'w') as f:
        f.write(fake_selinux_module)

    # Create fake selinux module
    fake_missing_selinux_module_path = tempfile.mkstemp()[1]
    fake_missing_selinux_module = '''
        def is_selinux_enabled():
            raise ImportError
    '''

# Generated at 2022-06-23 01:40:48.942715
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-23 01:40:50.679979
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''Unit test for constructor of class SelinuxFactCollector'''
    # Do nothing
    assert True

# Generated at 2022-06-23 01:41:04.964282
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import fact_cache
    from ansible.module_utils.compat import selinux

    fact_cache.clear_cache()

    # Create object of class SelinuxFactCollector and invoke method collect
    SelFactCollector = SelinuxFactCollector()
    Collector.collectors['selinux'] = SelFactCollector

    # Create a mock of the selinux module and set the mode and config_mode
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: 3000
    selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux.security_getenforce = lambda: 1

# Generated at 2022-06-23 01:41:06.759129
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:41:18.651426
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If the library selinux is installed, the facts selinux are present
    if HAVE_SELINUX:
        selinux_facts = SelinuxFactCollector().collect()
        assert selinux_facts['selinux_python_present'] == True

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    else:
        selinux_facts = SelinuxFactCollector().collect()
        assert selinux_facts['selinux_python_present'] == False
        assert 'selinux' not in selinux_facts

# Generated at 2022-06-23 01:41:19.357181
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:41:28.126156
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # selinux Python library missing, set booleans and return
    (f, facts_dict) = SelinuxFactCollector.collect()
    assert f is True
    assert isinstance(facts_dict, dict)
    assert facts_dict.get('selinux_python_present') is False
    assert facts_dict.get('selinux') is None

    # selinux Python library available, do not attempt collect
    # if selinux is not enabled
    f, facts_dict = SelinuxFactCollector.collect()
    assert f is True
    assert isinstance(facts_dict, dict)
    assert facts_dict['selinux_python_present'] is True
    assert facts_dict['selinux'] is None

# Generated at 2022-06-23 01:41:29.753711
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:41:31.879566
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'
    assert fc._fact_ids == set()

# Generated at 2022-06-23 01:41:34.407888
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:41:36.797251
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == "selinux"

# Generated at 2022-06-23 01:41:40.661820
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name is not None
    assert collector.name == 'selinux'
    assert collector._fact_ids is not None
    assert len(collector._fact_ids) >= 0


# Generated at 2022-06-23 01:41:46.906970
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create dummy module
    module = DummyModule()

    # Create dummy collected facts
    collected_facts = Facts()

    # Create instance of SelinuxFactCollector
    fact_collector = SelinuxFactCollector(module=module, collected_facts=collected_facts)

    # Check the facts
    assert fact_collector.collect() == {
        'selinux': {
            'status': 'disabled'
        },
        'selinux_python_present': False
    }


# Generated at 2022-06-23 01:41:48.835370
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:41:50.797157
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:41:51.814969
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:41:57.533083
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_module = SelinuxFactCollector()
    facts_dict = selinux_module.collect()

    if HAVE_SELINUX:
        print(facts_dict['selinux']['status'])
    else:
        assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
        assert facts_dict['selinux_python_present'] == False

# Generated at 2022-06-23 01:42:03.234973
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector_obj = SelinuxFactCollector()
    assert SelinuxFactCollector_obj.collect() == {'selinux': {'status': 'enabled',
                                                             'policyvers': '28',
                                                             'config_mode': 'enforcing',
                                                             'mode': 'enforcing',
                                                             'type': 'targeted'},
                                                  'selinux_python_present': True}

# Generated at 2022-06-23 01:42:04.622457
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector == SelinuxFactCollector()


# Generated at 2022-06-23 01:42:09.061522
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector_instance = SelinuxFactCollector()
    assert fact_collector_instance.name == 'selinux'
    assert fact_collector_instance._fact_ids == set()

# Generated at 2022-06-23 01:42:10.736581
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-23 01:42:17.972664
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import get_collector_instance
    selinux_collector = get_collector_instance(SelinuxFactCollector)

    # collector should return a dictionary
    assert isinstance(selinux_collector.collect(), dict)

    # collector should return a dictionary with the key selinux_python_present
    assert 'selinux_python_present' in selinux_collector.collect()

    # collector should return a dictionary with the key selinux
    assert 'selinux' in selinux_collector.collect()

# Generated at 2022-06-23 01:42:27.827348
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    # Mock selinux module so that only the selinux.is_selinux_enabled() method
    # will work
    selinux_mock = MagicMock()
    selinux_mock.is_selinux_enabled.return_value = True

    # Mock importlib to return the magic mock object
    importlib_mock = MagicMock()
    importlib_mock.import_module.return_value = selinux_mock

    # Patch selinux and importlib to use the mock
    with patch.dict('sys.modules', {'selinux': selinux_mock, 'importlib': importlib_mock}):
        result = collector.collect()

    # Assert that the correct library was imported
    importlib_mock.import_module.assert_called_once

# Generated at 2022-06-23 01:42:32.302945
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()

# Generated at 2022-06-23 01:42:40.939097
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Arrange
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Act
    collected_facts = selinux_fact_collector.collect()

    # Assert
    assert(collected_facts['selinux_python_present'] == True)
    assert(collected_facts['selinux']['status'] == 'enabled')

# Generated at 2022-06-23 01:42:42.692434
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:42:44.786394
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    c = SelinuxFactCollector()

    assert c.collect()

# Generated at 2022-06-23 01:42:53.612132
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()

    # Create a mock object, setting all return values to None
    module_mock = Mock()
    setattr(module_mock, '_socket_path', None)
    setattr(module_mock, 'run_command', Mock())
    selinux_collector.collect(module=module_mock)

    # Call the run_command method and verify the selinux binary is path is correct
    module_mock.run_command.call_args

    #
    # Create a mock object, setting all return values to False
    #

    # Create a mock object, setting all return values to False
    module_mock = Mock()
    setattr(module_mock, '_socket_path', None)

# Generated at 2022-06-23 01:43:04.675793
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert isinstance(result, dict)
    assert result['selinux_python_present'] == True
    assert isinstance(result['selinux'], dict)
    assert result['selinux']['status'] == 'enabled'
    assert result['selinux']['policyvers'] == '28'
    assert result['selinux']['config_mode'] == 'enforcing'
    assert result['selinux']['mode'] == 'enforcing'
    assert result['selinux']['type'] == 'targeted'

    result = SelinuxFactCollector().collect()
    assert isinstance(result, dict)
    assert result['selinux_python_present'] == True
    assert isinstance(result['selinux'], dict)

# Generated at 2022-06-23 01:43:07.698161
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:43:13.413620
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    collected_facts['ansible_selinux_python_present'] = True
    collected_facts['ansible_selinux'] = {'mode': 'disabled', 'status': 'enabled'}
    selinux_fact_collector.collect(collected_facts)
    assert 'ansible_selinux' in collected_facts

# Generated at 2022-06-23 01:43:17.018688
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector.priority == 15
    assert fact_collector._fact_ids == set()
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-23 01:43:26.300835
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts import get_collector_status
    
    fact_collector_inst = get_collector_instance(SelinuxFactCollector)
    selinux_collector_status = get_collector_status(SelinuxFactCollector)

    if selinux_collector_status != False:
        selinux_collector_facts = fact_collector_inst.collect()
        if selinux_collector_facts != None:
            print(selinux_collector_facts["selinux"])
            print(selinux_collector_facts["selinux_python_present"])

# Generated at 2022-06-23 01:43:29.813555
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect()
    assert 'selinux' in result
    assert result['selinux_python_present'] == True

# Generated at 2022-06-23 01:43:40.105432
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ''' Unit test for method collect of class SelinuxFactCollector '''

    collector = SelinuxFactCollector()
    selinux_facts = collector.collect()

    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-23 01:43:42.442305
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-23 01:43:46.769553
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fake_collected_facts = {}
    sfc = SelinuxFactCollector()
    fact = sfc.collect(collected_facts=fake_collected_facts)
    assert 'selinux_python_present' in fact

# Generated at 2022-06-23 01:43:54.036323
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    assert 'selinux_python_present' in facts.keys()
    assert 'selinux' in facts.keys()
    assert 'status' in facts['selinux'].keys()
    assert facts['selinux']['status'] in ('enabled', 'disabled', 'Missing selinux Python library')
    if facts['selinux']['status'] == 'enabled':
        assert 'type' in facts['selinux'].keys()
        assert 'mode' in facts['selinux'].keys()
        assert 'config_mode' in facts['selinux'].keys()

# Generated at 2022-06-23 01:43:58.396223
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    seinfo = SelinuxFactCollector()
    assert seinfo.name =='selinux'
    assert seinfo._fact_ids == set()
    assert seinfo.collect()

# Generated at 2022-06-23 01:44:00.347512
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts_collector = SelinuxFactCollector()
    assert(selinux_facts_collector.name == 'selinux')

# Generated at 2022-06-23 01:44:03.139099
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == set()


# Generated at 2022-06-23 01:44:06.555253
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = SelinuxFactCollector()
    result = fact.collect()
    assert result.get('selinux_python_present') is True

# Generated at 2022-06-23 01:44:10.974290
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This function is used to unit test collect method of class SelinuxFactCollector.
    """
    selinux_collector = SelinuxFactCollector()
    assert(selinux_collector.collect().get("selinux_python_present") == True)

# Generated at 2022-06-23 01:44:13.255039
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name is not None
    assert obj._fact_ids is not None


# Generated at 2022-06-23 01:44:15.455474
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    assert 'selinux_python_present' in facts

# Generated at 2022-06-23 01:44:24.244649
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Mock out module_utils.selinux

    class MockSelinuxModule(object):
        """
        This class is used to mock out the class module_utils.selinux.selinux
        """

        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return '24'

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 1

        def selinux_getpolicytype(self):
            return (0, 'targeted')

    class MockModuleUtilSelinux(object):
        """
        This class is used to mock out the class module_utils.selinux
        """


# Generated at 2022-06-23 01:44:26.165407
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sfc = SelinuxFactCollector()
    result = sfc.collect()
    for k,v in result.items():
        print(k,v)

# Generated at 2022-06-23 01:44:29.139217
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-23 01:44:30.902668
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test that no exception is raised on creation"""
    SelinuxFactCollector()

# Generated at 2022-06-23 01:44:36.316106
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  import doctest
  result = doctest.testmod()
  if result.failed == 0:
    print('PASSED')
  else:
    print('FAILED')

if __name__ == '__main__':
  test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:44:40.490695
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == "selinux", "The constructor of SelinuxFactCollector did not set the correct name attribute."
    assert c._fact_ids == set(), "The constructor of SelinuxFactCollector did not set the correct _fact_ids attribute."

# Generated at 2022-06-23 01:44:43.501012
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-23 01:44:47.176583
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts import collector
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, BaseFactCollector)


# Generated at 2022-06-23 01:44:49.888425
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    bfc = SelinuxFactCollector()
    assert bfc.name == 'selinux'
    assert bfc.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:44:56.867122
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """unit test for method collect of class SelinuxFactCollector"""

    class TestModule(object):
        def __init__(self):
            self.params = {}

    class TestFactsCollector(object):
        def __init__(self):
            self.ansible_facts = {}

    # Test with no selinux Python library
    module = TestModule()
    facts_collector = TestFactsCollector()
    col = SelinuxFactCollector(module=module, facts=facts_collector)
    col.collect()
    assert facts_collector.ansible_facts['selinux_python_present'] == False
    assert facts_collector.ansible_facts['selinux']['status'] == 'Missing selinux Python library'

    # Test when selinux Python library is present.
    module = TestModule()

# Generated at 2022-06-23 01:45:08.579054
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a fake module (no argument)
    from ansible.module_utils._text import to_bytes
    module = type('obj', (), dict())
    module.params = dict()

    # Create a fake selinux module
    selinux = type('obj', (), dict())
    selinux.is_selinux_enabled = lambda: False
    selinux.security_policyvers = lambda: None
    selinux.selinux_getenforcemode = lambda: None
    selinux.security_getenforce = lambda: None
    selinux.selinux_getpolicytype = lambda: None

    # Monkey patch the selinux module
    SelinuxFactCollector.HAVE_SELINUX = True
    SelinuxFactCollector.selinux = selinux

# Generated at 2022-06-23 01:45:11.201714
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'
    assert 'selinux' in sf._fact_ids

# Generated at 2022-06-23 01:45:22.680983
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.ansible.mitogen.plugins.module_utils.facts import \
        collector

    # If the selinux Python library is available, test fetching facts
    if not HAVE_SELINUX:
        return

    collector_obj = collector.get_collector('selinux')
    result = collector_obj.collect()
    assert 'selinux' in result
    assert isinstance(result['selinux'], dict)
    assert isinstance(result['selinux_python_present'], bool)
    assert result['selinux_python_present'] is True
    assert result['selinux']['type'] != 'unknown'
    assert result['selinux']['policyvers'] != 'unknown'
    assert result['selinux']['mode'] != 'unknown'

# Generated at 2022-06-23 01:45:31.463197
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a SelinuxFactCollector instance
    selinux_fact_collector = SelinuxFactCollector()

    # Test collect() method
    facts = selinux_fact_collector.collect()

    # Make sure that selinux is one of the keys in the facts dictionary
    assert 'selinux' in facts

    # Make sure that status is one of the keys in the inner dictionary
    assert 'status' in facts['selinux']

# Generated at 2022-06-23 01:45:34.580710
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    # Call method collect
    selinux_collector.collect()
    # Check if sub-dictionary 'selinux' was created
    assert 'selinux' in selinux_collector.collect()

# Generated at 2022-06-23 01:45:45.981130
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Instantiate class
    c = SelinuxFactCollector()

    # Prepare mocks
    class MockSelinux(object):
        def is_selinux_enabled(self):
            return False

    # Run method that is being tested
    result = c.collect(module=None, collected_facts=None)
    assert 'selinux' in result
    assert result['selinux']['status'] == 'disabled'

    import ansible.module_utils.facts
    ansible.module_utils.facts.selinux = MockSelinux()

    result = c.collect(module=None, collected_facts=None)
    assert 'selinux' in result
    assert result['selinux']['status'] == 'enabled'

# Generated at 2022-06-23 01:45:53.306930
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    test_object = SelinuxFactCollector(module=None, collected_facts=None)

    # Testing with selinux installed.
    test_object.set_module(module=None)
    test_collector_test_selinux_installed = Collector(module=None, collected_facts=None)
    test_collector_test_selinux_installed.set_fact_collectors([test_object])
    test_collector_object_test_selinux_installed = test_collector_test_

# Generated at 2022-06-23 01:45:54.927741
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:45:56.304472
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert 'selinux' in x.collect()

# Generated at 2022-06-23 01:46:05.598674
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for SelinuxFactCollector.collect
    """
    # Test with no selinux library present
    fact_collector = SelinuxFactCollector()
    selinux_facts = fact_collector.collect()

    assert selinux_facts['selinux_python_present'] == False
    assert selinux_facts['selinux']['status'] == 'Missing selinux Python library'

    # Test with selinux library present
    from ansible.module_utils.compat import selinux
    selinux_old = selinux
    selinux_facts = None
    selinux = None

# Generated at 2022-06-23 01:46:15.308246
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # For test_SelinuxFactCollector_collect, we can not predict
    # what the user has for selinux, so we will use stubs
    # to verify return values and not the actual implementation
    # this means we don't have to rely on the user's setup
    # being within the enforcement mode of selinux.
    # As we only stub the calls to the selinux module, we
    # can still ensure we are calling all the expected methods
    # and have them return the correct values.
    # Similarly we can test the 'missing library' case by
    # removing the selinux module.

    # load necessary modules
    import imp
    import sys

    # stub collect methods as they are not called in this class
    def stub_collect(self, module=None, collected_facts=None):
        return


# Generated at 2022-06-23 01:46:21.968869
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """This is a test for the constructor of the class. It checks that
    the class name and the fact_ids are set correctly.
    """
    sfc = SelinuxFactCollector()

    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:46:24.689180
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the collect method of the SelinuxFactCollector class
    """
    collector = SelinuxFactCollector()
    result = collector.collect()
    assert result['selinux_python_present'] is True

# Generated at 2022-06-23 01:46:36.624270
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    import os
    import sys
    import unittest

    # Initialize
    collector = SelinuxFactCollector()
    collected_facts = {}

    # Simulate SELinux library is available
    previous_path = sys.path
    sys.path = [os.path.dirname(os.path.realpath(__file__))]
    class SELinux:
        def __init__(self):
            pass
        def is_selinux_enabled(self):
            return True
        def security_getenforce(self):
            return 0
        def security_policyvers(self):
            return 14
        def selinux_getpolicytype(self):
            return (0, 'targeted')

# Generated at 2022-06-23 01:46:39.273339
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()

    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()



# Generated at 2022-06-23 01:46:40.678442
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_obj = SelinuxFactCollector()
    test_obj.collect()

# Generated at 2022-06-23 01:46:52.379437
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock

    with mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.collection_warn') as warnmock:
        with mock.patch('ansible.module_utils.facts.collector.BaseFactCollector.collection_info') as infomock:
            with mock.patch('ansible.module_utils.selinux') as mockselinux:
                mockselinux.is_selinux_enabled = mock.MagicMock(return_value=True)
                mockselinux.security_policyvers = mock.MagicMock(return_value=1)
                mockselinux.selinux_getenforcemode = mock.MagicMock(return_value=(0, 1))
                mockselinux.security_getenforce = mock.MagicMock(return_value=1)

# Generated at 2022-06-23 01:46:54.543539
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Should return an object of class SelinuxFactCollector.
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)

# Generated at 2022-06-23 01:46:56.754684
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sfc = SelinuxFactCollector({}, [])
    facts_dict = sfc.collect()
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-23 01:47:04.371911
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    context = {}
    selinux_collector = SelinuxFactCollector()
    collected_facts = selinux_collector.collect(None, context)
    assert selinux_collector.name in collected_facts
    assert 'selinux_python_present' in collected_facts
    if not HAVE_SELINUX:
        assert 'status' in collected_facts['selinux']
        assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    else:
        assert 'status' in collected_facts['selinux']
        assert 'config_mode' in collected_facts['selinux']
        assert 'mode' in collected_facts['selinux']
        assert 'policyvers' in collected_facts['selinux']
        assert 'type' in collected_facts['selinux']

# Generated at 2022-06-23 01:47:08.095453
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert hasattr(selinux_fact_collector, 'collect')

# Generated at 2022-06-23 01:47:19.060646
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test when selinux.is_selinux_enabled returns true
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.module = Mock()
    selinux_fact_collector.module.selinux = Mock()
    selinux_fact_collector.module.selinux.is_selinux_enabled.return_value = True
    selinux_fact_collector.module.selinux.security_policyvers.return_value = 5
    selinux_fact_collector.module.selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux_fact_collector.module.selinux.selinux_getpolicytype.return_value = (0, 'targeted')

# Generated at 2022-06-23 01:47:20.875753
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()
    selinux.collect()


# Generated at 2022-06-23 01:47:23.476446
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    my_collector = SelinuxFactCollector()
    facts_dict = my_collector.collect()
    assert 'ansible_selinux' in facts_dict

# Generated at 2022-06-23 01:47:35.559470
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fake_module = 'fake_module'

    # Load the selinux module and selinux module_utils
    selinux_module = __import__('selinux')
    selinux_module_utils = __import__('ansible.module_utils.selinux')

    # Create class instance
    selinux_fact_collector = SelinuxFactCollector()

    # Call the collect method with no internal methods mocked
    facts = selinux_fact_collector.collect(fake_module)
    assert facts['selinux']['status'] == 'disabled'

    # Mock the is_selinux_enabled method
    def is_selinux_enabled_mock(self):
        return True
    selinux_module.is_selinux_enabled = is_selinux_enabled_mock
    selinux_module_utils

# Generated at 2022-06-23 01:47:44.021234
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Mock a module from which we can get the distribution's name,
    # in this case, we are mocking RedHat distribution.  For other
    # distributions this module_utils needs to be updated.
    module = MagicMock()
    module.params = { 'gather_subset': ['all'], 'gather_timeout': 10 }
    module.distribution_file = 'redhat'
    module.distribution_version = '7.6'
    module.os_family = 'RedHat'
    module.lsb_dist_version = '7.6'
    module.lsb_dist_release = '7.6'

    # Mock selinux
    selinux = MagicMock()
    selinux.is_selinux_enabled = MagicMock(return_value=False)

    # Mock selinux that the library is present

# Generated at 2022-06-23 01:47:51.581613
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsHelper
    from ansible.module_utils.facts import selinux

    # Set up FactsHelper object
    fh = FactsHelper(None)
    selinux.HAVE_SELINUX = False
    selinux.is_selinux_enabled = lambda: False

    # Get collect method of SelinuxFactCollector object
    sfc = SelinuxFactCollector(module_name='test', module_args=None)
    collect = sfc.collect

    # Call collect method and compare results
    result = collect(fh)
    expected_result = dict(selinux=dict(status='Missing selinux Python library'), selinux_python_present=False)
    assert result == expected_result

# Generated at 2022-06-23 01:47:54.078999
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect()

# Generated at 2022-06-23 01:48:05.695992
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    from ansible.module_utils.compat import selinux

    # Setup a class instance with a SELinux Python library
    selinux_fact = SelinuxFactCollector()

    # Check for 'selinux' key in the dictionary
    assert 'selinux' in selinux_fact.collect()

    # Setup a class instance without a SELinux Python library
    selinux.is_selinux_enabled = None
    selinux_fact = SelinuxFactCollector()

    # Check for 'selinux' key and 'selinux_python_present' key in the dictionary
    assert 'selinux' in selinux_fact.collect()
    assert 'selinux_python_present' in selinux_fact.collect()

# Generated at 2022-06-23 01:48:13.562105
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test collecting facts with a SelinuxFactCollector object

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # Let's declare a fact collector object
    fact_collector = SelinuxFactCollector()

    # Let's declare some options/facts that we want to collect
    collected_facts = {}

    # Let's collect the facts
    fact_collector.collect(collected_facts=collected_facts)

    for fact in fact_collector._fact_ids:
        assert fact in collected_facts, "The fact %s did not get collected" % fact

# Generated at 2022-06-23 01:48:18.675855
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert 'selinux_python_present' in facts_dict
    assert 'selinux' in facts_dict


# Generated at 2022-06-23 01:48:23.166702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Mock the selinux library
    module_selinux = __import__('ansible.module_utils.compat', fromlist=['selinux'])
    module_selinux.selinux = SelinuxLibraryMock()

    # Call the collect method
    selinux_collector = SelinuxFactCollector()
    assert(selinux_collector.collect() == expected_facts)



# Generated at 2022-06-23 01:48:34.699314
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = {'ipv4': {'address': '1.2.3.4', 'network': '1.2.3.0', 'netmask': '255.255.255.0'}}
    selinux_fact_collector = SelinuxFactCollector()

    # Test without selinux library
    selinux_fact_collector._HAVE_SELINUX = False
    facts_dict = selinux_fact_collector.collect(module, collected_facts)
    assert facts_dict == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # Test with selinux library
    selinux_fact_collector._HAVE_SELINUX = True
    selinux_fact_collector._selinux = se

# Generated at 2022-06-23 01:48:44.606414
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of class SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()

    # Create a dictionary which will later be returned by mock_module
    collected_facts_dict = {
            'python': {
                'version': {
                    'major': 2,
                    'minor': 7,
                    'micro': 12,
                    'releaselevel': 'final',
                    'serial': 0
                }
            }
        }

    # Create an instance of AnsibleModule mock class
    from ansible.module_utils.facts.legacy import ansible_module_mock
    mock_module = ansible_module_mock()

    # Assert that selinux facts are not present in collected_facts dictionary
    assert 'selinux' not in collected_facts_dict

# Generated at 2022-06-23 01:48:46.546718
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:48:51.634219
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_class = SelinuxFactCollector()
    collected_facts = {}
    collected_facts['selinux'] = {}
    collected_facts['selinux_python_present'] = False
    test_class.collect(collected_facts=collected_facts)
    assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    assert collected_facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:49:00.676699
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collected_facts = {'selinux':{}, 'selinux_python_present': True}
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: 2
    selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux.security_getenforce = lambda: 1
    selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect(collected_facts=collected_facts)
    selinux_facts = facts_dict.get('selinux')

    assert 'status' in selinux_facts
    assert selinux_facts['status'] == 'enabled'
    assert 'policyvers' in selinux

# Generated at 2022-06-23 01:49:10.564705
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test that the instance of SelinuxFactCollector has the correct data
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux.collected_facts == {}


# Generated at 2022-06-23 01:49:14.014703
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of class SelinuxFactCollector.
    test_sef = SelinuxFactCollector()

    # Run method collect of class SelinuxFactCollector.
    test_sef.collect(module=None, collected_facts=None)

# Generated at 2022-06-23 01:49:17.859273
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    name = fact_collector.name
    fact_ids = fact_collector._fact_ids
    assert name == 'selinux'
    assert len(fact_ids) == 0

# Generated at 2022-06-23 01:49:23.713222
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_instance = SelinuxFactCollector()
    assert selinux_fact_collector_instance.name == 'selinux'

# Generated at 2022-06-23 01:49:35.666984
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_subset_of_facts, FactsCollector
    from ansible.module_utils._text import to_bytes
    import json
    # Disable fact collection to avoid key error in Python 2.7.10
    # https://github.com/ansible/ansible/issues/63471
    collect_subset_of_facts(subset=('!all'))
    facts_collector = FactsCollector()
    facts_collector.collect(module=None, collected_facts=None)
    # Need to convert collected facts to bytes for Python 3.x.
    collected_facts = facts_collector.get_facts()
    collected_facts_bytes = to_bytes(json.dumps({key: value for key, value in collected_facts.items()}))
    assert b

# Generated at 2022-06-23 01:49:46.738755
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    def mock_is_selinux_enabled():
        return True

    def mock_security_policyvers():
        return 99

    def mock_selinux_getenforcemode():
        return (0, 1)

    def mock_security_getenforce():
        return 0

    def mock_selinux_getpolicytype():
        return (0, 'targeted')

    selinux_module = dict()
    selinux_module['security'] = dict()
    selinux_module['security']['selinux_getenforcemode'] = mock_selinux_getenforcemode
    selinux_module['security']['security_policyvers'] = mock_security_policyvers
    selinux_module['security']['security_getenforce'] = mock_security_getenforce

# Generated at 2022-06-23 01:49:51.050366
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """ selinux_fact_collector_test.py:test_SelinuxFactCollector() """

    c = SelinuxFactCollector()

    assert c.name == 'selinux'
    assert c.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:49:58.885157
# Unit test for method collect of class SelinuxFactCollector