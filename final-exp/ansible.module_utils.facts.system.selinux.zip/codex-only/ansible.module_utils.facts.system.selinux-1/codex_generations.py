

# Generated at 2022-06-23 01:40:00.527337
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert 'selinux' == collector.name
    assert hasattr(collector, 'collect')
    assert 'selinux' in collector._fact_ids

# Generated at 2022-06-23 01:40:03.499457
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:40:06.524998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"

# Generated at 2022-06-23 01:40:09.344236
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.fact_ids == set()

# Generated at 2022-06-23 01:40:11.344959
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-23 01:40:13.788485
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    first_class = SelinuxFactCollector()
    assert first_class.collect()
    assert first_class.collect()['selinux']['status']

# Generated at 2022-06-23 01:40:20.304787
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    mock_dict = {
        'selinux': {
            'status': 'disabled',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        }
    }

    assert selinux_fact_collector.collect() == mock_dict

# Generated at 2022-06-23 01:40:21.356094
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:40:26.500393
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collected_facts = {'ansible_system': 'Linux'}
    module = 'fake_module'
    s = SelinuxFactCollector()
    facts_dict = s.collect(module, collected_facts)

    assert 'selinux_python_present' in facts_dict
    if HAVE_SELINUX:
        assert 'selinux' in facts_dict
    else:
        assert 'selinux' not in facts_dict

# Generated at 2022-06-23 01:40:30.103827
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:40:32.233242
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-23 01:40:42.307415
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    import os

    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = os.path.realpath(os.path.join(os.path.dirname(__file__), '../test/test_collection/'))
    facts = Facts(module_name='test_module')
    collector = SelinuxFactCollector(module=None, collected_facts=facts.get_fact_cache())
    selinux_facts = collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['config_mode'] == "disabled"
    assert selinux_facts['selinux']['mode'] == "disabled"

# Generated at 2022-06-23 01:40:45.137615
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactscollector = SelinuxFactCollector()
    assert selinuxfactscollector.name == 'selinux'
    assert selinuxfactscollector._fact_ids == set()

# Generated at 2022-06-23 01:40:53.224625
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Unit test for case where selinux is disabled
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import SelinuxFactCollector

    class MockSelinuxModule(object):

        class MockSELinux(object):
            def security_policyvers(self):
                raise OSError
            def selinux_getenforcemode(self):
                return (-1, -1)
            def security_getenforce(self):
                raise OSError
            def selinux_getpolicytype(self):
                return (-1, None)
            def is_selinux_enabled(self):
                return False

    class MockCollector(object):
        def __init__(self):
            self.all_facts = dict()
            self.facts = dict()

       

# Generated at 2022-06-23 01:40:58.022291
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = {'selinux': {'config_mode': 'permissive', 'type': 'targeted', 'policyvers': '28', 'mode': 'permissive', 'status': 'enabled'}, 'selinux_python_present': True}
    assert selinux_fact_collector.collect() == facts_dict

# Generated at 2022-06-23 01:41:02.312619
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-23 01:41:11.605550
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test without selinux module
    collector = SelinuxFactCollector()
    collector.collect()
    assert len(collector.collect().keys()) == 2
    assert collector.collect()['selinux_python_present'] == False
    assert len(collector.collect()['selinux'].keys()) == 1
    assert collector.collect()['selinux']['status'] == 'Missing selinux Python library'

    # Test with selinux module
    collector = SelinuxFactCollector()
    collector.collect()
    assert len(collector.collect().keys()) == 2
    assert collector.collect()['selinux_python_present'] == True

# Generated at 2022-06-23 01:41:20.212893
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect()"""

    # Create selinux fact collector object
    selinux_fact_collector = SelinuxFactCollector()

    # Try to collect facts and save them in test_facts_dict dictionary
    test_facts_dict = selinux_fact_collector.collect()

    # Check that we are not using selinux Python library
    assert test_facts_dict['selinux_python_present'] == False

    # Check that status is set to Missing selinux Python library
    assert test_facts_dict['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-23 01:41:30.235118
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Set up a fake module
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'selinux']
    module = FakeModule()

    # Set up a fake selinux object to test with
    class FakeSelinux:
        def is_selinux_enabled(self):
            return True
        def security_policyvers(self):
            return 5
        def selinux_getenforcemode(self):
            return (0, 1)
        def security_getenforce(self):
            return 1
        def selinux_getpolicytype(self):
            return (0, 'targeted')
    selinux_mod = FakeSelinux()

    # Set up a fake facts dict and add the selinux module under it
   

# Generated at 2022-06-23 01:41:33.190735
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector(None)
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collectors == set()

# Generated at 2022-06-23 01:41:34.592932
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    se = SelinuxFactCollector()
    assert se.name == 'selinux'

# Generated at 2022-06-23 01:41:36.700150
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
        assert SelinuxFactCollector() is not None

# Generated at 2022-06-23 01:41:39.807613
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == "selinux"
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-23 01:41:42.743609
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxf = SelinuxFactCollector()
    assert selinuxf.name == 'selinux'
    assert selinuxf._fact_ids == set()
    selinuxf.collect()

# Generated at 2022-06-23 01:41:50.540815
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()

    # Create a variable for the facts collected by the collect method
    selinux_facts_from_collect = {}

    # Run the collect method of the SelinuxFactCollector
    selinux_facts_from_collect = selinux_collector.collect()

    # Test if the selinux key is present in the collected facts
    assert 'selinux' in selinux_facts_from_collect

    # Test if the selinux_python_present key is present in the collected facts
    assert 'selinux_python_present' in selinux_facts_from_collect

# Generated at 2022-06-23 01:41:51.954745
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:41:54.886725
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test class SelinuxFactCollector.
    """
    selinux_collector = SelinuxFactCollector()

    return selinux_collector

# Generated at 2022-06-23 01:41:56.280439
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfc = SelinuxFactCollector()
    assert selinuxfc is not None

# Generated at 2022-06-23 01:41:59.140710
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    module = object()
    collected_facts = {}
    SelinuxFactCollector.collect(module, collected_facts)
    assert collected_facts['selinux_python_present'] is False

# Generated at 2022-06-23 01:42:01.353298
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector != None


# Generated at 2022-06-23 01:42:02.588118
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:42:08.530394
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import FallbackFactCollector
    from ansible.module_utils.facts import default_collectors

    for collector in default_collectors:
        if collector.__class__.__name__ == 'SelinuxFactCollector':
            selinux_fact_collector = collector
            break
    else:
        selinux_fact_collector = SelinuxFactCollector()

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


# Generated at 2022-06-23 01:42:13.880781
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    returned_facts_dict = SelinuxFactCollector.collect()

    assert len(returned_facts_dict) == 2
    assert 'selinux' in returned_facts_dict
    assert 'selinux_python_present' in returned_facts_dict
    assert isinstance(returned_facts_dict['selinux'], dict)

# Generated at 2022-06-23 01:42:14.483966
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'

# Generated at 2022-06-23 01:42:15.301033
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test constructor of class SelinuxFactCollector
    """
    assert SelinuxFactCollector

# Generated at 2022-06-23 01:42:18.626543
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    o = SelinuxFactCollector()
    assert o.name == 'selinux'
    assert o.collect() == {}

# Generated at 2022-06-23 01:42:22.298573
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:42:23.310612
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:42:25.531694
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-23 01:42:31.336866
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    d = selinux.selinux_getpolicytype()
    print (d)
    f = {'selinux_python_present': True,
         'selinux':
             {'type': 'targeted',
              'policyvers': 28,
              'config_mode': 'enforcing',
              'mode': 'permissive',
              'status': 'enabled'}
    }
    g = SelinuxFactCollector()
    f = g.collect()
    print(f)

# Generated at 2022-06-23 01:42:34.062004
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  selinux = SelinuxFactCollector()
  assert selinux.name == 'selinux'
  assert selinux._fact_ids == set()


# Generated at 2022-06-23 01:42:44.612546
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys

    # Backup the original selinux library which may be present
    old_selinux = sys.modules.get('selinux', None)

    # Create a mock selinux library
    module_selinux = type(sys)('selinux')
    module_selinux.is_selinux_enabled = lambda: True
    module_selinux.security_policyvers = lambda: "Number of policy versions"
    module_selinux.selinux_getpolicytype = lambda: (0, "Policy type")
    module_selinux.selinux_getenforcemode = lambda: (0, 1)
    module_selinux.security_getenforce = lambda: 0
    sys.modules['selinux'] = module_selinux

    selinuxfc = SelinuxFactCollector()
   

# Generated at 2022-06-23 01:42:50.361565
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collected_facts()"""
    from ansible.module_utils.facts.collector import FactCollector
    fact_collector = FactCollector("", {}, {}, {}, None)
    fact_collector.collectors['selinux'] = SelinuxFactCollector()
    new_facts = fact_collector.collect(module=None)
    assert isinstance(new_facts.get('selinux'), dict)

# Generated at 2022-06-23 01:43:00.101768
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""

    module = {}
    facts_dict = {}

    # Test when the selinux library is missing
    if HAVE_SELINUX:
        selinux.is_selinux_enabled = lambda: False
    else:
        have_selinux_python_library = False

    collector = SelinuxFactCollector()
    facts_dict_new = collector.collect()

    # Test that no exception was raised
    assert True is True

    # Test that the facts dict is as expected
    selinux_facts = {}
    selinux_facts['status'] = 'disabled'
    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        have_selinux_python_library = False

    assert facts_dict

# Generated at 2022-06-23 01:43:00.780545
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:43:10.234290
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector()
    res = selinux_fc.collect()
    exp = {'ansible_selinux': {'config_mode': 'unknown',
                               'mode': 'unknown',
                               'policyvers': 'unknown',
                               'status': 'enabled',
                               'type': 'unknown'},
           'ansible_selinux_python_present': True}

    assert res == exp


# Generated at 2022-06-23 01:43:13.828216
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SELINUX_FACTS = {'mode': 'disabled', 'status': 'disabled', 'type': 'unknown'}
    selinux_module = SelinuxFactCollector()
    collected_facts = selinux_module.collect()
    assert collected_facts['selinux'] == SELINUX_FACTS

# Generated at 2022-06-23 01:43:21.277449
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test method SelinuxFactCollector.collect"""

    module_mock = MagicMock()
    collected_facts_mock = MagicMock()

    fact_collector = SelinuxFactCollector(module=module_mock, collected_facts=collected_facts_mock)

    with patch('ansible.module_utils.facts.collector.selinux.is_selinux_enabled') as is_selinux_enabled_mock:
        is_selinux_enabled_mock.return_value = True

        with patch('ansible.module_utils.facts.collector.selinux.security_policyvers') as security_policyvers_mock:
            security_policyvers_mock.return_value = '25'


# Generated at 2022-06-23 01:43:26.866473
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create an object of the class SelinuxFactCollector
    selinux_fact_obj = SelinuxFactCollector()
    # Get the name of the class object
    class_name = selinux_fact_obj.__class__.__name__
    assert class_name == 'SelinuxFactCollector'
    # Check if class constructor executed properly
    assert selinux_fact_obj.name == 'selinux'
    assert selinux_fact_obj._fact_ids == set()

# Generated at 2022-06-23 01:43:28.909266
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    result = obj.collect()
    assert result['selinux_python_present'] == True

# Generated at 2022-06-23 01:43:37.441014
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    c = SelinuxFactCollector()
    assert c.collect() == {'selinux':
                              {'config_mode': 'unknown',
                               'mode': 'unknown',
                               'policyvers': 'unknown',
                               'status': 'disabled',
                               'type': 'unknown'},
                           'selinux_python_present': True}

# Generated at 2022-06-23 01:43:39.433992
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    o = SelinuxFactCollector()
    assert o.name == 'selinux'



# Generated at 2022-06-23 01:43:49.486207
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../test_data')
    selinux_stat = os.path.join(test_data_dir, 'selinux_status')
    selinux_types_dir = os.path.join(test_data_dir, 'selinux_types')
    selinux_type_files = [os.path.join(selinux_types_dir, x) for x in os.listdir(selinux_types_dir)]

    # Set up mocks for selinux.security_getenforce to return a value for each of the three
    # possible status values (enforcing, permissive, and disabled). Using classes instead of
    # functions since the functions are named and the class methods are private.

# Generated at 2022-06-23 01:43:51.878739
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:43:56.237183
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'

# Generated at 2022-06-23 01:43:59.345137
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids


# Generated at 2022-06-23 01:44:03.775785
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'
    assert SELINUX_MODE_DICT['1'] == 'enforcing'
    assert SELINUX_MODE_DICT['0'] == 'permissive'
    assert SELINUX_MODE_DICT['-1'] == 'disabled'

# Generated at 2022-06-23 01:44:07.894588
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:44:10.876849
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.collect() == { 'selinux': {}, 'selinux_python_present': False }

# Generated at 2022-06-23 01:44:19.573323
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    selinux_facts = facts.get('selinux')
    assert 'status' in selinux_facts
    if selinux_facts['status'] == 'enabled':
        assert 'mode' in selinux_facts
        assert selinux_facts['mode'] in SELINUX_MODE_DICT.values()
        assert 'policyvers' in selinux_facts
        assert 'type' in selinux_facts
        assert 'config_mode' in selinux_facts
        assert selinux_facts['config_mode'] in SELINUX_MODE_DICT.values()

# Generated at 2022-06-23 01:44:25.202504
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    collected_facts = {}

    # Create the instance of SelinuxFactCollector
    slx_col_obj = SelinuxFactCollector(None, collected_facts)

    # Collect facts
    rc = slx_col_obj.collect()
    assert rc == {'selinux': {'status': 'disabled'}, 'selinux_python_present': False}


test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:44:30.954051
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert isinstance(selinux_facts['selinux'], dict)
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-23 01:44:39.556657
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    Collector._initialize()
    facts_dict = FactCollector().collect(Collector._collectors)
    assert facts_dict['selinux']['status'] == 'enabled'
    assert facts_dict['selinux']['config_mode'] == 'enforcing'
    assert facts_dict['selinux']['mode'] == 'enforcing'
    assert facts_dict['selinux']['policyvers'] == 100
    assert facts_dict['selinux']['type'] == 'targeted'

# Generated at 2022-06-23 01:44:49.428702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.system.selinux import SelinuxFactCollector
    from ansible.module_utils.facts import get_all_facts

    # Create a mock module
    test_module = type(str(""), (object,), {'params': {}})
    setattr(test_module, 'exit_json', lambda x, **kwargs: None)

    # Create a mock object for the selinux_fact_collector class
    selinux_fact_collector = SelinuxFactCollector()
    setattr(selinux_fact_collector, 'collect', lambda x=None, y=None: {'selinux': {'mode': 'unknown'}})

# Generated at 2022-06-23 01:44:51.431213
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    expected_collector_name = 'selinux'
    assert c.name == expected_collector_name

# Generated at 2022-06-23 01:44:52.621125
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-23 01:45:03.416787
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create collector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary to store facts
    facts_dict = {}

    # Execute collect method
    facts_dict = selinux_fact_collector.collect(None, facts_dict)

    # Verify required keys are present in the returned dictionary
    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict
    selinux_facts = facts_dict.get('selinux')

    # Verify that boolean selinux_python_present is returned
    selinux_python_present = facts_dict.get('selinux_python_present')
    assert type(selinux_python_present) is bool

    # Verify required keys are present in the selinux dictionary
    assert 'status' in selinux_

# Generated at 2022-06-23 01:45:13.602423
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.selinux import SelinuxFactCollector

    selinux_fact_collector = SelinuxFactCollector()

    # No exception thrown when Python selinux module is NOT available
    with mock.patch('ansible.module_utils.compat.selinux', side_effect=ImportError):
        collected_facts = selinux_fact_collector.collect()
        assert collected_facts['selinux'] == {'status': 'Missing selinux Python library'}
        assert collected_facts['selinux_python_present'] == False

    # No exception thrown when Python selinux module is available

# Generated at 2022-06-23 01:45:16.677190
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert set(selinux_fc._fact_ids) == set()

# Generated at 2022-06-23 01:45:19.006573
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-23 01:45:29.573470
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = mock.MagicMock()
    collected_facts = mock.MagicMock()
    selinux_fact_collector = SelinuxFactCollector(module=module, collected_facts=collected_facts)
    assert selinux_fact_collector.name == 'selinux'
    collected_facts_keys = selinux_fact_collector.collect()

    assert collected_facts_keys['selinux_python_present'] == True

    assert 'selinux' in collected_facts_keys
    assert isinstance(collected_facts_keys['selinux'], dict)


# Generated at 2022-06-23 01:45:37.770413
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector. This
    method mocks the function is_selinux_enabled to yield different
    results.
    """
    selinux_facts = {}
    # Test for disabled status
    with mock.patch("ansible.module_utils.compat.selinux.is_selinux_enabled", return_value=False):
        selinux_facts_collector = SelinuxFactCollector()
        selinux_facts = selinux_facts_collector.collect()

    assert selinux_facts['selinux_python_present']
    assert selinux_facts['selinux']['status'] == 'disabled'

    # Test for enabled status

# Generated at 2022-06-23 01:45:48.765524
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def side_effect_selinux_is_enabled(*args, **kwargs):
        if args[0] == 'selinux_enabled':
            return True
        else:
            return False

    def side_effect_selinux_policyvers(*args, **kwargs):
        if args[0] == 'policyvers':
            return 100
        else:
            return 0

    def side_effect_selinux_getenforcemode(*args, **kwargs):
        if args[0] == 'selinux_getenforcemode':
            return 0, 'enabled'
        else:
            return 0, 'disabled'

    def side_effect_security_getenforce(*args, **kwargs):
        if args[0] == 'security_getenforce':
            return 1
        else:
            return 0

   

# Generated at 2022-06-23 01:45:55.497144
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    coll = SelinuxFactCollector()
    assert coll.name == 'selinux'
    assert coll._fact_ids == set()

# Generated at 2022-06-23 01:45:57.236812
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector(None)
    assert x

# Generated at 2022-06-23 01:46:00.221616
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector as sfc

    c = sfc()
    facts_dict = c.collect()

    assert facts_dict['selinux_python_present']

# Generated at 2022-06-23 01:46:08.022424
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create a custom class
    class MySelinuxFactCollector(SelinuxFactCollector):
        name = 'selinux'
        def __init__(self, module=None, collected_facts=None):
            self.collected_facts=collected_facts
    # create an instance of the custom class
    facts_collector = MySelinuxFactCollector()
    # run the collect method
    facts_collector.collect()
    # assert the status is unknown
    assert facts_collector.collected_facts['selinux']['status'] == 'unknown'

# Generated at 2022-06-23 01:46:10.764360
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Check that the class is successfully constructed.
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.collect() == {}

# Generated at 2022-06-23 01:46:17.865955
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Let's create a instance of SelinuxFactCollector
    selinux_fact_collector_ins = SelinuxFactCollector()

    # Select what facts to be collected
    selinux_fact_collector_ins.collect(module=None, collected_facts=None)

    for key in selinux_fact_collector_ins.fact_subset():
        print("%s : %s" % (key, selinux_fact_collector_ins.get_fact(key)))

if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-23 01:46:19.463488
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test whether the SelinuxFactCollector class could be initialized.
    SelinuxFactCollector()

# Generated at 2022-06-23 01:46:23.624374
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Testing with selinux library present
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()
    assert collector.collect() == {'selinux_python_present': True}
    assert collector.collect()['selinux']['status'] == 'enabled'

# Generated at 2022-06-23 01:46:24.739678
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:46:32.599237
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mod = module_mock('SelinuxFactCollector_collect')
    selinux = SelinuxFactCollector()

    class Test:
        def is_selinux_enabled(self):
            return True

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 1

        def selinux_getpolicytype(self):
            return (0, 'MLS')

        def security_policyvers(self):
            return 28
    selinux.module = Test()

    result = selinux.collect()

    assert result['selinux_python_present']
    assert 'disabled' not in result['selinux']['status']
    assert 'enabled' in result['selinux']['status']

# Generated at 2022-06-23 01:46:35.942601
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # NOTE: cannot test collect method because selinux library is required
    # and cannot be mocked without creating a new class
    pass

# Generated at 2022-06-23 01:46:38.652922
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_Selinux = SelinuxFactCollector()
    assert test_Selinux.name == 'selinux'
    assert test_Selinux._fact_ids == set()

# Generated at 2022-06-23 01:46:47.217955
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    def mock_is_selinux_enabled(self):
        return True

    def mock_selinux_getenforcemode(self):
        return (0, 1)

    def mock_getenforce(self):
        return 1

    def mock_selinux_getpolicytype(self):
        return (0, 'targeted')

    #mocked_selinux = Mock()
    #mocked_selinux.is_selinux_enabled = mock_is_selinux_enabled
    #mocked_selinux.selinux_getenforcemode = mock_selinux_getenforcemode
    #mocked_selinux.getenforce = mock_getenforce
    #mocked_selinux.selinux_

# Generated at 2022-06-23 01:46:50.056111
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfc = SelinuxFactCollector()
    assert selinuxfc.name == 'selinux'

# Generated at 2022-06-23 01:47:00.341173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # If the selinux library is missing, the only fact set
    # should be selinux_python_present.
    selinuxFactCollector = SelinuxFactCollector()
    facts = selinuxFactCollector.collect()

    assert 'selinux_python_present' in facts
    assert facts['selinux_python_present'] == False

    # Even though selinux_python_present is true, if the library
    # was not able to determine that SELinux is enabled, only the
    # status should be set.
    selinuxFactCollector = SelinuxFactCollector()
    facts = selinuxFactCollector.collect()

    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    assert facts['selinux']['status'] == 'disabled'

    # If the library is

# Generated at 2022-06-23 01:47:01.725136
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # check that a collector can be created
    SelinuxFactCollector()


# Generated at 2022-06-23 01:47:03.561608
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    se = SelinuxFactCollector()
    assert ('selinux' in se._fact_ids)

# Generated at 2022-06-23 01:47:10.144562
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    global SELINUX_MODE_DICT

    collector = SelinuxFactCollector()
    assert collector.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    SELINUX_MODE_DICT = {
        1: 'enforcing',
        0: 'permissive',
        -1: 'disabled'
    }

    selinux_stubs = {
        'is_selinux_enabled': lambda: False,
        'security_policyvers': lambda: 1,
        'selinux_getenforcemode': lambda: (1, 1),
        'security_getenforce': lambda: 1,
        'selinux_getpolicytype': lambda: (1, 'targeted')
    }


# Generated at 2022-06-23 01:47:13.912933
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import collector_registry
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c.collect() == {'selinux': {}, 'selinux_python_present': False}
    assert c.name in collector_registry


# Generated at 2022-06-23 01:47:23.133383
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from module_utils.facts.collector.selinux import SelinuxFactCollector

    test_collector = SelinuxFactCollector()

    test_result = {
        'selinux': {'config_mode': 'unknown',
                    'mode': 'unknown',
                    'policyvers': 'unknown',
                    'status': 'enabled',
                    'type': 'unknown'},
        'selinux_python_present': False
    }

    assert test_collector.collect() == test_result

# Generated at 2022-06-23 01:47:27.711530
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    class MyModule:
        def __init__(self, *args, **kwargs):
            pass

    class MyFacts:
        def __init__(self, *args, **kwargs):
            pass

    def get_distribution():
        return "Debian"

    module = MyModule()
    facts = MyFacts()
    selinux = SelinuxFactCollector(module=module, collected_facts=facts)
    assert selinux is not None

# Generated at 2022-06-23 01:47:31.252814
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-23 01:47:31.918853
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:47:39.799941
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()

    assert result['selinux_python_present'] is True
    assert result['selinux']['status'] == 'enabled'
    assert result['selinux']['mode'] == 'permissive'
    assert result['selinux']['policyvers'] == '28'
    assert result['selinux']['config_mode'] == 'permissive'
    assert result['selinux']['type'] == 'targeted'

# Generated at 2022-06-23 01:47:43.507105
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    assert 'selinux' in facts
    assert 'status' in facts['selinux']

# Generated at 2022-06-23 01:47:45.684680
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    results = fact_collector.collect()
    assert len(results['selinux']) > 0

# Generated at 2022-06-23 01:47:56.832942
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect()

    assert(facts['selinux_python_present'])
    assert(facts['selinux']['status'] == 'enabled')
    assert(facts['selinux']['policyvers'] == '28')
    assert(facts['selinux']['config_mode'] == 'enforcing')
    assert(facts['selinux']['mode'] == 'enforcing')
    assert(facts['selinux']['type'] == 'targeted')

# Generated at 2022-06-23 01:47:58.875755
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert isinstance(obj, BaseFactCollector)

# Generated at 2022-06-23 01:48:04.806668
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class MockModule:
        def __init__(self, name):
            self.name = name
            self.params = {}
            self.module_arg_spec = {}

    class MockCollectedFacts:
        def __init__(self, name):
            self.name = name
            self.facts = {}

    assert SelinuxFactCollector.collect(MockModule('test'), MockCollectedFacts('test'))

# Generated at 2022-06-23 01:48:15.104518
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import facts

    fact_collector = SelinuxFactCollector()

    mock_module = Mock(
        params={},
        _ansible_version='2.8.0dev0'
    )

    mock_selinux = Mock()
    mock_selinux.is_selinux_enabled.return_value = True
    mock_selinux.security_policyvers.return_value = 'test_policyvers'
    mock_selinux.selinux_getenforcemode.return_value = (1, 1)
    mock_selinux.security_getenforce.return_value = 1
    mock_selinux.selinux_getpolicytype.return_value = (1, 1)

    facts.selinux = mock_selinux
    selinux_facts

# Generated at 2022-06-23 01:48:18.964737
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None

    sfc = SelinuxFactCollector()
    facts_dict = sfc.collect(module, collected_facts)
    assert 'selinux' in facts_dict

# Generated at 2022-06-23 01:48:21.032806
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:48:22.803142
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector(None, None)
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:48:33.489398
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    import tempfile
    module_path = os.path.dirname(sys.modules['ansible.module_utils.facts.system'].__file__)
    collector = SelinuxFactCollector()
    os.environ['ANSIBLE_SELINUX_SPECIAL_FS'] = module_path
    os.environ['ANSIBLE_SELINUX_SPECIAL_MOUNT'] = os.path.join(module_path, 'data', 'selinux_special_mount')
    os.environ['ANSIBLE_SELINUX_POLICYVERS'] = '24'
    os.environ['ANSIBLE_SELINUX_CONFIG_MODE'] = '0'
    os.environ['ANSIBLE_SELINUX_MODE'] = '1'
    os.environ

# Generated at 2022-06-23 01:48:37.726104
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector()
    # Since selinux module is not installed on every system, selinux_python_present
    # must be set to False.
    assert selinux_fc.collect()['selinux_python_present'] == False

# Generated at 2022-06-23 01:48:41.377039
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:48:51.952729
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux = SelinuxFactCollector()
    collected_facts = {}

    # Test that the selinux status is 'disabled' when the selinux library is not present
    selinux.collect(collected_facts=collected_facts)
    assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    assert collected_facts['selinux_python_present'] == False

    # Test that the selinux status is 'disabled' when the selinux library is present and selinux is not enabled
    selinux.collect(collected_facts=collected_facts)
    assert collected_facts['selinux']['status'] == 'disabled'
    assert collected_facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:48:55.356173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sf = SelinuxFactCollector()
    assert sf.name == 'selinux'
    assert sf._fact_ids == set()


# Generated at 2022-06-23 01:49:04.507526
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of a SelinuxFactCollector object
    selinuxfactcollector = SelinuxFactCollector()

    # Call the SelinuxFactCollector.collect method and store the results in a variable
    result = selinuxfactcollector.collect()

    # Check if the result is as expected
    if not isinstance(result, dict):
        print("The data returned by SelinuxFactCollector.collect() is not a dictionary.")
    elif 'selinux' not in result:
        print("The selinux data key does not exist in the result.")
    elif not isinstance(result['selinux'], dict):
        print("The selinux data returned by SelinuxFactCollector.collect() is not a dictionary.")

# Generated at 2022-06-23 01:49:11.939966
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector

    :return: True if all tests pass
    :rtype: bool
    """
    SelinuxFactCollector = SelinuxFactCollector()
    facts_dict = SelinuxFactCollector.collect()
    return True

# Generated at 2022-06-23 01:49:22.851152
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create an instance of the SelinuxFactCollector class
    selinux_collector = SelinuxFactCollector()

    # Try the collect method of the instance
    facts_dict = selinux_collector.collect()

    # Assert that the fact 'selinux_python_present' is present in the returned dictionary
    assert isinstance(facts_dict, dict)
    assert 'selinux_python_present' in facts_dict.keys()
    assert (facts_dict['selinux_python_present'] == True) or (facts_dict['selinux_python_present'] == False)

    # Assert that the fact 'selinux' is present in the returned dictionary
    assert 'selinux' in facts_dict.keys()
    assert isinstance(facts_dict['selinux'], dict)

    # Assert

# Generated at 2022-06-23 01:49:24.853027
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x is not None


# Generated at 2022-06-23 01:49:27.510915
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Populate mocks
    s = SelinuxFactCollector()
    s.collect()

# Generated at 2022-06-23 01:49:29.729214
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert not collector._fact_ids
    assert collector.collect()

# Generated at 2022-06-23 01:49:31.286496
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-23 01:49:35.867857
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test the Selinux fact collector."""

    #
    # Test normal behavior.
    #

    # Create a Selinux fact collector object.
    seinfoc = SelinuxFactCollector()
    assert seinfoc.name == 'selinux'
    assert seinfoc._fact_ids == set()
    seinfoc._fact_ids = set()

# Generated at 2022-06-23 01:49:36.867017
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()


# Generated at 2022-06-23 01:49:38.951685
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts._fact_ids == set()
    assert selinux_facts.name == 'selinux'


# Generated at 2022-06-23 01:49:41.376064
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == "selinux"


# Generated at 2022-06-23 01:49:43.579986
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    facts_dict = collector.collect()
    assert facts_dict['selinux_python_present'] == True

# Generated at 2022-06-23 01:49:48.015079
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-23 01:49:50.217619
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    o = SelinuxFactCollector()
    assert o.name == 'selinux'
    assert o._fact_ids == set()


# Generated at 2022-06-23 01:49:52.881530
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfactcollector = SelinuxFactCollector()
    assert selinuxfactcollector.name == 'selinux'
    assert selinuxfactcollector._fact_ids == set()


# Generated at 2022-06-23 01:49:56.594649
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ##
    from ansible.module_utils.facts import collector

    # instantiate collector
    sfc = collector.get_collector('selinux')

    # get facts (fake)
    # collect() is invoked by the Ansible Facts module
    sf = sfc.collect()

    # test if the required keys exist

# Generated at 2022-06-23 01:50:00.666831
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    cp = SelinuxFactCollector()
    facts_dict = {}
    cp.collect(collected_facts=facts_dict)
    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict
    assert isinstance(facts_dict['selinux'], dict)
    assert isinstance(facts_dict['selinux_python_present'], bool)