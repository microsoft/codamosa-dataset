

# Generated at 2022-06-23 01:40:00.730473
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    _module = FakeModule('test')

    # Run collect
    _collector = SelinuxFactCollector()
    _collector.collect(_module)

    # Asserts
    selinux_facts = _collector.fact_list

# Generated at 2022-06-23 01:40:10.203251
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def test_method(mocker):
        if not HAS_SELINUX_LIBRARY:
            return
        selinux_facts = {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'enforcing',
            'mode': 'enforcing',
            'type': 'targeted'
        }
        config = mocker.MagicMock()
        config.selinux.is_selinux_enabled.return_value = True
        config.selinux.security_policyvers.return_value = 'unknown'
        config.selinux.selinux_getenforcemode.return_value = (0, 1)
        config.selinux.security_getenforce.return_value = 1
        config.selinux.selinux_getpolicytype.return_

# Generated at 2022-06-23 01:40:12.732638
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.fact_ids == set()

# Generated at 2022-06-23 01:40:17.449865
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Verify that there are no arguments to the constructor
    collector = SelinuxFactCollector()
    assert(collector)
    assert(collector.name == 'selinux')
    assert(collector._fact_ids == set())

# Generated at 2022-06-23 01:40:23.067566
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxfactcollector = SelinuxFactCollector()
    collected_facts = dict()
    result = selinuxfactcollector.collect(None, collected_facts)
    assert result['selinux_python_present'] is False
    assert 'status' in result['selinux']
    assert result['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-23 01:40:33.862179
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import selinux
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    selinux._import_failed = False
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: 0
    selinux.selinux_getenforcemode = lambda: (0,0)
    selinux.security_getenforce = lambda: 0
    selinux.selinux_getpolicytype = lambda: (0, 'foo')
    result = SelinuxFactCollector().collect()
    result['selinux']['policyvers'] = 'unknown'
    result['selinux']['config_mode'] = 'enforcing'
    result['selinux']['mode'] = 'enforcing'
   

# Generated at 2022-06-23 01:40:36.239706
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test if collector can be instantiated without failures.
    """

    fact_module = SelinuxFactCollector()
    assert fact_module


# Generated at 2022-06-23 01:40:39.966463
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect() == {}


# Generated at 2022-06-23 01:40:46.136972
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert type(s) == SelinuxFactCollector

# Unit tests for collect method of class SelinuxFactCollector

# Generated at 2022-06-23 01:40:50.332511
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    fact_ids = set()
    fact_ids.add('selinux')
    fact_ids.add('selinux_python_present')
    assert selinux_fact_collector._fact_ids == fact_ids


# Generated at 2022-06-23 01:40:53.883845
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  '''
  Unit test for method collect of class SelinuxFactCollector
  '''
  collector = SelinuxFactCollector()
  collector.collect()
  assert collector.name == 'selinux'
  return True


# Generated at 2022-06-23 01:41:06.239434
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup
    class MockModule(object):
        def __init__(self, selinux_python_present):
            self.selinux_python_present = selinux_python_present
            self.selinux_facts = {'config_mode': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown', 'status': 'disabled', 'type': 'unknown'}

    class MockSelinux(object):
        def __init__(self, is_selinux_enabled, security_policyvers, selinux_getenforcemode, security_getenforce, selinux_getpolicytype):
            self.is_selinux_enabled = is_selinux_enabled
            self.security_policyvers = security_policyvers
            self.selinux_getenforcemode = selinux_getenforcemode

# Generated at 2022-06-23 01:41:12.367755
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = {}

    # Create test instances of ObjClass, ObjInstance, and SelinuxFactCollector
    fact_collector = SelinuxFactCollector()

    # Call method collect of SelinuxFactCollector instance
    fact_collector.collect(module, collected_facts)

# Generated at 2022-06-23 01:41:14.642874
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:41:16.375857
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'


# Generated at 2022-06-23 01:41:21.830509
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert set(selinux_collector._fact_ids) == set(['selinux', 'selinux_python_present']), \
        "SelinuxFactCollector does not have only two fact_ids selinux and selinux_python_present"

# Generated at 2022-06-23 01:41:29.023176
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {'selinux': {'config_mode': 'unknown', 'type': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown'}, 'selinux_python_present': True, 'ansible_selinux': {'config_mode': 'unknown', 'type': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown'}}
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()
    assert selinux_fact_collector.collect() == selinux_facts

# Generated at 2022-06-23 01:41:37.787172
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    result = collector.collect()
    assert result['selinux']['status'] in ['enabled', 'disabled', 'Missing selinux Python library']
    if result['selinux']['status'] == 'enabled':
        assert result['selinux']['config_mode'] in ['enforcing', 'permissive', 'disabled', 'unknown']
        assert result['selinux']['mode'] in ['enforcing', 'permissive', 'disabled', 'unknown']
        assert result['selinux']['policyvers']
        assert result['selinux']['type'] in ['targeted', 'mls', 'unknown']
    assert isinstance(result['selinux_python_present'], bool)

# Generated at 2022-06-23 01:41:41.039094
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SELINUX_CLASS = SelinuxFactCollector()
    print(type(SELINUX_CLASS))
    print(SELINUX_CLASS)

if __name__ == "__main__":
    test_SelinuxFactCollector()

# Generated at 2022-06-23 01:41:44.019617
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # creating an object of SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()

    # calling method collect
    selinux_collector.collect()


# Generated at 2022-06-23 01:41:45.075990
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:41:48.013213
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector

# Generated at 2022-06-23 01:42:00.138421
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest

    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.collectors.selinux.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collectors.selinux import selinux

    fact_collector = SelinuxFactCollector()

    # Backup selinux library functions
    old_is_selinux_enabled = selinux.is_selinux_enabled
    old_security_policyvers = selinux.security_policyvers
    old_selinux_getenforcemode = selinux.selinux_getenforcemode
    old_security_getenforce = selinux.security_getenforce
    old_selinux_getpolicytype = selinux.selinux_getpolicytype

    # Mock selinux

# Generated at 2022-06-23 01:42:11.962784
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    # Replace SelinuxFactCollector with a mock class for testing
    class MySelinuxFactCollector(SelinuxFactCollector):
        def __init__(self):
            super(MySelinuxFactCollector, self).__init__()
            # Make the method "collect" of class "selinux" callable
            self.collect = self._collect_mock

        # Mock selinux.is_selinux_enabled
        def _is_selinux_enabled(self):
            return True

        # Mock selinux.selinux_getpolicy

# Generated at 2022-06-23 01:42:15.962477
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test function of class SelinuxFactCollector
    """
    # Ensure that we can collect facts without the selinux library being present
    selinux_collector = SelinuxFactCollector()
    try:
        selinux_collector.collect()
    except ImportError:
        assert False

# Generated at 2022-06-23 01:42:26.172103
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    # Test with selinux enabled
    selinux._selinux_enabled = True
    selinux.security_getenforce = lambda: 0
    selinux.selinux_getenforcemode = lambda: (0, 0)
    selinux.selinux_getpolicytype = lambda: (0, 'targeted')
    selinux.security_policyvers = lambda: 30

    collector = SelinuxFactCollector()

    # Collect, but don't pass in any facts as that's what would happen
    # with ansible.module_utils.facts.facts.get_facts()
    facts_dict = collector.collect(collected_facts={})
    assert facts_dict is not None
    assert isinstance(facts_dict, dict)

# Generated at 2022-06-23 01:42:33.259992
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert isinstance(facts_dict, dict)

    selinux_facts = facts_dict['selinux']
    assert isinstance(selinux_facts, dict)

    assert selinux_facts['status'] in ['enabled', 'disabled', 'Missing selinux Python library']
    assert selinux_facts['policyvers'] in ['unknown', int]
    assert selinux_facts['config_mode'] in ['unknown', 'enforcing', 'permissive', 'disabled']
    assert selinux_facts['mode'] in ['unknown', 'enforcing', 'permissive', 'disabled']
    assert selinux_facts['type'] in ['unknown', str]


# Generated at 2022-06-23 01:42:36.353324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None


# Generated at 2022-06-23 01:42:38.649048
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s
    assert s.name == 'selinux'

# Generated at 2022-06-23 01:42:43.330192
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import imp
    module = imp.new_module('test_SelinuxFactCollector')
    module.HAVE_SELINUX = False
    module.selinux = None
    module.__name__ = 'ansible.module_utils.facts.network.selinux'
    module.selinux.is_selinux_enabled = None
    collector = SelinuxFactCollector(module)
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:42:47.937832
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector
    """
    fact_collector = SelinuxFactCollector()
    # When SELinux is disabled
    fact_collector.collect()
    # When SELinux is enabled
    fact_collector.collect()


# Generated at 2022-06-23 01:42:59.498463
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'

    assert selinux_facts['selinux']['policyvers'] != 'unknown'
    assert selinux_facts['selinux']['config_mode'] != 'unknown'
    assert selinux_facts['selinux']['mode'] != 'unknown'
    assert selinux_facts['selinux']['type'] != 'unknown'

# Run the tests (only if SELinux Python library is present)

# Generated at 2022-06-23 01:43:02.331220
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_instance = SelinuxFactCollector()
    assert selinux_instance.name == 'selinux'

# Generated at 2022-06-23 01:43:14.595729
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    Params:
        module: the AnsibleModule object
        collected_facts: the existing facts collected
    """
    test_instance = SelinuxFactCollector()

    # If the selinux Python library is not present, ensure collect returns the
    # correct values
    test_instance.HAVE_SELINUX = False
    test_facts = test_instance.collect()
    assert test_facts['selinux_python_present'] == False
    assert test_facts['selinux']['status'] == 'Missing selinux Python library'

    # If the selinux Python library is present, ensure collect returns the
    # correct values
    test_instance.HAVE_SELINUX = True
    test_facts = test_instance.collect()
    assert test_

# Generated at 2022-06-23 01:43:18.080838
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()

    if not HAVE_SELINUX:
        assert facts_dict['selinux_python_present'] == False
    else:
        assert facts_dict['selinux_python_present'] == True

# Generated at 2022-06-23 01:43:20.507979
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    
    # Skip test if selinux library is missing
    if not HAVE_SELINUX:
        return

    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-23 01:43:28.176667
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Arrange
    potential_facts = {'selinux': {'status': 'enabled',
                                   'current_mode': 'enforcing',
                                   'config_mode': 'enforcing',
                                   'policy_version': '26',
                                   'policy_type': 'targeted'}}
    # Act
    fact_collector = SelinuxFactCollector()
    collected_facts = fact_collector.collect(module=None, collected_facts=None)

    # Assert
    assert collected_facts["ansible_local"]["selinux"] == potential_facts['selinux']


# Generated at 2022-06-23 01:43:31.974078
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import selinux
    test_object = SelinuxFactCollector()

    test_object.collect()

# Generated at 2022-06-23 01:43:36.096861
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-23 01:43:39.780618
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:43:42.920120
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_SelinuxFactCollector = SelinuxFactCollector()
    assert test_SelinuxFactCollector


# Generated at 2022-06-23 01:43:45.001064
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-23 01:43:47.733776
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:43:56.224769
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""

    #
    # Automated test using the mock library
    #

    # Creating a mock module
    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    # Mocking import selinux to raise an ImportError exception
    # when called from AnsibleCollectionFactsCollector
    class SelinuxMock(object):
        @staticmethod
        def is_selinux_enabled():
            return False

    # Mocking import selinux to not raise an ImportError exception
    # when called from AnsibleCollectionFactsCollector
    class SelinuxMock2(object):
        @staticmethod
        def is_selinux_enabled():
            return True


# Generated at 2022-06-23 01:43:58.046976
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc is not None

# Generated at 2022-06-23 01:44:01.890591
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()



# Generated at 2022-06-23 01:44:07.805829
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Validates that SelinuxFactCollector works as expected
    """
    selinux_facts = {
        'config_mode': 'permissive',
        'mode': 'enforcing',
        'status': 'enabled',
        'policyvers': '28',
        'type': 'targeted'
    }
    collector = SelinuxFactCollector()
    actual_ansible_facts = collector.collect()
    assert actual_ansible_facts is not None
    assert actual_ansible_facts['selinux_python_present'] is True
    assert actual_ansible_facts['selinux'] == selinux_facts

# Generated at 2022-06-23 01:44:10.994648
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test that the constructor works with a mock module
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:44:14.227714
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux', \
        "name method of SelinuxFactCollector should return string with name 'selinux'"


# Generated at 2022-06-23 01:44:15.605447
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-23 01:44:23.528109
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector = FactsCollector(module=None, collected_facts=None)
    selinux_fact_collector = SelinuxFactCollector(module=None, collected_facts=facts_collector._collected_facts)
    facts = selinux_fact_collector.collect(module=None, collected_facts=facts_collector._collected_facts)
    assert facts['selinux_python_present'] is not None, "Fact selinux_python_present was not collected"
    assert facts['selinux'] is not None, "Fact selinux was not collected"

# Generated at 2022-06-23 01:44:25.209036
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()

# Generated at 2022-06-23 01:44:26.580035
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:44:31.527094
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set(['selinux', 'selinux_python_present'])
    assert isinstance(selinux_collector._fact_ids, set)

# Generated at 2022-06-23 01:44:34.632228
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-23 01:44:37.626180
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    assert SelinuxFactCollector.collect() == {}


# Generated at 2022-06-23 01:44:41.085413
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert len(selinux_fact_collector._fact_ids) == 0


# Generated at 2022-06-23 01:44:50.583310
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Run method collect
    selinux_facts = selinux_fact_collector.collect()

    # Make sure the status key is present
    assert 'status' in selinux_facts['selinux']
    # Make sure selinux_python_present is True or False
    assert isinstance(selinux_facts['selinux_python_present'], bool)
    # If selinux_python_present is False, skip next checks
    if selinux_facts['selinux_python_present']:
        assert isinstance(selinux_facts['selinux']['policyvers'], str)
        assert isinstance(selinux_facts['selinux']['config_mode'], str)


# Generated at 2022-06-23 01:44:55.450532
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Check that the constructor of class SelinuxFactCollector works correctly.

    :returns: ``True`` if the constructor works correctly, otherwise ``False``
    :rtype: bool
    """
    obj = SelinuxFactCollector()
    return obj


# Generated at 2022-06-23 01:44:56.738683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-23 01:44:58.156484
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert True

# Generated at 2022-06-23 01:45:09.102686
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fc = SelinuxFactCollector()

    # Create a facts dict that will be passed to the method collect
    test_facts = {}

    # Save the result of the collect method
    result = selinux_fc.collect(collected_facts=test_facts)

    # Assert that the returned result is a dictionary
    assert isinstance(result, dict)

    # Assert that the returned result contains the correct keys
    assert 'selinux_python_present' in result
    assert 'selinux' in result

    # Assert that the returned result['selinux'] is a dictionary
    assert isinstance(result['selinux'], dict)

    # Assert that the returned result['selinux'] dictionary has at least the following keys
    # 'status', 'mode', '

# Generated at 2022-06-23 01:45:12.056262
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:45:12.696730
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-23 01:45:15.430587
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert 'selinux' in result
    assert 'status' in result['selinux']

# Generated at 2022-06-23 01:45:19.111227
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    name = 'selinux'
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, BaseFactCollector)
    assert name == selinux_fact_collector.name

# Generated at 2022-06-23 01:45:28.727619
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock object of AnsibleModule
    AnsibleModule = Mock()
    AnsibleModule.check_mode = False
    AnsibleModule.params = {}
    AnsibleModule.run_command.return_value = (0, 'libselinux 2.7-4.el8.1\n', '')

    # Create a mock object of BaseFactCollector
    bfc = BaseFactCollector(AnsibleModule)

    # Create a mock object of SelinuxFactCollector
    sfc = SelinuxFactCollector(bfc)

    ansible_selinux_facts = sfc.collect()
    assert ansible_selinux_facts['selinux_python_present'] is True

# Generated at 2022-06-23 01:45:31.015838
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == "selinux"

# Generated at 2022-06-23 01:45:35.415810
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create instance of class SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()

    # Create instance of class AnsibleModuleFake
    module = AnsibleModuleFake()

    # Call method collect of class SelinuxFactCollector, passing parameters module and collected_facts
    selinux_facts = selinux_collector.collect(module=module, collected_facts=None)

    # Check if facts_dict attribute is present in selinux_facts
    assert 'facts_dict' in dir(selinux_facts)

    # Check if selinux attribute is present in selinux_facts
    assert 'selinux' in selinux_facts

    # Check if status attribute is present in selinux_facts
    assert 'status' in selinux_facts['selinux']

    # Check if selinux_python_present attribute is present

# Generated at 2022-06-23 01:45:46.618457
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    #
    # setup test data
    #
    # test SelinuxFactCollector class with selinux Python library available
    test_selinux_present_list = []
    test_selinux_present_list.append(True)
    test_selinux_present_list.append(False)
    selinux_python_present_list = []
    selinux_python_present_list.append(True)
    selinux_python_present_list.append(False)

    #
    # setup mocks
    #
    # setup mock for AnsibleModule()
    mock_ansible_module = MagicMock()
    # setup mock for AnsibleModule().params
    mock_ansible_module.params = MagicMock()
    # setup mock for BaseFactCollector()
    mock_base_fact_collector = Magic

# Generated at 2022-06-23 01:45:49.445974
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids

# Generated at 2022-06-23 01:46:02.707762
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Patch the selinux Python library
    ansible_module = AnsibleModuleMock()
    import ansible.module_utils.facts.selinux as selinux_module
    selinux_module.selinux = ansible_module

    # Build the collector and run the collect method with empty fects
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()

    # Assertions
    assert facts['selinux_python_present'] == True
    assert facts['selinux']['status'] == 'disabled'
    assert facts['selinux']['policyvers'] == 'unknown'
    assert facts['selinux']['config_mode'] == 'unknown'
    assert facts['selinux']['mode'] == 'unknown'

# Generated at 2022-06-23 01:46:04.102420
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

    sel_obj = SelinuxFactCollector()
    assert sel_obj.name == 'selinux'


# Generated at 2022-06-23 01:46:07.426940
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    m_selinux = SelinuxFactCollector()
    assert m_selinux.name == 'selinux'
    assert m_selinux._fact_ids == set()


# Generated at 2022-06-23 01:46:08.876696
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert  SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:46:18.732262
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This test is primarily for 100% code coverage
    # as the functionality will not work as expected when selinux is not installed.
    from ansible.module_utils.facts import collector
    module = collector.BaseFactCollector()
    module._is_platform_windows = False
    module.selinux = None
    module.selinux_python_present = None

    # case 1: module.selinux is not present
    assert SelinuxFactCollector.collect(None, None) == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # case 2: module.selinux is present

# Generated at 2022-06-23 01:46:19.953930
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:46:22.127790
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-23 01:46:31.463623
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network import NetworkCollector

    # Create the selinux class
    selinux_collector = SelinuxFactCollector()

    # Compile a list of all the possible collectors
    collector_classes = Collector.collectors_classes()
    collector_classes.extend(NetworkCollector.collectors_classes())

    # Add the selinux class as it is not a NetworkCollector
    collector_classes['selinux'] = SelinuxFactCollector

    # Initialize collected facts and delete the selinux key
    collected_facts = Collector.collect(module=None, collector_classes=collector_classes)

    # Delete the selinux key as it will be created by the collect method
    del collected_facts['selinux']



# Generated at 2022-06-23 01:46:42.052879
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # create a mock module
    module = AnsibleMock()
    module.params = dict()
    module.params['gather_subset'] = ['all']
    collected_facts = dict()

    # create a mock selinux library or raise an exception if the selinux library
    # is missing

# Generated at 2022-06-23 01:46:52.787986
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""

    # Create a temporary dict for collected_facts
    collected_facts = dict()

    # Create an instance of the SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Call the collect method.
    returned_facts = selinux_fact_collector.collect(collected_facts=collected_facts)
    assert returned_facts == collected_facts

    # If the selinux Python library is not present, then only set the status
    if not HAVE_SELINUX:
        assert collected_facts['selinux']
        assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
        assert not collected_facts['selinux']['config_mode']

# Generated at 2022-06-23 01:46:54.970813
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux module not present on system
    selinux_obj = SelinuxFactCollector()
    selinux_obj.collect()

# Generated at 2022-06-23 01:46:55.983415
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-23 01:46:57.938256
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
     assert SelinuxFactCollector.name == 'selinux'
     assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:47:10.613555
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a mock module and selinux
    mock_module = MagicMock(name='module')
    mock_selinux = MagicMock(name='selinux')

    # Mock selinux
    mock_selinux.is_selinux_enabled.return_value = True
    mock_selinux.security_policyvers.return_value = '28'
    mock_selinux.selinux_getenforcemode.return_value = (0, 1)
    mock_selinux.security_getenforce.return_value = 1
    mock_selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Set the module to know the selinux library is installed
    mock_module.selinux_python_present = True

    # Call the collect method of the class

# Generated at 2022-06-23 01:47:21.776519
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Skip if selinux Python library is not present
    try:
        from ansible.module_utils.compat import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False
    if not HAVE_SELINUX:
       raise unittest.SkipTest("SELinux Python library not present.")

    # Save the current mode to restore it later
    mode = selinux.security_getenforce()

    # Test when SELinux is disabled
    selinux.security_setenforce(0)
    assert selinux.is_selinux_enabled() == False

    s = SelinuxFactCollector()
    d = s.collect()
    assert 'selinux_python_present' in d
    assert d['selinux_python_present'] == True


# Generated at 2022-06-23 01:47:23.640944
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:47:26.128920
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert len(selinux_fc._fact_ids) == 0

# Generated at 2022-06-23 01:47:37.262888
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import throttling
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.system import distro
    from ansible.module_utils.facts.system import network
    from ansible.module_utils.facts.system import platform
    from ansible.module_utils.facts.system import selinux
    from ansible.module_utils.facts.system import virtual
    import selinux
    selinux_mock = selinux.selinux
    selinux_mock.is_selinux_enabled = Mock(return_value=False)
    facts = dict()

# Generated at 2022-06-23 01:47:40.160267
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModuleMock()
    x = SelinuxFactCollector(module)
    assert x.name == 'selinux'
    assert not x._fact_ids

# This is used in unit tests to ensure the class is importing properly

# Generated at 2022-06-23 01:47:50.111340
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import ansible.module_utils.facts.collector

    ansible.module_utils.facts.collector.HAVE_SELINUX = False
    factCollector = SelinuxFactCollector()
    facts_dict = factCollector.collect()
    assert facts_dict['selinux_python_present'] is False
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'

    ansible.module_utils.facts.collector.HAVE_SELINUX = True
    factCollector = SelinuxFactCollector()
    facts_dict = factCollector.collect()
    assert facts_dict['selinux_python_present'] is True

# Generated at 2022-06-23 01:47:53.925261
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Constructor for SelinuxFactCollector class
    """
    selinux_facts_obj = SelinuxFactCollector()
    assert selinux_facts_obj.name == 'selinux'
    assert selinux_facts_obj._fact_ids == set({'selinux_python_present'})


# Generated at 2022-06-23 01:48:06.239228
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux library is not present
    # Expect:
    # selinux_python_present: False
    # selinux.status: 'Missing selinux Python library'
    fact_collector = SelinuxFactCollector()
    fact_collector._module = None
    fact_collector._collected_facts = {}
    fact_collector._have_selinux = False
    facts = fact_collector.collect()
    assert facts['selinux_python_present'] is False
    assert facts['selinux']['status'] == 'Missing selinux Python library'

    # selinux library is present
    # Expect:
    # selinux_python_present: True
    # selinux.status: 'disabled'
    fact_collector = SelinuxFactCollector()
    fact_collector._module = None
    fact

# Generated at 2022-06-23 01:48:09.927881
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # set the function and name of the object
    SELINUX = SelinuxFactCollector()
    assert SELINUX.name == "selinux"
    assert SELINUX._fact_ids == set()


# Generated at 2022-06-23 01:48:17.803834
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockFactCollector(object):
        def __init__(self):
            self.collected_facts = {}

    # Case 1: If the selinux Python library is missing, only set the status and selinux_python_present facts
    # because there is no way to tell if SELinux is enabled or disabled on the system without the library.
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-23 01:48:21.195639
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == "selinux"
    assert x._fact_ids == set()
    assert repr(x) == "<SelinuxFactCollector(name='selinux', fact_ids=set())>"

# Generated at 2022-06-23 01:48:32.242028
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test selinux facts collector"""

    # Test with a mock selinux module
    module = MagicMock()
    selinux_facts = SelinuxFactCollector(module)

    # Test selinux facts collection
    module.is_selinux_enabled.return_value = False
    selinux_facts.collect(module)

    assert selinux_facts._fact_ids == {'selinux.status', 'selinux.selinux_python_present'}
    assert selinux_facts.get_facts() == {
        'selinux': {'status': 'disabled'},
        'selinux_python_present': True
    }

    module.is_selinux_enabled.return_value = True

# Generated at 2022-06-23 01:48:39.673888
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Returns a dictionary of the SELinux facts.  Returns an empty dictionary
    if, for example, SELinux is not running, or the selinux library
    is missing.
    """

    # we skip testing if required libraries are missing
    if not HAVE_SELINUX:
        return

    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()

    # Expect to have 'selinux' in facts_dict
    assert 'selinux' in facts_dict



# Generated at 2022-06-23 01:48:49.479711
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Patch modules
    moduleMock = Mock(return_value=None)
    selinuxMock = Mock(return_value=True)
    selinux.is_selinux_enabled = selinuxMock

    import sys
    sys.modules['ansible.module_utils.facts.collector.base'] = Mock(return_value=None)
    sys.modules['ansible.module_utils.compat'] = Mock(return_value=None)
    sys.modules['ansible.module_utils.compat.selinux'] = selinux
    sys.modules['ansible.module_utils.selinux_python_present'] = moduleMock
    # Import module
    from ansible.modules.system.selinux import selinux_facts

    # Instantiate class
    selinuxFactCollector = selinux_facts.S

# Generated at 2022-06-23 01:48:52.412698
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_info = SelinuxFactCollector()
    assert selinux_info.name == 'selinux'

# Generated at 2022-06-23 01:48:56.027712
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector.name
    assert not selinux_fact_collector._fact_ids

# Generated at 2022-06-23 01:48:57.441851
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:48:59.139091
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'
    assert s._fact_ids is not None

# Generated at 2022-06-23 01:49:01.217103
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:49:10.288142
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    c = SelinuxFactCollector()
    assert c.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-23 01:49:21.111416
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Disable module import so we can re-enable it afterwards
    selinux = sys.modules.pop('selinux', None)

# Generated at 2022-06-23 01:49:23.853334
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-23 01:49:33.982498
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert 'selinux_python_present' in result
    assert 'selinux' in result
    assert isinstance(result['selinux'], dict)
    assert 'status' in result['selinux']
    if result['selinux_python_present']:
        assert 'policyvers' in result['selinux']
        assert 'config_mode' in result['selinux']
        assert 'mode' in result['selinux']
        assert 'type' in result['selinux']

# Generated at 2022-06-23 01:49:40.802743
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This test method is called when tests/hacking/test_module_utils.py
    is run to test the 'collect' method of class SelinuxFactCollector.
    """

    # Initialize collector
    selinux_fact_collector = SelinuxFactCollector()

    # Collect facts
    facts_dict = selinux_fact_collector.collect()

    # Return the facts collected
    return facts_dict

# Generated at 2022-06-23 01:49:41.824743
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:49:44.883015
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect() == {}

# Generated at 2022-06-23 01:49:47.031330
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-23 01:49:49.505358
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)
    assert hasattr(SelinuxFactCollector(), "collect")

# Generated at 2022-06-23 01:49:51.350848
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:49:59.072565
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    import json

    _mocked_module = type('module', (object,), {
        'params': {
            'gather_subset': ['!all', 'network'],
            'gather_timeout': 10,
            'filter': '*'
        }
    })()

    _mocked_module.params['gather_subset'] = ['!all', 'network']

    # Create instance of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector(_mocked_module)

    # Test collect() method of class SelinuxFactCollector