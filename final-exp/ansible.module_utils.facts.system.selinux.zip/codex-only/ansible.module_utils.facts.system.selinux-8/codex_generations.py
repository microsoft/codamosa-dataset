

# Generated at 2022-06-23 01:39:57.870617
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Setup class
    selinux_collector_class = SelinuxFactCollector()
    # Run constructor test
    assert selinux_collector_class.name == 'selinux'

# Generated at 2022-06-23 01:40:00.079291
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'

# Generated at 2022-06-23 01:40:03.294100
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:40:05.675564
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:40:06.689863
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:40:09.029883
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Initializing test
    selinuxMod = SelinuxFactCollector()
    assert selinuxMod.name == 'selinux'

# Generated at 2022-06-23 01:40:12.114131
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create instance of class SelinuxFactCollector
    obj = SelinuxFactCollector()

    # Check instance attributes
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()



# Generated at 2022-06-23 01:40:19.890935
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test for the collector without the selinux library installed
    instance = SelinuxFactCollector()
    result = instance.collect()
    assert 'selinux' in result and result['selinux']['status'] == 'Missing selinux Python library'

    # Mock attributes for selinux library from now on
    instance._selinux_enabled = True
    instance._selinux_policyvers = 5
    instance._selinux_config_mode = 0
    instance._selinux_mode = 0
    instance._selinux_type = 'targeted'

    # Test for the collector with selinux library installed but selinux disabled on the system
    instance._selinux_enabled = False
    result = instance.collect()
    assert 'selinux' in result and result['selinux']['status'] == 'disabled'

    #

# Generated at 2022-06-23 01:40:26.766637
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    s = SelinuxFactCollector()
    result = s.collect()
    assert('selinux_python_present' in result)
    if result['selinux_python_present']:
        assert('status' in result['selinux'])
        assert('policyvers' in result['selinux'])
        assert('config_mode' in result['selinux'])
        assert('mode' in result['selinux'])
        assert('type' in result['selinux'])

# Generated at 2022-06-23 01:40:30.018321
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-23 01:40:31.855490
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector({})
    selinux_fact_collector.collect()

# Generated at 2022-06-23 01:40:32.733287
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-23 01:40:42.438869
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.utils import get_collector_instance

    Collector._initialize()
    assert 'selinux' not in Collector.collected_facts

    SelinuxFactCollector.collect(None, Collector.collected_facts)

    assert 'selinux' in Collector.collected_facts
    assert 'status' in Collector.collected_facts['selinux']

    # this test doesn't run selinux but we can at least check the Collector
    # API works as expected.
    assert 'selinux' not in Collector.collected_facts
    Collector.clear_facts()
    assert 'selinux' not in Collector.collected_facts

# Generated at 2022-06-23 01:40:45.578807
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-23 01:40:47.630864
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact = SelinuxFactCollector()
    assert selinux_fact is not None

# Generated at 2022-06-23 01:40:57.720310
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.selinux
    from ansible.module_utils.selinux import security_getenforce, security_policyvers
    import mock

    def mock_security_getenforce():
        return 1

    def mock_security_policyvers():
        return '20160525'

    def mock_selinux_getpolicytype():
        return (0, 'targeted')

    def mock_selinux_getenforcemode():
        return (0, 1)


# Generated at 2022-06-23 01:41:02.327150
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Check default values
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-23 01:41:09.898103
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    expected_output = {
        'selinux_python_present': True,
        'selinux': {
            'type': 'targeted',
            'policyvers': '28',
            'config_mode': 'enforcing',
            'mode': 'enforcing'
        }
    }
    selinux_fact_collector = SelinuxFactCollector()
    actual_output = selinux_fact_collector.collect(None, None)
    assert actual_output == expected_output

# Generated at 2022-06-23 01:41:12.639760
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert issubclass(SelinuxFactCollector, BaseFactCollector)

# Generated at 2022-06-23 01:41:24.568895
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create SelinuxFactCollector instance
    selinux_fact_collector = SelinuxFactCollector()

    # Create selinux_python_present function and assign to SelinuxFactCollector.selinux_python_present
    selinux_python_present = lambda: True
    selinux_fact_collector.selinux_python_present = selinux_python_present

    # Create selinux_is_selinux_enabled function and assign to SelinuxFactCollector.selinux_is_selinux_enabled
    selinux_is_selinux_enabled = lambda: True
    selinux_fact_collector.selinux_is_selinux_enabled = selinux_is_selinux_enabled

    # Create selinux_selinux_getenforcemode function and assign to SelinuxFactCollect

# Generated at 2022-06-23 01:41:28.833849
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()
    assert 'selinux' in result.keys()
    assert 'selinux_python_present' in result.keys()

# Generated at 2022-06-23 01:41:38.247119
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-23 01:41:43.487331
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.collector == 'SelinuxFactCollector'
    assert selinux_facts.requirements == []
    assert selinux_facts._fact_ids == set()
    assert selinux_facts.read_only == True
    assert selinux_facts.combine_facts == None

# Generated at 2022-06-23 01:41:45.971356
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:41:51.935474
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    # Call method collect of class SelinuxFactCollector
    selinux_fact_collector.collect()

# Generated at 2022-06-23 01:41:53.452183
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:41:55.418708
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-23 01:41:57.234261
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """This is a unit test for SelinuxFactCollector"""

    SelinuxFactCollector()

# Generated at 2022-06-23 01:42:05.001226
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    result = selinux_facts.collect()

    assert isinstance(result, dict)
    assert result.get('selinux') is not None
    selinux = result.get('selinux')

    assert 'status' in selinux
    assert isinstance(selinux['status'], str)
    if selinux['status'] == 'disabled':
        assert selinux['config_mode'] == 'unknown'
        assert selinux['mode'] == 'unknown'
        assert selinux['policyvers'] == 'unknown'
        assert selinux['type'] == 'unknown'

    assert isinstance(result.get('selinux_python_present'), bool)

# Generated at 2022-06-23 01:42:08.314001
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()

# Generated at 2022-06-23 01:42:09.742278
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    results = SelinuxFactCollector().collect()
    assert 'selinux' in results

# Generated at 2022-06-23 01:42:11.140243
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:42:12.119093
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:42:15.785563
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_coll = SelinuxFactCollector()
    collected_facts = dict()
    collected_facts['ansible_selinux'] = selinux_fact_coll.collect(collected_facts=collected_facts)
    assert collected_facts['ansible_selinux']

# Generated at 2022-06-23 01:42:24.547382
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = dict()
    selinux_facts['config_mode'] = 'disabled'
    selinux_facts['status'] = 'disabled'
    selinux_facts['type'] = 'unknown'
    selinux_facts['mode'] = 'unknown'
    selinux_facts['policyvers'] = 'unknown'
    expected_facts = dict()
    expected_facts['selinux'] = selinux_facts
    expected_facts['selinux_python_present'] = True
    # Test
    selinux_facts_obj = SelinuxFactCollector()
    actual_facts = selinux_facts_obj.collect()
    assert actual_facts == expected_facts

# Generated at 2022-06-23 01:42:26.862738
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-23 01:42:36.422806
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux', "Testcase for checking SelinuxFactCollector.name failed"
    assert isinstance(selinux._fact_ids, set), "Testcase for checking SelinuxFactCollector._fact_ids failed"
    assert 'selinux' in selinux._fact_ids, "Testcase for checking SelinuxFactCollector._fact_ids failed"
    assert 'selinux_python_present' in selinux._fact_ids, "Testcase for checking SelinuxFactCollector._fact_ids failed"


# Generated at 2022-06-23 01:42:38.600506
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.get_facts()

# Generated at 2022-06-23 01:42:47.092724
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create the needed object
    selinuxMock = {
        'security_getenforce': lambda: 0,
        'selinux_getenforcemode': lambda: (0,0),
        'selinux_getpolicytype': lambda: (0,'targeted'),
        'is_selinux_enabled': lambda: True,
        'security_policyvers': lambda: 28
    }

    selinux.security_getenforce = selinuxMock['security_getenforce']
    selinux.selinux_getenforcemode = selinuxMock['selinux_getenforcemode']
    selinux.selinux_getpolicytype = selinuxMock['selinux_getpolicytype']
    selinux.is_selinux_enabled = selinuxMock['is_selinux_enabled']
    se

# Generated at 2022-06-23 01:42:52.199132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    # Test the name
    assert sfc.name == 'selinux'
    # Test the fact_ids
    assert sfc._fact_ids == set()

# Generated at 2022-06-23 01:42:58.355378
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SELINUX_FACTS = {
        'selinux': {
            'status': 'Missing selinux Python library',
        },
        'selinux_python_present': False,
    }
    collector = SelinuxFactCollector()
    assert collector.collect() == SELINUX_FACTS

# Generated at 2022-06-23 01:43:02.520470
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:43:14.595926
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import platform
    import sys
    from ansible.module_utils.facts import collector

    # Python 2.6 does not have selinux Python library
    if platform.python_version() < '2.7':
        return

    # Get the collector object
    obj = collector.get_collector('selinux')

    # Test if the object is an instance of SelinuxFactCollector
    assert isinstance(obj, SelinuxFactCollector)

    # Test if the object is an instance of BaseFactCollector
    assert isinstance(obj, BaseFactCollector)

    # Create a list of collected facts
    collected_facts = {}

    # Set the module_name attr of the object to ansible_module
    obj.module_name = 'ansible_module'

    # Call the collect method

# Generated at 2022-06-23 01:43:17.055469
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-23 01:43:23.296170
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect()

    # Check if facts has been collected
    assert 'selinux' in facts

    # Check if all the selinux facts have been collected
    assert 'status' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'type' in facts['selinux']

# Generated at 2022-06-23 01:43:25.447150
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector_obj = SelinuxFactCollector()
    assert selinux_collector_obj.name == 'selinux'

# Generated at 2022-06-23 01:43:34.129250
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts = SelinuxFactCollector()
    assert facts.collect() == {
        'selinux_python_present': False,
        'selinux': {},
    }

# Unit tests for selinux_facts module.
# These require the use of patch() and MagicMock() functions which are only
# available in Python 2.7 and 3.3 or later.
try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

from ansible.module_utils.facts import selinux_facts
from ansible.module_utils.facts.collector import FactsCollector
from ansible.module_utils.facts.collector import FactsParams
from ansible.module_utils.facts.hardware.selinux import SelinuxFactCollector

# Generated at 2022-06-23 01:43:36.997737
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    f = SelinuxFactCollector()

    assert f.name == 'selinux'
    assert 'selinux' in f._fact_ids

# Generated at 2022-06-23 01:43:37.926138
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-23 01:43:40.758507
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'
    assert selinux_obj._fact_ids == set()

# Generated at 2022-06-23 01:43:43.577361
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-23 01:43:49.401805
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    with patch.dict(selinux.__dict__, {'is_selinux_enabled': MagicMock(return_value=True),
    'security_getenforce': MagicMock(return_value=1)}):
        SelinuxFactCollector().collect()
        assert selinux.security_getenforce.call_count == 1
        assert selinux.security_getenforce() == 1


# Generated at 2022-06-23 01:43:51.433741
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'
    assert s._fact_ids == set()


# Generated at 2022-06-23 01:43:58.038735
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    collected_facts = selinux_collector.collect()
    try:
        selinux_collector.collect()
    except:
        pass
    assert collected_facts is not None

# Generated at 2022-06-23 01:44:01.887103
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-23 01:44:05.096408
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    assert selinux_fact_collector_obj
    assert selinux_fact_collector_obj.name == 'selinux'
    assert selinux_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-23 01:44:09.121091
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == frozenset(['selinux', 'selinux_python_present'])

# Generated at 2022-06-23 01:44:11.562130
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids is not None

# Generated at 2022-06-23 01:44:21.434702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    MockedModule = type('MockedModule', (), {'params': {'gather_subset': ['all']}})
    mocked_module = MockedModule()

    # Get selinux fact collector
    fact_collector = SelinuxFactCollector(mocked_module)

    # Get selinux facts
    selinux_facts = fact_collector.collect()

    # Assert expected selinux facts
    assert 'selinux' in selinux_facts
    assert isinstance(selinux_facts['selinux'], dict)

    assert 'status' in selinux_facts['selinux']
    assert isinstance(selinux_facts['selinux']['status'], str)
    selinux_status = selinux_facts['selinux']['status']


# Generated at 2022-06-23 01:44:25.503212
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector.name, str)
    assert isinstance(SelinuxFactCollector._fact_ids, set)
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:44:27.237762
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:44:32.577186
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert type(facts_dict) is dict
    assert set(facts_dict.keys()) == set(['selinux', 'selinux_python_present'])
    assert type(facts_dict['selinux']) is dict

# Generated at 2022-06-23 01:44:39.610385
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    # Test that the selinux_python_present is set
    facts = collector.collect()
    assert 'selinux_python_present' in facts
    assert facts['selinux_python_present'] == HAVE_SELINUX
    if HAVE_SELINUX:
        assert set(facts['selinux'].keys()) == {
            'status',
            'policyvers',
            'config_mode',
            'mode',
            'type'
        }
    else:
        assert 'selinux' not in facts

# vim: set et ts=4 sw=4

# Generated at 2022-06-23 01:44:50.562840
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils import basic
    import mock

    m = mock.Mock()
    m.collect.return_value = {'selinux_python_present': False}
    m.is_selinux_enabled.return_value = False
    c = SelinuxFactCollector(m, basic.AnsibleModule)
    results = c.collect()

    assert results['selinux']['status'] == 'Missing selinux Python library'
    assert results['selinux_python_present'] == False

    m = mock.Mock()
    m.collect.return_value = {'selinux_python_present': True}
    m.is_selinux_enabled.return_value = True

# Generated at 2022-06-23 01:44:52.480392
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    # TODO: Add more tests


# Generated at 2022-06-23 01:44:55.281920
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-23 01:44:57.178998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfc = SelinuxFactCollector()
    assert selinuxfc.name == 'selinux'

# Generated at 2022-06-23 01:44:59.363954
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:44:59.977131
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:45:01.242044
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert HAVE_SELINUX is True

# Generated at 2022-06-23 01:45:11.591903
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Mock for the selinux module
    class SelinuxMock:
        is_selinux_enabled = lambda self: True
        security_policyvers = lambda self: 5
        selinux_getenforcemode = lambda self: 0
        security_getenforce = lambda self: 1
        selinux_getpolicytype = lambda self: 0

    selinux_dict = {'__builtins__': {'isinstance': isinstance},
                    'selinux': SelinuxMock()}
    module_mock = {'__builtins__': {'__import__': lambda self, name: SelinuxMock() if name == 'selinux' else None}}

    # Testing for the case where the library is missing.
    selinux_fact_collector = SelinuxFactCollector()
    result_dict = selinux_fact

# Generated at 2022-06-23 01:45:15.694504
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    my_obj = SelinuxFactCollector()
    assert my_obj
    assert isinstance(my_obj, SelinuxFactCollector)
    assert my_obj.name == 'selinux'
    assert my_obj._fact_ids == set()

# Generated at 2022-06-23 01:45:30.708304
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_selinux_facts = {
        'selinux_python_present': True,
        'selinux': {
            'config_mode': 'enforcing',
            'policyvers': '28',
            'mode': 'enforcing',
            'status': 'enabled',
            'type': 'targeted'
        }
    }
    m_collector = SelinuxFactCollector(module=None, collected_facts=None)
    os_facts = m_collector.collect(module=None, collected_facts=None)
    assert test_selinux_facts == os_facts


# Generated at 2022-06-23 01:45:38.297811
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Instantiate a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Instantiate a BaseFactCollector object
    base_fact_collector = BaseFactCollector()

    # Update the gathered_list to contain the names of the facts collected by
    # the SelinuxFactCollector object
    base_fact_collector.gathered_list.update(selinux_fact_collector.get_fact_names())

    # Instantiate a Facts object
    facts_obj = facts.Facts(None, None, base_fact_collector)

    # Collect facts
    facts_obj.populate()

    # Get the facts
    facts = facts_

# Generated at 2022-06-23 01:45:45.635318
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize a module and facts instance
    collect_test = SelinuxFactCollector()
    # Get a dictionary of facts
    testdict = collect_test.collect(module=None, collected_facts=None)
    # Test if dictionary was returned
    assert isinstance(testdict, dict)
    # Test if keys selinux and selinux_python_present exist
    assert testdict.has_key('selinux')
    assert testdict.has_key('selinux_python_present')
    # Test if SELinux is enabled or disabled
    assert testdict['selinux_python_present'] or testdict['selinux']['status'] == 'disabled'

# Generated at 2022-06-23 01:45:53.646700
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = {
        'status': '',
        'policyvers': '',
        'config_mode': '',
        'mode': '',
        'type': ''
    }

    selinux_version = '3.13.1-229.el7_4.4'
    (rc, configmode) = (0, 1)
    policytype = 'targeted'

    # case 1: selinux library is missing
    fc_selinux = SelinuxFactCollector()
    selinux_facts = fc_selinux.collect(module=None)
    assert selinux_facts['selinux_python_present'] == False, selinux_facts['selinux_python_present']
    assert selinux_facts['selinux']['status'] == 'Missing selinux Python library', selinux_

# Generated at 2022-06-23 01:45:54.728293
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:45:56.317832
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector
    assert selinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:45:57.726562
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-23 01:45:59.677334
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert 'selinux' in x._fact_ids

# Generated at 2022-06-23 01:46:02.372608
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-23 01:46:05.814396
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_factcollector = SelinuxFactCollector()
    assert selinux_factcollector.name == 'selinux'
    assert selinux_factcollector._fact_ids == set(['selinux_python_present'])


# Generated at 2022-06-23 01:46:08.211698
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-23 01:46:18.199442
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Test when selinux library is missing
    selinux_collector = SelinuxFactCollector()
    selinux_collector.HAVE_SELINUX = False
    result = selinux_collector.collect()
    assert result['selinux']['status'] == 'Missing selinux Python library'
    assert result['selinux_python_present'] == False

    # Test when selinux library is present but not enabled
    selinux_collector = SelinuxFactCollector()
    selinux_collector.HAVE_SELINUX = True
    selinux_collector.selinux.is_selinux_enabled = lambda: False
    result = selinux_collector.collect()

# Generated at 2022-06-23 01:46:19.208810
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-23 01:46:28.723249
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        # Try to import the selinux library and fail if it is not found
        from ansible.module_utils.compat import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    # Define the test class
    class TestClass:
        def __init__(self, test_dict):
            self.ansible_facts = test_dict
            self.changed = False
            self.failed = False
            self.selinux_python_present = True
            self.selinux_facts = {
                'type': 'test_type',
                'config_mode': 'test_config_mode',
                'mode': 'test_mode',
                'status': 'test_status',
                'policyvers': 'test_policyvers'
            }

       

# Generated at 2022-06-23 01:46:39.771865
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_obj = SelinuxFactCollector()

    selinux_facts = selinux_fact_collector_obj.collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert selinux_facts['selinux_python_present']
    assert 'status' in selinux_facts['selinux']
    assert selinux_facts['selinux']['status'] in ['enabled', 'disabled', 'Missing selinux Python library']

    if selinux_facts['selinux']['status'] == 'enabled':
        assert 'policyvers' in selinux_facts['selinux']
        assert 'config_mode' in selinux_facts['selinux']

# Generated at 2022-06-23 01:46:42.681611
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

if __name__ == '__main__':
    # Unit test for constructor of class SelinuxFactCollector
    test_SelinuxFactCollector()

# Generated at 2022-06-23 01:46:53.175492
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeSelinux():
        def is_selinux_enabled():
            return True

        def security_policyvers():
            return '3.12.1'

        def selinux_getenforcemode():
            return (0, 1)

        def security_getenforce():
            return 1

        def selinux_getpolicytype():
            return (0, 'targeted')

    # Capture module_utils.selinux
    saved_selinux = collector.selinux
    collector.selinux = FakeSelinux

    f = SelinuxFactCollector()

    # Under this setup, Selinux is enabled and the facts
    # should be returned
    facts = f.collect

# Generated at 2022-06-23 01:47:03.234456
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collected_facts = {}
    test_collector = SelinuxFactCollector()
    # Try to collect selinux facts without the selinux Python library.  The returned
    # facts should include the status and selinux_python_present but nothing
    # else about selinux.
    try:
        current_selinux = globals()['selinux']
        del(globals()['selinux'])
        assert test_collector.collect(None, collected_facts) == {'selinux': {'status': 'Missing selinux Python library'},
        'selinux_python_present': False}
    finally:
        globals()['selinux'] = current_selinux
    # Try to collect selinux facts with the selinux Python library.  The returned
    # facts should include the status, policyvers, config_

# Generated at 2022-06-23 01:47:04.223854
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:47:12.562329
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Check selinux facts if selinux Python library is present
    if HAVE_SELINUX:
        # Check selinux facts if selinux is enabled
        if selinux.is_selinux_enabled():
            selinux_facts = {
                'status': 'enabled',
                'policyvers': 'unknown',
                'config_mode': 'unknown',
                'mode': 'unknown',
                'type': 'unknown'
            }
        # Check selinux facts if selinux is disabled
        else:
            selinux_facts = {
                'status': 'disabled'
            }
    # If selinux Python library is not present, set facts to default values
    else:
        selinux_facts = {
            'status': 'Missing selinux Python library',
        }


# Generated at 2022-06-23 01:47:15.314316
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-23 01:47:25.655315
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    class MockSelinux:
        @staticmethod
        def is_selinux_enabled():
            return False
        @staticmethod
        def security_policyvers():
            return '28'
        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)
        @staticmethod
        def security_getenforce():
            return 0
        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')

    selinux_facts = SelinuxFactCollector()

# Generated at 2022-06-23 01:47:26.459684
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-23 01:47:37.172026
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Make sure selinux library is not present
    module = None
    collected_facts = None
    selinux_facts = {'config_mode': 'unknown',
                     'type': 'unknown',
                     'mode': 'unknown',
                     'policyvers': 'unknown',
                     'status': 'Missing selinux Python library'}

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    collector = SelinuxFactCollector()
    collected_facts = collector.collect(module, collected_facts)
    assert collected_facts == {'selinux': selinux_facts, 'selinux_python_present': False}



# Generated at 2022-06-23 01:47:41.795468
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert 'selinux' in selinux_collector._fact_ids
    assert 'selinux_python_present' in selinux_collector._fact_ids
    assert not selinux_collector._collected_facts
    assert not selinux_collector._module
    assert selinux_collector._cache_dir

# Generated at 2022-06-23 01:47:52.409543
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a mock module object
    mock_module = type('module', (), {})()

    # Create a mock facts dict
    mock_facts_dict = dict()

    # Define a dict with expected results
    expected_result = dict()
    expected_result['selinux'] = {
        'status': 'disabled',
        'policyvers': 'unknown',
        'config_mode': 'unknown',
        'mode': 'unknown',
        'type': 'unknown'
    }
    expected_result['selinux_python_present'] = True

    # Instantiate a SelinuxFactCollector
    mock_selinux_collector = SelinuxFactCollector()

    # Test the collect method

# Generated at 2022-06-23 01:47:54.159815
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()

    assert collector.name == 'selinux'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-23 01:48:03.603119
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    selinux = SelinuxFactCollector()
    collected_facts = Collector().collect(module=None, collected_facts=None)
    expected_selinux_facts = {
        "status": "enabled",
        "policyvers": "28",
        "config_mode": "unknown",
        "mode": "unknown",
        "type": "unknown"
    }
    assert collected_facts['selinux'] == expected_selinux_facts
    assert collected_facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:48:06.423795
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    global selinux
    selinux = None
    obj = SelinuxFactCollector()
    assert isinstance(obj, BaseFactCollector)

# Generated at 2022-06-23 01:48:08.923953
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collecter = SelinuxFactCollector()
    assert collecter.name == 'selinux'
    assert collecter._fact_ids == set()

# Generated at 2022-06-23 01:48:10.658109
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector

# Generated at 2022-06-23 01:48:12.401546
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-23 01:48:13.785949
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    a = SelinuxFactCollector()
    assert a.collect()

# Generated at 2022-06-23 01:48:15.304328
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test for new instance creation
    selinux = SelinuxFactCollector()
    assert selinux is not None

# Generated at 2022-06-23 01:48:20.702025
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.platform == ''
    assert selinux_fact_collector.platforms == []
    assert selinux_fact_collector.default_flush_cache() is False

# Generated at 2022-06-23 01:48:25.770527
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Test method collect
    '''
    fact_collector = SelinuxFactCollector()
    fact_collector.collect()

# vim: expandtab tabstop=4 shiftwidth=4 smarttab ft=python

# Generated at 2022-06-23 01:48:29.138838
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollectorObj = SelinuxFactCollector()
    assert selinuxFactCollectorObj
    assert selinuxFactCollectorObj.name == 'selinux'
    assert selinuxFactCollectorObj._fact_ids == set()
    assert selinuxFactCollectorObj.collect()

# Generated at 2022-06-23 01:48:41.898549
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Tests whether a library is missing
    module = None
    facts_dict = None
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.HAVE_SELINUX = False
    selinux_dict = selinux_fact_collector.collect(module, facts_dict)
    assert selinux_dict['selinux_python_present'] == False
    assert selinux_dict['selinux']['status'] == 'Missing selinux Python library'

    # Tests when selinux is not present
    module = None
    facts_dict = None
    selinux_fact_collector = SelinuxFactCollector()
    selinux_dict = selinux_fact_collector.collect(module, facts_dict)
    assert selinux_dict['selinux_python_present']

# Generated at 2022-06-23 01:48:45.999905
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAVE_SELINUX:
        selinux_facts = SelinuxFactCollector().collect()
        print(selinux_facts)
        assert selinux_facts['selinux_python_present']
        assert 'selinux' in selinux_facts
        
    else:
        selinux_facts = SelinuxFactCollector().collect()
        print(selinux_facts)
        assert selinux_facts['selinux_python_present'] is False
        
test_SelinuxFactCollector_collect()

SelinuxFactCollector()

# Generated at 2022-06-23 01:48:49.917321
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-23 01:48:50.852904
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-23 01:48:52.596262
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:49:02.806934
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class TestSelinux(object):
        @staticmethod
        def is_selinux_enabled():
            return False

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def security_policyvers():
            return "28"

        @staticmethod
        def security_getenforce():
            return 0

        @staticmethod
        def selinux_getpolicytype():
            return (0, "targeted")

    selinux.is_selinux_enabled = TestSelinux.is_selinux_enabled
    selinux.selinux_getenforcemode = TestSelinux.selinux_getenforcemode
    selinux.security_policyvers = TestSelinux.security_policyvers
    selinux.security_getenforce = TestS

# Generated at 2022-06-23 01:49:04.984138
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c._fact_ids == set()


# Generated at 2022-06-23 01:49:11.094992
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert isinstance(selinux_collector.collect(), dict)

# Generated at 2022-06-23 01:49:13.765299
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()

    assert x.name == 'selinux'
    assert 'selinux_python_present' in x._fact_ids

# Generated at 2022-06-23 01:49:18.423803
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']

# Generated at 2022-06-23 01:49:26.008861
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_module = SelinuxFactCollector()
    selinux_facts = selinux_module.collect()
    if HAVE_SELINUX:
        assert selinux_facts.get('selinux_python_present', False)
    else:
        assert selinux_facts.get('selinux_python_present', False) == False
        assert selinux_facts.get('selinux', {}).get('status', None) == "Missing selinux Python library"

# Generated at 2022-06-23 01:49:36.061286
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with enabled selinux
    selinux_mock = Mock()
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = 22
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, "targeted")
    module_mock = Mock()
    facts_dict = dict()
    facts_dict['selinux'] = dict()
    fact_collector = SelinuxFactCollector(module_mock)
    result = fact_collector.collect(module_mock, facts_dict)
   

# Generated at 2022-06-23 01:49:37.072408
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-23 01:49:38.497846
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_obj = SelinuxFactCollector()
    test_obj.collect()

# Generated at 2022-06-23 01:49:40.065152
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-23 01:49:42.512836
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """This will test SelinuxFactCollector.collect()"""
    selinux_fact_collector = SelinuxFactCollector()

    # Testing return value of collect method.
    assert isinstance(selinux_fact_collector.collect(), dict)

# Generated at 2022-06-23 01:49:53.388512
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Checking that exception is raised for missing selinux Python library
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert not HAS_SELINUX
    facts = selinuxFactCollector.collect()
    assert facts['selinux_python_present'] == False

    # Checking that exception is not raised for selinux Python library present
    from ansible.module_utils.compat import selinux
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert HAVE_SELINUX
    facts = selinuxFactCollector.collect()
    assert facts['selinux_python_present'] == True

# Generated at 2022-06-23 01:50:00.402114
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a test class
    class SelinuxFactCollector_Test(SelinuxFactCollector):

        # Mock the method get_file_content
        @staticmethod
        def get_file_content(filename):
            if filename == '/selinux/enforce':
                return 1
            return 0

    # Create an instance of SelinuxFactCollector_Test
    selinux_fact_collector = SelinuxFactCollector_Test()

    # Get the selinux facts
    selinux_facts = selinux_fact_collector.collect()

    # Test the selinux facts
    assert type(selinux_facts) is dict
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'