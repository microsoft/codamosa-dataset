

# Generated at 2022-06-11 05:10:27.000626
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facter = SelinuxFactCollector()
    assert selinux_facter.name == 'selinux'
    assert selinux_facter._fact_ids == set()

# Generated at 2022-06-11 05:10:29.558220
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfcollector = SelinuxFactCollector()
    assert sfcollector.name == 'selinux'
    assert sfcollector._fact_ids == set([])

# Generated at 2022-06-11 05:10:37.311718
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()
    assert selinux_facts is not None
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts


# Generated at 2022-06-11 05:10:39.933657
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:10:50.895149
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-11 05:10:54.484344
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test initial instantiation of class SelinuxFactCollector
    """
    foo = SelinuxFactCollector()
    assert foo.name == "selinux"
    assert foo._fact_ids == set()


# Generated at 2022-06-11 05:10:55.468196
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()

# Generated at 2022-06-11 05:11:04.358886
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the SelinuxFactCollector.collect() method.
    """

    # Need to setup module_utils/facts/collector.py mocks/stubs
    # to be able to run this test.
    #
    # I tried doing a general mock of the selinux module but that
    # seemed to prevent it from being able to load the module.

    #import module_utils.facts.collector
    #collected_facts = module_utils.facts.collector.CollectedFacts()

    #import sys
    #sys.modules['selinux'] = selinux
    #import ansible.module_utils.facts.collector.base
    #import tempfile

    #collected_facts = ansible.module_utils.facts.collector.base.CollectedFacts()
    #print(collected_facts)

# Generated at 2022-06-11 05:11:06.592983
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert isinstance(obj, SelinuxFactCollector)
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-11 05:11:07.953120
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    print (selinux)

# Generated at 2022-06-11 05:11:21.088613
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collectors import collector_registry
    from ansible.module_utils.compat import selinux
    from ansible.module_utils.compat.six.moves import builtins

    fake_selinux = True
    try:
        builtins.__import__('selinux')
    except ImportError:
        fake_selinux = False

    real_security_getenforce = selinux.security_getenforce
    real_selinux_getenforcemode = selinux.selinux_getenforcemode
    real_selinux_getpolicytype = selinux.selinux_getpolicytype
    real_security_policyvers = selinux.security_policyvers

    def test_security_getenforce(enforce=0):
        return enforce


# Generated at 2022-06-11 05:11:32.303469
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create an instance of the SelinuxFactCollector class
    s = SelinuxFactCollector()

    # Set the selinux library to None
    selinux.security_getenforce = None

    # collect facts with the SelinuxFactCollector instance
    result = s.collect()

    # assert that the selinux_python_present boolean is False
    assert 'selinux_python_present' in result
    assert not result['selinux_python_present']

    # assert that the status is 'Missing selinux Python library'
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert result['selinux']['status'] == 'Missing selinux Python library'

    # reset the selinux library
    selinux.security_getenforce = lambda: 1

    # collect facts with

# Generated at 2022-06-11 05:11:33.686405
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    t_collector = SelinuxFactCollector()
    t_collector.collect()

# Generated at 2022-06-11 05:11:35.111914
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-11 05:11:40.958834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test constructor of class SelinuxFactCollector
    """
    # test creation of a SelinuxFactCollector object
    selinux_collector = SelinuxFactCollector()
    # test the name of the collector object is set correctly
    assert selinux_collector.name == 'selinux'
    # test the fact_ids of the collector object are set correctly
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-11 05:11:41.802557
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-11 05:11:43.811893
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact.name == 'selinux'
    assert selinux_fact._fact_ids is not None

# Generated at 2022-06-11 05:11:44.923680
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-11 05:11:47.195150
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# For unit testing

# Generated at 2022-06-11 05:11:48.524257
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    obj = SelinuxFactCollector()
    obj.collect()

# Generated at 2022-06-11 05:11:55.952701
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-11 05:11:56.522775
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-11 05:11:58.670134
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test instantiation of class SelinuxFactCollector."""
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'


# Generated at 2022-06-11 05:12:07.680802
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux module is not available
    global HAVE_SELINUX
    HAVE_SELINUX = False

    facts_dict = {}
    facts_dict['selinux'] = {
        'status': 'Missing selinux Python library',
    }
    facts_dict['selinux_python_present'] = False

    # Create an instance of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Check the collect method
    assert selinux_fact_collector.collect(None, None) == facts_dict

    # selinux module is available
    HAVE_SELINUX = True

    # replace the selinux.is_selinux_enabled() method to return a false
    # SELINUX is disabled on the system
    selinux.is_selinux_enabled

# Generated at 2022-06-11 05:12:17.294889
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    import ansible.utils.selinux

    sys.modules['ansible.module_utils.selinux'] = ansible.utils.selinux

    # Ensure that the selinux library is present before mocking
    assert(HAVE_SELINUX)

    module = None
    collected_facts = None
    selinux_fact_collector = SelinuxFactCollector()

    def test_se_enabled():
        ansible.utils.selinux.is_selinux_enabled = lambda: True
        ansible.utils.selinux.security_policyvers = lambda: 42
        ansible.utils.selinux.selinux_getenforcemode = lambda: (0, 0)
        ansible.utils.selinux.security_getenforce = lambda: 0
        ansible

# Generated at 2022-06-11 05:12:19.054464
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-11 05:12:23.891472
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test that a dictionary is returned with the correct keys.
    """
    result = SelinuxFactCollector.collect()
    assert isinstance(result, dict)
    assert result.get('selinux')
    assert result.get('selinux_python_present')
    assert result.get('ansible_system')
    assert result.get('ansible_system') == 'Linux'

# Generated at 2022-06-11 05:12:27.463146
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Tests that the constructor for SelinuxFactCollector initializes the correct
    attributes.
    """
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert len(sfc._fact_ids) == 0

# Generated at 2022-06-11 05:12:31.666558
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test for instantiation of SelinuxFactCollector class
    # The instantiation should be successful since the selinux
    # library is present in the Ansible distribution.
    c = SelinuxFactCollector()

    # Check the value of 'name'
    assert c.name == 'selinux'

# Generated at 2022-06-11 05:12:34.154790
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Ignore pylint warnings since they are unit tests
    # pylint: disable=redefined-outer-name
    selinux_col = SelinuxFactCollector()
    selinux_col.collect()

# Generated at 2022-06-11 05:12:45.919066
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:12:54.176820
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collectors import collector_exception_class, VirtualEnvFactCollector

    # test SelinuxFactCollector
    selinux_collector = get_collector_instance(SelinuxFactCollector)
    assert isinstance(selinux_collector, SelinuxFactCollector)

    # test VirtualEnvFactCollector
    with pytest.raises(collector_exception_class) as exc:
        get_collector_instance(VirtualEnvFactCollector)
    assert "VirtualEnvFactCollector is only supported in Python-2" == str(exc.value)

# Generated at 2022-06-11 05:13:04.664081
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.system.selinux import SelinuxFactCollector

    mock_module = MagicMock()
    mock_collector = SelinuxFactCollector(mock_module)

    # Test when selinux library is missing
    setattr(mock_collector, 'HAVE_SELINUX', False)
    assert (mock_collector.collect() == {'selinux': {'status': 'Missing selinux Python library'},
                                         'selinux_python_present': False}) is True

    # Test when selinux is disabled
    setattr(mock_collector, 'HAVE_SELINUX', True)
    mock_collector.selinux.is_selinux_enabled.return_value = False

# Generated at 2022-06-11 05:13:06.754438
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux']['status'] == 'enabled'

# Generated at 2022-06-11 05:13:09.487567
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert len(selinux_fact_collector._fact_ids) == 0

# Generated at 2022-06-11 05:13:18.236913
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the class
    se = SelinuxFactCollector()

    # Test that collect method returns an empty dict when selinux.is_selinux_enabled() returns False
    # and selinux.security_getenforce() raises an OSError
    def mock_is_enabled(self):
        return False

    def mock_se_getenforce(self):
        raise OSError

    selinux.is_selinux_enabled = mock_is_enabled
    selinux.security_getenforce = mock_se_getenforce

    result = se.collect()
    assert result == {'selinux': {'status': 'disabled', 'mode': 'unknown', 'config_mode': 'unknown'}, 'selinux_python_present': True}

    # Test that collect method returns an empty dict when se

# Generated at 2022-06-11 05:13:26.423186
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Instantiate a selinux fact collector
    selinux_collector = SelinuxFactCollector()

    # Mock the selinux module
    class MockSELinuxModule:
        def __init__(self):
            pass

        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return '28'

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 0

        def selinux_getpolicytype(self):
            return (1, 'targeted')

    selinux_module = MockSELinuxModule()
    import sys
    sys.modules['selinux'] = selinux_module
    reload(selinux)

    # Set facts to empty dict
    facts = {}

# Generated at 2022-06-11 05:13:34.411699
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test the collect method of the SelinuxFactCollector class
    """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.collector import DictFactCollector
    import ansible.module_utils.facts.collector.network

    # Create the SelinuxFactCollector object
    selinux_collector = SelinuxFactCollector()

    # The facts_dict should only have selinux_python_present set to False
    # since the selinux library is not present
    facts_dict = selinux_collector.collect()
    assert facts_dict['selinux_python_present'] is False

    # Mock

# Generated at 2022-06-11 05:13:41.796887
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    # Verify whether selinux_python_present is set to True when the selinux library is present.
    assert selinux_facts['selinux_python_present'] is True
    # Verify whether selinux_python_present is set to False when the selinux library is missing.
    selinux_facts = SelinuxFactCollector().collect(HAVE_SELINUX=False)
    assert selinux_facts['selinux_python_present'] is False
    # Verify whether selinux dictionary is empty when selinux library is missing.
    assert len(selinux_facts['selinux']) == 0
    # Verify whether selinux dictionary contains valid keys.
    assert len(selinux_facts['selinux']) == 7

# Generated at 2022-06-11 05:13:46.458639
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModuleMock()
    selinux_facts = SelinuxFactCollector(module)
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Unit tests for collect method of class SelinuxFactCollector

# Generated at 2022-06-11 05:14:14.323559
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    def test_func(module):
        # Set the return values to mimic
        # security_getenforce() returning -1, meaning SELinux is disabled

        # SELinux is disabled, so the values below should never be used
        selinux.security_getenforce.return_value = -1

        # Return values for other selinux functions not used
        selinux.security_policyvers.return_value = 60
        selinux.selinux_getenforcemode.return_value = (0, 0)
        selinux.selinux_getpolicytype.return_value = (0, 'targeted')

        selinux_facts = {}
        selinux_facts['status'] = 'disabled'
        selinux_facts['policyvers'] = 'unknown'
        selinux_facts['config_mode'] = 'unknown'
        se

# Generated at 2022-06-11 05:14:15.226398
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:14:17.638001
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == "selinux"
    assert selinux_facts._fact_ids == set()



# Generated at 2022-06-11 05:14:18.699161
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-11 05:14:22.695732
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # test if the class in properly initialized
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()
    assert x.collect() == {
        'selinux': {},
        'selinux_python_present': False
    }

# Generated at 2022-06-11 05:14:28.098442
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from module_utils.facts.collectors.selinux import SelinuxFactCollector

    test_collector = SelinuxFactCollector()
    result = test_collector.collect()

    assert result is not None

# Generated at 2022-06-11 05:14:30.308290
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' in selinux_fact_collector.name

# Generated at 2022-06-11 05:14:40.990622
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    def test_selinux_is_selinux_enabled():
        """
        Helper function to mock the is_selinux_enabled function of the selinux
        module.
        """
        return True

    def test_selinux_security_getenforce():
        """
        Helper function to mock the security_getenforce function of the selinux
        module.
        """
        return 1

    def test_selinux_security_policyvers():
        """
        Helper function to mock the security_policyvers function of the selinux
        module.
        """
        return 35


# Generated at 2022-06-11 05:14:43.789999
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert selinuxFactCollector._fact_ids == set()


# Generated at 2022-06-11 05:14:54.844963
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import types

    # removes fully qualified name of the class SelinuxFactCollector
    # and creates a fake class member variables
    class FakeModule(types.SimpleNamespace):
        def fail_json(self, *args, **kwargs):
            sys.stderr.write(kwargs.get("msg") + "\n")

    module = FakeModule()
    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect(module, None)
    assert result.get("selinux")
    if result.get("selinux").get("status") == 'Missing selinux Python library':
        assert result.get("selinux_python_present") == False
    else:
        assert result.get("selinux_python_present") == True

# Generated at 2022-06-11 05:15:42.955693
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Unit test for constructor of class SelinuxFactCollector
    :return:
    """
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux", "name is not %s" % selinux_fact_collector.name

# Generated at 2022-06-11 05:15:43.848682
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-11 05:15:45.440324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-11 05:15:50.098830
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_dict = {}
    collected_facts = {}
    selinux_facts = {}

    selinux_facts['status'] = 'disabled'
    selinux_facts['config_mode'] = 'disabled'
    selinux_facts['mode'] = 'disabled'
    selinux_facts['type'] = 'unknown'
    selinux_facts['policyvers'] = 'unknown'
    facts_dict['selinux'] = selinux_facts

    s = SelinuxFactCollector()
    facts_dict = s.collect(collected_facts)

    assert facts_dict == s.collect()

# Generated at 2022-06-11 05:15:52.460020
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    if 'selinux' in facts:
        assert isinstance(facts['selinux'], dict)
    else:
        assert 'selinux' not in facts

# Generated at 2022-06-11 05:15:55.432512
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # mock_module and mock_collector are defined in the TestBaseClass
    # which this class is derived from.
    collected_facts = mock_collector.collect(mock_module, collected_facts={})
    assert collected_facts['selinux']['status'] == 'disabled'

# Generated at 2022-06-11 05:15:57.552126
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert result['selinux']['status'] != 'unknown'
    assert result['selinux_python_present'] == True

# Generated at 2022-06-11 05:16:00.560543
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert len(obj._fact_ids) == 3
    assert 'selinux' in obj._fact_ids
    assert 'selinux_python_present' in obj._fact_ids

# Generated at 2022-06-11 05:16:02.086391
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'

# Generated at 2022-06-11 05:16:04.978364
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test the constructor of class SelinuxFactCollector

    # Test for valid instance of class SelinuxFactCollector
    obj = SelinuxFactCollector()
    assert isinstance(obj, SelinuxFactCollector)


# Generated at 2022-06-11 05:17:20.076910
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Execute collect method of SelinuxFactCollector.
    obj = SelinuxFactCollector()
    result_dict = obj.collect()



# Generated at 2022-06-11 05:17:22.291482
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Unit test for constructor of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-11 05:17:23.770192
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-11 05:17:29.945385
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    #
    # test whether selinux facts are returned
    #
    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect()
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert 'policyvers' in result['selinux']
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']
    assert 'type' in result['selinux']
    assert 'selinux_python_present' in result

# Generated at 2022-06-11 05:17:37.467785
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize fake selinux library to return invalid mode.
    # This will set status as disabled and it will set other
    # values to 'unknown'
    fake_selinux_lib = type('fake_selinux', (object,), {
        'is_selinux_enabled': lambda: False,
        'security_getenforce': lambda: -1,
        'security_policyvers': lambda: -1,
        'selinux_getpolicytype': lambda: (-1, ''),
        'selinux_getenforcemode': lambda: (-1, -1)
    })
    selinux.selinux = fake_selinux_lib()

    # Initialize Collector class
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect()['selinux']

# Generated at 2022-06-11 05:17:38.572995
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc is not None

# Generated at 2022-06-11 05:17:40.476921
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-11 05:17:45.974825
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""

    # Make sure the SelinuxFactCollector class is defined
    assert SelinuxFactCollector

    # Make sure the selinux library is not present
    assert not HAVE_SELINUX

    # Test the selinux status
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.collect()['selinux']['status'] == 'Missing selinux Python library'
    assert selinux_collector.collect()['selinux_python_present'] == False


# Generated at 2022-06-11 05:17:48.557314
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    # Test with a mocked selinux library
    selinux_fact_collector.collect()

    # Test without selinux
    selinux_fact_collector.collect()

# Generated at 2022-06-11 05:17:56.118644
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Disable selinux
    selinux.selinux_setenforce(0)

    fact_collector = SelinuxFactCollector()
    if fact_collector.collect()['selinux_python_present']:
        # If the Python selinux library is present, then assuming SELinux is enabled, set it to
        # permissive mode so that tests that expect it to be in permissive mode do not fail.
        selinux.selinux_setenforce(0)

    facts = fact_collector.collect()

    selinux_facts = facts['selinux']

    assert selinux_facts['status'] == 'enabled'
    assert selinux_facts['policyvers'] == 'unknown'
    assert selinux_facts['config_mode'] == 'permissive'