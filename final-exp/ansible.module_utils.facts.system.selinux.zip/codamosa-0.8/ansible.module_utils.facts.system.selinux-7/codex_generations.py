

# Generated at 2022-06-11 05:10:26.186508
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

    assert selinux_collector is not None
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-11 05:10:29.353566
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set(('selinux', 'selinux_python_present'))

# Generated at 2022-06-11 05:10:31.241044
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:10:37.569329
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    result = collector.collect()

    assert result['selinux']['status'] == 'disabled'
    assert result['selinux']['type'] == 'unknown'
    assert result['selinux']['mode'] == 'unknown'
    assert result['selinux']['config_mode'] == 'unknown'
    assert result['selinux']['policyvers'] == 'unknown'

# Generated at 2022-06-11 05:10:39.415181
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:10:41.558051
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert 'selinux' in facts

# Generated at 2022-06-11 05:10:45.908966
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    expected_result = {
        'selinux': {'status': 'enabled'},
        'selinux_python_present': True
    }
    c = SelinuxFactCollector()
    result = c.collect()
    assert type(result) is dict
    assert result == expected_result


# Generated at 2022-06-11 05:10:54.943051
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    selinux_facts = SelinuxFactCollector.collect()

    assert selinux_facts.get('selinux') is not None
    assert selinux_facts['selinux'].get('type') is not None
    assert selinux_facts['selinux'].get('mode') is not None
    assert selinux_facts['selinux'].get('status') is not None
    assert selinux_facts['selinux'].get('config_mode') is not None
    assert selinux_facts['selinux'].get('policyvers') is not None

# Generated at 2022-06-11 05:10:57.253553
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Test with the selinux library present
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == "selinux"


# Generated at 2022-06-11 05:10:59.079955
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'


# Generated at 2022-06-11 05:11:14.263573
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert (facts['selinux_python_present'] == True)
    assert (facts['selinux']['status'] == 'enabled')
    assert (facts['selinux']['policyvers'] > 0)
    assert (facts['selinux']['config_mode'] == 'unknown')
    assert (facts['selinux']['mode'] == 'unknown')
    assert (facts['selinux']['type'] == 'unknown')

# Generated at 2022-06-11 05:11:16.119658
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    o = SelinuxFactCollector()
    assert o.name == 'selinux'
    assert o._fact_ids == set()

# Generated at 2022-06-11 05:11:17.903869
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 05:11:20.904061
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux', "Name should be selinux"
    assert selinux._fact_ids == set(), "_fact_ids should be empty"

# Generated at 2022-06-11 05:11:25.527979
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:11:33.446647
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Mock selinux library
    class MockSelinux:
        def is_selinux_enabled():
            return True
        def security_policyvers():
            return "unknown"
        def selinux_getpolicytype():
            return (1, "unknown")
        def selinux_getenforcemode():
            return (0, 1)
        def security_getenforce():
            return 1

    selinux_mock = MockSelinux()
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect(selinux=selinux_mock)

# Generated at 2022-06-11 05:11:43.195198
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
     test_dict = {}

     # Create instance of class SelinuxFactCollector
     selinux_fact_collector = SelinuxFactCollector()

     # Call method collect of class SelinuxFactCollector
     result = selinux_fact_collector.collect(module='', collected_facts=test_dict)

     # Test that selinux_python_present is not set
     assert 'selinux_python_present' not in result
     # Test that selinux is not set
     assert 'selinux' not in result

     # Import module ansible.module_utils.compat.selinux
     module = __import__('ansible.module_utils.compat.selinux', fromlist=['selinux'])
     # Set attribute is_selinux_enabled of module ansible.module_utils.compat.sel

# Generated at 2022-06-11 05:11:44.811173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert 'selinux' in collector.collect().keys()

# Generated at 2022-06-11 05:11:53.720261
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test the collect method of SelinuxFactCollector class.
    """

    import sys
    import mock

    # Test case 1: selinux module is not present, selinux_python_present should be False
    # and status should be 'Missing selinux Python library'.
    collector_1 = SelinuxFactCollector()

    class MockModule(object):
        pass
    class MockCollected_facts(object):
        pass

    # `SelinuxFactCollector.collect` will raise an ImportError exception
    # if selinux module is not present. This exception should be
    # swallowed and the status should be set to 'Missing selinux Python library'.
    # selinux_python_present should be False.
    mock_module_1 = MockModule()
    mock_collected_facts_1 = MockCollected_facts()


# Generated at 2022-06-11 05:11:56.580677
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_object = SelinuxFactCollector()
    assert test_object
    assert test_object.name == 'selinux'
    assert test_object._fact_ids == set()



# Generated at 2022-06-11 05:12:24.114259
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import get_collector_instance

    mod = AnsibleModule(argument_spec={})
    facts_list = [get_collector_instance(c) for c in default_collectors]
    collected_facts = {}
    for fact_cls in facts_list:
        fact_cls.collect(module=mod, collected_facts=collected_facts)
    assert collected_facts.get("selinux") is not None
    assert collected_facts.get("selinux").get("type") is not None
    assert collected_facts.get("selinux").get("config_mode") is not None

# Generated at 2022-06-11 05:12:26.186784
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-11 05:12:27.129651
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:12:29.704349
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids is not None
    assert collector.collect() is not None

# Generated at 2022-06-11 05:12:32.575702
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact_collection = SelinuxFactCollector()

    assert selinux_fact_collection.name == 'selinux'
    assert selinux_fact_collection._fact_ids == set()

# Generated at 2022-06-11 05:12:34.178683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'
    assert 'selinux' in selinux_obj._fact_ids

# Generated at 2022-06-11 05:12:40.145973
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    expected_facts = {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown',
            'policyvers': 'unknown',
            'status': 'enabled'
        },
        'selinux_python_present': True
    }
    assert facts_dict == expected_facts

# Generated at 2022-06-11 05:12:49.777695
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import tempfile
    import os

    test_data = """enforcing: 0
policyvers: 28
config_mode: permissive
type: mls
mode: permissive"""
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(test_data)
    tmp_file.close()

    with mock.patch.dict(os.environ, {'ANSIBLE_SELINUX_FACTS': tmp_file.name}):
        facts = SelinuxFactCollector().collect()
        # We expect the enforcing value to be a string since the API returns a string.
        assert(facts['selinux']['config_mode'] == 'permissive')

# Generated at 2022-06-11 05:12:55.562967
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux is not installed, skip the test
    import imp
    result = imp.find_module("selinux")
    if result[0] is None:
        return

    import sys
    import os
    from ansible.module_utils.selinux import is_selinux_enabled, security_getenforce, security_policyvers, \
                                             selinux_getenforcemode, selinux_getpolicytype

    # Save the existing sys.modules values for selinux
    saved_modules = dict(sys.modules)

    # Add fake selinux module to sys.modules

# Generated at 2022-06-11 05:13:06.195972
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Initialize the collected_facts dictionary
    collected_facts = {}

    # Assert that selinux is not present in collected_facts
    assert 'selinux' not in collected_facts

    # Call the collect method of the SelinuxFactCollector object
    # which should populate the collected_facts dictionary
    selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that selinux is present in collected_facts and
    # that the selinux_python_present key is True.
    assert 'selinux_python_present' in collected_facts['selinux']
    assert collected_facts['selinux']['selinux_python_present'] == True

   

# Generated at 2022-06-11 05:13:25.242638
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    set_module_args({})
    SelinuxFactCollector().collect()

# Generated at 2022-06-11 05:13:30.829836
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()
    assert 'selinux' in selinux_facts
    assert isinstance(selinux_facts['selinux'], dict)
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'status' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-11 05:13:32.552625
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:13:33.934912
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-11 05:13:36.632766
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-11 05:13:37.691057
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    obj.collect()



# Generated at 2022-06-11 05:13:45.761418
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Mock the module so it does not exit and always returns False for is_selinux_enabled
    import ansible.module_utils.facts.collector.selinux
    import ansible.module_utils.facts.collector.selinux as selinux
    import mock

    @mock.patch.object(selinux, 'is_selinux_enabled')
    def test_collect(is_selinux_enabled_mock):
        is_selinux_enabled_mock.return_value = False
        sfc = SelinuxFactCollector()
        result = sfc.collect()
        assert result.get('selinux') == {'status': 'disabled'}
        assert result.get('selinux_python_present') == True

    test_collect()

# Generated at 2022-06-11 05:13:50.026471
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mySelinuxFactCollector = SelinuxFactCollector()
    result = mySelinuxFactCollector.collect(module=None, collected_facts=None)

    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert result['selinux_python_present']


# Generated at 2022-06-11 05:13:51.382041
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    selinux_facts.collect()

# Generated at 2022-06-11 05:13:59.022481
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Tests that SelinuxFactCollector is able to instantiate without fail.
    :return:
    """
    # Create an instance of SelinuxFactCollector
    sfc = SelinuxFactCollector()

    # Verify that the instance was successfully created
    assert isinstance(sfc, SelinuxFactCollector), 'SelinuxFactCollector object was not instantiated.'
    assert sfc.name == 'selinux', 'SelinuxFactCollector name was not assigned.'
    assert sfc._fact_ids == set(), 'SelinuxFactCollector fact_ids were not initialized to an empty set.'


# Generated at 2022-06-11 05:14:20.694245
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    tmp = SelinuxFactCollector()
    ansible_facts = tmp.collect()
    assert ansible_facts['selinux_python_present'] == False
    assert ansible_facts['selinux'] == {'status': 'Missing selinux Python library'}

# Generated at 2022-06-11 05:14:27.852181
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()
    # Run collect and get results
    collected_facts = selinux_fact_collector.collect()
    # Test if results equal expected results
    expected_facts = {
        'selinux': {
            'status': 'enabled',
            'config_mode': 'permissive',
            'mode': 'permissive',
            'type': 'targeted'
        },
        'selinux_python_present': True
    }
    assert collected_facts == expected_facts

# Generated at 2022-06-11 05:14:34.807344
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of SelinuxFactCollector
    selinuxfactcollector = SelinuxFactCollector()

    # Create a sample module to pass to the collect method
    module = AnsibleModule(argument_spec={})

    # Invoke collect method using the sample module
    collected_facts = selinuxfactcollector.collect(module=module)

    # Assert the generated facts
    assert collected_facts['selinux'] == {'status': 'Missing selinux Python library'}
    assert collected_facts['selinux_python_present'] is False

# Generated at 2022-06-11 05:14:38.343391
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:14:40.575869
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-11 05:14:42.792225
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:14:46.113004
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Constructor for class SelinuxFactCollector
    """

    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()



# Generated at 2022-06-11 05:14:48.733497
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:14:50.016122
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-11 05:15:00.116149
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a class object
    selinuxFactCollector = SelinuxFactCollector()

    # Try to collect facts
    facts = selinuxFactCollector.collect()

    # Check if selinux_python_present is present in the facts 
    # dictionary with a boolean value
    assert "selinux_python_present" in facts
    assert type(facts["selinux_python_present"]) is bool

    # Check if selinux is present in the facts dictionary with a dictionary value
    assert "selinux" in facts
    assert type(facts["selinux"]) is dict

    # If the selinux library is not present just test the selinux_python_present key
    if facts['selinux_python_present'] == False:
        return

    selinux_facts = facts['selinux']

    # Loop through the selinux

# Generated at 2022-06-11 05:15:51.248849
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name in SelinuxFactCollector.collect()

# Generated at 2022-06-11 05:15:53.551607
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Constructor test for SelinuxFactCollector
    """
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-11 05:15:55.942551
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:16:04.212227
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    g = globals()

    # Test default execution
    selinux = SelinuxFactCollector()
    selinux_facts = selinux.collect(g['module'], g['collected_facts'])

    assert selinux_facts.get('selinux_python_present') is not None
    if selinux_facts.get('selinux_python_present'):
        assert selinux_facts.get('selinux') is not None
        assert selinux_facts.get('selinux').get('status') is not None
        assert selinux_facts.get('selinux').get('policyvers') is not None
        assert selinux_facts.get('selinux').get('config_mode') is not None
        assert selinux_facts.get('selinux').get('mode') is not None
        assert selinux_

# Generated at 2022-06-11 05:16:07.782052
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Create object of the SelinuxFactCollector to test
    selinuxCollector = SelinuxFactCollector()

    # Check if the name of the collector is properly set
    assert selinuxCollector.name == 'selinux'
    assert selinuxCollector._fact_ids == set()


# Generated at 2022-06-11 05:16:10.557697
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:16:17.538033
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def getenforcemode_side_effect(*args):
        return (0, 1)
    def security_policyvers_side_effect(*args):
        return 2
    def selinux_getpolicytype_side_effect(*args):
        return (0, 'targeted')
    def selinux_getenforcemode_side_effect(*args):
        return (0, 0)
    def is_selinux_enabled_side_effect(*args):
        return True

    fact_collector = SelinuxFactCollector()
    fact_collector.__class__.security_policyvers = security_policyvers_side_effect
    fact_collector.__class__.selinux_getpolicytype = selinux_getpolicytype_side_effect
    fact_collector.__class__.selinux_getenforcemode = se

# Generated at 2022-06-11 05:16:22.167694
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys
    import types
    selinuxFactCollector = SelinuxFactCollector()
    assert isinstance(selinuxFactCollector, BaseFactCollector)
    assert isinstance(selinuxFactCollector.name, str)
    assert isinstance(selinuxFactCollector._fact_ids, types.SetType)
    assert isinstance(selinuxFactCollector.collect(), dict)

# Generated at 2022-06-11 05:16:24.119452
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-11 05:16:31.879473
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import platform

    platform_system = getattr(platform, 'system')

    facts = SelinuxFactCollector().collect()
    assert facts['selinux']['status'] == 'disabled'
    assert facts['selinux']['mode'] == 'unknown'
    assert facts['selinux']['config_mode'] == 'unknown'
    assert facts['selinux']['type'] == 'unknown'
    assert facts['selinux']['policyvers'] == 'unknown'

    if platform_system() == 'Darwin':
        assert facts['selinux_python_present'] == False
    else:
        assert facts['selinux_python_present'] == True

# Generated at 2022-06-11 05:17:59.871504
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import unittest
    from ansible.module_utils.facts import collector

    class TestSelinuxFactCollector(unittest.TestCase):
        def setUp(self):
            collector._FACTS_CACHE = {}

        def tearDown(self):
            collector._FACTS_CACHE = {}

        def test_selinux_fact_collector_collect(self):
            import ansible.module_utils
            import sys
            # Inject the selinux module into the module_utils namespace so it will be found when
            # the SelinuxFactCollector tries to import the selinux library
            sys.modules["ansible.module_utils.selinux"] = ansible.module_utils.selinux
            collector.collector_classes = {}

# Generated at 2022-06-11 05:18:02.209969
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-11 05:18:03.277828
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == "selinux"

# Generated at 2022-06-11 05:18:05.043887
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert isinstance(selinux_collector.collect(), dict)


# Generated at 2022-06-11 05:18:07.909246
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    fact_dict = selinux_collector.collect()

    selinux_keys = set(['status', 'policyvers', 'config_mode', 'mode', 'type'])

    assert(fact_dict['selinux_python_present'])
    assert('selinux' in fact_dict)
    assert(len(selinux_keys - fact_dict['selinux'].keys()) == 0)

# Generated at 2022-06-11 05:18:10.252950
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    x = SelinuxFactCollector()
    facts = x.collect()

    assert facts['selinux']
    assert 'status' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'type' in facts['selinux']
    assert 'policyvers' in facts['selinux']
    assert 'config_mode' in facts['selinux']

# Generated at 2022-06-11 05:18:11.787671
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert 'selinux' in collected_facts

# Generated at 2022-06-11 05:18:21.185733
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collector = SelinuxFactCollector()

    # Mock the selinux.is_selinux_enabled() method to return False
    # and assert selinux is disabled
    test_collector.module.run_command = MagicMock(return_value = (0, False))
    test_collector.module.selinux = selinux
    facts = test_collector.collect(module=MagicMock())
    assert facts['selinux']['status'] == 'disabled'

    # Mock the selinux.is_selinux_enabled() method to return True
    # and assert selinux is enabled
    test_collector.module.run_command = MagicMock(return_value = (0, True))
    test_collector.module.selinux = selinux

# Generated at 2022-06-11 05:18:23.287821
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_col = SelinuxFactCollector()
    assert selinux_col.name == 'selinux'
    assert selinux_col.collect() is not None
    assert selinux_col.collect()['selinux_python_present'] is True

# Generated at 2022-06-11 05:18:25.498498
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collected_facts = {}
    module = None
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact.collect(module, collected_facts) == {}, 'Failed to get selinux facts, expected empty dict'
    return 0
