

# Generated at 2022-06-11 05:10:33.358001
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector

    PyModule_mock = collector.PyModule
    collected_facts = {'os_family': 'RedHat'}

    # Initial setup
    selinux_facts = {
        'config_mode': 'disabled',
        'mode': 'disabled',
        'type': 'unknown',
        'status': 'disabled',
        'policyvers': 'unknown'
    }
    expected_facts = {'selinux': selinux_facts, 'selinux_python_present': False}

    # Mock selinux.is_selinux_enabled()
    with PyModule_mock(selinux, 'is_selinux_enabled', return_value=False):
        # Test with selinux library not found
        collector = SelinuxFactCollector(module=None)
        facts

# Generated at 2022-06-11 05:10:41.712440
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    collector = SelinuxFactCollector()

    # Test with newly added selinux_python_present in the collected facts.
    # selinux_python_present has default value True.
    collected_facts = {}
    collector.collect(collected_facts=collected_facts)

    assert 'SELINUX' in collected_facts
    assert 'selinux' in collected_facts
    assert 'config_mode' in collected_facts['selinux']
    assert 'mode' in collected_facts['selinux']
    assert 'status' in collected_facts['selinux']
    assert 'type' in collected_facts['selinux']

# Generated at 2022-06-11 05:10:44.374109
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test SelinuxFactCollector constructor
    """
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == 'selinux'

# Generated at 2022-06-11 05:10:53.373543
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Try instantiating the class without selinux library
    # present.
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    keys = facts.keys()

    # The only fact that should have been collected is selinux
    # and selinux_python_present.  selinux should be a dictionary with only
    # one key which is status.
    assert keys == ['selinux', 'selinux_python_present']
    assert 'status' in facts['selinux'].keys()
    assert 'disabled' == facts['selinux']['status']
    assert not facts['selinux_python_present']

# Generated at 2022-06-11 05:10:55.953958
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-11 05:11:04.921205
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts import timeout
    import ansible.module_utils.facts as facts
    facts.TIMEOUT = 0

    # Init the Collector
    collector = Collector()

    # Init the SELinuxFactCollector
    selinux_fct = SelinuxFactCollector(collector=collector)

    # Mock the selinux library
    selinux_mock = mock.MagicMock()
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = None
    selinux_mock.selinux_getenforcemode.return_

# Generated at 2022-06-11 05:11:09.231888
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = False
    collected_facts = {}
    selinux_fact = SelinuxFactCollector()
    expected = {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    assert selinux_fact.collect(module, collected_facts)  == expected

# Generated at 2022-06-11 05:11:15.514250
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect()
    """
    selinux_test_data = {
        'selinux': {
            'config_mode': 'permissive',
            'mode': 'permissive',
            'status': 'enabled',
            'policyvers': '28',
            'type': 'targeted'
        },
        'selinux_python_present': True
    }

    test_obj = SelinuxFactCollector()
    test_obj.collect()
    assert selinux_test_data == test_obj.get_facts()

# Generated at 2022-06-11 05:11:20.272923
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.collect() == {
        'selinux_python_present': True,
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        }
    }

# Generated at 2022-06-11 05:11:21.684869
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-11 05:11:34.769447
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts = SelinuxFactCollector().collect()
    assert 'selinux' in facts
    assert 'selinux_python_present' in facts

    # If Python selinux library is missing, the collector
    # should be able to set only values that can be obtained without it.
    assert 'status' in facts['selinux']

# Generated at 2022-06-11 05:11:44.122758
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    AnsibleModule = lambda *args, **kwargs: None
    setattr(AnsibleModule, 'params', {'gather_subset': ['!all', 'selinux']})

    import io
    collected_facts = {'module_setup': True}

    module = AnsibleModule
    sfc = SelinuxFactCollector()

    # Case: Missing selinux Python library
    setattr(selinux, 'is_selinux_enabled', None)
    facts = sfc.collect(module=module, collected_facts=collected_facts)
    expected_facts = {
        'module_setup': True,
        'selinux': {'status': 'Missing selinux Python library'},
        'selinux_python_present': False
    }


# Generated at 2022-06-11 05:11:45.662500
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_object = SelinuxFactCollector()
    test_object.collect()


# Generated at 2022-06-11 05:11:48.059120
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert(isinstance(selinux_fact_collector, SelinuxFactCollector))

# Generated at 2022-06-11 05:11:49.961193
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:11:58.954420
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a mock selinux module with predefined functions
    class MockSelinux:
        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return 'dummy_policyvers'

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 0

        def selinux_getpolicytype(self):
            return (0, 'dummy_policytype')

    selinux_object = MockSelinux()

    # Create a mock selinux module with no predefined functions
    class MockNoSelinux:
        pass

    no_selinux_object = MockNoSelinux()

    # Create a mock instance of the SelinuxFactCollector class

# Generated at 2022-06-11 05:11:59.854815
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:12:00.700755
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-11 05:12:01.720160
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:12:05.827324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Creates an object of type SelinuxFactCollector
    """
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert len(obj._fact_ids) == 0
    assert obj.collect() == {'selinux_python_present': True, 'selinux': {}}

# Generated at 2022-06-11 05:12:25.107527
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids

# Generated at 2022-06-11 05:12:34.466450
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Disable selinux on the system
    selinux.selinux_setenforce(0)

    # Instantiate the module object with AnsibleModuleMock parameters
    module = AnsibleModuleMock()
    selinux_collector = SelinuxFactCollector()
    # Run collect method
    facts = selinux_collector.collect()

    # Test
    assert facts['selinux_python_present'] == True
    assert facts['selinux']['status'] == 'disabled'
    assert facts['selinux']['config_mode'] is 'unknown'
    assert facts['selinux']['mode'] is 'unknown'
    assert facts['selinux']['type'] is 'unknown'
    assert facts['selinux']['policyvers'] is 'unknown'



# Generated at 2022-06-11 05:12:36.631526
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector


# Generated at 2022-06-11 05:12:39.903780
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()



# Generated at 2022-06-11 05:12:42.784268
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect()

# Generated at 2022-06-11 05:12:44.629821
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector


# Generated at 2022-06-11 05:12:47.822733
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Returns the fact collection from SelinuxFactCollector().collect()
    """
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    return facts

# Generated at 2022-06-11 05:12:49.291118
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.collect()


# Generated at 2022-06-11 05:12:58.474326
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # If the selinux module is not present, the constructor should
    # initialize the status to "Missing selinux Python library".
    # Initialize the SELinux module as None and then call the constructor.
    selinux.selinux_module = None
    sfc = SelinuxFactCollector()

    # Check the name of class
    assert sfc.name == "selinux"

    # Check if the _fact_ids is set to empty set.
    assert sfc._fact_ids == set()

    # Check the status fact
    assert sfc.collect().get("selinux").get("status") == "Missing selinux Python library"

    # Check the selinux_python_present fact
    assert sfc.collect().get("selinux_python_present") == False

    # Now set the selinux module to a new instance and

# Generated at 2022-06-11 05:13:04.375883
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    result_dict = {'selinux': {'status': 'enabled',
                               'config_mode': 'enforcing',
                               'mode': 'enforcing',
                               'type': 'targeted',
                               'policyvers': '28'},
                   'selinux_python_present': True}
    assert result_dict == selinux_facts.collect()

# Generated at 2022-06-11 05:13:53.515138
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """ Test that the selinux fact collector works correctly """
    # Mock out the selinux library, if present
    if HAVE_SELINUX:
        selinux_mock = []
        selinux_returns = {
            'is_selinux_enabled': True,
            'security_getenforce': 0,
            'security_policyvers': 10,
            'security_check_context': (0, 'valid context'),
            'selinux_getenforcemode': (0, 0),
            'selinux_getpolicytype': (0, 'targeted')
        }

        def selinux_side_effect(func_name, *args):
            if func_name in selinux_returns:
                selinux_mock.append(func_name)
                return selinux_returns[func_name]

           

# Generated at 2022-06-11 05:13:56.206458
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()
    assert fact_collector.collect()

# Generated at 2022-06-11 05:13:59.021513
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux_python_present'] in (True, False)
    assert 'selinux' in selinux_facts

# Generated at 2022-06-11 05:14:06.817136
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert 'selinux_python_present' in SelinuxFactCollector._fact_ids
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    if selinux_facts['selinux_python_present']:
        assert 'status' in selinux_facts['selinux']
    else:
        assert 'status' == 'Missing selinux Python library'

# Generated at 2022-06-11 05:14:16.642883
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create a temporary class called MockModuleUtilsFacts
    class MockModuleUtilsFacts():
        def __init__(self):
            self.cache = dict()


    # Initialize a mock object called module
    module = MockModuleUtilsFacts()


    # Create an instance of SelinuxFactCollector called selinux_collector
    selinux_collector = SelinuxFactCollector(module=module)

    # Get the value of selinux_collector.name
    name = selinux_collector.name

    # Assert that the selinux_collector.name is 'selinux'
    assert name == 'selinux'

    # Get the value of selinux_collector._fact_ids
    fact_ids = selinux_collector._fact_ids

    # Assert that selinux_collector._

# Generated at 2022-06-11 05:14:20.356911
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collected_facts = SelinuxFactCollector()
    selinux_collected_facts.collect()
    assert(selinux_collected_facts.name == 'selinux')

# Test for method collect() of class SelinuxFactCollector

# Generated at 2022-06-11 05:14:22.919265
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = None
    collected_facts = None
    selinux_facts = SelinuxFactCollector(module, collected_facts)
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-11 05:14:24.738324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == "selinux"

# Generated at 2022-06-11 05:14:26.129760
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-11 05:14:27.852128
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector is not None

# Generated at 2022-06-11 05:15:51.248959
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Unit test for constructor of class SelinuxFactCollector"""
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:15:55.432507
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect
    """
    module = None
    collected_facts = None
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect(module, collected_facts)
    assert "selinux" in selinux_facts
    assert "selinux_python_present" in selinux_facts

# Generated at 2022-06-11 05:16:03.687518
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        m = __import__('selinux')
        m.is_selinux_enabled = lambda: True
        m.security_policyvers = lambda: 3
        m.selinux_getenforcemode = lambda: (0, 1)
        m.security_getenforce = lambda: 1
        m.selinux_getpolicytype = lambda: (0, 'mcs')
    except ImportError:
        m = None

    collector = SelinuxFactCollector()
    facts = collector.collect()

    assert 'selinux' in facts
    if m is not None:
        expected_facts = {
            'mode': 'enforcing',
            'config_mode': 'enforcing',
            'policyvers': 3,
            'status': 'enabled',
            'type': 'mcs'
        }

# Generated at 2022-06-11 05:16:12.016524
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Stub for selinux.is_selinux_enabled() call
    def fake_selinux_enabled():
        return False

    # Stub for selinux.security_policyvers() call
    def fake_security_policyvers():
        return "fakever"

    # Stub for selinux.selinux_getenforcemode() call
    def fake_selinux_getenforcemode():
        return (0, 0)

    # Stub for selinux.security_getenforce() call
    def fake_security_getenforce():
        return 0

    # Stub for selinux.selinux_getpolicytype() call
    def fake_selinux_getpolicytype():
        return (0, "fakept")

    # Mock the Python SELinux library
    m_selinux = mock.MagicMock()
   

# Generated at 2022-06-11 05:16:14.253164
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:16:14.924687
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:16:23.025503
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with no Python selinux library.  This should be the default
    # if the selinux library is not installed on the system.
    SelinuxFactCollector = SelinuxFactCollector()
    results = SelinuxFactCollector.collect()
    assert results['selinux_python_present'] == False
    assert results['selinux']['status'] == 'Missing selinux Python library'

    # Test with Python selinux library present, but with selinux disabled on the system
    class test(object):
        def __init__(self, is_selinux_enabled=False, security_getenforce=1):
            self.is_selinux_enabled = is_selinux_enabled
            self.security_getenforce = security_getenforce

        def is_selinux_enabled(self):
            return

# Generated at 2022-06-11 05:16:24.274695
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    self = SelinuxFactCollector(None, None)
    self.collect()

# Generated at 2022-06-11 05:16:26.484651
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collector = SelinuxFactCollector()
    # If selinux library is missing, only set the status and selinux_python_present
    test_collector.collect()

# Generated at 2022-06-11 05:16:28.992547
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_col = SelinuxFactCollector()
    assert selinux_col.name == "selinux"
    assert "selinux" in selinux_col.collect()

# Generated at 2022-06-11 05:19:33.401033
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj_collector = SelinuxFactCollector()
    assert obj_collector.name == 'selinux'
    assert obj_collector.collectors == []
    assert obj_collector._fact_ids == set()

# Generated at 2022-06-11 05:19:40.501596
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a class instance to test
    selinux_facts = SelinuxFactCollector()

    # Mock the module for testing
    module = MockModule()

    # Define the return values of selinux.is_selinux_enabled, selinux.security_policyvers,
    # selinux.selinux_getenforcemode, selinux.security_getenforce, selinux.selinux_getpolicytype
    selinux.is_selinux_enabled.return_value = False
    selinux.security_policyvers.return_value = None
    selinux.selinux_getenforcemode.return_value = (0, -1)
    selinux.security_getenforce.return_value = -1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

   

# Generated at 2022-06-11 05:19:45.515381
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    sys.modules['selinux'] = SelinuxMock()
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector != None
    assert selinux_collector.collect() == {'selinux_python_present': True, 'selinux': {'config_mode': 'permissive',
            'status': 'enabled', 'type': 'unknown',
            'mode': 'permissive', 'policyvers': 'unknown'}}


# Generated at 2022-06-11 05:19:53.287288
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create test object
    testobj = SelinuxFactCollector()

    # create a test dict with a boolean and a string
    testdict = {'boolean' : False,
                'string'  : 'sample'}

    # run the collect method and compare the results
    result = testobj.collect(collected_facts=testdict)

    assert result['selinux_python_present'] == True
    assert result['selinux']['status'] == 'enabled'
    assert result['selinux']['mode'] == 'unknown'
    assert result['selinux']['config_mode'] == 'unknown'
    assert result['selinux']['type'] == 'unknown'
    assert result['selinux']['policyvers'] == 'unknown'


# Generated at 2022-06-11 05:19:55.232248
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_obj = SelinuxFactCollector()
    assert test_obj.name == 'selinux'
    assert not test_obj._fact_ids

# Generated at 2022-06-11 05:19:57.760325
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  
    # Constructor test.
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set([])


# Generated at 2022-06-11 05:19:59.117424
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.collect() == {}

# Generated at 2022-06-11 05:20:01.100195
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()

    assert selinux_facts is not None

# Generated at 2022-06-11 05:20:07.485448
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collect_output = SelinuxFactCollector().collect()
    assert 'selinux' in test_collect_output.keys()
    assert 'status' in test_collect_output['selinux'].keys()
    assert 'selinux_python_present' in test_collect_output.keys()
    assert 'policyvers' in test_collect_output['selinux'].keys()
    assert 'config_mode' in test_collect_output['selinux'].keys()
    assert 'mode' in test_collect_output['selinux'].keys()
    assert 'type' in test_collect_output['selinux'].keys()

# Generated at 2022-06-11 05:20:08.327242
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()
