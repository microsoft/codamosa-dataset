

# Generated at 2022-06-11 05:10:23.284114
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-11 05:10:26.809367
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.priority == 25
    assert selinux_fact_collector._fact_ids == set()

# Test for collect()

# Generated at 2022-06-11 05:10:28.439712
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-11 05:10:32.515945
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-11 05:10:34.321572
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    instance = SelinuxFactCollector()
    assert isinstance(instance, SelinuxFactCollector)

# Generated at 2022-06-11 05:10:35.277738
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-11 05:10:42.615900
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Unit test for method collect of class SelinuxFactCollector"""
    fact_coll = SelinuxFactCollector()

    # Test with a mock module that has selinux.is_selinux_enabled set to True
    mock_module = dict()
    mock_module['selinux'] = dict()
    mock_module['selinux']['is_selinux_enabled'] = True
    mock_facts = dict()
    mock_facts['selinux'] = dict()
    mock_facts['selinux_python_present'] = True
    mock_facts['selinux']['status'] = 'enabled'
    mock_facts['selinux']['policyvers'] = 'unknown'
    mock_facts['selinux']['config_mode'] = 'unknown'

# Generated at 2022-06-11 05:10:44.908154
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-11 05:10:49.417771
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_dict = {
        'selinux': {
            'status': 'disabled',
            'selinux_python_present': False
        }
    }
    assert set(SelinuxFactCollector().collect().keys()) == set(test_dict.keys())

# Generated at 2022-06-11 05:10:51.260857
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    assert SelinuxFactCollector.collect() == {}

# Generated at 2022-06-11 05:11:02.477296
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert not x._fact_ids

# Generated at 2022-06-11 05:11:03.478401
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-11 05:11:11.220090
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create instance of SelinuxFactCollector
    selinux_facts = SelinuxFactCollector()

    # Test that selinux library is not present
    result = selinux_facts.collect(None, None)
    assert(result['selinux_python_present'] is False)
    assert(result['selinux']['status'] == 'Missing selinux Python library')

    # Test that selinux library is present
    selinux_facts._module_importer = True
    result = selinux_facts.collect(None, None)
    assert(result['selinux_python_present'] is True)

# Generated at 2022-06-11 05:11:12.528095
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert (obj.name == 'selinux')
    assert (obj._fact_ids == set())


# Generated at 2022-06-11 05:11:21.326173
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''Unit test for method collect of class SelinuxFactCollector'''
    import os
    import mock
    import ansible.module_utils.facts.collector.selinux

    # Create a test fixture to mock the selinux library
    # and set return values for calls to the library
    #
    # Note: the selinux library and the selinux.py module
    # in ansible both have the same name.
    selinux_module = mock.Mock()
    is_selinux_enabled = mock.Mock(return_value=1)
    selinux_module.is_selinux_enabled = is_selinux_enabled
    getenforcemode = mock.Mock(return_value=(1, 0))
    selinux_module.selinux_getenforcemode = getenforcemode
    getpolicy

# Generated at 2022-06-11 05:11:28.142377
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.selinux import SelinuxFactCollector
    if not HAVE_SELINUX:
        return
    facts_collector = FactsCollector()
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect(facts_collector)
    assert facts is not None

# Generated at 2022-06-11 05:11:38.619031
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Method collect of class SelinuxFactCollector return expected data.
    :return:
    """

    expected = {
        'selinux_python_present': True,
        'selinux': {
            'config_mode': 'enforcing',
            'policyvers': '31',
            'type': 'targeted',
            'mode': 'enforcing',
            'status': 'enabled'
        }
    }

    class mock_selinux:
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return '31'

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def security_getenforce():
            return 1


# Generated at 2022-06-11 05:11:46.243937
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector

    # Mock the selinux.is_selinux_enabled method to always return True
    # Skip the selinux.security_policyvers(), selinux.selinux_getenforcemode(),
    # selinux.selinux_getpolicytype(), selinux.security_getenforce() and
    # selinux.getboolean() calls since they would return OSError since
    # the selinux library is not actually linked.
    selinux.is_selinux_enabled = lambda: True

    # Mock the Collector.file_exists() method to always return False
    # to skip the file existence tests
    Collector.file_exists = lambda *args: False

    # Create the selinux fact collector instance
    selinux_collector = SelinuxFactCollector()

   

# Generated at 2022-06-11 05:11:53.044473
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''Unit test for method collect of class SelinuxFactCollector.'''
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()
    assert 'selinux' in facts_dict
    selinux_facts = facts_dict['selinux']
    assert 'status' in selinux_facts
    assert 'config_mode' in selinux_facts
    assert 'mode' in selinux_facts
    assert 'policyvers' in selinux_facts
    assert 'type' in selinux_facts
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-11 05:12:02.081175
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Define the return values of mocked function calls
    class MockedSelinux:
        def __init__(self):
            self.called_setenforce = False
            self.called_getenforce = False
            self.called_getpolicytype = False
            self.called_is_selinux_enabled = False
            self.called_security_policyvers = False
            self.called_selinux_getenforcemode = False

        def is_selinux_enabled(self):
            self.called_is_selinux_enabled = True
            return False

        def security_policyvers(self):
            self.called_security_policyvers = True
            return 0

        def selinux_getpolicytype(self):
            self.called_getpolicytype = True
            return (0, 'targeted')


# Generated at 2022-06-11 05:12:21.231989
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Make SELinux Python library not present
    selinux.is_selinux_enabled = None
    selinux.security_policyvers = None
    selinux.selinux_getenforcemode = None
    selinux.security_getenforce = None
    selinux.selinux_getpolicytype = None
    selinux.selinux_getenforcemode = None

    collector = SelinuxFactCollector()
    facts_dict = collector.collect()

    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict['selinux_python_present'] == False

    # Make SELinux Python library is present but SELinux is disabled
    def mock_is_selinux_enabled():
        return False
    selinux.is_selinux

# Generated at 2022-06-11 05:12:22.243810
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:12:24.537780
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c._fact_ids == set()

# Generated at 2022-06-11 05:12:28.446100
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-11 05:12:31.882165
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''
    test for constructor of SelinuxFactCollector
    '''

    sfc = SelinuxFactCollector()

    assert sfc is not None
    assert sfc.name == 'selinux'

# Generated at 2022-06-11 05:12:32.534712
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:12:35.438088
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
    assert selinux_fact_collector._fact_ids == set()
    assert selinux_fact_collector.collector == {}


# Generated at 2022-06-11 05:12:42.584674
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()

    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-11 05:12:51.654458
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
   
    class FakeModule(object):
        def __init__(self):
            self.ansible_facts = {}

    fake_module = FakeModule()

    # Test case when selinux library is not present
    action_mode = SelinuxFactCollector()
    action_mode.collect(fake_module)
    assert 'selinux_python_present' in fake_module.ansible_facts

    # Test case when selinux library is present
    action_mode = SelinuxFactCollector()
    action_mode.collect(fake_module)
    assert 'selinux_python_present' in fake_module.ansible_facts

test_SelinuxFactCollector_collect()

# Generated at 2022-06-11 05:12:55.388744
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import cache

    collector = Collector(cache.Cache(), 'setup', None,
                          [SelinuxFactCollector])

    result = collector.collect(None, None)

    assert 'selinux' in result
    assert result['selinux']['status'] == 'disabled'
    assert result['selinux_python_present'] == True

# Generated at 2022-06-11 05:13:15.483352
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert 'selinux' in selinux_fc._fact_ids

# Generated at 2022-06-11 05:13:18.566690
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Unit test for constructor of class SelinuxFactCollector"""
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()
    assert selinux_facts.collect() == {}

# Generated at 2022-06-11 05:13:20.392795
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:13:24.709683
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of SelinuxFactCollector
    collector = SelinuxFactCollector(module=None, collected_facts=None)

    # Test the collect method
    facts_dict = collector.collect()

    # Assert that the facts_dict is empty if the selinux library is not present
    assert not facts_dict
    assert facts_dict.get('selinux_python_present') == False

# Generated at 2022-06-11 05:13:27.998427
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    selinux_keys = set(['status', 'policyvers', 'config_mode', 'mode', 'type'])
    assert obj._fact_ids == selinux_keys | set(['selinux_python_present'])

# Generated at 2022-06-11 05:13:28.511052
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-11 05:13:30.679422
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test for constructor with valid input"""
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-11 05:13:33.002487
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Set selinux module to None
    x = SelinuxFactCollector(module=None)
    assert x.name == 'selinux'
    assert x._fact_ids == set()
    assert x._module == None

# Generated at 2022-06-11 05:13:34.675758
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    loaded_class = SelinuxFactCollector()
    assert loaded_class.name == 'selinux'


# Generated at 2022-06-11 05:13:37.690194
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test for method collect of class SelinuxFactCollector
    '''
    selinux_collector = SelinuxFactCollector()
    results = selinux_collector.collect()

    assert results['selinux']['status'] in ['disabled', 'enabled']


# Generated at 2022-06-11 05:14:15.516098
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    f = SelinuxFactCollector()
    f.collect()

# Generated at 2022-06-11 05:14:17.552659
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect(module=None, collected_facts=None)
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector

# Generated at 2022-06-11 05:14:20.442858
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()

    assert obj.name == 'selinux'
    assert set(['selinux_python_present', 'selinux']) == obj._fact_ids


# Generated at 2022-06-11 05:14:30.456814
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect()."""
    import sys

    # Save original selinux Python library path
    selinux_lib = '/usr/lib/python2.7/site-packages/selinux'
    if selinux_lib in sys.path:
        sys.path.remove(selinux_lib)

    from ansible.module_utils.facts.collectors import SelinuxFactCollector

    # Disable selinux for testing
    selinux_enabled = False
    try:
        selinux_enabled = selinux.is_selinux_enabled()
        selinux.security_setenforce(0)
    except AttributeError:
        pass

    # Test that selinux is found
    collected_facts = SelinuxFactCollector().collect()

# Generated at 2022-06-11 05:14:33.441480
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:14:37.668292
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect()
    assert 'selinux_python_present' in facts
    if facts['selinux_python_present'] is True:
        assert 'selinux' in facts

# Generated at 2022-06-11 05:14:38.873492
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:14:40.576453
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert isinstance(obj, SelinuxFactCollector)

# Generated at 2022-06-11 05:14:43.086787
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-11 05:14:46.814415
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    se = SelinuxFactCollector()
    assert se.name == "selinux"
    assert se.collect() == dict(selinux=dict(status="enabled"), selinux_python_present=True)

# Generated at 2022-06-11 05:16:27.243858
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-11 05:16:37.368767
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with the Python selinux library present
    facts_dict = SelinuxFactCollector().collect()
    assert 'selinux' in facts_dict
    assert facts_dict['selinux']
    assert 'status' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']
    assert 'policyvers' in facts_dict['selinux']
    assert 'selinux_python_present' in facts_dict
    assert facts_dict['selinux_python_present']

    # Test with the Python selinux library not present
    original_have_selinux = SelinuxFactCollector.global_vars['HAVE_SELINUX']
    SelinuxFactCollector.global_vars['HAVE_SELINUX'] = False
    facts_dict = Selin

# Generated at 2022-06-11 05:16:46.727021
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import default_collectors

    testobj = Facts()

    testobj.populate()
    assert testobj._collector_facts['selinux_python_present'] is True, "testobj._collector_facts['selinux_python_present'] = %r" % testobj._collector_facts['selinux_python_present']
    assert (testobj._collector_facts['selinux'] is not None) and (testobj._collector_facts['selinux']['status'] is not None), "testobj._collector_facts['selinux'] = %r" % testobj._collector_facts['selinux']

    collector = SelinuxFactCollector()
    module_tmpdir = collector.get_module_

# Generated at 2022-06-11 05:16:51.674794
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    assert('selinux' in facts)
    assert('status' in facts['selinux'])
    assert('config_mode' in facts['selinux'])
    assert('mode' in facts['selinux'])
    assert('type' in facts['selinux'])

# Generated at 2022-06-11 05:17:01.254773
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set(['selinux', 'selinux_python_present'])

    # Test if the collect method returns the correct dictionary if selinux
    # python library is missing
    fact_dict = selinux_collector.collect()
    assert 'selinux' in fact_dict
    assert 'selinux_python_present' in fact_dict
    assert fact_dict['selinux'] == {'status':'Missing selinux Python library'}
    assert fact_dict['selinux_python_present'] == False

    # Test if the collect method returns the correct dictionary if the
    # selinux python library is present
    fact_dict = selinux_collector

# Generated at 2022-06-11 05:17:10.306061
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect()"""
    import builtins

    module = builtins.__dict__.get('__import__')('ansible.module_utils.facts.system.selinux', fromlist=['SelinuxFactCollector'])

    class MockSelObj(object):
        """Mock SELinux object"""
        def __init__(self, lib_present=True, selinux_enabled=True):
            self._lib_present = lib_present
            self._selinux_enabled = selinux_enabled

        def is_selinux_enabled(self):
            """Mock method selinux.is_selinux_enabled()"""
            return self._selinux_enabled

        def security_policyvers(self):
            """Mock method selinux.security_policyvers()"""
           

# Generated at 2022-06-11 05:17:14.545148
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test SelinuxFactCollector.collect()"""
    # Create a SelinuxFactCollector object
    selinuxfactcollector = SelinuxFactCollector()
    stat = selinuxfactcollector.collect()
    assert stat['selinux']['status'] == 'disabled'
    assert stat['selinux_python_present'] == True

# Generated at 2022-06-11 05:17:18.575992
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    facts = SelinuxFactCollector.collect(module)
    assert 'selinux' in facts
    assert 'status' in facts['selinux']
    assert isinstance(facts['selinux']['status'], str)
    assert isinstance(facts['selinux']['status'], str)


# Generated at 2022-06-11 05:17:27.455469
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    test_collector = SelinuxFactCollector()

    setattr(selinux, 'is_selinux_enabled', lambda: True)
    setattr(selinux, 'security_getenforce', lambda: 1)
    setattr(selinux, 'security_policyvers', lambda: 28)
    setattr(selinux, 'selinux_getenforcemode', lambda: (0, 1))
    setattr(selinux, 'selinux_getpolicytype', lambda: (0, 'targeted'))
    fact_dict = test_collector.collect(collected_facts={'selinux': {'status': 'enabled', 'mode': 'enforcing', 'type': 'targeted', 'policyvers': 28, 'config_mode': 'enforcing'}})

# Generated at 2022-06-11 05:17:32.164384
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.setup_cache("test_SelinuxFactCollector_collect")
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    selinux_fact_collector.cleanup_cache()
    assert result['selinux'] is not None
    assert result['selinux_python_present'] is not None