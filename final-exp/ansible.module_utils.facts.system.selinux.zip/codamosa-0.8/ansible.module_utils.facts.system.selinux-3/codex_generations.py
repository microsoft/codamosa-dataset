

# Generated at 2022-06-11 05:10:21.098123
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None

# Generated at 2022-06-11 05:10:28.924304
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Passing 'selinux' to the selinux fact collector.
    :return:
    """
    # If SELinux libraries are available, collect facts.
    # Otherwise, return a dict of status and selinux_python_present
    # with appropriate values.
    if HAVE_SELINUX:
        collector = SelinuxFactCollector()
        # Expected dict from collector
        expected = dict(selinux=dict(
            status='enabled',
            policyvers=0,
            config_mode='disabled',
            mode='disabled',
            type='targeted'
        ), selinux_python_present=True)
    else:
        collector = SelinuxFactCollector()
        expected = dict(selinux=dict(status='Missing selinux Python library',), selinux_python_present=False)

    #

# Generated at 2022-06-11 05:10:39.222264
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts_dict = dict(
        selinux=dict(
            status='enabled',
            policyvers=3,
            config_mode='enforcing',
            mode='enforcing',
            type='targeted'
        ),
        selinux_python_present=True
    )

    selinux_mock = dict(
        is_selinux_enabled=lambda: True,
        security_policyvers=lambda: 3,
        selinux_getenforcemode=lambda: (0, 1),
        security_getenforce=lambda: 1,
        selinux_getpolicytype=lambda: (0, 'targeted')
    )

    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect(selinux=selinux_mock)


# Generated at 2022-06-11 05:10:40.873629
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method SelinuxFactCollector.collect
    """


# Generated at 2022-06-11 05:10:51.893655
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        from ansible.module_utils.compat import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    _not_selinux_running = os.path.exists("/etc/selinux/config") and not selinux.is_selinux_enabled()
    _selinux_python_present = HAVE_SELINUX

    result = SelinuxFactCollector()
    facts_dict = result.collect(None, None)
    assert(isinstance(facts_dict, dict))

    # If selinux library is missing, set the status and selinux_python_present
    if not HAVE_SELINUX:
        assert('status' in facts_dict['selinux'])
        assert('python_present' in facts_dict)

# Generated at 2022-06-11 05:10:55.512946
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    collection_obj = SelinuxFactCollector()
    failed, complete_facts = collection_obj.collect(module=module, collected_facts=None)

    assert module._facts_set == 1

# Generated at 2022-06-11 05:10:56.926339
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()


# Generated at 2022-06-11 05:10:58.257281
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_coll = SelinuxFactCollector()
    assert selinux_fact_coll.name == 'selinux'

# Generated at 2022-06-11 05:11:03.288614
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    collected_facts = {}
    result = fact_collector.collect(collected_facts=collected_facts)
    assert 'selinux_python_present' in result['ansible_local']
    assert 'status' in result['ansible_local']['selinux']
    assert result['ansible_local']['selinux']['status'] == 'enabled'

# Generated at 2022-06-11 05:11:05.890645
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-11 05:11:12.142334
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:11:17.348828
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Setup test variables
    selinux_collector = SelinuxFactCollector()
    collector_name = 'selinux'
    collected_facts = {
        'selinux': {
            'status': 'disabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'disabled',
            'type': 'unknown'
        }
    }

    # Test name property
    assert(selinux_collector.name == collector_name)

    # Test collect method
    assert(selinux_collector.collect() == collected_facts)

# Generated at 2022-06-11 05:11:19.247046
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-11 05:11:22.848553
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector
    assert fact_collector.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library',
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-11 05:11:26.556696
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    obj = SelinuxFactCollector()
    collected_facts = obj.collect()
    assert collected_facts is not None

# Generated at 2022-06-11 05:11:29.378743
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    result = SelinuxFactCollector()
    assert result.__dict__ == {
        "name": "selinux",
        "_fact_ids": set()
    }

# Generated at 2022-06-11 05:11:31.629883
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 05:11:33.783545
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj.collect_fn == obj.collect

# Generated at 2022-06-11 05:11:36.847634
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == set()


# Generated at 2022-06-11 05:11:39.175275
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-11 05:11:45.545683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 05:11:51.229914
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import SelinuxFactCollector
    from ansible.module_utils import basic
    module_mock = basic.AnsibleModule(argument_spec={})
    selinux_facts_dict = SelinuxFactCollector().collect(module=module_mock)
    assert selinux_facts_dict is not None
    selinux_facts = selinux_facts_dict.get('selinux')
    assert selinux_facts is not None

# Generated at 2022-06-11 05:12:00.298022
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def selinux_is_selinux_enabled():
        return True
    def security_getenforce():
        return 1
    def selinux_getenforcemode():
        return 0, 1
    def security_policyvers():
        return 23
    def selinux_getpolicytype():
        return 0, 'targeted'

    selinux_mock = {'is_selinux_enabled': selinux_is_selinux_enabled,
                    'security_getenforce': security_getenforce,
                    'selinux_getenforcemode': selinux_getenforcemode,
                    'security_policyvers': security_policyvers,
                    'selinux_getpolicytype': selinux_getpolicytype}

    s = SelinuxFactCollector()

# Generated at 2022-06-11 05:12:08.240284
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Pass a mock module object to the class
    fact_collector = SelinuxFactCollector(module=None)

    # Pass a mock collected_facts object to the class
    fact_data = fact_collector.collect(collected_facts=None)

    assert 'selinux' in fact_data
    # The following asserts work if/when the Python selinux library is found
    assert 'status' in fact_data['selinux']
    assert 'mode' in fact_data['selinux']
    assert 'policyvers' in fact_data['selinux']
    assert 'config_mode' in fact_data['selinux']
    assert 'type' in fact_data['selinux']

# Generated at 2022-06-11 05:12:09.790171
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert not HAVE_SELINUX or 'selinux' in SelinuxFactCollector().collect()

# Generated at 2022-06-11 05:12:13.582654
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Unit Test for collect method of class SelinuxFactCollector

# Generated at 2022-06-11 05:12:15.747830
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert(isinstance(selinux_collector, SelinuxFactCollector))

# Generated at 2022-06-11 05:12:21.486526
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import mock

    module = mock.Mock()
    collected_facts = mock.Mock()
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts_dict = selinux_fact_collector.collect(module, collected_facts)

    import sys
    if sys.version_info.major > 2:
        assert isinstance(selinux_facts_dict, dict)
    else:
        assert isinstance(selinux_facts_dict, dict)

# Generated at 2022-06-11 05:12:22.519077
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-11 05:12:29.307013
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create empty object
    selinux_facts = SelinuxFactCollector()

    # Assume SELinux is not enabled
    selinux_facts.collect()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.collect_fn_args == {}
    assert selinux_facts.collect_fn_kwargs == {}
    assert selinux_facts.collected_facts == {}
    assert selinux_facts.fact_ids == set()
    assert selinux_facts.platform_supports_fact == True

# Generated at 2022-06-11 05:12:40.995335
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert 'selinux' in selinux_collector.name
    assert 'selinux_python_present' in selinux_collector.collect()

# Generated at 2022-06-11 05:12:51.573702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    import ansible.module_utils.facts.fact_cache
    from ansible.module_utils.facts.external import selinux

    ansible.module_utils.facts.fact_cache.FACT_CACHE, ansible.module_utils.facts.collector.FACTS_COLLECTORS, ansible.module_utils.facts.external.HAVE_SELINUX = (None, None, None)

    def refresh():
        FactsCollector.clear_cache()
        SelinuxFactCollector.clear_cache()


# Generated at 2022-06-11 05:12:53.659205
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c._fact_ids == set()
    assert c._collect_fn_list == [c.collect]


# Generated at 2022-06-11 05:13:04.043811
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import ansible.module_utils.facts.collectors.selinux as selinux_facts

    HAVE_SELINUX = False
    selinux_facts.HAVE_SELINUX = False

    # Test with no selinux python library
    facts_dict = {}
    selinux_collector = selinux_facts.SelinuxFactCollector()
    selinux_collector.collect(module=None, collected_facts=facts_dict)

    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict['selinux_python_present'] is False

    # Test with the selinux python library

    HAVE_SELINUX = True
    selinux_facts.HAVE_SELINUX = True


# Generated at 2022-06-11 05:13:13.425736
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAVE_SELINUX:
        selinux.is_selinux_enabled = lambda: True
        selinux.security_policyvers = lambda: '1'
        selinux.selinux_getenforcemode = lambda: (0, 1)
        selinux.selinux_getpolicytype = lambda: (0, 'targeted')
        selinux.security_getenforce = lambda: 1
    else:
        selinux.is_selinux_enabled = lambda: False

    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert facts_dict['selinux_python_present'] == HAVE_SELINUX

# Generated at 2022-06-11 05:13:14.281619
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-11 05:13:22.438400
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create mock return values for the selinux library
    selinux_mock_values = {
        'is_selinux_enabled': True,
        'security_policyvers': '29',
        'selinux_getenforcemode': (0, 1),
        'security_getenforce': 1,
        'selinux_getpolicytype': (0, 'targeted')
    }

    # Create mock methods for the selinux library
    def selinux_mock_method(method, *args, **kwargs):
        return selinux_mock_values.get(method)

    # Setup the module mock and module args
    module_mock = MagicMock()
    module_args = dict()

    # Import the module and create an instance of the class under test
    selinux_fact_collector = SelinuxFact

# Generated at 2022-06-11 05:13:30.607247
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    def mock_is_selinux_enabled():
        return False

    def mock_security_policyvers():
        return 48

    def mock_selinux_getenforcemode():
        return 0, 0

    def mock_security_getenforce():
        return -1

    def mock_selinux_getpolicytype():
        return 0, 'targeted'

    def mock_have_selinux():
        return False

    selinux.is_selinux_enabled = mock_is_selinux_enabled
    selinux.security_policyvers = mock_security_policyvers
    selinux.selinux_getenforcemode = mock_selinux_getenforcemode
    selinux.security_getenforce = mock_security_getenforce
    selinux.selinux_getpolicytype = mock_sel

# Generated at 2022-06-11 05:13:33.610626
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-11 05:13:38.925628
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact = SelinuxFactCollector()
    fact_dict = selinux_fact.collect()
    assert fact_dict['selinux_python_present'] == True
    assert fact_dict['selinux']['type'] == 'unknown'
    assert fact_dict['selinux']['mode'] == 'unknown'
    assert fact_dict['selinux']['config_mode'] == 'unknown'
    assert fact_dict['selinux']['policyvers'] == 'unknown'
    assert fact_dict['selinux']['status'] == 'disabled'

# Generated at 2022-06-11 05:13:50.803016
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    col_obj = SelinuxFactCollector()
    result = col_obj.collect(collected_facts={'ansible_selinux_python_present' : True})
    assert result

# Generated at 2022-06-11 05:14:00.329986
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockSELinux(object):
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return 1

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')

        @staticmethod
        def security_getenforce():
            return 1


# Generated at 2022-06-11 05:14:09.385487
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    tester = SelinuxFactCollector()

    assert tester.name == "selinux"
    assert tester.collect() is not None
    assert tester.collect()["selinux"] is not None
    assert tester.collect()["selinux"]["status"] is not None
    assert tester.collect()["selinux"]["mode"] is not None
    assert tester.collect()["selinux"]["type"] is not None
    assert tester.collect()["selinux"]["policyvers"] is not None
    assert tester.collect()["selinux"]["config_mode"] is not None
    assert tester.collect()["selinux_python_present"] is not None



# Generated at 2022-06-11 05:14:11.541952
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-11 05:14:21.192687
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import selinux
    selinux_facts = {}
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = 'unknown'
    selinux_facts['config_mode'] = 'unknown'
    selinux_facts['type'] = 'unknown'
    selinux_facts['mode'] = 'unknown'

    facts_dict = {}
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = True
    selinux.is_selinux_enabled.return_value = True
    selinux.security_getenforce.return_value = 0
    selinux.security_policyvers.return_value = 1
    selinux.selinux_getenforcemode.return_value = (0, 0)
    selinux.selinux_

# Generated at 2022-06-11 05:14:22.919241
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect_fn = None
    SelinuxFactCollector.collect()

# Generated at 2022-06-11 05:14:28.341698
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.virtual.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.compat.selinux

    test_obj = SelinuxFactCollector()
    test_obj.collect()
    assert issubclass(SelinuxFactCollector, BaseFactCollector)

# Generated at 2022-06-11 05:14:32.348362
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    expected_attributes = [
        'name',
        '_fact_ids'
    ]
    selinux_fact_collector = SelinuxFactCollector()
    actual_attributes = dir(selinux_fact_collector)
    assert all(item in actual_attributes for item in expected_attributes)

# Generated at 2022-06-11 05:14:34.706968
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    module = None
    collected_facts = {}


# Generated at 2022-06-11 05:14:45.033726
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()

    # Test without the selinux library present
    ret_val = selinux_collector.collect()
    assert(ret_val['selinux']['status'] == 'Missing selinux Python library')
    assert(ret_val['selinux']['type'] is None)
    assert(ret_val['selinux']['mode'] is None)
    assert(ret_val['selinux']['config_mode'] is None)
    assert(ret_val['selinux']['policyvers'] is None)
    assert(ret_val['selinux_python_present'] is False)

    # Test with the selinux library present
    selinux_collector.collect(None, dict(selinux_python_present=True))

# Generated at 2022-06-11 05:14:55.121498
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-11 05:14:57.187943
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    collected_facts = collector.collect()
    assert 'selinux' in collected_facts

# Generated at 2022-06-11 05:14:59.952964
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    input_param = {}
    instance = SelinuxFactCollector()
    result = instance.collect(input_param)
    assert result['selinux']
    assert result['selinux_python_present']

# Generated at 2022-06-11 05:15:09.214000
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test 1: If Python selinux library is missing, only set the status and selinux_python_present
    # since there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    # Also, test to ensure that the collected facts dict is returned.
    import builtins
    builtins.__dict__['HAVE_SELINUX'] = False
    facts_dict = SelinuxFactCollector().collect()
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert 'selinux_python_present' in facts_dict
    assert 'policyvers' not in facts_dict['selinux']
    assert 'config_mode' not in facts_dict['selinux']
    assert 'mode' not in facts_dict['selinux']


# Generated at 2022-06-11 05:15:17.451466
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import os

    os.environ['SELINUX_INIT'] = 'True'

    selinuxmock = mock.Mock()
    selinuxmock.is_selinux_enabled.return_value = True
    selinuxmock.security_policyvers.return_value = '23'
    selinuxmock.selinux_getenforcemode.return_value = (0, 1)
    selinuxmock.selinux_getpolicytype.return_value = (0, 'targeted')
    selinuxmock.security_getenforce.return_value = 1

    s = SelinuxFactCollector()
    with mock.patch.dict('sys.modules', selinux=selinuxmock):
        facts = s.collect(module=None, collected_facts=None)

   

# Generated at 2022-06-11 05:15:18.523213
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    o = SelinuxFactCollector()
    assert o.name == 'selinux'

# Generated at 2022-06-11 05:15:25.457234
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class MockSelinuxModule:
        # Mock class for selinux since we do not have this in unit tests currently
        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return '123'

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 1

        def selinux_getpolicytype(self):
            return (0, 'type')

    expected_result = {
        'ansible_selinux': {
            'config_mode': 'enforcing',
            'mode': 'enforcing',
            'policyvers': '123',
            'status': 'enabled',
            'type': 'type'
        }
    }

# Generated at 2022-06-11 05:15:26.185426
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:15:27.527914
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()
    assert s.name == 'selinux'
    assert s._fact_ids == set()

# Generated at 2022-06-11 05:15:28.384857
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    f = SelinuxFactCollector()
    assert f.name == 'selinux'

# Generated at 2022-06-11 05:16:04.861244
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    import inspect
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    selinux_collector = SelinuxFactCollector()

    def get_argument_spec():
        """Implemented for AnsibleModule Util"""
        return dict(
            gather_subset=dict(default=['!all'], type='list')
        )

    class AnsibleModuleTest(unittest.TestCase):
        """Unit Test class for AnsibleModule"""
        def __init__(self):
            self.module = AnsibleModule
            self.module.params = dict()
            self.module.params['gather_subset'] = ['all']


# Generated at 2022-06-11 05:16:07.738092
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:16:10.863378
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Set boolean for testing how the constructor deals with imports
    selinux.is_selinux_enabled = False
    instance = SelinuxFactCollector()
    assert instance.name == 'selinux'
    assert instance._fact_ids == set()


# Generated at 2022-06-11 05:16:16.833157
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collected_facts = {'ansible_facts': {'selinux': {'type': 'targeted'}}}
    fully_collected_facts = {'ansible_facts': {
        'selinux_python_present': True,
        'selinux': {
            'config_mode': 'unknown',
            'type': 'targeted',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'status': 'disabled'
        }
    }}
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect(collected_facts=collected_facts) == fully_collected_facts

# Generated at 2022-06-11 05:16:19.170445
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()


# Generated at 2022-06-11 05:16:21.380707
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    instance = SelinuxFactCollector()
    assert isinstance(instance, SelinuxFactCollector)
    assert isinstance(instance.collect(), dict)

# Generated at 2022-06-11 05:16:24.356289
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.__name__ == 'selinux'
    assert selinux_collector.__class__.__name__ == 'SelinuxFactCollector'

# Generated at 2022-06-11 05:16:26.565870
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == 'selinux'
    assert selinux_fc._fact_ids == set()

# Generated at 2022-06-11 05:16:28.431132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    a = SelinuxFactCollector()
    assert a.name == "selinux"
    assert a._fact_ids == set()


# Generated at 2022-06-11 05:16:30.062393
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-11 05:17:08.232446
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert 'selinux' in facts
    assert 'selinux_python_present' in facts


# Generated at 2022-06-11 05:17:09.817088
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_object = SelinuxFactCollector()
    assert selinux_object  # will raise exception if object creation fails

# Generated at 2022-06-11 05:17:18.539551
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test for selinux python library is missing
    class selinux_mock:
        @staticmethod
        def is_selinux_enabled():
            return False

    module_mock = MagicMock(name='module')
    facts_dict_mock = dict()
    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect_fn = selinux_mock
    selinux_collector.collect(module=module_mock, collected_facts=facts_dict_mock)
    assert isinstance(facts_dict_mock['selinux_python_present'], bool)
    assert facts_dict_mock['selinux'] == {'status': 'Missing selinux Python library'}

    # Test for selinux python library is present

# Generated at 2022-06-11 05:17:27.410735
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = dict()
    facts_dict = dict()
    if not HAVE_SELINUX:
        selinux_facts = dict()
        s = SelinuxFactCollector()
        collected_facts = s.collect(module, facts_dict)
        selinux_facts = collected_facts['selinux']
        assert selinux_facts['status'] == 'Missing selinux Python library'
        assert collected_facts['selinux_python_present'] == False
    else:
        selinux_facts = dict()
        s = SelinuxFactCollector()
        collected_facts = s.collect(module, facts_dict)
        selinux_facts = collected_facts['selinux']

        # If running under SELinux environment, test the values returned
        # by collect method against the values returned by the
        # corresponding API's

# Generated at 2022-06-11 05:17:29.272841
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'



# Generated at 2022-06-11 05:17:31.471102
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert sorted(collector._fact_ids) == ['selinux', 'selinux_python_present']

# Generated at 2022-06-11 05:17:39.026575
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    module = AnsibleModuleMock()
    collector = SelinuxFactCollector()

    # Simulate the selinux library is not present so the collect method
    # sets selinux_python_present to false.
    setattr(collector, 'have_selinux', False)

    result = collector.collect(module=module)
    assert result == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # Simulate the selinux library being present
    setattr(collector, 'have_selinux', True)
    # Simulate selinux not enabled
    setattr(selinux, 'is_selinux_enabled', lambda: False)
    result = collector.collect(module=module)

# Generated at 2022-06-11 05:17:45.319817
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Mock
    class FakeCollector():
        def __init__(self):
            self.name = 'fake_collector'
            self.verbose = False
            pass

    class FakeModule():
        def __init__(self):
            self.collector = FakeCollector()

        def get_bin_path(self, name, opt_dirs=None, required=False):
            return name

    module = FakeModule()

    # Test
    collec_facts = SelinuxFactCollector().collect(module=module,
                                                  collected_facts=None)

    # Assertions
    assert collec_facts['selinux_python_present'] == True

# Generated at 2022-06-11 05:17:52.010346
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # mock selinux library functions
    class MockSelinux:
        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return 3

        def selinux_getenforcemode(self):
            return (0, 1)

        def selinux_getpolicytype(self):
            return (0, 'targeted')

        def security_getenforce(self):
            return 0

    module = object()
    collected_facts = object()
    selinux_facts = MockSelinux()

    selinux_obj = SelinuxFactCollector()

    # test collecting of selinux facts
    selinux_obj.collect(module, collected_facts, selinux_facts)

# Generated at 2022-06-11 05:17:53.532104
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 05:19:50.578729
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc is not None
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()


# Generated at 2022-06-11 05:19:58.671547
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This function only runs if the selinux module is present
    if not HAVE_SELINUX:
        return

    collector = SelinuxFactCollector()
    facts = collector.collect()

    # There should be a 'selinux' dictionary in the facts
    assert isinstance(facts['selinux'], dict)

    if selinux.is_selinux_enabled():
        # Once we know selinux is enabled, the other values should be present
        assert isinstance(facts['selinux']['status'], str)
        assert isinstance(facts['selinux']['type'], str)
        assert isinstance(facts['selinux']['mode'], str)
        assert isinstance(facts['selinux']['config_mode'], str)

# Generated at 2022-06-11 05:20:00.505320
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collected_facts = {}
    SelinuxFactCollector().collect(collected_facts=collected_facts)
    assert 'selinux' in collected_facts

# Generated at 2022-06-11 05:20:07.241887
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup parameters for the test
    module_params = {}
    collected_facts = {}
    expected_fact_values = {
        'selinux': {
            'config_mode': 'unknown',
            'policyvers': 'unknown',
            'mode': 'unknown',
            'type': 'unknown',
            'status': 'enabled'
        }
    }

    selinux_collector = SelinuxFactCollector(module=module_params, collected_facts=collected_facts)

    # Result of the test
    test_result = selinux_collector.collect()

    # Assert that the returned data match the expected data
    assert expected_fact_values == test_result

# Generated at 2022-06-11 05:20:09.300552
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    result = SelinuxFactCollector()
    assert result is not None
    assert result.name == 'selinux'
    assert result._fact_ids == set()

# Generated at 2022-06-11 05:20:16.391880
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAVE_SELINUX:
        import mock
        from ansible.module_utils.facts.collector import SelinuxFactCollector
        selinux_fact_collector = SelinuxFactCollector()
        selinux_status = 'enabled'

        # Mock the selinux.is_selinux_enabled to return true
        # so that we can test the code for path when SELinux is
        # enabled.
        with mock.patch.object(selinux, 'is_selinux_enabled', return_value=True):
            # Test the code for path when SELinux is enabled
            facts = selinux_fact_collector.collect()
            selinux_facts = facts.get('selinux')
            assert selinux_facts is not None

            # Test the status