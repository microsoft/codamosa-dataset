

# Generated at 2022-06-11 05:10:23.642925
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert isinstance(obj._fact_ids, set)
    assert obj._fact_ids == set()


# Generated at 2022-06-11 05:10:33.663303
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect()
    assert facts['selinux'] == {}
    assert facts['selinux_python_present'] == False

    selinux_fact_collector.selinux.is_selinux_enabled = lambda: True
    selinux_fact_collector.selinux.security_policyvers = lambda: 1
    selinux_fact_collector.selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux_fact_collector.selinux.security_getenforce = lambda: 1
    selinux_fact_collector.selinux.selinux_getpolicytype = lambda: (0, "targeted")

# Generated at 2022-06-11 05:10:38.651902
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    # Create test values
    facts_dict = {'selinux': {'config_mode': 'permissive', 'status': 'enabled'}}

    # Check if collect method runs without errors
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux'] == facts_dict['selinux']

# Generated at 2022-06-11 05:10:44.385196
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux_python_present' in selinux_facts, 'selinux_python_present not present'
    assert 'selinux' in selinux_facts, 'selinux dict not present'
    assert 'status' in selinux_facts['selinux'], 'selinux status not present'

# Generated at 2022-06-11 05:10:45.823942
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector != None

# Generated at 2022-06-11 05:10:49.421465
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:10:52.078082
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()

    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-11 05:10:54.942607
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-11 05:11:00.437075
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Creating SelinuxFactCollector instance
    selinux_fact = SelinuxFactCollector()

    # "mock_selinux" is a mock for selinux Python library
    # that returns configured data and allows testing
    # of SelinuxFactCollector.collect method.
    mock_selinux = MockSelinux()

    # Loading SelinuxFactCollector.collect method with
    # specified parameters.

    # Testing if selinux Python library is not installed
    selinux_fact.collect(module=MockModule(selinux=None))

    # Testing if selinux is enabled on the system
    # and get some data from selinux Python library.
    selinux_fact.collect(module=MockModule(selinux=mock_selinux))

    # Testing if selinux is disabled on the system
    se

# Generated at 2022-06-11 05:11:01.425461
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()

# Generated at 2022-06-11 05:11:15.577592
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This is a unit test method for the class SelinuxFactCollector.
    """

    # Load module source file (if any) to test
    module_path = 'ansible.module_utils.facts.collectors.seine'
    module_args_name = 'ansible.module_utils.facts.collectors.seine.__file__'
    module_source = __import__(module_path, globals(), locals(), ['']).__file__

    # Create a fake module object
    module = types.ModuleType(module_path)
    module.__file__ = module_source

    # Create a fake config object for the module object
    class ModuleConfig(object):
        def __init__(self):
            self.config = None
    module.config = ModuleConfig()

    # Create a fake ansible config object for

# Generated at 2022-06-11 05:11:17.986012
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert 'selinux' in selinux_fact_collector._fact_ids

# Generated at 2022-06-11 05:11:29.174225
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    assert sys.version_info[0] == 2, "This test is only applicable in Python 2.x"
    from ansible.module_utils.facts.collector import Collector, get_collector_instance
    from ansible.module_utils.compat import selinux

    def save_se_enable():
        return 1

    def save_getenforce():
        return 1

    def save_spol_vers():
        return 1

    def save_getpolicytype():
        return (0, "min")

    def save_getenforcemode():
        return (0, 1)

    setattr(selinux, "is_selinux_enabled", save_se_enable)
    setattr(selinux, "security_getenforce", save_getenforce)

# Generated at 2022-06-11 05:11:35.733732
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Given
    selinux_fact = SelinuxFactCollector()

    # When
    result = selinux_fact.collect()

    # Then
    assert result['selinux']
    assert result['selinux']['config_mode']
    assert result['selinux']['mode']
    assert result['selinux']['policyvers']
    assert result['selinux']['status']
    assert result['selinux']['type']
    assert result['selinux_python_present']

# Generated at 2022-06-11 05:11:38.169476
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-11 05:11:39.555036
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-11 05:11:46.704213
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # In Ansible 2.4 we need to use module_utils.compat to import selinux
    import sys
    if sys.version_info < (2, 7):
        import imp
        try:
            imp.find_module('selinux')
            found = True
        except ImportError:
            found = False
        if not found:
            import socket
            import urllib
            import urllib2
            url = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/compat/selinux.py'
            response = urllib2.urlopen(url)
            selinux_pyc = response.read()

            with open('selinux.py', 'wb') as handle:
                handle.write(selinux_pyc)

# Generated at 2022-06-11 05:11:48.103483
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)

# Generated at 2022-06-11 05:11:53.830402
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test for method collect of class SelinuxFactCollector
    '''
    # Skip the test on platforms that don't have the selinux module
    if not HAVE_SELINUX:
        return

    selinux_collector = SelinuxFactCollector()
    facts = selinux_collector.collect(None, None)
    # The unit test below only validates we have the selinux facts
    assert facts['selinux_python_present']
    assert 'selinux' in facts

# Generated at 2022-06-11 05:11:56.373915
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test class creation
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == "selinux"
    assert selinux_facts.collect() == {}

# Generated at 2022-06-11 05:12:07.572508
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-11 05:12:09.749286
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector_test = SelinuxFactCollector()
    assert collector_test.name == 'selinux'
    assert collector_test._fact_ids != set()

# Generated at 2022-06-11 05:12:13.130688
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    assert selinux_fact_collector_obj.name == 'selinux'
    assert selinux_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-11 05:12:16.523888
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:12:26.229456
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class _module(object):
        def __init__(self):
            self.params = None

    class _collect(object):
        def __init__(self):
            self.selinux = None
            self.selinux_python_present = None

    selinux_facts_dict = dict(
        status="enabled",
        policyvers='21',
        config_mode="enforcing",
        mode='disabled',
        type='targeted',
    )

    selinux_facts = dict(
        selinux=selinux_facts_dict,
        selinux_python_present=True,
    )

    sfc = SelinuxFactCollector()
    facts = _collect()
    selinux_facts_returned = sfc.collect(collected_facts=facts)

    assert selinux_facts == selinux_

# Generated at 2022-06-11 05:12:35.635766
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockSelinux(object):
        SELINUX_DISABLED = -1
        SELINUX_ENFORCING = 1
        SELINUX_PERMISSIVE = 0

        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_getenforce():
            return MockSelinux.SELINUX_ENFORCING

        @staticmethod
        def security_policyvers():
            return '28'

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')


# Generated at 2022-06-11 05:12:46.319493
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # create instance and set settings
    selinux_collector = SelinuxFactCollector()
    selinux_collector._module = None
    selinux_collector._collect_subset = None
    selinux_collector._gather_subset = None
    selinux_collector._gather_timeout = None
    selinux_collector._display.verbosity = 'vvvv'
    selinux_collector._display.deprecate('message', date='2022-01-01') # do nothing to avoid warning message

    # test with selinux disabled
    selinux_collector_fallback = SelinuxFactCollector()
    selinux_collector_fallback._module = None
    selinux_collector_fallback._collect_subset = None

# Generated at 2022-06-11 05:12:55.493889
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock
    import ansible.module_utils.facts.collectors.selinux as selinux_fact

    # Create a mock selinux module that does not have selinux enabled
    # and does not have the selinux library (HAVE_SELINUX is false)
    mock_selinux_info = {
        'status': 'Missing selinux Python library',
        'config_mode': 'unknown',
        'policyvers': 'unknown',
        'mode': 'unknown',
        'type': 'unknown'
    }

# Generated at 2022-06-11 05:13:02.988119
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Unit test for method collect of class SelinuxFactCollector
    '''
    selinux_fact = SelinuxFactCollector()
    expected_fact = {
        'selinux_python_present': True,
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        }
    }
    assert selinux_fact.collect() == expected_fact

# Generated at 2022-06-11 05:13:12.337652
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact = SelinuxFactCollector()
    result = fact.collect()
    if 'selinux_python_present' in result:
        assert result['selinux']['status'] == 'enabled' or result['selinux']['status'] == 'disabled' or result['selinux']['status']=='Missing selinux Python library'
        if result['selinux']['status'] == 'enabled':
            assert result['selinux']['type'] == 'unknown' or result['selinux']['type'] == 'targeted'
            assert result['selinux']['mode'] == 'unknown' or result['selinux']['mode'] == 'enforcing' or result['selinux']['mode'] == 'permissive'

# Generated at 2022-06-11 05:13:41.872240
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux_ import SelinuxFactCollector


# Generated at 2022-06-11 05:13:43.820962
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector.collect() == {}

# Generated at 2022-06-11 05:13:53.419631
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()
    assert type(selinux_facts) is dict

    assert 'selinux_python_present' in selinux_facts
    assert type(selinux_facts['selinux_python_present']) is bool

    assert 'selinux' in selinux_facts
    assert type(selinux_facts['selinux']) is dict

    assert 'status' in selinux_facts['selinux']
    assert type(selinux_facts['selinux']['status']) is str
    assert selinux_facts['selinux']['status'] in ['enabled', 'disabled']


# Generated at 2022-06-11 05:13:55.451191
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-11 05:13:58.538308
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAS_SELINUX:
        selinux_fact_collector = SelinuxFactCollector()
        selinux_fact_collector.collect()
    else:
        pytest.skip('skipping selinux fact test, selinux module missing')

# Generated at 2022-06-11 05:14:00.326794
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Constructor of class SelinuxFactCollector tests
    """
    SelinuxFactCollector()

# Generated at 2022-06-11 05:14:10.221613
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import pytest
    from ansible.module_utils.facts import collector

    # Create an instance of class SelinuxFactCollector
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

    # Load SELinux Python library to the system path
    if sys.platform.startswith('linux'):
        sys.path.append('/usr/lib64/python2.7/site-packages/')
    pytest.importorskip('selinux')

    # Create a non selinux system

# Generated at 2022-06-11 05:14:11.161401
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector(None)

# Generated at 2022-06-11 05:14:12.509292
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert hasattr(SelinuxFactCollector, 'collect')

# Generated at 2022-06-11 05:14:13.483667
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-11 05:14:37.367863
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # The collect method of SelinuxFactCollector doesn't require a module parameter,
    # but we still need to provide it for the method signature.
    # We don't need to test the return value of the collect method, since that is
    # tested by the main facts unit test.
    SelinuxFactCollector(None).collect(None, None)

# Generated at 2022-06-11 05:14:46.511899
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {
        'status': 'enabled',
        'policyvers': '24',
        'config_mode': 'enforcing',
        'mode': 'enforcing',
        'type': 'targeted'
    }

    # mock the selinux module
    selinux_mock = mock.MagicMock(selinux)
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = '24'
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, 'targeted')

    selinux

# Generated at 2022-06-11 05:14:47.835700
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'

# Generated at 2022-06-11 05:14:51.647437
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert set(selinux_fact_collector._fact_ids) == set(['selinux', 'selinux_python_present'])


# Generated at 2022-06-11 05:14:56.575286
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test with abnormal case: selinux library not present
    selinux_collector = SelinuxFactCollector()
    facts_dict = selinux_collector.collect(None)
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict['selinux_python_present'] == False

# Generated at 2022-06-11 05:14:59.439656
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-11 05:15:08.271805
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """This is a destructured version of ansible/test/units/modules/utils/test_selinux.py
    """

    class MockSelinux(object):
        def is_selinux_enabled(self):
            return False

    import sys

    # Mock out the selinux module
    from ansible.module_utils import selinux
    selinux_old = selinux
    sys.modules['selinux'] = MockSelinux()

    # Run the module
    result = SelinuxFactCollector.collect()
    selinux_facts = result['selinux']

    # Restore the module
    sys.modules['selinux'] = selinux_old

    # Assert that selinux fact dictionary is empty
    assert selinux_facts == {}



# Generated at 2022-06-11 05:15:10.539311
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_fact_collector = SelinuxFactCollector()
    result = test_fact_collector.collect()
    assert result['selinux']



# Generated at 2022-06-11 05:15:14.844003
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    expected = {
        'selinux': {
            'status': 'disabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'disabled',
            'type': 'unknown'
        },
        'selinux_python_present': False
    }

    assert SelinuxFactCollector.collect() == expected

# Generated at 2022-06-11 05:15:16.761318
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    soldev = SelinuxFactCollector()
    assert soldev.name == 'selinux'
    assert 'selinux' in soldev._fact_ids

# Generated at 2022-06-11 05:16:19.180844
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a new instance of class SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()

    # Collect facts
    selinux_facts = selinux_collector.collect()

    # Test selinux_python_present is set to True
    assert 'selinux_python_present' in selinux_facts

    # Test selinux facts
    selinux_obj = selinux_facts['selinux']
    assert 'status' in selinux_obj
    assert 'config_mode' in selinux_obj
    assert 'mode' in selinux_obj
    assert 'policyvers' in selinux_obj
    assert 'type' in selinux_obj

# Generated at 2022-06-11 05:16:22.461132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test with name 'foo'
    x = SelinuxFactCollector('foo')
    assert x.name == 'foo'
    assert x._fact_ids == set()
    assert not x.fetch_cache
    assert not x.fetch_subset


# Generated at 2022-06-11 05:16:26.403091
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    expected_dict = {'selinux_python_present': True, 'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}}
    assert fact_collector.collect() == expected_dict

# Generated at 2022-06-11 05:16:31.522790
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_collected_facts = {'selinux': {'status': 'disabled'},
                               'selinux_python_present': 'False'}

    s = SelinuxFactCollector()
    assert s.name == 'selinux'
    assert s._fact_ids == set()
    assert s.collect(collected_facts=selinux_collected_facts) == selinux_collected_facts


# Generated at 2022-06-11 05:16:40.014835
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test if we can get selinux facts without a selinux Python library present
    # This is for backwards compatibility
    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect()
    assert selinux_collector._fact_ids == {'selinux', 'selinux_python_present'}

    # Test if we can get selinux facts with a selinux Python library present
    selinux_collector = SelinuxFactCollector()
    selinux_collector.collect()
    assert selinux_collector._fact_ids == {'selinux', 'selinux_python_present'}

# Generated at 2022-06-11 05:16:43.118129
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:16:44.249632
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)

# Generated at 2022-06-11 05:16:52.194786
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModule(argument_spec={})
    collected_facts = dict()

    # If the selinux library is missing, we expect the function to set
    # two values in the collected facts.
    #    selinux:
    #        status: 'Missing selinux Python library'
    #    selinux_python_present: False
    sfc = SelinuxFactCollector()
    collected_facts = sfc.collect(module=module, collected_facts=collected_facts)
    assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    assert collected_facts['selinux_python_present'] == False

# Generated at 2022-06-11 05:16:54.553290
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"
    assert obj.collected_facts == {}


# Generated at 2022-06-11 05:16:57.832536
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj.collect()['selinux']['status'] == 'Missing selinux Python library'
    assert obj.collect()['selinux_python_present'] == False



# Generated at 2022-06-11 05:18:53.394989
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    ansible_module = AnsibleModule()

    SelinuxFactCollectorType = collector.get_collector("selinux")
    selinux_collector = SelinuxFactCollectorType(ansible_module)

    assert(isinstance(selinux_collector, SelinuxFactCollector))
    assert(selinux_collector.name == 'selinux')
    assert(selinux_collector.priority == 80)
    assert(selinux_collector._fact_class == dict)
    assert(len(selinux_collector._fact_ids) == 0)

# Mock AnsibleModule class for unit testing

# Generated at 2022-06-11 05:18:56.355118
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    # We need to fake this value, otherwise it will be equal to the
    # SelinuxFactCollector.name, which is 'selinux'
    obj.name = 'gather_subset.selinux'

    return obj

# Generated at 2022-06-11 05:18:58.805929
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert 'selinux' == x.name
    assert 'selinux' in x._fact_ids


# Unit test to test method collect of class SelinuxFactCollector

# Generated at 2022-06-11 05:19:01.284905
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set(['selinux'])



# Generated at 2022-06-11 05:19:08.886675
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FactsCache
    fc = FactsCache()
    c = Collector(fc)
    c.collect_facts = False

    assert hasattr(c, '_fact_classes')
    assert type(c._fact_classes) is list
    assert not c._fact_classes
    assert SelinuxFactCollector not in c._fact_classes

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    for m in ('selinux', 'selinux_python_present'):
        assert m not in fc


# Generated at 2022-06-11 05:19:10.350536
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_collector.name

# Generated at 2022-06-11 05:19:12.813655
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.collect() == {'selinux': {'status': 'disabled'}, 'selinux_python_present': True}

# Generated at 2022-06-11 05:19:13.718093
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-11 05:19:16.318715
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Constructor with no arguments should return an object of SelinuxFactCollector
    obj = SelinuxFactCollector()

    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 05:19:19.916966
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_SelinuxFactCollector = SelinuxFactCollector()
    # Check that the instance created correctly
    assert test_SelinuxFactCollector
    # Check the attributes are correctly set
    assert hasattr(test_SelinuxFactCollector, "name")
    assert hasattr(test_SelinuxFactCollector, "_fact_ids")