

# Generated at 2022-06-11 05:10:26.809261
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert set(['selinux', 'selinux_python_present']) == selinux_fact_collector._fact_ids

# Generated at 2022-06-11 05:10:29.706654
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector.collect()['selinux_python_present'] is True
    assert 'selinux' in collector.collect()

# Generated at 2022-06-11 05:10:37.821044
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector()
    result = selinux_fc.collect()
    
    if HAVE_SELINUX:
        assert result['selinux']['status'] == 'enabled'
        assert result['selinux']['config_mode'] == 'enforcing'
        assert result['selinux']['mode'] == 'enforcing'
        assert result['selinux']['type'] == 'targeted'
    else:
        assert result['selinux']['status'] == 'Missing selinux Python library'
        assert result['selinux_python_present'] == False

# Generated at 2022-06-11 05:10:41.239000
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import sys

    # Set up the environment like a Linux system
    if 'linux' in sys.platform:
        fact_collector = SelinuxFactCollector()
        assert fact_collector.name == 'selinux'
        assert fact_collector._fact_ids == set()
    else:
        pass

# Generated at 2022-06-11 05:10:44.762120
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector_obj = SelinuxFactCollector()
    res = selinux_collector_obj.collect()
    assert not res['selinux_python_present']
    assert 'status' in res['selinux']

# Generated at 2022-06-11 05:10:49.217117
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    fact = SelinuxFactCollector()

    assert fact.name == 'selinux'
    assert fact._fact_ids == set()
    assert callable(getattr(fact, 'collect'))
    assert 'selinux_python_present' in fact.collect()


# Generated at 2022-06-11 05:10:58.960742
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class DummySel(object):
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_getenforce():
            return 1

        @staticmethod
        def security_policyvers():
            return 42

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'dummy')

    class DummyModule(object):
        selinux = DummySel()

    sfc = SelinuxFactCollector()

    facts_dict = sfc.collect(module=DummyModule())

    assert facts_dict['selinux_python_present'] == True
    assert facts_dict['selinux'].get('status') == 'enabled'

# Generated at 2022-06-11 05:11:01.505452
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    collected_facts = {}
    collected_facts = selinux_collector.collect(module=None, collected_facts=collected_facts)
    print(collected_facts)

if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-11 05:11:02.437353
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-11 05:11:03.805872
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-11 05:11:13.936207
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-11 05:11:23.236929
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a fake module object
    module = type('os', (object,), dict(params={}))

    # Create an instance of the SelinuxFactCollector
    collector = SelinuxFactCollector(module)

    # create a fake selinux library by creating a module with the same name
    # as the actual selinux library so we can mock up the return values.

# Generated at 2022-06-11 05:11:26.214037
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert(selinux_fact_collector.name == 'selinux')

# Generated at 2022-06-11 05:11:31.011008
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Verify behavior when selinux Python library is not present
    selinux_fact = SelinuxFactCollector()
    assert isinstance(selinux_fact, SelinuxFactCollector)

    # Verify attributes when selinux Python library is present
    assert selinux_fact.name == 'selinux'
    assert selinux_fact._fact_ids == set()

# Generated at 2022-06-11 05:11:33.160261
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'
    assert SelinuxFactCollector()._fact_ids == set()


# Generated at 2022-06-11 05:11:39.229208
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts_dict = fact_collector.collect()
    assert facts_dict['selinux']['status'] == 'enabled'
    assert facts_dict['selinux']['type'] == 'targeted'
    assert facts_dict['selinux']['mode'] == 'enforcing'
    assert facts_dict['selinux']['config_mode'] == 'enforcing'

# Generated at 2022-06-11 05:11:41.559444
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collect = SelinuxFactCollector().collect()
    assert collect == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-11 05:11:47.032316
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    collected_facts = {}
    facts_dict = collector.collect(collected_facts=collected_facts)

    assert 'selinux_python_present' in facts_dict
    assert 'selinux' in facts_dict

    if facts_dict['selinux_python_present']:
        assert 'status' in facts_dict['selinux']
        assert 'type' in facts_dict['selinux']
        assert 'config_mode' in facts_dict['selinux']
        assert 'mode' in facts_dict['selinux']
    else:
        assert 'status' in facts_dict['selinux']

# Generated at 2022-06-11 05:11:55.030382
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    class CollectorTest(Collector):
        def __init__(self):
            self.fact_class_list = [SelinuxFactCollector]
            super(CollectorTest, self).__init__()

    # Run collect method of SelinuxFactCollector
    collector = CollectorTest()
    collected_facts = {'kernel': {'name': 'Linux'}}
    selinux_facts = collector.collect(collected_facts=collected_facts)

    # Check if selinux facts key is present in the collected facts
    assert 'selinux' in selinux_facts
    assert selinux_facts['selinux_python_present'] == True

# Generated at 2022-06-11 05:11:56.701165
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    se = SelinuxFactCollector()
    assert se.name == 'selinux'


# Generated at 2022-06-11 05:12:17.429576
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-11 05:12:19.565074
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == "selinux", "The name of SelinuxFactCollector instance should be selinux"

# Generated at 2022-06-11 05:12:22.019171
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fc = SelinuxFactCollector()
    fct = fc.collect()
    if 'selinux' in fct:
        selinux = fct['selinux']
        if selinux['status'] != 'disabled':
            assert 'policyvers' in selinux
            assert 'config_mode' in selinux
            assert 'mode' in selinux
            assert 'type' in selinux

# Generated at 2022-06-11 05:12:31.958561
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test method collect of class SelinuxFactCollector
    """
    fake_selinux = get_fake_Selinux()
    selinux_data = SelinuxFactCollector().collect(fake_selinux)
    assert selinux_data.get('selinux_python_present')
    assert selinux_data['selinux']['status'] == 'enabled'
    assert selinux_data['selinux']['policyvers'] == 'fake_policyvers'
    assert selinux_data['selinux']['config_mode'] == 'fake_config_mode'
    assert selinux_data['selinux']['mode'] == 'fake_mode'
    assert selinux_data['selinux']['type'] == 'fake_type'


# Generated at 2022-06-11 05:12:39.056368
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    assert 'selinux' in facts
    assert 'selinux_python_present' in facts
    if facts['selinux_python_present']:
        assert 'status' in facts['selinux']
        assert 'config_mode' in facts['selinux']
        assert 'mode' in facts['selinux']
        assert 'type' in facts['selinux']
        assert 'policyvers' in facts['selinux']
    else:
        assert 'Missing selinux Python library' in facts['selinux']['status']

# Generated at 2022-06-11 05:12:41.909372
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_collector = SelinuxFactCollector()
    assert test_collector.name == 'selinux'
    assert test_collector._fact_ids == set()


# Generated at 2022-06-11 05:12:45.115961
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.collect() == {}

# Generated at 2022-06-11 05:12:49.083006
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    global HAVE_SELINUX
    HAVE_SELINUX = True
    c = SelinuxFactCollector()
    assert c['selinux_python_present']
    c = SelinuxFactCollector()
    assert c['selinux_python_present']

# Generated at 2022-06-11 05:12:49.397345
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-11 05:12:58.569697
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts import FACT_CACHE

    # Load facts for test
    Collector.load_cache(FACT_CACHE)

    # Get SelinuxFactCollector instance
    selinux_fact_collector = get_collector_instance(SelinuxFactCollector)

    # Need to mock selinux library
    selinux_fact_collector.module.selinux = selinux

    # Test the collection of selinux facts when selinux is enabled
    def mock_is_selinux_enabled():
        return True

    selinux_fact_collector.module.selinux.is_selinux_enabled = mock_is_selinux_enabled

   

# Generated at 2022-06-11 05:13:19.489864
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    This is a unittest for the constructor of the class SelinuxFactCollector.
    """
    f = SelinuxFactCollector()
    assert f.name == 'selinux'

# Generated at 2022-06-11 05:13:21.193142
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-11 05:13:26.862533
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    facts = selinux_collector.collect(None, None)
    assert facts['selinux']['status'] == 'disabled'
    assert facts['selinux']['type'] == 'unknown'
    assert facts['selinux']['mode'] == 'disabled'
    assert facts['selinux']['config_mode'] == 'unknown'
    assert facts['selinux']['policyvers'] == 'unknown'
    assert facts['selinux_python_present'] is False

# Generated at 2022-06-11 05:13:27.961865
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    se_instance = SelinuxFactCollector()
    assert se_instance.name

# Generated at 2022-06-11 05:13:29.744586
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 05:13:35.456595
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector()
    res = selinux_fc.collect()

    assert res is not None
    assert res['selinux'] is not None
    assert res['selinux']['type'] is not None
    assert res['selinux']['status'] is not None
    assert res['selinux']['config_mode'] is not None
    assert res['selinux']['mode'] is not None
    assert res['selinux']['policyvers'] is not None
    assert res['selinux_python_present'] is not None

# Generated at 2022-06-11 05:13:43.238014
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''Test SelinuxFactCollector.collect'''
    from ansible.module_utils.compat.tests.test_selinux import MockSELinuxModule
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts import get_collector
    # Get SelinuxFactCollector object
    selinux_collector = get_collector_instance(get_collector('selinux'))
    # Get a dictionary of facts with Selinux enabled
    selinux_collector._module = MockSELinuxModule(enabled=True)
    facts_dict = selinux_collector.collect()
    assert 'selinux' in facts_dict
    selinux_facts = facts_dict['selinux']
    # Check that facts_dict contains a dictionary
   

# Generated at 2022-06-11 05:13:44.875964
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = SelinuxFactCollector().collect()

    assert isinstance(facts_dict, dict) == True

# Generated at 2022-06-11 05:13:54.420405
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Define a 'mock' selinux module for testing if it is not installed on the local or remote
    # system when running the fact module code

    class mock_selinux_no_lib:
        @staticmethod
        def is_selinux_enabled():
            return False

    class mock_selinux_lib:
        @staticmethod
        def is_selinux_enabled():
            return False

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def security_getenforce():
            return 1

        @staticmethod
        def security_policyvers():
            return '42'

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')


# Generated at 2022-06-11 05:13:56.823275
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    actual = SelinuxFactCollector()

    assert(actual.name == 'selinux')
    assert(isinstance(actual._fact_ids, set))


# Generated at 2022-06-11 05:14:34.278590
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert 'selinux' in obj._fact_ids

# Generated at 2022-06-11 05:14:36.908232
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector('str')
    assert selinuxFactCollector.name == 'selinux'


# Generated at 2022-06-11 05:14:43.501459
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class MockModule(object):
        pass

    class MockCollectedFacts(dict):
        pass

    collector = SelinuxFactCollector()

    assert collector.collect() == {
        'selinux': {},
        'selinux_python_present': False
    }

    collected_facts = MockCollectedFacts()
    collector.collect(collected_facts=collected_facts)
    assert 'selinux' in collected_facts
    assert 'selinux_python_present' in collected_facts

# Generated at 2022-06-11 05:14:46.405047
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    mySelinuxFactCollector = SelinuxFactCollector()
    assert mySelinuxFactCollector


# Generated at 2022-06-11 05:14:57.136334
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert HAVE_SELINUX # If not True, will not be able to fully test this collector

    collector = SelinuxFactCollector()
    facts = collector.collect()

    # Verify the expected keys are in the output
    assert 'selinux' in facts
    assert 'selinux_python_present' in facts

    # Verify selinux_python_present is a logical True/False
    assert isinstance(facts['selinux_python_present'], bool)

    # Verify that selinux is present in the dictionary
    assert 'selinux' in facts

    # Verify that status is present
    assert 'status' in facts['selinux']

    # Check the status
    if not selinux.is_selinux_enabled():
        assert facts['selinux']['status'] == 'disabled'

# Generated at 2022-06-11 05:14:59.194254
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:15:00.749558
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.collect()['selinux_python_present']

# Generated at 2022-06-11 05:15:04.292444
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxfact_collector = SelinuxFactCollector()
    assert selinuxfact_collector.name == 'selinux'
    assert selinuxfact_collector.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-11 05:15:09.212914
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    x = SelinuxFactCollector()
    assert isinstance(x, Collector)
    assert isinstance(x, BaseFactCollector)
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-11 05:15:11.313559
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    m_module = MagicMock()
    m_fact_collector = SelinuxFactCollector()
    m_fact_collector.collect(m_module)

# Generated at 2022-06-11 05:16:45.869947
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"


# Generated at 2022-06-11 05:16:48.818417
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sf = SelinuxFactCollector()
    result = sf._collect()
    assert result.has_key("selinux")
    assert result.has_key("selinux_python_present")

# Generated at 2022-06-11 05:16:50.991504
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:16:54.455470
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fake_module = object()
    collector = SelinuxFactCollector()

    assert len(collector.collect(fake_module)) == 2
    assert len(collector.collect(fake_module)['selinux']) == 4

# Generated at 2022-06-11 05:16:56.465595
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    m = SelinuxFactCollector()
    assert m.name == 'selinux'
    assert m._fact_ids == set()

# Generated at 2022-06-11 05:17:01.596211
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.selinux_collector import SelinuxFactCollector


    # Create fake module and facts dictionary
    module = type('Module', (), {})()
    collected_facts = {}

    # Case 1: Disable the import of selinux for testing
    global HAVE_SELINUX
    HAVE_SELINUX = False

    facts = SelinuxFactCollector().collect(module)

    assert facts['ansible_facts']['selinux']['status'] == 'Missing selinux Python library'
    assert facts['ansible_facts']['selinux_python_present'] == False

    # Case 2: Enable the import of selinux for testing
    global HAVE_SELINUX
    HAVE_

# Generated at 2022-06-11 05:17:03.068385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None


# Generated at 2022-06-11 05:17:04.661218
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'

# Generated at 2022-06-11 05:17:13.649091
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    # Dummy class object used for passing to the collect method
    class DummyClass:
        pass
    dummy_class_obj = DummyClass()
    # If the selinux library is not present, the selinux.is_selinux_enabled method will not be
    # available. In that case, the 'selinux_python_present' will be set to false and the 'status'
    # will be set to 'Missing selinux Python library'
    try:
        selinux_collector.collect(dummy_class_obj)
        python_present = True
        status = 'enabled'
    except AttributeError:
        python_present = False
        status = 'Missing selinux Python library'

# Generated at 2022-06-11 05:17:16.208045
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()

    assert selinux_facts.get('selinux_python_present') is not None
    assert selinux_facts.get('selinux') is not None