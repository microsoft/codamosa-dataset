

# Generated at 2022-06-11 05:10:26.926889
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert len(selinux_facts._fact_ids) == 0
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-11 05:10:37.397966
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector instance so we can use the collect method to test
    sfc = SelinuxFactCollector()

    # Create a test module class, this is needed to call the collect method
    # and the module is needed to create the collected_facts parameter.
    class Module(object):
        def __init__(self):
            self._module = self

    test_module = Module()

    # Create a test collected_facts dict
    test_collected_facts = {}

    # Call the collect method and store the result, this is what we are trying to test
    result_dict = sfc.collect(test_module, test_collected_facts)

    # Check that the result dictionary contains the correct keys
    assert 'selinux' in result_dict
    assert 'selinux_python_present' in result_dict



# Generated at 2022-06-11 05:10:37.872203
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-11 05:10:48.019079
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize a Selinux fact collector
    fact_collector = SelinuxFactCollector()

    # Collect the facts
    facts = fact_collector.collect()

    if not facts:
        raise RuntimeError("Unable to collect facts")
    else:
        # Make sure that the selinux facts dict is present
        if 'selinux' not in facts:
            raise RuntimeError("selinux_facts dict not found")
        else:
            # Make sure that a selinux status is present
            if 'status' not in facts['selinux']:
                raise RuntimeError("selinux_facts['status'] not found")

        # If Python library is not present, make sure that both Python boolean and status
        # are present but that the other selinux facts are not present

# Generated at 2022-06-11 05:10:50.753049
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-11 05:10:53.527857
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact = SelinuxFactCollector()

    # Test that the constructor of the SelinuxFactCollector class is correct
    assert(type(fact)) == SelinuxFactCollector

# Generated at 2022-06-11 05:11:02.531269
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class MockModule():
        def __init__(self, params):
            self.params = params

    def mock_is_selinux_enabled():
        return True

    def mock_selinux_getenforcemode():
        return (0, 0)

    def mock_security_getenforce():
        return 0

    def mock_selinux_getpolicytype():
        return (0, 'targeted')

    def mock_security_policyvers():
        return 29

    class MockSel():
        def __init__(self, return_values):
            self.return_values = return_values

        def is_selinux_enabled(self):
            return self.return_values['is_selinux_enabled']


# Generated at 2022-06-11 05:11:03.954773
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-11 05:11:06.983688
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert 'selinux' in selinux_collector._fact_ids

# Generated at 2022-06-11 05:11:09.233868
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert isinstance(x._fact_ids, set)

# Generated at 2022-06-11 05:11:22.992605
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        expected = {
            'selinux_python_present': False,
            'selinux': {'status': 'Missing selinux Python library'}
        }
        collected_facts = SelinuxFactCollector().collect()
        assert expected == collected_facts
        return

    if not selinux.is_selinux_enabled():
        expected = {
            'selinux_python_present': True,
            'selinux': {'status': 'disabled'}
        }
        collected_facts = SelinuxFactCollector().collect()
        assert expected == collected_

# Generated at 2022-06-11 05:11:26.710868
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids

# Generated at 2022-06-11 05:11:32.681982
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()
    assert result == {
        "selinux": {
            "status": "enabled",
            "config_mode": "permissive",
            "type": "targeted",
            "mode": "permissive",
            "policyvers": "31"
        },
        'selinux_python_present': True
    }

# Generated at 2022-06-11 05:11:42.580925
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class mock_selinux:
        @staticmethod
        def is_selinux_enabled():
            return False

        @staticmethod
        def selinux_getenforcemode():
            return 0, 1

        @staticmethod
        def security_getenforce():
            return 1

        @staticmethod
        def selinux_getpolicytype():
            return 0, 'policytype'

        @staticmethod
        def security_policyvers():
            return 'policyvers'

    mock_module = object()
    mock_collected_facts = object()

    collector = SelinuxFactCollector()
    collector.collect(mock_module, mock_collected_facts)
    assert 'selinux' in collector.collect(mock_module, mock_collected_facts)

    collector = SelinuxFactCollector()
    collector

# Generated at 2022-06-11 05:11:45.462255
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Call constructor
    selinux_fact_collector = SelinuxFactCollector()

    # Check instance variables
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:11:52.586105
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()

    assert  isinstance(facts_dict, dict)

    assert  facts_dict.get('selinux')

    assert  facts_dict['selinux'].get('policyvers')
    assert  facts_dict['selinux'].get('config_mode')
    assert  facts_dict['selinux'].get('mode')
    assert  facts_dict['selinux'].get('type')
    assert  facts_dict['selinux'].get('status')
    assert  facts_dict.get('selinux_python_present')

# Generated at 2022-06-11 05:12:01.681051
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test data
    test_policy = {
        'status': 'enabled',
        'policyvers': '28',
        'config_mode': 'enforcing',
        'mode': 'enforcing',
        'type': 'targeted'
    }

    # Get the SeLinux fact collector
    fact_collector = SelinuxFactCollector()
    # Collect the selinux facts
    selinux_facts = fact_collector.collect()

    # Check that the selinux facts are as expected
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux'] == test_policy

    # Create a new Selinux fact collector
    fact_collector = SelinuxFactCollector()
    # Mock the is_selinux_enabled method so that it returns False and collect the facts


# Generated at 2022-06-11 05:12:03.443067
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'

# Generated at 2022-06-11 05:12:05.014621
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name

# Generated at 2022-06-11 05:12:07.918791
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fc = SelinuxFactCollector('test_module')
    test_dict = selinux_fc.collect()
    assert isinstance(test_dict, dict)
    assert test_dict['selinux_python_present'] == True

# Generated at 2022-06-11 05:12:21.400994
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj
    assert selinux_obj.collect() == {'selinux': {'status': 'disabled', 'mode': 'disabled', 'config_mode': 'disabled', 'type': 'unknown', 'policyvers': 'unknown'},
                                     'selinux_python_present': True}

# Generated at 2022-06-11 05:12:31.446667
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import ansible_collection_mock
    from ansible.module_utils.facts import ansible_module_mock
    from ansible.module_utils.facts import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    collector.collectors['ansible.module_utils.selinux_test'] = SelinuxFactCollector()

    # Mock of AnsibleModule
    module = ansible_module_mock.AnsibleModuleMock()
    # Mock of AnsibleCollectionFactsModule
    facts_module = ansible_collection_mock.AnsibleCollectionFactsModuleMock(module)
    # Mock of AnsibleFactsCollector
    facts_collector = BaseFactCollector

# Generated at 2022-06-11 05:12:33.262990
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:12:35.242261
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_data = {'selinux_python_present':False,'selinux':{'status':'Missing selinux Python library'}}
    obj = SelinuxFactCollector()
    assert test_data == obj.collect()

# Generated at 2022-06-11 05:12:38.100183
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxcollector = SelinuxFactCollector()
    assert selinuxcollector.name == "selinux"
    assert selinuxcollector._fact_ids == set()


# Generated at 2022-06-11 05:12:40.994681
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test if class SelinuxFactCollector methods exists"""
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:12:51.573458
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Define a class attribute _fact_ids to be used by collect method
    SelinuxFactCollector._fact_ids = set(['selinux', 'selinux_python_present'])

    # Test collect method when selinux Python library is missing
    f = SelinuxFactCollector()
    facts = f.collect()
    assert facts == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

    # Test collect method when selinux Python library is present and SELinux is disabled
    SelinuxFactCollector._fact_ids = set(['selinux', 'selinux_python_present'])
    f = SelinuxFactCollector()

# Generated at 2022-06-11 05:12:52.513874
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'

# Generated at 2022-06-11 05:12:54.423834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:13:02.940921
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert result['selinux_python_present'] == True

    if HAVE_SELINUX:
        assert result['selinux']['status'] == 'enabled'
        assert result['selinux']['mode'] == 'enforcing'
        assert result['selinux']['config_mode'] == 'enforcing'
        assert result['selinux']['policyvers'] == '28'
        assert result['selinux']['type'] == 'targeted'
    else:
        assert result['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-11 05:13:29.276061
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if not HAVE_SELINUX:
        return

    import mock

    def getenforcemode():
        return (0, 0)

    def security_policyvers():
        return 22

    def security_getenforce():
        return 0

    def selinux_getpolicytype():
        return (0, 'targeted')

    test_selinux_dict = {
        'config_mode': 'permissive',
        'mode': 'permissive',
        'policyvers': 22,
        'status': 'enabled',
        'type': 'targeted'}
    selinux.selinux_getenforcemode = getenforcemode
    selinux.security_policyvers = security_policyvers
    selinux.security_getenforce = security_getenforce
    selinux.selinux_getpolicytype = selinux_

# Generated at 2022-06-11 05:13:30.359741
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-11 05:13:32.476784
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_obj = SelinuxFactCollector()
    assert(test_obj.__class__.__name__ == 'SelinuxFactCollector')


# Generated at 2022-06-11 05:13:35.049794
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_obj = SelinuxFactCollector()
    result = selinux_fact_collector_obj.collect(collected_facts={})
    assert result['selinux']['mode'] == 'unknown'

# Generated at 2022-06-11 05:13:36.352285
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'

# Generated at 2022-06-11 05:13:38.241130
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert sfc._fact_ids == set()

# Generated at 2022-06-11 05:13:40.284662
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test case if selinux Python library is missing
    obj = SelinuxFactCollector()
    obj.collect(module, collected_facts={})

# Generated at 2022-06-11 05:13:42.867985
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:13:50.363281
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect(module=None, collected_facts=None)
    assert (selinux_facts['selinux']['mode'] in SELINUX_MODE_DICT.values()), "Unexpected SELinux mode"
    assert (selinux_facts['selinux']['config_mode'] in SELINUX_MODE_DICT.values()), "Unexpected SELinux config_mode"
    assert (selinux_facts['selinux']['policyvers'] in ["unknown", 1, 2, 3, 31, 32]), "Unexpected SELinux policyvers"

# Generated at 2022-06-11 05:13:53.185963
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Test that collector is initialized properly
    selinux_fact_collector = SelinuxFactCollector()

    # Make sure correct name attribute is set
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:14:30.788303
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:14:32.439076
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_obj = SelinuxFactCollector()
    assert facts_obj.name == "selinux"

# Generated at 2022-06-11 05:14:41.770996
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import platform
    os_name = platform.system()

    SelinuxFactCollector_obj = SelinuxFactCollector()

    # Test the method collect of class SelinuxFactCollector
    # without parameter module and collected_facts
    facts_dict = SelinuxFactCollector_obj.collect()
    selinux_facts = facts_dict.get('selinux', dict())
    if os_name == 'Linux':
        assert (selinux_facts.get('status') in list(SELINUX_MODE_DICT.values()))
    elif os_name == 'Darwin':
        assert (selinux_facts.get('status') == 'disabled')

# Generated at 2022-06-11 05:14:43.749603
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-11 05:14:55.169697
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_dict = {}
    selinux_facts = {}

    # Set the fact_ids to test
    selinux_collected_facts = SelinuxFactCollector()
    selinux_collected_facts._fact_ids = set(['selinux', 'selinux_python_present'])

    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_facts
        facts_dict['selinux_python_present'] = False
    else:
        # Set the fact_ids to test
        selinux_collected_facts = SelinuxFactCollector()
        selinux_collected_facts._fact_ids = set(['selinux', 'selinux_python_present'])

        # Set a boolean

# Generated at 2022-06-11 05:14:58.659879
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert 'selinux_python_present' in result


# Generated at 2022-06-11 05:15:00.952282
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-11 05:15:10.153632
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # The class SelinuxFactCollector inherits from BaseFactCollector.
    # Since BaseFactCollector's constructor needs to call get_module_path,
    # '__module__' must be set to a dummy string
    SelinuxFactCollector.__module__ = 'dummy'
    test_fact = SelinuxFactCollector()

    # This method tests the functionality of collect in class SelinuxFactCollector
    # using the following test cases.
    # 1. Check for selinux_python_present and selinux['status'] when selinux library is not present.
    # 2. Check for selinux_python_present, selinux['status'] and selinux['type'] when selinux library is present.
    # 3. Check for selinux_python_present, selinux['status'], selinux['config_mode'],
    #

# Generated at 2022-06-11 05:15:16.792085
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    preboot = SelinuxFactCollector()
    assert preboot.name == 'selinux'

    # assert that all constants are present in the returned dictionary
    collected = preboot.collect()
    assert 'selinux' in collected.keys()
    assert 'status' in collected['selinux'].keys()
    assert 'python_present' in collected.keys()
    assert 'config_mode' in collected['selinux'].keys()
    assert 'mode' in collected['selinux'].keys()
    assert 'type' in collected['selinux'].keys()
    assert 'policyvers' in collected['selinux'].keys()

# Generated at 2022-06-11 05:15:20.591458
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    expected_facts_dict = {
        'selinux': {'status': 'disabled'},
        'selinux_python_present': True}

    # Mock the selinux library
    selinux.is_selinux_enabled = lambda: False

    collector = SelinuxFactCollector()
    facts_dict = collector.collect()

    assert facts_dict == expected_facts_dict

# Generated at 2022-06-11 05:16:53.510578
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts.collect()['selinux']['status'] == 'enabled'
    assert selinux_facts.collect()['selinux_python_present'] == True


# Generated at 2022-06-11 05:16:56.093802
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector(None)
    result = selinux_fact_collector.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-11 05:16:56.969231
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:16:59.642502
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:17:05.892903
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fac = SelinuxFactCollector()
    if not HAVE_SELINUX:
        facts_dict = selinux_fac.collect()
        assert not facts_dict['selinux']
    else:
        if selinux.is_selinux_enabled():
            facts_dict = selinux_fac.collect()
            assert facts_dict['selinux']
        else:
            facts_dict = selinux_fac.collect()
            assert not facts_dict['selinux']

# Generated at 2022-06-11 05:17:10.244420
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    SelinuxFactCollector.__bases__[0].collect = lambda *args, **kwargs: dict()
    x = SelinuxFactCollector()
    assert isinstance(x, BaseFactCollector)
    assert 'selinux' in x.name


# Generated at 2022-06-11 05:17:11.805902
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj.collect()

# Generated at 2022-06-11 05:17:17.219146
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()

    # Create a mock module to pass to class SelinuxFactCollector, so we
    # can test the return from class method collect
    module = 'ansible.module_utils.facts.collector.SelinuxFactCollector'

    result = selinux.collect(module)
    assert result is not None
    for key, value in result.items():
        assert key is not None
        assert value is not None

# Generated at 2022-06-11 05:17:24.828013
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    facts = selinux_collector.collect()
    if not HAVE_SELINUX:
        assert 'selinux' in facts
        assert 'status' in facts['selinux']
        assert 'Missing selinux Python library' == facts['selinux']['status']
    else:
        assert 'selinux' in facts
        assert 'config_mode' in facts['selinux']
        assert 'policyvers' in facts['selinux']
        assert 'mode' in facts['selinux']
        assert 'type' in facts['selinux']
        assert 'status' in facts['selinux']
        assert 'selinux_python_present' in facts

# Generated at 2022-06-11 05:17:28.504928
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    print('Testing SelinuxFactCollector')
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()