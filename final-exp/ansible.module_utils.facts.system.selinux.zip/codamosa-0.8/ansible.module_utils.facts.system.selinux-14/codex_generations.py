

# Generated at 2022-06-11 05:10:27.113706
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert set(obj.collect().keys()) == { 'selinux_python_present', 'selinux' }

# Generated at 2022-06-11 05:10:37.569487
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This unit test tests method collect of class SelinuxFactCollector.
    """

    # Mock variables
    # class_under_test is a SelinuxFactCollector object
    class_under_test = SelinuxFactCollector()
    # collected_facts is a dictionary
    collected_facts = {'selinux_python_present': False}

    # Mock selinux.is_selinux_enabled().
    # Algorithm
    # 1) Verify that selinux.is_selinux_enabled() == False
    # 2) Verify that class_under_test.collect() == 'disabled'
    with mock.patch("ansible.module_utils.compat.selinux.is_selinux_enabled") as mock_selinux_is_selinux_enabled:
        mock_selinux_is_

# Generated at 2022-06-11 05:10:38.237735
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:10:48.665811
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxfacts = SelinuxFactCollector()
    collected_facts = selinuxfacts.collect()
    assert len(collected_facts) == 2, 'Expected to collect 2 selinux facts but, collected %i' % len(collected_facts)
    assert type(collected_facts) is dict, 'Expected selinux facts to be dictionary but was %s' % type(collected_facts)
    assert type(collected_facts['selinux']) is dict, 'Expected selinux facts to be dictionary but was %s' % type(collected_facts['selinux'])
    assert collected_facts['selinux_python_present'] == True, 'Expected selinux_python_present to be True but was %s' % type(collected_facts['selinux_python_present'])

# Generated at 2022-06-11 05:10:49.324333
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-11 05:10:50.796479
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collect = SelinuxFactCollector()
    assert collect is not None

# Generated at 2022-06-11 05:10:52.630162
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-11 05:10:54.994116
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None

    sfc = SelinuxFactCollector()
    sfc.collect(module, collected_facts)

# Generated at 2022-06-11 05:10:55.901500
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:10:58.801454
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:11:11.082151
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # When in selinux mode, return an object with the assert methods
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()
    assert selinux.collect() == {
        'selinux': {'status': 'disabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'},
        'selinux_python_present': True
    }
    print("{}: unit test passed".format(__name__))

# Unit test when SELinux is not present

# Generated at 2022-06-11 05:11:18.300194
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Set up mock value for selinux_python_present
    selinux_python_present = True

    # Set up mock value for selinux.is_selinux_enabled
    selinux.is_selinux_enabled = mock.MagicMock()
    selinux.is_selinux_enabled.return_value = True

    # Set up mock value for selinux.security_getenforce
    selinux.security_getenforce = mock.MagicMock()
    selinux.security_getenforce.return_value = 0

    # Set up mock value for selinux.security_policyvers
    selinux.security_policyvers = mock.MagicMock()
    selinux.security_policyvers.return_value = '28'

    # Set up mock value for selinux.selinux_getenforcemode

# Generated at 2022-06-11 05:11:29.583161
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import tempfile
    import shutil
    import os
    import mock
    import platform

    try:
        import selinux
    except ImportError:
        selinux = None 
        return_val = 0
        return_data = [0]
        return_warning = "Missing selinux Python library"
    else:
        return_val = 1
        return_data = [('SELinux status', '(current mode: enforcing mode: disabled)')]
        return_warning = None


    test_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 05:11:31.429442
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Ensure the SelinuxFactCollector class can be instantiated."""
    SelinuxFactCollector()

# Generated at 2022-06-11 05:11:34.721022
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test whether the constructor works with no parameters
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert len(selinux_fact_collector._fact_ids) == 0

# Generated at 2022-06-11 05:11:39.241202
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Creation of a mock object for class AnsibleModule
    mock_AnsibleModule = MagicMock()
    # Creation of a mock object for class BaseFactCollector
    mock_BaseFactCollector = MagicMock()
    # Creation of an instance of class SelinuxFactCollector
    selinuxFactCollector = SelinuxFactCollector(mock_AnsibleModule)
    results = selinuxFactCollector.collect(mock_BaseFactCollector)
    # Check if it is an instance of dict
    assert isinstance(results, dict)
    # Check if there is a key 'selinux' inside results
    assert results.has_key('selinux')
    # Check if there is a key 'status' inside results['selinux']
    assert results['selinux'].has_key('status')
    # Check

# Generated at 2022-06-11 05:11:40.315783
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 05:11:47.856856
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Check if ansible.module_utils.compat.selinux is imported
    try:
        from ansible.module_utils.compat import selinux
    except ImportError:
        msg = "Failed to find selinux Python library"
        assert False, msg

    # Check if selinux library is loaded
    selinux_load_status = selinux.is_selinux_enabled()

    # Create SelinuxFactCollector object
    collector_obj = SelinuxFactCollector()

    # Check if selinux_python_present is True if selinux library is loaded and False if it is not loaded
    if selinux_load_status:
        collector_obj.collect()

# Generated at 2022-06-11 05:11:49.108467
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c != None


# Generated at 2022-06-11 05:11:51.543190
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids

# Generated at 2022-06-11 05:12:09.304728
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    collected_facts = fact_collector.collect()
    assert fact_collector.name == 'selinux'
    assert 'selinux' in collected_facts
    if HAVE_SELINUX:
        assert collected_facts['selinux']['status'] == 'enabled'
        assert collected_facts['selinux']['mode'] == 'enforcing'
        assert collected_facts['selinux']['policyvers'] == '31'
        assert collected_facts['selinux']['type'] == 'targeted'
    else:
        assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    assert collected_facts['selinux_python_present'] == HAVE_SELINUX

# Generated at 2022-06-11 05:12:15.761001
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {
        'config_mode': 'permissive',
        'mode': 'disabled',
        'policyvers': 'unknown',
        'status': 'disabled',
        'type': 'unknown'
    }

    collected_facts = {
        'selinux': selinux_facts,
        'selinux_python_present': True
    }

    # Test case: SELinux is disabled
    selinux = SelinuxFactCollector()
    assert selinux.collect() == collected_facts

# Generated at 2022-06-11 05:12:17.474655
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == "selinux"


# Generated at 2022-06-11 05:12:21.401077
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    my_module = None
    my_facts = None
    my_test_object = SelinuxFactCollector()
    test_output = my_test_object.collect(module=my_module, collected_facts=my_facts)
    assert test_output['selinux_python_present'] == True

# Generated at 2022-06-11 05:12:22.810750
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-11 05:12:25.782903
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # test without selinux module
    temporary_path = "/tmp/ansible_selinux_facts.py"

# Generated at 2022-06-11 05:12:29.847132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Unit test for the constructor of class SelinuxFactCollector
    """
    assert SelinuxFactCollector().name == 'selinux'
    assert SelinuxFactCollector()._fact_ids == set()
    assert isinstance(SelinuxFactCollector().collect(), type(dict()))

# Generated at 2022-06-11 05:12:32.041893
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()

    assert 'selinux' == collector.name
    assert set() == collector._fact_ids

# Generated at 2022-06-11 05:12:34.583693
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert isinstance(selinux_fact_collector._fact_ids, set)
    assert selinux_fact_collector.priority == 20

# Generated at 2022-06-11 05:12:35.938580
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-11 05:12:55.773646
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert selinuxFactCollector._fact_ids == set()


# Generated at 2022-06-11 05:12:57.673226
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    bfc = SelinuxFactCollector()
    assert bfc.name == 'selinux'

# Generated at 2022-06-11 05:13:08.152884
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import tempfile
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': []}
            self.check_mode = False
            self.debug = False
            self.facts_dict = {}
            self.exit_json = lambda a, b: sys.exit(0)

    class FakeArgv:
        def __init__(self):
            self.curr = 0

        def __getitem__(self, index):
            self.curr = index
            return ''

        def __str__(self):
            return ''
    sys.argv = FakeArgv()
    module = FakeModule()
    selinux_facts = SelinuxFactCollector().collect(module, module.facts_dict)

# Generated at 2022-06-11 05:13:10.679595
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:13:11.684353
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()

# Generated at 2022-06-11 05:13:20.281538
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    The SelinuxFactCollector shall return a dictionary with a key 'selinux' that
    contains a dictionary with the same keys as the function 'selinux_facts'
    returns in the file 'ansible.module_utils.facts.system.selinux'.
    """
    import unittest
    from ansible.module_utils.facts.collectors.system.selinux import SelinuxFactCollector

    def test_case_1(self):
        """
        This function mocks the function 'selinux.is_selinux_enabled' and
        always returns False.
        """
        return False

    def test_case_1(self):
        """
        This function mocks the function 'selinux.security_policyvers' and
        returns a String.
        """

# Generated at 2022-06-11 05:13:21.741168
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-11 05:13:23.821674
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test for instance of class
    x = SelinuxFactCollector()
    assert isinstance(x, SelinuxFactCollector)
    assert x.name == 'selinux'

# Generated at 2022-06-11 05:13:29.781211
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()

    collector = SelinuxFactCollector()

    # Create a dictionary of selinux facts and make sure collect method
    # returns that dictionary.
    selinux_facts = {
        'config_mode': 'disabled',
        'mode': 'unknown',
        'status': 'disabled',
        'type': 'unknown'
    }

    collector.selinux_facts = lambda: selinux_facts
    assert collector.collect(module) == {'selinux': selinux_facts, 'selinux_python_present': True}

# Generated at 2022-06-11 05:13:37.453753
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Tests for SelinuxFactCollector.collect
    '''
    #
    # This test ensures that facts for selinux are collected correctly
    # when SELinux is enabled and there is a selinux Python library present
    #
    selinux_enabled = True
    selinux_python_present = True

    collector = SelinuxFactCollector()

    #
    # mock out selinux library
    #
    class MockSelinux(object):
        def is_selinux_enabled(self):
            return selinux_enabled

        def security_policyvers(self):
            return '29'

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 1


# Generated at 2022-06-11 05:14:15.000244
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create a selinux_test class which just inherits from SelinuxFactCollector
    class selinux_test(SelinuxFactCollector):
        pass

    # Test if the name is correctly set
    obj = selinux_test()
    assert obj.name == 'selinux'


# Generated at 2022-06-11 05:14:16.561497
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mycol = SelinuxFactCollector()
    # Get all the facts
    mycol.collect()

# Generated at 2022-06-11 05:14:18.793011
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 05:14:19.779496
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-11 05:14:22.276574
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-11 05:14:25.506807
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Case 1: selinux library is not available
    assert(SelinuxFactCollector().collect({}) == {'selinux_python_present': False,
                                                  'selinux': {'status': 'Missing selinux Python library'}})

# Generated at 2022-06-11 05:14:29.490029
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux'] is not None

# Generated at 2022-06-11 05:14:32.662928
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:14:36.958360
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector.collect() == {
        'selinux': {},
        'selinux_python_present': False
    }

# Generated at 2022-06-11 05:14:39.819966
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Tests the constructor of class SelinuxFactCollector
    """

    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-11 05:16:11.715862
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-11 05:16:14.524206
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x.collect() == {'selinux_python_present': False, 'selinux': {'status': 'Missing selinux Python library'}}


# Generated at 2022-06-11 05:16:17.761924
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    assert collector.collect() == {
        'selinux': {'status': 'disabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'},
        'selinux_python_present': True
    }

# Generated at 2022-06-11 05:16:24.472782
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    result = selinux_collector.collect()
    assert result is not None
    assert 'selinux' in result
    assert result['selinux']['config_mode'] == 'unknown'
    assert result['selinux']['mode'] == 'disabled'
    assert result['selinux']['policyvers'] == 'unknown'
    assert result['selinux']['status'] == 'disabled'
    assert result['selinux']['type'] == 'unknown'
    assert result['selinux_python_present'] is True

# Generated at 2022-06-11 05:16:27.036725
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert len(collector.collect()) > 0
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-11 05:16:37.155971
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sfc = SelinuxFactCollector()
    ret = sfc.collect()
    assert 'selinux' in ret
    assert 'selinux_python_present' in ret
    if HAVE_SELINUX:
        assert ret['selinux_python_present']
    else:
        assert not ret['selinux_python_present']
    assert 'status' in ret['selinux']
    if HAVE_SELINUX:
        assert ret['selinux']['status'] in ('enabled', 'disabled')
    else:
        assert ret['selinux']['status'] == 'Missing selinux Python library'
    if HAVE_SELINUX and ret['selinux']['status'] == 'enabled':
        assert 'policyvers' in ret['selinux']
        assert 'config_mode'

# Generated at 2022-06-11 05:16:39.967011
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collect = SelinuxFactCollector().collect()
    assert type(collect) is dict
    assert collect['selinux_python_present'] is True
    assert type(collect['selinux']) is dict

# Generated at 2022-06-11 05:16:49.476673
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Import the class and method to be tested
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    # Declare test variables
    selinux_facts = {}
    facts_dict = {}

    if HAVE_SELINUX:
        # Declare test variables when the selinux library is present
        if selinux.is_selinux_enabled():
            try:
                selinux_facts['status'] = 'enabled'
            except AttributeError:
                selinux_facts['status'] = 'unknown'
            selinux_facts['status'] = 'enabled'


# Generated at 2022-06-11 05:16:58.769944
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = {}
    selinux_facts = {}
    fact_collector = SelinuxFactCollector()

    # Check that name is assigned.
    assert fact_collector.name == 'selinux'

    # Check that correct fact_ids are assigned.
    assert fact_collector._fact_ids == {'selinux'}

    # Check that collect function returns expected facts.
    facts_dict['selinux_python_present'] = True
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = '28'
    selinux_facts['config_mode'] = 'enforcing'
    selinux_facts['mode'] = 'enforcing'
    selinux_facts['type'] = 'targeted'

# Generated at 2022-06-11 05:17:06.516567
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()

    assert isinstance(facts_dict, dict)
    assert isinstance(facts_dict['selinux']['status'], str)
    assert isinstance(facts_dict['selinux']['policyvers'], str)
    assert isinstance(facts_dict['selinux']['config_mode'], str)
    assert isinstance(facts_dict['selinux']['mode'], str)
    assert isinstance(facts_dict['selinux']['type'], str)