

# Generated at 2022-06-11 05:10:25.209663
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # The selinux module uses a dict of dicts
    selinux_dict = dict()
    selinux_dict['status'] = 'enabled'
    selinux_dict['policyvers'] = '23'
    selinux_dict['config_mode'] = 'permissive'
    selinux_dict['mode'] = 'permissive'
    selinux_dict['type'] = 'targeted'

    expected_facts = dict()
    expected_facts['selinux_python_present'] = True
    expected_facts['selinux'] = selinux_dict

    assert SelinuxFactCollector().collect() == expected_facts


# Generated at 2022-06-11 05:10:28.315789
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create an object of type SelinuxFactCollector and ensure that name is set correctly.
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == "selinux"
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-11 05:10:30.498686
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:10:33.051952
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    a = SelinuxFactCollector()
    assert isinstance(a, BaseFactCollector)

# Generated at 2022-06-11 05:10:41.545586
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # The Windows/Cygwin builds have an issue in the python libraries that come packed with
    # Ansible, which makes this test fail.
    from sys import platform
    if platform == 'cygwin':
        return
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.selinux import SelinuxFactCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.collectors.selinux import HAVE_SELINUX, SELINUX_MODE_DICT
    # Test with HAVE_SELINUX set to True
    HAVE_SELINUX = True
    # Run the method collect of class SelinuxFactCollector

# Generated at 2022-06-11 05:10:42.996914
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-11 05:10:47.346257
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert type(selinux_collector._fact_ids) is set
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-11 05:10:57.541853
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import TestCollector

    # Store, reset, and then restore current_module
    current_module = sys.modules['ansible.module_utils.facts.collector.selinux']
    orig_HAVE_SELINUX = current_module.HAVE_SELINUX
    orig_selinux = current_module.selinux

    # Test 1: selinux library is not present
    current_module.HAVE_SELINUX = False
    facts = {}
    collector = SelinuxFactCollector()
    collected_facts = collector.collect(module=None, collected_facts=facts)
    assert collected_facts['selinux']['status'] == 'Missing selinux Python library'
    assert collected_facts['selinux_python_present']

# Generated at 2022-06-11 05:10:58.867803
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:11:01.425779
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert set(selinux_collector._fact_ids) == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-11 05:11:12.184100
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test when selinux Python library is not present, only status and selinux_python_present
    # facts should be present
    selinux_fact_collector = SelinuxFactCollector()
    ansible_facts = {}
    selinux_facts = selinux_fact_collector.collect(None, ansible_facts)
    assert selinux_facts == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-11 05:11:20.903980
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Create instance of class SelinuxFactCollector
    fact_collector = SelinuxFactCollector()
    collected_facts = {}
    facts_dict = fact_collector.collect(collected_facts = collected_facts)

    # Test is selinux_python_present is set to False
    if not HAVE_SELINUX:
        assert 'selinux_python_present' in facts_dict
        assert 'selinux' in facts_dict
        assert 'status' in facts_dict['selinux']
        assert facts_dict['selinux_python_present'] == False

    # Test if selinux dictionary is added to facts_dict
    else:
        assert 'selinux' in facts_dict
        assert 'status' in facts_dict['selinux']

        # Test if status is set to disabled

# Generated at 2022-06-11 05:11:23.189760
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert not obj._fact_ids

# Generated at 2022-06-11 05:11:25.375533
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux != None

# Generated at 2022-06-11 05:11:35.722746
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {}

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        selinux_facts['status'] = 'Missing selinux Python library'
        selinux_facts['selinux_python_present'] = False
        return selinux_facts

    # Set a boolean for testing whether the Python library is present
    selinux_facts['selinux_python_present'] = True

    if not selinux.is_selinux_enabled():
        selinux_facts['status'] = 'disabled'
    else:
        selinux_facts['status'] = 'enabled'


# Generated at 2022-06-11 05:11:38.944444
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert facts['selinux']['status'] == 'disabled'

# Generated at 2022-06-11 05:11:40.330671
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert(isinstance(SelinuxFactCollector(), SelinuxFactCollector))

# Generated at 2022-06-11 05:11:44.522828
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initializing the class with the same parameters as in __init__()
    selinux_fact_collector = SelinuxFactCollector()

    # The assertEqual() method checks if two values are equal and raises an
    # AssertionError if they are not.
    # The assertIsNotNone() just checks if the given value is none.
    assert selinux_fact_collector.collect() is not None

# Generated at 2022-06-11 05:11:46.484107
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == "selinux"
    assert obj._fact_ids == set()

# Generated at 2022-06-11 05:11:49.233900
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert isinstance(c, BaseFactCollector)
    assert c.name == 'selinux'
    assert c._fact_ids == set()


# Generated at 2022-06-11 05:12:02.319066
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()
    assert fact_collector.collect() == {'selinux_python_present': True,
                                        'selinux': {'status': 'Missing selinux Python library'}}



# Generated at 2022-06-11 05:12:05.787896
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-11 05:12:15.219086
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Arrange
    HAVE_SELINUX = True  # This is set to True when selinux library is present
    selinux_facts = {}  # Initialize the selinux facts
    selinux_facts['status'] = 'enabled'  # Set status as enabled
    selinux_facts['policyvers'] = '28'  # Set policy version as 28
    selinux_facts['config_mode'] = 'enforcing'  # Set config mode as enforcing
    selinux_facts['mode'] = 'enforcing'  # Set mode as enforcing
    selinux_facts['type'] = 'targeted'  # Policy type as targeted

    # Act
    selinux_facts_actual = SelinuxFactCollector.collect()  # Get the actual selinux facts

    # Assert
    assert selinux_facts_actual == selinux_facts  # Check if

# Generated at 2022-06-11 05:12:17.344555
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-11 05:12:27.028884
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    def mock_collect(module=None, collected_facts=None):
        if not HAVE_SELINUX:
            return {u'selinux_python_present': False,
                    u'selinux': {u'status': u'Missing selinux Python library'}}

        return {u'selinux': {u'config_mode': u'unknown',
                             u'policyvers': u'unknown',
                             u'type': u'unknown',
                             u'status': u'enabled',
                             u'mode': u'unknown'},
                u'selinux_python_present': True}

    selinux_facts_collector = SelinuxFactCollector()
    selinux_facts_collector.collect = mock_collect

# Generated at 2022-06-11 05:12:30.026288
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:12:39.435991
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    sys.modules['selinux'] = __import__('ansible.module_utils.facts.selinux.mock_selinux')
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert facts['selinux'] == {
        'status': 'enabled',
        'policyvers': '1',
        'config_mode': 'enforcing',
        'mode': 'enforcing',
        'type': 'targeted'
    }
    assert facts['selinux_python_present'] == True
    del sys.modules['selinux']
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert facts['selinux'] == {'status': 'Missing selinux Python library'}

# Generated at 2022-06-11 05:12:46.628386
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    myselinux = SelinuxFactCollector()
    # Test if size of all facts is as expected
    assert len(myselinux.collect()) == 2
    # Test if the fact 'selinux_python_present' is as expected
    assert len(myselinux.collect().get('selinux_python_present')) == 1
    # Test if the fact 'selinux' is as expected
    assert len(myselinux.collect().get('selinux')) == 5

# Generated at 2022-06-11 05:12:50.110124
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    results = fact_collector.collect()
    assert results['selinux']['status'] == 'disabled'
    assert results['selinux_python_present'] == True

# Generated at 2022-06-11 05:12:51.348596
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 05:13:12.461493
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()

    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-11 05:13:13.549548
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:13:19.592224
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {}

    if HAVE_SELINUX:
        selinux_facts = {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'status': 'enabled',
            'type': 'unknown'
        }
    else:
        selinux_facts = {
            'status': 'Missing selinux Python library'
        }

    selinux_collector = SelinuxFactCollector()
    response = selinux_collector.collect()

    assert response['selinux'] == selinux_facts

# Generated at 2022-06-11 05:13:20.692466
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-11 05:13:24.013221
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    gfc = SelinuxFactCollector()
    facts_dict = gfc.collect()
    assert facts_dict['selinux']['status'] == 'enabled'
    assert facts_dict['selinux']['type'] == 'unknown'
    assert facts_dict['selinux_python_present'] == True

# Generated at 2022-06-11 05:13:29.641508
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()

    # Check we have the keys we expect
    assert 'selinux' in result
    assert 'config_mode' in result['selinux']
    assert 'mode' in result['selinux']
    assert 'type' in result['selinux']
    assert 'status' in result['selinux']
    assert 'policyvers' in result['selinux']
    assert 'selinux_python_present' in result

# Generated at 2022-06-11 05:13:37.305396
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SELINUX_FACTS = dict(selinux={'status': 'enabled',
                                  'config_mode': 'unknown',
                                  'mode': 'unknown',
                                  'type': 'unknown',
                                  'policyvers': 'unknown'
                                  },
                         selinux_python_present=True
                         )

    class ModuleFake(object):
        pass
    module = ModuleFake()

    def selinux_is_selinux_enabled_fake(self):
        return True

    def selinux_security_policyvers_fake(self):
        return 'unknown'

    def selinux_selinux_getenforcemode_fake(self):
        return (0, 'unknown')

    def selinux_security_getenforce_fake(self):
        return 'unknown'


# Generated at 2022-06-11 05:13:39.033039
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids is not None

# Generated at 2022-06-11 05:13:40.566333
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-11 05:13:41.682839
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj is not None

# Generated at 2022-06-11 05:14:27.422811
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    def fake_HAVE_SELINUX():
        return True

    def fake_selinux_is_selinux_enabled():
        return True

    def fake_security_policyvers():
        return 19

    def fake_selinux_getenforcemode():
        return 0, 1

    def fake_security_getenforce():
        return 0

    def fake_selinux_getpolicytype():
        return 0, 'targeted'

    test_collector = SelinuxFactCollector()

    # Selinux libraries do not exist
    if HAVE_SELINUX:
        # Force python-selinux to be unavailable.
        setattr(SelinuxFactCollector, "HAVE_SELINUX", fake_HAVE_SELINUX)

# Generated at 2022-06-11 05:14:38.005293
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        try:
            import selinux
            #raise Exception('Should have failed to import selinux')
        except:
            pass
        else:
            raise Exception('Should have failed to import selinux')
        # Assume SELinux is disabled if it isn't installed
        facts = SelinuxFactCollector.collect()
        assert facts['selinux']['status'] == 'disabled', 'Status should be disabled'
        assert facts['selinux']['python_present'] == False, 'Python present should be false'
        return
    # SELinux is installed, so assume

# Generated at 2022-06-11 05:14:46.864076
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import types

    module = types.ModuleType('fake_module')
    module.selinux_python_present = True
    module.selinux = {
        "status": "enabled",
        "config_mode": "unknown",
        "type": "unknown",
        "mode": "unknown",
        "policyvers": "unknown"
    }
    collector = SelinuxFactCollector()
    facts_dict = collector.collect(module, None)
    assert facts_dict == {
        'selinux': {
            "status": "enabled",
            "config_mode": "unknown",
            "type": "unknown",
            "mode": "unknown",
            "policyvers": "unknown"
        },
        'selinux_python_present': True
    }

    module.selinux_python

# Generated at 2022-06-11 05:14:50.643459
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    assert selinux_fact_collector_obj.name == 'selinux'
    assert not selinux_fact_collector_obj._fact_ids

# Generated at 2022-06-11 05:14:51.985002
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-11 05:14:55.432965
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector.collect.__name__ == 'collect'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-11 05:14:59.357605
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'
    assert fc.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }


# Generated at 2022-06-11 05:15:00.236520
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:15:05.561611
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector class
    selinux_fact_collector = SelinuxFactCollector()
    # Create a set for selinux_fact_collector._fact_ids
    selinux_fact_collector._fact_ids = set()
    # Run the collect method of the SelinuxFactCollector
    facts = selinux_fact_collector.collect()
    # Check that the facts set is not empty
    assert facts

# Generated at 2022-06-11 05:15:06.427184
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:16:46.861568
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    This test case checks two scenarios:
    1. selinux library not present (HAVE_SELINUX = False)
    2. selinux library present (HAVE_SELINUX = True)
    """
    instance = SelinuxFactCollector()

    # selinux library is not present and selinux_python_present is set to False
    # since the selinux library could not be imported
    selinux_dict = instance.collect()
    assert selinux_dict['selinux_python_present'] == False

    # Restore selinux library's import
    instance.HAVE_SELINUX = True

    # selinux library is present
    selinux_dict = instance.collect()
    assert selinux_dict['selinux_python_present'] == True

# Generated at 2022-06-11 05:16:56.711534
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system

    facts_dict = {}
    selinux_collector = SelinuxFactCollector()
    # If the selinux Python library is not available,
    # set selinux_python_present to False and return
    if not HAVE_SELINUX:
        selinux_info = {}
        selinux_info['status'] = 'Missing selinux Python library'
        facts_dict['selinux'] = selinux_info
        facts_dict['selinux_python_present'] = False
        return facts_dict

    # If the Python library is available, test if SELinux is enabled
    if selinux.is_selinux_enabled():
        selinux_info = {}

# Generated at 2022-06-11 05:16:58.051852
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert len(fact_collector._fact_ids) == 0

# Generated at 2022-06-11 05:16:59.467636
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-11 05:17:08.761717
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import os
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    os.environ['SELINUX_INIT'] = '1'
    module = {}
    fact_collector = SelinuxFactCollector(module=module, collected_facts={})
    facts = fact_collector.collect(module, {})
    assert 'selinux' in facts, "selinux key not in facts"
    assert 'selinux_python_present' in facts, "selinux_python_present key not in facts"
    assert 'status' in facts['selinux'], "status key not in selinux facts"

# Generated at 2022-06-11 05:17:11.080955
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    os_selinux_facts = SelinuxFactCollector()
    assert os_selinux_facts.name == 'selinux'


# Generated at 2022-06-11 05:17:11.925679
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect()

# Generated at 2022-06-11 05:17:15.106289
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    obj = SelinuxFactCollector()

    assert obj is not None
    assert obj.name == 'selinux'
    assert obj._fact_ids == {'selinux', 'selinux_python_present'}


# Generated at 2022-06-11 05:17:16.925177
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts_collector_instance = SelinuxFactCollector()
    assert selinux_facts_collector_instance is not None

# Generated at 2022-06-11 05:17:18.981007
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_dict = dict()
    test_obj = SelinuxFactCollector()
    test_dict = test_obj.collect()
    assert test_dict is not None