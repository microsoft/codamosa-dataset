

# Generated at 2022-06-11 05:10:34.373148
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an object of class SelinuxFactCollector
    sfc = SelinuxFactCollector()

    # Let's test the cases where the selinux library is not installed and the system
    # does not have SELinux enabled and the cases where the selinux library is installed
    # and SELinux is enabled and disabled.

# Generated at 2022-06-11 05:10:38.942821
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module_mock = {
        'HAVE_SELINUX': HAVE_SELINUX,
        'selinux': selinux,
    }

    obj = SelinuxFactCollector(module=module_mock)
    assert obj.name == 'selinux'
    assert not obj._fact_ids
    assert obj.collect()


# Generated at 2022-06-11 05:10:40.594085
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux.is_selinux_enabled() != 0, "SELinux is not enabled on this system"

# Generated at 2022-06-11 05:10:45.320598
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import mock

    module = mock.Mock()

    collect_result = SelinuxFactCollector().collect(module=mock.Mock())
    module.warn.assert_called()
    collect_result['selinux']['status'] == 'Missing selinux Python library'
    collect_result['selinux_python_present'] == False

# Generated at 2022-06-11 05:10:47.173972
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-11 05:10:57.461102
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxCollector = SelinuxFactCollector()
    selinuxDict = selinuxCollector.collect()
    assert 'selinux' in selinuxDict
    assert isinstance(selinuxDict.get('selinux'), dict)
    if 'selinux_python_present' in selinuxDict:
        assert isinstance(selinuxDict.get('selinux_python_present'), bool)
    if 'status' in selinuxDict.get('selinux'):
        assert isinstance(selinuxDict.get('selinux').get('status'), str)
        assert selinuxDict.get('selinux').get('status') in ['enabled', 'disabled', 'Missing selinux Python library']

# Generated at 2022-06-11 05:10:58.567571
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector != None

# Generated at 2022-06-11 05:11:01.557754
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test object instantiation
    m = SelinuxFactCollector()

    # Test method collect
    ansible_facts = {}
    m.collect(collected_facts=ansible_facts)
    selinux = ansible_facts['selinux']
    assert 'config_mode' in selinux
    assert 'mode' in selinux
    assert 'policyvers' in selinux
    assert 'type' in selinux

# Generated at 2022-06-11 05:11:11.724427
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    m = AnsibleModule()
    s = SelinuxFactCollector()

# Generated at 2022-06-11 05:11:13.458449
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    assert(selinux_fact.name == "selinux")
    assert(selinux_fact._fact_ids == set())

# Generated at 2022-06-11 05:11:27.748099
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test collect() method of class SelinuxFactCollector.
    """
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'selinux' in facts
    assert 'policyvers' in facts['selinux']
    assert 'type' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'status' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'selinux_python_present' in facts

# Generated at 2022-06-11 05:11:29.098607
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert (isinstance(SelinuxFactCollector(), SelinuxFactCollector))

# Generated at 2022-06-11 05:11:30.960210
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-11 05:11:41.150791
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Unit test for method collect of class SelinuxFactCollector
    """
    # In the fixture selinux_python_present is set to True
    # In this test the method is_selinux_enabled is stubbed
    # to return True so we can test that all the facts are
    # returned.


# Generated at 2022-06-11 05:11:43.471186
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    SelinuxFactCollector - constructor test
    """
    fcol = SelinuxFactCollector()
    assert isinstance(fcol, BaseFactCollector)
    assert fcol.name == 'selinux'

# Generated at 2022-06-11 05:11:49.816770
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector_obj = SelinuxFactCollector()
    module = AnsibleModule(argument_spec=dict())
    collected_facts = dict()
    result = SelinuxFactCollector_obj.collect(module=module, collected_facts=collected_facts)
    assert type(result) == dict
    assert 'selinux_python_present' in result
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert  result['selinux']['status'] in ('enabled', 'disabled', 'Missing selinux Python library')

# Generated at 2022-06-11 05:11:58.749777
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Initialize test values

    # Initialize class object
    obj_test = SelinuxFactCollector()

    # Initialize mock answers
    dict_test_params = {'selinux': {'policyvers': '28', 'type': 'targeted', 'mode': 'enforcing', 'config_mode': 'enforcing', 'status': 'enabled'}, 'selinux_python_present': True}

    # Initialize mock values
    dict_test_selinux_facts = {'config_mode': 'enforcing', 'status': 'enabled', 'mode': 'enforcing', 'policyvers': '28', 'type': 'targeted'}
    dict_test_facts_dict = {'selinux_python_present': True, 'selinux': dict_test_selinux_facts}

    # Set mock answers
    Sel

# Generated at 2022-06-11 05:12:07.764981
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}

    class MockSelinux(object):
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return "abc"

        @staticmethod
        def selinux_getenforcemode():
            return (0, 1)

        @staticmethod
        def security_getenforce():
            return -1

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'abc')


    def mock_import(name, *args):
        if name == 'selinux':
            return MockSelinux
        else:
            return __import__(name, *args)

    module = AnsibleModule()
    selinux_

# Generated at 2022-06-11 05:12:08.609836
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:12:18.403670
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Define some testfixtures
    test_collector = SelinuxFactCollector()
    test_collector._module = mock.MagicMock()

    test_result_dict_for_selinux_disabled = {'selinux': {'status': 'disabled'}, 'selinux_python_present': True}
    test_result_dict_for_selinux_enabled = {'selinux': {'status': 'enabled',
                                                        'type': 'targeted',
                                                        'policyvers': '28',
                                                        'config_mode': 'permissive',
                                                        'mode': 'permissive'},
                                            'selinux_python_present': True}

# Generated at 2022-06-11 05:12:37.479800
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # initialize the SelinuxFactCollector class
    c = SelinuxFactCollector()

    # run the collect method and get the facts
    facts = c.collect()

    # check the facts
    assert type(facts) == dict, 'expecting a dictionary'
    assert "selinux" in facts.keys(), 'expecting a key "selinux" in the dictionary'
    assert "selinux_python_present" in facts.keys(), 'expecting a key "selinux_python_present" in the dictionary'
    assert "status" in facts['selinux'].keys(), 'expecting a key "status" in the dictionary selinux'

# Generated at 2022-06-11 05:12:48.204009
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Setup a selinux module and fact module
    selinux_module = None
    fact_module = {'selinux': None,'selinux_python_present': None}

    # Create and initialize a SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Collect facts for selinux and check if selinux_python_present is set to
    # False when the selinux library is not available.
    selinux_fact_collector.collect(selinux_module, fact_module)
    if not HAVE_SELINUX:
        assert fact_module['selinux_python_present'] == False
        return

    # Collect facts for selinux and check if selinux_python_present is set to
    # True when the selinux library is available.
    selinux_fact_collector

# Generated at 2022-06-11 05:12:57.375936
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_facts = {'config_mode': 'unknown',
                     'mode': 'unknown',
                     'status': 'disabled',
                     'type': 'unknown'}

    sfc = SelinuxFactCollector()

    # set up mock selinux module
    module_mock = MagicMock()
    module_mock.fail_json.return_value = None
    selinux_mock = MagicMock()

    # set up mock imported modules
    imp = mock_module(path=['ansible.module_utils.facts.collector', 'ansible.module_utils.facts.collector.ansible_selinux'])
    imp.return_value = selinux_mock

    # calling collect should populate 'selinux' field with mock values
    result = sfc.collect(module=module_mock)
   

# Generated at 2022-06-11 05:12:59.710538
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''True if the class SelinuxFactCollector is constructed.'''
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc

# Generated at 2022-06-11 05:13:04.234117
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert isinstance(selinux_fact_collector._fact_ids, set)
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:13:05.535893
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector is not None

# Generated at 2022-06-11 05:13:06.469957
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:13:09.898439
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    '''Unit test for constructor of class SelinuxFactCollector'''
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:13:13.185865
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxobj = SelinuxFactCollector()
    assert 'selinux' == selinuxobj.name

    expected_fact_ids = set()
    assert expected_fact_ids == selinuxobj._fact_ids

# Generated at 2022-06-11 05:13:15.644307
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    assert hasattr(SelinuxFactCollector, 'collect')

# Generated at 2022-06-11 05:13:39.605102
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()

    assert x.name == 'selinux'
    assert sorted(x._fact_ids) == [
        'selinux',
        'selinux_python_present'
    ]

# Generated at 2022-06-11 05:13:42.166589
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test that constructor instantiates object of class SelinuxFactCollector without any errors
    selinux_collector = SelinuxFactCollector()
    assert isinstance(selinux_collector, SelinuxFactCollector)


# Generated at 2022-06-11 05:13:48.040752
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()

    # There should be 2 facts, one for the library being present, and the other for
    # the rest of the selinux facts
    assert len(facts) == 2
    assert isinstance(facts, dict)
    assert 'selinux' in facts
    assert 'selinux_python_present' in facts
    assert facts['selinux_python_present'] is True
    assert isinstance(facts['selinux'], dict)

# Generated at 2022-06-11 05:13:50.026383
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()



# Generated at 2022-06-11 05:13:51.379560
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect(module=None, collected_facts=None)

# Generated at 2022-06-11 05:13:53.957858
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    """
    :avocado: tags=unit
    """
    selinuxFactCollector = SelinuxFactCollector()

    assert selinuxFactCollector


# Generated at 2022-06-11 05:13:54.861523
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:13:57.519552
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    print('Testing constructor of SelinuxFactCollector')
    obj = SelinuxFactCollector()
    assert obj is not None, 'Failed to create SelinuxFactCollector object'


# Generated at 2022-06-11 05:13:58.922940
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x is not None


# Generated at 2022-06-11 05:14:00.290748
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect(collected_facts={})

# Generated at 2022-06-11 05:14:44.252548
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_collector = SelinuxFactCollector()

    # Test when selinux library is missing
    facts_dict = facts_collector.collect()
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict['selinux_python_present'] == False

    # Test when selinux library is present but selinux is not enabled on the system
    facts_dict = facts_collector.collect()
    assert facts_dict['selinux']['status'] == 'disabled'
    assert facts_dict['selinux_python_present'] == True


# Generated at 2022-06-11 05:14:55.388273
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    # For each collector, create a new one and run its collect method to get facts dict
    # and assert if the returned dict has the expected keys in it.
    for name in FactCollector._collectors:
        collector = get_collector_instance(name)
        facts_dict = collector.collect()
        if name == 'selinux':
            assert isinstance(facts_dict, dict)
            assert 'selinux' in facts_dict
            assert isinstance(facts_dict['selinux'], dict)
            for key in ('mode', 'policyvers', 'config_mode', 'status', 'type'):
                assert key in facts_dict['selinux']

# Generated at 2022-06-11 05:14:59.996221
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    # Get an instance of the SelinuxFactCollector class
    fact_collector = get_collector_instance(SelinuxFactCollector)

    # Collect facts and make sure selinux attribute is present
    facts = fact_collector.collect(None, None)
    assert facts['selinux']

# Generated at 2022-06-11 05:15:01.523374
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'

# Generated at 2022-06-11 05:15:04.413820
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'
    assert isinstance(sfc._fact_ids, set)
    assert sfc.collect() == {}


# Generated at 2022-06-11 05:15:13.216975
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Unit tests require the testing framework to be installed.
    try:
        from test.support import EnvironmentVarGuard
        from ansible.module_utils.six import PY3
    except ImportError:
        raise

    collector = SelinuxFactCollector()
    facts_dict = {}
    collected_facts = {}

    # Calling the collect method without setting the module should set the
    # status and selinux_python_present facts.  If the selinux Python library
    # is installed, the status will be set to enabled, otherwise it will be
    # set to disabled.
    facts_dict = collector.collect()

    if HAVE_SELINUX:
        assert facts_dict['selinux']['status'] == 'enabled'

# Generated at 2022-06-11 05:15:19.959080
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''Test the collect method of class SelinuxFactCollector'''
    fake_module = object()
    fake_collected_facts = object()
    fake_selinux_library_present = True
    fake_apply_selinux_enforcemode = False

    # make a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # test when there is no selinux library
    selinux_fact_collector.collect(fake_module, fake_collected_facts)

    # test when there is selinux library
    selinux_fact_collector.collect(fake_module, fake_collected_facts)

# Generated at 2022-06-11 05:15:25.140069
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None
    s = SelinuxFactCollector()
    facts = s.collect(module, collected_facts)
    assert isinstance(facts, dict)
    assert 'selinux' in facts
    assert 'policyvers' in facts['selinux']
    assert 'config_mode' in facts['selinux']
    assert 'status' in facts['selinux']
    assert 'mode' in facts['selinux']
    assert 'type' in facts['selinux']

if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-11 05:15:31.258371
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # We instantiate the Collector with a mocked version of module
    selinux_facts = SelinuxFactCollector({})
    # Set a mocked response for the selinux python library
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: 1
    selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux.selinux_getpolicytype = lambda: (0, "targeted")
    selinux.security_getenforce = lambda: 0

    # We collect the facts
    collect_facts = selinux_facts.collect()

    # We check the result
    assert collect_facts['selinux']['status'] == 'enabled'
    assert collect_facts['selinux']['policyvers'] == 1

# Generated at 2022-06-11 05:15:32.781899
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-11 05:17:03.870081
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test SelinuxFactCollector constructor"""
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-11 05:17:09.188807
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    f = SelinuxFactCollector()
    facts = f.collect()
    assert 'selinux' in facts
    assert 'policyvers' in facts[u'selinux']
    assert 'config_mode' in facts[u'selinux']
    assert 'mode' in facts[u'selinux']
    assert 'type' in facts[u'selinux']
    assert 'status' in facts[u'selinux']
    assert 'selinux_python_present' in facts

# Generated at 2022-06-11 05:17:14.788269
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Test the constructor of the class
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert len(obj._fact_ids) == 3
    assert isinstance(obj._fact_ids, frozenset)
    assert 'selinux' in obj._fact_ids
    assert 'selinux_python_present' in obj._fact_ids
    assert 'selinux_status' in obj._fact_ids


# Generated at 2022-06-11 05:17:17.220079
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:17:19.286666
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-11 05:17:20.197162
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:17:23.395048
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.selinux import is_selinux_enabled
    from ansible.module_utils.facts.collector import Collector
    SelinuxFactCollector()
    assert Collector.get_collector('selinux') == SelinuxFactCollector

# Generated at 2022-06-11 05:17:30.436494
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert 'mode' in selinux_fact_collector._fact_ids
    assert 'status' in selinux_fact_collector._fact_ids
    assert 'selinux_python_present' in selinux_fact_collector._fact_ids
    assert 'config_mode' in selinux_fact_collector._fact_ids
    assert 'policyvers' in selinux_fact_collector._fact_ids
    assert 'type' in selinux_fact_collector._fact_ids

# Generated at 2022-06-11 05:17:31.204848
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()

# Generated at 2022-06-11 05:17:32.789474
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()