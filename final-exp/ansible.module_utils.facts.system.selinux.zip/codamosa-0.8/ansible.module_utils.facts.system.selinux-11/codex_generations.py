

# Generated at 2022-06-11 05:10:24.022337
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Test construction of SelinuxFactCollector class
    selinux_collector = SelinuxFactCollector()

    # Assert that name of the collector is selinux.
    assert selinux_collector.name == 'selinux'
    assert selinux_collector.priority == 50
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-11 05:10:34.175764
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module_utils_helper = Mock()
    mock_module = Mock(
        params=dict(),
        module_args='',
    )
    mock_module_helper = Mock()

    mock_env = Mock()
    mock_env.get_module_utils.return_value = mock_module_utils_helper
    mock_env.get_module.return_value = mock_module
    mock_env.get_module_helper.return_value = mock_module_helper

    mock_module_utils_helper.get_platform_subclass.return_value = None

    collected_facts = dict()

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    x = SelinuxFactCollector(module)

    # Selinux is

# Generated at 2022-06-11 05:10:37.049432
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # Checks whether SelinuxFactCollector inherits class BaseFactCollector
    assert isinstance(selinux_fact_collector, BaseFactCollector)

# Generated at 2022-06-11 05:10:40.445363
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert 'selinux' in selinux_fact_collector._fact_ids
    assert 'selinux_python_present' in selinux_fact_collector._fact_ids

# Generated at 2022-06-11 05:10:43.463473
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:10:49.981883
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None
    selinuxFactCollector = SelinuxFactCollector()
    testFacts = {'selinux': {'type': 'targeted', 'mode': 'enforcing', 'status': 'enabled', 'policyvers': '28'},
                 'selinux_python_present': True}
    facts = selinuxFactCollector.collect(module, collected_facts)
    assert facts == testFacts

# Generated at 2022-06-11 05:10:56.593972
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux = SelinuxFactCollector()
    facts_dict = selinux.collect()
    assert facts_dict['selinux']['config_mode'] == 'unknown'
    assert facts_dict['selinux']['mode'] == 'unknown'
    assert facts_dict['selinux']['policyvers'] == 'unknown'
    assert facts_dict['selinux']['status'] == 'disabled'
    assert facts_dict['selinux']['type'] == 'unknown'

# Generated at 2022-06-11 05:11:02.150134
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect
    """
    import sys
    import platform

    # skip test if the system does not have selinux
    if sys.platform.lower() not in ('linux', 'darwin'):
        return

    # Save platform.system
    old_platform_system = platform.system
    platform.system = lambda: 'Linux'

    # create a test class
    class SelinuxTest(SelinuxFactCollector):
        """
        Test class for SelinuxFactCollector.collect
        """
        def __init__(self):
            self.name = 'selinux'
            self.selinux_getpolicytype_error = False
            self.selinux_getenforcemode_error = False
            self.security_getenforce_error = False
            self.security_

# Generated at 2022-06-11 05:11:03.904462
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-11 05:11:10.863300
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # testcase 1: selinux not found, selinux_facts should return Missing selinux Python library
    module = None
    collected_facts = None
    HAVE_SELINUX = False
    _fact_ids = set()
    selinux_facts = {}

    # Set a boolean for testing whether the Python library is present
    selinux_facts['selinux_python_present'] = False

    selinux_facts['status'] = 'Missing selinux Python library'

    assert(SelinuxFactCollector().collect(module, collected_facts) == selinux_facts)

# Generated at 2022-06-11 05:11:29.010891
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import tempfile

    sys.path.insert(0, tempfile.mkdtemp())

    try:
        from ansible.module_utils.test.test_selinux import TestSELinux
        from ansible.module_utils import facts

        test = TestSELinux()
        selinuxfacts = SelinuxFactCollector()
        selinuxfacts._module = test
        selinuxfacts._collect_platform_subset = ['']
        selinuxfacts._validate_platform_subset = ['']
        selinuxfacts.collect()
    finally:
        sys.path = sys.path[1:]

# Generated at 2022-06-11 05:11:30.466767
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-11 05:11:33.782513
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:11:43.416112
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''selinux_python_present is always a boolean'''
    fact_collector = SelinuxFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts['selinux_python_present'], bool)

    # When selinux is missing, return its status and
    # selinux_python_present as False.
    if HAVE_SELINUX:
        assert 'selinux' in facts
        assert facts['selinux']['status'] != 'Missing selinux Python library'
        assert facts['selinux']['policyvers'] != 'unknown'
        assert facts['selinux']['config_mode'] != 'unknown'
        assert facts['selinux']['mode'] != 'unknown'
        assert facts['selinux']['type'] != 'unknown'
   

# Generated at 2022-06-11 05:11:46.186348
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sfc = SelinuxFactCollector()
    facts = sfc.collect()
    assert facts['selinux']['status'] == 'Missing selinux Python library'
    assert facts['selinux_python_present'] == False

# Generated at 2022-06-11 05:11:47.110144
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x

# Generated at 2022-06-11 05:11:56.283973
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible.module_utils.facts import FactCollector

    # Create a new instance of the SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()
    # Invoke the collect method
    selinux_collector.collect()
    # Check the contents of the collected facts
    assert selinux_collector.collect() == {}

    set_module_args({
        'ANSIBLE_FACTS_CACHE': '/tmp/ansible_fact_cache.yml'
    })
    # Create a new instance of the FactCollector and invoke the collect method on SelinuxFactCollector
    fact_collector = FactCollector(module=None, collected_facts=None)
    selinux

# Generated at 2022-06-11 05:12:05.173683
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = None
    collected_facts = None

    # When selinux module is not present
    SelinuxFactCollector.HAVE_SELINUX = False

    collector = SelinuxFactCollector()
    fact_keys = []
    fact_values = []
    fact_dict = collector.collect(module, collected_facts)
    for k, v in fact_dict.items():
        fact_keys.append(k)

        if k == 'selinux':
            for selinux_k, selinux_v in v.items():
                fact_keys.append(selinux_k)
                fact_values.append(selinux_v)
        else:
            fact_values.append(v)

    assert 'selinux_python_present' in fact_keys and len(fact_keys) == 2
   

# Generated at 2022-06-11 05:12:06.330169
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-11 05:12:15.508973
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = object()
    mock_collected_facts = object()
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect(module=mock_module, collected_facts=mock_collected_facts)

    assert facts_dict == {
        'selinux': {
            'config_mode': 'disabled',
            'status': 'disabled',
            'type': 'targeted'
        },
        'selinux_python_present': True
    }
    assert facts_dict['selinux']['status'] == 'disabled'
    assert (facts_dict['selinux']['type'] == 'targeted' or facts_dict['selinux']['type'] == 'minimum')

# Generated at 2022-06-11 05:12:33.862556
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    cf = SelinuxFactCollector()

    # Check if name attribute exists and has the correct value.
    assert cf.name == 'selinux'

# Generated at 2022-06-11 05:12:36.678007
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    name = obj.name
    _fact_ids = obj._fact_ids
    assert name == 'selinux'
    assert not _fact_ids


# Generated at 2022-06-11 05:12:38.872189
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert 'selinux' in obj._fact_ids

# Generated at 2022-06-11 05:12:40.618429
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc.name == "selinux"

# Generated at 2022-06-11 05:12:45.764949
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_name
    coll = Collector()
    coll.collect_fact(SelinuxFactCollector())
    name = get_collector_name('selinux')
    assert coll.get_fact(name) is not None

# Generated at 2022-06-11 05:12:50.065693
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_FactCollector = SelinuxFactCollector()
    name = 'selinux'
    collected_facts = None
    collected_facts = selinux_FactCollector.collect(collected_facts)

    assert(collected_facts['selinux']['status'] == 'enabled')

# Generated at 2022-06-11 05:12:56.016682
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import get_collector_facts
    # Populate the FactsCollector with the facts we'll need to test
    facts_collector = FactsCollector(
        gather_subset=[],
        gather_timeout=10,
        exclude_fact_ids=[],
        fact_paths=[],
        module='',
        runner_facts=get_collector_facts()
    )
    # Make sure the SelinuxFactCollector is present
    assert 'selinux' in facts_collector.collector_array
    # Populate the facts_dict with the facts from SelinuxFactCollector
    facts_dict = {}
    SelinuxFactCollector().populate_fact_dict(facts_dict)
    # Now

# Generated at 2022-06-11 05:12:58.331584
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 05:13:03.342001
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of SelinuxFactCollector class
    collector = SelinuxFactCollector()

    # Collect facts
    res = collector.collect()

    # Assert result is a dictionary
    assert (isinstance(res, dict))

    # Ensure that literal key selinux is in fact dictionary
    assert ('selinux' in res)

# Generated at 2022-06-11 05:13:05.867129
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()

    assert selinux.name == "selinux"
    assert selinux._fact_ids == set()



# Generated at 2022-06-11 05:13:48.941277
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert 'selinux' in selinux_collector.collect()

# Generated at 2022-06-11 05:13:51.016657
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == "selinux"
    assert 'selinux' in collector.collect()

# Generated at 2022-06-11 05:13:52.368985
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-11 05:13:59.269060
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinuxfactcollector = SelinuxFactCollector()

    # Execute method collect
    selinuxfactcollector.collect()

    # Assert that selinux_python_present is set
    assert selinuxfactcollector.fact_ids == set() or selinuxfactcollector.fact_ids == {'selinux_python_present'}

    # Remove all keys in selinuxfactcollector.fact_ids
    selinuxfactcollector.fact_ids = set()

if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-11 05:14:08.946217
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test using different values of 'selinux_python_present' and selinux.is_selinux_enabled()
    # Test with selinux_python_present=True and selinux.is_selinux_enabled()=True
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.HAVE_SELINUX = True
    selinux_fact_collector.selinux.is_selinux_enabled = lambda: True
    facts = selinux_fact_collector.collect()
    assert facts['selinux'] is not None
    assert facts['selinux']['status'] == 'enabled'
    assert facts['selinux']['type'] == 'unknown'
    assert facts['selinux']['config_mode'] == 'unknown'
    assert facts

# Generated at 2022-06-11 05:14:11.027217
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # override the selinux module so it does not require a system dependency
    import sys

    sys.modules['selinux'] = None

    collector = SelinuxFactCollector()
    result = collector.collect()

    assert result['selinux']['status'] == 'Missing selinux Python library'
    assert result['selinux_python_present'] == False

    # Remove the custom selinux module
    del sys.modules['selinux']

# Generated at 2022-06-11 05:14:14.369230
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-11 05:14:16.353623
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 05:14:26.293795
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_collected_facts = {'ansible_distribution': 'CentOS',
                            'ansible_distribution_file_parsed': True,
                            'ansible_distribution_file_path': '/etc/redhat-release',
                            'ansible_distribution_file_variety': 'RedHat',
                            'ansible_distribution_major_version': '7',
                            'ansible_distribution_release': 'Core',
                            'ansible_distribution_version': '7.7.1908'}

    sfc = SelinuxFactCollector()
    result_dict = sfc.collect(collected_facts=test_collected_facts)

    assert result_dict['selinux'] == {'status': 'enabled',
                                      'policyvers': '28'}

   

# Generated at 2022-06-11 05:14:28.539714
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    c = SelinuxFactCollector()
    assert c.name == 'selinux'
    assert c._fact_ids == set()

# Generated at 2022-06-11 05:15:58.684579
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector = SelinuxFactCollector()
    facts = SelinuxFactCollector.collect()

    assert facts['selinux_python_present'] == True
    assert facts['selinux']

    assert facts['selinux']['status'] == 'enabled'
    assert facts['selinux']['policyvers'] == '28'
    assert facts['selinux']['config_mode'] == 'permissive'
    assert facts['selinux']['mode'] == 'permissive'
    assert facts['selinux']['type'] == 'targeted'

# Generated at 2022-06-11 05:16:01.104266
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    arg_data = {
      "module": {},
      "collected_facts": {}
    }
    collector = SelinuxFactCollector()
    collector.collect(**arg_data)

# Generated at 2022-06-11 05:16:03.416044
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()


# Generated at 2022-06-11 05:16:06.874605
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()

    assert isinstance(selinux_facts, dict)
    assert isinstance(selinux_facts['selinux'], dict)
    assert isinstance(selinux_facts['selinux_python_present'], bool)

# Generated at 2022-06-11 05:16:09.436480
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test SelinuxFactCollector"""
    test_collector = SelinuxFactCollector()
    assert test_collector is not None
    assert test_collector.name == 'selinux'

# Generated at 2022-06-11 05:16:16.716447
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    # Test with a fake dict for collected_facts
    collected_facts = {'selinux': None}
    results = collector.collect(collected_facts=collected_facts)
    assert 'selinux' in results
    if results['selinux'] is None or not results['selinux']:
        assert 'status' in results['selinux']
        assert 'config_mode' in results['selinux']
        assert 'policyvers' in results['selinux']
        assert 'mode' in results['selinux']
        assert 'type' in results['selinux']
    else:
        assert 'status' in results['selinux']
        assert results['selinux']['status'] == 'disabled'

    # Test that results['selinux'] and results

# Generated at 2022-06-11 05:16:18.696718
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    collected_facts = collector.collect(None, None)
    assert 'selinux' in collected_facts.keys()

# Generated at 2022-06-11 05:16:20.880118
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert type(obj) == SelinuxFactCollector
    assert obj.__class__ == SelinuxFactCollector


# Generated at 2022-06-11 05:16:23.510764
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector.collect() == {}

# Generated at 2022-06-11 05:16:32.314421
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible_collections.ansible.dist.plugins.module_utils.facts.collectors.selinux import SelinuxFactCollector
    from ansible.module_utils.selinux import is_selinux_enabled, security_policyvers, selinux_getenforcemode, security_getenforce, selinux_getpolicytype
    import pytest
    from unittest.mock import patch
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = {}
    is_enabled_flag = True
    is_enabled_patch = patch('ansible.module_utils.selinux.is_selinux_enabled', return_value = is_enabled_flag)
    is_enabled_patch.start()
    policyvers_flag = 1

# Generated at 2022-06-11 05:19:55.183776
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import utils

    def get_selinux_collector(module):
        '''
        pass the test module to the collector
        '''

        return SelinuxFactCollector(module=module)

    # Create the basic test module object
    module = basic.AnsibleModule(
        argument_spec=utils.base_arg_spec(),
        supports_check_mode=False)

    # Set the module so it can be used to get variables
    module.params['gather_subset'] = ['!all', 'selinux']
    module.params['filter'] = '*'

# Generated at 2022-06-11 05:19:57.383451
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-11 05:20:00.117783
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test SelinuxFactCollector class constructor
    """
    obj = SelinuxFactCollector()
    assert isinstance(obj, SelinuxFactCollector)
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 05:20:06.202817
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sut = SelinuxFactCollector()
    facts_dict = sut.collect()
    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict
    assert 'status' in facts_dict['selinux']

    # Because the selinux Python library is not present, the
    # status will be 'Missing selinux Python library' and
    # selinux_python_present will be False
    assert facts_dict['selinux_python_present'] == False
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'

# Generated at 2022-06-11 05:20:13.689603
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        input = {}
        selinux_facts = {}
        selinux_facts['status'] = 'Missing selinux Python library'
        input['selinux'] = selinux_facts
        input['selinux_python_present'] = False
        output = SelinuxFactCollector().collect(collected_facts=None)
        assert input['selinux']['status'] == output['selinux']['status']
        assert input['selinux_python_present'] == output['selinux_python_present']
        return

    # Case 1: SELinux is