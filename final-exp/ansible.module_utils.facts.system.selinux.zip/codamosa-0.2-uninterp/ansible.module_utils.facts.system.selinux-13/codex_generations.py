

# Generated at 2022-06-17 02:37:13.444683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:16.089020
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:19.630872
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:30.986085
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary to hold the collected facts
    collected_facts = {}

    # Call the collect method of the SelinuxFactCollector object
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the selinux_python_present fact is present in the collected facts
    assert 'selinux_python_present' in selinux_facts

    # Assert that the selinux fact is present in the collected facts
    assert 'selinux' in selinux_facts

    # Assert that the status fact is present in the selinux fact
    assert 'status' in selinux_facts['selinux']

    # Assert that the status fact is set to

# Generated at 2022-06-17 02:37:35.304196
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:45.954197
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux library present
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

    # Test with selinux library missing
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-17 02:37:50.329934
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:52.825900
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:37:58.553614
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:00.435375
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:15.320630
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:38:18.457880
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:22.167801
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:25.037745
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:33.764870
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:38:38.949834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:43.670521
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:49.666377
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:38:52.984687
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:56.490430
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:19.566876
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:21.606463
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:39:28.842015
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux library
    selinux = Mock()

    # Create a mock selinux library
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock AnsibleModule
    AnsibleModule = Mock()
    AnsibleModule.selinux = selinux

    # Create a mock AnsibleModuleUtils
    AnsibleModuleUtils = Mock()
    AnsibleModuleUtils.AnsibleModule = Ans

# Generated at 2022-06-17 02:39:31.306410
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:33.818689
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:45.154335
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and a mock collected_facts
    module = Mock()
    collected_facts = Mock()

    # Create a mock selinux module
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock selinux module that raises an OSError
    selinux_OSError = Mock()
    selinux_OSError.is_selinux_enabled.return_value = True
    selinux_OSError.security_policyvers

# Generated at 2022-06-17 02:39:53.678679
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:39:57.706226
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    selinux_facts.collect()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-17 02:40:07.323500
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:40:11.107834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:47.613743
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:50.581014
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:59.156701
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:41:01.557540
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:06.926620
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux']['status'] == 'disabled'
    assert selinux_facts['selinux_python_present'] == True

# Generated at 2022-06-17 02:41:11.157738
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:19.284533
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'params': {}})

    # Create a mock facts
    collected_facts = {}

    # Create a mock selinux module
    selinux_module = type('selinux', (object,), {'is_selinux_enabled': lambda: True,
                                                 'security_policyvers': lambda: '28',
                                                 'selinux_getenforcemode': lambda: (0, 1),
                                                 'security_getenforce': lambda: 1,
                                                 'selinux_getpolicytype': lambda: (0, 'targeted')})

    # Create a mock selinux module with missing functions

# Generated at 2022-06-17 02:41:22.928385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:29.368770
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:34.273698
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:42:49.609014
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:42:54.121711
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:58.258724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:08.418972
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect
    """
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {'params': {}})

    # Create a mock selinux module
    mock_selinux = type('selinux', (object,), {'is_selinux_enabled': lambda: True,
                                               'security_policyvers': lambda: '28',
                                               'selinux_getenforcemode': lambda: (0, 1),
                                               'security_getenforce': lambda: 1,
                                               'selinux_getpolicytype': lambda: (0, 'targeted')})

    # Create a mock AnsibleModule

# Generated at 2022-06-17 02:43:12.987175
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:43:21.836681
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:43:27.970607
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux_python_present'] == True
    assert facts_dict['selinux']['status'] == 'enabled'
    assert facts_dict['selinux']['policyvers'] == 'unknown'
    assert facts_dict['selinux']['config_mode'] == 'unknown'
    assert facts_dict['selinux']['mode'] == 'unknown'
    assert facts_dict['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:43:35.446252
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect()
    """
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Get the facts
    facts = selinux_fact_collector.collect()

    # Check the facts
    assert facts['selinux']['status'] == 'enabled'
    assert facts['selinux']['policyvers'] == 'unknown'
    assert facts['selinux']['config_mode'] == 'unknown'
    assert facts['selinux']['mode'] == 'unknown'
    assert facts['selinux']['type'] == 'unknown'
    assert facts['selinux_python_present'] == True

# Generated at 2022-06-17 02:43:38.696562
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:45.655838
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:46:43.460262
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import stat
    import subprocess
    import platform

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python file
    (fd, pyfile) = tempfile.mkstemp(dir=tmpdir, suffix='.py')
    f = os.fdopen(fd, 'w')

# Generated at 2022-06-17 02:46:50.147309
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:46:53.597791
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-17 02:47:02.280278
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'