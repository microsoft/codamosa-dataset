

# Generated at 2022-06-17 02:37:14.806608
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:17.363907
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:29.450720
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux module
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled method
    selinux.is_selinux_enabled = Mock(return_value=True)

    # Create a mock selinux.security_policyvers method
    selinux.security_policyvers = Mock(return_value=1)

    # Create a mock selinux.selinux_getenforcemode method
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))

    # Create a mock selinux.security_getenforce method
    selinux.security_getenforce = Mock(return_value=1)

    # Create a mock selinux.selinux_getpolicytype method
    selinux.selinux

# Generated at 2022-06-17 02:37:32.613583
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:42.964099
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'params': {}})()

    # Create a mock selinux library
    selinux_mock = type('selinux', (object,), {
        'is_selinux_enabled': lambda: True,
        'security_policyvers': lambda: '1.2.3',
        'selinux_getenforcemode': lambda: (0, 1),
        'security_getenforce': lambda: 1,
        'selinux_getpolicytype': lambda: (0, 'targeted')
    })()

    # Create a mock AnsibleModule
    AnsibleModule_mock = type('AnsibleModule', (object,), {
        'fail_json': lambda *args, **kwargs: None
    })

    # Create a mock BaseFact

# Generated at 2022-06-17 02:37:47.533615
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-17 02:37:52.779829
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:02.037393
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    mock_module = type('module', (object,), {'params': {}})()

    # Create a mock selinux module object
    mock_selinux = type('selinux', (object,), {'is_selinux_enabled': lambda: True,
                                               'security_policyvers': lambda: '28',
                                               'selinux_getenforcemode': lambda: (0, 1),
                                               'security_getenforce': lambda: 1,
                                               'selinux_getpolicytype': lambda: (0, 'targeted')})()

    # Create a mock AnsibleModule object
    mock_AnsibleModule = type('AnsibleModule', (object,), {'fail_json': lambda *args, **kwargs: None})

    # Create a mock Ans

# Generated at 2022-06-17 02:38:14.336561
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux library
    selinux = Mock()

    # Create a mock selinux library
    selinux.is_selinux_enabled = Mock(return_value=True)

    # Create a mock selinux library
    selinux.security_policyvers = Mock(return_value=1)

    # Create a mock selinux library
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))

    # Create a mock selinux library
    selinux.security_getenforce = Mock(return_value=1)

    # Create a mock selinux library
    selinux.selinux_getpolicytype = Mock(return_value=(0, 'targeted'))

    # Create a mock selinux library
    selinux.is_selin

# Generated at 2022-06-17 02:38:17.158337
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:38:30.066208
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:40.299541
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.selinux import HAVE_SELINUX
    import ansible.module_utils.compat.selinux

    # Create a mock module object
    mock_module = type('module', (object,), {})()

    # Create a mock selinux module object
    mock_selinux = type('selinux', (object,), {})()

    # Create a mock selinux.is_selinux_enabled function
    def mock_is_selinux_enabled():
        return True

    # Create a mock selinux.security_policyvers function

# Generated at 2022-06-17 02:38:49.237678
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux library present
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == '28'
    assert selinux_facts['selinux']['config_mode'] == 'enforcing'
    assert selinux_facts['selinux']['mode'] == 'enforcing'
    assert selinux_facts['selinux']['type'] == 'targeted'

    # Test with selinux library missing
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-17 02:38:52.619762
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:56.059691
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:03.300505
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:39:08.789680
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:13.757794
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:15.156290
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-17 02:39:19.953095
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:39:42.474948
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:45.363580
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:52.984674
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and collected_facts
    module = Mock(name='module')
    collected_facts = dict()

    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Call method collect of SelinuxFactCollector
    selinux_facts = selinux_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that selinux_python_present is set to True
    assert selinux_facts['selinux_python_present'] == True

    # Assert that selinux_python_present is set to False
    selinux_fact_collector.HAVE_SELINUX = False
    selinux_facts = selinux_fact_collector.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-17 02:39:57.515074
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:40:10.255447
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and mock facts
    module = Mock()
    collected_facts = dict()

    # Create a mock selinux module
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock AnsibleModule
    ansible_module = Mock()
    ansible_module.selinux = selinux

    # Create a mock AnsibleModuleUtils
    ansible_module_utils = Mock()

# Generated at 2022-06-17 02:40:18.945249
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:40:23.894426
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:30.832375
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:35.586683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:45.702054
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()
    module.params = {}

    # Create a mock selinux library
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = 1
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock selinux library that raises an exception
    selinux_exception = Mock()
    selinux_exception.is_selinux_enabled.return_value = True
    selinux_exception.security_policyvers.side_effect = OSError
    se

# Generated at 2022-06-17 02:41:32.080779
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:41:36.354559
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:47.400683
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.selinux import HAVE_SELINUX
    from ansible.module_utils.facts.collector.selinux import selinux

    # Test if selinux library is present

# Generated at 2022-06-17 02:41:54.187925
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a facts dictionary
    facts_dict = {}

    # Call method collect of class SelinuxFactCollector
    selinux_fact_collector.collect(collected_facts=facts_dict)

    # Assert that the facts dictionary is not empty
    assert facts_dict

# Generated at 2022-06-17 02:41:59.326152
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:42:08.367551
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (), {})()
    mock_module.params = {}

    # Create a mock selinux module
    mock_selinux = type('selinux', (), {})()
    mock_selinux.is_selinux_enabled = lambda: True
    mock_selinux.security_policyvers = lambda: '28'
    mock_selinux.selinux_getenforcemode = lambda: (0, 1)
    mock_selinux.security_getenforce = lambda: 1
    mock_selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    # Create a mock AnsibleModuleUtilsCompat
    mock_compat = type('AnsibleModuleUtilsCompat', (), {})()
    mock_

# Generated at 2022-06-17 02:42:17.547184
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock selinux object
    selinux = Mock()

    # Create a mock selinux object
    selinux.is_selinux_enabled = Mock(return_value=True)
    selinux.security_policyvers = Mock(return_value=1)
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))
    selinux.security_getenforce = Mock(return_value=1)
    selinux.selinux_getpolicytype = Mock(return_value=(0, 'targeted'))

    # Create a mock AnsibleModule object
    AnsibleModule = Mock()
    AnsibleModule.fail_json = Mock()

    # Create a mock AnsibleModule object
    AnsibleModule.fail_json = Mock()



# Generated at 2022-06-17 02:42:24.475447
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:42:36.570681
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux library present
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

    # Test with selinux library missing
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-17 02:42:40.947872
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:34.156716
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and mock facts
    module = Mock()
    collected_facts = {}

    # Create an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Call method collect of SelinuxFactCollector
    selinux_facts = selinux_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that the selinux facts are as expected
    assert selinux_facts['selinux'] == {'status': 'Missing selinux Python library'}
    assert selinux_facts['selinux_python_present'] == False

# Generated at 2022-06-17 02:43:39.022588
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:43:41.709324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:43:48.039529
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']

# Generated at 2022-06-17 02:43:51.572044
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:43:56.667832
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:01.283917
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    mock_module = type('module', (object,), {})()

    # Create a mock selinux library
    mock_selinux = type('selinux', (object,), {})()
    mock_selinux.is_selinux_enabled = lambda: True
    mock_selinux.security_policyvers = lambda: '28'
    mock_selinux.selinux_getenforcemode = lambda: (0, 1)
    mock_selinux.security_getenforce = lambda: 1
    mock_selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    # Create a mock selinux library that raises an exception
    mock_selinux_exception = type('selinux', (object,), {})()
    mock_selin

# Generated at 2022-06-17 02:44:07.137483
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:11.771678
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:20.395391
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux module
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock selinux module with missing functions
    selinux_missing_functions = Mock()
    selinux_missing_functions.is_selinux_enabled.return_value = True
    selinux_missing_functions.security_getenforce.return_value = 1
    selinux_

# Generated at 2022-06-17 02:45:45.502376
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == '28'
    assert selinux_facts['selinux']['config_mode'] == 'enforcing'
    assert selinux_facts['selinux']['mode'] == 'enforcing'
    assert selinux_facts['selinux']['type'] == 'targeted'

# Generated at 2022-06-17 02:45:47.735142
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:45:52.698939
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:45:57.130875
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:45:59.269442
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {'selinux': {'status': 'disabled'}, 'selinux_python_present': True}

# Generated at 2022-06-17 02:46:04.143339
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock collected_facts object
    collected_facts = Mock()

    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Call method collect of SelinuxFactCollector
    facts_dict = selinux_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that the facts_dict is not empty
    assert facts_dict

# Generated at 2022-06-17 02:46:08.986435
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:46:12.128286
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:46:18.458066
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:46:24.317905
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
