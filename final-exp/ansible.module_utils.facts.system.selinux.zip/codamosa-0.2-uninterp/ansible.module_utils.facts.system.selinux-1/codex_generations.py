

# Generated at 2022-06-17 02:37:15.138012
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect()
    """
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts
    assert isinstance(selinux_facts['selinux_python_present'], bool)

# Generated at 2022-06-17 02:37:19.672428
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:37:29.033144
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:37:39.684862
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = MagicMock()

    # Create a mock selinux module
    selinux = MagicMock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '1.2.3'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock selinux module with an exception
    selinux_exception = MagicMock()
    selinux_exception.is_selinux_enabled.return_value = True
    selinux_exception.security_policyvers.side_effect = AttributeError

# Generated at 2022-06-17 02:37:40.755281
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    selinux_facts.collect()

# Generated at 2022-06-17 02:37:46.120995
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:37:50.691415
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:56.713311
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:38:02.782863
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:13.482478
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:38:34.329329
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock selinux object
    selinux_mock = Mock()

    # Create a mock selinux.is_selinux_enabled object
    selinux_is_selinux_enabled_mock = Mock()
    selinux_is_selinux_enabled_mock.return_value = True
    selinux_mock.is_selinux_enabled = selinux_is_selinux_enabled_mock

    # Create a mock selinux.security_policyvers object
    selinux_security_policyvers_mock = Mock()
    selinux_security_policyvers_mock.return_value = '1'
    selinux_mock.security_policyvers = selinux_security_policyvers_mock

    # Create a mock selinux.sel

# Generated at 2022-06-17 02:38:45.039361
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of class SelinuxFactCollector
    selinux_collector = SelinuxFactCollector()

    # Create a dictionary of facts
    facts_dict = {}

    # Call method collect of class SelinuxFactCollector
    selinux_facts = selinux_collector.collect(collected_facts=facts_dict)

    # Assert that the facts_dict is not empty
    assert facts_dict

    # Assert that the selinux_facts is not empty
    assert selinux_facts

    # Assert that the selinux_facts is a dictionary
    assert isinstance(selinux_facts, dict)

    # Assert that the selinux_facts contains a key selinux
    assert 'selinux' in selinux_facts

    # Assert that the selinux_facts contains a key selinux_python_present


# Generated at 2022-06-17 02:38:47.817164
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:51.197756
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:00.666494
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock collected_facts
    collected_facts = Mock()

    # Create a mock selinux
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled
    selinux.is_selinux_enabled = Mock()

    # Create a mock selinux.security_policyvers
    selinux.security_policyvers = Mock()

    # Create a mock selinux.selinux_getenforcemode
    selinux.selinux_getenforcemode = Mock()

    # Create a mock selinux.security_getenforce
    selinux.security_getenforce = Mock()

    # Create a mock selinux.selinux_getpolicytype
    selinux.selinux_getpolicytype = Mock()

    # Create a mock selinux

# Generated at 2022-06-17 02:39:03.502132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:16.464985
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (), {})()

    # Create a mock selinux module
    mock_selinux = type('selinux', (), {})()

    # Create a mock selinux.is_selinux_enabled function
    def mock_is_selinux_enabled():
        return True

    # Create a mock selinux.security_policyvers function
    def mock_security_policyvers():
        return '28'

    # Create a mock selinux.selinux_getenforcemode function
    def mock_selinux_getenforcemode():
        return (0, 1)

    # Create a mock selinux.security_getenforce function
    def mock_security_getenforce():
        return 1

    # Create a mock selinux.selinux_getpolicy

# Generated at 2022-06-17 02:39:18.493326
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:24.194949
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:26.953425
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:55.373030
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and mock facts
    module = Mock()
    collected_facts = dict()

    # Create an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Call method collect of SelinuxFactCollector
    facts_dict = selinux_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Assert that the facts_dict contains the expected values
    assert facts_dict == {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'status': 'enabled',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }

# Generated at 2022-06-17 02:39:58.421628
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:40:01.056092
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:04.977456
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:11.675419
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert collected_facts['selinux_python_present'] == True
    assert collected_facts['selinux']['status'] == 'enabled'
    assert collected_facts['selinux']['policyvers'] == 'unknown'
    assert collected_facts['selinux']['config_mode'] == 'unknown'
    assert collected_facts['selinux']['mode'] == 'unknown'
    assert collected_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:40:19.238054
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:40:25.059265
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts
    assert isinstance(selinux_facts['selinux_python_present'], bool)

# Generated at 2022-06-17 02:40:30.946771
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:35.588572
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:37.990371
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:28.883746
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module
    module = os.path.join(tmpdir, 'ansible_collections', 'ansible_collections', 'test_ns', 'test_coll', 'plugins', 'modules', 'test_selinux.py')
    os.makedirs(os.path.dirname(module))

# Generated at 2022-06-17 02:41:35.285925
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:45.674482
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:41:55.598849
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:41:58.917531
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()
    # Assertion
    assert selinux_fact_collector.collect() == {'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}, 'selinux_python_present': True}

# Generated at 2022-06-17 02:42:06.184110
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert collected_facts['selinux']['status'] == 'disabled'
    assert collected_facts['selinux']['policyvers'] == 'unknown'
    assert collected_facts['selinux']['config_mode'] == 'unknown'
    assert collected_facts['selinux']['mode'] == 'unknown'
    assert collected_facts['selinux']['type'] == 'unknown'
    assert collected_facts['selinux_python_present'] == True

# Generated at 2022-06-17 02:42:09.436320
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:42:10.839522
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:15.627264
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:21.342227
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:47.085455
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:50.732742
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:43:53.413864
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:44:02.640973
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux module
    selinux_mock = Mock()
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = '28'
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock AnsibleModule
    AnsibleModule_mock = Mock()
    AnsibleModule_mock.return_value = module

    # Create a mock AnsibleModule
    AnsibleModule_mock = Mock()


# Generated at 2022-06-17 02:44:16.238856
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'params': {}})()

    # Create a mock collected_facts
    collected_facts = {}

    # Create a mock selinux module
    selinux_mock = type('selinux', (object,), {'is_selinux_enabled': lambda: True,
                                               'security_policyvers': lambda: '28',
                                               'selinux_getenforcemode': lambda: (0, 1),
                                               'security_getenforce': lambda: 1,
                                               'selinux_getpolicytype': lambda: (0, 'targeted')})

    # Create a mock AnsibleModule

# Generated at 2022-06-17 02:44:25.751465
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect()
    """
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary of facts
    collected_facts = {}

    # Call method collect of SelinuxFactCollector
    facts_dict = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the facts_dict is not empty
    assert facts_dict

# Generated at 2022-06-17 02:44:31.448841
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:44:34.511714
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:44.130544
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()
    module.params = {}

    # Create a mock selinux module
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock AnsibleModule
    AnsibleModule = Mock()
    AnsibleModule.return_value = module

    # Create a mock AnsibleModuleUtils
    AnsibleModuleUtils = Mock()
    AnsibleModuleUtils.HAVE_SELINUX = True

# Generated at 2022-06-17 02:44:49.317881
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()