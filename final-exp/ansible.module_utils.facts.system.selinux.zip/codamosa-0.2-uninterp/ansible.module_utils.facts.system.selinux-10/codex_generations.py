

# Generated at 2022-06-17 02:37:12.615495
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:18.648711
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:37:23.415245
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:27.060385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:37:35.983130
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'params': {}})

    # Create a mock selinux library
    class MockSelinux(object):
        def __init__(self):
            self.is_selinux_enabled_return_value = True
            self.security_policyvers_return_value = '28'
            self.selinux_getenforcemode_return_value = (0, 1)
            self.security_getenforce_return_value = 1
            self.selinux_getpolicytype_return_value = (0, 'targeted')

        def is_selinux_enabled(self):
            return self.is_selinux_enabled_return_value

        def security_policyvers(self):
            return self.security_policyvers_return_value



# Generated at 2022-06-17 02:37:44.117192
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()
    module.params = {}

    # Create a mock selinux library
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '1.0'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock AnsibleModule
    AnsibleModule = Mock()
    AnsibleModule.fail_json.side_effect = Exception('fail_json called')

    # Create a mock BaseFactCollector
    BaseFactCollector = Mock()

# Generated at 2022-06-17 02:37:50.451100
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:53.260452
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:37:59.059141
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-17 02:38:08.164820
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {'params': {}})()

    # Create a mock collected_facts
    mock_collected_facts = {}

    # Create a mock selinux module
    mock_selinux = type('selinux', (object,), {'is_selinux_enabled': lambda: True,
                                               'security_policyvers': lambda: '1.2.3',
                                               'selinux_getenforcemode': lambda: (0, 1),
                                               'security_getenforce': lambda: 1,
                                               'selinux_getpolicytype': lambda: (0, 'targeted')})()

    # Create a mock selinux module that raises an exception

# Generated at 2022-06-17 02:38:20.613487
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:38:27.502823
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:38:30.325855
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-17 02:38:35.081417
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:42.164696
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock selinux library object
    selinux = Mock()

    # Create a mock selinux library object
    selinux.is_selinux_enabled = Mock(return_value=True)
    selinux.security_policyvers = Mock(return_value=1)
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))
    selinux.security_getenforce = Mock(return_value=1)
    selinux.selinux_getpolicytype = Mock(return_value=(0, 'targeted'))

    # Create a mock AnsibleModule object
    ansible_module = Mock()
    ansible_module.params = {}

    # Create a mock AnsibleModule object
    ansible_module.params = {}

   

# Generated at 2022-06-17 02:38:44.996335
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:49.921043
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary that will be used to pass the collected facts to the
    # SelinuxFactCollector object
    collected_facts = {}

    # Collect facts
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the facts are collected
    assert selinux_facts['selinux'] is not None

# Generated at 2022-06-17 02:38:59.774001
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock selinux object
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled object
    selinux.is_selinux_enabled = Mock(return_value=True)

    # Create a mock selinux.security_policyvers object
    selinux.security_policyvers = Mock(return_value=1)

    # Create a mock selinux.selinux_getenforcemode object
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))

    # Create a mock selinux.security_getenforce object
    selinux.security_getenforce = Mock(return_value=1)

    # Create a mock selinux.selinux_getpolicytype object
    selinux.selin

# Generated at 2022-06-17 02:39:07.569257
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.selinux import HAVE_SELINUX
    from ansible.module_utils.facts.collector.selinux import SELINUX_MODE_DICT
    from ansible.module_utils.facts.collector.selinux import selinux

    # Create a mock module object
    class MockModule(object):
        def __init__(self):
            self.params = {}

    # Create a mock selinux object
    class MockSelinux(object):
        def __init__(self):
            self.is_selinux

# Generated at 2022-06-17 02:39:12.726301
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:30.203988
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:39:36.675502
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock selinux object
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled object
    selinux.is_selinux_enabled = Mock(return_value=True)

    # Create a mock selinux.security_policyvers object
    selinux.security_policyvers = Mock(return_value=1)

    # Create a mock selinux.selinux_getenforcemode object
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))

    # Create a mock selinux.security_getenforce object
    selinux.security_getenforce = Mock(return_value=1)

    # Create a mock selinux.selinux_getpolicytype object
    selinux.selin

# Generated at 2022-06-17 02:39:43.058698
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts
    assert selinux_facts['selinux_python_present'] == True

# Generated at 2022-06-17 02:39:49.850223
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:52.297534
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:39:57.558659
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:04.344956
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector class
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary containing the collected facts
    collected_facts = {}

    # Call the collect method of the SelinuxFactCollector instance
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the selinux_python_present fact is present in the collected facts
    assert 'selinux_python_present' in selinux_facts

    # Assert that the selinux fact is present in the collected facts
    assert 'selinux' in selinux_facts

    # Assert that the selinux fact is a dictionary
    assert isinstance(selinux_facts['selinux'], dict)

    # Assert that the selinux fact

# Generated at 2022-06-17 02:40:09.966078
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:18.805529
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present']
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:40:22.655767
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:40:45.701905
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux']['status'] == 'disabled'
    assert selinux_facts['selinux_python_present'] == True

# Generated at 2022-06-17 02:40:48.874791
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:51.940900
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:02.026766
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and mock facts
    module = Mock()
    collected_facts = Mock()

    # Create a mock selinux module
    selinux_mock = Mock()

    # Create a mock selinux module with a missing selinux library
    selinux_mock_missing_library = Mock()
    selinux_mock_missing_library.is_selinux_enabled.side_effect = ImportError

    # Create a mock selinux module with a missing selinux library
    selinux_mock_enabled = Mock()
    selinux_mock_enabled.is_selinux_enabled.return_value = True
    selinux_mock_enabled.security_policyvers.return_value = '28'
    selinux_mock_enabled.selinux_getenforcemode.return_value = (0, 1)
   

# Generated at 2022-06-17 02:41:07.364390
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:09.970787
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:18.851381
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    mock_module = type('module', (object,), {})()

    # Create a mock selinux module object
    mock_selinux = type('selinux', (object,), {})()

    # Create a mock selinux.is_selinux_enabled function
    def mock_is_selinux_enabled():
        return True

    # Create a mock selinux.security_policyvers function
    def mock_security_policyvers():
        return '28'

    # Create a mock selinux.selinux_getenforcemode function
    def mock_selinux_getenforcemode():
        return (0, 1)

    # Create a mock selinux.security_getenforce function
    def mock_security_getenforce():
        return 1

    # Create a mock selinux.sel

# Generated at 2022-06-17 02:41:28.722790
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux library
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '1.2.3'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock module_utils
    module_utils = Mock()
    module_utils.compat = Mock()
    module_utils.compat.selinux = selinux

    # Create a mock AnsibleModule
    AnsibleModule = Mock()
    AnsibleModule.module_utils

# Generated at 2022-06-17 02:41:33.905930
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:41:37.037285
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:20.685755
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:26.033538
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:29.273526
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:34.277037
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:37.280872
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:41.612138
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:50.200537
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:42:59.152702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:43:05.276827
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:07.160195
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:43.233138
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect()
    """
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Test the collect method
    selinux_facts = selinux_fact_collector.collect()

    # Assert that the selinux facts are present
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts

    # Assert that the selinux facts are not empty
    assert selinux_facts['selinux']
    assert selinux_facts['selinux_python_present']

# Generated at 2022-06-17 02:44:46.812419
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-17 02:44:56.625397
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()
    module.params = {}

    # Create a mock selinux library
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock AnsibleModule
    AnsibleModule = Mock()
    AnsibleModule.params = {}

    # Create a mock AnsibleModuleUtils
    AnsibleModuleUtils = Mock()
    AnsibleModuleUtils.is_selinux_enabled.return_value

# Generated at 2022-06-17 02:44:59.588920
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:45:04.575188
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:45:08.292994
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:45:13.998296
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:45:18.931339
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:45:23.849689
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:45:28.337460
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
