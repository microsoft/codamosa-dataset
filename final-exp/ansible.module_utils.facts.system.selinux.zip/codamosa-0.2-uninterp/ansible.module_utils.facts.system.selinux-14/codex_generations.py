

# Generated at 2022-06-17 02:37:14.191804
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:37:16.847219
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:21.079704
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:24.409002
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:37:28.390404
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:31.711352
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:35.420195
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:39.504350
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:44.916312
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert 'config_mode' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']
    assert 'type' in facts_dict['selinux']
    assert 'policyvers' in facts_dict['selinux']
    assert 'selinux_python_present' in facts_dict

# Generated at 2022-06-17 02:37:50.537762
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:02.684026
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:38:07.993294
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:13.657831
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:38:16.426858
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:38:24.414815
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:38:29.568099
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:38:40.269667
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    # Create a Collector object
    test_collector = Collector()

    # Add a SelinuxFactCollector to the Collector object
    test_collector.add_collector(SelinuxFactCollector)

    # Add a SystemFactCollector to the Collector object
    test_collector.add_collector(SystemFactCollector)

    # Collect and process facts
    test_collector.collect(module=None, collected_facts=None)
    facts = test_collector.get_facts()

    # Assert that the facts include the selinux facts

# Generated at 2022-06-17 02:38:42.225533
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:38:45.042200
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:51.446114
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and collected_facts
    module = Mock()
    collected_facts = {}

    # Create a mock selinux library
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock AnsibleModule
    ansible_module = Mock()
    ansible_module.selinux = selinux

    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

   

# Generated at 2022-06-17 02:39:03.297815
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:08.116028
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:39:13.257927
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:16.011393
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:26.061188
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock selinux object
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled object
    selinux.is_selinux_enabled = Mock(return_value=True)

    # Create a mock selinux.security_policyvers object
    selinux.security_policyvers = Mock(return_value=1)

    # Create a mock selinux.selinux_getenforcemode object
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))

    # Create a mock selinux.security_getenforce object
    selinux.security_getenforce = Mock(return_value=1)

    # Create a mock selinux.selinux_getpolicytype object
    selinux.selin

# Generated at 2022-06-17 02:39:28.873877
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-17 02:39:34.708504
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:39:45.636841
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux module
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled method
    selinux.is_selinux_enabled = Mock(return_value=True)

    # Create a mock selinux.security_policyvers method
    selinux.security_policyvers = Mock(return_value=1)

    # Create a mock selinux.selinux_getenforcemode method
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))

    # Create a mock selinux.security_getenforce method
    selinux.security_getenforce = Mock(return_value=1)

    # Create a mock selinux.selinux_getpolicytype method
    selinux.selinux

# Generated at 2022-06-17 02:39:49.945302
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:52.688089
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:13.951424
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:40:20.285528
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:40:30.698871
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'params': {}})

    # Create a mock collected_facts
    collected_facts = {}

    # Create a mock selinux module
    selinux_mock = type('selinux', (object,), {'is_selinux_enabled': lambda: True,
                                               'security_policyvers': lambda: '28',
                                               'selinux_getenforcemode': lambda: (0, 1),
                                               'security_getenforce': lambda: 1,
                                               'selinux_getpolicytype': lambda: (0, 'targeted')})

    # Create a mock selinux module with missing functions

# Generated at 2022-06-17 02:40:39.808167
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock collected_facts
    collected_facts = Mock()

    # Create a mock selinux
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled
    selinux.is_selinux_enabled = Mock()

    # Create a mock selinux.security_policyvers
    selinux.security_policyvers = Mock()

    # Create a mock selinux.selinux_getenforcemode
    selinux.selinux_getenforcemode = Mock()

    # Create a mock selinux.security_getenforce
    selinux.security_getenforce = Mock()

    # Create a mock selinux.selinux_getpolicytype
    selinux.selinux_getpolicytype = Mock()

    # Create a mock selinux

# Generated at 2022-06-17 02:40:48.092283
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:40:54.770930
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux']['status'] == 'disabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:41:04.311896
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (), {})()

    # Create a mock selinux library
    mock_selinux = type('selinux', (), {})()
    mock_selinux.is_selinux_enabled = lambda: True
    mock_selinux.security_policyvers = lambda: '1.2.3'
    mock_selinux.selinux_getenforcemode = lambda: (0, 1)
    mock_selinux.security_getenforce = lambda: 1
    mock_selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    # Create a mock module_utils
    mock_module_utils = type('module_utils', (), {})()
    mock_module_utils.selinux = mock_sel

# Generated at 2022-06-17 02:41:16.434584
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and collected_facts
    module = Mock()
    collected_facts = {}

    # Create a mock selinux module
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock selinux_python_present
    selinux_python_present = True

    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Call the collect method
    selinux

# Generated at 2022-06-17 02:41:18.161548
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:22.802461
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:59.638225
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:42:03.203847
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:42:13.672652
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock selinux library
    selinux = Mock()

    # Create a mock selinux library
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Call method collect of class SelinuxFactCollector
    result = selinux_fact_collector.collect(module, selinux)

   

# Generated at 2022-06-17 02:42:21.511709
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts
    assert isinstance(selinux_facts['selinux_python_present'], bool)

# Generated at 2022-06-17 02:42:29.417999
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock collected_facts
    collected_facts = Mock()

    # Create a mock selinux
    selinux = Mock()

    # Create a mock selinux.is_selinux_enabled
    selinux.is_selinux_enabled = Mock(return_value=True)

    # Create a mock selinux.security_policyvers
    selinux.security_policyvers = Mock(return_value=1)

    # Create a mock selinux.selinux_getenforcemode
    selinux.selinux_getenforcemode = Mock(return_value=(0, 1))

    # Create a mock selinux.security_getenforce
    selinux.security_getenforce = Mock(return_value=1)

    # Create a mock selinux.selinux_

# Generated at 2022-06-17 02:42:32.669932
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector()
    selinux_facts.collect()
    assert selinux_facts.name == 'selinux'

# Generated at 2022-06-17 02:42:39.274800
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:42:42.166827
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:42:46.654737
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:49.947029
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:40.436924
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:43.040879
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:45.035082
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:43:53.497177
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()
    module.params = {}

    # Create a mock collected_facts
    collected_facts = {}

    # Create a mock selinux
    selinux = Mock()
    selinux.is_selinux_enabled.return_value = True
    selinux.security_policyvers.return_value = '28'
    selinux.selinux_getenforcemode.return_value = (0, 1)
    selinux.security_getenforce.return_value = 1
    selinux.selinux_getpolicytype.return_value = (0, 'targeted')

    # Create a mock selinux_python_present
    selinux_python_present = True

    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-17 02:44:02.639336
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary to store the collected facts
    collected_facts = {}

    # Call method collect of class SelinuxFactCollector
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that selinux_facts is a dictionary
    assert isinstance(selinux_facts, dict)

    # Assert that selinux_facts contains the key selinux
    assert 'selinux' in selinux_facts

    # Assert that selinux_facts contains the key selinux_python_present
    assert 'selinux_python_present' in selinux_facts

    # Assert that selinux_facts['selinux'] is a dictionary
   

# Generated at 2022-06-17 02:44:12.344194
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector class
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary to hold the collected facts
    collected_facts = {}

    # Collect the facts
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the selinux facts are present in the collected facts
    assert 'selinux' in selinux_facts

# Generated at 2022-06-17 02:44:19.417276
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module object
    module = Mock()

    # Create a mock collected facts object
    collected_facts = Mock()

    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Call method collect of SelinuxFactCollector object
    selinux_facts = selinux_fact_collector.collect(module, collected_facts)

    # Assert that the selinux facts are equal to the expected selinux facts
    assert selinux_facts == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-17 02:44:24.528343
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:27.718825
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:44:37.152067
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']

# Generated at 2022-06-17 02:46:09.501377
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:46:14.111004
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:46:18.785022
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:46:24.354184
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:46:36.600993
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary to store the collected facts
    collected_facts = {}

    # Call the method collect of the object
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert the collected facts
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == '28'
    assert selinux_facts['selinux']['config_mode'] == 'enforcing'
    assert selinux_facts['selinux']['mode'] == 'enforcing'
    assert selinux_facts['selinux']['type'] == 'targeted'

# Generated at 2022-06-17 02:46:46.527967
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.selinux import HAVE_SELINUX

    # Create a Collector object
    test_collector = Collector()

    # Create a SelinuxFactCollector object
    test_selinux_collector = SelinuxFactCollector()

    # Add the SelinuxFactCollector object to the Collector object
    test_collector.add_collector(test_selinux_collector)

    # Get the facts from the SelinuxFactCollector object
    test_facts = test_selinux_collector.collect()

    # Test the selinux_python_present fact

# Generated at 2022-06-17 02:46:53.333487
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:46:58.347723
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:46:59.529531
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-17 02:47:01.625728
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
