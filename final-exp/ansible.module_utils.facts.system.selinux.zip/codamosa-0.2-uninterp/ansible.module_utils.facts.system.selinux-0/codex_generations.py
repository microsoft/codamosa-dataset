

# Generated at 2022-06-17 02:37:17.283819
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary of collected facts
    collected_facts = {}

    # Call the method collect of class SelinuxFactCollector
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the selinux facts are present in the collected facts
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:37:21.598946
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:25.035570
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:37:33.270078
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:37:36.206653
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:38.906009
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:37:41.466521
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:46.828188
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:37:51.088561
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:37:52.865598
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-17 02:38:12.992471
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux_python_present'] == True
    assert facts_dict['selinux']['status'] == 'enabled'
    assert facts_dict['selinux']['policyvers'] == 'unknown'
    assert facts_dict['selinux']['config_mode'] == 'unknown'
    assert facts_dict['selinux']['mode'] == 'unknown'
    assert facts_dict['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:38:16.063220
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:25.619354
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Test with selinux library present
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()
    # Create a BaseFactCollector object
    base_fact_collector = BaseFactCollector()
    # Create a facts dictionary
    facts_dict = {}
    # Set the selinux_python_present fact to True
    facts_dict['selinux_python_present'] = True
    # Set the selinux fact

# Generated at 2022-06-17 02:38:31.403308
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('AnsibleModule', (object,), {'params': {}})

    # Create a mock selinux module
    selinux_mock = type('selinux', (object,), {
        'is_selinux_enabled': lambda: True,
        'security_policyvers': lambda: '28',
        'selinux_getenforcemode': lambda: (0, 1),
        'security_getenforce': lambda: 1,
        'selinux_getpolicytype': lambda: (0, 'targeted')
    })

    # Create a mock AnsibleModule
    ansible_module_mock = type('AnsibleModule', (object,), {
        'params': {},
        'selinux': selinux_mock
    })

    # Create a mock Ans

# Generated at 2022-06-17 02:38:35.190309
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:42.186417
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {'params': {}})

    # Create a mock selinux library
    mock_selinux = type('selinux', (object,), {
        'is_selinux_enabled': lambda: True,
        'security_policyvers': lambda: '28',
        'selinux_getenforcemode': lambda: (0, 1),
        'security_getenforce': lambda: 1,
        'selinux_getpolicytype': lambda: (0, 'targeted')
    })

    # Create a mock selinux library with an exception

# Generated at 2022-06-17 02:38:50.037867
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module and facts
    mock_module = type('module', (object,), {})()
    mock_facts = {}

    # Create a mock selinux module
    mock_selinux = type('selinux', (object,), {})()
    mock_selinux.is_selinux_enabled = lambda: True
    mock_selinux.security_policyvers = lambda: '28'
    mock_selinux.selinux_getenforcemode = lambda: (0, 1)
    mock_selinux.security_getenforce = lambda: 1
    mock_selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    # Create a mock AnsibleModule
    mock_AnsibleModule = type('AnsibleModule', (object,), {})
    mock

# Generated at 2022-06-17 02:38:53.181766
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:38:59.976068
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test SelinuxFactCollector.collect()
    """
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary to hold the collected facts
    collected_facts = {}

    # Call the collect method
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)

    # Assert that the selinux fact is present in the collected facts
    assert 'selinux' in selinux_facts

# Generated at 2022-06-17 02:39:07.741043
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector
    from ansible.module_utils.facts.collector.selinux import HAVE_SELINUX

    # Create a Collector object
    test_collector = Collector()

    # Create a SelinuxFactCollector object
    test_selinux_collector = SelinuxFactCollector()

    # Add SelinuxFactCollector object to test Collector object
    test_collector.add_collector(test_selinux_collector)

    # Collect and process facts
    test_facts = test_collector.collect(module=None, collected_facts=None)

    # Test if selinux_python_present is set to True

# Generated at 2022-06-17 02:39:29.880492
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:35.453521
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:39:42.329817
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a facts dict
    facts_dict = {}

    # Call method collect of the SelinuxFactCollector object
    selinux_facts_dict = selinux_fact_collector.collect(collected_facts=facts_dict)

    # Assert that the selinux facts dict is not empty
    assert selinux_facts_dict

# Generated at 2022-06-17 02:39:45.880850
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:39:54.048514
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:39:58.325550
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:04.621713
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:12.065867
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = Mock()

    # Create a mock collected_facts
    collected_facts = Mock()

    # Create a mock selinux library
    selinux = Mock()

    # Create a mock selinux library
    selinux_enforce = Mock()

    # Create a mock selinux library
    selinux_policyvers = Mock()

    # Create a mock selinux library
    selinux_getenforcemode = Mock()

    # Create a mock selinux library
    selinux_getpolicytype = Mock()

    # Create a mock selinux library
    selinux_enforce_return_value = Mock()

    # Create a mock selinux library
    selinux_policyvers_return_value = Mock()

    # Create a mock selinux library
    selinux_getenforcemode_return_value = Mock()

    # Create

# Generated at 2022-06-17 02:40:15.938776
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:40:18.769419
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:06.633476
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a SelinuxFactCollector object
    selinux_fact_collector = SelinuxFactCollector()

    # Create a dictionary with the expected facts
    expected_facts = {
        'selinux': {
            'status': 'disabled',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown',
            'policyvers': 'unknown'
        },
        'selinux_python_present': True
    }

    # Collect the facts
    facts = selinux_fact_collector.collect()

    # Check if the facts match the expected facts
    assert facts == expected_facts

# Generated at 2022-06-17 02:41:11.368089
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:19.354707
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    mock_module = type('AnsibleModule', (), {})

    # Create a mock selinux library
    mock_selinux = type('selinux', (), {})
    mock_selinux.is_selinux_enabled = lambda: True
    mock_selinux.security_policyvers = lambda: '28'
    mock_selinux.selinux_getenforcemode = lambda: (0, 1)
    mock_selinux.security_getenforce = lambda: 1
    mock_selinux.selinux_getpolicytype = lambda: (0, 'targeted')

    # Create a mock selinux library with missing functions
    mock_selinux_missing = type('selinux', (), {})
    mock_selinux_missing.is_selinux_enabled

# Generated at 2022-06-17 02:41:22.977462
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:41:29.100782
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:41:35.424430
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:41:47.283744
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'params': {}})()

    # Create a mock selinux library
    selinux_mock = type('selinux', (object,), {'is_selinux_enabled': lambda: True,
                                               'security_policyvers': lambda: '1.2.3',
                                               'selinux_getenforcemode': lambda: (0, 1),
                                               'security_getenforce': lambda: 1,
                                               'selinux_getpolicytype': lambda: (0, 'targeted')})()

    # Create a mock AnsibleModule object
    ansible_module_mock = type('AnsibleModule', (object,), {'params': {}})()

    # Create a mock AnsibleModuleUtilsCompat object


# Generated at 2022-06-17 02:41:55.058269
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert 'config_mode' in facts_dict['selinux']
    assert 'mode' in facts_dict['selinux']
    assert 'type' in facts_dict['selinux']

# Generated at 2022-06-17 02:41:59.769635
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:42:06.830633
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-17 02:43:31.673039
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:43:39.439606
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:43:46.253299
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present'] == True
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'

# Generated at 2022-06-17 02:43:54.223382
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create an instance of the SelinuxFactCollector class
    selinux_collector = SelinuxFactCollector()

    # Create a dictionary of facts
    facts = {}

    # Call the collect method of the SelinuxFactCollector class
    selinux_collector.collect(collected_facts=facts)

    # Assert that the selinux key is present in the facts dictionary
    assert 'selinux' in facts

    # Assert that the selinux_python_present key is present in the facts dictionary
    assert 'selinux_python_present' in facts

    # Assert that the selinux_python_present key is set to True
    assert facts['selinux_python_present'] == True

    # Assert that the status key is present in the selinux dictionary
    assert 'status' in facts['selinux']

   

# Generated at 2022-06-17 02:43:59.703921
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux library present
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux_python_present']
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']

    # Test with selinux library missing
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
   

# Generated at 2022-06-17 02:44:02.180712
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:44:07.784073
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:12.197330
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:44:16.559038
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:44:22.060046
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()