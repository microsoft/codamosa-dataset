

# Generated at 2022-06-23 12:41:14.139567
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit Test for constructor of class LookupModule
    L = LookupModule()
    assert(isinstance(L, LookupModule))

# Generated at 2022-06-23 12:41:26.647934
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    host_list = [
        'localhost',
        'local',
        'localhost.localdomain',
        'local.localdomain'
    ]

    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    lookup = LookupModule()
    lookup.set_options(direct={
        'var1': 'value',
        'var2': 'value'
    })

    result = lookup.run(terms=['var1', 'var2'], variables=variable_manager._fact_cache)

    assert result == ['value', 'value']

# Generated at 2022-06-23 12:41:31.530557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = FakeTemplar()
    ret = lookup.run(['foo'], {'foo': 'bar'})
    assert ret == ['bar'], 'failed to lookup variable'


# Generated at 2022-06-23 12:41:33.983300
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Test case for conversion of string to array

# Generated at 2022-06-23 12:41:42.252053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['variabl' + 'ename']
    variables = {'variablename': 'hello'}
    conf = {'default': None, '_raw_params': 'variablename'}

    l = LookupModule()
    l._templar = {'_available_variables': variables, 'template': template}

    assert l.run(terms, variables, **conf) == ['hello']
    assert l.run(['variabl' + 'notename'], variables, **conf) == [None]


# Generated at 2022-06-23 12:41:43.472223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:41:45.525168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:41:51.668926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance
    vars_lookup = LookupModule()
    # Try to get value of non-existing variable
    res = vars_lookup.run(['non_exist'])
    assert res == []
    # Try to get value of existing variable
    res = vars_lookup.run(['exist'])
    assert res == ['exist']

# Generated at 2022-06-23 12:42:03.339721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        "ansible_play_hosts",
        "ansible_play_batch",
        "ansible_play_hosts_all",
        "test_hostvar"
    ]
    variables = {
        "ansible_play_hosts": "a_play_hosts_list",
        "ansible_play_batch": "a_play_batch_list",
        "ansible_play_hosts_all": "a_play_hosts_all_list",
        "inventory_hostname": "localhost",
        "hostvars": {
            "localhost": {
                "test_hostvar": 1
            }
        }
    }

# Generated at 2022-06-23 12:42:09.230577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = 'variablename'
    variables = {
        variablename: "hello",
        myvar: "ename",
    }
    lm.set_options(var_options=variables, direct=kwargs)
    assert lm.run == [ 'hello' ]

# Generated at 2022-06-23 12:42:18.076954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an object of the class LookupModule
    lookupModule = LookupModule()
    # Test if run function return a list
    assert isinstance(lookupModule.run('terms'), list)
    # Test if run function return a list of string
    assert isinstance(lookupModule.run('terms', 'variables'), list)
    # Test if run function raise an error if the argument is no a string
    assert isinstance(lookupModule.run(1, 'variables'), list)
    # Test if run function raise an error if the argument is no a list of string
    assert isinstance(lookupModule.run('terms', 1), list)

# Generated at 2022-06-23 12:42:29.779035
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock a dict as variables
    variables = {
        'test_var_1': 'first variable',
        'test_var_2': 'second variable',
        'test_var_3': 'third variable'
    }

    # Create mock of an AnsibleModule (from ansible.module_utils.basic)
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Create mock of a Templar (from ansible.parsing.templar)
    from ansible.parsing.templar import Templar
    templar = Templar(loader=None, variables=variables)
    templar._available_variables = variables # needed by this code...
    module.params = dict()

    # Create mock of a LookupBase

# Generated at 2022-06-23 12:42:31.881618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-23 12:42:42.590489
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:42:43.629384
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:42:55.607697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.become = False
            self.become_method = None
            self.become_user = None
            self.check = False
            self.diff = False

    class PlayContext(object):
        pass

    # Define test data
    lookup_data = {'variablename': 'hello', 'myvar': 'ename'}
    lookup_data2 = {'variablename': {'sub_var': 12}, 'myvar': 'ename'}

# Generated at 2022-06-23 12:43:02.576286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    #Test for undefined variable
    term = 'undefined_variable'
    variables = {}
    default = 'Default value for %s' % term
    result = lookup.run([term],variables=variables,default=default)
    assert result[0] == default

    #Test for defined variable
    term = 'define_variable'
    define_variable = 'Defined variable'
    variables = {term:define_variable}
    default = 'Default value for %s' % term
    result = lookup.run([term],variables=variables,default=default)
    assert result[0] == define_variable

# Generated at 2022-06-23 12:43:13.582248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    import os

    # create a dummy lookup module
    lookup_module = LookupModule()
    lookup_module._loader = None
    lookup_module._templar = Templar(loader=None, variables={'myvar': 'name'})

    # testing
    assert lookup_module.run(['variablename']), ['hello']

    assert lookup_module.run(['variabl' + lookup_module._templar.template("{{ myvar }}", fail_on_undefined=True)]), ['hello']

    assert lookup_module.run(['variablnotename'], default=''), ['']

    assert os.system("ansible localhost -i localhost.inv -c local -m debug -a 'msg=\"{{ lookup(\"vars\", \"variablnotename\")}}\"'")

# Generated at 2022-06-23 12:43:24.474532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.plugins.lookup.vars import LookupModule

    obj = LookupModule()
    terms = ['variablename']

    myvars = {
        'variablename': 'hello',
        'inventory_hostname': 'localhost',
        'hostvars': {
            'localhost': {
                'variablenotename': 'hello'
            }
        }
    }
    ret = obj.run(terms, variables=myvars)
    assert ret[0] == 'hello'

    terms = ['variablenotename']
    ret = obj.run(terms, variables=myvars)
    assert ret[0] == ''


# Generated at 2022-06-23 12:43:28.342595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    term_variable = 'term_variable'
    variables = {'term_variable': 'test_lookup_module'}
    assert term_variable in variables
    assert variables['term_variable'] == 'test_lookup_module'


# Generated at 2022-06-23 12:43:38.187843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar.available_variables = {}
    lm._templar._available_variables = {}
    assert lm.run(["test"], {}) == [None]
    lm._templar._available_variables = {"test": 'test'}
    assert lm.run(["test"], {}) == ["test"]
    lm._templar.available_variables = {'inventory_hostname': 'test', 'hostvars': {'test': {'test': 'test'}}}
    assert lm.run(["test"], {}) == ['test']

# Generated at 2022-06-23 12:43:40.682495
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Create a LookupModule object and do a simple test.
    """

    lookup_plugin = LookupModule()

    assert lookup_plugin is not None

# Generated at 2022-06-23 12:43:41.790054
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:43:46.013970
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test that LookupModule() is an instance of class LookupBase
    # is also tested in test_lookup_plugins, but that's a good idea to test it again here
    assert issubclass(LookupModule, LookupBase)
    assert isinstance(LookupModule, type)

# Generated at 2022-06-23 12:43:58.728997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.templating import Templar
    import pytest

    class FakePlaybook:
        def __init__(self):
            self.vars = dict(
                    common_var = dict(),
                    inventory_hostname = 'fake_inventory_hostname'
            )

    class FakeHost:
        def __init__(self,name):
            self.name = name
            self.vars = dict()

        def get_name(self):
            return self.name

    class FakeInventory:
        def __init__(self):
            self.hosts = dict()
            host1 = FakeHost

# Generated at 2022-06-23 12:43:59.288940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:44:00.669967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    vars_lookup = LookupModule()
    assert vars_lookup

# Generated at 2022-06-23 12:44:06.219771
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  expected = 'AnsibleError'
  try:
    lookup.run(terms=[1], variables=None, **{})
  except Exception as e:
    if e.__class__.__name__ == expected:
      pass
    else:
      raise Exception( '%s raised instead of %s' % (e.__class__.__name__, expected))
  else:
    raise Exception('Exception not raised')
    

# Generated at 2022-06-23 12:44:07.348091
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module,LookupModule)

# Generated at 2022-06-23 12:44:12.860649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_var1'}
    lookup_module._templar.template = lambda x, fail_on_undefined: x
    assert lookup_module.run(['test_var'], None) == ['test_var1']

# Generated at 2022-06-23 12:44:24.933539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest
    from .mock import Mock, patch

    # setup mock object for templar
    templar = Mock()
    templar.template.side_effect = lambda x: x
    templar._available_variables = {
        'foo': 'bar',
        'hostvars': {
            'host1': {
                'hostvar': 'hostvalue',
             }
        }
    }
    templar.available_variables = templar._available_variables

    # test lookupmodule and unittest
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule().run([None])
    assert 'is not a string' in str(excinfo.value)


# Generated at 2022-06-23 12:44:36.350637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'default': 'default_value'})

    # Test case when key in myvars
    terms = ['key']
    myvars = {'key': 'value'}
    variables = {'key': 'value'}
    result = lookup_module.run(terms, variables)
    assert(result == ['value'])

    # Test case when key not in myvars
    myvars = {'key': 'value'}
    variables = {}
    result = lookup_module.run(terms, variables)
    assert(result == ['default_value'])

    # Test case when key not in myvars and no default
    lookup_module.set_options({})
    result = lookup_module.run(terms, variables)

# Generated at 2022-06-23 12:44:43.903623
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Instantiate LookupModule
    lookup_module = LookupModule()

    # Define input
    terms = ['variable_name']
    variables = {'variable_name': 'VariableValue'}

    # Test with valid input
    assert lookup_module.run(terms, variables) == ['VariableValue']
    # Test with invalid input
    assert lookup_module.run(terms) == []
    assert lookup_module.run(terms, variables, default='Default') == ['Default']

# Generated at 2022-06-23 12:44:52.865355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = "DUMMY_TEMPLAR"

    # Unit test for method run when terms is not a string
    terms = ["A", "B", "C"]
    lookup_module.run(terms=terms)

    terms = {'A': 'B'}
    lookup_module = None
    try:
        lookup_module = LookupModule()
        lookup_module._templar = "DUMMY_TEMPLAR"
        lookup_module.run(terms=terms)
    except Exception as e:
        assert type(e) == AnsibleError
        assert e.args[0] == 'Invalid setting identifier, "A" is not a string, its a <type \'dict\'>'

# Generated at 2022-06-23 12:45:05.228144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    import pytest
    templar = Templar(loader=None, variables={})

    # test_dict_variable
    lookup = LookupModule(loader=None, templar=templar, shared_plugin_loader_ctx={}, basedir='/')
    terms = ['dict_variable', 'hostvars[inventory_hostname].dict_variable']
    variables = {'dict_variable': {'sub_var': '12'},
                 'inventory_hostname': 'test'}
    values = lookup.run(terms, variables)
    assert values == [{'sub_var': '12'}, {'sub_var': '12'}]

    # test_array_variable

# Generated at 2022-06-23 12:45:08.020923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.get_option('default') is None
    assert lookup_module.get_option('var_options') is None


# Generated at 2022-06-23 12:45:17.454491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = []
    kwargs = {"default":""}

    ###############################
    # test with incorrect terms list
    terms = [ {"hello": "world"} ]
    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(terms, **kwargs)
    assert 'is not a string' in str(excinfo.value)

    ###############################
    # test with undefined var
    terms = ["my_undefined_var"]
    with pytest.raises(AnsibleUndefinedVariable) as excinfo:
        lookup.run(terms, **kwargs)

    ###############################
    # test with defined var
    terms = ["my_var_to_lookup"]

# Generated at 2022-06-23 12:45:17.979041
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-23 12:45:27.156849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with valid terms and variables
    terms = ['ansible_os_family', 'ansible_distribution']
    variables = dict()
    variables['ansible_os_family'] = 'RedHat'
    variables['ansible_distribution'] = 'CentOS'

    ret = lookup_module.run(terms=terms, variables=variables)

    if not isinstance(ret, list):
        raise AssertionError('Expected returned type is list, got ' + str(type(ret)))

    if ret[0] != 'RedHat':
        raise AssertionError('Expected lookup result is RedHat, got ' + ret[0])
    if ret[1] != 'CentOS':
        raise AssertionError('Expected lookup result is CentOS, got ' + ret[1])

   

# Generated at 2022-06-23 12:45:35.291300
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create an instance of LookupModule
    myLookupModule = LookupModule()

    # Have a string variable with the default 'default' value
    terms = "inventory_hostname"

    # Have a list with the default 'variables' value
    variables = [ "192.168.1.1", "192.168.1.2" ]

    # Pass the parameters to the method 'run'
    result = myLookupModule.run(terms, variables)

    # Check if the variables are the same, it will return a boolean variable true
    assert terms is variables


# Generated at 2022-06-23 12:45:38.303868
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    # Verify if the constructor of class LookupModule set the attributes correctly
    assert lm.get_option('var_options') == None
    assert lm.get_option('direct') == None

# Generated at 2022-06-23 12:45:39.796449
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:45:49.195187
# Unit test for constructor of class LookupModule
def test_LookupModule():
   # Create instance of LookupModule
   lookup_instance = LookupModule()
   # Call run method of LookupModule
   # If a NameError is raised, fail the test
   try:
       lookup_instance.run(['ansible_inventory'])
   except NameError:
       fail_test = True

   # If the test fails, show an error message and exit the test
   # Otherwise, the test has been passed
   if fail_test:
       print ('ERROR: LookupModule.run() failed!')
       sys.exit()
   else:
       print ('SUCCESS: LookupModule.run() pass!')
       sys.exit()

# Generated at 2022-06-23 12:45:52.340653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    test_terms = {'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'}
    lookup_module.run(test_terms)
    return True

# Generated at 2022-06-23 12:45:56.924736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.vars = { "myvar": "hello world", "test": [1,2,3,4,5] }
    assert l.vars["myvar"] == "hello world"
    assert l.vars["test"][2] == 3


# Generated at 2022-06-23 12:46:04.894999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule.run() Unit test
    """

    # Unit test for method run of class LookupModule with args
    # {'terms': ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], 'variables': {'ansible_play_hosts': [u'localhost'], 'ansible_play_batch': None, 'ansible_play_hosts_all': [u'localhost']}}
    # and return value {'ansible_play_batch': None, 'ansible_play_hosts_all': [u'localhost'], 'ansible_play_hosts': [u'localhost']}

# Generated at 2022-06-23 12:46:15.784922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    # Create unit test environment for LookupModule class
    test_obj = LookupModule()

    # Define variables for testing method run of class LookupModule
    terms1 = ['variablename', 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables1 = {'variablename': 'hello', 'ansible_play_hosts': 'localhost', 'ansible_play_batch': 'batch1', 'ansible_play_hosts_all': 'localhost'}
    default1 = None

    terms2 = ['variablename', 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

# Generated at 2022-06-23 12:46:18.281944
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _lookup = LookupModule()
    assert(_lookup != None)


# Generated at 2022-06-23 12:46:23.985360
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test init, with no arguments
    lm = LookupModule()
    assert(lm is not None)

    # Test init, with an argument
    lm = LookupModule({'a variable name': 'a value'}, {}, {'_ansible_no_log': False, '_ansible_verbosity': 0})
    assert(lm is not None)



# Generated at 2022-06-23 12:46:27.021735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        if LookupModule is None:
            assert False, "could not import LookupModule"
    except:
        print("lookup_plugins/vars.py not found")

# Generated at 2022-06-23 12:46:31.027610
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookupModule = LookupModule()
    myLookupModule._templar.available_variables = {}
    myLookupModule.set_options(var_options=None, direct=None)

# Generated at 2022-06-23 12:46:37.608618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible import context, module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    context.CLIARGS = {}
    lookup = LookupModule()
    lookup.set_loader(loader)
    return lookup

# Generated at 2022-06-23 12:46:39.268317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:46:41.802739
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with arguments
    assert isinstance(LookupModule(loader=None, templar=None, shared_loader_obj=None), LookupModule)
    # Test without arguments
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:46:50.062997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookupModule = LookupModule()

    # Create a templar object
    templar = lookupModule._templar

    # Set a variable in object templar
    templar._available_variables = {'my_name': {'first_name': 'Ansible', 'last_name': 'Tower'}}

    # Define terms
    terms = ['first_name']
    variables = None
    kwargs = {}

    # Test the run method of lookupModule
    assert lookupModule.run(terms, variables, **kwargs) == ['Ansible']

# Generated at 2022-06-23 12:47:00.967153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible import context

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='localhost')

    host = inv_manager.get_host("localhost")
    host.vars = {"hostvar": {"host_var1": "host_var1_value"}}

    play_context = PlayContext(remote_addr='127.0.0.1')
    tqm = None
    playbook = Play().load({}, loader=loader, variable_manager=VariableManager(loader=loader, inventory=inv_manager),
                           loader=loader)


# Generated at 2022-06-23 12:47:11.593964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

# Generated at 2022-06-23 12:47:24.141571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Test to create instance of LookupModule class
    LookupModule_instance = LookupModule()

    #Test to raise exception if terms is not a string type
    try:
        LookupModule_instance.run(variables=None, terms=None, **{})
    except AnsibleError as e:
        if "Invalid setting identifier, \"%s\"" % (type(None)) in str(e):
            pass
        else:
            raise

    #Test to raise exception if default is not set and desired variable is not present
    try:
        LookupModule_instance.run(variables={"variablename": "hello"}, terms=["va"], **{})
    except AnsibleUndefinedVariable as e:
        if "No variable found with this name: va" in str(e):
            pass
        else:
            raise

   

# Generated at 2022-06-23 12:47:25.713935
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None, "LookupModule() failed"

# Generated at 2022-06-23 12:47:32.622162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test method run of class LookupModule
    # Scenario: Create LookupModule object, set some variables and test method run
    # Create LookupModule object
    lo = LookupModule()
    # Create dict with variables
    variables = {"foo": "bar" }
    # Set variables
    lo._templar.available_variables = variables
    myvars = getattr(lo._templar, '_available_variables', {})
    # Set option default
    default = 'None'
    lo.set_options(var_options=variables, direct={'default':default})
    # Test method run of class LookupModule
    terms=['foo']
    # Variable foo has value bar. I expect to return ['bar']
    assert lo.run(terms) == ['bar']
    # Now set variable foo to value 'None

# Generated at 2022-06-23 12:47:34.415029
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:47:41.904466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_subject = LookupModule()
    terms = ['a', 'b']
    variables = {'a': 1, 'b': 2}
    result = test_subject.run(terms, variables)
    assert result == [1, 2]
    # Test with a variable that is not present
    terms = ['a', 'c']
    default = 2
    result = test_subject.run(terms, variables, default=default)
    assert result == [1, 2]
    # Test with a variable that is nested
    terms = ['a', 'b', 'c', 'd']
    variables = {'a': 1,
                 'b': {'c': {'d': 3}}}
    result = test_subject.run(terms, variables)

# Generated at 2022-06-23 12:47:43.116441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: use mock
    pass

# Generated at 2022-06-23 12:47:46.429890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # This is not possible with the current unit test setup, as the LookupModule object always seems to be created with two parameters...
    assert lookup

# Generated at 2022-06-23 12:47:47.663987
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:47:53.603090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert len(lm.run(terms=['local', 'variables'],
                  variables={},
                  remote_user='root',
                  remote_password='password')) == 2
    assert len(lm.run(terms=['local', 'variables', 'not_there'],
                  variables={},
                  remote_user='root',
                  remote_password='password')) == 3

# Generated at 2022-06-23 12:48:03.798235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # case 1 test with term 'ansible_play_hosts_all'
    terms = ['ansible_play_hosts_all']

# Generated at 2022-06-23 12:48:05.764403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run("variablename", {"variablename": "hello"})

# Generated at 2022-06-23 12:48:17.372398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test_LookupModule_run : return value for the first element without default
    test_subject = ['ansible_play_hosts_all']
    result = lookup.run(test_subject, magic_variable_precedence, [])
    assert result == ['localhost']

    # test_LookupModule_run : return value for the second element without default
    test_subject = ['ansible_play_hosts_all', 'ansible_play_hosts']
    result = lookup.run(test_subject, magic_variable_precedence, [])
    assert result == ['localhost', 'localhost']

    # test_LookupModule_run : return default value for the third element

# Generated at 2022-06-23 12:48:27.491822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class LookupModule(object):

        def __init__(self, test_obj):
            if self.__class__.__bases__ != ():
                self._templar = test_obj


    class test_obj(object):
        def __init__(self):
            self._available_variables = {'variable1': 'hello', 'hostvars': {'test': {'variable2': 'world'}}}

    test_Lookup = LookupModule(test_obj())
    ret = test_Lookup.run(['variable1'])
    assert ret == ['hello']
    ret = test_Lookup.run(['variable2'])
    assert ret == ['world']
    ret = test_Lookup.run(['variable1', 'variable2'])
    assert ret == ['hello', 'world']

# Generated at 2022-06-23 12:48:28.469735
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:48:36.693055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.set_options(var_options={'inventory_hostname': 'localhost'})

    # Test invalid terms
    invalid_terms = [1, ['one', 'two', 3.14], object()]
    for invalid_term in invalid_terms:
        try:
            mod.run([invalid_term])
        except AnsibleError as e:
            assert 'Invalid setting identifier' in str(e)
        else:
            assert False, 'Run with invalid term "%s" should raise AnsibleError' % str(invalid_term)

    # Test with default
    default_value = 'a default value'
    assert mod.run(['my_invalid_var'], default=default_value) == [default_value]

# Generated at 2022-06-23 12:48:39.467863
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_class = LookupModule()
    assert test_class is not None
    assert test_class.get_option('default') is None

# Generated at 2022-06-23 12:48:44.501170
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    # We can't use assertIsInstance because the LookupModule class is a dynamic
    # class that is defined by modules/action_plugins/lookup.py and we only have
    # access to the LookupModule class after it is defined.
    assert isinstance(module, LookupModule)


# Generated at 2022-06-23 12:48:53.311343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run method with undefined variables
    def run1(cls, terms, variables=None, **kwargs):
        if variables is not None:
            cls._templar.available_variables = variables
        myvars = getattr(cls._templar, '_available_variables', {})

        cls.set_options(var_options=variables, direct=kwargs)
        default = cls.get_option('default')

        ret = []
        for term in terms:
            if not isinstance(term, string_types):
                raise AnsibleError('Invalid setting identifier, "%s" is not a string, its a %s' % (term, type(term)))


# Generated at 2022-06-23 12:48:54.272048
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:49:00.799695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        class Test_LookupModule(LookupBase):
            def run(self, terms, variables=None, **kwargs):
                return []
        tlm = Test_LookupModule()
        tlm.set_options({'_create_terms': True})
        tlm.set_options({'_loaded_by': "test_unittest"})
        tlm.set_options({'_ansible_check_mode': True})
        ret = tlm.run()
        print(ret)
    except Exception as e:
        print(e)

# Generated at 2022-06-23 12:49:04.530412
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule('vars', terms='hostvars')
    assert result == ["{{ lookup('vars', 'hostvars') }}"]


# Generated at 2022-06-23 12:49:13.685116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ..test.test_lookup_plugins import MockVarsModule
    lm = LookupModule()
    lm.set_loader(MockVarsModule())
    # success
    lm._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lm.run(['variablename']) == ['hello']
    # failure
    lm._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    try:
        assert lm.run(['variablenotename']) == ['']
    except AnsibleUndefinedVariable:
        pass


# Generated at 2022-06-23 12:49:26.218521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.errors import AnsibleError
    import yaml

    # test error in case of non-string identifiers
    with pytest.raises(AnsibleError):
        terms = [{'ansible': 'hi'}]
        lookupmock = LookupModule()
        lookupmock.run(terms, variables={'ansible': 'hi'})

    myvar = 'ansible'
    terms = ['ansible']
    lookupmock = LookupModule()
    assert lookupmock.run(terms, variables={'ansible': 'hi'}) == ['hi']

    # test error in case of missing variable
    with pytest.raises(AnsibleUndefinedVariable):
        terms = ['not in vars']
        lookup

# Generated at 2022-06-23 12:49:29.627562
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Unit tests of class LookupModule init methods:
    # default and kwarg_only - both are expected to raise an exception
    lookup = LookupModule()
    lookup.set_options(direct={})

# Generated at 2022-06-23 12:49:35.193967
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

    terms = [0, 'hi', {'a': 1}, ['a', 1]]
    for term in terms:
        assert not isinstance(term, string_types)
        assert not l.is_valid_term(term)

    terms = [1, None, 'a', 'a1', 'a.b']
    for term in terms:
        if isinstance(term, string_types):
            assert l.is_valid_term(term)
        else:
            assert not l.is_valid_term(term)

# Generated at 2022-06-23 12:49:42.649520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_vars = {
        'ip_address': '10.10.10.10',
        'hostname': 'testhost'
    }
    terms = ['ip_address', 'hostname']
    test_instance = LookupModule()
    result = test_instance.run(terms, test_vars)

    assert len(result) == 2
    assert result[0] == '10.10.10.10'
    assert result[1] == 'testhost'


# Generated at 2022-06-23 12:49:43.848606
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:49:53.797373
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    module_arg_spec = dict(
        _terms=dict(type='list', required=True),
        default=dict()
    )

    terms = ['variablename']
    variables = {'variablename': 'hello'}
    options = {'default': None, 'fail_on_undefined': True}
    templar = AnsibleMock()
    templar._available_variables = {'variablename': 'hello'}

    # Act
    lookup_module_instance = LookupModule(loader=None, templar=templar, **options)

    # Act
    ret = lookup_module_instance.run(terms, variables)

    # Assert
    assert(ret == ['hello'])



# Generated at 2022-06-23 12:50:00.784564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.vars
    mylookup = ansible.plugins.lookup.vars.LookupModule()
    mylookup.run([])
    assert False, "Should never reach line."

if __name__ == '__main__':
    import ansible.plugins.lookup.vars
    mylookup = ansible.plugins.lookup.vars.LookupModule()
    results = mylookup.run(['hostname'], variables={'hostname': 'localhost'})
    print(results)
    assert results[0] == 'localhost'

    results = mylookup.run(['variablename'], variables={'variablename': 'hello'})
    print(results)
    assert results[0] == 'hello'


# Generated at 2022-06-23 12:50:11.255754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import string_types

    # Create a fake host object
    HOST_NAME_1 = 'testhost1'
    VAR_NAME_1 = 'testvar1'
    VAR_VALUE_1 = 'testvalue1'
    VAR_NAME_2 = 'testvar2'
    VAR_VALUE_2 = 'testvalue2'
    HOST_NAME_3 = 'testhost2'
    VAR_NAME_3 = 'testvar3'
    VAR_VALUE_3 = 'testvalue3'

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

    host_

# Generated at 2022-06-23 12:50:21.092114
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test constructor succeeds with no parameters
    tempClass = LookupModule()

    # Test constructor generates AnsibleError if not passed a valid term
    try:
        tempClass.run(terms = 20)
        test = False
    except AnsibleError:
        test = True
    assert(test)

    # Test constructor generates AnsibleError if not passed a valid term
    try:
        tempClass.run(terms = 20)
        test = False
    except AnsibleError:
        test = True
    assert(test)

    # Test constructor returns a list
    try:
        out = tempClass.run(terms = [])
        test = True
    except AnsibleError:
        test = False
    assert(test)
    assert(isinstance(out, list))

    # Test constructor returns a list of the right size

# Generated at 2022-06-23 12:50:22.612202
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:50:28.958044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._templar._available_variables = {'test_var': "test_value"}
    assert lookup_module.run(['test_var'], None) == ["test_value"]
    assert lookup_module.run(['test_var2'], None) == []
    assert lookup_module.run(['test_var2'], None, default="test_default") == ["test_default"]

# Generated at 2022-06-23 12:50:29.866492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:50:41.813268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l=LookupModule()
    terms=[]
    terms.append('hostvars[inventory_hostname][\'ansible_mounts\']')
    terms.append('hostvars[inventory_hostname][\'ansible_architecture\']')
    terms.append('hostvars[inventory_hostname][\'ansible_kernel\']')
    terms.append('hostvars[inventory_hostname][\'ansible_os_family\']')
    terms.append('hostvars[inventory_hostname][\'ansible_selinux\']')
    terms.append('hostvars[inventory_hostname][\'ansible_distribution\']')
    terms.append('hostvars[inventory_hostname][\'ansible_distribution_major_version\']')

# Generated at 2022-06-23 12:50:45.117028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule(None)
  terms = 'inventory_hostname'
  variables = {'inventory_hostname': 'abc'}
  l.set_options(var_options=variables, direct={})
  value = l.run(terms, variables=variables, **{})
  assert value == ['abc'], value

# Generated at 2022-06-23 12:50:55.615840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    myvar = 'something'
    mylist = ['something']
    mynumber = 123
    mybool = True

    test_subject = LookupModule()
    test_subject.set_loader(None)
    test_subject._templar = Templar(None, variables={'myvar': myvar, 'mylist': mylist, 'mynumber': mynumber, 'mybool': mybool})

    result = test_subject.run(['myvar'])
    assert result[0] == 'something'

    result = test_subject.run(['myvar', 'mynumber'])
    assert result[0] == 'something'
    assert result[1] == 123


# Generated at 2022-06-23 12:51:05.087247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test to make sure this doesn't blow up
    lookup_plugin = LookupModule()
    lookup_plugin.run([], variables={'a': 1, 'b': {'c': 2}})
    assert lookup_plugin.run([], variables={'a': 1, 'b': {'c': 2}}) == []
    assert lookup_plugin.run(['a'], variables={'a': 1, 'b': {'c': 2}}) == [1]
    assert lookup_plugin.run(['a', 'b'], variables={'a': 1, 'b': {'c': 2}}) == [1, {'c': 2}]

# Generated at 2022-06-23 12:51:17.517496
# Unit test for method run of class LookupModule
def test_LookupModule_run():


	class MockTemplar(object):
		pass

	class MockVariables(object):
		pass

	mocktemplar = MockTemplar()
	mocktemplar.template = lambda x,y: x
	mockvariables = MockVariables()
	mockvariables._available_variables = {
		'hostvars': {
			'inventory_hostname': {
				'ansible_play_hosts': 'ansible_play_hosts',
				'ansible_play_batch': 'ansible_play_batch',
				'ansible_play_hosts_all': 'ansible_play_hosts_all',
			}
		},
		'inventory_hostname': 'inventory_hostname'
	}

