

# Generated at 2022-06-23 12:41:28.775852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make sure the class is instanciated and has the _templar attribute
    assert (isinstance(LookupModule(), LookupModule))
    assert (hasattr(LookupModule(), '_templar'))

    # Test module not callable with bad arguments
    try:
        LookupModule().run(terms={"a": "key"})
        assert False
    except AnsibleError:
        pass
    try:
        LookupModule().run(terms=[10, 20, 30])
        assert False
    except AnsibleError:
        pass

    # Test module callable with good arguments
    assert LookupModule().run(terms=["a"]) == [None]

    # Test module callable with default value
    assert LookupModule().run(terms=["a"], default="plop") == ["plop"]

    # Test

# Generated at 2022-06-23 12:41:40.148425
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys

    vars = {
        'ansible_play_hosts':'a',
        'ansible_play_batch':'b',
        'ansible_play_hosts_all':'c',
        'ansible_play_hosts_all1':'d',
        'hello': 'world',
        'hostvars': {
            'testhost': {
                'myvar': 'foobar'
            }
        }
    }

    myclass = sys.modules['ansible.plugins.lookup.vars']
    myobj = myclass.LookupModule()

    myobj.templar = None
    myobj.templar._available_variables = vars

    # First test

    # myvars contains 4 elements
    # ansible_play_hosts, ansible_play_

# Generated at 2022-06-23 12:41:42.781033
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # assert that the constructor did not fail
    assert lookup_module is not None

# Generated at 2022-06-23 12:41:43.768826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-23 12:41:44.831571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule
    lookup = lookup_class()

# Generated at 2022-06-23 12:41:57.839196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''
    lu = LookupModule()

    # attempt accessing with no variables, should error
    try:
        lu.run(["foo"])
    except AnsibleUndefinedVariable:
        pass
    else:
        raise AssertionError("No variables provided to lookup but did not error")

    # attempt accessing with variables, none set
    params = {'variables': {}}
    try:
        lu.run(["foo"], **params)
    except AnsibleUndefinedVariable:
        pass
    else:
        raise AssertionError("Variables provided to lookup but did not error")

    # normal access
    params = {'variables': {'foo': 'bar'}}

# Generated at 2022-06-23 12:41:59.232764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    l = LookupModule()
    assert l is not None



# Generated at 2022-06-23 12:42:00.637510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if __name__ == '__main__':
        test_LookupModule()

# Generated at 2022-06-23 12:42:01.586288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module


# Generated at 2022-06-23 12:42:09.695440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(var_options=None, direct=None)
    assert l.get_option('default') is None
    l.set_options(var_options=None, direct=dict(default=None))
    assert l.get_option('default') is None
    l.set_options(var_options=None, direct=dict(default='test'))
    assert l.get_option('default') == 'test'

# Generated at 2022-06-23 12:42:20.160709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    m._templar = DummyTemplar()

# Generated at 2022-06-23 12:42:21.717628
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        return LookupModule()
    except:
        return 'Error'

# Generated at 2022-06-23 12:42:30.865144
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()
    lookup_mod._templar = {}
    lookup_mod._templar._available_variables = {'hostvars': {'localhost': {'hostvar': 'hostvarvalue'}}}

    assert lookup_mod.run(terms=['hostvar']) == ['hostvarvalue']
    assert lookup_mod.run(terms=['unknownvar'], variables={'unknownvar': 'unknownvalue'}) == ['unknownvalue']
    assert lookup_mod.run(terms=['unknownvar'], variables={'unknownvar': 'unknownvalue'}, default='') == ['']

# Generated at 2022-06-23 12:42:39.481565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

# Generated at 2022-06-23 12:42:40.624433
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 12:42:41.524719
# Unit test for constructor of class LookupModule
def test_LookupModule():
	lm = LookupModule()
	assert lm.get_option('default') == None

# Generated at 2022-06-23 12:42:53.940740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test data
    terms_data=['sub_var','sub_var','sub_var','sub_var','sub_var','sub_var','sub_var','sub_var','sub_var']
    variables_data={"variablename": {"sub_var": "12"}, "myvar": "ename", "variablnotename": "", "ansible_play_hosts": [], "ansible_play_batch": [], "ansible_play_hosts_all": []}
    kwargs_data={'default':{'sub_var': '12'}}

    # LookupModule object
    lookup_data = LookupModule()

    # Actual result for test data
    terms = terms_data
    variables = variables_data
    kwargs = kwargs_data

# Generated at 2022-06-23 12:43:02.873190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupPlugin = LookupModule()
    terms = ['vars', 'variabl' + 'myvar']
    variables = {'vars': 'hello', 'myvar': 'ename'}
    default = None
    result = lookupPlugin.run(terms, variables, default)
    assert result == ['hello']
    try:
        lookupPlugin.run(['vars', 'variablnotename'], {'vars': 'hello', 'myvar': 'notename'})
    except AnsibleUndefinedVariable:
        assert True
    terms = ['vars', 'variabl' + 'myvar']
    variables = {'vars': 'hello', 'myvar': 'notename'}
    default = None

# Generated at 2022-06-23 12:43:13.429284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.set_options(var_options={"inventory_hostname": "test"}, direct={"fail_on_undefined": True})

    # Check if a variable is defined
    data = lm.run(["inventory_hostname"], variables={"inventory_hostname": "test"})
    assert data == ["test"]

    try:
        data = lm.run(["undefined"], variables={"inventory_hostname": "test"})
    except AnsibleUndefinedVariable as e:
        assert "undefined" in str(e)

    # Check if a variable is defined with a default value
    data = lm.run(["undefined"], default="test", variables={"inventory_hostname": "test"})
    assert data == ["test"]

# Generated at 2022-06-23 12:43:24.473621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple variable
    module = LookupModule()
    module._templar = FakeTemplar()
    terms = ['foo']
    results = module.run(terms)
    assert results == ['bar']

    # Test with a nested variable
    module = LookupModule()
    module._templar = FakeTemplar()
    terms = ['foobar']
    results = module.run(terms)
    assert results == ['baz']

    # Test with several variables
    module = LookupModule()
    module._templar = FakeTemplar()
    terms = ['foo', 'foobar']
    results = module.run(terms)
    assert results == ['bar', 'baz']

    # Test with undefined variable
    module = LookupModule()
    module._templar = FakeTemplar()


# Generated at 2022-06-23 12:43:32.091753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    templar = DummyTemplar()

    lookup_mod = LookupModule()
    # Inject the dummy templar
    lookup_mod._templar = templar

    terms = ['variablename']
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    expected_result = ['hello']
    result = lookup_mod.run(terms=terms, variables=variables)

    assert result == expected_result
    assert templar.available_variables == variables


# Generated at 2022-06-23 12:43:44.241408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.vars import LookupModule

    lookup_module = LookupModule()
    lookup_module.set_loader('/fake')
    myvars = {
        'variablename': 'hello',
        'ansible_play_hosts': 'hosts',
        'ansible_play_batch': 'batch',
        'ansible_play_hosts_all': 'hosts_all',
        'hostvars': {
            'fake_hostname': {
                'sub_var': 12
            }
        },
        'inventory_hostname': 'fake_hostname'
    }
    assert lookup_module.run(['variablename'], myvars) == ['hello']
    assert lookup_module.run(['variablnotename'], myvars) == []


# Generated at 2022-06-23 12:43:51.970107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with the terms = 'localhost' and 'ansible_play_hosts' as arguments
    # Test with the term = 'localhost'
    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    results = lookup.run(terms=['localhost'], variables=my_variables)
    assert results == ['127.0.0.1']
    # Test with the terms = 'localhost', 'ansible_play_hosts' and the option direct = {}
    results = lookup.run(terms=['localhost', 'ansible_play_hosts'], variables=my_variables)
    assert results == ['127.0.0.1', ['127.0.0.1', '127.0.0.2']]

# Generated at 2022-06-23 12:43:55.293234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None
    assert isinstance(lm, LookupModule)

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-23 12:44:05.704818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModuleForTest():
        def __init__(self, terms, variables=None, **kwargs):
            self.terms = terms
            self.variables = variables
            self.kwargs = kwargs

        def run(self, templar):
            return LookupModule.run(self, templar, self.terms, self.variables, self.kwargs)

    from ansible import context
    from ansible.vars import combine_vars
    from ansible.template import Templar
    from ansible.module_utils.six import BytesIO

    terms = 'test_term'

# Generated at 2022-06-23 12:44:18.363065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all', 'ansible_play_hosts_all']
    lookup = LookupModule()

    # Test undefined variables
    try:
        lookup.run(terms)
    except AnsibleError as e:
        assert str(e) == 'No variable found with this name: ansible_play_hosts'

    # Test defined variables
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    result = lookup.run(terms)
    assert result == ['all', 1, ['localhost']]

    # Test default value

# Generated at 2022-06-23 12:44:31.528519
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.utils.unsafe_proxy import ansible_unsafe_proxy_dict
    lookup = LookupModule()
    terms = ['hostvars', 'inventory_hostname', 'host']
    variables = ansible_unsafe_proxy_dict({
        'hostvars': {'my_host': {'host': 'my_host'}},
        'inventory_hostname': 'my_host',
    })
    results = lookup.run(terms, variables)
    assert results == ['my_host', 'my_host', 'my_host']

    class AnsibleUndefinedFailure(Exception):
        pass

    terms = ['hostvars', 'inventory_hostname', 'host_unknown']
    lookup.run(terms, variables)

# Generated at 2022-06-23 12:44:41.339707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_mock_templar(self):
        return MockedTemplar()
    LookupBase.set_loader = None
    LookupBase._get_loader = None
    LookupBase.get_loader = None
    LookupBase._templar = MockedTemplar()
    LookupBase._templar.template = get_mock_templar
    obj = LookupModule()
    terms = {'a':'Test', 'b':'2', 'test':'Hello world', 'myvar':'vars'}
    ret = obj.run(terms, terms)
    assert ret == ['Test', '2', 'Hello world', 'vars']

# Generated at 2022-06-23 12:44:42.465314
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module

# Generated at 2022-06-23 12:44:52.321997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.constants as C

    class DummyLookupModule(LookupModule):
        def __init__(self, source):
            self.source = source

        def _load_name(self, name):
            return self.source

        def get_basedir(self, task_vars=None):
            return C.DEFAULT_BASEDIR

    #
    # Tests
    #
    lookup_module = DummyLookupModule({'myvar': 'hello'})
    result = lookup_module.run(['myvar'])
    assert result == ['hello']

    # result is already a list
    result = lookup_module.run(['myvar', 'other'])
    assert result == ['hello', []]

    # no variables found
    result = lookup_module.run(['unknownvar'])

# Generated at 2022-06-23 12:45:04.600712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options({'default': ''})

    # Test with a variable that is defined
    assert l.run(['variablename'], {'variablename': 'hello'}) == ['hello']

    # Test with a variable that is undefined
    assert l.run(['variablename'], {'variablename2': 'hello2'}) == ['']

    # Test with multiple variables that are undefined
    assert l.run(['variablename', 'variablename2'], {'variablename1': 'hello1'}) == ['', '']

    # Test with multiple variables, one undefined with default
    assert l.run(['variablename', 'variablename2'], {'variablename': 'hello'}) == ['hello', '']

# Generated at 2022-06-23 12:45:06.121178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 12:45:12.960668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test 1: Test lookup module with default
    lookup_obj = LookupModule()
    try:
        lookup_obj.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables=None, default=3)
    except AnsibleUndefinedVariable:
        assert False

    # Test 2: Test lookup module without default
    lookup_obj = LookupModule()
    try:
        lookup_obj.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables=None)
    except AnsibleUndefinedVariable:
        assert True

# Generated at 2022-06-23 12:45:23.872456
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    class MyLookup(object):
        def __init__(self, t, vars=None, **kw):
            self.t = t
            self.vars = vars
            self.kw = kw
        def set_options(self, var_options, direct=False):
            assert var_options == self.vars
            assert direct == self.kw
        def run(self, terms, variables=None, **kwargs):
            if variables is not None:
                self.vars = variables
            myvars = getattr(self._templar, '_available_variables', {})

            terms = [self.t] + terms

# Generated at 2022-06-23 12:45:26.344062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:45:32.116244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'ansible_play_hosts'
    terms = [term]
    variables = {'ansible_play_hosts': '127.0.0.1'}
    looobj = LookupModule()
    looobj.set_options(var_options=variables)
    result = looobj.run(terms)
    assert result == [variables[term]]



# Generated at 2022-06-23 12:45:37.380294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    templar = Templar(None, vault_secrets=[], loader=None)
    lu = LookupModule(None, templar=templar, loader=None, vault_secrets=[])
    assert VaultLib == type(lu._templar.vault)

# Generated at 2022-06-23 12:45:49.494759
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up the class
    lm = LookupModule()

# Generated at 2022-06-23 12:45:57.017595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables={
        'ansible_play_hosts': ['host1', 'host2'],
        'ansible_play_batch': ['host3', 'host4'],
        'ansible_play_hosts_all': ['host5', 'host6']
    })
    assert l._result == ['host1', 'host2', 'host3', 'host4', 'host5', 'host6']

# Generated at 2022-06-23 12:46:05.889936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit tests for LookupModule.run
    '''
    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-23 12:46:11.308289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=protected-access
    lookup = LookupModule()
    assert lookup.run(terms=['lookup']) == []
    assert lookup.run(terms=['lookup'], variables={'lookup': 'test'}) == ['test']
    assert lookup.run(terms=['lookup', 'lookup'], variables={'lookup': 'test'}) == ['test', 'test']

# Generated at 2022-06-23 12:46:14.871498
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = {
        'inventory_hostname': 'localhost'
    }
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader()
    lookup_plugin.set_environment(Environment())
    lookup_plugin._templar._available_variables = data
    lookup_plugin.set_options(var_options=data)

    ret = lookup_plugin.run(terms=["inventory_hostname"])
    assert ret == ['localhost']


# Generated at 2022-06-23 12:46:25.670172
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize LookupModule
    lookup_module = LookupModule()
    # Initialize empty dict
    myvars = {}
    # Assign dict to available_variables
    lookup_module._templar.available_variables = myvars
    # Initialize list of terms
    terms = []
    # Initialize nested dict
    d = {'key1': {'key2': {'key3': 'value'}}}
    # Add dict to terms
    terms.append(d)
    # Add string to terms
    terms.append('string')
    # Add list to terms
    terms.append(['list'])
    # Run the run method of LookupModule
    lookup_module.run(terms, variables=myvars)

# Generated at 2022-06-23 12:46:26.691949
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 12:46:37.861738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	stub_variables = {
		"hostvars": {
			"host1": {
				"value1": "foo",
				"value2": "bar"
			}
		}
	}

	lookup = LookupModule()
	lookup._templar.available_variables = stub_variables
	lookup.set_options(var_options=stub_variables, direct={})

	assert lookup.run(["value1"]) == ["foo"]
	assert lookup.run(["value2"]) == ["bar"]

	assert lookup.run(["value1"], variables={"value1": "baz"}) == ["baz"]

	assert lookup.run(["value3"], default="default") == ["default"]

# Generated at 2022-06-23 12:46:49.756510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def stub_getattr(self, attr):
        return self._templar._available_variables

    def stub_getitem(self, name):
        if name == 'hostvars':
            return self._templar._available_variables['hostvars']
        else:
            return 'NOT IN VARIABLES'

    import __builtin__
    setattr(__builtin__, 'dict', dict)
    __builtin__.dict.get = __builtin__.dict.__getitem__

    # Set up a stub environment

# Generated at 2022-06-23 12:46:56.622841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class _PlayContext:
        def __init__(self):
            self.connection = None
            self.play = None
            self.options = None
            self.prompt = None
            self.terminated = None
            self.remote_addr = None
            self.remote_user = None
            self.port = None
            self.passwords = None
            self.become_method = None
            self.become_user = None

    class _Module:
        def __init__(self):
            self.params = None
            self.args = None
            self.tmp = None
            self.runner_path = None
            self._debug = None

    class _Task:
        def __init__(self):
            self.environment = None


# Generated at 2022-06-23 12:46:58.255124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    terms = lm._templar._available_variables['inventory_hostname']
    var = lm._templar._available_variables['hostvars'][terms]
    lm.run(terms, variables=var)

# Generated at 2022-06-23 12:47:00.874481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    words = 'hi there'
    module = LookupModule()
    test_result = module.run([words], {})
    assert test_result == [words], "Something went horribly wrong"

# Generated at 2022-06-23 12:47:04.502419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=no-member
    import unit
    import sys
    sys.modules['unit'] = unit

    terms = ['ansible_fact1']

    # Run the method
    module = LookupModule()
    ret = module.run(terms)
    assert ret == ['value1']

# Generated at 2022-06-23 12:47:13.891677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Pre-set variables for tests
    complex_var_name = 'complex_var_' + str(time.time())
    myvar = 'myvar_' + str(time.time())
    yaml_var = 'yaml_var_' + str(time.time())

    # Set up Ansible variables

# Generated at 2022-06-23 12:47:25.836989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import os


# Generated at 2022-06-23 12:47:27.058010
# Unit test for constructor of class LookupModule
def test_LookupModule():
    intance = LookupModule()
    assert intance is not None

# Generated at 2022-06-23 12:47:29.855386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print('Instantiation test succeeded')


# Generated at 2022-06-23 12:47:40.266943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Variable is defined
    terms = ['foo']
    variables = {'hostvars': {'host': {'foo': 'bar'}}, 'inventory_hostname': 'host'}
    assert lookup_module.run(terms, variables=variables)[0] == 'bar'

    # Variable is not defined
    lookup_module.set_options(var_options=variables, direct={'default': ''})
    assert lookup_module.run(terms, variables=variables)[0] == ''

    # Variable is not defined and no default is set
    lookup_module.set_options(var_options=variables, direct={})
    try:
        lookup_module.run(terms, variables=variables)
        assert False
    except:
        assert True

# Generated at 2022-06-23 12:47:52.801235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    class TestInvalidLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            raise AnsibleUndefinedVariable("%s is an invalid variable" % terms)

    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return terms

    variables = {
        'inventory_hostname': 'myhost',
        'hostvars': {
            'myhost': {'a': 'b'}
        },
        'a': 'b',
        'test': 'a'
    }

    test = TestLookupModule()
    assert test.run(terms=['inventory_hostname'], variables=variables) == ['myhost']

# Generated at 2022-06-23 12:47:54.977522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-23 12:48:00.125164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = []
    terms.append('ansible_play_hosts')
    terms.append('ansible_play_batch')
    terms.append('ansible_play_hosts_all')
    result = lookup.run(terms)
    assert(isinstance(result, list))
    assert(len(result) == 3)
    assert(all(isinstance(x, basestring) for x in result))

# Generated at 2022-06-23 12:48:06.875205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    d = {'foo': 'bar'}

    # No value
    assert l.run(['foo']) == d['foo']

    # Default
    d['foo'] = 'baz'
    assert l.run(['foo'], default='bar') == d['foo']

    # Non default
    d['foo'] = None
    assert l.run(['foo'], default='bar') == 'bar'

    # Error
    del d['foo']
    try:
        l.run(['foo'])
        assert False
    except AnsibleUndefinedVariable as e:
        assert str(e) == 'No variable found with this name: foo'

# Generated at 2022-06-23 12:48:07.847130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L is not None

# Generated at 2022-06-23 12:48:18.582219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['first_var', 'second_var', 'third_var']

    variables = dict(
        first_var={
            'key1': 'val1',
            'key2': 'val2',
            'key3': 'val3',
        },
        second_var={
            'key1': 'val1',
            'key2': 'val2',
            'key3': 'val3',
        },
        third_var={
            'key1': 'val1',
            'key2': 'val2',
            'key3': 'val3',
        }
    )

    result = lookup.run(terms=terms, variables=variables)

# Generated at 2022-06-23 12:48:19.628750
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__doc__ is not None

# Generated at 2022-06-23 12:48:20.563928
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:48:22.015712
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:48:30.545882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'],
                              {'hostvars': {'host1': {'ansible_play_hosts': 'host1',
                                                      'ansible_play_batch': 'host1',
                                                      'ansible_play_hosts_all': 'host1'},
                                            'host2': {'ansible_play_hosts': 'host2',
                                                      'ansible_play_batch': 'host2',
                                                      'ansible_play_hosts_all': 'host1,host2'}},
                               'inventory_hostname': 'host2'}) == ['host2', 'host2', 'host1,host2']


# Generated at 2022-06-23 12:48:38.026542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create mock AnsibleModule object
    module = AnsibleModule(argument_spec={
        '_terms': dict(type='list'),
        'default': dict()
    })

    # create mock AnsibleModule object
    module = AnsibleModule(argument_spec={
        '_terms': dict(type='list'),
        'default': dict()
    })

    # create mock module object
    templar = Templar(module)

# Generated at 2022-06-23 12:48:48.631478
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:48:58.802774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_variables = {
        'variablename': 'hello',
        'myvar': 'ename'
    }

    lookup = LookupModule()
    result = lookup.run(terms=["variablename", "myvar"])
    assert result == ['hello', 'ename']

    result = lookup.run(terms="variablename", variables=my_variables)
    assert result == 'hello'

    result = lookup.run(terms=["variablename", "myvar"], variables=my_variables)
    assert result == ['hello', 'ename']

    result = lookup.run(terms="variablename", variables=my_variables, default='')
    assert result == 'hello'

    result = lookup.run(terms="myvar", variables=my_variables, default='')

# Generated at 2022-06-23 12:49:11.205615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # 1 ---
  lookup_instance = LookupModule()
  terms = [ "test" ]
  variables = { 'test': 'test_value' }
  assert lookup_instance.run(terms, variables) == [ 'test_value' ]
  # 2 ---
  lookup_instance = LookupModule()
  terms = [ "test" ]
  variables = {}
  assert lookup_instance.run(terms, variables) == []
  # 3 ---
  lookup_instance = LookupModule()
  terms = [ "test" ]
  variables = { 'test': 'test_value',
                'inventory_hostname': 'local',
                'hostvars': { 'local': { 'other': 'other_value'} } }
  assert lookup_instance.run(terms, variables) == [ 'test_value' ]
  # 4 ---

# Generated at 2022-06-23 12:49:14.929704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # params = {'terms': ['variablename'], 'variables': {'variablename': 'hello', 'myvar': 'ename'}}
    # lookup = LookupModule()
    # result = lookup.run(**params)
    # assert result == ['hello']
    print('lookup/vars.py')

# Generated at 2022-06-23 12:49:27.301581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict

    def _get_templar():
        from ansible.template.safe_eval import compile_restricted_eval

        from ansible.template import Templar
        from ansible.vars import VariableManager

        from ansible.parsing.yaml.loader import AnsibleLoader

        def _restrict_functions(functions):
            for fn in functions:
                compile_restricted_eval(fn)

        loader = AnsibleLoader(None, False)
        vm = VariableManager()
        templar = Templar(loader=loader, variables=vm)
        # restrict only some functions
        restricted_function_list = ['match']
        _restrict_functions(restricted_function_list)

# Generated at 2022-06-23 12:49:28.145662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:49:29.812687
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:49:41.292698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = dict()
    lookup_module._templar._available_variables = dict()
    lookup_module.get_option = lambda x: None

    # test with a given variables
    lookup_module._templar._available_variables['variablename'] = 'hello'
    lookup_module._templar.template = lambda x, y: x
    result = lookup_module.run(['variablename'])
    assert result == ['hello']

    # test with not existing variable
    lookup_module._templar._available_variables['variablename'] = 'hello'
    lookup_module._templar.template = lambda x, y: x
    result = lookup_module.run(['variableX'])
    assert result == []



# Generated at 2022-06-23 12:49:50.208587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import necessary modules
    from ansible.plugins.lookup import LookupModule
    import ansible.module_utils.six
    from ansible.module_utils._text import to_native
    import ansible.plugins.loader
    import json

    # initialize class
    my_ansible_var = LookupModule()

    # get path to inventory
    paths = ansible.plugins.loader.find_plugin_files('./test/unit/test_data/plugins/inventory')

    # read inventory
    inventory = ansible.inventory.Inventory(paths)

    # create list of vars to look up
    vars_list = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    # run test

# Generated at 2022-06-23 12:50:01.752238
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display
    display = Display()

    terms = []
    terms.append(u'variablename')
    terms.append(u'myvar')
    term =  u'variablename'
    myvar = u'myvar'
    error_message = 'No variable found with this name: %s' % term
    error_message_with_default = 'No default value was found for the variables requested, which are: %s' % terms

    # Test with name: Show value of 'variablename'
    terms = [u'variabl' + myvar]
    terms.append(u'myvar')
    test_variables = { u'variablename': u'hello', u'myvar': u'ename' }

# Generated at 2022-06-23 12:50:02.331051
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:50:04.663909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test variables
    d = {}

    # Run code
    l = LookupModule()

    # Assertions
    assert l is not None



# Generated at 2022-06-23 12:50:06.864101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert(lookup_module.run(["plugin_dir"]) == ["/usr/share/ansible"])

# Generated at 2022-06-23 12:50:15.556856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables for tests
    my_variables = {
        'inventory_hostname': 'localhost',
        'ansible_play_hosts': ['all'],
        'ansible_play_batch': ['localhost'],
        'ansible_play_hosts_all': ['all'],
        'variablename': 'hello',
        'myvar': 'ename',
        'variablenotename': '',
        'variablenamed': 'hello',
        'myvar2': 'name',
        'variablenamed2': 'hello',
        'myvar3': 'en'
    }

    # Variables for test_run_with_default_param

# Generated at 2022-06-23 12:50:16.983776
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)


# Generated at 2022-06-23 12:50:19.424687
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert hasattr(lu, 'run')

# Generated at 2022-06-23 12:50:21.581094
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:50:23.749918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj._options == {'wantlist': True}

# Generated at 2022-06-23 12:50:25.032958
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup=LookupModule()
    print("lookup class initialized")

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:50:29.636876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Running test_LookupModule_run")
    test_terms = "foo"
    test_variables = {
        "foo" : "bar"
    }
    test_kwargs = {}
    test_LookupModule = LookupModule()
    result = test_LookupModule.run([test_terms], test_variables, **test_kwargs)
    assert result == ["bar"]


# Generated at 2022-06-23 12:50:31.797789
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.run.__doc__) > 0, "The documentation is empty"

# Generated at 2022-06-23 12:50:42.425283
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    lookup._templar._available_variables = {'myvar': 'value'}
    res = lookup.run(['myvar'])
    assert isinstance(res, list)
    assert len(res) == 1
    assert res[0] == 'value'
    res = lookup.run(['myvar2'])
    assert isinstance(res, list)
    assert len(res) == 1
    assert res[0] == None
    res = lookup.run(['myvar2'], default='ok')
    assert isinstance(res, list)
    assert len(res) == 1
    assert res[0] == 'ok'


# Generated at 2022-06-23 12:50:52.121976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    this = LookupModule()
    templar = this._templar
    templar._available_variables = dict(
            variablename='hello',
            myvar='ename',
            variablenotename='hello',
            myvar2='notename',
            inventory_hostname='hostname',
            hostvars={'hostname': dict(
                variablenotename_2='hello'
                )}
            )
    ret = this.run(['variab' + templar.template('{{ myvar }}', fail_on_undefined=True)], variables=templar._available_variables)
    assert ret == ['hello']

    this = LookupModule()
    templar = this

# Generated at 2022-06-23 12:50:53.495852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:51:00.934389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run(["var1"], variables={"var1": ["1", "2"]}) == ["1", "2"]
    assert lookup_module.run(["var1"], variables={"var1": 1}) == [1]
    assert lookup_module.run(["var1"], variables={"var1": True}) == [True]
    assert lookup_module.run(["var1"], variables={"var1": False}) == [False]
    assert lookup_module.run(["var1"], variables={}) == []

# Generated at 2022-06-23 12:51:08.972354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.dataloader as dl
    from ansible.vars import VariableManager

    loader = dl.DataLoader()
    vm = VariableManager()

    lookup = LookupModule()
    lookup.set_loader(loader)
    lookup.set_variable_manager(vm)
    lookup.set_options({'_ansible_check_mode': True})
    lookup.set_options({'_ansible_no_log': True})
    lookup.set_options({'_ansible_verbosity': 3})
    lookup.set_options({'_ansible_version': 'None'})

    terms = ['ansible_play_hosts_all']
    variables = dict()
    variables.update({'inventory_hostname': 'localhost'})

# Generated at 2022-06-23 12:51:20.535564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inventory_hostname = 'my_hostname'
    input_data = {
        'variables': {
            'myvar1': 'myvalue1',
            'myvar2': 'myvalue2',
            'myvar3': 'myvalue3',
            'myvar4': 'myvalue4',
        },
        'inventory_hostname': inventory_hostname,
        'hostvars': {
            'my_hostname': {
                'myvar1': 'h_myvalue1',
                'myvar2': 'h_myvalue2',
            }
        }
    }

    # Test that the correct value is returned when a variable is defined
    #  at top level and lower level
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    l = LookupModule()
    l._