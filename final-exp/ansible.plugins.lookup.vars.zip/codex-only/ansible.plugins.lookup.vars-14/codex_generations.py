

# Generated at 2022-06-23 12:41:15.639214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    lookup_module = LookupModule()
    lookup_module.set_loader(loader)

    assert getattr(lookup_module, '_loader') == loader
    assert getattr(lookup_module, '_templar') != None

# Generated at 2022-06-23 12:41:28.070145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    lookup = LookupModule()
    variable_manager = VariableManager()
    host_list = [
        'localhost',
    ]
    inventory = Inventory(loader=DataLoader(), variable_manager=variable_manager, host_list=host_list)
    variable_manager.set_inventory(inventory)

    print("--------------------------------------------------------------------------------------")
    print("\n1. Show value of 'variablename'")
    print("\n")
    print("Expected result: hell")
    print("Actual result: ")
    variables_in_use = [{'variablename': "hell"}, {'myvar': "o"}]

# Generated at 2022-06-23 12:41:35.655391
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={})
    lookup_plugin._templar = DummyTemplar()
    lookup_plugin._templar._available_variables = {'test_var_1' : 'test_value_1', 'test_var_2' : 'test_value_2'}

    assert lookup_plugin.run(["test_var_1"], None) == ['test_value_1']

    assert lookup_plugin.run(["test_var_2", "test_var_3"], None) == ['test_value_2', None]

    lookup_plugin.set_options(direct={'default' : 'N.A'})

# Generated at 2022-06-23 12:41:37.107745
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mytest = LookupModule()
    assert(mytest)

# Generated at 2022-06-23 12:41:41.949524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = 'ansible_play_hosts: test'
    terms = ['ansible_play_hosts']
    expected = [
        "test"
    ]
    module = LookupModule()
    result = module.run(terms, data)
    assert result == expected

# Generated at 2022-06-23 12:41:50.682940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    import ansible

    ansible._variable_manager = ansible.variables.VariableManager()

# Generated at 2022-06-23 12:41:51.508815
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:41:52.165710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:41:54.328319
# Unit test for constructor of class LookupModule
def test_LookupModule():
    variables = dict()
    assert(LookupModule(variables)._templar.available_variables == variables)

# Generated at 2022-06-23 12:41:57.952963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {
        'test_var':'test_value',
        'test_var1':'test_value1',
        'test_var2':'test_value2',
        'hostvars':{'test_host':{'test_var3':'test_value3'}}
    }
    assert lookup_module.run(['test_var']) == ['test_value']
    assert lookup_module.run(['test_var','test_var1','test_var2']) == ['test_value','test_value1','test_value2']

# Generated at 2022-06-23 12:42:06.474788
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This first part is just to initialize variables so we can run
    # the unit test and have it resemble real behavior
    from ansible.template import Templar
    import ansible.constants as C

    class MockTemplar(Templar):
        MOCK_AVAILABLE_VARIABLES = {}
        def _populate_available_variables(self):
            self._available_variables = self.MOCK_AVAILABLE_VARIABLES

    class MockVarsModule():
        class MockModule():
            class args():
                connection = 'local'
                _raw_params = None
                _ansible_check_mode = False
                diff = False
                _connection = None
                _ansible_diff = None
                _ansible_verbosity = 0
                _ansible_selinux_special_

# Generated at 2022-06-23 12:42:16.260349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class MockTemplar():
        def __init__(self):
            self._available_variables = {}

        def template(self, sub_var, fail_on_undefined=True):
            return sub_var

    class MockDisplay():
        def __init__(self):
            self.vvvv = 2

    class MockOptions():
        def __init__(self):
            self.variable_manager = MockTemplar()
            self.display = MockDisplay()

    class MockLoader():
        def __init__(self):
            self.options = MockOptions()
            self.vault_password = '12345'
            self._basedir = '/'

    variables = {'variablename': {'sub_var': 12}, 'myvar': 'ename'}

# Generated at 2022-06-23 12:42:19.354430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_loader(None)
    l.set_templar({'_available_variables':{'nested':{'sub_var':'12'}}})
    l.run(['nested'])

# Generated at 2022-06-23 12:42:30.542853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': "127.0.0.1", 'ansible_play_batch': "127.0.0.2", 'ansible_play_hosts_all': "127.0.0.3"}
    result = lookup_module.run(terms, variables=variables)
    assert result[0] == variables['ansible_play_hosts']
    assert result[1] == variables['ansible_play_batch']
    assert result[2] == variables['ansible_play_hosts_all']


# Generated at 2022-06-23 12:42:39.262391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verify that 'run' method of class 'LookupModule' is working as expected

    # Set up object
    LookupModuleObj = LookupModule()

    # Declare variables for LookupModule run method
    hostvars = dict()
    data = dict()
    hostvars['inventory_hostname'] = 'localhost'
    data['inventory_hostname'] = 'localhost'
    data['hostvars'] = dict()
    data['hostvars']['localhost'] = dict()
    data['hostvars']['localhost'] = hostvars
    data['test_var'] = 'test value'
    data['hostvars']['localhost']['host_var'] = 'host var value'

    # Call LookupModule.run method

# Generated at 2022-06-23 12:42:43.024225
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x.get_option('default') == None
    x.set_options(var_options=None, direct={'default': 5})
    assert x.get_option('default') == 5

# Generated at 2022-06-23 12:42:44.405289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:42:50.740800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod._templar = MagicMock()
    # test_no_var
    myvar = mod.run(terms=["var1"])
    assert myvar == []
    # test_with_var
    mod._templar._available_variables = {'var1': 123}
    myvar = mod.run(terms=["var1"])
    assert myvar == [123]
    # test_with_default_var
    mod._templar._available_variables = {'var1': 123}
    myvar = mod.run(terms=["var1"], default='456')
    assert myvar == [123]
    # test_without_default_var
    mod._templar._available_variables = {}

# Generated at 2022-06-23 12:42:53.045325
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)


# Generated at 2022-06-23 12:43:02.106338
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for AnsibleUndefinedVariable Exception
    lookup = LookupModule()
    try:
        lookup.run(terms=["variablenotfound"], variables={"variablefound": "Hello"})
        assert False
    except AnsibleUndefinedVariable:
        assert True

    # Test for AnsibleError Exception
    # Empty terms
    lookup = LookupModule()
    try:
        lookup.run(terms=[])
        assert False
    except AnsibleError:
        assert True

    # term is not a String
    lookup = LookupModule()
    try:
        lookup.run(terms=[1234])
        assert False
    except AnsibleError:
        assert True

    # Test the value returned
    lookup = LookupModule()

# Generated at 2022-06-23 12:43:13.197340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test cases for run method of class LookupModule"""
    templar = DictData()
    lookup = LookupModule()
    myvars = {'inventory_hostname': 'myhost',
              'variablename': 'hello',
              'myvar': 'ename'}

    assert lookup.run(terms=['variablename'], variables=myvars) == ['hello']
    assert lookup.run(terms=['variabl' + myvars['myvar']], variables=myvars) == ['hello']
    assert lookup.run(terms=['variabl' + myvar], variables=myvars) == ['hello']
    assert lookup.run(terms=['variabl' + myvars['myvar']], variables=myvars, default='') == ['']

# Generated at 2022-06-23 12:43:22.089363
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import iteritems
    from ansible.plugins.loader import lookup_loader

    LookupModule(None, None, '_ansible_tmp')

    # Load all lookup plugins
    lookup_loader._find_plugins(class_only=True)
    for name, obj in iteritems(lookup_loader._lookup_plugins):
        if not isinstance(obj, type):
            continue
        if obj is LookupModule:
            continue
        obj(None, None, '_ansible_tmp')

# Generated at 2022-06-23 12:43:33.241555
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestLookup:
        def __init__(self, available_variables):
            self.available_variables = available_variables
            self.templar = TestTemplar()

        def template(self, value, fail_on_undefined=True):
            return "{%s}" % value

    class TestTemplar:
        _available_variables = None

        def __init__(self):
            self._available_variables = {}

    # Test with empty variables
    looker = TestLookup({})
    mod = LookupModule(looker, {})
    ret = mod.run(["hostvars"])
    assert len(ret) == 1
    assert ret[0] == "{hostvars}"

    # Test with hostvars and some values
    looker = TestLookup({})
    look

# Generated at 2022-06-23 12:43:41.421464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    terms = ("myvar1", "myvar2", "myvar3")
    myvars = dict()
    myvars["myvar1"] = "Myvar Value 1"
    myvars["myvar2"] = "Myvar Value 2"
    myvars["myvar3"] = "Myvar Value 3"

    ret = lm.run(terms, myvars)

    assert len(ret) == 3
    assert ret[0] == myvars["myvar1"]


# Generated at 2022-06-23 12:43:42.925746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a=LookupModule()
    assert isinstance(a,LookupModule)

# Generated at 2022-06-23 12:43:51.356032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json

    # Test basic usage
    terms = ['hostname', 'hostvars']

    # Provide some data and vars to run against
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variables = VariableManager()

    vars_dict = {
        "hostname": "localhost",
        "hostvars": {
            "localhost": {
                "test": "hello"
            }
        }
    }

    results = [vars_dict["hostname"], vars_dict["hostvars"]]

    variables.set_variable("ansible_lookup_vars", vars_dict, loader=loader)

    lookup = LookupModule()
    result = lookup.run(terms, variables=variables)



# Generated at 2022-06-23 12:43:59.431080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test with a valid variable
    lookup._templar._available_variables = dict(
        hostvars=dict(
            localhost=dict(
                valid_var='This is a valid variable'
            )
        )
    )
    ret = lookup.run(
        terms=[
            'valid_var'
        ],
        variables=dict(
            ansible_host='localhost'
        ),
        inject=dict(
            ansible_host='localhost'
        )
    )
    assert len(ret) == 1
    assert ret[0] == 'This is a valid variable'

    # Test with a nested variable

# Generated at 2022-06-23 12:44:01.245514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:44:13.642785
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_text

    # Python 2 returns byte strings from repr(), Python 3 returns unicode
    if PY2:
        class_str = "<class 'ansible.plugins.lookup.vars.LookupModule'>"
    else:
        class_str = "<class 'ansible.plugins.lookup.vars.LookupModule'>"

    class_repr = repr(LookupModule)

    assert class_str == class_repr
    assert class_repr.startswith('<class')
    assert class_repr.endswith('>')

    # Python 2 returns byte strings from str(), Python 3 returns unicode

# Generated at 2022-06-23 12:44:25.906789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:44:36.579318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = {
        '_ansible_version': '2.5.1',
        '_ansible_no_log': False,
        '_ansible_verbosity': 3,
        '_ansible_debug': False,
        '_ansible_diff': True,
        '_ansible_selinux_special_fs': [
            'fuse',
            'nfs',
            'vboxsf',
            'ramfs',
            '9p',
            'vfat'
        ],
        '__run_num': 0
    }

    templar = DictData(data)

    # Test valid variables
    lm = LookupModule()
    lm.set_loader(DictData(data))
    lm._templar = templar

# Generated at 2022-06-23 12:44:39.577075
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert isinstance(l, LookupBase)

# Generated at 2022-06-23 12:44:41.550737
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule) == True

# Generated at 2022-06-23 12:44:51.733623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar._available_variables = {'myvar1': '12', 'hostvars': {'localhost': {'myvar2': '14'}}}
    lookup._templar._available_variables['hostvars']['localhost']['ansible_play_hosts'] = []
    lookup._templar._available_variables['hostvars']['localhost']['ansible_play_batch'] = []
    lookup._templar._available_variables['hostvars']['localhost']['ansible_play_hosts_all'] = []
    lookup.set_options(var_options={})
    lookup.get_option('default')
    assert lookup.run(['myvar1'], {}) == ['12']

# Generated at 2022-06-23 12:45:03.859589
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Mock _templar.available_variables
    available_variables = dict()
    available_variables['variablename'] = "hello"
    available_variables['myvar'] = "ename"
    available_variables['hostvars'] = dict()
    available_variables['hostvars']['host1'] = dict()
    available_variables['hostvars']['host2'] = dict()
    available_variables['hostvars']['host1']['sub_var'] = 10
    available_variables['hostvars']['host2']['sub_var'] = 20
    available_variables['inventory_hostname'] = "host1"

    # Create instance of LookupModule class
    lookup_module_instance = LookupModule()
    lookup_module_instance._tem

# Generated at 2022-06-23 12:45:14.241797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = [ 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all' ]

# Generated at 2022-06-23 12:45:21.445131
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #
    # Create object
    #
    lookup_plugin = LookupModule()

    #
    # Insert an example variable, it should be empty
    #
    lookup_plugin.run(terms='nothing')

    #
    # Insert an example variable
    #
    lookup_plugin.run(terms='inventory_dir')

    #
    # Insert an undefined variable
    #
    lookup_plugin.run(terms='nothing', variables={'inventory_dir': 'test'})

# Generated at 2022-06-23 12:45:22.777427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), object)



# Generated at 2022-06-23 12:45:24.093636
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance = LookupModule()
    assert test_instance

# Generated at 2022-06-23 12:45:28.104884
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module_cls = LookupModule()
    assert module_cls._templar._vars is None
    assert module_cls.set_options(var_options=None, direct=None) is None

# Generated at 2022-06-23 12:45:34.977045
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    expand = 'expand'
    term = 'term'
    terms = [term]
    templar = 'templar'
    lookup_base = LookupModule(loader=None, templar=templar)
    variables = {term: 'variable'}
    default = 'default'
    kwargs = {'a': 'a', 'b': 'b'}
    get_attr = 'getattr'

    # mock LookupBase.set_options()
    # mock templar.expand()
    # mock templar.template()

    lookup_base.set_options = lambda var_options, direct: None
    templar.expand = lambda term: expand
    templar.template = lambda value, fail_on_undefined: value

    # test run() where term is a string
    set

# Generated at 2022-06-23 12:45:36.375090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, object)

# Generated at 2022-06-23 12:45:44.285466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.module_utils.basic
    result = ansible.module_utils.basic.AnsibleModule(argument_spec={})._load_params()

    hostvars = {"host1": {"hello": "world"}}
    templar = result.get('templar')
    templar._available_variables = {"hostvars": hostvars}

    # Test with good variable
    lookup_module = LookupModule()
    value_list = lookup_module.run(["hello"], templar)
    assert value_list == ["world"]

    # Test with bad variable
    lookup_module = LookupModule()
    value_list = lookup_module.run(["cat"], templar)
    assert value_list == []

    # Test with bad variable and default
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:45:54.192053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [
        'persistent_log_messages', 
        'ansible_play_batch',
        'ansible_play_hosts',
        'ansible_play_hosts_all',
        'ansible_user_id',
        'ansible_user_dir'
    ] 
    
    variables = {}
    variables['persistent_log_messages'] = [
        {
            'task': 'Gather Facts', 
            'msg': 'Gathering Facts from the device'
        }
    ]
    variables['ansible_play_batch'] = {
        'hosts': [
            'vasir2'
        ]
    }

# Generated at 2022-06-23 12:46:04.153604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.set_options(var_options=None, direct=None)
    assert l.get_option('default') == None
    l.set_options(var_options=None, direct={ 'ansible_facts':{ 'inventory_hostname':'192.168.1.1', 'hostvars':{ '192.168.1.1':{ 'ansible_distribution':'CentOS', 'ansible_distribution_version':'5' } } } })
    assert l.get_option('default') == None

# Generated at 2022-06-23 12:46:06.817599
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # Test object created successfully
    assert lookup_module


# Generated at 2022-06-23 12:46:14.224958
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:46:25.744830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    lookup = LookupModule()

    with pytest.raises(AnsibleError) as excinfo:
        lookup.run([1])
    assert 'is not a string, its a' in str(excinfo.value)

    lookup._templar._available_variables = {'variablename': 'hello'}
    variables = {'myvar': 'ename'}

    ret = lookup.run(['variablename'])
    assert ret == ['hello']

    ret = lookup.run(['variablenotename'], variables, default='')
    assert ret == ['']

    with pytest.raises(AnsibleUndefinedVariable) as excinfo:
        lookup.run(['variablenotename'])
    assert 'No variable found with this name: variablenotename'

# Generated at 2022-06-23 12:46:37.131954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    options = dict(
        default = 'Default value',
    )

    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options = None, direct = options)

    # test normal usage
    var_dict = dict(
        term1 = 'someterm1value',
        term2 = dict(
            sub_term2 = 'somesubterm2value',
        ),
        term3 = '{{ lookup("vars", "term1") }}',
    )
    assert lookup_obj.run(terms = ['term1'], variables = var_dict) == ['someterm1value']
    assert lookup_obj.run(terms = ['term2'], variables = var_dict) == [dict(sub_term2 = 'somesubterm2value')]

# Generated at 2022-06-23 12:46:41.076668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        templar = None
        lookup = LookupModule(templar, loader, tempdir, filter_factory)
    except Exception as e:
        print('Exception:', e)

# Generated at 2022-06-23 12:46:43.197547
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # FIXME: more tests here please!
    lookup_plugin = LookupModule()
    assert 'default' in lookup_plugin

# Generated at 2022-06-23 12:46:52.764283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Expected variable initialization
    expected_dict = {'variablename': 'hello', 'myvar': 'ename'}

    # Populate variable with json structure
    variable = {
                "variablename": "hello",
                "myvar": "ename",
                "nested_value": {
                                 "sub_value1": 1,
                                 "sub_value2": 2,
                                 "sub_value3": 3
                                },
                "bool_value": True,
                "list_value": [
                               "value1",
                               "value2",
                               "value3"
                              ]
               }

    # Instantiate LookupModule with given variables
    module = LookupModule(variables=variable, loader=None, templar=None, shared_loader_obj=None)

    #

# Generated at 2022-06-23 12:46:57.961490
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    testclass = LookupModule()
    testclass.set_options(var_options={}, direct={'default': None})
    terms = ['test']
    variables = {'test': {'test': 'test'}}
    assert testclass.run(terms, variables) == [{'test': 'test'}]

    testclass = LookupModule()
    testclass.set_options(var_options={}, direct={'default': None})
    terms = ['test']
    variables = {'test': 'test'}
    assert testclass.run(terms, variables) == ['test']

    testclass = LookupModule()
    testclass.set_options(var_options={}, direct={'default': None})
    terms = ['test1', 'test2']

# Generated at 2022-06-23 12:47:00.157276
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-23 12:47:02.371151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule("test").run(["test"]) == [None]
    assert LookupModule("test").run(["test"], variables={"test": "test"}) == ["test"]

# Generated at 2022-06-23 12:47:09.860993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # define some ansible variables
  ansible_vars = {
    "ansible_play_hosts_all":["ansible_play_hosts_all_1", "ansible_play_hosts_all_2"],
    "ansible_play_batch":["ansible_play_batch_1", "ansible_play_batch_2"],
    "ansible_play_hosts_all_1":"ansible_play_hosts_all_1",
    "ansible_play_batch_2":"ansible_play_batch_2"
  }

  # define the terms to search
  terms = ["ansible_play_hosts_all", "ansible_play_batch"]

  # create the lookup module
  lookup_module = LookupModule()

# Generated at 2022-06-23 12:47:10.584276
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:47:12.131505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:47:13.593726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'variables': {'name': 'Erick'}})

    returned_val = lookup_module.run(['name'])
    assert returned_val == ['Erick']

# Generated at 2022-06-23 12:47:17.954044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Raise AnsibleError
    try:
        LookupModule().run([1])
    except AnsibleError as e:
        assert "is not a string" in str(e)

    # Raise AnsibleUndefinedVariable
    LookupModule().run(["foo"], variables={"foo": "hello"})

# Generated at 2022-06-23 12:47:19.844855
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None


# Generated at 2022-06-23 12:47:29.726257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = loader.load_basedir('.')
    vars_manager = templar._available_variables
    l = LookupModule()

    l.get_option = lambda x: None
    l.run_terms = ["var1", "var2"]

    l.set_options(var_options=vars_manager, direct={})
    assert l.get_option == l._options.get

    l.run(l.run_terms, vars_manager)
    assert l._templar._available_variables == templar._available_variables

# Generated at 2022-06-23 12:47:38.581167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    data = ".  ansible_play_hosts: 127.0.0.1\n" + \
           "  ansible_play_batch: 0"
    data_json = json.loads(data)
    ansible_vars = {'hostvars': data_json}
    l = LookupModule()
    assert l.run(terms='ansible_play_hosts', variables=ansible_vars) == ['127.0.0.1']
    assert l.run(terms='ansible_play_batch', variables=ansible_vars) == ['0']


# Generated at 2022-06-23 12:47:39.270931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:47:51.409940
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    var_manager = VariableManager()
    inv_manager = InventoryManager(loader=loader)

    term = dict(default = "default", _terms = "term")
    kwargs = dict(variables = {"test": "value", "test2": "nested value: {{ test }}"})
    testLookup = LookupModule(loader=loader, templar=var_manager, inventory=inv_manager)
    assert testLookup.run(terms=[term], **kwargs) == ["default"]
    assert testLookup.run(terms=[term], _terms=["test"], **kwargs) == ["value"]
    assert testLook

# Generated at 2022-06-23 12:47:55.213493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    myloader = DataLoader()
    mylook = LookupModule(loader=myloader, templar=myloader, basedir='./', environment=None)
    from ansible.template import Templar
    assert mylook._templar == Templar(myloader, variables={})

# Generated at 2022-06-23 12:47:56.573392
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None


# Generated at 2022-06-23 12:47:58.199589
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:48:00.255388
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module)
    assert(lookup_module)


# Generated at 2022-06-23 12:48:12.742361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('password', 'vault_password')
    vault_secret.load()
    vault_lib = VaultLib(vault_secret)

    assert(LookupModule().run([], vault_secret.as_dict()) == [])
    assert(LookupModule(extra_vars={'var1': 'foo'}).run([], vault_secret.as_dict()) == ['foo'])
    assert(LookupModule(extra_vars={'var1': ['foo', 'bar']}).run([], vault_secret.as_dict()) == [['foo', 'bar']])

# Generated at 2022-06-23 12:48:14.218168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert isinstance(obj, object)

# Generated at 2022-06-23 12:48:25.288610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    import ansible.plugins.lookup.vars as vars

    # we need to set up the environment as some plugins (ssh-related)
    # will make use of it
    builtins.__dict__['__ansible_ssh_host'] = 'localhost'

    # test function run with different types of valid input

# Generated at 2022-06-23 12:48:33.792550
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing default usage
    assert LookupModule(None).run([u'package_status'], {u'package_status': {u'installed': [u'python', u'python-apt']},
        u'inventory_hostname': u'localhost', u'ansible_play_batch': [u'localhost'], u'ansible_play_hosts_all': [u'localhost'],
        u'ansible_play_hosts': [u'localhost']}) == [{u'installed': [u'python', u'python-apt']}]

    # Testing default on undefined variable

# Generated at 2022-06-23 12:48:35.798053
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 12:48:37.211037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t is not None

# Generated at 2022-06-23 12:48:39.902033
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    assert lookup_loader.get('vars', class_only=True) == LookupModule

# Generated at 2022-06-23 12:48:44.132807
# Unit test for constructor of class LookupModule
def test_LookupModule():
    term = "ansible_version"
    lm = LookupModule()
    assert len(lm.run(terms=term)) == 1
    assert len(lm.run(terms=[term])) == 1
    assert len(lm.run(terms=[term, term])) == 2

# Generated at 2022-06-23 12:48:53.090126
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # valid_data template test
    # type: dict
    terms = {"a","b"}
    variables = {"a":1, "b":2, "c":3}
    l1 = LookupModule()
    assert l1.run(terms=terms, variables=variables) == [1,2]
    variables = {"a":1, "b":2, "c":3}
    assert l1.run(terms=terms, variables=variables) == [1,2]

    # invalid_data template test
    terms = 1
    variables = {"a":1, "b":2, "c":3}

# Generated at 2022-06-23 12:49:02.090069
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test with empty arguments
    module = LookupModule()

    assert module

    # test with terms
    module = LookupModule(terms=['terms'])

    assert module._plugin_name == 'vars'
    assert module._plugin_args == ['terms']
    assert module._templar.available_variables == {}
    assert module._options == {}

    assert module._serialized_options == {}

    assert isinstance(module._loader, object)
    assert isinstance(module._templar, object)

    # test with variables
    module = LookupModule(terms=['terms'],variables={'terms':'terms'})

    assert module._plugin_name == 'vars'
    assert module._plugin_args == ['terms']

# Generated at 2022-06-23 12:49:13.420873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initializing class LookupModule
    instance = LookupModule()

    # Set value to self._templar.available_variables
    variables = {}
    instance._templar.available_variables = variables

    # Set value to self._templar._available_variables
    available_variables = {}
    instance._templar._available_variables = available_variables

    # Set value to self._templar.default
    default = None
    instance._templar.default = default

    # Set value to instance.set_options
    var_options = {}
    direct = {}
    instance.set_options(var_options, direct)

    # Set value to instance.get_option('default')
    instance.get_option('default')

    ret = []

# Generated at 2022-06-23 12:49:25.796385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(
        module_loader=None,
        path_finder=None,
        module_utils_loader=None,
        module_utils_paths=None,
        inventory=None,
        variable_manager=None
    )
    lookup_module._templar._available_variables = {'ansible_play_hosts': ['127.0.0.1'], 'ansible_play_batch': ['1'], 'ansible_play_hosts_all': ['127.0.0.1']}
    ret = lookup_module.run(
        terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'],
        variables=None,
        **{}
    )
   

# Generated at 2022-06-23 12:49:35.134423
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Verify with no value in var, default is not set and
    # inventory_hostname is set

    lookup_obj = LookupModule()
    lookup_obj._templar._available_variables = {'hostvars': {'inventory_hostname': {}} }
    lookup_obj._templar._available_variables['hostvars']['inventory_hostname']['test_var'] = 10
    lookup_obj._templar._available_variables['inventory_hostname'] = 'inventory_hostname'
    myvar_list = ['test_var']
    assert lookup_obj.run(myvar_list) == [10]

# Verify with no value in var, default is not set and
# inventory_hostname is not set
    lookup_obj = LookupModule()
    lookup_obj._templar._

# Generated at 2022-06-23 12:49:45.323402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=too-few-public-methods
    class VariableManager(object):
        def __init__(self):
            self.variable_manager = None
            self.group_vars = {}
            self.host_vars = {}
            self.inventory = None

    # pylint: disable=too-few-public-methods
    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = {}

    # pylint: disable=too-few-public-methods
    class Inventory(object):
        def __init__(self):
            self.groups = {}

    # pylint: disable=invalid-name
    inventory = Inventory()
    host = Host('host')

# Generated at 2022-06-23 12:49:55.381460
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Testing with a variable that is not set
    #Should return empty string
    l = LookupModule()
    l.set_loader(None)
    results = l.run(terms=['its_a_trap'], variables={}, default='')
    assert results == [''], "Variable 'its_a_trap' with no default set should return an empty string"
    
    #Testing with a variable that is not set and no default set
    #Should raise an exception
    l = LookupModule()
    l.set_loader(None)
    #results = l.run(terms=['its_a_trap'], variables={}, direct={})

# Generated at 2022-06-23 12:50:06.207379
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:50:15.156980
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with variable undefined
    mylookup = LookupModule()
    terms = ['variablnotename']
    variables=dict(variablename='hello', myvar='notename')
    assert mylookup.run(terms, variables) == [] # No default

    # Test with variable defined
    mylookup = LookupModule()
    terms = ['variablename']
    variables=dict(variablename='hello', myvar='ename')
    assert mylookup.run(terms, variables) == ['hello']

    # Test with default
    mylookup = LookupModule()
    terms = ['variablnotename']
    variables = dict(variablename='hello', myvar='notename')
    assert mylookup.run(terms, variables, default='DEFAULT') == ['DEFAULT']

# Generated at 2022-06-23 12:50:16.092907
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()

# Generated at 2022-06-23 12:50:27.785844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test calls
    ut_result = []

    # unit test variable
    ut_terms = [
        [],
        ['testvar'],
        ['testvar1', 'testvar2']
    ]

    ut_result.append(True)
    try:
        LookupModule().run(ut_terms[0])
    except AnsibleError:
        ut_result.append(False)

    ut_result.append(True)
    try:
        LookupModule().run(ut_terms[1])
    except AnsibleError:
        ut_result.append(False)

    ut_result.append(True)
    try:
        LookupModule().run(ut_terms[2])
    except AnsibleError:
        ut_result.append(False)

    ut_result.append(True)

# Generated at 2022-06-23 12:50:39.689918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost'])

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{lookup("vars", "my_var")}}')))
        ]
    )

# Generated at 2022-06-23 12:50:50.757817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars import hostvars

    variable_manager = VariableManager()
    variable_manager.set_host_variable(host='localhost', varname='my_var', value=123)

    templar = Templar(loader=None, variables=variable_manager)

    test = LookupModule()
    test._templar = templar

    result = test.run(terms=['my_var'], variables=ImmutableDict({'hostvars': hostvars.HostVars(loader=None, variable_manager=variable_manager, hostname='localhost')}))
    assert result == [123]


# Generated at 2022-06-23 12:50:52.691857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert(set(l.__dict__) == set(['_options', '_display']))

# Generated at 2022-06-23 12:50:56.412672
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=unused-argument
    def _load_class(self, class_loader, class_name, *args, **kwargs):
        if not class_name == 'LookupModule':
            raise Exception('Unit test expects call to LookupModule class')
        return LookupModule(self, class_loader, class_name, *args, **kwargs)

    # Apply the '_load_class' function to the play context object
    import ansible.plugins.loader
    ansible.plugins.loader._load_class = _load_class

    # This unit test also serves as a test that the constructor can be called directly
    # pylint: disable=no-member
    lookup_module = LookupModule(play_context=None)
    assert lookup_module is not None

# Generated at 2022-06-23 12:50:58.435083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement this test.
    # To be implemented.
    return 1

# Generated at 2022-06-23 12:51:06.868803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleMapping
    class MockTemplar(object):
        def template(self, value):
            return value

    class MockPlay(object):
        def get_variable_manager(self):
            var_manager = MockVarsManager()
            return var_manager

        def __init__(self):
            var_manager = self.get_variable_manager()
            self.variable_manager = var_manager


# Generated at 2022-06-23 12:51:07.543539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:51:11.795375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    import ansible
    from ansible.plugins.loader import lookup_loader
    lookup = lookup_loader.get('vars', class_only=True)

    terms = ['searched_var', 'other_var']
    variables = {'searched_var': 'value'}

    # When
    result = lookup.run(terms, variables=variables)

    # Then
    assert result == ['value', None]



# Generated at 2022-06-23 12:51:21.053678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)
    assert isinstance(lm.run(terms=['ansible_play_hosts'], variables={'ansible_play_hosts': ['10.0.0.1', '10.0.0.2']}), list) # should execute without error
    assert lm.run(terms=['ansible_play_hosts'], variables={'ansible_play_hosts': ['10.0.0.1', '10.0.0.2']})[0] == ['10.0.0.1', '10.0.0.2'] # should return the correct result