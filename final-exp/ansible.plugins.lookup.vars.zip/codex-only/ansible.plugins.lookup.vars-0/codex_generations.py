

# Generated at 2022-06-23 12:41:11.964357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-23 12:41:17.717050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up test environment
    current_module = AnsibleModule(argument_spec={})
    current_module.params = {'_ansible_no_log': False}
    current_module.fail_json = fail_json
    current_module.exit_json = exit_json
    current_module.exit_json.setdefault('invocation', {})
    current_module._ansible_module_name = 'lookup'
    current_module._ansible_module_version = __version__

# Generated at 2022-06-23 12:41:29.568158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['var1'], {"var1": "1", "var2": "2"}) == ["1"]
    assert module.run(['var1', 'var2'], {"var1": "1", "var2": "2"}) == ["1", "2"]
    assert module.run(['var1', 'var2', 'var3'], {"var1": "1", "var2": "2"}) == ["1", "2", None]
    assert module.run(['var1', 'var2', 'var3'], {"var1": "1", "var2": "2"}, default='var1') == ["1", "2", "var1"]

# Generated at 2022-06-23 12:41:41.312777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['valid_var', 'invalid_var', 'nested_var.sub_var']
    test_vars = {
        'valid_var': 'value',
        'nested_var': {
            'sub_var': 12
        }
    }
    test_undef = []
    test_default = 'default'

    # Valid test - normal execution
    test_obj = LookupModule()
    test_obj.set_options(direct={'default': test_default})
    assert(test_obj.run(test_terms, test_vars) == ['value', [test_default], [12]])

    # Valid test - no default
    test_obj = LookupModule()
    assert(test_obj.run(test_terms, test_vars) == ['value'])

    # Valid

# Generated at 2022-06-23 12:41:42.409824
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None



# Generated at 2022-06-23 12:41:52.689528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Execute code for unit test
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    test_object = LookupModule()
    lookupresult = test_object.run(terms)

    #assertions
    assert lookupresult == ['127.0.0.1', '0', '127.0.0.1'], \
        "lookup result should have been '127.0.0.1,0,127.0.0.1', but was: %s" % lookupresult
    assert test_object._plugin_name == 'vars', \
        "_plugin_name should have been 'vars' but was: %s" % test_object._plugin_name

# Generated at 2022-06-23 12:42:04.018286
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test Case 1:
    # Create an instance of LookupModule and pass in a variable name.
    # This variable name should be returned in a list.
    test_lookup = LookupModule()
    test_myvars = {}
    setattr(test_lookup, '_available_variables', test_myvars)
    test_myvars['test_term'] = 'test_value'
    test_myvars['hostvars'] = {}
    test_myvars['hostvars'][test_myvars['inventory_hostname']] = {}
    test_myvars['hostvars'][test_myvars['inventory_hostname']]['test_term'] = 'test_value'
    test_ret = test_lookup.run(['test_term'], None)

# Generated at 2022-06-23 12:42:15.142878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_instance = LookupModule()
    LookupModule_instance._templar._available_variables = {'var_name': 'value', 'hostvars': {"host1": {"var_name_host_specific": "value_host_specific"}}}
    LookupModule_instance._templar.available_variables = {'var_name': 'value', 'hostvars': {"host1": {"var_name_host_specific": "value_host_specific"}}}
    LookupModule_instance.set_options(var_options="", direct={})
    LookupModule_instance.get_option('default')

    #Case1
    ret = LookupModule_instance.run(terms=['var_name'])
    assert ret == ['value']

    #Case2

# Generated at 2022-06-23 12:42:16.480723
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule({'settings': {}}, {})
    print(lm)

# Generated at 2022-06-23 12:42:17.452988
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_module = LookupModule()
  assert lookup_module is not None

# Generated at 2022-06-23 12:42:18.392673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run()

# Generated at 2022-06-23 12:42:22.229031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'hello': 'world'}
    res = lookup_module.run(['hello'])
    assert(res[0] == 'world')

# Generated at 2022-06-23 12:42:33.418580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms, variables, **kwargs)

    terms = ['test_variable_1', 'test_variable_2']
    hostvars = {
        'test_variable_1': [1, 2, 3],
        'test_variable_2': [2, 4, 6]
    }
    variables = {
        'inventory_hostname': 'localhost',
        'hostvars': hostvars
    }
    test_lookup = TestLookupModule()
    ret = test_lookup.run(terms, variables, fail_on_undefined=True)

# Generated at 2022-06-23 12:42:41.236994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    module_input = {'inventory_hostname': 'localhost',
                    'playbook_dir' : '/ansible/playbooks',
                    'play_hosts' : ['localhost'],
                    'play_batch' : ['/bin/ls'],
                    'play_hosts_all' : [],
                    'ansible_play_hosts': ['localhost'],
                    'ansible_play_batch': ['/bin/ls'],
                    'ansible_play_hosts_all': []}
    terms = ["playbook_dir", "play_hosts", "play_batch", "play_hosts_all"]
    output = lookup_module.run(terms, variables=module_input)
    assert(output[0] == '/ansible/playbooks')

# Generated at 2022-06-23 12:42:48.094821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    t_lookup = LookupModule()
    terms = ['variablename']
    variables = {
        'variablename': 'hello',
        'myvar': 'ename'
    }

    # When
    ret = t_lookup.run(terms, variables)

    # Then
    assert ret == ['hello']



# Generated at 2022-06-23 12:42:51.472415
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert hasattr(LookupModule, '_templar')
    assert hasattr(LookupModule, 'get_option')
    assert hasattr(LookupModule, 'set_options')

# Generated at 2022-06-23 12:42:53.310018
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module._templar._available_variables != {}

# Generated at 2022-06-23 12:42:54.251347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod is not None

# Generated at 2022-06-23 12:43:03.148617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # success to find variable
    terms = 'variablename'
    variable = {'variablename': 'hello'}
    assert lookup_plugin.run(terms=terms, variables=variable) == ['hello']
    # success to find variable with default value
    terms = 'variablename'
    variable = {'variablename': None}
    assert lookup_plugin.run(terms=terms, variables=variable, default='hello') == ['hello']
    # failed to find variable with default value
    terms = 'variablename'
    variable = {'variablename': None}
    assert lookup_plugin.run(terms=terms, variables=variable, default='hello') == ['hello']
    # failed to find variable
    terms = 'variablename'

# Generated at 2022-06-23 12:43:13.951504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import Ansible class DummyVars
    from ansible.vars import DummyVars
    # import Ansible class DictData
    from ansible.vars import DictData
    from ansible.parsing.vault import VaultLib
    # create an instance of class DictData
    data = DictData()
    # add a variable to the inventory
    data.set_variable('myvar', 'value of myvar')
    # create an instance of class DummyVars
    globalvars = DummyVars()
    # add the inventory to the globalvars
    globalvars.add_dictionary(data.get_vars(), play=data)
    # create an instance of class VaultLib
    vault = VaultLib(password_file=None)
    # create an instance of class LookupModule(LookupBase

# Generated at 2022-06-23 12:43:20.999126
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # construct case
  plugin = LookupModule()
  terms = ['var1', 'var2', 'var3']
  kwargs = {'default': 'nadie'}
  variables = {'var1': 'casa', 'hostvars': {'host1': {'var2': 'barco'}}}

  # invoke and assert
  try:
    assert plugin.run(terms=terms, variables=variables, **kwargs) == ['casa', 'barco', 'nadie']
  except Exception as e:
    print(e)
    assert False

  # error case: throw exception for undefined var
  try:
    assert plugin.run(terms=terms, variables=variables)
    assert False
  except Exception as e:
    assert True

# Generated at 2022-06-23 12:43:31.691226
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # create the templar object
    from ansible.template import Templar
    templar = Templar(loader=loader)

    # create a fake validator object
    from ansible.playbook.validate import Validator
    validator = Validator()

    lookup_obj = LookupModule(loader=loader, templar=templar, validator=validator)

    # simple string var
    terms = ['test_value']
    variables = {
        'test_value': 'hello world'
    }
    result = lookup_obj.run(terms, variables=variables)

# Generated at 2022-06-23 12:43:33.646661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module is not None)

# Generated at 2022-06-23 12:43:37.182645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
        Unit test for constructor of class LookupModule
    '''
    obj = LookupModule()
    assert obj._options == {}, 'test failed'
    return



# Generated at 2022-06-23 12:43:41.209920
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest

    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

    with pytest.raises(AnsibleError):
        lookup.run(['terminal'],
                   variables=None)



# Generated at 2022-06-23 12:43:50.455295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        import __builtin__ as builtins  # python 2
    except ImportError:
        import builtins  # python 3

    lm = LookupModule()

    # called with invalid input (terms not a list)
    try:
        lm.run(terms=1)
    except Exception as e:
        assert 'is not a string' in e.message # check we raise useful message
    else:
        raise AssertionError('Should have raised an exception')

    # called with invalid input (terms contains non-string)
    try:
        lm.run(terms=[1])
    except Exception as e:
        assert 'is not a string' in e.message # check we raise useful message
    else:
        raise AssertionError('Should have raised an exception')

    # called with invalid input (variables not a dict

# Generated at 2022-06-23 12:44:01.865651
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{vars}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tqm = None
    callback = None
   

# Generated at 2022-06-23 12:44:10.523295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test 1: checking the return values for the terms
    # with no option
    assert LookupModule().run(terms=['variablename'], variables={'variablename': 'hello'}, ) == ['hello']

    # test 2: checking the return values for the terms
    # with default option
    assert LookupModule().run(terms=['variablename', 'variablenotename'], variables={'variablename': 'hello'},
                              default='') == ['hello', '']

    # test 3: checking for the error without the default option
    # with terms having no source
    try:
        LookupModule().run(terms=['variablename', 'variablenotename'], variables={'variablename': 'hello'})
    except AnsibleError:
        assert True

# Generated at 2022-06-23 12:44:12.373027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Unit tests for constructor of class LookupBase

# Generated at 2022-06-23 12:44:14.206964
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(lm != None)

# Generated at 2022-06-23 12:44:26.532170
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myvars = {
            'variablename': 'hello',
            'ansible_play_hosts': ['host1', 'host2'],
            'ansible_play_batch': ['host1', 'host2'],
            'ansible_play_hosts_all': ['host1', 'host2'],
            'variablename_complex': {'sub_var': 12},
            'inventory_hostname': 'dummy_inventory_hostname',
            'hostvars': {
                'dummy_inventory_hostname': {
                    'dummy_var_for_hostvars': True
                }
            }
        }

    lu = LookupModule()
    test_term = 'variablename'

# Generated at 2022-06-23 12:44:34.269194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # term_list = ['jt_var1','jt_var2','jt_var1']
    # variables = {'inventory_dir':'/root', 'jt_var1':'value1', 'jt_var2':'value2'}
    # cb = LookupModule()
    # result = cb.run(terms=term_list, variables=variables)
    # assert result == ['value1', 'value2', 'value1']
    pass

# Generated at 2022-06-23 12:44:35.402718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:44:45.109229
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    try:
        lookup_module.run([1,2,3])
        assert False
    except AnsibleError:
        assert True


if __name__ == '__main__':
    import sys
    import json
    if len(sys.argv) > 1:
        print("lookup(%s)" % ",".join(sys.argv[1:]))
        result = LookupModule().run(terms=sys.argv[1:], variables={})
        print(json.dumps(result, indent=4))
    else:
        test_LookupModule()

# Generated at 2022-06-23 12:44:53.861216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader

    # Create a mock Templar object
    loader = DataLoader()
    variables = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources=StringIO())
    templar = Templar(loader=loader, variables=variables, inventory=inventory)

    # Create a mock HostVarsVars object
    hostvars = HostVarsVars(loader=loader, inventory=inventory)
    hostvars._set_variable('inventory_hostname', 'localhost')

# Generated at 2022-06-23 12:45:05.963216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test method run of class LookupModule
    """
    # Unit test for method run of class LookupModule that returns the value of a variable if it exists.
    mylookup = LookupModule()
    mylookup.set_loader({'vars': {'variablename': 'hello'}})
    assert mylookup.run([['variablename']], {'vars': {'variablename': 'hello'}}) == ['hello']

    # Unit test for method run of class LookupModule that returns the value of a variable if it exists in inventory hostvars.
    mylookup = LookupModule()
    mylookup.set_loader({'vars': {'hostvars': {'host1': {'variablename': 'hello'}}}})

# Generated at 2022-06-23 12:45:08.789942
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert a._templar
    assert a._loader
    assert a._loader._plugin_loaders
    assert a._loader._plugin_loaders.keys()

# Generated at 2022-06-23 12:45:10.643448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert type(test_lookup) is LookupModule


# Generated at 2022-06-23 12:45:16.161067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    class TestTemplar(object):
        def __init__(self):
            self._available_variables = {'hostvars': {'host_name':{'host_value':True}}}
            self.template = lambda x, fail_on_undefined=True: x
    lookup_module._templar = TestTemplar()
    assert lookup_module.run(['host_value'], None) == [True]

# Generated at 2022-06-23 12:45:26.210618
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.run(terms=["foo"]) == []
    assert module.run(terms=["foo"], variables={"foo": "bar"}) == ["bar"]
    assert module.run(terms=["foo"], variables={"hostvars": {}, "inventory_hostname": "localhost"}) == []
    assert module.run(terms=["foo"], variables={"hostvars": {"localhost": {"foo": "bar"}}, "inventory_hostname": "localhost"}) == ["bar"]
    assert module.run(terms=["foo"], variables={"hostvars": {"other": {"foo": "bar"}}, "inventory_hostname": "localhost"}) == []

# Generated at 2022-06-23 12:45:27.494587
# Unit test for constructor of class LookupModule
def test_LookupModule():

    my_obj = LookupModule()
    assert my_obj

# Generated at 2022-06-23 12:45:31.073990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # TODO: convert to py3 and add a test
    lookup.run(["variablename"], {"variablename":"hello", "myvar":"ename"})

# Generated at 2022-06-23 12:45:33.193382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test valid constructor
    assert(LookupModule(loader=None, templar=None, shared_loader_obj=None))

# Generated at 2022-06-23 12:45:42.493071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    import sys

    # Set display
    display = Display()
    display.verbosity = 3

    # Set templar
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=variable_manager)
    templar._available_variables = dict(foo='bar')

    # Set lookup module
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=templar._available_variables, direct=dict())

    sys.stdout.write("Unit test for method run of class LookupModule\n")


# Generated at 2022-06-23 12:45:43.717404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookup = LookupModule()
    assert isinstance(myLookup, LookupModule)


# Generated at 2022-06-23 12:45:49.397995
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test successful lookup
    terms = ['ansible_play_hosts']
    variables = { 'ansible_play_hosts': 'localhost' }
    lookup_module = LookupModule()
    ret = lookup_module.run(terms, variables)
    assert ret == ['localhost']

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = { 'ansible_play_hosts': 'localhost' }
    lookup_module = LookupModule()
    ret = lookup_module.run(terms, variables)
    assert ret == ['localhost', '', '']

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

# Generated at 2022-06-23 12:45:53.468247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = {
        'my_var' : 'my_value',
        'my_nested_var': {'my_dict_value': 'my_dict_result'}
    }

    lookup_result = LookupModule().run(['my_var', 'not_existing_var', 'my_nested_var.my_dict_value'], variables=data)

    assert lookup_result == ['my_value', None, 'my_dict_result']

# Generated at 2022-06-23 12:45:54.047484
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret is not None

# Generated at 2022-06-23 12:46:02.789491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["hostvar1", "hostvar2"]
    hostvar1 = "hostvar1"
    hostvar2 = "hostvar2"

    variables = dict()
    variables['hostvars'] = dict()
    variables['inventory_hostname'] = "test_host"
    variables['hostvars']['test_host'] = dict()
    variables['hostvars']['test_host']['hostvar1'] = hostvar1
    variables['hostvars']['test_host']['hostvar2'] = hostvar2

    ret = LookupModule().run(terms, variables)
    assert hostvar1 in ret
    assert hostvar2 in ret

# Generated at 2022-06-23 12:46:14.236747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
        Test case for the method "run" of class "LookupModule" Check if the value
        of the variable returns the expected value
    '''
    vars = dict(
        ansible_play_hosts="play_hosts",
        ansible_play_batch="play_batch",
        ansible_play_hosts_all="play_hosts_all",
        ansible_play_batch="play_batch",
        variablename="hello",
        myvar="ename",
    )
    terms = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]
    res = LookupModule().run(terms=terms, variables=vars)
    assert res == ["play_hosts", "play_batch", "play_hosts_all"]

# Generated at 2022-06-23 12:46:21.568651
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_vars
    test_vars = {
        "inventory_hostname": "inventory_hostname_test",
        "hostvars": {
            "inventory_hostname_test": {
                "test_lookup_var": "a value",
                "test_lookup_var_2": 12,
            }
        }
    }

    # test_terms
    test_terms = {
        "test_lookup_var",
        "test_lookup_var_2",
    }

    test_lookup_module = LookupModule()

    test_result = test_lookup_module.run(terms=test_terms, variables=test_vars)

# Generated at 2022-06-23 12:46:33.325540
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock object of class LookupBase
    class_LookupBase = LookupBase()

    # define class_LookupModule by invoking run()
    # method of LookupModule class
    class_LookupModule = LookupModule()
    class_LookupModule.run()

    # create a mock object of class LookupModule
    class_LookupModule = LookupModule()

    # define hostvars by initializing a dictionary
    hostvars = {}

    # set the attributes _templar and available_variables
    # of mock object named class_LookupBase
    setattr(class_LookupBase, '_templar', hostvars)
    setattr(class_LookupBase, 'available_variables', hostvars)

    # set the attribute _templar of mock object named
    # class_Look

# Generated at 2022-06-23 12:46:37.482033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars = {'myvar0': 'test0',
              'myvar1': 'test1',
              'myvar2': 'test2',
              'hostvars': {
                  'host1': {'myvar3': 'test3'},
                  'host2': {'myvar4': 'test4'}}}

    a = {'default': 'default', 'var_options': myvars}

# Generated at 2022-06-23 12:46:49.474466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible import context
    import pytest

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_host_variable(Host(name='host1'), 'name', 'host1')
    variable_manager.set_host_variable(Host(name='host1'), 'nested', {'name': 'nested'})

    variable_manager.set_host_variable(Host(name='host2'), 'name', 'host2')

# Generated at 2022-06-23 12:46:50.705243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None


# Generated at 2022-06-23 12:47:01.241327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case #1
    lookup_module = LookupModule()
    variables = 'variablename'
    terms = 'variablename'
    myvars = {'variablename': 'hello'}
    lookup_module._templar.available_variables = myvars
    result = lookup_module.run(terms, variables=myvars)
    assert result == ['hello']

    # Test case #2
    lookup_module = LookupModule()
    terms = 'variablename'
    myvars = {'variablename': 'hello'}
    lookup_module._templar.available_variables = myvars
    result = lookup_module.run(terms, variables=myvars)
    assert result == ['hello']

# Generated at 2022-06-23 12:47:07.679267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert (LookupModule().run(["test"]))
    assert (LookupModule().run(["test"], {"test": "test"}))
    assert (LookupModule().run(["test"], {"test": 1}))
    assert (LookupModule().run(["test"], {"test": ""}))
    assert (LookupModule().run(["test"], {"test": {"test": "test"}}))

# Generated at 2022-06-23 12:47:11.527506
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test when terms is not a list
    temp_templar = DummyTemplar()
    assert_raises(AnsibleError, LookupModule, temp_templar, "terms", [], {})

    # Test when terms is not a string type
    temp_templar = DummyTemplar()
    assert_raises(AnsibleError, LookupModule, temp_templar, [1,2,3], ['hostvars', 'inventory_hostname'], {})


# Generated at 2022-06-23 12:47:21.744008
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup mocks
    ansible_vars = {'hostvars': {'host1': {'var1': 'value1'}}}
    templar = lambda value: value
    templar.available_variables = ansible_vars
    templar.template = lambda value, fail_on_undefined: value
    templar._available_variables = ansible_vars

    # Run
    lookup_module = LookupModule()
    lookup_module._templar = templar
    res = lookup_module.run(terms=['var1'])

    # Assert
    assert res == ['value1']



# Generated at 2022-06-23 12:47:23.849124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)

# Generated at 2022-06-23 12:47:31.822972
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import os
    # use the system Ansible, so env vars will be loaded
    current_dir = os.getcwd()
    lookup_dir = os.path.dirname(os.path.dirname(__file__))
    ansible_dir = os.path.normpath(os.path.join(lookup_dir, '../../..'))
    os.chdir(ansible_dir)
    sys.path.insert(0, os.path.join(ansible_dir, 'lib'))
    import ansible
    import ansible.utils.vars
    import ansible.template
    import ansible.parsing.yaml.objects

    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-23 12:47:35.473002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access

    # test with empty terms
    module = LookupModule()
    try:
        module.run([])
        assert False
    except AnsibleError:
        assert True

    # test with string and int in the list
    module = LookupModule()
    try:
        module.run([1, '2'])
        assert False
    except AnsibleError:
        assert True

    # test with 'No variable found with this name: test'
    terms = ['test']
    module = LookupModule()
    try:
        module.run(terms)
        assert False
    except AnsibleError:
        assert True

    # test with 'No variable found with this name: test2'
    terms = ['test1', 'test2']
    module = LookupModule()

# Generated at 2022-06-23 12:47:40.940006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {
        'hostvars': {
            'hostname': {
                'hello': 1,
            },
        },
        'a': 1,
        'b': 2,
    }
    results = lookup_module.run(['a', 'b', 'hello'], variables={})
    assert results == [1, 2, 1]

# Generated at 2022-06-23 12:47:53.113205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # before base class is instantiated, the following keys were added to the dict.
    # those keys are required to avoid KeyErrors on lookups
    myvars = {
        'inventory_hostname': 'test_inventory_hostname',
        'hostvars': {
            'test_inventory_hostname': {
                'test_hostvar': 'test_hostvar_value'
            }
        }
    }

    # we have to instantiate the base class LookupModule
    # because it contains some initialization logic that is executed in the init method
    lookup_plugin = LookupModule()

    # the templar is not initialized as of ansible version 2.7.1
    # this also means we do not have _available_variables set
    # workaround: set it manually, so the lookup actually works
    lookup_plugin._templar

# Generated at 2022-06-23 12:48:02.614625
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from jinja2.exceptions import UndefinedError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar

    module = LookupModule()
    terms = AnsibleUnicode('variablename')
    variables = dict(variablename=AnsibleUnicode('hello'))
    templar = Templar(variables=variables)

    try:
        module.run(terms, variables=variables)
    except AnsibleError:
        assert 0

    try:
        module.run(terms, variables=variables, default='')
    except AnsibleError:
        assert 0


# Generated at 2022-06-23 12:48:14.651352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor


    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """


# Generated at 2022-06-23 12:48:24.290154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    hostvars = dict(local=dict())
    # create options
    options = dict()
    # create var_options
    var_options = dict()
    # initialize lookup module
    lookup = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    # set options
    lookup.set_options(var_options, options=options)
    # set _available_variables
    lookup._templar._available_variables = {'hostvars': hostvars}
    # define terms
    terms = ['local']
    # test run method
    assert lookup.run(terms=terms, variables=None) == [{}]

# Generated at 2022-06-23 12:48:32.858800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    import pytest

    # class LookupModule has no __init__ method
    lookup_module = LookupModule()

    # tests/unit/plugins/lookup/test_vars.py::test_LookupModule_run::test_01a
    #
    # Test with terms not a list
    #
    # terms must be a list
    terms = 'company name'
    variables = {}
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run(terms=terms, variables=variables)
    assert 'Invalid setting identifier' in str(excinfo.value)

    # tests/unit/plugins/lookup/test_vars.py::test_LookupModule_run::test_01b
    #
    # Test with terms

# Generated at 2022-06-23 12:48:34.398965
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule() is not None)


# Generated at 2022-06-23 12:48:46.452321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.template import Templar
    import pytest
    import os

    # Create Ansible objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    # Create object of class LookupModule
    lm = LookupModule()

    # Create a dummy inventory
    myvars = {}
    myvars['hostvars'] = {}
    myvars['hostvars']['host1'] = {}
    myvars['hostvars']['host1']['var1'] = 'val1'
    myvars

# Generated at 2022-06-23 12:48:50.719118
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = []
    for term in ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']:
        results.append(term)
    assert results == ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

# Generated at 2022-06-23 12:48:51.682408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    constructor_test(LookupModule)

# Generated at 2022-06-23 12:48:53.279056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LUM = LookupModule()
    assert LUM.run(terms="myvar", variables={"myvar": "myvalue"}) == ["myvalue"]

# Generated at 2022-06-23 12:48:54.277305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-23 12:48:55.662219
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()
    assert mylookup is not None

# Generated at 2022-06-23 12:48:56.958513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:48:57.571421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:49:10.006506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()


# Generated at 2022-06-23 12:49:22.969516
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_function(terms, variables=None):
        my_lookup_module = LookupModule()
        my_lookup_module.set_options(var_options=variables)
        return my_lookup_module.run(terms, variables)

    # test with one term, a string, that is defined in variables
    terms = ['automation_type']
    variables = {'automation_type': 'alpha'}
    result = test_function(terms, variables)
    assert result == ['alpha']

    # test with one term, a string, that is defined as hostvar in variables
    terms = ['ansible_host']

# Generated at 2022-06-23 12:49:24.889655
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    assert c._templar.available_variables is not None

# Generated at 2022-06-23 12:49:28.237077
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    terms = ['foo', 'bar']
    variables = None
    module = LookupModule()
    module.run(terms, variables)
    assert module.set_options() == None

# Generated at 2022-06-23 12:49:31.462499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import nose2
    argv = sys.argv + ['-v']
    nose2.main(argv=argv, defaultTest=__file__)


# Test class LookupModule

# Generated at 2022-06-23 12:49:43.044852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {
        'inventory_hostname': 'localhost',
        'hostvars': {
            'localhost': {
                'ansible_connection': 'local',
                'ansible_hostname': 'localhost',
                'ansible_user': 'root'
            }
        }
    }
    assert lookup_module.run(terms=['ansible_user']) == ['root']
    assert lookup_module.run(terms=['ansible_hostname']) == ['localhost']
    assert lookup_module.run(terms=['ansible_hostname', 'ansible_user']) == ['localhost', 'root']
    assert lookup_module.run(terms=['ansible_not_exist'], default='test') == ['test']


# Generated at 2022-06-23 12:49:45.152073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import types
    assert isinstance(LookupModule, types.TypeType)


# Generated at 2022-06-23 12:49:51.484443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = ['test_term1', 'test_term2']
    test_variables = {'testkey1': 'testvalue1', 'testkey2': 'testvalue2'}
    test_kwargs = {'default': 'test_default'}
    # test unkown variable
    mylookup = LookupModule()
    mylookup.run(test_terms, test_variables, **test_kwargs)
    return

# Generated at 2022-06-23 12:49:52.572989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:49:53.823164
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:50:04.810536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variablename = {
            "sub_var": 12
    }

    myvar = "ename"
    variablenotename = "notaname"

    hostname = 'baz'

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)

    l = LookupModule()
    l.set_options(var_options=variablename, direct=dict())

    l.set_loader(templar)
    l.set_templar(templar)

    results = l.run([variablename], variables=variablename)

# Generated at 2022-06-23 12:50:14.213950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test LookupModule.run"""
    # pylint: disable=protected-access
    lm = LookupModule()
    lm.set_options({})
    myvars = {
        'a': 1,
        'b': 2,
        'ansible_play_hosts': 3,
        'ansible_play_batch': 4,
        'ansible_play_hosts_all': 5,
        'hostvars': {
            'my_host': {
                'c': 6,
                'd': 7
            }
        }
    }
    expected = []
    actual = lm.run(terms=['a'], variables=myvars, **lm.options)
    assert actual == expected, "'a' returns %s, expected %s" % (actual, expected)


# Generated at 2022-06-23 12:50:21.273813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    # Testing with good input
    lu.set_options(var_options = {})

# Generated at 2022-06-23 12:50:28.153358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    hostvars = {'a': {"ansible_play_hosts": "a"}}
    variables = {'ansible_play_hosts': "b", 'ansible_play_batch': "c",'ansible_play_hosts_all': "d", 'hostvars': hostvars}
    assert lookup.run(terms, variables) == ['b', 'c', 'd']

# Generated at 2022-06-23 12:50:38.959831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    lm = LookupModule(
        loader=dl,
        templar=dl)
    lm._templar._available_variables = {'inventory_hostname': 'localhost'}

    assert lm.run([
        'inventory_hostname'
    ]) == ['localhost']
    assert lm.run([
        'not_exists'
    ]) == []
    try:
        lm.run([
            'not_exists'
        ], None, default=None)
    except AnsibleUndefinedVariable:
        pass
    else:
        raise Exception('Expected AnsibleUndefinedVariable')

# Generated at 2022-06-23 12:50:46.382676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from units.mock.loader import DictDataLoader

    # Expected result needed for compare output of test
    expected_result = ['hello']

    # Input needed to get expected output
    term = ['variablename']


    # Variables needed to run test
    inventory = dict(
        hostvars=dict(
            localhost=dict(variablename='hello', ansible_connection='local')))

    loader = DictDataLoader(inventory)
    variable_manager = VariableManager()

    # Run test
    lm = LookupModule()
    result = lm.run

# Generated at 2022-06-23 12:50:56.973085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=no-self-use
    from ansible.plugins.lookup import LookupModule
    import ansible.plugins
    import ansible.parsing.dataloader
    import ansible.vars

    mylook = LookupBase()
    mylook.set_options(direct=dict())
    mylook.basedir = '/tmp'
    mylook._loader = ansible.parsing.dataloader.DataLoader()
    mylook._templar = ansible.vars.VariableManager()
    mylook._templar._available_variables = dict()

    variables = dict()
    variables['test_variables'] = 'test_val'
    variables['test_nested_variables'] = dict()

# Generated at 2022-06-23 12:50:57.562472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:51:06.764817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for method run of class LookupModule
    """
    # Set Ansible variables
    variables = dict()
    variables['variablename'] = 'hello'
    variables['myvar'] = 'ename'
    variables['hostvars'] = dict()
    variables['hostvars']['localhost'] = dict()
    variables['hostvars']['localhost']['ansible_play_hosts'] = 'localhost'
    variables['hostvars']['localhost']['ansible_play_batch'] = 'localhost'
    variables['hostvars']['localhost']['ansible_play_hosts_all'] = 'localhost'
    variables['inventory_hostname'] = 'localhost'

    # Set arguments of method run

# Generated at 2022-06-23 12:51:18.971686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    terms = ['hello']
    variables = {'hello': 'world'}
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_fact('hello', 'world')
    lookup_plugin = LookupModule()

    # Testing without fail_on_undefined
    result = lookup_plugin.run(terms, variables, variable_manager._fact_cache)
    assert result == ['world']

    # Testing with fail_on_undefined
    result = lookup_plugin.run(terms, variables, variable_manager._fact_cache, True)
    assert result == ['world']

    # Testing with fail_on_undefined and a bad variable name
    terms = ['hello_world']
