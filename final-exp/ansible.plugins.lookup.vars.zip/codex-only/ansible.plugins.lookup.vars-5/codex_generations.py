

# Generated at 2022-06-23 12:41:14.534846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module._templar.available_variables == None
    assert getattr(module._templar, '_available_variables', {}) == {}

# Generated at 2022-06-23 12:41:27.080007
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        from ansible.constants import DEFAULT_VAULT_ID_MATCH
        from ansible.utils.vault import VaultLib
    except ImportError:
        class FakeVaultLib(object):
            def __init__(self, password, vault_ids):
                pass
        VaultLib = FakeVaultLib

# Generated at 2022-06-23 12:41:30.248664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        assert isinstance(LookupModule(), LookupModule)
    except Exception as e:
        print(e)


# Generated at 2022-06-23 12:41:38.762900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    myvars = obj._templar._available_variables
    myvars['inventory_hostname'] = 'test_host'
    myvars['hostvars'] = {'test_host': {'ansible_play_hosts': 'something', 'ansible_play_hosts_all': ['host1', 'host2']}}
    terms = ['ansible_play_hosts', 'ansible_play_hosts_all']
    result = obj.run(terms)
    assert result == ['something', ['host1', 'host2']]

# Generated at 2022-06-23 12:41:42.780637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_object = LookupModule()
    assert my_object.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']) == ["hosts", "all", "hosts[:]"]

# Generated at 2022-06-23 12:41:44.866146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x._templar is None
    assert x._loader is None
    assert x._available_variables == {}

# Generated at 2022-06-23 12:41:57.839261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.context import context
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar

    context.CLIARGS = {'module_path': 'lib/ansible/modules/commands'}
    context._init_global_context(context.CLIARGS)

    # Using direct=True to mimic the CLI invocation
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/cli/playbook.py#L629

# Generated at 2022-06-23 12:42:01.897889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create lookup
    lookup_obj = LookupModule()
    lookup_obj._options = {}
    lookup_obj._templar = None
    # Create the test variables
    test_variables = {
        'myvar': 'value'
    }
    # Run the test and assert results
    assert lookup_obj.run(
        terms = ['myvar'],
        variables = test_variables
    ) == ['value']


# Generated at 2022-06-23 12:42:07.720613
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #  # Constructor args
    #  tup_args = ()
    #  dic_args = {}
    #
    #  # Constructor
    #  instance = LookupModule(*tup_args, **dic_args)
    pass


# Generated at 2022-06-23 12:42:08.771590
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:42:11.358837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    assert 'default' in lookup_module.VALID_OPTIONS

# Generated at 2022-06-23 12:42:13.916782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['hello_world'], variables=dict(hello_world=['hello', 'world']))
    assert result == [['hello', 'world']]

# Generated at 2022-06-23 12:42:15.277626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupModule)

# Generated at 2022-06-23 12:42:23.344990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit Test for lookup module LookupModule '''

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.lookup.vars import LookupModule

    from ansible.template import Templar

    lookup_module = LookupModule()

    terms = (to_text('test_variable'),)
    variables = {'test_variable': to_text('Hello'), 'test': 'world'}
    assert lookup_module.run(terms, variables) == [to_bytes('Hello')]

    # Invalid Setting Identifier

    # TODO: Add test for type error

    # KeyError in Available Variable

    # TODO: Add test for KeyError


# Generated at 2022-06-23 12:42:24.649173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass


# Generated at 2022-06-23 12:42:26.581289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert isinstance(lookup_mod, LookupModule)


# Generated at 2022-06-23 12:42:30.336420
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    ret = lm.run("test_var", variables={'test_var': "test_value"})
    assert ret.__contains__("test_value")


# Generated at 2022-06-23 12:42:39.136644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    t = Templar()

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': ['a', 'b', 'c'], 'ansible_play_batch': ['d', 'e', 'f'], 'ansible_play_hosts_all': ['g', 'h', 'i']}
    lm = LookupModule(templar=t)
    result = lm.run(terms, variables=variables)
    assert result == [['a', 'b', 'c'], ['d', 'e', 'f'], ['g', 'h', 'i']]

    terms = ['ansible_play_batch']

# Generated at 2022-06-23 12:42:40.624196
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 12:42:45.845384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This part is just to initialize the different variables
    # The reason why we are not using a JSON file to make this test is to avoid having to load a JSON file
    # in order to run the test.
    templar = {}
    templar["_available_variables"] = {
        'hostvars': {
            'host1': {
                'host_variable': 1
            }
        },
        'my_variable': 'my_value',
        'my_list': ['item1', 'item2', 'item3'],
        'my_dict': {
            'key1': 'item1',
            'key2': 'item2',
            'key3': 'item3'
        },
        'inventory_hostname': 'host1'
    }

    lookup_module = LookupModule()
    lookup_

# Generated at 2022-06-23 12:42:56.656065
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    a = LookupModule(None, {})

    ###############
    # im done puny human! run along!
    #################
    assert (a.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], {"ansible_play_hosts": "hello", "ansible_play_batch": "human", "ansible_play_hosts_all": "ansible_play_hosts"}) == ['hello', 'human', 'ansible_play_hosts'])
    assert (a.run(['variables'], {}) == [])

    #################
    # i will always return an empty list
    #################
    assert(a.run([], {}) == [])

    ###############
    # return an empty list if all the values do

# Generated at 2022-06-23 12:43:04.688427
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test normal retrieval of variable without fail_on_undefined=True
    terms = ['my_var']
    variables = {'my_var': 'value'}
    assert LookupModule().run(terms, variables) == ['value']

    # test retrieval of undefined variable with fail_on_undefined=True
    try:
        LookupModule().run(terms, variables, fail_on_undefined=True)
    except AnsibleUndefinedVariable:
        pass
    else:
        assert False, 'AnsibleUndefinedVariable wasn\'t raised'

    # test retrieval of undefined variable with fail_on_undefined=False
    variables = {'my_var': '{{ undefined_var }}'}
    assert LookupModule().run(terms, variables) == ['']

    # test retrieval of undefined variable with default

# Generated at 2022-06-23 12:43:06.767169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test if LookupModule class runs without errors
    lookup_module = LookupModule()
    value = lookup_module.run(["inventory_dir"])

    # test return value of method `run`
    assert isinstance(value[0], (AnsibleUnsafeText, str, bytes))

# Generated at 2022-06-23 12:43:15.933388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Should return 'hello'
    assert LookupModule().run([u"variablename"], variables={"variablename": "hello"}) == ['hello']
    # Should return 'hello'
    assert LookupModule().run([u"variablename"], variables={u"variablename": u"hello"}) == ['hello']
    # Should return 'hello'
    assert LookupModule().run([u"variablename"], variables={u"variablename": True}) == [True]

    # Should find nothing and return default value ''
    assert LookupModule().run([u"variablnotename"], default='', variables={u"variablename": u"hello"}) == ['']

    # Should return KeyError

# Generated at 2022-06-23 12:43:20.936462
# Unit test for constructor of class LookupModule
def test_LookupModule():
    source = dict([("hostvars", "hostvars"), ("inventory_hostname", "inventory_hostname"), ("variablename", "hello"), ("myvar", "ename")])
    lkm = LookupModule(None, source)
    assert lkm._templar._available_variables == source

# Generated at 2022-06-23 12:43:21.846086
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:43:33.035078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run without default value
    myLookupModule = LookupModule()
    myLookupModule._templar._available_variables = {
        'variable_1' : 'test_variable',
        'variable_2' : 'test_variable_2',
        'hostvars': {
            'test_host' : {
                'variable_3': 'test_variable_3',
                'variable_4': 'test_variable_4'
                }
            }
        }
    assert myLookupModule.run(['variable_1', 'variable_2']) == ['test_variable', 'test_variable_2']
    assert myLookupModule.run(['variable_3']) == ['test_variable_3']
    assert myLookupModule.run(['variable_4']) == ['test_variable_4']

# Generated at 2022-06-23 12:43:34.530571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookupmodule = LookupModule()
    assert mylookupmodule != None

# Generated at 2022-06-23 12:43:37.631604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # executed our function but check the value is correct
    lookup = LookupModule()
    lookup.set_loader(False)
    lookup.set_templar(False)
    terms = ["myvar"]
    variables={'hostvars': {}, 'myvar': "value"}

    ret = lookup.run(terms, variables=variables)
    assert ret[0] == "value"

# Generated at 2022-06-23 12:43:43.817438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # Test for parse fail must be first since it cannot be tested otherwise (no way to force a parse fail)
        lm = LookupModule()
        lm.run(terms=10)
    except AnsibleError as e:
        if not isinstance(e.message, string_types) or 'Invalid setting identifier, "10" is not a string' not in e.message:
            raise

    # No args - error
    lm = LookupModule()
    try:
        lm.run(terms=[])
    except AnsibleError as e:
        if not isinstance(e.message, string_types) or 'Must supply at least one value to vars lookup' not in e.message:
            raise

    # No associated vars - error
    lm = LookupModule()

# Generated at 2022-06-23 12:43:46.552982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(terms=['variablename'], variables={'variablename': ['hello']}) == ['hello']

# Generated at 2022-06-23 12:43:59.424736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()
 
    # get the attributes of the object
    test_object_attr = vars(test_class)
    # test_object_attr["_templar"]._available_variables = { "inventory_hostname": "localhost", "hostvars": { "localhost": { "ansible_os_family": "my_os_family" } } }
    test_object_attr["_templar"] = 'test'

    result = test_class.run(terms=["ansible_os_family"])
    assert result == ['my_os_family']

    # test runner with undefined variable
    with pytest.raises(AnsibleUndefinedVariable) as excinfo:
        result = test_class.run(terms=["my_undefined_variable"])

# Generated at 2022-06-23 12:44:00.259468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO
    pass

# Generated at 2022-06-23 12:44:12.184926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'default': '0'})
    variables = {'inventory_hostname': 'test_host', 'hostvars': {
        'test_host': {'variable': 'ansible_variable'}
    }}
    # check template variable
    terms = ['ansible_variable']
    result = lookup_module.run(terms, variables)
    print('result: %s' % result)
    assert result == ['ansible_variable']
    # check nested template variable
    terms = ['variable']
    result = lookup_module.run(terms, variables)
    print('result: %s' % result)
    assert result == ['ansible_variable']
    # check default value
    terms = ['undefined_variable']
   

# Generated at 2022-06-23 12:44:19.289091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = (('ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'), {
        "ansible_play_batch": "batch",
        "ansible_play_hosts": "hosts",
        "ansible_play_hosts_all": "hosts_all"
    })
    result = LookupModule().run(*args)
    assert result == ["hosts", "batch", "hosts_all"]

# Generated at 2022-06-23 12:44:22.941782
# Unit test for constructor of class LookupModule
def test_LookupModule():
  terms = ['term1']
  lookup = LookupModule(loader=None, templar=None, shared_loader_obj=None)
  lookup.run(terms, variables=None)
  # todo

# Generated at 2022-06-23 12:44:35.329954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize the class LookupModule
    lookup_module = LookupModule()
    # initialize an empty dict for variables
    variables = dict()
    # set a value for the key 'variablename'
    variables['variablename'] = 'hello'
    # set a value for the key 'myvar'
    variables['myvar'] = 'ename'
    # set a value for the key 'inventory_hostname'
    variables['inventory_hostname']= 'test'
    # set a value for the key 'hostvars'
    variables['hostvars'] = dict()
    # set a value for the key 'variablename' of inner dict
    variables['hostvars']['test'] = dict()
    variables['hostvars']['test']['variablename'] = 'hello'
    # call the

# Generated at 2022-06-23 12:44:41.497732
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.utils.template

    mylookup = LookupModule(loader=None, templar=ansible.utils.template.Templar(loader=None), parser=None)
    assert mylookup.loader == None
    assert mylookup.templar._available_variables == {}
    assert mylookup.parser == None



# Generated at 2022-06-23 12:44:51.695732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ##################
    # Test for error #
    ##################
    # init
    from ansible.template import Templar

    templar = Templar(loader=None)
    lookup_module = LookupModule()
    lookup_module._templar = templar

    # test for error
    with pytest.raises(AnsibleError) as excinfo:
        templar._available_variables = {'host1' : 'value1'}
        lookup_module.run(terms=[123], variables=templar._available_variables)

    assert 'Invalid setting identifier, "123" is not a string, its a ' in str(excinfo.value)


# Generated at 2022-06-23 12:45:03.806609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class mock_loader():
        def __init__(self):
            self.path_info = {
                'module_utils': [
                    '/home/adam/.ansible/plugins/module_utils/',
                    '/usr/share/ansible/plugins/module_utils/'
                ]
            }
        def get_basedir(self, term):
            return term
        def load_plugin(self, term, component):
            return term
    class mock_variable_manager():
        def __init__(self):
            self.extra_vars = [
                {
                    'inventory_hostname': True
                }
            ]
    class mock_templar():
        def __init__(self):
            self.template = 'load_template'

# Generated at 2022-06-23 12:45:14.210585
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class MockVarsModule():
        def __init__(self):
            self.available_variables = None
            self._available_variables = None
            self._templar = Templar(loader=None, variables={})

        def set_available_variables(self, variables):
            self.available_variables = variables
            self._available_variables = variables

    class MockTemplar():
        def __init__(self, loader, variables):
            self._loader = loader
            self._available_variables = variables
            self.available_variables = variables

        def template(self, template, fail_on_undefined=False):
            return template


# Generated at 2022-06-23 12:45:19.724399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tuple_name = ("testkey", "testvalue")
    assert_string = "No variable found with this name: %s" % tuple_name
    try:
        LookupModule.run({"_terms": {"default": "test", tuple_name: "test"}})
    except AnsibleUndefinedVariable as error:
        assert error.message == assert_string

# Generated at 2022-06-23 12:45:28.225746
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test for undefined variable
    lookup = LookupModule()
    lookup._templar = object()
    lookup._templar._available_variables = dict()
    lookup._templar.template = lambda x, fail_on_undefined=True: x
    try:
        lookup.run(["test_not_defined"])
    except AnsibleUndefinedVariable:
        pass
    else:
        raise Exception("Failed to find undefined variable 'test_not_defined'")

    # test for defined variable
    lookup = LookupModule()
    lookup._templar = object()
    lookup._templar._available_variables = dict()
    lookup._templar._available_variables["test_defined"] = "var_value"

# Generated at 2022-06-23 12:45:35.056148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    myvars = {'a': '123', 'b': '456', 'c': 777, 'd': {'da': 'abc', 'db': 'xyz'}, 'hv': {'h1': {'h1a': 'cba', 'h1b': 'zyx'}}}
    l._templar._available_variables = myvars
    myvars = getattr(l._templar, '_available_variables')

    assert(l.run(['a'], myvars) == ['123'])
    assert(l.run(['a', 'b', 'c'], myvars) == ['123', '456', '777'])

    # nested variables

# Generated at 2022-06-23 12:45:36.400786
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(run_once=True, basedir=None, runner=None, templar=None, loader=None)

# Generated at 2022-06-23 12:45:40.802184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    hostvars_test = {'test_host':{'test_var':'test_value'}}
    vars_test = {'hostvars': hostvars_test, 'inventory_hostname': 'test_host'}
    ret = l.run(['test_var'], vars_test)
    assert ret == ['test_value']

# Generated at 2022-06-23 12:45:47.986033
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' == LookupModule.__name__
    assert 'lookup_plugins.vars' == LookupModule.__module__
    # test for the instance creation of class LookupModule
    args = [
        [
            'variablename'
        ], 'variables', 'kwargs'
    ]
    # creating the instance of class LookupModule
    test_instance = LookupModule(args)
    assert test_instance



# Generated at 2022-06-23 12:45:49.966746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    lm.set_options(var_options={})
    assert lm.get_option('default') is None

# Generated at 2022-06-23 12:46:00.329696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_batch', 'ansible_variable_to_be_set_to_default', 'ansible_variable_to_be_set_to_none', 'ansible_variable_to_be_set_to_null', 'ansible_variable_to_be_set_to_empty_string']
    variables = {
        'ansible_play_batch': 'fake_play_batch',
        'ansible_variable_to_be_set_to_default': 'variable_to_be_set_to_default',
        'ansible_variable_to_be_set_to_none': None,
        'ansible_variable_to_be_set_to_null': '',
        'ansible_variable_to_be_set_to_empty_string': ''
    }
    kwargs

# Generated at 2022-06-23 12:46:01.777017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert type(module) is LookupModule

# Generated at 2022-06-23 12:46:04.439997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.display import Display
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(["inventory_hostname"])
    assert result is not None


# Generated at 2022-06-23 12:46:11.084547
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)
    assert hasattr(lookup_module, '_templar')
    assert hasattr(lookup_module, '_options')
    assert hasattr(lookup_module, '_display')
    assert hasattr(lookup_module, 'set_options')
    assert hasattr(lookup_module, 'get_option')
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-23 12:46:11.676095
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:46:13.504701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True


# Generated at 2022-06-23 12:46:25.214633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    t = Templar(loader=None)
    l = LookupModule()
    l.set_loader(t)

    ##############################################
    # Method run should fail if the template
    # doesn't resolve to a string
    ##############################################
    terms=[1,2,3]
    try:
        l.run(terms=terms)
    except AnsibleError as e:
        assert isinstance(e.message, string_types)
    else:
        assert False, "run({}) should raise an exception".format(terms)

    ##############################################
    # Method run should fail if any of the terms
    # is not a string
    ##############################################
    terms=[1,'',3]


# Generated at 2022-06-23 12:46:26.638761
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for class LookupModule"""
    # pass
    return

# Generated at 2022-06-23 12:46:37.791339
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'myvar':'ename'}

    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_src =  dict(
            name = "Show value of 'variablename'",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', msg="{{ lookup('vars', 'variabl' + myvar) }}"))
            ]
        )

# Generated at 2022-06-23 12:46:39.090356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:46:50.256229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize a variable
    myvars = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'var':'this a variable',
                                                              'othervar':'this is another variable'}}}
    templar = DummyTemplar(available_variables=myvars)
    lookup_module = LookupModule(loader=DummyLoader(), templar=templar)
    # try to get a variable that should exist
    assert lookup_module.run(terms=['var']) == ['this a variable']
    # try to get a variable that does not exist
    assert lookup_module.run(terms=['notvar'], variables=myvars) == ['']
    # try to get a variable that should exist, but not defined at this level

# Generated at 2022-06-23 12:47:01.193948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # method run of class LookupModule
    hostvars = {"localhost": {"ansible_play_hosts": ['localhost']}}
    inventory_hostname = 'localhost'
    templar = MagicMock()
    templar.template.return_value = 'localhost'
    templar._available_variables = {'ansible_play_hosts': ['localhost'],
                                    'inventory_hostname': 'localhost',
                                    'hostvars': hostvars}
    module = LookupModule()
    module._templar = templar
    terms = ['ansible_play_hosts']
    assert module.run(terms) == ['localhost']

    templar.template.return_value = 'localhost'

# Generated at 2022-06-23 12:47:11.775741
# Unit test for constructor of class LookupModule
def test_LookupModule():
    loader = DictDataLoader({'_vars/vars.yml': """
    variable1: "Test Variable"
    variable2:
      - "first value"
      - "second value"
    variable3:
      variable3a: "Test variable 3a"
      variable3b: "Test variable 3b"
    """})
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(Inventory(loader=loader))
    lookup_interface = LookupModule()
    lookup_interface.set_runner(PlaybookRunner(loader=loader, variable_manager=variable_manager))

    # check that retriving an existing variable works
    assert lookup_interface.run(terms=['variable1']) == ['Test Variable']
    # check that retriving nested variables works

# Generated at 2022-06-23 12:47:19.625125
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    LookupModule class constructor
    """
    # Create class of type LookupModule
    x = type('LookupModule', (LookupModule,), dict(LookupModule.__dict__))()

    # LookupModule variables
    assert x.run == LookupModule.run
    assert x._options == {}
    assert x._fail_on_undefined_options == False

    # LookupBase variables
    assert x._loader is not None
    assert x._templar is not None
    assert x._loader_templar is not None

# Generated at 2022-06-23 12:47:30.180827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a test object
    obj = LookupModule()

    # Test for:
    # check for error if terms is not a string
    terms = [1, 2]
    variables = {'test': 'ansible', 'hey': 'ansible2'}
    try:
        obj.run(terms, variables)
    except AnsibleError as err:
        assert 'Invalid setting identifier' in err.message

    # Test for:
    # check for error if term value is not defined
    # when term value is not defined and there is no
    # variable named in **kwargs
    terms = ['test']
    variables = {'test': 'ansible', 'hey': 'ansible2'}
    try:
        obj.run(terms, variables)
    except AnsibleError as err:
        assert 'No variable found with this name'

# Generated at 2022-06-23 12:47:31.432969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:47:40.980739
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:47:53.114323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['variablename', 'myvar']
    variables = {'variablename': {'sub_var' : 12}, 'myvar': 'ename'}
    test_class = LookupModule()
    result = test_class.run(terms, variables)
    assert result == [{'sub_var': 12}, 'ename']

    terms = ['variablename', 'myvar', 'default']
    variables = {'variablename': {'sub_var' : 12}, 'myvar': 'ename', 'default': ''}
    test_class = LookupModule()
    result = test_class.run(terms, variables)
    assert result == [{'sub_var': 12}, 'ename', '']

    terms = ['variablename', 'myvar']

# Generated at 2022-06-23 12:48:01.107663
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestClass:
        def __init__(self):
            self.var = "hello"

    test_obj = TestClass()
    test_obj._templar = test_obj
    test_obj.set_options = test_obj
    test_obj.get_option = test_obj

    ret = LookupModule().run([ 'var' ], variables=test_obj, default='goodbye')
    assert ret[0] == "hello"

    ret = LookupModule().run([ 'nope' ], variables=test_obj, default='goodbye')
    assert ret[0] == "goodbye"

# Generated at 2022-06-23 12:48:13.010973
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test empty terms
    terms = []
    variables = dict()
    variables["test_variable"] = "test_value"
    my_lookup_module = LookupModule()
    result = my_lookup_module.run(terms, variables)
    assert result == []

    # Test no variable
    terms = ["test_variable"]
    variables = dict()
    my_lookup_module = LookupModule()
    result = my_lookup_module.run(terms, variables)
    assert result == []

    # Test one variable
    terms = ["test_variable"]
    variables = dict()
    variables["test_variable"] = "test_value"
    my_lookup_module = LookupModule()
    result = my_lookup_module.run(terms, variables)
    assert result == ["test_value"]



# Generated at 2022-06-23 12:48:15.189185
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert isinstance(test_lookup, LookupModule)

# Generated at 2022-06-23 12:48:17.899624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 12:48:27.932884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a lookup module
    lookup_module = LookupModule()
    # Create variables for testing
    term_list = [ 'variablename', 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all' ]
    test_vars = { 'variablename': 'hello', 'myvar': 'ename', 'ansible_play_hosts': [ 'localhost', 'example.com' ], 
                  'ansible_play_batch': 0, 'ansible_play_hosts_all': [ 'localhost', 'example.com' ] }
    # Test run method
    result = lookup_module.run(term_list,test_vars)
    assert result[0] == 'hello'
    assert result[1] == [ 'localhost', 'example.com' ]
   

# Generated at 2022-06-23 12:48:30.725202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m.run(['ansible_play_hosts','ansible_play_batch','ansible_play_hosts_all']) == [None, None, None], "must be..."

# Generated at 2022-06-23 12:48:31.956248
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module, "Module was not created"

# Generated at 2022-06-23 12:48:43.663289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Following taken from ansible/plugins/lookup/vars.py
    lm = LookupModule()

    # test case 1: run lookup with only one variable
    # needs to call set_options() to set private variable _options
    lm.set_options(var_options={'test_v1': 'test'})
    result_1 = lm.run(['test_v1'])
    assert result_1 == ['test']

    # test case 2: run lookup with two variables
    # needs to call set_options() to set private variable _options
    lm.set_options(var_options={'test_v1': 'test', 'test_v2': 'test'})
    result_2 = lm.run(['test_v1', 'test_v2'])

# Generated at 2022-06-23 12:48:51.764093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()
    t._templar = {}
    t._templar._available_variables = {'hostvars': {'testhost': {'port': '22'}}}
    t._templar._available_variables['inventory_hostname'] = 'testhost'
    # test that it correctly handles default
    assert ([''] == t.run(['port1']))
    t.set_options(direct={'default': 'default'})
    assert (['default'] == t.run(['port1']))
    t.set_options(direct={})
    # test that it correctly returns the value of the variable
    assert (['22'] == t.run(['port']))
    # test that it correctly raises error if its undefined

# Generated at 2022-06-23 12:48:58.387510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test module constructor
    lookup_module = LookupModule()
    assert lookup_module is not None
    # Test  run method
    test_variable_name = "test_var_name"
    test_variable_value = "test_value"
    terms = [test_variable_name]
    variables = {'hostvars': {'localhost': {test_variable_name: test_variable_value}}}
    ret = lookup_module.run(terms, variables)
    assert ret == [test_variable_value]

# Generated at 2022-06-23 12:49:07.038964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case N-1
    lookup_obj = LookupModule()
    with pytest.raises(AnsibleError) as exec_info:
        lookup_obj.run('term')
    assert 'Invalid setting identifier' in str(exec_info.value)
    # Test case N-1
    lookup_obj = LookupModule()
    with pytest.raises(AnsibleError) as exec_info:
        lookup_obj.run(['term'])
    assert 'Invalid setting identifier' in str(exec_info.value)

# Generated at 2022-06-23 12:49:09.318179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Test module constructor'''
    looker = LookupModule()
    # Check for attributes
    assert hasattr(looker, 'run')

# Generated at 2022-06-23 12:49:21.837503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_text
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib

    plain_text = u"This is a test"
    vault_secret = '$ANSIBLE_VAULT;1.1;AES256\n....\n....'
    terms = [u"name1", u"name2", u"name3"]

    # Case 1: no encryption
    variable = LookupModule()
    variable.set_options(direct={ '_original_basename': 'ansible' })
    variable._templar = variable._loader.get_basedir_loader(loader=variable._loader, basedir='.', variable_manager=None)
    variable._templar._available

# Generated at 2022-06-23 12:49:28.141667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        [["hostvars.host1.hostname", "hostvars.host1.group_names", "hostvars.host1.groups.infra.hosts"]]
        , {'hostvars': {'host1':{'hostname':'myhost1', 'group_names':['groupA', 'groupB'], 'groups':{'infra':{'hosts':['host1', 'host2', 'host3', 'host4']}}}}}
    )
    assert ret == [["myhost1", ["groupA", "groupB"], ['host1', 'host2', 'host3', 'host4']]]

    # Unamed group

# Generated at 2022-06-23 12:49:31.731137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create object
    testObject = LookupModule()
    
    # run method
    result = testObject.run(terms=['unit_test_variable'], variables=None, **{'default': None})
    
    # assert
    assert result

# Generated at 2022-06-23 12:49:43.398936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = None
    lookup._templar._available_variables = {'variablename':'hello', 'myvar':'ename', 'ansible_play_hosts':'1', 'ansible_play_batch':'2', 'ansible_play_hosts_all':'3'}
    lookup._templar._available_variables['hostvars'] = {'inventory_hostname':'whatever', 'variablename':'hello', 'myvar':'ename', 'ansible_play_hosts':'1', 'ansible_play_batch':'2', 'ansible_play_hosts_all':'3'}


    lookup.set_options(var_options={}, direct={'default':''})

# Generated at 2022-06-23 12:49:45.414283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert hasattr(LookupModule, 'run')



# Generated at 2022-06-23 12:49:48.425393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')
    assert hasattr(lookup, 'set_options')

# Generated at 2022-06-23 12:49:49.121741
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:49:57.369514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m.run(['BANANA'], {'BANANA': 'is the fruit!'}) == ['is the fruit!']
    assert m.run(['BANANA'], {'ANANAB': 'is the fruit!'}) == []
    assert m.run(['BANANA'], {'ANANAB': 'is the fruit!', 'default': 'not defined!'}) == ['not defined!']

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:49:59.785359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._templar = None
    l._loader = None
    assert type(l) is LookupModule

# Generated at 2022-06-23 12:50:20.272554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test example from documentation
    terms = ['variablename']
    variables = dict(variablename='hello')
    kwargs = dict(myvar='ename')

    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=variables, direct=kwargs)
    result = lookup_plugin.run(terms = terms, variables = variables, **kwargs)
    assert(result == ['hello'])

    # test nested variables
    terms = ['variablename']
    variables = dict(
        variablename=dict(
            sub_var='12'
        ),
        myvar='ename'
    )

    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=variables, direct=kwargs)
    result = lookup_plugin.run

# Generated at 2022-06-23 12:50:22.698213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    result = len(l.run(terms=terms, variables=variables))
    assert result == 3

# Generated at 2022-06-23 12:50:31.458391
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Test case with only one variable
    test = LookupModule(loader=None, templar=None, variable_manager=None)
    test._templar._available_variables = {
        "test": "hello",
        "test1": "hello1",
        "test2": ["test3", "test4", "test5"]
    }

    assert test.run(terms=['test'], variables=None) == ['hello']

    #Test case with more than one variable
    test = LookupModule(loader=None, templar=None, variable_manager=None)
    test._templar._available_variables = {
        "test": "hello",
        "test1": "hello1",
        "test2": ["test3", "test4", "test5"]
    }

    assert test.run

# Generated at 2022-06-23 12:50:33.809790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Dummy test for unit testing
    assert(True == True)

# Generated at 2022-06-23 12:50:43.856314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    terms = ['variablename']
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    l = LookupModule()
    l.run(terms, variables)
    assert l.run(terms, variables)[0] == "hello"
    assert l.run(terms, variables)[0] == l.run(terms, variables)[0]
    # Test case 2
    terms = ['variablename']
    variables = {'variablename': 'hello', 'myvar': 'notename'}
    l.run(terms, variables, default='')
    assert l.run(terms, variables, default='')[0] == ""

# Generated at 2022-06-23 12:50:46.177529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.variable_manager is None
    assert lookup.loader is None
    assert lookup.templar is None

# Generated at 2022-06-23 12:50:56.390434
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test exception
    try:
        # A string is not iterable
        lookuper = LookupModule()
        lookuper.run("term")
        raise Exception("The lookup should have failed")
    except AnsibleError:
        pass

    # test undefined variable
    try:
        lookuper = LookupModule()
        lookuper.run(['term'], variables=dict())
        raise Exception("The lookup should have failed")
    except AnsibleUndefinedVariable:
        pass

    # test undefined variable but set a default value
    lookuper = LookupModule()
    res = lookuper.run(['term'], variables=dict(), default="default")
    assert res[0] == "default"

    # test existing variable
    lookuper = LookupModule()

# Generated at 2022-06-23 12:51:05.903041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init LookupModule
    lm = LookupModule()

    # make vars that will later be available to the jinja2 templating
    myvars = {'inventory_hostname': 'localhost',
              'myvar': 'myval',
              'var1': 'val1',
              'var2': 'val2',
              'var3': 'val3',
              'hostvars': {'localhost': {'hostvar': 'hostval'}}}

    # set the options - currently the only option is default, so set it
    lm.set_options(direct={'default': 'defaultval'})

    ret = lm.run(terms=['myvar'], variables=myvars)
    assert ret == ['myval']


# Generated at 2022-06-23 12:51:18.532375
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import ansible.constants as C
    import ansible.context
    from units.mock.loader import DictDataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    ansible.context.CLIARGS = lambda: C
    variable_manager = VariableManager()
    loader = DictDataLoader({"/tmp/test.yml": "{'test_var': 'test_val'}"})
    inventory = InventoryManager(loader=loader, sources=["/tmp/test.yml"])
    variable_manager.set_inventory(inventory)

    vars_lookup = LookupModule()
    vars_lookup.set_options(direct={'vars': {'test_var': 'test_val'}})
    result1 = vars_lookup