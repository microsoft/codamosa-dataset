

# Generated at 2022-06-23 12:41:14.983386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret

# Generated at 2022-06-23 12:41:23.923832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1", "term2"]
    variables = {'term1': 'value1', 'term2': 'value2'}

    # Creating LookupBase instance
    lbase_instance = LookupBase()

    # Creating LookupModule instance
    lmodule_instance = LookupModule()

    # Checks if method run return the same as terms list
    assert lmodule_instance.run(terms, variables) == terms

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:41:24.337510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:41:25.843489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_loader(None)
    assert mod

# Generated at 2022-06-23 12:41:36.783869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # Test if 'options' is initialized
    if lookup_plugin.options is None:
        raise AssertionError("options not initialized in LookupModule")

    # Test if 'options' is a dict
    if not isinstance(lookup_plugin.options, dict):
        raise AssertionError("options is not a dict")

    # Test if 'options' is empty
    if len(lookup_plugin.options) != 0:
        raise AssertionError("options is not empty")

    # Test if 'options' is initialized
    if lookup_plugin._templar is None:
        raise AssertionError("_templar not initialized in LookupModule")


# Generated at 2022-06-23 12:41:39.078038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert test_lookup.get_option('default') is None

# Generated at 2022-06-23 12:41:39.904887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("hi")

# Generated at 2022-06-23 12:41:44.709975
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test with default default
    a = LookupModule()
    assert a.get_option('default') is None
    assert a._display.verbosity == 0  # do not want any output to be displayed
    assert a._datastore._loader.collection_list == []

# test_LookupModule end



# Generated at 2022-06-23 12:41:57.797219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test the run method of class LookupModule
    '''
    # Setup
    lookup_module = LookupModule()
    testvar = dict()
    testvar['testvar'] = 'testval'
    testvar['testvar2'] = dict()
    testvar['testvar2']['testvar3'] = 'testval2'
    testvar['testvar2']['testvar4'] = ['testval3', 'testval4', 'testval5']
    testvar['testvar2']['testvar4.0'] = 'testval3'
    testvar['testvar2']['testvar4.1'] = 'testval4'
    testvar['testvar2']['testvar4.2'] = 'testval5'
    testvar['hostvars'] = dict()
   

# Generated at 2022-06-23 12:42:06.381709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test default examples

    # test default examples
    result = lookup_module.run(['ansible_play_hosts'],
        variables={'ansible_play_hosts': [u'localhost']})
    assert result == [u'localhost']

    terms = ['ansible_play_batch']
    variables = {'ansible_play_batch': 1}
    result = lookup_module.run(terms, variables=variables)
    assert result == [1]

    terms = ['ansible_play_hosts_all']
    variables = {'ansible_play_hosts_all': [u'localhost']}
    result = lookup_module.run(terms, variables=variables)
    assert result == [u'localhost']


# Generated at 2022-06-23 12:42:16.232496
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:42:21.722526
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    module = LookupModule()
    templar = Templar(loader=DataLoader(), variables=VariableManager())
    module._templar = templar
    module._templar._available_variables = {'test_key': 'test_value'}
    assert module._templar._available_variables['test_key'] is 'test_value'

# Generated at 2022-06-23 12:42:22.738802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 12:42:24.546477
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 12:42:32.312283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule instance
    lookup = LookupModule()

    # Create variable dicts
    variables = dict()
    var1 = dict()
    var1['sub_var'] = 12
    variables['variablename'] = var1

    # Create a dict of vars to pass to method
    myvar = "ename"
    terms = ["variabl" + myvar]

    # Execute run method
    ret = lookup.run(terms, variables=variables)

    # Check results
    expected = 12
    assert ret[0] == expected

# Generated at 2022-06-23 12:42:33.350035
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm

# Generated at 2022-06-23 12:42:35.268580
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(LookupModule)

# Generated at 2022-06-23 12:42:39.338943
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(lookup_plugin.init(DictObj(
        _templar=DictObj(
            _available_variables={
                'variablename': 'hello',
                'inventory_hostname': 'localhost'
            }
        )
    )) is None)



# Generated at 2022-06-23 12:42:40.463071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run is not None

# Generated at 2022-06-23 12:42:42.387840
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with empty parameter
    result = LookupModule().run([])
    assert isinstance(result, list)
    assert result == []

# Generated at 2022-06-23 12:42:54.251275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()

    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]

    variables = {
        'ansible_play_hosts': ['127.0.0.1'],
        'ansible_play_batch': ['127.0.0.2', '127.0.0.3'],
        'ansible_play_hosts_all': ['127.0.0.1', '127.0.0.2', '127.0.0.3'],
    }


# Generated at 2022-06-23 12:42:58.976937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters
    terms = ['variablename', 'myvar']
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    default = None

    lookupModule = LookupModule()
    results = lookupModule.run(terms, variables, default=default)

    # Verify
    assert (results == ['hello', 'ename'])

    # Cleanup

# Generated at 2022-06-23 12:43:10.542109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Setup
    # This is the test for the following scenario:
    #  "Show default empty since i dont have 'variablnotename'"
    from ansible.template import Templar
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.plugins.loader import lookup_loader

    class Module():
        def __init__(self):
            self.params = {}
            self.ansible_facts = {}

    class PlayContext():
        def __init__(self, module):
            self.module = module
            self.connection = 'local'

    class Runner():
        all_vars = dict()
        tasks = [{}]
        collection_play = False

    class Task():
        def __init__(self, runner):
            self.runner = runner


# Generated at 2022-06-23 12:43:22.293923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.unsafe_proxy
    import ansible.utils.vars

    class MyTemplar(object):
        def __init__(self, available_variables):
            self._available_variables = available_variables

        def template(self, value, fail_on_undefined=False):
            return value

    class MyVarsModule(ansible.utils.vars.VarsModule):
        def __init__(self, variables):
            self.vars = variables

        def get_vars(self, loader, path, entities, cache=True):
            return self.vars

    lookup_module = LookupModule()
    lookup_module._templar = MyTemplar({'inventory_hostname': 'tests1'})
    # nested variables

# Generated at 2022-06-23 12:43:23.508532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:43:34.530567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from __main__ import LookupModule
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'my_var': 'hello world', 'my_var2': 'foobar'}}})
    l = LookupModule(None, templar=templar, loader=None, basedir=None).run
    # complex var
    assert l(['hostvars'])[0] == templar._available_variables['hostvars']
    # simple var
    assert l(['my_var'])[0] == templar._available_variables['my_var']
    # unknown var -> fails
    assert l(['my_varX'])


# Generated at 2022-06-23 12:43:36.291196
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Unit test to prove that no exception is raised on negative cases
#def test_LookupModule_exception():
#    try:
#        assert LookupModule()
#    except Exception as e:
#        assert False
#        assert str(e)

# Generated at 2022-06-23 12:43:44.941847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing class constructor')
    print('This should work')
    lookup_module = LookupModule()
    print('This should give a KeyError because _templar is not defined')
    try:
        lookup_module._templar.available_variables
    except KeyError as e:
        print('KeyError: {}'.format(e))
    print('This should give a KeyError because available_variables is not defined')
    try:
        lookup_module.run(['something'])
    except KeyError as e:
        print('KeyError: {}'.format(e))


# Generated at 2022-06-23 12:43:49.089430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    my_lookup._templar.available_variables = {'a': 'b'}
    ret = my_lookup.run(['a'])
    assert len(ret) == 1
    assert type(ret) == list
    assert ret[0] == 'b'


# Generated at 2022-06-23 12:44:00.805945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Make a mock ansible template.
    class templater():
        _available_variables = {}

    # Make a mock ansible context.
    class context():
        _templar = templater()

        def __init__(self, variables):
            self._templar.available_variables = variables

        def set_options(self, **kwargs):
            # Override to do nothing
            return

    # Define tests.

# Generated at 2022-06-23 12:44:02.175781
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # this is a default test case
    assert lm

# Generated at 2022-06-23 12:44:14.581265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase

    # Dummy function to test with
    def get_option(name):
        return None

    # Dummy function to test with
    def set_options(var_options, direct):
        return None

    # Dummy function to test with
    def template(value, fail_on_undefined=True):
        return value

    variables = {'test_variable': 'test_value', 'test_missing': None}

    # Create a object to test with
    lookup = LookupModule()

    # Set required properties
    lookup._templar = type('Templar', (object,), {
        "available_variables": variables,
        "get_option": get_option,
        "set_options": set_options,
        "template": template
    })

    # Run

# Generated at 2022-06-23 12:44:16.316335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)


# Generated at 2022-06-23 12:44:18.747848
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj.run(terms=[]) == []
    assert obj.run(terms='something') == []

# Generated at 2022-06-23 12:44:19.996116
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup = LookupModule()
   return lookup

# Generated at 2022-06-23 12:44:33.266814
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create the object with the _templar attribute set
    class FakeLookupBase(LookupBase):
        def __init__(self):
            self._templar = type('', (), {'_available_variables': {}})()

    my_lookup = FakeLookupBase()

    # Set variables
    my_lookup._templar._available_variables = {'test_var': 'test value'}
    my_lookup._templar.available_variables = my_lookup._templar._available_variables

    # Set the options
    my_lookup.set_options(var_options=my_lookup._templar.available_variables, direct={})

    # Set the default value

# Generated at 2022-06-23 12:44:40.918497
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Negative test:if attribute var_options is not passed ansible should throw an error
    module = LookupModule()
    try:
        module.run([])
        assert 0
    except Exception as e:
        assert e.message == 'Vars lookup requires the var_options plugin parameter'

    # Positive test: if attribute var_options is passed ansible should not throw an error
    module.run([], variables=['localhost'])
    assert 1

# Generated at 2022-06-23 12:44:51.271823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global EXAMPLES
    # invalid term
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=123)
        raise Exception('run() of LookupModule exception expected')
    except AnsibleError as e:
        pass
    # invalid term with defined variables
    try:
        lookup_module.run(terms=123, variables={'term': 'variablename'})
        raise Exception('run() of LookupModule exception expected')
    except AnsibleError as e:
        pass
    # term which does not exists
    try:
        lookup_module.run(terms='variablename', variables={})
        raise Exception('run() of LookupModule exception expected')
    except AnsibleUndefinedVariable as e:
        pass
    # term which does exists
    ret = lookup_module.run

# Generated at 2022-06-23 12:45:03.377911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    temp_lookup = LookupModule()
    # Testing with two valid variables
    assert(temp_lookup.run(['test_vars_1','test_vars_2'], {'test_vars_1' : 1, 'test_vars_2' : 2}) == [1,2])
    # return default if var doesn't exist
    assert(temp_lookup.run(['test_vars_3'], {'test_vars_1' : 1, 'test_vars_2' : 2}, default=3) == [3])
    # raise error if var doesn't exist and no default provided

# Generated at 2022-06-23 12:45:04.446161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(loader=None, variables=None)

# Generated at 2022-06-23 12:45:08.998200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    dummy_lookup_module = LookupModule()
    # The following test would fail if the constructor of class LookupModule has been changed
    assert set(dummy_lookup_module.__dict__.keys()) == set(['set_options', 'run', 'get_option', '_options'])

# Generated at 2022-06-23 12:45:10.079413
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:45:20.950668
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:45:21.951980
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # call constructor
    LookupModule()

# Generated at 2022-06-23 12:45:29.883527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    spec = {
            '_terms': {'type': 'list'},
            'default': {'type': 'string'}
            }
    module = LookupModule(None, spec)

    terms = ['variablename', 'myvar', 'variablenotename']
    data = {'variablename': 'hello'}

    module._templar._available_variables = data.copy()
    expected_value = 'hello', 'ename'
    value = module.run(terms, data)
    assert value == expected_value

    spec['default'] = {'type':'string', 'default': ''}
    module = LookupModule(None, spec)

    module._templar._available_variables = data.copy()
    expected_value = 'hello', 'ename', ''
    value = module.run

# Generated at 2022-06-23 12:45:31.739208
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        LookupModule()
    except:
        assert False

# Generated at 2022-06-23 12:45:32.732870
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert lookup

# Generated at 2022-06-23 12:45:38.476053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms=['a','b']
    variables={
        "a":"A1",
        "b":"B1",
        "hostvars": {
            "inventory_hostname": {
                "c":"C1"
                }
            }
        }
    l = LookupModule()
    result = l.run(terms,variables)
    assert result == ['A1', 'B1']

# Generated at 2022-06-23 12:45:49.889468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeTemplar:
        def __init__(self, _available_variables):
            self._available_variables = _available_variables
        def template(self, val, fail_on_undefined=True):
            return val

    # input: terms
    terms = [ 'var1', 'var2', 'var3' ]
    variables = { 'var1': 'value1', 'var2': 'value2' }
    # expected output: ret
    ret = [ 'value1', 'value2' ]
    
    # test run
    lookup = LookupModule()
    lookup._templar = FakeTemplar(variables)
    ret_result = lookup.run(terms)
    
    # check the result of run method
    assert ret_result == ret

# Generated at 2022-06-23 12:45:53.109554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # constructor from ansible.plugins.lookup.LookupBase.__init__
    try:
        assert LookupModule()
    except TypeError as e:
        assert "expected at least 1 argument, got 0" in str(e)


# Generated at 2022-06-23 12:46:03.533023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # int
    assert lookup_module.run(terms=[2]) == [2]
    assert lookup_module.run(terms=[2], default=3) == [2]
    assert lookup_module.run(terms=[None], default='hello') == ['hello']
    assert lookup_module.run(terms=[None], default='') == ['']
    # str
    assert lookup_module.run(terms=['hello']) == ['hello']
    assert lookup_module.run(terms=['global_var'], variables={'global_var': 'hello'}) == ['hello']
    assert lookup_module.run(terms=['global_var'], variables={'global_var': 'hello'}, default='world') == ['hello']

# Generated at 2022-06-23 12:46:14.971280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test list of variables
    variables = dict(
        dict1=dict(
            dict1_1="dict1_1",
            dict2_2="dict2_2",
        ),
        dict2="dict2",
        dict3=dict(
            dict3_1=dict(
                dict3_1_1="dict3_1_1",
            ),
            dict4_4="dict4_4",
        ),
    )

    lookup_obj = LookupModule()
    lookup_obj._templar = DummyTemplar()
    lookup_obj._templar._available_variables = variables


# Generated at 2022-06-23 12:46:15.819385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)

# Generated at 2022-06-23 12:46:23.529731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        ['foo', 'bar'],
        {'baz': 'wibble'},
        ["{{ bar }}", "{{ baz }}"],
    ]
    expected = [
        {'baz': 'wibble'},
        "{{ bar }}",
        "{{ baz }}",
    ]
    look = LookupModule()
    ret = look.run(terms, dict(bar="{{ wibble }}", baz="{{ foo }}"))
    assert ret == expected

# Generated at 2022-06-23 12:46:25.809799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run == LookupModule.run

# Generated at 2022-06-23 12:46:26.404373
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:46:27.997550
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule.run()


# Generated at 2022-06-23 12:46:38.395782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    myvars = { 
        "testvar": "testvalue",
        "testvar2": {"subvar1": "subvalue1"},
        "hostvars": {
            "test_hostname": {
                "test_var_in_hostvars": "test_value_in_hostvars"
            }
        },
        "inventory_hostname": "test_hostname",
    }
    lookup_instance._templar._available_variables = myvars

    lookup_instance.set_options({})
    assert lookup_instance.get_option("default") == None

    lookup_instance.set_options({"default": "testdefault"})
    assert lookup_instance.get_option("default") == "testdefault"


# Generated at 2022-06-23 12:46:39.552619
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 12:46:40.925479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup=LookupModule()

# Generated at 2022-06-23 12:46:41.665867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:46:47.158186
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mock_loader = 'ansible.plugins.loader.lookup_loader.get'
    with mock.patch(mock_loader) as mock_get:
        t = LookupModule()
        mock_get.assert_called_with('LookupBase')
        assert t._loader is mock_get.return_value
        assert t.run is mock_get.return_value.run

# Generated at 2022-06-23 12:46:48.566430
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert isinstance(lookupModule,LookupModule)

# Generated at 2022-06-23 12:46:59.358160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=no-member

    # Set class variables needed for testing
    module = dict(
        params=dict(
            terms=[
                'one_term',
                'second_term'
            ],
            variables=dict(
                one_term='one',
                second_term='two'
            ),
            default='default_value'
        )
    )
    class_instance = LookupModule()
    class_instance.set_options(module['params'])

    # Start test
    assert class_instance.run(**module['params']) == [
        u'one',
        u'two'
    ]

    # Test with undefined term
    module['params']['variables'].pop('second_term')

# Generated at 2022-06-23 12:47:00.359172
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:47:08.507794
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils._text import to_text
    from ansible.template import Templar

    myvariables = {
        "a": "A",
        "b": "B",
        "hostvars": {
            "host1": {
                "b": "C",
                "d": "D",
                "hostvars": {
                    "host1.1": {
                        "d": "E",
                    },
                    "host1.2": {
                        "d": "F",
                    },
                },
            },
            "host2": {
                "a": "H",
                "b": "I",
            },
        },
    }


# Generated at 2022-06-23 12:47:15.383724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run = LookupModule()
    terms = ['variablename']
    variables = {'variablename': 'hello'}
    test_run.set_options(var_options=variables, direct=None)
    assert test_run.run(terms, variables=variables, default='not_found') == ['hello']
    assert test_run.run(terms, variables=variables, default='ok') == ['hello']
    assert test_run.run(terms, variables=variables, default='ok', not_found='not_found') == ['hello']
    assert test_run.run(terms, variables=variables) == ['hello']
    assert test_run.run(terms, variables={'var': 'hello'})[0] == 'not_found'


# Generated at 2022-06-23 12:47:27.100417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_batch', 'ansible_play_hosts', 'ansible_play_hosts_all']

# Generated at 2022-06-23 12:47:39.271389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar(object):
        _available_variables = {'test_var': 'test'}

    class MockLookupModule(LookupModule):
        def __init__(self):
            self.default_value = None
            self._templar = MockTemplar()

        def set_options(self, var_options=None, direct=None):
            if direct['default']:
                self.default_value = direct['default']

        def get_option(self, option):
            if option == 'default':
                return self.default_value

        def _templar_template(self, value, fail_on_undefined=True):
            return '{0}'.format(value)

    lookup_module = MockLookupModule()


# Generated at 2022-06-23 12:47:51.410218
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    myvar = {}
    myvar['inventory_hostname'] = 'test'
    myvar['hostvars'] = {}
    myvar['hostvars']['test'] = {}
    myvar['hostvars']['test']['variablename'] = 'hello'
    myvar['hostvars']['test']['ansible_play_hosts'] = 'hosts'
    myvar['hostvars']['test']['ansible_play_batch'] = 'batch'

# Generated at 2022-06-23 12:48:00.873799
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit tests for method run of class LookupModule
    lookup = LookupModule()

    # Test with terms not string
    terms = [10, 15]
    try:
        lookup.run(terms)
    except AnsibleError as e:
        assert "not a string" in str(e)

    # Test with success with variablename exists
    myvars = {
        "variablename": "hello"
    }
    lookup.set_options(var_options=myvars)
    assert lookup.run(['variablename'], variables=myvars) == ['hello']

    # Test with success with variablename exists with default
    assert lookup.run(['variablename'], default='ok') == ['hello']

    # Test with failure with variablename exists with default

# Generated at 2022-06-23 12:48:08.513741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    from ansible.module_utils._text import to_text, to_native
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-23 12:48:17.186852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    mod.set_options(var_options={})
    assert mod.get_option('default') is None
    assert mod.get_option('my_option') is None
    mod.set_options(var_options={}, direct={'default': 'hello'})
    assert mod.get_option('default') == 'hello'
    assert mod.get_option('my_option') is None
    mod.set_options(var_options={}, direct={'my_option': 'hello'})
    assert mod.get_option('my_option') == 'hello'
    assert mod.get_option('default') is None

# Generated at 2022-06-23 12:48:18.918595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:48:20.654406
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        assert LookupModule
    except NameError:
        print("exception: lookup module not found")

# Generated at 2022-06-23 12:48:21.741640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('vars')

# Generated at 2022-06-23 12:48:30.435846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    import sys
    sys.path.append('/home/vagrant/ansible/lib/ansible/plugins/lookup')

    import jinja2

    class AnsibleModuleMock():
        def __init__(self):
            self.params=dict()
            self.params['lookup_params']=dict()

    class AnsibleFileMock():
        def __init__(self):
            self.params=dict()
            self.params['lookup_params']=dict()

    class AnsibleTemplateMock():
        def __init__(self):
            self.params=dict()
            self.params['lookup_params']=dict()

    class AnsibleErrorMock():
        def __init__(self, message):
            self.message = message


    my_lookup = LookupModule

# Generated at 2022-06-23 12:48:32.965769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupBase

    # Test that constructor creates an instance of LookupBase
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Unit tests for method run of class LookupModule

# Generated at 2022-06-23 12:48:39.996000
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = {}
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({'var_options':{'inventory_hostname':'localhost'},'direct':{'default':'foobar'}}, var_options=result)
    assert lookup_plugin._templar._available_variables['inventory_hostname'] == 'localhost'
    assert lookup_plugin._options['default'] == 'foobar'

# Generated at 2022-06-23 12:48:50.363363
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module._load_name = "vars"
    lookup_module._display.verbosity = 100

    # test with no variables
    terms = ["variablnotename"]
    variables = None
    try:
        lookup_module.run(terms, variables)
        assert False, "Should have raised an error"
    except Exception as e:
        assert "No variable found with this name: variablnotename" in str(e), "Should have raised : " + str(e)

    # test with no variables and default empty
    terms = ["variablnotename"]
    variables = None
    default = ''

# Generated at 2022-06-23 12:48:58.880566
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Dummy parameters
    terms = ['varname1', 'varname2']
    variables = {'varname1': 'value1', 'varname2': 'value2'}
    kwargs = {'_ansible_module_name': 'mymodule', '_ansible_module_origin': 'myorigin', '_ansible_language': 'mylanguage'}

    lm = LookupModule()
    lm.run(terms, variables, **kwargs)

    assert lm._templar._available_variables == variables
    assert lm._templar._available_variables == variables
    assert lm._templar._available_variables == variables

# Generated at 2022-06-23 12:48:59.458548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:49:00.583017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x != None

# Generated at 2022-06-23 12:49:12.511402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lm = LookupModule()
   myvars = {
       'test_var': 'test_var_value',
       'test_var_2': 'test_var_2_value',
       'hello': {
           'world': 'hello_world_value',
       },
       'k': 'v',
   }
   lm._templar._available_variables = myvars
   assert lm.run(['test_var', 'test_var_2']) == ['test_var_value', 'test_var_2_value']

   try:
       lm.run(['test_var', 'test_var_2', 'test_var_nonexistent',])
       raise AssertionError('Did not raise AnsibleUndefinedVariable')
   except AnsibleUndefinedVariable:
       pass


# Generated at 2022-06-23 12:49:24.942628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Object(object):
        pass

    lookup_result = [
        {
            'ansible_play_hosts': 'toto',
            'ansible_play_batch': 'tata',
            'ansible_play_hosts_all': 'titi'
        }
    ]
    l = LookupModule()

    l._templar = Object()

# Generated at 2022-06-23 12:49:34.632772
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Mock ansible.module_utils.six.string_types
    mock_string_types = mock.MagicMock()
    mock_string_types.return_value = 'string_types'
    sys.modules['ansible.module_utils.six'] = mock_string_types

    # Mock ansible.module_utils.six.string_types
    test_class = LookupModule()

    # with patch.object(LookupBase, 'run') as mock_run:
    # mock_run.return_value = 'string_types'
    # mock_string_types.return_value = 'string_types'

    # Try with invalid terms
    try:
        test_class.run([], variables = None, **kwargs)
    except AssertError:
        # assert raises AssertError if terms are invalid.
        pass


# Generated at 2022-06-23 12:49:36.252985
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:49:37.765311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['variablename'], {
        'variablename': 'hello'
    }) == ['hello']

# Generated at 2022-06-23 12:49:39.144153
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l._templar == None

# Generated at 2022-06-23 12:49:45.741683
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    import ansible.module_utils.six as six
    terms = ["a_var_1", "a_var_2"]
    variables = {"a_var_1": "value1", "a_var_2": "value2"}
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin.run(terms, variables), list)
    assert len(lookup_plugin.run(terms, variables)) == 2
    assert all(isinstance(item, six.string_types) for item in lookup_plugin.run(terms, variables))

# Generated at 2022-06-23 12:49:55.525633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that  run method works given an empty terms list
    terms = []
    variables = None
    kwargs = {}
    expected = []
    lookup_module = LookupModule()
    results = lookup_module.run(terms,variables,**kwargs)
    assert (results == expected)


if __name__ == '__main__':
    print('Test ''terms'', ''variables'', ''kwargs'':')
    print('Test with ''terms'' list in which:')
    print('1)  term is an int')
    terms = [1]
    print('Terms: {}'.format(terms))
    variables = None
    kwargs = {}
    # In this case we should get a value of type RawTemplate
    expected = AnsibleException
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:49:57.062780
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:50:07.911362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar._available_variables = {"abc": "a",
                                             "ansible_play_hosts": "b",
                                             "ansible_play_batch": "c",
                                             "ansible_play_hosts_all": "d",
                                             "hostvars": {"inventory_hostname": {"hello": "e"}}}
    ret = lookup.run(["abc", "ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all", "hello"], {})
    assert ret == ['a', 'b', 'c', 'd', 'e']
    ret = lookup.run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"], {})

# Generated at 2022-06-23 12:50:14.284063
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:50:14.803863
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:50:26.406657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]
    variables = {"ansible_play_hosts": "localhost",
                 "ansible_play_batch": "localhost",
                 "ansible_play_hosts_all": "localhost"
                 }
    lookup_obj = LookupModule()
    assert lookup_obj.run(terms, variables) == ["localhost", "localhost", "localhost"]
    terms = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]
    variables = {"ansible_play_batch": "localhost",
                 "ansible_play_hosts_all": "localhost"
                 }

# Generated at 2022-06-23 12:50:31.220673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Testing with default value
    myvars = {'inventory_hostname': 'myhost', 'hostvars': { 'myhost': {'var1': 'welcome1', 'var2': 'welcome2'}}}
    result = lookup.run([ 'var1', 'var2', 'var3' ], variables=myvars, default='default')
    assert result == ['welcome1', 'welcome2', 'default']


# Generated at 2022-06-23 12:50:42.741269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)
    lm = LookupModule(loader=loader, templar=templar)

    # init vars
    myvar = 'hello'
    myvar2 = 'goodbye'
    myvar3 = 'world'

    # define a dict to load as the variable dictionary

# Generated at 2022-06-23 12:50:43.679833
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 12:50:44.284408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-23 12:50:54.286730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a module instance
    lookupmodule = LookupModule()

    # create a mock templar object and add it to the module
    templar_mock = MockTemplar()
    lookupmodule._templar = templar_mock

    # set default vars
    vars = {u'hostvars':
                {u'host1':
                    {u'var1': u'value1',
                     u'var2': u'value2'},
                 u'host2':
                     {u'var1': u'value12',
                      u'var2': u'value22'}
                },
            u'var1': u'value1',
            u'var2': u'value2'}

    # test that the lookup fails when there is no default and we don't have the var
    res = lookup

# Generated at 2022-06-23 12:51:04.527884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup class
    class TestClass(object):
        def __init__(self):
            self.my_vars = {
                'new_variable': 'populated'
            }

            self.hostvars = {
                'inventory_hostname': {
                    'inventory_hostname': 'foo',
                    'ansible_memtotal_mb': 128,
                    'ansible_processor': ['Intel-CoreT-M-CPU-1100MHz']
                }
            }

            self.inventory_hostname = 'foo'

    test_class = TestClass()

    # Setup mock class
    class MockLookupModule(LookupModule):
        def __init__(self):
            self._templar = test_class

    # Setup arguments
    terms = ['new_variable']
    variables = None
    kwargs = {}

# Generated at 2022-06-23 12:51:15.177088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lpm = LookupModule()
    _terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    _variable = {'ansible_play_hosts': {'instance-1': '192.168.0.1'},
                 'ansible_play_batch': ['instance-1'],
                 'ansible_play_hosts_all': ['instance-1']}

    assert lpm.run(_terms, _variable) == [[{'instance-1': '192.168.0.1'}],
                                          [['instance-1']],
                                          [['instance-1']]]