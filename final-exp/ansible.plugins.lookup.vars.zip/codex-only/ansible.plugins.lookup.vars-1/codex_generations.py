

# Generated at 2022-06-23 12:41:12.412118
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:41:17.954614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule = LookupModule()
    terms = ['ansible_architecture', 'ansible_distribution', 'ansible_os_family', 'ansible_distribution_version', 'ansible_hostname', 'ansible_fqdn', 'ansible_domain', 'ansible_default_ipv4.address']

# Generated at 2022-06-23 12:41:29.727232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test 1:
    # default = None, 'myvar' is defined.
    myvar = 'hello'
    myvar_value = 10
    terms = ['myvar']
    variables = {'myvar': myvar_value}
    expected_result = [myvar_value]
    default = None

    result = lookup_module._templar._available_variables = None
    result = lookup_module.run(terms, variables, default=default)

    assert result == expected_result

    # Test 2:
    # default = None, 'myvar' is defined.
    myvar = 'hello'
    myvar_value = 10
    terms = ['myvar']
    variables = {'myvar': myvar_value}
    expected_result = [myvar_value]


# Generated at 2022-06-23 12:41:34.397413
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._templar._available_variables = {'foo': 'bar', 'baz': 'zab'}
    assert lookup.run(['foo']) == ['bar']
    assert lookup.run(['foo', 'baz']) == ['bar', 'zab']

# Generated at 2022-06-23 12:41:40.242386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options()
    assert lookup_module.run(['']) == []

    lookup_module.set_options(variables = {'myvar': 'hello', 'myvar1': 'hello1'})
    assert lookup_module.run(['myvar']) == ['hello']
    assert lookup_module.run(['myvar1']) == ['hello1']
    assert lookup_module.run(['myvar', 'myvar1']) == ['hello', 'hello1']

    lookup_module.set_options(variables = {'myvar': 'hello', 'myvar1': 'hello1'}, direct = {'default': '123'})
    assert lookup_module.run(['myvarnull']) == ['123']


# Generated at 2022-06-23 12:41:49.698855
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_vars = {'myvar': 'value'}
    terms = ['myvar']

    looker = LookupModule()

    # Test with default parameters
    result = looker.run(terms, test_vars)
    assert result == ['value']


    # Test with defined options
    result = looker.run(terms, test_vars, default='default')
    assert result == ['value']


    # Test with undefined variable
    terms.append('myvar2')
    result = looker.run(terms, test_vars)
    assert result == ['value', 'default']

    # Test with undefined variable without default value
    terms.append('myvar2')
    result = looker.run(terms, test_vars)
    assert result == ['value', 'default']

# Generated at 2022-06-23 12:42:01.986339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run method of class LookupModule
    lookup_module = LookupModule()
    variables = {
            'var1': 'value1',
            'var2': 'value2',
            'var3': 'value3',
            'var4': {'sub_var1': 12, 'sub_var2': 'new_value'}
    }

    res = lookup_module.run(['var1', 'var2', 'var3'], variables, default='default_value')
    assert res == ['value1', 'value2', 'value3']

    res = lookup_module.run(['var1', 'var2', 'var3', 'var5'], variables, default='default_value')
    assert res == ['value1', 'value2', 'value3', 'default_value']

    res = lookup_module.run

# Generated at 2022-06-23 12:42:14.045417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import mock

    lm = LookupModule()

    test_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']


# Generated at 2022-06-23 12:42:22.547139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create object LookupModule
    lookup_module = LookupModule()

    # tests
    # test_item_string
    terms = ['os_user_name']
    variables = {'os_username': 'ansadmin',
                 'os_password': 'admin',
                 'os_tenant_name': 'admin',
                 'os_auth_url': 'http://192.168.56.101:5000/v2.0',
                 'os_service_endpoint': 'http://192.168.56.101:35357/v2.0',
                 'os_region_name': 'RegionOne',
                 'os_service_token': 'service_token'
                 }
    result = lookup_module.run(terms=terms, variables=variables)

    assert result == ['ansadmin']

    # test_item_list

# Generated at 2022-06-23 12:42:24.803602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_m = LookupModule()
    assert lookup_m != None
    assert lookup_m != 1

# Generated at 2022-06-23 12:42:27.533370
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Constructor test for LookupModule """
    data = 'string'
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:42:28.589281
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test instanciation of class LookupModule
    LookupModule()

# Generated at 2022-06-23 12:42:29.219595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule("")

# Generated at 2022-06-23 12:42:38.531332
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Test():
        pass

    options = Test()
    options.var_options = {
        'myvar': 'myvarvalue',
        'myvar2': 'myvar2value',
        'myvar3': 'myvar3value'
    }
    options.direct = {
        'default': 'default value'
    }
    t = Test()
    # Set up templar object
    t.available_variables = options.var_options
    t.available_variables['hostvars'] = {
        'host': {
            'myvar': 'myvarhostvalue',
            'myvar2': 'myvar2hostvalue'
        }
    }
    t.available_variables['inventory_hostname'] = 'host'

    lookup_module = LookupModule()
    lookup_module._templ

# Generated at 2022-06-23 12:42:40.528993
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert lookup_mod.run(terms=['dummy']) is not None

# Generated at 2022-06-23 12:42:51.666197
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run([], {})) == 0
    assert len(LookupModule().run([], {'a':'A'})) == 0

    assert LookupModule().run(['a'], {'a':'A'}) == ['A']
    assert LookupModule().run(['a'], {'a':'A', 'b':'B'}) == ['A']

    assert LookupModule().run(['a', 'a'], {'a':'A', 'b':'B'}) == ['A', 'A']
    assert LookupModule().run(['a', 'b'], {'a':'A', 'b':'B'}) == ['A', 'B']

# Generated at 2022-06-23 12:42:56.610405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['var1', 'var2']
    variables = {'hostvars': ['hostvars'],
                 'inventory_hostname': 'inventory_hostname',
                 'var1': 'var1_value',
                 'var2': 'var2_value'
                 }
    assert LookupModule(None).run(terms, variables) == terms

# Generated at 2022-06-23 12:43:04.661171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import binary_type
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Template

    variable_manager = VariableManager()
    loader = DataLoader()

    lm = LookupModule(loader=loader, variable_manager=variable_manager)

    result = lm.run(terms=['lookup_plugin', 'lookup_jinja2_plugin'], variables={'lookup_plugin': 'value1', 'lookup_jinja2_plugin': 'value2'})
    assert(isinstance(result, list))
    assert(len(result) == 2)
    assert(isinstance(result[0], binary_type))
    assert(isinstance(result[1], binary_type))

# Generated at 2022-06-23 12:43:08.419724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._templar._available_variables = {}
    lookup._templar._available_variables['hostvars'] = {}
    lookup._templar._available_variables['inventory_hostname'] = ""
    # test with undefined variable
    result = lookup.run(terms=["foo"], variables={}, default=None)
    assert result == [None]
    result = lookup.run(terms=["foo"], variables={}, default="bar")
    assert result == ["bar"]
    # test with defined variable
    lookup._templar._available_variables['foo'] = "fooval"
    result = lookup.run(terms=["foo"], variables={}, default="bar")
    assert result == ['fooval']
    result = lookup.run(terms=["foo"], variables={}, default=None)

# Generated at 2022-06-23 12:43:16.871587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Check if an exception is raised when the list 'terms' is not a string
    term1 = [1, 2, 3]
    term2 = 'test'
    terms = [term1, term2]
    myvars = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'term1': 10, 'term2': 20} }}
    try:
        result = lm.run(terms, variables=myvars)
        assert False
    except AnsibleError as e:
        assert True

    # Check if the result is correct when using terms related to 'hostvars'
    term1 = 'term1'
    term2 = 'term2'
    terms = [term1, term2]

# Generated at 2022-06-23 12:43:19.342069
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_var = {'my_var': 10}

    assert LookupModule('', '', '', '', {}, global_var)

# Generated at 2022-06-23 12:43:29.269097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test to make sure that correct variables are retreived in different scenarios
    """
    myvars = {'variablename': 'hello', 'another_variable': 'bye', 'myvar': 'ename', 'variablenotename': 'noname', 'ansible_play_hosts': '/path/to/hosts',
              'ansible_play_batch': '/path/to/batch', 'ansible_play_hosts_all': '/path/to/hosts_all', 'hostvars': {'hostname': {'sub_var': 12}}}
    templar = MagicMock(spec=Templar, _available_variables=myvars)
    lookup = LookupModule(loader=None, basedir=None, templar=templar)

    # Use string concatenation to create a variable

# Generated at 2022-06-23 12:43:37.877674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylookup = LookupModule()
    mylookup.set_options(var_options={}, direct={'default': 'default_val'})
    res = mylookup.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables={'hostvars': {'host1': {'ansible_play_hosts': 'play_hosts_val'}}})
    assert res == ['play_hosts_val', 'default_val', 'default_val']

# Generated at 2022-06-23 12:43:44.051991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.plugins.lookup import LookupBase

    lookup = LookupModule()
    test_terms = ['variablename', 'myvar']
    test_variables = {'variablename': 'hello', 'myvar': 'ename'}
    results = lookup.run(terms=test_terms, variables=test_variables)

    test_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    results = lookup.run(terms=test_terms, variables=test_variables)

    test_terms = ['variablename', 'myvar']

# Generated at 2022-06-23 12:43:51.903121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    templar = Templar(loader=None)
    lookup = LookupModule(loader=None)
    # hostvars is a dict with a single entry and the key is inventory_hostname
    myvars = {'hostvars': {'hostname1':9}}
    myvars['hostname1'] = 10
    # This is what is passed to ansible as the variable dict
    myvars['hostvars']['hostname1'].update(myvars)
    lookup.set_options(var_options=myvars)
    lookup._templar = templar
    lookup._templar._available_variables = myvars

    mylist = [9,10]
    result = lookup.run(terms=['hostvars'], variables=myvars)


# Generated at 2022-06-23 12:44:02.408664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # return nothing
    assert None == lm.run([])

    # return nothing
    assert None == lm.run(['test'])

    # return undefined
    lm._dispatch_defaults = {
        'var': {
            'default': None
        }
    }
    assert None == lm.run(['test'])

    # return some values
    lm._dispatch_defaults = {
        'var': {
            'default': ''
        }
    }
    lm._templar._available_variables = {'test': 'test'}
    assert ['test'] == lm.run(['test'])
    assert ['var'] == lm.run(['test', 'var'])

    del lm

# Generated at 2022-06-23 12:44:10.894521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The following are from the default values of the 'run' method above.
    # To work, the *templar* attribute must be set.
    from ansible.template import Templar
    from ansible.inventory.host import Host

    templar = Templar(loader=None, variables={})
    # Create a 'fake' host for the inventory_hostname variable.
    templar._available_variables = {'inventory_hostname': Host(name='test_host')}
    templar._available_variables['hostvars'] = {'test_host': {}}
    ll = LookupModule()
    ll._templar = templar

    # Set some variables in the hostvars.

# Generated at 2022-06-23 12:44:13.271240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_object = LookupModule()
    assert test_object != None, "Could not instantiate LookupModule"

# Generated at 2022-06-23 12:44:17.057473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_mod = LookupModule()

    # Test with undefined variable.
    try:
        lookup_mod.run(terms=['this_is_undefined_variable'])
    except AnsibleError as e:
        assert e.message == 'No variable found with this name: this_is_undefined_variable'

    # Test with defined variable.
    assert lookup_mod.run(terms=['ansible_version']) == ['2.5.0']

# Generated at 2022-06-23 12:44:20.261348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup
    l = ansible.plugins.lookup.LookupModule()
    l.get_option = lambda key: None
    l.set_options = lambda **kwargs: None
    l._templar = FakeTemplar()
    assert(l.run(['y'])[0] == 'y')


# Generated at 2022-06-23 12:44:22.246643
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: Test lookup_module = LookupModule().run()
    #assert
    pass

# Generated at 2022-06-23 12:44:28.143341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l._templar._available_variables = {}
    assert l._templar._available_variables == {}
    l.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])

# Generated at 2022-06-23 12:44:37.469640
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:44:48.743419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    test_variables = {
        'var': 'hello',
        'bvar': 'world',
        'lvar': {'a': 123},
        'hostvars': {'localhost': {'lvar': 'hello'}}
    }

    # Test variable:
    assert module.run(['var'], variables=test_variables) == 'hello'

    # Test variable that's not defined
    try:
        module.run(['nvar'], variables=test_variables)
    except AnsibleUndefinedVariable:
        assert True
    else:
        assert False

    # Test variable that's not defined with a default value
    assert module.run(['nvar'], variables=test_variables, default='mydefault') == 'mydefault'

    # Test variable from hostvars:

# Generated at 2022-06-23 12:44:55.839559
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Default values for testing
    block_name = "vars"
    # For example:
    # ANSIBLE_NET_HOSTNAME=router1
    # ANSIBLE_NET_USERNAME=test
    # ANSIBLE_NET_PASSWORD=test123
    # ANSIBLE_NET_USE_SSL=False

    # Creating a templar object, that is basically template processor
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, enable_i18n=False)

    # Define variable, in which we will store Ansible variable
    # This variable is of AnsibleVars class.
    class AnsibleVars_Test(AnsibleVars):
        test_defined

# Generated at 2022-06-23 12:44:57.318440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)



# Generated at 2022-06-23 12:44:58.014485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:44:59.147884
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-23 12:45:10.900950
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ansible_vars = VariableManager(loader=DataLoader())
    ansible_vars.extra_vars = {
        'inventory_hostname': 'localhost',
        'hostvars': {
            'localhost': {
                'ansible_play_hosts': ['localhost'],
                'ansible_play_batch': ['localhost'],
                'ansible_play_hosts_all': ['localhost'],
                'ansible_play_batch': ['localhost'],
                'ansible_play_hosts_all': ['localhost'],
            },
        },
    }

    # test with variable already defined

# Generated at 2022-06-23 12:45:19.278530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize LookupModule
    lookupModule = LookupModule()

    # Test with a list of strings
    terms = ['host1', 'host2']
    variables = {'hostvars': {'host1': 'host1_var', 'host2': 'host2_var'}, 'inventory_hostname': 'host2'}
    result = lookupModule.run(terms, variables)
    assert result == ['host1_var', 'host2_var']

    # Test with a single string
    terms = 'hello'
    variables = {'hello': 'world'}
    result = lookupModule.run(terms, variables)
    assert result == ['world']

    # Test with a single string that is not associated with any variable
    terms = 'not_a_variable'
    variables = {'hello': 'world'}
    result

# Generated at 2022-06-23 12:45:20.059469
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-23 12:45:28.648847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test without "variables"
    data = ["a", "b", "c", "d", "e", "f"]
    lookup_plugins = [ "lookup_plugins" ]
    templar        = "templar"
    loader         = "loader"
    # run the constructor
    lookup_plugin  = LookupModule(loader=loader, templar=templar, basedir=None, cache=None)
    # compare with expected results
    assert lookup_plugin.loader    == loader
    assert lookup_plugin.templar   == templar
    assert lookup_plugin.basedir   == None
    assert lookup_plugin.vars      == []
    assert lookup_plugin.cache     == None
    assert lookup_plugin.extra_vars == {}
    assert lookup_plugin.options   == {}

# Unit test

# Generated at 2022-06-23 12:45:35.319554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import constants as C
    from ansible.template import Templar

    class Runner(object):
        def __init__(self):
            self.default_vars = dict()

    class Task(object):
        def __init__(self):
            self.environment = dict()

        def set_environment(self, variables, flag_is_from_task=False):
            self.environment = variables

    class Play(object):
        def __init__(self):
            self.hostvars = dict()

    class Inventory(object):
        def __init__(self):
            self.host_vars = dict()

    class Host(object):
        def __init__(self):
            self.vars = dict()
            self.name = 'localhost'


# Generated at 2022-06-23 12:45:46.511913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'inventory_hostname': 'host1',
            'hostvars': {'host1': {'a': 1, 'b': 2, 'c': 3}},
            'd': 'A',
            'e': 'B',
            'f': 'C'}
    # Test 1: No default value, no error
    t1 = LookupModule({}, templar=None, loader=None)
    ret1 = t1.run(['a', 'b', 'c', 'd', 'e', 'f'], vars=vars)
    assert ret1 == [1, 2, 3, 'A', 'B', 'C']
    # Test 2: No default value, error
    t2 = LookupModule({}, templar=None, loader=None)

# Generated at 2022-06-23 12:45:54.196924
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_common = LookupBase()
    lookup_common._loader = True
    lookup_common._templar = True
    lookup = LookupModule()
    assert not hasattr(lookup, '_loader')
    assert not hasattr(lookup, '_templar')
    lookup.set_loader(lookup_common._loader)
    lookup.set_templar(lookup_common._templar)
    assert lookup._loader == lookup_common._loader
    assert lookup._templar == lookup_common._templar


# Generated at 2022-06-23 12:45:55.244213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 12:46:04.855431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_module = LookupModule()

    # Test for no variables given
    print("Test for no variables given")
    assert test_module.run([]) == []

    # Test for only one variable
    print("Test for only one variable")
    assert test_module.run([], variables={'ansible_play_hosts': [1, 2, 3]}
                           ) == [[1, 2, 3]]

    # Test for a few variables
    print("Test for a few variables")
    variables = {'ansible_play_hosts': [1, 2, 3], 'ansible_play_batch': 4, 'ansible_play_hosts_all': 5}
    assert test_module.run([], variables=variables
                           ) == [[1, 2, 3], 4, 5]

    # Test for variables with default
   

# Generated at 2022-06-23 12:46:15.788031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a fake play context
    play_context = {
        "name": "<unnamed>",
        "path": "<unknown>",
        "tags": [],
        "become": False,
        "become_user": "root",
        "remote_user": "root",
        "user": "root",
        "playbook": "<unknown>"
    }
    # create a fake inventory

# Generated at 2022-06-23 12:46:20.113718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Make sure that the constructor of LookupModule can be called
    """
    lookup_plugin = LookupModule()

# Test for run method of class LookupModule

# Generated at 2022-06-23 12:46:28.650105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock LookupBase class variables
    templar_mock = {}
    templar_mock['_available_variables'] = {'myvar': 1, 'myvar1': 2, 'myvar2': 3, 'myvar3': 4, 'myvar4': 5, 'myvar5': 6, 'myvar6': 7, 'myvar7': 8, 'myvar8': 9, 'myvar9': 10}
    templar_mock['template'] = lambda x: x


# Generated at 2022-06-23 12:46:31.418783
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=[1], variables={'a':'b'}) == []

# Generated at 2022-06-23 12:46:40.659495
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule()

    # Unit test function run with valid and invalid input
    # GIVEN
    templar = lookup_plugin._templar
    templar._available_variables = {'a': 12, 'b': '23', 'c': 24}
    myvars = getattr(templar, '_available_variables', {})
    templar._available_variables['hostvars'] = {'localhost': myvars}

    mock_terms = ['a', 'b']
    myvars = getattr(templar, '_available_variables', {})

    # WHEN
    resp = lookup_plugin.run(mock_terms, variables=myvars)

    # THEN
    assert resp == [12, '23']

    # GIVEN
    mock_terms

# Generated at 2022-06-23 12:46:41.700236
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None


# Generated at 2022-06-23 12:46:48.944314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    from ansible.template import Templar

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes, to_text

    if PY2:
        # Patch stdout to StringIO
        stdout = sys.stdout
        sys.stdout = StringIO()

    lu = LookupModule()

    terms = [ "foo" ]
    variables = { "foo": "bar" }
    terms = lu.run(terms, variables, templar=Templar(loader=None, variables=variables))

    if PY2:
        # Resume stdout
        term = sys.stdout.getvalue()
        sys.stdout = stdout
        term = to_

# Generated at 2022-06-23 12:46:50.197779
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule('vars', None, None, None)

# Generated at 2022-06-23 12:46:52.302226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert not hasattr(lookup_module, '_plugin_loader')

# Generated at 2022-06-23 12:47:02.762888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''

    # Setup fake "Ansible" module to make sure it looks up variables
    # from the proper place
    import ansible.constants as C
    C.DEFAULT_HOST_LIST = '/dev/null'

    class FakeVarsModule:
        ''' Fake for the AnsibleModule class "ansible.module_utils.basic.AnsibleModule' '''
        def __init__(self):
            pass

        def fail_json(self, *args, **kwargs):
            raise AssertionError('AnsibleModule.fail_json() should not have been called')

    class FakeAnsibleModule:
        ''' Fake for the module class "ansible.module_utils.basic.AnsibleModule' '''

# Generated at 2022-06-23 12:47:10.116477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestTemplar:
        def __init__(self, available_variables):
            self._available_variables = available_variables
            self.available_variables = self._available_variables.copy()

    class TestLookupModule(LookupModule):
        def __init__(self):
            pass

        def set_options(self, var_options, direct):
            pass

        def get_option(self, option):
            pass

        def _templar(self, play_context):
            return TestTemplar(self._available_variables)

        def _templar_available_variables(self, new_variables):
            self._available_variables = new_variables

    test_lookup_module = TestLookupModule()
    test_lookup_module._templar_available_

# Generated at 2022-06-23 12:47:22.381401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the object of LookupModule
    vars_lookup_module = LookupModule()
    # Create a dictionary which contains the variables

# Generated at 2022-06-23 12:47:31.177526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=["myhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    play_context = Play()

    inventory.set_variable('myhost', 'foo', 'bar')
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms='foo', templar=templar, play_context=play_context)
    assert result == ['bar']

# Generated at 2022-06-23 12:47:32.578310
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 12:47:33.125694
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:47:41.189928
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit tests that run this module require ANSIBLE_HOST_KEY_CHECKING to be False
    try:
        import os
        os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    except ImportError:
        pass

    module_under_test = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    result = module_under_test.run(terms)

    assert result[0] == ['127.0.0.1']
    assert result[1] == ['127.0.0.1']
    assert result[2] == ['127.0.0.1']

# Generated at 2022-06-23 12:47:53.112906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_name = "test_LookupModule_run"
    # It works with both ansible 2.4.1 and ansible 2.5.0
    module = __import__(module_name, fromlist=["AnsibleModule"])

# Generated at 2022-06-23 12:48:01.847682
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import __main__ as main
    from ansible.parsing.vault import VaultLib

    lookup = LookupModule()
    # for some reason __init__ is called twice, so we avoid the second one by
    # checking if the lookup._templar is already set or not
    if lookup._templar is None:
        lookup._templar = VaultLib([])
    assert hasattr(lookup, '_templar')

    # test if a variable can be found
    myvars = {
        'myvar': 'hello',
    }
    terms = ['myvar']

    assert lookup.run(terms, variables=myvars) == ['hello']

# Generated at 2022-06-23 12:48:13.912294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with required arguments
    terms = ['hostvars', 'inventory_hostname']
    myvars = {'hostvars': {'inventory_hostname': {'foo': 'bar'}}}

    module = LookupModule()
    module.set_loader()
    module.set_environment(myvars, variables=myvars)
    module.set_options()

    try:
        result = module.run(terms)
    except AnsibleError as e:
        assert False, "LookupModule.run() raised Exception when it shouldn't have (1). Exception: %s" % e
    assert result == myvars['hostvars'], \
        "LookupModule.run() returned unexpected result (1). Expected %s, got %s" % (myvars['hostvars'], result)

    # Test with

# Generated at 2022-06-23 12:48:25.244192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()
    assert test_class.run(
        terms=[
            'variablename'
        ],
        variables={
            'variablename': 'hello',
            'myvar': 'ename'
        }) == [
            'hello'
        ]
    assert test_class.run(
        terms=[
            'variablename'
        ],
        variables={
            'myvar': 'ename'
        }) == []
    assert test_class.run(
        terms=[
            'variabl' + 'ename'
        ],
        variables={
            'variablename': 'hello',
            'myvar': 'ename'
        }) == [
            'hello'
        ]

# Generated at 2022-06-23 12:48:33.755566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory_manager = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory_manager)

    results = []
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

# Generated at 2022-06-23 12:48:45.911936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests with no default specified
    module = LookupModule()
    module.set_options(direct={
        '_ansible_remote_tmp':'/some/path'
    })
    assert module.run([u"some_var"]) == []
    assert module.run([u'hostvars']) == []
    assert module.run([u'_ansible_remote_tmp']) == [u'/some/path']

    # Tests with default specified
    module.set_options(direct={
        '_ansible_remote_tmp':'/some/path'
    })
    assert module.run([u"some_var"], default="default") == ["default"]

# Generated at 2022-06-23 12:48:52.123578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # test method run() with a json object
    term = 'test_term'
    vars = {'test_term' : 'test_value'}

    lm = LookupModule()
    lm._templar._available_variables = vars
    ret = lm.run(terms=term, variables=None, default=None)

    assert isinstance(ret, list)
    assert len(ret) == 1
    assert ret[0] == 'test_value'
    assert type(ret[0]) is str

# Generated at 2022-06-23 12:49:01.631226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #test using common ansible variables
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all', 'ansible_playbook_python']
    #set variables
    variables = {'ansible_play_hosts': 'hosts', 'ansible_play_batch': 'batch', 'ansible_play_hosts_all': 'hosts_all', 'ansible_playbook_python': 'python'}
    # initialise LookupModule instance
    lookup = LookupModule()
    # initialise templar dictionnary
    templar_dict = {}
    #mock get_option method (not used in this test)
    lookup._get_option = lambda x:None
    #set templar_dict variables

# Generated at 2022-06-23 12:49:13.115406
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    import os
    import json
    import sys

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, 'lib'))
    from ansible.plugins.loader import lookup_loader

    l = lookup_loader.get('vars')
    
    # load constants from constants.json file
    constants_json_file_path = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir, 'test', 'sanity', 'test-data', 'constants.json')
    with open(constants_json_file_path) as constants_json_file:
        constants = json.load(constants_json_file)


# Generated at 2022-06-23 12:49:25.522371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {
        'ansible_play_hosts': 'bogus_host1,bogus_host2',
        'ansible_play_batch': 'bogus_batch',
        'ansible_play_hosts_all': 'bogus_host1,bogus_host2,bogus_host3'
    }

    expected_value = ['bogus_host1,bogus_host2', 'bogus_batch', 'bogus_host1,bogus_host2,bogus_host3']

    l = LookupModule()
    l._templar = 'bogus_templar'
    # Here we are mocking

# Generated at 2022-06-23 12:49:29.209307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        l = LookupModule()
    except Exception as e:
        print(e)
        raise AssertionError

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:49:31.375899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myobj = LookupModule()
    assert myobj.run("foobar") == [], "myobj.run('foobar') failed"


# Generated at 2022-06-23 12:49:32.098400
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-23 12:49:43.789333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Testing the run method of LookupModule"""
    import pytest
    from ansible.plugins.lookup import LookupModule
    from ansible.parsing.vault import VaultLib

    lookup = LookupModule()
    lookup._lookup_args = {}
    lookup._options = {}
    lookup._fail_on_undefined = None
    lookup._templar = None
    lookup.set_options()

    # Test with AnsibleUndefinedVariable
    with pytest.raises(AnsibleUndefinedVariable):
        terms = ['test']
        lookup.run(terms)

    # Test with AnsibleError
    with pytest.raises(AnsibleError):
        VaultLib.load_vaultfile()
        lookup._templar = {}
        term = {'test': 'test'}
        lookup.run

# Generated at 2022-06-23 12:49:50.723746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test terms as string, check default as None (default)
    lu = LookupModule()
    result = lu.run(terms='this_var')
    assert result == [None], "'run' method returned unexpected result: %s" % result
    # test terms as list
    result = lu.run(terms=['this_var','that_var','another_var'])
    assert result == [None, None, None], "'run' method returned unexpected result: %s" % result

# Generated at 2022-06-23 12:50:02.317537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(direct={'default': "DEFAULT"})
    available_variables = {"foo": "bar", "baz": ["baz", "baz", "baz"], "qux": {"qux1":"qux1", "qux2":[1, 2, 3]}}

# Generated at 2022-06-23 12:50:03.351448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-23 12:50:04.404361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    temp = LookupModule()
    assert temp is not None

# Generated at 2022-06-23 12:50:06.609247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    v = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    print(v)

# Generated at 2022-06-23 12:50:15.404051
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar
    from ansible.module_utils.six import StringIO

    # variables is a dict, ansible_default_stdout_callback is a string
    variables = dict(ansible_default_stdout_callback='json')
    # _available_variables is a dict, inventory_hostname is a string
    _available_variables = dict(inventory_hostname='localhost')
    # hostvars is a dict, ansible_play_hosts is a list
    hostvars = dict(localhost=dict(ansible_play_hosts=['127.0.0.1']))
    # playbook_basedir is a string
    playbook_basedir = 'tests/unit/plugins/lookup/'
    # loader is a AnsibleFileLoader
    loader = None
    # shared_loader_obj is a

# Generated at 2022-06-23 12:50:27.001179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # Creation of the object LookupModule
    var1 = VaultLib()
    var2 = dict(a=1, b=2, c=dict(a=3, b=4))
    var3 = Templar(loader=None, variables=var2, vault_secrets=var1)
    var4 = dict(a=3, b=4)
    var5 = {"vault_password": "test"}

    var6 = LookupModule(templar=var3, loader=None, vault_secrets=var1)
    var6.set_options(var_options=var4, direct=var5)

# Generated at 2022-06-23 12:50:29.536139
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.vars import LookupModule
    lookup_mock = LookupModule()
    return lookup_mock


# Generated at 2022-06-23 12:50:38.543923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ctor = LookupModule()
    assert type(ctor) == LookupModule
    assert ctor.run(terms=["foo"]) == ctor.run(terms=["foo"])
    assert ctor.run(terms=["foo"]) != ctor.run(terms=["bar"])
    assert ctor.run(terms=["foo"]) == ctor.run(terms=["foo", "foo"])
    assert ctor.run(terms=["foo"]) != ctor.run(terms=["foo", "bar"])

# Generated at 2022-06-23 12:50:39.965477
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LOOKUPPLUGIN = LookupModule()
    assert LOOKUPPLUGIN

# Generated at 2022-06-23 12:50:50.919205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    templar = Templar(variables=dict(myvar='ename', variablename='hello'))
    templar._available_variables = dict(myvar='ename', variablename='hello')

    # test 1
    terms = ['variablename', 'myvar']
    lookup_instance = LookupModule()
    results = lookup_instance.run(terms=terms, templar=templar)
    assert results == ['hello', 'ename']

    # test 2

# Generated at 2022-06-23 12:51:02.333999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import __builtin__

    class MockTemplar(object):
        def __init__(self):
            self._available_variables = {
                "ansible_play_hosts": ['localhost'],
                "ansible_play_batch": [],
                "ansible_play_hosts_all": ['localhost'],
            }
        def template(self, value, fail_on_undefined=True):
            return value

    class MockDisplay(object):
        def __init__(self):
            self.verbosity = 3

    # Mock display
    __builtin__.display = MockDisplay()

    # Mock lookup module
    lookup_module = LookupModule()

    # Mock templar
    lookup_module._templar = MockTemplar()

    # Mock term

# Generated at 2022-06-23 12:51:04.628390
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create instance of LookupModule class
    LookupModuleInst = LookupModule()
    assert LookupModuleInst is not None


# Generated at 2022-06-23 12:51:16.033629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.template import Templar
