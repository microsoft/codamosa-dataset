

# Generated at 2022-06-23 12:41:15.069715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__init__.__defaults__) == 1
    assert LookupModule.__init__.__defaults__[0] is None
    assert len(LookupModule.run.__defaults__) == 2
    assert LookupModule.run.__defaults__[0] is None
    assert LookupModule.run.__defaults__[1] == {}

# Generated at 2022-06-23 12:41:16.168919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:41:17.854935
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookupModuleTemp = LookupModule()
   assert(lookupModuleTemp != None)

# Generated at 2022-06-23 12:41:29.688549
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    # the following are needed for loading inventory
    # the following are needed to make templating work
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['host1'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 12:41:30.484105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:41:33.080966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test constructor of class LookupModule
    lookup_plugin = lookup_plugin_class()
    assert lookup_plugin is not None


# Generated at 2022-06-23 12:41:35.124854
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)


# Generated at 2022-06-23 12:41:46.335541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader

    dataLoader = DataLoader()
    # define a dict with inventory variables for unit test
    inv_var={"myvar":"ename", "variablename":"hello","_ansible_no_log":None,"_ansible_verbose_override":False,"inventory_hostname":"h1"}
    # define a dict with hostvars variables for unit test
    host_var={"h1":{"ansible_play_batch":[1,2,3]}}

    # populate templar with required dictionaries
    lm = LookupModule(templar=dataLoader, loader=dataLoader)
    lm._templar._available_variables = dict(inv_var, **host_var)

    # case 1: 'variablename' exists in inventory
    #

# Generated at 2022-06-23 12:41:50.147590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={'ansible_play_hosts': 'localhost'})
    assert l.run('ansible_play_hosts') == ['localhost']

# Generated at 2022-06-23 12:42:02.360235
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    lookup_instance = LookupModule()
    lookup_instance.set_options({'_snippet': True, '_raw_params': 'a-variable', '_task': object})
    lookup_instance._lookup_plugin.loader = LookupModule.get_loader_class()()
    lookup_instance._templar = Templar(loader=lookup_instance._lookup_plugin.loader)
    lookup_instance._templar.set_available_variables(dict(_items=[{'a-variable': 'foo'}]))
    lookup_instance.run()
    lookup_instance._play_context = PlayContext()

# Generated at 2022-06-23 12:42:14.222832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    my_vars = {
        'ansible_play_hosts': ['host1'],
        'ansible_play_batch': ['batch1'],
        'ansible_play_hosts_all': ['hostall1'],
        'variablename': 'hello',
        'variablename2': 'hello2',
        'myvar': 'ename',
        'sub_var': 12,
    }

    # Check 'simple' lookup
    result = my_lookup.run(['ansible_play_hosts'], variables=my_vars)
    assert result == ['host1']

    # Check nested lookup
    result = my_lookup.run(['sub_var'], variables=my_vars)
    assert result == [12]

    #

# Generated at 2022-06-23 12:42:15.064124
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-23 12:42:20.238028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_ins = LookupModule()
    vars = {}
    
    # test if lookup('vars', 'variabl' + myvar) is 'hello'
    ans = "hello"
    terms = ['variablename']
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    ret = lookup_ins.run(terms, variables, variables)
    
    assert ans == ret[0]

# Generated at 2022-06-23 12:42:31.814264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Load class attributes (_templar) with valid value
    lookup_module._templar = object()
    # Test valid passing of terms
    terms = ["name", "other_name"]
    result = lookup_module.run(terms)
    assert result == []
    # Test invalid passing of terms (non string input)
    terms = [ 1234 ]
    try:
        result = lookup_module.run(terms)
    except Exception as e:
        assert "is not a string" in str(e)
    else:
        assert False, "An exception should have been raised"
    # Test the displayed error for a valid non-existing variable
    # NOTE: The test suite is not aware of any valid variable.
    # only 'example' is mentioned in the doc, but that's not enough
    #

# Generated at 2022-06-23 12:42:32.892488
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:42:43.293563
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  def run(params, variables, **kwargs):
    lookup = LookupModule()
    return lookup.run(params, variables, **kwargs)

  # test with empty variables
  assert run(['var_not_present'], {}) == []
  assert run(['var_present'], {}) == []

  # test with simple variable
  assert run(['var_present'], {'var_present': 'my string'}) == ['my string']

  # test with default value
  assert run(['var_not_present'], {}, default='my_default') == ['my_default']

  # test with nested variable
  assert run(['var_present'], {'var_present': {'sub_var': '12'}}) == [{'sub_var': '12'}]


# Generated at 2022-06-23 12:42:55.327607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Pre-defined variables
    variables = {
        "a": "25",
        "alpha": "12",
        "alpha_numeric": "12",
        "ansible_facts": {
            "nested": {
                "value": "a"
            }
        },
        "ansible_play_hosts": "a",
        "ansible_play_hosts_all": "b",
        "ansible_play_batch": "c",
        "hostvars": {
            "host01": {
                "a": "b",
                "alpha": "bravo",
                "ansible_facts": {
                    "nested": {
                        "value": "b"
                    }
                },
                "alpha_numeric": "bravo"
            }
        }
    }

    #

# Generated at 2022-06-23 12:42:57.022664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-23 12:43:04.921833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create mock class
    class MockVars(object):
        pass
    # Assign variables
    MockVars.ansible_play_hosts = 1
    MockVars.ansible_play_batch = 2
    MockVars.ansible_play_hosts_all = 3
    MockVars.hostvars = {'host01': {"test01_var": 1, "test02_var": 2, "test03_var": 3}}

    # First test, check if run return all variables
    collected_terms, collected_variables, collected_kwargs = [], {}, {}
    collected_terms.append(MockVars.ansible_play_hosts)
    collected_terms.append(MockVars.ansible_play_batch)

# Generated at 2022-06-23 12:43:14.389153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Given
    test_terms = ['{{ var1_name }}', '{{ var2_name }}', '{{ var3_name }}']
    test_vars = {
        'var1_name': 'var1',
        'var2_name': 'var2',
        'var3_name': 'var3'
    }
    test_kwargs = {'mykey': 'myvalue'}

    lookup_obj = LookupModule()

    # When
    results = lookup_obj.run(test_terms, test_vars, **test_kwargs)

    # Then
    assert len(results) == 3
    assert results[0] == 'var1'
    assert results[1] == 'var2'
    assert results[2] == 'var3'

# Generated at 2022-06-23 12:43:18.510375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    resp = LookupModule().run(['v', 'x'], variables={'v': 1, 'hostvars': {'host1': {'x': 2}}, 'inventory_hostname': 'host1'})
    assert resp == [1, 2]

# Generated at 2022-06-23 12:43:19.346332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:43:24.916817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  terms = ["foo"]
  ret = lookup.run(terms)
  assert(ret == [])

  terms = ["ansible_play_hosts"]
  ret = lookup.run(terms)
  assert(ret == ["127.0.0.1"])

  terms = ["foo", "ansible_play_hosts"]
  ret = lookup.run(terms)
  assert(ret == ["127.0.0.1"])



# Generated at 2022-06-23 12:43:25.871788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # To Do
    return None

# Generated at 2022-06-23 12:43:38.136982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # define input param 'terms'
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    # define output param '_value'
    _value = ['all', 0, 'all']
    # define output param 'self._task'
    self._task = None
    # define output param 'self._loader'
    self._loader = None
    # define output param 'self._templar'
    self._templar = None

    # init class LookupModule
    obj = LookupModule()

    # init method run of class LookupModule
    obj.run(terms, variables=_value[0])


# Generated at 2022-06-23 12:43:44.250723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()

    vars_manager = VariableManager()
    inventory = VariableManager()
    vars_manager.set_inventory(inventory)

    # define a dict for the host for the tests to reference
    new_host = dict(name='myhost',
                    inventory_hostname='myhost',
                    ansible_play_hosts='all_my_friends')
    # add our host to the 'inventory'
    inventory._vars_per_host = dict(new_host)
    # define a dict for each of the vars to be referenced in the tests
    vars_manager._vars_per_host = dict(new_host)

# Generated at 2022-06-23 12:43:45.874885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # TODO: Add unit tests for this class
    pass

# Generated at 2022-06-23 12:43:48.775308
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test if class LookupModule is instantiated
    assert (hasattr(LookupModule, 'run'))
    lookup_module = LookupModule()
    assert isinstance(lookup_module._templar, LookupModule)

# Generated at 2022-06-23 12:43:52.358382
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['test_constructor']
    variables = {'test_constructor': 'foo'}
    l = LookupModule()
    l.run(terms, variables=variables)

# Generated at 2022-06-23 12:43:55.344456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    input_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    result = module.run(input_terms)
    assert result == []


# Generated at 2022-06-23 12:43:56.899553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for the most simple case
    LookupModule().run(["hostvars"])

# Generated at 2022-06-23 12:44:08.103063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare  object
    lm = LookupModule()

    # Prepare Anisble variables
    myvars = dict()
    myvars['variablename']       = 'hello'
    myvars['myvar']              = 'ename'
    myvars['variablenotename']   = ''
    myvars['ansible_play_hosts'] = 'hello'
    myvars['ansible_play_batch'] = 'hello'
    myvars['ansible_play_hosts_all'] = 'hello'
    myvars['ansible_play_host_names'] = 'hello'
    myvars['variablename']['sub_var'] = 12

    # Test #1
    terms = ['variablename', 'myvar']

# Generated at 2022-06-23 12:44:20.054298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    vm = VariableManager()
    loader = DataLoader()
    vm.set_loader(loader)
    vars_dic = dict(
        variablename=dict(sub_var=12),
        myvar='ename',
        variablenotename='error'
    )
    vm.set_vars(vars_dic)

    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]
    mod = LookupModule()
    mod._templar = vm
    mod._templar_

# Generated at 2022-06-23 12:44:33.267117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2, binary_type
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    LookupBase.set_loader(DataLoader())

    variable_manager = VariableManager()
    variable_manager._extra_vars = {'foo': 'world'}
    variable_manager.set_inventory(InventoryManager(loader=variable_manager.get_loader(), sources=''))
    display = Display()

# Generated at 2022-06-23 12:44:35.973389
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookupModule = LookupModule()
    assert isinstance(myLookupModule, LookupModule)


# Generated at 2022-06-23 12:44:38.176922
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-23 12:44:49.381676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    gcp_vars = {
        "ansible_play_hosts": [
            "10.130.0.2",
            "10.130.0.3"
        ],
        "ansible_play_batch": [
            "10.130.0.2",
            "10.130.0.3"
        ],
        "ansible_play_hosts_all": [
            "10.130.0.2",
            "10.130.0.3"
        ],
    }


# Generated at 2022-06-23 12:45:00.623372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestInventory(object):
        def __init__ (self, hostvars={}, hostname='inventory_hostname'):
            self.hostvars = hostvars
            self._hostname = hostname

        def get_host(self, hostname):
            return self.hostvars.get(hostname)

        @property
        def inventory_hostname(self):
            return self._hostname

    class TestTemplar(object):
        def __init__(self, vars):
            self._available_variables = vars

        @property
        def available_variables(self):
            return self._available_variables

        def _flatten(self, data, preserve_dicts=True):
            """Flattens a list or dict into a list, no dicts are preserved."""

# Generated at 2022-06-23 12:45:02.886071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_option('default') is None

# Generated at 2022-06-23 12:45:06.121338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # test _flatten()
    lookup_module._flatten('1,2,3', False)
    lookup_module._flatten(['1,2', '3'], False)

# Generated at 2022-06-23 12:45:08.021208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run(['https_port']) == [443, 443]

# Generated at 2022-06-23 12:45:17.490096
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os

    # Mock variables
    class MockTemplar(object):
        def __init__(self):
            self.available_variables = {}

        def template(self, value, fail_on_undefined=True):
            return value

    class MockVariableManager(object):
        def __init__(self):
            mock_vars = {
                      "ansible_play_hosts":['localhost'],
                      "ansible_play_batch":['localhost'],
                      "ansible_play_hosts_all":['localhost'],
                      "variablename": "hello",
                      "myvar": "ename",
                      "variablnotename": "notexists"
                      }
            self._available_variables = {'hostvars': {'localhost': mock_vars}}
            self._vars_cache

# Generated at 2022-06-23 12:45:26.836231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    fake_hostvars = {'host1': {'variable1': 'value1'}, 'host2': {'variable2': 'value2'}}

# Generated at 2022-06-23 12:45:37.813769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass
#    #############################################################################
#    class MockTemplar(object):
#        # There are no __init__ method in the code but we write it here to
#        # make the tests easier.
#        def __init__(self):
#            self.available_variables = {}
#            self._available_variables = {}
#
#        def template(self, value, fail_on_undefined=True):
#            return value
#    class MockInventory(object):
#        # There are no __init__ method in the code but we write it here to
#        # make the tests easier.
#        def __init__(self):
#            self.set_variable()
#    class MockContext(object):
#        # There are no __init__ method in the code but we write it here to
#        #

# Generated at 2022-06-23 12:45:39.680353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Constructor: LookupModule()
    Assertion: None
    """
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 12:45:40.495603
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not isinstance(LookupModule, object)

# Generated at 2022-06-23 12:45:41.829361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(LookupModule)


# Generated at 2022-06-23 12:45:43.020942
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:45:51.963779
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock class LookupBase
    class LookupBase_mock:
        def __init__(self):
            self._options = {'default': None}
            self._templar = TestTemplar()

        def set_options(self, var_options=None, direct=None):
            if var_options:
                self._options['var_options'] = var_options
            if direct:
                self._options['direct'] = direct

        def get_option(self, term):
            if term in self._options:
                return self._options[term]

    # Mock class Templar
    class TestTemplar:
        def __init__(self):
            self._available_variables = {'var_name': 'value', 'hostvars': {'hostname': {'host_var': 'host_value'}}}


# Generated at 2022-06-23 12:46:02.585734
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myTemplate = '''
        {
            "key1": "value1",
            "key2": "value2",
            "nest": {
                "sub_key1": "sub_value1",
                "sub_key2": "sub_value2"
            }
        }
        '''

    myHostVars = {'hostvars': {'inventory_hostname': {'host_key1': 'host_value1', 'host_key2': 'host_value2'}}}
    myLookupBase = LookupBase()
    myLookupBase.set_options(var_options=myHostVars)
    myLookupBase._templar.template = lambda x, fail_on_undefined: x


# Generated at 2022-06-23 12:46:03.408666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:46:14.882447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()

    # Normal Case
    # Case 1
    lookup_module_obj._templar.available_variables = {'variable_name_1': 'value_1'}
    lookup_module_obj.set_options(var_options=lookup_module_obj._templar.available_variables, direct={})
    assert ['value_1'] == lookup_module_obj.run(['variable_name_1'], lookup_module_obj._templar.available_variables)

    # Case 2
    lookup_module_obj._templar.available_variables = {'variable_name_2': 'value_2'}
    lookup_module_obj.set_options(var_options=lookup_module_obj._templar.available_variables, direct={})


# Generated at 2022-06-23 12:46:22.676643
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test good terms
    lm = LookupModule()
    terms = ['a', 'b', 'c']
    ret = lm.run(terms)
    assert isinstance(terms, list)
    assert isinstance(ret, list)

    # Test bad term
    try:
        lm.run(terms='bad term')
    except AnsibleError as e:
        assert 'is not a string' in str(e)
        assert 'not a string' in str(e)

# Generated at 2022-06-23 12:46:34.731269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a MockTemplar object
    mock_templar = MockTemplar()

    # Create a LookupModule object
    my_vars_lookup = LookupModule(loader=None, templar=mock_templar)

    # Create a MockConfModule object
    mock_conf_module = MockConfModule()

    # Create a MockConnection object
    mock_connection = MockConnection()

    # Create a MockPlayContext object
    mock_play_context = MockPlayContext()

    # Set an attribute for the MockPlayContext object
    setattr(mock_play_context, 'connection', mock_connection)

    # Create a MockTask object
    mock_task = MockTask()

    # Set an attribute for the MockTask object

# Generated at 2022-06-23 12:46:41.424962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Make sure the constructor is invoked correctly

    # Make sure it invokes the super class' constructor
    try:
        l = LookupModule()
    except Exception as e:
        assert(False)

    # Make sure the super class' constructor is invoked correctly
    try:
        l.run([], [])
    except Exception as e:
        assert(False)
        raise



# Generated at 2022-06-23 12:46:45.776853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = 'test'
    variables = None
    kwargs = {'kwarg1': 'test1', 'kwarg2': 'test2'}
    lookup_plugin.run(terms, variables, **kwargs)

# Generated at 2022-06-23 12:46:47.253237
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 12:46:49.416481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print("LookupModule: {}".format(lookup))
    assert lookup is not None


# Generated at 2022-06-23 12:46:50.323568
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-23 12:47:01.251040
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['terms_one', 'terms_two']
    variables = {'terms_one': 'one', 'terms_two': 'two', 'inventory_hostname': 'test'}
    kwargs = {'inventory_hostname': 'test'}
    expected = ['one', 'two']

    lookup = LookupModule()
    lookup.run(terms, variables, **kwargs)

    assert lookup._templar._available_variables == variables
    assert lookup._lookup_terms == terms
    assert lookup._lookup_options == kwargs
    assert lookup._lookup_opts == {'_terms': terms, '_raw_params': u'terms_one, terms_two'}
    assert lookup._lookup_opts['_params'] == [u'terms_one', u'terms_two']


# Generated at 2022-06-23 12:47:11.848465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from .test_lookup_plugins import TestLookupModule

    # Test without a templar
    module = TestLookupModule()
    terms = ['variablename', 'myvar']
    variables = {
        'variablename': 'hello',
        'myvar': 'ename',
        }
    module.run(terms, variables)

    # Test with a templar
    module = TestLookupModule(
        templar = {
            '_available_variables': variables,
        },
    )
    module.run(terms, variables)

    # Test with a templar and a default
    module = TestLookupModule(
        templar = {
            '_available_variables': variables,
        },
    )
    terms = ['variablename', 'myvar', 'variablemissing']

# Generated at 2022-06-23 12:47:18.365916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test method run
    """
    terms = ['hostvars', 'hostvars', 'hostvars']
    # try:
    #     obj = LookupModule()
    #     result = obj.run(terms)
    #     print(result)
    # except AnsibleUndefinedVariable as e:
    #     print(e.message)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:47:29.357076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_self = Mock()
    mock_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    mock_templar = Mock()
    mock_self._templar = mock_templar

    mock_self.get_option.return_value = None
    mock_templar.template.return_value = ['foo', 'bar']

    ret = LookupModule.run(mock_self, mock_terms)
    assert ret == ['foo', 'bar']
    mock_self.set_options.assert_called_once_with(var_options=None, direct={})
    mock_self.get_option.assert_called_once_with('default')

    mock_self.reset_mock()

# Generated at 2022-06-23 12:47:40.052348
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test for ansible variable lookup for key in vars
    def test_static_lookup_top_level(self):
        mylookup = LookupModule()
        mylookup._templar = DictMemoized(fail_on_undefined=False)
        mylookup._templar._available_variables = {
           'ansible_play_hosts': ['localhost'],
           'ansible_play_batch': 'localhost',
           'ansible_play_hosts_all': 'localhost',
           'ansible_play_hosts_all': 'localhost',
           'inventory_hostname': 'localhost',
           'variablename': 'hello',
           'variablenotename': 'hello',
        }
        mylookup.set_options(var_options={}, direct={})

# Generated at 2022-06-23 12:47:45.047152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global LookupModule
    lookup = LookupModule()
    assert lookup.run(terms=['ansible_play_hosts']) == ['localhost']
    assert lookup.run(terms=['ansible_play_hosts', 'ansible_play_batch']) == ['localhost', None]

# Generated at 2022-06-23 12:47:47.719071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_module = LookupModule()
    assert test_lookup_module is not None

# Generated at 2022-06-23 12:47:49.367513
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:47:59.291087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play_context import PlayContext

    module_class = LookupModule(play_context=PlayContext(vars=dict(test_var='test_value')))

    # TEST 1: test_var exists
    ret = module_class.run(terms=['test_var', 'test_var2'], variables=dict())
    assert ret == ['test_value', None]

    # TEST 2: test_var exists, test_var2 does not exist
    module_class = LookupModule(play_context=PlayContext(vars=dict(test_var='test_value')))
    ret = module_class.run(terms=['test_var'], variables=dict())
    assert ret == ['test_value']



# Generated at 2022-06-23 12:48:01.514766
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(None, None) == [], "Empty input to lookup module should return empty list as result"

# Generated at 2022-06-23 12:48:13.487407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test for retrieving the value of an Ansible variable
    terms = ['variablename', 'myvar']
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    result = module.run(terms, variables)
    assert result == ['hello']
    # Test for retrieving the default value if a variable is undefined
    terms = ['variablename', 'myvar']
    variables = {'variablename': 'hello', 'myvar': 'notename'}
    result = module.run(terms, variables, default='')
    assert result == ['']
    # Test for getting error if a variable is undefined and no default is set
    terms = ['variablename', 'myvar']

# Generated at 2022-06-23 12:48:25.153385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add more test cases
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        unicode = str

    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class Templar(object):
        def __init__(self, available_variables):
            self._available_variables = available_variables

        def template(self, value, fail_on_undefined):
            return value

    class LookupModuleInstance(LookupModule):
        def __init__(self, loader=None, templar=None, *args, **kwargs):
            self._loader = loader
            self._templar = templar
            # We do not explicitly call the parent constructor because it is already

# Generated at 2022-06-23 12:48:30.332785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert [] == LookupModule().run(['test_user'], {})
    assert [] == LookupModule().run(['test_user'], {'hostvars': {'test_host': {'test_user': 'test'}}})
    assert ['test'] == LookupModule().run(['test_user'], {'hostvars': {'test_host': {'test_user': 'test'}}, 'inventory_hostname': 'test_host'})

# Generated at 2022-06-23 12:48:33.213150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.vars import LookupModule
    result = LookupModule().run(terms=["this_is_a_name"], variables={"this_is_a_name":"this works"})
    print(result)

# Generated at 2022-06-23 12:48:45.583378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Verify that specifying a non-string term raises an exception
    lookupModule = LookupModule()
    try:
        lookupModule.run(["a", 1])
        assert False, "Should have raised an exception"
    except AnsibleError:
        assert True

    # Verify that an undefined variable will result in an error when no default is specified.
    lookupModule = LookupModule()
    try:
        lookupModule.run(["undefined_variable"])
        assert False, "Should have raised an exception"
    except AnsibleUndefinedVariable:
        assert True

    # Verify that an undefined variable will result in an error when default is an empty string.
    lookupModule = LookupModule()

# Generated at 2022-06-23 12:48:52.164326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # simple test of verify_file against a known-good public key
    from ansible.plugins.lookup.vars import LookupModule
    lookup = LookupModule()
    assert lookup.run([], variables={'test': 'yes'}) == []
    assert lookup.run(['test'], variables={'test': 'yes'}) == ['yes']
    assert lookup.run(['test2'], variables={'test': 'yes'}) == []
    assert lookup.run(['test2'], variables={'test': 'yes'}, default='no') == ['no']

# Generated at 2022-06-23 12:48:54.039264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:49:03.257107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from collections import namedtuple
    import pytest

    # Fixture to support manual testing of #14146.
    @pytest.fixture
    def lookup_type_result(monkeypatch):
        """Simulate results of type_lookup"""
        LookupBaseClass = namedtuple('LookupBaseClass', ['run', 'ask_variables_on_stdin'])
        LookupModuleClass = namedtuple('LookupModuleClass', ['set_options', 'get_option'])
        lookup_base_inst = LookupBaseClass(run=test_LookupModule_run, ask_variables_on_stdin=False)

# Generated at 2022-06-23 12:49:13.939062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests run using the following fixtures
    # test/unit/plugins/lookup/var_fixtures/host_with_variables.py
    # test/unit/plugins/lookup/var_fixtures/hostvars.py
    # test/unit/plugins/lookup/var_fixtures/plugin_loader.py
    # test/unit/plugins/lookup/var_fixtures/plugin.py
    # test/unit/plugins/lookup/var_fixtures/group_vars/all.yaml
    # test/unit/plugins/lookup/var_fixtures/inventory.ini
    import pytest
    from ansible import context
    from ansible.plugins.loader import lookup_loader

    look = lookup_loader.get('vars')
    context._init_global_context(inventory=None)
    inventory_

# Generated at 2022-06-23 12:49:25.425118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test environment
    terms = ['test1', 'test2']
    test_lookup = LookupModule()
    myvars = {'test1': "test1_value", 'test2':"test2_value"}
    test_lookup._templar._available_variables = myvars
    # Test normal return
    assert test_lookup.run(terms) == ['test1_value', 'test2_value']
    # Test exception
    terms = ['test3', 'test2']
    test_lookup._templar._available_variables = myvars
    test_lookup.set_options(default="default_value")
    assert test_lookup.run(terms) == ['default_value', 'test2_value']

# Generated at 2022-06-23 12:49:32.094020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = AnsibleUndefinedVariable()
    l._templar._available_variables = {'a': '1', 'b': '2'}

    assert l.run(['a']) == ['1']
    assert l.run(['a', 'b']) == ['1', '2']
    assert l.run(['unk']) == [None]
    assert l.run(['unk'], default='0') == ['0']

# Generated at 2022-06-23 12:49:43.829101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    facts = {"ansible_distribution": "CentOS",
            "ansible_distribution_major_version": "7",
            "ansible_facts": {"distribution": "CentOS", "distribution_major_version": "7"}}
    # test with empty terms, should raise an AnsibleError
    try:
        lookup_obj.run([], facts)
        assert False
    except AnsibleError as err:
        assert "Error with input, needs to be a list" in str(err)

    # test with invalid terms, should raise an AnsibleError
    try:
        lookup_obj.run([1], facts)
        assert False
    except AnsibleError as err:
        assert "Invalid setting identifier" in str(err)

    # test with invalid term type, should raise an Ansible

# Generated at 2022-06-23 12:49:46.876871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert repr(lookup_instance) == "<ansible.plugins.lookup.vars.LookupModule object at 0x1063c1c18>"

# Generated at 2022-06-23 12:49:50.242691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the __init__ constructor
    assert(hasattr(LookupModule, '__init__'))
    l = LookupModule()
    assert(hasattr(l, 'run'))


# Generated at 2022-06-23 12:50:01.888520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible import constants as C
    from ansible.plugins.loader import lookup_loader

    # Create a new instance of the LookupBase class
    instance = lookup_loader.get('vars')

    # Confirm that the value of the module_loader attribute of the instance is not None
    assert instance.module_loader is not None

    # Confirm that the value of the result attribute of the instance is None
    assert instance.result is None

    # Confirm that the value of the basedir attribute of the instance is './.ansible/tmp'
    assert instance.basedir == './.ansible/tmp'

    # Confirm that the value of the _options attribute of the instance is an instance of type dict
    assert isinstance(instance._options, dict)

    # Create a new dict object
    d = dict()

    # Set the value of the "

# Generated at 2022-06-23 12:50:12.065058
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    lookup_module = LookupModule()
    myvars = {'one': 'Hello', 'two': 'World'}
    lookup_module._templar._available_variables = myvars
    assert lookup_module.run(['one']) == ['Hello']

    # Verify that the 'inventory_hostname' will be prepended in the lookup results
    # in case of the var_name is not present and is present in 'hostvars'
    myvars = {'hostvars': {'inventory_hostname': {'one': 'Hello', 'two': 'World'}}}
    lookup_module._templar._available_variables = myvars


# Generated at 2022-06-23 12:50:14.808489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with a non-string term
    try:
        module = LookupModule()
        module.run([{'msg': "This test should fail"}])
    except AnsibleError:
        pass
    else:
        assert False

# Generated at 2022-06-23 12:50:15.288858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:50:23.646699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Sanity test to check the method run of class LookupModule
    '''
    import os

    lookup_obj = LookupModule()
    basedir = os.path.join(os.path.dirname(__file__), '..', '..', '..')
    env = {'terms': ['foo'], 'variables': {'foo': 'bar', 'lookup_plugins': basedir}}
    result = lookup_obj.run(**env)
    assert result == ['bar']

# Generated at 2022-06-23 12:50:29.153429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': 'all', 'ansible_play_batch': '12', 'ansible_play_hosts_all' : '12'}
    l = LookupModule()
    result = l.run(terms, variables)
    assert result == ['all', '12', '12']


# Generated at 2022-06-23 12:50:41.100545
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:50:42.545918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-23 12:50:44.229095
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert ( LookupModule().run(terms=["test"], variables={"test": "test"}) == ["test"] )

# Generated at 2022-06-23 12:50:54.213230
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class DummyTemplar:
        def template(self, value, fail_on_undefined=True):
            if value == "Hello":
                return "Bye"
            else:
                raise AnsibleUndefinedVariable('No variable found with this name: %s' % value)

    lu = LookupModule()
    lu.set_options(var_options={'options': {'min_value':1, 'max_value':2}}, direct={'warn':False, 'fail':False})

    lu._templar = DummyTemplar()
    lu._templar._available_variables = {"var1": "Hello", "var2": "World", "hostvars": {"host1": {"var1": "World"}, "host2": {"var2": {"Hello": "Bye"}}}}

# Generated at 2022-06-23 12:50:56.758419
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert (lm is not None)


# Generated at 2022-06-23 12:51:06.225079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    inventory = Inventory(context.CLIARGS['inventory'])
    host = inventory.get_host("127.0.0.1")
    variable_manager = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-23 12:51:13.274010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lm = LookupModule()
    lm._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}

    # Act
    ret = lm.run(['variabl' + lm._templar._available_variables['myvar']])

    # Assert
    assert ret == ['hello']
