

# Generated at 2022-06-25 11:48:11.353196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_0 = dict()
    vars_0['variablename'] = 'hello'
    vars_0['myvar'] = 'ename'
    terms_0 = ['variabl' + vars_0['myvar']]
    kwargs_0 = dict()
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0, variables=vars_0, **kwargs_0)

# Generated at 2022-06-25 11:48:18.354322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    actual_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print(actual_0)
    assert actual_0 == []
    print("PASSED: test_LookupModule_run")



# Generated at 2022-06-25 11:48:20.497688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 11:48:25.519723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]
    lookup_module_0.run(terms, variables=None)
    assert_equal(type(lookup_module_0._templar._available_variables), dict)

# Generated at 2022-06-25 11:48:27.395956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars_lookup_module = LookupModule()
    assert vars_lookup_module.run(terms=['some_var']) == ['']

# Generated at 2022-06-25 11:48:30.458329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    variables = None
    kwargs = {'default': None}
    assert lookup_module_0.run(terms, variables, **kwargs) == []


# Generated at 2022-06-25 11:48:33.858033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = "variablename"
    variables = None
    kwargs = {'default': ''}
    assert lookup_module_0.run([term], variables, **kwargs) == ['hello']

# Generated at 2022-06-25 11:48:45.287208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types

    lookup_module_0 = LookupModule()
    # Test case where terms is an instance of string_types
    terms_0 = 'string_types'
    assert isinstance(terms_0, string_types)
    # Test case where 'variables' is an instance of dict
    variables_0 = {}
    assert isinstance(variables_0, dict)
    # Test case where 'variables' is an instance of dict
    variables_1 = {}
    assert isinstance(variables_1, dict)
    try:
        result = lookup_module_0.run(terms=terms_0, variables=variables_0, direct=variables_1)
    except Exception as e:
        raise AnsibleError(e)



# Generated at 2022-06-25 11:48:52.800620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([{'my_option': 'my_value'}])
    lookup_module.run([{'_terms': 'test_variable', 'default': 'default_value'}])
    lookup_module.run([{'_terms': {'key_1': 'value_1', 'key_2': 'value_2'}, 'default': 'default_value'}])

# Test run with arguments

# Generated at 2022-06-25 11:48:58.257262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms_0 = ['hostvars', 'myvar']
    try:
        test_result = lookup_module_0.run(test_terms_0)
    except AnsibleError as err:
        print(err)
        print('This test should not fail, it is a bug.')
        raise RuntimeError

# Generated at 2022-06-25 11:49:07.936752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = 'inventory_hostname'
    variables = {'inventory_hostname': 'host1'}
    lookup_module_0.run(term, variables)

# Generated at 2022-06-25 11:49:08.973091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()



# Generated at 2022-06-25 11:49:11.366060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    #print("Testing run")
    result = lookup_module_0.run("")
    assert result == []


# Generated at 2022-06-25 11:49:19.343284
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables_0 = {u'ansible_play_hosts': u'192.168.42.42,127.0.0.1', u'ansible_play_batch': u'0', u'ansible_play_hosts_all': u'192.168.42.42,127.0.0.1'}
    expected_result = [u'192.168.42.42,127.0.0.1', u'0', u'192.168.42.42,127.0.0.1']

    result = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:49:21.015797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([]) == []


# Generated at 2022-06-25 11:49:23.458511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options_from_plugi

# Generated at 2022-06-25 11:49:32.289891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['b', 'c']
    variables_1 = {'b': 'd', 'c': 'a'}
    default_1 = None
    lookup_module_1.set_options(var_options=variables_1, direct=None)
    lookup_module_1.get_option('default')
    lookup_module_1.run(terms=terms_1, variables=variables_1, default=default_1)


# Generated at 2022-06-25 11:49:34.455439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'mock_term'
    lookup_module_0.run(terms)


# Generated at 2022-06-25 11:49:35.513174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:49:39.802946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up parameters passed to method
    terms = list()
    variables = dict()
    lookup_module_0 = LookupModule()
    # execute method
    lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:50:00.118037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_var_0 = {"hostvars": "a variable", "inventory_hostname": "a variable", "lookup_plugin": "a variable", "lookup_loader": "a variable", "lookup_templar": "a variable", "lookup_inventory_loader": "a variable", "lookup_basedir": "a variable", "groups": "a variable", "group_names": "a variable", "omit": "a variable", "optional_variables": "a variable", "templar": "a variable", "loader": "a variable"}
    lookup_module_kwargs_var_0 = {"fail_on_undefined": "a variable", "default": "a variable", "var_options": "a variable", "direct": "a variable"}
    lookup_module_kwargs_default_0 = "a variable"


# Generated at 2022-06-25 11:50:11.125372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    ansible_play_hosts = ['localhost', '127.0.0.1']
    ansible_play_batch = None
    ansible_play_hosts_all = ['localhost', '127.0.0.1']
    ansible_play_hosts = lookup_module_1.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], {'ansible_play_batch': ansible_play_batch, 'ansible_play_hosts': ansible_play_hosts, 'ansible_play_hosts_all': ansible_play_hosts_all})

# Generated at 2022-06-25 11:50:18.250013
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = ["variablename"]
    myvar_0 = "ename"

    lookup_module_0._templar._available_variables = {"variablename": "hello"}
    lookup_module_0._templar._available_variables['myvar'] = "ename"

    result_0 = lookup_module_0.run(terms_0)

    assert result_0 == ['hello']

# Generated at 2022-06-25 11:50:20.215033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    value_0 = lookup_module_0.get_option('default')
    assert value_0 == None


# Generated at 2022-06-25 11:50:30.932863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for run
    #
    # Check if it returns correct value
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

# Generated at 2022-06-25 11:50:32.133874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()


# Generated at 2022-06-25 11:50:42.455185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_0 = {'inventory_hostname': 'ansible-inventory'}
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    assert lookup_module_0.run(terms=terms_0) == []
    assert lookup_module_0.run(terms=terms_0, variables=vars_0) == [ ['ansible-inventory'], [], ['ansible-inventory'] ]
    vars_0 = {'inventory_hostname': 'ansible-inventory'}
    terms_0 = ['variablename']
    assert lookup_module_0.run(terms=terms_0) == []

# Generated at 2022-06-25 11:50:44.004176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == None

# Generated at 2022-06-25 11:50:48.822356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'fail_on_undefined':'yes'})
    lookup_module_0._templar._available_variables = {'hostvars': {'hostname': {'var1': 'abc'}}}
    lookup_module_0._templar.template = lambda x, y, z: x
    lookup_module_0._templar._available_variables['inventory_hostname'] = 'hostname'
    
    assert lookup_module_0.run(['var1']) == ['abc']

# Generated at 2022-06-25 11:50:52.115955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=['wfid', 'wfid'])
    assert ret == ['0000', '0000']


# Generated at 2022-06-25 11:51:20.271256
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for run with argument terms, variables=None, and kwargs={}
    lookup_module_0 = LookupModule()
    lookup_module_0 = AnsibleLookupModule()
    result = lookup_module_0.run(terms=['foo'], variables=None, **{})


# Generated at 2022-06-25 11:51:31.060940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert_value = ['hello']
    assert_value_1 = ['']
    assert_value_2 = []
    assert_value_3 = ['{u\'127.0.0.1\': {}}', '{u\'127.0.0.1\': {}}', '{u\'127.0.0.1\': {}}']
    assert_value_4 = [u'12']
    assert_value_5 = ['{u\'127.0.0.1\': {}}', '{u\'127.0.0.1\': {}}', '{u\'127.0.0.1\': {}}']

# Generated at 2022-06-25 11:51:35.318554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module
    # test for missing argument
    try:
        lookup_module.run()
    except TypeError as e:
        assert 1


# Generated at 2022-06-25 11:51:37.831952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.lookup import LookupBase
    lookup_module = LookupModule()
    lookup_module.set_loader({})
    lookup_module.set_env({})
    lookup_module.set_inventory({})
    lookup_module.set_basedir('/')
    lookup_module._templar = LookupBase._create_templar(variables={})

    lookup_module.run(terms=["lookup_extras.lookup_type"], variables=None, **{})

# Generated at 2022-06-25 11:51:45.870103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["variabl", lookup_module_0]
    variables_0 = {}
    terms_1 = ["variabl", "hostvars", "inventory_hostname", lookup_module_0]
    variables_1 = {}
    # This one fails in ansible v2.8.3
    #terms_3 = ["variabl", "myvar", "default"]
    #variables_3 = {}
    terms_4 = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]
    variables_4 = {}
    terms_5 = ["variabl", "myvar", ".sub_var"]
    variables_5 = {}
    terms_6 = ["ansible_play_", lookup_module_0]
    variables

# Generated at 2022-06-25 11:51:50.260512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]

    default = False

    result = lookup_module_0.run(terms, default)
    assert result == [
        ['127.0.0.1'],
        2,
        ['127.0.0.1'],
    ]

# Generated at 2022-06-25 11:51:59.961366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['hello']
    default = 'world'
    variables = {'hello': 'world', 'ansible_play_hosts': ['a', 'b', 'c'], 'ansible_play_batch': ['d'], 'ansible_play_hosts_all': ['e'], 'inventory_hostname': 'localhost'}
    kwargs = {'default': 'world'}
    lookup_module_0.run(terms, variables, **kwargs)
    return

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:52:09.663357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(
        direct={
            'default': ''
        })
    myvars = {
        'variablename': 'hello',
        'myvar': 'ename',
        'hostvars': {
            'inventory_hostname': {
                'variablnotename': 'notfound'
            }
        }
    }
    assert lookup_module.run(
        terms=[
            'variabl' + myvars['myvar']
        ],
        variables=myvars) == ['hello']
    assert lookup_module.run(
        terms=[
            'variablnotename'
        ],
        variables=myvars) == ['']

# Generated at 2022-06-25 11:52:13.791499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['variablename', 'myvar']
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=terms, variables=variables)
    assert result == ['hello']
    assert lookup_module_1.run(terms=None) == []
    assert lookup_module_1.run(terms=None, variables=variables) == []


# Generated at 2022-06-25 11:52:23.883938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar()
    lookup_module._templar._available_variables = {
        'hostname_0': 'hostname_0',
        'variablename_0': 'variablename_0',
        'myvar_0': 'myvar_0',
        'hostvars': {
            'inventory_hostname_0': {
            }
        }
    }


# Generated at 2022-06-25 11:53:21.040475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_option = lambda x: None
    lookup_module_0._templar = None
    lookup_module_0._templar.available_variables = dict()
    lookup_module_0.get_option = lambda x: None
    lookup_module_0.get_option = lambda x: None
    terms_0 = ['a']
    lookup_module_0.run(terms_0, lookup_module_0._templar.available_variables)


# Generated at 2022-06-25 11:53:30.329395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], {'ansible_play_batch': '', 'ansible_play_hosts': [], 'ansible_play_hosts_all': []}) == [
        [], '', []]

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-s', '-v'])

# Generated at 2022-06-25 11:53:32.573295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_obj = LookupModule()
    args = [
            "terms",
            "variables=None"
            ]
    assert lookup_module_run_obj.run(*args)

# Generated at 2022-06-25 11:53:34.542326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:53:38.209132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(["ansible_test_var_0", "ansible_test_var_1"], {"ansible_test_var_0": "some_value_0", "ansible_test_var_1": "some_value_1", } ) == ["some_value_0", "some_value_1"]


# Generated at 2022-06-25 11:53:39.009596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:53:43.154870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = [
        'variablename',
    ]
    params_0 = {
        'variables': None,
    }

    res_0 = lookup_module_0.run(args_0, params_0)

    assert res_0 == ['hello']

# Generated at 2022-06-25 11:53:46.903796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lookup_module_0 = LookupModule()
    # uncomment when module is complete
    # assert lookup_module_0.run(terms) == []



# Generated at 2022-06-25 11:53:50.127450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == None, 'Test failed'

# Generated at 2022-06-25 11:53:59.075867
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test variables
    test_variables = {}

    # Test methods
    lookup_module_0 = LookupModule()

    # Test results
    test_result = lookup_module_0.run(terms, variables=test_variables)

    # Assertions

# Unit test main program
if __name__ == '__main__':
    # Import the package module to test
    module = __import__('vars')
    # Create a lookup class using module
    lookup_class = getattr(module, 'LookupModule')
    # Create an instance of the lookup class
    lookup_instance = lookup_class()
    # Create a lookup module using instance
    test_LookupModule_run()

# Generated at 2022-06-25 11:55:04.690117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00:\x10_'
    str_0 = '~'
    var_0 = lookup_run(lookup_module_0, bytes_0, str_0)
    assert var_0 == ['username'] or var_0 == ['~'] or var_0 == ['username'], 'Expected 'if var_0 == ['username'] or var_0 == ['~'] or var_0 == ['username']else 'Expected '+str(var_0) + ' to be equal to ' + '["username"]' + " or " + '["~"]' + " or " + '["username"]'


# Generated at 2022-06-25 11:55:11.768630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'c\xda'
    var_0 = lookup_run(lookup_module_0, bytes_0)
    print(var_0)


# Generated at 2022-06-25 11:55:13.555334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run(['vault_password_file']) == ['~/.vault_pass.txt']
    assert lookup_module_0.run(['inventory_dir', 'inventory_file']) == ['.']


# Generated at 2022-06-25 11:55:19.312508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    setattr(lookup_module_0, '_available_variables', {'key1': 'value1', 'key2': 'value2'})
    bytes_0 = b''
    var_0 = lookup_run(lookup_module_0, bytes_0)
    assert isinstance(var_0, list)
    str_0 = str(var_0)
    assert str_0 == "['value1', 'value2']"

# Generated at 2022-06-25 11:55:20.841896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert callable(getattr(lookup_module, "run"))


# Generated at 2022-06-25 11:55:32.410165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup args
    terms = ['var1', 'var2']

    # Expected return value
    ret = []

    # Setup mocks
    lookup_module_0 = LookupModule()
    lookup_module_0.get_option = Mock(return_value=None)
    lookup_module_0.set_options = Mock()

    # Call method
    ret = lookup_module_0.run(terms)

    # Assertions
    assert(ret == [])

    # Check call count
    lookup_module_0.get_option.assert_called_once_with('default')
    lookup_module_0.set_options.assert_called_once_with(var_options=None, direct=None)



# Generated at 2022-06-25 11:55:38.460049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global var_0
    var_0 = 'byte-string'
    lookup_module_0 = LookupModule()
    lookup_module_0.var_0 = var_0
    bytes_0 = b'c\xda'
    var_1 = lookup_run(lookup_module_0, bytes_0)
    assert var_0 == var_1


# Generated at 2022-06-25 11:55:40.468854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  bytes_0 = b'c\xda'
  var_1 = lookup_run(lookup_module_0, bytes_0)

# Generated at 2022-06-25 11:55:45.419142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = 'c\xda'
    var_0 = lookup_module_0.run(bytes_0)
    return var_0

# Generated at 2022-06-25 11:55:57.340702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_0 = 'q'
    str_1 = 'i'
    str_2 = 'l'
    str_3 = 'l'
    str_4 = 'o'
    str_5 = 'b'
    str_6 = '_'
    str_7 = 'r'
    str_8 = 'u'
    str_9 = 'n'
    str_10 = 'n'
    str_11 = 'e'
    str_12 = 'r'
    str_13 = '_'
    str_14 = 't'
    str_15 = 'e'
    str_16 = 's'
    str_17 = 't'
    str_18 = '_'
    str_19 = '4'
    key_0 = str_