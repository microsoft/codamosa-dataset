

# Generated at 2022-06-25 11:48:07.934202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = None
    var_options = None
    var_templar = object()
    lookup_base_instance = object()
    lookup_base_instance.get_option = object()
    lookup_base_instance.set_options = object()
    lookup_base_instance._templar = var_templar
    var_option_0 = None
    var_direct_0 = None
    lookup_base_instance.get_option.return_value = var_option_0
    lookup_base_instance.set_options.return_value = var_direct_0

# Generated at 2022-06-25 11:48:17.902423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'ansible_play_hosts': 'localhost', 'ansible_play_batch': 'localhost', 'ansible_play_hosts_all': 'localhost'}}}
    kwargs = {'playbook_dir': 'tests/test_utils/test_data/test_vars'}
    print(lookup_module_0.run(terms, variables, **kwargs))


# Generated at 2022-06-25 11:48:22.728248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = {'variablename': 'hello',
            'myvar': 'ename'}
    lookup_module = LookupModule()
    lookup_module.set_options({'default':None}, direct=data)
    terms = ['variablename']
    result = lookup_module.run(terms)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:48:25.761358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={u'default': u''})
    lookup_module_0.run([u'variabl' + u'myvar'], {})

# Generated at 2022-06-25 11:48:33.997881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert(lookup_module.run([''], {'v': ''}) == [''])

    assert(lookup_module.run(['v'], {'v': ''}) == [''])
    assert(lookup_module.run(['v'], {'v': 'v'}) == ['v'])
    assert(lookup_module.run(['v'], {'v': 'v1'}) == ['v1'])

    assert(lookup_module.run(['a', 'b', 'c'], {'a': '1', 'b': '2', 'c': '3'}) == ['1', '2', '3'])


# Generated at 2022-06-25 11:48:45.326824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["foo", "bar", "baz", "ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all", "variabl' + myvar", "variabl' + myvar", "{}".format("variabl' + myvar")]
    variables = {"foo": "bar", "bar": "baz", "baz": "qux", "ansible_play_hosts": ['foo', 'bar'], "ansible_play_batch": ['foo', 'bar'], "ansible_play_hosts_all": ['foo', 'bar'], "variabl' + myvar": 'bar', "variabl' + myvar": 'baz', "{}".format("variabl' + myvar"): 'qux'}

# Generated at 2022-06-25 11:48:46.580606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run() of class LookupModule')
    test_case_0()

# Generated at 2022-06-25 11:48:56.751900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms = [None]
    lookup_module_1.run(terms, 'variables')

    terms = ['variablename']
    lookup_module_1.run(terms, 'variables')

    terms = ['variablename']
    lookup_module_1.run(terms, 'variables')

    terms = ['variablename']
    lookup_module_1.run(terms, 'variables')

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lookup_module_1.run(terms, 'variables')

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lookup_module_1

# Generated at 2022-06-25 11:48:58.474637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=[], variables=None)


# Generated at 2022-06-25 11:49:07.046536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ansible_vars_0 = {'ansible_play_hosts': [], 'ansible_play_batch': [], 'ansible_play_hosts_all': []}
    lookup_module_0 = LookupModule()
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert [AnsibleUnsafeText(''), AnsibleUnsafeText(''), AnsibleUnsafeText('')] == lookup_module_0.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables=ansible_vars_0)


# Generated at 2022-06-25 11:49:20.501848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ 'msg', 'msg' ]

# Generated at 2022-06-25 11:49:26.270725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["variablename", "variablenotename"]
    variables_0 = {}
    lookup_module_0.set_options(var_options=variables_0)
    try:
        lookup_module_0.run(terms=terms_0)
        assert False
    except AnsibleUndefinedVariable:
        assert True


# Generated at 2022-06-25 11:49:33.280578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of the LookupModule class
    lookup_module = LookupModule()
    # Create the arguments that would be passed to the function lookup_module.run 
    terms = 'variabl' + myvar
    variables = None
    # Try to execute the function lookup_module.run without any arguments
    try:
        lookup_module.run()
    except TypeError:
        pass
    else:
        # check for the output of the function lookup_module.run
        assert False



# Generated at 2022-06-25 11:49:34.077086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() == None

# Generated at 2022-06-25 11:49:37.744808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    variables = {}
    kwargs = {}
    assert lookup_module_0.run(terms, variables, **kwargs) is None
    kwargs = {'default': None}
    assert lookup_module_0.run(terms, variables, **kwargs) is None



# Generated at 2022-06-25 11:49:42.472760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'variablename': 'hello', 'myvar': 'ename'}
    terms = ['variablename']
    module = LookupModule()
    result = module.run(terms, variables=vars)
    assert result == ['hello']


# Generated at 2022-06-25 11:49:44.233249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def do_test(val):
        print(val)

    assert do_test([1]) == None

# Generated at 2022-06-25 11:49:52.421412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    args = [
        'variablename',
        'variablnotename',
    ]
    kwargs = {
        "variables": {
            'variablename': 'hello',
            'myvar': 'ename',
        },
    }
    result = lookup_module.run(args, **kwargs)
    assert result == [
        'hello',
        'hello',
    ], "Expected value should be %s" % result

# Generated at 2022-06-25 11:49:58.825890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["variabl" + "ename"]
    variables = {"variablename" : "hello", "myvar" : "ename"}
    print(lookup_module_0.run(terms, variables=variables))

# Generated at 2022-06-25 11:50:05.214137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assertions 1-10
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1.run(['variablename'], None), list)


# Generated at 2022-06-25 11:50:24.186071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get reference to variable hostvars
    hostvars = lookup_module_0._templar._available_variables['hostvars']
    # Add one more variable
    hostvars['dummy'] = 'dummy_val'
    # Get reference to variable inventory_hostname
    inventory_hostname = lookup_module_0._templar._available_variables['inventory_hostname']
    # Set inventory_hostname
    inventory_hostname = 'dummy'
    # Call lookup_module_0.run with parameters
    # Call with valid parameters
    # Note: Assuming that the variable ansible_play_hosts exists.
    # Note: Assuming that the variable ansible_play_hosts_all exists.
    # Note: Assuming that the variable ansible_play_batch exists.
    # Note: Assuming that the variable ans

# Generated at 2022-06-25 11:50:35.548771
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:50:41.400397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_attributes_0 = {'undefined_variable_dict': {}}
    lookup_module_0._templar = DummyTemplar(my_attributes_0)
    my_attributes_1 = {'undefined_variable_dict': {}}
    lookup_module_0._templar = DummyTemplar(my_attributes_1)
    assert lookup_module_0.run('', '') is None
    assert lookup_module_0.run('', '') is None


# Generated at 2022-06-25 11:50:45.811571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options()
    lookup_module_1_run_args1 = [{'myvar': 'ename', 'variablename': 'hello'}]
    lookup_module_1_run_args2 = None
    lookup_module_1_run_values = ['hello']
    lookup_module_1.run(lookup_module_1_run_args1, lookup_module_1_run_args2)


# Generated at 2022-06-25 11:50:51.332056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"])
    assert ret == ['test_hosts_0', 'test_batch_0', ['test_hosts_0']]


# Generated at 2022-06-25 11:50:54.471842
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # TODO: implement this test case
    assert 0 == 0

# Generated at 2022-06-25 11:50:57.253199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '''variabl'''
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == []

# Generated at 2022-06-25 11:51:01.677918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError

    lookup_module_1 = LookupModule()
    terms = None
    variables = None
    lm_run_ret = lookup_module_1.run(terms,variables)
    assert lm_run_ret == None


# Generated at 2022-06-25 11:51:07.090702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'variablename', u'variablename']
    variables_0 = {}
    kwargs_0 = {}
    list_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert list_0 == ['hello', 'hello']


# Generated at 2022-06-25 11:51:13.198254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    myvars = {'hostvars': {'inventory_hostname': {'myvar': 'name'}}, 'variablename': 'hello'}
    terms_1 = ['variablename']
    default_1 = "''"
    variables = myvars
    kwargs_1 = {"default": default_1}
    ret = lookup_module_1.run(terms_1, variables=variables, **kwargs_1)
    assert ret[0] == "hello"

# Generated at 2022-06-25 11:51:31.694065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)


# Generated at 2022-06-25 11:51:36.301026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(None)

    # Testing with valid input
    terms = ['keys']
    lookup_module_1.run(terms)
    assert True

    # Testing with invalid input
    terms = ['term1']
    lookup_module_1.run(terms)
    assert True


# Generated at 2022-06-25 11:51:43.072571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)

# Generated at 2022-06-25 11:51:43.830142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = test_case_0()
    test_case_0()



# Generated at 2022-06-25 11:51:51.462331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    map_0 = map()

# Generated at 2022-06-25 11:51:59.412858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)
    assert var_0 == []

# Basic test of the lookup module

# Generated at 2022-06-25 11:52:09.272064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_7 = LookupModule({})
    lookup_module_7.run(['variablename'])

    lookup_module_8 = LookupModule({})
    lookup_module_8.run(['variablename'], {'variablnotename': 'hello'})

    lookup_module_9 = LookupModule({})
    lookup_module_9.run(['variablename'], {'variablenotename': 'hello'}, default='')

    lookup_module_10 = LookupModule({})
    lookup_module_10.run(['variablename'], {'variablenotename': 'hello'})

    lookup_module_11 = LookupModule({})

# Generated at 2022-06-25 11:52:15.890580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)


# Generated at 2022-06-25 11:52:21.383261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    list_0 = [{}, {}]
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    list_1 = [{}, {}]
    var_0 = lookup_module_2.run(list_1, list_0)

# Generated at 2022-06-25 11:52:31.312403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    list_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    dict_0 = dict()
    try:
        var_0 = lookup_module_0.run(list_0, dict_0)
    except AnsibleUndefinedVariable:
        var_0 = None
    assert var_0 == None
    try:
        var_0 = lookup_module_0.run(list_0, dict_0)
    except AnsibleUndefinedVariable:
        var_0 = None
    assert var_0 == None
    try:
        var_0 = lookup_module_0.run(list_0, dict_0)
    except AnsibleUndefinedVariable:
        var_0 = None
   

# Generated at 2022-06-25 11:53:01.232520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    set_1 = set()
    bool_1 = False
    lookup_module_4 = LookupModule(bool_1)
    var_1 = lookup_module_4.run(set_1)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['inventory_hostname'] = 'myhost'
    dict_1['hostvars'] = dict_0
    dict_1['var_1'] = var_1
    dict_1['var_0'] = var_0
    var_2 = lookup_module_3.run(set_1, dict_1)

# Generated at 2022-06-25 11:53:10.946160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)
    assert var_0 is None
    # Uncomment the next two lines for debug
    # print('test_LookupModule_run(): var_0 = {var_0!r}'.format(var_0=var_0))
    # print('test_LookupModule_run(): type(var_0) = {type(var_0)!r}'.format(type(var_0)))


# Generated at 2022-06-25 11:53:20.152356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)

    str_0 = 'Host is %s'
    str_1 = 'host'
    lookup_module_1._templar = mock_0 = MagicMock(return_value=str_0)
    lookup_module_1._templar._available_variables = {str_1: 'host'}
    lookup_module_1.run([])

# Generated at 2022-06-25 11:53:29.725643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    term_0 = ""
    var_0 = lookup_module_1.run(term_0)
    assert_true(var_0)
    term_1 = ""
    var_0 = lookup_module_1.run(term_1)
    assert_true(var_0)
    term_2 = ""
    var_0 = lookup_module_1.run(term_2)
    assert_true(var_0)

# Generated at 2022-06-25 11:53:38.350535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    _TEMPLAR = object()
    lookup_module._templar = _TEMPLAR
    _TEMPLAR._available_variables = {}
    TERMS = (object(),)
    # TODO: Implement test or mock _load_vars()
    # lookup_module._load_vars(TERMS)
    lookup_module._load_vars = lambda terms: terms
    variables = object()
    direct = object()
    ret = lookup_module.run(terms=TERMS, variables=variables, direct=direct)

# Generated at 2022-06-25 11:53:44.098349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    dict_0 = dict()
    bool_0 = False
    set_1 = set()
    dict_1 = dict()
    var_0 = lookup_module_0.run(set_0, dict_0, default=bool_0)
    var_1 = lookup_module_0.run(set_1, dict_1, default=bool_0)


# Generated at 2022-06-25 11:53:54.053515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    lookup_module_2.run(set_0)
    lookup_module_1.run(set_0)
    map_0 = {'test_var': 'test_var'}
    lookup_module_2.run(set_0, variables=map_0)
    lookup_module_1.run(set_0, variables=map_0)
    str_0 = 'test_var'
    lookup_module_2.run([str_0], variables=map_0)
    lookup_module_1.run([str_0], variables=map_0)
    lookup_

# Generated at 2022-06-25 11:54:01.337253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\nParameter 'terms'")
    print("Calling run without parameter 'terms' raises exception")
    try:
        lookup_module_4 = LookupModule()
        lookup_module_4.run()
    except:
        pass
    print("\nParameter 'variables'")
    print("Calling run without parameter 'variables'")
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 11:54:08.760646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = set()
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    lookup_module_1 = lookup_module_0.run(var_0)
    assert isinstance(lookup_module_1, list)
    assert len(lookup_module_1) == 0
    var_1 = []
    bool_1 = False
    lookup_module_2 = LookupModule(bool_1)
    lookup_module_3 = lookup_module_2.run(var_1)
    assert isinstance(lookup_module_3, list)
    assert len(lookup_module_3) == 0
    var_2 = []
    list_0 = []
    lookup_module_4 = LookupModule(list_0)
    lookup_module_5 = lookup_module

# Generated at 2022-06-25 11:54:10.544654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 11:55:18.157705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)
    bool_1 = False
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    set_1 = set()
    str_0 = 'octal'
    str_1 = 'numeric_value'
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    int_0 = 128
    int_1 = 9

# Generated at 2022-06-25 11:55:21.591819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)
    assert isinstance(var_0, list) == True


# Generated at 2022-06-25 11:55:28.896256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    dict_0 = dict()
    set_0 = {'terms', 'variables'}
    bool_0 = False
    lookup_module_1.run(set_0, dict_0, direct=bool_0)

# Generated at 2022-06-25 11:55:32.862130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_value = None
    lookup_module_3 = LookupModule(test_value)
    set_1 = set()
    bool_1 = False
    lookup_module_4 = LookupModule(bool_1)
    var_1 = lookup_module_4.run(set_1)
    var_1 = lookup_module_3.run(set_1)


# Generated at 2022-06-25 11:55:36.647636
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)

# Generated at 2022-06-25 11:55:42.207625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  set_0 = set()
  dict_0 = {"a": "b"}
  dict_1 = {"b": 1}
  dict_0.update(dict_1)
  lookup_module_0 = LookupModule(dict_0)
  set_0.add("a")
  set_0.add("b")
  dict_0 = {"a": "b"}
  dict_1 = {"b": 1}
  dict_0.update(dict_1)
  var_0 = lookup_module_0.run(set_0, dict_0)
  assert var_0 == ['b', '1']

# Generated at 2022-06-25 11:55:48.802494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = None
    lookup_module_4 = LookupModule(lookup_module_3)
    var_1 = {'ansible_play_batch': '0', 'ansible_play_hosts_all': '192.168.56.101', 'ansible_play_hosts': '192.168.56.101'}
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    var_2 = lookup_module_4.run(terms_0, var_1)


# Generated at 2022-06-25 11:55:55.387455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_0 = lookup_module_2.run(set_0)

    assert isinstance(lookup_module_2, LookupModule)
    assert isinstance(lookup_module_1, LookupModule)
    assert var_0 == []


# Generated at 2022-06-25 11:55:57.859874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    set_0 = set()
    bool_0 = False
    lookup_module_2 = LookupModule(bool_0)
    var_1 = lookup_module_2.run(set_0)



# Generated at 2022-06-25 11:56:06.801699
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  terms_0 = None
  variables_0 = None
  lkp_0 = LookupModule(terms_0)
  lkp_0.run(variables_0)
  terms_1 = "test_string"
  variables_1 = "test_string"
  lkp_1 = LookupModule(terms_1)
  lkp_1.run(variables_1)


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()