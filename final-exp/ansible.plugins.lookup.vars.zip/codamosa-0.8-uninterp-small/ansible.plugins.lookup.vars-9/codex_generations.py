

# Generated at 2022-06-25 11:48:06.381494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    terms_0 = None
    variables_0 = None
    kwargs_0 = {'a_0': 'a_0', 'default_0': 'default_0'}
    ret_0 = lookup_module_1.run(terms_0, variables_0, **kwargs_0)
    assert ret_0 is None


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:48:12.410539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define vars used in tests
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_batch': 'localhost', 'ansible_play_hosts': ['localhost'], 'ansible_play_hosts_all': ['localhost']}

    module_0 = LookupModule(None);
    assert module_0.run(terms, variables) != None

# Generated at 2022-06-25 11:48:13.545958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-25 11:48:15.425178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:48:18.893520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(lookup_module_0)


# Generated at 2022-06-25 11:48:27.404563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    terms_2 = list()
    test_of_ansible_error_3 = False
    try:
        lookup_module_1.run(terms_2)
    except AnsibleError as e_4:
        test_of_ansible_error_3 = True

    assert test_of_ansible_error_3
    test_of_ansible_error_5 = False
    try:
        lookup_module_1.run(terms_2)
    except AnsibleError as e_6:
        test_of_ansible_error_5 = True

    assert test_of_ansible_error_5


# Generated at 2022-06-25 11:48:30.325655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = []
    test_variables = None
    test_kwargs = {}
    lookup_module_0 = None
    lookup_module_1 = LookupModule(lookup_module_0)
    test_return = lookup_module_1.run(test_terms, test_variables, **test_kwargs)
    assert(None == test_return)


# Generated at 2022-06-25 11:48:34.966625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule('')
    lookup_module_3._templar._available_variables = dict()
    terms_4 = ['']
    variables_5 = None
    kwargs_6 = dict()
    value_of_retval_7 = lookup_module_3.run(terms_4, variables_5, **kwargs_6)
    assert value_of_retval_7 == ['']

# Generated at 2022-06-25 11:48:39.450640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = None
    terms_2 = None
    variables_3 = None
    assert LookupModule.run(lookup_module_1, terms_2, variables_3) == None


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:48:45.446192
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = None
        lookup_module_1 = LookupModule(lookup_module_0)
        terms = []
        variables = {}
        kwargs = {}
        lookup_module_1.run(terms, variables, **kwargs)
    except TypeError as e:
        print("unittest.mock.patch.object: test_LookupModule_run: TypeError")
        assert e.__class__ is TypeError


# Generated at 2022-06-25 11:48:58.713919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = "templar"
    lookup_module_0._templar._available_variables = dict()
    lookup_module_0._templar._available_variables['hostvars'] = dict()
    lookup_module_0._templar._available_variables['hostvars']['inventory_hostname'] = dict()
    terms = ['term']
    variables = None
    kwargs = dict()
    kwargs['var_options'] = variables
    kwargs['direct'] = kwargs
    assert lookup_module_0.run(terms, variables, **kwargs) == ["value"]


# Generated at 2022-06-25 11:49:09.406734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(hostvars={}, jinja2_native=False, var_templar=None, var_options={}, direct={}, all_vars={},
                              run_once=False, _fact_cache=None, _animmated=False, _connection=None, _task=None, _play_context=None,
                              runner_cache=None, _inject=None, runner_cache_enabled=False, connection_loader=None, loader=None,
                              templar=None, fail_on_undefined=True)

# Generated at 2022-06-25 11:49:16.285187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars = {
        'foo': 'bar'
    }
    module_name = 'builtin_module'
    hack_attributes = {'run':['myvars']}
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    for key in hack_attributes['run']:
        setattr(lookup_module, key, locals()[key])
    assert lookup_module.run(terms=['foo'], variables=None, **{}) == ['bar']
    return

# Generated at 2022-06-25 11:49:28.031355
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test_case
    test_case = {
        'default': None,
        'kwargs': {},
        'terms': [
            'ansible_play_hosts',
            'ansible_play_batch',
            'ansible_play_hosts_all'
        ],
        'variables': {
            'ansible_play_hosts': [
                '127.0.0.1'
            ],
            'ansible_play_batch': [
                '127.0.0.1'
            ],
            'ansible_play_hosts_all': [
                '127.0.0.1'
            ]
        }
    }

    # Test the run method of class LookupModule
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:49:33.084835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [unicode('variablename')]
    variables = {u'variablename': u'hello','myvar': 'ename'}
    result = lookup_module_0.run(terms, variables)
    assert result == ['hello']


# Generated at 2022-06-25 11:49:40.018975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = object()
    lookup_module._templar._available_variables = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'ansible_play_hosts': ['localhost_0'], 'ansible_play_batch': ['localhost_0', 'localhost_1'], 'ansible_play_hosts_all': ['localhost_0', 'localhost_1']}}}
    lookup_module.run(terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables = None, **{})
    lookup_module._templar = object()

# Generated at 2022-06-25 11:49:51.465733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(templar=None)
    lookup_module._templar = 'templar'
    lookup_module._templar.set_available_variables(dict())
    lookup_module._templar.available_variables = dict()
    lookup_module._templar._available_variables = dict()
    lookup_module._templar._available_variables = dict()
    lookup_module._templar.template = lambda x, y: x
    lookup_module._templar = 'templar'
    lookup_module._templar.set_available_variables(dict())
    lookup_module._templar.available_variables = dict()
    lookup_module._templar._available_variables = dict()
    lookup

# Generated at 2022-06-25 11:49:55.865864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    check_value_1 = ['test']
    # a list of all arguments for the class instance
    args = ['test',None,{}]
    # check to see if the expected outcome equals the return value of the method run
    assert(check_value_1 == lookup_module_1.run(*args))



# Generated at 2022-06-25 11:49:57.623280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_module_0.run(terms=['variablename'])
    assert result == ['hello']


# Generated at 2022-06-25 11:50:01.252760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([],{'inventory_hostname':'test','hostvars':{'test':{'term':'mock_value_0'}}}), 'Expected: \n Actual: \n{}'.format(lookup_module.run([],{'inventory_hostname':'test','hostvars':{'test':{'term':'mock_value_0'}}}))

# Generated at 2022-06-25 11:50:10.892460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\nTesting run of LookupModule...")

    terms = "test_variable"
    result = lookup_module_0.run(terms)
    assert result[0] == "test_value"

    print("Successful")


# Generated at 2022-06-25 11:50:20.756399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test_case_0
    myvars = {'ansible_play_hosts':'zabbix.localdomain', 'ansible_play_batch':'0', 'ansible_play_hosts_all':'zabbix.localdomain'}
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lookup_module_0.set_options(var_options=myvars, direct={})
    default = lookup_module_0.get_option('default')

    ret = []

# Generated at 2022-06-25 11:50:31.433300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'var1'
    variables = dict()
    kwargs = dict()
    kwargs['_ansible_check_mode'] = False
    kwargs['_ansible_debug'] = False
    kwargs['_ansible_diff'] = False
    kwargs['_ansible_keep_remote_files'] = False
    kwargs['_ansible_no_log'] = False
    kwargs['_ansible_remote_tmp'] = '~/.ansible/tmp'
    kwargs['_ansible_selinux_special_fs'] = ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p']
    kwargs['_ansible_shell_executable'] = '/bin/sh'
    kw

# Generated at 2022-06-25 11:50:38.416132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test with valid inputs
    lookup_module_0 = LookupModule()
    out = lookup_module_0.run(['hostvars', 'hostvars'])
    assert type(out) is list
    assert out == []

    # test with invalid inputs
    lookup_module_0 = LookupModule()
    try:
        out = lookup_module_0.run(None)
    except Exception as e:
        assert 'Invalid setting identifier' in str(e)

# Generated at 2022-06-25 11:50:40.879928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['terms_0', 'terms_0', 'terms_0'])



# Generated at 2022-06-25 11:50:49.369553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader(False)
    lookup_module_1.set_basedir('/tmp')
    terms_2 = ['hello']
    variables_2 = {'inventory_dir': '/ansible/inventory', 'role_names': [], 'inventory_file': '/ansible/inventory/dynamic_inventory.yml', 'private_key_file': ['/etc/ansible/ssh_keys/id_rsa'], 'inventory_hostname': '127.0.0.1', 'group_names': ['all'], 'playbook_dir': '/ansible/playbooks'}
    myvars_2 = {}

# Generated at 2022-06-25 11:51:00.425038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class LookupModule
    lookup_module = LookupModule()

    # Create mock for method _flatten_hash of class LookupBase
    def mock__flatten_hash(self, terms, **kwargs):
        return ['test_terms', 'test_terms_1']
    lookup_module._flatten_hash = mock__flatten_hash

    # Create mock for method _templar of class LookupBase
    class MockTemplar:
        def __init__(self):
            pass
        def __enter__(self):
            pass
        def __exit__(self, exc_type, exc_val, exc_tb):
            pass
        def _get_attributes(self, obj):
            return ['test_attribute', 'test_attribute_1']

# Generated at 2022-06-25 11:51:04.504092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        assert lookup_module_1._templar
    except Exception as e:
        print ("Exception at line 42")
        raise
    assert lookup_module_1.run(terms=None, variables=None) == None


# Generated at 2022-06-25 11:51:13.010856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == []
    assert lookup_module_0.run(terms_0, variables_0) == []
    assert lookup_module_0.run(terms_0, variables_0) == []
    assert lookup_module_0.run(terms_0, variables_0) == []

# Generated at 2022-06-25 11:51:21.476033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    values    = ['test_value_0', 'test_value_1']
    expected  = ['test_value_0', 'test_value_1']
    terms     = [values[0], values[1]]
    variables = {'test_key_0': values[0], 'test_key_1': values[1]}

    # Lookup module instance
    lookup_module_0 = LookupModule()

    # Test 'run' method
    ret = lookup_module_0.run(terms, variables)
    assert(ret == expected)



# Generated at 2022-06-25 11:51:41.532148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['hostvars']) is None
    assert lookup_module_0.run(terms=['inventory_hostname']) is None
    assert lookup_module_0.run(terms=['inventory_dir']) is None
    assert lookup_module_0.run(terms=['inventory_dir']) is None


# Generated at 2022-06-25 11:51:48.751211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # ansible-2.5/lib/ansible/plugins/lookup/test1.py
    lookup = LookupModule()

    # test with single undefined var
    terms = ['not_existing_var']
    ret = lookup.run(terms)
    assert ret == []

    # test with multiple defined vars
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    vars = {'ansible_play_hosts': 'localhost',
            'ansible_play_batch': 'localhost',
            'ansible_play_hosts_all': 'localhost'}
    ret = lookup.run(terms, vars)
    assert ret == ['localhost', 'localhost', 'localhost']

    # test with single nested var under hostvars

# Generated at 2022-06-25 11:51:58.693950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(MagicMock())
    lookup_module_0._connected_to_master = MagicMock(return_value=False)
    lookup_module_0._templar = MagicMock()
    lookup_module_0._templar.template.return_value = '15'
    lookup_module_0._templar.available_variables = {'fact_a': '3', 'fact_b': '5', 'fact_c': '7'}
    lookup_module_0._templar.set_available_variables.return_value = '15'
    lookup_module_0._templar._init_vars = MagicMock()

# Generated at 2022-06-25 11:52:06.242061
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = ['variabl' + 'name']
    default = None
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['hello']


# Generated at 2022-06-25 11:52:11.829611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['this_is_a_' + 'test']
    test_variables = {'hostvars': '', 'this_is_a_test': 'hello'}
    lookup_module_1 = LookupModule()
    lookup_module_1.run(test_terms, test_variables)

# Generated at 2022-06-25 11:52:19.530861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test run() with a simple nested structure
    test_var = {'nested': {'var': 'value'}}
    assert lookup_module_0.run(terms=['nested'], variables=test_var) == ['{u\'var\': u\'value\'}']
    # Test run() with a simple nested structure
    assert lookup_module_0.run(terms=['nested.var'], variables=test_var) == [u'value']
    # Test run() with a simple dict structure
    test_var = {'key': 'value'}
    assert lookup_module_0.run(terms=['key'], variables=test_var) == [u'value']
    # Test run() with alternative variable structure

# Generated at 2022-06-25 11:52:28.150640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization of class LookupModule with parameters
    lookup_module_0 = LookupModule()
    # Initialization of parameters
    terms_0 = [u'variablename']
    variables_0 = {u'vars': {u'variablename': 'hello', u'myvar': 'ename'}}
    # Call to method run of class LookupModule
    lookup_module_0.run(terms_0, variables_0)


# Generated at 2022-06-25 11:52:38.923347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]

    variables_0 = {
        'ansible_play_batch': 22,
        'ansible_play_hosts': [
            'host0',
            'host1',
        ],
        'ansible_play_hosts_all': [
            'host0',
            'host1',
        ],
    }

    kwargs_0 = {
        'var_options': variables_0,
        'direct': {
        },
    }

    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:52:41.198312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms=terms, variables=variables, **kwargs) == ret


# Generated at 2022-06-25 11:52:48.858283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [{'ansible_play_batch': ['vars1', 'vars2']}, 'ansible_play_hosts_all']
    variables = 'test_variables'
    ret = lookup_module.run(terms, variables, default='default')
    assert ret == ["vars1", "vars2", "vars1", "vars2"]


# Generated at 2022-06-25 11:53:19.835675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms = '', variables = None, default = None)


# Generated at 2022-06-25 11:53:23.893241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    myvars = {}
    lookup_module_0._templar._available_variables = myvars
    terms = [
            'term_0',
            'term_1',
            'term_2',
            ]
    variables = myvars
    try:
        lookup_module_0.run(terms, variables)
    except AnsibleUndefinedVariable:
        pass


# Generated at 2022-06-25 11:53:30.328572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_args_0 = ['foo', 'bar', 'baz']
    test_kwargs_0 = {'default': None}
    ret_val_0 = lookup_module_0.run(test_args_0, **test_kwargs_0)
    assert type(ret_val_0) == tuple
    assert ret_val_0 == ()


# Generated at 2022-06-25 11:53:36.770260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = dict()
    lookup_module._templar._available_variables = dict()
    lookup_module._templar._available_variables['hostvars']={}
    lookup_module._templar._available_variables['hostvars']['localhost']={}
    lookup_module._templar._available_variables['hostvars']['localhost']['a']="a"
    lookup_module._templar._available_variables['a']="b"
    lookup_module._templar._available_variables['ansible_play_hosts']=["localhost"]
    lookup_module._templar._available_variables['ansible_play_batch']=None
    lookup_module._templar._available_variables

# Generated at 2022-06-25 11:53:39.035592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = ['']
    variables = ''
    assert(lookup_module_0.run(term, variables) == [])


# Generated at 2022-06-25 11:53:42.837388
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lookup_module_0.run(terms=terms_0)

# Generated at 2022-06-25 11:53:47.216782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(["variablename"], {'variablename': 'hello'})
    lookup_module.run(["variablename"], {'variablename': 'hello', 'inventory_hostname': 'hello'})

# Generated at 2022-06-25 11:53:54.749376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    import pytest
    with pytest.raises(AnsibleError):
        lookup_module_0.run([None, ])

    class MockTemplar:

        def __init__(self, available_variables, ):
            self._available_variables = available_variables

        def set_available_variables(self, variables,):
            self._available_variables = variables

        def template(self, value, fail_on_undefined=True,):
            return value

    available_variables = {'myvar': 'ename', 'variablename': 'hello', }
    templar_0 = MockTemplar(available_variables)
    terms_0 = ['variabl' + templar_0._available_variables.get('myvar'), ]


# Generated at 2022-06-25 11:54:01.553000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars_list_0 = []
    terms_1 = []
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_1=terms_1, variables=vars_list_0, **kwargs_0)
    # assert


# Generated at 2022-06-25 11:54:08.895560
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = []
    variables = {}
    kwargs = {}

    # Setting vars of object lookup_module_0 of class LookupModule
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = {
        "_available_variables": {
            "variablename": "hello",
            "hostvars": {
                "inventory_hostname": {
                    "variablename": "world"
                }
            },
            "myvar": "ename"
        }
    }
    lookup_module_0.safe_args = []
    lookup_module_0._options = {}
    lookup_module_0._task_vars = {}
    lookup_module_0._templar._available_variables = {}
    lookup_module_0.safe_args = None
   

# Generated at 2022-06-25 11:55:19.561122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_option = MagicMock()
    lookup_module_0.get_option.return_value = None
    lookup_module_0._templar = MagicMock()
    lookup_module_0._templar.template = MagicMock()
    lookup_module_0._templar.template.return_value = 'hello'
    lookup_module_0._templar._available_variables = {'variabl': 'hello world'}
    assert lookup_module_0.run(['variabl']) == ['hello']


# Generated at 2022-06-25 11:55:29.226452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['variabl' + 'myvar']
    variables_0 = {}
    variables_0['variablename'] = 'hello'
    variables_0['myvar'] = 'ename'
    default_0 = None
    var_options_0 = variables_0
    direct_0 = {}
    direct_0['default'] = default_0
    lookup_module_0.set_options(var_options=var_options_0, direct=direct_0)
    assert lookup_module_0.run(terms_0, variables=variables_0) == ['hello']

# Generated at 2022-06-25 11:55:33.432587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_terms_0 = []
    var_variables_0 = {}
    var_default_0 = None
    ret_value_0 = lookup_module_1.run(var_terms_0, var_variables_0, default=var_default_0)
    assert ret_value_0 == []


# Generated at 2022-06-25 11:55:38.563280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ['ansible_play_hosts']
    __kwargs_2 = {
        'inventory_hostname': 'host1'
    }
    __kwargs_3 = {}
    __args_4 = ( terms_1, __kwargs_2, __kwargs_3 )
    try:
        value = lookup_module_0.run(*__args_4)
        assert False
    except Exception:
        pass

# Generated at 2022-06-25 11:55:40.811600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = {'var1':'val1', 'var2':'val2'}
    result = lookup.run(terms=terms, variables=None, **{})

# Generated at 2022-06-25 11:55:46.710915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=["variablename"]) == ["hello"]
    assert lookup_module_0.run(terms=["variablename"]) == ["hello"]
    assert lookup_module_0.run(terms=["variablename"]) == ["hello"]

# Generated at 2022-06-25 11:55:57.454662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar = MockTemplar()
    lookup_module_1._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module_1.run(["'variabl' + myvar"]) == ['hello']
    assert lookup_module_1.run(["'variabl' + myvar"], default='') == ['hello']
    lookup_module_1._templar._available_variables = {'variablename': 'hello', 'myvar': 'notename'}
    assert lookup_module_1.run(["'variabl' + myvar"], default='') == ['']

# Generated at 2022-06-25 11:56:05.523479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]
    variables = {"ansible_play_hosts": "localhost", "ansible_play_batch": "1 of 2", "ansible_play_hosts_all": "localhost"}
    assert(lookup_module_0.run(terms, variables) == ["localhost", "1 of 2", "localhost"])

# Generated at 2022-06-25 11:56:12.092646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['term1','term2',3]
    variables = {'v1':1, 'v2':2}
    kwargs = {'kwarg1':1,'kwarg2':2}
    lookup_module = LookupModule()
    lookup_module.run(terms=terms,variables=variables,**kwargs)

# Generated at 2022-06-25 11:56:22.522256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['my_var'], {'my_var': 'my_value'}) == ['my_value'], \
        "lookup_module_1.run(['my_var'], {'my_var': 'my_value'}) failed"
    assert lookup_module_1.run(['my_var'], {'hostvars': {'all': {'my_var': 'my_value'}}}) == ['my_value'], \
        "lookup_module_1.run(['my_var'], {'hostvars': {'all': {'my_var': 'my_value'}}}) failed"