

# Generated at 2022-06-25 11:48:07.957451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_' + item for item in ('hosts', 'batch', 'hosts_all')]
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:48:09.414240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True

# Generated at 2022-06-25 11:48:11.353031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 11:48:19.785695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a first simple case
    terms = ['variablename']
    variables = {
        'variablename': 'hello',
        'myvar': 'ename'
    }
    assert lookup_module_0.run(terms, variables=variables) == ['hello']

    # Test with error raised
    terms = ['variablename']
    variables = {
        'variablename': 'hello',
        'myvar': 'notename'
    }
    assert lookup_module_0.run(terms, variables=variables) == ''

# Generated at 2022-06-25 11:48:28.737395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}
    lookup_module_0.lab_var_0 = {}

# Generated at 2022-06-25 11:48:33.354776
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms='sample_terms', variables='sample_variables') == 'sample_result'


# Generated at 2022-06-25 11:48:45.244445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables={'variablename': 'hello', 'myvar': 'ename'}
    ansible_options={'forks': 10, 'remote_user': 'run', 'ask_pass': True, 'private_key_file': None, 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become': False, 'become_method': 'sudo', 'become_user': None, 'ask_value_pass': False, 'verbosity': 5, 'check': False, 'listhosts': None, 'listtasks': None, 'listtags': None, 'syntax': None, 'module_path': None, 'diff': False}
    ret = lookup

# Generated at 2022-06-25 11:48:52.080203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Test with
    # lookup_module_1.run(terms, variables=None, **kwargs)
    # TODO: Implement your test here
    assert True # TODO: implement your test here

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()
    print("Unit Test DONE")

# Generated at 2022-06-25 11:49:01.226864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    dict_terms = dict()
    dict_terms['term1'] = "value_term1"
    dict_terms['term2'] = "value_term2"
    dict_terms['term3'] = "value_term3"
    dict_terms['term4'] = "value_term4"
    list_terms = ['term1','term2','term3','term4']
    dict_kwargs = dict()
    dict_kwargs['kwarg1'] = "value_kwarg1"
    dict_kwargs['kwarg2'] = "value_kwarg2"
    dict_kwargs['kwarg3'] = "value_kwarg3"
    dict_kwargs['kwarg4'] = "value_kwarg4"
    dict_variables = dict()

# Generated at 2022-06-25 11:49:07.605599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    myvars = None
    terms = []
    ret = lookup_module_0.run(terms, myvars)
    assert ret == [], "Test 1 of method run of class LookupModule failed"


# Generated at 2022-06-25 11:49:16.827579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {}
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=['term'], variables=vars)


# Generated at 2022-06-25 11:49:21.920597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    hostvars_list = [dict()]
    terms_list = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'inventory_hostname': '192.168.56.12', 'hostvars': {'192.168.56.12': {'ansible_play_batch': [['192.168.56.12'], ['192.168.56.12'], ['192.168.56.12'], ['192.168.56.12'], ['192.168.56.12']], 'ansible_play_hosts_all': ['192.168.56.12'], 'ansible_play_hosts': ['192.168.56.12']}}}

# Generated at 2022-06-25 11:49:24.370437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'variablename'
    variables_0 = None
    kwargs_0 = dict()
    kwargs_0['default'] = None
    result = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == 'hello'

# Generated at 2022-06-25 11:49:26.125308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(lookup_module_0.run(terms = "no_error"), list)


# Generated at 2022-06-25 11:49:34.567864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:49:45.227289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars1 = dict()
    vars1['ansible_play_hosts'] = '1'
    vars1['ansible_play_batch'] = '2'
    vars1['ansible_play_hosts_all'] = '3'
    terms1 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    # Commenting out as it is not needed anymore
    # ret1 = lookup_module_0.run(terms=terms1, variables=vars1)
    # assert ret1 == [1, 2, 3]

    vars2 = dict()
    vars2['variablename'] = 'hello'
    vars2['myvar'] = 'notename'

# Generated at 2022-06-25 11:49:45.786183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:49:51.462203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms=None, variables=None, **{})
    except Exception as exception:
        print (exception)
        #assert type(exception) == Exception


# Generated at 2022-06-25 11:49:53.834004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    vars = [{'test_var': 'test_value'}]
    terms = ['test_var']
    result = lookup_module_0.run(terms, variables=vars)
    assert result == ['test_value']


# Generated at 2022-06-25 11:50:01.663001
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=dict(), direct=dict())
    lookup_module_0.set_loader()
    lookup_module_0.set_templar()
    lookup_module_0.run('ansible_play_hosts')
    lookup_module_0.run('ansible_play_batch')
    lookup_module_0.run('ansible_play_hosts_all')
    lookup_module_0.run('ansible_play_hosts', variables=dict())
    lookup_module_0.run('ansible_play_batch', variables=dict())
    lookup_module_0.run('ansible_play_hosts_all', variables=dict())

# Generated at 2022-06-25 11:50:11.633568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x07\xf2\x11\x19\x0e\x97\xaa\xb1\xebS\x03\xb3\x90'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)


# Generated at 2022-06-25 11:50:14.777099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x9a\xd7N\xad\x19\xce#\xb8'
    dict_0 = {}
    var_0 = lookup_module_0.run(bytes_0, **dict_0)
    return var_0

# Generated at 2022-06-25 11:50:19.872129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)
    assert var_0 == None



if __name__ ==  '__main__':
    test_LookupModule()

# Generated at 2022-06-25 11:50:24.409885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)


# Generated at 2022-06-25 11:50:35.787347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_0 = b'w\x82\xed\xfc\xb2+\n\t\xe9\xd8\xcf\x1da\xb2\x12\x8a\xbb\xdd\xc9\x07\xbb'
    bytes_1 = b'\x1d'
    bytes_2 = b'\x7f\t\x96\xa8\x12T'
    bytes_3 = b'!'
    bytes_list_0 = [bytes_0, bytes_1, bytes_2, bytes_3]
    dict_0 = {}
    var_0 = lookup_module_1.run(bytes_list_0, **dict_0)

# Generated at 2022-06-25 11:50:39.383882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    words_0 = ['hello']
    dict_0 = {}
    var_0 = lookup_module_0.run(words_0, **dict_0)
    assert var_0 == ['hello']

# Test for case 0 of function run of class LookupModule

# Generated at 2022-06-25 11:50:40.397963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:50:47.823241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm_0 = LookupModule()
    bytes_0 = b'\x08\xd3\xa7\x06\xd4\xdb\x98\xa8\xc6\xbe\xfd\x0c;\x8a'
    bytes_1 = b'm\xb9\x11\xe2\x1b\x08\x0b\xca\x9a\x94\x06'
    bytes_2 = b'M\xee'
    bytes_3 = b'\x9d\xab\x87\x02\xd8\x06\xb2\x0f\x91\xdc\x9c\x0b'

# Generated at 2022-06-25 11:50:58.008618
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:51:06.582715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_ = {}
    dict_['inventory_hostname'] = 'inventory_hostname_0'
    dict_['hostvars'] = {}
    dict_0 = dict_['hostvars']
    dict_1 = {}
    dict_0['inventory_hostname_0'] = dict_1
    list_ = ['list_0', 'list_1', 'list_2']
    dict_1['list_1'] = 1
    dict_1['list_2'] = 2
    dict_1['list_0'] = 0
    dict_1['a'] = 'a'
    dict_1['b'] = 'b'
    var_ = lookup_run(list_[2], list_[1], **dict_)
    assert var_ == [2]
    var

# Generated at 2022-06-25 11:51:27.811404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Implement me
    myvars = getattr(self._templar, '_available_variables', {})
    ret = []
    for term in terms:
        if not isinstance(term, string_types):
            raise AnsibleError('Invalid setting identifier, "%s" is not a string, its a %s' % (term, type(term)))

# Generated at 2022-06-25 11:51:32.656954
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    bytes_0 = b'\xffqY\xdd\xae\x84\x9d\xee'
    bytes_1 = b'<\x1e\xdc\xcb\xb5\xd6\x9b'
    dict_0 = {}
    str_0 = lookup_module_0.run(bytes_0, bytes_1, **dict_0)

    assert str_0 == 'No variable found with this name: jdfgkjerfg'



# Generated at 2022-06-25 11:51:40.461644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    dict_0 = {}
    # value of bytes_0

# Generated at 2022-06-25 11:51:46.952462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
  dict_0 = {}
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(bytes_0, **dict_0)


# Generated at 2022-06-25 11:51:49.315817
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    assert lookup_module_0.run([]) == [], "test #0 failed"



# Generated at 2022-06-25 11:51:54.292788
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Run the method
    result = lookup_module_0.run(terms, variables=None, **kwargs)

    assert result == expected_result

# Generated at 2022-06-25 11:52:03.428755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = {"0": {}, "1": "E!\x0cj\x1b\x1d\x0a\x88\x0c"}
    var_1 = {"0": "LI\x88\x1a\xbb\x1d\xf4}T\xec\x9a\xbf\x89", "1": "\xad!\x07\xbb\xef\x18\xbc\x9d\x1a\xc78\xf5"}

# Generated at 2022-06-25 11:52:10.922537
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:52:19.440948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)
    bytes_1 = b'\x9e\x08\xa1\xd0\xa2\xbe\xdbh\x87'
    dict_1 = {}
    var_1 = lookup_module_0.run(bytes_1, **dict_1)

# Generated at 2022-06-25 11:52:27.136238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)
    assert private_var_0 == var_0


# Generated at 2022-06-25 11:52:57.383131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x14\xbe\xd8\x1d\xab\xe4\xed\xbd'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)


# Generated at 2022-06-25 11:53:06.678097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms_1 = list()
    terms_1.append(b'variablename')
    terms_1.append(b'variablenotename')
    dict_0 = {}
    dict_0['variablename'] = b'hello'
    dict_0['myvar'] = b'ename'
    variables_1 = dict_0
    dict_1 = {}
    dict_1['variables'] = variables_1
    dict_1['default'] = b''
    dict_1['_terms'] = terms_1
    dict_1['ignore_errors'] = True
    lookup_run(terms_1, variables_1, **dict_1)

# Generated at 2022-06-25 11:53:12.194617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_1 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_1 = {}
    var_1 = lookup_module_1.run(bytes_1, bytes_1, **dict_1)

    return


# Generated at 2022-06-25 11:53:23.144432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = unicode('2\xc3\x02\xc3\x02', 'iso-8859-1')
    bytes_0 = b'\xb3\x1aJ\xd5\x0b\x1c\x11\x81'
    dict_0 = {}
    var_0 = lookup_run(str_0, bytes_0, **dict_0)
    bytes_0 = b'f\xfb\t\xce\xc8\x85\x87\x93'
    var_1 = lookup_run(str_0, bytes_0, **dict_0)
    bytes_0 = b'\x11\xf1\xeb\x9b\xb6cy\xa6'

# Generated at 2022-06-25 11:53:29.837857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_1 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    list_0 = [bytes_1]
    dict_1 = {}
    var_1 = lookup_run(list_0, **dict_1)


# Generated at 2022-06-25 11:53:32.934601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)



# Generated at 2022-06-25 11:53:38.636691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.set_options(**lookup_module_0)
    lookup_module_0.set_options(**lookup_module_0)
    lookup_module_0.run(**lookup_module_0)
    lookup_module_0.run(**lookup_module_0)
    lookup_module_0.run(**lookup_module_0)

# Generated at 2022-06-25 11:53:43.380616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)
    print(var_0)


# Generated at 2022-06-25 11:53:44.306005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assert call(raw=, scope=)
    pass

# Generated at 2022-06-25 11:53:49.153650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all' ]
    variables = 'ansible_play_batch'
    test_instance = LookupModule()
    ret = test_instance.run( terms, variables )
    print( ret )


# Test case for method run of class LookupModule
# Alternate way to find some 'prefixed vars' in loop

# Generated at 2022-06-25 11:54:51.802243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    list_0 = list_of_strings_0
    dict_0 = {}
    var_0 = lookup_module_0.run(list_0, **dict_0)


# Generated at 2022-06-25 11:54:54.939210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)


# Generated at 2022-06-25 11:54:55.844166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == None



# Generated at 2022-06-25 11:54:59.329018
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Run method of class LookupModule
    lookup_run = getattr(LookupModule(), 'run')
    # Test for run passing
    assert not (test_case_0())


test_LookupModule_run()

# Generated at 2022-06-25 11:55:00.907819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['var']) is not None


# Generated at 2022-06-25 11:55:05.876826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\x1e\x8e'
    str_1 = '\x9c\xc5'
    dict_0 = {}
    var_0 = lookup_module_0.run(str_0, var_1 = str_1, **dict_0)


# Generated at 2022-06-25 11:55:12.977213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_option = test_LookupModule_get_option_default
    bytes_0 = b'X'
    list_0 = [bytes_0]
    dict_0 = {}
    lookup_module_0.run(list_0, **dict_0)


# Generated at 2022-06-25 11:55:18.222307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x8d\x81\x1f\x0e\xed\x9a\xc2\x0e\x04\x0c\x8e6\x10\x14\xc1\xc7'
    dict_0 = {}
    lookup_module_0.run(bytes_0, **dict_0)


# Generated at 2022-06-25 11:55:20.334547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_module_0.run(bytes_0, **dict_0)

# Generated at 2022-06-25 11:55:23.572012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'L\xed\x12\xfd\x1a\xe1+\x92'
    dict_0 = {}
    var_0 = lookup_run(bytes_0, bytes_0, **dict_0)

# Generated at 2022-06-25 11:57:46.798275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x83K\x8d\x19\x9a\xae'
    bytes_1 = b'\xc6\xd0\xa5\xb8\xaf\xe1\x1b\xec\x8e\xef\x01\x93\xd5\x04\xac\xdc\xfa\xed\x8a?\xbe\x07\x90\x1a'
    dict_0 = {}

# Generated at 2022-06-25 11:57:56.695725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    # first arg is of type bytes, the second arg is of type bytes
    dict_0 = {}
    dict_0['var_0'] = "|`$|`"
    dict_0['var_1'] = bytes('var_2', 'UTF-8')
    dict_0['var_3'] = bytes('var_4', 'UTF-8')
    dict_0['var_5'] = "|`$|`"
    dict_0['var_6'] = "|`$|`"
    dict_0['var_7'] = bytes('var_8', 'UTF-8')
    dict_0['var_9'] = bytes('var_10', 'UTF-8')
    dict_0['var_11'] = "|`$|`"