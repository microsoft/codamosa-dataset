

# Generated at 2022-06-25 11:48:04.412629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 11:48:14.209278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['ansible_play_hosts_all'], variables={'hostvars': {'host_0': {'ansible_play_hosts_all': 'host_0'}, 'host_1': {'ansible_play_hosts_all': 'host_1'}, 'host_2': {'ansible_play_hosts_all': 'host_2'}}, 'inventory_hostname': 'host_0', 'ansible_play_hosts_all': ['host_0', 'host_1', 'host_2']})


# Generated at 2022-06-25 11:48:25.302413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar._available_variables = {}
    lookup_module_0._templar._available_variables['hostvars'] = {}
    lookup_module_0._templar._available_variables['inventory_hostname'] = ''
    term = ''
    variables = {}
    kwargs = {}

    # Case 1: exception test
    terms = ['ansible_play_batch']
    assert(lookup_module_0.run(terms, variables, **kwargs))

    # Case 2: exception test
    term = 'hostvars'
    assert(lookup_module_0.run([term], variables, **kwargs))

    # Case 3: exception test
    terms = ['inventory_hostname']

# Generated at 2022-06-25 11:48:30.452939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    myvars = {'hostvars': {'192.168.0.1': {'ansible_ssh_host': '192.168.0.1', 'ansible_ssh_port': 22}},
              'inventory_hostname': '192.168.0.1'}
    assert type(lookup_module_1.run('ansible_ssh_host', variables = myvars)) is list
    assert type(lookup_module_1.run('ansible_ssh_port', variables = myvars)) is list
    assert type(lookup_module_1.run('inventory_hostname', variables = myvars)) is list

# Generated at 2022-06-25 11:48:33.932764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["key_1", "key_2"]
    variables = {'key_1': 2}
    kwargs = {'default': "default_value"}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == [2, "default_value"]

# Generated at 2022-06-25 11:48:35.793513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:48:45.840241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with good args:
    try:
        lookup_module_0.run(terms=["ansible_play_hosts", "ansible_play_batch"], variables={"ansible_play_hosts": ["10.0.0.2", "10.0.0.3"], "ansible_play_batch": 10, "ansible_play_hosts_all": ["10.0.0.2", "10.0.0.3"]})
    except Exception:
        assert False

    # Test with bad args:

# Generated at 2022-06-25 11:48:51.298913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
     True,
     True]
    kwargs_0 = {
     'variables': True}
    assert lookup_module_0.run(terms_0, **kwargs_0)

# Generated at 2022-06-25 11:48:58.344574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:49:06.007109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    config = {
        'server': '127.0.0.1',
        'port': 5985,
        'user': None,
        'pass': None,
        'timeout': 10,
        'host': '127.0.0.1',
        'debug': False,
        'https_timeout': 10,
        'force_basic_auth': False,
        'lookup_timeout': 10
    }
    assert lookup_module_0._get_winrm_session(config=config) == {}

# Generated at 2022-06-25 11:49:12.060479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(["test"], ["test"])
    assert 'test' == var_0[0]

# Generated at 2022-06-25 11:49:19.348902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ('\n',)
    variables_0 = var_0 = {'\n': '\n', 'myvar': 'ename'}
    var_1 = lookup_module_0.run(terms_0, variables_0)
    assert_equal(var_1, ({}, ['\n'], [], [], 0, '\n'))
    default_0 = 0
    var_2 = lookup_module_0.run(terms_0, variables_0, default=default_0)
    assert_equal(var_2, ({}, ['\n'], [], [], 0, '\n'))
    var_3 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:49:30.798636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(str_0)
    var_2 = str_0
    var_3 = '!O}%c'
    var_4 = '!O}%c'
    var_5 = str_0
    var_6 = '!O}%c'
    var_7 = '!O}%c'
    var_8 = '!O}%c'
    var_9 = str_0
    var_10 = '!O}%c'
    var_11 = '!O}%c'    
    # test_0

# Generated at 2022-06-25 11:49:31.672135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert(helper_depends)

# Generated at 2022-06-25 11:49:34.381273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '=A]T`'
    lookup_module_1 = LookupModule()
    lookup_module_1.run(str_0)


# Generated at 2022-06-25 11:49:37.745682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!'
    lookup_module_1 = LookupModule()
    values_0 = lookup_module_1.run(str_0)
    str_1 = '_templar'
    private_0 = hasattr(lookup_module_0, str_1)


# Generated at 2022-06-25 11:49:39.355180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    str_0 = '!O}%c'
    var_0 = lookup_module.run(str_0)


# Generated at 2022-06-25 11:49:41.636387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'l?Z\'s'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)

if __name__ == '__main__':
    print('No unit test is implemented for %s' % __file__)

# Generated at 2022-06-25 11:49:51.699407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'fD)\'G'
    var_0 = lookup_module_0.run(str_0)
    str_0 = 'n;=}'
    var_1 = lookup_module_0.run(str_0)
    str_1 = 'G4uV:Q'
    var_2 = lookup_module_0.run(str_1)
    str_1 = '0k=Gs'
    var_3 = lookup_module_0.run(str_1)
    str_1 = '7\x17'
    var_4 = lookup_module_0.run(str_1)

# Generated at 2022-06-25 11:49:54.385969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)

# Generated at 2022-06-25 11:50:05.431441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)

# Generated at 2022-06-25 11:50:13.723264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '`=h-C{9Xp'
    str_1 = '8Y2=h(!lF'
    str_2 = '&QA'

# Generated at 2022-06-25 11:50:20.557308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:50:30.890269
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # self variable may depend on the current state of the variable _templar._available_variables, so it may change in
    # time
    lookup_module_0 = LookupModule()
    lookup_module_0._templar._available_variables = {'ansible_play_hosts': ['172.16.1.4'], 'ansible_play_batch': ['1'], 'ansible_play_hosts_all': ['172.16.1.4']}
    var_0 = lookup_module_0.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])
    assert var_0 == [['172.16.1.4'], ['1'], ['172.16.1.4']]

# Generated at 2022-06-25 11:50:32.437111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '!O}%c'
    test_case_0(var_0)

# Generated at 2022-06-25 11:50:38.415730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_0 = 'T'
    lookup_module_2.run(str_0)
    lookup_module_3 = LookupModule()
    str_0 = '~n,}{3'
    lookup_module_3.run(str_0)
    str_0 = '*'
    lookup_module_3.run(str_0)


# Generated at 2022-06-25 11:50:41.234819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)

# Generated at 2022-06-25 11:50:47.873004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "=G'D.X"
    lookup_module_1 = LookupModule()
    str_1 = 'jK%Mx'
    var_0 = lookup_module_1.run(str_1)
    lookup_module_2 = LookupModule()
    str_2 = 'f4Y*'
    var_1 = lookup_module_2.run(str_2)
    lookup_module_3 = LookupModule()
    str_3 = '(&^m'
    var_2 = lookup_module_3.run(str_3)
    lookup_module_4 = LookupModule()
    str_4 = 'RwDd'
    var_3 = lookup_module_4.run(str_4)
    lookup_module_

# Generated at 2022-06-25 11:50:51.599691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)

# Generated at 2022-06-25 11:50:54.689428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '&s[sH'
    lookup_module_1 = LookupModule()
    int_0 = lookup_module_1.run(str_0)

# Generated at 2022-06-25 11:51:10.403479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'y*'
    assert lookup_module_0.run(str_0) == None


# Generated at 2022-06-25 11:51:21.637161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {'variablename': 'hello',
            'myvar': 'ename',
            'ansible_play_hosts': 'hello',
            'ansible_play_batch': 'hello',
            'ansible_play_hosts_all': 'hello'}

    lookup_module_0 = LookupModule()
    str_0 = 'variablename'
    str_1 = 'variablenotename'
    str_2 = 'ansible_play_hosts'
    str_3 = 'ansible_play_batch'
    str_4 = 'ansible_play_hosts_all'
    str_5 = 'inventory_hostname'
    str_6 = 'hostvars'
    str_7 = 'variablnotename'
    str_8 = 'variablenotename'


# Generated at 2022-06-25 11:51:24.598241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run()

# Generated at 2022-06-25 11:51:30.622246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        #test 1
        lookup_module_0 = LookupModule()
        #str_0 = '!O}%c'
        lookup_module_1 = LookupModule()
        #var_0 = lookup_module_1.run(str_0)
        assert True
    except AssertionError as e:
        raise
    except IOError as e:
        raise
    except AnsibleUndefinedVariable as e:
        raise
    except TypeError as e:
        raise
    except AnsibleError as e:
        raise

# Generated at 2022-06-25 11:51:33.096795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if isinstance(getattr(lookup_module_0, '_templar', None), getattr(lookup_module_0._templar.__class__, '__class__', None)):
        test_case_0()
    if isinstance(getattr(lookup_module_0, '_templar', None), getattr(lookup_module_0._templar.__class__, '__class__', None)):
        test_case_0()

# Generated at 2022-06-25 11:51:44.285665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '=Z'
    lookup_module_0.run(str_0)
    lookup_module_1 = LookupModule()
    str_0 = 'n{/'
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(str_0)
    lookup_module_1.run(str_0, var_0)
    lookup_module_3 = LookupModule()
    var_0[lookup_module_3.get_option('a-v')] = str_0
    lookup_module_4 = LookupModule()
    str_0 = '={J#'
    lookup_module_5 = LookupModule()
    var_0 = lookup_module_5.run(str_0)
   

# Generated at 2022-06-25 11:51:46.691232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'S'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)


# Generated at 2022-06-25 11:51:56.657853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    str_0 = '!O}%c'
    var_0 = lookup_module_0.run(list_0)

    var_1 = lookup_module_0.run(str_0)

    lookup_module_1 = LookupModule()
    str_1 = 'Hm#!S'
    var_2 = lookup_module_1.run(str_1)

    lookup_module_2 = LookupModule()
    str_2 = '^<!Y'
    var_3 = lookup_module_2.run(str_2)

    lookup_module_3 = LookupModule()
    str_3 = 'O~5?5'
    var_4 = lookup_module_3.run(str_3)

    lookup_

# Generated at 2022-06-25 11:51:57.333345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == False



# Generated at 2022-06-25 11:52:00.126541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:52:31.035981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '5\x80I'
    lookup_module_1 = LookupModule()
    str_1 = '%'
    str_2 = '}@;&\x92'
    result_0 = lookup_module_1.run(str_0, str_1, str_2)
    result_1 = lookup_module_1.run(str_0, str_1, str_2)

# Generated at 2022-06-25 11:52:34.610402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run() == '!O}%c'

# Generated at 2022-06-25 11:52:40.650635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)


# Generated at 2022-06-25 11:52:47.083756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = "W8Rd>$aIY|"
    lookup_module._templar._available_variables = {"ansible_play_batch": "A'U<d6", "ansible_play_hosts": "4zd4YC4>", "ansible_play_hosts_all": "S<l[77Z'"}
    str_0 = "ansible_play_batch"
    str_1 = "ansible_play_hosts"
    str_2 = "ansible_play_hosts_all"
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_0, str_1, str_2)


# Generated at 2022-06-25 11:52:57.852389
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:53:07.688821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'cT<'
    dict_0 = dict()
    dict_0['a'] = dict()
    dict_0['a']['b'] = {}
    dict_0['a']['b']['c'] = 'd'
    dict_0['myvar'] = 'ENAME'
    dict_0['ITEM'] = 'a'
    dict_0['ansible_play_hosts'] = 'hosts'
    dict_0['ansible_play_batch'] = 'batch'
    dict_0['ansible_play_hosts_all'] = 'all'

# Generated at 2022-06-25 11:53:11.416815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = lookup_module_0.run('ansible')
    var_1 = lookup_module_0.run('ansible_play_hosts_all')
# -- end unit test --

# Generated at 2022-06-25 11:53:17.501668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['sudo_password', 'ansible_password', 'accelerate_port', 'accelerate_daemon_interval', 'accelerate_timeout', 'accelerate_connect_timeout'])

# Generated at 2022-06-25 11:53:21.042015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)


# Generated at 2022-06-25 11:53:27.875820
# Unit test for method run of class LookupModule
def test_LookupModule_run():


    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options='<module>')

    # Test if asserts are working
    lookup_module_0.run('!O}%c')


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:54:28.861621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'testing'
    lookup_module_1 = LookupModule()
    x = lookup_module_1.run(str_0)
    str_1 = '!O}%c'
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(str_1)
    str_2 = 'testing'
    lookup_module_3 = LookupModule()
    y = lookup_module_3.run(str_2)
    if (x != y):
        raise Exception('AssertionError')


# Generated at 2022-06-25 11:54:34.426366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '-H5&5'
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(str_0)
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    if var_0 == 'B\x7f':
        lookup_module_8.set_options(var_options={}, direct={})
        str_1 = '\x7f#'

# Generated at 2022-06-25 11:54:39.246603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = '?!N+'
    variables_0 = None
    kwargs_0 = { }
    lookup_module_0.run(term_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:54:39.953626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    test_case_0()

# Generated at 2022-06-25 11:54:42.729562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_1 = '!O}%c'
    lookup_module_3 = LookupModule()
    var_1 = lookup_module_3.run(str_1)

# Generated at 2022-06-25 11:54:45.846014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('', '')

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:54:57.982407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys

    # Define variable object
    lookup_module_0 = LookupModule()

    # Define variable array
    array_0 = []

    # Define variable str
    str_0 = 'app.title'

    # Define variable array
    array_1 = []

    # Define variable str
    str_1 = 'app.version'

    # Define variable array
    array_2 = []

    # Define variable str
    str_2 = 'app.date'

    # Define variable array
    array_3 = []

    # Define variable str
    str_3 = 'app.author'

    # Define variable array
    array_4 = []

    # Define variable str
    str_4 = 'app.company'

    # Define variable array

# Generated at 2022-06-25 11:54:58.837884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Basic unit test

# Generated at 2022-06-25 11:55:00.258703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(callable(LookupModule.run))

# Check that get_option works properly

# Generated at 2022-06-25 11:55:01.027838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:57:12.597322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7Fqga'
    lookup_module_0 = LookupModule()
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 11:57:22.275614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Variables initialisation
    str_0 = 'C,{\+-:z'
    dict_0 = dict()
    dict_0['default'] = 'default_value_1'
    dict_0['direct'] = 'direct_value_1'
    dict_0['var_options'] = 'var_options_value_1'
    dict_1 = dict()
    dict_1['default'] = 'default_value_2'
    dict_1['direct'] = 'direct_value_2'
    dict_1['var_options'] = 'var_options_value_2'
    list_0 = list()
    list_0.append('ansible_play_hosts')
    list_0.append('ansible_play_batch')
    list_0.append('ansible_play_hosts_all')


# Generated at 2022-06-25 11:57:28.141019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(None)

if __name__ == '__main__':
    import sys
    import os
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.parsing.convert_bool import BOOLEANS, boolean
    from ansible.module_utils.parsing.convert_bool import boolean
    import json

    sys.stdout = StringIO()
    args = ['-u', 'ansible', '-i', 'hosts', '-m', 'copy', '-a', 'src=hello dest=' + os.path.join(os.path.dirname(__file__), 'hellocopy') ]

# Generated at 2022-06-25 11:57:37.628082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '*'
    dict_0 = dict()
    dict_0['ansible_play_hosts'] = 'play_hosts'
    dict_0['ansible_play_batch'] = 'play_batch'
    dict_0['ansible_play_hosts_all'] = 'play_hosts_all'
    dict_0['myvar'] = 'myvar'
    dict_0['variablename'] = 'variablename'
    var_0 = lookup_module_0.run(str_0, dict_0)
    assert len(var_0)==1
    assert var_0==['*']
    lookup_module_1 = LookupModule()
    str_1 = 'ansible_play_'

# Generated at 2022-06-25 11:57:39.244140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_2 = LookupModule()
  str_1 = '!O}%c'
  lookup_module_2.run(str_1)


# Generated at 2022-06-25 11:57:44.962865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_1 = 'C!+,K|'
    str_2 = '{1zKU:l'
    lookup_module_2.run(str_1, str_2)


# Generated at 2022-06-25 11:57:51.053491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Call method run of lookup_module_0 with these parameters
    str_0 = '!O}%c'
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(str_0)

# Generated at 2022-06-25 11:57:54.132859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '$W'
    str_1 = 'w'
    test_case_0()


# Generated at 2022-06-25 11:58:00.824086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule with test set as it's module_utils.
    lookup_module_0 = LookupModule()
    # Create a variable with an initial value.
    var_0 = 'is empty'
    # Call method run of lookup_module_0 with var_0 and an empty list as arguments.
    # Assign the result to var_1.
    var_1 = lookup_module_0.run(var_0, [])
