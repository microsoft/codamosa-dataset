

# Generated at 2022-06-25 11:48:04.588403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test with multiple terms
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {}
    assert lookup_module_0.run(terms, variables=variables) == [None, None, None]



# Generated at 2022-06-25 11:48:07.938288
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    result = lookup_module_0.run('_terms', 'variables')

    assert(result == None)

# Generated at 2022-06-25 11:48:19.339047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(lookup_module_0.run(terms=[]), list) # check whether run of LookupModule returns a list
    assert len(lookup_module_0.run(terms=[]))==0 # check whether run of LookupModule returns a list of expected length

test_case_0()

test_LookupModule_run()

# Generated at 2022-06-25 11:48:28.415339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={u'defaults': {}, u'vars': {u'ansible_play_hosts': [u'localhost']}},
                                var_options={u'ansible_play_hosts': [u'localhost']})
    lookup_module_0.run([u'ansible_play_hosts'])
    lookup_module_0.set_options(direct={u'defaults': {}, u'vars': {u'ansible_play_hosts': [u'localhost']}})
    lookup_module_0.run([u'ansible_play_hosts'])

# Generated at 2022-06-25 11:48:30.242106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run()

# Generated at 2022-06-25 11:48:39.472017
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_instance = test_case_0()

    lookup_module_instance._templar._available_variables = {}
    lookup_module_instance._templar._available_variables['inventory_hostname'] = "test_host"
    lookup_module_instance._templar._available_variables['hostvars'] = {
        'test_host': {
            'test_var': "test_value"
        }
    }

    # Case 1
    # When term is single argument and matched with available_variables
    terms = 'test_var'

    result = lookup_module_instance.run(terms=terms)
    assert result == ['test_value']

    # Case 2
    # When term is list of arguments and matched with available_variables
    terms = ['test_var']

    result = lookup_

# Generated at 2022-06-25 11:48:43.954937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test variables
    lookup_module_1 = LookupModule()

    lookup_module_1.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], {'ansible_play_hosts':['192.168.1.1'], 'ansible_play_batch':[], 'ansible_play_hosts_all':['192.168.1.1']})

    lookup_module_1.run(['ansible_play_batch'], {'ansible_play_hosts':['192.168.1.1'], 'ansible_play_batch':[], 'ansible_play_hosts_all':['192.168.1.1']})


# Generated at 2022-06-25 11:48:49.132729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = ['key', '_key']
    kwargs_0 = {'default': None}
    kwargs_0.update({'wantlist': False})
    result = lookup_module_0.run(terms_0, **kwargs_0)
    assert result == [None, None]

# Generated at 2022-06-25 11:48:53.289350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=['_ansible_no_log'], direct=['_ansible_no_log'])
    lookup_module_0.run('_ansible_no_log')

# Generated at 2022-06-25 11:48:57.162249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["key_1"]
    variables = dict(key_1="value_1")
    assert lookup_module.run(terms, variables=variables) == ["value_1"]


# Generated at 2022-06-25 11:49:12.923136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({'_terms': ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], 'default': 'None'})
    assert lookup_module.run([], {}) == ['None', 'None']
    lookup_module.set_options({'_terms': ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], 'default': 'None'})
    assert lookup_module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], {}) == ['None', 'None', 'None']

# Generated at 2022-06-25 11:49:14.268594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  assert False # TODO: implement your test here


# Generated at 2022-06-25 11:49:21.125512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable_1 = 'hello'
    variable_2 = 'myvar'
    variable_3 = 'name'
    variable_4 = 'msg'
    variable_5 = ''
    variable_6 = 'hello'
    variable_7 = 'notename'
    variable_8 = 'hello'
    variable_9 = 'notename'
    variable_10 = 'variabl'
    variable_11 = 'myvar'
    variable_12 = 'ename'
    variable_13 = 'variabl'
    variable_14 = 'myvar'
    variable_15 = 'notename'
    variable_16 = 'variabl'
    variable_17 = 'myvar'
    variable_18 = 'notename'
    variable_19 = 'ansible_play_hosts'
    variable_20 = 'ansible_play_batch'

# Generated at 2022-06-25 11:49:31.381416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['{{ lookup("vars", "ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all") }}', 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables_0 = None
    kwargs_0 = {u'default': None}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    print('result_0 like ', result_0)
# Return value is [u'localhost', u'localhost', u'localhost', u'localhost'


# Generated at 2022-06-25 11:49:34.115672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Most simple test case possible
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['variablename'], {'variablename': 'hello'}) == ['hello']


# Generated at 2022-06-25 11:49:38.807355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = []
    lookup_module_1.run(terms)


# Generated at 2022-06-25 11:49:41.184423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
'variablename',
]
    variables_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == [
'']

# Generated at 2022-06-25 11:49:47.656101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_2 = ["variabl" + "ename"]
    variables_3 = {"variablename": "hello"}
    kwargs_4 = {"ignore_errors": True}
    result = lookup_module_1.run(terms_2, variables_3, **kwargs_4)
    assert result == ["hello"]


# Generated at 2022-06-25 11:49:51.041594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance_0 = LookupModule()
    lookup_instance_0.run(terms=[], variables=None)


# Generated at 2022-06-25 11:49:54.947807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run('ansible_p' + 'lay_batch', {'ansible_play_batch' : ['192.168.3.3', '192.168.3.4'], 'inventory_hostname' : '192.168.3.3'})

# Generated at 2022-06-25 11:50:10.664100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(['variabl' + myvar], [variablename])
    assert 'hello' in res


# Generated at 2022-06-25 11:50:19.698054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'hostvars':{'host1':{'var2':'world', 'var1':'hello'}}}, direct={})
    lookup_module_0._templar._available_variables = {'hostvars': {'host1': {'var2': 'world', 'var1': 'hello'}}, 'inventory_hostname': 'host1'}
    assert lookup_module_0.run(terms=['var2'], variables={'hostvars':{'host1':{'var2':'world', 'var1':'hello'}}}, direct={}) == ['world']

# Generated at 2022-06-25 11:50:27.448819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:50:31.861173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    parameters = "terms"
    assert lookup_module.run(parameters) == []

# Generated at 2022-06-25 11:50:42.198678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(['test_term_0', 'test_term_1']) == []
    assert lookup_module_1.run(['test_term_2', 'test_term_3'], test_key_0={}) == []
    assert lookup_module_1.run(['test_term_4', 'test_term_5'], test_key_1={'test_key_2': 'test_value_1'}) == []
    assert lookup_module_1.run(['test_term_6', 'test_term_7'], test_key_3={'test_key_4': 'test_value_2', 'test_key_5': 'test_value_3'}) == []

# Generated at 2022-06-25 11:50:43.972070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['terms']
    result = lookup_module.run(terms)
    assert result is None, "Result is not None"

# Generated at 2022-06-25 11:50:48.566500
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up the objects needed to test run
    lookup_module_0 = LookupModule()
    terms_0 = 'ansible_play_hosts, ansible_play_batch, ansible_play_hosts_all'
    variables_0 = 'hostvars'

    # run the method to be tested
    result = lookup_module_0.run(terms_0, variables_0, default='[\'hello\']')

    # check the results
    assert result == ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

# Generated at 2022-06-25 11:50:49.773924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, variables=None, **kwargs) == ret

# Generated at 2022-06-25 11:50:57.459038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # AssertionError: Expected string object, got <class 'ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode'>
    # assert lookup_module_0.run(terms="variablename", variables={"variablename": "hello"}, myvar="ename")
    pass


# Generated at 2022-06-25 11:51:02.145119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = "ansible_play_hosts"
    terms = [term]
    variables = {'inventory_hostname': "test_host"}
    response = lookup_module_0.run(terms, variables)
    assert (response[0] == variables[term])
    return response[0]


# Generated at 2022-06-25 11:51:30.320892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms = ['1', '2'])

# Generated at 2022-06-25 11:51:39.788410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    var_options = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    direct = {}
    lookup_module_0.set_options(var_options=var_options, direct=direct)
    direct_0 = lookup_module_0.get_option('direct')
    variables_0 = lookup_module_0.get_option('var_options')
    ret = lookup_module_0.run(terms_0, variables_0, **direct_0)
    return ret

# Generated at 2022-06-25 11:51:42.001436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_test = LookupModule()
    assert False

# Generated at 2022-06-25 11:51:50.742974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n STARTED LOOKUPMODULE_RUN \n")
    lookup_module_0 = LookupModule()
    terms_0 = "ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"
    ansible_play_hosts_0, ansible_play_batch_0, ansible_play_hosts_all_0 = lookup_module_0.run(terms_0)
    assert ansible_play_hosts_0 == ['localhost'], "The expected answer is '['localhost']' but the actual answer is: " + str(ansible_play_hosts_0)

# Generated at 2022-06-25 11:51:56.554527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])

# Generated at 2022-06-25 11:52:02.473462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct=None)
    lookup_module_0.set_options(var_options=None)
    lookup_module_0.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables=None, direct=None)
    lookup_module_0.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables=None, direct=None)

# Generated at 2022-06-25 11:52:07.558691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = (u'variablename', )
    variables_0 = {u'variablename': u'hello', u'myvar': u'ename'}
    kwargs_0 = {}
    retval = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert retval == [u'hello']

# Generated at 2022-06-25 11:52:19.947988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
        'ansible_play_tasks'
    ]

# Generated at 2022-06-25 11:52:28.299004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test function run(terms, variables=None, **kwargs)
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lookup_module_0 = LookupModule()
    run_return = lookup_module_0.run(terms=terms)
    assert run_return is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:52:38.924623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # Using fixture
    lookup_module_1._templar = test_case_0()
    lookup_module_1._templar.available_variables = {}
    lookup_module_1.set_options()
    lookup_module_1.get_option('default')
    lookup_module_1._templar._available_variables = {}
    assert lookup_module_1.run(terms=['variablename'], variables=None, **{}) == [u'hello']
    assert lookup_module_1.run(terms=['variablnotename'], variables=None, **{'default': ''}) == [u'']

# Generated at 2022-06-25 11:53:35.112446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['variablename', 'myvar']
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms) == ["hello", "ename"]

# Generated at 2022-06-25 11:53:44.222544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['variablename']) == ['hello']
    assert lookup_module.run(['variablename'], {'variablename':hello}) == ['hello']
    assert lookup_module.run(['ansible_play_hosts']) == ['all']
    assert lookup_module.run(['ansible_play_hosts_all']) == ['all']
    assert lookup_module.run(['variablename'], {'variablename':[1,2,3]}) == [[1,2,3]]
    assert lookup_module.run(['variablename'], {'variablename':[1,2,3]}) == [[1,2,3]]

# Generated at 2022-06-25 11:53:45.125921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() == []

# Generated at 2022-06-25 11:53:47.747490
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    vars = dict()

    terms = [ 'a', 'b' ]

    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms, vars)


# Generated at 2022-06-25 11:53:53.151819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # Test with default value of variable 'myvars'
    assert lookup_module_1.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']) == [
        myvars['ansible_play_hosts'], myvars['ansible_play_batch'], myvars['ansible_play_hosts_all']
    ]


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:53:56.076667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        terms = []
        variables = {}
        retval = lookup_module_0.run(terms=terms, variables=variables)
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-25 11:54:01.525566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['test']
    variables = {'test': 'b'}
    ret0 = lookup_module_0.run(terms, variables)
    assert ret0 == ['b']

test_LookupModule_run()

# Generated at 2022-06-25 11:54:08.648105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['myvar']
    variables_1 = {'ansible_play_hosts_all': ['127.0.0.1', '192.168.0.1'], 'ansible_play_batch': 0.5, 'ansible_play_hosts': ['127.0.0.1', '192.168.0.1']}
    kwargs_0 = {}
    kwargs_1 = {}
    try:
        result_0 = lookup_module_0.run(terms_0, variables_1, **kwargs_0)
    except Exception as e_0:
        result_0 = e_0.args[0]
    assert result_0 == result_0


# Generated at 2022-06-25 11:54:14.526335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        ret = lookup_module_1.run('test_LookupModule_run_1')
    except Exception:
        ret = 'test_LookupModule_run_2'
    assert ret == 'test_LookupModule_run_3'


# Generated at 2022-06-25 11:54:23.821818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module._templar = None
    lookup_module.set_options(var_options=None, direct=None)

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': ['host1', 'host2'], 'ansible_play_batch':['host3'], 'ansible_play_hosts_all':['host1', 'host2', 'host4']}

    assert lookup_module.run(terms, variables) == [['host1', 'host2'], ['host3'], ['host1', 'host2', 'host4']]

# Generated at 2022-06-25 11:56:31.473991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # provide args and kwargs here
    # expected_1 and expected_2 are tuples with parameters in that order
    # returns is a tuple with the return value in the first position
    # raises is a tuple with the exception type in the first position and the exception object in the second position
    expected_1 = (['hello'])
    expected_2 = (['hello', 'hello'])
    kwargs = {'variables': {'variablename': 'hello', 'myvar': 'ename'}}
    terms = ['variabl' + 'ename']
    ret = LookupModule.run(terms, **kwargs)
    return (ret == expected_1) and (ret == expected_2)


# Generated at 2022-06-25 11:56:42.092481
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Make a fake inventory
    inv = {}
    inv['_meta'] = {}
    inv['_meta']['hostvars'] = {}
    inv['all'] = {}
    inv['all']['vars'] = {}
    inv['all']['vars']['common_var'] = 1
    inv['all']['vars']['common_var2'] = '2'
    inv['all']['vars']['common_var3'] = {'key':'val'}
    inv['all']['vars']['nested'] = {'key':{'key':'val'}}
    inv['all']['children'] = []
    inv['all']['children'].append('group1')
    inv['group1'] = {}

# Generated at 2022-06-25 11:56:46.773019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['$test1', 'test2', 'test3']
    variables = {'test1': 'hello', 'test2': 'world', 'hostvars': {
        'host1': {'test3': 'test3'}}}
    kwargs = dict(default='failed')
    assert ['hello', 'world', 'test3'] == lookup_module_0.run(terms, variables, kwargs)

# Generated at 2022-06-25 11:56:53.602134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define arguments
    # Define arguments
    # Define arguments
    # Define arguments
    # Define arguments
    # Define arguments
    # Define arguments
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]

    lookup_module_0 = LookupModule()

    # Invoke method
    result = lookup_module_0.run(terms=terms)
    assert result == [
        {
            'qa-host': True,
            'qa-host2': True
        },
        [
            'qa-host',
            'qa-host2'
        ],
        [
            'qa-host',
            'qa-host2'
        ]
    ]

# Generated at 2022-06-25 11:56:57.086453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = []
    var_options_0 = None
    direct_0 = {}

    lookup_module_0.set_options(var_options=var_options_0, direct=direct_0)
    default_0 = lookup_module_0.get_option('default')

    ret_0 = lookup_module_0.run(terms=terms_0, variables=var_options_0, **direct_0)

    assert ret_0 == []


# Generated at 2022-06-25 11:57:05.529158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options={})
    lookup_module_1.set_options(direct={'default': None})
    lookup_module_1._templar = None
    lookup_module_1._templar__available_variables = {}
    assert lookup_module_1.run(['ansible_play_hosts'], {}) == ['localhost']

    lookup_module_2 = LookupModule()
    lookup_module_2.set_options(var_options={})
    lookup_module_2.set_options(direct={'default': None})
    lookup_module_2._templar = None
    lookup_module_2._templar__available_variables = {}

# Generated at 2022-06-25 11:57:07.847160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_module_0.run(terms=['test_term_0'], variables={'test_term_0': 'test_value', 'test_key_2': 'test_value'}, **{'default': 'test_value'})
    assert result == ['test_value']


# Generated at 2022-06-25 11:57:08.367380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:57:12.827760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars = {'ansible_play_hosts': 'localhost', 'ansible_play_batch': 'localhost', 'ansible_play_hosts_all': 'localhost',
              'inventory_hostname': 'localhost'}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=[''], variables=myvars, default='')
    lookup_module_0.run(terms=[], variables=myvars, default='')
    lookup_module_0.run(terms=['hosts'], variables=myvars, default='')
    lookup_module_0.run(terms=['batch', 'hosts_all'], variables=myvars, default='')

if __name__ == '__main__':
    test_case_0()
    test_Lookup

# Generated at 2022-06-25 11:57:19.436434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'foo'
    variables = {'hostvars': {'host1': {'bar': 'baz'}}, 'inventory_hostname': 'host1'}
    parameters = {'default': 'foo'}
    assert lookup_module_0.run(terms, variables, **parameters) == ['baz']