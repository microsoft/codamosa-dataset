

# Generated at 2022-06-25 11:48:07.875096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "ter"
    str_1 = "sub_var"
    list_0 = []
    list_1 = []
    list_2 = []
    str_2 = "inventory_hostname"
    list_3 = []
    argv_0 = [str_0, "m", "sub_v" + str_1]
    str_3 = "\n    - hosts\n    - batch\n    - hosts_all\n"
    str_4 = "variablename"
    str_5 = "myvar"
    bool_0 = None
    str_6 = "notename"
    str_7 = "hello"
    str_8 = "ename"
    str_9 = "variabl"
    str_10 = "variabl"

# Generated at 2022-06-25 11:48:10.403964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    if (True):
        return

    for i in range(10):
        lookup_module_0.run()

# Generated at 2022-06-25 11:48:21.765351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  print("Testing run")

  dct_0 = {"variablename": "hello", "myvar": "ename"}
  assert(lookup_module_0.run(["variablename"], dct_0) == ["hello"])

  dct_1 = {"variablename": "hello", "myvar": "notename"}
  assert(lookup_module_0.run(["variablename"], dct_1) == ["hello"])

  dct_2 = {"variablename": "hello", "myvar": "notename"}
  assert(lookup_module_0.run(["variablename"], dct_2) == ["hello"])

  dct_3 = {"ansible_play_hosts": "hello"}

# Generated at 2022-06-25 11:48:30.862093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    lookup_module_0 = LookupModule()

    # test with valid parameters

# Generated at 2022-06-25 11:48:34.665642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ansible_play_hosts_0 = None
    ansible_play_batch_0 = None
    ansible_play_hosts_all_0 = None

    terms_0 = [ansible_play_hosts_0, ansible_play_batch_0, ansible_play_hosts_all_0]

    ret_0 = lookup_module_0.run(terms=terms_0)
    assert not ret_0
    # @TODO: Add tests
    pass

# Generated at 2022-06-25 11:48:37.575237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == [], 'Method run returned error'

# Generated at 2022-06-25 11:48:41.628626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    lookup_module_0 = LookupModule()
    terms_0 = ()
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, **kwargs_0)
    assert result_0 == []


# Generated at 2022-06-25 11:48:45.155868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 1
    bool_0 = None
    lookup_module_0 = LookupModule()
    bool_0 = lookup_module_0['ansible_check_mode'] is None
    assert bool_0 == True



# Generated at 2022-06-25 11:48:55.751545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'ansible_play_batch'
    str_1 = 'ansible_play_hosts_all'
    str_2 = 'ansible_play_hosts'
    terms_0 = [str_0, str_1, str_2]
    variables_0 = {}
    __args__ = {}
    __args__['variables'] = variables_0
    print(lookup_module_0.run(terms_0, **__args__))


# Generated at 2022-06-25 11:48:57.207458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []

# Generated at 2022-06-25 11:49:11.891829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Empty case
    terms = []
    variables = None
    ret = lookup_module_0.run( terms, variables)
    assert ret == []

    # Normal case with empty terms, empty variables
    ret = lookup_module_0.run("",[])
    assert ret == []

    # Normal case with empty terms, empty variables
    ret = lookup_module_0.run("")
    assert ret == []

    # Test with default values
    ret = lookup_module_0.run(['test_val_1'], {})
    assert ret == []

    myvars = {'ansible_play_hosts': [u'localhost'], 'ansible_play_batch': [u'localhost'], 'ansible_play_hosts_all': [u'localhost']}


# Generated at 2022-06-25 11:49:19.194049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([], {})
    lookup_module_0.run([], {'hostvars': {'inventory_hostname': 'variable'}})
    lookup_module_0.run(['variable'], {'hostvars': {'inventory_hostname': 'variable'}})
    lookup_module_0.run([], {})
    lookup_module_0.run([], {'variable': 'test'})
    lookup_module_0.run(['test'], {'variable': 'test'})
    lookup_module_0.run(['test'], {'var_options': {'inventory_hostname': 'variable'}})

# Generated at 2022-06-25 11:49:30.621344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # empty any variables set in the past
    lookup_module_0._templar.available_variables = {}

    # set_options
    lookup_module_0.set_options(var_options=None, direct=None)

    # run with terms setting and default
    # 'LookupModule', 'run', terms=['first', 'second'],
    # variables={'first': 'Hello'}, default='default'
    ansible_vars = {'first': 'Hello'}
    ret = lookup_module_0.run(terms=['first', 'second'],
                              variables=ansible_vars,
                              default='default')
    assert ret == ['Hello', 'default']

    # set_options

# Generated at 2022-06-25 11:49:33.432316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ["term_0"]
    default_0 = "defaul"
    test_case_0(lookup_module_0, term_0, None, default=default_0)

# Generated at 2022-06-25 11:49:38.185640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert callable(getattr(lookup_module_0, 'run'))

# Generated at 2022-06-25 11:49:44.186054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['variabl' + 'ename']
    variables_0 = None
    kwargs_0 = {u'default': u''}
    result_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert result_0 == [u'hello']

# Generated at 2022-06-25 11:49:51.649854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['variablename']
    variables_0 = {'variablename': 'hello', 'myvar': 'ename'}
    kwargs_0 = {'lookup_options': {}}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert 'hello' in ret_0


# Generated at 2022-06-25 11:49:59.742538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['f14b8a4b-c7b4-4a54-8e4f-73c2b1e975d9']
    variables_1 = 'f14b8a4b-c7b4-4a54-8e4f-73c2b1e975d9'
    kwargs_1 = {'x': 'f14b8a4b-c7b4-4a54-8e4f-73c2b1e975d9'}


# Generated at 2022-06-25 11:50:08.074783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible_core_version', 'ansible_core_fact_cache']
    ret = lookup_module.run(terms, None)
    assert ret[0].startswith('2.7'), \
        'Failed to lookup version from vars'
    assert ret[1] == '/home/user/.ansible/fact_cache', \
        'Failed to lookup fact_cache path from vars'

# Generated at 2022-06-25 11:50:11.890826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = ['name']
    variables = 'hostvars'
    kwargs = {'default': 'DEBUG'}
    result = lookup_module_1.run(terms, variables, **kwargs)
    assert result == [u'localhost']

    lookup_module_2 = LookupModule()
    terms = ['name']
    variables = 'hostvars'
    kwargs = {'default': 'name'}
    result = lookup_module_2.run(terms, variables, **kwargs)
    assert result == [u'localhost']

    lookup_module_3 = LookupModule()
    terms = ['name']
    variables = 'hostvars'
    kwargs = {'default': 'DEBUG'}

# Generated at 2022-06-25 11:50:19.895728
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:50:26.230655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Start test for method run of class LookupModule")
    my_variables = {
        "inventory_hostname": "google.com"
    }
    my_terms = [
        "inventory_hostname"
    ]
    lookup_module = LookupModule()
    results = lookup_module.run(my_terms, variables=my_variables)
    assert(results == ["google.com"])
    print("Test successful!")



# Generated at 2022-06-25 11:50:32.338652
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # empty terms, return empty list
    lookup_module = LookupModule()
    assert [] == lookup_module.run([])

    # terms, return a list
    assert [] == lookup_module.run(['1'])

    # terms, return a list
    assert [] == lookup_module.run(['1', '2'])

    # terms, return a list
    assert [] == lookup_module.run(['1', '2', '3'])

# Generated at 2022-06-25 11:50:42.656394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Pass a dummy value to run method as argument, we don't want to test lookup module here.
    lookup_module_0 = LookupModule()
    # Get the parameters of run which are declared above.
    args = inspect.getargspec(lookup_module_0.run)
    # Get the default value of arguments
    args.defaults = ('',)

    # Create a dictionary from the arguments
    param_dict = dict(zip(args.args[-len(args.defaults):], args.defaults))
    # Change the value of  terms
    param_dict['terms'] = ['localhost']
    # Change the value of  default
    param_dict['default'] = 'XX'
    # Invoke the function with arguments as a dict
    ret_value = lookup_module_0.run(**param_dict)

# Generated at 2022-06-25 11:50:49.079745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    check_terms = ['variablename', 'variablnotename']
    check_variables = {'variablename': 'hello', 'myvar': 'ename'}
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = FakeTemplar()
    lookup_module_0._get_terms = Mock(side_effect=lambda x, y: x)
    lookup_module_0._templar.available_variables = check_variables
    lookup_module_0._templar.fail_on_undefined = True
    try:
        result = lookup_module_0.run(check_terms, variables=check_variables)
    except AnsibleUndefinedVariable:
        result = None

    assert result is None


# Generated at 2022-06-25 11:50:58.509136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new instance of LookupModule()
    lookup_module = LookupModule()
    variables = {"a": "1", "b": {"c": "2"}}
    # Call method run of LookupModule
    assert lookup_module.run(terms=["a"], variables=variables) == ["1"]
    assert lookup_module.run(terms=["b.c"], variables=variables, direct="") == ["2"]
    # TODO: Fix in future versions
    # assert lookup_module.run(terms=["b", "c"], variables=variables, direct="") == ["2"]

if __name__ == "__main__":
    # Run this unit test when this file is ran directly.
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:51:03.100940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with two possible scenarios
    vars = {"variable": "value"}
    assert lookup_module_0.run(["variable"], vars) == ["value"]

    assert lookup_module_0.run(["variable_not_exist"], vars) == []



# Generated at 2022-06-25 11:51:04.059121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Call method 'run' of lookupModule object
    lookup_module_0.run()

# Generated at 2022-06-25 11:51:13.407466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()

    # test case:
    try:
        # Test the case where there are no variables passed to lookup module.
        lookup_module_0.run(terms=["key1", "key2"], variables=None)
    except Exception as e:
        if "No variable found with this name: key1" in str(e):
            pass


# Generated at 2022-06-25 11:51:14.729894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-25 11:51:34.184915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Running of the method run with default parameters
    lookup_module = LookupModule()
    # Asserting that the returned value is correct
    assert lookup_module.run(terms=["testval"]) == ["test"]


# Generated at 2022-06-25 11:51:44.729933
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # No default provided, terms are not found in vars.
    lookup_module_1 = LookupModule()
    myvars_1 = {}
    terms_1 = ['term_1', 'term_2']
    variables_1 = None
    kwargs_1 = {}

    try:
        result_1 = lookup_module_1.run(terms_1, variables_1, **kwargs_1)
    except Exception as except_1:
        print('Exception code: ' + str(except_1))
        assert False
    else:
        assert False

    # No default provided, terms are found in vars.
    lookup_module_2 = LookupModule()
    myvars_2 = {'term_1':'value_1', 'term_2':'value_2'}

# Generated at 2022-06-25 11:51:47.336342
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: Below test is done without assigning a value to 'terms'
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() is None, "lookup.py: test_LookupModule_run() did not return the expected result"


# Generated at 2022-06-25 11:51:54.307603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run_args = [('ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'),
                     ('ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all')]
    test_run_kwargs = {'variables': {
        'ansible_play_hosts': ["1", "2", "3"],
        'ansible_play_batch': 0,
        'ansible_play_hosts_all': ["4", "5", "6"],}
    }

    lookup_module_run_return = lookup_module_0.run(*test_run_args, **test_run_kwargs)

# Generated at 2022-06-25 11:52:02.500528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_options_0 = None
    direct_0 = {'verbosity': 0}
    ansible_play_hosts = 'ansible_play_hosts'
    ansible_play_batch = 'ansible_play_batch'
    ansible_play_hosts_all = 'ansible_play_hosts_all'
    ansible_play_hosts_all_0 = 'ansible_play_hosts_all'
    terms_0 = [ansible_play_hosts, ansible_play_batch, ansible_play_hosts_all]
    terms_0_0 = ansible_play_hosts_all_0
    terms_0_0_0 = terms_0_0
    default_0 = None
    default_0_0 = default

# Generated at 2022-06-25 11:52:06.996154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args = []
    if len(args) == 0:
        # No parameter provided - skipping function
        pass
    else:
        # We have some input - let's check it
        assert len(args) == 3, "Input parameter mismatch"



# Generated at 2022-06-25 11:52:17.747339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'variablename',
        'myvar',
    ]
    variables = {
        'variablename': 'hello',
        'myvar': 'ename',
    }
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = {
            '_available_variables': variables,
    }
    expected_result_0 = [
        'hello',
        '',
    ]
    result_0 = lookup_module_0.run(terms, variables, default='')
    assert result_0 == expected_result_0


# Generated at 2022-06-25 11:52:19.641467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run('hostvars')

# Generated at 2022-06-25 11:52:28.555848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]
    result = lookup_module_0.run(terms, variables={'ansible_play_batch': [], 'ansible_play_hosts': [], 'ansible_play_hosts_all': [], 'ansible_play_hosts_all_count': 0})
    assert result == [[], [], []]


# Generated at 2022-06-25 11:52:31.317361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = []
    variables = {}
    kwargs = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={'test_var': 'test_value'}, direct={})
    lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 11:53:02.952989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   terms = ['hostvars', 'hostname', 'hostname']
   variables = {"___omit_place_holder": True, "inventory_hostname": "localhost", "hostvars": {"localhost": {"ansible_play_batch": [], "ansible_play_hosts": ["localhost"], "ansible_play_hosts_all": ["localhost"]}}}
   lookup_module = LookupModule()
   result = lookup_module.run(terms, variables)
   expected_result = [{'localhost': {"ansible_play_batch": [], "ansible_play_hosts": ["localhost"], "ansible_play_hosts_all": ["localhost"]}}, 'localhost', 'localhost']
   assert expected_result == result

# Generated at 2022-06-25 11:53:04.009336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True == False


test_LookupModule_run()

# Generated at 2022-06-25 11:53:11.416388
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    lookup_module_1._templar._available_variables = {}

    lookup_module_1._templar._available_variables['myvar'] = '12'

    lookup_module_1._templar._available_variables['myvar'] = '12'


# Generated at 2022-06-25 11:53:17.857507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ "myvar1" ]
    variables = { "myvar1" : "myvar1_val" }
    kwargs = {}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables, **kwargs) == [ "myvar1_val" ]


# Generated at 2022-06-25 11:53:21.355061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  try:
    lookup_module_0.run(terms=[])
  except AnsibleError:
    # exceptions.AnsibleError: At least one term is required to lookup a var.
    pass

# Generated at 2022-06-25 11:53:27.995785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'ansible_os_family'
    variables = {'ansible_os_family': 'centos'}
    lookup_module_0 = LookupModule()
    value = lookup_module_0.run(terms, variables)
    assert value[0] == 'centos'


# Generated at 2022-06-25 11:53:29.764100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run('variablename') == ['hello']

# Generated at 2022-06-25 11:53:31.141424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:53:38.172502
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing for checking the case where there is no default value and undefined variable

    lookup_module_1 = LookupModule()
    lookup_module_1._load_name = ""
    lookup_module_1._templar.vars = {}
    lookup_module_1._templar._available_variables = {}
    lookup_module_1._templar.template = lambda x, y: x
    assert lookup_module_1.run(terms=['var_name'], variables={}, default=None) == []



# Generated at 2022-06-25 11:53:39.854080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], []) == []



# Generated at 2022-06-25 11:54:43.970640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lookup_module_0 = LookupModule()

    var_terms = "''"
    var_options = []
    var_default = []
    try:
        lookup_module_0.run(var_terms, var_options, var_default)
    except Exception as e:
        pass

    var_terms = []
    var_options = []
    var_default = []
    try:
        lookup_module_0.run(var_terms, var_options, var_default)
    except Exception as e:
        pass

    var_terms = None
    var_options = None
    var_default = None
    try:
        lookup_module_0.run(var_terms, var_options, var_default)
    except Exception as e:
        pass

# Generated at 2022-06-25 11:54:49.076660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Tests the type of the return value
    assert isinstance(lookup_module_0.run(['variablename'], {'variablename': "hello"}, myvar='ename'), list)


# Generated at 2022-06-25 11:54:59.311512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    assert lookup_module_0.run(terms_0, variables_0) == []
    assert lookup_module_0.run(terms_0, variables_0) == []
    terms_1 = []
    variables_1 = {}
    assert lookup_module_0.run(terms_1, variables_1) == []
    assert lookup_module_0.run(terms_1, variables_1) == []
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options()

# Generated at 2022-06-25 11:55:06.178169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0 = ["hello"]
    test_case_1 = ["hello", "" ]
    myvar = "name"
    myvar = "notename"
    other = "ansible_play_hosts"
    other = "ansible_play_batch"
    other = "ansible_play_hosts_all"
    sub_var = 12
    sub_var = "12"
    item = "hosts"
    item = "batch"
    item = "hosts_all"

# Generated at 2022-06-25 11:55:13.581463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    try:
        lookup_module_1.run(["","-01","1","A","abc"], {'A': '0x41DDDDC4C4D4E4F4', '1': '0x4142', '-01': 3.2e-8 , 'abc': '0x000000000'})
    except:
        pass


# Generated at 2022-06-25 11:55:17.867416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['hello', 'ansible_play_hosts_all']
    variables = {"hello": "world"}
    kwargs = {"default": "default_value"}
    ret = LookupModule().run(terms, variables, **kwargs)
    assert ret == ['world', 'default_value']

# Generated at 2022-06-25 11:55:18.987286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:55:21.437051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    values = {'inventory_hostname': 'localhost'}
    term = "inventory_hostname"
    assert lookup_module_1.run(terms=term,variables=values,default="unknown") == "localhost"


# Generated at 2022-06-25 11:55:28.425205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  test_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
  expected_doc = ['all', 1, ['localhost']]
  assert lookup_module.run(test_terms) == expected_doc

# Generated at 2022-06-25 11:55:35.373250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()

  # Set up mock environment
  lookup_module._templar._available_variables = {u'variablename': u'hello', u'inventory_hostname': u'localhost', u'hostvars': {u'localhost': {}}}
  lookup_module._templar._available_variables['myvar'] = u'ename'


  # Invoke method
  ret = lookup_module.run(terms=[u'variabl' + lookup_module._templar._available_variables['myvar']])

  # Check return value
  assert ret[0] == u'hello'