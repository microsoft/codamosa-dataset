

# Generated at 2022-06-25 11:48:08.849552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ansible_vars_0 = {'var_3': {'main': {'var_1': 2, 'var_2': 'foo'}}, 'var_4': {'main': {'var_1': 3, 'var_2': 'bar'}}}
    lookup_module_0._templar._available_variables = ansible_vars_0
    input_0 = ['var_1', 'var_2', 'var_1']
    lookup_module_0.run(input_0)


# Generated at 2022-06-25 11:48:12.319811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['variablename']
    myvars = {'variablename':'hello', 'myvar':'ename'}
    lookup_module = LookupModule()
    lookup_module.run(terms, myvars)


# Generated at 2022-06-25 11:48:15.841765
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myvars = {}

    assert myvars == {}
    lookup_module_0 = LookupModule()
    terms = []
    lookup_module_0.run(terms, variables=None)
    assert myvars == {}


# Generated at 2022-06-25 11:48:18.489668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:48:23.951885
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=vars, direct=kwargs)
    assert lookup_module.run(terms) == ret
    assert lookup_module.run(terms, variables) == ret


# Generated at 2022-06-25 11:48:28.859742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars = {'variablename': 'hello',
              'myvar': 'ename',
              'hostvars': {'myhost': {'variablename': 'hello'}},
              'inventory_hostname': 'myhost'}
    lookup_instance = LookupModule()
    result = lookup_instance._get_myvars_from_module_utils_six(myvars)
    assert result == {'variablename': 'hello',
                      'myvar': 'ename',
                      'hostvars': {'myhost': {'variablename': 'hello'}},
                      'inventory_hostname': 'myhost'}, "test_LookupModule_run does not work as expected"


# Generated at 2022-06-25 11:48:33.760308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "ansible_play_hosts"
    variables = None
    try:
        lookup_module_0.run(terms, variables)
    except Exception as err:
        pass



# Generated at 2022-06-25 11:48:45.298586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['hostvars', 'hostvars']

# Generated at 2022-06-25 11:48:53.813870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    msg_0 = "msg"
    msg_1 = "msg"
    lookup_module_0.set_options()
    lookup_module_0.get_option("default")
    lookup_module_0.run(terms=[msg_0, msg_1])
    lookup_module_1.set_options()
    lookup_module_1.get_option("default")
    lookup_module_1.run(terms=[msg_0, msg_1])


# Generated at 2022-06-25 11:48:58.402285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    args = [{'terms': 't', 'variables': None}]
    kwargs = {'kwarg_1': 'kwarg_val'}
    ret = lookup_module_1.run(args[0]['terms'], variables=args[0]['variables'], **kwargs)
    assert ret is not None

# Generated at 2022-06-25 11:49:13.264191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]
    #variables = {"ansible_play_hosts": "host1", "ansible_play_batch": "host2", "ansible_play_hosts_all": "host3"}
    variables = {
        "ansible_play_hosts": "host1",
        "ansible_play_batch": "host2",
        "ansible_play_hosts_all": "host3",
        "variablename": "hello",
        "myvar": "ename"
    }
    ret = lookup_module.run(term, variables)


# Generated at 2022-06-25 11:49:20.372336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["aws_access_key_id", "aws_secret_access_key"]
    variables_0 = {"aws_security_token": "None", "ansible_connection": "local"}
    myvars = getattr(lookup_module_0._templar, '_available_variables', {})

    lookup_module_0.set_options(var_options=variables_0, direct={})
    default = lookup_module_0.get_option('default')

    ret = []
    for term in terms_0:
        if not isinstance(term, string_types):
            raise AnsibleError('Invalid setting identifier, "%s" is not a string, its a %s' % (term, type(term)))


# Generated at 2022-06-25 11:49:27.469919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1._templar._available_variables == {}
    assert lookup_module_1.run([]) == []

    lookup_module_2 = LookupModule()

    assert lookup_module_2._templar._available_variables == {}
    assert lookup_module_2.run([]) == []

    lookup_module_3 = LookupModule()

    assert lookup_module_3._templar._available_variables == {}
    assert lookup_module_3.run([]) == []

# Generated at 2022-06-25 11:49:27.995751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True



# Generated at 2022-06-25 11:49:37.485816
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [0]
    variables_0 = 0
    kwargs_0 = {'a': 'a', 'b': 'b'}
    returned_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
    assert returned_0['assert'] == 'AnsibleError'
    terms_0 = ["ansible_play_hosts"]
    variables_0 = None
    returned_1 = lookup_module_0.run(terms_0, variables_0)
    assert returned_1 == ['a']
    terms_0 = [1]
    variables_0 = 1
    returned_2 = lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:49:42.562549
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={u'extravars': {u'var_f': u'foo'}, u'inventory_hostname': u'localhost'}, direct={u'default': u''})
    lookup_module_0.get_option('default')
    assert re.match(r'''[ (.,':"]+''', lookup_module_0.run(terms=[u'var_f', u'var_a'])) is not None
    lookup_module_0.get_option('default')
    assert re.match(r'''[ (.,':"]+''', lookup_module_0.run(terms=[u'var_f', u'var_a'])) is not None

# Generated at 2022-06-25 11:49:54.042016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    ret = lookup_module_0.run(terms=terms)
    assert len(ret) == 3
    assert ret[0] == ['dummy0']
    assert ret[1] == [1]
    assert ret[2] == ['dummy0', 'dummy1', 'dummy2']
    default = None
    ret = lookup_module_0.run(terms=terms, default=default)
    assert len(ret) == 3
    assert ret[0] == ['dummy0']
    assert ret[1] == [1]
    assert ret[2] == ['dummy0', 'dummy1', 'dummy2']

#

# Generated at 2022-06-25 11:49:59.675553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  myvars = {'hostvars': {'myhost': {'myvar': 'myvalue'}}, 'inventory_hostname': 'myhost'}
  lookup_module_0 = LookupModule()
  lookup_module_0.set_options(var_options=myvars, direct=dict())
  terms=['myvar']
  variables=myvars
  kwargs={}
  res0 = lookup_module_0.run(terms, variables, **kwargs)
  assert any(res0 == ['myvalue'])


# Generated at 2022-06-25 11:50:05.300855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    looker = LookupModule()
    my_var = looker.run(['b'], {'a':'c', 'b':'a'})
    assert my_var == ['a']


# Generated at 2022-06-25 11:50:08.591213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=None, variables=None)
    assert result is None

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 11:50:22.038808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = set(['variablename'])
    variables = None
    res = lookup_module.run(terms, variables)
    assert(res == ['hello'])

    terms = set(['variablename', 'variablenotename'])
    variables = None
    res = lookup_module.run(terms, variables)
    assert(res == ['hello', ''])

# Generated at 2022-06-25 11:50:26.230654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'Njw7Vu3F&C%=,/~Y'
    var_0 = lookup_run(set_0, str_0)


# Generated at 2022-06-25 11:50:37.142407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {'hi'}
    str_0 = 'hi'
    str_1 = "hi"

    # init
    assert terms_0 == {'hi'}
    assert str_0 == 'hi'
    assert str_1 == 'hi'

    # set_options
    var_0 = lookup_module_0.get_option('direct')
    var_1 = lookup_module_0.get_option('var_options')
    var_2 = lookup_module_0.get_option('default')
    assert var_1 == {}
    assert var_2 is None
    assert var_0 == {}

    # run
    assert lookup_run(terms_0, str_1) == ['hi']

# Generated at 2022-06-25 11:50:45.556554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_1 = set()
    str_1 = 'wi]FB7mZa}au#\\$'
    str_2 = 'SGHIe:g'
    var_2 = lookup_run(set_1, str_1, str_2)
    var_3 = lookup_run(set_1, str_1, str_2)
    var_4 = lookup_run(set_1, str_1, str_2)
    var_5 = lookup_run(set_1, str_1, str_2)
    var_6 = lookup_run(set_1, str_1, str_2)
    var_7 = lookup_run(set_1, str_1, str_2)

# Generated at 2022-06-25 11:50:47.731350
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (None, [])
    int_0 = lookup_run(lookup_module_0, tuple_0)
    assert int_0 == 0


# Generated at 2022-06-25 11:50:50.588676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_1 = set()
    set_2 = set()
    test_case_1 = (set_1 is not set_2)
    if test_case_1:
        str_0 = 'wi]FB7mZa}au#\\$'
        var_0 = lookup_run(set_1, str_0)

# Generated at 2022-06-25 11:50:56.665143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_1 = set()
    str_1 = 'wi]FB7mZa}au#\\$'
    with pytest.raises(AnsibleError):
        lookup_module_1.run(set_1, str_1)


# Generated at 2022-06-25 11:51:05.815099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Wi]fb7MzA}au#\\$'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['default'] = dict_0
    list_0 = list()
    var_0 = lookup_run(set_0, str_0)
    var_1 = lookup_module_0.run(set_0, dict_0, dict_1)
    assert len(var_1) == 1
    var_2 = var_1[0]
    assert var_2 == list_0
    assert var_0 is not var_2


# Generated at 2022-06-25 11:51:08.555871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = '$'
    var_0 = lookup_run(set_0, str_0)


# Generated at 2022-06-25 11:51:15.530327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  set_0 = set()
  str_0 = ''
  dict_0 = dict()
  dict_1 = dict()
  key_0 = 'r%q3HWJ'
  list_0 = list()
  dict_2 = dict()
  dict_2[key_0] = list_0
  dict_1['inventory_hostname'] = dict_2
  dict_0['hostvars'] = dict_1
  var_0 = lookup_module_0.run(set_0, str_0, variables=dict_0)

if __name__ == "__main__":
    test_case_0()
    # test_LookupModule_run()

# Generated at 2022-06-25 11:51:37.222338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    lookup_module = LookupModule()

    ret = lookup_module.run(terms)

    assert(len(ret) == 3)
    assert(ret[0] == [])
    assert(ret[1] == 1)
    assert(ret[2] == ['127.0.0.1'])


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:51:40.542652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['a', 'b']
    variables_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert type(ret_0) == list
    assert ret_0[0] == 'a'
    assert ret_0[1] == 'b'



# Generated at 2022-06-25 11:51:49.097010
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'

    # Invoke method
    # Invoke method
    # Invoke method
    # Invoke method
    var_0 = lookup_module_0.get_option(str_0)
    # Invoke method
    var_1 = lookup_module_0.run(set_0, str_0, default=var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:51:59.152573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = dict()
    str_0 = 'G[*F$^'
    dict_0.update({'ansible_inventory_hostname': str_0})
    dict_0.update({'ansible_play_hosts_all': 'gyF^K0M'})
    dict_0.update({'ansible_play_hosts': 'HZ,N.>'})
    dict_0.update({'ansible_play_batch': 'G[*F$^'})
    set_0 = set()
    str_0 = 'fYG[*F$^K0M],'
    var_0 = lookup_module_0.run(dict_0, set_0, str_0)

# Generated at 2022-06-25 11:52:06.693687
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 0
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    # Check the value returned by method run is equal to the expected value.
    assert lookup_module_0.run(set_0, str_0) == ['wi]FB7mZa}au#\\$']


# Generated at 2022-06-25 11:52:11.786176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)

# Generated at 2022-06-25 11:52:16.764492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs = {}
    terms_0 = 4
    self_0 = test_case_0()
    # self, terms, variables=None, **kwargs
    lookup_module_0 = LookupModule()
    res_0 = lookup_module_0.run(terms_0, **kwargs)

# Generated at 2022-06-25 11:52:20.654411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)
    return var_0


# Generated at 2022-06-25 11:52:24.793872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)
    var_1 = lookup_module_0.run(set_0, str_0)
    assert(var_0 == var_1)


# Generated at 2022-06-25 11:52:27.296699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	lookup_module_0 = LookupModule()
	assertEqual(lookup_module_0.run(terms, variables=None is False), False)

# Generated at 2022-06-25 11:53:01.018859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '&p9[u{7e'
    list_0 = ['&p9[u{7e', 'v1', 'v2']
    var_0 = lookup_run(str_0, list_0)
    var_1 = lookup_module_0.run(str_0, list_0)
    assert(var_0 == var_1)


# Generated at 2022-06-25 11:53:08.219861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_0 = set()
    str_0 = 'foo'
    str_1 = 'bar'
    dict_1 = dict()
    dict_1[str_0] = set_0
    dict_1[str_1] = set_0
    dict_0 = dict()
    dict_0['ansible_play_hosts'] = dict_1
    dict_0['ansible_play_batch'] = set_0
    dict_0['ansible_play_hosts_all'] = dict_1
    result_0 = lookup_module_1.run(set_0, dict_0)


# Generated at 2022-06-25 11:53:10.666410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    set_1 = set()
    lookup_module_0.run(set_0, set_1)

# Generated at 2022-06-25 11:53:12.371558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    lookup_module_0.run(set_0, str_0)


# Generated at 2022-06-25 11:53:17.602164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)
    assert var_0 == None


# Generated at 2022-06-25 11:53:21.416935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_module_1.run(set_0, str_0)


# Generated at 2022-06-25 11:53:25.845774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the various cases of the method
    # test_case_0()
    pass

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:53:29.646258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)
# test_case_0()

# Generated at 2022-06-25 11:53:35.283104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)

# Generated at 2022-06-25 11:53:42.287751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    set_1 = {}
    var_0 = lookup_module_0.run(set_0, str_0, set_1)


# Generated at 2022-06-25 11:54:44.057514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 't{f8*v]X4'
    dict_0 = lookup_module_0.run(set_0, str_0)
    assert dict_0 == None



# Generated at 2022-06-25 11:54:48.760029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)



# Generated at 2022-06-25 11:54:52.777125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = set()
    variables = 'm7lGZw0<bDVp'
    lookup_module_0 = lookup_module.run(terms, variables)


# Generated at 2022-06-25 11:55:01.361967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_module.run(set_0, str_0)

if __name__ == '__main__':
    #test_LookupModule_run()
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_module_0.run(set_0, str_0)

# Generated at 2022-06-25 11:55:06.993669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    tuple_0 = (False, set_0, str_0)

    try:
        lookup_module_0.run(tuple_0)
    except ValueError:
        print("Unit test for LookupModule.run() failed")
    else:
        print("Unit test for LookupModule.run() passed")


# Generated at 2022-06-25 11:55:11.966380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    set_1 = set()
    str_1 = 'wi]FB7mZa}au#\\$'
    lookup_module_1.run(set_1, str_1)


# Generated at 2022-06-25 11:55:15.558922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = '`$m%x{]E~^M>2QY'
    var_0 = lookup_run(set_0, str_0)


# Generated at 2022-06-25 11:55:22.295352
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    ansible_play_hosts = 'ansible_play_hosts'
    ansible_play_batch = 'ansible_play_batch'
    ansible_play_hosts_all = 'ansible_play_hosts_all'
    lookup_result = lookup_module.run(terms=[ansible_play_hosts, ansible_play_batch, ansible_play_hosts_all])
    assert lookup_result == [{u'localhost'}, [1], [u'localhost']]


# Generated at 2022-06-25 11:55:28.787628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)

# A more thorough unit test.

# Generated at 2022-06-25 11:55:34.179353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set({'ansible_play_hosts': [], 'ansible_play_batch': [], 'ansible_play_hosts_all': []})
    str_0 = 'ansible_play_hosts'
    # call method run of class LookupModule with arguments set_0, str_0
    result = lookup_module_0.run(set_0, str_0)
    assert result == set_0


# Generated at 2022-06-25 11:57:58.209491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    set_0 = set()
    str_0 = 'wi]FB7mZa}au#\\$'
    var_0 = lookup_run(set_0, str_0)
    assert set_0 == var_0["_raw_params"]
    assert str_0 == var_0["self"].get_option("_terms")[0]
    assert set_0 == var_0["variables"]
    assert var_0["lookup_module_0"] == var_0["self"]
    assert set_0 == var_0["kwargs"]
