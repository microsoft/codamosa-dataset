

# Generated at 2022-06-25 11:48:07.844369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'L9%c'
    str_1 = 'Btq+!#'
    lookup_module_0 = LookupModule(str_0)
    lookup_module_1 = LookupModule(str_0)
    lookup_module_2 = LookupModule(str_0)
    lookup_module_3 = LookupModule(str_0)
    lookup_module_4 = LookupModule(str_0)
    lookup_module_5 = LookupModule(str_0)
    lookup_module_6 = LookupModule(str_0)
    lookup_module_7 = LookupModule(str_0)
    lookup_module_8 = LookupModule(str_0)
    lookup_module_9 = LookupModule(str_0)

# Generated at 2022-06-25 11:48:19.250547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule('$^#&`F#%')
        lookup_module_0.get_option('default')

        str_0 = 'f7{]t<sO'
        list_0 = ['a', 'c', 'b']
        dict_0 = {'_': 'a', '__': 'c', '___': 'b'}
        lookup_module_0 = LookupModule(str_0)
        lookup_module_0.set_options(var_options=dict_0, direct=dict_0)
        lookup_module_0.run(list_0)
    except Exception as e:
        print(e)
        raise


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:48:25.121491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    variables = { }
    terms = { }
    # kwargs is a dictionary

    # Call method run
    kwargs = None
    lookup_module_0.run(terms, variables, **kwargs)


if __name__ == '__main__':
    import sys
    import pytest

    sys.exit(pytest.main(['-x', '--pdb', __file__]))

# Generated at 2022-06-25 11:48:32.459767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '~GWrkD&idf'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'jF!'
    tuple_0 = (str_1,)
    str_2 = 'cH'
    dict_0 = {str_2: None}
    lookup_module_0.run(tuple_0, dict_0)


# Generated at 2022-06-25 11:48:38.666792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '~GWrkD&idf'
    lookup_module_0 = LookupModule(str_0)
    assert lookup_module_0.run(terms='~GWrkD&idf') == None

# Generated at 2022-06-25 11:48:45.066232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '~GWrkD&idf'
    lookup_module_0 = LookupModule(str_0)
    terms_0 = []
    terms_0.append('hostvars')
    terms_0.append('inventory_hostname')
    variables_0 = {}
    try:
        lookup_module_0.run(terms=terms_0, variables=variables_0)
    except AnsibleUndefinedVariable:
        return
    raise Exception('Expected Exception not thrown')

# Generated at 2022-06-25 11:48:55.684168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = randint(0, 3)
    while True:
        if int_0 == 2:
            if len(str_0_0) == 0:
                return 0
            int_0 = 3
            break
        if int_0 != 1:
            list_0_0.append(list_1[(int_0 - 1)])
            str_0_0 = str_0_0[:(int_0 - 1)]
            int_0 = 1
            break
        list_0_0.append('~')
        str_1 = '~GWrkD&idf'
        lookup_module_1 = LookupModule(str_1)
        try:
            str_1 = lookup_module_1.run('variablename', dict_0)
        except Exception:
            raise

# Generated at 2022-06-25 11:48:56.853114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'fail_on_undefined' == test_case_0()

# Generated at 2022-06-25 11:48:59.840099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('_terms')
    str_0 = '~GWrkD&idf'
    dictionary_0 = {}
    dictionary_0['a'] = str_0
    lookup_module_0.run(dictionary_0)

test_case_0()

# Generated at 2022-06-25 11:49:00.557057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
 
    assert 1==1

# Generated at 2022-06-25 11:49:12.629225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        ansible_vars,
        ansible_inventory,
        ansible_options,
        ansible_facts,
        ansible_play_hosts,
    ]
    variables = {
        ansible_vars,
        ansible_inventory,
        ansible_options,
        ansible_facts,
        ansible_play_hosts,
    }
    # test for exceptions

# Generated at 2022-06-25 11:49:18.620237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create new LookupModule object
    lookup_module_0 = LookupModule()
    # Declare variables used in the test
    str_0 = ''
    # Try to invoke method LookupModule.run on object lookup_module_0, arguments are (str_0)
    try:
        value = lookup_module_0.run(str_0)
    # Catch exception AnsibleUndefinedVariable and throw the exception to caller
    except AnsibleUndefinedVariable:
        raise
    # Catch exception AnsibleError and throw the exception to caller
    except AnsibleError:
        raise
    # Return value must be an object of type str
    assert type(value) is str

# Generated at 2022-06-25 11:49:24.930281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = None
    variables = None
    kwargs = None
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_module_0.run(terms, variables, kwargs)


# Generated at 2022-06-25 11:49:27.022634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = lookup_module()
    lookup_module_0.run()


# class LookupModule


# Generated at 2022-06-25 11:49:30.754822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms, variables, kwarg = [], None, {}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables, **kwarg) is not None

# Generated at 2022-06-25 11:49:38.409358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'gK\x18\xc0\xaf\xfa\x1b\x1b\x0e\xee\xe6\x83\x15\x11\x7f\xac\x9c\xb9\xcd\xd0\xbd\x8f\xcc'

# Generated at 2022-06-25 11:49:45.271258
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 0
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(str_0)

    assert '\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T' == var_0

# Generated at 2022-06-25 11:49:51.652133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T')
    lookup_module_1.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])

# Generated at 2022-06-25 11:49:57.441318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = ['variablename']
    assert isinstance(variables, dict)
    default = ''
    var_0 = variables.get(name)
    assert isinstance(var_0, list)
    assert isinstance(variables, dict)
    var_1 = variables.get('inventory_hostname')
    assert isinstance(var_1, list)
    assert isinstance(variables, dict)
    res_0 = variables.get(name)
    assert isinstance(res_0, list)
    assert isinstance(res_0, list)
    res_1 = variables.get('inventory_hostname')
    assert isinstance(res_1, list)
    res_2 = variables.get(name)
    assert isinstance(res_2, list)
    assert isinstance(res_2, list)
   

# Generated at 2022-06-25 11:50:00.235892
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters
    terms = ''
    variables = ''
    kwargs = ''
    # Instantiate class
    lookup_module_0 = LookupModule('')
    # Test method
    result = lookup_module_0.run(terms, variables, **kwargs)
    # Assertion message
    print(result)


# Generated at 2022-06-25 11:50:14.647363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvar = 'nonexistent'
    failed = False
    try:
        lookup_module_1 = LookupModule(myvar)
        vars_0 = {}
        terms_0 = [myvar]
        var_0 = lookup_run(vars_0, terms_0)
    except AnsibleUndefinedVariable:
        failed = True
    assert failed


# Generated at 2022-06-25 11:50:16.145018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:50:26.956677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run('', {}) == [], \
        'Failed to assert that the run method of the LookupModule class returns the expected value'
    assert lookup_run('', {'ansible_play_hosts': True, 'ansible_play_batch': False, 'ansible_play_hosts_all': True}) == ['True', 'False', 'True'], \
        'Failed to assert that the run method of the LookupModule class returns the expected value'
    assert lookup_run('', {'variablename': 'hello', 'myvar': 'ename'}) == ['hello'], \
        'Failed to assert that the run method of the LookupModule class returns the expected value'

# Generated at 2022-06-25 11:50:35.695617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:50:44.339609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'z\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_module_0.run(str_0)
    bytes_1 = b'f\x9b\x00\x8e\xe4\xbd\x13\x15\xc8\xea\xb2K\xe9\xe3\x8cW'
    var_1 = lookup_module_0.run(str_0)
    var_2 = lookup_run(str_0)
    tuple_

# Generated at 2022-06-25 11:50:54.427047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = 'variabl' + myvar

# Generated at 2022-06-25 11:50:56.218649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    str_0 = str_0
    lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:51:01.773541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '3]\xa9\x9e'
    str_1 = 'V\x0b'
    str_2 = '\x1f\x98\x80\x0f'
    str_3 = '[\x1c\xcf\x92\xd1T\xe9\x08\xbe\xdb\x87\xef\xb8\x95\x04'
    str_4 = '\xd3\x90.\x10\xe2'
    str_5 = '\xc2\x87~\x15\x9d\xa1\x1d\x99\x8e\xe3\xac\xfd\t'

# Generated at 2022-06-25 11:51:11.843903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''

# Generated at 2022-06-25 11:51:16.342755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)

    setup_mock_ansible_module(mocker, lookup_module_0)

    lookup_module_0.run(terms=str_0)
    lookup_module_0.run(terms=str_0, variables=str_0)
    lookup_module_0.run(terms=str_0, variables=str_0, default=str_0)

# Generated at 2022-06-25 11:51:39.756945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\x1f\x95\x07\xfdR\xfa\x8e'
    str_1 = 'x'
    str_2 = '\x08;\xbb\x9a\x8d\xbf\xf2\xca\xb1N\xd8\x18U\x9b\x9b\xcb\x06;'
    str_3 = '\xdb\xf7\x94\xc9\xb1\xcc\xeb\x11\x85\x88\xa3'
    str_4 = '\x0c\x9a\x8d\xad\x07\xb0\x98\xce\xbc'
    lookup_module_0 = LookupModule(str_4)
    lookup_module_0.set

# Generated at 2022-06-25 11:51:47.462527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
    '',
    '',
    ]
    variables_0 = {
    '',
    '',
    }
    default_0 = ''
    lookup_module_0 = LookupModule('')
    lookup_module_0.lookup_module_run(terms_0, variables_0, default_0)


# Generated at 2022-06-25 11:51:57.304866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setting up arguments
    terms = ''
    variables = ''
    kwargs = ''

    # Executing the method under test
    try:
        str_0 = ''
        bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
        lookup_module_0 = LookupModule(bytes_0)
        var_0 = lookup_module_0.run(str_0)
    except Exception as e: 
        pass
    else:
        raise Exception("Expected exception not raised")

    # Executing method with arguments

# Generated at 2022-06-25 11:51:58.434319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = LookupModule(None)



# Generated at 2022-06-25 11:52:03.569031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    bytes_0 = b'\xc1\xd0\x1a\x9e9\x08\xde\x80\x92\xf4\x1c\x1a\x9d\xc6\x0b\xf4O\xdf\xf4\xdbh\x00\xc4\xfd\x8c\x1b'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 11:52:07.454573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0.run(str_0)
        raise AssertionError
    except AssertionError:
        pass
    except:
        raise AssertionError


# Generated at 2022-06-25 11:52:15.940032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars = {'hostvars' : {'host1' : {'ansible_play_hosts_all' : '[host1], [host2]'}}}
    lookup_module_1 = LookupModule('')
    lookup_module_1.set_options(var_options=myvars)
    assert lookup_module_1.run(['ansible_play_hosts_all']) == [u'[host1], [host2]']


# Generated at 2022-06-25 11:52:20.602314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '\x1f'
    bytes_0 = b'Q\xf2\xa2\x7f\x9d'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 11:52:29.152366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run("terms", "variables")
    var_1 = lookup_module_0.run("terms", "variables", "kwargs")
    var_2 = lookup_module_0.run("terms", "variables", "kwargs")
    var_3 = lookup_module_0.run("terms", "variables")
    var_4 = lookup_module_0.run("terms", "variables", "kwargs")
    var_5 = lookup_module_0.run("terms", "variables", "kwargs")


from ansible.plugins.lookup import LookupModule
from ansible.parsing.splitter import parse_kv
from ansible.utils.listify import listify_lookup_plugin_terms


# Generated at 2022-06-25 11:52:38.987097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict(a='aaaaaaaa')
    dict_1 = dict(b='bbbbbb')
    dict_2 = dict(c='cccccccc')
    dict_3 = {'d': 'ddddddd', 'e': 'eeeeeee', 'f': 'fffffff', 'g': 'ggggggg'}
    dict_4 = dict_3
    dict_5 = dict(h='hhhhhhhh')
    dict_6 = {'i': 'iiiiii', 'j': 'jjjjjjjjj', 'k': 'kkkkkkkkkkkkk', 'l': 'llllllllllllllllllllll'}

# Generated at 2022-06-25 11:53:15.638906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 'ansible_play_hosts'
    var_1 = 'ansible_play_batch'
    var_2 = 'ansible_play_hosts_all'
    var_3 = getattr(self._templar, '_available_variables', {})
    self.set_options(var_4=variables, direct=kwargs)
    var_5 = self.get_option('default')
    var_6 = []
    for var_7 in terms:
        if not isinstance(var_7, string_types):
            raise AnsibleError('Invalid setting identifier, "%s" is not a string, its a %s' % (var_7, type(var_7)))

# Generated at 2022-06-25 11:53:20.637612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(str_0)



# Generated at 2022-06-25 11:53:32.175461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = AnsibleUndefinedVariable
    var_0 = module_0()
    module_1 = str
    var_1 = module_1(['hostvars'])
    module_2 = str
    var_2 = module_2({'hostvars': 'hostvars'})
    module_3 = str
    var_3 = module_3(['hostvars'])
    module_4 = str
    var_4 = module_4('hostvars')
    module_5 = AnsibleUndefinedVariable
    var_5 = module_5()
    module_6 = str
    var_6 = module_6('hostvars')
    module_7 = AnsibleUndefinedVariable
    var_7 = module_7()
    module_8 = str
    var_8 = module_8('hostvars')

# Generated at 2022-06-25 11:53:36.871715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = ''
    bytes_1 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_1 = LookupModule(bytes_1)
    str_2 = ''
    lookup_module_1.run(str_2)


# Generated at 2022-06-25 11:53:45.352099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    string_0 = ''

# Generated at 2022-06-25 11:53:54.795829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin_0 = LookupModule(b'\x02\x96\x1a\xea\x01\x11\x10\x1c\x96\xaf\x80\x1b\x99\x88\xdb\xbb\x9b\x88\xdb\xbb\xb0\x82\x81\x11')
    lookup_plugin_0.lookup_module_0.set_options(var_options=None, direct=None)

# Generated at 2022-06-25 11:54:05.486307
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    result_0 = lookup_module_0.run(terms=var_0)
    assert result_0 == ('',), 'Test 1 failed'

    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(terms=var_0, variables=var_0)
    assert result_1 == ('',), 'Test 1 failed'

    lookup_module_2 = LookupModule()
    result_2 = lookup_module_2.run(terms=var_0, variables=var_0)
    assert result_2 == ('',), 'Test 2 failed'

    lookup_module_3 = LookupModule()
    result_3 = lookup_module_3.run(terms=var_0, variables=var_0)

# Generated at 2022-06-25 11:54:14.123601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'J$\x9c\xda\xf3\x01\x0f\xbb\xf7{\x89\xc6'
    bytes_0 = b'\x8d\x90\xb6*\xfa\x0f\x89g\xda\xc9\x0b\x8b\xfc\xcc\x98\xda\x8d\xb2'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 11:54:18.557886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = test_LookupModule_run.__closure__[0].cell_contents
    v = {}
    v['some_var'] = 'value'
    assert module.run([ 'some_var' ], variables=v) == [ 'value' ]
    # In older Ansible versions, lookup did not produce errors
    # if a variable was not defined. Now it does, but we should
    # have an option to disable the error.
    assert module.run([ 'some_var2' ], variables=v, default=[]) == []
try:
    from ansible.plugins.lookup import LookupBase
except ImportError:
    # Older Ansible version, e.g. 1.9.x
    assert module.run([ 'some_var2' ], variables=v) == [ None ]
test_LookupModule_run.__closure__

# Generated at 2022-06-25 11:54:22.448048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T')
    lookup_module_0.run([])

# Generated at 2022-06-25 11:55:29.530910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(b'\xf8\x10\xaf\x1a\xaf\x8f\x0c\x85\xb3\x94\x9a\x9a\x9f\xb1\xff\x84\xef\xb6\xee\x9b')
    var_0 = lookup_module_0.run(bytes_0, None)
    assert var_0 == 'b' or var_0 == 'i', var_0


# Generated at 2022-06-25 11:55:30.384553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule.run()

# Generated at 2022-06-25 11:55:38.838492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '\x04\x07\x1b\x1b\x1b\x1b\x11\x15\x15\x11\x1b\x04'
    var_1 = '\n\x0c\x0e\x11\x11\x12\x12\x11\x11\x11\x0e\x04'
    var_2 = '\t\x11\x04\t\x11\x04\t\x11\x0c\x0e\x11\x11\x12\x12\x11\x11\x11\x0e\x04'

# Generated at 2022-06-25 11:55:49.885650
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    eq = (test_LookupModule_run.__dict__)['eq']
    lookup_module_0 = LookupModule(b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T')
    var_4 = '\tvalue1\t'
    var_5 = lookup_module_0.run(var_4)
    eq(var_5, [])
    var_6 = '\tvalue1\t'
    var_7 = '\tvalue1\t'
    var_8 = dict()
    var_8['value1'] = 'value1'
    var_9 = lookup_module_0.run(var_6, '\tvalue1\t', var_8)
    var_10 = 'value1'

# Generated at 2022-06-25 11:55:59.432755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '"6\x18\x15\x06'
    str_1 = '-\x10\x18\x12\x1f\x0c/\x0e\x1c\x15\x14b\x05'
    lookup_module_0._templar._available_variables = {'b': '', 'a': '', 'd': [''], 'c': '', 'f': '', 'e': 0}
    lookup_module_0._templar = str_0
    lookup_module_0.set_options()
    var_0 = lookup_module_0.run('')
    lookup_module_0._templar = str_1
    var_1 = lookup_module_0.run('')

# Generated at 2022-06-25 11:56:06.607261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(str_0)


# Generated at 2022-06-25 11:56:12.185791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ''
    bytes_0 = b'\xdc\xccNlS\xb6t\xc1\x1d\x8dy\xbf~T'
    str_1 = ''
    str_2 = 'No variable found with this name: %s'

# Generated at 2022-06-25 11:56:17.898750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run({'ansible_check_mode': True}) == ['False']
    assert lookup_run({'ansible_debug': True}) == ['False']
    assert lookup_run({'ansible_delegated_vars': {'a': 'b'}}) == ['{}']
    assert lookup_run({'ansible_diff': True}) == ['True']
    assert lookup_run({'ansible_module_name': 'yum'}) == ['setup']
    assert lookup_run({'ansible_module_name': True}) == ['setup']
    assert lookup_run({'ansible_module_name': 'command'}) == ['command']
    assert lookup_run({'ansible_playbook_python': 'python'}) == ['python']

# Generated at 2022-06-25 11:56:23.886539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Term 0 is string : 'test_case_0'
    var_0 = 'test_case_0'
    # Term 1 is string : 'test_case_1'
    var_1 = 'test_case_1'
    terms = (var_0, var_1)
    lookup_module_0 = LookupModule(var_0)
    # Test case 1 - Assertion passed
    test_run(terms)
    # Test case 2 - Assertion passed
    test_run2(terms)
    # Test case 3 - Assertion passed
    test_run3(terms)
    # Test case 4 - Assertion failed
    # Can not load /tmp/ansible-test/test_module.py: No module named ansible_test
    # test_run4(terms)
    # Test case 5 - Ass

# Generated at 2022-06-25 11:56:29.248047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ''
    variables_0 = ''
    direct_0 = ''
    lookup_module_0 = LookupModule(terms_0)
    lookup_module_0.run(terms_0, variables_0, direct_0)

if __name__ == '__main__':
    test_LookupModule_run()
    print('tests passed.')