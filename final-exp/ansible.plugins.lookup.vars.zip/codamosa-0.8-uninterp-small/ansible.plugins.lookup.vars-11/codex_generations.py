

# Generated at 2022-06-25 11:48:02.440303
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['variabl' + myvar],defau='',) == 'hel'

# Generated at 2022-06-25 11:48:09.483425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options='', direct='', fail_on_undefined='')
    lookup_module_0._templar._available_variables = {'ansible_play_hosts': 'host01', 'ansible_play_batch': 'host01,host02', 'ansible_play_hosts_all': 'host01,host02', 'inventory_hostname': 'host02'}
    myvars = lookup_module_0._templar._available_variables
    lookup_module_0.get_option = lambda option: None if option == 'default' else ''
    # Call method run of class LookupModule

# Generated at 2022-06-25 11:48:20.853825
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:48:21.765889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()


# Generated at 2022-06-25 11:48:30.846359
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Tests using `return_data` and `run` method
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['name'],{'name': 'value'}) == ['value']

    # Tests passing default as an argument
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['name'],{'name': 'value'}, default='default') == ['value']

    # Tests passing default as an argument and invalid key
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['name1'],{'name': 'value'}, default='default') == ['default']

    # Tests passing default as an argument and invalid key
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:48:33.031430
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:48:38.992012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """test_LookupModule_run"""
    lookup_module_0 = LookupModule()
    # Variable part, enter your test data
    # do not modify below.

    # Test
    ## method run
    term = 'ansible_play_hosts'
    terms = [term]
    variables = None
    ret_val_0 = lookup_module_0.run(terms, variables)
    assert (ret_val_0 == ['127.0.0.1'])

    term = 'ansible_play_batch'
    terms = [term]
    variables = None
    ret_val_1 = lookup_module_0.run(terms, variables)
    assert (ret_val_1 == ['None'])

    term = 'ansible_play_hosts_all'
    terms = [term]
    variables = None

# Generated at 2022-06-25 11:48:40.674200
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:48:46.499691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_arg_1 = "variablename"
    variables_arg_1 = ""
    lookup_module_1.run(terms_arg_1, variables_arg_1)
    terms_arg_0 = "variablename"
    variables_arg_0 = ""
    lookup_module_0.run(terms_arg_0, variables_arg_0)

# Generated at 2022-06-25 11:48:54.244914
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("")
    print("#################################################################")
    print("#####                                                         #####")
    print("#####     Unit test for method run of class LookupModule     #####")
    print("#####                                                         #####")
    print("#################################################################")
    print("")

    lookup_module_0 = LookupModule()

    assert isinstance(lookup_module_0.run([]), list)

    print("")
    print("### Unittest for LookupModule is done ###")
    print("")

# Generated at 2022-06-25 11:49:07.028000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[{'variablename': 'hello', 'myvar': 'ename'}], variables=None)

# Generated at 2022-06-25 11:49:16.163170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    lookup_base_0 = LookupBase()
    lookup_base_0.set_environment({'foo': 'bar'})
    lookup_base_0.set_options({'__file__': 'vars.py', '__line__': '39', '__name__': '__main__', '__package__': None, 'environment': {'foo': 'bar'}, 'foo': 'bar'})
    lookup_base_0._templar = None
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = lookup_base_0._templar
    lookup_module_0.run(['foo'])
    lookup_module_0.run(['foo'], {'foo': 'bar'})
    lookup_module_0

# Generated at 2022-06-25 11:49:20.019273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # I'll build a dictionary of variables to use in the lookup module
    d = {'some_var': 'some_value' }
    terms_list = [ 'some_var' ]

    # I'll create my lookup module
    lookup_module = LookupModule()

    # Now I'll call the run method of my module
    result = lookup_module.run(terms_list, variables=d)

    assert result == [ 'some_value' ], "Run method of LookupModule did not return the expected result"



# Generated at 2022-06-25 11:49:26.600205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case = 0
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'hostvars': {'inventory_hostname': {'term': 'value'}}}, direct={'default':None})
    lookup_module._templar = MockTemplar(available_variables={'term': 'value'})
    assert lookup_module.run([ 'term' ], variables=MockAvailableVariables()) == [ 'value' ]



# Generated at 2022-06-25 11:49:31.526949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # default value of variable 'myvars' is assigned
    lookup_module.run('myvars')
    # default value of variable 'myvars' is assigned
    lookup_module.run('myvars', 'default')


# Generated at 2022-06-25 11:49:40.339312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = ['variablename', 'variablename']
    variables_0 = {}
    parameters_0 = {}
    lookup_module_0.set_options(**parameters_0)
    res_0 = lookup_module_0.run(term_0, variables_0)
    assert lookup_module_0._templar.available_variables is variables_0
    assert res_0 == ['hello', 'hello']



# Generated at 2022-06-25 11:49:51.834307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    value_of_variable_0 = {'some_random_key_0': 0}
    def test_run(self, terms, *args, **kwargs):
        if (self.set_options.__func__.__get__(self, LookupModule) != lookup_module_0.set_options):
            return False
        if (value_of_variable_0['some_random_key_0'] == terms):
            return True
        return False
    lookup_module_0.run = test_run.__get__(lookup_module_0, LookupModule)
    lookup_module_0.set_options(var_options=None, direct=None)
    assert_equal(lookup_module_0.run(0), True)

# Generated at 2022-06-25 11:49:59.859750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_var_args = {
        'terms': [
            'ansible_play_hosts',
            'ansible_play_batch',
            'ansible_play_hosts_all'
        ],
        'variables': {
            'ansible_play_hosts': [
                '127.0.0.1'
            ],
            'ansible_play_batch': [
                '127.0.0.1'
            ],
            'ansible_play_hosts_all': [
                '127.0.0.1'
            ]
        },
        'kwargs': {
        }
    }

    lookup_module_run_var_args['variables'] = None
    lookup_module_run_var_args['kwargs'] = None

    ret = lookup_module_

# Generated at 2022-06-25 11:50:04.864022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    lookup_module_instance.set_loader('/usr/lib/python2.7/dist-packages/ansible/library')
    lookup_module_instance.set_basedir('')

    lookup_module_instance._templar._available_variables = {"ansible_play_hosts": [u'10.5.5.5', u'10.5.5.6'], "ansible_play_batch": [u'10.5.5.5', u'10.5.5.6'], "ansible_play_hosts_all": [u'10.5.5.5', u'10.5.5.6']}

# Generated at 2022-06-25 11:50:15.654143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
        ]

    variables = {
        'ansible_play_hosts': [
            '127.0.0.1',
            '127.0.0.2'
            ],
        'ansible_play_batch': '127.0.0.1',
        'ansible_play_hosts_all': '127.0.0.2'
        }

    lookup_module_0 = LookupModule()

    ret = lookup_module_0.run(terms, variables)

    print('ret == ' + str(ret))


# Generated at 2022-06-25 11:50:33.620977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(terms=['ansible_play_hosts']) == [{u'192.168.30.11': {u'ansible_connection': u'local'}}]
    assert lookup_module_1.run(terms=['ansible_play_batch']) == [[u'192.168.30.11']]
    assert lookup_module_1.run(terms=['ansible_play_hosts_all']) == [{u'192.168.30.11': {u'ansible_connection': u'local'}}]


# Generated at 2022-06-25 11:50:43.200511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]
    variables_0 = {}
    kwargs_0 = {
        '_ansible_check_mode': True,
        '_ansible_forks': 2,
        '_ansible_module_name': '',
        '_ansible_no_log': False,
        '_ansible_verbosity': 2,
        '_ansible_version': '',
        'default': None,
        'fail_on_undefined': True,
        'newvars': [],
    }
    args = (
        terms_0,
        variables_0,
    )
    result

# Generated at 2022-06-25 11:50:48.823694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = ['hostvars']
    variables_0 = dict()
    variables_0['hostvars'] = dict()
    variables_0['hostvars']['ansible_play_hosts_all'] = ['ansible_play_hosts_all']
    variables_0['hostvars']['ansible_play_batch'] = ['ansible_play_batch']
    variables_0['hostvars']['ansible_play_hosts'] = ['ansible_play_hosts']
    ret_0 = lookup_module_1.run(terms_0, variables_0)
    assert ret_0 == [dict()]

# Generated at 2022-06-25 11:50:55.031000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = { 'ansible_play_hosts': ['localhost'], 'ansible_play_batch': ['localhost'], 'ansible_play_hosts_all': ['localhost']}
    ret = lookup_module_0.run(terms, variables)
    assert ret == [['localhost'], ['localhost'], ['localhost']]

# Generated at 2022-06-25 11:51:01.592646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test instance creation
    assert isinstance(lookup_module, LookupModule)
    # test with default args
    lookup_module.run(*[], **{'vars': {'a': '1', 'b': '2'}, 'fail_on_undefined': True}) == ['1', '2']
    # test with some args
    lookup_module.run(*['a'], **{'vars': {'a': '1', 'b': '2'}, 'fail_on_undefined': True}) == ['1']

# Generated at 2022-06-25 11:51:11.487156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Example 1
    result_1 = lookup_module_0.run(["hello"], {"myvar": "name"})
    assert result_1 == []
    # Example 2
    result_2 = lookup_module_0.run(["hello"], {"variablename": "hello", "myvar": "name"})
    assert result_2 == []
    # Example 3
    result_3 = lookup_module_0.run(["hello"], {"variablename": "hello", "myvar": "notename", "default": ""})
    assert result_3 == []
    # Example 4
    result_4 = lookup_module_0.run(["hello"], {"variablename": "hello", "myvar": "notename"}, )
    assert result_4 == []

# Generated at 2022-06-25 11:51:17.825499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'my_terms'
    variables_0 = 'my_variables'
    ret = lookup_module_0.run(terms_0, variables_0)
    return None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:51:26.217328
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    vars = dict()
    vars['inventory_hostname'] = 'localhost'
    myvars = dict()
    myvars['hostvars'] = dict()
    myvars['hostvars']['localhost'] = dict()
    myvars['hostvars']['localhost']['ansible_connection'] = 'local'
    myvars['hostvars']['localhost']['ansible_host'] = 'localhost'
    myvars['hostvars']['localhost']['ansible_user'] = 'root'
    myvars['hostvars']['localhost']['ansible_ssh_private_key_file'] = '~/.ssh/id_rsa'

# Generated at 2022-06-25 11:51:31.351117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['www', 'nice', 'hosts']
    variables = {
        'foo': 'bar',
        'hostvars': {
            'somehost': {
                'www': 'www.somehost.com',
                'nice': 'nice.somehost.com'
            },
            'somehost2': {
                'www': 'www.somehost2.com',
                'nice': 'nice.somehost2.com'
            }
        },
        'inventory_hostname': 'somehost2'
    }
    direct = {}

    lookup_module.run(terms, variables=variables, direct=direct)

# Generated at 2022-06-25 11:51:41.950135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars = {'var_name_0': 0}
    myvars['hostvars'] = {'inventory_hostname_0': {'host_var_name_0': 0}}
    lookup_module_0 = LookupModule()
    lookup_module_0._templar._available_variables = myvars
    lookup_module_0._templar._template_data = myvars
    lookup_module_0.set_options(var_options=myvars, direct={})
    lookup_module_0.get_option('default') == None
    lookup_module_0.run(['var_name_0'])
    lookup_module_0.run(['var_name_1'])
    lookup_module_0.run(['var_name_2'], default=0)
    lookup_

# Generated at 2022-06-25 11:52:20.206315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # illegal variable name passed
  lookup_module_1 = LookupModule()
  terms_1 = [2]
  variables_1 = None
  kwargs_1 = dict()
  try:
    lookup_module_1.run(terms_1,variables_1, **kwargs_1)
    assert(False)
  except:
    pass

  # variable not present
  lookup_module_2 = LookupModule()
  terms_2 = ['test_var']
  variables_2 = None
  kwargs_2 = dict()
  try:
    lookup_module_2.run(terms_2,variables_2, **kwargs_2)
    assert(False)
  except:
    pass

  # variable present
  lookup_module_3 = LookupModule()

# Generated at 2022-06-25 11:52:24.936495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    lookup_module_0.run(terms)


# Generated at 2022-06-25 11:52:30.440067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible_play_hosts', "ansible_play_batch", "ansible_play_hosts_all"]
    variables = {'ansible_play_hosts': "localhost", 'ansible_play_batch': "localhost", 'ansible_play_hosts_all': "localhost"}
    kwargs = {}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result is not None


# Generated at 2022-06-25 11:52:34.262031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert(lookup_module_1.run("terms", "variables", "default") == None)

# Generated at 2022-06-25 11:52:36.382377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = 'test_0'
    result = lookup_module_0.run(terms)


# Generated at 2022-06-25 11:52:40.597521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Testing module is_valid_param of class LookupModule

# Generated at 2022-06-25 11:52:45.877694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('#####', 'test_LookupModule_run', '#####')
    lookup_module_0 = LookupModule()
    test_term_0 = 'test_term_0'
    expect_result_0 = 'test_result_0'
    
    lookup_module_0._templar._available_variables = {test_term_0: expect_result_0}
    result_0 = lookup_module_0.run([test_term_0])
    print(result_0)
    assert result_0[0] == expect_result_0


# Generated at 2022-06-25 11:52:49.176965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = 'ansible_play_hosts'
    lookup_module_run_0 = LookupModule().run(terms=terms_0)
    assert isinstance(lookup_module_run_0, list) is True
    assert lookup_module_run_0 == ['localhost']


# Generated at 2022-06-25 11:52:55.490878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with invalid num of args
    try:
        lookup_module_0.run()
        assert True
    except TypeError:
        assert False
        return
    # Test with invalid args
    try:
        lookup_module_0.run("", [])
        assert True
    except TypeError:
        assert False
        return
    # Test with valid args
    lookup_module_0.run("", "")


# Generated at 2022-06-25 11:52:58.142821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Assertion for call to method run of class LookupModule
    assert True

# Generated at 2022-06-25 11:53:31.187019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    list_0 = [var_0, var_0, lookup_module_0]
    dict_0 = None
    bytes_0 = b'~\n\x96\xb6\xf7;\xbc\xda\xdf\x95\x88P'
    dict_1 = {list_0: var_0, list_0: bytes_0}
    var_1 = lookup_run(dict_1, dict_0)
    var_2 = lookup_run(list_0, **dict_0)

# Generated at 2022-06-25 11:53:34.440279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = set()
    var_1 = lookup_run(lookup_module_0)
    var_0.add(var_1)
    list_0 = sorted(var_0)
    var_2 = lookup_run(list_0, **dict_0)

# Generated at 2022-06-25 11:53:35.366142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:53:43.837469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module__0 = LookupModule()
    var_0 = lookup_run(lookup_module__0)
    lookup_module__1 = LookupModule()
    var_1 = lookup_run(lookup_module__1, **dict_0)
    lookup_module__2 = LookupModule()
    var_2 = lookup_run(lookup_module__2, **dict_0)
    lookup_module__3 = LookupModule()
    var_3 = lookup_run(lookup_module__3, **dict_0)


# Generated at 2022-06-25 11:53:49.615058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    list_ = ['var', 'var', lookup_module]
    dict_ = None
    bytes_ = b'~\n\x96\xb6\xf7;\xbc\xda\xdf\x95\x88P'
    dict_1 = {list_: var, list_: bytes_}
    var_1 = lookup_run(dict_1, dict_)
    var_2 = lookup_run(list_, **dict_)

# Generated at 2022-06-25 11:53:59.794284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms_0 = 'terms_0'
    variables_0 = 'variables_0'
    kwargs_0 = 'kwargs_0'
    lookup_module_0 = LookupModule()
    lookup_module_0._templar.available_variables = variables_0
    lookup_module_0.set_options(var_options=variables_0, direct=kwargs_0)
    lookup_module_0.get_option('default')
    lookup_module_0._templar._available_variables = dict_0
    lookup_module_0.get_option('default')
    lookup_module_0.get_option('default')
    lookup_module_0._templar.template(term_0, fail_on_undefined=True)
    lookup_module_0.get

# Generated at 2022-06-25 11:54:03.894692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [dict, list]
    variables_0 = lookup_run(terms_0)
    kwargs_0 = {'variables': variables_0}
    assert lookup_module_0.run(terms_0, **kwargs_0) == ['a', 'b', 'c']


# Generated at 2022-06-25 11:54:06.171856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:54:11.078492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    lookup_module_0.run(var_0)

# Generated at 2022-06-25 11:54:16.456997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    list_0 = [var_0, var_0, lookup_module_0]
    dict_0 = None
    bytes_0 = b'~\n\x96\xb6\xf7;\xbc\xda\xdf\x95\x88P'
    dict_1 = {list_0: var_0, list_0: bytes_0}
    var_1 = lookup_run(dict_1, dict_0)
    var_2 = lookup_run(list_0, **dict_0)
    str_0 = lookup_run(var_2)
    str_1 = lookup_run(var_1)
    term_0 = lookup_run()
    var_3 = lookup

# Generated at 2022-06-25 11:55:23.651142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    list_0 = [var_0, var_0, lookup_module_0]
    dict_0 = None
    bytes_0 = b'~\n\x96\xb6\xf7;\xbc\xda\xdf\x95\x88P'
    dict_1 = {list_0: var_0, list_0: bytes_0}
    var_2 = lookup_run(dict_1, dict_0)
    var_3 = lookup_run(list_0, **dict_0)
    lookup_run(var_0, var_2)
    var_4 = lookup_run(dict_0, var_2)

# Generated at 2022-06-25 11:55:33.282246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs = {}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    list_0 = [var_0, var_0, lookup_module_0]
    dict_0 = None
    lookup_module_0.run(list_0, **dict_0)
    dict_1 = {list_0: var_0, list_0: dict_0}
    var_1 = lookup_run(dict_1, dict_0)
    var_2 = lookup_run(list_0, **dict_0)


# Generated at 2022-06-25 11:55:37.832962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    list_0 = [var_0, var_0, lookup_module_0]
    dict_0 = None
    bytes_0 = b'~\n\x96\xb6\xf7;\xbc\xda\xdf\x95\x88P'
    dict_1 = {list_0: var_0, list_0: bytes_0}
    var_1 = lookup_run(dict_1, dict_0)
    var_2 = lookup_run(list_0, **dict_0)

# Generated at 2022-06-25 11:55:43.714440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'variablename'
    lookup_module_0 = LookupModule()
    str_0 = lookup_module_0.run(terms=[term, *list(list(list()))])

# Generated at 2022-06-25 11:55:50.555485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_3 = lookup_run(lookup_module_1)
    dict_2 = None
    lookup_module_1.terms = dict_2
    dict_3 = {var_3: var_3}
    var_4 = lookup_run(dict_3, dict_2)
    lookup_module_1.variables = dict_2
    dict_4 = {var_3: var_3, var_3: dict_2}
    dict_3 = None
    var_5 = lookup_run(dict_4, dict_3)
    var_6 = lookup_run(var_5, **dict_3)
    dict_5 = {}
    dict_6 = {var_3: dict_5}
    dict_3 = dict_6

# Generated at 2022-06-25 11:55:58.164741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_baz(lookup_module_0)
    list_0 = [var_0, var_0, lookup_module_0]
    dict_0 = None
    list_1 = [var_2, var_2, var_2]
    dict_1 = {var_0: list_0, var_0: list_1}
    var_1 = lookup_run(dict_1, dict_0)
    var_2 = lookup_run(list_0, **dict_0)


# Generated at 2022-06-25 11:56:09.087073
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test the results of calling run() (LookupModule#run)
    var_0 = lookup_run()
    var_1 = lookup_run()
    var_2 = lookup_run()
    var_3 = lookup_run()
    var_4 = lookup_run()
    var_5 = lookup_run()
    var_6 = lookup_run()
    var_7 = lookup_run()
    var_8 = lookup_run()
    var_9 = lookup_run()
    var_10 = lookup_run()
    var_11 = lookup_run()
    var_12 = lookup_run()
    var_13 = lookup_run()
    var_14 = lookup_run()
    var_15 = lookup_run()
    var_16 = lookup_run()
    var_17 = lookup_run()
    var

# Generated at 2022-06-25 11:56:15.516492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_term_0 = list()
    lookup_variables_0 = dict()
    lookup_kwargs_0 = dict()
    lookup_result_0 = lookup_module_0.run(lookup_term_0, lookup_variables_0, **lookup_kwargs_0)
    assert len(lookup_result_0) == 0
    assert lookup_result_0 == []
    lookup_term_1 = list()
    lookup_kwargs_1 = {"default": str}
    lookup_result_1 = lookup_module_0.run(lookup_term_1, lookup_variables_0, **lookup_kwargs_1)
    assert len(lookup_result_1) == 0
    assert lookup_result_1 == []
    lookup_term_

# Generated at 2022-06-25 11:56:17.870092
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = [lookup_module_1, lookup_module_1, lookup_module_1]
    dict_2 = None
    var_3 = lookup_module_1.run(list_1, dict_2)



# Generated at 2022-06-25 11:56:18.872574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()
