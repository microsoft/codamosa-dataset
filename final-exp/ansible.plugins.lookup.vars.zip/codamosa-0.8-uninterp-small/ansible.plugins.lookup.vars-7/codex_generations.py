

# Generated at 2022-06-25 11:48:07.902805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    # check if it can pass when provided with local variables
    myvar = 'helloansible'
    terms = 'variablename'
    default = None
    variables = {'variablename': 'hello'}
    assert lookup_instance.run(terms=terms, default=default, variables=variables)

    terms = 'variablename'
    default = None
    variables = {'variablename': 'hello'}
    assert lookup_instance.run(terms=terms, default=default, variables=variables)

    terms = 'variablename'
    variables = {'variablename': 'hello'}
    assert lookup_instance.run(terms=terms, variables=variables)

    # check if it can raise AnsibleError when an invalid type is provided

# Generated at 2022-06-25 11:48:11.781349
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    myvars = {}
    lookup_module._templar._available_variables = myvars
    terms = [u'variablename', u'myvar']
    variables = None
    lookup_module.run(terms, variables)


# Generated at 2022-06-25 11:48:23.354641
# Unit test for method run of class LookupModule
def test_LookupModule_run():


    terms = ['x']
    with pytest.raises(AnsibleError) as context:
        lookup_module_0.run(terms)
    assert 'Invalid setting identifier, "x" is not a string, its a <class \'int\'>' in str(context.value)


    terms = ['ansible_play_hosts_all']
    lookup_module_0.run(terms)


    terms = ['ansible_play_hosts_all']
    variables = {'ansible_play_hosts_all': 'x'}
    lookup_module_0.run(terms, variables)


    terms = ['ansible_play_hosts_all']
    with pytest.raises(AnsibleError) as context:
        lookup_module_0.run(terms, {'x': 'x'})

# Generated at 2022-06-25 11:48:28.074058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=[], variables=None, **{'direct': {}})
    assert result == []

# Generated at 2022-06-25 11:48:32.489928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test
    lookup_module_0 = LookupModule()
    terms_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables_0 = None
    assert lookup_module_0.run(terms_0, variables_0) == [
        ['localhost']
    ]


# Generated at 2022-06-25 11:48:36.538213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert type(lookup_module_0.run()) is list

# Generated at 2022-06-25 11:48:46.353117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}

    try:
        with open('/opt/ansible/bin/ansible-test-data/lookup-plugins/vars/test_case_0.json') as f:
            data = json.load(f)
    except IOError as e:
        assert False, "Couldn't read file: %s" % str(e)

    try:
        terms_0 = data.get('terms_0')
    except KeyError as e:
        assert False, "Couldn't find expected key 'terms_0' in JSON data, " \
            "exception was: %s" % str(e)


# Generated at 2022-06-25 11:48:53.491012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_case = {
        'terms': 'variablename',
        'variables': {
                'variablename': 'hello'
        },
        'default': None
    }
    result = lookup_module.run(**test_case)

    expected = ['hello']
    assert result == expected, 'Expected: %s, Got: %s' % (expected, result)


# Generated at 2022-06-25 11:48:54.324986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() == None

# Generated at 2022-06-25 11:49:02.162291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'variablename', u'ansible_play_hosts', u'ansible_play_batch', u'ansible_play_hosts_all']
    variables_0 = {u'ansible_play_hosts_all': [u'test_host'], u'variablename': u'hello', u'ansible_play_hosts': [u'test_host'], u'ansible_play_batch': 0, u'inventory_hostname': u'test_host'}
    myvar_0 = u'ename'
    default_0 = None
    kwargs_0 = {u'default': default_0}
    elements_0 = raw

# Generated at 2022-06-25 11:49:15.666906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    expected_result = ['hello']

    terms = ['variablename']
    variables = {'myvar': 'ename', 'variablename': 'hello'}
    lookup_module_0.run(terms, variables)

    actual_result = lookup_module_0.run(terms, variables)

    assert expected_result == actual_result

# Generated at 2022-06-25 11:49:16.858451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result_0 = LookupModule.run(test_case_0)
    assert result_0 == None


# Generated at 2022-06-25 11:49:18.229707
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test case #0
    # test_case_0()
    assert True

# Generated at 2022-06-25 11:49:28.261909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule(loader=None, variables=dict(color='red', ansible_play_hosts=None, ansible_play_batch=None, ansible_play_hosts_all=None, myvar='ename', variablename='hello', item=None))
    lookup.set_options(var_options=None, direct=dict(default=None))

# Generated at 2022-06-25 11:49:33.316555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['hello']
    variables = {'hello': 'ansible'}
    ret = lookup_module_0.run(terms, variables)
    assert ret[0] == 'ansible'
    return

# Test with nested variables

# Generated at 2022-06-25 11:49:35.319025
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms=None, variables=None, )
    assert result == []



# Generated at 2022-06-25 11:49:37.518527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run(["variablename"]) == []


# Generated at 2022-06-25 11:49:48.662608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ansible_result_0 = lookup_module.run(['ansible_user', 'ansible_host', 'ansible_connection'])
    assert ansible_result_0 == [u'root', u'localhost', u'local'], 'Expected ["root","localhost","local"], but got %s' % ansible_result_0
    ansible_result_1 = lookup_module.run(['foo', 'bar'], {'ansible_user': 'root', 'ansible_host': 'localhost', 'ansible_connection': 'local', 'foo': 'baz', 'bar': 'bam'})
    assert ansible_result_1 == ['baz', 'bam'], 'Expected ["baz","bam"], but got %s' % ansible_result_1

# Unit

# Generated at 2022-06-25 11:49:55.044700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1._templar._available_variables = {'inventory_hostname': 'host', 'hostvars': {'host': {'vars': {'x': 'xx'}}}}
    terms_1 = ['vars', 'inventory_hostname']
    assert lookup_module_1.run(terms_1) == ['host', 'host']

# Generated at 2022-06-25 11:49:55.672897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

test_case_0()

# Generated at 2022-06-25 11:50:03.979977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    # TODO : Unit Test this...


# Generated at 2022-06-25 11:50:11.199938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = []
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms_0, variables_0)

# Test program
if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_LookupModule_run()
    print("Test done")

# Generated at 2022-06-25 11:50:20.704115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Test 1
  lookup_module_1 = LookupModule()
  list_1 = ["variablename", "myvar"]
  dict_1 = {"variablename": "hello", "myvar": "ename"}
  var_1 = lookup_module_1.run(list_1, dict_1)
  assert var_1 == ['hello']
  
  # Test 2
  lookup_module_2 = LookupModule()
  list_2 = ["variablnotename", "myvar"]
  dict_2 = {"variablename": "hello", "myvar": "notename"}
  var_2 = lookup_module_2.run(list_2, dict_2)
  assert var_2 == ['']
  
  # Test 3
  lookup_module_3 = LookupModule()
  list_

# Generated at 2022-06-25 11:50:31.393994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    import ansible

    class TestRun(unittest.TestCase):

        @unittest.skipIf(ansible.__version__ < '2.5', 'only valid for Ansible 2.5 and higher')
        @patch('ansible.plugins.lookup.LookupModule.run')
        def test_run(self, mock_run):
            mock_run.return_value = 'default'

            list_0 = []
            lookup_module_0 = LookupModule()
            var_0 = lookup_run(list_0)
            # Testing if the call to run() worked correctly
            mock_run.assert_called_with(list_0)

# Generated at 2022-06-25 11:50:34.719266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  input_0 = []
  lookup_module_0 = LookupModule()
  lookup_module_0.run(input_0)


# Generated at 2022-06-25 11:50:37.239916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:50:38.789268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0_0.run(terms, variables) == var_0


# Generated at 2022-06-25 11:50:44.151849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f_0 = 'run'
    list_0 = []
    lookup_module_0 = LookupModule()
    if hasattr(lookup_module_0, f_0):
        func = getattr(lookup_module_0, f_0)
        func(list_0)
    else:
       raise Exception("Method {!r} not implemented in class {!r}".format(f_0, lookup_module_0.__class__.__name__))

# Generated at 2022-06-25 11:50:46.478881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    if var_0 != []:
        raise Exception("Test failed")	


# Generated at 2022-06-25 11:50:50.345717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['sub_var'] = 12
    dict_1['variablename'] = dict_2
    dict_0['myvar'] = 'ename'
    lookup_module_run_0 = lookup_module_0.run(list_0, dict_0)
    assert lookup_module_run_0 == [12]

# Generated at 2022-06-25 11:51:05.763723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "Test method not implemented"


# Generated at 2022-06-25 11:51:10.867056
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test variable assignment with custom error message
    var_term = []
    # TODO: add more assertions
    # assertEquals(expected, LookupModule.run(terms, variables, **kwargs))
    #throw NotImplementedError()

# Generated at 2022-06-25 11:51:21.009208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    myvars_0 = {1: 'q', 2: 'k', 3: 'g', 4: 'l', 5: 'j', 6: 't', 7: 'e', 8: 'a', 9: 'v', 10: 'o', 11: 'r', 12: 'a', 13: 't', 14: 'i', 15: 'b', 16: 'l', 17: 'e', 18: 's'}
    default_0 = 'q'
    list_0 = []
    var_1 = lookup_module_0.run(list_0, myvars_0, default='q')
    assert var_1 == ['q']


# Generated at 2022-06-25 11:51:26.022809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    #expected = ['hello', 'hello']
    expected = []
    with patch.object(LookupModule, 'run', return_value=expected):
        actual = lookup_module_0.run(list_0)
    assert actual == expected

if __name__ == '__main__':
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-25 11:51:29.360600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Unit test')
    lookup_module_1 = LookupModule()
    list_1 = []
    var_1 = lookup_run(list_1)


# Generated at 2022-06-25 11:51:39.726872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # variables
    terms=[
        "kubernetes_service",
        "kubernetes_host",
        "kubernetes_port"
    ]

# Generated at 2022-06-25 11:51:42.813711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 0


# Generated at 2022-06-25 11:51:49.949093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run.
    """
    # Test run with default arguments of function run
    # Function signature: run(self, terms, variables = None, **kwargs)
    # Default arguments:
    #   terms = <No default value>
    #   variables = None
    #   **kwargs = <No default value>
    # Example:
    #   lookup_module_0 = LookupModule()
    #   lookup_module_0.run(list_0)
    #   lookup_module_0.run(list_0, variables = None)
    #   lookup_module_0.run(list_0, variables = None, **kwargs = <No default value>)

    # Call function run
    # Parameter list: list_0
    # Parameter variables: None
    # Parameter **kwargs: <No default value

# Generated at 2022-06-25 11:51:50.700730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() is ()

# Generated at 2022-06-25 11:51:56.564700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:52:27.500635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    var_0 = lookup_module_0.run(list_0)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:52:31.183806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    terms_0 = list_0
    var_0 = lookup_module_0.run(terms_0)


# Generated at 2022-06-25 11:52:35.777152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(pattern=list_0)
    assert ret_0 == []


# Generated at 2022-06-25 11:52:41.525880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_1 = []
    var_1 = lookup_module_1.run(list_1)
    assert var_1 == []

# Generated at 2022-06-25 11:52:43.857093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    assert isinstance(var_0, list)


# Generated at 2022-06-25 11:52:51.718965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    var_0 = None
    var_1 = vars()
    var_2 = hash(var_1)
    var_3 = id(var_1)
    var_4 = 'Hello World!'
    var_5 = type(var_4)
    var_6 = type(var_0)
    lookup_module_0 = LookupModule()
    var_7 = lookup_module_0.run(terms_0)
    var_8 = 'root'
    lookup_module_1 = LookupModule()
    var_9 = lookup_module_1.run(terms_0)
    var_10 = lookup_module_1.run(terms_0)
    var_11 = type(var_10)
    var_12 = type(var_9)

# Generated at 2022-06-25 11:52:54.667468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    list_1 = []
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0)
    lookup_module_0.run(list_1)
    test_case_0()

# Generated at 2022-06-25 11:53:02.837392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = lookup_module_class_0()
    str_0 = "ansible_play_hosts"
    str_1 = "ansible_play_batch"
    str_2 = "ansible_play_hosts_all"
    terms_0 = [str_0, str_1, str_2]
    lookup_module_run(lookup_module_0, terms_0)
    assert True


# Generated at 2022-06-25 11:53:09.779901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = [{"_terms": "ansible_play_hosts", "default": "empty"}]
    vars_0 = {"ansible_play_hosts": ["127.0.0.1"]}
    ret_0 = LookupModule().run(args_0, vars_0)
    assert ret_0 == ["127.0.0.1"]

# Generated at 2022-06-25 11:53:11.031008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = []
    lookup_module_1 = LookupModule()
    assert isinstance(lookup_run(list_1), list)

# Generated at 2022-06-25 11:54:15.746402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiation of class object LookupModule
    lookup_module_instance = LookupModule()
    # Assigning argument to variable lookup_module_0
    lookup_module_0 = ["variablename", "myvar"]
    # Variable myvar is assigned the value "ename"
    myvar = "ename"
    # Variable variablename is assigned the value "hello"
    variablename = "hello"
    # Variable lookup_module_1 is assigned the value of method run of class LookupModule with lookup_module_0 as parameters
    lookup_module_1 = lookup_module_instance.run(lookup_module_0)
    # Variable lookup_module_2 is assigned the value of variable lookup_module_1 index 0
    lookup_module_2 = lookup_module_1[0]
    # Assert if "hello" is

# Generated at 2022-06-25 11:54:18.477404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables)
    var_1 = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 11:54:21.707146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = None
    assert  ret == 0

# Generated at 2022-06-25 11:54:23.611618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)

test_case_0()


# Generated at 2022-06-25 11:54:30.034138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    # Change to if in order to skip test
    if False:
        dict_0['hostvars'] = dict_0['inventory_hostname'] = 'hostname'
    var_0 = not hasattr(lookup_module_0, '_templar')
    lookup_module_0._templar = dict_0
    list_0 = lookup_module_0.run(list_0)
    var_0 = lookup_module_0._templar
    assert var_0 is dict_0

# Generated at 2022-06-25 11:54:39.832883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars_0 = {b'inventory_hostname': b'foobar', b'anvar': b'something'}
    terms_0 = [b'anvar']
    variables_0 = {b'_raw_params': b'anvar'}
    list_0 = [b'anvar']

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms_0, variables_0, **{b'direct': {b'default': None}}) == list_0


# Generated at 2022-06-25 11:54:43.740576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  list_0 = []
  lookup_module_0 = LookupModule()
  lookup_module_0._templar = templar_0 = object()
  dir(lookup_module_0)
  var_0 = lookup_run(list_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:54:45.301237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = lookup_module_1 = LookupModule()
    result = lookup_module_1.run(['foo', 'bar'])
    assert result == [None, None]

# Generated at 2022-06-25 11:54:57.143297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    terms_0 = []
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == ['test_value_0']
    terms_0 = ['test_value_1']
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == ['test_value_0']
    terms_0 = ['test_value_1', 'test_value_2']
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == ['test_value_0']
    terms_0 = ['test_value_1', 'test_value_2', 'test_value_3']
    var_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:55:04.709853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    vars = {}
    vars['ansible_fqdn'] = 'localhost'
    vars['ansible_hostname'] = 'localhost'
    vars['ansible_play_hosts'] = ['localhost']
    vars['ansible_play_batch'] = ['localhost']
    lookup_module = LookupModule()
    val = lookup_module.run(terms=['vars_test_var'], variables=vars)

    assert val == ['testhost']

    val = lookup_module.run(terms=['vars_test_var', 'ansible_fqdn'], variables=vars)

    assert val == ['testhost', 'localhost']


# Generated at 2022-06-25 11:57:18.210810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['key']
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    assert var_0 == []


# Generated at 2022-06-25 11:57:21.458539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({'var_options': {'ansible_play_hosts': ['localhost']}})
    lookup_module_0._templar.available_variables = {'ansible_play_hosts': ['localhost']}
    # evaluate test case 0
    test_case_0()

# Generated at 2022-06-25 11:57:22.874473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret_val = lookup_module_0.run()
    print(ret_val)

# Generated at 2022-06-25 11:57:25.302718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    assert var_0
    assert len(var_0) == 0


# Generated at 2022-06-25 11:57:26.380842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = 2
    y = 3
    assert LookupModule.run() == x+y


# Generated at 2022-06-25 11:57:32.552463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test args
    list_0 = []
    # Test and verify the result
    try:
        lookup_module_0.run(list_0)
        assert False
    except:
        assert True


# Generated at 2022-06-25 11:57:35.592151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = []
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 11:57:38.724505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(list_0)
    assert var_0 == []

# Generated at 2022-06-25 11:57:40.321672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    list_0.append('foo')

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == []

# Generated at 2022-06-25 11:57:47.832315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    myvars = {'inventory_hostname': 'foo', 'hostvars': {'bar': {'test_var': 'bar'}}, 'test_var': 'foo'}
    list_0 = ['test_var', 'hostvars', 'foo']
    dict_0 = {'var_options': myvars, 'direct': {'default': None}}
    lookup_module_0.set_options(**dict_0)
    assert lookup_module_0.run(list_0, **{'variables': myvars}) == ['foo', {'bar': {'test_var': 'bar'}}, 'foo']

if __name__ == '__main__':
    test_LookupModule_run()