

# Generated at 2022-06-25 11:48:05.745673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['variablename', 'myvar']
    ret_val_0 = lookup_module_0.run(terms_0)
    assert ret_val_0 == ['hello', 'ename']


# Generated at 2022-06-25 11:48:09.101572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()
# Local Variables:
# indent-tabs-mode: nil
# End:
# vim: ai et sw=4 ts=4

# Generated at 2022-06-25 11:48:17.948932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_0 = {'variables': {'b': 132, 'a': 3}, 'default': None, 'kwargs': {'_ansible_check_mode': False, '_ansible_no_log': False, '_ansible_debug': False, '_ansible_diff': False}, 'terms': ['a', 'b']}

    result_0 = lookup_module_0.run(**args_0)
    assert type(result_0) is list
    assert result_0 == [3, 132]


# Generated at 2022-06-25 11:48:20.802279
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._templar = '9_variables'
    assert lookup_module_0.run('_terms_') == '_terms_'

# Generated at 2022-06-25 11:48:27.404054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader(dict())
    lookup_module_1.set_environment(dict())
    terms_1 = [dict()]
    variables_1 = dict()
    kwargs_1 = dict()
    try:
        assert isinstance(lookup_module_1.run(terms=terms_1, variables=variables_1, **kwargs_1), list)
    except AssertionError:
        raise AssertionError('Cannot assert type of result of "LookupModule.run".')

# Generated at 2022-06-25 11:48:33.202234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {
        'f2_1': 'ansible_play_hosts',
    }
    variables_0 = {
        'f2_1': 'ansible_play_hosts',
    }
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 11:48:45.288912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Initialize variable term with value 'ansible_play_batch'
    term = 'ansible_play_batch'
    # Initialize variable terms with string value 'ansible_play_batch'
    terms = 'ansible_play_batch'
    # Initialize variable myvars with value {}
    myvars = {}
    # Assign value for hostvars to myvars -> {'hostvars': {} }
    myvars['hostvars'] = {}
    # Assign value for inventory_hostname to myvars -> {'hostvars': {}, 'inventory_hostname': '10.127.169.100' }
    myvars['inventory_hostname'] = '10.127.169.100'
    # Assign value for ansible_play_batch to

# Generated at 2022-06-25 11:48:50.724661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # See if no exception is raised when calling run
    assert lookup_module.run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"], {}, {})!=None

# Generated at 2022-06-25 11:48:54.589336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=['ansible_play_hosts'], variables={'hostvars':{'localhost': {'ansible_play_hosts': 'ansible_play_hosts'}}, 'inventory_hostname': 'localhost'})


# Generated at 2022-06-25 11:48:58.509385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]

    variables = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]

    kwarg

# Generated at 2022-06-25 11:49:12.630430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["variablename", "variables", "variableswithnestedname", "ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all", "allvariablewithsubvar"]
    variables = {"variablename": "hello", "myvar": "ename", "variablename": {"sub_var": 12}, "inventory_hostname": "somehost"}
    kwargs = {"default": "default"}
    assert lookup_module_0.run(terms, variables, **kwargs) == ['hello', 'hello', '{"sub_var": 12}', ['somehost'], ['somehost'], [['somehost']], '12']

# Generated at 2022-06-25 11:49:19.859036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    myvars = {}
    templar = {}

# Generated at 2022-06-25 11:49:27.469874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['pre_ansible_play_hosts', 'ansible_play_hosts_all']
    test_0 = lookup_module_0.run(terms_0, ansible_play_hosts='pre_ansible_play_hosts', ansible_play_batch='ansible_play_batch', ansible_play_hosts_all='ansible_play_hosts_all')
    assert test_0 == ['pre_ansible_play_hosts', 'ansible_play_hosts_all']

# Generated at 2022-06-25 11:49:33.647190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = { 'ansible_play_batch': 'batch_value', 'ansible_play_hosts': 'hosts_value','ansible_play_hosts_all': 'hosts_all_value'}
    assert lookup_module.run(terms, variables) == ['hosts_value', 'batch_value', 'hosts_all_value']

# Generated at 2022-06-25 11:49:38.376487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert callable(lookup_module_0.run)


# Generated at 2022-06-25 11:49:40.545014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:49:52.015384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run(['a', 'b'], {"a": ["\"a\""], "b": ["\"b\""]}) == [['a'], ['b']]
    assert lookup_module.run(['a', 'b'], {"a": ["\"a\""], "b": ["\"b\""], "c": ["\"c\""]}, default="d") == [['a'], ['b']]
    assert lookup_module.run(['a', 'b'], {"a": ["\"a\""], "b": ["\"b\""], "c": ["\"c\""]}, default="d") == [['a'], ['b']]

# Generated at 2022-06-25 11:49:56.024116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [u'variablename']
    myvars = {u'myvar': u'ename', u'variablename': u'hello'}
    default = None

    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms, myvars, default) == [u'hello']


# Generated at 2022-06-25 11:49:56.937469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['/etc/passwd']) == ['/etc/passwd']

# Generated at 2022-06-25 11:50:00.877516
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:50:10.747427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize test object
    lookup_module_0 = LookupModule()

    # Initialize variables
    terms = []
    variables = {}

    # Call the method
    result = lookup_module_0.run(terms, variables)

    # Check the result
    assert result == []

# Generated at 2022-06-25 11:50:20.177915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    lookup_module.set_options({ 'var_options': {}, 'direct': {} })
    lookup_module._templar = DummyTemplar()
    lookup_module._templar.available_variables = { 'hostvars': {'host_a': {'ansible_play_hosts': 1, 'ansible_play_batch': 2, 'ansible_play_hosts_all': 3}}, 'inventory_hostname': 'host_a' }
    # Test
    ret = lookup_module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])
    assert ret == [1, 2, 3]


# Generated at 2022-06-25 11:50:25.099187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_1 = 'temp'
    str_0 = 'test'
    bool_0 = False
    str_3 = 'test_test'
    var_1 = lookup_run(str_1, str_0, bool_0, str_3)


# Generated at 2022-06-25 11:50:34.794444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(test_data_0)
    dict_0 = {'item': 'ansible_play_batch', 'msg': {'ansible_play_batch': ['Hi!']}}
    list_0 = [dict_0]
    assert lookup_module.run(terms=['ansible_play_batch'], variables=test_data_0) == list_0
    dict_1 = {'msg': {'ansible_play_hosts_all': ['Hi!']}}
    list_1 = [dict_1]
    assert lookup_module.run(terms=['ansible_play_hosts_all'], variables=test_data_0) == list_1

# Generated at 2022-06-25 11:50:43.294664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    tuple_1 = ()
    int_0 = 0
    list_0 = []
    str_3 = '\x0c'
    int_1 = 10
    str_4 = '\x00'
    str_5 = '\x03'
    str_6 = '\x0f'
    str_7 = '\x0b'
    str_8 = '_\x0c\x00\x00\x0b\x0c'
    str_9 = '\t'
    str_10 = '\x0e'
    str_11 = '\x01'
    str_12 = '\x0a'
    str_13 = '\x02'
    str_14 = '\n'

# Generated at 2022-06-25 11:50:49.303097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    dict_0 = {}
    dict_1 = {}
    dict_2 = {'ansible_play_hosts': '127.0.0.1', 'ansible_play_batch': 'yes', 'ansible_play_hosts_all': '127.0.0.1'}
    dict_0.update(dict_1)
    dict_0.update(dict_2)
    assert_equals(['127.0.0.1', 'yes', '127.0.0.1'], lookup_module_0.run(list_0, dict_0))

# Generated at 2022-06-25 11:51:00.428357
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:51:10.487686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n*** Start test_LookupModule_run ***\n")

    # Instantiate lookup module instance
    lookup_module = LookupModule()
    # Parameters for lookup module
    # Retrieve value of variable 'test_var'
    kw_params = {'_terms': ['test_var'],
                 '_templar': '_templar',
                 '_loader': '_loader'}
    # Template value of variable 'test_var'
    template_result = 'template_result'
    # Variables for templar
    # Template value of variable 'test_var'
    templar_vars = {'test_var': 'test_var'}
    # Error message
    error_msg = 'Invalid setting identifier, "%s" is not a string, its a %s'
    # Expected variables

# Generated at 2022-06-25 11:51:16.864503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'ansible_play_hosts': 'hihi', 'ansible_play_batch': 'ho', 'ansible_play_hosts_all': 'hehe', 'myvar': 'ename'}
    tuple_0 = ('variablename',)
    str_0 = 'variabl'
    str_1 = 'hello'
    str_2 = 'msg'
    str_3 = '{{ lookup('
    str_4 = 'ansible_play_batch'
    str_5 = 'ansible_play_hosts_all'
    str_14 = 'ansible_play_hosts'
    str_20 = ')'
    str_21 = '}}'
    tuple_1 = ('variablename',)

# Generated at 2022-06-25 11:51:27.674058
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:51:51.405891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module._templar._available_variables = {'test_var': 'ansible'}
    ret = lookup_module.run(
        ['test_var'], variables={'test_var_2': 'ansible_2'}
    )

    assert ret == ['ansible']
    # return the error if var is not set
    lookup_module._templar._available_variables = {}
    with pytest.raises(AnsibleUndefinedVariable):
        lookup_module.run(
            ['test_var'],
            variables={'test_var_2': 'ansible_2'}
        )

    # return the default if set
    lookup_module._templar._available_variables = {}

# Generated at 2022-06-25 11:51:57.549576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=[], variables=None)
    assert result == [], "Incorrect value returned by LookupModule.run"



# Generated at 2022-06-25 11:51:59.749984
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])


# Generated at 2022-06-25 11:52:07.897237
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    str_0 = 'dead but '
    str_1 = 'ohai_'
    list_0 = [str_0, str_1]
    str_2 = 'not'
    str_3 = 'dead'
    dict_0 = {str_2: str_3, str_0: lookup_module_0, str_1: str_1}
    lookup_0 = lookup_run(dict_0)
    result_0 = lookup_0.run(list_0)
    assert result_0 == lookup_run(dict_0)

# Generated at 2022-06-25 11:52:13.919330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    tuple_1 = ('a', )
    dict_0 = {'a': 'a', 'b': tuple_0, 'c': tuple_1}

    lookup_module_0.run(variables=dict_0)

# Generated at 2022-06-25 11:52:14.971718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_run()


# Generated at 2022-06-25 11:52:21.670865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    tuple_0 = ()
    str_0 = 'dead but '
    str_1 = 'ohai_'
    dict_0 = {str_0: lookup_module_1, str_1: str_1}
    var_0 = lookup_run(dict_0)
    lookup_module_1.run(tuple_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:52:31.313751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'MULTI_LINE_STRING_VAR'
    str_1 = 'ohai_'
    str_2 = 'dead but '
    str_3 = 'NestedVar'
    str_4 = "NestedVar2"
    str_5 = "boo"

    # Code to generate result for above unit test
    terms = [str_0, str_1]
    variables_dict = {str_0: '''"it
will
be
ignored
anyway"''', str_3: {"foo": '12', str_4: {"bar": "13"}}, str_1: str_1, str_5: "baz"}
    kwargs = {"default": "17"}

    # Unit test for method run of class LookupModule


# Generated at 2022-06-25 11:52:36.625256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms, variables = None, None
    lookup_module_run_0 = LookupModule(variables)
    tuple_0 = ()
    int_0 = 0
    int_1 = 1
    str_0 = 'dead but '
    str_1 = 'ohai_'
    dict_0 = {str_0: terms, str_1: str_1}
    var_0 = lookup_run(dict_0)
    lookup_module_run_1 = LookupModule(var_0)
    lookup_module_run_1 = LookupModule(tuple_0)
    tuple_1 = (int_0, int_1)


# Generated at 2022-06-25 11:52:41.605527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['lookup', 'lookup']
    variables = {}
    assert lookup_module.run(terms, variables)

# Generated at 2022-06-25 11:53:16.319558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    tuple_1 = ()
    str_2 = 'hello'
    dict_1 = {'myvar': str_2}
    dict_2 = {'myvar': str_2, 'variablename': str_2}
    var_1 = lookup_run(dict_2)
    dict_3 = {'variablename': str_2, 'myvar': str_2}
    var_2 = lookup_run(dict_3)
    dict_4 = {'variablename': str_2, 'myvar': str_2}
    dict_5 = {'variablename': str_2, 'myvar': str_2}
    var_3 = lookup_run(dict_5)

# Generated at 2022-06-25 11:53:24.606725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_attributes(LookupModule(), dict_0)
    dict_1 = {'myvar': var_0}
    dict_2 = {str_2: lookup_module_1, str_3: str_4}
    dict_3 = {str_5: dict_0, str_6: dict_1, str_7: dict_2}
    dict_4 = {str_8: lookup_module_0, str_9: var_1, str_10: dict_3}
    lookup_run(dict_4)
    dict_5 = {str_11: term, str_12: var_2, str_13: str_14, str_15: str_16}
    lookup_run(dict_5)
    dict_6 = {str_17: str_14}

# Generated at 2022-06-25 11:53:34.118952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    str_0 = 'dead but '
    str_1 = 'ohai_'
    dict_0 = {str_0: lookup_module_0, str_1: str_1}
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule(tuple_0)
    tuple_1 = ()
    str_2 = 'yourself'
    str_3 = 'need'
    bool_0 = True
    str_4 = 'so'
    str_5 = 'do'
    str_6 = 'not'
    str_7 = 'you'
    str_8 = 'I'
    str_9 = 'tell'
    str_10 = 'am'

# Generated at 2022-06-25 11:53:38.744251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    pass in test data
    """
    terms = []
    variables = {}
    kwargs = {}

    lookup_module_0 = LookupModule()
    tuple_0 = ()
    str_0 = 'dead but '
    str_1 = 'ohai_'
    dict_0 = {str_0: lookup_module_0, str_1: str_1}
    var_0 = lookup_run(terms)
    lookup_module_1 = LookupModule(variables)
    tuple_1 = ()
    dict_1 = {str_0: tuple_1, str_1: tuple_0}
    var_1 = lookup_run(terms, variables)
    lookup_module_2 = LookupModule(terms)

# Generated at 2022-06-25 11:53:43.884908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '  '
    list_0 = []
    dict_0 = {'set_options': lookup_module_0, 'get_option': lookup_module_0}
    tuple_0 = (str_0, list_0)
    ret_0 = test_case_0()
    assert ret_0 == tuple_0

# Generated at 2022-06-25 11:53:47.821244
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    str_0 = 'dead'
    str_1 = 'ohai_'
    dict_0 = {str_0: lookup_module_0, str_1: str_1}
    var_0 = lookup_run(dict_0)
    assert var_0 == []


# Generated at 2022-06-25 11:53:55.056298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['_terms', 'default', '_options', '_display.deprecated_warning', '_display.deprecated', 'get_option', '_load_name', 'run', '_load_terms', '_flatten', '_get_terms', 'set_options', '_display.warning', 'lookup_loader', 'lookup_loader.get', 'lookup_loader.all', 'lookup_loader.list_available']
    variables = {'_terms': ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']}
    lookup_module = LookupModule()
    assert lookup_module.run(terms, variables) == ['dead but ohai_' for i in xrange(len(terms))]

# Generated at 2022-06-25 11:54:02.308744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule(list)
    tuple_1 = ()
    str_2 = 'dead but '
    str_3 = 'ohai_'
    dict_1 = {str_2: lookup_module_2, str_3: str_3}
    var_1 = lookup_run(dict_1)
    ret_0 = lookup_module_2.run(var_1)


# Generated at 2022-06-25 11:54:07.815392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = (1, 2, 3)
    str_0 = 'dead but '
    str_1 = 'ohai_'
    dict_0 = {str_0: lookup_module_0, str_1: str_1}
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule(tuple_0)
    list_0 = []
    var_1 = lookup_module_1.run(list_0)
    assert var_1 == []



# Generated at 2022-06-25 11:54:14.948856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_batch', 'ansible_play_hosts_all', 'ansible_play_hosts']
    test_var = {'ansible_play_batch': '123', 'ansible_play_hosts_all': 'all', 'ansible_play_hosts': 'hosts'}
    expected = ['123', 'all', 'hosts']
    lookup_module = LookupModule(terms)
    assert lookup_module.run(terms, variables=test_var) == expected

# Generated at 2022-06-25 11:55:23.066197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_2 = 'host'
    str_3 = 'type'
    str_4 = 'human'
    str_5 = 'ansible'
    dict_1 = {str_2: str_3, str_4: str_5}
    var_1 = lookup_module_2.run(dict_1)
    lookup_module_3 = LookupModule()
    str_6 = 'ansible'
    str_7 = 'hello'
    str_8 = 'world'
    dict_2 = {str_6: str_7, str_8: dict_1}
    var_2 = lookup_module_3.run(dict_2)
    lookup_module_4 = LookupModule()
    str_9 = 'world'

# Generated at 2022-06-25 11:55:34.724656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = 'ohai_'
    term_1 = 'd'
    term_2 = 'dead but'
    term_3 = 'o'
    term_4 = 'ohai_'
    term_5 = 'd'
    term_6 = 'dead but'
    term_7 = 'o'
    tuple_0 = (term_1, term_3)
    tuple_1 = (term_5, term_7)
    tuple_2 = (term_0, term_2, term_4, term_6)
    dict_0 = {term_0: tuple_0, term_2: tuple_1}

# Generated at 2022-06-25 11:55:42.405628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ' '
    list_0 = [str_0]
    tuple_0 = ()
    tuple_1 = ('j',)
    tuple_2 = ('i',)
    tuple_3 = ('h', 'g')
    tuple_4 = (tuple_3, 'f')
    tuple_5 = ('e', tuple_4)
    tuple_6 = (tuple_2, tuple_5)
    tuple_7 = ('l', tuple_6)
    tuple_8 = (tuple_1, tuple_7)
    tuple_9 = ('o', tuple_8)
    tuple_10 = (tuple_0, tuple_9)
    tuple_11 = ('s',)
    tuple_12 = ('r', tuple_11)
    tuple_13

# Generated at 2022-06-25 11:55:50.140596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instance creation
    terms = ['_terms']

# Generated at 2022-06-25 11:55:57.781070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    tuple_1 = (tuple_0,)
    str_0 = 'dead but '
    str_1 = 'ohai_'
    dict_0 = {str_0: lookup_module_0, str_1: str_1}
    lookup_module_1 = LookupModule(tuple_0)
    var_0 = lookup_run(dict_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:56:03.778754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(myvars, lookup_module_1, **kwargs) == tuple_0
    assert lookup_module_1.run(variables, terms, **kwargs) == tuple_0


# Generated at 2022-06-25 11:56:07.720751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run()
    var_1 = lookup_module_0.run()
    var_2 = lookup_module_0.run()
    assert (var_2 == var_1)
    assert (var_1 == [None])
    assert (var_0 != var_1)



# Generated at 2022-06-25 11:56:10.939323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    str_0 = 't_s_t'
    dict_0 = {str_0: str_0}
    method_ret_0 = lookup_module_0.run(tuple_0, dict_0)
    assert method_ret_0 == []
    lookup_module_1 = LookupModule(tuple_0)

# Generated at 2022-06-25 11:56:20.115496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    kwargs_0 = dict()
    kwargs_0['default'] = 'dead but '
    kwargs_0['ohai_'] = 'ohai_'
    lookup_module_0 = LookupModule()
    tuple_0 = ()
    str_0 = 'dead but '
    str_1 = 'ohai_'
    dict_0 = {str_0: lookup_module_0, str_1: str_1}
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule(tuple_0)
    assert var_0 == kwargs_0

# Generated at 2022-06-25 11:56:32.094202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'terms'
    str_1 = 'w'
    str_2 = 'default'
    str_3 = 'renaissance'
    list_0 = []
    dict_0 = dict()
    dict_1 = dict()
    dict_0[str_0] = list_0
    dict_0[str_2] = str_3
    var_1 = lookup_module_0.run(list_0, dict_0)
    dict_1[str_0] = dict_0
    dict_1[str_1] = dict_1
    dict_0[str_0] = dict_1
    var_1 = lookup_module_0.run(list_0, dict_0)
    str_4 = 'l'
    dict_