

# Generated at 2022-06-25 11:48:07.982501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={})
    lookup_module_0._templar = DummyClass()
    lookup_module_0._templar.available_variables = variables={'inventory_hostname': '', 'ansible_play_batch': ''}
    lookup_module_0._templar._available_variables = {'inventory_hostname': 'localhost', 'ansible_play_batch': '', 'hostvars': {'localhost': {'ansible_play_batch': '', 'inventory_hostname': ''}}}
    lookup_module_0._templar.template = lambda x, fail_on_undefined: x
    lookup_module_0._templar.template.fail_on_undefined = True

# Generated at 2022-06-25 11:48:08.879355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True



# Generated at 2022-06-25 11:48:10.014400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Generated at 2022-06-25 11:48:18.757990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct={'default': 'test_default'})
    lookup_module_0.get_option = lambda x: 'test_default'
    lookup_module_0._templar = MockTemplar()
    terms_0 = ['term_0']
    variables_0 = None
    ret_0 = lookup_module_0.run(terms_0, variables_0)
    assert ret_0 == [u'test_variable']


# Generated at 2022-06-25 11:48:27.909261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']) == ['localhost', '3', 'localhost']
    assert lookup_module.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables={'ansible_play_batch': '4'}) == ['localhost', '4', 'localhost']
    assert lookup_module.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables={'ansible_play_batch': '4'}, default='') == ['localhost', '4', 'localhost']
    assert lookup_module.run

# Generated at 2022-06-25 11:48:32.601335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # print the doc of run method
    print(LookupModule.run.__doc__)
    # initialise lookup_module_0 object
    lookup_module_0 = LookupModule()
    # look up the value of test_vars
    lookup_module_0.run(['i_am_a_test_var'], {'i_am_a_test_var': ['test_value']})

# Generated at 2022-06-25 11:48:45.242516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Non-string parameter
    lookup_instance_0 = LookupModule()
    res = lookup_instance_0.run(['variablename', 0])
    assert res == ['hello', 0]

    # Invalid terms
    lookup_instance_0 = LookupModule()
    res = lookup_instance_0.run(object())
    assert isinstance(res, AnsibleError)

    # invalid terms
    lookup_instance_0 = LookupModule()
    res = lookup_instance_0.run('bad')
    assert isinstance(res, AnsibleError)

    # invalid terms
    lookup_instance_0 = LookupModule()
    res = lookup_instance_0.run(['variablename', 'bad'])
    assert isinstance(res, AnsibleError)

    # bad term
    lookup_instance_0 = Look

# Generated at 2022-06-25 11:48:47.202905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Input parameters for this testcase
    lookup_module.run("tests")


# Generated at 2022-06-25 11:48:57.134922
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up mocks
    test_run_mocks = Mocker()
    terms = "ansible_play_hosts"
    variables = None
    kwargs = {}
    _templar = test_run_mocks.mock()
    _templar.available_variables = variables
    getattr(_templar, '_available_variables', {})
    _templar._available_variables = {}

    lookup_module_1 = LookupModule()
    lookup_module_1._templar = _templar
    lookup_module_1.set_options(var_options=variables, direct=kwargs)
    lookup_module_1.get_option('default')
    assert lookup_module_1._templar.available_variables == variables

    # test case 1
    _tem

# Generated at 2022-06-25 11:49:01.814876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = []
    lookup_module_1.run(terms_1)

# Generated at 2022-06-25 11:49:09.345992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = test_case_0()

# Generated at 2022-06-25 11:49:18.116186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # This is a dict of dicts for testing.
    a = {
        'a': '1',
        'b': {
            'ba': 'ba',
            'bb': 'bb'
        },
        'c': '3',
        'd': {
            'da': 'da',
            'db': 'db'
        }
    }

    # This is a dict of lists for testing.
    b = {'a': ['1', '2']}


# Generated at 2022-06-25 11:49:20.148750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = 'dY\xe5\x8f\x06'
    lookup_module_0 = LookupModule('var_0')
    var_0 = lookup_module_0.run(str_0)
    print(var_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:49:31.548980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '{'
    lookup_module_0 = LookupModule(str_0)
    str_1 = '{'
    str_2 = '{'
    str_3 = '{'
    str_4 = '{'
    str_5 = '{'
    str_6 = '{'
    str_7 = '{'
    str_8 = '{'
    str_9 = '{'
    str_10 = '{'
    str_11 = '{'
    str_12 = '{'
    str_13 = '{'
    str_14 = '{'
    str_15 = '{'


# Generated at 2022-06-25 11:49:40.588244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = '\x12'
    str_1 = 'Y8'
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    lookup_module_0 = LookupModule(str_0)
    ret_0 = lookup_module_0.run(bool_0, bytes_0, str_1)
    if ret_0 is not None:
        ret_0 = True
    assert not ret_0


# Generated at 2022-06-25 11:49:47.297844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\x03D\xa0\xca\xe1z\x92O\x08\xe3'
    str_0 = 'f<e?/'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 11:49:53.389573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = 'l[s'
    list_0 = [str_0]
    dict_0 = {'ansible_play_batch': str_0}
    lookup_module_0 = LookupModule(str_0)
    result = lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 11:50:00.236395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:50:11.185271
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import mock
    import lookups

    # Mock the case when the default option does not exist
    with mock.patch.dict(lookups.LookupModule.get_option.__dict__,
                         {
                             'return_value': None
                         }):

        # Call the run method of the LookupModule with the input term as an undefined variable
        with mock.patch.dict(lookups.AnsibleUndefinedVariable.__dict__,
                             {
                                 'raise_exception.side_effect': Exception('Variable is undefined')
                             }):
            # Verify that an exception is raised
            result_1 = lookups.LookupModule.run(lookups.LookupModule, ['undefined_var'],
                                                {}, {'default': None})
            assert result_1 == Exception('Variable is undefined')

    # Mock

# Generated at 2022-06-25 11:50:18.583544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)
    pass
    return


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:50:31.513359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = False
    bytes_1 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_1 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_1 = LookupModule(str_1)
    var_1 = lookup_run(bool_1, bytes_1)
    
    

# Generated at 2022-06-25 11:50:40.040048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import binascii
    str_0 = '"\x0f\xa6\x9d\xea\x80\x8c\xee\x7f\xb6`\x7f\xc0\xa2E4;\xae'
    binascii.unhexlify(str_0)
    str_1 = '\xfa\xbf\x01\x07\xfa'
    lookup_module_0 = LookupModule(str_1)
    bool_0 = lookup_module_0.run([]) == [None]
    print("> %s" % (bool_0))


# Generated at 2022-06-25 11:50:42.087376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["_"]
    variables = None
    kwargs = {}
    lookup_module_0 = LookupModule(terms)
    _value = lookup_module_0.run(terms, variables, **kwargs)
    assert isinstance(_value, list)
    assert _value[0] == "_"

# Generated at 2022-06-25 11:50:46.540839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)
    assert var_0 == True


# Generated at 2022-06-25 11:50:47.214538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == 'Pass'

# Generated at 2022-06-25 11:50:52.461660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bytes_0 = b'\x15\xcd\xec\xae\x18\x16\n\xd4\xc4\x1bE\x9f\xb6\x84V\x14\xec\x18\xe1\xc1'
    bytes_1 = b'\xd1\x12\x8c\xf2\x07\xa2\xaa\xd0\xc5\x9e\x1b\xae\r<\x92\xa5\xda\xf5'
    str_0 = '!\x16\x04\xee\xba\xc2\xa2]\xd2\xe5'
    lookup_module_0 = LookupModule(str_0)

# Generated at 2022-06-25 11:50:58.375411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy dummy values for variables
    myvars = {'sub_var': 12, 'variablename': {'sub_var': 12}, 'myvar': 'ename', 'variablename': 'hello', 'myvar': 'notename', 'variablename': 'hello', 'myvar': 'notename'}
    # Tests using the dummy dummy values
    assert test_case_0(myvars) == [12, 'hello', 'hello', 12]


# Generated at 2022-06-25 11:51:08.693743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_module_0._templar
    str_1 = '|D_J'
    dict_0 = {str_0: bytes_0, '|D_J': bool_0, }
    var_0._available_variables = dict_0
    var_0 = lookup_module_0._templar
    var_1 = set_options(dict_0)

# Generated at 2022-06-25 11:51:15.759817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test run")
    terms = '_E?%&vJz\nHs-]6Ir`^'
    variables = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    kwargs = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(terms)
    try:
        lookup_module_0.run(terms, variables, **kwargs)
    except Exception:
        print("An exception occurred")
        if isinstance(lookup_module_0, LookupBase):
            lookup_module_0.run(terms, variables, **kwargs)
    else:
        print("No exception occurred")


# Generated at 2022-06-25 11:51:21.519997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    set_0 = set()
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    dict_0 = {}
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_module_0.run(list_0, dict_0)



# Generated at 2022-06-25 11:51:42.353143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ctypes
    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(0), ctypes.py_object(SystemError))
    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_long(-1), ctypes.py_object(SystemError))
    # Test with invalid values for parameters defaults to None
    # TEST WITH NON-STRING OBJECT AS TERMS
    # TEST WITH UNDEFINED KEY
    # TEST WITH INVALID KEY AS DEFAULT

# Generated at 2022-06-25 11:51:46.849634
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declare var_0
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)

    # Call method run of class LookupModule
    lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:51:52.413930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #  default='', two terms
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)

# Generated at 2022-06-25 11:51:58.309116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    lookup_module_0 = LookupModule(bool_0)
    int_0 = 1
    str_0 = '*Xx8W+'
    dictionary_1 = {}

    # call the test function
    test_case_0(lookup_module_0, int_0, str_0, dictionary_1)
    return None


# Generated at 2022-06-25 11:52:06.016827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '7T:p@H|}yn\x00W\x8bv'
    bool_0 = False
    float_0 = float(0.05)
    lookup_module_0 = LookupModule(str_0)
    lookup_module_0.set_options(bool_0, float_0)
    var_0 = lookup_module_0.run(bool_0, float_0)

if __name__ == "__main__":
    try:
        test_case_0()
        test_LookupModule_run()
    except AssertionError as e:
        pass

    except Exception as e:
        raise Exception('Graph test failed')

# Generated at 2022-06-25 11:52:14.158909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("test_LookupModule_run")
    my_var = 'prefixed_var'
    lookup_module_0 = LookupModule(my_var)
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]
    ret = lookup_module_0.run(terms, kwargs={'vars': {'prefixed_var': '1234'}})
    assert len(ret) == 3

# Generated at 2022-06-25 11:52:24.107551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myvars = getattr(self._templar, '_available_variables', {})

    self.set_options(var_options=variables, direct=kwargs)
    default = self.get_option('default')

    ret = []
    for term in terms:
        if not isinstance(term, string_types):
            raise AnsibleError('Invalid setting identifier, "%s" is not a string, its a %s' % (term, type(term)))


# Generated at 2022-06-25 11:52:30.130163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = '-I\x00\x06\x00\x02'
    str_1 = '\x1f\xea\xfc]\x12\xf5\x84\xe9\x82\xa0\x1c\xc6fB\xae'
    dict_0 = dict()
    lookup_module_0 = LookupModule(str_0)
    result = lookup_module_0.run(str_1)

    assert result == dict_0

# Generated at 2022-06-25 11:52:40.053186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bool_1 = True
    bytes_0 = b'0\xcc\xfd\x1b'
    bytes_1 = b'@F\xfd\xd8\x80\x92v[\xea\x83\x8b'
    float_0 = 0.792887046387
    float_1 = 0.764301149068
    int_0 = 2
    int_1 = 3
    int_2 = 3
    int_3 = 3
    int_4 = 2
    int_5 = 2
    int_6 = 1

# Generated at 2022-06-25 11:52:45.473905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'8\xcb\xa0\xec\x81\xb2\x08\xbc\x17\x0f\xa1O:\x11\x85\x9f\x0e\xd9\x9b\xffG\x1a\x90\xa2\x08\x84\xf3/\xc3\x9b\x11'
    lookup_module_0 = LookupModule(str_0)
    var_0 = test_case_0(bool_0, bytes_0)

# Generated at 2022-06-25 11:53:20.141807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = "hostvars['host1']['ansible_play_hosts']"
    lookup_module_0 = LookupModule(str_0)

    var_0 = lookup_module_0.run(bool_0, bytes_0)
    assert var_0 == "test1"



# Generated at 2022-06-25 11:53:29.725715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = false
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)
    if test_case_0() == 1:
        var_0 = lookup_run(bytes_0, str_0)

# Generated at 2022-06-25 11:53:34.939653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '<|>L'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:53:39.704363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = None
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:53:45.336607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = False
    bytes_1 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_1 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_1 = LookupModule(str_1)
    var_1 = lookup_run(bool_1, bytes_1)



# Generated at 2022-06-25 11:53:52.336519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run()
        lookup_module_1 = LookupModule('vars')
        lookup_module_1.run(['inventory_hostname'])
        lookup_module_2 = LookupModule(str_0)
        lookup_module_2.run(['inventory_dir'])
        lookup_module_3 = LookupModule()
        lookup_module_3.run(['ansible_play_batch'])
    except AnsibleUndefinedVariable as e:
        print(e.message)
    except KeyError as e:
        print(e.message)
    except TypeError as e:
        print(e.message)


# Generated at 2022-06-25 11:53:57.125784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)


# Generated at 2022-06-25 11:54:06.501977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xe3\xbe\xb8j\xa1\xef\x13\x0f\xdc\xee\x9d'
    term_0 = '7s\xce4u\xfb\xfa/\xec\xea\x9b\x83\xdbK'
    terms_0 = [term_0]
    str_0 = '\xfdQ{1\xd3\xab\xeb\xaf\xb0\xec<\xfbs'
    module_0 = LookupModule(str_0)

# Generated at 2022-06-25 11:54:07.974123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run('2', '_E?%&vJz\nHs-]6Ir`^') == '2'

# Generated at 2022-06-25 11:54:14.198041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types

    # Set up mock objects
    terms_0 = ['variable_0']
    variables_0 = {'variable_0': 'value'}

    lookup_module_0 = LookupModule('')
    lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 11:55:16.841198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    bytes_0 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_0 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:55:22.459153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ')Sx?*'
    lookup_module_0 = LookupModule(str_0)
    list_0 = ['']
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:55:23.268381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True


# Generated at 2022-06-25 11:55:30.414625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str)
    var_0 = lookup_run([], {})
    # Test for success
    assert var_0 == [None]
    # Test for failure
    try:
        var_0 = lookup_run(None, {})
    except AnsibleError:
        pass


# Generated at 2022-06-25 11:55:31.912004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(test_LookupModule_run(), list)

test_LookupModule_run()

# Generated at 2022-06-25 11:55:36.568778
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert test_case_0() == None

# Generated at 2022-06-25 11:55:37.389568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:55:43.303616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with if (self._templar.available_variables is not None):

    bool_0 = False
    bytes_0 = b'>\x02\x8f\xd9\x05\xeb/\xce\xa6\xe1'
    str_0 = '  :    '
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_run(bool_0, bytes_0)
    # Test with else:
    # Test with try:
    # Test with except KeyError:
    # Test with try:
    # Test with except KeyError:
    # Test with except AnsibleError:
    # Test with except AnsibleUndefinedVariable:

# Generated at 2022-06-25 11:55:46.130035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = False
    bytes_1 = b'\xdf\x0e/\xc0\x9e?\xa3IC\xad'
    str_1 = '_E?%&vJz\nHs-]6Ir`^'
    lookup_module_1 = LookupModule(str_1)
    var_1 = lookup_run(bool_1, bytes_1)

test_LookupModule_run()

# Generated at 2022-06-25 11:55:57.428685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False