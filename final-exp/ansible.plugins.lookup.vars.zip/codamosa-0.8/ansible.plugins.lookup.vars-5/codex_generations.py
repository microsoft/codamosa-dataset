

# Generated at 2022-06-11 16:31:07.540595
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with simple term - 'lookup'
    lookup_obj = LookupModule()
    lookup_obj._templar = MockTemplar()
    lookup_obj._templar._available_variables = {'lookup': 'temp'}
    lookup_obj._templar.template = lambda x: x
    assert lookup_obj.run(['lookup']) == ['temp']
    assert lookup_obj.run(['lookup1']) == ['temp']
    lookup_obj._templar._available_variables = {}
    assert lookup_obj.run(['lookup']) == ['temp']

    # Test with full inventory terms
    lookup_obj._templar._available_variables = {'hostvars': {'inventory_hostname': {'lookup': 'temp'}}}

# Generated at 2022-06-11 16:31:17.412075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.template import Templar

    lookup_module = LookupModule()

    # Testing LookupModule
    def get_available_variables(self):
        return {
            'variablename': 'hello',
            'myvar': 'ename',
        }

    # Monkey patching the _templar.available_variables
    lookup_module._templar.available_variables = get_available_variables
    getattr(lookup_module._templar, '_available_variables', {})

    lookup_module._templar.template = Templar._template

    # Testing error in LookupModule

# Generated at 2022-06-11 16:31:27.841691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeTemplar(object):
        def __init__(self, available_variables):
            self._available_variables = available_variables

        def template(self, value):
            return value

    # success
    myvars = {'testvar1': 'mytestvalue1', 'testvar2': 'mytestvalue2', 'testvar3': 'mytestvalue3'}
    module = LookupModule()
    module._templar = FakeTemplar(myvars)

    terms = ['testvar1', 'testvar2', 'testvar3']
    result = module.run(terms, variables=myvars)
    assert result == ['mytestvalue1', 'mytestvalue2', 'mytestvalue3']

    # error

# Generated at 2022-06-11 16:31:32.275755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    lookup_module._templar._available_variables = {'first' : 'foo', 'second': 'bar'}
    assert lookup_module.run(['first', 'second']) == ['foo', 'bar']


# Generated at 2022-06-11 16:31:43.301758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # dict for MockTemplar
    template_data = {u'a': 'vala',
                     u'b': 'valb',
                     u'hostvars': {'host1': {u'c': 'valc'}},
                     u'inventory_hostname': 'host1',
                     u'z': 'valz'}
    print(template_data)

    # mock class LookupBase
    lookup_base = LookupModule(None, None, None)

    # method set_options of class LookupBase
    lookup_base.set_options(var_options=template_data, direct=None)
    print("set_options")

    # method run of class LookupModule
    ret = lookup_base.run(terms=['a', 'b', 'c', 'z'], variables=template_data)
    print

# Generated at 2022-06-11 16:31:49.186173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fm = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': '1.1.1.1', 'ansible_play_batch': [], 'ansible_play_hosts_all': []}
    fm.run(terms, variables)

test_LookupModule_run()

# Generated at 2022-06-11 16:31:59.709858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Creating LookupModule object
    test_obj = LookupModule()
    # Creating the data loader object
    test_loader = DataLoader()
    # Creating templar object
    test_temp = Templar(loader=test_loader)
    # Setting the templar object
    test_obj._templar = test_temp
    # Creating variable manager object
    test_vars = VariableManager()
    # Adding data to variable manager object

# Generated at 2022-06-11 16:32:09.928915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all' ]
    variables = {
        'inventory_hostname': 'localhost',
        'ansible_play_hosts': 'placeholder',
        'ansible_play_batch': 'placeholder',
        'ansible_play_hosts_all': 'placeholder',
        'hostvars': {
            'localhost': {
                'ansible_play_hosts': 'placeholder',
                'ansible_play_batch': 'placeholder',
                'ansible_play_hosts_all': 'placeholder',
            }
        }
    }

    lookup = LookupModule()
    results = lookup.run(terms, variables)
    assert results == ['placeholder'] * len(terms)


# Generated at 2022-06-11 16:32:21.488937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup_module = LookupModule()

    # Define test variables
    term_list = ['foo', 'bar']

    # Setup helper variables for assert statements
    lookup_module.set_options(var_options={term_list[0]: 1, term_list[1]: 2})
    myvars = getattr(lookup_module._templar, '_available_variables', {})

    # Setup test cases
    test_cases = []
    test_cases.append({'_terms': term_list,
                       '_expected_ret': {'action': 'set', 'value': [1, 2]}
                       })

# Generated at 2022-06-11 16:32:29.677562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method run of class LookupModule."""

    # get parameters of method run
    terms = ['{{ myVar }}', '{{ myVar2 }}']
    variables = {'myVar': 'Hello', 'myVar2': 'World'}
    kwargs = {}

    # initialize object
    lookup_module = LookupModule()

    # run method
    ret = lookup_module.run(terms=terms, variables=variables, **kwargs)

    # verify result
    assert ret == ['Hello', 'World'], \
        "'ret' contains unexpected value: {} expected: {}".format(ret, ['Hello', 'World'])

# Generated at 2022-06-11 16:32:47.754168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test method run of class LookupModule
    '''
    # Test variable definitions
    lookup_plugin = LookupModule()
    templar = None
    terms = ['foo']
    variables = {'foo': 'bar', 'baz': 'qux'}
    kwargs = {'default': 'default'}

    # Test case 1
    # Tests that run method returns the required value of a variable
    # when variables is not None and term is one variable
    # return_value: value of the variable requested
    expected_return_value = ['bar']
    return_value = lookup_plugin.run(terms, variables, **kwargs)
    assert return_value == expected_return_value

    # Test case 2
    # Tests that run method returns the required value of a variable
    # when variables is not None and term

# Generated at 2022-06-11 16:32:59.387306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Fake_templar():
        def __init__(self, _available_variables, _fail_on_undefined=True):
            self._available_variables = _available_variables
            self._fail_on_undefined = _fail_on_undefined

        def template(self, value, fail_on_undefined=None):
            if fail_on_undefined is None:
                fail_on_undefined = self._fail_on_undefined

            if fail_on_undefined:
                try:
                    return self._available_variables[value]
                except KeyError:
                    raise AnsibleUndefinedVariable('No variable found with this name %s ' % value)
            else:
                try:
                    return self._available_variables[value]
                except KeyError:
                    return None


# Generated at 2022-06-11 16:33:10.149241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    from ansible.template import Templar

    templar = Templar()

    terms = ['hostvars', 'inventory_hostname', 'group_names']

# Generated at 2022-06-11 16:33:18.400374
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    dummy_module = DummyModule()
    dummy_module.run_command.return_value = (0, 'success', '')
    # Initial Setup
    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    lookup._templar._available_variables = {
        'variablename': 'hello',
        'myvar': 'ename',
        'nonexistentvar': 'foo',
        'ansible_play_hosts': ['localhost'],
        'ansible_play_batch': ['localhost'],
        'ansible_play_hosts_all': ['localhost'],
        'variablenotename': int(),
    }
    lookup._templar._available_variables = lookup._templar._available_variables
    lookup._templar._module

# Generated at 2022-06-11 16:33:18.978893
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True

# Generated at 2022-06-11 16:33:27.656758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    terms = [
        'test.test',
        'test.test1.test2',
    ]
    variables = {
        'test': {
            'test': {
                'test3': 'test3value'
            },
            'test1': 'test1value',
            'test2': {
                'test': 'testvalue'
            }
        }
    }
    options = {
        'default': None
    }
    tail = 'test'
    myvars = {
        'test': {
            'test': 'value'
        }
    }

    lookup = LookupModule()
    lookup._templar._available_variables = myvars
    lookup.set_options(var_options=variables, direct=options)

# Generated at 2022-06-11 16:33:37.542997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Unit test for method run of class LookupModule '''
    # Mock objects for the test
    class _AnsibleUndefinedVariable(AnsibleUndefinedVariable):
        def __init__(self, msg):
            self.msg = msg

    class _AnsibleError(AnsibleError):
        def __init__(self, msg):
            self.msg = msg

    class _LookupBase():
        def get_option(self, str):
            return self.default_value

    class _LookupModule(_LookupBase):
        def __init__(self, templar, available_variables):
            self._templar = templar
            self._templar._available_variables = available_variables
            self.default_value = None
            self.terms = None

# Generated at 2022-06-11 16:33:46.466874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'],
            variables=dict(ansible_play_hosts='test', ansible_play_batch='test1', ansible_play_hosts_all='test2')) == ['test', 'test1', 'test2']
    assert lookup_module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'],
            variables=dict(ansible_play_hosts='test')) == ['test', None, None]

# Generated at 2022-06-11 16:33:47.457485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([]) == None

# Generated at 2022-06-11 16:33:57.161315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar.available_variables = {}

    # Testing for invalid setting identifier
    tests = [dict(name='Not string', terms=1),
        dict(name='Invalid string', terms='this/is/invalid')]

    for test in tests:
        try:
            lm.run(test['terms'])
        except AnsibleError as ex:
            assert str(ex) == 'Invalid setting identifier, "%s" is not a string, its a %s' % (test['terms'], type(test['terms']))
        else:
            assert test['name'] == 'Not string'

# Generated at 2022-06-11 16:34:05.026013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run([1])

# Unit test of function run of class LookupModule

# Generated at 2022-06-11 16:34:13.067010
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    default = 'test'
    term1 = 'test_term_1'
    term2 = 'test_term_2'

    # Test failure if term1 or term2 not found without a default
    mylookup = LookupModule()
    assert mylookup.run([term1, term2], {'inventory_hostname':'test_host'}) == []
    assert mylookup.run([term1, term2], {'inventory_hostname': 'test_host', 'hostvars': {'test_host': {term1: 'test_value'}}}) == []

    # Test failure with non-string values

# Generated at 2022-06-11 16:34:19.497118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import errors
    from ansible.utils.vars import combine_vars
    test_obj = LookupModule()
    test_term = "ansible_play_hosts"
    test_default = "default"
    test_variables = {
        'ansible_play_batch': ['mybatch'],
        'ansible_play_hosts': ['myhosts'],
        'ansible_play_hosts_all': ['myallhosts'],
    }
    with pytest.raises(errors.AnsibleError) as excinfo:
        test_obj.run([test_term, 2], test_variables)
    assert 'is not a string' in str(excinfo.value)
    test_obj.set_options(var_options=test_variables)

# Generated at 2022-06-11 16:34:29.249154
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["test_var1", "test_var2"]
    variables = {'test_var1': 'foo', 'test_var2': 'bar'}
    
    lkup_mod = LookupModule()
    lkup_mod._templar = None
    lkup_mod._templar._available_variables = variables
    
    assert lkup_mod.run(terms) == ['foo', 'bar']
    
    # AttributeError: 'NoneType' object has no attribute '_available_variables'
    try:
        lkup_mod.run(terms, variables)
    except AttributeError:
        # error
        pass
    else:
        # success
        assert True
        

# Generated at 2022-06-11 16:34:33.251264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    lookup = LookupModule()
    assert lookup.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], {}) == [None, None, None]

# Generated at 2022-06-11 16:34:40.398381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import warnings
    import pytest

    # Capture warnings only if we are in a test.
    if sys.argv[0] == 'ansible-test':
        cwd = os.getcwd()
        capture_warnings = cwd.endswith('test/units')
    else:
        capture_warnings = False

    if capture_warnings:
        # New in python 2.7
        if hasattr(warnings, 'catch_warnings'):
            with warnings.catch_warnings(record=True) as w:
                with pytest.raises(AnsibleUndefinedVariable):
                    # When there is no warning then the w variable is empty,
                    # and warnings.warn is never called.
                    LookupModule().run(['non_existing_key'])
                assert len

# Generated at 2022-06-11 16:34:45.402146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a class to use as the templar
    class Templar():
        # Initialise the Templar class
        def __init__(self):
            self._available_vars = dict()

        # Method to allow available_vars to be accessed from outside this class
        def get_available_vars(self):
            return self._available_vars

        # Method to allow available_vars to be set from outside this class
        def set_available_vars(self, available_vars):
            self._available_vars = available_vars

        # Method to allow available_vars to be set from outside this class
        def template(self, value, fail_on_undefined=True):
            return value

    # Create a templar runner
    temporary_obj = Templar()

    # Create an ansible variable dictionary
    ansible

# Generated at 2022-06-11 16:34:52.239353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # return code of run method is a list of values
    assert len(LookupModule(loader=None, templar=None, shared_loader_obj=None).run([1], None))>0
    assert len(LookupModule(loader=None, templar=None, shared_loader_obj=None).run(['1'], None))>0
    assert len(LookupModule(loader=None, templar=None, shared_loader_obj=None).run(['ansible_os_family'], None))>0
    assert len(LookupModule(loader=None, templar=None, shared_loader_obj=None).run(['ansible_play_hosts'], None))>0

# Generated at 2022-06-11 16:34:57.069308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['']) == [None], 'empty term should return None'

    try:
        module.run(['non-existing-var'])
        assert False, "should have thrown error"
    except:
        assert True, "error was thrown as expected"



# Generated at 2022-06-11 16:35:07.348753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test1: terms = string_types
    term1 = 'ansible_play_hosts'
    variables = {'ansible_play_hosts': 'localhost'}
    results = lookup.run(terms=term1, variables=variables)
    assert results == ['localhost'], 'Failed to find term1'

    # Test2: terms = list
    term2 = ['ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_batch': ['localhost'],
                 'ansible_play_hosts_all': ['localhost']}
    results = lookup.run(terms=term2, variables=variables)
    assert results == [['localhost'], ['localhost']], 'Failed to find term2'

    # Test3: terms

# Generated at 2022-06-11 16:35:31.273134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_str = 'testing'
    my_dict = {'sub_dict': {'sub_sub_dict': {'sub_sub_sub_dict': {'sub_sub_sub_sub_dict': 'test1'}}}}
    my_dict2 = {'sub_dict': {'sub_sub_dict': {'sub_sub_sub_dict': {'sub_sub_sub_sub_dict': 'test2'}}}}
    my_dict3 = {'sub_dict': {'sub_sub_dict': {'sub_sub_sub_dict': {'sub_sub_sub_sub_dict': 'test3'}}}}
    my_list = [my_dict, my_dict2, my_dict3]

# Generated at 2022-06-11 16:35:41.783167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys

    from ansible.module_utils._text import to_bytes
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.module_utils.six.moves import builtins

    module_path = os.path.join(os.path.dirname(__file__), '..', 'templar.py')
    if module_path not in sys.path:
        sys.path.append(module_path)

    from ansible.module_utils.facts import templar

    ##############
    #
    # Test cases
    #
    ##############

    # run: test error when term is not String

# Generated at 2022-06-11 16:35:48.747529
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['variablename', 'myvar']

    variables={
        u'variablename': u'hello',
        u'myvar': u'ename',
        u'inventory_hostname': u'localhost'
        }

    # Initialize the Lookup module class
    lu = LookupModule()
    # Check the method run of LookupModule and test the return value
    assert(lu.run(terms, variables)) == ['hello', 'ename']

# Generated at 2022-06-11 16:35:59.881184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup_plugin = LookupModule()
    _inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    _variable_manager = VariableManager(loader=DataLoader(), inventory=_inventory)
    _variable_manager.extra_vars = {'foo': 'baz', 'bar': {'subvar': 12}}
    myvariables = _variable_manager.get_vars(play=None, host=None)
    myvariables['inventory_hostname'] = 'localhost'

# Generated at 2022-06-11 16:36:11.185502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    import ansible.plugins.loader
    from ansible.vars.hostvars import HostVars
    import copy
    import sys
    import ansible.plugins.lookup.vars
    test_lookup = ansible.plugins.lookup.vars.LookupModule(loader=None)

    # define terms to lookup
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    # define default value
    default = 'my default'

    # define hostvars

# Generated at 2022-06-11 16:36:22.604728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.templating import Templar
    from ansible.utils.vars import combine_vars

    # Initialize
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'myvar': 'ename', 'inventory_hostname': 'test-host'}
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost'))


# Generated at 2022-06-11 16:36:31.969229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mocks
    templar = Mock()
    templar._available_variables = {}
    templar.template = Mock()
    templar.template.return_value = 'some_value'
    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module.get_option = Mock()

    # test1
    terms = ['var1', 'var2']
    lookup_module.get_option.return_value = None
    assert ['some_value', 'some_value'] == lookup_module.run(terms)
    templar.template.assert_has_calls([call(lookup_module.run(terms)[0]), call(lookup_module.run(terms)[1])])

    # test2
    terms = ['var1', 'var2']

# Generated at 2022-06-11 16:36:33.756479
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:36:40.978095
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import string_types
    import ansible.plugins.lookup.vars as vars_lookup
    lookup_module = vars_lookup.LookupModule()

    terms = ['terms_string']
    myvars = {'terms_string': 'hello_world'}
    lookup_module._templar._available_variables = myvars
    result = lookup_module.run(terms)
    assert result == ['hello_world']

    # When variables, is not none and is provided to run
    # variables, terms and myvars are available for lookup
    terms = ['terms_string']
    myvars = {'terms_string': 'hello_world'}

# Generated at 2022-06-11 16:36:51.459608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with an undefined variable name
    from ansible.module_utils.six.moves import StringIO
    try:
        lookup = LookupModule()
        result = lookup.run(['test'], dict())
        assert False
    except AnsibleUndefinedVariable:
        assert True
    except:
        assert False

    # Test with a defined variable name

# Generated at 2022-06-11 16:37:28.381616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test the method run of class LookupModule
    """
    # Test variables
    # test 1
    myvariables = {'a':'1', 'b':'2', 'c':'3'}
    terms = ['a', 'b', 'c']
    default = '3'
    # test 2
    myvariables = {'a':'1', 'b':'2', 'c':'3'}
    terms = ['a', 'd', 'e']
    default = '3'
    # test 3
    myvariables = {'a':'1', 'b':'2', 'c':'3'}
    terms = ['a', 'b', 'c']
    default = None
    # test 4

# Generated at 2022-06-11 16:37:36.838573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test to test method run of class LookupModule.

    Inputs:
    Logger object, ansible_options, ansible_args, ansible_playbook, ansible_play

    Outputs:
    Array containing the output of the method run.
    """
    logger = logging.getLogger(__name__)

    class AnsibleOptions:
        def __init__(self, verbosity=None, inventory=None):
            self.verbosity = verbosity
            self.inventory = inventory

    class AnsibleArgs:
        def __init__(self, context=None):
            self.context = context

    class AnsiblePlaybook:
        def __init__(self, inventory=None):
            self.inventory = inventory


# Generated at 2022-06-11 16:37:44.270966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # generate output
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(['my_var', 'my_second_var'], {'my_var': [1, 2, 3], 'my_second_var': None, 'my_third_var': '5', 'my_fourth_var': {'key': 'value'}})

    # see if the result is what we expected
    expected_result = [1, 2, 3, None]
    assert expected_result == result, "Expected %s, but got %s" % (expected_result, result)

# Generated at 2022-06-11 16:37:55.076823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    # Set needed info for our tests
    lookup = LookupModule()
    lookup.set_options({})

    #
    # First test
    #

    # Set info to make the first test
    myvars = {
        'ansible_play_hosts': ['host1', 'host2', 'host3'],
        'ansible_play_batch': 'host2',
        'ansible_play_hosts_all': ['host1', 'host2', 'host3']
    }
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    # Test if function return need info

# Generated at 2022-06-11 16:38:03.175781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #pylint: disable=unused-variable,protected-access
    from ansible.module_utils.six import PY3

    # class variables
    lookup = LookupModule()
    lookup._templar = "templar"
    lookup._templar._available_variables = {
        'foo': 'bar',
        'hostvars': {
            'inventory_hostname': 'localhost',
            'localhost': {
                'baz': 'buz'}
            }
        }

    # tests
    assert lookup.run(terms=['foo'], variables="variables") == ['bar']
    assert lookup.run(terms=['foo']) == ['bar']

    assert lookup.run(terms=['baz'], variables="variables") == ['buz']

# Generated at 2022-06-11 16:38:14.248673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import errors
    from ansible.module_utils._text import to_bytes
    from unit.mock.template import MockTemplate
    from unittest import TestCase
    from random import randint

    # Create some variables to test
    diskinfo = {
        'sda': {
            'size': '300GB',
            'speed': '7200rpm',
        }
    }

# Generated at 2022-06-11 16:38:25.690800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # setup mock objects
    class mock_templar:
        def __init__(self):
            self.some_available_variable = "foo"
            self._available_variables = {'some_available_variable': self.some_available_variable,
                                         'hostvars': {'some_inventory_hostname': {'some_hostvars_variable': "foobar"}}}

        def template(self, value, fail_on_undefined=None):
            if value != self.some_available_variable:
                return value
            else:
                raise AnsibleUndefinedVariable

    class mock_LookupBase:
        def __init__(self):
            self.options = {'default': None}
            self._templar = mock_templar()


# Generated at 2022-06-11 16:38:35.542713
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    if sys.version_info.major >= 3:
        long = int

    vars = {'inventory_hostname': 'localhost',
            'hostvars':
                {'localhost':
                    {'ansible_play_hosts': ['localhost'],
                     'ansible_play_batch': [],
                     'ansible_play_hosts_all': ['localhost']}
                }
            }

    args = [
        ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'],
        vars,
    ]

    kwargs = {
        'default': 'default',
    }
    # no exception should be raised
    mod = LookupModule()
    mod.run(*args, **kwargs)

# Generated at 2022-06-11 16:38:43.774538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()         # Create an object of class LookupModule
    terms = ['hostvars']            # terms is the list of terms to lookup
    variables = {
        'hostvars': {
            'host1': {'host_key1': 'host_val1'},
            'host2': {'host_key1': 'host_val2'},
            'host3': {'host_key1': 'host_val3'},
            'host4': {'host_key1': 'host_val4'},
        }
    }                               # variables is the dictionary of all variables

    result = module.run(terms,variables)

    assert result == [variables['hostvars']]

# Generated at 2022-06-11 16:38:54.584904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    my_vars = dict(
        hostvars=dict(
            localhost=dict(
                a_hostvar=42,
            )
        ),
        inventory_hostname='localhost',
        a_var=1,
    )
    terms = 'a_var', 'a_hostvar', 'a_missing_var'

    expected = [1, 42, None]
    # All lookups are valid, so we don't want any exception to be raised
    assert lm.run(terms, variables=my_vars) == expected
    # All lookups should succeed, but one is invalid so it will be replaced by None
    assert lm.run(terms, variables=my_vars, default=None) == expected
    # Now, an exception should be raised since invalid lookups cannot be ignored


# Generated at 2022-06-11 16:40:05.215371
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # No value in vars
    lvar = LookupModule()
    lvar._templar.available_variables = dict()
    # Note: PEP8 E128 continuation line under-indented for visual indent
    terms = ['ansible_play_hosts']
    with pytest.raises(AnsibleError) as q:
        lvar.run(terms, variables=lvar._templar.available_variables)
    errstr = 'Invalid setting identifier, "ansible_play_hosts" is not a string, its a list'
    assert str(q.value) == errstr

    # No value in vars
    lvar = LookupModule()
    lvar._templar.available_variables = dict()
    # Note: PEP8 E128 continuation line under-indented for visual indent
    terms

# Generated at 2022-06-11 16:40:15.716625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pool = dict(
        inventory_hostname='test_inventory',
        user='test_user',
        hostvars=dict(
            test_inventory=dict(
                test_var='test_var',
                test_var_undef=None
            )
        )
    )

    module = LookupModule()
    module.set_options(var_options=pool)

    # Valid Variable
    ret = module.run(['test_var'], variables=pool)
    assert ret == ['test_var']

    # Valid Variable from hostvars
    ret = module.run(['hostvars', 'test_inventory', 'test_var'], variables=pool)
    assert ret == ['test_var']

    # Variable is undefined
    ret = module.run(['test_var_undef'], variables=pool)


# Generated at 2022-06-11 16:40:21.966144
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of LookupModule
    obj = LookupModule()
    
    # testing using only terms
    terms = ['variablename']
    obj.run(terms)
    # testing using only terms and variables
    variables = 'variablename'
    obj.run(terms, variables)
    # testing using terms, variables and default
    terms = ['variablename']
    variables = 'variablename'
    default = 'variablevalue'
    obj.run(terms, variables, default)

# Generated at 2022-06-11 16:40:26.972657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['variabl' + 'ename']
    variables = {
        'inventory_hostname': 'localhost',
        'hostvars': {
            'localhost': {
                'variabl': 'hello'
            }
        }
    }
    result = lookup_module.run(terms=terms, variables=variables)
    assert 'hello' == result

# Generated at 2022-06-11 16:40:30.054153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'CaseStudy'
    terms = [term]
    
    variables = {'TestVar': 'TestVarContent', 'CaseStudy': 'CaseStudyContent'}
    
    runArgs = (terms, variables)
    assert run(*runArgs) == ['CaseStudyContent']

# Generated at 2022-06-11 16:40:38.721616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test to make sure class is being set up properly

    test_vars = {
        u'hostvars': {
            u'host_name': {
                u'host_variable': u'host_value'
            }
        },
        u'play_hosts': [u'host_name'],
        u'inventory_hostname': u'host_name',
        u'play_hosts_all': [u'host_name'],
        u'play_batch': [u'host_name'],
        u'group_names': [],
        u'inventory_dir': u'/ansible/inventory'
    }

    lookup = LookupModule()
    lookup_results = lookup.run(terms=["host_variable"], variables=test_vars)
    assert lookup_results == ["host_value"]

   

# Generated at 2022-06-11 16:40:50.434926
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # When no variable is found then AnsibleUndefinedVariable is raised
    fake_templar = {
        '_available_variables': {
            'hostvars': {
                'host1':{
                    'my_var': 'test'
                }
            }
        },
        'available_variables': {
            'inventory_hostname': 'host1'
        }
    }
    lookup_obj = LookupModule(fake_templar)
    try:
        lookup_obj.run(['not_existing_var'])
    except AnsibleUndefinedVariable:
        pass
    else:
        assert False, "AnsibleUndefinedVariable should be raised !!!"

    # When no variable is found then AnsibleUndefinedVariable is raised
    # if default is not set

# Generated at 2022-06-11 16:40:56.338708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setting up parameters
    terms = ['da_var']
    # Setting up expected results
    expected = ['hello']
    # Setting up our test class
    test_class = LookupModule()
    # Setting up variables
    variables = {
        'da_var': 'hello'
    }
    # Setting up kwargs
    kwargs = {'var_options': variables}
    # Getting results
    results = test_class.run(terms, **kwargs)
    assert expected == results