

# Generated at 2022-06-11 16:31:07.780111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Let's use this opportunity to test some of the key features of this lookup as well
    import os
    import sys

    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedString

    from units.mock.vault import VaultLib
    from units.mock.loader import DictDataLoader

    from ansible.template import Templar
    from ansible.vars import DataLoader
    from ansible.vars import VariableManager

    test_dir = os.path.dirname(__file__)

    # Setup environment

# Generated at 2022-06-11 16:31:17.595473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test passing empty terms list
    assert len(lookup.run([], variables={})) == 0
    assert len(lookup.run([], variables={'hostvars': {}})) == 0
    # test passing valid and invalid variable names
    assert ['Hello'] == lookup.run(['hello'], variables={'hello': 'Hello'})
    # test passing a valid variable name should not raise error but return empty list instead
    assert len(lookup.run(['invalid_name'], variables={'hello': 'Hello'})) == 0
    # test passing a valid variable name and default value should return default value
    assert ['default'] == lookup.run(['invalid_name'], variables={'hello': 'Hello'}, default='default')
    # test passing valid variable name with sub variable and valid sub variable


# Generated at 2022-06-11 16:31:24.493086
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {
            'ansible_play_batch': 'test',
            'ansible_play_hosts': 'test',
            'ansible_play_hosts_all': 'test',
            }

    result = module.run(terms, variables)

    expected_result = ['test', 'test', 'test']
    assert result == expected_result

# Generated at 2022-06-11 16:31:29.843976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'vars':{'a':'b', '1':'2'}})
    assert lookup_plugin.run(['a', '1']) == [u'b', u'2']
    assert lookup_plugin.run(['a', '1', 'c'], direct={'vars':{'a':'b', '1':'2', '3':'c'}}) == [u'b', u'2', u'c']

# Generated at 2022-06-11 16:31:38.316284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(['foo', 'bar'], variables={'foo': 'foo', 'bar': 'bar'})
    assert result == ['foo', 'bar']

    try:
        result = lookup.run(['foo', 'bar'], variables={'foo': 'foo'})
    except:
        result = None
    assert result is None
    result = lookup.run(['foo', 'bar'], variables={'foo': 'foo'}, default='default')
    assert result == ['foo', 'default']

# Generated at 2022-06-11 16:31:48.252590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test default run
    terms = ['ansible_play_hosts']
    variables = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'ansible_play_hosts': '127.0.0.1'}}}
    assert lookup_module.run(terms, variables=variables) == ['127.0.0.1']

    # Test default run : batch
    terms = ['ansible_play_batch']
    variables = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'ansible_play_batch': '127.0.0.1'}}}
    assert lookup_module.run(terms, variables=variables) == ['127.0.0.1']

    # Test default run : fail_on_undefined


# Generated at 2022-06-11 16:31:49.368902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule(None, None).run()

# Generated at 2022-06-11 16:31:59.822606
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestLookupModule(unittest.TestCase):
        ''' test LookupModule run method '''

        def setUp(self):
            self.terms = ['c', 'd']

            self.test_module = LookupModule()
            self.test_module._templar = MagicMock()
            self.test_module.set_options = MagicMock()
            self.test_module.get_option = MagicMock(side_effect=['default_value'])

            self.test_module._templar.template.return_value = 'template_result'
            self.test_module._templar.fail_on_undefined = True
            self.test_module

# Generated at 2022-06-11 16:32:10.070996
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("LookupModule: run")

    ####################################################################################################################

    terms = ['test']

    ####################################################################################################################

    variables = {
        'test': 12
    }

    ####################################################################################################################

    kwargs = {
        'default': None
    }

    ####################################################################################################################

    l = LookupModule()
    l._templar._available_variables = variables

    expected = [12]
    actual = l.run(terms, variables, **kwargs)

    assert expected == actual

    ####################################################################################################################

    terms = ['a', 'b', 'c']

    ####################################################################################################################

    variables = {
        'a': 11,
        'b': 22,
        'c': 33
    }

    ####################################################################################################################

    kwargs

# Generated at 2022-06-11 16:32:21.769864
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import shutil
    import sys
    import tempfile
    sys.path.append("/home/ansible/ansible/plugins/lookup")
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.template import Templar

    current_dir = os.path.dirname(os.path.realpath(__file__))
    lookup_file = "/home/ansible/ansible/plugins/lookup/vars.py"
    temp_dir = tempfile.mkdtemp()
    shutil.copy(lookup_file, temp_dir)
    os.chdir(temp_dir)

# Generated at 2022-06-11 16:32:31.557410
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myvars = {
        'my_minimum': 5,
        'my_maximum': 10,
        'my_list': [1, 2, 3]
    }

    test_lookup = LookupModule()

    test_result = test_lookup.run(['my_minimum', 'my_maximum', 'my_list'], myvars)

    assert test_result == [5, 10, [1, 2, 3]]

# Generated at 2022-06-11 16:32:39.398542
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:32:50.231541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import sys
    import json
    import io

    file_name = os.path.join('/etc/ansible/ansible.cfg')
    with open(file_name, 'r') as f:
        text = f.read()
    text = text.replace('host_key_checking = False', 'host_key_checking = True')
    with open(file_name, 'w') as f:
        f.write(text)

# Generated at 2022-06-11 16:33:01.183173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import jinja2
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {
        "ansible_play_hosts": "localhost",
        "ansible_play_batch": "['localhost']",
        "ansible_play_hosts_all": "['localhost']",
        "inventory_hostname": "localhost",
        "hostvars": {
            "localhost": {
                "ansible_play_hosts": "localhost",
                "ansible_play_batch": "['localhost']",
                "ansible_play_hosts_all": "['localhost']",
                "ansible_play_hosts_all_set": "localhost"
            }
        }
    }
    default = None
    templar

# Generated at 2022-06-11 16:33:11.982870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # instantiate the lookup module object
    lm = LookupModule()
    # set the variable from which we will retrieve the value
    lm._templar._available_variables = dict()
    lm._templar._available_variables["variable1"] = { "sub_variable": 12 }
    # no variable found
    try:
        lm.run(["variable2"])
        print("AnsibleUndefinedVariable exception not raised")
    except AnsibleUndefinedVariable:
        pass
    # default defined
    result = lm.run(["variable2"], default="def value")
    assert len(result) == 1
    assert result[0] == "def value"
    # variable found
    result = lm.run(["variable1"])
    assert len(result) == 1
    assert result[0]

# Generated at 2022-06-11 16:33:19.513333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import Templar
    from ansible.template import Jinja2TemplateModule
    from ansible.parsing.dataloader import DataLoader

    data_loader = DataLoader()

    templar = Templar(loader=data_loader)

    test_vars = {'str1': 'str', 'str2': 'str', 'list1': [1, 2, 3, 4], 'list2': [2, 3, 4, 5], 'dict1': {'1': 1, '2': 2, '3': 3}}

# Generated at 2022-06-11 16:33:27.963541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input values
    terms = ['test_term']
    vars_result = {'hostvars': {'host1': {'test_term': 'ret'}}}
    vars_result_default = {'hostvars': {'host1': {'test_term_default': 'ret_default'}}}
    vars_result_default_new = {'hostvars': {'host1': {'test_term_default_new': 'ret_default_new'}}}
    vars_result_no_result = {'hostvars': {'host1': {'test_term_no_result': 'ret_no_result'}}}
    vars_result_no_result_default = {'hostvars': {'host1': {'test_term_no_result': 'ret_no_result_default'}}}

# Generated at 2022-06-11 16:33:37.686214
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:33:47.742479
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import StringIO
    import tempfile
    import yaml

    # Instanciate a new LookupModule object without arguments
    # and call the run method to test it
    lookupModule = LookupModule()
    results = lookupModule.run(["ansible_play_hosts"])
    assert results == ["test-inventory-host"]

    # Instanciate a new LookupModule object with arguments from  a playbook
    # and call the run method to test it
    lookupModule = LookupModule("vars", "ansible_play_", "ansible_play_hosts", "ansible_play_hosts_all")
    templar = lookupModule._templar

# Generated at 2022-06-11 16:33:59.625166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader

    loader = AnsibleLoader(None)
    data =  '''
    myvar: myvalue
    mynestedvar: {mynestedvalue: 5}
    '''
    data = loader.load(data)
    vars = VariableManager()
    vars.extra_vars = data
    templar = vars

# Generated at 2022-06-11 16:34:14.932871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    sys.path.append('./test')
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables=dict(hostvars=HostVars(loader=None, variables=None)))
    templar._available_variables = dict(
        ansible_play_hosts=[], ansible_play_batch=[], ansible_play_hosts_all=[], variablename='hello', myvar='ename'
    )
    lookup_module = LookupModule()
    lookup_module._templar = templar

    # test of term ansible_play_hosts
    result = lookup_module

# Generated at 2022-06-11 16:34:25.480766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    #Terms with only top level variables
    terms = ['a.b', 'a.c.d']
    variables = {'a': [{'b': 'A', 'c': {'d': 'C'}}]}
    result = ['A', 'C']
    assert result == lookup_module.run(terms, variables)

    #Terms with variables in all levels
    terms = ['a.b', 'a.c.d', 'a.c.e']
    variables = {'a': [{'b': 'A', 'c': {'d': 'C', 'e':'E'}}]}
    result = ['A', 'C', 'E']
    assert result == lookup_module.run(terms, variables)

    #Testing variable with list in variable

# Generated at 2022-06-11 16:34:33.295480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Construct arguments
    terms = ("{{ var1 }}", "{{ var2 }}")
    variables = {"var1": "value1", "var2": "value2"}
    kwargs = {}

    # Define expected return value
    expected = ("value1", "value2")

    # Instantiate LookupModule
    look = LookupModule()

    # Get return value
    ret = look.run(terms, variables, **kwargs)

    # Assert results
    assert ret == expected

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-11 16:34:38.940574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for issue #20627 where the templated value of a variable is looked up
    # rather than the actual value of the variable.
    obj = LookupModule()

    class TestTemplar(object):
        _available_variables = {'var': 'value'}

        def template(self, value, fail_on_undefined=True):
            return value
    obj._templar = TestTemplar()

    ret = obj.run(['var'])
    assert len(ret) == 1
    assert ret[0] == 'value'

# Generated at 2022-06-11 16:34:49.162128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the class and a AnsibleModule
    mock_ansible_module = MockAnsibleModule()

    # Create a lookup object so we can inspect its results
    lookup_obj = LookupModule()

    # Mock the AnsibleModule
    mock_ansible_module.params = {
        '_terms': ['foo'],
        'default': 'bar'
    }

    # Create a fake variable to return when doing a lookup
    fake_variable = {
        'foo': 'hello world'
    }

    # Create a fake variable to return when doing a lookup
    fake_variable_2 = {
        'bar': 'hello world',
        'foo': 'hello world'
    }

    mock_ansible_module.run_command.side_effect = [fake_variable]

# Generated at 2022-06-11 16:34:59.448230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    loader = AnsibleLoader(None, vault_password_file='vault_password_file')
    templar = Templar(loader=loader, variables={'hostvars': {'host': {'test_var2': 'value2'}}} )

    lookup = LookupModule(templar)

    # 1. If a variable is undefined, and no default is set, it will result in an error
    lookup.set_options(None, direct={ 'var_options': {'test_var': 'value'} })

# Generated at 2022-06-11 16:35:09.764922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['variablename1', 'variablename2']
  myvars = {
    'variablename1': 4,
    'variablename2': ['somestring']
  }

  assert LookupModule().run(terms, myvars) == [4, ['somestring']]

  myvars = dict()
  try:
    LookupModule().run(terms, myvars)
  except AnsibleUndefinedVariable:
    assert True
  else:
    assert False

  myvars = {
    'variablename1': 4,
  }
  try:
    LookupModule().run(terms, myvars)
  except AnsibleUndefinedVariable:
    assert True
  else:
    assert False


# Generated at 2022-06-11 16:35:20.391913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Test 1 - set variable 'test_var' to variable 'default'
    # 
    test_LookupModule = LookupModule(None)
    test_templar = LookupModule(None)
    test_LookupModule._templar = test_templar
    test_templar._available_variables = {'test_var': 'test'}
    test_LookupModule.set_options(var_options={'test_var': 'test'}, direct={'default':'default'})
    assert test_LookupModule.run(['test_var'], variables={'test_var': 'test'}) == ['default']
    
    # Test 2 - get value of variable 'test_var'
    #
    test_LookupModule = LookupModule(None)

# Generated at 2022-06-11 16:35:31.192167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={'play_hosts': ['localhost', '127.0.0.1'],
                               'play_hosts_all': ['localhost', '127.0.0.1', '127.0.0.2'],
                               'play_batch': [1, 2, 3],
                               'hostvars': {'localhost': {'host_var': 'test'}}
                               })
    test_play_hosts = l.run(['play_hosts'])
    assert test_play_hosts == [['localhost', '127.0.0.1']]
    test_play_batch = l.run(['play_batch'])
    assert test_play_batch == [[1, 2, 3]]

# Generated at 2022-06-11 16:35:37.126320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    res = lookup.run(
        terms=[
            'foo',
            'bar',
        ],
        variables={
            'foo': 'f',
            'bar': 'b',
        },
    )
    assert res == ['f', 'b']

    res = lookup.run(
        terms=[
            'foo',
            'bar',
            'baz',
        ],
        variables={
            'foo': 'f',
            'bar': 'b',
        },
    )
    assert res == ['f', 'b', 'baz']

    res = lookup.run(
        terms=[
            'foo',
            'bar',
        ],
        variables={
            'foo': 'f',
            'bar': 'b',
        },
        default=None,
    )


# Generated at 2022-06-11 16:36:00.868125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={})
    l._templar.set_available_variables({
        "ansible_play_hosts": ["host1", "host2", "host3"],
        "ansible_play_batch": "host1,host2",
        "ansible_play_hosts_all": ["host1", "host2", "localhost"],
        "ansible_play_hosts_all_pattern": "all"
    })
    expected_output = [["host1", "host2", "host3"], "host1,host2", ["host1", "host2", "localhost"]]

# Generated at 2022-06-11 16:36:01.566687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 16:36:11.503702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test_LookupModule_run
    Check if the run method of LookupModule works as expected.
    """

    # Create an instance of LookupModule
    lookup = LookupModule()

    # Arrange
    terms = ['hostvars', 'host1', 'hostname']
    variables = {
        'hostvars': {
            'host1': {'hostname': 'myhost' }
        }
    }

    # Act
    results = lookup.run(terms, variables)

    # Assert
    assert len(results) == 2
    assert results[0] == {'host1': { 'hostname': 'myhost' }}
    assert results[1] == 'myhost'

# Generated at 2022-06-11 16:36:19.467974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.config.manager import ensure_type
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['../../test/unit/inventory/hosts.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    def _get_var(key):
        return variable_manager.get_vars()['hostvars']['banana'][key]

    # All tests should return 'success'
    assert(LookupModule().run(['ansible_play_hosts'], variable_manager.get_vars()) == ['banana'])

# Generated at 2022-06-11 16:36:27.199797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """check the method run of class LookupModule"""

    lookup_module = LookupModule()
    terms = [
        "ansible_play_hosts",
        "ansible_play_batch",
        "ansible_play_hosts_all",
    ]
    variables = {
        "ansible_play_hosts": "hosts",
        "ansible_play_batch": "batch",
        "ansible_play_hosts_all": "hosts_all",
    }
    ret_expected = [
        "hosts",
        "batch",
        "hosts_all",
    ]
    return_actual = lookup_module.run(terms=terms, variables=variables)
    assert ret_expected == return_actual

# Generated at 2022-06-11 16:36:35.258017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['hello']
    variables = {'hello':'world'}
    assert lookup_module.run(terms,variables) == ['world']
    terms = ['hello','world']
    variables = {'hello':'world','world':'hello'}
    assert lookup_module.run(terms,variables) == ['world','hello']
    terms = ['hello','world']
    variables = {'hello':['world','hello']}
    assert lookup_module.run(terms,variables) == [['world','hello']]


# Generated at 2022-06-11 16:36:46.558544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_obj = LookupModule()
    LookupModule_obj.set_loader(None)

    # test for "No variable found with this name" error
    terms = ['foo']
    assert LookupModule_obj.run(terms) == []

    # test for basic use case
    terms = ['bar']
    assert LookupModule_obj.run(terms) == ['abc']

    # test for basic use case with default value
    terms = ['foo']
    assert LookupModule_obj.run(terms, default='hello') == ['hello']

    # test for nested use case
    terms = ['nested']
    assert LookupModule_obj.run(terms) == [{'a': 1}]

    # test for nested use case with default value
    terms = ['nested_foo']
    assert LookupModule_obj

# Generated at 2022-06-11 16:36:48.063243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['testvar']) == ['testval']

# Generated at 2022-06-11 16:36:57.490065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Valid case for bulk get of variables
    data = ['var1', 'var2']
    module.set_options(var_options={'var1':'var1_value', 'var2':'var2_value'})
    assert module.run(data) == ['var1_value', 'var2_value']

    # Undefined variables (AssertionError expected)
    try:
        module.run([])
        assert False
    except AssertionError:
        assert True

    data = 'var1'
    module.set_options(var_options={'var1':{'sub_var1':'sub_var1_value'}})
    assert module.run(data) == [{'sub_var1':'sub_var1_value'}]

    # Invalid setting identifier

# Generated at 2022-06-11 16:37:07.412895
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mocking class LookupBase
    class LookupBase():
        def set_options(self, var_options, direct):
            self._var_options = var_options
            self._direct = direct

        def get_option(self, key):
            return self._direct[key]

    # Mocking class AnsibleModule
    class AnsibleModule():
        def __init__(self, argument_spec, bypass_checks=False):
            self._argument_spec = argument_spec
            self._bypass_checks = bypass_checks

        def params(self):
            return self._argument_spec

        def check_mode(self):
            return self._bypass_checks

    # Mocking class VarModule
    class VarModule():
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 16:37:44.650238
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:37:45.640513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-11 16:37:56.602123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    vars_lookup_plugin = lookup_loader._vars_lookup_plugins['vars']
    vars_lookup = vars_lookup_plugin()

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': 'host1',
                 'ansible_play_batch': 'batch1',
                 'ansible_play_hosts_all': 'all1'}
    assert vars_lookup.run(terms=terms, variables=variables) == ['host1', 'batch1', 'all1']


# Generated at 2022-06-11 16:37:59.026822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['val1', 'val2']
    variables = {'val1': 10, 'val2': 20}
    result = lookup.run(terms, variables)
    assert result == [10, 20]

# Generated at 2022-06-11 16:38:09.443197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyVars:
        def __init__(self, init_vars):
            self.__setattr__('ansible_play_hosts', ["host_0", "host_1", "host_2"])
            self.__setattr__('ansible_play_batch', 0)
            self.__setattr__('ansible_play_hosts_all', ["host_0", "host_1", "host_2", "host_3", "host_4"])
            self.__setattr__('my_var', "my_var_value")
            self.__setattr__('my_var_other', "my_var_other_value")
            self.__setattr__('str_var', "str_var_value")

# Generated at 2022-06-11 16:38:11.744002
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:38:19.249085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()

    var_manager = VariableManager()
    var_manager.set_inventory(loader.load_from_file('test/inventory'))

    mylookup = LookupModule()
    mylookup.set_options(var_options=var_manager)

    assert mylookup.run(["my_var"]) == ["my_value"]
    assert mylookup.run(["my_list"]) == [["a", "b"]]
    assert mylookup.run(["my_dict"]) == [{"a":"b"}]
    assert mylookup.run(["my_dict.a"]) == ["b"]

# Generated at 2022-06-11 16:38:27.204296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test method LookupModule.run()
    """
    terms = ['test_var']
    variables = {'test_var': 'hello'}
    def get_option(self, x):
        return None
    lookup_module_instance = LookupModule()
    lookup_module_instance.get_option = get_option.__get__(lookup_module_instance, LookupModule)
    lookup_module_instance.run(terms, variables=variables)

# Generated at 2022-06-11 16:38:36.583829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests with simple variables
    assert LookupModule(None).run(terms=['test_var'], variables = {'test_var': 'test_value'}) == ['test_value']

    # Tests with more complex variables
    assert LookupModule(None).run(terms=['test_var'], variables = {
            'test_var': {'sub_var': 12},
            'myvar': {'sub_var': 'test_value'}
        }) == [{'sub_var': 12}]

    # Tests with not valid term
    try:
      LookupModule(None).run(terms=[10], variables = {'test_var': 'test_value'})
      assert False
    except AnsibleError as e:
      assert True

    # Tests with default option

# Generated at 2022-06-11 16:38:46.864495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    def _native_dict(d):
        if PY3:
            return d
        else:
            # Python 2.7 returns a dict that is not json serializable.
            # Need to convert it to a native string dictionary
            return {to_native(k, errors='surrogate_or_strict'):
                    to_native(v, errors='surrogate_or_strict')
                    for k, v in d.items()}


# Generated at 2022-06-11 16:39:55.670993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    array = ['ansible_play_batch', 'ansible_play_hosts', 'ansible_play_hosts_all']
    array_expected = ['hosts', 'hosts','hosts']

# Generated at 2022-06-11 16:40:04.683719
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing with one terms
    lookup_plug = LookupModule()
    values = lookup_plug.run(["test"], {"test": "test provided"})
    assert values == ["test provided"]

    # Testing without any terms
    values = lookup_plug.run([], {})
    assert values == []

    # Testing with two terms
    values = lookup_plug.run(["test", "test1"], {"test": "test provided", "test1": "test1 provided"})
    assert values == ["test provided", "test1 provided"]

    # Testing with two terms, one doesn't exist
    try:
        values = lookup_plug.run(["test", "test1"], {"test": "test provided"})
    except AnsibleUndefinedVariable:
        values = None
    assert values is None

    # Testing with two terms, one doesn't

# Generated at 2022-06-11 16:40:15.251252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import inspect
    
    # Answer for run method

# Generated at 2022-06-11 16:40:25.290739
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mockModule = LookupModule()
    terms=['testterm']
    variables = {'testterm': 'testvalue'}

    assert mockModule.run(terms, variables) == ['testvalue']

    mockModule = LookupModule()
    variables = {'ansible_play_hosts': 'testvalue'}
    assert mockModule.run(terms, variables) == []

    mockModule = LookupModule()
    variables = {'hostvars': {'inventory_hostname': {'testterm': 'testvalue'}}}
    assert mockModule.run(terms, variables) == ['testvalue']

    mockModule = LookupModule()
    variables = {'hostvars': {'inventory_hostname': {'testterm': 'testvalue'}}}

# Generated at 2022-06-11 16:40:30.794013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_instance = LookupModule()
    test_instance.set_options(var_options="variables")
    res = test_instance.run(["ansible_env.HOME"])
    assert res == ['/home/ansible']
    res = test_instance.run([None])
    assert res == []
    res = test_instance.run(['ssh_host'])
    assert res == ['127.0.0.1']
    res = test_instance.run(["localhost"])
    assert res == ["localhost"]
    res = test_instance.run(["ansible_play_hosts"])
    assert res == ["localhost"]

# Generated at 2022-06-11 16:40:38.980139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.compat.tests.mock import patch
    from ansible.template import Templar

    # Setup mock objects
    templar_mock = Templar(loader=None, variables={})

    # Create test object
    lm = LookupModule()
    lm._templar = templar_mock

    # Test with a simple var
    assert lm.run([u'my_var'], variables = {u'ansible_play_hosts': [u'localhost']}) == [u'localhost']

    # Test with a nested var
    assert lm.run([u'ansible_play_hosts'], variables = {u'ansible_play_hosts': [u'localhost']}) == [u'localhost']

    # Test with

# Generated at 2022-06-11 16:40:50.222048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod._templar = DummyTemplar()
    assert mod.run(terms=['term'], variables={'term':'value'}) == ['value']
    # With no default, a missing variable should raise an exception
    try:
        mod.run(terms=['term2'], variables={'term':'value'})
        assert False
    except AnsibleException as e:
        assert str(e) == 'template error while templating string: No variable found with this name: term2'
    # With default, a missing variable should return default
    assert mod.run(terms=['term2'], variables={'term':'value'}, default='my default') == ['my default']

# Unit tests for method template of class DummyTemplar

# Generated at 2022-06-11 16:40:54.206686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule.
    #
    #  @param self The object pointer.
    #
    #  @param terms
    #  @param variables
    #  @param kwargs
    #
    #  @return None

    LookupModule.run()

# Generated at 2022-06-11 16:41:01.439942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'],
                               variables={'ansible_play_hosts':['host1', 'host2'], 'ansible_play_batch':['host1', 'host2'],
                                          'ansible_play_hosts_all':['host1', 'host2'], 'inventory_hostname': 'host1'})
    assert result == [['host1', 'host2'], ['host1', 'host2'], ['host1', 'host2']]
