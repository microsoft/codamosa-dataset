

# Generated at 2022-06-11 16:30:58.973059
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Add test cases
    pass

# Generated at 2022-06-11 16:31:04.790624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    res = LookupModule().run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables={'ansible_play_hosts':"test_1", 'ansible_play_batch' :"test_2", 'ansible_play_hosts_all':"test_3"})
    assert res == ['test_1', 'test_2', 'test_3']

# Generated at 2022-06-11 16:31:07.713085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    results = lookup_plugin.run(["testvar1", "testvar2"],
                                dict(testvar1="testvar1", testvar2="testvar2"))

    assert results == ["testvar1", "testvar2"]

# Generated at 2022-06-11 16:31:17.538280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test defaults, no values passed
    test = LookupModule()
    all_modules = {"ansible_play_hosts":[10,20,30], "ansible_play_batch":5, "ansible_play_hosts_all":100}
    result = test.run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"], all_modules)
    assert result == [10, 20, 30, 5, 100]

    # test passing default value
    test = LookupModule()
    result = test.run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"], all_modules, default=0)
    assert result == [10, 20, 30, 5, 100]

    # test passing default value


# Generated at 2022-06-11 16:31:27.920048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_templar = MagicMock()
    mock_templar.template.return_value = 'updated value'
    lookup_module = LookupModule()
    lookup_module._templar = mock_templar
    # testing with expected variables
    result = lookup_module.run(terms=['var1', 'var2'], variables={'var1': 'value1', 'var2': 'value2', 'var3': 'value3'})
    print(result)
    assert result == ['updated value', 'updated value']
    # testing with default value
    result = lookup_module.run(
        terms=['var1', 'var2'],
        variables={'var1': 'value1', 'var2': 'value2', 'var3': 'value3'},
        default='default value')

# Generated at 2022-06-11 16:31:37.734610
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class DummyTemplar():

        def template(self, value, fail_on_undefined = False):
            return value


    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    assert lookup_module._templar.template("some_value") == "some_value"

    items = [{'hostvars':
                  {'hostname':
                       {'some_var': 'some_value'}}
              }]
    #
    lookup_module.set_options(var_options=items, direct={})
    assert lookup_module.run(['some_var'], items) == ['some_value']

# Generated at 2022-06-11 16:31:45.880983
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:31:56.864719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a fake templar
    class FakeTemplar:
        pass

    # Create an instance of LookupModule class
    lookup = LookupModule()
    lookup._templar = FakeTemplar()

    # Pass a name of a variable that doesn't exist in the hostvars/hostinfo file
    host, value = lookup.run(["invalidvar"])
    # Check if host is None and value is None
    assert(host is None and value is None)

    # Pass a name of a variable that exists in the hostvars/hostinfo file
    host, value = lookup.run("inventory_hostname")
    # Check if host is None and value is same as value in hostvars/hostinfo file
    assert(host is None and value == "localhost")

# Generated at 2022-06-11 16:32:03.682458
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:32:12.169527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MyLookupModule(LookupModule):
        def __init__(self, templar, loader, basedir, **kwargs):
            super(MyLookupModule, self).__init__(loader, basedir, templar)
            self.t = templar

        # override method: run()
        def run(self, terms, variables=None, **kwargs):
            print("\n== run() ==")
            print("self._loader: {p}".format(p=self._loader))
            print("self._basedir: {p}".format(p=self._basedir))
            print("self._templar: {p}".format(p=self._templar))
            print("self._templar._loader: {p}".format(p=self._templar._loader))
           

# Generated at 2022-06-11 16:32:26.720105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print()
    print("testing 'run' method of LookupModule")

    from ansible.template import Templar

    templar = Templar(loader=None, variables=None)
    lookup_plugin = LookupModule()
    lookup_plugin._templar = templar

    terms = ['testing_variable1', 'testing_variable2']
    variables = {}
    # testing a normal case
    print("testing a normal case")
    variables["testing_variable1"] = "value1"
    variables["testing_variable2"] = "value2"
    result = lookup_plugin.run(terms, variables)
    assert result == ['value1', 'value2']
    print("test PASSED")

    # testing an error case
    print("testing an error case")
    result = lookup_plugin.run(terms, {})

# Generated at 2022-06-11 16:32:36.410912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native

    lkm = LookupModule()

    # test 1
    result = lkm.run(terms=('hostvars',), variables=dict(hostvars=dict(hostname=dict(key='value'))))
    assert result == [{'hostname': {'key': 'value'}}]

    # test 2
    lkm._templar.available_variables = dict(hostvars=dict(hostname=dict(key='value')))
    result = lkm.run(terms=('hostvars',))
    assert result == [{'hostname': {'key': 'value'}}]

    # test 3

# Generated at 2022-06-11 16:32:48.509437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a test object
    testobj = LookupModule()

    # Create a test variables
    test_vars = {'variablename': 'hello',
                 'myvar': 'ename',
                 'variablnotename': 'hello2',
                 'myvar2': 'notename',
                 'ansible_play_hosts': 'all',
                 'ansible_play_batch': '1',
                 'ansible_play_hosts_all': 'all',
                 'variablename2': {'sub_var': 12},
                 'myvar3': 'ename2'}

    # run with only one term
    test_term = "variablename"
    ret = testobj.run([test_term], variables=test_vars,)
    assert ret == ['hello']

    # run with only one term

# Generated at 2022-06-11 16:32:56.062512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    template = "{{ lookup('vars', 'variabl' + myvar) }}"
    myvars = {
        'variablename': 'hello',
        'myvar': 'ename'
    }
    expected_output = "hello"
    result = lookup_plugin._templar.template(template, variables=myvars, fail_on_undefined=True)
    assert expected_output == result

# Generated at 2022-06-11 16:33:03.378053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Object module
    module = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    terms_wrong = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all', 'ansible_play_hosts_all2']

# Generated at 2022-06-11 16:33:13.710214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar._available_variables = {
                                            'variablename': 'value',
                                            'hostvars':
                                                {'localhost':
                                                    {'variable_nested': {'sub_var': 12}}
                                                }
                                            }
    lookup._templar._available_variables['inventory_hostname'] = 'localhost'
    # Check that it returns the value of 'variablename'
    assert lookup.run(terms='variablename') == ['value']
    # Check that it raises an error if 'variablenotename' is requested
    try:
        lookup.run(terms='variablenotename')
    except AnsibleError as e:
        assert "No variable found with this name: variablenotename"

# Generated at 2022-06-11 16:33:20.578095
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Necessary Variables
    variable_name = 'my_var'
    variable_value = {'sub_var': 'value'}
    variable_value_str = "test"
    variable_value_int = 20

    terms = [variable_name, 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {
        'inventory_hostname': 'host',
        'hostvars': {
            'host': {
                variable_name: variable_value,
                'ansible_play_hosts': 'all',
                'ansible_play_batch': 'all',
                'ansible_play_hosts_all': 'all'
            }
        }
    }

    # Implementing the test class

# Generated at 2022-06-11 16:33:28.509045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test mocking attributes and methods of class
    # LookupBase, which is the parent class of LookupModule
    class MockLookupBase(LookupBase):
        def __init__(self):
            self._options = {'default': 'default'}
            self._templar = MockTemplar()
            self._loader = None
            self._templar._available_variables = {}

        def get_option(self, option):
            return self._options[option]

        def set_options(self, var_options=None, direct=None):
            if var_options is not None:
                self._templar._available_variables = var_options
            if direct is not None:
                self._options['default'] = direct['default']


# Generated at 2022-06-11 16:33:35.780285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    lookup._templar = mock.Mock()
    lookup._templar._available_variables = {}
    lookup._templar.template = lambda x, fail_on_undefined=True: x
    lookup.set_options = lambda var_options=None, direct=None: None

    assert lookup.run(terms=["hostvars"]) == []
    assert lookup.run(terms=["hostvars"], variables=[1, 2, 3, 4], default=None) == []


# Generated at 2022-06-11 16:33:38.276362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [u'variable']
    variables = {u'variable': u'foobar'}
    mylookup = LookupModule()
    mylookup.run(terms, variables)

# Generated at 2022-06-11 16:33:56.152078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ['_terms', 'bad_terms']
    variables = {'_terms': 1, 'bad_terms': 2, 'hostvars': {'inventory_hostname': {'_terms': 3, 'bad_terms': 4}}}
    default = 'default_value'
    myvars = {'_terms': 5, 'bad_terms': 6, 'inventory_hostname': 'inventory_hostname_value', 'hostvars': {'inventory_hostname_2': {'_terms': 7, 'bad_terms': 8}}}
    myvars['hostvars']['inventory_hostname'] = myvars['hostvars']['inventory_hostname_2']
    obj = LookupModule()
    obj._templar = type('Templar', (object,), {})
    obj._

# Generated at 2022-06-11 16:34:02.616982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    terms = [ "foo" ] # single term
    default = "bar" # default string
    myvars = {
        "foo": "{{ value }}",
        "value": "baz",
    } # variables in the environment

    # check that the correct value is returned
    assert "baz" == LookupModule().run(terms, variables=myvars, default=default)[0]

    # check that the wrong value doesn't return anything
    assert [] == LookupModule().run(["bar"], variables=myvars, default=default)

    # check that raising AnsibleUndefinedVariable when default is not passed works

# Generated at 2022-06-11 16:34:03.494173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(None)

# Generated at 2022-06-11 16:34:11.914710
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_LookupModule = LookupModule()
    lookup_params = {}
    lookup_params['_templar'] = 'templar'
    lookup_params['templar'] = 'templar'

# Generated at 2022-06-11 16:34:21.822000
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test module
    def test_module(path, data, **kwargs):
        return True
    # Test connection
    class Connection(object):
        @staticmethod
        def _exec_command(cmd, tmp_path=None, in_data=None, sudoable=True, **kwargs):
            return (0, '', '')
        def exec_command(self, cmd, tmp_path=None, in_data=None, sudoable=True, **kwargs):
            return (0, '', '')
        def put_file(self, in_path, out_path):
            pass
        def fetch_file(self, in_path, out_path):
            pass
        def close(self):
            pass

    # Set up a minimal structure to use LookupBase

# Generated at 2022-06-11 16:34:30.443393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m_templar = MagicMock()
    m_templar._available_variables = {}

    m_lookup_base = MagicMock()
    m_lookup_base.get_option = MagicMock(return_value=None)
    m_lookup_base._templar = m_templar

    test_terms = [['item1'], 'item2']

    lookup_module = LookupModule()
    lookup_module.set_options = MagicMock()
    lookup_module.run(test_terms, variables={})
    lookup_module.set_options.assert_called_with(var_options={}, direct={})
    m_lookup_base.get_option.assert_called_with('default')


# Generated at 2022-06-11 16:34:39.225411
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupModule = LookupModule()

    # test if method run return the same result with different settings
    def test_run(terms, variables, **kwargs):
        assert lookupModule.run(terms, variables, **kwargs) == lookupModule.run(terms, variables, **kwargs)

    test_run(terms=None, variables=None)
    test_run(terms=["hostvars"], variables={"hostvars": {}, "inventory_hostname": "localhost"})

    dict = {"my_var": "my_value"}
    test_run(terms=["my_var"], variables=dict)
    test_run(terms=["my_var"], variables=None, **dict)

    dict = {"my_var": "my_value"}

# Generated at 2022-06-11 16:34:49.234647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.plugins.lookup.vars import LookupModule

    lookup = LookupModule()

# Generated at 2022-06-11 16:34:59.488735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ test docstring """
    #########################################################################
    # Test with success                                                     #
    #########################################################################
    terms = ['variablename', 'variablename']
    variables = {'variablename': 'some_variable', 'variablename': 'some_variable'}
    default = {'default': ''}
    
    test_obj = LookupModule()
    result = test_obj.run(terms, variables, **default)
    assert result == ['some_variable', 'some_variable']

    #########################################################################
    # Test with failure due to missing variable                             #
    #########################################################################
    terms = ['variablename', 'variablename']
    variables = {'variablename': 'some_variable', 'variablename': 'some_variable'}

# Generated at 2022-06-11 16:35:09.796126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Ansible 2.8.0 removed the private _available_variables and _data attributes
    # from the AnsibleTemplar class.  This version switch is needed to support that.
    from ansible.utils.version import ansible_version
    ver = ansible_version.__version_info__
    if ver[0] > 2 or (ver[0] == 2 and ver[1] >= 8):
        lm = LookupModule()
        myvars = {'variablename': 'hello',
                  'myvar': 'ename',
                  'inventory_hostname': 'test',
                  'hostvars': {'test': {'variablename': 'world'}}}
        terms = ['variablename', 'variablename']
        assert lm.run(terms, myvars) == ['world', 'world']

# Generated at 2022-06-11 16:35:32.949261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    lookup_plugin = LookupModule()

    # Test 1: run()
    # happy path
    test_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    result = lookup_plugin.run(
        terms=test_terms,
        variables=variable_manager.get_vars(),
        )

# Generated at 2022-06-11 16:35:44.026077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import filecmp
    import shutil
    import pprint

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    def get_as_dict(output):
        if output and isinstance(output, list):
            output = output[0]
        elif output and isinstance(output, dict):
            output = output.copy()
        elif output:
            output = str(output)
        return output

    mybasedir = os.path.dirname(__file__)
   

# Generated at 2022-06-11 16:35:48.990177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  # test with valid arguments
  lookup_module.run(terms=['test_variable'],variables={'test_variable': 'test_value'})
  # test with missing required argument 'terms'
  lookup_module.run(variables={'test_variable': 'test_value'})

# Generated at 2022-06-11 16:35:59.316626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleMapping
    l = LookupModule()
    l._templar = AnsibleMapping()
    l._templar.available_variables = {'a': 'avar', 'b': 'bvar'}
    assert l.run(terms=['a']) == ['avar']
    assert l.run(terms=['a'], variables={'a': 'x'}) == ['x']
    assert l.run(terms=['b']) == ['bvar']
    assert l.run(terms=['c'], default='cvar') == ['cvar']
    assert l.run(terms=['c'], variables={'c': 'cvar'}) == ['cvar']

# Generated at 2022-06-11 16:36:10.560323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_plugin = LookupModule()

        # Test with input names and common.
        assert lookup_plugin.run(terms=['a', 'b', 'common'], variables={'a': 1, 'b': 2, 'common': 3}) == [1, 2, 3]
        assert lookup_plugin.run(terms=['a', 'b', 'common'], variables={'a': 1, 'b': 2, 'common': 3, 'other': 4}) == [1, 2, 3]
        assert lookup_plugin.run(terms=['a', 'b', 'common'], variables={'a': 1, 'b': 2, 'common': 3, 'other': 4}, direct={'_ansible_remote_tmp': 'test'}) == [1, 2, 3]

        # Test with input names and hostvars.
        assert lookup_

# Generated at 2022-06-11 16:36:18.931677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    myvars = {'inventory_hostname': 'localhost',
              'hostvars': {'localhost': {'ansible_play_batch': ['localhost'],
                                         'ansible_play_hosts': ['localhost'],
                                         'ansible_play_hosts_all': ['localhost']}},
              'ansible_play_batch': ['localhost'],
              'ansible_play_hosts': ['localhost'],
              'ansible_play_hosts_all': ['localhost']}
    r_value = [['localhost'], ['localhost'], ['localhost']]

    module = LookupModule()
    module._templar._available_variables = myvars
   

# Generated at 2022-06-11 16:36:22.771019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(['ansible_playbook_python'], {'ansible_playbook_python': '/usr/bin/python3'}, direct={})
    assert result == ['/usr/bin/python3']

# Generated at 2022-06-11 16:36:32.139524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run"""
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars import VariableManager
    terms = [AnsibleUnicode('ansible_play_hosts'),
             AnsibleUnicode('ansible_play_batch'),
             AnsibleUnicode('ansible_play_hosts_all')]
    variables = {'ansible_play_hosts': ['this_host', 'that_host'],
                 'ansible_play_batch': {'index': 0, 'size': 1},
                 'ansible_play_hosts_all': ['this_host', 'that_host']}

    templar = Templar(loader=None)
    templar._available_variables = variables
    set

# Generated at 2022-06-11 16:36:40.339139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    lm = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts':['127.0.0.1', '10.0.73.192'], 'ansible_play_batch':['127.0.0.1', '10.0.73.192'], 'ansible_play_hosts_all':['127.0.0.1', '10.0.73.192']}
    result = lm.run(terms, variables)

# Generated at 2022-06-11 16:36:50.837467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    vault_pass = 'password'
    secret_vars = {'secret': 'password'}

    vault = VaultLib(vault_pass)
    vars_encrypted = vault.encrypt(secret_vars)

    secret_vars.update({'encrypt': 'this is not encrypted'})
    secret_vars.update(vars_encrypted)

    loader = DataLoader()
    variables = loader.load_from_file('/dev/null', vault_password=vault_pass,
                                      vault_secrets=secret_vars)

    templar = Templar(loader=loader, variables=variables)
    lookup = LookupModule()


# Generated at 2022-06-11 16:37:27.723830
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:37:28.257224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 16:37:36.761577
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test that run() will raise error when terms passed in is not a string

    lookup = LookupModule()
    lookup.set_options(default=None)

    myvars = {
        "hostvars": {
            "host": {
                "var_name": "var_value"
            }
        }
    }

    terms = ["var_name"]

    # Test that run() will also return the top-level variable
    # defined in myvars when it is called with a variable.

    returned_value = lookup.run(terms, variables=myvars)

    assert returned_value == ["var_value"]

    # Test that run() will raise error when terms passed in is not a string

    terms = [["var_name", "var_name2"]]


# Generated at 2022-06-11 16:37:37.347454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 16:37:47.926756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(terms=['foo'], variables={'foo': 'hello_world'})
    assert ret == ['hello_world']

    ret = LookupModule().run(terms=['hostvars.host1.foo'], variables={'hostvars': {'host1': {'foo': 'hello_world'}}})
    assert ret == ['hello_world']

    ret = LookupModule().run(terms=['hostvars.inventory_hostname.foo'], variables={'hostvars': {'inventory_hostname': {'foo': 'hello_world'}}})
    assert ret == ['hello_world']


# Generated at 2022-06-11 16:37:52.282417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # perform lookup module
    lookup = LookupModule()
    try:
        res = lookup.run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"])
    except:
        res = []
    assert isinstance(res, list)

# Generated at 2022-06-11 16:38:01.643150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    hostvars = {'test_host': {'test_var': 'test_value'}}
    templar = DummyTemplar(vars={'inventory_hostname': 'test_host', 'hostvars': hostvars}, fail_on_undefined=True)
    lookup = LookupModule(loader=None, templar=templar, basedir=None)
    assert lookup.run(['test_var'], variables={'hostvars': hostvars}) == ['test_value']

# Generated at 2022-06-11 16:38:13.251541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostvars = {
        'host1': {
            'var1': 'host1var1',
            'var2': 'host1var2',
            'var3': 'host1var3',
            'var4': 'host1var4',
            'var5': 'host1var5',
        },
    }
    test_result = [
        ['var1', 'var2', 'var3', 'var4', 'var5'],
        ['var1', 'var2', 'var3', 'var4', 'var5'],
        ['var5', 'var5'],
    ]

# Generated at 2022-06-11 16:38:23.598572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class vars_lookup_test():
        def __init__(self):
            self.errors = []
        def set_options(self, var_options=None, direct=None):
            if var_options:
                self.var_options = var_options
            if direct:
                self.direct = direct
        def get_option(self, param_name):
            if param_name == 'default':
                return self.var_options
        def run(self, terms, variables=None, **kwargs):
            self.variables = variables
            ansible_vars = getattr(self._templar, '_available_variables', {})

# Generated at 2022-06-11 16:38:27.705727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    import os

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ lookup("vars", "hostvars")}}')))
        ]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)
    tqm = None

# Generated at 2022-06-11 16:39:36.591286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context

    test_context = context.CLIContext()

    test_varmgr = test_context.variable_manager
    test_varmgr._extra_vars = {'test_extra': '1234', 'ansible_play_hosts': 'testHosts',
                               'ansible_play_batch': 'testBatch', 'ansible_play_hosts_all': 'testHostsAll',
                               'hostvars': {'inventoryhost1': {'host': '1'}, 'inventoryhost2': {'host': '2'}}}
    test_term = 'test_extra'
    test_terms = [test_term, 'unknowVariable']
    test_terms_hosts = ['hostvars', 'hostvars', 'ansible_play_hosts']
    test_terms

# Generated at 2022-06-11 16:39:45.639234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms=['myvar'], variables={'myvar': 'this is a test'})
    assert result == ['this is a test']

    result = lookup_module.run(terms=['myvar'], variables={'myvar': 'this is a test'}, default='not found')
    assert result == ['this is a test']

    result = lookup_module.run(terms=['notexist'], variables={'myvar': 'this is a test'}, default='not found')
    assert result == ['not found']

    result = lookup_module.run(terms=['notexist'], variables={'myvar': 'this is a test'})
    assert result == []

# Generated at 2022-06-11 16:39:57.158495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    mod = LookupModule()
    mod.set_options({'default': {}})
    result = mod.run([to_bytes('ansible_playbook_python')],
                                 {'ansible_playbook_python': '/usr/bin/python'})
    assert result == ['/usr/bin/python']
    result = mod.run([to_bytes('ansible_playbook_pythonx')],
                                 {'ansible_playbook_python': '/usr/bin/python'})
    assert result == [{}]
    result = mod.run([to_bytes('ansible_playbook_python'), to_bytes('ansible_playbook_pythonx')],
                                 {'ansible_playbook_python': '/usr/bin/python'})


# Generated at 2022-06-11 16:40:05.531215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import iteritems
    from ansible.plugins.lookup.vars import LookupModule

    # Create test class
    class OptionsModule:
        def __init__(self, var_options=None, direct=None):
            self.direct = direct
            self.var_options = var_options
            self.var = None
            self.no_log = None
            self.warn_only = None

    class TemplarModule:
        def __init__(self, myvars, fail_on_undefined):
            self.myvars = myvars
            self.fail_on_undefined = fail_on_undefined
            self._available_variables = None
            self.available_variables = None

# Generated at 2022-06-11 16:40:10.046024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    terms = ['foo', 'bar']
    variables = {'foo': 'baz', 'inventory_hostname': 'test_host'}
    kwargs = {'default': 'default_val'}

    assert module.run(terms, variables, **kwargs) == ['baz', 'default_val']

# Generated at 2022-06-11 16:40:17.864485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myLModule = LookupModule()
    basedir = os.path.join(os.path.dirname(__file__), '../..', 'lib/ansible')
    myLModule._templar = Templar(basedir=basedir)
    terms = ['value1', 'value2', 'value3', 'value4']
    check_terms = ['value1', 'value2', 'value3', 'value4']
    variables = {'value1': 'Hello World!', 'value2': 'I', 'value3': 'You', 'value4': 'We'}
    ret = myLModule.run(terms, variables)
    assert ret == check_terms

# Generated at 2022-06-11 16:40:27.009687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # LookupModule.__init__()
    test_lookup_module = LookupModule()

    # mock template
    def mock_template(template, fail_on_undefined=True):
        return template
    test_lookup_module._templar.template = mock_template

    # call method run()
    # assert method run() of class LookupModule
    assert test_lookup_module.run("variable") == [None]

    test_lookup_module._templar._available_variables = {
        "hostvars": {
            "test_host": {"variable": "Blue"}
        },
        "inventory_hostname": "test_host"
    }
    
    assert test_lookup_module.run("variable") == ["Blue"]

# Generated at 2022-06-11 16:40:36.019865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    my_variables = { "hostvars": { "host1": { "var1": "value1", "var2": "value2" } }, "var3": "value3", "var4": "value4", "inventory_hostname": AnsibleUnicode("host1") }
    my_terms = [ "var1", "var2", "var3", "var4", "var5" ]
    my_result = [ "value1", "value2", "value3", "value4", None ]

    my_lookup = LookupModule()
    my_results = my_lookup.run(my_terms, my_variables, default=None)
    assert(my_results == my_result)

# Generated at 2022-06-11 16:40:46.528603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_item(vars, item):
        return vars[item]

    lookup_plugin = LookupModule()
    lookup_plugin.get_option = get_item

    def test_run_returns_expected(vars, terms, expected_returns):
        lookup_plugin._templar = DummyTemplar(vars)
        assert(lookup_plugin.run(terms, variables=vars) == expected_returns)

    # simple check
    test_run_returns_expected({'a': 1, 'b': 2, 'c': 3}, ['a'], [1])
    # returns list of values
    test_run_returns_expected({'a': 1, 'b': 2, 'c': 3}, ['a', 'b', 'c'], [1, 2, 3])

    # test

# Generated at 2022-06-11 16:40:56.764794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    y = {
        'variablename': 'hello',
        'myvar': 'ename'
    }
    assert x.run(terms=['variablename'], variables=y) == ['hello']
    assert x.run(terms=['variabl' + y.get('myvar')], variables=y) == ['hello']
    assert x.run(terms=['variabl' + y.get('myvar')], variables=y, default='') == ['hello']
    assert x.run(terms=['variabl' + y.get('myvar')], variables=y, default='') == ['hello']