

# Generated at 2022-06-11 16:31:07.232537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.utils.vars
    import ansible.parsing.vault
    import os
    import sys

    # reset
    try:
        os.remove('test.yml')
    except OSError:
        pass

    password = 'secret'

    # setup
    vault_password_file = 'test/fixtures/ansible-vault/vault-password-file'
    result = ansible.parsing.vault.VaultLib(password, 0).encrypt_string(
        'password: "{{ vault_password }}"',
        vencformat='yaml'
    )
    f = open('test.yml', 'w')
    f.write(result)
    f.close()


# Generated at 2022-06-11 16:31:17.211777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-import
    # import pytest
    mock_templar = MagicMock()
    mock_loader = MagicMock()
    mock_ds = MagicMock()
    mock_inventory = MagicMock()
    mock_play_context = MagicMock()
    mock_variables = MagicMock()
    mock_options = MagicMock()
    mock_options.__getitem__.side_effect = lambda key: mock_options[key]
    mock_options.copy.return_value = mock_options
    lookup_obj1 = LookupModule(loader=mock_loader,
                               templar=mock_templar,
                               variables=mock_variables)
    lookup_obj1.set_loader(mock_loader)
    lookup_obj1.set

# Generated at 2022-06-11 16:31:27.719921
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_module = AnsibleModuleMock()

    data = dict()
    data['templar'] = dict()
    data['templar']['hostvars'] = dict()
    data['templar']['inventory_hostname'] = '10.1.1.1'
    data['templar']['_available_variables'] = dict()
    data['templar']['_available_variables']['var1'] = 'val1'
    data['templar']['_available_variables']['inventory_hostname'] = '10.1.1.1'
    data['templar']['_available_variables']['hostvars'] = dict()

# Generated at 2022-06-11 16:31:35.620842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    input_data = '{{ var }}'
    lookup_result = ['okidoki']
    lookup_data = {'var': 'okidoki'}

    # Create a LookupModule object
    lookup_obj = LookupModule()
    lookup_obj.set_options(direct={'var': 'okidoki'})

    assert lookup_obj.run(terms=input_data) == lookup_result
    assert lookup_obj.run(terms=input_data, variables=lookup_data) == lookup_result

# Generated at 2022-06-11 16:31:44.831131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from collections import namedtuple
    import json

    if not PY3:
        from ansible.utils.unicode import to_unicode
        to_text = to_unicode

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader=loader)

    vault_secrets_file = ''
    vault_password = 'secret'


# Generated at 2022-06-11 16:31:55.800027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeAnsibleModule(object):
        class FakeAnsibleModule_Templar(object):
            def __init__(self):
                self._available_variables = {}
            def template(self, value, fail_on_undefined):
                template = str(value)
                return template

        def __init__(self):
            self.params = {}
            self.Templar = self.FakeAnsibleModule_Templar()

    module = FakeAnsibleModule()
    module.params['inventory_hostname'] = "localhost"
    module.params['hostvars'] = {"localhost": {"my_var1": "myvar1"}}
    assert LookupModule(module).run(["my_var1"]) == ["myvar1"]

# Generated at 2022-06-11 16:32:00.016355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test with single variable
    term = ['myvar']
    variables = dict(myvar='hello')
    result = module.run(term, variables)
    assert result == ['hello']
    # Test with multiple variables
    term = ['myvar', 'myvar2']
    variables = dict(myvar='hello', myvar2='world')
    result = module.run(term, variables)
    assert result == ['hello', 'world']
    # Test with variable that does not exist
    term = ['myvar3']
    variables = dict(myvar='hello', myvar2='world')
    result = module.run(term, variables)
    assert result == ['hello']
    # Test with variable that does not exist without default
    term = ['myvar3']

# Generated at 2022-06-11 16:32:00.657926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-11 16:32:07.259267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()

    # Test error
    try:
        m.run(['invalid'], variables={})
    except AnsibleError:
        pass

    # Test undefined error
    try:
        m.run(['invalid'], variables={})
    except AnsibleUndefinedVariable:
        pass

    # Test default value
    assert m.run(['invalid'], variables={}, default='default') == ['default']

# Generated at 2022-06-11 16:32:18.624928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = dict(
        _available_variables = dict(a = 1,
                                    b = 2,
                                    hostvars = dict(local = dict(b = 'abc'))))
    
    def fail_run(terms, variables=None, **kwargs):
        lookup.set_options(var_options=variables, direct=kwargs)
        lookup_result = lookup.run(terms, variables=variables)
        assert lookup_result == []
        return lookup_result
    
    def succ_run(terms, variables=None, **kwargs):
        lookup.set_options(var_options=variables, direct=kwargs)
        lookup_result = lookup.run(terms, variables=variables)

        assert lookup_result == [1]
        return lookup_result

# Generated at 2022-06-11 16:32:32.615264
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:32:39.951735
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # term is a list of strings
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all', 'ansible_play_hosts_wo_localhosts']
    # variables is a dictionary
    variables = {'ansible_play_hosts': [u'localhost'],
                'ansible_play_batch': u'0',
                'ansible_play_hosts_all': [u'localhost'],
                'ansible_play_hosts_wo_localhosts': [u'localhost'],
                'inventory_hostname': u'localhost'}
    kwargs = {}
    ret = LookupModule.run(terms, variables, kwargs)

    # ret is a list of strings

# Generated at 2022-06-11 16:32:48.035156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myclass = LookupModule()
    default_arg = None
    terms_arg = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables_arg = {'ansible_play_batch': 'batch','ansible_play_hosts':'host','ansible_play_hosts_all':'all'}

    assert myclass.run(terms_arg, variables_arg, default=default_arg) == ['host', 'batch', 'all']

# Generated at 2022-06-11 16:32:59.510467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    assert lookup_module.run([['hostvars', 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']]) == [[['localhost'], None, [['localhost']], [['localhost']]]]
    assert lookup_module.run([[['hostvars', 'ansible_play_hosts'], ['ansible_play_batch'], ['ansible_play_hosts_all']]]) == [[['localhost'], None, [['localhost']], [['localhost']]]]

# Generated at 2022-06-11 16:33:09.862506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()

    # The parameters are all set in this example, but we're not testing them.
    my_lookup.set_options(var_options=None, direct=None)

    # Expected results
    expected_1 = ["12"]
    expected_2 = ["hel"]

    # Actual results
    actual_1 = my_lookup.run(["variabl' + myvar|int"], variables={"variablename": "12", "myvar": "ename"})
    actual_2 = my_lookup.run(["variabl' + myvar|slice(0, 3)"], variables={"variablename": "hello", "myvar": "ename"})

    assert actual_1 == expected_1
    assert actual_2 == expected_2

# Generated at 2022-06-11 16:33:18.231310
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    module.set_options(dict(default=None))
    module._templar._available_variables = {
        'hostvars': {'host1': {'var1': 'value1', 'var2': 'value2'}},
        'inventory_hostname': 'host1'
    }

    # Test case 1
    terms = ['var1', 'var2']
    actual = module.run(terms)
    assert actual == ['value1', 'value2']

    # Test case 2
    terms = ['var1', 'var2', 'var3']
    try:
        actual = module.run(terms)
    except AnsibleError as e:
        assert str(e) == 'No variable found with this name: var3'

# Generated at 2022-06-11 16:33:27.218639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t1 = {
            'hostvars': {
                'host1': {'v1': 'value1', 'v2': 'value2'},
                'host2': {'v1': 'value11', 'v2': 'value22'},
            }
        }

    t2 = {
            'hostvars': {
                'host1': {'v1': 'value1', 'v2': 'value2'},
                'host2': {'v1': 'value11', 'v2': 'value22'},
            },
            'inventory_hostname': 'host1'
        }


# Generated at 2022-06-11 16:33:35.494455
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = dict(
        term1 = 'term1',
        term2 = 'term2'
    )
    variables = dict(
        term1 = 'term1',
        term2 = 'term2'
    )
    lm = LookupModule()
    lm.set_options(var_options=variables, direct=dict())
    lm._templar._available_variables = variables
    lm._templar.template = lambda x: x
    _value = lm.run(terms=terms.keys(), variables=variables)
    assert _value == terms.values()


# Generated at 2022-06-11 16:33:45.766270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.vars
    ansible.plugins.lookup.vars.LookupModule._templar = None
    ansible.plugins.lookup.vars.LookupModule._available_variables = None
    ansible.plugins.lookup.vars.LookupModule._available_variables = {
        'variablename': 'hello',
        'ansible_play_hosts': [
            '10.10.10.11',
            '10.10.10.12',
        ],
        'ansible_play_batch': [
            '10.10.10.11',
        ],
        'ansible_play_hosts_all': [
            '10.10.10.11',
            '10.10.10.12',
        ],
    }
    lm

# Generated at 2022-06-11 16:33:47.240834
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=["hello"], variables={"hello": 1}), [1]

# Generated at 2022-06-11 16:34:04.206626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule.

    """
    # Arrange
    terms = ['term1','term2','term3','term4','term5']
    variables = {'term1': 'value1', 'term4': 'value4'}

    def test_run_body(module_name, class_name, direct, var_options):
        module = __import__(module_name)
        class_obj = module.__dict__[class_name]
        return class_obj().run(terms, variables, **direct)

    # Act
    module_name = 'ansible.plugins.lookup.vars'
    class_name = 'LookupModule'
    direct = {'default':'default_value'}

# Generated at 2022-06-11 16:34:09.500884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(terms=['ansible_play_hosts', 'ansible_play_batch'],variables={'hostvars':{'localhost':{'ansible_play_hosts':{'stda':{'a':'b'}}},'ansible_play_batch':{'sda':{'a':'b'}}}})
    assert result == [{'a':'b'},{'a':'b'}]

# Generated at 2022-06-11 16:34:15.427206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    if sys.version_info[0] == 2:
        from cStringIO import StringIO
    else:
        from io import StringIO
    import mock
    import pytest

    # Check with no parameters
    with pytest.raises(Exception) as excinfo:
        l = LookupModule()
        l.run()
    assert 'One of the following is required: terms' in str(excinfo.value)

    # Check with one parameter
    with pytest.raises(Exception) as excinfo:
        l = LookupModule()
        l.run([])
    assert 'One of the following is required: terms' in str(excinfo.value)

    # Check with more parameters
    with pytest.raises(Exception) as excinfo:
        l = LookupModule()

# Generated at 2022-06-11 16:34:26.024294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()

    # Test
    assert module.run('my_var') == ['my_value']

    # Test #2
    assert module.run(['my_var_1', 'my_var_2']) == ['my_value_1', 'my_value_2']

    # Test #3
    assert module.run(['my_var_1', 'my_var_2', 'my_var_3']) == ['my_value_1', 'my_value_2', 'my_value_3']

    # Test #4
    assert module.run(['my_var_1', 'my_var_2'], variables={'my_var_2': 'value2'}) == ['my_value_1', 'value2']

    # Test #5

# Generated at 2022-06-11 16:34:32.776235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test successful case
    my_terms = [ 'variablename', 'myvar' ]
    my_variables = {
        'variablename': 'hello',
        'myvar': 'ename',
        'hostvars': {
            'localhost': {
                'variablename': 'hello'
            }
        },
        'inventory_hostname': 'localhost'
    }

    expected_result = [ 'hello', 'ename' ]
    assert LookupModule().run(my_terms, my_variables) == expected_result, "TEST1: Unexpected output"

    # Test with key error
    my_terms = [ 'variablename', 'myvar' ]

# Generated at 2022-06-11 16:34:40.207395
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 16:34:49.854741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest

    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase

    lookup_base = LookupBase()

    def test_bind_and_get(lookup_base, search_path, request, bind_value):
        """
        bind temporary var and get it back
        """
        try:
            lookup_base.bind_vars(variables=dict(request=bind_value))
            return lookup_base.get_vars(variables=dict(request=request))
        finally:
            lookup_base.bind_vars(variables=dict(request=None))


# Generated at 2022-06-11 16:34:59.878627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    params = dict(
        terms=['name1', 'name2', 'name3'],
        variables={'name1': 'val1', 'name2': 'val2', 'name3': 'val3', 'name4': 'val4'},
        default='val5'
    )

    ret_val = lookup_module.run(**params)
    assert type(ret_val) is list
    assert ret_val == ['val1', 'val2', 'val3']

    params = dict(
        terms=['name1', 'name2', 'name3'],
        variables={'name1': 'val1', 'name2': 'val2', 'name4': 'val4'},
        default='val5'
    )


# Generated at 2022-06-11 16:35:06.369933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    myList = []
    myList.append(string_types)
    myList.append(str)
    myList.append(AnsibleError)
    myList.append(AnsibleUndefinedVariable)

    for elem in myList:
        test_LookupModule_run_paramter_string_type(elem)

    # test_LookupModule_run_parameter_int_type()

# paramter is string type

# Generated at 2022-06-11 16:35:16.152791
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    empty_config = {}
    empty_inventory = {}
    empty_variables = {}
    empty_loader = None
    empty_templar = None
    empty_playcontext = None

    class empty_Display():

        def display(self, path, data, style, show_content=False,
                    show_content_force=False, expand=True, metadata=False,
                    sort_keys=False, sort_values=False, none_as_empty=False,
                    set_formatter=None, indent=None):
            return None

    display_mock = empty_Display()
    
    def build_mock(*args, **kwargs):
        return empty_templar

    def availability_mock(*args, **kwargs):
        return empty_variables

    # Case 1
    result_case_1 = []



# Generated at 2022-06-11 16:35:36.269230
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import PY3

    # Test case: lookup for a nonexistent variable
    templar = DummyTemplar()
    lookup_plugin = LookupModule()
    lookup_plugin._templar = templar

    try:
        lookup_plugin.run(['inexistent_variable'])
        assert False
    except AnsibleUndefinedVariable:
        pass

    # Test case: lookup for a variable that is passed using
    # the option 'variables'
    templar = DummyTemplar()
    lookup_plugin = LookupModule()
    lookup_plugin._templar = templar

    templar.available_variables = {'variable': 'value'}
    lookup_plugin.run(['variable'], variables=templar.available_variables)

    #

# Generated at 2022-06-11 16:35:48.030708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    module = LookupModule()
    terms = [
        'variablename',
        'variablenotename',
        ['variabl' + 'ename'],
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]

# Generated at 2022-06-11 16:35:59.200294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text

    my_vars = dict(ansible_facts=dict(facts_var='facts_var_value'), group_vars=dict(group_var='group_var_value'),
                   hostvars=dict(host_var='host_var_value'))

    # Case 1: Success
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar(my_vars)
    terms = ['ansible_facts', 'group_vars', 'hostvars']
    result = lookup_module.run(terms, variables=my_vars, fail_on_undefined=True)

# Generated at 2022-06-11 16:36:03.562486
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
     ]

    result = LookupModule().run(terms, None, **{'default': 'ansible'})
    assert result == [None, None, None]

# Generated at 2022-06-11 16:36:14.343275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  def set_vars(obj, vars):
    obj._templar._available_variables = vars
  def get_vars(obj):
    return obj._templar._available_variables

  terms = ['term1','term2','term3','term4','term5','term6']
  terms_t1 = ['term1','term2','term3']
  terms_t2 = ['term4','term5','term6']
  terms_t3 = ['term1','term2','term3','term4','term5','term6']


# Generated at 2022-06-11 16:36:25.088390
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create instance of LookupModule class
    lookup_obj = LookupModule()

    # create mock variabls

# Generated at 2022-06-11 16:36:35.373956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._constants = {'inventory_hostname': 'host1',
                         'hostvars': {'host1': {}}, 'variables': {}}

    assert lookup.run([]) == []
    assert lookup.run(['inventory_hostname']) == ['host1']
    assert lookup.run(['hostvars']) == [{}]
    assert lookup.run(['variables']) == [{}]

    lookup._constants['variables']['var1'] = 'value1'
    lookup._constants['hostvars']['host1']['var2'] = 'value2'
    assert lookup.run(['var1']) == ['value1']
    assert lookup.run(['var2']) == ['value2']

# Generated at 2022-06-11 16:36:38.196687
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_vars = {
        'myvar': '12'
    }
    terms = ['myvar']

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, my_vars)
    assert result == ['12']

# Generated at 2022-06-11 16:36:48.480752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Should return a list of 2 elements that are the values of the 2 terms
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lookup_module = LookupModule()
    results = lookup_module.run(terms=terms, variables={'ansible_play_hosts': 'localhost', 'ansible_play_batch': 1,
                                                        'ansible_play_hosts_all': 'all'})
    assert len(results) == 3
    assert results[0] == 'localhost'
    assert results[1] == 1
    assert results[2] == 'all'
    # Should raise an AnsibleError
    terms = ['ansible_play_hosts', 2]
    lookup_module = LookupModule()

# Generated at 2022-06-11 16:36:57.788449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar

    path_to_vars = 'test/unit/plugins/lookup/fixtures/vars.yml'
    def set_option_mock(var_options=None, direct=None):
        pass
    def template_mock(value, fail_on_undefined=True):
        return value

    with open(path_to_vars) as f:
        vars_content = f.read()

    # Test class constructor
    lookupModule = LookupModule()
    # Test if member fields are initialized as expected
    assert isinstance(lookupModule._templar, Templar)

# Generated at 2022-06-11 16:37:34.063076
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    templar = Templar(loader=loader, variables=variable_manager)
    lookup_cls = LookupModule()
    lookup_cls._templar = templar

    # Test with simple term and without default
    terms = ['test_simple_term']
    result = lookup_cls.run(terms)
    assert result == ['test_simple_term']

    # Test with simple term and with default

# Generated at 2022-06-11 16:37:44.133807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = LookupModule()

    # Invalid setting identifier, its a <class 'list'>
    try:
        t.run(terms=[2, 3, 4], variables=dict(foo=1))
    except AnsibleError as e:
        assert 'Invalid setting identifier' in str(e)
    else:
        assert False, 'AnsibleError not raised'

    # No variable found with this name: bar
    try:
        t.run(terms=['bar'], variables=dict(foo=1))
    except AnsibleError as e:
        assert 'No variable found with this name' in str(e)
    else:
        assert False, 'AnsibleError not raised'

    # No variable found with this name: bar

# Generated at 2022-06-11 16:37:54.984611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Example of terms
    terms = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]
    # Example of variables used in built-in lookup lookup vars
    variables = {"ansible_play_hosts": ["foo.example.org", "other.example.org"], "ansible_play_batch": ["foo.example.org", "other.example.org"], "ansible_play_hosts_all": ["foo.example.org", "other.example.org"]}
    # Example of configuration of the built-in lookup lookup vars
    kwargs = {}
    # We instantiate and test LookupModule
    # The test aims to cover all lines of the run method of class LookupModule
    lookup_module = LookupModule()
    # We test the run method with terms

# Generated at 2022-06-11 16:37:58.292721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up test case
    # Run test
    # Assert results

    # Assert exception in following cases:
    #   value is not a string
    #   value is not an integer
    #   value is not a float
    pass

# Generated at 2022-06-11 16:38:04.815611
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing that templated vars are returned
    lm = LookupModule()
    ret = lm.run(['variablename'])
    assert ret == ['hello']
    ret = lm.run(['variablenotename'], default='')
    assert ret == ['']
    ret = lm.run(['variablenotename'])
    assert ret == []

    # Testing that I can find several related variables
    lm = LookupModule()
    ret = lm.run(['ansible_play_hosts','ansible_play_batch','ansible_play_hosts_all'])
    assert ret == [["localhost"]]

    # Testing nested vars
    lm = LookupModule()
    ret = lm.run(['variablename'])

# Generated at 2022-06-11 16:38:14.604212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'inventory_hostname': 'test_hostname'}
    lookup_module._templar._available_variables['hostvars'] = {'test_hostname':{'test_variable':'test_value'}}
    results = lookup_module.run(['test_variable'])
    assert results == ['test_value']
    results = lookup_module.run(['test_variable'], default='test_default')
    assert results == ['test_value']
    results = lookup_module.run(['test_variable_other'], default='test_default')
    assert results == ['test_default']

# Generated at 2022-06-11 16:38:26.159840
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with an undefined variable
    manager = DummyVarsModule()
    mylookup = LookupModule(loader=None, templar=manager)

    terms = ['variablename']
    variables=None

# Generated at 2022-06-11 16:38:35.921855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    for term in [1, 1.1, True, False, [1, '2'], {}]:
        try:
            test_obj.run(terms=term)
            assert False, "Expected AnsibleError"
        except AnsibleError:
            pass

    assert test_obj.run(['ansible_' + term for term in ['play_hosts', 'play_batch', 'play_hosts_all']]) == ['localhost']

    assert test_obj.run(['ansible_' + term for term in ['play_hosts', 'play_batch', 'play_hosts_all', 'nonexistent']]) == ['localhost', None]

# Generated at 2022-06-11 16:38:43.554887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize test data
    terms = ['variable_name']

    vari = {
        'var1': 'value1',
        'inventory_hostname': 'test_host',
        'hostvars': {
            'test_host': {
                'var2': 'value2'
            }
        }
    }

    # Initialize lookup module
    lu_obj = LookupModule()
    lu_obj.set_options(direct={})

    # Call method run of class LookupModule
    result = lu_obj.run(terms, variables=vari)

    # Check results
    assert result == [vari['var1']]

# Generated at 2022-06-11 16:38:54.387225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import json
    import textwrap
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Initialize values to be used
    terms_vars_config = json.loads(textwrap.dedent('''
        [
            "variablename",
            "variablenotename"
        ]
    '''))

# Generated at 2022-06-11 16:40:05.219141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Init
    lookup_module = LookupModule()

    # setup
    myvars_dict = dict({'var1': 'Hello',
                        'var2': 'World',
                        'var3': 1,
                        'var4': [1,2,3],
                        'var5': {'var1': 'It works!'}
                        })
    lookup_module._templar.available_variables = myvars_dict
    lookup_module._templar._available_variables = myvars_dict
    lookup_module._templar.available_variables['inventory_hostname'] = None

    # Test no variable found
    terms = ['var6']
    direct = {'default': None}
    lookup_module.set_options(var_options=myvars_dict, direct=direct)

# Generated at 2022-06-11 16:40:15.753655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test data
    terms = list()
    terms.append('ansible_managed')
    var_options = {
        'ansible_managed': 'Ansible managed',
        'ansible_play_hosts': 'localhost',
        'ansible_play_batch': 'localhost',
        'ansible_play_hosts_all': 'localhost'
    }
    kwargs = {
        'default': 'default'
    }
    # Constructor
    lookup_module = LookupModule()
    # Method we want to test
    result = lookup_module.run(terms, variables=var_options, **kwargs)
    # Second test with different data
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables=var_options, **kwargs)
    # Third test with different data

# Generated at 2022-06-11 16:40:25.716876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    MY_VARS = {
        'ansible_play_hosts': 'list_of_hosts',
        'hostvars': {
            'host_name_1': {
                'ansible_play_batch': 'list_of_batches_for_host_1',
                'ansible_play_hosts_all': 'all_hosts_1'
            },
            'host_name_2': {
                'ansible_play_batch': 'list_of_batches_for_host_2',
                'ansible_play_hosts_all': 'all_hosts_2'
            }
        }
    }

    class LookupModuleEmpty(LookupBase):
        def __init__(self):
            super(LookupModuleEmpty, self).__init__()


# Generated at 2022-06-11 16:40:32.426278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import text_type
    from ansible.plugins.lookup import LookupBase
    lookup = LookupBase()
    assert lookup.run(["a", "b"], variables={"a": 1, "hostvars": {'host1': {"b": 2}}}) == [1, 2]
    assert lookup.run(["c", "b"], variables={"a": 1, "hostvars": {'host1': {"b": 2}}}) == [None, 2]

# Generated at 2022-06-11 16:40:38.191916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup basic variables for test
    myterm = 'test_variable'
    myvars = {
            'hostvars': {
                'hostname': {
                    'test_variable': 'test_hostvar'
                    }
                },
            'test_variable': 'test_variable_value'
            }

    # Initialize lookup module
    module = LookupModule()
    module.set_options({'var_options': myvars})

    # Test that the method run(...) returns the correct value
    assert(module.run([myterm]) == ['test_variable_value'])

# Generated at 2022-06-11 16:40:49.717742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    class DummyVarsModule:
        def __init__(self):
            self.available_variables = {'inventory_hostname': 'dummyhost',
                                        'hostvars': {
                                                        'dummyhost': {
                                                            'ansible_play_hosts': 'blah',
                                                            'ansible_play_batch': 'bar'
                                                            }
                                                        }
                                        }
        def get_option(self, *args, **kwargs):
            if args[0] == 'default':
                return 'defaultvalue'

    templar_obj = Templar(loader=None)
    dummy_vars = DummyVarsModule()
    dummy_vars._templar = templar_obj
    lookup_obj = Look

# Generated at 2022-06-11 16:40:56.160531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test to run lookup module
    """
    module = AnsibleModule(
        argument_spec={
            '_terms': {'required': True, 'type': 'list'},
            'default': {'required': False, 'type': 'str'}
        },
        supports_check_mode=True
    )
    lookup_obj = LookupModule(loader=None,
                              templar=MagicMock(untemplate='ok'),
                              variables=None)
    assert lookup_obj._templar.untemplate == 'ok'