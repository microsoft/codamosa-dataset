

# Generated at 2022-06-21 07:09:00.154138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # test with default value None
    # test with one term
    term = 'ansible_play_hosts'
    terms = [term]
    variables = {'ansible_play_hosts': 'value1'}
    result = [variables[term]]
    assert result == lookup_module.run(terms=terms, variables=variables)

    # test with multiple terms
    term2 = 'ansible_play_batch'
    term3 = 'ansible_play_hosts_all'
    terms = [term, term2, term3]
    variables = {'ansible_play_hosts': 'value1', 'ansible_play_batch': 'value2', 'ansible_play_hosts_all': 'value3'}

# Generated at 2022-06-21 07:09:10.277808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    test_lookup = LookupModule()
    test_dict = {"first_name": "Dinuka",
                 "last_name": "Malalanayake",
                 "address": {
                    "line_1": "No.9, Malalanda Mawatha,",
                    "line_2": "Mulleriyawa New Town",
                    "city": "Colombo"
                 }
                }

    test_terms = []
    test_terms.append("first_name")
    test_terms.append("last_name")
    test_terms.append("address")

    test_terms_empty = []

    test_terms_bad = []
    test_tems_bad.append("first_name")
    test_tems_bad.append("last_name")

# Generated at 2022-06-21 07:09:20.051774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.notmintest.not_a_real_collection.plugins.lookup import vars

    # Test default case
    with patch.object(vars.AnsibleUnsafeText, '__str__') as mock_str:
        mock_str.return_value = 'val1'

        assert vars.LookupModule().run([
            'var1'], dict(
            var1='val1')) == ['val1']

    # Test error thrown when non string type passed to run

# Generated at 2022-06-21 07:09:27.187093
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import string_types

    assert hasattr(LookupModule, 'run'), \
        "Class `LookupModule` doesn't have method `run`"

    assert hasattr(LookupModule, 'set_options'), \
        "Class `LookupModule` doesn't have method `set_options`"

    assert hasattr(LookupModule, 'get_option'), \
        "Class `LookupModule` doesn't have method `get_option`"

    # create object
    lookup_obj = LookupModule()

    # test that results of method run are of type string_types
    terms, variables, kwargs = [], {}, {}
    results = lookup_obj.run(terms, variables, **kwargs)
    assert isinstance(results, string_types)

# Generated at 2022-06-21 07:09:36.570592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.plugins.lookup import LookupBase
    from ansible.template.safe_eval import boolean
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six.moves import builtins

    mylookup = LookupModule()


# Generated at 2022-06-21 07:09:39.199632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'foo'
    variables = {
        'foo': 'bar'
    }
    lookup_obj = LookupModule()
    actual = lookup_obj.run(terms, variables=variables)
    assert actual == ['bar']

# Generated at 2022-06-21 07:09:49.701790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    name = "lookup_module_test"
    terms = ["lookup_module_test"]
    defaults = {}
    with pytest.raises(AnsibleUndefinedVariable) as e_info:
        module.run(terms, defaults)
    assert "No variable found with this name: lookup_module_test" == str(e_info.value)
    defaults[name] = "example"
    result = module.run(terms, defaults)
    assert "example" in result


# Generated at 2022-06-21 07:10:00.663049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Tests when no variables parameter is passed
    parameters = {}
    result = lookup_module.run(['hostvars', 'inventory_hostname'], variables=parameters)

    if result != ['__ansible_vars__', None]:
        raise AssertionError

    # Tests when variables parameter is passed, and _templar.available_variables is a non-empty dict
    parameters = {'test': 10, 'test_dict': {'a': 1, 'b': 2}}
    lookup_module._templar.available_variables = parameters

    result = lookup_module.run(["test", "test_dict"], variables=parameters)
    if result != [10, {'a': 1, 'b': 2}]:
        raise AssertionError

    # Tests when variables parameter

# Generated at 2022-06-21 07:10:12.506445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib
    vault_pass = '$ANSIBLE_VAULT;1.1;AES256\n36343565343561353635316336613565306339636330343563353433393530373733383137623563633\n37666534386639653434333931653538373762626332346136313665366265373536383762363400\n'
    vault = VaultLib(vault_pass)

# Generated at 2022-06-21 07:10:16.685103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests if instantiation of LookupModule works properly
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 07:10:32.008864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO

    class Test(object):

        def __init__(self):
            self.lookup = LookupModule()
            self.myvar = "name"
            self.ret = []
            self.errors = []

        def _init_templar(self):
            from ansible.template import Templar
            from ansible.parsing.vault import VaultLib
            templar = Templar(loader=None, variables={})
            templar._available_variables = {
                'variablename': 'hello',
                'myvar': self.myvar,
                'variablenotename': 'goodbye',
            }
            templar._vault = VaultLib(None, None, None)
            templar._add_vars = self.add_v

# Generated at 2022-06-21 07:10:36.084233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  result = LookupModule().run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])
  assert result == ['hosts', 'hosts', 'hosts']

# Generated at 2022-06-21 07:10:43.129385
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common.collections import ImmutableDict

    lookup_module = LookupModule()
    terms_result = ["term1", "term2"]
    variables_result = ImmutableDict({"ansible_play_hosts": ["host1", "host2"]})
    with pytest.raises(AnsibleError) as exc:
        lookup_module.run(terms_result, variables_result)
    assert "Invalid setting identifier" in str(exc)


# Generated at 2022-06-21 07:10:55.301818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    lookup_loader._get_all_lookups()
    lookup = lookup_loader.get('vars')
    # In Python 2.6, TravisCI uses an older version of ansible that does not
    # have the LookupBase class.
    if hasattr(lookup, 'set_options'):
        lookup.set_options(var_options={'hostvars': {'host_name': {'var_name': 'var_value'}}}, direct={})
    else:
        lookup.set_loader(None)
    lookup._templar = Templar(loader=None, variables={'hostvars': {'host_name': {'var_name': 'var_value'}}})

# Generated at 2022-06-21 07:11:00.225214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()
    assert isinstance(mylookup, LookupModule)

# Generated at 2022-06-21 07:11:09.794054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={}, direct={})

    my_vars = {'var1':'hello', 'var2':'world'}
    l.run(['var1', 'var2'], variables=my_vars) == ['hello', 'world']

    try:
        l.run(['var1', 'var3'], variables=my_vars)
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError not raised.')

    l.run(['var1', 'var3'], variables=my_vars, default='') == ['hello', '']

    my_vars = {'var1.var2':'hello'}

# Generated at 2022-06-21 07:11:15.228866
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:11:25.925694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance._templar._available_variables = {'inventory_hostname': 'dummy-host', 'hostvars': {'dummy-host': {'var1': 'val1'}}}
    # test for string value
    terms = 'var1'
    assert lookup_instance.run([terms]) == ['val1']
    # test for list value
    terms = 'hostvars'
    assert lookup_instance.run([terms]) == [{'dummy-host': {'var1': 'val1'}}]
    # test for default value
    terms = 'non-existent-var1'
    default = 'dummy-value'
    assert lookup_instance.run([terms], default=default) == [default]

# Generated at 2022-06-21 07:11:28.651134
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert(module)

# Generated at 2022-06-21 07:11:41.248343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'default': 'default'})
    result = lookup_module.run(terms=['variable1', 'variable2'], variables={'variable1': 'value1', 'variable2':'value2'})
    assert result == ['value1', 'value2']
    result = lookup_module.run(terms=['variable3'], variables={'variable4':'value4', 'variable1': 'value1', 'variable2':'value2'})
    assert result == ['default']
    result = lookup_module.run(terms=['variable3'], variables={'variable1': 'value1', 'variable2':'value2'})
    assert result == []
    lookup_module.set_options(direct={})

# Generated at 2022-06-21 07:11:52.259144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test case 1 - normal arguments
    terms = ['foo', 'bar']
    variables = {'foo': 'bar', 'bar': 'foo', 'inventory_hostname': 'ansible'}
    default = 'default'

    # initiate object
    lookup_module = LookupModule()

    # run constructor
    lookup_module.run(terms, variables, default=default)



# Generated at 2022-06-21 07:11:55.475225
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')
    assert hasattr(lookup, 'set_options')

# Generated at 2022-06-21 07:12:05.846848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo', 'bar']

    # No variables and no kwargs - no keys in any dictionary at all
    # A KeyError should be raised when trying to look up 'foo' and 'bar'
    # Expected outcome: LookupError: No variable found with this name: foo
    mock_templar = MockTemplar()
    mock_templar._available_variables = {}
    lookup_plugin = LookupModule(loader=None, templar=mock_templar)
    assert_equals(lookup_plugin.run(terms), [])
    terms.append('not_a_real_key')
    assert_raises(AnsibleUndefinedVariable, lookup_plugin.run, terms)

    # Add a default to the kwargs - no keys in any dictionary at all
    # A KeyError should

# Generated at 2022-06-21 07:12:07.770288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 07:12:11.233694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_1 = LookupModule()
    assert isinstance(lookup_1, LookupModule)

# Generated at 2022-06-21 07:12:16.267105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def _my_templar():
        return {
            "_available_variables": {"var1": "hello"},
            "template": lambda x, y: x
        }

    l = LookupModule()
    l._templar = _my_templar()

    res = l.run(["var1"])
    assert res == ["hello"]

    res = l.run(["var2"])
    assert res == []

# Generated at 2022-06-21 07:12:28.905040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader
    from ansible.vars import VariableManager

    # Include needed variables
    variable_manager = VariableManager()
    loader = lookup_loader
    inventory = None
    include_task_vars = True

    my_lookup = loader.get('vars', 
        variable_manager=variable_manager,
        loader=loader,
        inventory=inventory,
        include_task_vars=True)

    result = my_lookup.run(['fake_value'], variables=dict(fake_value=12))
    assert result[0] == 12
    result = my_lookup.run([12], variables=dict(fake_value=12))
    assert result[0] == 12



# Generated at 2022-06-21 07:12:40.115211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # class MockTemplar:
    #
    #     def __init__(self):
    #         pass
    #
    #     def template(self, value, fail_on_undefined=True):
    #         return value

    class MockLookupModule(LookupModule):
        """
            Class with empty methods and members for testing
        """

        def __init__(self, loader=None, templar=None, **kwargs):
            self._loader = loader
            self._templar = templar
            # self._templar = MockTemplar()

        def run(self, terms, variables=None, **kwargs):
            ret = super(MockLookupModule, self).run(terms, variables, **kwargs)
            return ret


# Generated at 2022-06-21 07:12:48.821700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        "ansible_user",
        "ansible_play_hosts_all"
    ]

    result = [
        "ec2-user",
        "localhost"
    ]

    # run the test
    # we're not mocking out _templar.available_variables, so we can try out the lookup as it is run in play execution

    # create a new lookup engine
    lookup = LookupModule()

    # run the test
    results = lookup.run(
        terms=terms
    )

    # assert the results
    assert isinstance(results, list)
    assert results == result

    # run the test, with a default return value
    results_default = lookup.run(
        terms=terms,
        default="unknown"
    )

    # assert the results fall back to default
    assert isinstance

# Generated at 2022-06-21 07:13:02.153433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    utils.assert_equal(["world"], LookupModule.run(utils.mock_args("hello"), variables={"hello": "world"}))
    utils.assert_equal(["world"], LookupModule.run(utils.mock_args("hello"), variables={"hostvars": {"hostname": {"hostvar": "world"}}, "inventory_hostname": "hostname"}))
    # test default
    utils.assert_equal(["world"], LookupModule.run(utils.mock_args("hello"), variables={}, default="world"))
    utils.assert_equal([], LookupModule.run(utils.mock_args("hello"), variables={}))
    utils.assert_equal([], LookupModule.run(utils.mock_args("hello"), variables={}, default=[]))
    utils.assert_

# Generated at 2022-06-21 07:13:16.133801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-21 07:13:16.756042
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:13:18.383925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-21 07:13:20.387311
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-21 07:13:21.246609
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 07:13:34.649276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a test LookupModule for testing run()
    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return super(TestLookupModule, self).run(terms, variables=variables, **kwargs)

    # Create test variables
    terms = ['true', 'false', 'invalid']
    variables = {
        'true': 'yes',
        'false': False,
        'none': None,
        'invalid': set(),
        'hostvars': {
            'host1': {
                'hostvar': 'hostvar_value'
            }
        },
        'inventory_hostname': 'host1'
    }

    # Execute test code
    lm = TestLookupModule()

# Generated at 2022-06-21 07:13:43.656853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test LookupModule_run starts.')
    test_terms = ['_terms']
    test_variables = {'_terms': ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']}

    lookup_module = LookupModule()
    lookup_module.run(test_terms, test_variables)
    print('Test LookupModule_run ends.')

# Generated at 2022-06-21 07:13:54.684876
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:14:02.809960
# Unit test for constructor of class LookupModule
def test_LookupModule(): 
    # Test 1
    lookup_instance = LookupModule()
    assert lookup_instance is not None
    print("Constructor Test1 Pass!")

    # Test 2
    try:
        lookup_instance.run(terms=0)
        assert False, "Should throw AnsibleError exception"
    except AnsibleError:
        print("Constructor Test2 Pass!")

    # Test 3
    try:
        lookup_instance.run(terms='a')
        assert True, "Should pass without exception"
    except AnsibleError:
        assert False, "Should not throw AnsibleError exception"

    print("Constructor Test3 Pass!")


# Generated at 2022-06-21 07:14:12.372472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    # simple variable
    yaml = '''
        variable1:
            value: variable1
        '''
    ret = LookupModule().run([yaml], variable1={'value': 'variable1'})
    assert ret == ['variable1']

    # not existing variable with default value
    yaml = '''
        variable1:
            value: variable1
        '''
    ret = LookupModule().run(['variable2'], variable1={'value': 'variable1'}, default='my_default_value')
    assert ret == ['my_default_value']

    # existing variable
    yaml = '''
        variable1:
            value: variable1
        '''

# Generated at 2022-06-21 07:14:29.303152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 07:14:42.534913
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize test module
    lookup = LookupModule()

    # Define test variables
    test_terms = ['test', 'test_in_hostvars']
    test_variables = { 'test': 'Hello World', 'hostvars': {
        'localhost': { 'test_in_hostvars': 'Test in hostvars' } } }
    test_default = 'No Match'

    # Test run function output
    test_result = [test_variables['test'], test_variables['hostvars']['localhost']['test_in_hostvars']]
    assert lookup.run(terms=test_terms, variables=test_variables, default=test_default) == test_result

    # Test run function output on undefined variables

# Generated at 2022-06-21 07:14:52.653269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    
    loader = DataLoader()
    host_vars =  {'host1': {'var1': 'a'},
                  'host2': {'var1': 'b', 'var2': 'c'}}
    inventory = InventoryManager(loader=loader, host_list=[])
    inventory.set_variable('hostvars', host_vars)
    inventory.set_variable('inventory_hostname', 'host2')
    inventory.set_variable('var1', 'd')
    inventory.set_variable('var3', 'e')
    

# Generated at 2022-06-21 07:14:58.966381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    test_terms = ['a', 'b', 'c']
    assert lookup_instance.run(test_terms) == []
    assert lookup_instance.run(test_terms, variables={"a": "a", "b": "b", "c": "c"}) == ['a', 'b', 'c']

# Generated at 2022-06-21 07:15:07.834394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    # Test with a simple variable
    terms = ['var_simple']
    variables = {
        'var_simple': 'foo',
    }

    assert list(lu.run(terms, variables=variables)) == ['foo']

    # Test with a variable containing a template
    terms = ['var_template']
    variables = {
        'var_template': '{{ var_simple }}',
        'var_simple': 'Hello',
    }

    assert list(lu.run(terms, variables=variables)) == ['Hello']

    # Test with a variable containing a subvar
    terms = ['var_subvar']
    variables = {
        'var_subvar': {
            'var_subvar_inner': 'foo',
        },
    }


# Generated at 2022-06-21 07:15:11.462593
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Checking the constructor of the class LookupModule
    obj = LookupModule()
    print("LookupModule constructor is working")

# Generated at 2022-06-21 07:15:18.607194
# Unit test for constructor of class LookupModule
def test_LookupModule():
    cls = LookupModule()
    assert cls is not None

if __name__ == '__main__':
    cls = LookupModule()
    print(cls.run(['test1','test2'], variables = {'inventory_vars': {'test1': 'test_test1', 'test2': 'test_test2'}}))

# Generated at 2022-06-21 07:15:20.092669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-21 07:15:25.750966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_module = LookupModule()
    assert test_lookup_module.get_option("default") is None
    # test_lookup_module.set_options(var_options=None, direct={"default": "hello"})
    # assert test_lookup_module.get_option("default") == "hello"
    # assert test_lookup_module.get_option("invalid") is None

# Generated at 2022-06-21 07:15:37.155195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for multiple vars
    result = LookupModule.run(
        args={
            '_variables': {'var1': 'foo', 'var2': 'bar', 'var3': 'foobar'},
            '_terms': ['var1', 'var2', 'var3']
        },
        inject={'_templar': Templar(variables={'var1': 'foo', 'var2': 'bar', 'var3': 'foobar'})}
    )

    assert result == ['foo', 'bar', 'foobar']

    # Test for invalid term

# Generated at 2022-06-21 07:16:13.857995
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule({}).run(['variablename']) == [{'sub_var': 12, 'variablename': 'hello'}]

# Generated at 2022-06-21 07:16:27.052763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar(object):
        _available_variables = {'term': 'v1', '_term': 'v2'}
        def template(self, value, fail_on_undefined):
            return value
    class MockVariables(object):
        pass
    class MockOptions(object):
        var_options = MockVariables()
        def __init__(self):
            self.default = None
    terms = ['term', '_term', 'undefined']
    mk_templar = MockTemplar()
    mk_options = MockOptions()

    lm = LookupModule()
    lm.set_options(mk_options)
    lm._templar = mk_templar

    assert lm.run(terms, variables=None) == ['v1', 'v2', None]


# Generated at 2022-06-21 07:16:27.923886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 07:16:31.096463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test1 = LookupModule()
    assert(test1.run(terms = "myvar", variables = dict(myvar="hello")))

# Generated at 2022-06-21 07:16:41.884729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible import context

        loader = DataLoader()
        inventory = InventoryManager(loader=loader, sources='')
        variable_manager = VariableManager(loader=loader, inventory=inventory)
        variable_manager._available_variables = {
                'variablename': 'hello',
                'myvar': 'ename',
                'ansible_play_hosts': ['test_play_hosts'],
                'ansible_play_batch': ['test_play_batch'],
                'ansible_play_hosts_all': ['test_play_hosts_all']
        }

        lookup_module = LookupModule()

# Generated at 2022-06-21 07:16:49.929166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=unused-wildcard-import, wildcard-import
    from ...unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import *
    from ansible.utils.collection_loader import list_collection_names

    # Support for list collections.
    # Ansible support for lookup plugins is based on collections.
    # However, a lookup plugin is a module, not a collection.
    # We need to hack around to make it work.
    try:
        from ansible.plugins.loader import lookup_loader
    except ImportError:
        def lookup_loader(*args, **kwargs):
            return None

    # Create a fake collection

# Generated at 2022-06-21 07:16:51.668906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-21 07:16:54.376550
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Call constructor of class LookupModule
    lookup_module = LookupModule()
    # Check that the constructor is not None
    assert lookup_module is not None, "Failed! Constructor of class LookupModule returned None, but was expecting an object."
    return

# Generated at 2022-06-21 07:16:58.654084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert(module.run(terms=['test_var1', 'test_var2'], variables={'test_var1': 'var1_value', 'test_var2': 'var2_value'}) == ['var1_value', 'var2_value'])


# Generated at 2022-06-21 07:17:00.625657
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # No arg constructor test
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:18:07.674597
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert LookupModule.run is not None

# Generated at 2022-06-21 07:18:11.026542
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()
    lookup_module.set_options(direct={"default": "debug"})
    assert lookup_module.get_option("default") == "debug"


# Generated at 2022-06-21 07:18:15.475949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # checking data type of returned value
    assert isinstance(LookupModule(loader=None, templar=None, **{}).run([], variables={}), list)


# Generated at 2022-06-21 07:18:18.663835
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t is not None

# Generated at 2022-06-21 07:18:24.546686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['ansible_connection', 'ansible_ssh_private_key_file']
    lookup_obj = LookupModule()
    assert lookup_obj.run(terms) == ['smart', '/home/vagrant/.ssh/id_rsa']

# Generated at 2022-06-21 07:18:26.382201
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 07:18:35.761151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    The test is designed to check the correct execution of the method run
    """

# Generated at 2022-06-21 07:18:44.061800
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #test_LookupModule_testdata is declared as global
    #because it is accessed in test_LookupModule_testdata
    #within the scope of the test_LookupModule
    global test_LookupModule_testdata
    module = LookupModule()
    # set up a test data of ansible variables
    test_LookupModule_testdata = {'variablename': 'hello', 'myvar': 'ename', 'myvar2': 'notename'}
    #constructor test data
    terms = 'variablename22'
    variables = {'variablename': 'hello'}
    kwargs = {}
    #Expect to raise an error, because the variable does not exist