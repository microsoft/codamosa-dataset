

# Generated at 2022-06-21 07:09:00.893360
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:09:09.661673
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    # test constructor with wrong values
    terms = [1, 2, 3, 4]
    try:
        l.run(terms)
    except AnsibleError as e:
        assert str(e) == 'Invalid setting identifier, "1" is not a string, its a %s' % type(terms[0])

    # test constructor with good values
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]
    assert l.run(terms) == []

# Generated at 2022-06-21 07:09:17.254135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['a', 'b', 'c']
    variables = {
        'a': '1',
        'c': '3'
    }
    lookup._templar._available_variables = variables
    default = 'default'
    options = dict(var_options=variables, direct=dict(default=default))
    lookup.set_options(**options)
    ret = lookup.run(terms)
    assert ret == ['1', default, '3']

# Generated at 2022-06-21 07:09:18.785090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 07:09:23.562943
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 07:09:30.424336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule = LookupModule()
    test_LookupModule._templar = DummyTemplar()
    output = test_LookupModule.run(terms=['ansible_play_hosts'], variables={'ansible_play_hosts': 'Test_Str'})
    assert output == ['Test_Str']
    output = test_LookupModule.run(terms=['ansible_play_hosts', 'ansible_play_batch'], variables={'ansible_play_hosts': 'Test_Str', 'ansible_play_batch': 'Test_Str2'})
    assert output == ['Test_Str', 'Test_Str2']
    # output = test_LookupModule.run(terms=['ansible_play_hosts', 'ansible_play_batch'], variables={'ansible_play

# Generated at 2022-06-21 07:09:43.358375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    
    # Case 1: no variable in the variables
    terms = {'test': 'hostvars'}
    test_variables = {'inventory_hostname': 'test_host', 'hostvars': {'test_host': {'test': 'value'}}}
    expected = ['value']
    result = list(module.run(terms, test_variables))
    assert (result == expected)

    # Case 2: no variable in the variable
    terms = {'test': 'hostvars'}
    test_variables = {'inventory_hostname': 'test_host', 'hostvars': {'test_host': {'test1': 'value'}}}
    expected = ['']
    result = list(module.run(terms, test_variables, default=''))

# Generated at 2022-06-21 07:09:48.518767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["a", "b"]
    variables = {"a": "123", "b": "234"}
    expect = ["123", "234"]
    assert(expect == module.run(terms, variables))
    try:
        assert(expect == module.run(["a", "c"], variables))
    except AnsibleUndefinedVariable:
        pass
    assert(["123", ""] == module.run(["a", "c"], variables, default=""))

# Generated at 2022-06-21 07:10:00.209965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # All good. No errors expected
    terms = ['var1']
    variables = dict(myvar='value', var1='value1', var2='value2')
    loop = dict(var_options=variables, direct=dict())
    lookup_mod = LookupModule(None)
    lookup_mod._templar = dict(myvar='value', var1='value1', var2='value2')
    lookup_mod.set_options(var_options=variables, direct=dict())
    out = lookup_mod.run(terms, variables=variables, **loop)
    assert out == ['value1']
    # Test for error. An error is expected because there is no 'var3'
    terms = ['var3']

# Generated at 2022-06-21 07:10:12.317016
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six import iteritems
    import pytest

    def get_variables(variables):
        """
        mimic the templar variable lookup
        """
        self = get_variables
        if self.variables is None:
            self.variables = variables
        return self.variables

    def mock_HTTPConnection(host, port, *args, **kwargs):
        return host, port


# Generated at 2022-06-21 07:10:26.125737
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:10:36.515445
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError
    import pytest
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    test_result = None

    # test 1: no vars defined
    test_terms = ['ansible_play_hosts', 'unknown']
    test_kwargs = {}
    test_result = None

# Generated at 2022-06-21 07:10:42.445744
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup as lookup_plugins
    import ansible.template as template

    templar = template.AnsibleTemplar(loader=plugin_loader._find_plugin_loader())

    lookup = lookup_plugins.LookupModule()
    lookup._templar = templar
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-21 07:10:54.996476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()

    # Empty term
    assert len(LookupModule(pc).run([''])) == 0

    # Undefined variables
    try:
        LookupModule(pc).run(['undefined_var'])
        assert False
    except AnsibleUndefinedVariable:
        pass

    # Valid term with single value
    assert LookupModule(pc).run(['ansible_play_hosts']) == [['host1', 'host2']]

    # Multiple valid terms
    assert LookupModule(pc).run(['ansible_play_hosts', 'ansible_play_batch']) == [['host1', 'host2'], ['BATCH']]

    # Mixed valid and invalid terms, no default set

# Generated at 2022-06-21 07:10:57.314808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 07:11:05.319848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': ['192.168.0.1', '192.168.0.2'], 'ansible_play_batch': ['192.168.0.3', '192.168.0.4'], 'ansible_play_hosts_all': ['192.168.0.1', '192.168.0.2', '192.168.0.3', '192.168.0.4']}
    result = my_lookup.run(terms, variables)

# Generated at 2022-06-21 07:11:10.627491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader({'something': 10})
    assert lookup_module.run(terms=['']) == [10]

    lookup_module = LookupModule()
    assert lookup_module.run(terms=['something']) == []

# Generated at 2022-06-21 07:11:14.369037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    data = [{'test1': 'test1'}]
    lookup.run(data, None)

# Generated at 2022-06-21 07:11:17.952753
# Unit test for constructor of class LookupModule
def test_LookupModule():
    y = LookupModule()

    y.run(terms=['foo', 'bar', 'baz'], variables=None, **{})

# Generated at 2022-06-21 07:11:21.789544
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Check if constructor creates a LookupBase object
    assert type(lookup) is LookupBase
    assert lookup.__class__.__name__ == 'LookupBase'

# Generated at 2022-06-21 07:11:40.072778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # callbacks to use the test data to set the necessary variable values
    def get_variables():
        return {
            'hostvars': {
                'host1': {
                    'site': 'FooSite'
                }
            },
            'inventory_hostname': 'host1',
            'a_var': 'hello',
            'ansible_play_hosts': 'host1',
            'ansible_play_batch': 'host1',
            'ansible_play_hosts_all': 'host1'
        }

    def get_option(key):
        return None

    def template(value, fail_on_undefined=True):
        return value

    # create the mock object to be used by the class

# Generated at 2022-06-21 07:11:41.083149
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:11:48.965713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simple test of run
    variables = {'foo': ['bar']}
    default = 'baz'
    terms = ['foo']
    kwargs = {'default': default}

    # Redefine the run function
    def run(self, terms, variables=None, **kwargs):
        if variables is not None:
            self._templar.available_variables = variables
        myvars = getattr(self._templar, '_available_variables', {})

        self.set_options(var_options=variables, direct=kwargs)
        default = self.get_option('default')

        ret = []

# Generated at 2022-06-21 07:12:00.048845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables={})
    lookup = lookup_loader.get('vars', templar=templar, loader=None, play_context=PlayContext())
    assert 'ansible_distribution' == lookup.run(['ansible_distribution'])[0]
    assert 'Hello' == lookup.run(['greeting'], default='Hello')[0]
    assert ['Hello', 'Hello'] == lookup.run(['greeting', 'greeting'], default='Hello')

# Generated at 2022-06-21 07:12:09.186118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    key = 'hostvars'
    term = 'hostvars'
    myvars = {
        'foo': 'foo_value',
        'bar': 'bar_value',
        key: {
            'host1': {
                'foo': 'host1_foo_value',
                'bar': 'host1_bar_value',
            },
            'host2': {
                'foo': 'host2_foo_value',
                'bar': 'host2_bar_value',
            },
        }
    }

    module = LookupModule()
    module.set_options(var_options=myvars)
    result = module.run(terms=[term], variables=myvars)

# Generated at 2022-06-21 07:12:13.743557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(['variablname']) == []
    assert module.run(['variablname'], variables={'variablname': 'test_value'}) == ['test_value']

# Generated at 2022-06-21 07:12:15.158233
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:12:18.721948
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)
    assert issubclass(LookupModule(), LookupBase)

# Generated at 2022-06-21 07:12:31.351351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import yaml

    yaml_str = """
        myvars:
            variablename: hello
            myvar: ename
        myvar2: notename
    """

    yml = yaml.load(yaml_str)
    mvars = LookupModule(None, yml)

    # Testing with one variable that exists
    terms = ['variablename']
    res = mvars.run(terms)
    print(res)
    assert res == ['hello']


    # Testing with two variables, one exist and the other does not
    terms = ['variablename', 'variablnotename']
    res = mvars.run(terms)
    print(res)
    assert res == ['hello', '']

    # Testing with two variables, one exist and the other does not with

# Generated at 2022-06-21 07:12:36.152955
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Call constructor of LookupModule
    lookup_module = LookupModule()
    # Print LookupModule
    print("\nPRINTING VARIABLE lookup_module:")
    print(lookup_module)


# Generated at 2022-06-21 07:13:02.979891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.utils.template as templar
    import ansible.plugins.loader as loader
    import ansible.vars as vars
    # the next line is so that the test will run on distributions which
    # don't have the jinja2 package installed.
    templar._available_lookups = loader._find_plugin_filters()
    templar._available_lookups = vars.VarsModule()
    templar._available_variables = {"hostvars" : {
        "{#hostname#}" : {
            "hostname" : "{#hostname#}",
            "groupname" : "{#groupname#}",
            "groupname1" : "{#groupname1#}"
        }
    }}

# Generated at 2022-06-21 07:13:14.724330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import numpy as np

    # Test with default input.
    my_lookup = LookupModule()
    test_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    my_variables = {'inventory_hostname':'127.0.0.1', 'hostvars':{'127.0.0.1':{'ansible_play_hosts_all':['127.0.0.1']}}, 'ansible_play_batch':'test_batch', 'ansible_play_hosts':['127.0.0.1']}
    ret = my_lookup.run(test_terms, variables=my_variables)
    assert my_variables['ansible_play_hosts'] == ret[0]
    assert my

# Generated at 2022-06-21 07:13:26.588502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # source: https://docs.python.org/2/library/unittest.html
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.module_utils.six import string_types
    from .LookupModule import LookupModule
    import ansible.plugins.lookup.vars
    
    # (1) class variable under test
    lookup_module_name = 'vars'
    lookup_module_class = ansible.plugins.lookup.vars.LookupModule
    
    # (2) class for lookup parameters
    class LookupParameters:
        def __init__(self, terms, variables=None, **kwargs):
            self.terms = terms
            self.variables = variables
            self.kwargs = kwargs
    


# Generated at 2022-06-21 07:13:35.506236
# Unit test for constructor of class LookupModule
def test_LookupModule():
    hostvars = {'ansible_play_hosts': [''],
                'ansible_play_batch': [[]],
                'ansible_play_hosts_all': [[{'ansible_play_hosts': [''],
                                             'ansible_play_batch': [[]]},
                                            {'ansible_play_hosts': [''],
                                             'ansible_play_batch': [[]]}]]}
    LookupModule.run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'], variables=hostvars)

# Generated at 2022-06-21 07:13:38.102582
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # call the constructor
    lookup_module = LookupModule()
    assert lookup_module != None


# Generated at 2022-06-21 07:13:47.112520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='{0}')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    lookup_base = LookupModule()
    lookup_base._templar = variable_manager._templar

    test_var = ''

# Generated at 2022-06-21 07:13:59.759452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: add more tests
    l = LookupModule()
    l.set_options(var_options={"test_var1": "test_value1", "test_var2": "test_value2", "test_var_dict": {"test_sub_var1": "test_sub_value1", "test_sub_var2": "test_sub_value2"}}, direct={})

    # Given a list of terms, return a list of the result of looking up each term in the variables
    # Use case 1: terms are a list of simple variable names
    assert l.run(["test_var1", "test_var2"]) == ["test_value1", "test_value2"]
    # Use case 2: given an empty list return an empty list
    assert l.run([]) == []
    # Use case 3: non

# Generated at 2022-06-21 07:14:11.341832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os.path
    import json

    lookupModule = LookupModule()
    lookupModule.set_options(var_options={'dvar1': 1, 'dvar2': 2}, direct={'default': 3})
    ret = lookupModule.run(terms=['dvar1'], variables={'dvar3': 4})
    assert json.loads(json.dumps(ret)) == [1]

    lookupModule.set_options(var_options={'dvar1': 1, 'dvar2': 2}, direct={'default': 3})
    ret = lookupModule.run(terms=['dvar1', 'dvar2'], variables={'dvar3': 4})
    assert json.loads(json.dumps(ret)) == [1, 2]


# Generated at 2022-06-21 07:14:22.528998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # For testing purposes only
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a test inventory for testing purposes only
    test_inventory = """
    localhost ansible_connection=local
    """
    inventory = InventoryManager(loader=None, sources=test_inventory)

    # Create the variable manager for testing purposes only
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create the lookups for testing purposes only
    options = dict()
    variable_manager._extra_vars = dict(variablname='value')
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=None, variable_manager=variable_manager, options=options)
    lookup_module = LookupModule()
    lookup

# Generated at 2022-06-21 07:14:34.216173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.lookup.plugins import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.template import Templar
    import os

    templar = Templar(loader=None, variables={
        'hostvars': {
            'test_host': {
                'test_var': 'ok',
                'test_list': ['ok1', 'ok2']
            }
        },
        'inventory_hostname': 'test_host',
        'test_var': 'ok',
        'test_list': ['ok1', 'ok2'],
        'test': os.path.abspath('test'),
        'test_unavailable': '{{ test_unavailable }}'
    })
    lookup_module = LookupModule()
    lookup_module._templar = templar



# Generated at 2022-06-21 07:15:02.415509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 07:15:04.013806
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-21 07:15:16.594277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #setup mock object for ansible.plugins.lookup._templar
    mock_templar = Mock()
    mock_templar.template.return_value = 'test'

    #setup mock object for ansible.plugins.lookup.LookupBase
    mock_LookupBase_instance = Mock()
    mock_LookupBase_instance.get_option.return_value = False
    mock_LookupBase_instance._templar = mock_templar
    mock_LookupBase_instance.set_options.return_value = True
    #setup mock object for ansible.plugins.lookup.LookupModule
    mock_LookupModule_instance = LookupModule()
    mock_LookupModule_instance.get_option = Mock()
    mock_LookupModule_instance.get_option.return_value = False


# Generated at 2022-06-21 07:15:18.687799
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None


# Generated at 2022-06-21 07:15:25.507593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    lookup = LookupModule()
    t = Templar(None, loader=None, variables=dict(var_name="world"))
    lookup._templar = t
    assert lookup.run([ "var_name" ]) == [ "world" ]
    assert lookup.run([ "var_name", 'var_does_not_exist' ]) == [ "world", None ]
    assert lookup.run([ "var_name", 'other_var_name' ], variables=dict(var_name="world", other_var_name="hello")) == [ "world", "hello" ]


# Generated at 2022-06-21 07:15:37.061891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Test 1: Test with only ansible_play_hosts,'ansible_play_batch.'ansible_play_hosts_all' variables
  new_terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
  lookup_class = LookupModule()
  expected_value = ['[u\'127.0.0.1\', u\'127.0.0.2\']', u'1', '[u\'127.0.0.1\', u\'127.0.0.2\']']
  actual_value = lookup_class.run(new_terms)
  assert actual_value == expected_value
  actual_value = lookup_class.run(new_terms, ['ansible_play_batch'])
  assert actual_value == expected_value



# Generated at 2022-06-21 07:15:47.999773
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance of LookupModule
    lm = LookupModule()
    # create options
    options = {'default': 'Testing'}
    # create variables
    variables = {'variablname': 'Hello'}
    # set options and variables
    lm.set_options(var_options=variables, direct=options)
    # run
    result = lm.run(['variablname'])
    # assert result
    assert result[0] == 'Hello'
    # run
    result = lm.run(['variablnotename'])
    # assert result
    assert result[0] == 'Testing'
    # run
    result = lm.run(['variablnotename', 'variablname'])
    # assert result
    assert result[0] == 'Testing'
    assert result[1]

# Generated at 2022-06-21 07:15:54.903832
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert isinstance(lookup_instance, LookupModule)
    assert lookup_instance.lookup_type is not None
    assert lookup_instance.run is not None

# Generated at 2022-06-21 07:16:05.380004
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    lookup = LookupModule()
    ret = lookup.run(terms=[0])
    assert(ret == ['No variable found with this name: 0'])
    ret = lookup.run(terms=['test', 'hash'])
    assert(ret == ['No variable found with this name: test', 'No variable found with this name: hash'])
    ret = lookup.run(terms=['string'], variables={'string': 'string'})
    assert(ret == ['string'])
    ret = lookup.run(terms=['string1', 'string2', 'string3'], variables={'string1': 1, 'string2': 2, 'string3': 3})
    assert(ret == [1, 2, 3])

# Generated at 2022-06-21 07:16:08.470461
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-21 07:17:18.075887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    instance = LookupModule()
    class_name = __name__ # 'TestLookupModule'

    variables = {
        'variables': {
            'variablename': 'hello',
            'inventory_hostname': 'hostname',
            'hostvars': {
                'hostname': {
                    'myvar': 'ename',
                },
            },
        },
        'ansible_play_hosts': ['127.0.0.1'],
        'ansible_play_batch': 1,
        'ansible_play_hosts_all': ['127.0.0.1'],
    }

    def test_module_run():
        instance.set_options(var_options=variables['variables'])
        instance._templar._available_variables = variables['variables']
        ret

# Generated at 2022-06-21 07:17:30.088531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,  host_list='localhost')
    variable_manager.set_inventory(inventory)

    variable_manager.extra_vars = {"prefix": "value1", "suffix": "value2"}

    play_context = PlayContext()
    t = LookupModule()

    # Test constructor of class LookupModule
    assert t._templar is None
    assert t._loader is None

# Generated at 2022-06-21 07:17:32.853524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj._templar is not None

# Generated at 2022-06-21 07:17:35.365750
# Unit test for constructor of class LookupModule
def test_LookupModule():

    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            return terms

    assert TestLookupModule()

# Generated at 2022-06-21 07:17:40.838572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestVarsLookupModule(object):
        def __init__(self):
            self.plugin = 'VarsLookupModule'
            self.vars = dict()
    obj = LookupModule(TestVarsLookupModule())
    assert isinstance(obj, LookupModule)
    assert obj.plugin == 'VarsLookupModule'
    assert obj.vars == {}


# Generated at 2022-06-21 07:17:41.632867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(),LookupModule)

# Generated at 2022-06-21 07:17:50.727206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define test variables
    terms = ['test_variable_1', 'test_variable_2']
    variables = {
        'test_variable_1': 'variable_1',
        'test_variable_2': 'variable_2',
    }
    expected_ret = ['variable_1', 'variable_2']

    # Test code
    obj = LookupModule()
    ret = obj.run(terms, variables=variables)

    # Assert test result
    assert(ret == expected_ret)

# Generated at 2022-06-21 07:17:58.799184
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
    ]
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == [['localhost'], [1], ['localhost']]

# Generated at 2022-06-21 07:18:07.837080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    # Create a mock templar object
    myvars = {
        'hostvars' : {
            'host1' : {
                'ansible_ssh_host' : 'host1'
            },
            'host2' : {
                'ansible_ssh_host' : 'host2'
            }
        },
        'inventory_hostname' : 'host1'
    }
    templar = MockTemplar(myvars)

    # Call LookupModule with the following params
    terms = ['inventory_hostname', 'ansible_ssh_host']
    variables = {'inventory_hostname': 'host2'}
    default = '127.0.0.1'

    # Create an instance of LookupModule
    lookup_module = LookupModule()

    # Set the

# Generated at 2022-06-21 07:18:16.860541
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with defined variable
    l = LookupModule()
    l._templar._available_variables = {
        'variablename': 'hello',
        'myvar': 'ename',
        'hostvars': {
            'inventory_hostname': {
                'myhostvar': 'myhostvalue',
            },
        },
    }
    assert l.run(['variablename']) == ['hello']
    assert l.run(['variablename']) == ['hello']
    assert l.run(['variablename']) == ['hello']
    assert l.run(['variablename', 'variablename']) == ['hello', 'hello']
    assert l.run(['variablename', 'myvar']) == ['hello', 'ename']