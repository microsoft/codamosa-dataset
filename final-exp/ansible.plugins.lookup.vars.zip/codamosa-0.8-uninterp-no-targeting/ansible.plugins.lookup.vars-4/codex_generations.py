

# Generated at 2022-06-21 07:08:55.291780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible_collections.ansible.community.tests.unit.plugins.lookup.vars import _mock_templar, _mock_templar_available_variables, _mock_ansible_module

    module = _mock_ansible_module()
    templar = _mock_templar(module)
    terms = ['ansible_hostname']

    lookup_module = LookupModule()
    lookup_module._templar = templar
    lookup_module.set_options({'var_options':{}, 'direct':{}}, variables=_mock_templar_available_variables())
    result = lookup_module.run(terms=terms)
    assert result == [_mock_templar_available_variables()[terms[0]]]

# Unit test

# Generated at 2022-06-21 07:08:55.899092
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert  isinstance(l,LookupModule)

# Generated at 2022-06-21 07:08:56.696274
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # pylint: disable=maybe-no-member
    module = LookupModule()
    assert module != None

# Generated at 2022-06-21 07:09:09.516009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    infile = ''
    ut = LookupModule(None, load_options_vars_defaults=True, basedir=None)
    ut.set_loader(None)
    ut._templar.template_class = None
    ut._templar.template_class = None
    ut._templar._available_variables = {u'hostvars': {u'myhostname': {u'variablename': u'hello', u'myvar': u'ename'}}, u'variablename': u'hello', u'myvar': u'ename'}

# Generated at 2022-06-21 07:09:12.407425
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Creates a LookupModule object to verify __init__ function
    '''
    test_lookup = LookupModule()
    assert test_lookup._options == {}
    assert test_lookup._templar._available_variables == {}
    assert test_lookup._templar.environment == None



# Generated at 2022-06-21 07:09:16.551090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.vars import LookupModule
    lookup = LookupModule()
    terms = ['foo', 'bar']
    result = lookup.run(terms)
    assert not result, "LookupModule() returned unexpected non-empty result: %s" % result

# Generated at 2022-06-21 07:09:29.970938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Choose one feature and test it
    """
    lookup = LookupModule()
    # test with valid variables
    def mock_getattr(self, vars, direct):
        self._templar._available_variables = {'inventory_hostname': "a", 'hostvars': {"a": {"var1":"var1 value"}}}
        self.get_option = lambda x, y={}: None
    lookup.get_option = lambda x: None
    lookup.set_options = mock_getattr
    assert lookup.run(["var1"]) == ["var1 value"]
    assert lookup.run(["var2"]) == []
    # test with invalid variables

# Generated at 2022-06-21 07:09:32.668830
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-21 07:09:40.543794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(DataLoader())
    lookup_plugin._templar.set_available_variables({"test1": 123, "test2": 456, "test3": 789})

    parameters = ("test1", "test2", {"default": "n/a"})
    terms = listify_lookup_plugin_terms(parameters, loader=lookup_plugin._loader, templar=lookup_plugin._templar, wrap_as_plugin=False)
    assert lookup_plugin.run(terms) == [123, 456]


# Generated at 2022-06-21 07:09:51.622411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule with basic mocks
    lm = LookupModule()
    lm.set_options = Mock()
    lm.get_option = Mock()

    # Test with undefined variables
    terms = ["defined", "undefined"]
    lm.run(terms)

    # Test with defined variables
    lm.run(terms,{"undefined":1})
    lm.run(terms,{"defined":"defined"})

    # Test return values
    lm.get_option.side_effect = [None, "default"]
    lm.run(terms,{"undefined":1})
    lm.run(terms,{"defined":"defined"})

# Generated at 2022-06-21 07:10:05.499627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    terms = ['term1', 'term2']
    variables = {'term1': {'sub_var': 10},
                 'term2': {'sub_var': 20},
                 'hostvars': {'host1': {'term1': {'sub_var': 11}}}}

    ret = l.run(terms, variables)
    assert ret == [{'sub_var': 10}, {'sub_var': 20}]

    ret = l.run(terms, variables, inventory_hostname='host1')
    assert ret == [{'sub_var': 11}, {'sub_var': 20}]

# Generated at 2022-06-21 07:10:10.692132
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    lookup.set_options(dict(test_path='test/test_lookup_plugin.py'))
    assert lookup.get_option('test_path') == 'test/test_lookup_plugin.py'


# Generated at 2022-06-21 07:10:14.222062
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule('LookupModule')
    assert lookup_class is not None
    

# Generated at 2022-06-21 07:10:24.055633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input:
    terms = ['ansible_play_batch', 'batch_results',
             'ansible_play_hosts', 'ansible_play_hosts_all']
    variables = {'ansible_play_batch': '10'}
    kwargs = {'default': ''}

    # Expected output:
    expected_result = ['10', '',
                       '10', '10']

    lookup_module = LookupModule()
    result = lookup_module.run(terms,
                               variables=variables,
                               **kwargs)

    assert result == expected_result
    print('Unit test for method run of class LookupModule successful!')

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 07:10:29.276900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    def test_object():
        lookup_plugin = LookupModule()
        assert lookup_plugin is not None

    test_object()

# Generated at 2022-06-21 07:10:30.220423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 07:10:43.254182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys, os

    # Hack to load this plugin
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    from ansible.template import Templar

    templar = Templar(None, loader=None, variables={
        'variablename': 'hello',
        'myvar': 'ename'
    })

    terms = ['variablename']

    result = LookupModule(templar).run(terms)
    assert result == ['hello']

    result = LookupModule(templar).run(terms, default='')
    assert result == ['hello']

    result = LookupModule(templar).run(terms, default=None)
    assert result == ['hello']


# Generated at 2022-06-21 07:10:55.343417
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestLookupModule(LookupModule):
        def __init__(self, terms, variables):
            self.terms = terms
            self.variables = variables
            self._templar = MagicMock(spec=Templar)

            def _template(value, fail_on_undefined=True):
                return value

            self._templar.template.side_effect = _template

    assert TestLookupModule(terms=['ansible_play_hosts'], variables={'ansible_play_hosts': 'abc'}).run() == ['abc']
    assert TestLookupModule(terms=['ansible_play_hosts'], variables={'ansible_play_hosts': 'abc',
                                                                     'ansible_play_batch': 'def'}).run() == ['abc']
    assert TestLook

# Generated at 2022-06-21 07:11:01.256953
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(str(LookupModule()) == '<ansible.plugins.lookup.vars.LookupModule object at 0x7f0c9e9e32d0>')

# Generated at 2022-06-21 07:11:12.728641
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a template from variables
    data = '''
        {
            "app1.example.com": {
                "examplevar": "foo bar"
            },
            "app2.example.com": {
                "examplevar": "bar foo"
            },
            "myvar": "othervar.value",
            "othervar": {
                "value": "myvar.examplevar"
            }
        }
    '''
    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = Inventory

# Generated at 2022-06-21 07:11:20.982867
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 07:11:34.990166
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test normal case with term in available_variables
    templar = get_templar()
    lookup_module = LookupModule(templar=templar)
    templar._available_variables = dict(term1='var1')
    assert lookup_module.run(terms=['term1']) == ['var1']

    # test undefined variable
    templar = get_templar()
    lookup_module = LookupModule(templar=templar)
    templar._available_variables = dict(term1='var1')
    try:
        lookup_module.run(terms=['term2'])
    except AnsibleUndefinedVariable:
        pass
    else:
        assert False

    # test undefined variable with default
    templar = get_templar()
    lookup

# Generated at 2022-06-21 07:11:43.451891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # from the module
    from ansible.parsing.plugins.lookup import LookupModule
    from ansible.plugins.lookup import LookupBase

    LookupModule.run = LookupModule.run.__func__
    LookupBase.set_options = LookupBase.set_options.__func__
    LookupBase.get_option = LookupBase.get_option.__func__

    # Mock import modules
    import ansible.module_utils.six
    ansible.module_utils.six.string_types = (str, bytes)

    import ansible.errors
    AnsibleError = ansible.errors.AnsibleError
    AnsibleUndefinedVariable = ansible.errors.AnsibleUndefinedVariable

    # Mocked variables
    # In this test case, I will test with 2 available variables to use :


# Generated at 2022-06-21 07:11:45.972153
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:11:56.747862
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:12:03.097532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupplugin = LookupModule()
    test_command = "ls"
    assert isinstance(lookupplugin, LookupModule)
    assert lookupplugin._command == test_command
    assert lookupplugin.get_option == lookupplugin.get_opts
    assert lookupplugin._options == {}
    assert lookupplugin._templar is not None


# Generated at 2022-06-21 07:12:12.014902
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variables = VariableManager()

    #Passing empty terms
    terms = []
    test = LookupModule()
    assert test.run(terms, variables) == []

    #Passing None terms
    terms = None
    test = LookupModule()
    assert test.run(terms, variables) == []

    #Passing invalid terms
    terms = [1,2,3]
    test = LookupModule()
    assert test.run(terms, variables) == []
    terms = [{'one': 'two'}]
    assert test.run(terms, variables) == []

    #Passing valid terms
    terms = ['test']
    test = LookupModule()
   

# Generated at 2022-06-21 07:12:20.159781
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()

    # Validate that the error 'Invalid setting identifier' is raised when the lookup parameter is not a string
    args = ((('self',), {'variables': None}, {}, 0), ({'fail': True}, {}, {}, 1))
    for parms in args:
        try:
            module.run(*parms[0], **parms[1])
        except AnsibleError as e:
            if parms[2]['fail'] or 'Invalid setting identifier' not in e.message:
                raise AssertionError("Unexpected AnsibleError raised: %s" % e.message)
            else:

                continue
        else:

            raise AssertionError("AnsibleError not raised")

    # Validate that the error 'No variable found with this name' is raised when the lookup parameter does not exist
   

# Generated at 2022-06-21 07:12:32.313225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock objects
    class MockTemplar:
        _available_variables = {'var1': 1, 'var2': 'var2', 'hostvar': 'hostvar_val'}
        def __init__(self):
            self.available_variables = {}
            self._available_variables['hostvars'] = {}
            self._available_variables['hostvars']['host1'] = {}
            self._available_variables['hostvars']['host1']['hostvar'] = 'hostvar_val'
            self._available_variables['inventory_hostname'] = 'host1'
        def template(self, value, fail_on_undefined=False):
            # Return value
            return value

# Generated at 2022-06-21 07:12:41.378401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    ret = module.run(['hostvars', 'hostvars'])
    assert ret == [{}, {}]

    ret = module.run(['false_var'], variables={'false_var': 'bar'})
    assert ret == ['bar']
    ret = module.run(['false_var'], variables={'false_var': 'bar'}, default={})
    assert ret == [{}]
    ret = module.run(['false_var'], variables={'false_var': 'bar'}, default="")
    assert ret == [""]
    ret = module.run(['false_var'], variables={'false_var': 'bar'}, default=[])
    assert ret == [[]]

# Generated at 2022-06-21 07:12:55.660218
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 07:13:02.733407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test LookupModule.run method
    # Parameter: terms, variables
    terms_in = ['var1','var2','var3']
    terms_out = ['var1','var2','var3']
    variables_in = {'var1':'value1','var2':'value2','var3':'value3'}
    variables_out = {'var1':'value1','var2':'value2','var3':'value3'}
    kwargs_in = {}
    method_result = LookupModule(None, terms_in, variables_in, **kwargs_in).run(terms_in, variables_in)
    assert method_result == terms_out

import pytest


# Generated at 2022-06-21 07:13:14.603120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    module_utils_path = os.path.abspath(os.path.join(__file__, '..', '..', '..', 'module_utils'))
    lookup_plugin_path = os.path.abspath(os.path.join(__file__, '..', '..'))

    # Ansible 2.2.2
    if os.path.exists(os.path.join(module_utils_path, 'common.py')):
        module_utils_full_path = os.path.join(module_utils_path, 'common.py')
        from ansible.utils.vars import combine_vars

# Generated at 2022-06-21 07:13:16.494974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except NameError:
        assert False

# Generated at 2022-06-21 07:13:23.026272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    retval = []
    temp = {'inventory_hostname': 'localhost',
            'ansible_play_hosts': [],
            'ansible_play_batch': [],
            'ansible_play_hosts_all': []}
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    lm = LookupModule()
    lm.run(terms, variables=temp)
    for term in terms:
        assert term in temp
    assert temp['ansible_play_hosts'] == []
    assert temp['ansible_play_batch'] == []
    assert temp['ansible_play_hosts_all'] == []


# Generated at 2022-06-21 07:13:35.201635
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create a mock lookup_plugin
    lookup_plugin = LookupModule()

    # Create a mock templar
    templar = MockTemplar()

    # set the template property
    lookup_plugin.set_options(var_options={}, direct={})

    # Create a mock loader
    loader = MockLoader()

    # Set the loader as a property of the templar
    templar._loader = loader

    # On the templar set the lookup_plugin as the lookup_loader
    templar.lookup_loader = MockLoader()

    lookup_plugin.set_loader(loader)

    # Get the available variables
    lookup_plugin.get_available_variables()

    # Get the option 'default'
    default = lookup_plugin.get_option('default')

    # Run the lookup_plugin

# Generated at 2022-06-21 07:13:40.956260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(direct={"_ansible_tmpdir": "/tmp",
                          "_ansible_keep_remote_files": False,
                          "_ansible_no_log": False,
                          "_ansible_debug": False,
                          "_ansible_verbosity": 0})
    l._templar.available_variables = {}
    l._templar._available_variables = {}

    assert l.run(["host1", "host2"], {}) == ["host1", "host2"]


# Generated at 2022-06-21 07:13:53.588647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #test 1: retrieve 2 top level variable names ('a' and 'b'), with 'b' undefined
    templar = DummyTemplar()
    templar._available_variables = {"a":"value of a","b":"value of b"}
    lookup_obj = LookupModule(templar)
    assert lookup_obj.run(['a', 'b']) == ['value of a', 'value of b']

    #test 2: retrieve 2 nested variable names ('c.x' and 'c.y'), with 'c.z' undefined
    templar = DummyTemplar()
    templar._available_variables = {"c":{"x":"value of c.x","y":"value of c.y","z":"value of c.z"}}
    lookup_obj = LookupModule(templar)
    assert lookup_

# Generated at 2022-06-21 07:13:58.514422
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert getattr(LookupModule(None), 'is_safe_callable', 1) is 1

# Generated at 2022-06-21 07:14:10.999022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable

    # Test 1
    # test case: lookup('vars', 'variabl' + myvar)
    myvar = 'ename'
    variablename = 'hello'
    templar = object()
    setattr(templar, 'template', lambda x: x)
    setattr(templar, '_available_variables', {'variablename': variablename, 'myvar': myvar})
    lookup_module = LookupModule()
    lookup_module._templar = templar
    result = lookup_module.run(['variabl' + myvar])
    assert result == [variablename]

    # Test 2
    # test case: lookup

# Generated at 2022-06-21 07:14:39.268596
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert 'help' in lookup_module.__doc__

# Generated at 2022-06-21 07:14:40.810197
# Unit test for constructor of class LookupModule
def test_LookupModule():
      p = LookupModule()

      assert isinstance(p, LookupModule)

# Generated at 2022-06-21 07:14:44.709020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()



if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 07:14:47.268429
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('lookup_plugins.vars.test_LookupModule')
    return LookupModule

# Generated at 2022-06-21 07:14:56.784536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import json
    import sys

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # create a play to deal with ansible-playbook infrastructure

# Generated at 2022-06-21 07:15:05.032553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    lookup_module = LookupModule()

    # Create test variables
    first_variable = "first_variable"
    first_value = "first_value"
    second_variable = "second_variable"
    second_value = "second_value"
    third_variable = "third_variable"
    third_value = "third_value"
    test_variable = "test_variable"
    test_value = "test_value"
    test_value_two = "test_value_two"
    # Create test variables

# Generated at 2022-06-21 07:15:11.878490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Create variables to be passed as input and output to the run method
    pass

# Use below for testing
#if __name__ == "__main__":
#    print("Test for class LookupModule")
#    test_LookupModule_run()

# Generated at 2022-06-21 07:15:24.412043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    class MockTemplar(object):
        def __init__(self):
            self.available_variables = {}
            self._available_variables = {}
            self.fail_on_undefined_errors = False

    class MockVarsModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.params['name'] = ""
            self.params['_original_basename'] = os.path.basename(__file__)
            self.params['_ansible_syslog_facility'] = 'LOG_USER'
            self.params['_ansible_verbosity'] = 5
            self.return_val = 0
            self.exit_json = lambda: self.return_val
            self.fail_json = lambda: self.return_val

# Generated at 2022-06-21 07:15:26.484319
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.run.__name__ == 'run'

# Generated at 2022-06-21 07:15:37.433259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test that the LookupModule.run method returns expected values

    Test return values for specific variable conditions

    Test return when variable exists in variables
    Test return when variable exists in hostvars

    Test the first value returned when multiple arguments are passed

    Test return when variable does not exist in variables or hostvars
    Test return when variable does not exist in variables or hostvars and default is supplied
    Test return when variable does not exist in variables or hostvars and default is not supplied
    '''
    from ansible.plugins.lookup import LookupModule

    # Test setup
    # Initialise mock variables
    templar_mock = MockTemplar()

    # Initialise LookupModule object
    lookup_module_obj = LookupModule()
    # Set value of templar
    lookup_module_obj._templar = tem

# Generated at 2022-06-21 07:16:41.727152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look_obj = LookupModule()
    assert look_obj._options == {'_ansible_check_mode': False,
                                 '_ansible_debug': False,
                                 '_ansible_diff': False,
                                 '_ansible_module_name': '',
                                 '_ansible_no_log': False,
                                 '_ansible_verbosity': 0,
                                 '_ansible_version': '',
                                 '_ansible_version_string': '',
                                 '_original_file': '',
                                 '_original_module': '',
                                 '_uses_shell': False,
                                 '_uses_delegate_to': False}


# Generated at 2022-06-21 07:16:46.145605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for constructor of class LookupModule'''
    lookup_module = LookupModule()
    assert lookup_module is not None
    # check that class attributes are assigned as expected
    assert lookup_module.fail_on_undefined_errors == True
    assert lookup_module.no_lookup_plugin_erro

# Generated at 2022-06-21 07:16:59.742199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class FakeTemplar(object):
        def __init__(self):
            self.available_variables = {
                'foo': 'bar',
                'hostvars': {
                    'foo': 'bar'
                }
            }

    l = LookupModule()
    l.set_loader(None)

    # Test that the constructor of LookupModule instantiates the correct class
    assert l._templar.__class__.__name__ == 'Templar', '_templar is not an instance of the Templar class'

    # Test that the constructor of LookupModule instantiates lookup_plugin with the proper class
    assert l._loader.__class__.__name__ == 'DataLoader', '_loader is not an instance of the DataLoader class'

    # Test that _templar is not None
    assert l._templ

# Generated at 2022-06-21 07:17:12.610667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    l = LookupModule()
    l._templar = Templar(loader=None)
    # Basic test
    assert l.run(terms="var1", variables={"var1": "blah"}) == ["blah"]
    assert l.run(terms="var1", variables={"var1": "{{ var2 }}", "var2": "blah"}) == ["blah"]
    # Test var_options
    assert l.run(terms="var1", var_options={"var1": "blah"}) == ["blah"]
    # Test default
    assert l.run(terms="var1", var_options={}, default="blah") == ["blah"]
    # Test terms is a list

# Generated at 2022-06-21 07:17:13.271283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-21 07:17:25.473879
# Unit test for constructor of class LookupModule
def test_LookupModule():
  import inspect
  import imp
  import os
  import sys

  # Deny the use of the imp module which has been removed recently in Python 3.5
  if sys.version_info[0] >= 3 and sys.version_info[1] >= 5:
    import pytest
    pytest.skip("The imp module is not available anymore in Python 3.5")

  # Get the absolute path related to the current script
  script_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
  filename = os.path.join(script_dir, 'vars.py')

  # Load the module and instantiate it
  class_inst = imp.load_source('vars', filename)
  lk = class_inst.LookupModule()

  # Check whether the method

# Generated at 2022-06-21 07:17:29.488045
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_run_results = {}

    def fake_run(self, terms, variables=None, **kwargs):
        # puts terms into a dict, and when given the same terms in the future returns the value for said terms
        if len(lookup_run_results) != 0:
            if terms in lookup_run_results:
                return lookup_run_results[terms]
        lookup_run_results[terms] = terms


# Generated at 2022-06-21 07:17:39.854213
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    # test run function
    terms = ['not_exist_var']
    try:
        lm.run(terms)
    except AnsibleError as e:
        assert type(e) == AnsibleError
    else:
        raise AssertionError("Unit Test: test_LookupModule (constructor test) failed!")

    # test set_options
    with pytest.raises(AnsibleError):
        lm.set_options(var_options={'test': 'test'}, direct={'not_exist_key': 'test'})

# Generated at 2022-06-21 07:17:52.377126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    import ansible.module_utils.basic
    import json

    play_context = PlayContext()
    task_vars = dict(inventory_hostname='localhost', ansible_play_hosts=['host1','host2','host3'], ansible_play_batch=['host1','host2','host3'], ansible_play_hosts_all=['host1','host2','host3'])

# Generated at 2022-06-21 07:18:03.487206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(['item1', 'item2'], {'item1': 'test_item1', 'item2': 'test_item2'})
    assert result == ['test_item1', 'test_item2']
    result = lookup_module.run(['item1', 'item2'])
    assert result == ['test_item1', 'test_item2']
    result = lookup_module.run(['item1', 'item2'], {'item1': 'test_item1'})
    assert result == ['test_item1', 'test_item2']
    result = lookup_module.run(['item1', 'item2'], fail_on_undefined=False, default='default_value')