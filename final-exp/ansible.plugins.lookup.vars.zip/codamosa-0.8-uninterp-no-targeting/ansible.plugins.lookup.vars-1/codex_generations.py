

# Generated at 2022-06-21 07:08:49.326960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Mock of class Template to use in unit tests

# Generated at 2022-06-21 07:08:51.214234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 07:09:02.070884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['localhost'])
    variable_manager = inventory.get_variable_manager()

# Generated at 2022-06-21 07:09:06.602266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([u'inventory_dir'], dict(inventory_dir=u'/home/ansible/inventory')) == [u'/home/ansible/inventory']

# Generated at 2022-06-21 07:09:13.280515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with recursive lookup
    assert LookupModule.run(None, ['{{myvar1}}', '{{myvar2}}'], {'myvar1': '{{myvar2}}', 'myvar2': 'myval'}) == ['myval', 'myval']
    assert LookupModule.run(None, [1, '{{myvar2}}'], {'myvar2': 'myval'}) == [1, 'myval']
    # test failure of recursive lookup

# Generated at 2022-06-21 07:09:20.477569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with one variable defined and one variable not defined
    test_terms = ['defined_variable', 'undefined_variable']
    test_default = 'testing_default_value'
    test_variables = {
        'defined_variable': 'testing_defined_value',
        'hostvars': {
            'inventory_hostname': {
                'undefined_variable': 'testing_undefined_value'
            }
        }
    }

    lookup_module = LookupModule()
    ret = lookup_module.run(test_terms, test_variables, default=test_default)

    assert ret[0] == 'testing_defined_value'
    assert ret[1] == 'testing_undefined_value'

    # Test with one variable defined and one variable not defined
    # but this time without the default argument
    test_

# Generated at 2022-06-21 07:09:21.999353
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 07:09:24.876189
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup.vars import LookupModule
    lm = LookupModule()



# Generated at 2022-06-21 07:09:34.770127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up object
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import context_objects as co

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_inventory(inventory)
    host = inventory.get_host('localhost')

# Generated at 2022-06-21 07:09:44.329821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
       unit test for method run of LookupModule class.
       """
    from ansible import constants as C

    C.DEFAULT_HASH_BEHAVIOUR = 'merge'

    # Creating LookupModule object
    lookup_obj = LookupModule()
    # Creating dictionary for variables
    variables_dict = {
        "test_vars": {
            "1": "one",
            "2": "two",
            "3": "three"
        }
    }

    expected_result = [variables_dict["test_vars"]["1"]]
    result = lookup_obj.run(terms=["test_vars.1"], variables=variables_dict)
    assert result == expected_result

    # Creating dictionary for variables

# Generated at 2022-06-21 07:10:01.413676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = {}
    lookup.set_options({'_terms' : ['a', 'b'], 'default': 'NOTHING'})
    lookup._templar._available_variables = {'a': 'AA', 'c': 'CC'}
    assert lookup.run() == ['AA', 'NOTHING']
    lookup._templar._available_variables = {'a': 'AA', 'b': 'BB', 'c': 'CC'}
    assert lookup.run() == ['AA', 'BB']
    lookup._templar._available_variables = {'a': 'AA', 'b': None, 'c': 'CC'}
    assert lookup.run() == ['AA', None]

# Generated at 2022-06-21 07:10:03.669164
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None).run(['var']) == []

# Generated at 2022-06-21 07:10:04.945592
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 07:10:14.455915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import b

    # Setup for test
    lookup = LookupModule()
    lookup.set_loader({})
    lookup._templar = lookup._loader.get_basedir()
    lookup._templar._available_variables = {'hostvars': {'this_host': {'lookup': "This Is A Lookup Test"}}}

    # First test
    terms = ['lookup']
    variables = {}
    kwargs = {}
    try:
        result = lookup.run(terms, variables, **kwargs)
    except AnsibleError as e:
        assert False
    assert type(result) is list
    assert len(result) == 1
    assert result[0] == "This Is A Lookup Test"



# Generated at 2022-06-21 07:10:22.640575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with a single term
    assert LookupModule().run(["ansible_play_hosts"])[0] == ["scratch", "scratch2", "scratch3"]
    # Testing with a multiple terms
    assert LookupModule().run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]) == \
           [["scratch", "scratch2", "scratch3"], [3], ["scratch", "scratch2", "scratch3"]]

# Generated at 2022-06-21 07:10:27.227011
# Unit test for constructor of class LookupModule
def test_LookupModule(): # pylint: disable=missing-docstring
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 07:10:31.824797
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test right answers
    # test string term
    # test several terms
    # test a nested variable
    # test default
    # test raise exception
    pass

# Generated at 2022-06-21 07:10:44.112225
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.vault import VaultLib

    vault_secrets = {}

    # get secrets from vault and set to vault_secrets dict
    def get_vault_secrets():
        vault_secrets = VaultLib(vault_password).secrets
        return vault_secrets

    # helper methods to avoid get_vault_secrets()
    def get_secret(secret_file):
        if secret_file not in vault_secrets:
            vault_secrets.update(get_vault_secrets())

        return vault_secrets[secret_file]

    def get_variable(secret_file, variable):
        secret = get_secret(secret_file)

        if variable not in secret:
            raise AnsibleError('No variable found with this name: %s' % variable)


# Generated at 2022-06-21 07:10:56.767441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible
    ansible_module_version = ansible.__version__.rsplit('.', 1)[0]
    hosts_data = []
    hosts_all_data = []

    if ansible_module_version == "2.6":
        hosts_data = [
            "test_one",
            "test_two",
            "test_three"
        ]
        hosts_all_data = [
            "test_one",
            "test_two",
            "test_three"
        ]
    elif ansible_module_version == "2.5":
        hosts_data = [
            "test_four",
            "test_five",
            "test_six"
        ]

# Generated at 2022-06-21 07:11:02.800552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = AnsibleModule(
        argument_spec=dict(
            _terms=dict(type='list', elements='str', required=True),
            default=dict(type='str', required=False),
        ),
    )
    assert mod is not None

# Generated at 2022-06-21 07:11:12.310439
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return [{
        "_value": [
            "hello"
        ]
    }, {
        "_value": [
            ""
        ]
    }]

# Generated at 2022-06-21 07:11:16.551178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test the constructor of the class LookupModule.
    """
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 07:11:26.604198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestTemplar():
        def template(self, value, fail_on_undefined=None):
            if value == '{{ test_var }}':
                return 'test_value'
            elif value == '{{ test_var_from_nested_dict }}':
                return 'test_value_from_nested_dict'
            else:
                return value

    test_variables = {'ansible_play_hosts': 'first_play_hosts', 'ansible_play_batch': 'first_play_batch', 'ansible_play_hosts_all': 'first_play_hosts_all'}
    test_lookups = LookupModule()
    test_templar = TestTemplar()
    test_lookups._templar = test_templar

# Generated at 2022-06-21 07:11:37.916977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test default value
    assert LookupModule().run(terms=('test_var1',), variables={'test_var1': 'hello'}) == ['hello']
    assert LookupModule().run(terms=('test_var1',), variables={'test_var1': 'world'}) == ['world']
    assert  LookupModule().run(terms=('test_var1',), variables={'test_var1': ['test', 'world']}) == [['test', 'world']]
    assert LookupModule().run(terms=('test_var1',), variables={'test_var1': {'test': 'world'}}) == [{'test': 'world'}]

    # Test default value

# Generated at 2022-06-21 07:11:41.088714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ 'name', ]
    variables = { 'name': 'python2', 'hostvars': { 'localhost': { 'name': 'python2' }}}
    lookup = LookupModule()
    assert lookup.run(terms, variables=variables) == [ 'python2', ]

    variables = { 'name': 'python2', 'hostvars': { 'localhost': {}}}
    assert lookup.run(terms, variables=variables, default='') == [ '', ]



# Generated at 2022-06-21 07:11:48.965337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.template import Templar


# Generated at 2022-06-21 07:11:51.891167
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create object for LookupModule
    obj = LookupModule()
    # check for object
    if hasattr(obj, 'run'):
        print("True")

# run test for class LookupModule
test_LookupModule()

# Generated at 2022-06-21 07:11:58.179627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Execute code with mocked input and output:
    # To mock a class method, use side_effect:
    #
    # with patch.object(ClassName, 'methodName', side_effect=methodName) as methodName_mock:
    #     call to the method with parameters and call to the method without parameters:
    #     methodName_mock.assert_called_with(parameterName)
    #     methodName_mock.assert_called()
    pass
# LookupModule._get_plugin_options is tested in module_utils.lookup_utils.test_LookupModule._get_plugin_options

# Generated at 2022-06-21 07:12:02.303448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run([''], {'test_term': 12}) == [12]
    assert lookup.run(['test_term'], {'test_term': 12}) == [12]
    assert lookup.run(['', 'test_term'], {'test_term': 12}) == [None, 12]
    assert lookup.run(['test_term', ''], {'test_term': 12}) == [12, None]
    assert lookup.run(['test_term'], {'test_term': 12, '': 11}) == [12]



# Generated at 2022-06-21 07:12:11.757012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule(loader=None, templar=None, shared_loader_obj=None)

    # test default mode
    test_vars = {'foo': 'hello var. this is foo',
                 'bar': [1, 2, 3],
                 'baz': {'baz-1': 'baz-1'}}

    ret = test_class.run(terms=['foo', 'bar', 'baz'], variables=test_vars)

    assert ret[0] == 'hello var. this is foo'
    assert ret[1] == [1, 2, 3]
    assert ret[2] == {'baz-1': 'baz-1'}

    # test default mode with missing var

# Generated at 2022-06-21 07:12:29.189859
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert isinstance(lookup_obj, LookupModule)

# Generated at 2022-06-21 07:12:40.087508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=import-error
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.templating import Templar
    from ansible.plugins.lookup import LookupModule

    class TestTemplar(Templar):
        def __init__(self, loader, variables, **kwargs):
            super(TestTemplar, self).__init__(loader, variables)
            self._available_variables = kwargs

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 07:12:48.761593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    vault_pass = to_bytes('vault_password')
    vault = VaultLib(vault_pass)
    vault_secret = VaultSecret(vault_pass, 'sha1', vault)

    class Options(object):
        def __init__(self):
            self.default = None
    options = Options()

    class Templar(object):
        def __init__(self):
            self._available_variables = {}
            self._available_variables['first_nested_var'] = 'first nested var value'

# Generated at 2022-06-21 07:12:50.048739
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:12:51.467082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 07:13:03.421435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {}
    lookup_module._templar._available_variables.update({"hostvars": {"host1": {"asdf": 12}}})
    # Test that it fails when the variable is not found
    try:
        lookup_module.run(["asdf"])
        assert False, "AnsibleUndefinedVariable not raised"
    except AnsibleUndefinedVariable:
        assert True
    # Test that it fails when the variable is not found in a different host
    try:
        lookup_module.run(["hostvars.host2.asdf"])
        assert False, "AnsibleUndefinedVariable not raised"
    except AnsibleUndefinedVariable:
        assert True
    # Test that the variable is found
    assert lookup_

# Generated at 2022-06-21 07:13:05.092597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:13:15.401594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Create a template
    my_variables = {
        'my_name': 'Bob'
    }
    terms = ['my_name']
    result = lookup.run(terms, my_variables)
    assert result == ['Bob']

    # Check if the default value is returned when needed
    my_variables = {
        'my_name': 'Bob'
    }
    terms = ['my_other_name']
    result = lookup.run(terms, my_variables, default=5)
    assert result == [5]

    my_variables = {
        'my_name': 'Bob'
    }
    terms = ['my_other_name']
    result = lookup.run(terms, my_variables)
    assert result == []

    #Check nested variables
    my

# Generated at 2022-06-21 07:13:24.981743
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # Set up necessary variables and objects needed to load plugins
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list='localhost')

    # Create a new lookup module with the appropriate settings
    lookup_module = LookupModule()
    lookup_module.set_loader(loader)
    lookup_module.set_inventory(inventory)
    lookup_module.set_variable_manager(variable_manager)
    res = lookup_module.run([['test_name'], ['test_name']], {'test_name': ['test_name']})
    assert res == [['test_name'], ['test_name']]



# Generated at 2022-06-21 07:13:25.319881
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-21 07:13:59.960193
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a temporary inventory file
    inv_file = '''
    [webservers]
    tomcat ansible_host="192.168.1.1"
    '''
    inventory_file = open("inventory_file", 'w')
    inventory_file.write(inv_file)
    inventory_file.close()

    # test the lookup module
    mylookup = LookupModule()
    mylookup._set_loader()

    # check the file
    assert (os.path.exists(inventory_file.name))

    # delete the file
    os.remove(inventory_file.name)

# Generated at 2022-06-21 07:14:11.401472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # testing with valid variables
    data = dict(inventory_hostname='localhost', hostvars=dict(localhost=dict(var='localhostvar')))
    terms = ['var', 'inventory_hostname']

    lookup_plugin = LookupModule()
    actual_result = lookup_plugin.run(terms, data)

    assert len(actual_result) == len(terms),\
        'The len of returned should be `len(terms)`'
    for var in actual_result:
        assert var in ['localhostvar', 'localhost'],\
            'The returned value should be in {var, inventory_hostname}'

    # testing with variabls that is not in data
    terms.append('not_avail_var')

    lookup_plugin = LookupModule()
    actual_result = lookup_plugin.run(terms, data)



# Generated at 2022-06-21 07:14:22.587947
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test yield correct result with default set to None
    lookup_module = LookupModule()
    lookup_module._templar.available_variables = {"var":"hello"}
    results=list(lookup_module.run([], variables={"var":"hello"}))
    assert results == []
    results=list(lookup_module.run(["var"], variables={"var":"hello"}))
    assert results == ["hello"]
    results=list(lookup_module.run(["var", "var"], variables={"var":"hello"}))
    assert results == ["hello", "hello"]
    results=list(lookup_module.run(terms=["var", "var"], variables={"var":"hello"}, default=123))
    assert results == ["hello", 123]

    # test yield correct result with default set to ''

# Generated at 2022-06-21 07:14:29.703836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = 'test_var'
    variables = {terms: 'test_val'}
    ret = lookup_module.run([terms], variables)
    assert ret == ['test_val']

# Generated at 2022-06-21 07:14:30.768361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert True

# Generated at 2022-06-21 07:14:42.025073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with parameters that are expected to succeed
    templar = LookupModule("test_templar", "test_loader")
    assert isinstance(templar._loader, "test_loader")
    assert templar._templar == "test_templar"

    # Test with parameters that are expected to fail
    try:
        templar = LookupModule("test_templar")
    except TypeError:
        pass
    except Exception:
        assert False
    try:
        templar = LookupModule("test_templar", None)
    except TypeError:
        pass
    except Exception:
        assert False



# Generated at 2022-06-21 07:14:52.626109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'variablename',
        'variablenotename',
        'variablenotename',
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all',
        'variablename',
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]

    hostvars = {
        'host1': {'variablename': 'hello', 'nested': {'sub_var': 12}},
        'host2': {'inventory_hostname': 'host2'}
    }


# Generated at 2022-06-21 07:15:03.733833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible.vars import VariableManager

    mytemplar = Templar(loader=None, variables=None)

    vm = VariableManager()
    vm.hostvars = {}
    vm.hostvars['host1'] = {'var1': 'val1', 'var2': 'val2'}
    vm.hostvars['host2'] = {'var2': 'val2', 'var3': 'val3'}
    mytemplar._available_variables = vm.get_vars(loader=None, play=None)

    l = LookupModule(loader=None)

# Generated at 2022-06-21 07:15:16.459012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader

    module_loader, lookup_loader, tests_dir = basic._setup_loader()

    ####################################################################
    # Define the files and objects we need to test the LookupModule.run method
    ####################################################################

    # This file is like host_vars/host_with_host_vars_test.yml
    host_vars_file = tests_dir / 'test_lookup_vars/host_vars/host_with_host_vars_test.yml'
    host_vars_file_str = host_vars_file.strpath

    # This file is like host_vars/group_with_vars_

# Generated at 2022-06-21 07:15:22.718867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    terms = ['ansible']
    variables = {'ansible': 'Ansible'}
    options = {'_terms': terms, '_variables': variables}
    t = LookupModule()
    res = t.run(terms, variables, **options)
    assert res == ['Ansible']


# Generated at 2022-06-21 07:16:28.967897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if error is raised when term is not a string
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    result = LookupModule().run([u'variable'], variables={'variable': 'Test'}, fail_on_undefined=True)
    assert result == ['Test']
    terms = [
        123,
        ['variable'],
        {'variable': 'variable'}
    ]
    for term in terms:
        try:
            LookupModule().run([term], variables={'variable': 'Test'}, fail_on_undefined=True)
        except AnsibleError as e:
            assert e.message == 'Invalid setting identifier, "%s" is not a string, its a %s' % (term, type(term))
        else:
            raise AssertionError

# Generated at 2022-06-21 07:16:40.742960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()

    # LookupModule.run
    # Test with expected result
    terms = ['test_key1', 'test_key2']
    variable = {
        'test_key1':'test_value1',
        'test_key2':'test_value2'
    }
    expected = ['test_value1', 'test_value2']
    result = test_class.run(terms=terms, variables=variable)
    assert result == expected

    # Test with unexpected result
    terms = ['test_key1']
    variable = {'test_key2':'test_value2'}
    with pytest.raises(AnsibleUndefinedVariable):
        test_class.run(terms=terms, variables=variable)

    # Test with default
    terms = ['test_key1']

# Generated at 2022-06-21 07:16:47.379260
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    variables = VariableManager(loader=loader, inventory=inv_manager)
    lm = LookupModule()

    assert lm.run(terms=['env'], variables=variables) == []

# Generated at 2022-06-21 07:16:59.932176
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a LookupModule object
    lm = LookupModule()

    # Create a terms object
    terms = []

    # Set the options for the object
    set_options_dict = {}

    # Test the run function
    def run_test():
        return lm.run(terms, **set_options_dict)

    # Test with empty terms
    assert run_test() == [], 'Expected an empty return.'

    # Test with single term
    terms = ['term1']
    set_options_dict['var_options'] = 'test_var'
    with pytest.raises(AnsibleError) as err:
        run_test()
    assert 'is not a string' in str(err.value), 'Expected "is not a string", but got "{0}".'.format(err.value)

    #

# Generated at 2022-06-21 07:17:02.857769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 07:17:17.207203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.lookup_plugins._terms import Terms
    from ansible.module_utils.lookup_plugins.vars import LookupModule
    from ansible.module_utils.lookup_plugins.vars import VARS_TERMS
    from ansible.module_utils.lookup_plugins.vars import VARS_TERM_OPTIONS
    from ansible.module_utils.lookup_plugins.vars import VARS_TERM_DEFAULT

    VARS_TERMS_INSTANCE = Terms(VARS_TERMS, VARS_TERM_OPTIONS, VARS_TERM_DEFAULT)

    lookup_module_instance = LookupModule()
    lookup_module_instance.terms = VARS_TERMS_INSTANCE

# Generated at 2022-06-21 07:17:29.742625
# Unit test for constructor of class LookupModule
def test_LookupModule():
    input_vars = {
        'host1': {
            'hostvars':
            {
                'hostname': 'host1',
                'subvar': 'sub1'
            },
            'sub':
            {
                'sub_var': 12
            }
        },
        'sub': {
            'sub_var2': 3
        }
    }
    terms = ['sub', 'sub_var2']
    def _read_config(data=None, fail_on_undefined=True):
        return data

    LookupModule._read_config = _read_config
    lm = LookupModule()
    result = lm.run(terms=terms, variables=input_vars)
    assert result == [3]

    terms = ['sub', 'sub_var']
    result = lm.run

# Generated at 2022-06-21 07:17:41.866945
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms =['test1', 'test2']
    ret = lookup.run(terms)
    assert ret == ['test1', 'test2'], 'test1, test2 is expected to be returned'

    # Test invalid argument
    invalid_terms = [123, 456]
    try:
        lookup.run(invalid_terms)  # Test the exception
        assert False, 'AnsibleError is expected to be raised'
    except AnsibleError:
        # Expected error
        assert True

    lookup_args = {'default': 'test'}
    ret = lookup.run(invalid_terms, **lookup_args)
    assert ret == ['test', 'test'], 'test, test is expected to be returned'

# Example from the documentation

# Generated at 2022-06-21 07:17:54.176855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod._templar = MockTemplar()

    # positive test for one valid variable for one term
    terms = ['valid_var']
    variables = {'valid_var': 'v_value'}
    mod.run(terms, variables)

    # positive test for one valid variable for two term
    terms = ['valid_var', 'valid_var2']
    variables = {'valid_var': 'v_value', 'valid_var2': 'v_value2'}
    mod.run(terms, variables)

    # positive test for one valid variable with a default
    terms = ['valid_var', 'valid_var2']
    variables = {'valid_var': 'v_value'}
    mod.run(terms, variables, default='abc')

    # positive test for one invalid variable with

# Generated at 2022-06-21 07:18:07.151710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin._templar._available_variables = { 'foo' : 'bar', 'one' : 1 }
    assert lookup_plugin.run(terms=['foo'], variables={ 'foo': 'baz' }) == ['baz']
    assert lookup_plugin.run(terms=['foo'], variables={ 'foo': 'baz' }, default='buz') == ['baz']
    assert lookup_plugin.run(terms=['foo']) == ['bar']
    assert lookup_plugin.run(terms=['foo'], default='buz') == ['bar']
    assert lookup_plugin.run(terms=['one'], variables={ 'foo': 'baz' }) == [1]