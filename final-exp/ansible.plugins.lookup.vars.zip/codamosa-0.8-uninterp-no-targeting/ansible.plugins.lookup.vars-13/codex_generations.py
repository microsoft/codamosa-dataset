

# Generated at 2022-06-21 07:08:51.060782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() != None

# Generated at 2022-06-21 07:08:55.292008
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    assert isinstance(LookupModule.run, types.MethodType)

# Generated at 2022-06-21 07:08:58.888588
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import jinja2.exceptions

    # construct a class LookupModule()
    from ansible.plugins.lookup.vars import LookupModule
    lookup_module = LookupModule()

    # construct the ansible variable
    variables = dict(ansible_play_hosts=[dict(name='1.1.1.1'), dict(name='2.2.2.2')])

    # construct the arguments list
    terms=['ansible_play_hosts']

    try:
        # execute the run function LookupModule.run()
        lookup_module.run(terms, variables)
    except jinja2.exceptions.UndefinedError as e:
        assert False, "variable undefined,{0}".format(e)

# Generated at 2022-06-21 07:09:10.416907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=W0621, no-value-for-parameter
    lm = LookupModule()
    lm.set_options(var_options={'variablename': 'hello'}, direct={})
    assert lm.run(['variablename']) == ['hello']
    assert lm.run(['variablename', 'variablename']) == ['hello', 'hello']
    lm.set_options(var_options={'variablename': 123}, direct={})
    assert lm.run(['variablename']) == [123]

    # Test default value
    lm.set_options(var_options={}, direct={'default': 'defaultval'})
    assert lm.run(['variablename']) == ['defaultval']
    lm

# Generated at 2022-06-21 07:09:19.466890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar = ''
    with pytest.raises(AnsibleError):
        lm.run(terms=[{'dict':'dict'}], variables={})
    lm._templar = ''
    with pytest.raises(AnsibleUndefinedVariable):
        lm.run(terms=['dict'], variables={'inventory_hostname':'test'})
    
    lm._templar = ''
    assert lm.run(terms=['dict'], variables={'inventory_hostname':'test', 'hostvars':{'test':{'dict':'dict'}}}) == ['dict']

    lm._templar = ''

# Generated at 2022-06-21 07:09:22.944992
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Tests LookupModule constructor
    """
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 07:09:31.896960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {
        'ansible_play_batch': [1,2,3,4],
        'ansible_play_hosts': ['localhost'],
        'ansible_play_hosts_all': ['localhost'],
    }
    lookup_obj._templar._available_variables = variables
    result = lookup_obj.run(terms)
    assert result[0] == variables['ansible_play_hosts']
    assert result[1] == variables['ansible_play_batch']
    assert result[2] == variables['ansible_play_hosts_all']

# Generated at 2022-06-21 07:09:43.709417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    display = Display()
    templar = Templar(loader=None, variables={}, display=display)
    variable_manager = VariableManager(loader=None, variables={})

    lookup = LookupModule(templar=templar, display=display)
    lookup.set_options(default=None)

# Generated at 2022-06-21 07:09:53.695577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import unittest
    import tempfile
    import shutil
    import stat
    import json

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.vault_pass = tempfile.mkstemp()
            self.vault_pass_content = 'hunter2'

            # create a fake ansible.cfg
            self.configuration_file_path = os.path.join(self.tmpdir, "ansible.cfg")
            self.configuration_content = """
[defaults]
vault_password_file=%s
""" % self.vault_pass[1]

# Generated at 2022-06-21 07:09:55.605624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({}, {}, {}, {})

# Generated at 2022-06-21 07:10:11.891555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Incomplete mock of class LookupBase()
    class _LookupBase(object):
        def __init__(self):
            self.default = None

        def set_options(self, **kwargs):
            return None

        def get_option(self, name):
            return self.default

        def _templar(self, value, fail_on_undefined=True):
            return value

    # Mocking of class LookupModule()
    class LookupModule(_LookupBase):
        def __init__(self):
            self.variable = None

            # mock of LookupBase() creation
            _LookupBase.__init__(self)


# Generated at 2022-06-21 07:10:22.461088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms='test')
    l.run(terms=[])
    l.run(terms=[1])
    try:
        l.run(terms=['test', 1])
    except Exception as ex:
        assert isinstance(ex, AnsibleError)
        assert 'not a string' in str(ex)
    try:
        l.run(terms=['test'], default='')
    except Exception as ex:
        assert isinstance(ex, AnsibleUndefinedVariable)
        assert 'No variable' in str(ex)

# Generated at 2022-06-21 07:10:30.389585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # arrange
    auth = {'name': 'john', 'password': 'pass123', 'as_user': 'root'}
    lu = LookupModule()
    # act
    actual = lu.run([auth, '2'], None, dummy='d')
    expected = [auth, '2']
    # assert
    assert expected == actual, 'Expected: ' + str(expected) + ', Actual: ' + str(actual)

# Generated at 2022-06-21 07:10:32.024712
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert type(x) == LookupModule

# Generated at 2022-06-21 07:10:35.776934
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for constructor of class LookupModule'''
    l = LookupModule()
    assert hasattr(l, '_templar')
    assert hasattr(l, '_available_variables')

# Generated at 2022-06-21 07:10:43.395976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test sample 1
    test_1 = {}
    test_1['ansible_play_hosts'] = ['localhost', '127.0.0.1']
    test_1['ansible_play_batch'] = [1, 2]
    test_1['ansible_play_hosts_all'] = [2, 3]
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    LookupModule().run(terms, variables=test_1)

# Generated at 2022-06-21 07:10:50.392669
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setting up the variables
    terms = ['foo', 'bar']
    variables = {'foo': 'Foo', 'bar': 'Bar'}

    # Running the test method
    result = LookupModule.run(terms=terms, variables=variables)

    # Asserting the result
    assert result == ['Foo', 'Bar']

# Generated at 2022-06-21 07:11:03.028272
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import pytest

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})
    variable_manager = VariableManager()

    lookup_obj = LookupModule()
    lookup_obj.set_options({'_ansible_variable_manager': variable_manager})
    lookup_obj.set_options({'_ansible_play_context': play_context})
    lookup_obj._templar = templar

    with pytest.raises(AnsibleError):
        lookup_obj.run([None])


# Generated at 2022-06-21 07:11:13.434021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # construct a minimal mock templar object
    import tempfile
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader

    MockTemplarResult = namedtuple('MockTemplarResult', (
        '_available_variables',
    ))

    MockTemplar = namedtuple('MockTemplar', (
        'available_variables',
        '_available_variables',
        'template',
    ))
    mock_loader = DataLoader()

# Generated at 2022-06-21 07:11:14.905685
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    print (l)

# Generated at 2022-06-21 07:11:34.815833
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display

    # Setup for LookupModule
    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    display = Display()

    PLUGIN_INSTANCE = LookupModule(loader=loader, variables=variables, inventory=inventory, display=display)
    assert PLUGIN_INSTANCE._loader == loader
    assert PLUGIN_INSTANCE._templar == variables
    assert PLUGIN_INSTANCE._display == display
    assert PLUGIN_INSTANCE._display.verbosity == 3

# Generated at 2022-06-21 07:11:43.144547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    lookup = LookupModule()

# Generated at 2022-06-21 07:11:46.666137
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.options is None

# Generated at 2022-06-21 07:11:57.015029
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit: test a simple lookup by providing a defined variable name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['ansible_all_ipv4_addresses'],
                             variables={'ansible_all_ipv4_addresses': '192.0.2.1'}) == ['192.0.2.1']

    # Unit: test a simple lookup by providing a defined variable name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=[u'ansible_all_ipv4_addresses'],
                             variables={'ansible_all_ipv4_addresses': u'192.0.2.1'}) == [u'192.0.2.1']

    # Unit: test a simple lookup by providing a defined variable name with default=False


# Generated at 2022-06-21 07:11:57.768071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lo = LookupModule()
    assert lo is not None

# Generated at 2022-06-21 07:12:00.219198
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  # test the run method to ensure it works correctly
  assert lookup.run(['foo', 'bar']) == []

if __name__ == '__main__':
  test_LookupModule()

# Generated at 2022-06-21 07:12:09.297925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    def _load_vars(terms):
        return {
            "hello": "world",
            "foo": "bar",
            "zoo": "123",
            "item": terms,
            "ansible_play_hosts": "foo",
            "ansible_play_batch": "bar",
            "ansible_play_hosts_all": "zoo"
        }

    assert lookup.run([], []) == []
    assert lookup.run(["hello"], _load_vars("inner")) == ["world"]
    assert lookup.run(["hello", "foo"], _load_vars("inner")) == ["world", "bar"]
    assert lookup.run(["hello", "foo", "zoo"], _load_vars("inner")) == ["world", "bar", "123"]


# Generated at 2022-06-21 07:12:10.133467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-21 07:12:10.983871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create instance of class LookupModule
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 07:12:19.825766
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with invalid type of arguments
    test_obj = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        test_obj.run([1,2,3], [1,2,3])
    assert 'Expected string or bytes object' in str(excinfo.value)

    # Test with invalid type of arguments
    test_obj = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        test_obj.run(1, [1,2,3])
    assert 'Expected string or bytes object' in str(excinfo.value)

    # Test with valid arguments
    test_obj = LookupModule()
    assert test_obj.run(['name', 'version']) == [None, None]

# Generated at 2022-06-21 07:12:41.945048
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global_variables = {
        u'ansible_play_hosts': [u'host1.example.com'],
        u'ansible_play_hosts_all': [u'all'],
        u'ansible_play_batch': [u'first'],
    }
    host_variables = {
        u'ansible_play_hosts': [u'host1.example.com'],
        u'ansible_play_hosts_all': [u'all'],
        u'ansible_play_batch': [u'first'],
    }
    inventory = {
        u'host1.example.com': {}
    }
    templar = DummyTemplar(host_variables, global_variables, inventory)
    lookup_module = LookupModule(templar)

# Generated at 2022-06-21 07:12:51.358233
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test: Use of class LookupModule to get value of variable
    def test_simple_variable_value(mocker, monkeypatch):
        monkeypatch.setattr(AnsibleError, '__init__', lambda x, y: None)
        monkeypatch.setattr(AnsibleError, '__repr__', lambda x: None)
        monkeypatch.setattr(AnsibleError, '__str__', lambda x: 'AnsibleError')
        mocker.patch('ansible.errors.AnsibleError')
        mocker.patch('ansible.plugins.lookup.LookupBase.set_options')
        mocker.patch('ansible.plugins.lookup.LookupBase.get_option')
        mocker.patch('ansible.utils.template.Templar.template', lambda x: None)
        m

# Generated at 2022-06-21 07:12:52.934652
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('vars')

# Generated at 2022-06-21 07:13:04.002534
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import yaml
    lookup = LookupModule()
    tc = '''
        tasks:
          - debug:
              msg: "{{ lookup('vars', 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all') }}"
    '''

    ret = lookup.run(terms = [ 'ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all' ],
                     variables = yaml.load(os.popen("ansible-playbook -i localhost -vvvvv test.yml --extra-vars '@test.yml' "
                                                   "--tags debug  -e 'host_key_checking=False' --list-tasks"))['vars'])

# Generated at 2022-06-21 07:13:12.666154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This test asserts whether the LookupModule class was initialized properly
    """
    # Arrange
    loader = 'fake-loader'
    templar = 'fake-templar'
    args = (loader, templar)

    # Act
    lookup_module = LookupModule(*args)
    my_loader = lookup_module._loader
    my_templar = lookup_module._templar

    # Assert
    assert my_loader == loader
    assert my_templar == templar

# Generated at 2022-06-21 07:13:25.454860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # Test with success
    assert lookup_plugin.run(["this"], dict(this="value")) == ["value"]

    # Test error if a variable is not present
    with pytest.raises(AnsibleError):
        lookup_plugin.run(["this", "that"], dict(this="value"))

    # Test with an undefined variable but with a default value
    assert lookup_plugin.run(["this", "that"], dict(this="value"), default="") == ["value", ""]

    # Test with an array of dict
    assert lookup_plugin.run(["this"], dict(this=[{"key": "value"}])) == [[{"key": "value"}]]
    # Test with a dict

# Generated at 2022-06-21 07:13:34.419491
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_obj = LookupModule()

    # Test with empty terms
    test_vars = {'hostvars': {'hostname': {'var1': 'value1', 'var2': 'value2'}}}
    assert test_obj.run([], test_vars) == []

    # Test with simple term
    test_vars = {'var1': 'value1'}
    assert test_obj.run(['var1'], test_vars)[0] == 'value1'

    # Test with complex term
    test_vars = {'var1': 'value1', 'var2': 'value2'}
    assert test_obj.run(['var1' + 'var2'], test_vars)[0] == 'value1value2'

    # Test with complex and simple terms
    test_vars

# Generated at 2022-06-21 07:13:41.868306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test_terms = [
                'ansible_play_hosts',
                'ansible_play_batch',
                'ansible_play_hosts_all',
                ]
    # Set the variables required in test_terms, different values of variables

# Generated at 2022-06-21 07:13:55.030007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import pytest

    # Use the dummy class DummyLookupBase for testing purposes
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.path import unfrackpath

    class DummyLookupModule(LookupBase):
        def __init__(self):
            self.called_run = None

        def run(self, terms, variables=None, **kwargs):
            self.called_run = terms
            return super().run(terms, variables, **kwargs)

    # first, import mymodule and execute it
    sys.path.append(unfrackpath('/test_LookupModule_run'))
    import mymodule

    mymodule.run_module = DummyLookupModule()

    # Set the ansible variables

# Generated at 2022-06-21 07:14:00.603102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(terms=["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"], variables={"ansible_play_hosts": "a", "ansible_play_batch": "b", "ansible_play_hosts_all": "c"}) == ["a", "b", "c"]

# Generated at 2022-06-21 07:14:31.460328
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)


# Generated at 2022-06-21 07:14:41.462511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = DummyTemplar()
    l._templar._available_variables = {'hostvars': {'host1': {'var1': 15, 'var2': 'Hello'}}, 'var3': 15}
    terms = ['var1', 'var2', 'var4']
    variables = {'var4': 'foo'}
    res = l.run(terms, variables)
    assert res == [15, 'Hello', 'foo']

    l = LookupModule()
    l._templar = DummyTemplar()
    l._templar._available_variables = {'hostvars': {'host1': {'var1': 15, 'var2': 'Hello'}}, 'var3': 15}

# Generated at 2022-06-21 07:14:53.700077
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.template import Templar

    # This is the dict that would be passed in as vars
    # in the context of the playbook
    variables = dict(
        variablename = "hello",
        myvar = "ename",
        variablenotename = "goodbye",
        mynotename = "notename"
    )

    # This is the dict that would be passed in as terms
    terms = dict(
        variablename = "variabl" + variables['myvar'],
        default = variables['myvar'],
        variablenotename = "variabl" + variables['mynotename'],
    )

    # This is the dict that would be passed in as kwargs
    # in the context of the playbook
    kwargs = dict(
        default = ''
    )

    lm = Look

# Generated at 2022-06-21 07:15:04.191007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import os

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=os.path.join(os.path.dirname(__file__), '../../../inventory'))
    host_variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:15:10.688339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    lookupModule._templar = {}
    lookupModule.set_options(direct={})
    assert lookupModule.run(['variablename'], {'variablename': 'hello'}) == ['hello']

# Generated at 2022-06-21 07:15:11.687405
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance = LookupModule()
    assert isinstance(test_instance, LookupModule)

# Generated at 2022-06-21 07:15:13.999417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert lookup_module.run([]) == []

# Generated at 2022-06-21 07:15:25.134268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(['a', 'b'], {'a': 11, 'b': 22}) == [11, 22]
    assert l.run(['a', 'b', 'c'], {'a': 11, 'b': 22}) == [11, 22]
    assert l.run(['a', 'b', 'c'], {'a': 11, 'b': 22}, default=33) == [11, 22, 33]
    try:
        assert l.run(['a', 'b', 'c'], {'a': 11, 'b': 22}) == [11, 22, 33]
        assert False
    except AnsibleUndefinedVariable:
        pass

# Generated at 2022-06-21 07:15:36.929982
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Create test object LookupModule
    args = (None, 'my_terms', 'my_variables')
    kwargs = {'kwargs1': 'value1'}
    lm = LookupModule(*args, **kwargs)

    # Test arg 'terms' is expected to be a list
    # Test that LookupModule does not accept non-string types for arg 'terms'
    for non_string_term in [1, 2.0, dict(), list(), tuple()]:
        lm = LookupModule(*args, **kwargs)
        terms = ['term1', non_string_term]
        lm._templar = MagicMock()

# Generated at 2022-06-21 07:15:42.047972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lc = LookupModule()
    terms = 'test_var'
    variables = dict(test_var=True, test_var2='hello')
    ret = lc.run(terms, variables)
    assert ret == [True]


# Generated at 2022-06-21 07:16:41.404424
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-21 07:16:42.844256
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 07:16:43.266202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 07:16:50.354113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # Test run with empty args
    assert lookup.run(terms=[]) == []

    # Test run with one arg that doesn't exist in the variables
    assert lookup.run(terms=['arg1'], variables={'arg2':'value2'}) == []

    # Test run with one arg that exists in the variables
    assert lookup.run(terms=['arg1'], variables={'arg1':'value1'}) == ['value1']

    # Test run with two args that exist in the variables
    assert lookup.run(terms=['arg1', 'arg2'], variables={'arg1':'value1', 'arg2':'value2'}) == ['value1', 'value2']

    # Test run with two args of which the first doesn't exist in the variables

# Generated at 2022-06-21 07:16:59.603748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six.moves import builtins

    class FakeTemplar:
        def __init__(self):
            self._available_variables = {}
            self.template = self.my_template
            self.available_variables = {}

        def my_template(self, data, fail_on_undefined=True):
            ret = []
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, string_types):
                        ret.append(item)
                    else:
                        ret.append(self.my_template(item))

# Generated at 2022-06-21 07:17:12.554952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    setattr(lookup, '_templar', DummyTemplar())
    terms = ["variablename"]
    variables = {'variablename': 'hello','myvar': 'ename'}
    assert 'hello' == lookup.run(terms, variables=variables)[0]
    terms = ["variablnotename"]
    variables = {'variablename': 'hello','myvar': 'notename'}
    assert '' == lookup.run(terms, variables=variables, default='')[0]
    iterations = 0
    try:
        lookup.run(terms, variables=variables)
    except Exception as e:
        assert 'No variable found with this name' in str(e)
        iterations += 1
    assert iterations == 1

# Generated at 2022-06-21 07:17:13.467936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    print(obj)


# Generated at 2022-06-21 07:17:14.502337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ml = LookupModule()
    assert ml is not None


# Generated at 2022-06-21 07:17:16.063601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup_class = LookupModule()
    # Test the constructor
    assert test_lookup_class

# Generated at 2022-06-21 07:17:24.587404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar
    import ansible.parsing.yaml.objects
    assert(str(LookupModule)) == '<class \'ansible.plugins.lookup.vars.LookupModule\'>'
    assert(str(LookupModule.default)) == '<function LookupBase.default at 0x7f2ffc2b89b0>'
    assert(str(LookupModule.default.__name__)) == 'default'
    assert(str(LookupModule.default.__module__)) == 'ansible.plugins.lookup.vars'
    assert(str(LookupModule.run)) == '<function run at 0x7f2ffc2b8730>'
    assert(str(LookupModule.run.__name__)) == 'run'