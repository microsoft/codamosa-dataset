

# Generated at 2022-06-21 07:08:49.622052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result.run([]) == []


# Generated at 2022-06-21 07:08:55.620631
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Instantiation of LookupModule
    lm = LookupModule()

    # Testing if lm is a instance of LookupModule
    assert isinstance(lm, LookupModule)

    # Test repr method
    assert repr(lm) == "LookupModule()"

# Generated at 2022-06-21 07:08:59.428187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_runner({'inventory_hostname': 'test-lookup-module'})
    lookup_module._templar.available_variables = {'inventory_hostname': 'test-lookup-module',
                                                  'hostvars': {'test-lookup-module':
                                                               {'var_to_find': 'foo'}}}

    assert lookup_module.run([''], {}) == list()
    assert lookup_module.run(['var_to_find'], {}) == ['foo']
    assert lookup_module.run(['var_to_not_find'], {}) == list()
    assert lookup_module.run(['var_to_not_find'], {}, default='bar') == ['bar']
    assert lookup_module.run

# Generated at 2022-06-21 07:09:07.404830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Get the object of LookupModule
    lookup_module = LookupModule()
    
    # Create the variables for the test
    variables = {}
    variables['hostvars'] = { 'localhost': {'az': 'east'} }
    variables['inventory_hostname'] = 'localhost'
    
    # Create the test terms
    terms = ['az']
    # Execute the run method of LookupModule
    lookup_module.run(terms, variables)

# Generated at 2022-06-21 07:09:08.880746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 07:09:19.007730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock AnsibleModule
    ansible_module = mock.Mock()
    # create LookupModule instance
    instance = LookupModule()
    # mock ret variable
    test_ret = ['mocked_ret']
    # mock value variable
    test_value = ['mocked_value']
    # mock default variable
    test_default = ['mocked_default']

    # Test 1.
    # Test description: Test when a variable is not found in the environment
    # Test expectation: An Ansible error is raised
    with pytest.raises(AnsibleError):
        instance.run('test_term', variables=test_value)

    # Test 2.
    # Test description: Test when a variable is not found in the environment and default is set
    # Test expectation: The default is returned

# Generated at 2022-06-21 07:09:21.763358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check the constructor
    module = LookupModule(None, {}, None, None)

# Generated at 2022-06-21 07:09:31.760742
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import mock
    import pytest

    from ansible.module_utils.six import string_types

    from ansible.template import Templar

    from ansible.errors import AnsibleError, AnsibleUndefinedVariable

    templar = Templar(loader=None)

    vm = mock.MagicMock()
    vm.vars = {}
    vm.vars['template_data'] = 'testing'

    vm.run.side_effect = AnsibleUndefinedVariable('No variable found with this name: %s' % 'template_data')
    vm.get_option.side_effect = AnsibleUndefinedVariable('No variable found with this name: %s' % 'template_data')

    vars_dict = {}
    vars_dict['template_data'] = 'testing2'
    vm.vars = vars_dict

    mylook

# Generated at 2022-06-21 07:09:36.343239
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()

# Generated at 2022-06-21 07:09:40.748926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    
    lookup_module = LookupModule()
    terms = [1, 2, 3]
    
    try:
        lookup_module.run(terms)
    except AnsibleError:
        assert True

# Generated at 2022-06-21 07:09:50.955223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run("Term", {"foo": "bar"})
    lookup_plugin.run("Term", {"foo": "bar"}, default="Default")
    lookup_plugin.run("Term", {"foo": "bar"}, ignore_undefined=False)

# Generated at 2022-06-21 07:09:54.436419
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    result = lookup_module.run(["hostvars", "inventory_hostname"])
    assert result == []

# Generated at 2022-06-21 07:10:01.352418
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test without fail_on_undefined=True
    LookupModule(loader=None,templar=None, variables=None)

    # Test with fail_on_undefined=True
    LookupModule(loader=None,templar=None, variables=None, fail_on_undefined=True)

    #Test with fail_on_undefined=True and undefined variable
    lookup_module = LookupModule(loader=None,templar=None, variables=None, fail_on_undefined=True)
    assert lookup_module.run(["some_undefined_var"]) == []

# Generated at 2022-06-21 07:10:02.844393
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 07:10:13.841674
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    my_variable_manager = {
        'inventory_hostname': 'alpha',

        'name_of_variable': 'value_of_variable',
        'name_of_variable_two': {'sub_var': 'value_of_subvar'},

        'not_in_hostvars': 'something',
        'hostvars': {
            'alpha': {
                'hostvars_one': 'hostvars_value',
                'hostvars_two': {'sub_var': 'hostvars_value'},
            },
        }
    }

    value = LookupModule(Templar(loader=None)).run(
        terms=['name_of_variable'], variables=my_variable_manager)
   

# Generated at 2022-06-21 07:10:23.021414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a mock module and mock the vars variable
    passed_vars = {'variable_name': 'value'}
    passed_vars['hostvars'] = {'hostname': {'host_variable': 'host_value'}}

    lu = LookupModule(loader=None, templar=None)
    lu.set_options(var_options=passed_vars, direct=None)

    assert lu._templar._available_variables is passed_vars, \
        'Templar not passed to LookupModule constructor'

# Generated at 2022-06-21 07:10:25.863715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""
    assert True

# Generated at 2022-06-21 07:10:39.755976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    test_success_msg = "Success - Lookup Module should have handled this case!"
    test_failure_msg = "Failed - Lookup Module should have handled this case!"
    module_name = "lookup"
    lookup_name = "vars"

    # Test for method run of class LookupModule with an invalid term to lookup (e.g. not a string)
    # Success: the AnsibleError exception is raised

# Generated at 2022-06-21 07:10:41.748414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    assert(lookup_class != None)

# Generated at 2022-06-21 07:10:47.784491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of class LookupModule
    obj_lookup_module = LookupModule()
    
    # Invoke run() of class LookupModule
    obj_lookup_module.run(terms='variablename')

# Generated at 2022-06-21 07:11:12.234337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for vars module'''
    lookup_module = LookupModule()
    lookup_module.set_options({u'default': None, u'_terms': [u'host']}, direct={u'inventory_hostname': u'host1'})
    result = lookup_module.run([u'host'])
    assert result[0] == u'host1'
    
    lookup_module.set_options({u'default': None, u'_terms': [u'host']}, direct={u'inventory_hostname': u'host1'})
    lookup_module._templar = {'inventory_hostname': u'host1'}
    result = lookup_module.run([u'host'])
    assert result[0] == u'host1'

# Generated at 2022-06-21 07:11:18.344331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert len(lm.run(["0", "1", "2"])) == 3
    assert lm.run(["0", "1", "2"]) == ["0", "1", "2"]

# Generated at 2022-06-21 07:11:23.274501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = ["ansible_play_hosts"]
    options = {'default': None}
    lookup_plugin.set_options(options)
    result = lookup_plugin.run(terms, variables={"ansible_play_hosts": ["192.168.0.1"]})
    assert result == ["192.168.0.1"]

# Generated at 2022-06-21 07:11:35.153510
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test run with a not existing variable
    lookup_module = LookupModule()
    assert lookup_module.run(
        ['ansible_play_hosts_all'],
        variables = {"inventory_hostname": "worker-01", "hostvars": {"worker-01": {"ansible_play_hosts": ["worker-01", "worker-02"]}}}
    ) == []

    # Test run for a normal case
    assert lookup_module.run(
        ['ansible_play_hosts'],
        variables = {"inventory_hostname": "worker-01", "hostvars": {"worker-01": {"ansible_play_hosts": ["worker-01", "worker-02"]}}}
    ) == [["worker-01", "worker-02"]]


# Generated at 2022-06-21 07:11:35.990089
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:11:39.215007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 07:11:41.341044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    myvars = {"test":"test"}
    lm.run(["test"], myvars)

# Generated at 2022-06-21 07:11:45.293197
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l_mod = LookupModule()
    print("Test creating variable.")
    terms = ['test']
    variables = {'test': 'hello'}
    l_mod.run(terms, variables)
    print("Sucessfully created variable.")

# Generated at 2022-06-21 07:11:56.305351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = [
        {'fail_on_undefined': True, 'variable_start_string': '{{', 'variable_end_string': '}}'},
        {'fail_on_undefined': False, 'variable_start_string': '{{', 'variable_end_string': '}}'},
        {'fail_on_undefined': True, 'variable_start_string': '{', 'variable_end_string': '}'},
        {'fail_on_undefined': False, 'variable_start_string': '{', 'variable_end_string': '}'}
    ]

# Generated at 2022-06-21 07:11:57.878166
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lmod = LookupModule()
    assert lmod is not None

# Generated at 2022-06-21 07:12:15.372495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["foo", "bar"]
    # FIXME: setup fixture to not require PyYAML
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    result = lookup_module.run(terms=terms)
    assert result == []

# Generated at 2022-06-21 07:12:18.204549
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 07:12:29.236259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Testing run method of LookupModule")
    obj = LookupModule()
    variable = {'test_variable': 'test'}
    variable_list = ['test_variable', 'test_variable1']
    kwarg = {'variable': variable}
    #test with proper variable
    try:
        result = obj.run(variable_list, **kwarg)
        print("Test for proper variable passed")
    except:
        print("Test for proper variable failed")
    #test with improper variable
    variable_list = ['test_variable2']
    try:
        result = obj.run(variable_list, **kwarg)
        print("Test for improper variable failed")
    except:
        print("Test for improper variable passed")

# Generated at 2022-06-21 07:12:32.312272
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()
    assert isinstance(mylookup, LookupModule)

# Generated at 2022-06-21 07:12:41.376883
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': ['localhost'], 'ansible_play_batch': 'b', 'ansible_play_hosts_all': 'c'}
    ret = LookupModule().run(terms = terms, variables = variables)
    assert ret == ['localhost', 'b', 'c']
    terms = ['variablenotename']
    default = ''
    ret = LookupModule().run(terms = terms, variables = variables, default = default)
    assert ret == ['']
    terms = ['variablenotename']
    ret = LookupModule().run(terms = terms, variables = variables)
    assert ret == [None]

# Generated at 2022-06-21 07:12:47.316573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule."""
    test_terms = 'test_term'
    test_variables = {'test_term': 'test_value'}
    look = LookupModule()
    assert look.run(test_terms, test_variables) == 'test_value'



# Generated at 2022-06-21 07:12:49.294552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.utils.plugins
    p = ansible.utils.plugins.lookup_loader.get('vars')
    assert hasattr(p,'run')


# Generated at 2022-06-21 07:12:51.250630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)


# Generated at 2022-06-21 07:13:02.232216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    lookup_module = LookupModule(loader=None, templar=templar, basedir=None)

    terms = ['var1']
    variables = {'var1': 'value1'}
    default = 'default'

    lookup_module.set_options(var_options=variables, direct={'default': default})
    templar._templar._available_variables = variables

    # Test
    ret = lookup_module.run(terms, variables)

    # Assert
    assert ret == ['value1']



# Generated at 2022-06-21 07:13:14.481551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # Simple test for vars with no default return
    lookup = LookupModule()

    # The templated dict in the test below is used to simulate
    # the contents of self._templar._available_variables
    # which is what the 'vars' lookup plugin uses for
    # retrieving variables.
    ret = lookup.run(terms=['ho'], variables={'ho': 'ge'})
    assert ret == ['ge']

    ret = lookup.run(terms=['ho'], variables={'ho': 'ge', 'bo': 'gies'})
    assert ret == ['ge']

    ret = lookup.run(terms=['nonsense', 'ho'], variables={'ho': 'ge', 'bo': 'gies'})
    assert ret == ['ge']


# Generated at 2022-06-21 07:13:52.810229
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    my_term1 = 'ansible_play_hosts'
    my_term2 = 'ansible_play_batch'
    my_term3 = 'ansible_play_hosts_all'
    terms = [my_term1,my_term2,my_term3]

    my_vars = {
        'inventory_hostname': 'server1',
        'ansible_play_hosts': ['server1','server2','server3'],
        'ansible_play_batch': [],
        'ansible_play_hosts_all': ['server1','server2','server3']
    }

    testobj = LookupModule()
    assert testobj.run(terms, my_vars) == [['server1','server2','server3'], [], ['server1','server2','server3']]

# Generated at 2022-06-21 07:14:01.972974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    # LookupModule(loader, variables=None, **kwargs)
    lookup = LookupModule(None, { 'ansible_play_hosts' : ['1.1.1.1', '2.2.2.2'] })
    # Act
    result = lookup.run(terms = ['ansible_play_hosts'], variables=None, **{})
    # Assert
    assert result == [['1.1.1.1', '2.2.2.2']]


# Generated at 2022-06-21 07:14:12.075201
# Unit test for constructor of class LookupModule

# Generated at 2022-06-21 07:14:19.213340
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test setting 'default' and 'default not set'
    l = LookupModule()
    l.set_options(var_options=None, direct={'default': 'not_set'})
    assert l.get_option('default') == 'not_set'

    l = LookupModule()
    l.set_options(var_options=None, direct={})
    assert l.get_option('default') is None

# Generated at 2022-06-21 07:14:30.671074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # case 1
    assert lookup.run([
        'foo'
    ], {
        'foo': 'bar'
    }) == ['bar']

    # case 2
    assert lookup.run([
        'foo'
    ], {
        'foo': 'bar',
        'var_name': 'foo'
    }) == ['bar']

    # case 3
    assert lookup.run([
        'var_name'
    ], {
        'foo': 'bar',
        'var_name': 'foo'
    }) == ['bar']

    # case 4

# Generated at 2022-06-21 07:14:40.533277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import mock
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestLookupModule(unittest.TestCase):
        ''' test LookupModule() '''

        def test_lookup_module(self):
            ''' test LookupModule '''

            # executing run() method
            lookup_module = LookupModule()
            assert hasattr(lookup_module, 'run')
            assert callable(lookup_module.run)

            # creating vars() object
            var_obj = {}
            assert hasattr(var_obj, 'run')

            # creating mock object for getattr()
            mock_getattr = mock.Mock()

# Generated at 2022-06-21 07:14:43.151159
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 07:14:47.197543
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()

# Generated at 2022-06-21 07:14:48.463323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert not lm._options

# Generated at 2022-06-21 07:14:52.792152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global lm
    lm = LookupModule()


# Generated at 2022-06-21 07:15:51.305738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Prepare test data
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'inventory_hostname': 'dummy', 
                 'hostvars': {'dummy': {'ansible_play_hosts': 'host1'}}}
    # Execute the run method
    ret = LookupModule().run(terms = terms, variables = variables)
    # Verify results
    assert ret == ['host1', None, None], \
        "LookupModule()_run() returned %r" % ret

# Generated at 2022-06-21 07:15:59.051969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the base object
    lm = LookupModule()
    # Create a temp object to pass as first parameter - no need to pass templar here.
    lm._templar = {}
    # Create the second parameter - no need to pass None here.
    variables = {}
    # Create the third parameter - no need to pass undefined
    terms = []
    # Create the forth parameter - no need to pass None here.
    undefined = ""

    # Create the test input list
    test1 = ['user','ansible_check_mode','ansible_loop_var','ansible_inventory_hostname','hostvars','group_names','inventory_hostname','inventory_hostname_short','inventory_file','inventory_file_short','inventory_dir','inventory_dir_short','playbook_dir']

# Generated at 2022-06-21 07:16:10.643322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class VarsLookupModule(LookupModule):

        def run(self, terms, variables=None, **kwargs):
            return super(VarsLookupModule, self).run(terms, variables, **kwargs)

    # test with valid variables
    variablename = "hello"
    myvar = "ename"
    valid_variables = {'variablename': variablename, 'myvar': myvar}
    l = VarsLookupModule()
    assert l.run(["variablename"], valid_variables) == [variablename]
    l = VarsLookupModule()
    assert l.run(["variablename", "myvar"], valid_variables) == [variablename, myvar]
    l = VarsLookupModule()

# Generated at 2022-06-21 07:16:21.596730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import pytest

    # test variable already present
    mm = LookupModule(None)
    mm._templar._available_variables = {
        "username":"mm",
        "hostvars": {
            "localhost": {
                "ansible_connection": "local"
            }
        },
        "inventory_hostname": "localhost"
    }

    out = mm.run(["username"])
    assert out == ["mm"]

    # test variable available through hostvars
    out = mm.run(["ansible_connection"])
    assert out == ["local"]

    # test default value
    out = mm.run(["non-existant", "username"], default="default")
    assert out == ["default", "mm"]

    # test no default value

# Generated at 2022-06-21 07:16:32.911620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=protected-access
    # see https://github.com/PyCQA/pylint/issues/2747
    my_lookup = LookupModule()
    my_lookup._templar = AnsibleUndefinedVariable('No variables found')
    my_lookup._templar._available_variables = dict(
        term1='term1_value',
        term2='term2_value'
    )
    terms = list(my_lookup._templar._available_variables.keys())
    assert my_lookup.run(terms) == my_lookup._templar._available_variables.values()
    my_lookup.set_options(default='default_value')
    assert my_lookup.run(['term3']) == ['default_value']

# Generated at 2022-06-21 07:16:41.601950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.set_options(direct={'var1': 'test'})
    lm._templar.available_variables = {'var1': 'test'}
    ret1 = lm.run(['var1'])
    lm.set_options(direct={'var1': 'test'})
    lm._templar.available_variables = {'var1': 'test'}
    ret2 = lm.run(['var1', 'var2'], {'var1': 'test', 'var2': 'test2'})
    assert ret1 == ['test']
    assert ret2 == ['test', 'test2']

# Generated at 2022-06-21 07:16:49.815879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeTemplar(object):
        vars = {'myvar': 12, 'hostvars': {'127.0.0.1': {'hostvar': 34}}}

        def __init__(self):
            self._available_variables = self.vars

        def template(self, value, fail_on_undefined=False):
            return value

    class FakeLookupModule(LookupModule):
        def __init__(self):
            self._templar = FakeTemplar()

    class FakeRunner(object):
        def __init__(self):
            self._valid_attrs = {'no_log': False, 'run_once': True}
        def __getitem__(self, attr):
            return self._valid_attrs[attr]

    lookup = FakeLookupModule()

    #

# Generated at 2022-06-21 07:16:51.586316
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupModule)


# Generated at 2022-06-21 07:16:53.317033
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None

# Generated at 2022-06-21 07:17:01.047929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    terms = ['ansible_play_hosts']
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms) == [["abcd.com", "wxyz.com"]], "Should return the value of ansible_play_hosts"

    # Test 2
    terms = ['ansible_play_batch', 'ansible_play_hosts_all']
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms) == [[1, 2], ["abcd.com", "wxyz.com"]], "Should return the value of ansible_play_batch and ansible_play_hosts_all"
