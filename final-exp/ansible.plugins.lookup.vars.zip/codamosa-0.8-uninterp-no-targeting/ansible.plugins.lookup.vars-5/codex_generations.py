

# Generated at 2022-06-21 07:08:51.872130
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 07:08:53.293602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 07:09:03.099184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #import os
    #print(os.path.abspath(__file__))
    #exit(1)
    lm = LookupModule()
    terms = ['foo', 'bar'] #str

# Generated at 2022-06-21 07:09:05.771984
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 07:09:08.077571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    terms = 'variablename'
    variables = {'variablename': 'hello'}
    result = lookup_module_obj.run(terms, variables)
    assert(result[0] == 'hello')


# Generated at 2022-06-21 07:09:14.198433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    LookupModule.get_option = lambda x, y: x.options.get(y) if x.options else None

    options = {'_ansible_verbose_always': True, '_ansible_version': (2, 9, 0)}
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:09:19.854958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar._available_variables = {'ansible_play_hosts': ['10.10.10.1'], 'ansible_play_batch': [['10.10.10.1']], 'ansible_play_hosts_all': ['10.10.10.1'] }
    result = lookup.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])
    assert result == [['10.10.10.1'], [['10.10.10.1']], ['10.10.10.1']]

# Generated at 2022-06-21 07:09:31.178489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import string_types
    lm = LookupModule()
    terms = 'variablename'
    variables = {'variablename': 'hello'}
    default = None
    assert lm.run([terms], variables, default=default) == ['hello']

    terms = 'variablename'
    variables = {'variablename1': 'hello'}
    default = None
    try:
        lm.run([terms], variables, default)
    except AnsibleUndefinedVariable:
        pass

    terms = 'variablename'
    variables = {'variablename1': 'hello'}
    default = ''
    assert lm.run([terms], variables, default) == ['']

    terms = 'variablename'

# Generated at 2022-06-21 07:09:38.530100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameters
    terms = ['name']

    # Defining a variable
    variables = {'name': 'Ansible'}

    # Run the code to be tested
    ret = LookupModule.run(terms, variables)

    # Verify that the expected results are returned
    assert ret == ['Ansible']


# Generated at 2022-06-21 07:09:39.255161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 07:09:51.078508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    vars = {
        'vi': 'ro',
        'wadus': {
            'ping': 'pong',
            'other': 'value',
        },
    }

    # Basic variable
    assert ['ro'] == LookupModule().run(['vi'], variables=vars)
    assert ['ro'] == LookupModule().run(['vi'], variables=vars)
    assert ['pong'] == LookupModule().run(['wadus.ping'], variables=vars)

# Generated at 2022-06-21 07:09:53.579322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # GIVEN
    # WHEN
    # THEN
    pass

# Generated at 2022-06-21 07:10:02.313791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3


# Generated at 2022-06-21 07:10:13.665542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l._templar = None
    l._templar._available_variables = {'hostvars': {'somehost': {'var1': '', 'var2': '', 'var3': '', 'var4': ''}}, 'var1': '', 'var2': '', 'var3': '', 'var4': ''}
    l._templar._available_variables['hostvars']['somehost']['var1'] = '1'
    l._templar._available_variables['hostvars']['somehost']['var2'] = '2'
    l._templar._available_variables['hostvars']['somehost']['var3'] = '3'

# Generated at 2022-06-21 07:10:23.883171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    terms_undefined = ['ansible_play_undefined']
    variables = {'ansible_play_hosts': ['192.168.1.1'], 'ansible_play_batch': ['192.168.1.2'], 'ansible_play_hosts_all': ['192.168.1.3']}

    l = LookupModule()
    l.set_options(var_options=variables)
    ret = l.run(terms=terms)

    assert ret == [['192.168.1.1'], ['192.168.1.2'], ['192.168.1.3']]
    assert len(ret) == 3
    assert len(ret[0])

# Generated at 2022-06-21 07:10:36.457351
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_plugin = LookupModule(templar=None)

    class myvars:
        def __init__(self, my_vars):
            self.my_vars = my_vars
        def __getitem__(self, varname):
            return self.my_vars[varname]

    my_vars = myvars({'myvar': 'hello'})

    terms = ['myvar']
    assert lookup_plugin.run(terms=terms, variables=my_vars) == ['hello']
    assert lookup_plugin.run(terms=[], variables=my_vars) == []


# Generated at 2022-06-21 07:10:40.763336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #TODO: This module is quite difficult to unit test because of the access to _templar.
    #      A valid approach might be to mock _templar, but doing so seems to require a
    #      significant refactor.
    pass

# Generated at 2022-06-21 07:10:43.136421
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-21 07:10:47.321941
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testobj = LookupModule()
    assert testobj is not None
    assert isinstance(testobj, LookupModule)
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 07:10:59.562515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert [u'localhost'] == lookup_plugin.run(['hostvars[inventory_hostname].ansible_play_hosts'], variables={u'hostvars': {u'localhost': {u'ansible_play_hosts': [u'localhost']}}, u'inventory_hostname': u'localhost'})
    assert [u'localhost'] == lookup_plugin.run(['ansible_play_hosts'], variables={u'inventory_hostname': u'localhost', u'ansible_play_hosts': [u'localhost']})
    assert [u'localhost'] == lookup_plugin.run(['ansible_play_' + item], variables={u'inventory_hostname': u'localhost', u'ansible_play_hosts': [u'localhost']})


# Unit test

# Generated at 2022-06-21 07:11:12.733353
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'ansible_play_hosts': ['localhost'], 'ansible_play_batch': ['localhost']}
    variable_manager._extra_vars = {'myvar': 'ename'}
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    play_context = Play()
    variable_manager.set_play_context(play_context)

    lookups = LookupModule()
    lookups._templar.available

# Generated at 2022-06-21 07:11:25.283783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.set_options(direct={'_original_file': '/a/b/c', '_original_module': 'd'})

    myvars = {}
    assert mod.run(terms=['myvar'], variables=myvars) == [], "dflt, normal"
    assert mod.run(terms=['myvar'], variables=myvars, default='a') == ['a'], "dflt, normal"
    myvars['myvar'] = 'a'
    assert mod.run(terms=['myvar'], variables=myvars) == ['a'], "dflt, normal"
    assert mod.run(terms=['myvar'], variables=myvars, default='a') == ['a'], "dflt, normal"

# Generated at 2022-06-21 07:11:31.057760
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)

    inventory.add_host('my_hostname')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 07:11:43.135741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert ['a'] == module.run(['a'], variables={'a': 'a'})
    assert ['a'] == module.run(['a'], variables={'hostvars': {'host1': {'a': 'a'}}, 'inventory_hostname': 'host1'})
    assert ['b'] == module.run(['a', 'b'], variables={'a': 'a', 'b': 'b'})
    assert ['b'] == module.run(['a', 'b'], variables={'hostvars': {'host1': {'a': 'a', 'b': 'b'}}, 'inventory_hostname': 'host1'})

# Generated at 2022-06-21 07:11:52.513639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test constructor of LookupModule.
    """
    x = LookupModule()
    assert x, 'Fail: instantiation of LookupModule failed.'
    assert x.get_option('default') is None, 'Fail: default option is not None.'
    assert x.set_options(var_options=None, direct=None), 'Fail: set_options returned False.'
    assert x.run(terms=['abc']), 'Fail: run returned False.'

# Generated at 2022-06-21 07:12:00.137143
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:12:09.224085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __builtin__ as builtins
    import ansible.utils.unsafe_proxy as unsafe_proxy

    lu = LookupModule()
    terms = ('ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all')
    variables = {
        'ansible_play_hosts': 'all',
        'ansible_play_batch': [ 'localhost' ],
        'ansible_play_hosts_all': 'all',
    }
    result = lu.run(terms, variables)
    assert result == ['all', ['localhost'], 'all']

    terms = terms[:-1]
    result = lu.run(terms, variables)
    assert result == ['all', ['localhost']]

    variables['ansible_play_batch'] = 'localhost'
    result

# Generated at 2022-06-21 07:12:09.793877
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 07:12:19.443824
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader()

    if lookup.run(["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"], {"ansible_play_hosts": ["server1"], "ansible_play_batch": [1, 2], "ansible_play_hosts_all": ["server1", "server2"]}) != ["server1", [1, 2], ["server1", "server2"]]:
        raise Exception("The test case failed")


# Generated at 2022-06-21 07:12:31.603883
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # raise an error
    lookup_module_obj = LookupModule()
    lookup_module_obj._templar._available_variables = {'nested_var': {'ansible_facts': 'facts'}}
    lookup_module_obj.run(['nested_var.ansible_facts'], {'inventory_hostname': 'host'}, default='default')
    assert lookup_module_obj._templar.template('nested_var.ansible_facts', fail_on_undefined=True) == 'facts'

    # return default value
    lookup_module_obj = LookupModule()
    lookup_module_obj._templar._available_variables = {'nested_var': {'ansible_facts': 'facts'}}

# Generated at 2022-06-21 07:12:47.107474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run

# Generated at 2022-06-21 07:12:48.294029
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass


# Generated at 2022-06-21 07:12:50.253764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.get_option('default') == None

# Generated at 2022-06-21 07:12:58.006925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        import ansible
        from ansible.plugins.lookup import LookupModule
    except ImportError as e:
        print('Failed to import ansible: %s' % e)
        return 1

    lookup_module = LookupModule()
    assert lookup_module is not None
    return 0


# Generated at 2022-06-21 07:13:05.838835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    import pytest
    import ansible.plugins.loader
    import ansible.errors
    import ansible.module_utils.basic

    target_dir = 'my_test_dir'

    # Since we are manipulating the ENVIRONMENT,
    # let's save this and clean it up when done.
    old_environ = os.environ

    # Imports for this test.
    from ansible.plugins.lookup.vars import LookupModule

    # Set up a logger for this unit test
    ansible.plugins.loader._logger = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
    ).logger
    # Create an instance of our lookup module
    lookup_instance = LookupModule()

    # build fake environment
    os.environ

# Generated at 2022-06-21 07:13:12.761931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    from ansible.plugins.lookup.vars import LookupModule
    lookup = LookupModule(None)
    assert lookup != None
    assert isinstance(lookup, object)
    assert isinstance(lookup, LookupModule)
    assert isinstance(lookup._templar, object)
    assert lookup._templar != None
    assert isinstance(lookup._loader, object)
    assert lookup._loader != None

# Generated at 2022-06-21 07:13:15.939812
# Unit test for constructor of class LookupModule
def test_LookupModule():
	if LookupModule() is not None:
		print("Success")
		exit(0)
	else:
		print("Failure")
		exit(1)


# Generated at 2022-06-21 07:13:22.862285
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test setup to make sure that LookupModule has a clean state
    ls = LookupModule()
    ls._templar._available_variables = None
    
    # Test that the constructor sets _templar._available_variables to a dictionary
    ls = LookupModule()
    assert (type(ls._templar._available_variables) is dict)

    # Setting variables to a "clean" dictionary and test if the constructor
    # sets it correctly
    ls._templar._available_variables = {}
    ls = LookupModule()
    assert(ls._templar._available_variables == {})
    # Set variables to a dictionary and make sure it stays that way
    ls._templar._available_variables = {'test': False}
    ls = LookupModule()

# Generated at 2022-06-21 07:13:33.520004
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    # Unit test for method run.
    # test for invalid input
    with pytest.raises(AnsibleError) as excinfo:
        module.run(
            [
                3
            ]
        )
    # test for valid input return type
    assert isinstance(module.run(
        [
            'ansible_play_hosts'
        ]
    ), list)
    # test for valid input return elements
    assert isinstance(
        module.run(
            [
                'ansible_play_hosts'
            ]
        )[0], string_types
    )

# Generated at 2022-06-21 07:13:38.132589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term1 = "variablename"
    term2 = "myvar"
    myvars1 = {"variablename":"hello"}
    myvars2 = {"variablename":"hello", "myvar":"ename"}
    myvars3 = {"inventory_hostname":"server1", "hostvars":{"server1":{"variablename":"hello"}}}
    myvars4 = {"inventory_hostname":"server1", "hostvars":{"server1":{"variablename":"hello"}}}
    myvars5 = {"inventory_hostname":"server1", "hostvars":{"server1":{"variablename":"hello"}}}

    terms = [term1, term2]
    terms1 = [term1]
    terms2 = [term2]

    #Test for fail_on_undefined == True
    #Test for different

# Generated at 2022-06-21 07:14:13.137525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError

    verify_string = "Invalid setting identifier"
    verify_error = "not a string"

    try:
        LookupModule(None, "")
    except AnsibleError as e:
        assert(isinstance(e, AnsibleError))
        assert(str(e).startswith(verify_string))
        assert(str(e).endswith(verify_error))

    try:
        LookupModule(None, "", "", "", "")
    except AnsibleError as e:
        assert(isinstance(e, AnsibleError))
        assert(str(e).startswith(verify_string))

# Generated at 2022-06-21 07:14:16.296681
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-21 07:14:21.452748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    VARS = {
        'inventory_hostname': '127.0.0.1'
    }
    lm = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    lm._lookup_plugin_check_mode(direct={'a': None})
    lm._templar.set_available_variables(VARS)
    assert lm._templar.available_variables == VARS

# Generated at 2022-06-21 07:14:31.463919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = LookupModule()

    terms = ('var1', 'var2')
    variables = {
        'var1': 1,
        'var2': 3.14,
    }

    assert r.run(terms, variables) == [1, 3.14], 'test 1'
    assert r.run(terms, variables, default='') == [1, 3.14], 'test 2'
    assert r.run(terms, variables, default='default') == [1, 3.14], 'test 3'

    assert r.run(("'var1'"), variables) == ["'var1'"], 'test 4'
    assert r.run(("'var1'"), variables, default='') == ["'var1'"], 'test 5'

# Generated at 2022-06-21 07:14:41.462666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    l = LookupModule()

    # Method run
    result = l.run(terms=['terms_1'], variables=variables, default=default)
    assert result == ['value_1']

    result = l.run(terms=['terms_2'], variables=variables, default=default)
    assert result == ['value_2']

    result = l.run(terms=['terms_3'], variables=variables, default=default)
    assert result == ['value_3']

    result = l.run(terms=['terms_4'], variables=variables, default=default)
    assert result == [default]

# Create variables for unit test

# Generated at 2022-06-21 07:14:43.871043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-21 07:14:47.613148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['hello']
    variables = {'hello': 'world'}
    assert module.run(terms, variables=variables) == ['world']

# Generated at 2022-06-21 07:14:53.699777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'],
                        {'ansible_play_hosts': ['host1', 'host2'],
                         'ansible_play_batch': ['batch1', 'batch2'],
                         'ansible_play_hosts_all': ['all1'],
                         'inventory_hostname': 'my_host'})
    assert result == [['host1', 'host2'], ['batch1', 'batch2'], ['all1']]

# Generated at 2022-06-21 07:15:00.398492
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.plugins.lookup.vars import LookupModule
    lookup_module = LookupModule()

    assert lookup_module._templar is not None, "Templar is none"
    assert hasattr(lookup_module,'_templar'), "Templar is none"


# Generated at 2022-06-21 07:15:02.224717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert LookupModule.run

# Generated at 2022-06-21 07:16:10.504043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['testkey', 'testkey1'], variables={'testkey': 1, 'testkey1': 2})
    assert result == [1, 2]

    result = LookupModule().run(['testkey1', 'testkey'], variables={'testkey': 1, 'testkey1': 2})
    assert result == [2, 1]

    result = LookupModule().run(['testkey'], variables={'testkey': 1, 'testkey1': 2}, default="not set")
    assert result == [1]

    result = LookupModule().run(['notset'], variables={'testkey': 1, 'testkey1': 2}, default="not set")
    assert result == ['not set']


# Generated at 2022-06-21 07:16:14.131373
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)
    assert hasattr(lookup, 'run')
    assert hasattr(lookup, 'run')

# Generated at 2022-06-21 07:16:27.207853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(terms = ["test1", "test2"], variables = {"test1":"value1", "test2":"value2"}, fail_on_undefined=True) == ["value1", "value2"]
    assert LookupModule.run(terms = ["test1", "test2"], variables = {"test1":"value1"}, fail_on_undefined=True) == ["value1", None]
    assert LookupModule.run(terms = ["test1", "test2"], variables = {"test1":"value1"}, fail_on_undefined=False) == ["value1", None]
    assert LookupModule.run(terms = ["test1", "test2"], variables = {"test1":"value1"}, fail_on_undefined=False, default="default_value") == ["value1", "default_value"]
    assert LookupModule

# Generated at 2022-06-21 07:16:39.438574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os
    import collections
    import pytest

    xmldir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../xmldata')

    # load in empty vars from the top level
    inv_info = collections.defaultdict(dict)
    inv_info['all'] = collections.defaultdict(dict)
    inv_info['all']['vars'] = collections.defaultdict(dict)
    inv_info['all']['hosts'] = collections.defaultdict(dict)

    # hack it so that the inventory thinks it is being run via the CLI
    inv_info['_ansible_verbosity'] = 2
    inv_info['_ansible_syslog_facility'] = 'LOG_USER'


# Generated at 2022-06-21 07:16:43.177782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert "LookupModule" not in globals()
    res = LookupModule()
    assert isinstance(res, LookupModule)
    assert "LookupModule" in globals()

# Generated at 2022-06-21 07:16:46.639242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(direct=True)
    assert lookup.get_option('direct') == True
    lookup.set_options(var_options=True)
    assert lookup.get_option('var_options') == True

# Generated at 2022-06-21 07:16:48.938741
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 07:17:00.526141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    assert lm.run([None]) == [""]
    assert lm.run(["not_found"]) == [""]
    assert lm.run(["not_found_1", "not_found_2"]) == ["", ""]
    assert lm.run(["not_found"], default="default") == ["default"]
    assert lm.run(["not_found_1", "not_found_2"], default="default") == ["default", "default"]

    assert lm.run([None], variables={"none_var": None}) == [None]
    assert lm.run([None], variables={"none_var": None}, default="default") == ["default"]

    assert lm.run(["none_var"], variables={"none_var": None}) == [None]

# Generated at 2022-06-21 07:17:03.498687
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # FIXME: Rewrite this test
    assert 0 == 1

# Generated at 2022-06-21 07:17:18.076906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.module_utils.six import string_types

    # Test terms not a string
    terms = [1,2,3]
    obj = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        obj.run(terms)
    assert 'Invalid setting identifier' in str(excinfo.value)

    # Verify that AnsibleUndefinedVariable is thrown if variable is not found and default is not set
    term = "test_var"
    variables = {"not_test_var": "test_value"}
    obj = LookupModule()
    obj.set_options(var_options=variables)