

# Generated at 2022-06-21 07:09:00.773814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeLookupModule:
        def __init__(self, d={'hostvars': {'fake-inventory_hostname': {'term2': 'value2', 'var2': 'value2'}, 'fake-inventory_hostname-1': {'var3': 'value3'}}, 'var1': 'value1', 'ANSIBLE_VAR1': 'value1'}):
            self._templar = FakeTemplar(d)

        def set_options(self, var_options=None, direct=None):
            self.var_options = var_options
            self.direct = direct
        
        def get_option(self, var_name):
            return self.direct[var_name]
        

# Generated at 2022-06-21 07:09:03.546356
# Unit test for constructor of class LookupModule
def test_LookupModule():
    res = LookupModule()
    assert isinstance(res, LookupModule)


# Generated at 2022-06-21 07:09:06.170768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()

# Unit test: Check if AnsibleError is raised when term is not a string type

# Generated at 2022-06-21 07:09:11.475404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_text

    t = get_lookup_plugin(LookupModule)

    stdout = cStringIO() if PY3 else cStringIO.StringIO()
    t.run(["foo"], **{'stdout': stdout, '_ansible_check_mode': False})
    assert to_text(stdout.getvalue()) == 'undefined\n'

# Generated at 2022-06-21 07:09:22.585517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms
    import json
    lookup_ins = LookupModule()

    # tests empty input
    results = lookup_ins.run([], {})
    assert results == []

    # tests undefined variable
    terms = listify_lookup_plugin_terms(['undefined'], templar=Templar(), loader=None, fail_on_undefined=False)
    results = lookup_ins.run(terms, {})
    assert results == []

    # tests defined variable

# Generated at 2022-06-21 07:09:32.000231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types

    # Creating up empty instance of LookupBase class
    lookupBase = LookupBase()
    # Creating up empty instance of LookupModule class
    lookupModule = LookupModule()

    # test with empty terms param
    terms = []
    try:
        lookupModule.run(terms=terms)
    except AnsibleError as e:
        assert repr(e) == repr('"terms" is required')

    # test with terms param which is not string
    terms = [123, 456]

# Generated at 2022-06-21 07:09:37.597254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    # Constructor should initialize the _templar with Jinja2Template
    assert obj._templar is not None

# Generated at 2022-06-21 07:09:44.718744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    test_LookupModule has been added for the purpose of testing the
    get_option() and set_options() method of class LookupModule
    '''
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import cStringIO as stringio
    stream = stringio()

    lm = LookupModule()
    mock_variables = {'roses': 'red', 'violets': 'blue'}
    mock_kwargs = {'direct': {'roses': 'other_red'}}

    lm._display.display(msg='cool stuff', verbosity=3, color='yellow', stderr=True, screen_only=True, log_only=False)

# Generated at 2022-06-21 07:09:46.787876
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert hasattr(l, 'run')

# Generated at 2022-06-21 07:09:54.822149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Note: There are many more combinations of types and inputs to test, but this is a good start.
    from ansible.errors import AnsibleError
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types

    # Create a fake class for this test.
    class FakeLookupModule(LookupBase):
        def __init__(self):
            # Create a fake dictionary for the lookup items.
            self._templar = {
                '_available_variables': {
                    'hostvars': {
                        'inventory_hostname': {
                            'variable': 'test'
                        }
                    }
                }
            }

        def run(self, terms, variables=None, **kwargs):
            return terms

    # Create a fake class for the exception.

# Generated at 2022-06-21 07:10:00.679685
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 07:10:12.537052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cls = LookupModule()
    import os
    path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-21 07:10:23.602561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    variables = {'test_variable': 'variable value',
                 'hostvars': {'hostname': {'host_variable': 'host_variable value'}}}
    terms = ['test_variable', 'hostvars', 'host_variable']
    result = lookup.run(terms, variables)
    assert result is not None
    assert len(result) == 3
    assert result[0] == 'variable value'
    assert result[1] == {}
    assert result[2] == 'host_variable value'

# Generated at 2022-06-21 07:10:33.949561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    items = ("ansible_play_batch", "ansible_play_hosts_all", "ansible_play_hosts")
    # Define some variables
    variables = {
        "ansible_play_batch": "ansible_play_batch",
        "ansible_play_hosts_all": "ansible_play_hosts_all",
        "ansible_play_hosts": "ansible_play_hosts"
    }
    # Call the method
    ret = lookup_obj.run(items, variables=variables)

    assert ret == list(variables.values())

# Generated at 2022-06-21 07:10:36.760633
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_LookupModule = LookupModule()
    return test_LookupModule



# Generated at 2022-06-21 07:10:45.830837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing method run of class LookupModule')
    terms = ["{{ lookup('vars','', 'default=fail') }}"]
    variables = {}
    assert 'fail' == LookupModule().run(terms, variables)

    terms = ["{{ lookup('vars','test_var', 'default=fail') }}"]
    variables = {}
    assert 'fail' == LookupModule().run(terms, variables)

    terms = ["{{ lookup('vars','test_var', 'default=fail') }}"]
    variables = {'test_var': {'host1': 'host1_value'}}
    assert 'host1_value' == LookupModule().run(terms, variables)

    terms = ["test_var"]
    variables = {}
    assert AnsibleError == type(LookupModule().run(terms, variables))


# Generated at 2022-06-21 07:10:57.869700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test that the class can be instantiated and that the methods can be called """

    # Prepare test environment
    # Note: For future test cases we need to prepare the following stuff
    # - mock templar object (maybe we can use the real object here, but we should mock the rendering)
    # - mock _load_name method of templar object
    # - setup the _available_variable of the templar object
    # - put the LookupModule.run method into a try/except block

    # prepare LookupBase object
    temp_object = LookupBase()

    # prepare templar/environment object
    # we need to mock the _load_name method of the templar (for further tests)
    # we need to set the _available_variables of the templar
    # we need to put the lookup.run method into a try

# Generated at 2022-06-21 07:11:11.277231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()
    lookup_mock._templar._available_variables = {'ansible_play_hosts': ['myinventory'],
                                                  'ansible_play_batch': [],
                                                  'ansible_play_hosts_all': [],
                                                  'ansible_play_batch': [],
                                                  'inventory_hostname': 'myinventory'}
    lookup_mock.set_options(var_options=lookup_mock._templar._available_variables, direct={})
    lookup_mock.get_option = lambda x: None
    terms = ['ansible_play_' + item for item in ['hosts', 'batch', 'hosts_all']]

# Generated at 2022-06-21 07:11:16.709255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_name = "ansible.plugins.lookup.vars"
    module = __import__(module_name, fromlist=["object"])
    lookupModule = module.LookupModule()
    assert lookupModule != None

# Generated at 2022-06-21 07:11:24.921945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ['one', 'two']
    variables = {'one': "1", 'two': 2, 'three': 3, 'hostvars': {'host1': {'one': 1, 'two': 2, 'three': 3}}}
    assert [u'1', 2] == lookup_module.run(terms, variables=variables)

    terms = ['one', 'two', 'three']
    variables = {'one': "1", 'two': 2, 'three': 3, 'hostvars': {'host1': {'one': 1, 'two': 2, 'three': 3}}}
    assert [u'1', 2, 3] == lookup_module.run(terms, variables=variables)

    terms = ['one', 'two', 'three']

# Generated at 2022-06-21 07:11:34.090379
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__class__.__dict__) == 0

# Generated at 2022-06-21 07:11:43.005628
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Initialize LookupModule
    lookup_module = LookupModule()

    # Default return value
    assert lookup_module.run(['test']) == []

    # Define a custom return value
    myvar = {}
    myvar['variablename'] = 'hello'
    myvar['myvar'] = 'ename'
    myvar['variables'] = myvar

    assert lookup_module.run(['variablename'], None, **myvar) == ['hello']

# Generated at 2022-06-21 07:11:55.775348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create the LookupModule object for testing
    lookup_module = LookupModule()

    # create the arguments for testing
    terms = [ "ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all" ]
    variables = {
        "ansible_play_hosts": [ "localhost" ],
        "ansible_play_batch": [ "localhost" ],
        "ansible_play_hosts_all": [ [ "localhost" ] ],
        "hostvars": {
            "localhost": { "ansible_play_hosts": [ "localhost" ] }
        }
    }

    # run method run of class LookupModule for testing
    result = lookup_module.run(terms=terms, variables=variables)

    # the result should be a list of three elements
   

# Generated at 2022-06-21 07:11:58.177806
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance to use methods
    _lookup_module_instance = LookupModule()
    assert isinstance(_lookup_module_instance, LookupModule)

#Unit test for run() of class LookupModule

# Generated at 2022-06-21 07:11:59.216533
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 07:12:00.816479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # verify constructor of class LookupModule
    lookup_module = LookupModule()
    assert isinstance(lookup_module, object)

# Generated at 2022-06-21 07:12:06.699547
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()

    lm = LookupModule(loader=loader,
                      variable_manager=variable_manager,
                      play_context=play_context)

    print(lm._templar)

# Generated at 2022-06-21 07:12:14.665813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    my_dict = {}
    my_lookup.set_options(var_options = my_dict)
    my_lookup._templar._available_variables =  {'inventory_hostname': 'First_Node', 'hostvars': {'First_Node': {'foo': 'bar'}}}
    result = my_lookup.run(['foo'])
    assert result[0] == 'bar'

# Generated at 2022-06-21 07:12:28.440722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    try:
        l.run([])
        assert False
    except Exception:
        assert True

    assert l.run([''], {"myvar": 12}) == [12]

    try:
        l.run([''], {"myvars": {}})
        assert False
    except Exception:
        assert True

    try:
        l.run([''], {"myvars": 12})
        assert False
    except Exception:
        assert True

    try:
        l.run(12, {"myvars": 12})
        assert False
    except Exception:
        assert True

    try:
        l.run([''], {"myvars": {"inventory_hostname": "", "hostvars": {}}})
        assert False
    except Exception:
        assert True

# Generated at 2022-06-21 07:12:39.795325
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.plugins.lookup import LookupBase

    # Base class for self._templar object
    class Test_templar(object):

        # Test available_variables method
        def __init__(self, available_variables):
            self.available_variables = available_variables

        # Test template method
        def template(self, value, fail_on_undefined=True):
            return value

    # Test set_option method
    def Test_set_options(self, var_options, direct):
        self.options = direct

    # Test get_option method
    def Test_get_option(self, key):
        return self.options.get(key)

    # Test run method

# Generated at 2022-06-21 07:13:01.284969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    assert lookup_obj._templar._available_variables == None
    assert lookup_obj._loader == None
    assert lookup_obj._templar._available_variables == None
    assert lookup_obj.get_option('default') == None
    assert lookup_obj._display.display(None) == None
    assert lookup_obj.set_options(var_options = None, direct = None) == None


# Generated at 2022-06-21 07:13:06.714600
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test for constructor of class LookupModule.
    """
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()


    lm = LookupModule(None, dl, None)

# Generated at 2022-06-21 07:13:15.948953
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    variablename = 'Ansible'
    myvar = 'lookup_'
    variablenotename = ''
    variablenotename = 'Ansible'
    iterable = ['hosts', 'batch', 'hosts_all']

    test_object = LookupModule()
    test_object._templar = templar
    results = test_object.run(['lookup_'+myvar])
    assert results == [variablename]

    test_object = LookupModule()
    test_object._templar = templar

# Generated at 2022-06-21 07:13:22.862588
# Unit test for method run of class LookupModule
def test_LookupModule_run():

	# get empty LookupModule
    lookupModule = LookupModule()

    # create test variables
    test_variables = {}
    test_variables['test_variable'] = 'test_value'
    test_variables['hostvars'] = {}
    test_variables['hostvars']['test_hostname'] = {}
    test_variables['hostvars']['test_hostname']['host_test_variable'] = 'host_test_value'
    test_variables['inventory_hostname'] = 'test_hostname'

    # retrieve test data
    retrieved_value = lookupModule.run(['test_variable'], test_variables)
    retrieved_value = lookupModule.run(['host_test_variable'], test_variables)

# Generated at 2022-06-21 07:13:35.170604
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test setup

    test_target = 'target'
    test_args = [{'term': 'var1', 'expected': 'var1_value'}, {'term': 'var2', 'expected': 'myhostvar2_value'}, {'term': 'var3', 'expected': 'thishostvar3_value'}]
    test_terms = [test_args[0]['term'], test_args[1]['term'], test_args[2]['term']]

# Generated at 2022-06-21 07:13:36.776141
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:13:46.834207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test import
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Test vars
    options = None
    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    inventory = InventoryManager(loader=loader, sources=['/path/to/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:13:59.652221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Default argument
    module = LookupModule()
    terms = ['example']
    variables = {'example': 'foo'}
    result = module.run(terms, variables)

    # Should return ['foo']
    assert result == ['foo']

    # First term does not exist
    module = LookupModule()
    terms = ['example1', 'example2']
    variables = {'example2': 'foo'}
    result = module.run(terms, variables)

    # Should return ['foo']
    assert result == ['foo']

    # Second term does not exist
    module = LookupModule()
    terms = ['example1', 'example2']
    variables = {'example1': 'foo'}
    result = module.run(terms, variables)

    # Should return ['foo']
    assert result == ['foo']

# Generated at 2022-06-21 07:14:10.793370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input data
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {'ansible_play_hosts': 'localhost', 'ansible_play_batch': 'some batch'}

    # Code to execute
    # Instantiation of the class to be tested
    lookup_module = LookupModule()

    # Invocation of the method to be tested
    # TODO: Change this call to data-driven test
    result = lookup_module.run(terms, variables)

    # Visible results
    expected_result = ['localhost', 'some batch', []]
    assert result == expected_result, 'Expected: %s, Actual: %s' % (expected_result, result)

# Generated at 2022-06-21 07:14:12.954467
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import unittest

    class Test_lookup_module(unittest.TestCase):
        def setUp(self):
            self.lookupmodule = LookupModule()

    if sys.version_info.major == 2:
        unittest.main()

# Generated at 2022-06-21 07:14:51.990210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_run(self, terms, variables=None, **kwargs):
        ret = []

        for term in terms:
            if term == 'AnsibleUndefinedVariable':
                raise AnsibleUndefinedVariable
            elif term == 'AnsibleError':
                raise AnsibleError

            ret.append(self.get_option(term))

        return ret

    lookup_module = LookupModule()
    lookup_module.get_option = lambda x: x

    lookup_module.run = mock_run

    assert lookup_module.run(terms=['a', 'b', 'c'], variables={'a':'A', 'b': 'B', 'c': 'C'}) == ['a', 'b', 'c']

# Generated at 2022-06-21 07:14:53.275890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-21 07:14:55.719212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 07:14:58.944571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup_module = LookupModule()
    except Exception as e:
        print('Exception in test_LookupModule', str(e))

# Generated at 2022-06-21 07:15:04.560367
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test case with empty kwargs
    kwargs = {}
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options=None, direct=kwargs)
    assert lookup_obj.get_option('default') == None
    # Test kwargs with default
    kwargs = {'default': '1234', 'some_other': '1234'}
    lookup_obj = LookupModule()
    lookup_obj.set_options(var_options=None, direct=kwargs)
    assert lookup_obj.get_option('default') == '1234'


# Generated at 2022-06-21 07:15:11.605542
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #_templar = AnsibleTemplate()
    #_loader = AnsibleLoader()
    #l = LookupModule(_loader, templar=_templar)
    return 0

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 07:15:24.252784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # define some variables
    variablename   = "hello"
    myvar          = "ename"
    variablenotname= "hello"
    notename       = "notename"
    variablenotename= "hello"
    sub_var        = 12
    loop_items     = ["hosts", "batch", "hosts_all"]

    ansible_play_hosts      = "test1"
    ansible_play_batch      = "test2"
    ansible_play_hosts_all  = "test3"

    inventory_hostname = 'test_name'

# Generated at 2022-06-21 07:15:26.329963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None, None, None)

# Generated at 2022-06-21 07:15:30.540754
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert isinstance(l, LookupBase)

# Unit tests for run method of class LookupModule

# Generated at 2022-06-21 07:15:39.448606
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Example objects to run methods with
    terms1 = [
        "a",
        "b"
    ]
    terms2 = [
        "a.c",
        "a.b.c"
    ]
    terms3 = [
        "b",
        "c",
        "a"
    ]

    var_options1 = {
        "a": 1,
        "b": 2
    }
    var_options2 = {
        "a": {
            "b": {
                "c": 1
            },
            "c": 0
        }
    }
    var_options3 = {
        "a": {
            "b": {
                "c": 0
            },
            "c": 1
        },
        "b": 0,
        "c": 1
    }

    kw

# Generated at 2022-06-21 07:16:47.344235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def assertRunMethodsEqual(run1, run2):
        assert run1[0] == run2[0]
        assert run1[1] == run2[1]

    lookup_obj = LookupModule()

# Generated at 2022-06-21 07:16:57.379809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    variables = {
        'ansible_play_hosts': 'localhost',
        'ansible_play_batch': 'batch',
        'ansible_play_hosts_all': 'all',
    }

    value = lookup_module.run(terms, variables)

    assert value == variables.values()



# Generated at 2022-06-21 07:17:00.078717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase), "Test class LookupModule"


# Generated at 2022-06-21 07:17:12.743865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test global variables
    lookup = LookupModule()
    lookup._templar = DummyTemplar()
    lookup._templar._available_variables = {'a': 'A', 'b': 'B', 'd': {'e': 'E', 'f': 'F'}, 'h': {'i': 'I', 'j': 'J'}}

# Generated at 2022-06-21 07:17:18.717860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test Variables
    templar = Templar()
    templar._available_variables = {'host1': {'host_specific_var': 'host 1', 'host_specific_var2': 'host2'},
                                    'host2': {'host_specific_var': 'host 2', 'host_specific_var2': 'host2'},
                                    'group_specific_var': 'group var',
                                    'group_specific_var2': 'group var2',
                                    'all_hosts': ['host1', 'host 2'],
                                    'all_groups': ['group1', 'group2'],
                                    'inventory_hostname': 'host1',
                                    'groups': {'group1': ['host1', 'host2'], 'group2': ['host1', 'host2']}}
   

# Generated at 2022-06-21 07:17:23.576678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mydict = {'ansible_play_hosts': ['127.0.0.1'],
              'ansible_play_batch': ['127.0.0.1'],
              'ansible_play_hosts_all': [{'127.0.0.1': [{'ansible_play_hosts': ['127.0.0.1']}]}]}
    assert(mydict == LookupModule(loader=None, templar=None, variables=mydict).run(terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']))

# Generated at 2022-06-21 07:17:26.182961
# Unit test for constructor of class LookupModule
def test_LookupModule():
    res = LookupModule()
    assert res is not None, "Cannot instanciate LookupModule"

# Generated at 2022-06-21 07:17:33.661922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule

    lookup_module = LookupModule()
    assert lookup_module.run(["name"], {'name': 'nabe'}) == ['nabe']
    assert lookup_module.run(["hostvars.host1.name"], {'hostvars': {'host1': {'name': 'nabe'}}}) == ['nabe']
    assert lookup_module.run(["name"], {'name': 'nab', 'nab': 'nabe'}) == ['nabe']
    assert lookup_module.run(["name"], {'name': {'sub1': 'nabe'}}) == [{'sub1': 'nabe'}]

# Generated at 2022-06-21 07:17:35.940715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup

# Generated at 2022-06-21 07:17:37.356674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()