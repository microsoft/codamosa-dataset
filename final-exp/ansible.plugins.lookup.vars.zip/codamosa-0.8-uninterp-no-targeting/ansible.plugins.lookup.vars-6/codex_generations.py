

# Generated at 2022-06-21 07:08:50.973443
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test loading the module
    lookup = LookupModule()
    assert lookup is not None
    assert lookup._templar is not None
    assert lookup._templar._available_variables is not None

    assert lookup._templar.available_variables is not None

# Generated at 2022-06-21 07:09:00.449931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict(variablename='hello', myvar='ename'))

    l = LookupModule()
    l._templar = templar

    assert l.run(terms=['variablename'], variables=templar._available_variables, **dict(default='')) == ['hello']
    assert l.run(terms=['variabl' + myvar], variables=templar._available_variables, **dict(default='')) == ['hello']

# Generated at 2022-06-21 07:09:02.367679
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert lm.name == 'vars'

# Generated at 2022-06-21 07:09:07.513294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    fail_LookupModule = None
    try:
        fail_LookupModule = LookupModule()
        assert fail_LookupModule is not None
    except:
        fail_LookupModule = None
    assert fail_LookupModule is not None

# Generated at 2022-06-21 07:09:09.515566
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['foo', 'bar']
  variables = {'foo':'foo', 'bar':'bar'}
  assert LookupModule().run(terms, variables) == list(terms)

# Generated at 2022-06-21 07:09:14.170742
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a new LookupModule instance
    my_LookupModule = LookupModule()

    # Assert that my_LookupModule is an instance of LookupModule
    assert isinstance(my_LookupModule, LookupModule)


# Generated at 2022-06-21 07:09:20.739721
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def mock_templar_template(data):
        return data

    from collections import namedtuple

    # variables used for test
    myvars = {
        'inventory_hostname': 'localhost',
        'hostvars': {
            'localhost': {
                'host_var': 'host_value'
            }
        },
        'play_var': 'play_value'
    }
    terms = [
        'play_var',
        'host_var'
    ]

    # create test object LookupModule
    # by simulating the __init__ method
    LookupModule.set_options = namedtuple(
        'options',
        'var_options direct'
    )

    LookupModule.get_option = lambda self, key: None


# Generated at 2022-06-21 07:09:30.690805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    myvars = {
        "hello": 'world',
        "inventory_hostname": 'myhost',
        "hostvars": {
            "myhost": {
                "var1": "value1",
                "var2": "value2"
            }
        }
    }

    terms = [ 'hello', 'var1', 'var2' ]
    check_return = [ 'world', 'value1', 'value2' ]
    variables = { "ansible_play_hosts": [ "host1", "host2" ] }

    ret = lookup_module.run(terms, variables=myvars, variable_manager=variables)
    assert ret == check_return

# Generated at 2022-06-21 07:09:31.355541
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testclass = LookupModule()
    assert testclass

# Generated at 2022-06-21 07:09:43.249043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    test_obj = LookupModule()
    test_obj._templar = {'_available_variables': {'variablename': 'hello'}, 'inventory_hostname': 'localhost'}
    default = 'default'
    with pytest.raises(AnsibleUndefinedVariable) as e:
        test_obj.run(['variablenotename'], variables=None, default=None)
        assert e.msg == 'No variable found with this name: variablenotename'
    ret = test_obj.run(['variablename'], variables=None, default=default)
    assert ret == ['hello']


# Generated at 2022-06-21 07:09:54.973909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    c1 = {'hostvars_host_c': {
        'a': '1',
        'b': '2'
        }
    }

# Generated at 2022-06-21 07:10:02.703968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    # TEST: Generate a mock_templar object to be used by the lookup module
    mock_templar = MockTemplar()

    # TEST: Create a mocked inventory object that has a dictionary of mocked_hosts, one of which is the needed host
    mock_inventory = MockInventory()
    mock_host = MockHost('host1')
    mock_host.variables = {'hostvars': {'host1': {'var1': 'myvalue1'}}}
    mock_inventory.hosts['host1'] = mock_host

    # TEST: Create a lookup module instance with the mock_templar and mock_inventory
    lookup_module = LookupModule(mock_templar, mock_inventory)

    # TEST: Test the run function for a single variable

# Generated at 2022-06-21 07:10:11.812197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None).run(
        ['ansible_os_family'], variables={'ansible_os_family': 'RedHat'}) == ['RedHat']
    assert LookupModule(loader=None, templar=None, shared_loader_obj=None).run(
        ['ansible_os_family'], variables={'hostvars': {'test': {'ansible_os_family': 'RedHat'}}},
        terms={'inventory_hostname': 'test'}) == ['RedHat']


# Generated at 2022-06-21 07:10:25.233340
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test that keyerror is raised if undefined variables are used
    terms = ['test']
    variables = {'test': 'this works'}
    with pytest.raises(AnsibleUndefinedVariable) as e:
        LookupModule().run(terms, variables)
        assert e.msg == 'No variable found with this name: test'

    # test that keyerror is raised if undefined variables are used
    terms = ['test']
    variables = {}
    with pytest.raises(AnsibleUndefinedVariable) as e:
        LookupModule().run(terms, variables)
        assert e.msg == 'No variable found with this name: test'

    # test that keyerror is not raised if undefined variables are used and default is set
    terms = ['test']
    variables = {}
    default = 'default string'
    res = Look

# Generated at 2022-06-21 07:10:37.102532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test 1
    terms = ['ansible_facts']
    variables = {'ansible_facts': {'a': 'test'}}
    l = LookupModule()
    result = l.run(terms, variables=variables)
    assert result == [{'a': 'test'}]

    # test 2
    terms = ['a']
    variables = {'ansible_facts': {'a': 'test'}}
    l = LookupModule()
    result = l.run(terms, variables=variables)
    assert result == ['test']

# Generated at 2022-06-21 07:10:38.629386
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 07:10:46.436874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit tests for method run of class LookupModule """

    ################################################################################
    #
    # Unit test for method run of class LookupModule, without default.
    #

    # Create a LookupModule instance.
    module = LookupModule()

    # Create sample entries, which will be looked up.
    terms = [
        'var1',
        'var2'
    ]

    # Create mapping variables, which will be looked up.
    variables = {
        'var1': 'lookup1',
        'var2': 'lookup2'
    }

    # Call method run.
    ret = module.run(terms, variables)

    # Check result from method run.
    assert ret == ['lookup1', 'lookup2']


    ################################################################################
    #
    # Unit test for

# Generated at 2022-06-21 07:10:58.185907
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test: Without default value if any of the variables is not defined, it will throw an error.
    # Expected results: LookupError exception is thrown.
    ls = LookupModule()
    ls.set_options(direct={})
    try:
        ls.run([
            'ansible_play_not_defined_variable1',
            'ansible_play_not_defined_variable2',
            'ansible_play_not_defined_variable3'
        ])
        assert False
    except AnsibleUndefinedVariable:
        pass

    # Test: With default value if any of the variables is not defined, it will return the default value for that variable.
    # Expected results: A list of values for the defined variables and default value for the undefined variables.
    ls = LookupModule()

# Generated at 2022-06-21 07:11:06.251887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    module_args = [
        'ansible_play_hosts',
        'ansible_play_batch',
        'ansible_play_hosts_all'
    ]
    lookup_module._display.display = lambda x: x
    assert lookup_module.run(
        module_args
    ) == lookup_module._display.display(lookup_module.run(module_args))


# Generated at 2022-06-21 07:11:14.368038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule instance 
    lookup_module = LookupModule()

    # Create a variable and set updat
    variables = dict(a=1, b=2)
    lookup_module.set_options(var_options=variables, direct=dict())

    # Test method run
    terms = ['a', 'b']
    assert lookup_module.run(terms) == [1, 2]

# Generated at 2022-06-21 07:11:23.985001
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = AnsibleModule(
        argument_spec = dict(
            _terms = dict(required=True, type='list'),
            default = dict(default=None),
        )
    )

    lookup_plugin = LookupModule()
    lookup_plugin.set_options()
    lookup_plugin.run(module.params['_terms'])
# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-21 07:11:27.105718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    instance.run(terms=['term1'])

# Generated at 2022-06-21 07:11:39.037520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import json
    import pytest
    mylookup = LookupModule()
    mylookup.set_loader(DictDataLoader({}))
    mylookup._templar = Templar(loader=DataLoader(), variables=VariableManager())
    mylookup._templar._available_variables = {'testvar': 'test_value'}
    assert json.dumps(mylookup.run(['testvar'], ['test_value'])) == '[\n    "test_value"\n]'

# Generated at 2022-06-21 07:11:47.928559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys
    import tempfile
    from ansible.module_utils.six import b

    # For coverage to work correctly in python 2.7
    try:
        import coverage
        coverage.process_startup()
    except:
        pass

    # Get the path of the LookupModule class
    source_path = os.path.abspath(__file__)
    source_dir = os.path.dirname(source_path)
    code, output = tempfile.mkstemp()

    # Construct the task

# Generated at 2022-06-21 07:11:48.820779
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mod = LookupModule()
    


# Generated at 2022-06-21 07:11:59.907439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test is being done in isolation because it has been observed
    # that the order of the decorators changes the results of the test
    # in the other test cases like test_lookup_plugins.yml.

    import six
    from ansible.plugins.loader import lookup_loader, module_loader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import Reserved

    # Mock DataLoader
    mock_dl = DataLoader()

    # Mock Template
    mock_templar = Templar(loader=mock_dl)

    # Mock Reserved
    mock_reserved = Reserved()


# Generated at 2022-06-21 07:12:10.710166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    # Setup
    myvars = {
        'hostvars': HostVars({'hostvars': {}, 'inventory_hostname': 'name'}, {'hostvars': {}, 'inventory_hostname': 'name'}),
        'inventory_hostname': 'name',
        'ansible_play_hosts': ['a', 'b', 'c'],
    }
    var_manager = VariableManager(loader=None, inventory=None, version_info=None)
    templar = Templar(loader=None, variables=var_manager, shared_loader_obj=None)

# Generated at 2022-06-21 07:12:19.629769
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #test with a valid variable
    l = LookupModule()
    l._templar._available_variables = {'test':'variable'}
    r = l.run(terms='test')
    assert r == ['variable']

    #test with a variable that doesn't exist
    l = LookupModule()
    l._templar._available_variables = {'test':'variable'}
    r = l.run(terms='test2')
    assert r == [None]

    #test with a variable that doesn't exist and a default value
    l = LookupModule()
    l._templar._available_variables = {'test':'variable'}
    r = l.run(terms='test2', default='default')
    assert r == ['default']

# Generated at 2022-06-21 07:12:21.178734
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 07:12:32.886432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Current best workaround for knowing the callback plugin name from tests
    # the callback plugin name is the file name
    #
    # https://github.com/ansible/ansible/issues/15495
    import os
    callback_plugin = os.path.splitext(os.path.basename(__file__))[0]

    # Create mock inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])

    # Create mock variable_manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # Create mock templar

# Generated at 2022-06-21 07:12:45.767730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestException(Exception):
        pass

    class TestLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            super(TestLookupModule, self).__init__(*args, **kwargs)
            raise TestException()

    try:
        TestLookupModule(terms=[], variables=None)
    except Exception as e:
        assert type(e) == TestException

# Generated at 2022-06-21 07:12:52.161501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.plugins.loader import lookup_loader

    def __get_lookup_plugin(name):
        return lookup_loader.get(name, class_only=True)

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-21 07:12:54.991073
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 07:13:04.443263
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Test get_option
    default_value = 'default'
    default_value2 = 'default2'
    option1 = 'my_option1'
    option2 = 'my_option2'
    value1 = 'my_value1'
    value2 = 'my_value2'
    class temp:
        def __init__(self, opt1, opt2, default=None):
            self.default = default
            self.opt1 = opt1
            self.opt2 = opt2

    options_lookup = temp(value1, value2, default_value)
    # Test set_options
    test_lookup = LookupModule()
    assert test_lookup.get_option(option1) is None
    assert test_lookup.get_option(option2) is None
    assert test_lookup.get

# Generated at 2022-06-21 07:13:08.984079
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule(None)
    assert isinstance(mod, LookupModule)

# Generated at 2022-06-21 07:13:11.177899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-21 07:13:15.206464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup.run(["foo", "bar"]) == []

# Generated at 2022-06-21 07:13:24.981577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # input_data = [<terms>, <variables>]
    # assert_equals(expected_result, LookupModule.run(input_data))
    lookup = LookupModule()
    assert_equals(12, lookup.run(['variablename.sub_var'], {'variablename': {'sub_var': 12}})[0], 'Nested Variable')
    assert_equals(12, lookup.run(['variablename.sub_var'], {'variablename': 12})[0], 'Variable is not nested')

# Generated at 2022-06-21 07:13:25.691679
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)

# Generated at 2022-06-21 07:13:35.469882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    from ansible.module_utils._text import to_bytes

    template = '{{ lookup("vars", "ansible_play_hosts") }}'
    lookup = LookupModule()
    # Note: method run returns a list
    result = lookup.run(template, "test")
    assert result[0] == "test"

    task = json.loads(to_bytes('''{
        "_ansible_no_log": false,
        "changed": false,
        "_ansible_item_result": true,
        "item": "test"
    }'''))
    result = lookup.run(template, task['item'])
    assert result[0] == "test"

# Generated at 2022-06-21 07:14:00.239724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

# Generated at 2022-06-21 07:14:05.155626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._templar._fail_on_undefined_errors == True
    assert lookup_plugin._templar._available_variables == {}

# Generated at 2022-06-21 07:14:13.040255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.fail_json = mock.MagicMock(side_effect=Exception('fail'))
    lu = LookupModule(templar=basic.AnsibleTemplar(loader=basic.AnsibleLoader(module._init_loader_paths())))
    lu._templar._available_variables = {'variablename': 'hello'}

    lu.set_options(var_options={'variablename': 'hello'}, direct={'default': 'def'})
    assert lu.get_option('default') == 'def'

    lu.set_options(var_options={'myvar': 'ename'}, direct={})

# Generated at 2022-06-21 07:14:16.136710
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run(terms=['foo'], failure=True)


# Generated at 2022-06-21 07:14:16.867352
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:14:25.719691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_module = LookupModule()

    terms = ['test_variable']
    variables = {}
    variables['test_variable'] = 'test_value'
    variables['inventory_hostname'] = 'test_host'
    variables['hostvars'] = {}
    variables['hostvars']['test_host'] = {}
    variables['hostvars']['test_host']['test_variable'] = 'test_host_value'
    kwargs = {}

    # Return value of 'test_host_value' is ok
    test_module.run(terms, variables, **kwargs)
    assert test_module._templar._available_variables['test_variable'] == 'test_value'

# Generated at 2022-06-21 07:14:28.782103
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_mod = LookupModule()
    my_lookup_mod.run(terms=['vagrant_box'])

# Generated at 2022-06-21 07:14:42.247867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import pytest
    from ansible.compat.six.moves import StringIO
    from ansible.plugins.lookup import LookupModule

    lookup = LookupModule()
    lookup.set_options(dict())

    var_options = {'a': 'a',
                   'b': 'b',
                   'c': {'d': 'd',
                         'e': 'e'},
                   'f': [1, 2, 3, {'g': 'g'}],
                   'h': ['h1', 'h2'],
                   'i': ['i1', {'i2': 'i2'}]
                   }
    lookup.set_options(var_options=var_options)
    assert lookup.run(["a"], var_options) == ['a']

# Generated at 2022-06-21 07:14:47.983938
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test empty constructor
    test = LookupModule()
    assert test._display_name() == 'vars'

# Generated at 2022-06-21 07:14:56.821486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    templar = unittest_utils.mock_unix_template()
    lookup._templar = templar

# Generated at 2022-06-21 07:15:36.997523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    templar = Templar(loader=None, shared_loader_obj=None)

    # First test the execution of the method without default value
    # Test case #1 with only one defined variable
    parameters = {'hostvars':
                  {'host1':
                   {'ansible_play_hosts': '192.168.1.1'}}}
    myvars = ImmutableDict(parameters, vault_password=VaultLib.get_vault_password)
    result = LookupModule().run(['ansible_play_hosts'], variables=myvars)

# Generated at 2022-06-21 07:15:48.000294
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader, variables=dict(hostvars=dict(hostname=dict(var1="val1", var2="val2"))))
    var_manager = VariableManager(loader=loader, inventory=None)
    lookup_instance = LookupModule()

    lookup_instance._templar = templar
    lookup_instance._loader = loader
    lookup_instance._variable_manager = var_manager

    assert lookup_instance._templar._available_variables == dict(hostvars=dict(hostname=dict(var1="val1", var2="val2")))
    assert lookup_instance._loader.list_tem

# Generated at 2022-06-21 07:15:58.783516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mydict = {'myvar': 'myval', 'myvar2': 'myval2'}
    mydict_host = {'hostvars': {'host1': mydict}}
    mydict_host_omit = {'hostvars': {'host2' : {}}}
    myobj = LookupModule()
    myobj._templar._available_variables = mydict
    myobj._templar._available_variables = mydict_host
    myobj._templar._available_variables = mydict_host_omit

    # Check looking up a key
    ret = list(myobj.run(terms=['myvar'], variables=mydict))
    assert len(ret) == 1 and ret[0] == 'myval'

    # Check looking up a key that does not exist

# Generated at 2022-06-21 07:16:06.758843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    my_terms = ['test1', 'test2']
    my_variables = {'test1': '1', 'test2': '2'}
    my_result = my_lookup.run(terms=my_terms, variables=my_variables)
    assert my_result == ['1', '2']

# Generated at 2022-06-21 07:16:17.680004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """

    module = LookupModule()
    assert module.run([]) == []
    assert module.run(['foo']) == [], "lookup() should return undefined values as strings, but: %r" % module.run(['foo'])
    assert module.run(['foo'], variables={'foo': 'bar'}) == ['bar']
    assert module.run(['foo'], variables={'foo': None}) == [None]
    assert module.run(['foo'], variables={'foo': []}) == [[]]
    assert module.run(['foo'], variables={'foo': ['bar', 'cat']}) == [['bar', 'cat']]

# Generated at 2022-06-21 07:16:25.483497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(None, 'dummy') == []
    assert LookupModule().run('dummy', 'dummy') == []
    assert LookupModule().run(['dummy'], None) == []
    assert LookupModule().run(['dummy'], None, default='hello') == ['hello']
    assert LookupModule().run(['dummy'], {'dummy': 1}) == [1]


# Generated at 2022-06-21 07:16:25.976007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass


# Generated at 2022-06-21 07:16:38.996994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import text_type
    from ansible.template import Templar

    names_var = u'ansible_play_hosts'
    batch_var = u'ansible_play_batch'
    host_all = u'ansible_play_hosts_all'

    terms = [names_var, batch_var, host_all]

    # Create hostvars

# Generated at 2022-06-21 07:16:48.876632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    myvars = dict(myvar1 = "hello", myvar2 = dict(myvar2a = "bye", myvar2b = "bon voyage"))
    assert l.run(["myvar1"], variables = myvars) == ["hello"]
    assert l.run(["myvar2"], variables = myvars) == [{'myvar2a': 'bye', 'myvar2b': 'bon voyage'}]
    assert l.run(["myvar2.myvar2b"], variables = myvars) == ["bon voyage"]
    assert l.run(["myvar3"], variables = myvars) == []
    assert l.run(["myvar1", "myvar2.myvar2b"], variables = myvars) == ["hello", "bon voyage"]
    assert l.run

# Generated at 2022-06-21 07:16:53.619453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test for lookup module constructor
    lookup = LookupModule()
    assert not hasattr(lookup, '_templar')


# Generated at 2022-06-21 07:17:58.042573
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 07:18:09.113090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm._templar._available_variables = {
        'variablename': 'hello',
        'myvar': 'ename',
        'hostvars': {
            'inventory_hostname': {
                'variablename': 'hello'
            }
        }
    }

    assert ['hello'] == lm.run(["'variablename'"])
    assert ['hello'] == lm.run(["'variabl' + myvar"])
    assert ['hello'] == lm.run(["'variabl' + myvar", "'variablename'"])

    assert [] == lm.run(["'variablnotename'"])

# Generated at 2022-06-21 07:18:22.340513
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule
    # Arrange
    class options:
        def __init__(self):
            self.var_options = None
            self.direct = None

    class templar:
        def template(self, v, fail_on_undefined=None):
            return v

        def __init__(self):
            self._available_variables = {}
            self.available_variables = {}

    class LookupBase:
        def set_options(self, var_options=None, direct=None):
            self.options = options()
            self.options.var_options = var_options
            self.options.direct = direct

        def get_option(self, option):
            return self.options.direct[option]

    lookup = LookupModule()

# Generated at 2022-06-21 07:18:23.776997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-21 07:18:34.905906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    class TestTemplar:
        def __init__(self, dict_of_variables):
            self._available_variables = dict_of_variables

        def template(self, value, fail_on_undefined=False, convert_bare=True, overrides=None,
                     preserve_trailing_newlines=True, escape_backslashes=True,
                     convert_data=True, strip_comments=True, remove_blank_lines=True):
            return AnsibleUnsafeText(str(myvars[value]))

    class TestLookupModule:
        def __init__(self, templar):
            self._templar = templar


# Generated at 2022-06-21 07:18:35.606362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()


# Generated at 2022-06-21 07:18:43.730203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.vars import LookupModule
    t = LookupModule()
    t._templar = TestClass()
    assert t.run('variablename') == ['hello']
    assert t.run(['variablename', 'myvar']) == ['hello', 'ename']
    assert t.run(['variablnotename'], default='') == ['']
    assert t.run(['variablnotename']) == []
    assert t.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']) == ['hosts', 'batch', 'hosts_all']
    assert t.run(['variablename']) == ['hello']
