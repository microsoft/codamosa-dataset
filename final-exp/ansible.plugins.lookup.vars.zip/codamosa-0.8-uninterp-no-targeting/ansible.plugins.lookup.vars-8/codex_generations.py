

# Generated at 2022-06-21 07:08:48.990745
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(loader=None, templar=None, variables=None)

# Generated at 2022-06-21 07:09:01.201643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3

    # Test for a valid term.
    lookup = LookupModule()
    result = lookup.run(terms=['test_term'], variables={'test_term': 'test_value'})[0]
    assert result == 'test_value'

    # Test for an undefined variable.
    try:
        lookup.run(terms=['missing_term'], variables={})
        print('lookup.run should have thrown an AnsibleUndefinedVariable exception!')
    except AnsibleUndefinedVariable as e:
        if PY3:
            assert str(e) == 'No variable found with this name: missing_term'
        else:
            assert str(e) == 'No variable found with this name: u\'missing_term\''

    # Test for an undefined variable with a default

# Generated at 2022-06-21 07:09:05.989154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule
    terms = ['testvarname']
    variables = {'testvarname': 'testvarvalue'}

    # Test option fail_on_undefined false
    ret = lookup.run(terms, variables)
    assert ret == ['testvarvalue']

    # Test option fail_on_undefined true
    variables = {}
    with pytest.raises(AnsibleUndefinedVariable):
        ret = lookup.run(terms, variables)

# Generated at 2022-06-21 07:09:10.117966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert len(lookup._options) == 1
    assert 'default' in lookup._options
    assert len(lookup._options['default']) == 5
    assert lookup._options['default']['default'] == None
    assert lookup._options['default']['type'] == 'str'
    assert lookup._options['default']['description'] == 'What to return if a variable is undefined.  If no default is set, it will result in an error if any of the variables is undefined.'
    assert lookup._options['default']['choice'] == None
    assert lookup._options['default']['env'] == None


# Generated at 2022-06-21 07:09:10.477998
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:09:20.319864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.vars import LookupModule

    # construct fake templar
    class FakeTemplar(object):
        def __init__(self, result=None):
            self._result = result
        def template(self, value, fail_on_undefined):
            return self._result
    ft = FakeTemplar()

    # construct fake module options
    class FakeModuleOptions(dict):
        def __init__(self):
            self["direct"] = {}
        def get_option(self, x):
            return self["direct"].get(x)
    fmo = FakeModuleOptions()

    # construct fake module
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.tmp = '/tmp'

# Generated at 2022-06-21 07:09:25.073185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # TODO: need more tests here
    assert module.run(['hostvars']) == [{'result': 'hostvars'}]

# Generated at 2022-06-21 07:09:26.535674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()


# Generated at 2022-06-21 07:09:31.270052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for class lookup module with constructor
    x = LookupModule()
    assert x is not None


# Generated at 2022-06-21 07:09:43.445321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test with no hostvars
    variables = {'inventory_hostname': 'localhost', 'hostvars': {}}
    myvars = variables['hostvars']
    method_kwargs = {'variables': variables}

    # test with no variables, but one term and default
    terms = ['one']
    kwargs = {'default': 'default'}
    result = lookup.run(terms, **method_kwargs)
    assert result == ['default'], "Expected default for no variables, one term, and default"

    # test with one variable, one term and default
    myvars['one'] = 'first'
    result = lookup.run(terms, **method_kwargs)
    assert result == ['first'], "Expected var value for one variable, one term and default"

# Generated at 2022-06-21 07:10:00.883887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    myvars =  {
        "inventory_hostname": "testvm",
        "hostvars": {
            "testvm": {
                "sub_var": 12,
                "sub_var_2": 24,
                "subsub_var": 36
            }
        }
    }
    terms = [
        'sub_var',
        'subsub_var',
        'sub_var_2',
        'subsub_sub_var',
        'subsubsubsub_sub_var'
    ]

    returned_terms = [
        12,
        'subsubsubsub_sub_var'
    ]

    returned_terms_default = [
        12,
        24,
        36
    ]


# Generated at 2022-06-21 07:10:02.909150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Add
    l = LookupModule()
    l.run('your variable name')

# Generated at 2022-06-21 07:10:05.183833
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert type(lookup_module) == LookupModule

# Generated at 2022-06-21 07:10:07.203221
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None



# Generated at 2022-06-21 07:10:13.960235
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test if calling the run method returns an error when the _terms parameter is not a string
    lookup_module = LookupModule()
    try:
        lookup_module.run(terms=[3])
        assert False
    except AnsibleError:
        assert True


    # Test if calling the run method returns a lookup in the myvar variable
    lookup_module = LookupModule()
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(terms=['variablename'], variables=variables) == ['hello']

    # Test if calling the run method returns a default variable when there is no variable
    lookup_module = LookupModule()
    variables = {'variablnotename': 'hello'}

# Generated at 2022-06-21 07:10:15.830381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-21 07:10:17.310175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(isinstance(LookupModule(), LookupModule))

# Generated at 2022-06-21 07:10:26.162072
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test normal constructor
    lookup_module = LookupModule()

    # test the available_variables functionality
    available_variables = {'a': 'b'}
    lookup_module._templar._available_variables = available_variables
    assert lookup_module._templar._available_variables == available_variables

    # test the constructor with variables argument
    lookup_module = LookupModule(variables=available_variables)
    assert lookup_module._templar._available_variables == available_variables

    # test the available_variables functionality
    lookup_module._templar.available_variables = available_variables
    assert lookup_module._templar._available_variables == available_variables

# Generated at 2022-06-21 07:10:30.064903
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l._templar._available_variables == {}
    assert l._templar.available_variables == {}



# Generated at 2022-06-21 07:10:31.271469
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule)

# Generated at 2022-06-21 07:10:56.768051
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:11:01.014441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of the LookupModule class
    test_lookup_module = LookupModule()

    # Test the constructor of the LookupModule class
    assert(isinstance(test_lookup_module, LookupModule))



# Generated at 2022-06-21 07:11:12.072238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar

    templar1 = Templar(loader=None)
    templar1._available_variables = {
        'inventory_hostname': 'testhost',
        'test': 'firsttest',
        'playbooks_test': 'playtest',
        'playbooks_test2': 'playtest2',
        'hostvars': {
            'testhost': {
                'test': 'secondtest',
                'playbooks_test': 'playtest',
            },
        }
    }
    templar1._available_variables['hostvars']['testhost']['playbooks_test2'] = 'playtest2'

    # Cannot access defined variable
    terms = ['test']
    variables = None
    kwargs = {}
    expected_return = ['firsttest']
   

# Generated at 2022-06-21 07:11:23.137240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    sys.path.append('./lib')
    from ansible.parsing.dataloader import DataLoader
    templar = DataLoader()

    terms = [
        'variablename',
        'myvar',
    ]

    variables = {
        'variablename': 'hello',
        'myvar': 'ename',
    }

    default = ''

    result = LookupModule(loader=None, templar=templar, **{'_terms': terms, 'default': default}).run(variables=variables)

    assert result == ['hello', 'ename']

# Generated at 2022-06-21 07:11:24.943098
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:11:28.697698
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin._templar is not None

# Generated at 2022-06-21 07:11:33.050964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import unittest
    from ansible.module_utils.six import StringIO

    class TestAnsibleModuleInvalidType(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_run(self):
            try:
                from ansible.module_utils.basic import AnsibleModule
            except:
                self.skipTest('AnsibleModule not found')
            m_args = dict(
                _terms = [
                    '{{inventory_hostname}}'
                ]
            )

            # Redirect stdout to capture any exception thrown by the lookup
            # and to make debugging easier
            old_stdout = sys.stdout
            output = StringIO()
            sys.stdout = output

            # Set some vars that are used in

# Generated at 2022-06-21 07:11:36.957120
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''Unit test for the constructor of the LookupModule class.'''
    lookup_instance = LookupModule()
    assert LookupBase == type(lookup_instance)


# Generated at 2022-06-21 07:11:47.873905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup = LookupModule()  # ansible.parsing.dataloader.DataLoader(), template.AnsibleTemplar(variables=dict())

    class MyVars:
        hostvars = {'localhost': {'var_1': 'value_1'}}
        inventory_hostname = 'localhost'
        var_2 = 'value_2'

    test_vars = MyVars()
    test_lookup._templar = test_lookup._load_plugins(['template'])[0]  # ansible.parsing.dataloader.DataLoader(), template.AnsibleTemplar()
    test_lookup._templar._available_variables = test_vars  # {'hostvars': {'localhost': {'var_1': 'value_1'}

# Generated at 2022-06-21 07:11:57.662118
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # init
    templar = DummyTemplar()
    lookup = LookupModule(templar=templar)
    variables = DummyVariables()

    # result same as lookup vars
    terms = ['a']
    variables._available_variables['a'] = '10'
    assert lookup.run(terms=terms, variables=variables) == [10]
    assert lookup.run(terms=terms, variables=variables, default='20') == [10]

    # result different as lookup vars
    terms = ['b']
    variables._available_variables['b'] = '10'
    assert lookup.run(terms=terms, variables=variables) == [10]
    assert lookup.run(terms=terms, variables=variables, default='20') == [10]

    # result same as lookup vars

# Generated at 2022-06-21 07:12:32.929158
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['a', 'b']
    ret = []
    variables = {'a': 1, 'b': 2}
    lookup_obj = LookupModule()
    lookup_obj._templar._available_variables = variables
    assert lookup_obj.run(terms, variables) == [1, 2]
    terms = ['a', 'c']
    variables = {'a': 1}
    hostvars = {'host1': {'b': 2}}
    myvars = {'inventory_hostname': 'host1', 'hostvars': hostvars}
    lookup_obj._templar._available_variables = myvars
    assert lookup_obj.run(terms, variables) == [1]

# Generated at 2022-06-21 07:12:33.459669
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:12:41.801516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible import context
    from ansible.template import Templar

    inv = dict(
        all=dict(
            hosts=dict(
                localhost=dict(
                    ansible_connection=dict(
                        _value="local"
                    )
                )
            )
        ),
        _meta=dict(
            hostvars=dict(
                ansible_connection=dict(
                    _value="local"
                )
            )
        )
    )

    context.CLIARGS = {}

# Generated at 2022-06-21 07:12:52.363676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Test Case: HostDefinition.load_from_dataset_override_fields
  lookup = LookupModule()
  # Test Case: HostDefinition.load_from_dataset_override_fields
  lookup.run(['variablename', 'myvar'])
  # Test Case: HostDefinition.load_from_dataset_override_fields
  lookup.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])
  # Test Case: HostDefinition.load_from_dataset_override_fields
  lookup.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])
  # Test Case: HostDefinition.load_from_dataset_override_fields

# Generated at 2022-06-21 07:13:03.777531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    paths = './test/integration/lookup_plugins/vars'
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='test')))
         ]
    )

# Generated at 2022-06-21 07:13:15.029078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # define expected result
    terms = ['variablename', 'myvar']
    default = None
    # define variables
    variables = dict(variablename='hello', myvar='ename')

    # define expected result
    expected_result = ['hello', 'ename']
    # validate
    assert lookup.run(terms, variables, default) == expected_result

    # define expected result
    terms = ['variablename', 'myvar']
    default = ''
    # define variables
    variables = dict(variablename='hello', myvar='notename')

    # define expected result
    expected_result = ['hello', '']
    # validate
    assert lookup.run(terms, variables, default) == expected_result

    # define expected result

# Generated at 2022-06-21 07:13:22.734707
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar

    mod = AnsibleModule(argument_spec={})
    t = Templar(loader=None, variables={})
    lookup = LookupBase()
    lookup.set_options(direct={})
    lookup._templar = t
    assert lookup.run(terms=['bar'], loader=None, variables={'foo': {'bar': 'qux'}}) == ['qux']

# Generated at 2022-06-21 07:13:23.855805
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookupModule = LookupModule()
    return myLookupModule

# Generated at 2022-06-21 07:13:35.500018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupBase(LookupBase):
        def __init__(self):
            class BadTemplate:
                pass
            self.some_dict = {'hostname': 'host1',
                              'hostvars': {'host1': {'some_dict': BadTemplate()}}}
            self._templar = self.some_dict

    test_var_base = TestLookupBase()

    # Test with default not set
    expected_return = ['host1']
    returned = test_var_base.run(terms=["hostname"])
    assert cmp(expected_return, returned) == 0

    # Test with default set
    expected_return = ['host1']
    returned = test_var_base.run(terms=["host1"])
    assert cmp(expected_return, returned) == 0

    #

# Generated at 2022-06-21 07:13:46.492985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Module object for test
    module = LookupModule()

    # Variables we want to test
    myvars = {'myvar1': 123, 'myvar2': 'Hello', 'myvar3': 'World'}

    # This should succeed
    module._templar = myvars
    result = module.run(['myvar1'])
    assert result == [123]

    # This should succeed
    result = module.run(['myvar1'], default='Default')
    assert result == [123]

    # This should succeed and return the default
    result = module.run(['other'], default='Default')
    assert result == ['Default']

    # This should succeed but return an empty list
    result = module.run(['other'])
    assert result == []

    # This should fail

# Generated at 2022-06-21 07:14:44.825269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import LookupModule

    # Test for nested dictionary
    test_dict = {
        'my_var': {
            'my_key': 'my_value'
        }
    }

    # PY3 requires bytes()
    if PY3:
        test_dict_str = '{{"my_var": {{"my_key": "my_value"}}}}'.encode()
    else:
        test_dict_str = '{{"my_var": {{"my_key": "my_value"}}}}'

    test_tmpl = 'my_var.my_key'

    lm = LookupModule()

    res = lm.run([test_tmpl], self._templar._available_variables)


# Generated at 2022-06-21 07:14:51.185503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self):
            self.private = False

    myvars = dict(
        myvar='myvarvalue',
        mylist=['firstitem', 'seconditem'],
        mydict={'key1': 'val1', 'key2': 'val2'},
        inventory_hostname='fakestr',
        hostvars={'fakestr': dict(anothervar='anothervarvalue')},
    )

    # Create an instance of LookupModule and call run method
    lm = LookupModule()
    lm._templar = None
    lm._templar = type('MockTemplar2', (object,), {'available_variables': myvars})
    lm.set_options(var_options=myvars, direct=Options())

# Generated at 2022-06-21 07:14:53.868013
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config = {}
    cls = LookupModule(config)
    assert hasattr(cls, 'run')


# Generated at 2022-06-21 07:15:03.958372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    term1 = "var_name1"
    term2 = "var_name2"
    terms = [term1, term2]

    variables = {"var_name1": "hello", "var_name2": "world"}
    assert lookup_module.run(terms, variables) == ["hello", "world"]

    variables = {"ansible_play_hosts": [{}], "ansible_play_batch": [{}], "ansible_play_hosts_all": [{}]}
    terms = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]
    assert lookup_module.run(terms, variables) == [[{}], [{}], [{}]]

# Generated at 2022-06-21 07:15:05.411693
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()


# Generated at 2022-06-21 07:15:15.792569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests for method run of class LookupModule
    # Testing for a value
    lm = LookupModule()
    assert lm.run(["name"])[0] == "vars"

    # Testing for a missing value
    lm = LookupModule()
    with pytest.raises(AnsibleError) as exc_info:
        lm.run(["name2"])
    assert "No variable found with this name: name2" in str(exc_info.value)

    # Testing for a default value
    lm = LookupModule()
    assert lm.run(["name2"], default="hello")[0] == "hello"

# Generated at 2022-06-21 07:15:25.736663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing condition where terms is empty
    terms = []
    lu = LookupModule()
    assert lu.run(terms) == []

    # Testing condition where term is not a string
    terms = [1, 2]
    lu = LookupModule()
    try:
        lu.run(terms)
    except AnsibleError as err:
        assert str(err) == 'Invalid setting identifier, "1" is not a string, its a %s' % type(1)
    else:
        raise Exception('Expected exception was not raised')

    # Testing condition where myvar is undefined
    terms = ['variablename1']
    lu = LookupModule()
    try:
        lu.run(terms)
    except AssertionError:
        pass

# Generated at 2022-06-21 07:15:28.751514
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Test to check if instance is created correctly
    assert lookup is not None

# Generated at 2022-06-21 07:15:37.490842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    scope = {
        "hostvars": {
            "testhost": {
                "hostvar1": "value1",
            }
        },
        "inventory_hostname": "testhost",
        "var1": "{{ var2 }}",
        "var2": " lookupsuccess",
    }
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar()
    lookup_module._templar._available_variables = scope
    result = lookup_module.run(["var1", "var2", "var3", "var4"], variables=scope)

    assert result == ["{{ var2 }}", " lookupsuccess", ""]


# Generated at 2022-06-21 07:15:48.183477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all', 'ansible_play_hosts_all_new']
    variables = {}
    expected_result = ['127.0.0.1', '0', '127.0.0.1', 'undefined']
    result = lookup_module.run(terms, variables)
    assert result == expected_result, "Failed to get expected result; expected: %s, got: %s" % (expected_result, result)


# Generated at 2022-06-21 07:17:36.312744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert test_lookup.run(['lookup_plug'], variables=None, **{}) == ['plugin']

# Generated at 2022-06-21 07:17:44.873152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest

    # py2 only
    try:
        from ansible.module_utils._text import to_bytes
    except ImportError:
        to_bytes = str

    lookup_module = LookupModule()

    # case 1
    terms = ['foo']
    variables = {
        'foo': 'bar',
        'myvar': 'ename',
        'variablename': 'hello'
    }

    result = lookup_module.run(terms, variables)

    assert result == ['bar']

    # case 2
    terms = ['foo']
    variables = {
    }

    result = lookup_module.run(terms, variables)

    assert result == []


    # case 3
    terms = ['foo']

# Generated at 2022-06-21 07:17:47.750243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 07:17:49.936199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    # assert that the Lookup option is set to the class
    assert module.LookupBase == LookupBase


# Generated at 2022-06-21 07:17:51.342141
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()

# Generated at 2022-06-21 07:18:02.350559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["a", "b"]
    variables = {
        "a": 1,
        "b": 2,
        "c": 3
    }
    assert module.run(terms, variables) == [1, 2]
    assert module.run(["d"], variables) == []

    # set default value
    module = LookupModule()
    terms = ["a", "b", "d"]
    variables = {
        "a": 1,
        "b": 2,
        "c": 3
    }
    assert module.run(terms, variables, default=0) == [1, 2, 0]

# Generated at 2022-06-21 07:18:11.315761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    import sys
    import unittest
    from ansible.executor.play_iterator import PlayIterator
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import string_types

    class TestTemplar(Templar):
        def __init__(self, loader, variables=None, **kwargs):
            super(TestTemplar, self).__init__(loader, variables, **kwargs)

# Generated at 2022-06-21 07:18:22.850457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'test_var'
    value = 'test_val'
    hostname = 'test_host'
    myvars = {'hostvars': {hostname: {term: value}}}

    module = LookupModule()
    module._templar = LookupBase()
    module._templar._available_variables = myvars
    module._templar.template = lambda myvars, fail_on_undefined: str(myvars)
    module._templar.available_variables = myvars

    module.set_option = lambda var_options, direct: None
    module.get_option = lambda option: None

    assert module.run([term]) == [value]
    assert module.run([term, term]) == [value, value]

# Generated at 2022-06-21 07:18:34.517987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    template = Templar(None, vault_secrets=VaultLib())

    # Test non string term
    test_int = 100
    lookup = LookupModule(loader=None, templar=template, **{})
    try:
        lookup.run(terms=test_int, variables={})
        assert 0
    except AnsibleError as e:
        assert 'is not a string' in e.message

    # Test default default
    test_str = 'hostvars[inventory_hostname][\'hostname\']'

# Generated at 2022-06-21 07:18:43.095906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.vault import VaultLib
    from collections import namedtuple

    Options = namedtuple('Options', ['vault_password'])
    variable_manager = VariableManager()