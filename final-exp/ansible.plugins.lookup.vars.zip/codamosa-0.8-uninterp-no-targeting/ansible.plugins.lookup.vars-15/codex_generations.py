

# Generated at 2022-06-21 07:09:00.931419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Execute lookup using fake data
    # Borrowed from https://github.com/ansible/ansible/blob/devel/test/unit/plugins/lookup/tests/test_vars.py
    def _get_terms(tmpl, vars):
        tmpl = Template(tmpl)
        args = {'vars': vars}
        return ast.literal_eval(tmpl.render(**args))

    class TestLookupModule(LookupModule):
        def run(self, terms, variables=None, **kwargs):
            self._templar = Templar(loader=None, variables=variables)
            return terms

    lm = TestLookupModule()
    assert lm.run([], {}, variable='value', variable2='value2') == \
        ['variable', 'variable2']

# Generated at 2022-06-21 07:09:04.269025
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-21 07:09:09.776400
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test for valid term
    mod_obj = LookupModule()
    terms = ['variablename']
    my_var = mod_obj.run(terms)
    assert my_var == [12]

    # test for invalid term
    terms = ['variablename', 'variablenotename']
    try:
        my_var = mod_obj.run(terms)
    except AnsibleUndefinedVariable:
        assert True

# Generated at 2022-06-21 07:09:10.820831
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 07:09:14.568391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 07:09:22.767721
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class TestLookupModule(LookupModule):

        def run(self, terms, variables=None, **kwargs):
            return terms

    lm = TestLookupModule()
    terms = lm.run([u'a', u'a.b', u'a.b.c', u'a.b[i]', u'a.b[i].d'], variables=u'a: {b: {c: c1, d: d1}, e: e1}')
    assert terms == [u'a', u'a.b', u'a.b.c', u'a.b[i]', u'a.b[i].d']

    # test if method run raises AnsibleError if term is not a string

# Generated at 2022-06-21 07:09:29.740240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Creating a constructor for the class LookupModule
    lookup_module = LookupModule()
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all', 'ansible_play_hosts_all']
    result = lookup_module.run(terms=terms, variables=None, **{})
    #Checking if the result is not empty
    assert result != None
    result = lookup_module.run(terms=terms, variables=None, **{})
    #Checking if the result is not empty
    assert result != None
    #Creation of variables required in order to run the lookup

# Generated at 2022-06-21 07:09:40.171010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test with no default value
    go_on = False
    vars = {'variablename': 'hello', 'myvar': 'ename'}
    try:
        lookup_module.run(['variablename', 'variablenotename'], vars)
        assert False
    except AnsibleUndefinedVariable:
        go_on = True
    assert go_on

    # Test with default value
    lookup_module.run(['variablename', 'variablenotename'], vars, default='')

# Generated at 2022-06-21 07:09:46.029561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Setup
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    templar = Templar(loader=loader, variables=variable_manager)
    lookup = LookupModule()
    lookup._templar = templar
    result = list()

    # Test
    # No error
    result = lookup.run(terms=['ansible_play_hosts', 'ansible_play_batch'], variables=variable_manager._vars, default='default')

# Generated at 2022-06-21 07:09:54.556972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    templar = lookup._templar

    # test that undefined inputs result in error
    try:
        lookup.run('bogus')
    except AnsibleUndefinedVariable:
        pass # expected
    except Exception as e:
        raise AssertionError('Expected AnsibleUndefinedVariable but got %s' % e)

    # test that undefined inputs results in default, if specified
    assert lookup.run('bogus', default=None) == [None]

    # test that defined inputs do not result in error
    lookup.run('ansible_play_hosts')

    # test that inputs from hostvars work fine
    lookup.run('ansible_play_hosts', variables=templar._available_variables)

    # test that nested variables work

# Generated at 2022-06-21 07:10:02.606465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 07:10:12.595535
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create mock objects
    terms = [
        "ansible_play_hosts",
        "ansible_play_batch",
        "ansible_play_hosts_all"
    ]
    variables = {
        "ansible_play_hosts": ["localhost"],
        "ansible_play_batch": ["localhost"],
        "ansible_play_hosts_all": ["localhost"],
    }

    # Create LookupModule object
    lookup_obj = LookupModule()

    # Run run method and store result
    result = lookup_obj.run(terms, variables)
    print(result)

    # Assert result
    assert(result == ["localhost", "localhost", "localhost"])

# Generated at 2022-06-21 07:10:15.449872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 07:10:17.544330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 07:10:21.410558
# Unit test for constructor of class LookupModule
def test_LookupModule():

    args = {}
    args['_templar'] = '_templar'

    # Constructor for LookupModule class
    lm = LookupModule()

    term = 'term'
    lm.run([term], args)

# Generated at 2022-06-21 07:10:24.367777
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_mod = LookupModule()
    print('Test passed')


# Generated at 2022-06-21 07:10:36.455865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit tests request ValueError exception from method run
      of class LookupModule when one of the terms is not a string.

    :return: 0 if tests passed
    """
    from ansible import errors
    import pytest

    LUM = LookupModule()

    test_terms = ['hello']
    test_vars = {
        'hello': 'world',
        'other_var': 'value'
    }
    test_kwargs = dict(
        default='default'
    )

    LUM.run(terms=test_terms, variables=test_vars, **test_kwargs)

    test_terms = [12]

    with pytest.raises(errors.AnsibleError):
        LUM.run(terms=test_terms, variables=test_vars, **test_kwargs)

# Generated at 2022-06-21 07:10:38.631757
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor for class LookupModule
    LookupModule()



# Generated at 2022-06-21 07:10:39.891963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert type(LookupModule) is type

# Generated at 2022-06-21 07:10:40.678240
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:10:58.747067
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing that args are initialized
    l = LookupModule()
    assert l.set_options == LookupBase.set_options
    assert hasattr(l._templar, 'available_variables')
    assert l.get_option == LookupBase.get_option

# Generated at 2022-06-21 07:11:05.751255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_instance = LookupModule()
    assert ['Hello', 'Andy'] == LookupModule_instance.run(['myvar', 'name'], {'myvar': 'Hello', 'name': 'Andy'})
    assert ['Hello'] == LookupModule_instance.run(['myvar'], {'myvar': 'Hello', 'name': 'Andy'})
    assert ['Andy'] == LookupModule_instance.run(['name'], {'myvar': 'Hello', 'name': 'Andy'})
    #assert ['Andy'] == LookupModule_instance.run('name', {'myvar': 'Hello', 'name': 'Andy'})
    #assert ['Hello', 'Andy'] == LookupModule_instance.run(['myvar', 'name'], {'myvar': 'Hello', 'name': 'Andy'})

# Generated at 2022-06-21 07:11:17.600696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['Ansible_Play_Hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    # test with variables

# Generated at 2022-06-21 07:11:27.009698
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit tests are run against the class methods, so instantiate the class
    assert LookupModule.run

    # Instantiate the templar so we can use it in the tests
    look = LookupModule()

    # First set the instance properties
    look._templar = Templetor()

    # First test, no variable defined
    try:
        look.run(['foo'], variables={}, **{})
    except AnsibleUndefinedVariable as e:
        assert isinstance(e, AnsibleUndefinedVariable)
    else:
        assert False
    # Second test, variable defined
    assert look.run(['foo'], variables={'foo': 'bar'}, **{}) == ['bar']

    # Third test, variable prefixed with hostname

# Generated at 2022-06-21 07:11:36.276811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for the method run for ansible LookUpModule

    """
    mymodule = LookupModule()
    # Testing with undefined variable
    terms = [ 'variablename' ]
    variablename = 'hello'
    variables = dict()
    variables['variablename'] = variablename
    kwargs = dict()
    ret = mymodule.run(terms, variables)
    assert ret == None
    # Testing with defined variable
    terms = [ 'variablename', 'test']
    variables = dict()
    variables['variablename'] = variablename
    variables['test'] = 'test'
    ret = mymodule.run(terms, variables)
    assert ret == ['hello', 'test']

# Generated at 2022-06-21 07:11:43.484603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of the lookup plugin class
    lookup = LookupModule()

    # From this we could test the lookup plugin class methods
    assert lookup is not None

    # Test the method run of class LookupModule
    # When the variable given is not match in the template
    # then it should raise AnsibleError
    try:
        lookup.run([{"test_data": 0}], variables={'test_data': 1})
        assert False
    except AnsibleError as e:
        assert "Unable to look up a name or access an attribute" in str(e)

    # When the variable given is 'None'
    # then it should raise a AnsibleError

# Generated at 2022-06-21 07:11:55.293300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_results(**kwargs):
        templar = DummyVars()
        lookup_module = LookupModule(templar)
        return lookup_module.run(terms=terms, variables=variables, **kwargs)

    # with undefined variables
    terms = ['variablename', 'variablnotename']
    variables = {}

    result = get_results(default='')
    assert not result[0]
    assert not result[1]

    # with default=None
    result = get_results(default=None)
    assert not result[0]
    assert not result[1]

    # without default
    result = get_results()
    assert result[0] == 'hello'
    assert not result[1]


# Generated at 2022-06-21 07:11:57.579968
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None, None)

# Generated at 2022-06-21 07:12:08.487146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    import ansible.context

    template_data = {
        'inventory_hostname': 'localhost',
        'group_names': ['all', 'ungrouped'],
        'hostvars': {
            'localhost': {
                'ansible_fqdn': 'localhost',
                'ansible_host': '127.0.0.1',
            }
        }

    }

    variables = combine_vars(template_data, {})
    templar = Templar(loader=None, variables={}, shared_loader_obj=ansible.context._loader)
    templar._available_

# Generated at 2022-06-21 07:12:13.389136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(['hostvars', 'inventory_hostname'], variables=dict(hostvars=dict(some_value='some_value')), inventory_hostname='xyz')
    assert [{'some_value': 'some_value'}, 'xyz'] == result

# Generated at 2022-06-21 07:12:39.560825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    hostvars = {'hostvars': {'inventory_hostname': {'ansible_play_hosts': 'ansible_play_hosts', 'ansible_play_batch': 'ansible_play_batch',
                                                    'ansible_play_hosts_all': 'ansible_play_hosts_all'}}}
    templar = AnsibleUnicode()
    lookup_module = LookupModule()
    output = lookup_module.run(terms, hostvars)
    assert isinstance(output, list)
    assert len(output) == 3

# Generated at 2022-06-21 07:12:41.375448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    myvars = {}
    lookup._templar._available_variables = myvars
    lookup.set_options(var_options=myvars, direct={})

    assert lookup is not None


# Generated at 2022-06-21 07:12:52.365492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Dummy class for testing
    class DummyTemplate(object):
        def __init__(self):
            self._available_variables = {
                'inventory_hostname': 'testHostname',
                'hostvars': {
                    'testHostname': {
                        'ansible_play_hosts': 'testHosts',
                        'ansible_play_batch': 'testBatch',
                        'ansible_play_hosts_all': 'testHostsAll',
                    }
                }
            }

        def template(self, value, fail_on_undefined):
            return value

    dummy_template = DummyTemplate()
    lookupModule = LookupModule()
    lookupModule._templar = dummy_template
    lookupModule.set_options(var_options={}, direct={})

    # Test 1: Test for

# Generated at 2022-06-21 07:12:54.610496
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    return obj

# Generated at 2022-06-21 07:12:55.451969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:13:00.797966
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Verify that the constructor of LookupModule
    # raises an exception if not provided
    # with proper arguments
    #
    # Arrange
    # Act
    #
    # Assert
    try:
        lu = LookupModule()
    except:
        None
    else:
        assert False, 'Unexpected success'

# Generated at 2022-06-21 07:13:13.774084
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class DummyTemplar(object):
        class NoValue(object):
            pass

        # A variable is available if the variable has been assigned a value other than
        # NoValue.
        def __init__(self, vars):
            self._vars = vars
            self.available_variables = self.vars()

        def vars(self):
            # A variable is available if the variable has been assigned a value other than
            # NoValue.
            return dict((k, v) for k, v in self._vars.items() if v is not self.NoValue)

        def template(self, value, fail_on_undefined=True):
            # Return value.
            return value

    def assertListEqual(list1, list2):
        assert len(list1) == len(list2)

# Generated at 2022-06-21 07:13:22.642250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case using undefined variables
    from ansible.plugins.lookup import LookupModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible import context
    from ansible.utils.vars import combine_vars

    lookup = LookupModule()
    loader = DataLoader()
    variable_manager = VariableManager()

    variables = combine_vars(loader.load_from_file('tests/vars/var.yml'),
                             loader.load_from_file('tests/vars/include_var.yml'))

    context.CLIARGS = {}
    context.CLIARGS['lookup_plugin'] = 'default'

    terms = ['ansible_os_family']

# Generated at 2022-06-21 07:13:23.652886
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:13:35.441754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    assert [12, 12, 12] == lookup_instance.run(terms=['variablename.sub_var', 'variablename.sub_var', 'variablename.sub_var'], variables={'variablename': {'sub_var': 12}})
    assert [12, 12, 12] == lookup_instance.run(terms=['variablename.sub_var', '{{ variablename.sub_var }}', '{{ variablename.sub_var }}'], variables={'variablename': {'sub_var': 12}})

# Generated at 2022-06-21 07:14:00.456413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyLookupModule(LookupModule):

        def __init__(self):
            self._templar = DummyTemplar()

    # myvars = {'ansible_play_hosts': [u'192.168.1.1', u'192.168.1.2'], 'ansible_play_batch': u'0:1', 'ansible_play_hosts_all': [u'192.168.1.3', u'192.168.1.1', u'192.168.1.2']}

# Generated at 2022-06-21 07:14:09.408546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['variablename', 'myvar'], {'variablename': 'hello', 'myvar': 'ename'}) == ['hello', 'ename']
    assert LookupModule().run(['variablename', 'notexists'], {'variablename': 'hello', 'myvar': 'ename'}) == ['hello']
    assert LookupModule().run(['variablename', 'myvar'], {'variablename': 'hello'}) == ['hello']


# Generated at 2022-06-21 07:14:11.407505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run test script, makes sure code is not syntax error
    assert True

# Generated at 2022-06-21 07:14:22.569357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Test code path 1: simple variable
    terms = ['variable_name']
    variables = {'variable_name': 'value'}
    assert module.run(terms, variables=variables) == ['value']
    # Test code path 2: variable is undefined by no default provided
    terms = ['variable_name']
    variables = {}
    try:
        module.run(terms, variables=variables)
        assert False
    except AnsibleUndefinedVariable:
        assert True
    # Test code path 3: variable is undefined with a default provided
    terms = ['variable_name']
    variables = {}
    assert module.run(terms, variables=variables, default='default value') == ['default value']
    # Test code path 4: list input
    terms = ['variable_name']

# Generated at 2022-06-21 07:14:34.214876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # pylint: disable=no-self-use
    from ansible.module_utils.six import PY3


# Generated at 2022-06-21 07:14:35.954852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 07:14:44.373390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class FakeVars:
        available_variables = {'hostvars': {'host': {'a': 1, 'b': 2, 'c': 3}}}
        def template(self, content, fail_on_undefined=True):
            return content

    # test without fail on undefined variables
    lookup = LookupModule()
    lookup._templar = FakeVars()
    assert lookup.run(['a'], variables={'a': 1}) == [1]
    assert lookup.run(['b', 'a'], variables={'b': 2, 'a': 1}) == [2,1]
    assert lookup.run(['a', 'c'], variables={'c': 3, 'a': 1}) == [1,3]
    # test with fail on undefined variables

# Generated at 2022-06-21 07:14:46.201838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-21 07:14:56.711168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    options = dict()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["127.0.0.1,"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='127.0.0.1',
        gather_facts='no',
        tasks=[]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    # Variable definitions
    # Ansible variables

# Generated at 2022-06-21 07:15:01.499100
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Verify LookupModule is a subclass of LookupBase
    assert(issubclass(LookupModule, LookupBase))
    term = 'variablename'
    lookup_module = LookupModule()
    # Verify answer from run()
    print(lookup_module.run(terms=term))

# Generated at 2022-06-21 07:15:32.494802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 07:15:46.109856
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test preparing myvars
    myvars = {'foo': 'bar', 'bam': 'baz'}
    lookup._templar.available_variables = myvars
    assert lookup._templar._available_variables == myvars, "Preparing myvars failed"
    # Test vars_files
    vars_files = ['f1', 'f2']
    lookup.set_options({'vars_files': vars_files})
    assert lookup._options['vars_files'] == vars_files, "Setting vars_files failed"
    # Test direct
    direct = {'bim': 'bab'}
    lookup.set_options({'direct': direct})
    assert lookup._options['direct'] == direct, "Set direct failed"
    #

# Generated at 2022-06-21 07:15:47.792679
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("declare a LookupModule object:")
    lookup1 = LookupModule()
    print(lookup1)



# Generated at 2022-06-21 07:15:52.574453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert(t._templar.available_variables is not None)

# Generated at 2022-06-21 07:15:57.381040
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert isinstance(lu, LookupModule)
    assert isinstance(lu, LookupBase)


# Generated at 2022-06-21 07:16:04.931808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize LookupModule test object
    lm = LookupModule()
    # Initialize params
    lm.set_options()
    lm._templar = AnsibleUndefinedVariable
    # Instantiate test variables
    terms = ['test']
    variables = {'test': 'Test variable'}

    # Test when variables are provided
    ret_value = lm.run(terms, variables)
    assert ret_value == ['Test variable']

    # Test when variables are not provided
    ret_value = lm.run(terms)
    assert ret_value == []



# Generated at 2022-06-21 07:16:17.717238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    config = "hostvars:\n"+ \
             "\n  ".join(["host_%d: {key: val}" % i for i in range(1,10)])
    config += "\n" + \
              "\ninventory_hostname: host_1"
    # Check that we only have `host_1` in the available variables
    look = LookupModule()
    look.run(terms=["key"], variables={"hostvars": {}, "inventory_hostname": "host_1"})
    # Check that we have all `host_*` variables in the available variables
    look = LookupModule()
    look.run(terms=["key"], variables={"hostvars": {}, "inventory_hostname": "host_1", "key": "val"})
    # Check that we have all `host_*`

# Generated at 2022-06-21 07:16:24.936948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    terms = ['foo']
    variables = {'foo': 'bar'}
    test_object.run(terms, variables=variables)
    assert test_object._templar.template(variables['foo']) == 'bar'

# Generated at 2022-06-21 07:16:35.641511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    import __builtin__ as builtins

    module = LookupModule()
    terms = ['show_stdout_callback', 'show_custom_callback']
    variables = {
        'show_stdout_callback': 'False',
        'show_custom_callback': 'True',
    }
    results = module.run(terms, variables)
    assert results == ['False', 'True'], results

# Generated at 2022-06-21 07:16:45.965426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.get_option = stub_get_option
    lookup_plugin.set_options = stub_set_options
    lookup_plugin._templar = stub_AnsibleTemplar()
    lookup_plugin._templar._available_variables = stub_available_variables()
    lookup_plugin._templar.template = stub_template

    terms = ['some_variable', 'some_other_variable', 'some_unknown_variable']
    variables = {}
    kwargs = {}
    result = lookup_plugin.run(terms, variables, **kwargs)
    assert result == ['some_value', 'some_other_value', 'some_value'], 'Result should be ["some_value", "some_other_value", "some_value"]'


# Stubs for

# Generated at 2022-06-21 07:17:53.937733
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    import os
    test_dir='/var/tmp/ansible'
    test_file='test_2.yml'
    os.makedirs(test_dir)
    with open(test_dir + '/'+ test_file, 'w') as outfile:
        json.dump("test: test", outfile)
    lkm = LookupModule()

# Generated at 2022-06-21 07:18:08.133447
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    # Create the mock of the context
    play_context = PlayContext()

    # Create the lookup module
    lookup_module = LookupModule()

    # Create a mock of the templar and assign to the lookup module
    # The mock object must be automatically created recursively (spec=True)
    lookup_module._templar = create_autospec(lookup_module._templar, spec=True)

    # Create the mock of the available variables and assign to the lookup module through the templar
    # The mock object must be automatically created recursively (spec=True)

# Generated at 2022-06-21 07:18:17.845357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # Simple run
    ret = lm.run(['inventory_file'])
    assert ret == ['']

    # Bad term
    try:
        ret = lm.run([3])
    except AnsibleError as e:
        assert "Invalid setting identifier" in str(e)

    # Default
    #ret = lm.run(['inventory_file', 'inventory_test'], default='')
    #assert ret == ['', '']

# Generated at 2022-06-21 07:18:22.124390
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 07:18:23.648164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-21 07:18:25.161822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 07:18:33.866774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test the case where the term argument is empty
    lookup_module=LookupModule()
    assert lookup_module.run([], []) == []

    # Test the case where the term argument is not empty
    # but the value of the variable is not found
    lookup_module=LookupModule()
    assert lookup_module.run(['myvar'], []) == []

    # Test the case where the term argument is not empty
    # and the value of the variable is found
    lookup_module=LookupModule()
    assert lookup_module.run(['myvar'], [{'myvar':12}]) == [12]

# Generated at 2022-06-21 07:18:42.453203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_terms = ['test', 'test1', 'test2']
    input_variables = {'test': 'test_variable', 'test1': {'test2': 'test_variable_1'}}
    lookup_base_object = LookupModule()
    lookup_base_object._templar._available_variables = input_variables
    lookup_base_object._templar.available_variables = input_variables

    lookup_base_object.set_options(var_options=input_variables, direct={'default':'test_default'})
    lookup_base_object.get_option('default')

    result = lookup_base_object.run(input_terms,input_variables)
    assert result == ['test_variable', 'test_variable_1']


# Generated at 2022-06-21 07:18:50.757597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create object of this class.
    lookup = LookupModule()
    
    # Test what happens with terms not being a string.
    terms = [1,2,3]
    
    # Check if exception is raised.
    try:
        lookup.run(terms)
    except AnsibleError:
        pass
    else: 
        raise Exception("Test failed.")