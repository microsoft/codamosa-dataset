

# Generated at 2022-06-21 07:08:49.708696
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.get_option("default") is None

# Generated at 2022-06-21 07:08:52.193074
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None


# Generated at 2022-06-21 07:09:02.569522
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.template import Templar
    from ansible.template import display
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.display import Display
    import os


# Generated at 2022-06-21 07:09:10.172371
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a class for mocking the method vars which returns the value of the variable.
    class MockTemplar:
        def __init__(self):
            self._available_variables = {}

        def _init__available_variables(self, hostvars, hostname, term, value):
            self._available_variables = {
                'hostvars': hostvars,
                'inventory_hostname': hostname,
                term: value,
            }

        def _init__available_variables_no_hostvars(self, hostname, term, value):
            self._available_variables = {
                'inventory_hostname': hostname,
                term: value,
            }

        def _init__available_variables_one_term(self, hostvars, hostname, value):
            self._available_

# Generated at 2022-06-21 07:09:17.319047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create a fake inventory
    class FakeInventory:
        def __init__(self):
            # set some vars
            self.vars = {"name" : "Hello World"}
            self.vars["empty_var"] = False

    lookup = LookupModule()
    assert lookup._templar.available_variables["name"] == "Hello World"
    assert lookup._templar.available_variables["empty_var"] == False

# Generated at 2022-06-21 07:09:30.311067
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Set up a test object (simulate Ansible)
    class Ansible(object):
        class Template(object):
            pass

    class Utils(object):
        pass

    class Options(object):
        def __init__(self):
            self.module_name = 'test'

    test = Ansible()
    test.template = Ansible.Template()
    test.template._utils = Utils()
    test.template._options = Options()

    # Instantiate LookupModule
    lookup_module = LookupModule()
    # Create a class with a fake 'run' method
    class FakeCaller(object):
        def run(self, *args, **kwargs):
            self.run_called = True
            self.run_args = args
            self.run_kwargs = kwargs
            return []

    fake

# Generated at 2022-06-21 07:09:43.357808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.vars import LookupModule

    lookup = LookupModule()
    terms = [
        'my_var',
        'my_other_var',
        'my_nested_var.sub_var',
        'hostvars.hostname.host_var'
    ]

    variables = {
        'my_var': '12',
        'hostvars': {
            'hostname': {
                'host_var': 'host_value'
            }
        },
        'my_nested_var': {
            'sub_var': 'my_sub_value'
        },
    }

    options = {
        'default': None,
    }

    res = lookup.run(terms=terms, variables=variables, **options)

# Generated at 2022-06-21 07:09:44.863890
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookupModule_init = LookupModule()
    if test_lookupModule_init is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-21 07:09:52.419600
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Init
    lookup_module = LookupModule()
    templar = DummyVarTemplate()
    lookup_module._templar = templar

    # Call lookup_module.run()
    templar._available_variables = { 'a' : 1, 'b' : 2, 'c' : '3', 'd' : (4,) }
    result = lookup_module.run(terms=['a', 'b', 'c', 'd'])

    # Assertion
    assert result == [1, 2, '3', (4,)]


# Generated at 2022-06-21 07:10:01.844508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    lookup = LookupModule()
    lookup._templar = loader.load('')

    # It should return an empty array if nothing matches
    assert lookup.run(['vars_not_defined']) == []

    # And it should return the object value if it matches
    # with a simple value
    assert lookup.run(['vars_not_defined', 'vars_defined']) == [{'msg': 'hello world'}]

    # And it should return the object value if it matches
    # with a dict value

# Generated at 2022-06-21 07:10:13.535535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    templar = Templar(loader=loader, variables={'inventory_hostname': 'myhost'})
    lookup_plugin_vars = LookupModule(basedir=None, runner=None, templar=templar)

    # Retrieve a variable defined in the global variable set
    my_var = lookup_plugin_vars.run([listify_lookup_plugin_terms("var")])
    assert my_var == ['global_var_value']
    assert my_var[0] == 'global_var_value'

    # Retrieve

# Generated at 2022-06-21 07:10:23.937554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._templar = {'_available_variables': {"manageiq_miq_api_token": "408908b225a5d8495d85dafc55b28f4db4e845ca", "manageiq_url": "https://10.0.0.60/api"}}
    lookup_module.run(terms=["manageiq_miq_api_token"])
    lookup_module.run(terms=["manageiq_miq_api_token1"])
    lookup_module.run(terms=['10', '20'])

# Generated at 2022-06-21 07:10:36.458356
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    MyVars = {
        'foo': 'bar',
        'bar': 'baz',
        'foo_bar': 'baz',
        'first.second': 'baz',
        'first_second': 'baz',
        'first@second': 'baz',
        'a-b-c': 'd',
        'a_b_c': 'd'
    }

    # test lookup with no defaults
    results = LookupModule().run(['foo', 'bar'], variables=MyVars)
    assert results == ['bar', 'baz']

    # test lookup with defaults
    results = LookupModule().run(['foo', 'fop'], variables=MyVars, default='default')
    assert results == ['bar', 'default']

    # test lookup with dotted path

# Generated at 2022-06-21 07:10:37.957337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 07:10:46.257468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(object):
        def __init__(self, fail_on_undefined=True):
            self.fail_on_undefined = fail_on_undefined

        def __getitem__(self, item):
            from ansible.vars.hostvars import HostVars
            from ansible.vars.unsafe_proxy import UnsafeProxy
            from ansible.parsing.dataloader import DataLoader
            if item == 'inventory_hostname':
                return 'test_hostname'
            elif item == 'hostvars':
                return HostVars(UnsafeProxy(dict({'test_hostname':{'a':'test_a'}}), DataLoader()))
            else:
                return {'a':'test_a'}

    myvars = TestLookupModule()

# Generated at 2022-06-21 07:10:57.416475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    variables = {"hostvars": { "localhost": { "variable1": "value1" } }}
    
    # test for valid input
    terms = ['variable1']
    result = lookup_module_obj.run(terms, variables)
    assert result == ['value1']

    # test for invalid input
    terms = ['variable2']
    try:
        result = lookup_module_obj.run(terms, variables)
    except AnsibleUndefinedVariable as e:
        assert True

    # test for default value
    terms = ['variable2']
    default = 'default value'
    result = lookup_module_obj.run(terms, variables, default=default)
    assert result == [default]

# Generated at 2022-06-21 07:11:10.930727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['test', 'test2']

    # Test case:  function LookupModule.run throw Exception
    # Input:
    # terms = ['a', 1]
    # Expected:
    # ansible.errors.AnsibleError: Invalid setting identifier, "1" is not a string, its a <type 'int'>
    try:
        LookupModule().run(terms=[1], variables=['a'])
        assert False, "ansible.errors.AnsibleError not raised"
    except AnsibleError as e:
        assert 'Invalid setting identifier' in e.message

    # Test case: function LookupModule.run throw Exception
    # Input:
    # terms = ['a', 'a']
    # Expected:
    # ansible.errors.AnsibleUndefinedVariable: No variable found with this name: a


# Generated at 2022-06-21 07:11:24.370783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    assert test.run(['']) == []
    assert test.run('') == []
    assert test.run([], variables={'variable': '42'}) == []
    assert test.run('variable', variables={'variable': '42'}) == ['42']
    assert test.run('', variables={'variable': '42'}) == ['']
    assert test.run([], variables={'variable': 0}) == []
    assert test.run('variable', variables={'variable': 0}) == [0]
    assert test.run('', variables={'variable': 0}) == ['']
    assert test.run('variable', variables={}, default='42') == ['42']
    assert test.run('', variables={}, default='42') == ['42']

# Generated at 2022-06-21 07:11:32.666894
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test initialization of class
    l = LookupModule()
    l.set_options(var_options={'test': 'vars'}, direct={'test2': 'test2'})
    assert l._templar._available_variables == {'test': 'vars'}
    assert l._options == {'var_options': {'test': 'vars'}, 'direct': {'test2': 'test2'}}


# Generated at 2022-06-21 07:11:35.426849
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

# Generated at 2022-06-21 07:11:46.376151
# Unit test for constructor of class LookupModule
def test_LookupModule():

    import ansible.plugins.lookup.vars
    lookup = ansible.plugins.lookup.vars.LookupModule()
    assert(lookup)


# Generated at 2022-06-21 07:11:48.248724
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run

# Generated at 2022-06-21 07:11:50.688258
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert a.run([]) == []
    assert isinstance(a, LookupBase)

# Generated at 2022-06-21 07:11:53.637540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None)

# Generated at 2022-06-21 07:12:03.426116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule.run(
        [
            'variablename',
            'variablenotename',
        ], 
        variables={
            'variablename': 'hello',
            'myvar': 'notename',
            'myvar2': 'ename',
            'variablenotename': 'bye'
        }
    )
    assert ret[0]=='hello'
    assert ret[1]=='bye'


# Generated at 2022-06-21 07:12:05.490647
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = [ '1' ]
    assert data == LookupModule().run(data)

# Generated at 2022-06-21 07:12:16.078004
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']

    variable_manager = DummyVars()

    instance = LookupModule()
    instance._templar = variable_manager

    result = instance.run(terms, variables=variable_manager._available_variables, default=None)

    assert result == variable_manager._available_variables['ansible_play_hosts']
    assert result == variable_manager._available_variables['ansible_play_batch']
    assert result == variable_manager._available_variables['ansible_play_hosts_all']


# Generated at 2022-06-21 07:12:28.905192
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils.common.text.template import AnsibleTemplate
    from ansible.module_utils.six import PY3

    if PY3:
        try:
            import unittest.mock as mock
        except ImportError:
            import mock

        mock_templar = mock.MagicMock(spec_set=AnsibleTemplate)
        mock_templar.available_variables = {}
        mock_templar._available_variables = {}
    else:
        import mock
        mock_templar = mock.MagicMock(spec_set=AnsibleTemplate)

    lookup_vars = LookupModule(loader=None, templar=mock_templar)

    assert mock_templar == lookup_vars._templar

# Generated at 2022-06-21 07:12:29.710182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.run(["system"], [])

# Generated at 2022-06-21 07:12:31.114133
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()

# Generated at 2022-06-21 07:12:51.847392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    lookup = LookupModule()
    loader = mock.MagicMock()
    loader._templar = templar.Templar(loader=loader, variables={})
    loader._templar._available_variables = {
        'inventory_hostname': 'myhostname.example.com',
        'hostvars': {
            'myhostname.example.com': {
                'testvar': 'testval'
            }
        }
    }
    lookup.set_loader(loader)

    testval = lookup.run(['testvar'], variables=None, default=None)
    assert testval == ['testval']
    testval = lookup.run(['testvar'], variables=None, default='testval2')

# Generated at 2022-06-21 07:12:55.294685
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module is not None)


# Generated at 2022-06-21 07:13:04.593087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Test setup, create a lookup object and add some variables to variable manager
    index_file = loader.path_dwim_relative(None, 'hosts', 'test_inventory.yml')
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[index_file])
    variable_manager.set_inventory(inventory)
    # Test all options
    lookup_obj = LookupModule()

    # Test terms with all valid data
    terms = [('foo', 'bar')]

# Generated at 2022-06-21 07:13:10.838707
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    terms = 'test_lookup'
    variables = {'test_lookup': 'test_lookup'}
    kwargs = {'default': 'test_lookup'}
    module.run(terms, variables, **kwargs)

# Generated at 2022-06-21 07:13:21.802052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m1 = LookupModule()
    terms = ['variablename', 'no_such_var']
    my_var = 'ename'
    variables = {'variablename': 'hello', 'myvar': my_var}
    result = m1.run(terms, variables)
    assert result == ['hello', None]

    m2 = LookupModule()
    default = ''
    variables = {'variablename': 'hello', 'myvar': my_var}
    result = m2.run(terms, variables, default=default)
    assert result == ['hello', '']

# Generated at 2022-06-21 07:13:23.777717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj

# Generated at 2022-06-21 07:13:25.949394
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(['foo'])

# Generated at 2022-06-21 07:13:36.123601
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    my_cls = LookupModule()

# Generated at 2022-06-21 07:13:39.371885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(["item1", "item2", "item3"], variables={"item2": 3})

# Generated at 2022-06-21 07:13:41.048885
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    test_lookup_module = LookupModule()
    assert test_lookup_module != None

# Generated at 2022-06-21 07:14:19.795864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # init var
    myvars = {'inventory_hostname': 'foo', 'hostvars': {'foo': {'ansible_play_hosts': ['a', 'b'], 'ansible_play_batch': ['aa', 'bb']}}}
    # call function
    lookup_plugin = LookupModule()
    lookup_plugin.set_options({'var_options': myvars})
    result = lookup_plugin.run([['ansible_play_hosts', 'ansible_play_batch']], myvars)
    # test result
    assert result == [['a', 'b'], ['aa', 'bb']]


# ---------------------------

# Generated at 2022-06-21 07:14:30.907899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with hostvars variables
    lookup_plugin = LookupModule()
    lookup_plugin._templar = MagicMock()
    lookup_plugin._templar._available_variables = dict()
    lookup_plugin._templar._available_variables['hostvars'] = dict()
    lookup_plugin._templar._available_variables['hostvars']['myhost'] = dict()
    lookup_plugin._templar._available_variables['hostvars']['myhost']['myvar'] = 'my value'
    lookup_plugin._templar._available_variables['inventory_hostname'] = 'myhost'
    assert lookup_plugin.run(['myvar']) == ['my value']

    # Test with fake modules
    lookup_plugin = LookupModule()
    lookup_plugin._

# Generated at 2022-06-21 07:14:35.783084
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This test module is to check the correctness of class
    LookupModule by using constructor.
    """
    # test with set_options
    # test with get_option
    pass

# Generated at 2022-06-21 07:14:39.705417
# Unit test for constructor of class LookupModule
def test_LookupModule():
     x = LookupModule()
     print (x)

# test_LookupModule()

# Generated at 2022-06-21 07:14:49.846090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()
    terms = ['variablename', 'myvar', 'variablnotename']

    my_test_vars = {
        "variablename": "hello",
        "myvar": "ename",
        "variablenotename": "hi"
    }

    expected_result = ["hello", "hi"]

    final_result = L.run(terms, variables=my_test_vars, default="")
    assert final_result == expected_result

# Generated at 2022-06-21 07:15:02.681125
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup
    var_settings = dict(ansible_play_hosts=[], ansible_play_batch=[], ansible_play_hosts_all=[])
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    expected_result = [[], [], []]
    my_LookupModule = LookupModule()
    my_LookupModule.environment = dict()
    my_LookupModule.runner = dict()
    my_LookupModule._templar = dict()
    my_LookupModule._templar._available_variables = var_settings

    # Test
    result = my_LookupModule.run(terms, variables=var_settings)

    # Verify
    assert result == expected_result

# Generated at 2022-06-21 07:15:16.026445
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check if method run returns the value of the variable if it is defined in the inventory.
    # Expected result: the value of the variable.
    assert LookupModule().run(terms = ['ansible_connection']) == ['local']

    # Check if method run returns the default value if the variable is not defined in the inventory.
    # Expected result: the default value or an empty string.
    assert LookupModule().run(terms = ['foo'], variables=dict(roles=[])) == ['']

    # Check if method run returns the value of the top level variable if it is defined in the inventory.
    # Expected result: the value of the variable.
    assert LookupModule().run(terms = ['foo'], variables=dict(roles=[], foo='bar'), default='default') == ['bar']

    # Check if method run returns the

# Generated at 2022-06-21 07:15:17.428359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 07:15:21.189631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: Write tests for constructor of class LookupModule, if necessary
    assert True # "TODO: Write tests for constructor of class LookupModule"


# Generated at 2022-06-21 07:15:27.587754
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test cases #1
    from ansible.plugins.lookup.vars import LookupModule
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class TestLookupModule(ModuleTestCase):

        def setUp(self):
            self.mock_AnsibleExitJson = patch.multiple(basic.AnsibleModule, exit_json=exit_json(), fail_json=fail_json())
            self.mock_AnsibleExitJson.start()

# Generated at 2022-06-21 07:16:33.152764
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test creating the LookupModule instance for variable names 'host' and 'hostvars', with three defaults
    lm = LookupModule()
    lm._templar._available_variables = {'host': 1}
    lm._templar._available_variables['hostvars'] = {'localhost': {'host': 2}}
    assert lm.run(['host','hostvars','host'])==[1, {'localhost': {'host': 2}}, 1]

    # Test with invalid variable identifier 'invalid_var'
    try:
        lm.run(['invalid_var'])
        assert "The above line should fail and this line should not be reached."
    except AnsibleError:
        pass

    # Test with only one of the variable names being defined in _templar._available_variables

# Generated at 2022-06-21 07:16:42.803918
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case 1
    test_class = LookupModule()
    class TestVars:
        def __init__(self, myvars):
            self._available_variables = myvars

    class TestTemplar:
        def __init__(self):
            pass

        def template(self, value, fail_on_undefined=True):
            return value

    class TestVariables:
        def __init__(self, hostvars, inventory_hostname):
            self.hostvars = hostvars
            self.inventory_hostname = inventory_hostname

    variables_obj = TestVariables(hostvars={'host':{'host_var': 'host_var_value'}}, inventory_hostname='host')
    vars_obj = TestVars({'variablename': 'hello'})


# Generated at 2022-06-21 07:16:44.847326
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return (lookup_module)


# Generated at 2022-06-21 07:16:50.286349
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Set-up for test
    lookup_module = LookupModule()

    # Check that constructor is working
    assert lookup_module != None

# Generated at 2022-06-21 07:16:51.708810
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Ensure class was created
    assert LookupModule is not None

# Generated at 2022-06-21 07:17:00.402709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils.six import string_types

    assert LookupModule.run.__doc__ == '''Retrieves the value of an Ansible variable.
    Note: Only returns top level variable names.'''

    # terms as None
    lmodule = LookupModule()
    try:
        assert lmodule.run(terms=None) == []
        assert False
    except AnsibleError as e:
        assert str(e) == 'One or more required arguments have not been provided.'

    # terms as list of non-string
    lmodule = LookupModule()

# Generated at 2022-06-21 07:17:12.837511
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    from ansible.module_utils.six import PY3
    from ansible.plugins.lookup import LookupBase

    if PY3:
        unicode = str

    class DummyLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return [u'foo', u'bar']

    lookup_instance = DummyLookupModule()

    assert isinstance(lookup_instance, DummyLookupModule)
    assert isinstance(lookup_instance, LookupBase)
    assert lookup_instance.run(terms=None) == [u'foo', u'bar']

    if not PY3:
        assert isinstance(lookup_instance.run(terms=None)[0], unicode)


# Generated at 2022-06-21 07:17:24.413113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # Unit test for class LookupModule: method run without a default value
    myvars = {'hostvars': {'hostname': {'a': '10', 'c': '12'}}, 'b': '11', 'inventory_hostname': 'hostname'}
    terms = ['hostvars', 'a', 'inventory_hostname', 'b', 'c']
    result = lookup_plugin.run(terms, myvars)
    assert result == [{'hostname': {'a': '10', 'c': '12'}}, '10', 'hostname', '11', '12']

    # Unit test for class LookupModule: method run with a default value

# Generated at 2022-06-21 07:17:28.360037
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    LookupModule Constructor test
    :return:
    """
    LookupModule()

# Generated at 2022-06-21 07:17:30.422956
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)