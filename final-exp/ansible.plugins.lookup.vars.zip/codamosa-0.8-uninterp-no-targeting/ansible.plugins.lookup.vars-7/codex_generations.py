

# Generated at 2022-06-21 07:08:55.291632
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create an instance of class LookupModule
    lookup_module = LookupModule()

    # call a method in this class
    terms = ['var1', 'var2', 'var3']
    ret = lookup_module.run(terms)
    # check value of ret
    assert ret == ret

# Generated at 2022-06-21 07:08:58.095329
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()  # default options are set in base class
    assert(obj is not None)
    assert(isinstance(obj, LookupModule))


# Generated at 2022-06-21 07:09:10.063528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path_to_this_file = os.path.dirname(os.path.abspath(__file__))
    templar = Templar(loader=DataLoader())
    lookup_obj = LookupModule(templar=templar, loader=templar._loader,  )
    terms = ["ansible_play_hosts", "ansible_play_batch", "ansible_play_hosts_all"]

# Generated at 2022-06-21 07:09:10.552977
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 07:09:20.319369
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Given a playbook code snippet, an ansible variable and the expected result
    # I test the run method of LookupModule.
    def _test_run(code, variable, expected_result):

        # Given a dict of variable name/values,
        # I create a fake playbook context
        def _get_play(vars=None):
            if not vars:
                vars = {}

            return {
                'vars': vars,
                'hostvars': {},
                'inventory_hostname': '',
            }

        # Given a dict of variable name/values,
        # I create a fake host context
        def _get_host(vars=None):
            if not vars:
                vars = {}

            return {
                'vars': vars,
            }

        # I cast the result of the

# Generated at 2022-06-21 07:09:28.765981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._templar = dict(
        _available_variables = dict(
            inventory_hostname = "mock.hostname",
        )
    )

    assert ["foo"] == lookup.run([
        "foo"
    ])

    assert [] == lookup.run([
        "foo",
    ], dict(), dict(default=""))

    assert ["foo"] == lookup.run([
        "foo",
    ], dict(), dict(default="foo"))


# Generated at 2022-06-21 07:09:33.498244
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-21 07:09:43.852903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing with valid data

    data = dict()
    data['_ansible_verbosity'] = 3
    data['inventory_dir'] = '/home/ec2-user/environment/ansible'
    data['playbook_dir'] = '/home/ec2-user/environment/ansible'
    data['inventory_file'] = '/home/ec2-user/environment/ansible/hosts'
    data['inventory_hostname'] = 'ip-172-31-19-9.us-east-2.compute.internal'
    data['inventory_hostname_short'] = 'ip-172-31-19-9'
    data['inventory_basedir'] = '/home/ec2-user/environment/ansible'
    data['playbook_basedir'] = '/home/ec2-user/environment/ansible'
   

# Generated at 2022-06-21 07:09:53.754275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert(l._templar.__class__.__name__ == 'Templar')
    assert(l._loader.__class__.__name__ == 'DataLoader')

    # test self._templar.available_variables
    arr_dict = {'var':'value'}
    l.run(terms=None, variables=arr_dict, **{'default':'default', 'var':'value'})
    assert(l._templar.available_variables == arr_dict)
    # test self.set_options() with 'var_options' and 'direct'
    assert(l._options.var_options == arr_dict)
    assert(l._options.default == 'default')
    assert(l._options.var == 'value')
    # test self.get_option

# Generated at 2022-06-21 07:09:58.783792
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test for the method run
    # Arrange
    terms = ['myvar']
    variables = {'myvar': 'hello'}

    lm = LookupModule()
    lm.set_loader(None)

    # Act
    results = lm.run(terms, variables)

    # Assert
    assert results == ['hello']

# Generated at 2022-06-21 07:10:13.664864
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ansi_templar = None
    lkmod = LookupModule(ansi_templar)
    test_terms = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
                  'aa','bb','cc','dd','ee','ff','gg','hh','ii','jj','kk','ll','mm','nn','oo','pp','qq','rr','ss','tt','uu','vv','ww','xx','yy','zz']

# Generated at 2022-06-21 07:10:23.852931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test "run" function of module
    # add all variables for the test
    host, port = "localhost", 22
    user, password = "ansible", "123456"
    protocol = "ssh"
    ssh = "ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no"

    ansible_ssh_host = "%s@%s" % (user, host)
    ansible_ssh_pass = password
    ansible_become_pass = None
    ansible_ssh_port = port
    ansible_ssh_private_key_file = None
    ansible_connection = "ssh"
    ansible_user = user
    ansible_python_interpreter = "/usr/lib/python2.7/dist-packages/ansible/modules"

    ansible_play_host

# Generated at 2022-06-21 07:10:28.435983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 07:10:39.807319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys

    # first, test with an existing variable
    lookup_obj = LookupModule()
    inventory_variables = dict(
        ansible_play_hosts=['a', 'b'],
        ansible_play_batch=['batch'],
        ansible_play_hosts_all=['all'],
    )
    terms = ['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']
    expected = [['a', 'b'], ['batch'], ['all']]
    result = lookup_obj.run(terms, inventory_variables)
    assert result == expected

    # second, test with a non-existing variable and default value is not set
    lookup_obj = LookupModule()

# Generated at 2022-06-21 07:10:43.056921
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert issubclass(LookupModule,LookupBase)
  assert isinstance(LookupModule(),LookupModule)

# Generated at 2022-06-21 07:10:45.934987
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 07:10:50.818554
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        test_LookupModule = LookupModule()
    except Exception as e:
        assert False, "Exception '%s' should not be raised" % str(e)
    else:
        assert True, "No exception raised"


# Generated at 2022-06-21 07:10:53.997962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 07:10:55.388090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 07:11:07.397874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockTemplar(object):
        def __init__(self, available_variables):
            self._available_variables = available_variables
            self._templar = None

        def template(self, value, fail_on_undefined):
            return value

    class MockAnsibleUndefinedVariable(AnsibleUndefinedVariable):
        def __init__(self,value):
            pass
            
    class MockAnsibleError(AnsibleError):
        def __init__(self, value):
            pass

    class MockLookupModule(LookupModule):

        def __init__(self, available_variables, templar=MockTemplar):
            self._available_variables = available_variables
            self._templar = templar(self._available_variables)


# Generated at 2022-06-21 07:11:16.168288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 07:11:25.313601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    vars = { "a": "1", "b": "2" }
    l = LookupModule(variables=vars)
    assert l._templar._available_variables == vars
    assert l.get_option('default') == None
    # The following commented block does not work as the function read_vars_from_file is not implemented.
    try:
        l.set_options(var_options={"a": "4", "c": "5"})
        # assert l._templar._available_variables == {"a": "4", "b": "2", "c": "5"}
    except NotImplementedError:
        assert True


# Generated at 2022-06-21 07:11:30.515686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    The following test is used to verify the test cases in the function `run`
    of class `LookupModule`.
    """
    # Replace the following parameters to test different input values
    terms = [
        "hello",
        "how"
    ]
    variables = None
    kwargs = {
        "default": None
    }
    ansible_module = AnsibleModule(argument_spec={})

    # Instantiate the class
    lookup_obj = LookupModule(ansible_module)

    # Get the return value
    ret = lookup_obj.run(terms, variables, **kwargs)

    # Print the return value
    pprint(ret)

    # Return the return value
    return ret

# Generated at 2022-06-21 07:11:40.693676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of LookupModule
    lookup = LookupModule()

    # Get value of variable 'host'
    # LookupModule.run(self, terms, variables=None, **kwargs)
    # (terms, variables=None, **kwargs)
    #
    # terms: The variable name to look up.
    # variables: If there is a variable 'host' exists, get its value.
    #
    # LookupModule._get_value_from_vars(self, terms, variables, **kwargs)
    # (terms, variables, **kwargs)
    #
    # terms: The variable name to look up.
    # variables: If there is a variable 'host' exists, get its value.
    #
    # LookupModule._get_name_from_templar(self, terms, variables, **kwargs

# Generated at 2022-06-21 07:11:44.895906
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()
    assert lookup_plugin.lookup_type == 'vars'

    assert isinstance(lookup_plugin.run(['test'], variables={'test':'test value'}), list)

# Generated at 2022-06-21 07:11:46.654698
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create class object
    c_instance = LookupModule()

    # Check if object exists
    assert isinstance(c_instance, LookupModule)


# Generated at 2022-06-21 07:11:56.977718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3, b
    from ansible.plugins.lookup.vars import LookupModule
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    host = AnsibleUnsafeText("host")
    my_host = AnsibleUnsafeText("my_host")
    templar = Templar(variables={"my_host" : host})
    myvars = { "inventory_hostname" : my_host }
    vars_manager = VariableManager(loader=None, inventory=None, use_cache=False)
    vars_manager

# Generated at 2022-06-21 07:12:05.998351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    lm.set_options(var_options={'test2':'test2_value'})

    res = lm.run(terms=['test1'], variables={'test1':'test1_value'})
    assert res == ['test1_value']

    res = lm.run(terms=['test2'], variables={'test1':'test1_value'})
    assert res == ['test2_value']

    # Test default
    res = lm.run(terms=['test1'], variables={'test1':'test1_value'}, default='test_default')
    assert res == ['test1_value']

    res = lm.run(terms=['test2'], variables={'test1':'test1_value'}, default='test_default')


# Generated at 2022-06-21 07:12:13.149722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_lookup_module = LookupModule()

    test_LookupModule_run_var_default = {
        'hostvars': {
            'host1': {
                'hostname': 'host1'
            },
            'host2': {
                'hostname': 'host2'
            }
        },
        'inventory_hostname': 'host1',
        'inventory_hostname_short': 'host1'
    }


# Generated at 2022-06-21 07:12:14.030062
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:12:39.479272
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_native

    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    assert lm.get_option('default') is None

    terms = ['undefinedvar1', 'undefinedvar2']
    with pytest.raises(AnsibleError) as e:
        lm.run(terms)
    assert 'No variable found with this name: undefinedvar1' in to_native(e.value)

    terms = ['undefinedvar1', 'undefinedvar2']
    variables = dict(undefinedvar1='definedvar1')
    ret = lm.run(terms, variables)
    assert ret == ['definedvar1']

    variables = dict(undefinedvar1=dict(sub_var=12))

# Generated at 2022-06-21 07:12:41.108417
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret =  LookupModule()
    assert ret

# Generated at 2022-06-21 07:12:49.984582
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None, variables=combine_vars(None, dict()))

    l = LookupModule()

    # 2 terms
    terms = ['first', 'second']
    variables = {'first': 'lookup_first', 'second': 'lookup_second'}

    assert l.run(terms, templar._available_variables) == ['lookup_first', 'lookup_second']
    assert l.run(terms, variables) == ['lookup_first', 'lookup_second']

    # 1 term
    l = LookupModule()
    terms = ['first']
    assert l.run(terms, templar._available_variables) == ['lookup_first']
    assert l

# Generated at 2022-06-21 07:13:02.831964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock modules and class
    mock_templar = MockTemplarClass()
    lookup_module = LookupModule()
    lookup_module._templar = mock_templar

    # Test with different queries
    query = ['ping', 'pong']
    myvars = {'ping':1, 'pong':2}
    assert(lookup_module.run(query, myvars) == [1, 2])

    query = ['ping', 'pong', 'unkonwn']
    assert(lookup_module.run(query, myvars) == [1, 2, None])

    query = ['ping', 'pong', 'unkonwn']
    assert(lookup_module.run(query, myvars, default='0') == [1, 2, '0'])


# Generated at 2022-06-21 07:13:14.664780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock
    from ansible.plugins.lookup.vars import LookupModule

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.lookup = LookupModule()
            self._templar = Mock()
            self.lookup._templar = self._templar

# Generated at 2022-06-21 07:13:20.429299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # function tempate(self, data, variables=None, preserve_trailing_newlines=True, convert_data=True, fail_on_undefined=True)
    """
    # TODO
    :return:
    """

# Generated at 2022-06-21 07:13:21.940626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Returns LookupModule class object
    """
    return LookupModule

# Generated at 2022-06-21 07:13:31.640287
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # creating an object to look up Ansible variable
    variable_object = LookupModule()

    # creating variable names for lookup
    variable_name = ['variablename', 'myvar']

    # setting the variables for templating
    variable_object.set_options(var_options={'variablname': 'hello', 'myvar': 'ename'})

    # testing the run method
    assert variable_object.run(variable_name) == ['hello']

# Generated at 2022-06-21 07:13:32.784611
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 07:13:45.904375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    lookup_value_mock = LookupModule()
    setattr(lookup_value_mock._templar, '_available_variables', {'variablename': AnsibleUnicode(u'hello'), 'myvar': AnsibleUnicode(u'ename')})
    print(lookup_value_mock.run(['variablename']))
    setattr(lookup_value_mock._templar, '_available_variables', {'variablename': AnsibleUnicode(u'hello'), 'myvar': AnsibleUnicode(u'notename')})
    print(lookup_value_mock.run(['variablename'], {}, default = u''))

# Generated at 2022-06-21 07:14:23.686203
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plug = LookupModule()
    # test plugins/lookup/vars.py
    # default args:
    try:
        lookup_plug.run(["ansible_play_batch"], [])
    except Exception as ex:
        print(ex)
        assert False

    # default is not None , so we can catch AnsibleError
    try:
        lookup_plug.run(["ansible_play_batch"], [], default='10')
    except Exception as ex:
        print(ex)
        assert False

    # term argument is not a list of string, so we can catch AnsibleError
    try:
        lookup_plug.run([1, 2, 3], [])
    except Exception as ex:
        print(ex)
        assert True

# Generated at 2022-06-21 07:14:29.445972
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["a", "b", "c"]
    variables = {}
    variables["a"] = "hello"
    variables["c"] = 12
    variables["hostvars"] = variables
    variables["inventory_hostname"] = "host"
    l = LookupModule(terms, variables=variables, basedir='../')
    assert l.run(terms) == ["hello", None, 12]

# Generated at 2022-06-21 07:14:42.607597
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Only one choice for an empty term list, return []
    ret = LookupModule(loader=loader).run([], default='xyz')
    assert ret == []

    # List (one choice for valid term and one for invalid term)
    try:
        ret = LookupModule(loader=loader).run([ 'my_template_var', 'my_undefined_var' ], default='xyz')
    except AnsibleUndefinedVariable:
        # Verifies that we have a second term in valid term list
        ret = LookupModule(loader=loader).run([ 'my_template_var' ], default='xyz')

    assert ret == [ 'xyz' ]

    # Dictionary

# Generated at 2022-06-21 07:14:50.742620
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test normal case
    obj = LookupModule()
    terms = ['some_var', 'some_var2']
    variables = {'some_var': 'test', 'some_var2': 'test2'}
    obj.run(terms, variables=variables, fail_on_undefined=False)

# Generated at 2022-06-21 07:15:03.146593
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a 'variables' dict
    test_vars = dict()
    test_vars['variablename'] = 'hello'
    test_vars['myvar'] = 'ename'
    test_vars['variablenotename'] = 'hello2'
    test_vars['myvarnotename'] = 'ename2'

    # Test with variablename
    test_lookup = LookupModule()
    test_lookup._templar.available_variables = test_vars
    test_result = test_lookup.run(terms=['variablename'], variables=test_vars)
    assert test_result[0] == 'hello'

    # Test with variablename using a two variables
    test_lookup = LookupModule()
    test_lookup._templ

# Generated at 2022-06-21 07:15:16.281948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager


    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(),  host_list='tests/inventory')

    play_source = dict(
        name = "Ansible Play",
        hosts = 'testhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{lookup(\'vars\',\'ansible_play_batch\')}}'))),
        ]
    )


# Generated at 2022-06-21 07:15:18.230579
# Unit test for constructor of class LookupModule
def test_LookupModule():
    "test the class constructor"
    lookup_module = LookupModule()
    return lookup_module


# Generated at 2022-06-21 07:15:19.640825
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 07:15:24.004320
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Test: test_LookupModule')
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 07:15:36.330753
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import library
    import ansible.plugins.lookup.vars

    # Create class objct LookupModule
    lookupModule = ansible.plugins.lookup.vars.LookupModule()

    # Create objct LookupBase
    lookupBase = ansible.plugins.lookup.LookupBase()

    # Create variable terms
    terms = "ansible_play_hosts"

    # Create variable variables
    variables = [
        {
            "ansible_play_hosts": [
                "host1",
                "host2",
                "host3",
                "host4"
            ]
        }
    ]

    # Create variable kwargs
    kwargs = {}

    # Call method run of class LookupModule

# Generated at 2022-06-21 07:16:35.234368
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookup = LookupModule()
    assert myLookup is not None

# Generated at 2022-06-21 07:16:37.343431
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-21 07:16:48.158767
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    import ansible.utils
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from io import StringIO

    class TestLookupModule(LookupModule):
        def __init__(self, loader=None, templar=None, shared_loader_obj=None, **kwargs):
            self._loader = loader
            self._templar = templar

        def run(self, terms, variables=None, **kwargs):
            super(TestLookupModule, self).run(terms, variables, **kwargs)


# Generated at 2022-06-21 07:16:50.469278
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t is not None

# Generated at 2022-06-21 07:17:01.474173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit tests are developed using Python standard unittest module.
    # The `unittest` documentation provides a thorough explanation of
    # how to write unittests:
    # https://docs.python.org/2.7/library/unittest.html
    import unittest
    from ansible.parsing.dataloader import DataLoader

    # Pass a string and expect the result to be a list
    # with a single string element inside
    class Test_lookup_vars(unittest.TestCase):
        def test_string_passed(self):
            my_dict = {'ansible_foo': 'bar', 'ansible_bar': 'baz'}
            templar = DummyTemplar(my_dict)
            lookup = LookupModule(loader=DummyLoader())
            ret = lookup

# Generated at 2022-06-21 07:17:06.817808
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule.run(LookupModule(), terms=['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']) ==
          [[], [], []])

# Generated at 2022-06-21 07:17:07.774448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-21 07:17:14.334106
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 07:17:19.720126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar

    hostvars = dict()
    inventory_hostname = 'test1'
    hostvars[inventory_hostname] = dict()
    hostvars[inventory_hostname]['variablename'] = 'hello'
    list_of_terms = dict()
    list_of_terms['myvar'] = 'ename'
    default = ''
    myvars = dict()
    myvars['hostvars'] = hostvars
    myvars['inventory_hostname'] = inventory_hostname
    templar = Templar(loader=None, variables=myvars)

    test_obj = LookupModule()


# Generated at 2022-06-21 07:17:21.466619
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()