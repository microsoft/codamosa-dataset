

# Generated at 2022-06-17 13:41:03.350695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a dictionary of variables
    variables = {
        'ansible_play_hosts': ['host1', 'host2'],
        'ansible_play_batch': ['host1', 'host2'],
        'ansible_play_hosts_all': ['host1', 'host2'],
        'variablename': 'hello',
        'myvar': 'ename',
        'variablenotename': 'hello',
        'myvar': 'notename',
        'variablename': {'sub_var': 12},
        'myvar': 'ename'
    }

    # Create a dictionary of kwargs
    kwargs = {
        'default': ''
    }

    # Create a list of terms
    terms

# Generated at 2022-06-17 13:41:15.546214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var'], default='default_value') == ['test_value']
    assert lookup_module.run(['test_var_not_exist'], default='default_value') == ['default_value']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

# Generated at 2022-06-17 13:41:26.001762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var'], default='default_value') == ['test_value']
    assert lookup_module.run(['test_var_not_exist'], default='default_value') == ['default_value']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

# Generated at 2022-06-17 13:41:31.531384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test': 'test_value'}
    assert lookup_module.run(['test']) == ['test_value']
    assert lookup_module.run(['test', 'test2']) == ['test_value']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test': 'test_value'}
    assert lookup_module.run(['test'], default='default_value') == ['test_value']
    assert lookup_module.run(['test2'], default='default_value') == ['default_value']

# Generated at 2022-06-17 13:41:43.295030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no default
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'var1': 'value1', 'var2': 'value2', 'var3': 'value3'}
    assert lookup_module.run(['var1', 'var2', 'var3']) == ['value1', 'value2', 'value3']
    assert lookup_module.run(['var1', 'var2', 'var3', 'var4']) == ['value1', 'value2', 'value3']

    # Test with default
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()

# Generated at 2022-06-17 13:41:52.278857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with undefined variable
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'hostvars': {'host1': {'var1': 'value1'}}}
    result = lookup_module.run(['var2'])
    assert result == [None]

    # Test with defined variable
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'hostvars': {'host1': {'var1': 'value1'}}}
    result = lookup_module.run(['var1'])
    assert result == ['value1']

    # Test with defined variable and default value
    lookup_module

# Generated at 2022-06-17 13:42:04.446378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 13:42:10.176948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    result = lookup_module.run(['variabl' + '{{ myvar }}'], None, default='')
    assert result == ['hello']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'notename'}
    result = lookup_module.run(['variabl' + '{{ myvar }}'], None)
    assert result == []

    # Test with nested variables
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:42:22.585068
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:42:32.414357
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader

    # Create a mock inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a mock play

# Generated at 2022-06-17 13:42:42.594033
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'var1': 'value1', 'var2': 'value2'}
    assert lookup_module.run(['var1', 'var2'], default='default') == ['value1', 'value2']

    # Test with undefined variables
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'var1': 'value1', 'var2': 'value2'}
    assert lookup_module.run(['var1', 'var3'], default='default') == ['value1', 'default']

    # Test with undefined variables and no default value
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:42:52.282492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var'], default='default_value') == ['test_value']
    assert lookup_module.run(['test_var_not_exist'], default='default_value') == ['default_value']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

# Generated at 2022-06-17 13:43:04.849424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1:
    #   - terms:
    #       - variablename
    #       - myvar
    #   - variables:
    #       variablename: hello
    #       myvar: ename
    #   - default: None
    #   - kwargs: {}
    #   - expected:
    #       - hello
    terms = ['variablename', 'myvar']
    variables = {'variablename': 'hello', 'myvar': 'ename'}
    default = None
    kwargs = {}
    expected = ['hello']
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == expected

    # Test 2:
    #   - terms:
    #       - variablename
    #

# Generated at 2022-06-17 13:43:17.739763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with multiple terms
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variablename', 'myvar']) == ['hello', 'ename']

    # Test with a single term and a default value
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:43:28.252715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a variable that is defined
    my_lookup = LookupModule()
    my_lookup._templar._available_variables = {'variablename': 'hello'}
    my_lookup._templar._available_variables['myvar'] = 'ename'
    assert my_lookup.run(['variablename']) == ['hello']

    # Test with a variable that is not defined
    my_lookup = LookupModule()
    my_lookup._templar._available_variables = {'variablename': 'hello'}
    my_lookup._templar._available_variables['myvar'] = 'notename'
    assert my_lookup.run(['variablename']) == ['hello']

    # Test with a variable that is not defined and no default

# Generated at 2022-06-17 13:43:42.245474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar()
    lookup_module._templar._available_variables = {'var1': 'val1', 'var2': 'val2'}
    assert lookup_module.run(['var1'], default='default') == ['val1']
    assert lookup_module.run(['var3'], default='default') == ['default']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar = FakeTemplar()
    lookup_module._templar._available_variables = {'var1': 'val1', 'var2': 'val2'}
    assert lookup_module.run(['var1']) == ['val1']

# Generated at 2022-06-17 13:43:48.945356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()
    # Create a dictionary of variables
    variables = {'hostvars': {'host1': {'var1': 'value1', 'var2': 'value2'}}, 'var3': 'value3'}
    # Create a list of terms
    terms = ['var1', 'var2', 'var3']
    # Create a dictionary of kwargs
    kwargs = {'default': 'default'}
    # Call the run method of LookupModule
    result = lookup_module.run(terms, variables, **kwargs)
    # Assert the result
    assert result == ['value1', 'value2', 'value3']

# Generated at 2022-06-17 13:44:01.010879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a variable that is defined
    terms = ['ansible_play_hosts']
    variables = {'ansible_play_hosts': ['localhost']}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == [['localhost']]

    # Test with a variable that is not defined
    terms = ['ansible_play_hosts_all']
    variables = {'ansible_play_hosts': ['localhost']}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables)
    assert result == [[]]

    # Test with a variable that is not defined and a default value
    terms = ['ansible_play_hosts_all']
    variables = {'ansible_play_hosts': ['localhost']}
   

# Generated at 2022-06-17 13:44:10.313758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(['test']) == []

    # Test with variables
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test': 'test'}
    assert lookup_module.run(['test']) == ['test']

    # Test with variables and default
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test': 'test'}
    assert lookup_module.run(['test'], default='default') == ['test']

    # Test with variables and default
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test': 'test'}

# Generated at 2022-06-17 13:44:21.131973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a variable that exists
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

    # Test with a variable that does not exist
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var_2']) == []

    # Test with a variable that does not exist and a default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}

# Generated at 2022-06-17 13:44:43.289864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a simple variable
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

    # Test with a nested variable
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': {'test_sub_var': 'test_value'}}
    assert lookup_module.run(['test_var.test_sub_var']) == ['test_value']

    # Test with a nested variable and a default value
    lookup_module = LookupModule()

# Generated at 2022-06-17 13:44:52.829676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a fake templar
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a fake lookup module
    lookup_module = LookupModule()
    lookup_module._templar = templar

    # Test with a valid variable
    result = lookup_module.run(terms=['test_var'])
    assert isinstance

# Generated at 2022-06-17 13:45:04.289215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a variable that exists
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

    # Test with a variable that doesn't exist
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var_2']) == []

    # Test with a variable that doesn't exist and a default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}

# Generated at 2022-06-17 13:45:13.853809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with undefined variable
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'inventory_hostname': 'localhost'}
    lookup_module._templar._available_variables['hostvars'] = {'localhost': {'ansible_play_hosts': ['localhost']}}
    lookup_module.set_options(var_options=lookup_module._templar._available_variables, direct={})
    lookup_module.get_option = lambda x: None
    lookup_module._templar.template = lambda x, y: x
    lookup_module._templar.fail_on_undefined_errors = True
    lookup_module._templar.fail_on_undefined_vars = True

# Generated at 2022-06-17 13:45:26.025976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a variable that is defined
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    lookup_module._templar._available_variables['myvar'] = 'ename'
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with a variable that is not defined
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    lookup_module._templar._available_variables['myvar'] = 'notename'
    assert lookup_module.run(['variablename']) == []

    # Test with a variable that is not defined and a default value
    lookup_module = LookupModule

# Generated at 2022-06-17 13:45:37.614751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    lookup_module._templar._available_variables = {
        'variablename': 'hello',
        'myvar': 'ename'
    }
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar = MockTemplar()
    lookup_module._templar._available_variables = {
        'variablename': 'hello',
        'myvar': 'notename'
    }
    assert lookup_module.run(['variablename'], default='') == ['']

    # Test with default value

# Generated at 2022-06-17 13:45:45.206345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with multiple terms
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variablename', 'myvar']) == ['hello', 'ename']

    # Test with a default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}


# Generated at 2022-06-17 13:45:56.841898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_term': 'test_value'}
    assert lookup_module.run(['test_term']) == ['test_value']

    # Test with an invalid term
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_term': 'test_value'}
    assert lookup_module.run(['invalid_term']) == []

    # Test with a valid term and a default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_term': 'test_value'}

# Generated at 2022-06-17 13:46:05.515010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'notename'}
    assert lookup_module.run(['variablename'], default='') == ['']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'notename'}
    assert lookup

# Generated at 2022-06-17 13:46:15.774462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variabl' + '{{ myvar }}'], default='') == ['hello']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variabl' + '{{ myvar }}']) == ['hello']

    # Test with default value
    lookup_module = Look

# Generated at 2022-06-17 13:46:43.702452
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'ansible_play_hosts': ['localhost'], 'ansible_play_batch': ['localhost'], 'ansible_play_hosts_all': ['localhost']}}}
    assert lookup_module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all']) == [['localhost'], ['localhost'], ['localhost']]

# Generated at 2022-06-17 13:46:55.666036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a single term
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with a single term and a default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    assert lookup_module.run(['variablename'], default='default') == ['hello']

    # Test with a single term and a default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}

# Generated at 2022-06-17 13:47:04.760979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock class for LookupBase
    class MockLookupBase(object):
        def __init__(self):
            self.set_options_called = False
            self.get_option_called = False
            self.get_option_return = None

        def set_options(self, var_options=None, direct=None):
            self.set_options_called = True

        def get_option(self, option):
            self.get_option_called = True
            return self.get_option_return

    # Create a mock class for Templar
    class MockTemplar(object):
        def __init__(self):
            self.template_called = False
            self.template_return = None

        def template(self, value, fail_on_undefined=True):
            self.template_called = True
           

# Generated at 2022-06-17 13:47:12.185306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'foo': 'bar'}
    assert lookup_module.run(['foo']) == ['bar']
    assert lookup_module.run(['foo', 'bar'], default='baz') == ['bar', 'baz']
    assert lookup_module.run(['foo', 'bar']) == ['bar']


# Generated at 2022-06-17 13:47:22.162736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var'], default='default_value') == ['test_value']
    assert lookup_module.run(['test_var_not_exist'], default='default_value') == ['default_value']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

# Generated at 2022-06-17 13:47:33.250711
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variabl' + '{{ myvar }}'], variables={'myvar': 'ename'}, default='') == ['hello']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variabl' + '{{ myvar }}'], variables={'myvar': 'ename'}) == ['hello']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar

# Generated at 2022-06-17 13:47:41.380403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a variable that exists
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    lookup_module._templar._available_variables['hostvars'] = {'inventory_hostname': {'variablename': 'hello'}}
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with a variable that does not exist
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    lookup_module._templar._available_variables['hostvars'] = {'inventory_hostname': {'variablename': 'hello'}}

# Generated at 2022-06-17 13:47:52.120870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.lookup import LookupBase
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager._extra_vars = {'myvar': 'ename', 'variablename': 'hello'}

# Generated at 2022-06-17 13:48:04.145132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'hostvars': {'host1': {'var1': 'value1'}}}
    assert lookup_module.run(['var1'], default='default') == ['value1']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'hostvars': {'host1': {'var1': 'value1'}}}
    assert lookup_module.run(['var1']) == ['value1']

    # Test with undefined variable
    lookup_module = LookupModule()
    lookup

# Generated at 2022-06-17 13:48:15.075122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'ename'}
    assert lookup_module.run(['variablename']) == ['hello']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'notename'}
    assert lookup_module.run(['variablename'], default='') == ['']

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello', 'myvar': 'notename'}
    assert lookup

# Generated at 2022-06-17 13:49:01.089928
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:49:09.320172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']
    assert lookup_module.run(['test_var_not_exist']) == []

    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var'], default='default_value') == ['test_value']
    assert lookup_module.run(['test_var_not_exist'], default='default_value') == ['default_value']

# Generated at 2022-06-17 13:49:18.377469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']
    assert lookup_module.run(['test_var_not_exist'], default='default_value') == ['default_value']
    assert lookup_module.run(['test_var_not_exist']) == []

    # Test with no default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

# Generated at 2022-06-17 13:49:29.153361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']
    assert lookup_module.run(['test_var_not_exists'], default='default_value') == ['default_value']

    # Test without default value
    lookup_module = LookupModule()
    lookup_module._templar = DummyTemplar()
    lookup_module._templar._available_variables = {'test_var': 'test_value'}
    assert lookup_module.run(['test_var']) == ['test_value']

# Generated at 2022-06-17 13:49:43.171900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    assert lookup_module.run(['variablename']) == ['hello']
    assert lookup_module.run(['variablename'], default='default') == ['hello']
    assert lookup_module.run(['variablename'], default='default', var_options={'variablename': 'default'}) == ['default']

    # Test with no default value
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'variablename': 'hello'}
    assert lookup_module.run(['variablename']) == ['hello']

# Generated at 2022-06-17 13:49:55.150303
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 13:50:05.454031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'hostvars': {'host1': {'var1': 'value1'}}}
    lookup_module._templar._available_variables['var2'] = 'value2'
    lookup_module._templar._available_variables['var3'] = 'value3'
    lookup_module._templar._available_variables['var4'] = 'value4'
    lookup_module._templar._available_variables['var5'] = 'value5'
    lookup_module._templar._available_variables['var6'] = 'value6'
    lookup_module._templar._available_variables['var7'] = 'value7'

# Generated at 2022-06-17 13:50:15.808988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'ansible_play_hosts': ['localhost'], 'ansible_play_batch': ['localhost'], 'ansible_play_hosts_all': ['localhost']}}}
    lookup_module.set_options(var_options={'inventory_hostname': 'localhost', 'hostvars': {'localhost': {'ansible_play_hosts': ['localhost'], 'ansible_play_batch': ['localhost'], 'ansible_play_hosts_all': ['localhost']}}}, direct={})
    assert lookup_module.run(['ansible_play_hosts', 'ansible_play_batch', 'ansible_play_hosts_all'])

# Generated at 2022-06-17 13:50:20.193271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test']) == []

    # Test with variables
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test': 'test'}) == ['test']

    # Test with variables and default
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test': 'test'}, default='default') == ['test']

    # Test with variables and default
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['test'], variables={'test': 'test'}, default='default') == ['test']

    # Test with variables and default
    lookup_module = LookupModule()
    assert lookup

# Generated at 2022-06-17 13:50:27.347518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with undefined variable
    lookup_module = LookupModule()
    lookup_module._templar._available_variables = {'inventory_hostname': 'localhost'}
    lookup_module._templar.available_variables = {'inventory_hostname': 'localhost'}
    lookup_module.set_options(var_options={'inventory_hostname': 'localhost'}, direct={})
    lookup_module.get_option = lambda x: None
    lookup_module._templar.template = lambda x, y: x
    lookup_module._templar.fail_on_undefined_errors = []
    lookup_module._templar.fail_on_undefined_vars = []
    lookup_module._templar.fail_on_undefined_errors = []
    lookup_module._templar.fail