

# Generated at 2022-06-22 23:45:55.163762
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import remove_fact_ext
    from ansible.module_utils.facts import gathering
    module = gathering._FakeModule()
    FactCollector = FcWwnInitiatorFactCollector(module)
    fc_facts = FactCollector.collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts
    assert len(fc_facts['fibre_channel_wwn']) > 0
    assert remove_fact_ext(fc_facts['fibre_channel_wwn'][0]) == fc_facts['fibre_channel_wwn'][0]

# Generated at 2022-06-22 23:45:56.441515
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:01.071008
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_fact_collector.collect()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()

# Generated at 2022-06-22 23:46:09.207943
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector"""

    class MockModule(object):
        def __init__(self):
            self._results = []

        def get_bin_path(self, arg):
            self._results['get_bin_path'] = arg
            return None

        def run_command(self, arg):
            self._results['run_command'] = arg
            return None

    module = MockModule()
    fc = FcWwnInitiatorFactCollector()
    fc.collect(module)
    assert module._results['get_bin_path'] is not None

# Generated at 2022-06-22 23:46:15.685662
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an instance for testing
    fc_facts = FcWwnInitiatorFactCollector()
    # list of dict is needed as retrun data type
    facts = []
    # collect should return a dict
    facts.append(fc_facts.collect())
    # check that the fc_facts dict is not empty
    assert facts[-1]
    # check that we got some wwn in answer
    assert facts[-1]['fibre_channel_wwn'][0]
    # print the values thus collected
    print(facts)

if __name__ == '__main__':
    # Unit test module
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:46:19.124362
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test FcWwnInitiatorFactCollector constructor"""
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:21.682621
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert type(obj).__name__ == 'FcWwnInitiatorFactCollector'

# Generated at 2022-06-22 23:46:31.192651
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class FakeModule:

        def __init__(self, fc_wwn_list=[]):
            self.params = {'gather_subset': 'all'}
            self.fc_wwn_list = fc_wwn_list

        def get_bin_path(self, name, opt_dirs=[]):
            return 'true'

        def run_command(self, cmd):
            return 0, '', ''

    class FakeFcWwnFactCollector(FcWwnInitiatorFactCollector):

        def __init__(self):
            pass

        def _get_platform_facts(self, module):
            return {'distribution': 'Linux'}

        def _get_linux_facts(self, module):
            return {'sys_platform': 'linux'}


# Generated at 2022-06-22 23:46:34.885167
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test class instantiation
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj is not None


# Generated at 2022-06-22 23:46:45.682515
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Test function collection of FcWwnInitiatorFactCollector """

    from ansible.module_utils.facts import ModuleStub

    # Make sure we run on linux or aix
    if not sys.platform.startswith('linux') and not sys.platform.startswith('aix'):
        return True

    facts = {}

    module_obj = ModuleStub()
    FcWwnInitiatorFactCollector._collect(facts, module_obj)

    class_name = FcWwnInitiatorFactCollector._name
    device_name = 'fibre_channel_wwn'
    supported = True

    assert class_name in facts, \
        "Expected %s device field to be present in facts." % class_name

# Generated at 2022-06-22 23:46:53.587751
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector import Hardware
    import sys
    import glob
    facts_to_collect = [FcWwnInitiatorFactCollector]
    inventory_cache = {}
    collected_facts = {}
    module = "ansible.module_utils.facts.test.test_utils"
    nd = NetworkCollector(module=module, inventory_cache=inventory_cache)
    # dummy class to pass a test
    class MockModule:
        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd
    module = MockModule()

# Generated at 2022-06-22 23:46:54.680778
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:46:56.965945
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:08.433953
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    # Known values for Linux and Solaris
    fc_facts = dict(
        fibre_channel_wwn = ['21000014ff52a9bb'],
    )

    # Create an instance of FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    # Unit test collect method
    result = fc.collect()
    if platform.system() == 'Linux' or platform.system().startswith('SunOS'):
        assert result == fc_facts
    else:
        assert result['fibre_channel_wwn'] == []

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-22 23:47:11.050529
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collect_cmd = FcWwnInitiatorFactCollector()
    assert collect_cmd.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:47:16.884287
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector.collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)


# Generated at 2022-06-22 23:47:19.983420
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-22 23:47:23.180131
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_obj = FcWwnInitiatorFactCollector()
    test_obj.collect()

# Generated at 2022-06-22 23:47:25.469091
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:38.349858
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # mocks for module and custom collector class
    class MockModule():
        def get_bin_path(self, arg, opt_dirs=[]):
            return '/' + arg

    class MockCollector(object):
        name = 'fibre_channel_wwn'

        class MockFile():
            def __init__(self, name, data):
                self.name = '/' + name
                self.data = data

            def readlines(self):
                return self.data

        def collect(self, module=None, collected_facts=None):
            # fake data
            data = ['0x21000014ff52a9bb\n', '0x21000014ff52a9bc']

            fc_facts = {}

# Generated at 2022-06-22 23:47:41.126602
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector is not None
    assert fc_wwn_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_collector.collect() == {}

# Generated at 2022-06-22 23:47:43.612867
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    print("FcWwnInitiatorFactCollector instance created.")


# Generated at 2022-06-22 23:47:47.242561
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_collector = FcWwnInitiatorFactCollector()
    fcwwn_collector.collect()

# Generated at 2022-06-22 23:47:58.961628
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    collected_facts = FcWwnInitiatorFactCollector.collect(module=module,
                                                          collected_facts=dict())
    assert type(collected_facts) is dict
    assert 'fibre_channel_wwn' in collected_facts
    assert type(collected_facts['fibre_channel_wwn']) is list
    for fcwwn in collected_facts['fibre_channel_wwn']:
        assert type(fcwwn) is str

# Generated at 2022-06-22 23:48:03.048744
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_obj = FcWwnInitiatorFactCollector()
    test_obj.collect()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:48:07.448853
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fcwwninitiator = FcWwnInitiatorFactCollector()
    facts = fcwwninitiator.collect(module=module, collected_facts=None)
    assert facts == {}

# Generated at 2022-06-22 23:48:13.927325
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # instantiate class FcWwnInitiatorFactCollector
    test_class = FcWwnInitiatorFactCollector()

    # set collected_facts to empty dict
    collected_facts = dict()

    # call method collect
    facts = test_class.collect(collected_facts=collected_facts)

    # assert the method call did not change the collected facts dict
    assert collected_facts == dict()

    # assert facts dict is empty
    assert facts == dict()

# Generated at 2022-06-22 23:48:23.415530
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create object and assign to fcwwn_initiator
    fcwwn_initiator = FcWwnInitiatorFactCollector()
    # Call method and assign to the result
    result = fcwwn_initiator.collect()
    # Check if result is not empty
    assert result['fibre_channel_wwn'] != None

# Main execution
# Run test_FcWwnInitiatorFactCollector_collect
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:48:27.905851
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn', 'Wrong name'
    assert c._fact_ids == set(), 'Wrong fact_ids'
    assert c.collect() == {}, 'Wrong collect'

# Generated at 2022-06-22 23:48:40.243679
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of FcWwnInitiatorFactCollector.
    """
    # Setup
    module_name = "ansible.module_utils.facts.network.fibre_channel_wwn.FcWwnInitiatorFactCollector"
    module_args = {}
    tmp_path = '/tmp'
    fake_module = FakeAnsibleModule(module_name,
                                    module_args,
                                    tmp_path)

    ff = FcWwnInitiatorFactCollector()

    # Exercise SUT
    result = ff.collect(fake_module)

    # Verify
    assert 'fibre_channel_wwn' in result
    assert isinstance(result['fibre_channel_wwn'], list)

# Generated at 2022-06-22 23:48:48.954263
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """

    # Create FcWwnInitiatorFactCollector object
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert fc.collect() == {}
    assert fc.collect() == {}

# Generated at 2022-06-22 23:48:51.310899
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:48:54.999504
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)
    assert len(fc._fact_ids) == 0

# Generated at 2022-06-22 23:49:01.525719
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.collect() == {'fibre_channel_wwn': []}

if __name__ == '__main__':
    # Unit test
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:06.363699
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ test class FcWwnInitiatorFactCollector """
    fc_collector_obj = FcWwnInitiatorFactCollector()
    assert type(fc_collector_obj).__name__ == "FcWwnInitiatorFactCollector"

# Generated at 2022-06-22 23:49:06.860217
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:49:12.871939
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    base_collector = BaseFactCollector()
    base_collector.collect(module=module)
    fc_collector = FcWwnInitiatorFactCollector()
    fc_collector.collect(module=module)
    facts = base_collector.read_facts()
    assert 'fibre_channel_wwn' in facts
    if sys.platform.startswith('linux'):
        assert len(facts['fibre_channel_wwn']) > 0
        assert facts['fibre_channel_wwn'][0] == '21000014ff52a9bb'
    elif sys.platform.startswith('sunos'):
        assert len(facts['fibre_channel_wwn']) > 0
        assert facts

# Generated at 2022-06-22 23:49:25.157016
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    from ansible.module_utils.facts import Collector

    # prep
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['base_dir'] = os.getcwd()

        def get_bin_path(self, path, opt_dirs=[]):
            return path

        def run_command(self, cmd):
            return os.system(cmd), None, None

        def get_platform(self):
            return sys.platform

    class FakeCollector(Collector):
        def __init__(self):
            self.data = {}

        def get_data(self):
            return self.data

        def collect_data(self):
            return

   

# Generated at 2022-06-22 23:49:28.934489
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
     fc_wwn = FcWwnInitiatorFactCollector()
     assert fc_wwn.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:49:33.697135
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert len(x._fact_ids) == 1
    assert 'fibre_channel_wwn' in x._fact_ids
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:34.381358
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:49:40.938403
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector.collect()

    # example output:
    #{
    #    "fibre_channel_wwn": [
    #        "50060b00006975ec",
    #        "50060b00006975ed",
    #    ]
    #}

# Generated at 2022-06-22 23:49:52.970103
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Tests for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector

    class MockModule(object):
        """
        Mock class for AnsibleModule.
        """
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.exit_json = exit_json

        def get_bin_path(self, arg, *args, **kwargs):
            """
            Mock method for get_bin_path.
            """
            if arg == "ioscan":
                return arg
            if arg == "fcmsutil":
                return

# Generated at 2022-06-22 23:50:00.380907
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = type('FakeModule', (object,), {})
    module.run_command = lambda x, *args, **kwargs: (0, '', '')

    sys.modules['ansible'] = type('FakeAnsibleModule', (object,), {
        'get_bin_path': lambda x, *args, **kwargs: x,
    })

    fcfact = FcWwnInitiatorFactCollector()
    fcfact.collect(module=module)

# Generated at 2022-06-22 23:50:05.447463
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = object()
    fci = FcWwnInitiatorFactCollector()
    fc_facts = fci.collect(module)
    assert len(fc_facts) == 1
    assert fc_facts['fibre_channel_wwn'] == [()]

# Generated at 2022-06-22 23:50:11.926348
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == 'fibre_channel_wwn'
    assert fcwwnfc._fact_ids == set()
    assert fcwwnfc._collect_fn_list == [fcwwnfc.collect]
    assert fcwwnfc.collect() == {}


# Generated at 2022-06-22 23:50:17.574385
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcfact = FcWwnInitiatorFactCollector()
    assert fcfact
    assert 'fibre_channel_wwn' in fcfact.name
    assert fcfact._fact_ids == {'fibre_channel_wwn'}
    assert fcfact.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:20.910134
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:27.606271
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create dummy module
    module = type('module', (object,), {})()
    # create instance of FcWwnInitiatorFactCollector
    fcWwnFC = FcWwnInitiatorFactCollector()
    # get facts
    fc_facts = fcWwnFC.collect(module=module)
    # assert that WWN is found
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:50:30.911762
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    data = collector.collect()
    assert data.get('fibre_channel_wwn') is not None

# Generated at 2022-06-22 23:50:34.636923
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    if collector.collect():
        assert type(collector.collect()['fibre_channel_wwn']) is list

# Generated at 2022-06-22 23:50:40.666596
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ minimal test to check if class and method exists and return something
    """
    module = AnsibleModuleMock()
    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_fact_collector.collect(module)
    assert fc_facts['fibre_channel_wwn']

# Generated at 2022-06-22 23:50:50.463266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    facts = {}

    s = """
    0x21000014ff52a9bb
    """

    #  create instance of FcWwnInitiatorFactCollector
    fc_initiator = FcWwnInitiatorFactCollector()
    if sys.version_info[0] >= 3:
        s_file = s.splitlines()
    else:
        s_file = s.split('\n')

    # call method collect
    for line in s_file:
        results = fc_initiator.collect(module=None, collected_facts=facts)
        # unit test for class FcWwnInitiatorFactCollector, method collect

# Generated at 2022-06-22 23:50:51.911166
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:50:54.940511
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:58.622291
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    assert o.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:00.354632
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:02.691785
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.platforms == ['Linux', 'SunOS']

# Generated at 2022-06-22 23:51:14.768138
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic

    # create test device for matching (must be in /sys/class/fc_host on linux)
    class TestDevice:
        def __init__(self, mp):
            self.mp = mp
            self.devname = None

        def device_name(self):
            return self.devname

        def mountpoint(self):
            return self.mp

    # create test class for AnsibleModule
    class TestModule:
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            import fcntl
            # read port_name from file

# Generated at 2022-06-22 23:51:20.263809
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_fact = FcWwnInitiatorFactCollector()

    assert fc_fact
    assert fc_fact.name == 'fibre_channel_wwn'
    assert fc_fact._fact_ids == set()

# Generated at 2022-06-22 23:51:24.706581
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnInitiatorFactCollectorObj = FcWwnInitiatorFactCollector()
    assert "fibre_channel_wwn" == fcWwnInitiatorFactCollectorObj.name
    assert len(fcWwnInitiatorFactCollectorObj._fact_ids) == 0

# Generated at 2022-06-22 23:51:35.875941
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import MythicFactCollector

    def MockModule(name):
        class MockModule(object):
            def __init__(self):
                self.name = name
                self.params = None
                self.exit_json = None
                self.fail_json = None

            def get_bin_path(self, name, opt_dirs=[]):
                if name == 'ioscan':
                    return 'ioscan'
                elif name == 'fcmsutil':
                    return 'fcmsutil'
                else:
                    return None

            def run_command(self, cmd):
                return(0, '', '')
        return MockModule()

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    collected_facts = {}
    module

# Generated at 2022-06-22 23:51:45.955046
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # example /sys/class/fc_host/host0/port_name
    host0_port_name_lines = \
            b'0x21000014ff52a9bb'

    # /sys/class/fc_host/host1/port_name
    host1_port_name_lines = \
            b'0x2000014ff52a9bb'

    # example /dev/null
    null_lines = \
            b''

    # fcinfo output
    fcinfo_out = """
    HBA Port WWN: 10000090fa1658de
    """

    fcinfo_out_lines = \
            b'HBA Port WWN: 10000090fa1658de'


# Generated at 2022-06-22 23:51:50.963239
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    object = FcWwnInitiatorFactCollector()
    assert object.name == "fibre_channel_wwn"
    assert object._fact_ids == set()


# Generated at 2022-06-22 23:51:54.718618
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:58.383537
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for class FcWwnInitiatorFactCollector.
    """
    my_collector = FcWwnInitiatorFactCollector()
    assert my_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:01.820302
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # pylint: disable=protected-access
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()

# Generated at 2022-06-22 23:52:14.878515
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    """

    # create a mock object for importable class FcWwnInitiatorFactCollector
    mock_module = type('module', (object,), {'run_command':lambda self, cmd: (0, 'HBA Port WWN: 10000090fa1658de', ''), 'get_bin_path':lambda self, cmd, opt_dirs=[] : cmd})
    mock_module_inst = mock_module()
    mock_module_inst.run_command = lambda cmd: (0, 'HBA Port WWN: 10000090fa1658de', '')
    fcwwn_collector_inst = FcWwnInitiatorFactCollector()
    # call method collect
    result = fcwwn_collector_inst.collect(module=mock_module_inst)


# Generated at 2022-06-22 23:52:22.754827
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test FcWwnInitiatorFactCollector.collect
    """
    test_dict = {
        'fibre_channel_wwn': ['21000014ff52a9bb'],
    }
    module = AnsibleModuleMock()
    fcs = FcWwnInitiatorFactCollector()
    facts = fcs.collect(module=module)
    assert facts == test_dict

# Code for mocking the AnsibleModule class

# Generated at 2022-06-22 23:52:26.022363
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    gffc = FcWwnInitiatorFactCollector()
    assert isinstance(gffc.collect(), dict)



# Generated at 2022-06-22 23:52:31.755889
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    # Testing all attributes defined in the class
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.platforms == None
    assert fact_collector.priority == 50
    assert fact_collector._fact_ids == set()

    # Testing the method collect
    # TBD....

# Generated at 2022-06-22 23:52:33.860778
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == {'fibre_channel_wwn'}
    assert obj.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:52:46.842900
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test 1: linux
    module = MockModule()
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert fc_facts['ansible_facts']['fibre_channel_wwn'] == ['21000014ff52a9bb']

    # test 2: solaris
    module = MockModule()
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert fc_facts['ansible_facts']['fibre_channel_wwn'] == ['21000014ff52a9bb']

    # test 3: aix
    module = MockModule()
    fc_facts = FcWwnInitiatorFactCollector().collect(module)

# Generated at 2022-06-22 23:52:47.137749
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    return

# Generated at 2022-06-22 23:52:48.636325
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:58.875501
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import AnsibleCollector
    # simple class which simulates the module for test purposes
    class Module:
        def __init__(self, desired_platform):
            self.desired_platform = desired_platform
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            return arg

        def run_command(self, arg, check_rc=True):
            return 0, arg, ''

        def platform(self):
            return self.desired_platform

    # dict of platforms to test results

# Generated at 2022-06-22 23:53:01.702238
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = ""
    fci = FcWwnInitiatorFactCollector()
    assert fci is not None


# Generated at 2022-06-22 23:53:04.475007
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcobj = FcWwnInitiatorFactCollector()
    assert fcobj.name == 'fibre_channel_wwn'
    assert 0 == len(fcobj._fact_ids)


# Generated at 2022-06-22 23:53:09.680849
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector.collect()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:53:21.067401
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys
    import os
    # mock module object
    module = MockModule()
    # get platform
    platform = sys.platform
    # bail out if platform is not supported
    if (platform != 'linux' and platform != 'sunos' and platform != 'aix' and platform != 'hp-ux'):
        return
    # for linux
    if platform == 'linux':
        # if file exists, we create it
        if not os.path.isfile('/sys/class/fc_host/host1/port_name'):
            with open('/sys/class/fc_host/host1/port_name', 'w') as f:
                f.write('0x21000014ff52a9bb')
    if (platform == 'linux' or platform == 'sunos' or platform == 'aix'):
        f

# Generated at 2022-06-22 23:53:33.468023
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import tempfile
    import shutil
    import sys
    import glob

    test_facts = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS', 'ansible_distribution_major_version': '7', 'ansible_distribution_version': '7.2.1511'}

    # create test_fc_files, cleanup afterwards
    test_fc_files = tempfile.mkdtemp()
    # create test file for each WWN device
    for test_fc_wwn in ['10000090fa1658de', '21000014ff52a9bb']:
        test_fc_file = os.path.join(test_fc_files, test_fc_wwn)

# Generated at 2022-06-22 23:53:36.642562
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector._fact_ids == set()

# Generated at 2022-06-22 23:53:40.576753
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:49.137519
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collections import LinuxFacts
    from ansible.module_utils.facts.collections import SolarisFacts
    from ansible.module_utils.facts.collections import AIXFacts
    from ansible.module_utils.facts.collections import HPUXFacts
    from mock import Mock
    module = Mock()
    module.get_bin_path.return_value = '/usr/bin/fcinfo'
    module.run_command.return_value = (0, 'HBA Port WWN: 10000090fa1658de\nHBA Port WWN: 10000090fa1658d5\n', '')

# Generated at 2022-06-22 23:54:01.185479
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda msg, changed=False: sys.exit(0)
            self.fail_json = lambda msg: sys.exit(1)
            self.run_command = lambda *args, **kwargs: (0, 'fake-output', None)
            self.get_bin_path = lambda *args, **kwargs: 'fake-path'

    def exit_func(code):
        sys.excepthook = sys.__excepthook__
        raise SystemExit(code)

    # Create a mock version of get_file_lines function

# Generated at 2022-06-22 23:54:03.009797
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:54:07.098144
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwwn = FcWwnInitiatorFactCollector()
    assert fwwn.name == 'fibre_channel_wwn'
    assert fwwn._fact_ids == set()


# Generated at 2022-06-22 23:54:09.589429
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:10.677513
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:54:18.671191
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # setup a fake module object
    class FakeModule(object):
        def __init__(self):
            self.facts = {}
            self.params = {}
            self.params['gather_subset'] = []
            self.params['gather_timeout'] = 1
            self.params['filter'] = None

        def run_command(self, command):
            return (0, None, None)

        def get_bin_path(self, arg, opt_dirs=[]):
            return "/bin/"

    # setup fake module
    module = FakeModule()

    # create the object
    fc_

# Generated at 2022-06-22 23:54:31.383418
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    my_collector = FcWwnInitiatorFactCollector(None)

    # NOTE: prepare some data for testing purpose
    #       add real data to file /sys/class/fc_host/fchost0/port_name
    #       file should contain one line with value like:
    # 0x21000014ff52a9bb
    # add mock data
    data = '0x21000014ff52a9bb'
    file_path = '/sys/class/fc_host/fchost0/port_name'
    with open(file_path, 'w') as fp:
        fp.write(data)

    facts = my_collector.collect()
    assert facts is not None
    assert 'fibre_channel_wwn' in facts
    assert '21000014ff52a9bb'

# Generated at 2022-06-22 23:54:32.398605
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name

# Generated at 2022-06-22 23:54:34.326790
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    print(fc_facts.collect())

# Generated at 2022-06-22 23:54:35.780273
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:54:41.282076
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector(None)
    assert fc.name == 'fibre_channel_wwn'


if __name__ == '__main__':
    import pytest
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-22 23:54:44.489409
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # test with expected results
    coll = FcWwnInitiatorFactCollector()
    assert coll is not None

    # test without expected results
    assert True

# Generated at 2022-06-22 23:54:48.667057
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:01.378409
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
     # create module object and inject fake facts
    import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector.network import NetworkCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector.base import BaseFactCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.utils import get_file_lines
    class Module():
        def __init__(self):
            self.facts={}
            self.params = {}


# Generated at 2022-06-22 23:55:04.872065
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwwnfc = FcWwnInitiatorFactCollector()
    assert fwwnfc.name == 'fibre_channel_wwn'
    assert fwwnfc._fact_ids == set()


# Generated at 2022-06-22 23:55:12.842615
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import collector
    # Test creation of instance
    FcWwnInitiatorFactCollector()
    # Test that it is registered
    assert collector.FACTS_COLLECTORS['fibre_channel_wwn'] == FcWwnInitiatorFactCollector

if __name__ == '__main__':
    # Unit test
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:55:20.616599
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = type('Module', (), {'run_command': lambda self, cmd: (0, '', ''),
                                 'get_bin_path': lambda self, program, opt_dirs=[] : ''})
    testobj = FcWwnInitiatorFactCollector(module)
    assert testobj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:30.788369
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # First test would be on Linux to check if method returns Fc list
    if sys.platform.startswith('linux'):
        FcWwnInitiatorFactCollector.collect(None)
        fc_facts = FcWwnInitiatorFactCollector.collect(None)
        assert len(fc_facts) is not 0, "There is no Fibre Channel wwn in facts!"

    # Next test would be on Solaris to check if method returns Fc list
    if sys.platform.startswith('sunos'):
        fc_facts = FcWwnInitiatorFactCollector.collect(None)
        assert len(fc_facts) is not 0, "There is no Fibre Channel wwn in facts!"

    # Next test would be on AIX to check if method returns Fc list

# Generated at 2022-06-22 23:55:33.555593
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is not None

# Generated at 2022-06-22 23:55:34.568165
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:55:39.740948
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    TestFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert (TestFcWwnInitiatorFactCollector.name == 'fibre_channel_wwn')
    assert (TestFcWwnInitiatorFactCollector._fact_ids == set())

# Generated at 2022-06-22 23:55:45.352317
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    # assert
    assert fc_facts_collector.name == 'fibre_channel_wwn'
    assert fc_facts_collector._fact_ids == set()
    # assert
    assert fc_facts_collector.collect() == {}