

# Generated at 2022-06-22 23:45:48.419889
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()
    assert collector._platform == 'Generic'

# Generated at 2022-06-22 23:46:00.796369
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class LinuxModule(object):
        def __init__(self):
            self.params = {}

        class ModuleFailException(Exception):
            pass

        class RunCommandException(Exception):
            pass

        def fail_json(self, msg):
            raise self.ModuleFailException(msg)

        def get_bin_path(self, binary, opt_dirs=[]):
            bin_paths = {'linux': '',
                         'aix': '',
                         'hp-ux': '',
                         'sunos': ''}
            return bin_paths[sys.platform]

        def run_command(self, cmd):
            out = ''
            err = ''
            if 'lsdev -Cc adapter -l fcs*' in cmd:
                out = '''fcs0 Available
fcs1 Defined
'''


# Generated at 2022-06-22 23:46:07.564685
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class TestModule(object):
        pass

    test_module = TestModule()
    test_module.get_bin_path = lambda x, opt_dirs=None: '/usr/sbin/' + x

    facts = FcWwnInitiatorFactCollector().collect(test_module)
    assert 'fibre_channel_wwn' in facts
    assert ['2100001b32560b00'] == facts['fibre_channel_wwn']

# Generated at 2022-06-22 23:46:09.028728
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:46:18.124941
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_host = FcWwnInitiatorFactCollector()
    test_host_facts = test_host.collect()
    # test_host_facts is a dict, so check if all keys are there
    if not isinstance(test_host_facts, dict):
        return False
    if not test_host_facts:
        return False
    if not 'fibre_channel_wwn' in test_host_facts:
        return False
    if not isinstance(test_host_facts['fibre_channel_wwn'], list):
        return False
    return True

# Generated at 2022-06-22 23:46:20.391231
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:23.835220
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    A minimal test for method collect of class FcWwnInitiatorFactCollector.
    """
    test_collector = FcWwnInitiatorFactCollector()
    test_facts_dict = test_collector.collect()
    assert test_facts_dict == {'fibre_channel_wwn': []}, 'Incorrect facts dict returned by FcWwnInitiatorFactCollector.collect()'

# Generated at 2022-06-22 23:46:25.117556
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  res = FcWwnInitiatorFactCollector()
  assert res.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:33.072487
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

    # Unit test for collect function of class FcWwnInitiatorFactCollector
    def mock_run_command(module, cmd, check_rc=True):
        return (0, "", "")
    setattr(sys.modules['ansible.module_utils.basic'], 'run_command', mock_run_command)

    def mock_get_bin_path(module, cmd, opt_dirs=[]):
        if cmd == 'lsdev':
            return 'lsdev'
        elif cmd == 'lscfg':
            return 'lscfg'
       

# Generated at 2022-06-22 23:46:36.354052
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:41.917356
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_dict = {}
    test_dict['fibre_channel_wwn'] = ['50060b00006975ec', '50060b000069760c']
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect(None, None)
    assert set(facts['fibre_channel_wwn']) == set(test_dict['fibre_channel_wwn'])

# Generated at 2022-06-22 23:46:53.984484
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # define a fake inventory and facts
    class FakeModule:
        def run_command(self, cmd):
            return 0, "HBA Port WWN: 10000090fa1658de", ""
        def get_bin_path(self, cmd, opt_dirs=[]):
            return "fcinfo"

    class FakeCollectedFacts:
        def __init__(self):
            self.values = {}

    fake_module = FakeModule()
    fake_collected_facts = FakeCollectedFacts()

    col = FcWwnInitiatorFactCollector(fake_module)

    collected_facts = col.collect(fake_module, fake_collected_facts)

    # test collected facts are what we expect

# Generated at 2022-06-22 23:47:06.913914
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # when:
    # /sys/class/fc_host/host5/port_name contains "0x21000014ff52a9bb\n"
    # /sys/class/fc_host/host0/port_name contains "0x210000e0070b58a2\n"
    # /sys/class/fc_host/host1/port_name contains "0x210000e0070b58a3\n"
    # /sys/class/fc_host/host2/port_name contains "0x210000e0070b58a4\n"
    # /sys/class/fc_host/host3/port_name contains "0x210000e0070b58a5\n"


# Generated at 2022-06-22 23:47:10.146702
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fci = FcWwnInitiatorFactCollector()
    assert fci.name == 'fibre_channel_wwn'
    assert fci._fact_ids == set()

# Generated at 2022-06-22 23:47:16.581847
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_test_obj = FcWwnInitiatorFactCollector()
    assert my_test_obj.name == 'fibre_channel_wwn'

# Unit test to collect facts
#def test_collect():
#    fc_facts = FcWwnInitiatorFactCollector().collect()
#    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:47:18.613903
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fwifc = FcWwnInitiatorFactCollector()
    fwifc.collect()

# Generated at 2022-06-22 23:47:29.465358
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # only run this test on Linux
    if sys.platform.startswith('linux'):
        from ansible.module_utils.facts.collector import Collector
        from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector

        loader_mock = Collector.get_loader_mock()
        collected_facts = Collector.collect(FcWwnInitiatorFactCollector, loader_mock, None)
        assert type(collected_facts) is dict
        assert collected_facts['fibre_channel_wwn']
        assert type(collected_facts['fibre_channel_wwn']) is list
        assert len(collected_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:47:38.060195
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test the method collect of FcWwnInitiatorFactCollector class
    """
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'
    fc_facts = fc_obj.collect()
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:47:40.615470
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector.name == 'fibre_channel_wwn'
    assert fc_facts_collector._fact_ids == set()

# Generated at 2022-06-22 23:47:44.338793
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert facts.name == 'fibre_channel_wwn'
    assert facts._fact_ids == set()


# Generated at 2022-06-22 23:47:51.649598
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn', \
        "Fact Collector name is incorrect: " + fc.name
    assert set(fc.collect().keys()) == set(['fibre_channel_wwn']), \
        "Fact Collector incorrect collected facts: %s" % set(fc.collect().keys())

# Generated at 2022-06-22 23:47:57.199353
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    class_inst = FcWwnInitiatorFactCollector()
    class_inst.collect()


if __name__ == '__main__':
    # Unit test for method collect of class FcWwnInitiatorFactCollector
    #test_FcWwnInitiatorFactCollector_collect()
    pass

# Generated at 2022-06-22 23:48:03.049472
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    col = FcWwnInitiatorFactCollector()
    assert col.name == 'fibre_channel_wwn'
    assert col.priority == 6
    assert col._fact_ids is not None
    assert len(col._fact_ids) == 1
    assert 'fibre_channel_wwn' in col._fact_ids

# Generated at 2022-06-22 23:48:06.076684
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcf = FcWwnInitiatorFactCollector()
    assert fcf.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:48:08.436677
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:10.819100
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:48:13.168401
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:19.868786
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Construct class, do any initialization required and
    return FcWwnInitiatorFactCollector instance.

    :return fcwwn: instance of FcWwnInitiatorFactCollector
    """
    fcwwn = FcWwnInitiatorFactCollector()
    return fcwwn


# Generated at 2022-06-22 23:48:22.092467
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:48:24.275011
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:26.559472
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except:
        assert False

# Generated at 2022-06-22 23:48:39.290658
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Unit test without mocking

    import sys
    sys.modules['ansible'] = type('AnonymousClass', (dict,), {'ANSIBLE_VERSION': '2.9.0'})()
    sys.modules['ansible.module_utils.facts.utils'] = __import__('ansible.module_utils.facts.utils')
    sys.modules['ansible.module_utils.facts.collector'] = __import__('ansible.module_utils.facts.collector')
    sys.modules['ansible.module_utils.facts.collector.base'] = __import__('ansible.module_utils.facts.collector.base')
    sys.modules['ansible.module_utils.facts'] = __import__('ansible.module_utils.facts')

# Generated at 2022-06-22 23:48:41.853577
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector is not None

# Generated at 2022-06-22 23:48:54.709696
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.hardware import HardwareCollector

    # create instance of FcWwnInitiatorFactCollector
    test_obj = FcWwnInitiatorFactCollector()

    # create instance of FactCollector
    fact_collector_obj = FactCollector(
        collectors=[test_obj],
        cache={},
        # module_name=None,
        # timeout=10,
        # interval=86400,
        # config_file=None,
        # fact_path=None,
        # verbose=True
    )

    # create instance of Collector


# Generated at 2022-06-22 23:48:57.938089
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:49:10.562087
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    @mock.patch('ansible.module_utils.facts.collector.get_file_lines')
    @mock.patch('glob.glob')
    def test_run(glob_mock, get_file_lines_mock):
        collect_manager = FcWwnInitiatorFactCollector()
        glob_mock.return_value = ['/sys/class/fc_host/host1/port_name']
        get_file_lines_mock.return_value = ['0x21000014ff522bb']
        expected_result = {
            'fibre_channel_wwn': ['21000014ff522bb']
        }
        result = collect_manager.collect()
        assert result == expected_result
    test_run()

# Generated at 2022-06-22 23:49:14.364099
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock
    fci_facts = FcWwnInitiatorFactCollector()
    fixture = fci_facts.collect(module)
    assert fixture == expected_fixture

# Generated at 2022-06-22 23:49:18.184178
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import unittest
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert not collector._fact_ids

# Generated at 2022-06-22 23:49:29.520803
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create an instance of FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    # Add a new fact
    fc._fact_ids.add('fibre_channel_wwn_0x21000014ff52a9bb')
    # Dummy method to get file contents
    def dummy_get_file_lines(filename, *args, **kwargs):
        if filename == '/sys/class/fc_host/*/port_name':
            return '0x21000014ff52a9bb'
        else:
            return None
    # Mock method
    fc.get_file_lines = dummy_get_file_lines
    # Test
    out = fc.collect()

# Generated at 2022-06-22 23:49:34.708777
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """initialize a collector and check that it is of expected class.
    """
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.__class__.__name__ == 'FcWwnInitiatorFactCollector'


# Generated at 2022-06-22 23:49:46.614457
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    AnsibleModule stub object
    """
    class AnsibleModule(object):
        @staticmethod
        def get_bin_path(bin_name, opt_dirs=[]):
            """
            dummy method
            """
            return "/bin/%s" % bin_name
        @staticmethod
        def run_command(cmd):
            """
            dummy method
            """
            cmd_list = cmd.split(' ')
            if cmd_list[1] == 'hba-port':
                return 0, "HBA Port WWN: 10000090fa1658de", ''
            elif cmd_list[1] == '-Cc':
                """
                dummy output
                """
                return 0, "fcs0  Defined\nfcs1  Available", ''

# Generated at 2022-06-22 23:49:52.866467
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''
    Test for constructor of class FcWwnInitiatorFactCollector
    '''
    obj = FcWwnInitiatorFactCollector()
    print("Test of FcWwnInitiatorFactCollector:\n", obj.name)


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:57.246318
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test module FcWwnInitiatorFactCollector

    :return:
    """
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:09.360472
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # unit test code
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    # empty list of returned facts 
    in_data = dict(
        ansible_facts=dict(
            fibre_channel_wwn='list'
        )
    )
    # create a collector
    c = FcWwnInitiatorFactCollector()
    # and call its collect method
    out_data = c.collect(module=module, collected_facts=in_data)
    # example of out_data['ansible_facts']['fibre_channel_wwn']

# Generated at 2022-06-22 23:50:13.947502
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert fc.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:50:17.109747
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts is not None


# Generated at 2022-06-22 23:50:19.130212
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # declare test parameters
    # create a test module object
    # run actual test
    pass

# Generated at 2022-06-22 23:50:31.377654
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir))
    test_file_path = os.path.join(os.path.dirname(__file__), 'test-fibre_channel_wwn.txt')
   

# Generated at 2022-06-22 23:50:35.548593
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    ff = FcWwnInitiatorFactCollector()
    assert ff.name == 'fibre_channel_wwn'
    assert ff._fact_ids == set()


# Generated at 2022-06-22 23:50:47.324209
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import glob

    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        """
        Mock class for AnsibleModule
        """
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd, opt_dirs=[]):
            """
            Mock method for AnsibleModule.get_bin_path
            """
            # mock ioscan / lscfg / fcmsutil
            if cmd in ('ioscan', 'lscfg', 'fcmsutil'):
                return cmd
            # mock fcinfo
            if 'fc_host' in glob.glob('/sys/class/fc_host/*'):
                return '/usr/sbin/fcinfo'
            # mock lsdev

# Generated at 2022-06-22 23:50:49.967793
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:51:03.060197
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform

    class MockModule(object):
        def get_bin_path(self, arg1, opt_dirs=None):
            return "test"

        def run_command(self, arg1):
            stdout = b''
            if arg1.startswith("test fcinfo"):
                stdout = b'\n'.join([b'HBA Port WWN: 10000090fa1658de', b''])
                rc = 0

# Generated at 2022-06-22 23:51:06.774619
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    instance = FcWwnInitiatorFactCollector()
    assert instance.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in instance._fact_ids



# Generated at 2022-06-22 23:51:08.887772
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:14.768400
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector._fact_ids == set()

    assert fc_collector.collect({}) == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:51:28.217088
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import tempfile
    import filecmp
    module = AnsibleModuleMock()
    fact = FcWwnInitiatorFactCollector({}, module)
    res = fact.collect()
    # add platform and uname info to results
    res['platform'] = platform.platform()
    res['uname'] = platform.uname()
    # store results for comparison
    file = tempfile.NamedTemporaryFile(delete=False)
    file.write(json.dumps(res, sort_keys=True, indent=4).encode('utf-8') + b"\n")
    file.close()
    # compare results with file

# Generated at 2022-06-22 23:51:32.391594
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() == dict(fibre_channel_wwn=[])


# Generated at 2022-06-22 23:51:35.723134
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj.collect() == {}

# Generated at 2022-06-22 23:51:39.794178
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    test_class = FcWwnInitiatorFactCollector()
    result = test_class.collect()
    print("%s" % result)


if __name__=="__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:51:49.329205
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit tests for class FcWwnInitiatorFactCollector
    """
    fc_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # test name
    fc_initiator_fact_collector_name = fc_initiator_fact_collector.name
    assert fc_initiator_fact_collector_name == 'fibre_channel_wwn'
    # test platform dependent facts
    fc_initiator_facts = fc_initiator_fact_collector.collect()
    assert 'fibre_channel_wwn' in fc_initiator_facts
    assert fc_initiator_facts['fibre_channel_wwn']

# Generated at 2022-06-22 23:51:51.904953
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:51:56.377783
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()



# Generated at 2022-06-22 23:51:56.784696
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:52:03.278433
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    module_name = 'ansible.module_utils.facts.collector.fibre_channel_wwn_initiator'
    module = __import__(module_name, globals(), locals(), ['AnsibleModule'], 0)

    runner = module.AnsibleModule(
        argument_spec={}
    )

    fc_facts = FcWwnInitiatorFactCollector(runner).collect()

    assert fc_facts['fibre_channel_wwn']



# Generated at 2022-06-22 23:52:15.459870
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self, name, bin_path_1='/bin/cmd', bin_path_2=None):
            self.name = name
            self.params = {}
            self.bin_path = bin_path_1
            self.bin_path_2 = bin_path_2
            self.called_commands = []
            self.called_commands_rc = []
            self.called_commands_out = []
            self.called_commands_err = []

        def get_bin_path(self, arg, opt_dirs=None):
            if arg == 'fcinfo':
                return self.bin_path
            elif arg == 'fcmsutil':
                return self.bin_path_2
            if arg == 'ioscan':
                return self.bin_

# Generated at 2022-06-22 23:52:19.372929
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_FcWwnFactCollector = FcWwnInitiatorFactCollector()
    assert test_FcWwnFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:22.598548
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_object = FcWwnInitiatorFactCollector()
    assert my_object.name == 'fibre_channel_wwn'
    assert my_object.platforms == []

# Generated at 2022-06-22 23:52:27.780369
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.platforms == ['Linux', 'SunOS', 'AIX', 'HP-UX']

# Generated at 2022-06-22 23:52:30.313640
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None


# Generated at 2022-06-22 23:52:33.198489
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()


# Generated at 2022-06-22 23:52:39.419222
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)
    assert len(FcWwnInitiatorFactCollector._fact_ids) == 0


# Generated at 2022-06-22 23:52:43.566789
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert len(obj._fact_ids) == 1
    assert 'fibre_channel_wwn' in obj._fact_ids

# Generated at 2022-06-22 23:52:55.728601
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Collect fibre_channel_wwn facts.
    """
    import sys
    import glob
    import tempfile
    import os
    from ansible.module_utils.facts import collector

    # create some fake files
    fc_facts = {'fibre_channel_wwn': []}
    sys.platform = 'linux'
    for x in range(1,4):
        file_name = "/sys/class/fc_host/host%s/port_name" % x
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            os.chmod(tmp.name, 0o644)
            tmp.write(b"0x%012x\n" % x)

# Generated at 2022-06-22 23:52:57.902431
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    fcfacts = Collector().collect(module=None, collected_facts=None)
    assert fcfacts.get('fibre_channel_wwn')

# Generated at 2022-06-22 23:53:01.392420
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnFactCollector = FcWwnInitiatorFactCollector()
    facts = FcWwnFactCollector.collect()
    assert facts is not None
    assert 'fibre_channel_wwn' in facts
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:53:03.812123
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()


# Generated at 2022-06-22 23:53:07.162562
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set([])

# Generated at 2022-06-22 23:53:13.818254
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """This function returns true if the constructor for
    FcWwnInitiatorFactCollector class is defined; False otherwise.
    """
    fcwwn = FcWwnInitiatorFactCollector()
    return isinstance(fcwwn, FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:53:15.950890
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:53:17.151054
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector('dummy_class_name') is not None

# Generated at 2022-06-22 23:53:19.811040
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:53:26.814074
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    FcWwnInitiatorFactCollector.collector = collector
    FcWwnInitiatorFactCollector.__bases__ = (BaseFactCollector,)
    fc = FcWwnInitiatorFactCollector()
    # not implemented yet
    assert fc.collect() == {}

# Generated at 2022-06-22 23:53:34.749732
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()

    FcWwnInitiatorFactCollector._fact_ids.add('fibre_channel_wwn')
    result = collector.collect()
    assert result is not None
    assert 'fibre_channel_wwn' in result
    if sys.platform.startswith('linux'):
        assert len(result['fibre_channel_wwn']) > 0
    else:
        assert len(result['fibre_channel_wwn']) == 0

# Generated at 2022-06-22 23:53:46.407303
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.hardware.fc_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import mocked_commands

    collector = FcWwnInitiatorFactCollector()
    # patching methods needed by FcWwnInitiatorFactCollector.collect()
    #
    command_mock = mocked_commands()
    collector._platform_ignore_command = command_mock

    # patching methods needed by  FcWwnInitiatorFactCollector._get_platform_info()
    #
    collector._get_file_content = lambda x: 'Linux'
    collector._

# Generated at 2022-06-22 23:53:51.463275
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    sys.platform = 'linux'
    module = AnsibleModule()
    fc_fact_collector = FcWwnInitiatorFactCollector(module)
    fc_facts = fc_fact_collector.collect()
    assert fc_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-22 23:53:52.026448
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:53:54.749146
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert "fibre_channel_wwn" in fc_facts.name


# Generated at 2022-06-22 23:54:07.046921
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    module = AnsibleModule(
        argument_spec = {
            'filter': {'required': False, 'type': 'list', 'default': ['.*']},
            'gather_subset': {'required': False, 'type': 'list'},
        },
    )
    fact_collector = FcWwnInitiatorFactCollector(module=module)
    facts = fact_collector.collect()
    assert facts['fibre_channel_wwn'] == [
        'd0d3eebbc3200000',
        '10000090a0b9d8c8',
        '10000090fa1658de'
    ]

# Generated at 2022-06-22 23:54:10.826589
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert isinstance(x._fact_ids, set) and len(x._fact_ids) == 0


# Generated at 2022-06-22 23:54:12.891360
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    wwn = FcWwnInitiatorFactCollector()
    assert wwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:17.029749
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()


# Generated at 2022-06-22 23:54:29.404589
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    test method collect of class FcWwnInitiatorFactCollector

    unit tests are in the same directory as this file.
    to run use: ansible-test units --python collection/ansible_collections/ansible/community/plugins/facts/fibre_channel_wwn
    """
    # pylint: disable=import-error
    from ansible_collections.ansible.community.tests.unit.plugins.facts.test_fibre_channel_wwn import TestModule
    from ansible_collections.ansible.community.plugins.facts.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import ansible.module_utils.facts.collector

    testmodule = TestModule()
    # create a fake module
    testmodule.params = {}
    test_F

# Generated at 2022-06-22 23:54:34.029511
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_facts_collector = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-22 23:54:37.617083
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn', 'Test FcWwnInitiatorFactCollector.name failed!'

# Generated at 2022-06-22 23:54:50.313728
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import sys
    import tempfile
    import unittest

    class ModuleStub(object):
        def __init__(self, params):
            self._params = params
            self.run_command_calls = []

        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'fcinfo':
                if self._params['platform'] == 'sunos':
                    return cmd
                else:
                    return None
           

# Generated at 2022-06-22 23:55:01.692169
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def run_command(self, cmd, opt_dirs=[]):
            return 0, glob.glob('tests/unittests/facts/files/fibre_channel_wwn/linux/*'), None
        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name

    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    fc_facts = fcWwnInitiatorFactCollector.collect(module=MockModule())
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']



# Generated at 2022-06-22 23:55:04.826722
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """only for test, not for release"""
    FcWwnInitiatorFactCollector().collect()


if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:55:07.116629
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:55:09.442471
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:55:12.790546
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:55:17.604756
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() == {}

# Generated at 2022-06-22 23:55:22.820236
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert set(fc_wwn._fact_ids) == set(['fibre_channel_wwn'])

# Generated at 2022-06-22 23:55:29.033561
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector

    :return:
    """
    print("Test method collect of class FcWwnInitiatorFactCollector")
    fc_facts_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_facts_collector.collect()
    print(fc_facts)

if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:55:31.503149
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:55:34.570006
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_object = FcWwnInitiatorFactCollector()
    my_object_name = FcWwnInitiatorFactCollector.name
    assert my_object.name == my_object_name

# Generated at 2022-06-22 23:55:46.800120
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import get_all_facts
    from ansible.module_utils.facts.utils import set_module_args
    import setupmodule_examples.ansible_module_setup as m  # module under test
    set_module_args(dict())
    module = m.MyAnsibleModule()
    if sys.platform.startswith('linux'):
        expected_fc_facts = [
            '21000014ff52a9bb'
        ]
    elif sys.platform.startswith('sunos'):
        expected_fc_facts = [
            '10000090fa1658de'
        ]