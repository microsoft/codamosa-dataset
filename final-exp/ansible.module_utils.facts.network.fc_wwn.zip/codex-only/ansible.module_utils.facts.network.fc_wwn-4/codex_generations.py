

# Generated at 2022-06-22 23:45:52.606931
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    facts_collector = FactsCollector()
    facts_collector._collectors.append(FcWwnInitiatorFactCollector())
    facts_collector.collect()
    assert('fibre_channel_wwn' in facts_collector.facts)


# Generated at 2022-06-22 23:45:58.876260
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = {}
    fc_wwn_initiator_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_collector.collect(facts=facts)
    for wwn in facts['fibre_channel_wwn']:
        assert wwn.startswith('50060b')  # SUN WWN prefix

# Generated at 2022-06-22 23:46:07.518631
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert hasattr(FcWwnInitiatorFactCollector, 'collect') == True
    assert hasattr(FcWwnInitiatorFactCollector, 'name') == True
    assert isinstance(FcWwnInitiatorFactCollector.name, str)
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert hasattr(FcWwnInitiatorFactCollector, '_fact_ids') == True
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-22 23:46:08.212909
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-22 23:46:13.810610
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test constructor of class FcWwnInitiatorFactCollector.
    :return:
    """

    test_obj = FcWwnInitiatorFactCollector()
    # Check if object initialized
    assert test_obj is not None

# Generated at 2022-06-22 23:46:20.237288
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test to ensure the constructor of class FcWwnInitiatorFactCollector
    creates a correct object

    :return: None
    """
    fc_fact_collector = FcWwnInitiatorFactCollector()

    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert len(fc_fact_collector._fact_ids) == 1
    assert fc_fact_collector.collect() == {}

# Generated at 2022-06-22 23:46:30.305994
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import tempfile
    import shutil
    import os
    import sys
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.fibre_channel_wwn

    (tmp_fd, temp_file_name) = tempfile.mkstemp(prefix='ansible_facts_')
    os.close(tmp_fd)

    sys_platform = sys.platform
    sys_version = sys.version
    sys.version = '2.7.5 (default, Nov  6 2016, 00:28:07) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-11)]'
    sys.platform = 'linux2'


# Generated at 2022-06-22 23:46:34.943245
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:46:39.206594
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-22 23:46:42.034099
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:54.155182
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestFactCollector(BaseFactCollector):
        name = 'collector'

        def collect(self, module=None, collected_facts=None):
            return {'test_fact': '42'}

    Collector.add_collection_method(TestFactCollector)

    test_instance = get_collector_instance('collector')
    assert test_instance.collect() == {'test_fact': '42'}

    class TestFactCollector(BaseFactCollector):
        name = 'collector'


# Generated at 2022-06-22 23:46:58.303266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    print(fc.collect())

if __name__ == '__main__':
    # this section is for testing only
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:47:01.734437
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:05.481893
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == "fibre_channel_wwn"
    assert obj.collect() == {}

# Generated at 2022-06-22 23:47:18.302831
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # fake module instance
    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, command, opt_dirs=[]):
            return command

        def run_command(self, cmd, cwd=None, data=None, binary_data=False):
            self.run_command_calls.append({
                'cmd': cmd,
                'cwd': cwd,
                'data': data
            })

# Generated at 2022-06-22 23:47:19.668632
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:21.638925
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f.collect() == {'fibre_channel_wwn': []}


# Generated at 2022-06-22 23:47:24.432989
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector class constructor
    """
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"
    assert fc._fact_ids is not None
    assert len(fc._fact_ids) == 0


# Generated at 2022-06-22 23:47:26.567992
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwi = FcWwnInitiatorFactCollector()
    assert fwi.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:39.322646
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    def _get_bin_path(module, path):
        return path

    class ModuleStub:

        def __init__(self):
            self.run_command_results = [(0, '', ''), (0, '', '')]

        def get_bin_path(self, module, opt_dirs=None):
            return _get_bin_path(module, '/bin/' + module)

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    class AnsibleModuleStub:
        def __init__(self):
            self.params = {'fibre_channel_wwn': []}

        def fail_json(self, msg):
            self.msg = msg


    original_get_file_lines = get_file_lines


# Generated at 2022-06-22 23:47:41.905173
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:47:49.695717
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert 'linux' in fcwwn._platform_callbacks
    assert 'sunos' in fcwwn._platform_callbacks
    (name, callback) = fcwwn._platform_callbacks['linux']
    assert name == 'fibre_channel_wwn'
    assert callable(callback)

# Generated at 2022-06-22 23:48:02.336608
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    module = 'test_module'
    collected_facts = {}

    # first test: no Fibre-Channel initiator present
    try:
        fc_facts = FcWwnInitiatorFactCollector().collect(module, collected_facts)
        assert not fc_facts
    except ImportError:
        # avoid that unit test fails if module cannot be mocked
        pass

    # second test: fake Fibre-Channel initiator present
    class MockModuleUtilsModule(object):
        """Mocked AnsibleModule"""
        def get_bin_path(self, exe, opt_dirs=[]):
            '''Mocked' AnsibleModule.get_bin_path()'''

# Generated at 2022-06-22 23:48:05.051037
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert isinstance(obj, FcWwnInitiatorFactCollector)
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-22 23:48:16.962520
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_collector = FcWwnInitiatorFactCollector()
    # prepare 'fake' module
    class TestModule:
        def get_bin_path(self, a, b):
            return a
        def run_command(self, cmd):
            return 0, cmd, None
    # define available wwns
    wwns = ['0x10000090fa1658de', '0x21000014ff52a9bb']
    # define mocked functions
    def mocked_get_file_lines(file_path):
        return wwns
    # do the test
    fc_collector.get_file_lines = mocked_get_file_lines
    collected_facts = fc_collector.collect(TestModule())
    # ensure we collected all wwns

# Generated at 2022-06-22 23:48:21.550626
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    myFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert myFcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:25.190981
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids != set()

# Generated at 2022-06-22 23:48:38.203767
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # set up some test data
    class FakeModule(object):
        @staticmethod
        def run_command(cmd):
            """
            fake method for module.run_command
            """
            # just a generic call
            if cmd.startswith("lsdev -Cc adapter -l fcs"):
                return 0, 'fcs3 Available 00-08-00-16-FA-52-A9-BB', None
            # check for lscfg command
            if cmd.startswith("lscfg -vl fcs3"):
                return 0, 'Network Address.............10000090FA551509', None
            # check for ioscan command

# Generated at 2022-06-22 23:48:40.247975
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:48:51.105312
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    fc_fact_collector = get_collector_instance(FcWwnInitiatorFactCollector)
    fc_fact_collector.collect()
    facts = fc_fact_collector.get_facts()

    assert 'fibre_channel_wwn' in facts
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:48:51.736170
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:48:56.110542
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for:
    ansible.module_utils.facts.collectors.network.fibre_channel_wwn.FcWwnInitiatorFactCollector
    method: collect
    """
    # TODO: implement assert
    print("NOTIMPLEMENTED")
    pass

# Generated at 2022-06-22 23:49:09.409961
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    cmd = '/usr/bin/true'


# Generated at 2022-06-22 23:49:13.321954
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()
    assert collector.priority == 50

# Generated at 2022-06-22 23:49:25.931324
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    test1 = """
    0x21000014ff52a9bb
    """
    test2 = """
    # fcinfo hba-port  | grep "Port WWN"
    HBA Port WWN: 10000090fa1658de
    """

# Generated at 2022-06-22 23:49:29.383313
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.collect() == {}
    assert collector._fact_ids == {'fibre_channel_wwn'}

# Generated at 2022-06-22 23:49:41.709616
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # get the class name of the FcWwnInitiatorFactCollector class
    cls_name = FcWwnInitiatorFactCollector.__name__
    cls = getattr(sys.modules[__name__], cls_name)

    # instantiate an object of the FcWwnInitiatorFactCollector class
    fc_collector = cls()

    # check the value of the name attribute
    assert fc_collector.name == 'fibre_channel_wwn'

    # check the value of the _fact_ids attribute
    expected_fact_ids = set()
    assert fc_collector._fact_ids == expected_fact_ids

    # check the value of the collect method
    assert type(fc_collector.collect()) == dict


# Generated at 2022-06-22 23:49:45.262357
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwwn = FcWwnInitiatorFactCollector()
    assert fcwwwn.name == 'fibre_channel_wwn'
    assert fcwwwn._fact_ids == set()

# Generated at 2022-06-22 23:49:50.186088
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_init_fc = FcWwnInitiatorFactCollector()
    assert fc_wwn_init_fc.name == 'fibre_channel_wwn'
    assert fc_wwn_init_fc._fact_ids == set()

# Generated at 2022-06-22 23:49:55.047599
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fcwwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-22 23:50:07.770246
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.utils import ModuleUtilsLegacyFactCollectionDeprecationWarning
    import warnings

    from ansible.module_utils.facts.collector import Collector

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        c = FcWwnInitiatorFactCollector()

        # Test with missing module (i.e. no module on Windows)
        facts_dictionary = c.collect()
        assert facts_dictionary == {}
        assert len(w) == 1
        assert issubclass(w[-1].category, ModuleUtilsLegacyFactCollectionDeprecationWarning)
        assert "FcWwnInitiatorFactCollector is kept for backwards compat" in str(w[-1].message)

        # Test with module with no run_command (

# Generated at 2022-06-22 23:50:20.719282
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    # create test object
    FcWwnInitiatorFactCollectorObj = FcWwnInitiatorFactCollector()

    # create mock module
    mock_module_args = {}
    mock_module = basic.AnsibleModule(argument_spec=mock_module_args)
    mock_module.run_command = MagicMock(return_value=(0, 'output', ''))
    mock_module.get_bin_path = MagicMock(return_value='/bin/ls')

    # collect facts
    ansible_facts = collector.collect(mock_module)

    # check we got correct results
    assert len(ansible_facts['fibre_channel_wwn']) >= 0

# Generated at 2022-06-22 23:50:23.607405
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    #Initialize class
    factCollector = FcWwnInitiatorFactCollector()

    # Check name
    assert factCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:26.404048
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:30.639229
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import ansible_facts

    fc = FcWwnInitiatorFactCollector(None, ansible_facts)
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:32.359313
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert FcWwnInitiatorFactCollector.collect() is not None

# Generated at 2022-06-22 23:50:38.119144
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fc = FcWwnInitiatorFactCollector()
    assert fc_fc.name == 'fibre_channel_wwn'
    assert fc_fc._fact_ids == set()
    assert fc_fc.collect() == {}
    assert fc_fc._fact_ids == set()


# Generated at 2022-06-22 23:50:40.027173
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    foo = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:43.863770
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn = FcWwnInitiatorFactCollector()

    # test collection on current platform for correct result keys
    result = fcwwn.collect()
    assert isinstance(result, dict)
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-22 23:50:45.963289
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == "fibre_channel_wwn"


# Generated at 2022-06-22 23:50:48.324723
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    result = FcWwnInitiatorFactCollector.collect()
    print(result)

# Generated at 2022-06-22 23:50:50.841298
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == "fibre_channel_wwn"
    assert fcwwnfc._fact_ids == set()

# Generated at 2022-06-22 23:50:52.691355
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class_inst = FcWwnInitiatorFactCollector()
    assert class_inst.collect()

# Generated at 2022-06-22 23:51:00.011343
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {'fibre_channel_wwn': []}
    fc_facts['fibre_channel_wwn'].append('21000014ff52a9bb')

    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert facts == fc_facts

# Generated at 2022-06-22 23:51:06.786966
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import doctest
    import sys
    import tempfile
    # Because we run our unit test in a non-Linux system, mock the
    # behaviour of sys.platform and the existence of files in /sys/class/fc_host path.
    # Note that we mock open() method to handle multiple open() calls.

# Generated at 2022-06-22 23:51:10.166116
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    unit test for FcWwnInitiatorFactCollector()
    """
    fc = FcWwnInitiatorFactCollector()
    print(fc)

# Generated at 2022-06-22 23:51:14.471584
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcf = FcWwnInitiatorFactCollector()
    assert fcf.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fcf._fact_ids

# Generated at 2022-06-22 23:51:19.353286
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:23.052671
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:26.910605
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()


# Generated at 2022-06-22 23:51:33.374470
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fwwn = FcWwnInitiatorFactCollector()
    data = fwwn.collect()
    # at least one facet should exist
    assert 'fibre_channel_wwn' in data
    # if 'fibre_channel_wwn' is empty, a warning message should be there
    # assert len(data['fibre_channel_wwn']) > 0 or len(data['_warnings']) > 0

# Generated at 2022-06-22 23:51:39.844785
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:41.654276
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()

# Generated at 2022-06-22 23:51:47.443354
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = {}
            self.bin_path = {}
            self.run_command_rc = 0

        def get_bin_path(self, exe, opt_dirs=[]):
            cmd = self.bin_path[exe]
            if cmd:
                return cmd
            else:
                return ""

        def run_command(self, cmd, check_rc=False):
            # print(cmd)
            if cmd == 'fcinfo hba-port':
                return (self.run_command_rc, fcinfo_out, "")
            if cmd == 'lscfg -vpl fcs3':
                return (self.run_command_rc, lscfg_out, "")

# Generated at 2022-06-22 23:51:50.460339
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:54.614017
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fct = FcWwnInitiatorFactCollector()
    assert fct.name == 'fibre_channel_wwn'
    assert fct._fact_ids == set()

# Generated at 2022-06-22 23:52:04.435544
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import mock

    def mock_glob(path):
        return ['/sys/class/fc_host/host0/port_name', '/sys/class/fc_host/host1/port_name']

    def mock_get_file_lines(file):
        lines = list()
        lines.append('0x21000014ff52a9bb')
        lines.append('0x21000014ff52a9bb')
        return lines

    def mock_system(system):
        return 'linux'

    test_fc_facts = dict()
    test_fc_facts['fibre_channel_wwn'] = ['21000014ff52a9bb', '21000014ff52a9bb']


# Generated at 2022-06-22 23:52:10.517960
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


if __name__ == '__main__':
    # Unit test for constructor of class FcWwnInitiatorFactCollector
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:52:13.700118
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == facts.name
    assert 'fibre_channel_wwn' in facts._fact_ids

# Generated at 2022-06-22 23:52:26.896429
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = None
    test_module_utils = None
    test_module_utils_module = None
    test_utils_module_get_bin_path = None

    # prepare mocks
    # --------------------------------------------------
    # class mock_module_utils(object):
    #    @staticmethod
    #    def get_bin_path(app, opt_dirs=None):
    #        if app == "fcinfo":
    #            return "fcinfo"
    #        if app == "fcmsutil":
    #            return "fcmsutil"
    #        if app == "lscfg":
    #            return "lscfg"
    #        if app == "ioscan":
    #            return "ioscan"
    #        if app == "lsdev":
    #            return "lsdev"
    #

# Generated at 2022-06-22 23:52:32.413896
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    # create and populate module for test
    module = AnsibleModule(argument_spec={})
    module.run_command = run_command_mock

    # create and populate collector instance for test
    collector = get_collector_instance(FcWwnInitiatorFactCollector, module)
    # check returned instance is of expected type
    assert isinstance(collector, BaseFactCollector)

    # check returned dictionary content
    assert collector.collect() == {'fibre_channel_wwn': ['10000090fa551509']}


# Generated at 2022-06-22 23:52:41.732180
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    wwns = fc_fact_collector.collect()
    assert 'fibre_channel_wwn' in wwns
    assert len(wwns['fibre_channel_wwn']) > 0, "WWN is empty"
    assert '0x21000014ff52a9bb' in wwns['fibre_channel_wwn']

test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:52:49.470098
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    # prepare test data
    module = type('', (), dict(run_command=lambda args, check_rc=True: (0, '', '')))()
    # prepare test object
    FcWwnInitiatorFactCollectorObj = FcWwnInitiatorFactCollector()
    # test
    assert {} == FcWwnInitiatorFactCollectorObj.collect(module)


# Generated at 2022-06-22 23:52:52.172515
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:53:01.859560
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcWwnInitiatorFactCollector: test method collect
    """

    class MockModule(object):
        def __init__(self, params, platform):
            self.params = params
            self.platform = platform

        def get_bin_path(self, binary, opt_dirs=[]):
            if self.params == "fail":
                return None
            else:
                # special case: return a fake command on solaris platform
                if self.platform.startswith('sunos'):
                    if binary in ['fcinfo']:
                        return '/usr/sbin/fcinfo'
                return binary

        def run_command(self, cmd, check_rc=True):
            return 0, "", ""

    platform = sys.platform

    # create an instance of the MockModule class

# Generated at 2022-06-22 23:53:03.643912
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:16.820894
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collections import fc_wwn_initiator
    from ansible.module_utils.facts.collections.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import remove_internal_keys
    import json

    # When module is not available the result should be empty
    module = None
    collected_facts = Collector()
    fcwwn_collector = FcWwnInitiatorFactCollector()
    result = fcwwn_collector.collect(module, collected_facts)

    assert 'fibre_channel_wwn' not in result

# Generated at 2022-06-22 23:53:20.492584
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import ModuleFacts
    fact_collector = FcWwnInitiatorFactCollector()
    module_facts = ModuleFacts(None, fact_collector)
    assert fact_collector == module_facts.collect()

# Generated at 2022-06-22 23:53:22.108242
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:53:34.242045
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    fc_facts = dict()
    fc_facts['fibre_channel_wwn'] = ['10000090fa1658de']

    class MockModule(object):
        def get_bin_path(self, command, opt_dirs=[]):
            return sys.platform.startswith('aix') and command is 'lsdev' and command is 'lscfg'
        def run_command(self, command):
            return (0, '', '')
        def fail_json(self, **kwargs):
            pass

    class MockFactCollector(BaseFactCollector):
        def __call__(self):
            return dict()


# Generated at 2022-06-22 23:53:38.873439
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    expected = {
        'fibre_channel_wwn': ['10000090fa1658de']
    }
    if sys.platform.startswith('sunos'):
        import unittest

        module = unittest.mock.Mock()
        facts = FcWwnInitiatorFactCollector().collect(module=module)
        assert facts == expected



# Generated at 2022-06-22 23:53:45.237351
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This test should be improved after the method collect
    of class FcWwnInitiatorFactCollector has been changed.
    """
    module = AnsibleModule(argument_spec={})
    result = FcWwnInitiatorFactCollector().collect(module=module)
    assert type(result) is dict
    # assert len(result['fibre_channel_wwn']) == 1
    assert type(result['fibre_channel_wwn']) is list

# Generated at 2022-06-22 23:53:46.174920
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:53:47.128554
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    #TBD
    pass

# Generated at 2022-06-22 23:53:58.006096
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module_args
    from ansible.module_utils.facts import ansible_collections

    TestFcWwnInitiatorFactCollector = ansible_collections.ansible.misc.plugins.module_utils.facts.collectors.fibre_channel.fc_wwn_initiator.FcWwnInitiatorFactCollector

    # with no parameters
    module = mock_module_args()
    test_collector = TestFcWwnInitiatorFactCollector()
    result = test_collector.collect(module=module)
    assert result == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:54:07.905449
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_lines

    fc_facts = FcWwnInitiatorFactCollector(None, Collector)
    fc_facts.collect()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert callable(fc_facts.collect)
    assert fc_facts.fibre_channel_wwn is not None
    assert fc_facts.fibre_channel_wwn is not []
    assert fc_facts.fibre_channel_wwn is not ''

# Generated at 2022-06-22 23:54:09.080243
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:54:12.982716
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule({'command': 'echo "test_FcWwnInitiatorFactCollector_collect"', 'run_command': run_command})
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert fc_facts is not None

# Generated at 2022-06-22 23:54:24.484710
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ test method collect of class FcWwnInitiatorFactCollector """

    import sys
    import unittest
    from ansible.module_utils.facts.utils import get_file_lines

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):

        def setUp(self):
            self.fc_facts = { 'fibre_channel_wwn' : [] }
            self.collector = FcWwnInitiatorFactCollector()

        def test_collect_no_fc(self):
            """ Test for systems without fibre channel adapters """

            fc_facts_out = self.collector.collect()
            self.assertEqual(set(fc_facts_out.keys()), set(self.fc_facts.keys()))

# Generated at 2022-06-22 23:54:27.572342
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.collect() is not None

# Generated at 2022-06-22 23:54:30.263411
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:41.495100
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # get test data provider
    test_data = FcWwnInitiatorFactCollectorTestData()
    # get test data
    test_data_items = test_data.get_items()
    for test_data_item in test_data_items:
        # init test input
        collected_facts = test_data_item.get_collected_facts()
        module = test_data_item.get_module()
        # call method
        fact_collector = FcWwnInitiatorFactCollector()
        facts = fact_collector.collect(module, collected_facts)
        # get expected result data
        expected_facts = test_data_item.get_expected_facts()
        # compare both data structures
        assert facts == expected_facts

# Unit test class

# Generated at 2022-06-22 23:54:53.555020
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Initialize
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel import FcWwnInitiatorFactCollector
    fcwwnfact = FcWwnInitiatorFactCollector()
    test_obj = BaseFactCollector()
    # Run
    result = fcwwnfact.collect(test_obj)
    # Assert
    assert fcwwnfact.name == 'fibre_channel_wwn'
    assert isinstance(result, dict)
    assert isinstance(result['fibre_channel_wwn'], list)
    assert len(result['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:54:57.192494
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    # print(f.name)
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()

# Generated at 2022-06-22 23:54:57.560123
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert True

# Generated at 2022-06-22 23:55:00.498843
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:13.153746
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    import platform
    TEST_PLATFORM = platform.system()
    # if platform is not linux or sunos or aix or hp-ux skip this test
    if not TEST_PLATFORM in ['Linux', 'SunOS', 'AIX', 'HP-UX']:
        return True
    from ansible.module_utils.facts.collector import BaseFactCollector, Collector
    from ansible.module_utils.facts.utils import get_file_lines, get_file_content
    collect = BaseFactCollector().collect
    # short version of the class to be tested
    class FcWwnInitiatorFactCollector(BaseFactCollector):
        name = 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:19.360369
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc.collected_facts

# Generated at 2022-06-22 23:55:23.384682
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    result = fact_collector.collect()
    assert type(result) is dict
    assert result == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:55:24.762535
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector, object)

# Generated at 2022-06-22 23:55:26.849003
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert isinstance(fc, FcWwnInitiatorFactCollector)


# Generated at 2022-06-22 23:55:30.077927
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert isinstance(fc_facts._fact_ids, set)

# Generated at 2022-06-22 23:55:41.681212
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.collectors.fibre_channel as fc
    import ansible.module_utils.facts.system.platform as platform
    # create fake module object
    class FakeModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg, opt_dirs=None):
            # emulate fcinfo hba-port command
            if arg == 'fcinfo':
                return "/usr/sbin/fcinfo"
            return None

# Generated at 2022-06-22 23:55:51.691772
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # init an instance
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    # # test method collect
    # # if os is linux
    sys.platform='linux'
    # # if no device defined
    fc_wwn_collector._read_file_lines=lambda path:[]
    assert fc_wwn_collector.collect() == {'fibre_channel_wwn': [] }
    # # if device is defined
    fc_wwn_collector._read_file_lines=lambda path:['0x21000014ff52a9bb']
    assert fc_wwn_collector.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb'] }
    # # if os is solaris