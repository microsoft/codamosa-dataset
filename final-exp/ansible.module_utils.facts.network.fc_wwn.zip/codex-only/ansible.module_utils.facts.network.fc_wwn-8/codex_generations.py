

# Generated at 2022-06-22 23:45:45.376258
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    print("fc_facts: ", fc_facts)
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:45:58.091214
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import FactsParseError
    import pprint
    import json

    _factory = BaseFactCollector.get_collection_factory()
    assert _factory is not None

    if sys.platform == 'sunos':
        expected_data = {'fibre_channel_wwn': ['10000090fa1658de']}
    elif sys.platform == 'hp-ux':
        expected_data = {'fibre_channel_wwn': ['0x50060b00006975ec']}
    elif sys.platform == 'aix':
        expected_data = {'fibre_channel_wwn': ['10000090FA551509']}
    else:
        expected_

# Generated at 2022-06-22 23:46:00.478899
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:04.847402
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FC_TEST_LINUX = """
0x21000014ff52a9bb
"""
    FC_TEST_SOLARIS11 = """
HBA Port WWN: 10000090fa1658de
"""
    FC_TEST_AIX = """
fcs0 Available 04-08-00            Fibre Channel-SCSI Adapter (df1000fcs)
fcs1 Available 04-08-01            Fibre Channel-SCSI Adapter (df1000fcs)
fcs2 Available 04-08-02            Fibre Channel-SCSI Adapter (df1000fcs)
"""

    FC_TEST_SOLARIS10_AIX_OUTPUT = """
        Network Address.............10000090FA551509
"""

# Generated at 2022-06-22 23:46:12.344286
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # set up parameters needed for __init__
    facts_module = ''
    name = 'fibre_channel_wwn'
    # create FcWwnInitiatorFactCollector instance
    test_inst = FcWwnInitiatorFactCollector(facts_module, name)
    # test if instance is of right type
    if not isinstance(test_inst, FcWwnInitiatorFactCollector):
        raise AssertionError(
            'Should be an instance of FcWwnInitiatorFactCollector')
    # test if instance name attribute is set correctly
    if name != test_inst.name:
        raise AssertionError(
            'Name attribute of instance not set to %s' % name)

# Generated at 2022-06-22 23:46:23.509918
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test collect method of class FcWwnInitiatorFactCollector
    """

    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys
    # UnitTest class does not have a run_command() method
    class MockModule(object):
        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'lsdev':
                return '/usr/sbin/lsdev'
            elif path == 'lscfg':
                return '/usr/sbin/lscfg'
            elif path == 'ioscan':
                return '/sbin/ioscan'
            elif path == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'

# Generated at 2022-06-22 23:46:24.869753
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:29.281778
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test correct creation of a FcWwnInitiatorFactCollector object.
    """
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids  # pylint: disable=protected-access


# Generated at 2022-06-22 23:46:41.827248
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self, result):
            self.result = result

        def run_command(self, cmd):
            return self.result

        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif cmd == 'lsdev':
                return '/usr/sbin/lsdev'
            elif cmd == 'lscfg':
                return '/usr/sbin/lscfg'
            elif cmd == 'ioscan':
                return '/usr/sbin/ioscan'
            elif cmd == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            else:
                return None

    # on solaris 10 or solaris 11 should use `

# Generated at 2022-06-22 23:46:53.897602
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    m = ansible_facts.AnsibleModule(argument_spec={})
    m._name = 'FcWwnInitiatorFactCollector'
    c = Collector(m, 'fc_wwn_initiator', [], [FcWwnInitiatorFactCollector])
    c.collect()
    assert 'fibre_channel_wwn' in m.ansible_facts

# Generated at 2022-06-22 23:46:58.465451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    FcWwnInitiatorFactCollector.collect(test_module)
    assert test_module.exit_json.called

# Generated at 2022-06-22 23:47:04.455889
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import loader
    from ansible.module_utils.facts.collectors.fibre_channel import FcWwnInitiatorFactCollector
    assert len(FcWwnInitiatorFactCollector().collect().keys()) > 0



# Generated at 2022-06-22 23:47:06.913922
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-22 23:47:19.395679
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    module_mock = Mock()

    sys.platform = 'linux'
    fcwwn_collector = FcWwnInitiatorFactCollector(module_mock)
    assert fcwwn_collector.name == 'fibre_channel_wwn'
    assert isinstance(fcwwn_collector.collect(), dict)
    assert fcwwn_collector.collect()['fibre_channel_wwn'] == ['21000014FF52A9BB']

    """
    on solaris 10 or solaris 11 should use `fcinfo hba-port`
    TBD (not implemented): on solaris 9 use `prtconf -pv`
    """
    sys.platform = 'sunos'

# Generated at 2022-06-22 23:47:30.024758
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method FcWwnInitiatorFactCollector.collect()
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.fallback import FallbackCollector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.utils import permute_dict
    import sys
    import platform

    class Module(object):
        def __init__(self):
            self._platform = platform
            self._sys = sys

        def get_bin_path(self, *args, **kwargs):
            return "/bin/cmd"
            # return "/bin/cmd"

        def run_command(self, *args, **kwargs):
            return 0, [], ""
            # return 0, [],

# Generated at 2022-06-22 23:47:37.520170
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_collector = FcWwnInitiatorFactCollector()
    # move to test/lib/ansible/module_utils/facts/ and run `python -m pytest .\test_fc_wwn.py`
    fc_data = fc_collector.collect()
    assert len(fc_data) > 0
    
test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:47:42.361744
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''
    Unit test for constructor of class FcWwnInitiatorFactCollector
    '''
    cls = FcWwnInitiatorFactCollector()
    assert cls.name == 'fibre_channel_wwn', \
            'Failed to instantiate FcWwnInitiatorFactCollector'

# Generated at 2022-06-22 23:47:42.762061
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:47:54.079031
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Runs collect method of FcWwnInitiatorFactCollector class
    without specifying any parameter.
    """
    print("\n\n############### Test 'collect' method of class FcWwnInitiatorFactCollector ###############\n")
    fc_collector = FcWwnInitiatorFactCollector()
    result = fc_collector.collect()
    print("Return value of collect method: ")
    print(result)

if __name__ == '__main__':
    # Test the method 'collect' of class 'FcWwnInitiatorFactCollector'
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:47:56.401049
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:47:59.580014
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcObj = FcWwnInitiatorFactCollector()
    assert fcObj.name == 'fibre_channel_wwn'
    assert fcObj._fact_ids == set()

# Generated at 2022-06-22 23:48:03.301510
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect(module)
    # TBD
    assert facts == {}

# Generated at 2022-06-22 23:48:08.935298
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Method collect of class FcWwnInitiatorFactCollector
    """
    import sys
    sys.path.append('.')
    fs_facts_collector = FcWwnInitiatorFactCollector()
    result = fs_facts_collector.collect()
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-22 23:48:10.168484
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:13.263548
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_file = FcWwnInitiatorFactCollector()
    assert fcwwn_file.name == 'fibre_channel_wwn'
    

# Generated at 2022-06-22 23:48:15.958394
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:22.188721
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)  # pylint: disable=protected-access
    assert fc._fact_ids == set()  # pylint: disable=protected-access

# Generated at 2022-06-22 23:48:26.020207
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_fc = FcWwnInitiatorFactCollector()
    assert test_fc.name == 'fibre_channel_wwn'
    assert test_fc._fact_ids == set()
    assert test_fc.collect() == {}

# Generated at 2022-06-22 23:48:27.499195
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:48:31.355971
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_object = FcWwnInitiatorFactCollector()
    assert test_object
    assert 'fibre_channel_wwn' == test_object.name
    assert test_object._fact_ids == set()


# Generated at 2022-06-22 23:48:35.901980
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()



# Generated at 2022-06-22 23:48:40.320830
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwf = FcWwnInitiatorFactCollector()
    assert fwf.name == 'fibre_channel_wwn'
    assert fwf._fact_ids == set(['fibre_channel_wwn'])
    assert fwf._platform == 'all'

# Generated at 2022-06-22 23:48:44.148539
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()

# Generated at 2022-06-22 23:48:49.345845
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    myFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert myFcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:49:02.717327
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
        from ansible.module_utils.facts import gather_facts
        from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

        FcWwnInitiatorFactCollector._fact_ids = set()

        # no facts at all without init
        assert {} == FcWwnInitiatorFactCollector.collect()

        # init twice doesn't matter
        FcWwnInitiatorFactCollector.init()
        FcWwnInitiatorFactCollector.init()

        # collect facts
        facts = gather_facts(dict(gather_subset=['all']))
        #print(json.dumps({'facts': facts}, indent=4))

# Generated at 2022-06-22 23:49:04.985746
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:10.705946
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_results = FcWwnInitiatorFactCollector()

    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector == fc_results.__class__
    assert FcWwnInitiatorFactCollector.name == fc_results.name
    assert 'fibre_channel_wwn' in fc_results._fact_ids

# Generated at 2022-06-22 23:49:16.376976
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()
    return True

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:17.823490
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:22.312764
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test to create an instance of class FcWwnInitiatorFactCollector
    """
    obj = FcWwnInitiatorFactCollector()
    assert isinstance(obj, FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:49:23.694589
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Returns the facts of this collector."""


# Generated at 2022-06-22 23:49:27.761423
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert fc_wwn._fact_ids == set()


# Generated at 2022-06-22 23:49:30.311209
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fake_module = lambda: 0
    fw = FcWwnInitiatorFactCollector(fake_module)
    assert fw.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:35.279457
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = MockAnsibleModule()
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert type(fc_facts) is dict
    assert type(fc_facts['fibre_channel_wwn']) is list



# Generated at 2022-06-22 23:49:47.022267
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    from ansible.module_utils.facts.network.fibre_channel_wwn import FcWwnInitiatorFactCollector

    from mock import patch, MagicMock

    # Create a tested instance of FcWwnInitiatorFactCollector class
    FcWwnInitiatorFactCollector_instance = FcWwnInitiatorFactCollector()

    # Create a mocked instance of AnsibleModule class
    module_instance = MagicMock(spec=basic.AnsibleModule)

    # Create a mocked instance of BaseFactCollector class
    BaseFactCollector_instance = MagicMock(spec=collector.BaseFactCollector)

    # Create a mocked instance of DeprecatedFactCollector class
    DeprecatedFactCollector

# Generated at 2022-06-22 23:49:50.545591
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Test if FcWwnInitiatorFactCollector is in fact a subclass of BaseFactCollector

# Generated at 2022-06-22 23:50:02.910607
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_host = {}
    test_host['ansible_module_commands'] = {}
    test_host['ansible_module_commands']['fcinfo hba-port'] = "HBA Port WWN: 10000090fa1658de"

# Generated at 2022-06-22 23:50:05.707089
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:09.465664
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj
    assert test_obj.name == 'fibre_channel_wwn'
    assert test_obj._fact_ids == set()


# Generated at 2022-06-22 23:50:13.248013
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()


# Generated at 2022-06-22 23:50:25.126751
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """

    # Create an instance of FcWwnInitiatorFactCollector and run test
    print("Test method collect of class FcWwnInitiatorFactCollector")
    fc_collector = FcWwnInitiatorFactCollector()
    result = fc_collector.collect()
    print("Facts: %s" % result)
    print("")
    if result:
        print("Test PASSED")
    else:
        print("Test FAILED")


# Run test when module is standalone
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:50:27.452865
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:30.391502
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:43.095119
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts import collector

    # test with a fake module that has no params
    # Mocking class AnsibleModule
    class FakeAnsibleModule:
        def __init__(self):
            self.exit_json = lambda x, y: None
        def get_bin_path(self, bin_name, opt_dirs=[]):
            # for linux return first bin_name, for solaris return second bin_name
            return "/bin/ls"

    # Mocking class AnsibleModule._ansible_module
    class FakeAnsibleFactsModule:
        def __init__(self):
            self.params = dict()

# Generated at 2022-06-22 23:50:52.146627
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.cache import FactsCache
    from ansible.module_utils.facts import ansible_collector
    import tempfile
    import shutil
    import os
    import platform

    # override the config file
    def cleanup():
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
    temp_dir = tempfile.mkdtemp()
    config_file = os.path.join(temp_dir, "ansible.cfg")
    with open(config_file, "w") as f:
        f.write("[defaults]\n")
        f.write("fact_caching_connection = local\n")

# Generated at 2022-06-22 23:50:57.623152
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.facts.fibre_channel_wwn import FcWwnInitiatorFactCollector as FcWwn
    fcwwn_c = FcWwn()
    fcwwn_c.collect()

# Generated at 2022-06-22 23:51:07.137698
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule:
        @staticmethod
        def get_bin_path(arg1, opt_dirs=None):
            if arg1 == 'ioscan':
                return '/bin/ioscan'
            if arg1 == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            if arg1 == 'fcinfo':
                return '/usr/sbin/fcinfo'
            return None

        @staticmethod
        def run_command(arg1):
            if arg1 == '/bin/ioscan -fnC FC':
                return 0, "/dev/fcd0                                            fcd   0/3/0/0/0.0.c000\n"

# Generated at 2022-06-22 23:51:18.201806
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    try:
        import platform
        os_platform = platform.system()
    except:
        os_platform = 'linux'
    if os_platform == 'SunOS':
        from ansible.module_utils.facts.collector.solaris.fibre_channel_wwn import FcWwnInitiatorFactCollector
    elif os_platform == 'Linux':
        from ansible.module_utils.facts.collector.linux.fibre_channel_wwn import FcWwnInitiatorFactCollector
    elif os_platform == 'AIX':
        from ansible.module_utils.facts.collector.aix.fibre_channel_wwn import FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:51:21.050606
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj
    assert test_obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:51:32.979803
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    import os

    # test for linux
    sys.modules['ansible.module_utils.basic'] = basic
    os.environ['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    assert result['fibre_channel_wwn'] == ['21000014ff52a9bb']

    # test for solaris
    sys.platform = 'sunos5'
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    assert result['fibre_channel_wwn'] == ['10000090fa1658de']

    # test for aix

# Generated at 2022-06-22 23:51:37.816200
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    fcwwn = FcWwnInitiatorFactCollector()
    print(fcwwn.collect())

# Generated at 2022-06-22 23:51:41.052268
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert hasattr(collector, '_fact_ids')

# Generated at 2022-06-22 23:51:44.211106
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_init = FcWwnInitiatorFactCollector()

    # Assertions
    assert fc_wwn_init is not None
    assert fc_wwn_init.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:46.287039
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:50.913865
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    # test if instantiation of class do not throw
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:52:02.480377
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    m = builtins.__dict__['modules']
    m['ansible_facts'] = {'ansible_system': sys.platform}
    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_fact_collector.collect()
    try:
        assert 'fibre_channel_wwn' in fc_facts
    except AssertionError:
        print("no fibre_channel_wwn found on %s" % sys.platform)
        print("got %s" % fc_facts)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:52:05.410852
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert(f.name == 'fibre_channel_wwn')

# Generated at 2022-06-22 23:52:18.030667
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import types
    import mock
    import os.path
    from ansible.module_utils.facts.utils import get_file_lines, get_file_content

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.facts.collector import BaseFactCollector

    # create a temp directory to store the test file, and cd
    with mock.patch('ansible.module_utils.facts.collector.os'):
        os.mkdir('/tmp/test')
        os.chdir('/tmp/test')

    # create a dummy file
    f = open('myfile', 'w')
    f.write('0x21000014ff52a9bb\n')

# Generated at 2022-06-22 23:52:30.599798
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import collections
    import os

    MockModule = collections.namedtuple('MockModule', ['get_bin_path'])
    MockModule.run_command = lambda x: (0, '', '')
    MockModule.get_bin_path.return_value = os.path.dirname(os.path.realpath(__file__)) + '/../../../hacking/test_data/bin/'

    # Linux
    sys.platform = lambda: 'linux2'
    fc_f = FcWwnInitiatorFactCollector()
    fc_f.collect(MockModule())
    assert fc_f.collect(MockModule()) == {'fibre_channel_wwn': ['000014ff52a9bb']}

    # Solaris

# Generated at 2022-06-22 23:52:32.797600
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn', 'obj.name should be "fibre_channel_wwn"'

# Generated at 2022-06-22 23:52:35.163367
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    fc_wwn_collector.collect()

# Generated at 2022-06-22 23:52:40.654682
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcargs = {}
    fcargs['ansible_facts'] = {}
    fc = FcWwnInitiatorFactCollector(fcargs, None)
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:52.556256
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    facts = FcWwnInitiatorFactCollector().collect(module)
    assert 'fibre_channel_wwn' in facts
    assert isinstance(facts['fibre_channel_wwn'], list)

    if sys.platform.startswith('linux'):
        assert facts['fibre_channel_wwn']
    elif sys.platform.startswith('sunos'):
        assert facts['fibre_channel_wwn']
    elif sys.platform.startswith('aix'):
        assert facts['fibre_channel_wwn']
    elif sys.platform.startswith('hp-ux'):
        assert facts['fibre_channel_wwn']

# Generated at 2022-06-22 23:53:02.164029
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    # test without OS dependent module_utils
    if sys.version_info[0] < 3:
        from ansible.module_utils.facts.collector.dummy_collector import DummyCollector
        collect_set = Collectors(None, FactManager())
        collect_set.add(NetworkCollector(None, collect_set))
        collect_set.add(DummyCollector(None, collect_set))

# Generated at 2022-06-22 23:53:15.130908
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import tempfile
    import os

    os_platform = platform.system()
    os_release = platform.release()
    facts = {}
    fcwwn = FcWwnInitiatorFactCollector(module=None)
    facts = fcwwn.collect(None, facts)
    if not os_platform.startswith(('linux')) and not os_platform.startswith(('aix')) and not os_platform.startswith(('sunos')) and not os_platform.startswith(('hp-ux')):
        assert not facts['fibre_channel_wwn']

# Generated at 2022-06-22 23:53:17.112873
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:53:22.403325
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method is called to generate test cases for method
    collect of class FcWwnInitiatorFactCollector
    """
    fact_collector = FcWwnInitiatorFactCollector()
    # check type of return value
    assert isinstance(fact_collector.collect(), dict)


# Unit test import of module FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:53:29.373670
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn', 'name of FcWwnInitiatorFactCollector should be fibre_channel_wwn'
    assert 'fibre_channel_wwn' in obj._fact_ids, 'fact_id fibre_channel_wwn should be in _fact_ids of FcWwnInitiatorFactCollector'

# Generated at 2022-06-22 23:53:33.932402
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    This is a test for constructor of class FcWwnInitiatorFactCollector.
    """
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-22 23:53:40.011580
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcf = FcWwnInitiatorFactCollector()
    assert fcf.name == 'fibre_channel_wwn'
    assert str(fcf._fact_ids) == 'set()', repr(fcf._fact_ids)


# Generated at 2022-06-22 23:53:42.735171
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert len(fc._fact_ids) == 0

# Generated at 2022-06-22 23:53:46.490896
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)


# Generated at 2022-06-22 23:53:59.235459
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector

    # create a temporary file
    __, tmpfile = tempfile.mkstemp()
    f = open(tmpfile, "w")
    f.write("0x21000014ff52a9bb")
    f.close()

    # create a temporary module
    class MockModule(object):
        def __init__(self, tmpfile):
            self.tmpfile = tmpfile

        def get_bin_path(self, *args, **kwargs):
            # in the unit test do not look for any binary
            return None

        def run_command(self, args):
            return 0, "", ""

    mockmodule = MockModule(tmpfile)

    fc_collector = FcWwnInitiator

# Generated at 2022-06-22 23:54:11.270743
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = None
    fc_fcinfo = ""
    fc_ioscan = ""
    fc_lsdev = ""

    # linux
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert type(fc_facts) == dict
    if sys.platform.startswith('linux'):
        assert fc_facts['fibre_channel_wwn'] == [
            '21000014ff52a9bb'
        ]

    # solaris
    fc_facts = FcWwnInitiatorFactCollector().collect(fcinfo_out=fc_fcinfo)
    assert type(fc_facts) == dict
    if sys.platform.startswith('sunos'):
        assert fc_facts['fibre_channel_wwn'] == []

   

# Generated at 2022-06-22 23:54:18.779290
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # To test the collect() method we have to first instantiate the Collector class
    collector_obj = Collector(None, None, None)
    fc_wwn_obj = FcWwnInitiatorFactCollector()
    fc_facts = fc_wwn_obj.collect(None, None)
    collector_obj.add_fact('fibre_channel_wwn', fc_facts['fibre_channel_wwn'])
    assert collector_obj.collected_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-22 23:54:31.431908
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    import requests_mock
    FcWwnInitiatorFactCollector._fact_ids = set()
    FcWwnInitiatorFactCollector.name = 'fibre_channel_wwn'
    collector = FcWwnInitiatorFactCollector()
    # set mocked facts for test
    facts_dict = {}
    facts_dict['fibre_channel_wwn'] = ['21000014ff52a9bb']
    # test the method collect in BaseFactCollector class
    result = collector.collect(collected_facts=facts_dict)
    # test if the result is a list

# Generated at 2022-06-22 23:54:34.534423
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc.collect().keys()

# Generated at 2022-06-22 23:54:36.981790
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'

FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:54:50.129140
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    class AnsibleModuleMock:
        def __init__(self, params):
            self.params = params
        def get_bin_path(self, name, opt_dirs=[]):
            if name == "fcinfo":
                return "/usr/sbin/fcinfo"
            elif name == "lsdev":
                return "/usr/sbin/lsdev"
            elif name == "lscfg":
                return "/usr/sbin/lscfg"

# Generated at 2022-06-22 23:54:54.106681
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert fc_wwn._fact_ids == set()

# Generated at 2022-06-22 23:54:55.837386
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible_collections.community.general.plugins.module_utils.facts import \
            FcWwnInitiatorFactCollector
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids is not None


# Generated at 2022-06-22 23:55:05.982149
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Runs ansible-facts for linux and checks results
    """
    import json
    import os.path
    from ansible.module_utils.facts.collector import BaseFactCollector
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '../../../'
    if os.path.exists('../../../ansible_collections/ansible/community/plugins/module_utils/tests/_data/legacy/test_FcWwnInitiatorFactCollector_collect.json'):
        result_file = '../../../ansible_collections/ansible/community/plugins/module_utils/tests/_data/legacy/test_FcWwnInitiatorFactCollector_collect.json'

# Generated at 2022-06-22 23:55:10.859836
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {'fibre_channel_wwn': ['0x21000014ff52a9bb']}
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()
    assert facts == fc_facts

# Generated at 2022-06-22 23:55:15.376351
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create class object
    item = FcWwnInitiatorFactCollector()
    # check if the object is created properly
    if item.name == 'fibre_channel_wwn' and item._fact_ids == set():
        print("Testcase Passed: object created successfully")
    else:
        print("Testcase Failed: object not created properly")

# Generated at 2022-06-22 23:55:19.306088
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:23.337577
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    # test if the collector is actually a FcWwnInitiatorFactCollector object
    assert isinstance(fc, FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:55:32.196340
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, '0x21000014ff52a9bb', ''),
                (0, '0x21000014ff52a9bc', ''),
                (0, 'HBA Port WWN: 10000090fa1658de\nHBA Port WWN: 10000090fa1658df', ''),
                (0, '        Network Address.............10000090FA551509\n        Network Address.............10000090FA551508\n', ''),
                (0, '             N_Port Port World Wide Name = 0x50060b00006975ec\n             N_Port Port World Wide Name = 0x50060b00006975ed\n', ''),
            ]

# Generated at 2022-06-22 23:55:36.378324
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == fc_facts

# Generated at 2022-06-22 23:55:47.903874
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    import os

    # create a temporary directory for unit test
    tempdir = os.path.dirname(__file__) + "/tempdir"

    os.mkdir(tempdir, 0o755)

    # create fake sys_class_fc_hosts directory
    # (standard linux)
    fake_sys_class_fc_hosts = tempdir + '/sys_class_fc_hosts'
    os.mkdir(fake_sys_class_fc_hosts, 0o755)
    os.mkdir(fake_sys_class_fc_hosts + "/host0", 0o755)