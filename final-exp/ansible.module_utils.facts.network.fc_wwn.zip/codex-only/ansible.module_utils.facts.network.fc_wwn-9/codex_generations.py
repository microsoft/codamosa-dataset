

# Generated at 2022-06-22 23:45:56.273167
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import unittest
    import ansible
    import ansible.module_utils.facts.utils as utils
    import ansible.module_utils.facts.collector as collector
    if sys.version_info[0] == 2:
        PLATFORM = 'linux2'
    else:
        PLATFORM = 'linux'
    class AnsibleModuleFake:
        def __init__(self):
            self.params = {}
            self.version_info = ansible.__version__
        def get_bin_path(self, name, opt_dirs=None):
            for d in ['/bin', '/usr/bin', '/opt/bin']:
                if os.path.isfile(os.path.join(d, name)):
                    return os.path.join(d, name)

# Generated at 2022-06-22 23:46:07.474259
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector"""
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector.fibre_channel import FcFactCollector
    import copy
    import os

    # If a file is present, we should check if the facts are being added.
    sys.modules['ansible'] = type('', (), {})()
    sys.modules['ansible.module_utils'] = type('', (), {})()
    sys.modules['ansible.module_utils.facts'] = type('', (), {})()

# Generated at 2022-06-22 23:46:07.868383
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  pass

# Generated at 2022-06-22 23:46:10.122656
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:46:12.356316
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj is not None


# Generated at 2022-06-22 23:46:23.512679
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Return correct values for fibre_channel_wwn
    """

    class Class():
        vars = dict()
        def __init__(self, value=None):
            self.value = value
            self.values = [self.value]
        def set(self, value):
            self.value = value
        def append(self, value):
            self.values.append(value)
        def get(self, key):
            return self.vars.get(key, self.value)
        def flip(self):
            if self.value == None:
                self.value = True
            else:
                self.value = None
        def put(self, key, value):
            self.vars[key] = value
        def set_result(self, **kwargs):
            self.result = kwargs



# Generated at 2022-06-22 23:46:25.732060
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert obj.collect() == {}


# Generated at 2022-06-22 23:46:36.195065
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_names
    from ansible.module_utils.facts.collectors import list_collectors
    from ansible.module_utils.facts.utils import FactsCollectorException

    FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in get_collector_names()
    assert FcWwnInitiatorFactCollector.name in [
        x.name for x in list_collectors()]
    assert isinstance(FcWwnInitiatorFactCollector, Collector)
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.fact_

# Generated at 2022-06-22 23:46:46.310310
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:46:48.591849
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert facts == {'fibre_channel_wwn': []}


# Generated at 2022-06-22 23:46:52.575802
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj
    assert obj.name == 'fibre_channel_wwn'
    assert obj.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:47:00.923028
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import pytest
    import os
    import sys

    test_name = "fibre_channel_wwn"
    test_path = os.path.realpath(os.path.dirname(__file__))
    fc = FcWwnInitiatorFactCollector(None, None, None)
    fc_facts = fc.collect(None, None)
    found = False

    for v in fc_facts['fibre_channel_wwn']:
        if v == '50060b00006975ec':
            found = True
    assert found == True

# Generated at 2022-06-22 23:47:13.699413
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    This is a unit test for the constructor of class FcWwnInitiatorFactCollector
    """

    # Constructor test without parameters
    try:
        FcWwnInitiatorFactCollector()
    except:
        # We expect an exception; this is correct
        pass
    else:
        # The constructor should have failed; report a error
        assert False, 'The constructor test of FcWwnInitiatorFactCollector shall fail.'

    # Constructor test with a bad parameter
    try:
        FcWwnInitiatorFactCollector(42)
    except:
        # We expect an exception; this is correct
        pass
    else:
        # The constructor should have failed; report a error
        assert False, 'The constructor test of FcWwnInitiatorFactCollector shall fail.'

    # Construct

# Generated at 2022-06-22 23:47:19.187717
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcfacts = FcWwnInitiatorFactCollector()
    assert fcfacts.name == 'fibre_channel_wwn'
    assert fcfacts._fact_ids == set()
    assert fcfacts.collect(collected_facts=None) == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:47:20.169880
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # N/A
    pass

# Generated at 2022-06-22 23:47:30.659513
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleArgsParser
    import ansible.module_utils.facts.names
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import ansible.module_utils.facts.collectors
    from ansible.module_utils.facts.collectors.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ModuleArgsParser
    import ansible.module_utils.facts.names

# Generated at 2022-06-22 23:47:34.617287
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x.collect() == {}

# Generated at 2022-06-22 23:47:37.962166
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'
    assert result._fact_ids == set()

# Generated at 2022-06-22 23:47:50.055581
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.utils import AnsibleCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils import basic

    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, arg1, opt_dirs=None):
            return "/bin/" + arg1

        def run_command(self, arg1):
            output = ""
            if 'lsdev' in arg1:
                output="""
fcs0 Available 02-08-00  FC Adapter
fcs1 Available 02-09-00  FC Adapter
fcs2 Defined   02-0a-00  FC Adapter"""

# Generated at 2022-06-22 23:47:53.715743
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert isinstance(x, BaseFactCollector)
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:58.124795
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """This is a constructor test for FcWwnInitiatorFactCollector class"""
    x = FcWwnInitiatorFactCollector()
    print("Success")

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:02.285216
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:48:13.837771
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class
    FcWwnInitiatorFactCollector
    """

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import tempfile
    module = type('', (), {})
    module.run_command = lambda x, **kwargs: (0, x, '')
    module.get_bin_path = lambda x, **kwargs: x
    test_dir = tempfile.mkdtemp()
    collector = Collector(test_dir, module)
    FcWwnInitiatorFactCollector.collect(collector)
    assert collector.data
    assert 'fibre_channel_wwn' in collector.data

# Generated at 2022-06-22 23:48:20.564490
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    # Constructor test:
    # Obj must be of type FcWwnInitiatorFactCollector
    obj = FcWwnInitiatorFactCollector()
    assert type(obj) is FcWwnInitiatorFactCollector
    # class variable `name` is set properly
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:31.963228
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcWwnInitiatorFactCollector_collect method is tested on CentOS and RedHat platforms

    :return:
    """

    # Create the module mock
    fake_module = type('module', (object,), {'get_bin_path': lambda self, name: '/bin/' + name.replace('-', '_')})()

    # Create the class instance
    fc_fact_collector = FcWwnInitiatorFactCollector(fake_module)

    # Create the expected results
    expected_results = dict(fibre_channel_wwn=['21000024ff58e728'])

    # if sys.platform.startswith('linux'):
    # Create the test data
    test_data = "0x21000024ff58e728"

    # Create the test file

# Generated at 2022-06-22 23:48:39.156359
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ unit test for method collect of class FcWwnInitiatorFactCollector """
    from ansible.module_utils.facts.system.fibre_channels import FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    facts = fc.collect()
    assert 'fibre_channel_wwn' in facts



# Generated at 2022-06-22 23:48:52.151868
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    ###################################################
    # If the below collection of facts is not working,
    # this needs to be improved.
    # For now, it is a good check to find out if the
    # collection code is broken.
    ###################################################
    import platform

    class ModuleFake:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return '/usr/sbin/fcinfo'
            if arg == 'lsdev':
                return '/usr/sbin/lsdev'
            if arg == 'lscfg':
                return '/usr/sbin/lscfg'

# Generated at 2022-06-22 23:48:54.560850
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:01.385423
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    :return:
    """
    collector = FcWwnInitiatorFactCollector()
    my_facts = collector.collect()
    assert my_facts is not None
    assert 'fibre_channel_wwn' in my_facts

# Generated at 2022-06-22 23:49:03.838306
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:05.902678
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """

    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:09.409682
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    givenCollector = Collector()
    fcwwn_collector = FcWwnInitiatorFactCollector(givenCollector)
    assert fcwwn_collector._collector == givenCollector

# Generated at 2022-06-22 23:49:22.832690
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import tempfile
    import os
    import shutil
    import glob

    def fake_module_get_bin_path(name, opt_dirs=[]):
        return name

    def fake_run_command(cmd):
        file_name = cmd.split(' ')[-1]
        with open(file_name, 'r') as file_d:
            return (0, file_d.read(), '')

    def fake_get_file_lines(file_name):
        with open(file_name, 'r') as file_d:
            return file_d.read().splitlines()

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 23:49:28.475677
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print('Test for method collect of class FcWwnInitiatorFactCollector')

    fc_facts_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_facts_collector.collect()

    print('fc_facts:')
    print(fc_facts)
    assert fc_facts

test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:49:36.675743
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append('10000090fa1658de')
    fc_facts['fibre_channel_wwn'].append('10000090FA551509')
    fc_facts['fibre_channel_wwn'].append('50060b00006975ec')
    assert FcWwnInitiatorFactCollector().collect() == fc_facts


# Generated at 2022-06-22 23:49:41.235881
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'
    assert isinstance(fc_obj._fact_ids, set)
    assert fc_obj._fact_ids == set()

# Generated at 2022-06-22 23:49:42.409901
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:45.077706
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:46.149388
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:48.130544
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collecto

# Generated at 2022-06-22 23:49:50.964628
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:52.816052
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert isinstance(f, BaseFactCollector)

# Generated at 2022-06-22 23:49:54.198684
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:06.986674
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    :return:
    '''
    from ansible.module_utils.facts.collector import collect_facts
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # create instance of FcWwnInitiatorFactCollector
    fc_fact_collector = FcWwnInitiatorFactCollector()

    # create base fact collector
    base_fact_collector = BaseFactCollector()
    collected_facts = {}
    collected_facts.update({'fact_id':'fact_id_value'})

# Generated at 2022-06-22 23:50:10.876569
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert fc.collect() == {}

# Generated at 2022-06-22 23:50:14.738425
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import ansible.module_utils.facts.collector as facts_collector
    import ansible.module_utils.facts.collectors.network as fcwwn_collector
    import ansible.module_utils.facts.utils as facts_utils
    import os

    module = facts_utils.AnsibleModuleMock()
    module.run_command.return_value = [0, "", ""]
    module.get_bin_path.return_value = '/bin/foo'

    mock_collector = facts_collector.BaseFactCollector()
    mock_collector.get_module.return_value = module

    def m_walk_sys(dir):
        if 'linux' in dir:
            return [[dir, ['fc_host'], ['port_name']], ]

# Generated at 2022-06-22 23:50:27.863596
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for FcWwnInitiatorFactCollector.collect """
    import ansible.module_utils.facts.collector
    # create a dummy module object
    module = ansible.module_utils.facts.collector.get_ansible_module_mock()
    # create a dummy command to get kernel version
    command_uname = 'uname -r'
    # set a return value for command
    module.run_command.return_value = 0, '2.6.32-573.el6.x86_64', ''
    # create a dummy fact array
    fact_array = [{'kernel': '2.6.32-573.el6.x86_64'}]
    # set a return value for fact_array
    module.parse_kv.return_value = fact_array
    #

# Generated at 2022-06-22 23:50:34.686436
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:35.693529
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-22 23:50:47.456741
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import get_cachefile
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # Initialize a Collector object
    collected_facts = Collector()

    # Initialize FcWwnInitiatorFactCollector class
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector(collected_facts=collected_facts)

    # Test the method collect with invalid cache
    assert not fc_wwn_initiator_fact_collector.collect(cache=get_cachefile())

    # Test the method collect with valid cache
    assert not fc_wwn_initiator_fact_

# Generated at 2022-06-22 23:50:52.106368
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_resp = FcWwnInitiatorFactCollector()
    assert fcwwn_resp.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:51:04.251053
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import unittest
    import tempfile
    import ansible.module_utils.facts.collector
    class MockModule(object):
        def run_command(self, cmd):
            if cmd.startswith('ioscan'):
                out = "/dev/fcd0 0/0/1/1/0.0.0050        /dev/fcd0"
                out = out + "/dev/fcd1 0/0/1/2/0.0.0051        /dev/fcd1"
                out = out + "/dev/fcd2 0/0/1/3/0.0.0052        /dev/fcd2"
                out = out + "/dev/fcd3 0/0/1/4/0.0.0053        /dev/fcd3"


# Generated at 2022-06-22 23:51:16.316041
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import base
    from ansible.module_utils.facts.collectors.network.fibre_channel import FcWwnInitiatorFactCollector as fact_collector
    from ansible.module_utils.facts.utils import get_file_lines

    # Create test environment
    if platform.system() == 'HP-UX':
        glob.glob = lambda a: ['/dev/fcd0']
        sys.platform = 'hp-ux'
        fcmsu_cmd_name = 'fcmsutil'

# Generated at 2022-06-22 23:51:28.454221
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import sys
    import glob
    import unittest
    import tempfile

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):

        # mock original method of class BaseFactCollector
        def _get_file_lines(self, path):
            test_file = tempfile.NamedTemporaryFile()
            print("0x21000014ff52a9bb\n0x21000014ff52a9bc\n0x21000014ff52a9bd", file=test_file)
            return get_file_lines(test_file.name)

        # mock original method of class BaseFactCollector
        def _glob(self, path):
            return ['%s/sys/class/fc_host/host0/port_name' % self._tempdir]


# Generated at 2022-06-22 23:51:33.675744
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    results = collector.collect()
    assert type(results['fibre_channel_wwn']) == list
    if sys.platform.startswith('linux'):
        assert len(results['fibre_channel_wwn']) > 0
    # TBD: implement unit tests for other platforms

# Generated at 2022-06-22 23:51:35.874592
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect()
    assert fc_facts is not None, "Dictionary expected, got None"

# Generated at 2022-06-22 23:51:43.497848
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method is not callable - the method is for unit test only.
    """
    # Imports are needed in this method, because it is not callable
    # otherwise and import occurs in the body of module only
    from ansible.module_utils.facts.collector import get_collector_instance
    import ansible.module_utils.facts.collector

    # create mock of module object
    class module:
        def __init__(self):
            self.run_command = ansible.module_utils.facts.collector.run_command

    m = module()

    # mock os.path.exists method
    class os:
        def __init__(self):
            self.path = self
        class path:
            def exists(self, path):
                return True


# Generated at 2022-06-22 23:51:45.910521
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fcwwn_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_collector is not None

# Generated at 2022-06-22 23:51:58.738779
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector as Fcwwn
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import get_module_facts

    facts = Facts(get_module_facts())
    FcwwnCollector = FcWwnInitiatorFactCollector()
    FcwwnCollector.collect(facts=facts)
    fcwwn_facts = facts.get('fibre_channel_wwn')

    assert fcwwn_facts is not None, 'fibre_channel_wwn is empty'
    assert type(fcwwn_facts)

# Generated at 2022-06-22 23:52:02.174288
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Note: Fact collection mostly tested in integration tests
    facts = FcWwnInitiatorFactCollector()
    assert isinstance(facts, FcWwnInitiatorFactCollector)
    assert facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:06.213395
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-22 23:52:10.999252
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fact = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact.name == 'fibre_channel_wwn'
    assert fc_wwn_fact._fact_ids == set()

# Generated at 2022-06-22 23:52:12.492745
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert hasattr(FcWwnInitiatorFactCollector, 'collect')

# Generated at 2022-06-22 23:52:14.357637
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    c = FcWwnInitiatorFactCollector()
    assert c.collect() is not None

# Generated at 2022-06-22 23:52:27.540583
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils import basic

    # set up test environment
    myplatform = 'linux'
    myhostname = 'myhostname.mydomain.com'
    mypythonversion = '2.6.6'
    mypythonpath = '/usr/bin/python'

    # Generate necessary mock objects
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create dummy module object in memory

# Generated at 2022-06-22 23:52:30.462435
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'
    assert result.priority == 19

# Generated at 2022-06-22 23:52:32.955010
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    col = FcWwnInitiatorFactCollector()
    assert col.name == 'fibre_channel_wwn'
    assert col._fact_ids == set()

# Generated at 2022-06-22 23:52:40.654347
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    results = fc.collect()
    assert 'fibre_channel_wwn' in results
    assert results['fibre_channel_wwn'] != []
    assert len(results['fibre_channel_wwn']) > 0
    # TBD: check each wwn if this is a valid wwn


# Generated at 2022-06-22 23:52:43.889393
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fc_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleModuleMock

    module = AnsibleModuleMock()
    # module.debug = True
    fc = FcWwnInitiatorFactCollector()
    Collector._collectors.append(fc)
    fc_facts = fc.collect()
    assert fc_facts.get('fibre_channel_wwn')



# Generated at 2022-06-22 23:52:50.135310
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_wwn_initiator._fact_ids


# Generated at 2022-06-22 23:52:52.748127
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    results = collector.collect()

    assert 'fibre_channel_wwn' in results.keys()


# Generated at 2022-06-22 23:52:55.371460
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    item = FcWwnInitiatorFactCollector()
    assert item
    assert item.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:59.006135
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_fact_collector.collect()
    assert('fibre_channel_wwn' in fc_facts)
    assert(len(fc_facts['fibre_channel_wwn']) > 0)

# Generated at 2022-06-22 23:53:00.882430
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:53:03.936394
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector class
    """
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in obj._fact_ids

# Generated at 2022-06-22 23:53:07.735915
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()


# Generated at 2022-06-22 23:53:20.026279
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import unittest
    import sys
    import copy
    import os

    class TestAnsibleModule(object):

        def __init__(self):
            self.run_command_calls = 0
            self.run_command_output = []
            self.get_bin_path_output = None
            self.run_command_output = []

        def get_bin_path(self, command, required=False, opt_dirs=[]):
            return self.get_bin_path_output

        def run_command(self, command):
            self.run_command_calls += 1
            if len(self.run_command_output) > 0:
                return self.run_command_output.pop()
            else:
                return [0, '', '']


# Generated at 2022-06-22 23:53:26.654825
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = 'ansible.module_utils.facts.collectors.fibre_channel_wwn.FcWwnInitiatorFactCollector'
    test_module = __import__(test_module, globals(), locals(), ['object'], 0)
    fcwwn_obj = test_module.FcWwnInitiatorFactCollector()
    fcwwn_obj.collect()

# Generated at 2022-06-22 23:53:30.898548
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json

    from ansible.module_utils.facts.fibre_channel import FcWwnInitiatorFactCollector
    from ansible.utils.platform import Platform
    from ansible.module_utils.facts import __ansible_module__

    # Remove fibrefacts.json if it exists
    if os.path.isfile('./fibrefacts.json'):
        os.remove('./fibrefacts.json')

    # Set up the platform and module we want to test
    platform = Platform('linux')
    module = __ansible_module__
    module.platform = platform

    # Set up the fixture data we want to use for the method collect
    fc_facts_collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:53:33.748072
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # unit test here
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:53:42.240380
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Facts
    import os
    fc = FcWwnInitiatorFactCollector()
    facts = Facts(Collector._module)
    # unit test for method collect
    assert fc.collect(facts) == os.path.join(os.path.dirname(__file__), 'fixtures', 'ansible_fibre_channel_wwn.fact')

# Generated at 2022-06-22 23:53:45.123541
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert isinstance(fc, FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:53:57.510934
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {'fibre_channel_wwn': []}
    if sys.platform.startswith('linux'):
        for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
            for line in get_file_lines(fcfile):
                fc_facts['fibre_channel_wwn'].append(line.rstrip()[2:])
    elif sys.platform.startswith('sunos'):
        cmd = "/usr/sbin/fcinfo"
        if cmd:
            cmd = cmd + " hba-port"
            rc, fcinfo_out, err = module.run_command(cmd)

# Generated at 2022-06-22 23:54:04.332478
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    class MockModule:
        def __init__(self):
            self.run_command_calls = 0
            self.bin_path_msg = ""

        def get_bin_path(self, cmd, opt_dirs=[]):
            if self.bin_path_msg == "none":
                return None
            if self.bin_path_msg == "empty":
                return ""
            return "/bin/foo"

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls += 1
            if cmd == "fcinfo hba-port":
                return 0, """HBA Port WWN: 10000090fa1658de""", ""
            return -1, "", ""

    # Unit tests
    fwi = FcWwnInitiatorFactCollector()
    assert f

# Generated at 2022-06-22 23:54:07.963912
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    :return: none
    """
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:54:10.829349
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-22 23:54:18.015095
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    if platform.system().startswith('Linux'):
        fc_facts['fibre_channel_wwn'].append('21000014ff52a9bb')
    elif platform.system().startswith('SunOS'):
        fc_facts['fibre_channel_wwn'].append('10000090fa1658de')
    elif platform.system().startswith('HP-UX'):
        fc_facts['fibre_channel_wwn'].append('50060b00006975ec')
    return fc_facts

# Generated at 2022-06-22 23:54:21.373258
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    c = FcWwnInitiatorFactCollector()
    # no data available, method collect should return an empty dict
    if c.collect():
       return True
    else:
       return False

# Generated at 2022-06-22 23:54:26.467866
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids is not None

# Generated at 2022-06-22 23:54:34.058484
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test: test case for method `collect` of class FcWwnInitiatorFactCollector
    """

    class MockModule(object):
        """
        This is a MagicMock implementation of class AnsibleModule to help
        write unit tests for the `FcWwnInitiatorFactCollector.collect` method.
        """
        class ModuleFailException(Exception):
            """
            This is the exception that is raised by `fail_json` in the class
            AnsibleModule.
            """
            pass

        def __init__(self, ansible_arguments):
            self.params = ansible_arguments


# Generated at 2022-06-22 23:54:46.880441
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    class FakeModuleUtilsFactsCollectorOS(object):
        def __init__(self):
            pass
        def get_file_lines(self,path):
            return [ "0x21000014ff52a9bb" ]

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_MESSAGES': 'C'}
            self.run_command_invocation = None
        def get_bin_path(self, cmd, opt_dirs=[]):
            return "/usr/local/bin/%s" % cmd

# Generated at 2022-06-22 23:54:50.842418
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-22 23:54:58.153156
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create class instance
    fc_facts = FcWwnInitiatorFactCollector()

    # create facts collection structure using the class instance
    collected_facts = fc_facts.collect(module=None, collected_facts=None)
    # test collected_facts dictionary
    assert 'fibre_channel_wwn' in collected_facts

# Generated at 2022-06-22 23:55:01.015330
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in fc_fact.collect()

# Generated at 2022-06-22 23:55:02.396256
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fixture = FcWwnInitiatorFactCollector()
    fixture.collect()

# Generated at 2022-06-22 23:55:14.671388
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from collections import namedtuple
    import json
    import os

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def get_bin_path(self, command, opt_dirs=[]):
            if command == "fcinfo" and os.path.exists('/usr/sbin/fcinfo'):
                return "/usr/sbin/fcinfo"
            elif command == "ioscan" and os.path.exists('/sbin/ioscan'):
                return "/sbin/ioscan"

# Generated at 2022-06-22 23:55:27.674199
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    MOCK_LINUX_FACT_LINES = """0x21000014ff52a9bb"""
    MOCK_AIX_FACT_LINES = """fcs3  Available  02-08-03  FC  Port  QLogic Fibre Channel Adapter
        Network Address.............10000090FA551509"""
    MOCK_SUNOS_FACT_LINES = """HBA Port WWN: 10000090fa1658de
    HBA Port WWN: 10000090fa1658de
    HBA Port WWN: 10000090fa1658de
    HBA Port WWN: 10000090fa1658de"""

# Generated at 2022-06-22 23:55:30.336982
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    if not fact_collector:
        raise("Failed to instantiate FcWwnInitiatorFactCollector")


# Generated at 2022-06-22 23:55:36.999222
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert len(fc_wwn_initiator_fact_collector._fact_ids) == 0


# Generated at 2022-06-22 23:55:39.448815
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:46.757026
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_fc = FcWwnInitiatorFactCollector()
    ansible_module = MockModule()
    ansible_module.run_command = Mock(return_value=(0, FCINFO_OUT, ""))
    fcwwn_facts_out = fcwwn_fc.collect(module=ansible_module)
    assert fcwwn_facts_out['fibre_channel_wwn'] == FCINFO_OUT.split()

