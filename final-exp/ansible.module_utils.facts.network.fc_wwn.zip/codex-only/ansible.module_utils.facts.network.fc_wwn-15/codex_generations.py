

# Generated at 2022-06-22 23:45:46.773836
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()

# Generated at 2022-06-22 23:45:59.627727
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FcWwnInitiatorFactCollectorTest(FcWwnInitiatorFactCollector):

        def collect(self, module=None, collected_facts=None):
            return super(FcWwnInitiatorFactCollectorTest, self).collect(module, collected_facts)

    class AnsibleModuleFake:
        def __init__(self, os=None):
            self.os = os
            self.binaries = {}
            self._module = None
            self._name = None
            self.params = {}

        def get_bin_path(self, command, opt_dirs=[]):
            if self.os in self.binaries and command in self.binaries[self.os]:
                return

# Generated at 2022-06-22 23:46:05.620998
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcinitiator = FcWwnInitiatorFactCollector()
    assert fcinitiator.name == 'fibre_channel_wwn'
    assert hasattr(fcinitiator, 'collect')
    assert isinstance(fcinitiator._fact_ids, set)
    assert len(fcinitiator._fact_ids) == 0
    assert isinstance(fcinitiator.collect(), dict)

# Generated at 2022-06-22 23:46:09.019387
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    result = FcWwnInitiatorFactCollector().collect()
    print("Result of module ansible.module_utils.facts.fibre_channel_wwn.FcWwnInitiatorFactCollector.collect():\n")
    print("Type: %s\n" % type(result))
    print("Value:\n%s\n" % result)

# Main program section
if __name__ == '__main__':
    print("Starting test of function ansible.module_utils.facts.fibre_channel_wwn.FcWwnInitiatorFactCollector.collect\n")
    test_FcWwnInitiatorFactCollector_collect()
    print("Test finished.")

# Generated at 2022-06-22 23:46:13.132308
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids == set()

# Generated at 2022-06-22 23:46:17.445948
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x

if __name__ == '__main__':
    # Unit test for constructor of class FcWwnInitiatorFactCollector
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:27.936405
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a FcWwnInitiatorFactCollector object
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    # Get a dummy module object
    module = get_dummy_module()

    # Test collect method
    fc_facts = fc_wwn_collector.collect(module=module, collected_facts=None)
    if sys.platform.startswith('linux'):
        assert fc_facts == {'fibre_channel_wwn': [u'21000014ff52a9bb']}
    elif sys.platform.startswith('sunos'):
        assert fc_facts == {'fibre_channel_wwn': [u'10000090fa1658de']}

# Generated at 2022-06-22 23:46:31.771316
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:34.101826
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == {}

# Generated at 2022-06-22 23:46:38.674857
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcColl = FcWwnInitiatorFactCollector()
    assert fcColl.name == "fibre_channel_wwn"
    assert fcColl._fact_ids == set()
    assert fcColl.collect() == dict()

# Generated at 2022-06-22 23:46:47.851085
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys

    sys.modules['ansible'] = type('', (object, ), {'__version__': '2.9.14'})()
    sys.modules['ansible.module_utils'] = type('', (object, ), {'facts': lambda: None})()
    sys.modules['ansible.module_utils.facts'] = type('', (object, ), {'collector': lambda: None})()

    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.utils import get_file_lines

    ansible.module_utils.facts.collector.get_file_lines = get_file_lines
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts.keys()
   

# Generated at 2022-06-22 23:46:52.882240
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test with no arguments
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()
    # Test with arguments
    x = FcWwnInitiatorFactCollector('some', {'some': 'some'})
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == {'some'}

# Generated at 2022-06-22 23:46:56.106478
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc.collect().keys()

# Generated at 2022-06-22 23:46:58.743838
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:06.913856
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Return a  dictionary of objects to be added to facts[fibre_channel_wwn]
    """
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()

    # make sure we have a list
    assert isinstance(result['fibre_channel_wwn'], list)

    # if this test fails, the list needs to be cleaned up
    assert len(result['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:47:13.699451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    collected_facts = {}
    try:
        result = collector.collect(module=None, collected_facts=None)
    except:
        exception = sys.exc_info()[1]
        print(str(exception))

    if result is not None:
        print('GOT: %s' % repr(result))
    else:
        print('Failed to get facts')

# Generated at 2022-06-22 23:47:26.480552
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # example /sys/class/fc_host/*/port_name
    def get_file_lines_mock(filename):
        """ Mock method get_file_lines of module_utils.facts.utils """
        if filename == '/sys/class/fc_host/host0/port_name':
            return ['0x21000014ff52a9ba']
        elif filename == '/sys/class/fc_host/host1/port_name':
            return ['0x23000014ff52a9bb']
        elif filename == '/sys/class/fc_host/host2/port_name':
            return ['0x25000014ff52a9bc']
        else:
            return []

# Generated at 2022-06-22 23:47:30.579954
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import FactCollector
    fact_collector = FactCollector()
    fc_fc = fact_collector.collect(['!all', '!any', 'fibre_channel_wwn'])

# Generated at 2022-06-22 23:47:33.237857
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fci = FcWwnInitiatorFactCollector()
    print(fci.collect())


# Generated at 2022-06-22 23:47:38.991213
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    my_obj = FcWwnInitiatorFactCollector()
    assert isinstance(my_obj, BaseFactCollector)
    assert my_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:42.760256
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == 'fibre_channel_wwn'
    assert fcwwnfc.collect() == {}


# Generated at 2022-06-22 23:47:50.188676
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    f = FcWwnInitiatorFactCollector({})
    facts = f.collect(module=None, collected_facts=None)
    assert type(facts) is dict
    assert facts['fibre_channel_wwn'] is not None
    assert type(facts['fibre_channel_wwn']) == list

# Generated at 2022-06-22 23:47:52.556061
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    a = FcWwnInitiatorFactCollector()
    a.collect()

# Generated at 2022-06-22 23:48:03.814162
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector class constructor
    """
    # Get the class
    fcwwn_obj = FcWwnInitiatorFactCollector()
    # Unit test for property `name` of FcWwnInitiatorFactCollector class
    try:
        fcwwn_obj.name
    except AttributeError as e:
        assert False, "FcWwnInitiatorFactCollector instance has no attribute 'name'"
    # Unit test for property `_fact_ids` of FcWwnInitiatorFactCollector class
    try:
        fcwwn_obj._fact_ids
    except AttributeError as e:
        assert False, "FcWwnInitiatorFactCollector instance has no attribute '_fact_ids'"

# Generated at 2022-06-22 23:48:09.085736
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector.
    """
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'
    assert fc_obj._fact_ids == set()

# Generated at 2022-06-22 23:48:12.505170
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector"""

    # Mock module object
    class MockModule(object):
        pass

    module = MockModule()
    module.get_bin_path = Mock(return_value=False)
    module.run_command = Mock(return_value=(0, '', ''))

    # Try to run collect
    FcWwnInitiatorFactCollector().collect(module)

# Generated at 2022-06-22 23:48:25.190700
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test on linux
    sys.modules['platform'] = type('MockModule', (object,), {'system': lambda: 'linux', 'uname': lambda: ['Linux'], 'platform': lambda: 'linux2', 'release': lambda: '4.4.0-119-generic', 'version': lambda: "#143-Ubuntu SMP Mon Apr 2 16:08:24 UTC 2018", 'machine': lambda: 'x86_64', 'node': lambda: 'pf-lnx01', 'processor': lambda: 'x86_64'})

# Generated at 2022-06-22 23:48:27.242018
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = None
    collected_facts = None
    test = FcWwnInitiatorFactCollector()
    fc_facts = test.collect(module, collected_facts)
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:48:39.892239
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return "/bin/lsdev"

        def run_command(self, command):
            output = """
            fcs0 Available  08-08-02-3,0  Fibre C
            fcs1 Available  08-08-02-3,1  Fibre C
            fcs2 Available  08-08-02-3,2  Fibre C
            fcs3 Available  08-08-02-3,3  Fibre C
            fcs4 Available  08-08-02-3,4  Fibre C
            """
            return (0, output, "")

    collector = FcWwnInitiatorFactCollector()
    result = collector.collect(TestModule())

# Generated at 2022-06-22 23:48:53.291070
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    try:
        import platform

        import unittest2 as unittest
    except ImportError:
        import platform
        import unittest

    from ansible.module_utils.facts.collector import Collector

    class PlatformLinux(platform.linux_distribution):
        """
        Override the platform.dist()[0] method to always return Linux
        """
        def linux_distribution(self, *args, **kwargs):  # pylint: disable=arguments-differ
            return ('Linux', '', '')


    class PlatformSunos(platform.dist):
        """
        Override the platform.dist()[0] method to always return SunOS
        """

# Generated at 2022-06-22 23:49:06.856520
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import sys
    from ansible.module_utils.facts.collector.network import FcWwnInitiatorFactCollector
    import os
    from ansible.module_utils.facts.collector.network import FcWwnInitiatorFactCollector

    class ModuleStub(object):
        def __init__(self, params):
            self._params = params

        def get_bin_path(self, opt, opt_dirs=[]):
            return "/usr/sbin/fcmsutil"


# Generated at 2022-06-22 23:49:08.447978
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:09.377590
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:49:09.987804
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass

# Generated at 2022-06-22 23:49:13.792565
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()

    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:49:23.830401
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    FcWwnInitiatorFactCollector
    fc_facts = {}
    fact_collector = FcWwnInitiatorFactCollector(BaseFactCollector)
    fact_collector.collect(None, fc_facts)
    # print(fc_facts)
    return True

# Main function for testing
if __name__ == '__main__':
    import sys
    import platform
    sys.exit(0) if test_FcWwnInitiatorFactCollector_collect() else sys.exit(1)

# Generated at 2022-06-22 23:49:28.298078
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert o_FcWwnInitiatorFactCollector != None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:40.485331
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fc_wwn_initiator import \
        FcWwnInitiatorFactCollector

    collection = Collector()
    assert 'linux' in collection.platforms
    assert 'fibre_channel_wwn' in collection.fact_classes
    assert FcWwnInitiatorFactCollector in collection.fact_classes['fibre_channel_wwn']
    assert 'rhel' in collection.distribution
    assert 'fedora' in collection.distribution
    assert 'debian' in collection.distribution
    assert 'oracle' in collection.distribution
    assert 'ubuntu' in collection.distribution
    assert 'arch' in collection.distribution
    assert 'redhat' in collection.distribution

# Generated at 2022-06-22 23:49:43.173738
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    test_object = FcWwnInitiatorFactCollector()
    assert isinstance(test_object, Collector)

# Generated at 2022-06-22 23:49:46.612887
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-22 23:49:59.142801
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # prepared test data
    wwn_list = ['21000014ff52a9bb','21000014ff52a9bc','21000014ff52a9cd']
    # get instance of FcWwnInitiatorFactCollector
    collector_instance = FcWwnInitiatorFactCollector()

    # set list of WWNs in port_name file
    # as not real os, we have to mock methods with test data
    def mock_get_file_lines(arg):
        file_lines=''
        for wwn in wwn_list:
            file_lines = file_lines + '0x' + wwn + '\n'
        return (file_lines)
    collector_instance.get_file_lines = mock

# Generated at 2022-06-22 23:50:01.171604
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ Due to chained inheritance, we need instance of subclass
        FcWwnInitiatorFactCollector to verify constructor of superclass BaseFactCollector.
        This test was written to satisfy test coverage.
    """
    base_ = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:03.363161
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO: unit test for method collect of class FcWwnInitiatorFactCollector
    assert False

# Generated at 2022-06-22 23:50:16.156743
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.dell.legacy import FcWwnInitiatorFactCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes

    sys.modules['chocpkg'] = DummyChocpkg()

    def get_file_lines_mock(filename):
        if filename == '/sys/class/fc_host/host0/port_name':
            return [to_text(to_bytes('0x21000014ff52a9bb'))]
        return []

    FcWwnInitiatorFactCollector._get_file_lines = get_file_lines_mock


# Generated at 2022-06-22 23:50:28.848758
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcWwnInitiatorFactCollector - test collect() method
    """

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_collector

    # create a dummy module and facts
    module = AnsibleFakeModule()
    # set the paths to some dummy binaries
    module.set_bin_path("lsdev", "/usr/sbin/lsdev")
    module.set_bin_path("lscfg", "/usr/sbin/lscfg")
    module.set_bin_path("fcinfo", "/usr/sbin/fcinfo")
    module.set_bin_path("ioscan", "/usr/sbin/ioscan")
    # create a new FactsCollector
    ansible_collector = FactsCollector()
    #

# Generated at 2022-06-22 23:50:31.658335
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in fcwwn._fact_ids


# Generated at 2022-06-22 23:50:37.001690
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == "fibre_channel_wwn"
    assert fc_obj._fact_ids == set()
    assert fc_obj.collect() == {}


# Generated at 2022-06-22 23:50:40.613528
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facter = FcWwnInitiatorFactCollector()
    assert facter.name == 'fibre_channel_wwn'
    assert facter._fact_ids == set()

# Generated at 2022-06-22 23:50:50.385585
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector.
    The purpose is to check if the collector correctly parses the
    output of the 'fcinfo hba-port' command.
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    class TestableFcWwnInitiatorFactCollector(FcWwnInitiatorFactCollector):
        """
        Testable version of FcWwnInitiatorFactCollector.
        The collector only returns a fact if it finds the file test_fcfile.
        The test_fcfile is a file which contains data that is tested
        in this method.
        """
        def __init__(self):
            self.name = 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:00.368954
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    method collect of class FcWwnInitiatorFactCollector
    """
    # execute test
    test_obj = FcWwnInitiatorFactCollector()
    test_facts = test_obj.collect()
    # check result
    if test_facts.get('fibre_channel_wwn'):
        assert len(test_facts.get('fibre_channel_wwn')) > 0
    else:
        assert len(test_facts.get('fibre_channel_wwn')) == 0

# Generated at 2022-06-22 23:51:02.731875
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-22 23:51:14.813843
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.collector import MockModuleCollector

    def mock_uname():
        if sys.platform.startswith('sunos'):
            return ('SunOS')
        elif sys.platform.startswith('linux'):
            return ('Linux')
        elif sys.platform.startswith('hp-ux'):
            return ('HP-UX')
        elif sys.platform.startswith('aix'):
            return ('AIX')


# Generated at 2022-06-22 23:51:19.445798
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    tFC = FcWwnInitiatorFactCollector()
    assert tFC is not None
    assert tFC.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:51:31.660630
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    # test where no facts are returned
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils import basic

    # create a module and initialise the basic params
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=False)

    # create a Collector object
    collector = Collector()
    assert collector is not None

    # create a FcWwnInitiatorFactCollector object
    fact = FcWwnInitiatorFactCollector()
    assert fact is not None

    # create a Facts object
    facts = Facts(collector)
    assert facts is not None

# Generated at 2022-06-22 23:51:41.821580
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MyModule(object):
        def __init__(self):
            self.run_command = lambda x,y,z: True

        def get_bin_path(self, bin_name, opt_dirs=[]):
            if bin_name == 'lsdev':
                return '/usr/sbin/lsdev'
            elif bin_name == 'lscfg':
                return '/usr/sbin/lscfg'
            else:
                return True

    class MyModuleSunOS(object):
        def __init__(self):
            self.run_command = lambda x,y,z: True

        def get_bin_path(self, bin_name, opt_dirs=[]):
            if bin_name == 'fcinfo':
                return '/usr/sbin/fcinfo'
            else:
                return True

# Generated at 2022-06-22 23:51:45.126998
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts is not None
    result = fc_facts.collect()
    assert result['ansible_fibre_channel_wwn'] is not None

# Generated at 2022-06-22 23:51:57.861260
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collector

    # path to fake modules for unit tests
    module_utils_path = os.path.join(os.path.dirname(__file__), 'unit_tests/module_utils/')
    sys.path.append(module_utils_path)

    # fake module for unit tests
    from ..unit_tests.module_utils import basic

    # set up module args
    module_args = {}

    # set up module
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # create a collector instance
    facts_collector = ansible_collector.get_collector(module, 'FcWwnInitiatorFactCollector')

    # call method

# Generated at 2022-06-22 23:52:04.022855
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from collections import namedtuple
    from ansible.module_utils.facts import ansible_collector

    module = namedtuple('module', 'run_command get_bin_path')
    module.run_command = lambda cmd: (0, "test_output", "")
    module.get_bin_path = lambda cmd: cmd

    ansible_collector.collector.collect(module=module)
    assert ansible_collector.collector.fetch_file_lines_from_file == get_file_lines

# Generated at 2022-06-22 23:52:09.339689
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert len(fact_collector._fact_ids) == 1
    assert fact_collector._fact_ids.pop() == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:21.789202
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if sys.platform.startswith('sunos'):
        test_platform = "SunOS"
    elif sys.platform.startswith('linux'):
        test_platform = "Linux"
    elif sys.platform.startswith('aix'):
        test_platform = "AIX"
    elif sys.platform.startswith('hp-ux'):
        test_platform = "HP-UX"
    else:
        test_platform = "UNKNOWN"

    o = FcWwnInitiatorFactCollector(None, None)
    # check the platform-dependent name of the fact
    if test_platform == "AIX":
        assert o.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:33.485723
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    test_FcWwnInitiatorFactCollector_collect: fc_wwn.collect unit test
    """


# Generated at 2022-06-22 23:52:38.993888
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect(module=None, collected_facts=None)
    print(fc_facts)


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:52:47.245483
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test FcWwnInitiatorFactCollector
    """
    import sys
    import test as _test
    class sys:
        platform = 'fictitious'

    fc_fact_collector = FcWwnInitiatorFactCollector()
    facts = fc_fact_collector.collect()
    print("Gathered facts:\n%(" + str(facts) + ")")

    assert 'fibre_channel_wwn' in facts
    assert isinstance(facts['fibre_channel_wwn'], list)

# Generated at 2022-06-22 23:52:50.451031
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert FcWwnInitiatorFactCollector.collect() == {'fibre_channel_wwn': ['0000a09806f79ff0']}

# Generated at 2022-06-22 23:52:51.496206
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:52:56.339947
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == 'fibre_channel_wwn'
    assert not fcwwnfc._fact_ids
    assert fcwwnfc in Collector.collectors

# Generated at 2022-06-22 23:52:58.811186
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fw = FcWwnInitiatorFactCollector()
    assert fw.name == 'fibre_channel_wwn'
    assert fw._fact_ids == set()

# Generated at 2022-06-22 23:53:09.951345
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import collector

    # instantiate FcWwnInitiatorFactCollector
    fc_wwn_initiator = collector.get_collector('fibre_channel_wwn')

    # make a mocked module for the test
    class MockAnsibleModule:
        params = {}

        def run_command(self, cmd):
            """Mock of run_command method.
            """
            fcinfo_out = """
            HBA Port WWN: 10000090fa1658de
            Attached FC Port WWN: 20000090fa1658de
            HBA Port WWN: 10000090fa22228e
            Attached FC Port WWN: 20000090fa22228e
            """
            return (0, fcinfo_out, "")


# Generated at 2022-06-22 23:53:21.564191
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcc = FcWwnInitiatorFactCollector()
    assert fcc.collect() == {'fibre_channel_wwn': []}
    assert fcc.collect().get('fibre_channel_wwn') == []
    assert fcc.collect().get('fibre_channel_wwn') != None
    assert fcc.collect().get('fibre_channel_wwn') is not None
    assert fcc.collect().get('fibre_channel_wwn') != 'unknown'
    assert fcc.collect().get('fibre_channel_wwn') is not 'unknown'
    assert fcc.collect().get('fibre_channel_wwn') is None
    assert fcc.collect().get('fibre_channel_wwn') != {}
    assert fcc.collect().get

# Generated at 2022-06-22 23:53:33.749720
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Unit test of method
    :meth:`ansible.module_utils.facts.fibre_channel_wwn.FcWwnInitiatorFactCollector.collect`
    '''
    import ansible.utils.platform as platform
    from ansible.module_utils.facts import collector

    if platform.system().startswith('SunOS'):
        # Skip on Solaris systems (no fcinfo command)
        return
    elif platform.system().startswith('HP-UX'):
        # Skip on HP-UX systems
        # if either of the commands (ioscan and fcmsutil) are not available
        from distutils.spawn import find_executable
        if find_executable('ioscan') is None:
            return

# Generated at 2022-06-22 23:53:38.493536
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    # get all ansible facts
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts.collect()
    # print collected facts
    print(fc_facts.get_facts())

# Generated at 2022-06-22 23:53:43.049357
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = sys.modules[__name__].FcWwnInitiatorFactCollector
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn']

# Generated at 2022-06-22 23:53:49.438015
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create instance of class FcWwnInitiatorFactCollector
    fc_initiator_fact_collector = FcWwnInitiatorFactCollector({}, {}, {}, {})
    # Call method collect of FcWwnInitiatorFactCollector class
    fc_initiator_fact_collector.collect()


if __name__ == '__main__':
  test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:53:52.349351
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:55.061121
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:54:02.317045
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    ini = FcWwnInitiatorFactCollector()
    facts = ini.collect()
    assert 'fibre_channel_wwn' in facts
    assert len(facts['fibre_channel_wwn']) == 2
    assert facts['fibre_channel_wwn'][0] == '1000d8a000000004'
    assert facts['fibre_channel_wwn'][1] == '1000d8a000000005'

# Generated at 2022-06-22 23:54:08.069062
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect({}, {})
    assert isinstance(facts, dict)
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-22 23:54:14.161501
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = FakeAnsibleModule()
    fact_collector = FcWwnInitiatorFactCollector()
    facts_dict = fact_collector.collect(module=module)
    assert facts_dict['ansible_local']['fibre_channel_wwn']
    assert facts_dict['ansible_local']['fibre_channe' + 'l_wwn'][0] == '21000014ff52a9bb'


# Generated at 2022-06-22 23:54:26.996199
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return '/usr/bin'
        def run_command(self, cmd):
            if cmd == '/usr/bin/fcinfo hba-port':
                return (0, 'HBA Port WWN: 10000090fa1658de\nHBA Port WWN: 10000090fa1658df\n', '')
            elif cmd == '/usr/bin/lsdev -Cc adapter -l fcs*':
                return (0, 'fcs0 Available  Virtual FC Adapter (df1000f4) \nfcs1 Available  Virtual FC Adapter (df1000f4) \nfcs2 Defined    Virtual FC Adapter (df1000f4) \n', '')

# Generated at 2022-06-22 23:54:30.486540
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect()
    assert fc_facts['fibre_channel_wwn'] is not None

# Generated at 2022-06-22 23:54:33.042267
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj
    assert test_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:45.639834
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import json
    import pytest
    try:
        set
    except NameError:
        from sets import Set as set

    class MockModule(object):

        def __init__(self):
            self.params = {'gather_subset': ['all']}
            self.exit_json = lambda v, **kwargs: sys.exit(0)
            self.fail_json = lambda **kwargs: sys.exit(1)

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            script_dir = os.path.join(
                os.path.dirname(os.path.realpath(__file__)), '..')
            return os.path.join(script_dir, 'helpers/mock_bin/' + executable)

       

# Generated at 2022-06-22 23:54:51.032163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.collectors.network.fibre_channel_wwn as fcwwn_collector
    module = FakeAnsibleModule()
    fcwwn_collector.FcWwnInitiatorFactCollector.collect(module)


# Generated at 2022-06-22 23:54:52.475416
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-22 23:54:57.677710
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = {}
    fact_collector.collect(collected_facts=collected_facts)
    assert len(collected_facts) > 0
    assert len(collected_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:55:06.039866
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # On a Linux test system:
    # Example contents /sys/class/fc_host/*/port_name:
    # 0x21000014ff52a9bb
    # Example contents /sys/class/fc_host/*/node_name:
    # 0x200014ff52a9bb
    # 0x100000051f0b5bb5
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert set(collector._fact_ids) == {'fibre_channel_wwn'}
    fc_facts = collector.collect()
    assert set(fc_facts.keys()) == {'fibre_channel_wwn'}

# Generated at 2022-06-22 23:55:13.101460
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts import ModuleFacts

    fc_fact_collector = FactCollector(ModuleFacts, 'fibre_channel_wwn')
    result = fc_fact_collector.collect(collected_facts=None)

    assert result['ansible_facts']['fibre_channel_wwn']

# Generated at 2022-06-22 23:55:16.276187
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:55:19.873347
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for the constructor.
    """

    fcwwn_obj = FcWwnInitiatorFactCollector()
    assert fcwwn_obj.name == "fibre_channel_wwn"
    assert fcwwn_obj._fact_ids == set()

# Generated at 2022-06-22 23:55:22.429866
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:31.775166
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_fact_collector = FcWwnInitiatorFactCollector(module)

    # test if method collect works as expected with output from fcinfo
    module.run_command = MagicMock(return_value=(0, 'HBA Port WWN: 10000090fa1658de\nHBA Port WWN: 10000090fa1658df', ''))
    assert fc_fact_collector.collect() == {
        'fibre_channel_wwn': [
            '10000090fa1658de',
            '10000090fa1658df'
        ]
    }

    # test if method collect works as expected with output from lscfg

# Generated at 2022-06-22 23:55:43.290792
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = {}

    # init collected facts
    collected_facts['ansible_facts'] = {}
    collected_facts['ansible_facts']['fibre_channel_wwn'] = []

    test_ansible_module = AnsibleModuleStub(
        argument_spec={},
        supports_check_mode=True)

    # Unit test without any FC WWN given
    fc_fact_collector.collect(module=test_ansible_module,
                              collected_facts=collected_facts)
    assert collected_facts['ansible_facts']['fibre_channel_wwn'] == []

# Unit test of AnsibleModuleStub

# Generated at 2022-06-22 23:55:45.760859
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
