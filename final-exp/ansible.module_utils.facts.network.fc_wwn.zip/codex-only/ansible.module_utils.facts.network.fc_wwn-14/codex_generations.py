

# Generated at 2022-06-22 23:45:42.185415
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_collector.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:45:45.631602
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_init = FcWwnInitiatorFactCollector()
    assert fcwwn_init.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:45:53.356936
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # unit test requires pytest
    import pytest
    from ansible.module_utils.facts import Collector

    def test_constuctor():
        module = pytest.Mock()
        module.get_bin_path.return_value = None
        coll = Collector(module=module)
        collector = FcWwnInitiatorFactCollector(module=module, fact_list=coll.collect())
        assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:05.375226
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys
    import os

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    fc_result = {
        "fibre_channel_wwn": [
            "21000014ff52a9bb"
        ]
    }
    class FcHostFilesException(Exception):
        pass

    def _mock_get_file_lines(filename):
        if filename not in ['/sys/class/fc_host/host1/port_name']:
            raise FcHostFilesException('Unknown fc_host file %s' % filename)

# Generated at 2022-06-22 23:46:13.285465
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test that the collect method of FcWwnInitiatorFactCollector returns an empty list
    on linux system without any fibre-channel initiators.
    """
    # Setup for test
    # pylint: disable=import-error,unused-variable,unused-argument,no-value-for-parameter
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    # pylint: enable=import-error,unused-variable,unused-argument,no-value-for-parameter

    # Test the collect method of the FcWwnInitiatorFactCollector class
    fc_collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:15.446701
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    testobj = FcWwnInitiatorFactCollector()
    assert testobj.name == 'fibre_channel_wwn'
    assert testobj._fact_ids == set()

# Generated at 2022-06-22 23:46:18.889492
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector != None
    assert fc_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:21.412435
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"


# Generated at 2022-06-22 23:46:21.775067
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:46:23.771523
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    FcWwnInitiatorFactCollector().collect(module=module)
    # Tests have to be platform dependent

# Generated at 2022-06-22 23:46:25.603220
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-22 23:46:30.497150
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.system.fibre_channel_wwn as fibre_channel_wwn

    my_collector = Collector(
        module=None,
        collectors=[fibre_channel_wwn.FcWwnInitiatorFactCollector]
    )
    assert my_collector is not None

# Generated at 2022-06-22 23:46:33.273291
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  assert len(FcWwnInitiatorFactCollector().collect().get('fibre_channel_wwn'))

# Generated at 2022-06-22 23:46:44.839297
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(
        argument_spec = dict()
    )

    # fake class and methods to allow the collector to get the lines
    class FakeFile:
        def __init__(self, contents):
            self.lines = contents

    class FakeOs:
        def __init__(self, osfacts):
            self.lines = osfacts
            self.path = FakeFile([])

        def get_bin_path(self, binname, opt_dirs=[], required=False):
            return binname

        def run_command(self, cmd):
            return (0, '', '')

    def fake_get_file_lines(file_name):
        return ['0x21000014ff52a9bb']

    module.os = FakeOs({})
    module.get_file_lines = fake_get_

# Generated at 2022-06-22 23:46:47.310519
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:51.226361
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()
    fc_facts = FcWwnInitiatorFactCollector.collect()
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:47:02.625993
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # prepare test data
    # we need to mock the following module calls:
    # 1. sys.platform == 'linux2'
    # 2. glob.glob == result_list
    # 3. os.path.isfile == True
    # 4. get_file_lines == output_list
    import sys
    import os
    import glob
    from ansible.module_utils.facts.utils import get_file_lines

    class MockModule(object):
        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd

        def run_command(self, cmd):
            output = ""
            if 'fcs3' in cmd:
                output = "Network Address.............10000090FA551509"

            return (0, output, '')

    module = MockModule()

# Generated at 2022-06-22 23:47:15.361703
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    if platform.system() == 'Linux':
        import sys, os
        sys.path.append(os.path.dirname('.'))
        from module_utils.facts import ModuleFactsCollectorHelper, get_platform_subclass
        helper = ModuleFactsCollectorHelper(CollectorClz=FcWwnInitiatorFactCollector)
        results = helper.get_facts('linux_facts')
        wwns = results['ansible_facts']['fibre_channel_wwn']
        assert len(wwns) > 0
        for wwn in wwns:
            assert len(wwn) == 16

    elif platform.system() == 'SunOS':
        from module_utils.facts import ModuleFactsCollectorHelper, get_platform_subclass
        helper = ModuleFactsCollector

# Generated at 2022-06-22 23:47:24.946290
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    # Create object with module.params['gather_subset'] = ['!all', 'network']
    obj = FcWwnInitiatorFactCollector(module=None,
        collected_facts=fc_facts,
        gather_subset=['!all', 'network'])
    # Assertion: if !all and network is present, module should be executed
    assert obj.should_collect('fibre_channel_wwn') == True


# Generated at 2022-06-22 23:47:32.487022
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create mock module
    class Module:
        def get_bin_path(self, *args, **kw):
            return None
        def run_command(self, *args, **kw):
            return 0, '', ''
    module = Module()

    # prepare mock parser - always return empty facts
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockFactCollector:
        def collector(self, module=None, collected_facts=None):
            return {}
        def filter_collected_facts(self, facts=None, fact_list=None, include_facts=None, exclude_facts=None):
            return {}
    BaseFactCollector.collectors.clear()
    BaseFactCollector.collectors['mock'] = MockFactCollect

# Generated at 2022-06-22 23:47:44.593259
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_facts

    # create a dummy Collector object
    mycollector = Collector(
        modules=[FcWwnInitiatorFactCollector],
        module_utils=[BaseFactCollector],
        ansible_facts=ansible_facts
    )
    # create a test module
    module = {
        'run_command': run_command
    }
    # does it return a dictionary?
    result = mycollector.collect(module=module)
    assert isinstance(result, dict) is True
    assert 'fibre_channel_wwn' in result
    assert result['fibre_channel_wwn'] is not None


# Generated at 2022-06-22 23:47:57.250109
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    class ModuleStub:

        def __init__(self, bin_path=None):
            self.bin_path = bin_path

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path

    class OptionsStub:

        def __init__(self, gather_subset=None):
            self.gather_subset = gather_subset

    module = ModuleStub(bin_path='/server/path/bin')
    options = OptionsStub('!all,!min')

    # test constructor with options.gather_subset
    fact_collector = FcWwnInitiatorFactCollector(module, options)

# Generated at 2022-06-22 23:48:03.460253
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert hasattr(FcWwnInitiatorFactCollector, '_fact_ids')
    fc_wwn_fc = FcWwnInitiatorFactCollector()
    assert fc_wwn_fc.name == 'fibre_channel_wwn'
    assert fc_wwn_fc._fact_ids == set()



# Generated at 2022-06-22 23:48:07.448030
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()

    assert fc_facts.name == 'fibre_channel_wwn'
    assert isinstance(fc_facts.collect(), dict)

# Generated at 2022-06-22 23:48:17.892539
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # prepare mocks
    module = Mock(name='ansible.module_utils.basic.AnsibleModule')
    collected_facts = {'fibre_channel_wwn': []}
    # get instance of FcWwnInitiatorFactCollector class
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    # prepare expected result
    expected_fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    # run the test
    result_fc_facts = fc_wwn_collector.collect(module, collected_facts)
    # assert results
    assert result_fc_facts == expected_fc_facts

# Generated at 2022-06-22 23:48:23.808284
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    module = MockModule()
    fcwwn = FcWwnInitiatorFactCollector(module=module)
    fcwwn.collect()
#    print(fcwwn.collect())


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:48:25.095621
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:28.978174
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()
    assert type(facts) is dict, 'FcWwnInitiatorFactCollector.collect() did not return a dict'


# Generated at 2022-06-22 23:48:33.094649
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    wwn = FcWwnInitiatorFactCollector()
    assert wwn.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in wwn._fact_ids

# Generated at 2022-06-22 23:48:36.952673
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"
    assert fc._fact_ids == set()



# Generated at 2022-06-22 23:48:43.085627
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = object()
    fact_data = '''0x21000014ff52a9bb
0x5000090fa1658de'''
    with open('/sys/class/fc_host/host0/port_name', 'w') as f:
        f.write(fact_data)
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(module_mock)
    assert facts['fibre_channel_wwn'] == ['21000014ff52a9bb', '5000090fa1658de']

# Generated at 2022-06-22 23:48:49.567193
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Arrange
    fact_collector = FcWwnInitiatorFactCollector()
    expected_wwn = ['21000014ff52a9bd', '21000014ff52a9bb']

    # Act
    actual_wwn = fact_collector.collect()

    # Assert
    assert actual_wwn == expected_wwn

# Generated at 2022-06-22 23:48:54.902955
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test for class FcWwnInitiatorFactCollector"""

    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:56.689344
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:07.818819
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = AnsibleModuleMock()
    module_mock.params = {}
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.return_value = True
    fc_facts = FcWwnInitiatorFactCollector().collect(module=module_mock)

    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    assert fc_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-22 23:49:09.683525
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:49:11.525590
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:14.965194
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect(None, None)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:49:27.376982
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    #
    # Test for Solaris 11
    #
    class FakeModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'fcinfo':
                return '/usr/sbin/fcinfo'
        def run_command(self, cmd, check_rc=True, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
            return (0, "HBA Port WWN: 10000090fa1658de\n", '')
    fake_module = FakeModule()
    fc_info = collector.collect(module=fake_module)

# Generated at 2022-06-22 23:49:39.431326
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.hardware import HardwareCollector
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.utils import get_file_lines
    import glob

    # create a fake AnsibleModule object
    class AnsibleModule(object):

        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'fcinfo':
                return '/usr/bin/fcinfo'
        def run_command(self, cmd):
            return 0, '', ''
    module = AnsibleModule()

    # create

# Generated at 2022-06-22 23:49:46.202590
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of FcWwnInitiatorFactCollector class.
    Return of constructor method should be of type class FcWwnInitiatorFactCollector
    """
    fc_facts = FcWwnInitiatorFactCollector()
    assert isinstance(fc_facts, FcWwnInitiatorFactCollector)
# test_FcWwnInitiatorFactCollector()



# Generated at 2022-06-22 23:49:58.750008
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.utils.pycompat24 import get_exception
    from ansible.module_utils.facts.collector import get_collection_list

# Generated at 2022-06-22 23:50:11.416478
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    class MockModule:
        """
        Mock class for AnsibleModule
        """
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, **kwargs):
            """
            Dummy method for AnsibleModule get_bin_path
            """
            return None

        def run_command(self, arg, **kwargs):
            """
            Dummy method for AnsibleModule run_command
            """
            return None, None, None

    class MockCollector(FcWwnInitiatorFactCollector):
        """
        Mock class for NetworkFactCollector
        """
        def _platform(self, module):
            """
            Dummy method for _platform
            """

# Generated at 2022-06-22 23:50:14.970160
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    import unittest

    class TestFcWwnInitiatorFactCollectorConstructor(unittest.TestCase):

        def test_minimal(self):
            FcWwnInitiatorFactCollector()

    unittest.main()

# Generated at 2022-06-22 23:50:24.814566
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # arrange
    test_module = FakeAnsibleModule()
    collector = FcWwnInitiatorFactCollector()
    collected_facts = {}

    # act
    new_facts  = collector.collect(module=test_module, collected_facts=collected_facts)

    # assert
    assert 'fibre_channel_wwn' in new_facts
    assert '10000090fa1658de' in new_facts['fibre_channel_wwn']


# Unit test helper class FakeAnsibleModule

# Generated at 2022-06-22 23:50:28.742564
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts._module = "module"
    fc_facts.collect()
    assert fc_facts.collect()['fibre_channel_wwn']

# Generated at 2022-06-22 23:50:40.511247
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # Prepare test environment (ansible module arguments and constants)
    module_args = {}
    FcWwnInitiatorFactCollector._fact_ids = set()
    fc_facts = {}
    collected_facts = {}

    # Test if method collect of class FcWwnInitiatorFactCollector works as expected
    # and is returning the expected fibre-channel WWN initiator facts
    fc_facts = FcWwnInitiatorFactCollector.collect(module_args, collected_facts)
    assert fc_facts['fibre_channel_wwn'] is not None


# Generated at 2022-06-22 23:50:44.603120
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MyModule(object):
        _module = None
        def __init__(self):
            self.params = {}
        @property
        def params(self):
            return self._params
        @params.setter
        def params(self, val):
            self._params = val
        @property
        def module(self):
            return self._module
        @module.setter
        def module(self, val):
            self._module = val
        def get_bin_path(self, path, opt_dirs=[]):
            l_path = path
            return l_path
        def run_command(self, cmd):
            l_rc = 0
            l_out = None
            l_err = ""

# Generated at 2022-06-22 23:50:45.341012
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:49.799378
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    collector = FcWwnInitiatorFactCollector()
    collected_facts = {}

    facts = collector.collect(collected_facts=collected_facts)

    assert 'fibre_channel_wwn' in facts
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector._fact_ids


# Generated at 2022-06-22 23:51:02.859346
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test the collect() method of FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts import FactCollector

    # patch BaseFactCollector.get_file_lines to not try to use cat or
    # PowerShell (RHEL 7.0 does not have PowerShell) and always return an
    # empty list
    def fake_get_file_lines(path):
        return []

    # patch FactCollector.collect to not try to parse any other fact files
    def fake_collect(self):
        return {}

    # patch BaseFactCollector.get_file_lines and FactCollector.collect
    BaseFactCollector.get_file

# Generated at 2022-06-22 23:51:14.995303
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    sys.path.append('/Users/tklee/workspace/ansible/ansible_git/lib/ansible/module_utils/facts')
    from ansible.module_utils import facts
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts import utils
    mod = sys.modules[__name__]
    mocked_module = type('mocked_module', (), {})()


# Generated at 2022-06-22 23:51:17.227581
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcFactsCollector: Test the method collect of class FcFactsCollector
    """

    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:51:19.879433
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_test = FcWwnInitiatorFactCollector()
    assert fc_test.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:30.502430
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector

    module = AnsibleModuleMock()
    Collector.collectors['fibre_channel_wwn'] = FcWwnInitiatorFactCollector
    c = Collector(module=module)
    facts = c.get_facts()

    assert facts['fibre_channel_wwn'] is not None
    assert len(facts['fibre_channel_wwn']) > 0
    assert facts['fibre_channel_wwn'][0] is not None


# Generated at 2022-06-22 23:51:39.194439
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    sys.path.append('/')  # Ansible module_utils are not available in a normal python session
    import ansible.module_utils.facts.system.linux.fibre_channel_wwn
    from ansible.module_utils import basic
    
    true_dict = {
        "changed": False,
        "ansible_facts": {
            "fibre_channel_wwn": [
                "20000090fa1658de",
                "21000014ff52a9bb",
                "21000024ff52a9bb"
            ]
        }
    }

    module = basic.AnsibleModule(argument_spec= dict())
    
    # original collect()
    fcwwn = FcWwnInitiatorFactCollector(module=module)
    fc_info = f

# Generated at 2022-06-22 23:51:45.447668
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_facts = FcWwnInitiatorFactCollector.collect(module, {})
    assert type(fc_facts) is dict
    assert 'fibre_channel_wwn' in fc_facts
    assert len(fc_facts['fibre_channel_wwn']) > 0
    for wwn in fc_facts['fibre_channel_wwn']:
        assert wwn and isinstance(wwn, str)

# test mock objects

# Generated at 2022-06-22 23:51:49.327474
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_inst = FcWwnInitiatorFactCollector()
    assert fcwwn_inst.name == 'fibre_channel_wwn'
    assert fcwwn_inst._fact_ids == set()

# Generated at 2022-06-22 23:51:54.614118
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert(fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn')

# Generated at 2022-06-22 23:51:58.507972
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """test if parse method of FcWwnInitiatorFactCollector works"""
    import platform
    import io
    import os
    import tempfile

    # create test environment (a temporary directory containing a fake file)
    tmpdir = tempfile.mkdtemp()

    filename = os.path.join(tmpdir, 'testfile')
    with open(filename, 'w') as f:
        f.write('test\n')

    # get the FcWwnInitiatorFactCollector class
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector

    # create test case

# Generated at 2022-06-22 23:52:02.653950
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)



# Generated at 2022-06-22 23:52:15.012582
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import re
    import mock
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, check_rc=False):
            self.command = cmd
            return (0,
                    '\n'.join(self.params[self.command]),
                    None)

        def get_bin_path(self, name, opt_dirs=[]):
            return self.params[name]

    class MockCollector(BaseFactCollector):
        def __init__(self):
            self.name = 'mock_collector'
            self.data = dict()
            self._fact_ids = set()


# Generated at 2022-06-22 23:52:18.883204
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids is not None

# Generated at 2022-06-22 23:52:31.277917
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect(collected_facts={})

    # check if 'fibre_channel_wwn' key is present in fc_facts
    assert 'fibre_channel_wwn' in fc_facts

    # check if we get some results back
    assert len(fc_facts['fibre_channel_wwn']) > 0

    # check if we just get correct WWN's back
    for item in fc_facts['fibre_channel_wwn']:
        assert item[:2] == '50'
        assert item[2:4] == '00'
        assert item[4:6] == '60'
        assert item[6:8] == 'b0'
        assert len(item) == 16

# Generated at 2022-06-22 23:52:43.757053
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Processor
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector

    class MockModule(object):
        def __init__(self):
          self.params = {}

        def get_bin_path(self, arg1, opt_dirs=None):
          if arg1 == 'lsdev':
            return '/usr/sbin/lsdev'
          elif arg1 == 'lscfg':
            return '/usr/sbin/lscfg'
          elif arg1 == 'ioscan':
            return '/usr/sbin/ioscan'
          else:
            return '/opt/fcms/bin/fcmsutil'


# Generated at 2022-06-22 23:52:49.941623
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_collected_facts = dict()
    test_module = type('module', (object,), dict())
    fc_collector = FcWwnInitiatorFactCollector()
    fc_collector.collect(test_module, test_collected_facts)
    assert 'fibre_channel_wwn' in test_collected_facts

# Generated at 2022-06-22 23:52:52.222095
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:01.898683
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    # test data
    first_wwn = '00:1b:21:0f:ff:3d:3d:3b'
    second_wwn = '00:1b:21:0f:ff:3d:3d:3c'
    fc_wwn_keys = []

    fact_collector = FcWwnInitiatorFactCollector(module)
    fact_collector.collect()

    # test results
    fc_facts = fact_collector.get_facts()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:53:02.709679
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:53:15.772090
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for method collect of class FcWwnInitiatorFactCollector.
    """
    class MockModule:
        """ Class used to mock the module class.
        """
        def __init__(self):
            pass

        def run_command(self, cmd):
            """ Method used to mock method run_command of Module class.
            """
            if cmd.startswith('fcinfo'):
                return (0, 'HBA Port WWN: 10000090fa1658de', '')
            elif cmd.startswith('ioscan'):
                return (0, '/dev/fcd0   1 0/0/0/0/0/0/0/0  fcd CLAIMED   DEVICE  HP  A5158A', '')

# Generated at 2022-06-22 23:53:17.026545
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector is not None

# Generated at 2022-06-22 23:53:29.062732
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import utils


# Generated at 2022-06-22 23:53:31.419290
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_fact_collector is not None

# Generated at 2022-06-22 23:53:35.357331
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector
    assert fc_wwn_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_collector._fact_ids == set()


# Generated at 2022-06-22 23:53:39.415369
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_fact = FcWwnInitiatorFactCollector()
    collected_facts = {}
    fcwwn_fact.collect(module=None, collected_facts=collected_facts)
    assert collected_facts['fibre_channel_wwn'] == [] or \
                                                type(collected_facts['fibre_channel_wwn']) is list

# Generated at 2022-06-22 23:53:48.023505
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    sys.modules['ansible'] = None
    sys.modules['ansible.module_utils.facts.collector'] = BaseFactCollector()
    sys.modules['ansible.module_utils.facts.collector'].Collectors = Collectors()
    sys.modules['ansible.module_utils.facts.collector'].Collector = BaseFactCollector()
    sys.modules['ansible.module_utils.facts.utils'] = BaseFactCollector()
    sys.modules['ansible.module_utils.facts.utils'].get_file_lines = get_file_lines

   

# Generated at 2022-06-22 23:53:49.594827
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-22 23:54:02.040290
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    collector = FcWwnInitiatorFactCollector()
    # empty result for unsupported platform
    assert collector.collect() == {}
    # example for supported platform
    BaseFactCollector.collectors['platform'] = lambda : 'linux'
    BaseFactCollector.collectors['distribution'] = lambda : 'centos'
    BaseFactCollector.collectors['distribution_version'] = lambda : '7'
    BaseFactCollector.collected_facts = {}
    collector = FcWwnInitiatorFactCollector()
    results = collector.collect()
    assert results
    assert results['fibre_channel_wwn'] == ['21000014ff52a9bb']
    del BaseFactCollector.collected_facts
    del BaseFactCollect

# Generated at 2022-06-22 23:54:07.739058
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fcwwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-22 23:54:10.237192
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:15.366231
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create instance
    fc_fcwwn_collector = FcWwnInitiatorFactCollector()
    # facts = {}
    # fc_fcwwn_collector.collect(module=None, collected_facts=facts)
    # assert fc_fcwwn_collector.name in facts
    # assert facts['fibre_channel_wwn'] != []
    pass

# Generated at 2022-06-22 23:54:27.907134
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test of method collect of class FcWwnInitiatorFactCollector
    """

    import sys
    import unit_test_utils

    # create a mock module
    mock_module = unit_test_utils.MockModule()

    # define the return values for method get_bin_path
    # for linux 'fcinfo' is not in PATH, so return None
    mock_module.get_bin_path_values = {
        'lsdev': None,
        'lscfg': None,
        'ioscan': None,
        'fcmsutil': None
    }

    # create class instance FcWwnInitiatorFactCollector
    # for testing
    testfc = FcWwnInitiatorFactCollector()
    # set platform to linux
    sys.platform = 'linux'
    assert testfc

# Generated at 2022-06-22 23:54:32.992666
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an instance of the class and call method collect
    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_fact_collector.collect()
    assert len(fc_facts) == 1 and len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:54:38.905870
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    # This should not raise an exception
    fcwwn.collect({})
    # check for attribute is defined
    assert fcwwn.name == 'fibre_channel_wwn'
    assert isinstance(fcwwn._fact_ids, set)

# Generated at 2022-06-22 23:54:41.653148
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == "fibre_channel_wwn"
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:54:43.082616
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-22 23:54:45.375011
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.collect()

# Generated at 2022-06-22 23:54:50.466562
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import types
    import unittest
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import py23_compat

    class PlatformStub(object):
        platform = "fake"
        release = "fake"
        system = "linux"
        version = "fake"
        machine = "x86_64"
        python_version = "2.7.9"
        python_version_tuple = ('2', '7', '9')
        python_branch = "fake"
        python_revision = "fake"
        python_build = ("fake", "fake")
        python_compiler = "fake"
        python_im

# Generated at 2022-06-22 23:54:56.180020
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    testmodule = 'fibre_channel_wwn'
    collector = FcWwnInitiatorFactCollector()
    facts = {}
    # no module argument, get_file_lines and run_command will fail
    results = collector.collect(collected_facts=facts)
    assert results == {'fibre_channel_wwn': []}



# Generated at 2022-06-22 23:55:01.908796
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Return an FcWwnInitiatorFactCollector object
    """

    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.collect() == dict(fibre_channel_wwn=[])

# Generated at 2022-06-22 23:55:02.488146
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:55:14.707069
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # create empy testfacts
    testfacts = FcWwnInitiatorFactCollector()

    # create empty test_module
    test_module = {}

    # set module_utils/facts/utils.py get_file_lines to mocked function
    def mocked_get_file_lines(path):
        if path == "testpath1":
            return ["test21000014ff52a9bb\n", "test31000024ff52a9bb\n"]
        if path == "testpath2":
            return ["test41000014ff52a9bb\n", "test51000024ff52a9bb\n"]
        if path == "testpath3":
            return ["test61000014ff52a9bb\n", "test71000024ff52a9bb\n"]

# Generated at 2022-06-22 23:55:23.234084
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # construct expected data structure
    expected = {}
    expected['fibre_channel_wwn'] = [u'10000090fa1658de']
    # construct instance of FcWwnInitiatorFactCollector
    c = FcWwnInitiatorFactCollector()
    # run the code that is being tested
    result = c.collect()
    # compare the expected and the result
    assert result == expected

# Generated at 2022-06-22 23:55:32.153708
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    collector = FcWwnInitiatorFactCollector()
    assert isinstance(collector, BaseFactCollector)
    # test collect method
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'hacking'))
    from test.support import EnvironmentVarGuard
    test_env = EnvironmentVarGuard()
    test_env.set('ANSIBLE_LOCAL', '1')
    test_env.set('ANSIBLE_LOCAL_TEMP', '/tmp')
    test_env.set('ANSIBLE_REMOTE_TEMP', '/tmp')
    # for linux platform

# Generated at 2022-06-22 23:55:38.145808
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Test-cases starts with 'test_FcWwnInitiatorFactCollector_collect_'
    '''
    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_obj.collect()["fibre_channel_wwn"] == []

# Generated at 2022-06-22 23:55:49.170503
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mac_2 = {'fibre_channel_wwn': ['500c500018000042']}
    mac_3 = {'fibre_channel_wwn': ['500c500018000042', '500c500018000043']}
    mac_4 = {'fibre_channel_wwn': ['500c500018000042', '500c500018000043', '500c500018000044']}
    mac_5 = {'fibre_channel_wwn': ['500c500018000042', '500c500018000043', '500c500018000044', '500c500018000052']}