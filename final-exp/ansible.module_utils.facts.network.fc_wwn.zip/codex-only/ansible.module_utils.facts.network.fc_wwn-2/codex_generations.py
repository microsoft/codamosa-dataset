

# Generated at 2022-06-22 23:45:48.262288
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import add_collector
    add_collector(FcWwnInitiatorFactCollector())
    collectors = Collector.get_collector_names()
    assert 'fibre_channel_wwn' in collectors

# Generated at 2022-06-22 23:45:52.135431
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("Test method collect of class FcWwnInitiatorFactCollector")
    fc_wwn_fc = FcWwnInitiatorFactCollector()
    fc_wwn_fc.collect()

# Generated at 2022-06-22 23:45:53.303703
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:05.320785
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_fact_collector.collect(module=module)
    assert fc_wwn_fact_collector.name == "fibre_channel_wwn"
    assert fc_wwn_fact_collector._fact_ids == set()
    assert len(fc_wwn_fact_collector.collect(module=module)) == 1

# Generated at 2022-06-22 23:46:07.790693
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:10.674061
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-22 23:46:13.810378
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:24.533895
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import unittest

    class TestModule(object):
        def __init__(self, platform, hw_fcs):
            self.platform = platform
            self.hw_fcs = hw_fcs
            self.run_command_rc = 0

            self.run_command_out = ""
            self.run_command_err = ""

        def get_bin_path(self, bin_name, opt_dirs=[]):
            if bin_name == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif bin_name == 'lsdev':
                return '/usr/bin/lsdev'
            elif bin_name == 'lscfg':
                return '/usr/bin/lscfg'

# Generated at 2022-06-22 23:46:25.975832
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()



# Generated at 2022-06-22 23:46:28.415456
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn', "Invalid name: %s" % fc_fact.name
    # _fact_ids (Tested implicitly through name property)

# Generated at 2022-06-22 23:46:39.112597
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector._fact_ids is not None
    assert len(fc_wwn_initiator_fact_collector._fact_ids) == 1
    assert 'fibre_channel_wwn' in fc_wwn_initiator_fact_collector._fact_ids
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:42.273588
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-22 23:46:47.998615
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    module = os
    fc_collector = FcWwnInitiatorFactCollector()
    res = fc_collector.collect(module=module)
    assert isinstance(res, dict)
    assert 'fibre_channel_wwn' in res

# Generated at 2022-06-22 23:46:50.363686
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert(fc_facts.name == 'fibre_channel_wwn')
    assert(fc_facts.collect() == {})

# Generated at 2022-06-22 23:46:53.020236
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    :return:
    """

    FcWwnInitiatorFactCollector.collect()


# Generated at 2022-06-22 23:46:55.845396
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_collected_facts = FcWwnInitiatorFactCollector().collect()
    assert(test_collected_facts['fibre_channel_wwn'])


# Generated at 2022-06-22 23:46:56.459206
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:47:09.636941
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {
        "fibre_channel_wwn": [
            "21000014FF52A9BB",
            "21000014FF52A9BA",
            "21000014FF52A9B9"
        ]
    }

    class MockModule:
        def run_command(self, args):
            if "fcs" in args:
                return (0, "Available fcs0, Available fcs1, Defined fcs2, Defined fcs3", "")
            elif "fcmsutil" in args:
                return (0, "        N_Port Port World Wide Name = 0x21000014FF52A9BB", "")

# Generated at 2022-06-22 23:47:12.904130
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_fibre_channel_wwn = FcWwnInitiatorFactCollector()
    assert fact_fibre_channel_wwn.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:47:16.366692
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fci = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fci.name
    assert fci._fact_ids is not None

# Generated at 2022-06-22 23:47:23.043521
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_facts = FcWwnInitiatorFactCollector()
    assert fcwwn_facts.name == 'fibre_channel_wwn'
    assert fcwwn_facts.collect() == {'fibre_channel_wwn': []}


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:47:30.584236
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a module object
    from ansible.module_utils.facts import ModuleFacts

    mf = ModuleFacts(module_name='ansible.builtin.fibre_channel_wwn',
                     module_args={})
    # create a collector object
    fc = FcWwnInitiatorFactCollector()
    # run the collect method
    facts = fc.collect(mf)
    # test the result
    assert facts['ansible_facts']['fibre_channel_wwn']

if __name__ == '__main__':
    # Unit test this module
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:47:43.114667
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ Test case for FcWwnInitiatorFactCollector """


    # Unit test: test_FcWwnInitiatorFactCollector_constructor_success
    # Need to check the constructor of the class
    # Hint: Construtor of base class
    #       self.name = name
    #       self.priority = priority
    #       self.depends = depends
    # Unit test: test_FcWwnInitiatorFactCollector_constructor_success
    # Need to check the constructor of the class
    # Hint: Inheritance, constructor of base class
    # Unit test: test_FcWwnInitiatorFactCollector_constructor_success
    # Need to check the constructor of the class
    # Hint: Construtor of base class
    #       def __init__(self, name,priority=

# Generated at 2022-06-22 23:47:54.811472
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import Facts
    # Test init of class
    fcwwn_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fcwwn_collector, Collector)
    assert isinstance(fcwwn_collector, FcWwnInitiatorFactCollector)
    # Test collect method
    facts = Facts()
    collected_facts = fcwwn_collector.collect(collected_facts=facts)
    assert 'fibre_channel_wwn' in collected_facts
    assert isinstance(collected_facts['fibre_channel_wwn'], list)

# Generated at 2022-06-22 23:47:57.145181
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_module = FcWwnInitiatorFactCollector()
    assert fact_module.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:59.482779
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_host = FcWwnInitiatorFactCollector()
    assert isinstance(fc_host, FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:48:03.198938
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:48:03.818337
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:48:09.086324
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test for constructor of class FcWwnInitiatorFactCollector."""
    fc_info = FcWwnInitiatorFactCollector()
    assert fc_info.name == 'fibre_channel_wwn'
    assert len(fc_info._fact_ids) == 0

# Generated at 2022-06-22 23:48:12.532244
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == "fibre_channel_wwn"
    assert isinstance(collector, BaseFactCollector)
    assert collector._fact_ids == set()
    facts = collector.collect()
    print(facts)
    assert facts['fibre_channel_wwn'] is not None

# Generated at 2022-06-22 23:48:13.745232
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-22 23:48:24.041731
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test data is created in /tmp/ansible_fibre_channel_wwn/
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    set_module_args(dict(gather_subset='all'))

    collector = FcWwnInitiatorFactCollector(module=module)
    result = collector.collect()
    # FIBRE_CHANNEL_FACTS = {'fibre_channel_wwn':['10000090fa1658de']}
    assert result == {'fibre_channel_wwn': ['10000090fa1658de']}

# Generated at 2022-06-22 23:48:26.783800
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-22 23:48:27.647982
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector is not None

# Generated at 2022-06-22 23:48:40.049727
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Unit test for FcWwnInitiatorFactCollector.collect
    '''
    # wwn=['21000014ff52a9bb', '21000014ff52a9bc']
    wwn_data = """
21000014ff52a9bb
21000014ff52a9bc
"""
    # wwn=['0x21000014ff52a9bb']
    wwn_data1 = """
0x21000014ff52a9bb
"""
    # wwn=['10000090fa1658de']

# Generated at 2022-06-22 23:48:49.121481
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    :return:
    """
    # initialize collector object to test
    test_collector = FcWwnInitiatorFactCollector()

    # create fixture object
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    test_collector.collect(module=test_module)
    assert test_collector

# Generated at 2022-06-22 23:49:02.120302
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fake_glob_glob = ["/sys/class/fc_host/host1/port_name", "/sys/class/fc_host/host2/port_name"]
    fake_get_file_lines = [['0x21000014ff52a9bb'], ['0x21000014ff52a9bb']]

    def fake_glob_glob_call(pathname, *args):
        return fake_glob_glob

    def fake_get_file_lines_call(filename, *args, **kwargs):
        return fake_get_file_lines.pop()

    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/usr/bin/' + x

# Generated at 2022-06-22 23:49:13.689193
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    test_class = FcWwnInitiatorFactCollector()

    # check if empty if no linux platform
    test_platform = {'linux2': False,
                     'sunos5': False,
                     'aix': False}

    def test_get_platform(self):
        return test_platform

    test_class.collect()
    assert not test_class.facts['fibre_channel_wwn']

    # check for linux platform
    test_platform = {'linux2': True,
                     'sunos5': False,
                     'aix': False}

    def test_get_platform(self):
        return test_platform

    test_class.collect()

# Generated at 2022-06-22 23:49:19.584889
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fake_module = object()
    fake_module.get_bin_path = lambda x: x
    fc_facts = FcWwnInitiatorFactCollector(fake_module).collect()
    assert fc_facts['fibre_channel_wwn'][0] == '21000014ff52a9bb'

# Generated at 2022-06-22 23:49:22.312662
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert "fibre_channel_wwn" == facts.name

# Generated at 2022-06-22 23:49:23.704578
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_info = FcWwnInitiatorFactCollector()
    assert fc_info.name == 'fibre_channel_wwn'
    assert fc_info._fact_ids is not None

# Generated at 2022-06-22 23:49:24.970170
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a=FcWwnInitiatorFactCollector()
    assert a is not None


# Generated at 2022-06-22 23:49:35.881271
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = get_module_mock()
    if sys.platform.startswith('linux'):
        FcWwnInitiatorFactCollector.collect(module, collected_facts='ansible_facts')
    elif sys.platform.startswith('sunos'):
        FcWwnInitiatorFactCollector.collect(module, collected_facts='ansible_facts')
    elif sys.platform.startswith('aix'):
        FcWwnInitiatorFactCollector.collect(module, collected_facts='ansible_facts')
    elif sys.platform.startswith('hp-ux'):
        FcWwnInitiatorFactCollector.collect(module, collected_facts='ansible_facts')

# Generated at 2022-06-22 23:49:39.081758
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert isinstance(fc, FcWwnInitiatorFactCollector)
    fc.collect()

# Generated at 2022-06-22 23:49:46.582358
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import pprint
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.fibre_channel import FcWwnInitiatorFactCollector

    if platform.system() == 'Linux':
        test_fact_data = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    elif sys.platform.startswith('aix'):
        test_fact_data = {'fibre_channel_wwn': ['10000090FA551509']}
    elif sys.platform.startswith('hp-ux'):
        test_fact_data = {'fibre_channel_wwn': ['50060b00006975ec']}

# Generated at 2022-06-22 23:49:49.049525
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:49:51.877604
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert isinstance(obj, FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:49:54.990859
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # test if class constructor works
    module = AnsibleModuleMock()
    factCollector = FcWwnInitiatorFactCollector(module)


# Generated at 2022-06-22 23:49:56.026795
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:49:59.252016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:50:11.874070
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # 1: no OS specific fact available
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    collector = FcWwnInitiatorFactCollector(None, fc_facts)
    assert collector.collect() == {'fibre_channel_wwn': []}

    # 2: linux FC WWN available
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['ansible_facts'] = {'ansible_os_family': 'RedHat'}
    fc_facts['ansible_system'] = 'Linux'
    collector = FcWwnInitiatorFactCollector(None, fc_facts)

# Generated at 2022-06-22 23:50:14.615026
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    collector = FcWwnInitiatorFactCollector()
    assert collector.collect(module=module) == {}


# Generated at 2022-06-22 23:50:19.132307
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-22 23:50:28.743406
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector

    _collector = Collector()
    _collector.collect(['fibre_channel_wwn'])
    facts_dict = _collector.get_facts()
    my_obj = FcWwnInitiatorFactCollector(None, None, None, {})

    if facts_dict != {}:
        assert('fibre_channel_wwn' in facts_dict)

# Generated at 2022-06-22 23:50:31.250389
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector(
    ).name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:50:44.006116
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts.collector import SymlinkFactsCollector
    from ansible.module_utils.facts.collector import DefaultCollector

    test_dict = {'name': 'fibre_channel_wwn',
                 'file_path': '/sys/class/fc_host/fc',
                 'symlink': '../../devices/pci0000:00/0000:00:03.0/0000:01:00.0/host2/fc_host/fc'}
    collector = SymlinkFactsCollector(test_dict, DefaultCollector())
    collector.collect()
    test_dict['file_path'] = '/sys/class/fc_host/fc/port_name'

# Generated at 2022-06-22 23:50:55.024812
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test of method collec of class FcWwnInitiatorFactCollector
    """
    collector = FcWwnInitiatorFactCollector()

    # run on linux
    collected_facts = dict()
    collected_facts['ansible_os_family'] = 'RedHat'
    result = collector.collect(None, collected_facts)
    assert result['fibre_channel_wwn'] == [u'21000014ff52a9bb']

    # run on solaris
    collected_facts = dict()
    collected_facts['ansible_os_family'] = 'Solaris'
    result = collector.collect(None, collected_facts)
    assert result['fibre_channel_wwn'] == [u'21000014ff52a9bb']

    # run on aix

# Generated at 2022-06-22 23:50:57.623751
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-22 23:51:07.137575
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # substitute for class AnsibleModule
    class AnsibleModuleFake:
        def __init__(self):
            self.params = {}
            self.params['path'] = ['fake_path']
            self.params['name'] = ['fake_name']
            self.params['_ansible_version'] = ['fake_ansible_version']
            self.params['gather_subset'] = []
            self.params['gather_timeout'] = 10
            self.params['filter'] = 'fake_filter'
            self.params['gather_network_resources'] = ['all']
            self.params['gather_subset'] = ['fake_subset']

        def get_bin_path(self, arg1, arg2, **kwargs):
            return arg1

        def run_command(self, arg1):
            return

# Generated at 2022-06-22 23:51:10.163555
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    FcWwnInitiatorFactCollector().collect(None, Facts())

# Generated at 2022-06-22 23:51:19.605953
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    # create mock module object
    from ansible.module_utils.facts import ModuleDummy
    module = ModuleDummy()
    module.run_command = MockModuleRunCommand.run_command
    module.get_bin_path = MockModuleGetBinPath.get_bin_path
    module.fail_json = MockModuleFailJson.fail_json
    # no fc_host / no fcinfo
    collected_facts = collector.collect(module)
    assert collected_facts
    assert not collected_facts['fibre_channel_wwn']

    # invalid output
    MockModuleRunCommand.run_command.output = ""
    collected_facts = collector.collect(module)
    assert collected_facts

# Generated at 2022-06-22 23:51:31.800415
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    sys.modules['ansible'] = {}
    sys.modules['ansible.module_utils'] = {}
    sys.modules['ansible.module_utils.facts'] = {}
    sys.modules['ansible.module_utils.facts.utils'] = {}
    sys.modules['ansible.module_utils.facts.collector'] = {}
    sys.modules['ansible.module_utils.facts.utils.get_file_lines'] = lambda a: ["0x0000111122223333"]
    sys.modules['ansible.module_utils.facts.collector.BaseFactCollector'] = object
    from ansible.module_utils.facts.collector.network import FcWwnInitiatorFactCollector
    collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:51:42.100244
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    # setup default collector to be able to call method collect of
    # FcWwnInitiatorFactCollector
    FactsCollector._collectors['fibre_channel_wwn'] = FcWwnInitiatorFactCollector()

    fc = FcWwnInitiatorFactCollector()

    class Lsdev(object):
        def __init__(self):
            self.rc = 0

# Generated at 2022-06-22 23:51:43.296334
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    my_class = FcWwnInitiatorFactCollector()
    my_class.collect()

# Generated at 2022-06-22 23:51:45.722632
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:48.437621
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fc_fact_collector, BaseFactCollector)

# Generated at 2022-06-22 23:52:01.210569
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for method collect of class FcWwnInitiatorFactCollector """
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument

    class FcWwnInitiatorFactCollectorForTest(FcWwnInitiatorFactCollector):
        """ FcWwnInitiatorFactCollectorForTest """
        def __init__(self):
            """ constructor for FcWwnInitiatorFactCollectorForTest """
            BaseFactCollector.__init__(self)

        #def collect(self, module=None, collected_facts=None):
        #    return {}

    # Testcase 1: dummy fact collection
    fwinit_fc_obj = FcWwnInitiatorFactCollectorFor

# Generated at 2022-06-22 23:52:12.295150
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule(object):

        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            if arg == 'ioscan':
                return '/opt/fcms/bin/ioscan'
            if arg == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'

        def run_command(self, arg):
            return (0, '', '')

    m = FcWwnInitiatorFactCollector()
    result = m.collect(MockModule())
    assert('fibre_channel_wwn' in result)

# Generated at 2022-06-22 23:52:16.256373
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_facts_collector = FcWwnInitiatorFactCollector()
    result = fcwwn_facts_collector.collect()
    assert 'fibre_channel_wwn' in result


# Generated at 2022-06-22 23:52:19.632418
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_init_fac_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_init_fac_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:20.940373
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ checks if class FcWwnInitiatorFactCollector is instantiated """
    obj = FcWwnInitiatorFactCollector(None)
    assert obj is not None


# Generated at 2022-06-22 23:52:30.009359
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = MockModule()
    mock_run_command = MockRunCommand()
    module.run_command = mock_run_command
    FcWwnInitiatorFactCollector.collect(module)
    fc_facts = module.ansible_facts[FcWwnInitiatorFactCollector.name]
    assert len(fc_facts['fibre_channel_wwn']) > 0
    assert fc_facts['fibre_channel_wwn'][0] == '50060b00006975ec'


# Generated at 2022-06-22 23:52:34.533414
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-22 23:52:47.818687
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # create class instance
    fcwwn = FcWwnInitiatorFactCollector()
    # create class instance of base class
    base = BaseFactCollector()

    # create dict to pass to collect function
    collected_facts = {}
    # set of expected fact_ids
    expected_fact_ids = set()
    # call collect function
    fcwwn_facts = fcwwn.collect(collected_facts=collected_facts)

    assert isinstance(fcwwn_facts, dict)
    assert 'fibre_channel_wwn' in fcwwn_facts

# Generated at 2022-06-22 23:52:50.866367
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact is not None


# Generated at 2022-06-22 23:52:55.419637
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # test_FcWwnInitiatorFactCollector_collect is not implemented
    # as ansible uses the facts from setup module, which
    # returns a dictionary with all the facts
    pass

# Generated at 2022-06-22 23:53:02.268513
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwnMod = sys.modules[__name__]
    fcwwnClass = getattr(fcwwnMod, 'FcWwnInitiatorFactCollector')
    fcwwnInst = fcwwnClass()
    sys.platform = 'linux'
    glob.glob = lambda *args: ['/sys/class/fc_host/host0/port_name']
    fcwwnInst.collect()
    sys.platform = 'sunos'
    fcwwnInst.collect()
    sys.platform = 'aix'
    fcwwnInst.collect()
    sys.platform = 'hp-ux'
    fcwwnInst.collect()

# Generated at 2022-06-22 23:53:15.270315
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    result = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    result_sunos = {'fibre_channel_wwn': ['10000090fa1658de']}
    result_aix = {'fibre_channel_wwn': ['10000090fa551c42']}
    result_hp = {'fibre_channel_wwn': ['50060b00006975ec']}

    my_obj = FcWwnInitiatorFactCollector()
    # is the method collect defined?
    assert callable(my_obj.collect)
    # is the result of collect a dictionary?
    assert isinstance(my_obj.collect(), dict)
    # does the dictionary contain the key 'fibre_channel_wwn'?

# Generated at 2022-06-22 23:53:16.172588
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mycollection = FcWwnInitiatorFactCollector()
    mycollection.collect()

# Generated at 2022-06-22 23:53:18.339834
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids is not None
    assert len(obj._fact_ids) == 0

# Generated at 2022-06-22 23:53:30.592019
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import CachingCollector
    module = FakeAnsibleModule()
    cc = CachingCollector(FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:53:39.804025
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a dummy class
    class DummyOS:
        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == "fcinfo":
                if sys.platform.startswith('sunos'):
                    return "./ansible/hacking/test/unit/modules/test_fc_wwn_init_facts.sh"
                elif sys.platform.startswith('aix'):
                    return "./ansible/hacking/test/unit/modules/test_fc_wwn_init_facts_aix.sh"
                elif sys.platform.startswith('hp-ux'):
                    return "./ansible/hacking/test/unit/modules/test_fc_wwn_init_facts_hpux.sh"
            elif arg == "lsdev":
                return

# Generated at 2022-06-22 23:53:44.025198
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    # create an instance of BaseFactCollector
    fcwwnCollector = FcWwnInitiatorFactCollector()
    assert isinstance(fcwwnCollector, BaseFactCollector)

# Generated at 2022-06-22 23:53:51.279734
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.community.general.tests.unit.compat.mock import patch, Mock

    fc_initiator_info = {'fibre_channel_wwn': [
        '21000014ff52a9bb'
    ]}

    mock_module = Mock()
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = '/usr/sbin/fcsutil'
    mock_module.run_command.return_value = (0, 'N_Port Port World Wide Name = 0x50060b00006975ec', '')

    fc_collector = FcWwnInitiatorFactCollector()
    result = fc_collector.collect(module=mock_module)

    assert result

# Generated at 2022-06-22 23:54:03.628135
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule:
        def __init__(self, platform='linux'):
            self.platform = platform

        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'lsdev':
                return '/usr/sbin/lsdev'
            elif cmd == 'lscfg':
                return '/usr/sbin/lscfg'
            elif cmd == 'ioscan':
                return '/usr/sbin/ioscan'
            elif cmd == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            elif cmd == 'fcinfo':
                return '/usr/sbin/fcinfo'

    if sys.platform.startswith('hp-ux'):
        sys.modules['fcmsutil'] = None
    module = TestModule()
    FC

# Generated at 2022-06-22 23:54:09.915460
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Unit test for class FCWwnInitiatorFactCollector
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts_result = fc_facts.collect()
    expected_result = {'fibre_channel_wwn':[]}
    assert sorted(fc_facts_result) == sorted(expected_result)


# Generated at 2022-06-22 23:54:14.802710
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import module_utils.facts.fibre_channel_wwn as fc_wwn_init

    fc_wwn_init_instance = fc_wwn_init.FcWwnInitiatorFactCollector()
    fcwwn_data = fc_wwn_init_instance.collect()
    assert 'fibre_channel_wwn' in fcwwn_data

# Generated at 2022-06-22 23:54:18.452547
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj_one = FcWwnInitiatorFactCollector()
    assert obj_one.name == 'fibre_channel_wwn'
    assert obj_one._fact_ids == set()

# Generated at 2022-06-22 23:54:31.193584
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test that Fibre Channel WWN is collected on supported systems.
    """
    class MockAnsibleModule(object):
        """
        Mock AnsibleModule class that only implements the run_command method
        """
        @staticmethod
        def run_command(cmd):
            if "fcinfo" in cmd:
                return 0, " 10000090fa1658de", ""
            if "lsdev" in cmd and "lscfg" in cmd:
                return 0, "fcs3 Available 0FC Adapter", ""
            if "ioscan" in cmd and "fcmsutil" in cmd:
                return 0, "/dev/fcd0 0/0/1/1.1.1 0", " 50060b00006975ec"
            else:
                return 0, "", ""

# Generated at 2022-06-22 23:54:34.276313
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
   fc = FcWwnInitiatorFactCollector()
   assert fc.name == 'fibre_channel_wwn'
   assert 'fc_host' in fc.collect().keys()


# Generated at 2022-06-22 23:54:39.330057
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc = FcWwnInitiatorFactCollector('dummy', module=module)
    assert fc.collect() == {'fibre_channel_wwn': []}

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-22 23:54:43.307760
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj
    assert test_obj.name == "fibre_channel_wwn"
    assert test_obj._fact_ids == set()


# Generated at 2022-06-22 23:54:54.107956
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # mocking arguments and return values
    module = mock_ansible_module()
    collected_facts = dict()

    # instantiate FcWwnInitiatorFactCollector class
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    # execute method collect
    res = fc_wwn_initiator_fact_collector.collect(module=module, collected_facts=collected_facts)

    # assert return values
    assert isinstance(collected_facts, dict)
    assert isinstance(res, dict)
    assert res == {'fibre_channel_wwn': []}


# Generated at 2022-06-22 23:54:55.971569
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts = FcWwnInitiatorFactCollector.collect()
    assert len(facts) > 1

# Generated at 2022-06-22 23:55:06.040356
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import LinuxSysctlFactCollector as Linux
    from ansible.module_utils.facts import SunOSSysctlFactCollector as SunOS
    import os
    import tempfile
    import pytest
    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 23:55:08.753120
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:55:12.901502
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == "fibre_channel_wwn"
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-22 23:55:14.977190
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:55:26.086754
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    fcwwn_initiator = FcWwnInitiatorFactCollector()
    fcwwn_facts = fcwwn_initiator.collect()
    assert 'fibre_channel_wwn' in fcwwn_facts
    assert len(fcwwn_facts['fibre_channel_wwn']) > 0
    assert '21000014ff52a9bb' in fcwwn_facts['fibre_channel_wwn']



# Generated at 2022-06-22 23:55:27.616111
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:55:29.357815
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:40.846598
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'fcinfo':
                return '/usr/bin/fcinfo'
            elif name == 'lsdev':
                return '/usr/sbin/lsdev'
            elif name == 'lscfg':
                return '/usr/sbin/lscfg'
            elif name == 'ioscan':
                return '/sbin/ioscan'
            elif name == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            else:
                return ''


# Generated at 2022-06-22 23:55:49.206847
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # we can't test this on every system
    return
    """
    Example contents /sys/class/fc_host/*/port_name:

    0x21000014ff52a9bb
    """
    collector = FcWwnInitiatorFactCollector()
    collected_facts = collector.collect()
    assert len(collected_facts['fibre_channel_wwn']) == 1
    assert 'fibre_channel_wwn' in collected_facts
    assert collected_facts['fibre_channel_wwn'][0] == '21000014ff52a9bb'
