

# Generated at 2022-06-22 23:45:54.619662
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # simulate an ansible module object and class AnsibleModule
    class mock_module():
        def __init__(self):
            self.params = dict()
        def get_bin_path(self, *args, **kwargs):
            return '/bin/fcinfo'
        def run_command(self, cmd):
            class mock_run_command():
                def __init__(self):
                    self.stdout = '''HBA Port WWN: 210000e08b4c4e89
HBA Port WWN: 210000e08b4c4e8a
'''
            return 0, mock_run_command().stdout, None
    # create an instance of mocked AnsibleModule
    mock_ansible_module = mock_module()
    # create an instance of mocked AnsibleModule
    facts_collector = FcW

# Generated at 2022-06-22 23:45:57.826737
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn', fc.name


# Generated at 2022-06-22 23:46:07.880385
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def get_bin_path(bin):
        return True
    class Module(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.binary = kwargs['binary']

        def get_bin_path(self, bin, opt_dirs=[]):
            return get_bin_path(bin)

        def run_command(self, cmd):
            return (0, '', '')
    test_module = Module(binary='ansible-test')
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector(module=test_module)
    data = fc_wwn_fact_collector.collect()
    assert data == {}


# Generated at 2022-06-22 23:46:20.048877
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''Unit test for method collect of class FcWwnInitiatorFactCollector
    '''
    class MockModule(object):
        '''Class mock for module
        '''
        def __init__(self):
            self.params = {}

        class MockSubprocess(object):
            '''Class mock for subprocess
            '''
            def __init__(self, return_code, output, error):
                self.returncode = return_code
                self.output = output
                self.splitlines = lambda:[output]
                self.error = error

            def communicate(self):
                return (self.output, self.error)

        def run_command(self, cmd):
            if cmd.startswith('lsdev'):
                # AIX 7.1
                lsdev_rc = '0'
                lsdev

# Generated at 2022-06-22 23:46:23.816124
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_mod = FcWwnInitiatorFactCollector()

    assert fact_mod.name == 'fibre_channel_wwn'
    assert set(['fibre_channel_wwn']) == fact_mod._fact_ids

# Generated at 2022-06-22 23:46:27.239060
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnFacts = FcWwnInitiatorFactCollector()
    assert fcWwnFacts.name == 'fibre_channel_wwn'
    assert fcWwnFacts._fact_ids == set()


# Generated at 2022-06-22 23:46:39.206280
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector._platform = "linux"
    FcWwnInitiatorFactCollector._module = "os_platform_linux"
    FcWwnInitiatorFactCollector._collector = FcWwnInitiatorFactCollector(FcWwnInitiatorFactCollector._module)
    res = FcWwnInitiatorFactCollector._collector.collect()
    assert type(res.get('fibre_channel_wwn')) is list
    FcWwnInitiatorFactCollector._platform = "sunos"
    FcWwnInitiatorFactCollector._module = "os_platform_sunos"

# Generated at 2022-06-22 23:46:48.236983
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:46:51.838698
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-22 23:46:54.832168
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    o = FcWwnInitiatorFactCollector()
    assert o.name == 'fibre_channel_wwn'
    assert o._fact_ids == set()



# Generated at 2022-06-22 23:46:57.165617
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:00.509669
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_instance = FcWwnInitiatorFactCollector()
    assert test_instance.name == 'fibre_channel_wwn'
    assert not test_instance._fact_ids

# Generated at 2022-06-22 23:47:13.319593
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of FcWwnInitiatorFactCollector.
    Method collect of FcWwnInitiatorFactCollector is able to get a list
    of Fibre Channel WWN IDs.
    """
    fc_facts = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        fc_facts_linux = {'fibre_channel_wwn': ['21000014ff52a9bb']}
        assert fc_facts.collect() == fc_facts_linux
    elif sys.platform.startswith('sunos'):
        fc_facts_solaris = {'fibre_channel_wwn': ['10000090fa1658de']}
        assert fc_facts.collect() == fc_facts_solar

# Generated at 2022-06-22 23:47:17.946502
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # it's not that easy to test this constructor, because it's supposed to be
    # used dynamically and not static like this
    # just check if an object could be instantiated with this constructor
    fc = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:47:20.171569
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:26.523718
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import platform
    fw = FcWwnInitiatorFactCollector()
    assert fw.name == 'fibre_channel_wwn'
    assert fw._fact_ids == set()
    # FcWwnInitiatorFactCollector.collect() is tested by :
    # test/units/modules/utils/facts/test_ansible_local.py

# Generated at 2022-06-22 23:47:39.322374
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a mock object for the module
    # with a unctionnal get_bin_path mock.
    class MockModule(object):
        def __init__(self):
            self._bin_path = {}

        def get_bin_path(self, cmd, **kwargs):
            return self._bin_path.get(cmd)

    # Create the instance of the class FcWwnInitiatorFactCollector
    fc_wwn = FcWwnInitiatorFactCollector()

    # Check if os is linux and /sys/class/fc_host is present
    if sys.platform.startswith('linux'):
        # Mock the module
        module = MockModule()

        # Set fake get_bin_path return value

# Generated at 2022-06-22 23:47:41.905460
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:46.061776
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-22 23:47:47.692429
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:47:49.589697
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:59.580581
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method tests the collect method of class FcWwnInitiatorFactCollector.
    """
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import facts

    fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb']}

    fc_wwn_collector = FcWwnInitiatorFactCollector()
    fc_wwn_collector.collect()

    assert fc_wwn_collector.collect() == fc_facts

# Generated at 2022-06-22 23:48:12.059675
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import unittest

    if platform.system() != 'Linux':
        unittest.skip('%s platform not supported' % platform.system())

    # Create an instance of a module
    module = FakeModule()

    # Create a dictionary of facts - this will be collected
    # by the class and tested
    facts = dict(ansible_facts=dict())

    # Create an instance of FcWwnInitiatorFactCollector
    collector = FcWwnInitiatorFactCollector(module=module,
                                            facts=facts)

    # Test the collect method
    collector.collect()

    # Test the facts returned
    assert 'fibre_channel_wwn' in facts['ansible_facts']

# Generated at 2022-06-22 23:48:15.707326
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert fc_wwn._fact_ids == set()

# Generated at 2022-06-22 23:48:21.550349
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys

    collector = FcWwnInitiatorFactCollector()
    # test sys.platforms
    platf = 'not_real_platform'
    sys.platform = platf
    assert collector.name == 'fibre_channel_wwn'
    assert collector.platform == platf


# Generated at 2022-06-22 23:48:25.142312
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    expected_result = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    assert result == expected_result

# Generated at 2022-06-22 23:48:27.218673
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:39.892410
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import get_facts
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector

    collector = Collector()
    collector._fact_collectors = [FcWwnInitiatorFactCollector()]
    collected_facts = collector.collect(get_facts(dict()))
    assert 'fibre_channel_wwn' in collected_facts
    assert isinstance(collected_facts['fibre_channel_wwn'], list)
    assert len(collected_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:48:44.352670
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fact_collector._fact_ids

# Generated at 2022-06-22 23:48:51.679588
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    Return nothing, just validate the format
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    fact_collector = FcWwnInitiatorFactCollector()
    result = fact_collector.collect()
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-22 23:48:54.080641
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:03.162303
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = MockModule()
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector(module=module_mock)

    collected_facts = dict()
    fc_wwn_fact_collector.collect(module_mock, collected_facts)
    assert type(collected_facts) is dict
    assert collected_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']



# Generated at 2022-06-22 23:49:14.418285
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test output of method collect against current output of
    "fcinfo hba-port". Just check if the same WWNs are returned.

    """
    module = None
    collected_facts = None
    fcwwn = FcWwnInitiatorFactCollector()
    rc, fcinfo_out, err = module.run_command("fcinfo hba-port")
    fcinfo_out = fcinfo_out.splitlines()
    fcinfo_wwn = []
    for line in fcinfo_out:
        if 'Port WWN' in line:
            data = line.split(' ')
            fcinfo_wwn.append(data[-1].rstrip())
    fc_facts = fcwwn.collect()

# Generated at 2022-06-22 23:49:22.004236
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn', 'Wrong name: %s' % fc_facts.name
    assert 'fibre_channel_wwn' in fc_facts.collect().keys(), 'Wrong collected facts: %s' % fc_facts.collect()


# Generated at 2022-06-22 23:49:33.327410
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts import collector

    class fake_module:
        def __init__(self):
            self.params = {}
            self.platform = platform.system()

        def get_bin_path(self, arg, opt_dirs=[]):
            self.bin_path = arg
            self.opt_dirs = opt_dirs
            return '/bin/foo'

        def run_command(self, arg):
            self.command = arg
            return (0, '', '')

    class fake_platform:
        def system(self):
            return "Linux"

    class fake_collector:
        def collect(self, module=None, collected_facts=None):
            return "bar"

    ffc = FcWwnInitiatorFactCollector()
    assert ffc

# Generated at 2022-06-22 23:49:45.217235
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    host_facts = {}
    # on linux
    if platform.system() == 'Linux':
        host_facts['distribution'] = 'centos'
        host_facts['distribution_version'] = '7.2'
        host_facts['distribution_release'] = 'Core'
    # on solaris
    if platform.system().startswith('SunOS'):
        host_facts['distribution'] = 'solaris'
        host_facts['distribution_version'] = '11'
        host_facts['distribution_release'] = '11.3'
    # on aix
    if platform.system() == 'AIX':
        host_facts['distribution'] = 'aix'
        host_facts['distribution_version'] = '7100-04'
    # on hp-ux
   

# Generated at 2022-06-22 23:49:47.292065
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcFactColl = FcWwnInitiatorFactCollector()
    assert fcFactColl

# Generated at 2022-06-22 23:49:51.863573
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import unittest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Collector

    FcWwnInitiatorFactCollector.collect(module=None)
    #fibre_channel_wwn_data = FcWwnInitiatorFactCollector.collect(module=None)
    #print( "fibre_channel_wwn_data: ", fibre_channel_wwn_data )


# Generated at 2022-06-22 23:49:54.934776
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Check init
    fcwwn=FcWwnInitiatorFactCollector()
    assert fcwwn.name=='fibre_channel_wwn'

# Generated at 2022-06-22 23:49:58.993997
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn', "Name of the class FcWwnInitiatorFactCollector should be fibre_channel_wwn"

# Generated at 2022-06-22 23:50:01.645957
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:13.948748
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils._text import to_text
    try:
        from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    except ImportError:
        from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    FACTS_CACHE = {}

    class AnsibleModuleFake(object):
        def __init__(self, *args, **kwargs):
            self.run_command_count = 0
            self.run_

# Generated at 2022-06-22 23:50:18.305182
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    myFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    facts = myFcWwnInitiatorFactCollector.collect()
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-22 23:50:31.150068
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector

    # Create the collector object
    fc_fact_collector = FcWwnInitiatorFactCollector()

    # Create a class for the module paramaters
    class module:
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}

        class params:
            ansible_python_interpreter = ''

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, name, opt_dirs=[]):
            binary = None
            if name == 'ioscan':
                binary = '/usr/sbin/ioscan'

# Generated at 2022-06-22 23:50:43.909771
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import unittest
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        @staticmethod
        def get_bin_path(bin_name, opt_dirs=None, required=True):
            """This method takes a binary name (for example, cp, ls, python)
            and returns the full path (for example /usr/bin/python)
            or raises an exception.
            """
            return os.path.join('/usr/bin', bin_name)

        @staticmethod
        def run_command(command, check_rc=True):
            rc = 0

# Generated at 2022-06-22 23:50:45.762442
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:46.562242
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:50.539512
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Unit test for FcWwnInitiatorFactCollector - constructor
    fcwwn_fc = FcWwnInitiatorFactCollector()
    assert fcwwn_fc.name == 'fibre_channel_wwn'
    assert fcwwn_fc._fact_ids == set()


# Generated at 2022-06-22 23:51:03.212845
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class DummyModule():
        def get_bin_path(self, *args, **kwargs):
            return 'bin'
        def run_command(self, *args, **kwargs):
            class Dummy():
                def __init__(self):
                    self.rc = 0
                    self.stdout = 'stdout'
                    self.stderr = ''
            return Dummy()

    module = DummyModule()
    fc_facts = FcWwnInitiatorFactCollector().collect(module)


# Generated at 2022-06-22 23:51:15.352319
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys

    mock_module = type('module', (object,), {'run_command': run_command})()
    m_collector = FcWwnInitiatorFactCollector()

    m_data_linux = '''0x21000014ff52a9bb\n'''
    m_data_sunos = '''HBA Port WWN: 10000090fa1658de\n'''
    m_data_aix = '''10000090FA551509\n'''
    m_data_hpux = '''0x50060b00006975ec\n'''

    class MockFile(object):
        def __init__(self, data):
            self.data = data

        def readlines(self):
            return self.data.splitlines()


# Generated at 2022-06-22 23:51:28.216550
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import platform
    import tempfile
    import filecmp
    import sys
    import random

    # select platform-specific data accordingly
    if (platform.system() == 'Linux'):
        target_file = '/etc/passwd'
    elif (platform.system() == 'SunOS'):
        target_file = '/etc/passwd'
    elif (platform.system() == 'HP-UX'):
        target_file = '/etc/passwd'
    elif (platform.system() == 'AIX'):
        target_file = '/etc/passwd'
    else:
        target_file = '/etc/passwd'

    # define a collection of items to be used as source content

# Generated at 2022-06-22 23:51:32.402591
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == {'fibre_channel_wwn'}

# Generated at 2022-06-22 23:51:43.233310
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Use fake os platform and the following fake contents
    of /sys/class/fc_host/*/port_name files:
    0x21000014ff52a9bb
    """
    import platform
    from ansible.module_utils.facts import collect
    from ansible.module_utils.facts.collector import get_collector_instance

    platform.system = lambda: 'Linux'
    FcWwnInitiatorFactCollector._fact_ids = None
    FcWwnInitiatorFactCollector._platform = None

    facts_d = {}
    std_facts = collect.get_std_facts(facts=facts_d)
    collector = get_collector_instance(FcWwnInitiatorFactCollector, std_facts)
    result = collector.collect()

# Generated at 2022-06-22 23:51:49.700406
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Unit tests must be run from ./hacking/test-unit subdirectory
    # Some tests do not pass on Ubuntu / Debian,
    # but they pass on RedHat / CentOS
    if sys.platform.startswith('linux'):
        collector = FcWwnInitiatorFactCollector()
        assert collector.name == 'fibre_channel_wwn'
        assert collector._fact_ids == set()



# Generated at 2022-06-22 23:51:54.458344
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-22 23:52:04.339419
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector
    class TestAnsibleModule(object):
        def __init__(self):
            self.run_command =  lambda x, y: [0, "", ""]
            self.get_bin_path = lambda x, y=None: None
    # on Linux
    if platform.system() == "Linux":
        class TestFile(object):
            def __init__(self, lines):
                self.lines = lines
                self.readlines_counter = 0
            def readlines(self):
                self.readlines_counter += 1

# Generated at 2022-06-22 23:52:12.248109
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Create an instance of class FcWwnInitiatorFactCollector
    FcWwnInitiatorFactCollector()
    # Test the constructor of class FcWwnInitiatorFactCollector.
    # If the constructor raises no exceptions, the test succeeds.
    # If the constructor raises an exception, the test fails.
    # Note that this test does not test the functionality of class FcWwnInitiatorFactCollector, it
    # tests the constructor only.


# Generated at 2022-06-22 23:52:15.383609
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fc = FcWwnInitiatorFactCollector()
    assert fc_fc.name == 'fibre_channel_wwn'
    assert fc_fc._fact_ids == set()

# Generated at 2022-06-22 23:52:28.418474
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector.defaults import DefaultCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.facts import Facts

    from ansible.module_utils.basic import AnsibleModule

    content = ["0x21000014ff52a9bb", "0x21000018ff52a7a3", "0x21000014ff52a895"]
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    collector = FcWwnInitiatorFactCollector(module=module)
    collector.collect()
    facts = Facts

# Generated at 2022-06-22 23:52:31.752967
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None

# Generated at 2022-06-22 23:52:35.277018
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-22 23:52:36.529592
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:41.731983
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method FcWwnInitiatorFactCollector.collect of class FcWwnInitiatorFactCollector
    """
    module_args = {}
    FcWwnInitiatorFactCollector.collect(module_args)


# Generated at 2022-06-22 23:52:44.603158
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:50.188486
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert '_' not in FcWwnInitiatorFactCollector.name
    assert FcWwnInitiatorFactCollector.name not in BaseFactCollector.deprecated_names

# Generated at 2022-06-22 23:52:52.800021
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_pfc = FcWwnInitiatorFactCollector()
    assert fc_pfc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:57.189014
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_col = FcWwnInitiatorFactCollector()
    assert fcwwn_col.name == 'fibre_channel_wwn'
    assert fcwwn_col._fact_ids == set()
    assert fcwwn_col.collect() == {}

# Generated at 2022-06-22 23:53:04.517628
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import os
    import sys
    import tempfile

    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = []
            self.run_command_kwargs = []

        def get_bin_path(self, name, *args):
            return 'nosuchcommand'

        def run_command(self, cmd, *args, **kwargs):
            self.run_command_count += 1
            self.run_command_args.append( (cmd,) + args )
            self.run_command_kwargs.append(kwargs)

            # TODO: handle more varied data
            if 'fcinfo' in cmd:
                if self.run_command_count == 1:
                    return (1, '', '')

# Generated at 2022-06-22 23:53:07.215816
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwwn = FcWwnInitiatorFactCollector()
    assert fwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:16.483614
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    # Here we don't need a module, but the collect method requires it
    module = None
    collected_facts = {}

    # remove potential previous collection
    if 'fibre_channel_wwn' in collected_facts:
        del collected_facts['fibre_channel_wwn']

    collected_facts = fact_collector.collect(module, collected_facts)

    # Check the facts include the WWN
    assert ('fibre_channel_wwn' in collected_facts)

# Generated at 2022-06-22 23:53:18.440958
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:20.647101
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:25.976105
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    my_object = FcWwnInitiatorFactCollector(Collector)
    assert my_object.name == 'fibre_channel_wwn'
    assert my_object._fact_ids == set()


# Generated at 2022-06-22 23:53:36.943399
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import pytest
    import re

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.linux import hardware
    from ansible.module_utils.facts.hardware.fibre_channel_wwn import FcWwnInitiatorFactCollector

    class MockModule(object):
        def __init__(self):
            self._sys_platform = sys.platform

        def run_command(self, cmd):
            if '/usr/bin/fcinfo hba-port' in cmd:
                stdout = 'HBA Port WWN: 10000090fa1658de'
                return 0, stdout, ''

# Generated at 2022-06-22 23:53:38.105169
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:53:41.345158
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:53:52.294984
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import mock
    import platform

    # setting up some minimum required attributes before instantiation
    FcWwnInitiatorFactCollector.name = 'fibre_channel_wwn'
    FcWwnInitiatorFactCollector.__doc__ = 'Example doc string'
    FcWwnInitiatorFactCollector.platforms = ['linux', 'solaris', 'aix', 'hp-ux']
    FcWwnInitiatorFactCollector.validate_facts = False
    FcWwnInitiatorFactCollector.has_jmespath_exception = False
    FcWwnInitiatorFactCollector.jmespath_exception = None

    # setting up some minimum required attributes before instantiation
    module = mock.MagicMock()
    module.get_bin_path.return_value = True

# Generated at 2022-06-22 23:53:57.025479
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert 'fibre_channel_wwn' in fc.collect().keys()

# Generated at 2022-06-22 23:54:09.133607
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from pytest import raises
    from ansible.module_utils.facts.collector.kernel import KernelFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    test_facts = Collector()
    test_facts.collector = [KernelFactCollector, FcWwnInitiatorFactCollector]

    if sys.platform.startswith('aix'):
        # if we can run lscfg, lscfg_cmd will have a value
        lscfg_cmd = test_facts.module.get_bin_path('lscfg')
        # if we can run lsdev, lsdev_cmd will have a value

# Generated at 2022-06-22 23:54:18.014010
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collectors import base
    from ansible.module_utils.facts.collectors.fc_wwn_initiator import FcWwnInitiatorFactCollector

    BaseFactCollector.set_collection_filter(['fibre_channel_wwn'])
    fci_collector = base.get_collector(None, ansible_collections,
                                       'fibre_channel_wwn',
                                       FcWwnInitiatorFactCollector)
    module = MockModule()
    fc_facts = fci_collector.collect(module=module, collected_facts={})
    # check that WWN is found on linux and not on solaris

# Generated at 2022-06-22 23:54:20.479971
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_fact_collector

# Generated at 2022-06-22 23:54:22.522428
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-22 23:54:27.044075
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:54:35.780343
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = get_ansible_module(dict())
    result = FcWwnInitiatorFactCollector().collect(module)
    assert isinstance(result, dict), 'fibre_channel_wwn facts class returns a dictionary'
    assert 'fibre_channel_wwn' in result, 'fibre_channel_wwn facts key exists'
    assert isinstance(result['fibre_channel_wwn'], list), 'fibre_channel_wwn facts is a list'
    assert len(result['fibre_channel_wwn']) == 3, 'fibre_channel_wwn facts list has 3 entries'

# Generated at 2022-06-22 23:54:42.968561
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    FcWwnInitiatorFactCollector = get_collector_instance(FcWwnInitiatorFactCollector)
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:55.417094
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule:
        def __init__(self):
            self.params = {"key": "value"}
            self.bin_path_cache = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            """
            Mock the search for a binary in a list of directories.
            """
            if arg == 'fcinfo':
                # solaris
                return '/usr/sbin/fcinfo'
            elif arg == 'lsdev':
                # AIX
                return '/usr/sbin/lsdev'
            elif arg == 'lscfg':
                # AIX
                return '/usr/sbin/lscfg'

# Generated at 2022-06-22 23:55:00.873936
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector loaded and working

    """
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:55:02.395868
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:55:14.671865
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Check on Linux that 1) we have the symlink /sys/class/fc_host
    #                                           2) we have at least one filesystem under /sys/class/fc_host
    result = dict(changed=False, ansible_facts=dict())
    for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
        for line in get_file_lines(fcfile):
            wwn = line.rstrip()[2:]
            result['ansible_facts']['fibre_channel_wwn'] = wwn
    assert result['ansible_facts']['fibre_channel_wwn'] is not None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:55:21.065531
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector is not None
    assert fc_fact_collector.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:55:23.997644
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec=dict())
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:55:35.890878
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    from ansible.module_utils.facts import get_module_facts
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # Test method collect of class FcWwnInitiatorFactCollector
    #
    # Return a fact_subset and exit. This fact_subset should
    # have a key, 'fibre_channel_wwn' in it
    #
    # Since this test runs on many systems, we can't easily
    # test whether or not the key is present.
    #
    # Instead, we'll test that the method returns a dict with exactly
    # one key

    # get Ansible module facts
    facts = get_module_facts(FcWwnInitiatorFactCollector())

    # look

# Generated at 2022-06-22 23:55:37.883143
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    F = FcWwnInitiatorFactCollector()
    assert type(F.collect()) is dict

# Generated at 2022-06-22 23:55:44.347033
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print (FcWwnInitiatorFactCollector.name)
    if sys.version_info.major >= 3:
        # as of now, only tested on python2
        pass
    else:
        # test constructor
        obj = FcWwnInitiatorFactCollector()
        assert obj.name == 'fibre_channel_wwn'
        assert obj._fact_ids == set()