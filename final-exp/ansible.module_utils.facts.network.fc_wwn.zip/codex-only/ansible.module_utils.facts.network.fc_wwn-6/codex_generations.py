

# Generated at 2022-06-22 23:45:50.340689
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This function is used to test the FcWwnInitiatorFactCollector.collect method
    in FcWwnInitiatorFactCollector class.
    """

    # create object of FcWwnInitiatorFactCollector class and calling
    # collect method on it
    fc_obj = FcWwnInitiatorFactCollector()
    print(fc_obj.collect())

# Generated at 2022-06-22 23:45:53.094717
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:45:56.453586
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fcnidr_collector = FcWwnInitiatorFactCollector()
    assert fc_fcnidr_collector is not None


# Generated at 2022-06-22 23:46:02.243504
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert globals()['FcWwnInitiatorFactCollector'].__name__ == 'FcWwnInitiatorFactCollector'
    assert globals()['FcWwnInitiatorFactCollector'].name == 'fibre_channel_wwn'
    assert globals()['FcWwnInitiatorFactCollector']._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-22 23:46:06.397234
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert set(obj._fact_ids) == set(['fibre_channel_wwn'])


# Generated at 2022-06-22 23:46:10.122710
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_obj = FcWwnInitiatorFactCollector()
    test_module = FauxAnsibleModule()
    test_facts = {}

    response = test_obj.collect(test_module, test_facts)
    assert 'fibre_channel_wwn' in response



# Generated at 2022-06-22 23:46:15.337645
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    expected_collector_name = 'fibre_channel_wwn'
    expected_fact_ids = set()
    assert obj.name == expected_collector_name
    assert obj._fact_ids == expected_fact_ids


# Generated at 2022-06-22 23:46:18.793869
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector.name == 'fibre_channel_wwn'
    assert fc_facts_collector._fact_ids == set()

# Generated at 2022-06-22 23:46:29.197745
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.smart.fibre_channel_wwn import FcWwnInitiatorFactCollector

    class FakeModule(object):
        def __init__(self, bin_ansible_call):
            self.bin_ansible_call = bin_ansible_call

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return self.bin_ansible_call

    class FakeFactCollector(BaseFactCollector):
        def __init__(self, module):
            pass


# Generated at 2022-06-22 23:46:31.495515
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()


# Generated at 2022-06-22 23:46:42.403992
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    class FakeModule(object):
        def run_command(self, cmd):
            return 0, '', ''

        def get_bin_path(self, cmd, opt_dirs=[]):
            return '/bin/' + cmd

    # create a fake module
    module = FakeModule()
    facts = {}

    # create the platform specific collector
    fc = FcWwnInitiatorFactCollector()

    # invoke the collect function of the collector
    fc.collect(module=module, collected_facts=facts)

    # assert
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-22 23:46:47.441655
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn', 'Test FcWwnInitiatorFactCollector - instance creation'

# Generated at 2022-06-22 23:46:55.288923
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:46:59.659223
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    fc_factcollector = FcWwnInitiatorFactCollector()
    assert fc_factcollector.collect() == facts


# Generated at 2022-06-22 23:47:12.569325
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    unit test to test collect()
    """

    import os
    import sys
    import tempfile
    import unittest

    class FcWwnInitiatorFactCollectorCollectTestCase(unittest.TestCase):
        """
        unit test class to test collect()
        """

        def setUp(self):
            """
            initialize test variables
            """

            self.tmp_dir = tempfile.mkdtemp(prefix='test_FcWwnInitiatorFactCollector_collect')
            sys.platform = 'linux'

            self.test_fchost_path = self.tmp_dir + os.sep + 'test_fchost_path'

# Generated at 2022-06-22 23:47:15.786805
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert hasattr(fc, 'name')
    assert hasattr(fc, 'collect')


# Generated at 2022-06-22 23:47:27.170042
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector constructor by instantiating it with a module and some facts then checking
    if the instance name is correctly set to 'fibre_channel_wwn', and fact_ids set correctly.
    """
    test_collector = FcWwnInitiatorFactCollector()
    assert test_collector.name == 'fibre_channel_wwn',\
        'Expected instance name "fibre_channel_wwn", got %s.' % test_collector.name
    assert test_collector._fact_ids == set(),\
        'Expected instance attribtue _fact_ids to be %s, got %s.' % (set(), test_collector._fact_ids)

# Generated at 2022-06-22 23:47:39.452124
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()

    # Set up filesystem directory structure
    dir_tree = [
        '/sys/class',
        '/sys/class/fc_host',
        '/sys/class/fc_host/fc_host0',
        '/sys/class/fc_host/fc_host0/port_name',
        '/sys/class/fc_host/fc_host1',
        '/sys/class/fc_host/fc_host1/port_name',
        '/sys/class/fc_host/fc_host2',
        '/sys/class/fc_host/fc_host2/port_name',
        '/sys/class/fc_host/fc_host3',
        '/sys/class/fc_host/fc_host3/port_name',
    ]

    # Set up files
    fc

# Generated at 2022-06-22 23:47:42.856947
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert not fc_collector._fact_ids

# Generated at 2022-06-22 23:47:55.830266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import platform

    class FakeModule(object):
        def get_bin_path(self, arg):
            if arg == 'fcinfo':
                return "/usr/sbin/fcinfo"
            elif arg == 'lsdev':
                return "/usr/sbin/lsdev"
            elif arg == 'lscfg':
                return "/usr/sbin/lscfg"
            elif arg == 'ioscan':
                return "/usr/sbin/ioscan"
            elif arg == 'fcmsutil':
                return "/opt/fcms/bin/fcmsutil"
            else:
                return None


# Generated at 2022-06-22 23:48:02.086398
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()
    assert fc_fact_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:48:02.824923
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f != None

# Generated at 2022-06-22 23:48:06.340176
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:08.023787
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    print(fc_facts)

# Generated at 2022-06-22 23:48:20.564702
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollectorModule

    class MyModule(AnsibleFactCollectorModule):
        pass

    my_module = MyModule()

    fcwwn_obj = get_collector_instance(my_module, 'fibre_channel_wwn')
    assert(isinstance(fcwwn_obj, FcWwnInitiatorFactCollector))

    # test collect method of class FcWwnInitiatorFactCollector
    # in real environment, we should use the run_commands_from_module method
    # and test the results, using testinfra maybe

# Generated at 2022-06-22 23:48:32.015924
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Create empty class for testing
    test_module = type('TestModule', (object,), {})

    # Create empty ansible_module_data
    ansible_module_data = {}

    # Create instance of class FcWwnInitiatorFactCollector
    fc_wwn_fact_collector_inst = FcWwnInitiatorFactCollector()

    # Call collect method of instance FcWwnInitiatorFactCollector
    result = fc_wwn_fact_collector_inst.collect(test_module, ansible_module_data)

    # Check result
    assert result != {}
    assert 'fibre_channel_wwn' in result
    assert isinstance(result['fibre_channel_wwn'], list)

# Generated at 2022-06-22 23:48:36.375010
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create instance
    FcWwn = FcWwnInitiatorFactCollector()

    # Check result
    assert FcWwn.collect() == dict(fibre_channel_wwn=[])

# Generated at 2022-06-22 23:48:40.359140
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    my_obj = FcWwnInitiatorFactCollector()
    my_str = my_obj.collect()
    assert isinstance(my_str, dict)


# Generated at 2022-06-22 23:48:44.151150
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test of constructor of class FcWwnInitiatorFactCollector
    my_obj = FcWwnInitiatorFactCollector()
    assert my_obj


# Generated at 2022-06-22 23:48:56.446571
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FcWwnInitiatorFactCollector
    import sys
    import os
    import shutil
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import BaseFactCollector

    collector = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        class Module(object):
            def __init__(self, module_utils):
                self.params = {}
                self.module_utils = module_utils
                self.run_command = self.mock_run_command
            def mock_run_command(self, cmd):
                return dict(rc=0, stdout="", stderr="")
        module = Module({})
        #

# Generated at 2022-06-22 23:49:02.745787
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()



# Generated at 2022-06-22 23:49:06.660306
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' not in f._fact_ids
    assert f._fact_ids is not None

# Generated at 2022-06-22 23:49:09.414804
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fciFact = FcWwnInitiatorFactCollector()
    assert fciFact.name == 'fibre_channel_wwn'
    assert sorted(fciFact._fact_ids) == sorted(['FcWwnInitiatorFactCollector'])


# Generated at 2022-06-22 23:49:22.832361
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method FcWwnInitiatorFactCollector.collect().
    The method is called without argument.
    """

    # Parameters
    # The method is called without argument.
    # Return value
    # The return value is not checked.
    # The return value is a dictionary.

    import sys
    import os
    import platform

    class TestModule(object):
        """
        Class that implements a dummy AnsibleModule.
        """
        def __init__(self, name):
            # initialize the module
            self.name = name
            self.argument_spec = {}
            self.params = {}

        def fail_json(self, msg=None, **kwargs):
            """
            Fail json method.
            """
            raise Exception(msg)


# Generated at 2022-06-22 23:49:27.836822
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    fc_facts = FcWwnInitiatorFactCollector()
    collected_facts = fc_facts.collect()
    assert collected_facts['fibre_channel_wwn'] == ['10000090fa1658de']

# Generated at 2022-06-22 23:49:33.607518
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector

    FcWwnInitiatorFactCollector = collector.get_collector('fibre_channel_wwn')
    facts = FcWwnInitiatorFactCollector.collect()
    assert facts == {'fibre_channel_wwn': ['21000014ff52a9bb']}

    with patch.object(FcWwnInitiatorFactCollector, 'collect') as mock_collect:
        FcWwnInitiatorFactCollector.collect_device = False
        FcWwnInitiatorFactCollector.collect()
        mock_collect.assert_not_called()

# Generated at 2022-06-22 23:49:36.585123
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
	fibre_channel_wwn = FcWwnInitiatorFactCollector()
	print("name: %s" % fibre_channel_wwn.name)


# Generated at 2022-06-22 23:49:38.760551
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    print(fact_collector.name)

# Generated at 2022-06-22 23:49:42.183966
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.collector
    fci = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in fci.collect()

# Generated at 2022-06-22 23:49:46.022656
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is not None
    assert fc.collect.__doc__ is not None

# Generated at 2022-06-22 23:49:47.234319
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:58.842045
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleBase
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector

    class TestModule(ModuleBase):
        pass

    # setup test
    mm = TestModule(argument_spec={}, supports_check_mode=False)
    mc = FcWwnInitiatorFactCollector(module=mm)

    # execute
    fc_facts = mc.collect()

    # check results
    assert fc_facts['fibre_channel_wwn']

if __name__ == '__main__':
    # run unit tests
    test_FcWwnInitiatorFactCollector_collect()
    sys.exit(0)

# Generated at 2022-06-22 23:50:11.456745
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    # Check Linux
    if sys.platform.startswith('linux'):
        sys_class_file = "fchost0_port_name"
        test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
        # Prepare expected result
        fc_facts['fibre_channel_wwn'].append(sys_class_file.rstrip()[2:])
        # Call method collect of the class FcWwnInitiatorFactCollector
        result = test_FcWwnInitiatorFactCollector.collect(collected_facts=None)
        # Check if both results are equal
        assert result == fc_facts

# Generated at 2022-06-22 23:50:14.614440
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_testobj = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_testobj.collect() != False

# Generated at 2022-06-22 23:50:27.711240
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys

    # data to emulate the return values of module functions
    _sys_platform = 'linux'

    # stub module object to pass in to the FcWwnInitiatorFactCollector.collect method
    class StubModule(object):
        def __init__(self, platform):
            self.sys_platform = platform

        @property
        def platform(self):
            return self.sys_platform

        @platform.setter
        def platform(self, value):
            self.sys_platform = value

        def get_bin_path(self, executable, opt_dirs=[], required=False):
            # ioscan and fcmsutil are only available on hp-ux
            if executable == 'ioscan':
                return '/usr/sbin/ioscan'

# Generated at 2022-06-22 23:50:30.630147
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:33.381311
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert isinstance(x, FcWwnInitiatorFactCollector)


# Generated at 2022-06-22 23:50:39.921151
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn is not None
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert fc_wwn._fact_ids == set()
    assert hasattr(fc_wwn, 'collect')

# Generated at 2022-06-22 23:50:42.563282
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    col = FcWwnInitiatorFactCollector()
    facts = col.collect(None, None)

    assert type(facts['fibre_channel_wwn']) is list

# Generated at 2022-06-22 23:50:51.826138
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Test case 1
    """
    Test case for aix platform
    """
    if sys.platform.startswith('aix'):
        from ansible.module_utils.facts import collector
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts.collector import Collector
        from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
        import mock


# Generated at 2022-06-22 23:50:55.515573
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:01.056718
# Unit test for constructor of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:51:03.707196
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:51:15.797717
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect
    """
    import platform

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.test.unit.collectors.commands_test.test_software_raid_fact_collector import TestSoftwareRaidFactCollector

    """
    TBD:
    test results depend on the current hardware, therefore
    test results are only verified if they are empty
    """
    class_ = FcWwnInitiatorFactCollector
    class_inst = class_()
    class_inst.collect()

    if not platform.system().lower() in ('sunos', 'aix', 'hp-ux'):
        if len(class_inst.fact_results) == 0:
            assert True
        else:
            assert False

# Generated at 2022-06-22 23:51:16.895939
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:51:29.371487
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This unit test will test the method collect of class FcWwnInitiatorFactCollector
    and will check if the returned facts are the ones we expect.
    """
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    class MyModule(object):
        def __init__(self):
            pass

        def run_command(self, cmd):
            output = ''

# Generated at 2022-06-22 23:51:35.358421
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    util_obj = FcWwnInitiatorFactCollector()
    assert util_obj.name == 'fibre_channel_wwn', "Failed to construct object with correct values: %s" % util_obj.name
    assert util_obj._fact_ids == set(), "Failed to construct object with correct values: %s" % util_obj._fact_ids

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:51:42.012737
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn', 'Expected name "fibre_channel_wwn"'
    assert FcWwnInitiatorFactCollector._fact_ids == set(), 'Expected empty fact IDs set'
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set), 'Expected fact IDs to be of type set'
    assert isinstance(FcWwnInitiatorFactCollector.name, str), 'Expected name to be of type str'
    assert isinstance(FcWwnInitiatorFactCollector, object), 'Expected class to be of type object'


# Generated at 2022-06-22 23:51:44.355806
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = sys.modules[__name__].FcWwnInitiatorFactCollector
    fcwwn = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in fcwwn.collect()

# Generated at 2022-06-22 23:51:51.273647
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform

    module = AnsibleModuleMock(
        platform=platform.system(),
        lsdev_out='',
        lscfg_out='',
        fcinfo_out='',
        ioscan_out='',
        fcmsutil_out=''
    )
    fc = FcWwnInitiatorFactCollector()
    data = fc.collect(module)

    assert data.get('fibre_channel_wwn', []) is not None

# Generated at 2022-06-22 23:52:03.158822
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector

    FcWwnInitiatorFactCollector._collect_linux() is tested
    """

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    # Mock object for module
    MockedModule = MagicMock()

    # Mock class for BaseFactCollector
    MockedBaseFactCollector = MagicMock(return_value=MockedModule)

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []


# Generated at 2022-06-22 23:52:07.362353
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == {'fibre_channel_wwn'}

# Generated at 2022-06-22 23:52:12.242277
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Create object
    obj = FcWwnInitiatorFactCollector()
    # Test the name property
    assert obj.name == 'fibre_channel_wwn'
    # Test the _fact_ids property
    assert obj._fact_ids == set()

# Generated at 2022-06-22 23:52:20.859388
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, ('HBA Port WWN: 10000090fa1658de',), '')
    mock_module.get_bin_path.return_value = True
    mock_module.params = {}

    fc_facts = FcWwnInitiatorFactCollector()
    collected_facts = {}
    fc_facts.collect(mock_module, collected_facts)

    assert collected_facts['fibre_channel_wwn'] == ['10000090fa1658de']

# Generated at 2022-06-22 23:52:26.404553
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Checks the constructor of the class FcWwnInitiatorFactCollector
    """
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:52:28.164952
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    :return:
    """
    module = sys.modules["__main__"]
    test = FcWwnInitiatorFactCollector()
    import pprint
    pprint.pprint(test.collect(module))

# Generated at 2022-06-22 23:52:29.624355
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:52:42.202794
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import platform

    sys.path.insert(0, '../../')

    from ansible.module_utils.facts import Namespace, ModuleBase

    def run_module(*args, **kwargs):
        local_args = dict(
            kwargs,
            argument_spec=dict(),
            supports_check_mode=False,
        )
        module = ModuleBase(**local_args)
        module.exit_json = lambda **kwargs: kwargs
        return module.run_command(*args, **kwargs)

    class TestModule(object):
        """
        Fake version of module_utils.facts.ModuleBase
        """
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-22 23:52:49.523551
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a instance of FcWwnInitiatorFactCollector
    test_collector = FcWwnInitiatorFactCollector()
    # call the collect method to get fc initiator WWN facts
    result = test_collector.collect()
    assert isinstance(result, dict)
    assert isinstance(result['fibre_channel_wwn'], list)
    assert result['fibre_channel_wwn']


# Generated at 2022-06-22 23:52:53.350980
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for class FcWwnInitiatorFactCollector"""
    import platform
    import copy

    this_platform = platform.system().lower()

    # class TestModule:
    class TestModule:
        """
        Test class for module_utils.basic.AnsibleModule (no init method)
        """
        def get_bin_path(self, executable, opt_dirs=[]):
            """
            stub method for AnsibleModule.get_bin_path
            """
            return True

        def run_command(self, cmd, check_rc=True):
            """
            stub method for AnsibleModule.run_command
            """
            return (0, '', '')

    test_module = TestModule
    test_module.run_command = TestModule.run_command
    test_module.get_bin_

# Generated at 2022-06-22 23:52:56.509852
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert 'fibre_channel' in obj.valid_choices
    assert 'fc' in obj.valid_choices

# Generated at 2022-06-22 23:53:06.107044
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # set up some test data
    class mock_module(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, cmd, opt_dirs=()):
            for dir in opt_dirs:
                if cmd == 'fcmsutil' and dir == '/opt/fcms/bin':
                    return "/opt/fcms/bin/fcmsutil"
            return None

        def run_command(self, cmd):
            if cmd == "fcinfo hba-port":
                return 0, "HBA Port WWN: 10000090fa1658de", ""

# Generated at 2022-06-22 23:53:12.995954
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == {'fibre_channel_wwn'}
    assert fc_facts.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:53:13.869865
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass

# Generated at 2022-06-22 23:53:20.562841
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts.collector import MockFile
    from ansible.module_utils.facts.collector import AnsibleCmd
    from ansible.module_utils.facts.collector import AnsibleCmdResult

    module = MockModule()
    cmd = AnsibleCmd(module)
    # return value of module.get_bin_path
    bin_path = '/usr/bin/'
    module.get_bin_path_ans = [bin_path] * 2
    # return value of module.run_command
    rc = 0
    out = 'hba0: Class=FCP A N PortHandle=0x000100 N Port WWN=50060b0000c278eb A Port WWN=50060b0000c278eb'
    err = ''

# Generated at 2022-06-22 23:53:29.484916
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    # instantiate the class
    fc_collector = FcWwnInitiatorFactCollector()

    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn', "FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'"
    assert fc_collector.name == 'fibre_channel_wwn', "fc_collector.name == 'fibre_channel_wwn'"

    # test collect method
    fc_collector.collect()

# Generated at 2022-06-22 23:53:31.920158
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector


# Generated at 2022-06-22 23:53:40.504095
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    For unit tests, we are using the Mock class.
    """
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    fc_wwn_initiator_collector = FcWwnInitiatorFactCollector()

    # Mocking module utility to run command
    # ansible.module_utils.facts.utils.get_file_lines
    def mock_get_file_lines(filename):
        file_contents = (
            "0x21000014ff52a9bb\n"
            "0x21000014ff52a9bc\n"
            "0x21000014ff52a9bd\n")
        return file_contents.splitlines

# Generated at 2022-06-22 23:53:47.893311
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Check if constructor of class FcWwnInitiatorFactCollector behaves as expected.
    """
    # instantiate a instance of class FcWwnInitiatorFactCollector, should not fail
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    # call collect method, should not fail (unit test implementation)
    assert fc_fact_collector.collect() == dict(fibre_channel_wwn=['2200001B32AE3084'])



# Generated at 2022-06-22 23:53:51.320325
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() is not None

# Generated at 2022-06-22 23:53:52.890688
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:53:54.598872
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    ansible_facts = {}
    collector.collect(ansible_facts=ansible_facts)
    assert 'fibre_channel_wwn' in ansible_facts

# Generated at 2022-06-22 23:54:05.058894
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Check if dynamic facts about fibre channel WWN initiator are
    collected
    """

    # Mock a module
    mock_module = MagicMock(name='module')
    mock_module.run_command.return_value = (
        0, 'HBA Port WWN: 10000090fa1658de', 'error string')

    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(module=mock_module, collected_facts={})
    assert 'fibre_channel_wwn' in facts
    assert facts['fibre_channel_wwn'] == ['10000090fa1658de']

# Generated at 2022-06-22 23:54:07.689048
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()


# Generated at 2022-06-22 23:54:12.891820
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn = FcWwnInitiatorFactCollector()
    collected_facts = {}
    fc_wwn.collect(module=None, collected_facts=collected_facts)
    facts = collected_facts['ansible_facts']
    assert 'fibre_channel_wwn' in facts
    assert facts['fibre_channel_wwn'] is not None

# Generated at 2022-06-22 23:54:14.589263
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:27.536170
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Run a unit test of method collect of class FcWwnInitiatorFactCollector

    :param module_patcher is a built-in helper function to do automated mocking
    """
    import ansible.module_utils.facts.collector

    with ansible.module_utils.facts.collector.patched_module('os.path') as mock_os_path, ansible.module_utils.facts.collector.patched_module('os') as mock_os:

        mock_os_path.exists.return_value = True
        mock_os.name = 'posix'
        mock_os.path.exists.return_value = True
        mock_os.path.isdir.return_value = True
        mock_os.path.isfile.return_value = True

        # test of `fcinfo h

# Generated at 2022-06-22 23:54:28.758710
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:54:38.676849
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Context
    test_collector = FcWwnInitiatorFactCollector()
    test_context = Context(None)
    test_result = test_collector.collect(None, None)
    assert isinstance(test_result, dict)
    assert 'fibre_channel_wwn' in test_result.keys()
    assert isinstance(test_result['fibre_channel_wwn'], list)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()
    print('unittest ok')

# Generated at 2022-06-22 23:54:41.859695
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    coll = FcWwnInitiatorFactCollector()
    assert coll.name == 'fibre_channel_wwn'
    assert coll._fact_ids == set()


# Generated at 2022-06-22 23:54:54.620861
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a fake module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []
            self.run_command_results = []
            self.get_bin_path_results = []

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.get_bin_path_results.pop(0)

        def run_command(self, command):
            self.run_command_calls.append(command)
            res = self.run_command_results.pop(0)
            return res

    # create mock module with stubbed commands
    module = MockModule()
    # prepare lscfg output

# Generated at 2022-06-22 23:55:04.181600
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    hostvars = {
        'ansible_facts': {
        },
    }
    module = type('test', (object,), {'params': {}, 'run_command': run_command})
    result = FcWwnInitiatorFactCollector(module).collect(module, hostvars)
    assert 'fibre_channel_wwn' in result
    assert len(result['fibre_channel_wwn']) > 0
    assert result['fibre_channel_wwn'][0] == '21000014FF52A9BB'

# Fake run_command method for unit tests on module FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:55:15.689174
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    module = AnsibleModuleMock()

    Collector.add_callback(FcWwnInitiatorFactCollector.name, get_collector_instance)
    facts = Collector.get_facts(module)

    # FIXME: find a way to get this method also tested on non linux system
    if sys.platform.startswith('linux'):
        assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-22 23:55:27.912253
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Tested on Solaris 11.3 with two FC HBAs connected to a FC switch
    # Currently, this test is only executed on Solaris 11.3
    if sys.platform.startswith('sunos'):
        import ansible.module_utils.facts.collector
        import ansible.module_utils.facts.processor
        import ansible.module_utils.facts.hardware
        import ansible.module_utils.facts.system
        import ansible.module_utils.facts.distribution
        import ansible.module_utils.facts.virtual
        class MockModule:
            __ansible_module__ = 'test'

            def __init__(self):
                self._bin_path = {}
                self.params = {}
                self.fail_json = None
                self.run_command = None


# Generated at 2022-06-22 23:55:30.750017
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc,BaseFactCollector)

# Generated at 2022-06-22 23:55:41.534579
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils.facts import callback
    from ansible.module_utils._text import to_bytes

    FcWwnInitiatorFactCollector.name = 'test'
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    c = FcWwnInitiatorFactCollector()
    result = c.collect()
    assert isinstance(result, dict)
    assert result == { 'fibre_channel_wwn': ['21000014ff52a9bb'] }


# Generated at 2022-06-22 23:55:44.070738
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts is not None