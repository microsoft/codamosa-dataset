

# Generated at 2022-06-22 23:45:56.364716
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import mock
    import json
    import sys

    def test_linux():
        ''' Test on linux '''
        os_platform = 'linux' # override the os_platform
        fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
        # for linux, call the collect method
        facts = fc_wwn_fact_collector.collect(module=None)
        # check if the module_utils method exists
        assert 'facts.utils.get_file_lines' in sys.modules['ansible.module_utils.facts.utils'].__dict__
        assert 'ansible.module_utils.facts.collector.BaseFactCollector' in sys.modules['ansible.module_utils.facts.collector'].__dict__
        # check if facts dict is returned and contains

# Generated at 2022-06-22 23:45:59.909735
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    results = FcWwnInitiatorFactCollector()
    assert results.name == 'fibre_channel_wwn'
    assert results._fact_ids == set()


# Generated at 2022-06-22 23:46:02.375313
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    # this will raise an exception and fail if the constructor does not work properly
    str(f)


# Generated at 2022-06-22 23:46:05.768731
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    assert collector.collect() == {}

    # TODO: Create a test dict with known values and run a test on it

# Generated at 2022-06-22 23:46:08.231882
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO
    # This is a placeholder for a real unit test. The
    # test will be a mix of unit test and the unittest framework
    assert True

# Generated at 2022-06-22 23:46:20.574792
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import unittest
    import os

    class ModuleMock(object):
        def run_command(self, command):
            return 0, "0x21000014ff52a9bb", ""

        def get_bin_path(self, name):
            return os.path.join(
                ".",
                "fixtures",
                "ansible_facts",
                "fibre_channel_wwn",
                name
            )

    module = ModuleMock()
    collected_facts = {}
    fact_collector = FcWwnInitiatorFactCollector()

    # On Linux, collect output is simply the content of
    # /sys/class/fc_host/*/port_name

# Generated at 2022-06-22 23:46:25.343041
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Unit test for method collect of class FcWwnInitiatorFactCollector
    '''
    collector = FcWwnInitiatorFactCollector()
    assert collector.collect() == {}

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:46:27.529777
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:29.866658
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:42.184067
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # define mock classes / objects
    class MockModule:
        @staticmethod
        def get_bin_path(name, opt_dirs=None):
            if name=='ioscan':
                return '/sbin/ioscan'
            if name=='fcmsutil':
                return '/opt/fcms/bin/fcmsutil'

# Generated at 2022-06-22 23:46:46.486211
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:50.047110
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = Mock()
    fact_collector = FcWwnInitiatorFactCollector(module=module_mock)
    facts = fact_collector.collect()
    print("facts: %s" % facts)


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:46:52.004862
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:55.894111
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test: constructor of class FcWwnInitiatorFactCollector
    """
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj.collect() is None

# Generated at 2022-06-22 23:46:58.464559
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None


# Generated at 2022-06-22 23:46:59.540474
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # the actual test is in test/unit/module_utils/facts/collector/fibre_channel_wwn.py

    pass


# Generated at 2022-06-22 23:47:03.558606
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert len(fcwwn._fact_ids) == 0

# Generated at 2022-06-22 23:47:16.636941
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.utils import mock
    from ansible.module_utils.facts.collector import Collector

    a = mock.MagicMock(name='a')
    a.run_command = mock.MagicMock(return_value=(0, 'mock_output', ''))

    def get_bin_path(name, opt_dirs=[]):
        if name == 'fcinfo':
            return '/sbin/fcinfo'
        elif name == 'ioscan':
            return '/sbin/ioscan'
        elif name == 'fcmsutil':
            return '/opt/fcms/bin/fcmsutil'
        elif name == 'prtconf':
            return '/usr/sbin/prtconf'

# Generated at 2022-06-22 23:47:19.246203
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method FcWwnInitiatorFactCollector.collect(module)
    """
    # arrange
    TEST_COLLECTED_FACTS = {}
    TEST_MODULE = {}

    # act
    collector = FcWwnInitiatorFactCollector()
    fc_facts = collector.collect(module=TEST_MODULE)

    # assert
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:47:20.763920
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    res = fc.collect()
    assert 'fibre_channel_wwn' in res

# Generated at 2022-06-22 23:47:30.886861
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:47:38.396595
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # set up the object that we want to test
    fc = FcWwnInitiatorFactCollector()
    fc.name = 'fibre_channel_wwn'
    # test that the _fact_ids has the expected value (=None)
    assert fc._fact_ids is None

    # test that the name property has the expected value
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:44.403623
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import tempfile
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    if platform.system() == 'Linux':
        os.environ['TEST_SYSTEM'] = 'Linux'
        file_path = tempfile.mkdtemp()
        file_path_wwn_1 = file_path + '/port_name_1'
        file_path_wwn_2 = file_path + '/port_name_2'
        with open(file_path_wwn_1, 'w') as f:
            f.write('0x21000014ff52a9bb')
        with open(file_path_wwn_2, 'w') as f:
            f.write('0x21000014ff52a9cc')

# Generated at 2022-06-22 23:47:46.420343
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:47:53.925789
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # test for fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == "fibre_channel_wwn"
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-22 23:48:01.431077
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
        assert fc_wwn_initiator_fact_collector.name == "fibre_channel_wwn"
    except Exception:
        print("Error: failed to instantiate class FcWwnInitiatorFactCollector")


if __name__ == '__main__':
  test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:04.097898
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    res = collector.collect()
    assert (res == {'fibre_channel_wwn': []})

# Generated at 2022-06-22 23:48:16.055287
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    class AnsibleModule(object):

        def __init__(self, argument_spec, supports_check_mode=True):
            self.argument_spec = argument_spec
            self.params = {}
            self.check_mode = False

        def log(self, msg):
            pass

        def run_command(self, args, check_rc=True):
            if args.startswith('fcinfo'):
                return (0, 'HBA Port WWN: 0x21000014ff52a9bb\n', '')


# Generated at 2022-06-22 23:48:21.108936
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:48:24.464814
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test function to verify that we do no error out when we can't find
    any facts on the system
    """
    collector_facts = FcWwnInitiatorFactCollector()
    fact_results = collector_facts.collect()
    assert fact_results.get('fibre_channel_wwn') is not None

# Generated at 2022-06-22 23:48:37.730336
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class Module:

        def __init__(self):
            pass

        def get_bin_path(self, cmd):
            return cmd

    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.exit_json = None

        def run_command(self, cmd):
            return 0, "wwn", None

    fc_wwn_fc = FcWwnInitiatorFactCollector()
    module = AnsibleModule()
    fs_facts = fc_wwn_fc.collect(module=module, collected_facts=None)
    assert 'fibre_channel_wwn' in fs_facts
    assert isinstance(fs_facts['fibre_channel_wwn'], list)
    assert fs_facts['fibre_channel_wwn'][0]

# Generated at 2022-06-22 23:48:41.529937
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    # get facts
    collected_facts = FactsCollector().collect(module=None, collected_facts=None)
    # Some of the facts were collected by FcWwnInitiatorFactCollector.
    assert 'fibre_channel_wwn' in collected_facts

# Generated at 2022-06-22 23:48:44.403580
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:45.665101
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:52.927301
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import FactsCollector

    def get_bin_path(name):
        return name

    fc_class_inst = FcWwnInitiatorFactCollector()
    facts_inst = FactsCollector()
    fc_class_inst.collect(module=None, collected_facts=facts_inst.collect())
    assert facts_inst.collect() != ''

# Generated at 2022-06-22 23:49:06.468424
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_lines

    class FakeModule(object):
        def __init__(self, param):
            self.params = param

        def get_bin_path(self, executable, opt_dirs=None):
            pass

        def run_command(self, executable):
            pass

    def run_command(executable):
        if executable == "ioscan -fnC FC":
            return (0, "/dev/fcd0 Class I    Mass Storage ", "")
        if executable == "fcmsutil /dev/fcd0":
            return

# Generated at 2022-06-22 23:49:08.101203
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ Unit test for constructor of class FcWwnInitiatorFactCollector """
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:49:10.829695
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = sys.modules['ansible.module_utils.facts.system.fibre_channel_wwn_initiator']
    result = FcWwnInitiatorFactCollector.collect(test_module)
    assert result == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:49:13.792093
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert isinstance (x, FcWwnInitiatorFactCollector)


# Generated at 2022-06-22 23:49:17.928999
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn', "FcWwnInitiatorFactCollector.name is wrong"

# Generated at 2022-06-22 23:49:29.336761
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # import builtins module for mocking input to this module and running unittest
    if sys.version_info[0] > 2:
        import builtins  # pylint: disable=redefined-builtin
    else:
        import __builtin__ as builtins
    # import ansible module which already has a mocked AnsibleModule class to do unit testing
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.collector import FactsCollector

    # create a mocked FactCollector object by using the type(...) constructor
    # and passing the mocked AnsibleModule object, FcWwnInitiatorFactCollector object as arguments
    # which will return a object of type FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:49:33.705608
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test for constructor of class FcWwnInitiatorFactCollector"""
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:39.080058
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts.collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert len(fc_facts['fibre_channel_wwn']) > 0
    assert fc_facts['fibre_channel_wwn'][0]

# Generated at 2022-06-22 23:49:42.084275
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_fc = FcWwnInitiatorFactCollector()
    assert test_fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:49:44.837647
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:49:54.768203
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    m = mock.mock_open(read_data='0x21000014ff52a9bb')

    with mock.patch.object(sys, 'platform', 'linux'):
        with mock.patch.object(glob, 'iglob', return_value=['/sys/class/fc_host/*/port_name']):
            with mock.patch.object(__builtin__, 'open', m, create=True):
                fct = FcWwnInitiatorFactCollector()
                result = fct.collect()

    assert result == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-22 23:50:07.531490
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    This test is intended to be run only on the platform,
    which is detected as Linux.
    """
    # assume sys.platform is Linux
    from ansible.module_utils.facts.collectors.other.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.basic import AnsibleModule
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    module = AnsibleModule({})
    facts = {}
    res = fc.collect(module, facts)

# Generated at 2022-06-22 23:50:09.311302
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # class constructor should instantiate without error
    fcwwn = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:19.456471
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # test with empty dictionaries
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect({}, {})
    assert result == {'fibre_channel_wwn': []}

    # test with a single WWN
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect({}, {'ansible_facts': {'fibre_channel_wwn': ['10000000c973a601']}})
    assert result == {'ansible_facts': {'fibre_channel_wwn': ['10000000c973a601']}}

# Generated at 2022-06-22 23:50:31.706011
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method `collect` of class `FcWwnInitiatorFactCollector`
    """
    from ansible.module_utils.facts.collector import BaseFactCollector

    class AnsibleModule:
        def run_command(self, cmd):
            """
            Test method run_command of module AnsibleModule.
            """
            if cmd == "fcinfo hba-port":
                """
                Test on Solaris 10.
                """

# Generated at 2022-06-22 23:50:43.622564
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector._platform = 'linux'
    FcWwnInitiatorFactCollector._module = 'ansible.module_utils.facts.collectors.fibre_channel_wwn.FcWwnInitiatorFactCollector'
    collector = FcWwnInitiatorFactCollector()
    # example output:
    # {'fibre_channel_wwn': ['210000edff4324a4', '100000051f1f4c70']}
    fibres = collector.collect()
    assert fibres == {"fibre_channel_wwn": [u"210000edff4324a4", u"100000051f1f4c70"]}


# Generated at 2022-06-22 23:50:52.476762
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    if sys.version_info[0] > 2:
        # for python3
        import io
        import sys

        class StringIO(io.StringIO):
            def write(self, s):
                if isinstance(s, str):
                    s = s.encode('utf-8')
                io.StringIO.write(self, s)

        class BytesIO(io.BytesIO):
            def getvalue(self):
                return self.getbuffer().tobytes()

        class NativeStringIO(BytesIO):
            def write(self, str):
                super(NativeStringIO, self).write(to_bytes(str, encoding=sys.getfilesystemencoding()))
   

# Generated at 2022-06-22 23:51:01.056805
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import get_collector_instance
    fact_collector = get_collector_instance(FcWwnInitiatorFactCollector)
    if fact_collector:
        facts = fact_collector.collect()
        assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-22 23:51:03.003179
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert len(fcwwn.collect()) > 0

# Generated at 2022-06-22 23:51:05.825078
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:51:08.778354
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert isinstance(obj.name, str)
    assert isinstance(obj._fact_ids, set)

# Generated at 2022-06-22 23:51:19.049264
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorModule
    from ansible.module_utils.facts.utils import Module
    from ansible.module_utils.facts.utils import is_executable
    import os

    module = Module()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x, opt_dirs: os.path.join(os.path.dirname(__file__), x)
    # pretend that is available

# Generated at 2022-06-22 23:51:21.428385
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert (FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn')


# Generated at 2022-06-22 23:51:31.426529
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class
    FcWwnInitiatorFactCollector
    """

    # create FcWwnInitiatorFactCollector object
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()

    # create mock module object
    module = AnsibleModuleMock()

    # call collect method
    fc_wwn_fact_collector.collect(module)

    # assert contents of fc_wwn facts
    assert fc_wwn_fact_collector.fibre_channel_wwn == ['21000014ff52a9bb']


# Generated at 2022-06-22 23:51:32.387387
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fci = FcWwnInitiatorFactCollector()
    assert fci.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:40.626766
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Testcase for class FcWwnInitiatorFactCollector: method collect
    """
    # testdata for FC-WWN-FactCollector.collect
    # testdata:
    # [0] input platform
    # [1] mocked return_value of glob.glob('/sys/class/fc_host/*/port_name')
    # [2] expected output

# Generated at 2022-06-22 23:51:45.674645
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test case to check constructor of class FcWwnInitiatorFactCollector
    """

    fc_wwn_fact_module = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_module.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_wwn_fact_module._fact_ids



# Generated at 2022-06-22 23:51:58.511440
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import MemoryCollector
    from ansible.module_utils.facts import helpers
    from ansible.module_utils.basic import AnsibleModule

    import sys
    import glob

    if sys.version_info.major == 2:
        from mock import patch, mock_open, MagicMock
        import __builtin__ as builtins
    elif sys.version_info.major == 3:
        from unittest.mock import patch, mock_open, MagicMock
        import builtins
    else:
        raise Exception

# Generated at 2022-06-22 23:52:04.953755
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test for constructor of class FcWwnInitiatorFactCollector"""

    collector = FcWwnInitiatorFactCollector()
    # test name of fact
    name = collector.name
    assert name == 'fibre_channel_wwn'
    # test name of fact file
    fact_file = collector.fact_file
    assert fact_file == 'ansible_fibre_channel_wwn'
    # test cache
    cache = collector.cache
    assert cache == '/tmp/ansible_fibre_channel_wwn_facts'

# Generated at 2022-06-22 23:52:11.927950
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    ff = FcWwnInitiatorFactCollector()
    test_facts = {}
    ff.collect(collected_facts=test_facts)
    assert 'fibre_channel_wwn' in test_facts
    for wwn in test_facts['fibre_channel_wwn']:
        assert len(wwn) > 0 and len(wwn) == 16


# Generated at 2022-06-22 23:52:20.585652
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Get the test object
    """
    test_object = FcWwnInitiatorFactCollector()

    """
    Get the expected result
    """
    expected_result = {'fibre_channel_wwn': ['50:06:0b:00:00:6a:95:61']}

    """
    Run the collect method
    """
    result = test_object.collect()

    """
    Asserts the result
    """
    assert result == expected_result, "Expected: %s, Got: %s" % (expected_result, result)

# Generated at 2022-06-22 23:52:25.589682
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    fcinst = FcWwnInitiatorFactCollector()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:52:26.896429
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.__doc__

# Generated at 2022-06-22 23:52:38.888770
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_collector = FcWwnInitiatorFactCollector(None, None)
    print("Testing %s collect" % test_collector.name)
    # check linux case
    if sys.platform.startswith('linux'):
        nwwn = int(len(test_collector.collect()["fibre_channel_wwn"]))
        assert(nwwn > 0)
        print(" - number of fibre_channel_wwn: %d" % nwwn)
    elif sys.platform.startswith('aix'):
        nwwn = int(len(test_collector.collect()["fibre_channel_wwn"]))
        assert(nwwn > 0)
        print(" - number of fibre_channel_wwn: %d" % nwwn)

# Generated at 2022-06-22 23:52:51.449000
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils.linux import LinuxFileSystem

    fact_collector = FcWwnInitiatorFactCollector()

    fs = LinuxFileSystem(module=None)

    mock_module = type('module', (object,), {
        'get_bin_path': fs.which,
        'run_command': fs.run_command
    })

    facts = {'linux': {'file_system': fs}}
    collected_facts = Collector.collect(fact_collector, facts, mock_module)

    # expected collect module output on a Linux system

# Generated at 2022-06-22 23:52:52.846059
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:52:54.388229
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwc = FcWwnInitiatorFactCollector()
    assert fwc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:57.115758
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    print("this is the directory path: %s" % dir_path)
    x = FcWwnInitiatorFactCollector()
    assert x

# Generated at 2022-06-22 23:53:04.504075
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method unit test the method collect of the class FcWwnInitiatorFactCollector
    """
    sys.platform = 'linux'
    collector = FcWwnInitiatorFactCollector()
    facts = {}
    facts['ansible_module_mock'] = None
    facts = collector.collect(facts)
    assert facts['fibre_channel_wwn'] == []

    sys.platform = 'sunos5'
    collector = FcWwnInitiatorFactCollector()
    facts = {}
    facts['ansible_module_mock'] = None
    facts = collector.collect(facts)
    assert facts['fibre_channel_wwn'] == []

    sys.platform = 'linux'
    collector = FcWwnInitiatorFactCollector()
    facts = {}
    facts

# Generated at 2022-06-22 23:53:07.163714
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:19.556226
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()

    assert collector.name == 'fibre_channel_wwn'
    assert not collector._fact_ids

    # Linux
    collector.name = 'test_name'
    collector._fact_ids = set(['test_id'])
    collector._platform = 'Linux'

    collector.collect()

    assert collector.name == 'fibre_channel_wwn'
    assert not collector._fact_ids
    assert collector._platform == 'Linux'

    # Solaris
    collector.name = 'test_name'
    collector._fact_ids = set(['test_id'])
    collector._platform = 'SunOS'

    collector.collect()

    assert collector.name == 'fibre_channel_wwn'
    assert not collector._fact_ids

# Generated at 2022-06-22 23:53:31.822169
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    from collections import namedtuple
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    MockModule = namedtuple('MockModule', ['run_command', 'get_bin_path'])
    mock_module = MockModule(
        run_command=lambda *args, **kwargs: (0, '', ''),
        get_bin_path=lambda x, opt_dirs=[] : None)

    if sys.platform.startswith('linux'):
        fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-22 23:53:33.742038
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_obj = FcWwnInitiatorFactCollector()
    test_obj.collect()

# Generated at 2022-06-22 23:53:45.750762
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for method collect of class FcWwnInitiatorFactCollector """
    import sys
    import os

    if sys.platform.startswith('linux'):
        _file = '/sys/class/fc_host/host0/port_name'
        _path = '/sys/class/fc_host/'
        _file_content = "0x21000014ff52a9bb\n"
        _collected_facts = {}

    if sys.platform.startswith('sunos'):
        _file = '/dev/null'
        _path = '/dev'
        _file_content = "HBA Port WWN: 10000090fa1658de\n"
        _collected_facts = {}

    if sys.platform.startswith('aix'):
        _file = '/dev/null'

# Generated at 2022-06-22 23:53:58.248554
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    if fc_fact_collector.name == 'fibre_channel_wwn':
        print("test_FcWwnInitiatorFactCollector_collect(): name = 'fibre_channel_wwn'")
    else:
        print("test_FcWwnInitiatorFactCollector_collect(): name != 'fibre_channel_wwn'")

    fc_facts = fc_fact_collector.collect()
    if fc_facts:
        for fc_fact in fc_facts['fibre_channel_wwn']:
            print("test_FcWwnInitiatorFactCollector_collect(): fc_facts = " + fc_fact)

# Generated at 2022-06-22 23:54:02.680495
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_fact_collector.collect()

    assert fc_facts['fibre_channel_wwn'], "fibre_channel_wwn is empty"

# Generated at 2022-06-22 23:54:07.576501
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_collector._fact_ids == set()

# Generated at 2022-06-22 23:54:17.276516
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_obj = FcWwnInitiatorFactCollector()
    # Setup mocks
    import sys
    import glob
    _fc_facts = {'fibre_channel_wwn': []}

    def mock_get_file_lines(fcfile):
        return ['0x21000014ff52a9bb']


# Generated at 2022-06-22 23:54:21.625571
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Unit tests for collect method of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:54:33.980843
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector

    Returns:
        False, if the unit test fails

    Raises:
        None
    """

    # create an object of class FcWwnInitiatorFactCollector
    facter = FcWwnInitiatorFactCollector()

    # create a fake module
    class Module(object):
        def __init__(self, params):
            self.params = params
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'fcinfo':
                return '/usr/sbin/fcinfo'
            return None


# Generated at 2022-06-22 23:54:35.875809
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fp = FcWwnInitiatorFactCollector()
    assert fp is not None


# Generated at 2022-06-22 23:54:39.668983
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.valid

# Generated at 2022-06-22 23:54:44.660118
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import collector_registry
    collector_registry.register(FcWwnInitiatorFactCollector)

    # call the constructor and unregister the class
    collector_registry.unregister(FcWwnInitiatorFactCollector)


# Generated at 2022-06-22 23:54:57.836932
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os

    class FcWwnInitiatorModuleMock(object):
        def __init__(self):
            self.name = 'ansible_fibre_channel_wwn'
            self.path = 'ansible/module_utils/facts/fibre_channel/wwn_initiator/'
            self.platform = platform.system().lower()
            self.platform_version = platform.release()

        def get_bin_path(self, cmd, opt_dirs=[]):
            if self.platform == "linux":
                file_name = 'ansible_' + cmd.replace('-', '_') + '_linux_' + self.platform_version

# Generated at 2022-06-22 23:55:02.534088
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock(platform='linux')
    fc_fact_obj = FcWwnInitiatorFactCollector(module=module)
    assert fc_fact_obj.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-22 23:55:08.378442
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector constructor
    """

    fwc = FcWwnInitiatorFactCollector()
    assert fwc
    assert fwc.name == "fibre_channel_wwn"
    assert fwc._fact_ids == set()


# Generated at 2022-06-22 23:55:10.618689
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:16.303537
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    """Unit test for constructor of class FcWwnInitiatorFactCollector."""

    fact = FcWwnInitiatorFactCollector()

    # Test the name of the instance
    assert fact.name == 'fibre_channel_wwn'

    # Test the facts the class is supposed to collect
    assert 'fibre_channel_wwn' in fact.collection_rules

    # Test whether fact_ids is empty
    assert fact._fact_ids == set()


# Generated at 2022-06-22 23:55:21.664836
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    # Instantiate the FcWwnInitiatorFactCollector class
    fcwic_instance = get_collector_instance(FcWwnInitiatorFactCollector)

    # Test that fcwic_instance is an instance of FcWwnInitiatorFactCollector
    assert isinstance(fcwic_instance, FcWwnInitiatorFactCollector)

    # Test that the collect method returns a dictionnary
    assert isinstance(fcwic_instance.collect(), dict)


# Generated at 2022-06-22 23:55:29.828585
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create an instance of class FcWwnInitiatorFactCollector
    fc_wwn = FcWwnInitiatorFactCollector()
    # verify that isinstance returns True for the instance created for the class
    assert isinstance(fc_wwn, FcWwnInitiatorFactCollector)
    # verify that the name of the instance matches expectations
    assert fc_wwn.name == 'fibre_channel_wwn'
    # verify that the instance implements the required method collect
    assert callable(getattr(fc_wwn, 'collect', None))
    # verify that the instance implements the required method _fact_ids
    assert getattr(fc_wwn, '_fact_ids')

# Generated at 2022-06-22 23:55:41.434254
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    import mock
    import glob

    # create mock object for module
    module = mock.MagicMock()
    module.get_bin_path = mock.MagicMock(return_value='/usr/bin/fcinfo')
    module.run_command = mock.MagicMock(return_value=(0, '', ''))
    # create mock object for collected_facts
    collected_facts = mock.MagicMock()


# Generated at 2022-06-22 23:55:51.526709
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mock_module = FakeAnsibleModule()
    mock_module.run_command.return_value = (0, "", "")
    mock_module.get_bin_path.return_value = '/bin/fcinfo'
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()

    fcinfo_output = '''
    HBA Port WWN: 10000090fa1658de
    HBA Port WWN: 10000090fa1658df
    '''
    mock_module.run_command.return_value = (0, fcinfo_output, "")

    fc_facts = fcwwn_fact_collector.collect(module=mock_module, collected_facts=None)