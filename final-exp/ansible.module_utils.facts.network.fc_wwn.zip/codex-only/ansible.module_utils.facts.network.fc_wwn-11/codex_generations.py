

# Generated at 2022-06-22 23:45:46.511630
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    FcWwnInitiatorFactCollector.collect(module)

# Generated at 2022-06-22 23:45:59.388331
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):

        def __init__(self):
            self.params = dict()

        def run_command(self, command_line):
            # command line is as follows:
            #   fcinfo hba-port
            """
                fcinfo hba-port  | grep "Port WWN"
                HBA Port WWN: 10000090fa1658de
            """
            self.command_line = command_line
            if command_line == 'fcinfo hba-port  | grep "Port WWN"':
                return (0, 'HBA Port WWN: 10000090fa1658de', '')
            return (0, '', '')

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'fcinfo':
                return 'fcinfo'


# Generated at 2022-06-22 23:46:02.233436
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'
    assert a._fact_ids == set()
    assert a.collect() == {}

# Generated at 2022-06-22 23:46:03.594355
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:08.450261
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector, FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:46:11.799392
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == obj.name

# Generated at 2022-06-22 23:46:14.615919
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:17.255822
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is not None

# Generated at 2022-06-22 23:46:18.271321
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:28.339258
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for FcWwnInitiatorFactCollector.collect() method."""

    # Import here to avoid cross import dependency
    import ansible.module_utils.facts.collector

    # There is no simple way to test the method collect() of class
    # FcWwnInitiatorFactCollector because it reads files from the file system.
    # In order to test, it is necessary to write test files to a specific
    # directory or to mock these files.
    # Therefore, the test file is empty, but at least it checks if the method
    # collect() is callable.
    fc_facts = ansible.module_utils.facts.collector.collect_fc_wwn_initiator_facts()
    assert isinstance(fc_facts, dict)

# Generated at 2022-06-22 23:46:40.836042
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule:
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr
        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd
        def run_command(self, cmd):
            return (self.rc, self.stdout, self.stderr)

    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
            self.facts = {}
        def exit_json(self, ansible_facts, **kwargs):
            self.facts = ansible_facts

    def get_file_lines(filename):
        if filename == '/sys/class/fc_host/host0/port_name':
            return

# Generated at 2022-06-22 23:46:43.262508
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:45.674551
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:56.200964
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.fibre_channel_wwn import FcWwnInitiatorFactCollector
    fake_module = ModuleFacts(
        module_name='fake_module',
        module_args='',
        module_internal_arguments='',
        module_deprecation=None,
        check_invalid_arguments=False,
        argument_spec={},
        supports_check_mode=True)
    facts_collector = Collector(
        module=fake_module,
        file_extension_modules=[],
        collectors=[FcWwnInitiatorFactCollector])

# Generated at 2022-06-22 23:47:09.321796
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # stub out required modules
    class StubModule(object):
        def __init__(self):
            self.run_command_result = 0, '', ''
            self.run_command_results = []
            self.run_command_results.append(self.run_command_result)

        def run_command(self, command, **kwargs):
            return self.run_command_results.pop(0)

        def get_bin_path(self, name, **kwargs):
            if name == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif name == 'prtconf':
                return '/usr/sbin/prtconf'
            elif name == 'lsdev':
                return '/usr/sbin/lsdev'

# Generated at 2022-06-22 23:47:10.713920
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f != None

# Generated at 2022-06-22 23:47:13.412430
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:47:17.152593
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:47:19.446111
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:20.991146
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert c._fact_ids == set()

# Generated at 2022-06-22 23:47:24.531562
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:47:27.340905
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()
    collector.collect()

# Generated at 2022-06-22 23:47:38.349788
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_collected_facts = set()
    fc_wwn_initiator_collected_facts.add('fibre_channel_wwn')

    # create instance of FcWwnInitiatorFactCollector
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    
    # the collect method has no parameters, so we call it without any
    fc_wwn_initiator_collected_facts = fc_wwn_collector.collect()

    # check if the collect method returned the expected result
    assert fc_wwn_initiator_collected_facts == fc_wwn_initiator_collected_facts

# Generated at 2022-06-22 23:47:40.505703
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()


# Generated at 2022-06-22 23:47:43.115121
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:55.676662
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector.network import NetworkCollector

    ansible_module = AnsibleModule({})
    ansible_module.exit_json = lambda x: x
    network_fact_collector = NetworkCollector()
    fc_fact_collector = FcWwnInitiatorFactCollector()
    input_facts = {}

    # unit test, call collect method of class FcWwnInitiatorFactCollector
    result = fc_fact_collector.collect(ansible_module, input_facts)
    # assert that result['fibre_channel_wwn'] is not empty
    assert(result['fibre_channel_wwn'] != [])

# Generated at 2022-06-22 23:47:58.417593
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert any(fc_facts['fibre_channel_wwn'])

# Generated at 2022-06-22 23:48:01.711150
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:03.958683
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    myObj = FcWwnInitiatorFactCollector()
    assert myObj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:05.051026
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:09.602939
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()
    assert x._platform  # platform var for module utils

# Generated at 2022-06-22 23:48:20.272630
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test instantiating constructor of class FcWwnInitiatorFactCollector."""
    # create collector object
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_collector._fact_ids == set()
    assert fc_wwn_collector._platform == 'Generic'
    assert fc_wwn_collector._required_version == ''
    assert fc_wwn_collector._has_legacy_facts is False
    assert fc_wwn_collector._collect_again is False

# Generated at 2022-06-22 23:48:22.139619
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    FcWwnInitiatorFactCollector.collect(None, module)

# Generated at 2022-06-22 23:48:26.834664
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector._module = None
    data = FcWwnInitiatorFactCollector.collect()
    assert 'fibre_channel_wwn' in data.keys()

# Generated at 2022-06-22 23:48:39.552287
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.six import PY3
    if PY3:
        # PY3: create a mock module class like AnsibleModule
        from unittest.mock import MagicMock
    else:
        # PY2: create a mock module class like AnsibleModule
        from ansible.module_utils.facts.collector.mock import MagicMock
    from ansible.module_utils.facts import collector as facts_collector
    # mock module class
    module = MagicMock()
    setattr(module, 'run_command', run_command)

# Generated at 2022-06-22 23:48:43.894182
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert len(f.name) > 0
    # unit test - is this a class ?
    assert "class" in str(FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:48:49.944219
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    collected_facts = {}
    result_facts = FcWwnInitiatorFactCollector.collect(None, collected_facts)
    assert result_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-22 23:48:55.621412
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Create instance of class FcWwnInitiatorFactCollector
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()

    # Check instance attributes after creation
    assert fc_wwn_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_fact_collector._fact_ids == set([])

# Generated at 2022-06-22 23:49:00.387742
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()


# Generated at 2022-06-22 23:49:09.454944
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    ansible_facts = {}
    test_obj = FcWwnInitiatorFactCollector(ansible_facts)
    assert test_obj.name == 'fibre_channel_wwn'
    assert test_obj.fact_id_prefix == 'ansible_'
    assert test_obj.fact_id_prefix == test_obj.fact_sub_id_prefix
    assert test_obj.fact_id == 'fibre_channel_wwn'
    assert test_obj.fact_id == test_obj.fact_sub_id
    assert test_obj._fact_ids == set()


# Generated at 2022-06-22 23:49:12.536306
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:14.418328
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:26.887018
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create mock module object
    class MockModule(object):
        def run_command(self, command=None, check_rc=False, cwd=None, data=None, binary_data=False, path_prefix=None, environ_update=None, use_unsafe_shell=False, prompt_regex=None):
            class Response(object):
                pass
            response = Response()
            response.rc = 0
            response.stdout = '''HBA Port WWN: 0x21000014ff52a9bb
HBA Port WWN: 0x21000014ff52a9bc'''
            response.stderr = ''
            return (response.rc, response.stdout, response.stderr)


# Generated at 2022-06-22 23:49:31.636717
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.collect() == dict(fibre_channel_wwn=[])

# Generated at 2022-06-22 23:49:36.231407
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.fibre_channel import FcWwnInitiatorFactCollector

    fake_file_lines = '0x21000014ff52a9bb\n0x21000014ff52a9bc\n0x21000014ff52a9bd'

    def collect_fct(self, module=None, collected_facts=None):
        fc_facts = {}
        fc_facts['fibre_channel_wwn'] = []

# Generated at 2022-06-22 23:49:38.869735
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector is not None
    print("%s" % collector)

# Generated at 2022-06-22 23:49:50.693103
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create the class and instantiate an object
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    # create a very simple module for testing
    from ansible.module_utils.facts import ModuleUtilsFacts
    module = ModuleUtilsFacts(module_name='test',
                              module_args={'gather_subset': ['all']})
    result = fc.collect(module=module)
    # check if result is as expected
    assert 'fibre_channel_wwn' in result


if __name__ == '__main__':
    # running this invokes the unit test
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:50:02.951044
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test fixture for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils.facts import FactCollectorCache
    from ansible.module_utils.facts.collector import Cache
    from ansible.module_utils.facts.facts import FactCacheFilter

    cache = FactCollectorCache()
    fw = FcWwnInitiatorFactCollector()
    mock_module = MockModule()
    facts = fw.collect(module=mock_module, collected_facts=None)
    assert 'fibre_channel_wwn' in facts

    # test caching of collector
    cache = Cache([FactCacheFilter(fw)])
    mock_module = MockModule(cache=cache)

    facts = f

# Generated at 2022-06-22 23:50:14.920307
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import JINJA2_GLOBAL_ENV
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network_legacy import NetworkLegacyCollector

    # init the module
    module_init = dict(ANSIBLE_MODULE_ARGS={'gather_subset': '!all,!any,!fibre_channel_wwn'},
                       ANSIBLE_SYSTEM_VERSION='2.2.0.0',
                       ANSIBLE_NOCOWS=1)
    module = AnsibleModule(**module_init)

    # init class
    cwwn = FcWwnInitiatorFactCollector(module)

    # init the class
    n = NetworkCollector

# Generated at 2022-06-22 23:50:17.676797
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:21.884672
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc1 = FcWwnInitiatorFactCollector()
    fc1_name = fc1.name
    assert fc1_name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:50:34.638412
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fw = FcWwnInitiatorFactCollector()
    facts_result = fw.collect()

    # determine if we run on Linux, Solaris, AIX or HP-UX
    platform = sys.platform.split('-')[0]
    if platform == 'linux':
        assert facts_result['fibre_channel_wwn'][0] == '21000014ff52a9bb'
    elif platform == 'sunos':
        assert '10000090fa1658de' in facts_result['fibre_channel_wwn']
    elif platform == 'aix':
        assert facts_result['fibre_channel_wwn'][0] == '10000090FA551509'
    elif platform == 'hp':
        assert '0x50060b00006975ec' in facts_

# Generated at 2022-06-22 23:50:40.666708
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert isinstance(fc_facts._fact_ids, set)
    assert list(fc_facts._fact_ids) == [('fibre_channel_wwn', None)]

# Generated at 2022-06-22 23:50:44.601552
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts import Facts

    # create an instance and collect facts
    lib_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    sys.path.insert(1, lib_path)
    import ansible.module_utils.facts.collector

    module = Mock()
    collector = FcWwnInitiatorFactCollector()
    collected_facts = collector.collect(module=module)
    #assert collected_facts == {'fibre_channel_wwn': ['0x21000014ff52a9bb']}



# Generated at 2022-06-22 23:50:52.834571
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json
    import os
    import tempfile

    content = """
    0x21000014ff52a9bb
    """

    fc_facts = {}
    ansible_module = None
    if sys.platform.startswith('linux'):
        tempdir = tempfile.mkdtemp()
        os.makedirs(tempdir + "/sys/class/fc_host/1/")
        file_handle = open(tempdir + "/sys/class/fc_host/1/port_name", "w+")
        file_handle.write(content)
        file_handle.close()

        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector(module=ansible_module)
        fc_facts = fc_wwn_initiator_fact_

# Generated at 2022-06-22 23:50:56.405140
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    mock_module = type('mock_module', (object,), {})
    mock_module.run_command = builtins.staticmethod(lambda module, cmd: (0, '', ''))
    mock_module.get_bin_path = builtins.staticmethod(lambda name, opt_dirs=[] : '/bin/true')

    # example output from fcinfo hba-port
    mock_module.run_command = builtins.staticmethod(lambda module, cmd:
                                                    (0, "HBA Port WWN: 10000090fa1658de", ''))

    collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:51:00.628612
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = {}
    fact_collector = FcWwnInitiatorFactCollector(facts, None)
    assert fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:51:07.548779
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    def LinuxFcWwnInitiator_mockreturn(self, module=None):
        return [
            '0x21000014ff5a9f98',
            '0x21000014ff5a9f99',
        ]
    BaseFactCollector.collect = LinuxFcWwnInitiator_mockreturn
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts.collect()
    #assert len(fc_facts.collect()) == 2

# Generated at 2022-06-22 23:51:16.895518
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method FcWwnInitiatorFactCollector.collect
    """
    ####
    # System under test
    ####
    sut = FcWwnInitiatorFactCollector()
    ####
    # Test variables
    ####
    ####
    # Test data
    ####
    ####
    # Test code
    ####
    # mock
    fc_facts = {'fibre_channel_wwn': ['0x21000014ff52a9bb']}
    # execute
    result = sut.collect()
    # assert
    assert result == fc_facts

# Generated at 2022-06-22 23:51:26.800685
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import set_module_args
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector

    module = AnsibleModule(argument_spec={})
    set_module_args(dict(gather_subset='!all,!any,fibre_channel_wwn'))

    my_obj = FcWwnInitiatorFactCollector()
    facts = my_obj.collect(module=module)

    assert(len(facts['fibre_channel_wwn']) > 0)

# Generated at 2022-06-22 23:51:31.061921
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_collector.name == 'fibre_channel_wwn'
    assert fcwwn_collector._fact_ids == set()

# Generated at 2022-06-22 23:51:33.846090
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'
    assert result._fact_ids == set()


# Generated at 2022-06-22 23:51:45.675507
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class TestModule():
        @staticmethod
        def run_command(cmd):
            class TestCmd():
                def __init__(self, cmd):
                    self.cmd = cmd
                    self.rc = 0
                    self.stdout = None


# Generated at 2022-06-22 23:51:51.904966
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Create the object
    fc_collector = FcWwnInitiatorFactCollector()

    # Run collect
    fc_facts = fc_collector.collect()

    # Test
    assert type(fc_facts) is dict
    assert 'fibre_channel_wwn' in fc_facts
    assert type(fc_facts['fibre_channel_wwn']) is list

# Generated at 2022-06-22 23:51:56.924821
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Unit test to invoke collect() of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:51:57.964873
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:52:06.133493
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    unit test for FcWwnInitiatorFactCollector.collect()
    """
    from ansible.module_utils.facts.collector import Collector
    # use mocks for Collector for testing purposes
    # https://docs.python.org/3.3/library/unittest.mock-examples.html#patching-objects
    from unittest.mock import Mock, patch

    class CollectorMock(Collector):
        def __init__(self, module, cache=None, collect_subset=None,
                     collector_instance=None, filter_options=None):
            """
            mock the __init__() method of Collector class
            to return the FcWwnInitiatorFactCollector
            """
            self.collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:52:14.694275
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = module.run_command_mock
    module.get_bin_path = module.get_bin_path_mock
    fc_collector = FcWwnInitiatorFactCollector()
    facts = fc_collector.collect(module=module)
    assert(facts['fibre_channel_wwn'] == ['1234567890123456', '0123456789abcdef'])


# Unit test helper class MockAnsibleModule

# Generated at 2022-06-22 23:52:17.759058
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:19.322049
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:52:31.706502
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule():
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out.splitlines()
            self.err = err.splitlines()

        def get_bin_path(self, command, opt_dirs=[]):
            if command == "fcinfo":
                return "/usr/sbin/" + command
            elif command == "ioscan":
                return "/usr/sbin/" + command
            elif command == "fcmsutil":
                return "/opt/fcms/bin/" + command
            else:
                return "/usr/bin/" + command

        def run_command(self, command):
            return self.rc, self.out, self.err

        def fail_json(self, msg, **kwargs):
            pass


# Generated at 2022-06-22 23:52:34.325705
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:52:43.614218
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None


# required module function for importing into ansible
# argument_spec = dict(
#     os_type=dict(default="Linux"),
# )

# module = AnsibleModule(argument_spec=argument_spec)
# fact_collector = FcWwnInitiatorFactCollector()
# facts_dict = fact_collector.collect(module=module)

# module.exit_json(ansible_facts=facts_dict)

# Generated at 2022-06-22 23:52:50.660400
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # create instance of class FcWwnInitiatorFactCollector
    fact_collector = FcWwnInitiatorFactCollector()
    # call method collect of class FcWwnInitiatorFactCollector
    # (no arguments given, no module generated)
    facts = fact_collector.collect()
    # run test
    assert (len(facts['fibre_channel_wwn']) > 0)

# Generated at 2022-06-22 23:52:52.906201
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:53.648447
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    m = FcWwnInitiatorFactCollector()
    assert m is not None

# Generated at 2022-06-22 23:53:02.631231
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    class test_module:
        def __init__(self):
            self.bin_path = '/usr/bin/ansible'
        def get_bin_path(self, cmd, opt_dirs=[]):
            return self.bin_path

    data = []
    data.append("HBA Port WWN: 10000090fa1658de")
    data.append("        Network Address.............10000090FA551509")
    data.append("             N_Port Port World Wide Name = 0x50060b00006975ec")

    class test_exec(object):
        def __init__(self, cmd, data):
            self.cmd = cmd
            self.data = data
            self.rc = 0


# Generated at 2022-06-22 23:53:15.683348
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create dummy module object
    test_object = FcWwnInitiatorFactCollector()
    test_module = object()

    # create test_facts as object
    class test_facts:
        def __init__(self):
            self.ansible_facts = {}

    # create test_module.run_command mock
    class run_command_mock:
        def __init__(self, module, cmd):
            if cmd == 'fcstat':
                self.rc = 0
                self.stdout = 'Device: fcp0 Port WWN: 21000024ffc10bb7 Node WWN: 20000024ffc10bb7 Class: FC  SCSI Target'
                # self.rc = 1
                # self.stdout = ''
                # self.rc = 0
                # self.stdout = 'Unknown command'

# Generated at 2022-06-22 23:53:20.416076
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'
    fact_ids = fact.collect().keys()
    for key in fact.get_fact_ids():
        assert key in fact_ids


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:53:23.859981
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """FcWwnInitiatorFactCollector - constructor test
    """
    fc = FcWwnInitiatorFactCollector()
    assert fc


# Generated at 2022-06-22 23:53:35.388719
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import mock
    import os

    # avoid pytest error: AttributeError: 'module' object has no attribute 'fibre_channel_wwn'
    sys.modules['ansible.module_utils.facts.collector'] = mock.MagicMock()
    import ansible.module_utils.facts.collector as facts_collector

    # load collector
    from ansible.module_utils.facts.plugins.network.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector

    # load module
    from ansible.module_utils.basic import AnsibleModule

    # create dummy module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    # create dummy collector
    base_collector = facts_collector

# Generated at 2022-06-22 23:53:38.908961
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert 'fibre_channel_wwn' in facts
    print(facts)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:53:42.826699
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    objFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector('fibre_channel_wwn')

    assert objFcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:46.593936
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector(None)
    name = obj.name
    assert name == 'fibre_channel_wwn'
    fact_ids = obj._fact_ids
    assert fact_ids is not None

# Generated at 2022-06-22 23:53:59.330136
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # mock module for Ansible
    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, cmd, opt_dirs=None):
            if cmd == 'ioscan':
                return '/bin/ioscan'
    
    # mock module.run_command
    def mock_run_command(self, cmd, check_rc=True, data=None, binary_data=False):
        return (0, '', '')

    MockModule.run_command = mock_run_command

    # instantiate a FcWwnInitiatorFactCollector object
    fcw = FcWwnInitiatorFactCollector()

    # generate facts
    facts = fcw.collect(MockModule())

    # test facts

# Generated at 2022-06-22 23:54:07.847946
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.fact == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector._fact_ids
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)
    assert FcWwnInitiatorFactCollector.collect() == { 'fibre_channel_wwn': [] }

# Generated at 2022-06-22 23:54:15.225159
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test to check the correctness of FcWwnInitiatorFactCollector.collect()
    method.
    """
    fact_collector = FcWwnInitiatorFactCollector()
    platform_mock = 'linux'
    sys.platform = platform_mock
    init_dict = fact_collector.collect()
    assert init_dict['fibre_channel_wwn'] == ['21000014ff52a9bb']
    assert init_dict['ansible_facts']['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-22 23:54:27.812466
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a dummy module object
    class my_module():
        def __init__(self):
            self.run_command = my_run_command

    def my_run_command(self, cmd):
        class my_result():
            def __init__(self):
                self.rc = 0
                self.stdout = ""
                self.stderr = ""
        result = my_result()

# Generated at 2022-06-22 23:54:34.178119
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcic = FcWwnInitiatorFactCollector()
    assert(fcic.name == 'fibre_channel_wwn')
    facts = fcic.collect()
    assert(isinstance(facts, dict))
    assert('fibre_channel_wwn' in facts)
    # at least should collect one WWN
    assert(len(facts['fibre_channel_wwn']) > 0)

# Generated at 2022-06-22 23:54:44.346830
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector
    module = BaseFactCollector()
    fc_initiator = FcWwnInitiatorFactCollector()

    fc_initiator_facts = fc_initiator.collect(module=module)
    assert 'fibre_channel_wwn' in fc_initiator_facts
    assert len(fc_initiator_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:54:56.283293
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import Collector
    mod = types.ModuleType('ansible.module_utils.facts')
    mod.ansible_collector = ansible_collector
    mod.__loader__ = None
    mod.__package__ = 'ansible.module_utils.facts'
    sys.modules['ansible.module_utils.facts'] = mod
    sys.modules['ansible.module_utils.facts.collector'] = Collector
    from ansible.module_utils.facts.linux import FcWwnInitiatorFactCollector
    myfact = FcWwnInitiatorFactCollector()
    print(myfact.collect())


# Generated at 2022-06-22 23:55:01.558350
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fcwwn._fact_ids



# Generated at 2022-06-22 23:55:13.898533
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an instance of a class to be tested
    fcwwn_collector = FcWwnInitiatorFactCollector()

    # Mock module class we use but which may not be available during testing
    class MockModule(object):
        # Skip most of this class since we only want to test one function
        # of the class
        def get_bin_path(self, arg1, opt_dirs=[]):
            test_com = 'test_com'
            return test_com

        def run_command(self, arg1):
            test_rc = 0
            test_com = 'test_com'
            test_fcinfo_out = '''
            test_out
            HBA Port WWN: 10000090fa1658de
            test_out
            '''
            test_err = 'test_err'
           

# Generated at 2022-06-22 23:55:19.250194
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:29.203391
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    FC_WWN_INITIATOR_FACTS = {'fibre_channel_wwn': ['50060b00006975ec', '50060b00006975ed']}

    class MockModule:
        def __init__(self, fc_wwn_initiator_facts):
            self.fc_wwn_initiator_facts = fc_wwn_initiator_facts
            self.run_command_results = [(0, "a\n b\n c", ''), ]
            self.run_command_calls = []

        def get_bin_path(self, arg, opt_dirs=[]):
            return "/usr/bin/%s" % arg

        def run_command(self, cmd, check_rc=False, close_fds=True):
            self.run_command

# Generated at 2022-06-22 23:55:32.000347
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert (isinstance(fc_facts, FcWwnInitiatorFactCollector))

# Generated at 2022-06-22 23:55:34.231039
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:44.447586
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for ansible.module_utils.facts.fibre_channel_wwn_initiator.FcWwnInitiatorFactCollector.collect"""

    # __init__ method
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

    # collect method
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append('0123456789ABCDEF')
    assert fact_collector.collect() == fc_facts