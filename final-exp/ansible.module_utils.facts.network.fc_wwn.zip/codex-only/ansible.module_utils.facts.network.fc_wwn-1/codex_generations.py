

# Generated at 2022-06-22 23:45:40.855568
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:45:52.607565
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """

    # noinspection PyBroadException

# Generated at 2022-06-22 23:45:55.620577
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:00.660211
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-22 23:46:10.785292
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self, params, args=None):
            self.params = params
            self.args = args

        def get_bin_path(self, app, *args, **kwargs):
            lookup_dict = {
                'fcinfo': '/usr/sbin/fcinfo',
                'ioscan': '/usr/sbin/ioscan',
                'lscfg': '/usr/bin/lscfg',
                'prtconf': '/usr/sbin/prtconf',
                'fcmsutil': '/opt/fcms/bin/fcmsutil',
                'lsdev': '/usr/bin/lsdev',
            }
            if app in lookup_dict:
                return lookup_dict[app]
            else:
                return None


# Generated at 2022-06-22 23:46:15.663271
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Test method collect of class FcWwnInitiatorFactCollector """
    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_obj.collect() == {}


# Generated at 2022-06-22 23:46:18.745515
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-22 23:46:28.794253
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def create_module():
        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True
        )
        return module

    module = create_module()
    # create fact collector
    fact_module = FcWwnInitiatorFactCollector()
    #assert fact_module.name == 'fibre_channel_wwn'
    collected_facts = fact_module.collect(module=module)
    wwn_list = collected_facts.get('fibre_channel_wwn')
    assert wwn_list is not None
    assert type(wwn_list) == list
    assert len(wwn_list) > 0
    for wwn in wwn_list:
        assert type(wwn) == unicode

# Generated at 2022-06-22 23:46:31.301595
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:46:35.788873
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    col = FcWwnInitiatorFactCollector()
    assert col is not None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:38.394683
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:46:42.659063
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_col = FcWwnInitiatorFactCollector()
    assert facts_col.name == 'fibre_channel_wwn', 'test_FcWwnInitiatorFactCollector assert #1 has failed.'
    assert facts_col._fact_ids == set(), 'test_FcWwnInitiatorFactCollector assert #2 has failed.'

# Generated at 2022-06-22 23:46:46.748309
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    x = FcWwnInitiatorFactCollector()

    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:57.318918
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_factcollector = FcWwnInitiatorFactCollector()
    fc_facts = fc_factcollector.collect()
    assert 'fibre_channel_wwn' in fc_facts

    # test solaris11 facts
    cmd = '/usr/sbin/fcinfo'
    rc, fcinfo_out, err = module.run_command(cmd)
    assert fcinfo_out

    # test solaris10 facts
    cmd = '/usr/sbin/fcinfo'
    rc, fcinfo_out, err = module.run_command(cmd)
    assert fcinfo_out

    # test AIX facts
    cmd = '/usr/sbin/lsdev'
    rc, lsdev_out, err = module.run_command(cmd)
    assert lsdev_out

   

# Generated at 2022-06-22 23:47:08.799540
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # pylint: disable=protected-access,import-error
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import FactsCollector

    fww = FactsCollector().collect(module=None, collected_facts={})
    fc_fact = FcWwnInitiatorFactCollector()._collect(module=None,
                                                     collected_facts=fww)
    facts = FactsCollector().call_collectors(module=None,
                                             collected_facts=fc_fact)
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-22 23:47:11.003291
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:12.760473
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_class = FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:47:19.187966
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'fibre_channel_wwn'
    assert list(fact_collector._fact_ids) == []
    assert fact_collector._platform == ['Linux', 'SunOS', 'AIX', 'HP-UX']


# Generated at 2022-06-22 23:47:20.021504
# Unit test for constructor of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:47:25.903700
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import BaseFactCollector
    module = BaseFactCollector(None)
    del module.ansible_facts['ansible_fibre_channel_wwn']
    module.collect_facts = ['ansible_fibre_channel_wwn']
    module.gather_subset = ['all']
    module.populate_facts(None, {})
    assert module.ansible_facts['ansible_fibre_channel_wwn'] == []

    # Example contents /sys/class/fc_host/*/port_name:
    # 0x21000014ff52a9bb
    test_file_path = '/tmp/ansible_test_fc_host_port_name'
   

# Generated at 2022-06-22 23:47:30.492845
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.collect() == {}


# Generated at 2022-06-22 23:47:40.647413
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_args = []
    test_kwargs = {
        'module' : None,
        'collected_facts' : None
    }
    with patch('ansible.module_utils.facts.collector.BaseFactCollector.collect', Mock(return_value={})):
        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector(*test_args, **test_kwargs)
        fc_wwn_initiator_fact_collector.collect()
        assert fc_wwn_initiator_fact_collector.collected_facts == {}

# Generated at 2022-06-22 23:47:43.211719
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a
    assert a.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:47:56.191270
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    d_file_lines = {'/sys/class/fc_host/test/port_name': ['0x21000024ff52a9bb']}

# Generated at 2022-06-22 23:48:02.084495
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnFC = FcWwnInitiatorFactCollector()
    assert fcWwnFC.name == 'fibre_channel_wwn'
    assert fcWwnFC.collect() is not None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:13.598208
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Use Mock for unit testing
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector.fibre_channel import FcWwnInitiatorFactCollector
    import ansible.module_utils.facts.utils as facts_utils

    # Create a mock module since we are faking all command line args here
    mm = type('AnsibleModule', (), {})()
    setattr(mm, 'params', {})
    setattr(mm, 'fail_json', facts_utils.fail_json)

    # Create a mock facts_module_params class that can be passed to
    #   get_collector_facts()
    class MockFactsModuleParams:
        def __init__(self):
            self.gather_subset = None


# Generated at 2022-06-22 23:48:16.294083
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'
    assert a.collect()

# Generated at 2022-06-22 23:48:20.175009
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:23.177898
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-22 23:48:36.012617
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This is the test for the collect method inside the FcWwnInitiatorFactCollector class.
    It checks the output of the collect method against some fake data.
    The test also checks if the method throws a SystemExit when the given parameters are not valid.
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import sys
    import os
    import unittest

    # create fake values
    fake_files = list()
    fake_files.append('/sys/class/fc_host/host1/port_name')
    fake_files.append('/sys/class/fc_host/host2/port_name')

    # create fake contents
    contents = list()

# Generated at 2022-06-22 23:48:38.746120
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:48:42.806356
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:48:55.235013
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule:
        def __init__(self):
            self.params = {}
            self.bin_path =  '/usr/bin'

        def get_bin_path(self, name, opt_dirs=None):
            return self.bin_path

        def run_command(self, cmd):
            from ansible.module_utils.facts.platform.aix import AixFacts
            platform_facts = AixFacts(self)
            platform_name = platform_facts.pop('distribution_name').lower()
            if platform_name == 'aix':
                out = '''fcs3 Available 19-08-00 8Gb FC PCI Express Host Adapter (df1000fe)
fcs0 Defined   19-08-00 8Gb FC PCI Express Host Adapter (df1000fe)
'''
                return 0, out,

# Generated at 2022-06-22 23:49:06.000382
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleDummy
    TEST_WWNS = ['0x21000014ff52a9bb', '0x21000014ff52a9bc', '0x21000014ff52a9bd']
    myTestModule = ModuleDummy()
    myFactCollector = FcWwnInitiatorFactCollector(myTestModule)
    assert myFactCollector.name == 'fibre_channel_wwn'
    assert myFactCollector.collect() == {'fibre_channel_wwn': TEST_WWNS}

# Generated at 2022-06-22 23:49:07.963075
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:49:10.491251
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import GenericFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    FcWwnInitiatorFactCollector()
    GenericFactCollector()
    BaseFactCollector()

# Generated at 2022-06-22 23:49:12.299428
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    arg_spec = {"FcWwnInitiatorFactCollector": ""}
    obj = FcWwnInitiatorFactCollector(arg_spec)
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:14.639615
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert type(fc_facts) == FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:49:18.440785
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    assert o.name == 'fibre_channel_wwn'
    assert o._fact_ids == set()

# Generated at 2022-06-22 23:49:26.159694
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_collector = FcWwnInitiatorFactCollector()

    # Example contents /sys/class/fc_host/*/port_name:
    # 0x21000014ff52a9bb
    lines = [b"0x21000014ff52a9bb"]
    fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    assert fc_collector.collect(collected_facts=None, lines=lines) == fc_facts

# Generated at 2022-06-22 23:49:28.879610
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.collect(collected_facts=None) == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:49:31.493259
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:49:34.658943
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()

# Generated at 2022-06-22 23:49:46.563203
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # execute the method

    # dummy class with execute modules enabled
    class MyModuleDummy:
        def __init__(self):
            self._name = 'ansible_fibre_channel_wwn'

        def get_bin_path(self, arg1, opt_dirs=None):
            print(arg1)
            if arg1 == 'lsdev':
                return '/usr/sbin/lsdev'
            if arg1 == 'lscfg':
                return '/usr/sbin/lscfg'
            if arg1 == 'ioscan':
                return '/usr/sbin/ioscan'
            if arg1 == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            if arg1 == 'fcinfo':
                return '/usr/sbin/fcinfo'


# Generated at 2022-06-22 23:49:59.093072
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import platform
    import os
    import sys
    import stat
    import errno
    import tempfile

    test_file_content = """hello world"""

    class ModuleMock():

        def get_bin_path(self, name, opt_dirs=[]):
            return name

    class OsMock():

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def access(self, path, flag):
            if test_file_content in path and flag == os.R_OK:
                return True
            else:
                raise OSError(
                    errno.EACCES,
                    "Permission denied: '%s'" % path
                    )


# Generated at 2022-06-22 23:50:11.720965
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # create object class
    fact_collector = FcWwnInitiatorFactCollector()

    # call method
    facts = fact_collector.collect()

    # check results
    assert 'fibre_channel_wwn' in facts

    if sys.platform.startswith('linux'):
      assert len(facts['fibre_channel_wwn']) == 1
    elif sys.platform.startswith('sunos'):
      assert len(facts['fibre_channel_wwn']) == 1
    elif sys.platform.startswith('aix'):
      assert len(facts['fibre_channel_wwn']) == 1

# Generated at 2022-06-22 23:50:20.910528
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    platform = sys.platform
    try:
        from ansible.module_utils.facts.collector import Collector
        fcWwnInitiatorFactCollector = Collector.factory('fibre_channel_wwn')
        assert isinstance(fcWwnInitiatorFactCollector, FcWwnInitiatorFactCollector, 'not an instance of FcWwnInitiatorFactCollector')
    finally:
        sys.platform = platform

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:33.226960
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self, return_value, command_in, command_out):
            self.return_value = return_value
            self.command_in = command_in
            self.command_out = command_out
            self.params = {}

        def get_bin_path(self, command, opt_dirs=[]):
            return command

        def run_command(self, cmd):
            return self.return_value, self.command_out.get(cmd, ""), ""


# Generated at 2022-06-22 23:50:42.163612
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.exit_json = lambda x: x
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    # only run on linux as testbed
    if FcWwnInitiatorFactCollector.is_platform_supported(test_module):
        fc_facts = test_FcWwnInitiatorFactCollector.collect(test_module)
        assert fc_facts['fibre_channel_wwn'] != []

# Generated at 2022-06-22 23:50:51.612944
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name, opt_dirs=[]):
            if name in [ 'ioscan', 'fcmsutil' ]:
                return os.path.join('/tmp', name)
            else:
                return 'false'

        def run_command(self, cmd):
            with open(os.path.join(self.params['path'], 'expect_out.txt')) as f:
                expect_out_lines = f.readlines()


# Generated at 2022-06-22 23:50:59.046330
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-22 23:51:01.285392
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector is not None


# Generated at 2022-06-22 23:51:03.322065
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fcwwn.name

# Generated at 2022-06-22 23:51:10.663301
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    # test name
    assert(fc.name == 'fibre_channel_wwn')
    # test source
    assert(fc.source == 'fibre_channel_wwn_fact_collector')
    # test _fact_ids
    assert(len(fc._fact_ids) == 1)
    assert(fc._fact_ids == {'fibre_channel_wwn'})

# Generated at 2022-06-22 23:51:14.208639
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:51:22.246263
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect()
    assert isinstance(fc_facts, dict)
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:51:24.197040
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    fcwwn = FcWwnInitiatorFactCollector()
    assert isinstance(fcwwn, Collector)
    assert fcwwn.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:51:35.520243
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Test case for FcWwnInitiatorFactCollector"""
    # create the object
    fci = FcWwnInitiatorFactCollector()

    # create a stub module object
    class Module:
        def get_bin_path(self, arg1, arg2=None):
            return arg2

        def run_command(self, arg1):
            if arg1 == 'fcinfo hba-port':
                return (0, 'HBA Port WWN: 10000090fa1658de\n', '')
            elif arg1 == 'lsdev -Cc adapter -l fcs*':
                return (0, 'fcs3 Available 00-02 FC Adapter\n', '')

# Generated at 2022-06-22 23:51:45.865717
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for FcWwnInitiatorFactCollector.collect"""
    import random
    import string

    class MockModule:
        """Mock class of ansible module"""
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            """
            Mock for run_command
            """
            if cmd == 'ioscan -fnC FC':
                mock_stdout = '/dev/fcd0    0/fc/fcd0   devfs   bus=0xfc path=0x0 target=0x0 lun=0x0  (FC DSKA)'
                return 0, mock_stdout, None

# Generated at 2022-06-22 23:51:58.687746
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ test FcWwnInitiatorFactCollector.collect() """
    import platform
    import sys
    import glob
    import shutil
    import tempfile
    from ansible.module_utils.facts import MacroModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    import pytest

    class TestMacroModule(MacroModule):
        """ test class for ansible.module_utils.facts.MacroModule """

        def __init__(self, module_name=None, module_args=None, tmpdir=None):
            super(TestMacroModule, self).__init__(module_name, module_args)
            self.tmpdir = tmpdir


# Generated at 2022-06-22 23:52:03.117796
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    col = get_collector_instance('fibre_channel_wwn')
    facts = col.collect()
    assert 'fibre_channel_wwn' in facts
    assert isinstance(facts['fibre_channel_wwn'], list)

# Generated at 2022-06-22 23:52:15.287016
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create object
    fact_collector = FcWwnInitiatorFactCollector()

    # create mock module
    class MockModule(object):
        def __init__(self, value):
            self.val = value
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable.startswith('lscfg'):
                # mock command
                return 'lscfg'
            if executable.startswith('ioscan'):
                # mock command
                return 'ioscan'
            if executable.startswith('fcmsutil'):
                # mock command
                return 'fcmsutil'
            if executable.startswith('fcinfo'):
                # mock command
                return 'fcinfo'

# Generated at 2022-06-22 23:52:19.212752
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:31.613499
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a simple module class to use for testing
    class AnsibleModule(object):
        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return 'finfo'
            elif arg == 'ioscan':
                return 'ioscan'
            elif arg == 'lsdev':
                return 'lsdev'
            elif arg == 'lscfg':
                return 'lscfg'
            elif arg == 'fcmsutil':
                return 'fcmsutil'
            return None

        def run_command(self, arg):
            if arg == 'finfo hba-port':
                return (0, "HBA Port WWN: 10000090fa1658de", '')

# Generated at 2022-06-22 23:52:33.723809
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:46.763968
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class mock_module:
        def __init__(self):
            self.run_command = self.fake_run_command
            self.get_bin_path = self.fake_get_bin_path
        def fake_run_command(self, cmd):
            return (0, 'HBA Port WWN: 10000090fa1658de', '')
        def fake_get_bin_path(self, cmd):
            # We will test for cmd == 'fcinfo' only
            return '/usr/bin/' + cmd
    class mock_facts:
        pass
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    res = fcwwn_fact_collector.collect(mock_module(), mock_facts())

# Generated at 2022-06-22 23:52:52.124258
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    test_obj = FcWwnInitiatorFactCollector()
    fc_facts = test_obj.collect(module)
    assert fc_facts == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-22 23:53:01.820914
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    returns a list of wwns

    """
    import platform

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
        for line in get_file_lines(fcfile):
            fc_facts['fibre_channel_wwn'].append(line.rstrip()[2:])
    if platform.system() == 'Linux' and not fc_facts['fibre_channel_wwn']:
        # this is the "fast" module, on linux, with no values
        raise AssertionError("No Fibre Channel WWN found in /sys/class/fc_host/*/port_name")
    return fc_facts

# Generated at 2022-06-22 23:53:14.690389
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Test collecting facts from fc_host."""

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector.linux.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.utils import ModuleVoip

    module = ModuleVoip()
    collected_facts = collector.collect(module=module)

    fcwwn_collector = FcWwnInitiatorFactCollector()
    facts = fcwwn_collector.collect(module=module, collected_facts=collected_facts)

    assert type(facts) is dict

# Generated at 2022-06-22 23:53:20.750211
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    `FcWwnInitiatorFactCollector.__init__` should set `FcWwnInitiatorFactCollector.name`
    and `FcWwnInitiatorFactCollector._fact_ids`.

    `FcWwnInitiatorFactCollector.name` should be `fibre_channel_wwn`.
    `FcWwnInitiatorFactCollector._fact_ids` should be `fibre_channel_wwn`.
    """
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fc_wwn_initiator_fact_collector.name
    assert 'fibre_channel_wwn' in fc_wwn_initiator_fact

# Generated at 2022-06-22 23:53:25.688650
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    data = { 'ansible_facts' : {
                'fibre_channel_wwn' : ['fcwwn_test_data']
                }
            }
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == data

# Generated at 2022-06-22 23:53:29.062790
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:53:38.799287
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Note: as this method is dependent on the system/platform on which it executes,
          it can not be reliably tested on a developer machine. There is a chance
          this method gets tested in integration tests.
          This is the reason, why method collect is mocked here.
    """
    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.command_results = []

        def get_bin_path(self, name, opt_dirs=[]):
            return self.params.get(name)

        def run_command(self, command, check_rc=False):
            return self.params['run_command_func'](command)

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-22 23:53:41.207809
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc == fc



# Generated at 2022-06-22 23:53:43.310941
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_class = FcWwnInitiatorFactCollector()
    assert test_class.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:46.360014
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Units tests for constructor of class FcWwnInitiatorFactCollector
    """
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.collect() == {}

# Generated at 2022-06-22 23:53:50.609182
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    assert 'fibre_channel_wwn' in result
    assert result['fibre_channel_wwn'] == []


# Generated at 2022-06-22 23:53:52.136181
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:53:54.408804
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:02.177521
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.facts import Facts

    fact_collector = get_collector_instance("FcWwnInitiatorFactCollector")
    facts = Facts(collect_default=False)
    fact_collector.collect(None, facts)

    fc_facts = facts.get('fibre_channel_wwn')
    assert len(fc_facts) > 0

# Generated at 2022-06-22 23:54:11.805504
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector.
    """
    FcWwnInitiatorFactCollector = sys.modules[__name__].FcWwnInitiatorFactCollector
    options = {'ansible_check_mode': False}

    d = {'ansible_facts': {'fibre_channel_wwn': []}}
    f = FcWwnInitiatorFactCollector(d, {}, options)
    f.collect()
    assert len(d['ansible_facts']['fibre_channel_wwn']) == 0


# Generated at 2022-06-22 23:54:21.985162
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    We're passing sys.platform value to the `FCWwnInitiatorFactCollector`
    in order to make it work.
    Also, we're passing globals() and locals() from the same function
    in order to make access to class 'AnsibleModule'.
    """
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import sys
    import tempfile
    import os

    # create temporary directory, which will contain files with FC WWN
    tmpdirpath = tempfile.mkdtemp()

# Generated at 2022-06-22 23:54:33.092038
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # prepare test object
    class MockModule(object):
        def run_command(self, cmd, tmp_path=None, environ_update=None):
            return dict(rc=0, stdout="", stderr="")
        def get_bin_path(self, cmd, opt_dirs=[]):
            return "mock_bin_path"
    module = MockModule()
    # prepare test input
    collected_facts = dict()
    # execute test
    fc = FcWwnInitiatorFactCollector(module, collected_facts)
    fc_facts = fc.collect()
    # verify
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:54:34.622786
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Arrange

    # Act
    # Assert
    assert True

# Generated at 2022-06-22 23:54:47.391511
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("Test method FcWwnInitiatorFactCollector_collect")

    myFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector
    test_facts = {'fibre_channel_wwn': []}

    if sys.platform.startswith('linux'):
        myFcWwnInitiatorFactCollector._file_paths = ["/sys/class/fc_host/host1/port_name",
                                                     "/sys/class/fc_host/host2/port_name"]
    elif sys.platform.startswith('sunos'):
        myFcWwnInitiatorFactCollector._file_paths = ["fcinfo_hba-port.linux"]
    elif sys.platform.startswith('aix'):
        myFcW

# Generated at 2022-06-22 23:54:49.412722
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result is not None

# Generated at 2022-06-22 23:54:57.138944
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    test_module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    # create a FcWwnInitiatorFactCollector object
    c = FcWwnInitiatorFactCollector(None, test_module)

    # retrieve facts
    x = c.collect()
    assert 'fibre_channel_wwn' in x

# Generated at 2022-06-22 23:55:06.335373
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # pylint: disable=import-error
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    # pylint: enable=import-error
    # pylint: disable=line-too-long
    # pylint: disable=too-many-branches

    # create a test class
    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()

    # create a test AnsibleModule object
    AnsibleFactCollector_obj = AnsibleFactCollector()
    AnsibleFactCollector_obj.collect = lambda: dict(ansible_facts={})
    AnsibleFactCollector_obj.exit

# Generated at 2022-06-22 23:55:09.646521
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fc_obj.name
    assert fc_obj.collect() == {}

# Generated at 2022-06-22 23:55:14.023617
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    result = {'fibre_channel_wwn': []}
    assert FcWwnInitiatorFactCollector().collect() == result

# Generated at 2022-06-22 23:55:27.596206
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.fc_wwn_initiator import FcWwnInitiatorFactCollector

    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.platform == 'Linux'

    sys_platform = platform.system().lower()
    if sys_platform == 'linux':
        file_exist = os.path.isfile('/sys/class/fc_host/host0/port_name')
        if not file_exist:
            os.makedirs('/sys/class/fc_host/host0')

# Generated at 2022-06-22 23:55:31.703321
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    fact_collector = FcWwnInitiatorFactCollector(None)
    fact_collector.collect()
    # nothing to test - requires real linux system

# Generated at 2022-06-22 23:55:43.612213
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()

    # test default functionality
    #class AnsibleModuleMock(object):
    #    def get_bin_path(self, arg):
    #        return "echo"
    #    def run_command(self, arg):
    #        return 0, "50060b00006975ec", ""
    #ansibleModuleMock = AnsibleModuleMock()
    #fc_facts = FcWwnInitiatorFactCollector.collect(ansibleModuleMock)
    #assert fc_facts == {'fibre_channel_wwn': ['50060b00006975ec']}

    # test non-default functionality
    #class AnsibleModuleMock(object):
    #    def get_bin_path(self, arg