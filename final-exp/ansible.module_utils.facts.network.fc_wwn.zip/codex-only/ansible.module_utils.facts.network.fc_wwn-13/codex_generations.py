

# Generated at 2022-06-22 23:45:50.603104
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create mock environment.
    from ansible.module_utils.facts import ansible_facts
    facts = ansible_facts
    # We need to add a mock value of an AnsibleModule object inside of which we'll mock the run_command method
    # to simulate a command run.
    facts['ansible_module'] = MockAnsibleModule()
    fci = FcWwnInitiatorFactCollector()
    result = fci.collect(collected_facts=facts)
    assert result == {'fibre_channel_wwn': [ '21000014ff52a9bb',
                                             '50060b00006975ec' ] }


# Generated at 2022-06-22 23:45:55.067857
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert type(a) == FcWwnInitiatorFactCollector
    assert a.name == 'fibre_channel_wwn'
    assert a._fact_ids == set()

# Generated at 2022-06-22 23:45:57.864533
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in a.name

# Generated at 2022-06-22 23:46:00.440571
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-22 23:46:03.694591
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj
    assert test_obj.name == 'fibre_channel_wwn'
    assert test_obj._fact_ids is not None

# Generated at 2022-06-22 23:46:06.729024
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:46:09.083810
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:46:12.816446
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:46:17.255591
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create class instance
    fc_obj = FcWwnInitiatorFactCollector()
    # test name
    assert fc_obj.name == 'fibre_channel_wwn'
    # test fact_ids
    assert fc_obj._fact_ids == set()

# Generated at 2022-06-22 23:46:27.756632
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class ModuleMock(object):
        def __init__(self, params=None):
            if params:
                self.params = params
            else:
                self.params = {}
        def run_command(self, cmd, check_rc=None):
            if 'fcinfo' in cmd and 'hba-port' in cmd:
                return 0, """
HBA Port WWN: 10000090fa1658de
HBA Port WWN: 10000090fa1658df
                """, ""
            if 'lsdev' in cmd:
                return 0, """
              fcs0 Available  00-08        IBM 10 Gb PCI Express Dual-port CFFh CA
              fcs1 Available  00-09        IBM 10 Gb PCI Express Dual-port CFFh CA
                """, ""

# Generated at 2022-06-22 23:46:40.011740
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    D = dict()
    D['ANSIBLE_MODULE_UTILS'] = 'ansible.module_utils'
    D['ANSIBLE_CACHE_PLUGIN'] = ''
    D['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = ''
    D['ANSIBLE_CONFIG'] = ''
    D['ANSIBLE_SYSTEM_HOSTS'] = ''
    D['ANSIBLE_HOSTS'] = ''
    D['ANSIBLE_SSH_ARGS'] = '-o StrictHostKeyChecking=no'
    D['ANSIBLE_RETRY_FILES_ENABLED'] = 'False'
    D['ANSIBLE_REMOTE_USER'] = 'ansible'
    D['ANSIBLE_PIPELINING'] = 'True'

# Generated at 2022-06-22 23:46:42.170807
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Returns the FcWwnInitiatorFactCollector instance for testing.
    """
    return FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:46.791865
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-22 23:46:47.700962
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:46:58.798120
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import platform
    import sys
    import time

    class Struct:
        """
        Helper class to produce function return values
        """
        def __init__(self, **entries):
            self.__dict__.update(entries)

        def __str__(self):
            return str(self.__dict__)

    class Module:
        """
        Helper class to produce ansible module like commands
        """
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_err = ''
            self.run_command_out = ''
            self.platform = sys.platform
            self.distribution = platform.dist()


# Generated at 2022-06-22 23:47:02.625722
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc != None
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() == {}

# Generated at 2022-06-22 23:47:04.988497
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts = {}
    # TBD: implement unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:47:17.841702
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Nothing to test on windows
    if sys.platform.startswith('win'):
        return
    # init module_utils and AnsibleModule
    module_args = dict(
        collector=[dict(name='fibre_channel_wwn')],
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    collector = FcWwnInitiatorFactCollector(module)
    facts_collected = collector.collect()
    module.exit_json(ansible_facts=facts_collected)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:47:24.636689
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    test_module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    result = FcWwnInitiatorFactCollector().collect(test_module, {})
    assert result.get('fibre_channel_wwn') == []

# Generated at 2022-06-22 23:47:32.349570
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, Mock, MagicMock
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines, get_file_content

    mock_module = MagicMock()
    mock_module.run_command = Mock(return_value=(0, '', ''))
    mock_module.get_bin_path = Mock(return_value='/bin/some_command')

    # Unit test for linux platform:
    # return fact list with wwn


# Generated at 2022-06-22 23:47:35.557422
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert hasattr(fc, 'collect')

# Generated at 2022-06-22 23:47:38.349094
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:47:39.322206
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:47:46.474808
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fcwwn import FcWwnInitiatorFactCollector
    module = None
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect( module)
    assert facts
    assert facts['fibre_channel_wwn']
    assert facts['fibre_channel_wwn'][0]

# Generated at 2022-06-22 23:47:48.022158
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c is not None

# Generated at 2022-06-22 23:47:55.468449
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    collected_facts = Collector().collect(module=None)

    new_facts = FcWwnInitiatorFactCollector().collect(module=None, collected_facts=collected_facts)
    assert new_facts['fibre_channel_wwn']


# Generated at 2022-06-22 23:48:01.272698
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    ''' Test for method collect of class FcWwnInitiatorFactCollector '''
    collector = FcWwnInitiatorFactCollector()
    fc_facts = collector.collect()
    assert fc_facts['fibre_channel_wwn']
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:48:10.398018
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    result = {}
    class MockModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: result.update(x)
        def run_command(self, cmd):
            return (0, '', '')
        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd
    fci = FcWwnInitiatorFactCollector()
    fci.collect(MockModule())
    assert result['fibre_channel_wwn'] == ['21000014ff52a9bb']


# Generated at 2022-06-22 23:48:22.745189
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys
    import glob
    from ansible.module_utils.facts.utils import get_file_lines

    # We need to substitute the BaseFactCollector class with a dummy class
    # to prevent the method collect of the tested class to invoke the
    # method collect of the BaseFactCollector superclass and to avoid
    # the subsequent call to self.collect_platform_facts()
    FcWwnInitiatorFactCollector.__bases__ = (object,)

    c = FcWwnInitiatorFactCollector()

    class Module:
        def __init__(self):
            self.params = {}
            self.facts = {}

# Generated at 2022-06-22 23:48:24.551447
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.collect()['fibre_channel_wwn']

# Generated at 2022-06-22 23:48:26.174307
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'



# Generated at 2022-06-22 23:48:28.672623
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule

    FcWwnInitiatorFactCollector.collect(MockModule())

# Generated at 2022-06-22 23:48:33.149588
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    assert ('fibre_channel_wwn' in result)
    assert (type(result['fibre_channel_wwn']) is list)

# Generated at 2022-06-22 23:48:42.793087
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    module = AnsibleModuleStub_FcWwnInitiatorFactCollector()
    # call the method under test
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], (list, tuple))
    assert fc_facts['fibre_channel_wwn'] == ['10000090fa1658de', '10000090fa551509']


# Unit test stub for AnsibleModule
# see https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/system/__

# Generated at 2022-06-22 23:48:43.842256
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass



# Generated at 2022-06-22 23:48:49.891563
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Setup
    test_instance = FcWwnInitiatorFactCollector()
    # Test
    result = test_instance.collect()
    print ("Result is %s\n" % result)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:49:03.271508
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts

    # setup our test class/object
    mf = ModuleFacts()

    # create an instance of our class
    fwc = FcWwnInitiatorFactCollector(mf)

    # create a mock module
    class MockModule:
        def __init__(self,rc,fs_out,fs_err):
            self.rc = rc
            self.fs_out = fs_out
            self.fs_err = fs_err
        def get_bin_path(self, path, required=False, opt_dirs=[]):
            # assert we were passed the expected arguments
            assert path == 'fcmsutil'
            assert required == False
            assert opt_dirs == ['/opt/fcms/bin']

# Generated at 2022-06-22 23:49:05.490609
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn is not None

# Generated at 2022-06-22 23:49:17.448986
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def set_module_args(args):
        module_args = dict(
            gather_subset=args['gather_subset'],
            gather_timeout=args['gather_timeout']
        )
        return module_args

    gathered_facts = {}
    input_params = {}
    input_params['gather_subset'] = ['!all', 'fibre_channel_wwn']
    input_params['gather_timeout'] = 30
    input_args = set_module_args(input_params)
    fc_obj = FcWwnInitiatorFactCollector(module=None, params=input_args, gathered_facts=gathered_facts)

    # Test 1 - empty gathered facts
    for fact_name in fc_obj._fact_ids:
        assert fact_name not in gathered_facts

# Generated at 2022-06-22 23:49:22.843268
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector is not None
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()


# Generated at 2022-06-22 23:49:24.526523
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:49:26.926462
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_collector = FcWwnInitiatorFactCollector()
    facts = fc_collector.collect()


# Generated at 2022-06-22 23:49:31.309771
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is not None
    assert isinstance(fc._fact_ids, set)
    assert fc.collect() is not None

# Generated at 2022-06-22 23:49:35.025456
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_initiator_collector = FcWwnInitiatorFactCollector()
    assert fc_initiator_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:38.045846
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_facts_collector is not None


# Generated at 2022-06-22 23:49:50.397434
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_lines
    sys.modules['ansible'] = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
    )
    #
    # Create some test data
    #

# Generated at 2022-06-22 23:49:51.972849
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector() is not None

# Generated at 2022-06-22 23:50:04.659116
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    #
    # The following example data are based on the following
    # system configuration:
    #
    # - linux operating system
    # - two fibre-channel HBA
    #   - one online
    #   - one offline
    # - according  to /sys/class/fc_host/*/port_name the following
    #   WWN are configured:
    #   - 0x21000014ff52a291
    #   - 0x21000014ff502893
    #
    from ansible.module_utils.facts.collector import Collector

    module_mock = Mock()
    module_mock.run_command.return_value = (0, None, None)


# Generated at 2022-06-22 23:50:08.597820
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert len(fc_fact_collector._fact_ids) == 0

# Generated at 2022-06-22 23:50:12.746685
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn'
    assert fc_fact._fact_ids == set()


# Generated at 2022-06-22 23:50:18.304370
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    result = {'fibre_channel_wwn': ['10000090fa1658de', '10000090fa551509']}
    assert result == test_FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:50:31.150566
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['system'] = 'Linux'
            self.params['distribution'] = 'Debian'
            self.params['distribution_version'] = '10'

        def get_bin_path(self, *args, **kwargs):
            bin_path = kwargs.get('opt_dirs', ['/bin', '/sbin', '/usr/bin', '/usr/sbin'])
            return bin_path

        def run_command(self, command):
            fcs_device = ['/dev/fcs0', '/dev/fcs1', '/dev/fcs2']

# Generated at 2022-06-22 23:50:36.458085
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fact_collector._fact_ids


# Generated at 2022-06-22 23:50:37.497563
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:50:42.759529
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test with empty argument
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-22 23:50:46.054227
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'
    assert fc_obj._fact_ids == set()

# Generated at 2022-06-22 23:50:48.412274
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_collector is not None


# Generated at 2022-06-22 23:50:52.325830
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_collector = FcWwnInitiatorFactCollector()
    assert test_collector.name == 'fibre_channel_wwn'
    assert test_collector._fact_ids == set()



# Generated at 2022-06-22 23:50:57.347876
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-22 23:51:06.116691
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    class DummmyModule(object):
        def __init__(self):
            self.run_command_environ_update = {}
            self.run_command_results = {}
            self.run_command_calls = []
            self.params = {}
            self.exit_args = {}
            self.exit_called = False

        def exit_json(self, **kwargs):
            self.exit_called = True
            self.exit_args = kwargs
            return

        def fail_json(self, **kwargs):
            self.exit_called = True
            self.exit_args = kwargs
            return

        def get_bin_path(self, arg1, opt_dirs=None):
            return '/usr/bin/' + arg1


# Generated at 2022-06-22 23:51:09.948496
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()

    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:51:12.596131
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert len(fc._fact_ids) == 0

# Generated at 2022-06-22 23:51:20.891265
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import platform
    from ansible.module_utils.facts import Facts

    module = FakeModule()

    if sys.platform.startswith('linux'):
        module.run_command.return_value = (0, '0x21000014ff52a9bb\n0x21000014ff52a9ba\n', '')
    elif sys.platform.startswith('sunos'):
        module.run_command.return_value = (0, 'HBA Port WWN: 10000090fa1658de\nHBA Port WWN: 10000090fa1658df\n', '')

# Generated at 2022-06-22 23:51:25.194794
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
   fc = FcWwnInitiatorFactCollector()
   assert fc.name == 'fibre_channel_wwn'
   assert 'fibre_channel_wwn' in fc._fact_ids

# Unit Test for collect()

# Generated at 2022-06-22 23:51:29.674144
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    test_object = FcWwnInitiatorFactCollector()
    assert test_object.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:38.756616
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a MockStruct object
    class MockStruct:
        def __init__(self, platform=None, lsdev_out=None, lsdev_rc=0, lscfg_out=None, lscfg_rc=0,
            fcinfo_out=None, fcinfo_rc=0, ioscan_out=None, ioscan_rc=0, fcmsutil_out=None, fcmsutil_rc=0,
            **kwargs):
            self.platform = platform
            self.lsdev_out = lsdev_out
            self.lsdev_rc = lsdev_rc
            self.lscfg_out = lscfg_out
            self.lscfg_rc = lscfg_rc
            self.fcinfo_out = fcinfo_out
            self.fcinfo_rc = f

# Generated at 2022-06-22 23:51:49.380069
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # given
    import os

    class ModuleMock(object):
        def get_bin_path(self, path, opt_dirs=[]):
            # simulate an AIX system
            return '/opt/fcms/bin/fcmsutil'

        def run_command(self, cmd, check_rc=True, close_fds=True):
            # given
            class StorageMock(object):
                def __init__(self):
                    self.stdout = "lscfg -vpl fcs3 | grep \"Network Address\""
                def close(self):
                    pass

            return 0, StorageMock(), None

    module = ModuleMock()


# Generated at 2022-06-22 23:52:01.776588
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    setattr(builtins, 'open', mock_open(read_data="""0x21000014ff52a9bb"""))
    module = Mock()
    module.run_command.return_value = (0, "", "")
    module.get_bin_path.return_value = "/bin/fcinfo"
    fc_wwn = FcWwnInitiatorFactCollector()
    fc_wwn.collect(module)
    assert fc_wwn.collect(module) == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-22 23:52:14.878554
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """test method collect of class FcWwnInitiatorFactCollector"""
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import FactsArgs

    # create test object
    facts_args = {'_ansible_sys_module_copy': "fake_copy"}
    test_obj = BaseFactCollector(module_facts_args=facts_args)
    assert type(test_obj) == BaseFactCollector

    # create test object
    test_obj = Collector(module_facts_args=facts_args)

# Generated at 2022-06-22 23:52:19.799234
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for FcWwnInitiatorFactCollector.
    """
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.priority == 22

# Generated at 2022-06-22 23:52:23.741440
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:35.169572
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import ansible.module_utils.basic

    class MockModule(object):

        def __init__(self, platform):
            self.platform = platform

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'ioscan':
                if self.platform == 'hp-ux':
                    return '/usr/sbin/ioscan'

# Generated at 2022-06-22 23:52:39.153621
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    if sys.platform.startswith('linux'):
        data = '''
        0x21000014ff52a9bb
        '''
        fcfacts = {
            'fibre_channel_wwn': [
                '21000014ff52a9bb'
            ]
        }
        module = FakeAnsibleModule(data=data)
    elif sys.platform.startswith('sunos'):
        data = '''
        HBA Port WWN: 10000090fa1658de
        '''
        fcfacts = {
            'fibre_channel_wwn': [
                '10000090fa1658de'
            ]
        }
        module = FakeAnsibleModule(data=data)

# Generated at 2022-06-22 23:52:39.471880
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:52:44.063111
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
     from ansible.module_utils.facts import ModuleFacts
     from ansible.module_utils.facts.collector import FactsCollector
     from ansible.module_utils.facts.system.fibre_channel import FcWwnInitiatorFactCollector
     from ansible.module_utils.facts.utils import get_file_lines
     from ansible.module_utils.facts.utils import AnsibleFacts
     from ansible.module_utils.facts.utils import ModuleArgs
     import os, sys
     # setup test environment
     # create fake /sys/class/fc_host/host222/port_name file
     test_data = '0x21000014ff52a9bb'
     test_file_path = '/tmp/port_name'
     test_file = open(test_file_path,'w')
    

# Generated at 2022-06-22 23:52:56.211178
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This function returns the Fibre Channel WWN facts of the local system.
    :return: A dictionary containing the Fibre Channel WWN facts of the local system.
    :rtype: dict
    """
    fci_fact_collector = FcWwnInitiatorFactCollector()
    facts = fci_fact_collector.collect()
    assert type(facts) == dict
    return facts


# Generated at 2022-06-22 23:52:59.590531
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    config = [
        { 'initState': 'available'},
        { 'initState': 'available'},
        { 'initState': 'available'}
    ]

    ret = FcWwnInitiatorFactCollector.__new__(FcWwnInitiatorFactCollector)

    assert ret is not None

# Generated at 2022-06-22 23:53:02.789132
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn'] is not None


if __name__ == '__main__':
    print(test_FcWwnInitiatorFactCollector_collect())

# Generated at 2022-06-22 23:53:15.862373
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method can be used to test the method collect of class FcWwnInitiatorFactCollector
    """
    class TestModule:
        """
        Test class to provide required methods for unit test, e.g. like run_command()
        """
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            fc_facts = {}
            fc_facts['fibre_channel_wwn'] = []

# Generated at 2022-06-22 23:53:19.205497
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in f._fact_ids


# Generated at 2022-06-22 23:53:26.445915
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_test = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fc_test.name, 'Test FcWwnInitiatorFactCollector constructor failed'
    assert fc_test is not None, \
        'Fibre Channel WWN test constructor failed'
    assert 'fibre_channel_wwn' in fc_test._fact_ids, \
        'Test FC WWN test constructor failed'

# Generated at 2022-06-22 23:53:31.971627
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert fc.collect(collected_facts=None) == {
        'fibre_channel_wwn': [],
    }

# Generated at 2022-06-22 23:53:40.561913
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts import collector

    collector_registry.register(FcWwnInitiatorFactCollector)

    host_facts = collector.collect(None, None)
    assert 'fibre_channel_wwn' in host_facts

    fc_facts = host_facts['fibre_channel_wwn']
    assert isinstance(fc_facts, list)

    if sys.platform.startswith('linux'):
        # minimum two adapter, better two
        assert len(fc_facts) >= 2
    elif sys.platform.startswith('sunos'):
        assert len(fc_facts) >= 1

# Generated at 2022-06-22 23:53:42.826932
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:53:44.808720
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector(None)
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:55.486196
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec=dict())

    # Add a global dir to search
    Collector._global_dirs = [to_bytes('./')]

    facts_collector = Collector(module=module)
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    fc_wwn_collector.collect(module, facts_collector.collected_facts)

# Generated at 2022-06-22 23:53:56.129142
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:54:00.044944
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create singleton
    # check that is instance of class FcWwnInitiatorFactCollector
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)

# Generated at 2022-06-22 23:54:00.671590
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:54:12.669740
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import collections

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.collectors import FcWwnInitiatorFactCollector

    class MockModule():

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == "fcinfo":
                return "/usr/bin/fcinfo"
            return ""

        def run_command(self, cmd):
            if cmd == "/usr/bin/fcinfo hba-port":
                return 0, fc_info_out, ""
            else:
                return 1, "", ""

    fc_info_out = """
HBA Port WWN: 10000090fa1658de
            """


# Generated at 2022-06-22 23:54:23.947745
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = Mock()
    module_mock.run_command = Mock()
    module_mock.get_bin_path = Mock()

    # on linux
    module_mock.run_command.return_value = (0, "", "")
    module_mock.get_bin_path.return_value = "/bin/ls"
    sys.platform = "linux"
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect(module_mock)
    assert result == {'fibre_channel_wwn': []}

    # on solaris 10 (fcinfo available)
    module_mock.run_command.return_value = (0, "HBA Port WWN: 10000090fa1658de", "")
    module_mock.get_bin_path

# Generated at 2022-06-22 23:54:29.800963
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-22 23:54:33.731740
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_fact_collector = FcWwnInitiatorFactCollector()
    assert type(my_fact_collector) == FcWwnInitiatorFactCollector
    assert my_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:35.997069
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ Unit test to validate the constructor
    of class FcWwnInitiatorFactCollector.

    Not testing the collection of facts as they
    depend on platform and hardware.
    """
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert 'FcWwnInitiatorFactCollector' in str(obj._fact_ids)

# Generated at 2022-06-22 23:54:39.429180
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_obj = FcWwnInitiatorFactCollector()
    assert facts_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:54:52.003386
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule, MockFactCollector
    from ansible.module_utils.facts.collector import DictListAccumulator

    """
    Run the FcWwnInitiatorFactCollector.collect method and
    assert that the returned dict is correct.
    """
    def mock_run_command(self, command, environ_update=None, check_rc=False):
        """
        Mock module.run_command
        """
        if command.endswith('fcinfo hba-port') and sys.platform.startswith('sunos'):
            return 0, FCINFO_OUT_SUNOS, ''
        elif command.endswith('fcmsutil fcms0') and sys.platform.startswith('hp-ux'):
            return 0, FCMS

# Generated at 2022-06-22 23:55:03.662808
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import FakeModuleUtils
    FakeModuleUtils.BIN_PATHS['ioscan'] = '/usr/sbin/ioscan'
    FakeModuleUtils.BIN_PATHS['fcmsutil'] = '/opt/fcms/bin/fcmsutil'

# Generated at 2022-06-22 23:55:07.618894
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    w = FcWwnInitiatorFactCollector
    assert w.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in w._fact_ids

# Generated at 2022-06-22 23:55:13.048806
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = False
    collected_facts = {}
    default_facts = FcWwnInitiatorFactCollector(module, collected_facts)
    assert default_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in default_facts._fact_ids

# Generated at 2022-06-22 23:55:16.078089
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # First test instantiation of class
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:55:19.314430
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids is not None
    assert len(obj._fact_ids) > 0

# Generated at 2022-06-22 23:55:22.332789
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect(): # pylint: disable=invalid-name
    """ Unit test for method collect of class FcWwnInitiatorFactCollector """
    pass


# Generated at 2022-06-22 23:55:31.508955
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    collected_facts = {}

    collector = FcWwnInitiatorFactCollector()
    new_facts = collector.collect(module=None, collected_facts=collected_facts)

    assert isinstance(new_facts, dict)
    assert 'fibre_channel_wwn' in new_facts
    assert isinstance(new_facts['fibre_channel_wwn'], list)
    assert len(new_facts['fibre_channel_wwn']) >= 1
    # check if collected WWN have a valid format according to
    # http://en.wikipedia.org/wiki/World_Wide_Name
    for wwn in new_facts['fibre_channel_wwn']:
        assert len(wwn) == 16
        assert wwn.isalnum()

# Generated at 2022-06-22 23:55:36.120876
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import AnsibleFacts
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    module.run_command = lambda *args: (0, '', '')

    fc_facts = AnsibleFacts(module)

    c = Collector()
    c._module = module
    c._collect_platform_facts()
    c._get_facts(fc_facts)

    assert type(fc_facts['fibre_channel_wwn']) is list
    assert len(fc_facts['fibre_channel_wwn']) > 1

# Generated at 2022-06-22 23:55:40.121859
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = AnsibleModule(argument_spec={})
    fc = FcWwnInitiatorFactCollector(module=module)
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is None


# Generated at 2022-06-22 23:55:42.348728
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    fc_facts = FcWwnInitiatorFactCollector().collect()
    """
    pass