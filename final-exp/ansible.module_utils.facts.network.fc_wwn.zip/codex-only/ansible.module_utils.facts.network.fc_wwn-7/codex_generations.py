

# Generated at 2022-06-22 23:45:45.583935
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids is not None

# Generated at 2022-06-22 23:45:48.673473
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:45:55.770226
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Run unit tests for FcWwnInitiatorFactCollector.collect()
    """
    # simple unit test here
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_fact_collector.collect()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:45:59.285295
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert "FcWwnInitiatorFactCollector" in str(fc)

# Generated at 2022-06-22 23:46:09.583019
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    if not sys.platform.startswith('linux'):
        return
    data = get_file_content('/sys/class/fc_host/host*/port_name')

    fc_fact_collector = FcWwnInitiatorFactCollector()
    collector = AnsibleCollector(collects_subset=['network'])
    collector.collect(fc_fact_collector)
    fact = collector.get_fact(FcWwnInitiatorFactCollector.name)


# Generated at 2022-06-22 23:46:21.358671
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts import collector

    # statement for catching imported modules
    imported_modules = {}

    # import module if run
    if __name__ == '__main__':
        from ansible.module_utils.facts import collector
    else:
        from ansible.module_utils.facts import collector
        imported_modules['collector'] = collector

    # import module if run
    if __name__ == '__main__':
        import platform
    else:
        import platform
        imported_modules['platform'] = platform

    # =====start unit test =====

    # payload for get_collector_names method
    collector_names_payload = {}

    # payload for method get_fact_names of class FactsCollector
    get

# Generated at 2022-06-22 23:46:31.018253
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule, MockFile
    fc_facts = {'fibre_channel_wwn': [],
                'ansible_facts': {'fibre_channel_wwn': []}}

    aix_mock_module = MockModule(
        facts={},
        params={},
    )


# Generated at 2022-06-22 23:46:38.870148
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector"""
    fc = FcWwnInitiatorFactCollector()
    res_fc = fc.collect()
    # we expect an empty list
    assert res_fc['fibre_channel_wwn'] == []
    # test if fibre_channel_wwn is an available fact
    assert 'fibre_channel_wwn' in res_fc

# Generated at 2022-06-22 23:46:47.993759
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test if the fact FcWwnInitiatorFactCollector can be collected
    accurately for different operating systems.

    """
    fc_facts = {u'fibre_channel_wwn': []}

    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect()

    """
    for linux systems the output should be a list with the first and the
    last two chars set to '0x'
    """
    if sys.platform.startswith('linux'):
        assert fc_facts['fibre_channel_wwn'] != []
        for wwn in fc_facts['fibre_channel_wwn']:
            assert wwn[0:2] == '0x'

# Generated at 2022-06-22 23:46:51.920155
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_collector.collect()

# Generated at 2022-06-22 23:46:52.493450
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass

# Generated at 2022-06-22 23:47:04.616231
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import get_collector_instance

    test_module = ModuleFacts(dict(PATH="/bin:/sbin:/usr/bin:/usr/sbin"))
    test_FcWwnInitiatorFactCollector = get_collector_instance(FcWwnInitiatorFactCollector, test_module)
    test_FcWwnInitiatorFactCollector.collect()
    fc_facts = test_FcWwnInitiatorFactCollector.get_facts()
    assert len(fc_facts) > 1
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-22 23:47:17.581267
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector

    # Collector is instantiated in unit tests automatically
    c = Collector.get_collector('fibre_channel_wwn')
    assert isinstance(c, FcWwnInitiatorFactCollector)

    # Fiber Channel WWN is different by platform. We are unit testing only
    # linux platform here because the code is written in python.
    if sys.platform.startswith('linux'):
        # Instantiate this collector class
        fc = c
        # Example contents /sys/class/fc_host/*/port_name
        # 0x21000014ff52a9bb
        # Create contents of /sys/class/fc_host/*/port_name for testing

# Generated at 2022-06-22 23:47:28.696661
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an instance of class FcWwnInitiatorFactCollector
    fc_obj = FcWwnInitiatorFactCollector()
    # create an instance of class ModuleStub
    module_obj = ModuleStub()
    # create an instance of class FileStub
    file_obj1 = FileStub('/sys/class/fc_host/host0/port_name', ['0x21000014ff52a9bb'])
    file_obj2 = FileStub('/sys/class/fc_host/host1/port_name', ['0x21000014ff52a9bc'])
    # inject stubs into the class FcWwnInitiatorFactCollector
    fc_obj._files = [file_obj1, file_obj2]
    # call collect method of the class FcWwn

# Generated at 2022-06-22 23:47:34.840769
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # DummyClass inherits from base class
    collected_facts = {}
    x = FcWwnInitiatorFactCollector(collected_facts, None)
    # test that the constructor did not return None
    assert x != None
    # test that the constructor's returned object has attribute 'name'
    assert hasattr(x, 'name')


# Generated at 2022-06-22 23:47:44.793656
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create empty class
    module = {}
    collected_facts = {}
    # Create class instance
    fc_wwn_class = FcWwnInitiatorFactCollector()
    # Set test values to return from method
    test_facts = {'fibre_channel_wwn':['10000000c9426903','10000000c9426904','10000000c9426905']}
    fc_wwn_class.collect = lambda module, collected_facts: test_facts
    fc_facts = fc_wwn_class.collect(module, collected_facts)
    # Check if facts colleted are as expected
    assert fc_facts == test_facts


# Generated at 2022-06-22 23:47:47.294200
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result is not None

# Generated at 2022-06-22 23:47:48.402410
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:48:00.261469
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule(object):
        """
        Mock class for AnsibleModule
        """
        def get_bin_path(self, arg1, opt_dirs=[]):
            if arg1 == 'ioscan':
                return '/sbin/ioscan'
            elif arg1 == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            else:
                return ''

    class MockRunCommand(object):
        """
        Mock class for AnsibleModule.run_command()
        """
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr


# Generated at 2022-06-22 23:48:04.441407
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector._fact_ids

# Generated at 2022-06-22 23:48:08.839668
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_obj = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fc_obj.name
    assert 'fibre_channel_wwn' in fc_obj.collect()

# Generated at 2022-06-22 23:48:12.012216
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'
    assert fact._fact_ids == set()
    assert fact.collect() == {}

# Generated at 2022-06-22 23:48:16.054493
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn'
    assert sorted(fc_fact._fact_ids) == ['fibre_channel_wwn']

# Generated at 2022-06-22 23:48:22.699468
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = AnsibleModuleMock()
    fact_module = FcWwnInitiatorFactCollector()
    facts = fact_module.collect(module_mock, None)
    assert facts['fibre_channel_wwn']
    assert facts['ansible_local']
    assert facts['ansible_local']['fibre_channel_wwn']

# Generated at 2022-06-22 23:48:25.190298
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-22 23:48:28.331014
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Return a FcWwnInitiatorFactCollector object with a name.
    """

    fc_wwn_initiator_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_collector._fact_ids == set()

# Generated at 2022-06-22 23:48:40.581489
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.network import get_subprocess_output
    from ansible.module_utils.facts.collector.network.fibre_channel_wwn import FcWwnInitiatorFactCollector

    class MockModule(object):
        def __init__(self):
            self.get_bin_path_results = ['/foo', '/bin/fcmsutil']

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return self.get_bin_path_results.pop(0)


# Generated at 2022-06-22 23:48:51.838289
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    import os.path
    import sys
    test_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, test_dir)
    from AnsibleModuleMock import AnsibleModule
    module = AnsibleModule()
    fc_fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = fc_fact_collector.collect(module=module)
    assert 'fibre_channel_wwn' in collected_facts

# Generated at 2022-06-22 23:49:05.607101
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_subset_facts
    from ansible.module_utils.facts.collector import BaseFileReadCollector
    from ansible.module_utils.facts.collector import BaseCommandCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts import collector
    import os
    import glob

    class TestAnsibleModule:
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            pass
        def get_bin_path(self, *args, **kwargs):
            return '/bin/echo'

# Generated at 2022-06-22 23:49:10.516354
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    my_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert my_FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:14.312050
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in fc_wwn_fact_collector.name

# Generated at 2022-06-22 23:49:19.374018
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-22 23:49:28.421834
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector._load_platform_subclass = \
        lambda *args: FcWwnInitiatorFactCollector
    FcWwnInitiatorFactCollector.collect = lambda *args: {'fibre_channel_wwn': ['foo', 'bar']}

    # make sure we get a list back
    facts = FcWwnInitiatorFactCollector().collect(module=None, collected_facts=None)
    assert isinstance(facts, dict)
    assert 'fibre_channel_wwn' in facts
    assert isinstance(facts['fibre_channel_wwn'], list)

# Generated at 2022-06-22 23:49:40.659052
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import FactCollector

    ###############################################################################
    # create a fake module
    ###############################################################################

    class FakeModule:
        def __init__(self):
            self.fake_dist = dict()
            self.debug = True
            self.fail_json = dict()
            self.changed = False

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == "fcinfo":
                return "/usr/sbin/fcinfo"
            elif arg == "ioscan":
                return "/usr/sbin/ioscan"
            elif arg == "fcmsutil":
                return "/opt/fcms/bin/fcmsutil"
            else:
                return None


# Generated at 2022-06-22 23:49:52.698942
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts["fibre_channel_wwn"] = [
        '21000014FF43D964',
        '21000024FF43D964'
    ]

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.args = {}
            self.exit_json = {}

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'fcinfo':
                return 'fcinfo'
            if binary == 'lsdev':
                return 'lsdev'
            if binary == 'lscfg':
                return 'lscfg'
            if binary == 'ioscan':
                return 'ioscan'
            if binary == 'fcmsutil':
                return 'fcmsutil'


# Generated at 2022-06-22 23:49:57.039019
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert 'fibre_channel_wwn' in facts
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-22 23:49:59.881100
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert c._fact_ids == set()

# Generated at 2022-06-22 23:50:12.422816
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("Test started of method collect of class FcWwnInitiatorFactCollector")
    testclass = FcWwnInitiatorFactCollector()
    testclass_dict = testclass.collect()
    if testclass_dict.has_key('fibre_channel_wwn') and \
       len(testclass_dict['fibre_channel_wwn']) > 0:
        print("Success: Result of method collect of class FcWwnInitiatorFactCollector: %s" % testclass_dict['fibre_channel_wwn'])
    else:
        print("Error: No result of method collect of class FcWwnInitiatorFactCollector: %s" % testclass_dict['fibre_channel_wwn'])

# Generated at 2022-06-22 23:50:17.318858
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Initiate the class and test if the init went well
    fc_col = FcWwnInitiatorFactCollector()
    assert fc_col.name == 'fibre_channel_wwn'
    assert fc_col._fact_ids == set()

# Generated at 2022-06-22 23:50:21.938108
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwninitiator = FcWwnInitiatorFactCollector()
    assert fcwwninitiator
    assert fcwwninitiator.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:50:32.728065
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts import utils
    assert utils.get_file_lines("test_file") == [
        "first line",
        "second line"
    ]
    fc_collected_facts = {}
    fc_module = AnsibleCollector.load_fact_module("test_file")
    fc_collected_facts = FcWwnInitiatorFactCollector().collect(fc_module)
    assert fc_collected_facts == {
        "fibre_channel_wwn": [
            "21000014ff52a9bb"
        ]
    }

# Generated at 2022-06-22 23:50:36.458085
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:50:44.424750
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    def test_FcWwnInitiatorFactCollector():
        module = Mock()
        module.get_bin_path.return_value = '/usr/sbin/iscsiadm'
        test_obj = FcWwnInitiatorFactCollector(module)
        assert test_obj.name == 'fibre_channel_wwn'
        assert test_obj._fact_ids == set()



# Generated at 2022-06-22 23:50:52.759250
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollectorCache
    # prepare test data
    test_data = [
        "0x21000014ff52a9bb",
        "21000014ff52a9bb",
        "0x21000014ff52a9bc",
        "0x21000014ff52a9bd",
        "HBA Port WWN: 10000090fa1658de",
        "Available",
        "Network Address",
        "Network Address.............10000090FA551509",
        "0x50060b00006975ec"
    ]
    # mock class
    class MockModule:
        def get_bin_path(self, app):
            return app

# Generated at 2022-06-22 23:50:56.441673
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:05.855333
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import unittest
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector

    # generate some test data
    port_data = [
            '0x21000014ff52a9bb',
            '0x21000014ff52cdd9',
            '0x21000014ff52a243'
        ]
    # redirect sys.platform temporarily for unit testing on systems different from Linux
    sys_platform = sys.platform
    sys.platform = 'linux'

    test_tmp_path = tempfile.mkdtemp()
    os.mkdir(os.path.join(test_tmp_path, 'class'))
    os.mkdir(os.path.join(test_tmp_path, 'class/fc_host'))
    os.mk

# Generated at 2022-06-22 23:51:08.364984
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcobj = FcWwnInitiatorFactCollector()
    assert fcobj.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:18.835055
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Facts
    from ansible.module_utils.facts.collectors import FcWwnInitiatorFactCollector

    test_instance = FcWwnInitiatorFactCollector()
    # Test for linux platform
    test_instance.collector.sys_module.platform = 'linux'
    test_facts = {}
    test_instance.collector.facts = Facts()
    test_instance.collector.facts.populate(test_facts)
    result = test_instance.collect()
    assert result['fibre_channel_wwn'] == ['21000014ff52a9bb']
    # Test for solaris 10 platform

# Generated at 2022-06-22 23:51:22.075716
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()

    assert obj.name == "fibre_channel_wwn"
    assert obj.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-22 23:51:25.499520
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fact._fact_ids

# Generated at 2022-06-22 23:51:31.426391
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator is not None
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator._fact_ids == set()

# Generated at 2022-06-22 23:51:39.916700
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.utils import hypen_to_underscore

    random_fact_data = {
        "fibre_channel_wwn": [
            "21000014ff52a9bb",
            "21000014ff52a9bc"
        ]
    }
    fact_collector = FcWwnInitiatorFactCollector()
    result = fact_collector.collect()
    assert 'ansible_local' in result
    del result['ansible_local']
    assert result == random_fact_data

    # test collector as part of get_collector_facts method
    result = get_collector_facts(FcWwnInitiatorFactCollector)
    assert 'ansible_local'

# Generated at 2022-06-22 23:51:45.578350
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform

    testplatform = platform.system().lower()
    if testplatform not in ['linux', 'sunos', 'aix', 'hp-ux']:
        raise Exception("Unsupported testplatform " + testplatform)

    from ansible.module_utils.facts import Collector
    test_collector = Collector()
    test_FactCollector = FcWwnInitiatorFactCollector()
    test_FcWwnInitiatorFactCollector_collect_return = test_FactCollector.collect(test_collector)

    print("test_FcWwnInitiatorFactCollector_collect_return = %s" % test_FcWwnInitiatorFactCollector_collect_return)
    assert type(test_FcWwnInitiatorFactCollector_collect_return) == dict

# Generated at 2022-06-22 23:51:49.431750
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    fc_wwn_obj = FcWwnInitiatorFactCollector()
    assert fc_wwn_obj


# Generated at 2022-06-22 23:51:52.699873
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwiw = FcWwnInitiatorFactCollector()
    assert fwiw.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:51:54.879311
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:51:58.944663
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys
    import pytest
    # inject the uname_result mock return value
    sys.platform = 'linux'
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:04.468110
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    collected_facts = {}
    new_facts = fc.collect(collected_facts)
    assert isinstance(new_facts, dict)
    assert 'fibre_channel_wwn' in new_facts
    assert isinstance(new_facts['fibre_channel_wwn'], list)
    assert '21000014ff52a9bb' in new_facts['fibre_channel_wwn']

# Generated at 2022-06-22 23:52:06.059216
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:52:18.680163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    #  mock module
    module = ansible_mock.Mock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = None

    #  mock platform
    platform = ansible_mock.Mock()
    platform.system.return_value = "NotLinux"

    #  mock collector
    coll = FcWwnInitiatorFactCollector(module=module, platform=platform)
    assert len(coll.collect().keys()) == 0

    #  mock module
    module.run_command.return_value = (0, '/dev/fcd0', '')

# Generated at 2022-06-22 23:52:22.806657
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:52:34.431111
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.hardware.fibre_channel_wwn as test_module
    import os

    # set platform to linux
    os.environ['ANSIBLE_SYS_PLATFORM'] = 'linux'

    # create new instance of FcWwnInitiatorFactCollector
    fcwwnfc = test_module.FcWwnInitiatorFactCollector()

    assert isinstance(fcwwnfc, test_module.FcWwnInitiatorFactCollector)
    assert isinstance(fcwwnfc, BaseFactCollector)

    # create new instance of ansible facts object
    ans_facts = Facts()

# Generated at 2022-06-22 23:52:37.225191
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector is not None


# Generated at 2022-06-22 23:52:41.453790
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:52:50.084782
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in collector._fact_ids
    assert collector.collect() == dict(fibre_channel_wwn=[])

# Run with `python -m testtools.run <file>` or `nosetests --with-doctest <file>`
if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:53:00.166152
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    module_mock = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    collected_facts = {'fibre_channel_wwn': ['0x21000014ff52a9bb']}

    # create a real FcWwnInitiatorFactCollector instance
    fc_collector = FcWwnInitiatorFactCollector(module=module_mock)
    fc_facts = fc_collector.collect()
    assert fc_facts == collected_facts

    # create a FcWwnInitiatorFactCollector instance

# Generated at 2022-06-22 23:53:03.229710
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method is used to test the collect method
    in the FcWwnInitiatorFactCollector class.
    """
    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_fact_collector.collect()

# Generated at 2022-06-22 23:53:12.504376
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec = dict(),
    )
    # list of facts to collect
    facts_to_collect = set('fibre_channel_wwn')
    collector._set_platform_facts(module)
    collected_facts = collector.collect(module=module,
                                        facts_to_collect=facts_to_collect)
    assert type(collected_facts) is dict

# Generated at 2022-06-22 23:53:23.391278
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys

    class MockModule(object):
        def get_bin_path(self, arg, opt_dirs=[]):
            if sys.platform.startswith('linux'):
                if arg == 'fcinfo':
                    return '/usr/sbin/fcinfo'
            if sys.platform.startswith('sunos'):
                if arg == 'fcinfo':
                    return '/usr/sbin/fcinfo'
                if arg == 'prtconf':
                    return ''
            if sys.platform.startswith('hp-ux'):
                if arg == 'ioscan':
                    return '/usr/sbin/ioscan'
                if arg == 'fcmsutil':
                    return '/opt/fcms/bin/fcmsutil'

# Generated at 2022-06-22 23:53:26.921915
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_fact_collector = FcWwnInitiatorFactCollector()
    fact_data = test_fact_collector.collect(collected_facts=None)
    assert fact_data == {}


# Generated at 2022-06-22 23:53:30.641350
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    facts = fc.collect()
    assert facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-22 23:53:36.816110
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit tests using /sys/class/fc_host/*/port_name
    """
    module = None
    fc_facts = set(['fibre_channel_wwn'])
    fc_facts_response = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    fc = FcWwnInitiatorFactCollector(module=module)
    assert (fc.collect() == fc_facts_response)

# Generated at 2022-06-22 23:53:48.245705
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def get_bin_path(arg, opt_dirs=None):
        if arg == "fcinfo":
            return "fcinfo"
        elif arg == "lsdev":
            return "lsdev"
        elif arg == "lscfg":
            return "lscfg"
        else:
            return "ioscan"

    class Options(object):
        def __init__(self, **kwargs):
            self._options = kwargs

        def get(self, name, default=None):
            return self._options.get(name, default)

    # Mock module
    class MockModule(object):
        def get_bin_path(self, arg, opt_dirs=None):
            return get_bin_path(arg, opt_dirs)


# Generated at 2022-06-22 23:53:52.077059
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:53:54.804547
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    print('FcWwnInitiatorFactCollector: %s' % fc.collect())

# Generated at 2022-06-22 23:54:00.810436
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    fake_module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    FcWwnInitiatorFactCollector.collect(fake_module)
    assert FcWwnInitiatorFactCollector.name in collector.FactsCollector.collected_facts

# Generated at 2022-06-22 23:54:09.643903
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.hardware.fc import FcWwnInitiatorFactCollector

    fc_fact_collector = FcWwnInitiatorFactCollector()

    collected_facts = Collector().collect(module=None, collectors=[fc_fact_collector])
    assert collected_facts['fibre_channel_wwn'] == ["10000090FA1658DE", "10000090FA551509"]

# Generated at 2022-06-22 23:54:14.318553
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    # on linux the following is an invalid assumption
    #assert 'fibre_channel_wwn' not in collector.collect()
    # on solaris or aix the following should be True if the system has fc adapters
    #assert collector.collect() == { "fibre_channel_wwn": [] }

# Generated at 2022-06-22 23:54:27.142163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector

    # create a get_file_lines mock for /sys/class/fc_host/*/port_name
    # and set a test content
    import mock
    get_file_lines = mock.Mock(wraps=collector.get_file_lines)

    def fake_get_file_lines(file):
        if file == '/sys/class/fc_host/fc_host0/port_name':
            return ['0x21000014ff52a9bb', '0x21000014ff52a9bc', ]
        elif file == '/sys/class/fc_host/fc_host1/port_name':
            return ['0x21000014ff52a9bd']

# Generated at 2022-06-22 23:54:39.121482
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule():
        def get_bin_path(self, arg1, opt_dirs=None):
            if arg1 == 'fcinfo':
                return '/usr/bin/fcinfo'
            if arg1 == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            if arg1 == 'ioscan':
                return '/usr/bin/ioscan'
            if arg1 == 'lscfg':
                return 'lscfg'
            if arg1 == 'lsdev':
                return 'lsdev'

        def run_command(self, arg1):
            return 0,'','error'
    class MockFactCollector():
        _fact_ids = set()
    # example data taken from linux

# Generated at 2022-06-22 23:54:41.440040
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == "fibre_channel_wwn"


# Generated at 2022-06-22 23:54:43.744980
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:54:56.130640
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

    for fc_fact in fc_facts:
        fc_facts[fc_fact] = '0x0000000000000000'

    #define test values
    fc_facts['fibre_channel_wwn'] = ['10000090fa1658de', '10000090fa551509']

    from ansible.module_utils.facts.collector import BaseFactCollector
    class mock_module():
        def __init__(self):
            self.params = {}
            self.run_command = mock_module.run_command
        @classmethod
        def run_command(cls, cmd):
            return 0, '', ''


# Generated at 2022-06-22 23:55:06.124353
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ Unit test for constructor of class FcWwnInitiatorFactCollector """

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.hardware.fc_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    # Create an instance of Collector
    test_collector = Collector()

    # Create an instance of FcWwnInitiatorFactCollector
    test_fcwwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    # Test if test_fcwwn_initiator_fact_collector is an instance of Collector
    assert isinstance(test_fcwwn_initiator_fact_collector, Collector)

    #

# Generated at 2022-06-22 23:55:11.865435
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-22 23:55:16.450548
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method will test if the fact collector collect method will collect
    the facts related with fibre channel wwn initiators
    """
    f = FcWwnInitiatorFactCollector()
    result = f.collect()
    assert result is not None

# Generated at 2022-06-22 23:55:28.146196
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    class MockSystem:
        """
        Mocking the system platform.

        :returns: 'linux'
        """
        def __init__(self):
            self.platform = 'linux'

    class MockModule:
        """
        Mocking the module class.

        :returns: out, err, rc from executing the command.
        """
        def __init__(self):
            self.run_command_out = 0
            self.run_command_err = ''
            self.run_command_rc = 0
            self.run_command_data = 0


# Generated at 2022-06-22 23:55:32.666783
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ Unit test for constructor of class FcWwnInitiatorFactCollector """
    # TODO: make use of the fact collector registry
    fw = FcWwnInitiatorFactCollector()
    # check its name
    assert fw.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:34.372313
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Initialize the class
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    # Check the name is set to fibre_channel_wwn
    assert fc_wwn_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:41.939691
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test case that instantiates the FcWwnInitiatorFactCollector class."""

    assert issubclass(FcWwnInitiatorFactCollector, BaseFactCollector)
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:55:45.169187
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'