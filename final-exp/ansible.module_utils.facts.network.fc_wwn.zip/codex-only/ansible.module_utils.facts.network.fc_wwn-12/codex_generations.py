

# Generated at 2022-06-22 23:45:43.799102
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print('UnitTest: test_FcWwnInitiatorFactCollector() ..')
    fcl_fact = FcWwnInitiatorFactCollector()
    assert fcl_fact.name == 'fibre_channel_wwn'
    print('UnitTest: OK')

# Generated at 2022-06-22 23:45:56.642660
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Simple test of method collect
    # fc_fact_collector = FcWwnInitiatorFactCollector()
    class ModuleMock():
        # module.run_command()
        def run_command(self, cmd):
            return 0, """            N_Port Port World Wide Name = 0x50060b00006975ec""", ''

        # module.get_bin_path()
        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd

    fc_facts = FcWwnInitiatorFactCollector().collect(module=ModuleMock())
    # one WWN should be found
    assert ('fibre_channel_wwn' in fc_facts), "fibre_channel_wwn-fact not found"

# Generated at 2022-06-22 23:46:07.835811
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test FcWwnInitiatorFactCollector.collect method.
    """
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.collectors import which
    from ansible.module_utils.facts.collectors.platform.dist import (BaseDistFactCollector,
                                                                     DistFactCollector)
    from ansible.module_utils.facts.collectors.system.distribution import DistributionFactCollector
    import os
    import sys
    import platform

    # Create an instance of AnsibleFactCollector
    afc = AnsibleFactCollector()
    # register collectors
    afc.register_collector(DistributionFactCollector)
    afc.register_collector(DistFactCollector)

# Generated at 2022-06-22 23:46:12.956052
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    fact_collector = get_collector_instance("fibre_channel_wwn")
    assert isinstance(fact_collector, FcWwnInitiatorFactCollector) == True
    assert isinstance(fact_collector, BaseFactCollector) == True
    assert fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:46:24.102157
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test data
    class Module:
        def get_bin_path(self, cmd):
            return cmd
        def run_command(self, cmd):
            if "ioscan" in cmd:
                return 0, "  fcd  1 0/4/8/4.4.0.0.0  sdisk CLAIMED  DEVICE  HP   1000000090FC2A99 /dev/fcd/fcd0\n  fcd  2 0/4/8/4.4.0.1.0  sdisk CLAIMED  DEVICE  HP   1000000090FC2A9A /dev/fcd/fcd1", ""

# Generated at 2022-06-22 23:46:32.561651
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts
    import ansible.module_utils.facts.collector
    import sys
    import os
    os.environ['LINUX_WWN_TEST'] = "aix"

# Generated at 2022-06-22 23:46:33.141421
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:46:37.497565
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-22 23:46:40.196796
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert not c._fact_ids

# Generated at 2022-06-22 23:46:44.632427
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-22 23:46:55.441579
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import modules.facts.fibre_channel_wwn as fcwwn_facts
    class MockModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, name, opt_dirs=[]):
            return name

    mock_module = MockModule()
    fc_facts = fcwwn_facts.FcWwnInitiatorFactCollector(mock_module)
    platform = sys.platform
    if 'linux' in platform:
        fc_out = fc_facts.collect()
        fc_wwn = fc_out['fibre_channel_wwn']
        assert len(fc_wwn) > 0
        assert isinstance(fc_wwn, list)

# Generated at 2022-06-22 23:47:00.509626
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn', "'name' is '%s' and not 'fibre_channel_wwn' as expected." % fc_fact_collector.name

# Generated at 2022-06-22 23:47:04.934934
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_module = FcWwnInitiatorFactCollector()
    assert fact_module.name == 'fibre_channel_wwn', \
        "Test for constructor of class FcWwnInitiatorFactCollector failed."

# Generated at 2022-06-22 23:47:08.590030
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_collector = FcWwnInitiatorFactCollector()
    assert isinstance(facts_collector, FcWwnInitiatorFactCollector)


# Generated at 2022-06-22 23:47:10.204339
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    FcWwnInitiatorFactCollector().collect(module=module)
    assert type(FcWwnInitiatorFactCollector().collect()) == dict

# Generated at 2022-06-22 23:47:13.263774
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factcoll = FcWwnInitiatorFactCollector()
    # check if correct name
    assert 'fibre_channel_wwn' == factcoll.name


# Generated at 2022-06-22 23:47:26.035752
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def get_file_lines_mock(file_name):
        wwn_data = [
            '0x21000014ff52a9bb',
            ]
        class MockFile:
            def __init__(self, data):
                self.data = data
            def __enter__(self):
                return self
            def __exit__(self, type, value, traceback):
                return False
            def readlines(self):
                return self.data

        if 'fc_host' in file_name:
            return MockFile(wwn_data)
        else:
            raise IOError

    # TODO: implement this test at all
    # x = FcWwnInitiatorFactCollector()
    # x._get_file_lines = get_file_lines_mock
    # assert x.collect() ==

# Generated at 2022-06-22 23:47:38.992555
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    module = sys.modules[__name__]
    fact_collector = FcWwnInitiatorFactCollector()

    if sys.platform.startswith('linux'):
        fc_facts = {}
        fc_facts['fibre_channel_wwn'] = []
        for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
            for line in get_file_lines(fcfile):
                fc_facts['fibre_channel_wwn'].append(line.rstrip()[2:])
        assert fc_facts['fibre_channel_wwn'] == fact_collector.collect()['fibre_channel_wwn']


# Generated at 2022-06-22 23:47:43.560553
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test case 1:
    #   - no fact_list
    # Objective:
    #   - ensure that fact_list is initialized to []
    fact_collector = FcWwnInitiatorFactCollector()
    fact_list = fact_collector.collect()
    assert fact_list == []

# Generated at 2022-06-22 23:47:55.728284
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for FcWwnInitiatorFactCollector.collect
    """
    # import python modules used here so that it works on Windows too
    import sys
    import unittest
    import platform

    if platform.system() != 'SunOS':
        raise unittest.SkipTest("Solaris only test")

    module = sys.modules['ansible.module_utils.facts.collector.network.fibre_channel_wwn']
    FcWwnInitiatorFactCollector = module.FcWwnInitiatorFactCollector
    facts = FcWwnInitiatorFactCollector.collect()
    assert facts['fibre_channel_wwn'][0] == '21000014FF52A9BB'

# Generated at 2022-06-22 23:47:57.258904
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()


# Generated at 2022-06-22 23:48:02.285968
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    _, module = get_test_data()
    collector = FcWwnInitiatorFactCollector(module=module)
    ans = collector.collect()
    assert ans['fibre_channel_wwn'] == [u'21000014ff52a9bb']


# Generated at 2022-06-22 23:48:06.174900
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert type({}) is type(fc_wwn_initiator_fact_collector.collect())

# Generated at 2022-06-22 23:48:08.326710
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert(FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn')
    assert(FcWwnInitiatorFactCollector.filename == None)

# Generated at 2022-06-22 23:48:12.247248
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    test_facts = FcWwnInitiatorFactCollector.collect()
    for key in test_facts.keys():
        assert test_facts[key] != []

# Generated at 2022-06-22 23:48:20.320573
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # make a mock module
    module = type('module', (), dict())
    module.get_bin_path = lambda x,y: '/bin/%s' % x
    module.run_command = lambda x: (0, "", "")
    # test no facts
    f = FcWwnInitiatorFactCollector(module=module)
    assert f.collect(module=module)['fibre_channel_wwn'] == []

# Generated at 2022-06-22 23:48:22.561128
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == "fibre_channel_wwn"


# Generated at 2022-06-22 23:48:25.646592
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    assert o.name == 'fibre_channel_wwn'
    assert o._fact_ids == set()

# Generated at 2022-06-22 23:48:28.923927
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert len(fc_facts._fact_ids) == 0

# Generated at 2022-06-22 23:48:33.910647
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert fcWwnInitiatorFactCollector is not None
    assert fcWwnInitiatorFactCollector.name == "fibre_channel_wwn"

# Generated at 2022-06-22 23:48:39.333396
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import \
        FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils._text import to_bytes

    class NewModule:
        def get_bin_path(self, _, opt_dirs=None):
            return '/bin/true'

        def run_command(self, _):
            return 0, to_bytes(os.linesep.join(['HBA Port WWN: 10000090fa1658de', 'HBA Port WWN: 10000090fa1658df', 'HBA Port WWN: 10000090fa1658dg'])), ''

    new_module = NewModule()

# Generated at 2022-06-22 23:48:42.753998
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    assert collector.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-22 23:48:55.190224
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.system.fibre_channel_wwn import get_fibre_channel_wwn_facts
    from ansible.module_utils.facts.system.fibre_channel_wwn import populate_facts

    # Create instance of FcWwnInitiatorFactCollector
    fcwwnfc = FcWwnInitiatorFactCollector()

    # Create instance of FactCollector

# Generated at 2022-06-22 23:48:57.360172
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:02.120420
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:04.609165
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FACTS = {u'fibre_channel_wwn': [u'21000024ff52a9bb']}
    FcWwnInitiatorFactCollector.fetch_all()
    assert FcWwnInitiatorFactCollector.get_fact_ids() == {u'fibre_channel_wwn'}
    assert FcWwnInitiatorFactCollector.collect() == FACTS

# Generated at 2022-06-22 23:49:07.362306
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    # returns dict()
    fact_collector.collect(collected_facts=dict())

# Generated at 2022-06-22 23:49:13.153221
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test input
    module = type('DummyModule', (object,), {})
    module.run_command = lambda cmd: (0, cmd, None)
    module.get_bin_path = lambda name, opt_dirs=None: name
    # run collect method
    fc = FcWwnInitiatorFactCollector()
    ansible_facts = {}
    # Test for linux
    sys.platform = 'linux'
    linux_facts = fc.collect(module, ansible_facts)
    # Test for sunos
    sys.platform = 'sunos'
    sunos_facts = fc.collect(module, ansible_facts)
    # Test for aix
    sys.platform = 'aix'
    aix_facts = fc.collect(module, ansible_facts)
    # Test for

# Generated at 2022-06-22 23:49:14.207687
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:49:26.701944
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector

    module = Mock()

    # find fcinfo executable
    module.get_bin_path.side_effect = [ True, 'fcinfo' ]

    # run fcinfo command and return valid output

# Generated at 2022-06-22 23:49:31.447451
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-22 23:49:38.411971
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids is not None
    fcww_factcol = FcWwnInitiatorFactCollector()
    assert fcww_factcol.name == 'fibre_channel_wwn'
    assert fcww_factcol._fact_ids is not None

# Generated at 2022-06-22 23:49:41.893209
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids == set()

# Generated at 2022-06-22 23:49:46.305101
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test the constructor of FcWwnInitiatorFactCollector
    """
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:49:51.736267
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    _FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert _FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert _FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-22 23:49:52.814740
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert True


# Generated at 2022-06-22 23:50:05.459914
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()

    """
    Example contents /sys/class/fc_host/*/port_name:

    0x21000014ff52a9bb

    """
    class FakeModule(object):
        def __init__(self, platform, get_bin_path_returns):
            self.platform = platform
            self.get_bin_path_returns = get_bin_path_returns

        def get_bin_path(self, name, opt_dirs=[]):
            """
            Fake get_bin_path method
            """
            return self.get_bin_path_returns.get(name)

        def run_command(self, cmd):
            """
            Fake run_command method
            """

# Generated at 2022-06-22 23:50:09.312045
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fact_collector._fact_ids

# Generated at 2022-06-22 23:50:12.177273
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass  # TODO

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:50:25.388524
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.collector import CollectorsManager

    # collect fibre_channel facts
    FcWwnInitiatorFactCollector = get_collector_instance('FcWwnInitiatorFactCollector')
    fc_dict = FcWwnInitiatorFactCollector.collect()
    # check if the returned list is empty
    assert len(fc_dict['fibre_channel_wwn']) > 0

    # check if the method collect of class FcWwnInitiatorFactCollector rules
    # if a valid fibre_channel device is attached
    FcWwnInitiatorFactCollector = get_collect

# Generated at 2022-06-22 23:50:28.951705
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    fc = FcWwnInitiatorFactCollector(None)
    fc = fc.collect()
    print(fc)


# Generated at 2022-06-22 23:50:32.938230
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:50:36.602732
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.collect() == {}

# Generated at 2022-06-22 23:50:47.893633
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # get file to read a dictionary of facts.
    sys.path.append('/mnt/play/workspace/ansible/ansible_devel/lib/ansible/module_utils/facts/')
    mod_utils = __import__('module_utils')
    fact_utils = __import__('facts.utils')
    # initialize fact collector
    fact_collector = FcWwnInitiatorFactCollector()
    # load platform specific module_utils if needed

# Generated at 2022-06-22 23:50:51.007697
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn', "Failed to set name"

# Generated at 2022-06-22 23:50:55.352214
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-22 23:51:05.337601
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.solaris import SolarisNetworkCollector
    sys.modules['ansible.module_utils.facts.collector.network.LinuxNetworkCollector'] = LinuxNetworkCollector
    sys.modules['ansible.module_utils.facts.collector.network.SolarisNetworkCollector'] = SolarisNetworkCollector
    from ansible.module_utils.facts import collector


# Generated at 2022-06-22 23:51:17.010296
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    mock_module = Mock()
    mock_module.get_bin_path = MagicMock(return_value=True)
    mock_module.run_command = MagicMock(return_value=(0, "", ""))
    collected_facts = {}
    collector = FactCollector(module=mock_module, collected_facts=collected_facts)

    test_collector = FcWwnInitiatorFactCollector(collector=collector,
                                                 collected_facts=collected_facts)
    test_collector.collect(module=mock_module, collected_facts=collected_facts)

    mock_module.run_command.assert_called_with('fcsutil')

# Generated at 2022-06-22 23:51:27.691783
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # mock the module arguments
    module_args = {}

    # get the target class
    target_class = sys.modules[__name__]

    # get the class name
    target_class_name = target_class.__name__

    # create a instance of FcWwnInitiatorFactCollector class
    fwc = FcWwnInitiatorFactCollector()

    # run the collect method
    fc_facts = fwc.collect(module_args)

    # check if method returns a dict
    assert isinstance(fc_facts, dict), "Failed to create a dictionary"
    assert fc_facts['fibre_channel_wwn'], "Empty list of fibre_channel_wwn"

# Generated at 2022-06-22 23:51:32.256209
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.collect.__name__ == 'collect'

# Generated at 2022-06-22 23:51:38.346451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ tests the collect method of FcWwnInitiatorFactCollector """
    collector = FcWwnInitiatorFactCollector()
    # for now just test if exception is thrown for unsupported platforms
    if sys.platform.startswith('win'):
        import pytest
        with pytest.raises(Exception) as excinfo:
            facts = collector.collect()
            assert 'unsupported' in str(excinfo.value)

# Generated at 2022-06-22 23:51:49.328673
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import glob
    import unittest
    import ansible.module_utils
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.utils

    class FakeModule:

        def get_bin_path(self, binary, opt_dirs=[]):
            test_sys_platform = 'linux'
            if test_sys_platform.startswith('linux'):
                if binary == 'fcinfo':
                    return '/usr/sbin/fcinfo'
                if binary == 'lsdev':
                    return '/usr/sbin/lsdev'
                if binary == 'lscfg':
                    return '/usr/sbin/lscfg'

# Generated at 2022-06-22 23:51:54.175801
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn'][0].startswith('21000014ff52a9bb')

# Generated at 2022-06-22 23:51:56.481339
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:51:59.308000
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # instantiate test object
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:52:06.792938
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    # create class object
    try:
        fc = FcWwnInitiatorFactCollector()
    except NameError as err:
        print('Error: %s' % err)
        return 1

    # check if property 'name' exists
    if hasattr(fc, 'name'):
        print("fc.name: %s" % fc.name)
    else:
        print("No attribute: fc.name")
    # check if property '_fact_ids' exists
    if hasattr(fc, '_fact_ids'):
        print("fc._fact_ids: %s" % fc._fact_ids)
    else:
        print("No attribute: fc._fact_ids")


# Generated at 2022-06-22 23:52:09.758962
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:12.446922
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:52:15.123575
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcf = FcWwnInitiatorFactCollector()
    assert fcf.name=='fibre_channel_wwn'

# Generated at 2022-06-22 23:52:28.196899
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    # define some fake sys.platform
    fake_platform = 'linux'
    real_platform = sys.platform
    sys.platform = fake_platform

    # get an instance of the FcWwnInitiatorFactCollector object
    fci_fc = get_collector_instance(FcWwnInitiatorFactCollector)

    # generate some fake data
    fake_data = """
0x21000014ff52a9bb
0x21000014ff52a9bc
"""

    # mock get_file_lines() method
    def get_file_lines_mock(file_name):
        return fake_data.splitlines()

    # patch get_file_lines() method

# Generated at 2022-06-22 23:52:29.949896
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-22 23:52:34.057588
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    mock_module = MockModule()
    fact_collector = FcWwnInitiatorFactCollector()
    fact_collector.collect(module=mock_module)

# Unit test - all possible outcomes of the collect method
# of class FcWwnInitiatorFactCollector
#

# Generated at 2022-06-22 23:52:47.087667
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector, cache
    from ansible.module_utils._text import to_bytes
    import tempfile
    import os

    # create tmp test files
    (
        file_handle,
        linux_facts_file_name
    ) = tempfile.mkstemp(dir='/tmp/')
    os.close(file_handle)
    os.remove(linux_facts_file_name)

    # create dummy test facts dictionary
    collected_facts = dict()
    module = basic.AnsibleModule(
        argument_spec=dict(),
    )
    cache.fact_cache = dict()

    # call FcWwnInitiatorFactCollector method collect
    col = collector.get_collector('fibre_channel_wwn')

# Generated at 2022-06-22 23:52:50.294506
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in collector.collect({}).keys()

# Generated at 2022-06-22 23:53:00.329554
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import os
    import platform
    import sys

    class RunCommand(object):
        def __init__(self, module):
            self.module = module

        def run_command(self, cmd, check_rc=False):
            return (0, None, None)

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary in ['fcinfo', 'lscfg', 'ioscan', 'fcmsutil']:
                return binary
            return None

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    module.run_command

# Generated at 2022-06-22 23:53:02.749515
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn'
    assert fc_fact.collect() == {}

# Generated at 2022-06-22 23:53:04.608941
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-22 23:53:09.845402
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    result = fcwwn_fact_collector.collect()
    assert result == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-22 23:53:21.502456
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    import ansible_collections.ansible.misc.plugins.module_utils.facts.collectors.network.fibre_channel_wwn as module_under_test

    module_under_test.glob = glob.glob
    module_under_test.sys = sys
    module_under_test.get_file_lines = get_file_lines

    with basic.mocked_object(module_under_test, "get_bin_path", return_value="Foo"):
        with basic.mocked_object(module_under_test, "run_command", return_value=(0, "", "" )):
            FcWwnInitiatorFactCollector = module_under_test.FcWwnInitiatorFactCollector()
            result = FcWwnIniti

# Generated at 2022-06-22 23:53:25.442339
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector != None, ("Failed to instantiate FcWwnInitiatorFactCollector class")

# Generated at 2022-06-22 23:53:36.464701
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector

    """

    class ModuleStub(object):
        def __init__(self, cmd, opt_dirs):
            self.cmd = cmd
            self.opt_dirs = opt_dirs
            if cmd == 'fcinfo':
                if opt_dirs:
                    if opt_dirs[0] == '/opt/fcms/bin':
                        self.stdout = '''
                            HBA Port WWN: 10000090fa1658de
                            HBA Driver: fcmh
                            HBA Host Name: host1
                            HBA Host Port: fcd0
                        '''
                        self.rc = 0
                        self.stderr = ''
                    else:
                        self.stdout = ''
                        self.rc = 1


# Generated at 2022-06-22 23:53:41.115966
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fw = FcWwnInitiatorFactCollector()
    assert fw.name == 'fibre_channel_wwn'
    assert fw._fact_ids == set()

# Generated at 2022-06-22 23:53:43.300569
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-22 23:53:54.454294
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  # Test with fc_host directory
  FC_HOST_DIRECTORY = [
    '/sys/class/fc_host/host0/port_name',
    '/sys/class/fc_host/host15/port_name'
  ]

  # Test with fcinfo command
  FCINFO_COMMAND = [
    '',
    'HBA Port WWN: 10000090fa1658de',
    'HBA Port WWN: 20000090fa1658de',
    'HBA Port WWN: 10000090fa1658de',
    ''
  ]

  fact_collector = FcWwnInitiatorFactCollector()
  facts = fact_collector.collect({}, {})
  assert not facts

  # test with /sys/class/fc_host directory
  fact_collector = F

# Generated at 2022-06-22 23:53:58.005656
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_initiator = FcWwnInitiatorFactCollector()
    assert fc_initiator.name == 'fibre_channel_wwn'


# Generated at 2022-06-22 23:54:09.753094
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import collector
    # Create a dummy Ansible module object
    ansible_module = type('AnsibleModule', (object,), {'params': {}})
    # Create a dummy Ansible module
    m = collector.get_host_facts(ansible_module)
    fc_facts = FcWwnInitiatorFactCollector().collect(module=ansible_module, collected_facts=m)
    assert len(fc_facts) == 0 or type(fc_facts) == dict
    if sys.platform.startswith('linux'):
        assert len(fc_facts['fibre_channel_wwn']) > 0

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-22 23:54:14.398654
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)
    assert isinstance(FcWwnInitiatorFactCollector.name, str)

# Generated at 2022-06-22 23:54:15.344974
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-22 23:54:27.912546
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import tempfile
    sys.path.append(os.path.join(os.getcwd(),'../../','lib/'))
    from ansible.module_utils.facts.collectors import which
    from ansible.module_utils.facts import ModuleFileParser
    try:
        import json
    except ImportError:
        import simplejson as json
    def write_fchost(path, wwn):
        with open(path, "w") as f:
            f.write(wwn)
    if sys.platform.startswith('linux'):
        (handle, tmpdir) = tempfile.mkstemp(dir="/tmp")
        os.close(handle)
        os.makedirs(os.path.join(tmpdir, 'sys/class/fc_host/'))


# Generated at 2022-06-22 23:54:32.165078
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    This is a functional test for the constructor of FcWwnInitiatorFactCollector
    """
    my_collector = FcWwnInitiatorFactCollector()
    assert my_collector.name == 'fibre_channel_wwn'
    assert my_collector._fact_ids == set()


# Generated at 2022-06-22 23:54:44.398660
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    unittest for FcWwnInitiatorFactCollector collect
    """

    class MyModule:
        def __init__(self):
            pass
        def get_bin_path(self, cmd, opt_dirs=[]):
            if 'lsdev' == cmd:
                return './lsdev'
            elif 'lscfg' == cmd:
                return './lscfg'
            elif 'ioscan' == cmd:
                return './ioscan'
            elif 'fcmsutil' == cmd:
                return './fcmsutil'
            else:
                return cmd

    class ModuleStub:
        def __init__(self, module, command, rc, out, err):
            self.module = module
            self.command = command
            self.rc = rc
            self.out

# Generated at 2022-06-22 23:54:49.422833
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() is None
    assert fc.collect().has_key('fibre_channel_wwn')

# Generated at 2022-06-22 23:54:59.806437
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # this test actually runs `fcinfo hba-port` on solaris 10 and solaris 11
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    fcwwn_facts = FcWwnInitiatorFactCollector.collect(module)
    assert fcwwn_facts


# ===========================================
# Main
#
# args[0] - has to be a json filename
#
# For example:
#
#      ansible_facts_fibre_channel_wwn_collected.json
#
# ===========================================
#


# Generated at 2022-06-22 23:55:02.853088
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()

# Generated at 2022-06-22 23:55:15.001641
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import FactsView
    from ansible.module_utils.facts.utils import get_file_lines
    orig_len = len(sys.path)

# Generated at 2022-06-22 23:55:17.710776
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-22 23:55:21.066078
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-22 23:55:21.711910
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  pass

# Generated at 2022-06-22 23:55:24.859490
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.__class__.__name__ == 'FcWwnInitiatorFactCollector'

# Generated at 2022-06-22 23:55:28.837778
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"
    assert fc._fact_ids == set(['fibre_channel_wwn'])


# Generated at 2022-06-22 23:55:40.306973
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    import platform
    test_platform = platform.system()
    if test_platform == 'Linux':
        fc_collector = FcWwnInitiatorFactCollector()
        fc_facts = fc_collector.collect()
        assert 'fibre_channel_wwn' in fc_facts
        assert len(fc_facts['fibre_channel_wwn']) > 0
        assert isinstance(fc_facts['fibre_channel_wwn'], list)
        for fc_name in fc_facts['fibre_channel_wwn']:
            assert isinstance(fc_name, str)
            assert len(fc_name) == 16
