

# Generated at 2022-06-17 00:43:23.777681
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure

    # get list of available collectors
    collectors = list_collectors()
    assert 'fibre_channel_wwn' in collectors

    # get instance of FcWwnInitiatorFactCollector
    fc_collector = get_collector_instance('fibre_channel_wwn')
    assert isinstance(fc_collector, FcWwnInitiatorFactCollector)

    # get list of available fact_ids
   

# Generated at 2022-06-17 00:43:34.190328
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorException
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_exceptions
    from ansible.module_utils.facts.collector import get_collector_exception_instances
    from ansible.module_utils.facts.collector import get_collector_exception_names
    from ansible.module_utils.facts.collector import list

# Generated at 2022-06-17 00:43:36.803740
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:43:41.574496
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    # create a Collector object
    test_collector = Collector()

    # create a FcWwnInitiatorFactCollector object
    test_FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()

    # create a AnsibleFactCollector object
    test_ansible_fact_collector_obj = AnsibleFactCollector(
        collectors=[test_FcWwnInitiatorFactCollector_obj],
        namespace='ansible_local'
    )

    # call method collect of

# Generated at 2022-06-17 00:43:48.819246
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    # create a Collector object
    test_collector = Collector()
    # create a FcWwnInitiatorFactCollector object
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector(test_collector)

    # test collect method
    # test on Linux
    if sys.platform.startswith('linux'):
        # create a list of file names
        test_file_list = []

# Generated at 2022-06-17 00:43:59.003403
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_device

# Generated at 2022-06-17 00:44:07.602639
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_cmd_output
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_cmd

# Generated at 2022-06-17 00:44:14.060123
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:44:25.499114
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import sys
    import tempfile
    import unittest

    class TestAnsibleFactCollector(AnsibleFactCollector):
        """
        Class for testing AnsibleFactCollector
        """

# Generated at 2022-06-17 00:44:34.018233
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'network']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'


# Generated at 2022-06-17 00:44:55.692275
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []
            self.run_command_results = []
            self.run_command_rcs = []
            self.run_command_exceptions = []
            self.get_bin_path_calls = []
            self.get_bin_path_results = []
            self.get_bin_path_exceptions = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            if self.run_command_exceptions:
                raise self.run_command_exceptions.pop(0)

# Generated at 2022-06-17 00:45:01.261418
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:45:14.207991
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    import sys
    import os
    import tempfile
    import shutil
    import stat
    import json
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_facts

# Generated at 2022-06-17 00:45:16.611364
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:21.554061
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:28.633711
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return './fcinfo'

# Generated at 2022-06-17 00:45:39.714438
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # create a Collector object
    test_collector = Collector()
    # add FcWwnInitiatorFactCollector to the list of collectors
    test_collector.add_collector(FcWwnInitiatorFactCollector())
    # create a AnsibleFactCollector object

# Generated at 2022-06-17 00:45:50.973961
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []
            self.run_command_results = []
            self.run_command_rcs = []
            self.run_command_exceptions = []
            self.run_command_exception_tracebacks = []
            self.get_bin_path_calls = []
            self.get_bin_path_results = []
            self.get_bin_path_exceptions = []
            self.get_bin_path_exception_tracebacks = []


# Generated at 2022-06-17 00:45:57.048776
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:46:06.643067
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get

# Generated at 2022-06-17 00:46:35.247394
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)

# Generated at 2022-06-17 00:46:45.712636
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg, opt_dirs=[]):
            return arg
        def run_command(self, arg):
            return (0, '', '')
    dummy_module = DummyModule()
    # create a dummy collector
    fc_collector = FcWwnInitiatorFactCollector()
    # run the collect method
    fc_facts = fc_collector.collect(dummy_module)
    # check the result
    assert fc_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-17 00:46:50.622528
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:46:56.522965
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:47:01.731548
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:47:13.680567
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_gid

# Generated at 2022-06-17 00:47:17.853407
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:47:29.541740
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.system.fibre_channel_wwn import test_FcWwnInitiatorFactCollector_collect
    from ansible.module_utils.facts.system.fibre_channel_wwn import test_FcWwnInitiatorFactCollector_collect_aix
    from ansible.module_utils.facts.system.fibre_channel_wwn import test_FcWwnInitiatorFactCollector_collect_hpux

# Generated at 2022-06-17 00:47:34.734278
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert fc_wwn_initiator_fact_collector.collect() == {}

# Generated at 2022-06-17 00:47:41.628947
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    module = AnsibleModule(argument_spec={})
    # create a dummy class
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # get facts
    facts = fc_wwn_initiator_fact_collector.collect(module=module)
    # check if facts are empty
    assert facts['fibre_channel_wwn'] != []

# Generated at 2022-06-17 00:48:35.307108
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_cmd_output
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_cmd_output
    from ansible.module_utils.facts.utils import get_mount

# Generated at 2022-06-17 00:48:39.162696
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:48:43.704155
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:48:49.568327
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:48:52.393851
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-17 00:49:00.537911
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure

# Generated at 2022-06-17 00:49:12.588691
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import os
    import sys
    import tempfile
    import unittest

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):
        def setUp(self):
            Collector._collectors = []
            Collector.module = None
            Collector.collected_facts = {}
            Collector.warnings = []
            Collector.errors = []
            Collector.skipped = []
            Collector.deprecations = []
            Collector.deprecations_raw = []
            Collector.cache = {}
            Collector.cache_ex

# Generated at 2022-06-17 00:49:15.972072
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:49:18.303339
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:49:21.816214
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:51:02.857741
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:51:13.094225
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 00:51:16.634797
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:51:22.221529
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:51:27.188583
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:51:29.886466
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:51:33.300895
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-17 00:51:36.845872
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-17 00:51:39.509093
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-17 00:51:50.189109
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import os
    import tempfile
    import shutil
    import json

    class MockModule(object):
        def __init__(self, platform):
            self.platform = platform
            self.params = {}
            self.bin_path = '/bin'
            self.tmpdir = tempfile.mkdtemp()

        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'fcinfo':
                return os.path.join(self.bin_path, cmd)
            elif cmd == 'lsdev':
                return os.path.join(self.bin_path, cmd)
            elif cmd == 'lscfg':
                return os.path.join(self.bin_path, cmd)