

# Generated at 2022-06-17 00:43:28.596616
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # get list of all available collectors
    collectors = list_collectors()
    assert 'fibre_channel_wwn' in collectors

    # get list of all available fact_ids
    fact_ids = get_collector_names(collectors)
    assert 'fibre_channel_wwn' in fact_ids

    # get instance of FcWwnInitiatorFactCollector
    fc_

# Generated at 2022-06-17 00:43:39.006082
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_number
    from ansible.module_utils.facts.utils import get_file_is_a_directory
    from ansible.module_utils.facts.utils import get_file_is_a_file

# Generated at 2022-06-17 00:43:49.711428
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time

# Generated at 2022-06-17 00:43:59.971741
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import sys
    import tempfile
    import shutil
    import glob
    import json

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a file in the temporary directory
    fc_file = os.path.join(tmpdir, "fc_host_port_name")
    f = open(fc_file, 'w')

# Generated at 2022-06-17 00:44:08.082242
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_number
    from ansible.module_utils.facts.utils import get_file_is_a_directory
    from ansible.module_utils.facts.utils import get_file_is_a_symlink
   

# Generated at 2022-06-17 00:44:12.476848
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-17 00:44:16.359782
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:44:20.114674
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:44:30.265550
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x: x
    dummy_module = DummyModule()
    # create a dummy collector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # run the collect method
    fc_wwn_initiator_fact_collector.collect(module=dummy_module)

# Generated at 2022-06-17 00:44:42.291259
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return '/usr/sbin/fcinfo'

# Generated at 2022-06-17 00:45:04.639359
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import sys
    import tempfile
    import shutil

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a file in the temporary directory
    (fd, fcfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # write some content to the file
   

# Generated at 2022-06-17 00:45:07.682385
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-17 00:45:12.590476
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:21.704144
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount

# Generated at 2022-06-17 00:45:29.655876
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get

# Generated at 2022-06-17 00:45:33.412990
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:37.674127
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:45:46.273794
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a test object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a test module
    test_module = AnsibleModule(
        argument_spec = dict()
    )
    # run the collect method
    fc_wwn_initiator_fact_collector.collect(module=test_module)
    # check the result
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert fc_wwn_initiator_fact_collector.collect(module=test_module) == {'fibre_channel_wwn': []}

# Unit test

# Generated at 2022-06-17 00:45:58.972347
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file_uid
   

# Generated at 2022-06-17 00:46:03.749448
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:46:32.032056
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:46:35.811584
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:46:38.061009
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:46:43.840038
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:46:53.254298
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # get list of all available collectors
    collectors = list_collectors()
    assert 'fibre_channel_wwn' in collectors

    # get list of all available fact_ids
    fact_ids = get_collector_names()
    assert 'fibre_channel_wwn' in fact_ids

    # get instance of FcWwnInitiatorFactCollector
    fc_wwn_collector = get_collector_instance('fibre_channel_wwn')

# Generated at 2022-06-17 00:46:56.912049
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:47:05.464218
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import sys
    import tempfile
    import shutil
    import glob

    # create temporary directory
    tmpdir = tempfile.mkdtemp()
    # create temporary files
    fc_files = ['fc_host_1_port_name', 'fc_host_2_port_name', 'fc_host_3_port_name']

# Generated at 2022-06-17 00:47:17.360397
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat

# Generated at 2022-06-17 00:47:20.964079
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:47:25.448180
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:48:16.451797
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_fact_collector.name == 'fibre_channel_wwn'
    assert fcwwn_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:48:20.174168
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:48:23.445990
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:48:28.965966
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:48:31.647938
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:48:40.782150
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # create a Collector object
    test_collector = Collector()
    # create a FcWwnInitiatorFactCollector object
    test_fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a AnsibleFactCollector object
    test_ansible_fact_collector = Ans

# Generated at 2022-06-17 00:48:52.709169
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat

# Generated at 2022-06-17 00:49:05.211960
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 00:49:12.341176
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:49:24.767529
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount

# Generated at 2022-06-17 00:51:10.746591
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:51:17.773057
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 00:51:21.432034
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:51:26.682594
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:51:32.116110
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:51:43.190202
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a test object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a test module
    test_module = AnsibleModule(argument_spec={})
    # create a test ansible module
    test_ansible_module = AnsibleModule(argument_spec={})
    # create a test ansible module
    test_ansible_module.run_command = MagicMock(return_value=(0, '', ''))
    # create a test ansible module
    test_ansible_module.get_bin_path = MagicMock(return_value='')
    # create a test ansible module
    test_ansible_module.get_file

# Generated at 2022-06-17 00:51:52.312077
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    module = AnsibleModule(argument_spec={})
    # create a dummy collector
    fc_collector = FcWwnInitiatorFactCollector(module=module)
    # run the collect method
    fc_facts = fc_collector.collect()
    # check if we have a list of WWN
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    # check if we have at least one WWN
    assert len(fc_facts['fibre_channel_wwn']) > 0
    # check if we have a list of WWN
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
   

# Generated at 2022-06-17 00:52:02.567815
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_number
    from ansible.module_utils.facts.utils import get_file_is_a_symlink
    from ansible.module_utils.facts.utils import get_file_is_a_directory
   

# Generated at 2022-06-17 00:52:05.949791
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:52:17.704483
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_checksum