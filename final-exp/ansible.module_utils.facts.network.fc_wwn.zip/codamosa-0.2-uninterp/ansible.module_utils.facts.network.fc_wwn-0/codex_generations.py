

# Generated at 2022-06-17 00:43:18.882347
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:43:27.882428
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 00:43:38.333802
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 00:43:47.695314
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a test object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a test module
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    # create a test ansible_facts
    test_ansible_facts = dict()
    # run the collect method
    test_ansible_facts = fc_wwn_initiator_fact_collector.collect(module=test_module, collected_facts=test_ansible_facts)
    # check the result
    assert 'fibre_channel_wwn' in test_ansible_facts

# Generated at 2022-06-17 00:43:57.611921
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a test class object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a test ansible module object
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    base_fact_collector = BaseFactCollector()
    ansible_module = base_fact_collector.get_ansible_module()
    # run the collect method
    fc_facts = fc_wwn_initiator_fact_collector.collect(ansible_module)
    # check the result
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-17 00:44:07.010213
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorException
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_exception_class
    from ansible.module_utils.facts.collector import get_collector_exception_classes
    from ansible.module_utils.facts.collector import get_collector_exception_class_names

# Generated at 2022-06-17 00:44:12.628680
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:44:24.647616
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob
    import os

    # create a Collector object
    test_collector = Collector()

    # create a FcWwnInitiatorFactCollector object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    # create a AnsibleFactCollector object
    ansible

# Generated at 2022-06-17 00:44:33.687189
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network import NetworkCollector
    from ansible.module_utils.facts.collectors.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # create Collector object
    test_collector = Collector()
    # add NetworkCollector to Collector object
    test_collector.add_collector(NetworkCollector)
    # add FcWwnInitiatorFactCollector to Collector object
    test_collector.add_collector(FcWwnInitiatorFactCollector)
    # call method collect of Collector object

# Generated at 2022-06-17 00:44:44.489596
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    # create a Collector object
    test_collector = Collector()
    # create a FcWwnInitiatorFactCollector object
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector(test_collector)
    # create a test module
    from ansible.module_utils.facts import ModuleTestCase
    test_module = ModuleTestCase.create_ansible_module()

    # test for linux
    sys.platform = 'linux'
    test_

# Generated at 2022-06-17 00:45:02.808904
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    module = AnsibleModule(argument_spec={})
    # create a dummy collector
    fc_wwn_initiator_collector = FcWwnInitiatorFactCollector()
    # call the collect method
    fc_wwn_initiator_collector.collect(module=module)
    # check if the result is as expected
    assert fc_wwn_initiator_collector.collect(module=module) == {'fibre_channel_wwn': []}

# Generated at 2022-06-17 00:45:06.496035
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:45:10.752308
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-17 00:45:16.209064
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:45:26.298834
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file

# Generated at 2022-06-17 00:45:30.315828
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:41.757197
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    # create a Collector object
    test_collector = Collector()

    # create a FcWwnInitiatorFactCollector object
    test_FcWwnInitiatorFactCollector_collector = FcWwnInitiatorFactCollector()

    # create a test module object
    from ansible.module_utils.facts.test_module import TestModule
    test_module = TestModule()

    # set module_utils/facts/utils.get_file_lines to a test function

# Generated at 2022-06-17 00:45:46.519948
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:45:58.972217
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'network']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'


# Generated at 2022-06-17 00:46:09.569701
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif arg == 'lsdev':
                return '/usr/sbin/lsdev'

# Generated at 2022-06-17 00:46:42.087692
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):

        def setUp(self):
            self.collector = FcWwnInitiatorFactCollector()
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)

        def test_collect_linux(self):
            # create test data
            sys.platform = 'linux'
            os.makedirs(os.path.join(self.tmpdir, 'sys', 'class', 'fc_host', 'host0'))

# Generated at 2022-06-17 00:46:52.269131
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # Create an instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # Create an instance of class AnsibleModule
    from ansible.module_utils.facts import ModuleFacts
    module_facts = ModuleFacts()
    # Create an instance of class AnsibleModule
    from ansible.module_utils.facts.collector.network import NetworkCollector
    network_collector = NetworkCollector()
    # Create an instance of class AnsibleModule
    from ansible.module_utils.facts.collector.platform import PlatformFactCollector
    platform_fact_collector = PlatformFactCollector()
    # Create an

# Generated at 2022-06-17 00:46:55.698581
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:46:59.230427
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-17 00:47:10.686506
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_fact_names

    # create instance of FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = get_collector_instance(FcWwnInitiatorFactCollector)

    # create instance of Collector
    collector = Collector()

    # add FcWwnInitiatorFact

# Generated at 2022-06-17 00:47:21.604074
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.utils import get_file_lines

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return '/usr/sbin/fcinfo'

# Generated at 2022-06-17 00:47:26.148185
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-17 00:47:30.231417
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:47:35.623162
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:47:44.182404
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 00:48:32.617222
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:48:41.293597
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 00:48:47.483798
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator._fact_ids == set()
    assert fc_wwn_initiator.collect() == {}

# Generated at 2022-06-17 00:48:52.567588
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:48:59.575914
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:49:03.439522
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:49:13.310418
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'fcinfo':
                return '/usr/sbin/fcinfo'

# Generated at 2022-06-17 00:49:16.893577
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:49:20.542857
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:49:29.261896
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    assert len(fc_facts['fibre_channel_wwn']) > 0
    assert isinstance(fc_facts['fibre_channel_wwn'][0], str)
    assert len(fc_facts['fibre_channel_wwn'][0]) > 0
    assert fc_facts['fibre_channel_wwn'][0].startswith('50060')

# Generated at 2022-06-17 00:51:09.646850
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    module = AnsibleModule(
        argument_spec = dict()
    )
    fc_facts = FcWwnInitiatorFactCollector().collect(module=module)
    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    assert len(fc_facts['fibre_channel_wwn']) > 0
    assert isinstance(fc_facts['fibre_channel_wwn'][0], str)
    assert len(fc_facts['fibre_channel_wwn'][0]) == 16


# Generated at 2022-06-17 00:51:21.715630
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    # create a instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock module
    mock_module = type('AnsibleModule', (object,), dict(params=dict()))
    # create a mock ansible module

# Generated at 2022-06-17 00:51:24.429058
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:51:28.282490
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-17 00:51:33.525483
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:51:36.675862
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-17 00:51:40.328915
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:51:44.941787
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:51:47.671663
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-17 00:51:58.785252
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['gather_network_resources'] = ['all']
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10