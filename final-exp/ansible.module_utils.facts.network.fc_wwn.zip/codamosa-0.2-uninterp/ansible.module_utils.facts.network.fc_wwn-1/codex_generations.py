

# Generated at 2022-06-17 00:43:18.724356
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:43:27.882974
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob
    import os
    import tempfile

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # create a temporary file
    (fd, fcfile) = tempfile.mkstemp(dir=tmpdir)
    # write some data to the temporary file
    os.write(fd, b"0x21000014ff52a9bb\n")
    # close the file descriptor
    os.close(fd)

    # create a temporary file

# Generated at 2022-06-17 00:43:38.338281
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create an instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock module
    module = type('', (), {})()
    # create a mock module.run_command
    module.run_command = type('', (), {})()
    # create a mock module.run_command.return_value
    module.run_command.return_value = (0, '', '')
    # create a mock module.get_bin_path
    module.get_bin_path = type('', (), {})()
    # create a mock module.get_bin_path.return_value

# Generated at 2022-06-17 00:43:49.194970
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/' + arg

        def run_command(self, arg):
            return 0, '', ''

    # create a dummy module
    module = DummyModule()



# Generated at 2022-06-17 00:43:52.308366
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-17 00:44:02.140287
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure

    # create instance of FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = get_collector_instance(FcWwnInitiatorFactCollector)

    # test method collect
    fc_wwn_initiator_fact_collector.collect()

    # test method get_fact_names
    fc_wwn_initiator_fact_collector.get_fact

# Generated at 2022-06-17 00:44:06.605650
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:44:18.533460
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock module
    mock_module = type('AnsibleModule', (object,), dict(params=dict()))
    # create a mock ansible module
    mock_ansible_module = type('AnsibleModule', (object,), dict(
        params=dict(),
        exit_json=dict(),
        fail_json=dict()
    ))
    # set module functions
    mock_module.run_command = lambda *args, **kwargs: (0, '', '')

# Generated at 2022-06-17 00:44:29.558408
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_collector

    ansible_collector.collectors = [FcWwnInitiatorFactCollector()]
    ansible_collector.collectors[0]._platform = 'linux'
    ansible_collector.collectors[0]._sys_class_fc_host_dir = 'tests/unit/module_utils/facts/files/sys/class/fc_host'
    ansible_collector.collectors[0]._sys_class_fc_host_port_name_file = 'port_name'
    ansible_collector.collectors[0]._sys_class_fc_host

# Generated at 2022-06-17 00:44:34.312486
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:44:49.326403
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:44:53.666511
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:45:02.033137
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorException
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_as_lines
    from ansible.module_utils.facts.utils import get_file_content_as_dict

# Generated at 2022-06-17 00:45:09.696199
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert fc_wwn_initiator_fact_collector.collect() == {}

# Generated at 2022-06-17 00:45:20.814235
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get

# Generated at 2022-06-17 00:45:23.022877
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:31.300894
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # test if FcWwnInitiatorFactCollector is in list of available collectors
    assert 'fibre_channel_wwn' in get_collector_names()

    # test if FcWwnInitiatorFactCollector is an instance of Collector
    assert isinstance(get_collector_instance('fibre_channel_wwn'), Collector)

    # test if FcWwnInitiatorFactCollector is in list of available collectors
    assert 'fibre_channel_wwn' in list_

# Generated at 2022-06-17 00:45:41.764652
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # pylint: disable=protected-access
    # pylint: disable=no-self-use
    # pylint: disable=too-many-public-methods
    class MockModule(object):
        """
        Mock class for AnsibleModule
        """
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            """
            fail_json mock
            """
            pass

        def get_bin_path(self, *args, **kwargs):
            """
            get_bin_path mock
            """
            return '/bin/ls'


# Generated at 2022-06-17 00:45:45.753016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:51.900391
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:46:07.012961
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:46:10.599546
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-17 00:46:13.931810
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:46:25.496596
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None
            self.get_bin_path = None

        def run_command(self, cmd):
            return self.run_command(cmd)

        def get_bin_path(self, cmd, opt_dirs=[]):
            return self.get_bin_path(cmd, opt_dirs)

    class MockRunCommand(object):
        def __init__(self):
            self.cmd = None
            self.rc = 0
            self.stdout = None
            self.stderr = None


# Generated at 2022-06-17 00:46:29.559374
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert fc_wwn_initiator_fact_collector.collect() == {}

# Generated at 2022-06-17 00:46:34.612877
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:46:38.106421
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:46:49.669916
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import set_file_lines

    # create a temporary file
    import tempfile
    fd, fcfile = tempfile.mkstemp()

    # write some data to the temporary file
    set_file_lines(fcfile, ['0x21000014ff52a9bb'])

    # create a Collector instance
    c = Collector()

    # create a FcWwnInitiatorFactCollector instance
    fc_wwn_initiator_fc = FcWwnInitiatorFact

# Generated at 2022-06-17 00:46:57.895661
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    module = type('', (), {})()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: x
    # create a dummy collector
    fc_collector = FcWwnInitiatorFactCollector()
    # run the collect method
    fc_facts = fc_collector.collect(module=module)
    # check if the result is what we expect
    assert fc_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-17 00:47:01.452192
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:47:34.850482
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    import sys
    import os
    import unittest

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):
        """
        Unit test for method collect of class FcWwnInitiatorFactCollector
        """
        def setUp(self):
            """
            Setup test environment
            """
            self.fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

        def test_collect_linux(self):
            """
            Test collect method on Linux
            """
            sys.platform = 'linux'
            self.fc_wwn_initiator_fact_collector.collect()

# Generated at 2022-06-17 00:47:41.442292
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    module = AnsibleModule(argument_spec={})
    # create a dummy collector
    fact_collector = FcWwnInitiatorFactCollector(module=module)
    # run the collect method
    facts = fact_collector.collect()
    # check if the facts are empty
    assert facts['fibre_channel_wwn'] == []


# Generated at 2022-06-17 00:47:53.802991
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 00:47:59.590108
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:48:09.246711
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a class object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock module
    mock_module = MockModule()
    # create a mock ansible module
    mock_ansible_module = MockAnsibleModule()
    # get facts
    fc_facts = fc_wwn_initiator_fact_collector.collect(module=mock_module, collected_facts=None)
    # check if facts are empty
    assert not fc_facts
    # check if method run_command was called
    assert mock_ansible_module.run_command.called
    # check if method get_bin_path was called

# Generated at 2022-06-17 00:48:13.453611
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-17 00:48:25.113019
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['gather_network_resources'] = 'no'
            self.params['gather_subset'] = 'all'
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

# Generated at 2022-06-17 00:48:31.145119
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:48:35.121714
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:48:38.677276
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()
    assert fc_facts.collect() == {}

# Generated at 2022-06-17 00:49:38.881767
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock module
    mock_module = type('AnsibleModule', (object,), {'run_command': run_command})
    # create a mock module
    mock_module.get_bin_path = get_bin_path
    # run method collect
    fc_facts = fc_wwn_initiator_fact_collector.collect(module=mock_module)
    # assert if method collect returns a dictionary
    assert isinstance(fc_facts, dict)
    # assert if method collect returns a dictionary with key '

# Generated at 2022-06-17 00:49:42.474136
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:49:46.919196
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:49:53.992651
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collectors
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_collector_

# Generated at 2022-06-17 00:50:00.361556
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:50:11.585972
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'network']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fcinfo':
                return '/usr/sbin/fcinfo'

# Generated at 2022-06-17 00:50:17.587145
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a dummy module
    module = AnsibleModule(argument_spec={})
    # create a dummy collector
    fc_collector = FcWwnInitiatorFactCollector()
    # collect facts
    facts = fc_collector.collect(module)
    # check if facts are collected
    assert facts['fibre_channel_wwn']

# Generated at 2022-06-17 00:50:20.827707
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-17 00:50:25.972683
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # create a test object
    fc_obj = FcWwnInitiatorFactCollector()

    # create a test module
    test_module = AnsibleModule(
        argument_spec = dict()
    )

    # get facts
    fc_facts = fc_obj.collect(module=test_module)

    # check if we have a list of WWN
    assert isinstance(fc_facts['fibre_channel_wwn'], list)


# Generated at 2022-06-17 00:50:36.272815
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import search_file
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 00:52:16.860118
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:52:28.556716
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collector_fact_names
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import get_collector_instance_by_name

# Generated at 2022-06-17 00:52:38.817451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'fibre_channel_wwn']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.run_command_calls = 0
            self.run_command_rcs = []
            self.run_command_outputs = []
            self.run_command_exceptions

# Generated at 2022-06-17 00:52:45.294807
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:52:54.369456
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x: x

    # create a dummy ansible module
    module = DummyModule()

    # create a dummy ansible module
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect(module=module)

# Generated at 2022-06-17 00:52:57.940945
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()
