

# Generated at 2022-06-17 00:43:18.403173
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:43:21.845397
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:43:25.670198
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:43:30.674726
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-17 00:43:36.835673
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:43:39.103832
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:43:44.943308
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:43:52.522283
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd: (0, '', ''),
        'get_bin_path': lambda self, cmd: cmd
    })()
    # run method collect of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector.collect(module=mock_module)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-17 00:44:02.438871
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []
            self.run_command_results = []
            self.run_command_rcs = []
            self.run_command_exceptions = []

        def get_bin_path(self, arg, opt_dirs=[]):
            return arg

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            try:
                result = self.run_command_results.pop(0)
                rc = self.run_command_rcs.pop(0)
            except IndexError:
                raise self.run_command_exceptions.pop(0)

# Generated at 2022-06-17 00:44:09.946959
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = 'all'
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['fact_path'] = None
            self.params['fact_basename'] = None
            self.params['_ansible_version'] = '2.4.3.0'
            self

# Generated at 2022-06-17 00:44:32.142395
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_class_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import list_collector_classes
    from ansible.module_utils.facts.collector import list_collector_class_names
    from ansible.module_utils.facts.collector import list_fact_collectors

# Generated at 2022-06-17 00:44:36.326093
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:44:46.175404
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get

# Generated at 2022-06-17 00:44:53.515509
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector

    # create a Collector instance
    test_collector = Collector()
    # create a FcWwnInitiatorFactCollector instance
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    # add the FcWwnInitiatorFactCollector instance to the Collector instance
    test_collector.add_collector(test_FcWwnInitiatorFactCollector)
    # get facts
    facts = test_collector.collect(module=None, collected_facts=None)
    # test if facts is not empty

# Generated at 2022-06-17 00:44:56.915852
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:45:03.696837
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/' + arg
        def run_command(self, cmd):
            return 0, '', ''
    module = DummyModule()
    # create a dummy collector
    class DummyCollector(object):
        def __init__(self):
            self.facts = {}
    collected_facts = DummyCollector()
    # create a FcWwnInitiatorFactCollector object
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    # run the

# Generated at 2022-06-17 00:45:16.241098
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, name, opt_dirs=[] : '/bin/' + name,
    })()
    # create a mock collected_facts
    mock_collected_facts = {}
    # create a FcWwnInitiatorFactCollector instance
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # run method collect of FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact

# Generated at 2022-06-17 00:45:26.335959
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import FactManager
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import sys
    import tempfile
    import shutil
    import glob
    import json

    # create temporary directory
    tmpdir = tempfile.mkdtemp()
    # create temporary files

# Generated at 2022-06-17 00:45:32.288107
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-17 00:45:42.673952
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob
    import os

    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', 'network']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'


# Generated at 2022-06-17 00:46:13.861532
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    # create a dummy module
    class DummyModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x: x

    # create a dummy module

# Generated at 2022-06-17 00:46:25.495871
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 00:46:29.098303
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:46:33.400915
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:46:43.955543
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import BaseFactCollector

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.exit_json = lambda **kwargs: sys.exit(0)

# Generated at 2022-06-17 00:46:48.349794
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:46:50.905393
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-17 00:47:02.183194
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a test object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a test module
    test_module = AnsibleModule(
        argument_spec = dict()
    )
    # set the module as global var
    fc_wwn_initiator_fact_collector.set_module(test_module)
    # run the collect method
    fc_wwn_initiator_fact_collector.collect()
    # get the facts
    facts = fc_wwn_initiator_fact_collector.get_facts()
    # check if the facts are empty
    assert facts == {}


# Generated at 2022-06-17 00:47:06.265148
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:47:17.979727
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_attributes
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get

# Generated at 2022-06-17 00:47:53.831087
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exception
    from ansible.module_utils.facts.collector import get_collector_exceptions
    from ansible.module_utils.facts.collector import get_collector_instance_

# Generated at 2022-06-17 00:47:58.478743
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:48:07.828553
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 00:48:12.003158
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:48:24.099424
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_checksum
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_access_time

# Generated at 2022-06-17 00:48:28.281288
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:48:37.488502
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create mock module
    mock_module = type('module', (object,), {'run_command': run_command})
    # run method collect
    fc_wwn_initiator_fact_collector.collect(module=mock_module)


# Generated at 2022-06-17 00:48:41.377176
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:48:53.139289
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a dummy module
    module = AnsibleModule(argument_spec={})
    # create a dummy collector
    fc_collector = FcWwnInitiatorFactCollector()
    # call method collect
    fc_facts = fc_collector.collect(module=module)
    # check if we have a list of WWN
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    # check if we have at least one WWN
    assert len(fc_facts['fibre_channel_wwn']) > 0
    # check if we have a valid WWN
    assert len(fc_facts['fibre_channel_wwn'][0]) == 16

# Generated at 2022-06-17 00:48:58.430984
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:49:48.093559
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-17 00:49:51.547990
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:50:03.677283
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 00:50:06.904629
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-17 00:50:10.431287
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:50:17.599956
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # create an instance of the FcWwnInitiatorFactCollector class
    fc_collector = get_collector_instance(FcWwnInitiatorFactCollector)

    # create an instance of the Collector class
    collector = Collector()

    # add the FcWwnInitiatorFactCollector instance to the list of enabled collectors
    collector.add_collector(fc_collector)

    # get the list of enabled collectors
    enabled_collectors = collector.get_enabled_collectors()



# Generated at 2022-06-17 00:50:22.215983
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-17 00:50:26.497796
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a dummy module
    module = AnsibleModule(argument_spec={})
    # create a dummy collector
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    # run the collect method
    fc_wwn_collector.collect(module=module)
    # check the result
    assert fc_wwn_collector.collect(module=module) == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-17 00:50:33.089815
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # create a instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock module
    module = AnsibleModuleMock()
    # get facts
    facts = fc_wwn_initiator_fact_collector.collect(module=module)
    # check if facts are empty
    assert facts == {}


# Generated at 2022-06-17 00:50:41.371171
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    # create a Collector object
    test_collector = Collector()
    # create a FcWwnInitiatorFactCollector object
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    # create a AnsibleFactCollector object
    test_ansible_fact_collector = AnsibleFactCollector()
    # add the FcWwnInitiatorFactCollector object to

# Generated at 2022-06-17 00:52:22.017419
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:52:30.710225
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import sys
    import tempfile
    import shutil

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a file in the temporary directory
    (fd, fcfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # write some content to the file

# Generated at 2022-06-17 00:52:33.675860
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:52:40.050815
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    # create a dummy module
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

# Generated at 2022-06-17 00:52:44.611697
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-17 00:52:54.157130
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_exceptions
    from ansible.module_utils.facts.collector import get_collector_instance_vars
    from ansible.module_utils.facts.collector import get_collector_