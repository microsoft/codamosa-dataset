

# Generated at 2022-06-11 03:15:05.474477
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    import re

    tmp_collection = ansible_collector.get_collection('FcWwnInitiatorFactCollector')
    tmp_collector = tmp_collection.collectors[0]
    facts = tmp_collector.collect()

    for id in facts:
        assert(id in tmp_collector._fact_ids)

    assert(len(facts['fibre_channel_wwn']) == 1)
    assert(re.match('^[0-9A-F]{16}$', facts['fibre_channel_wwn'][0]))

# Generated at 2022-06-11 03:15:15.977064
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_test = FcWwnInitiatorFactCollector()
    # test name
    assert fc_test.name == 'fibre_channel_wwn'
    # test _fact_ids
    assert fc_test._fact_ids
    assert type(fc_test._fact_ids) is set
    # test collect()
    fc_wwn_facts = fc_test.collect()
    assert fc_wwn_facts
    assert type(fc_wwn_facts) is dict
    assert fc_wwn_facts.has_key('fibre_channel_wwn')
    fc_wwn_list = fc_wwn_facts['fibre_channel_wwn']
    assert type(fc_wwn_list) is list

# Generated at 2022-06-11 03:15:18.597533
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert isinstance(x, FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:15:22.695516
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    fact_collector._module = None
    fact_collector._collected_facts = None
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:34.238866
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    with mock.patch('os.path.isfile', return_value=True):
        with mock.patch.object(FcWwnInitiatorFactCollector, 'get_file_lines', return_value=['0x21000014ff52a9bb']):
            new_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
            res = new_FcWwnInitiatorFactCollector.collect()
            assert type(res['fibre_channel_wwn']) is list
            assert len(res['fibre_channel_wwn']) == 1
            assert res['fibre_channel_wwn'][0] == '21000014ff52a9bb'


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-11 03:15:46.489266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import setup_collector_module
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import sys

    if sys.platform.startswith('linux'):
        test_collector = FcWwnInitiatorFactCollector
        test_collector.collect()
        # content of test file /sys/class/fc_host/host0/port_name
        expected = {'fibre_channel_wwn': ['21000014ff52a9bb']}
        assert test_collector.fact_ids == expected.keys()
        assert test_collector.collected_facts == expected

    if sys.platform.startswith('sunos'):
        test_collector = F

# Generated at 2022-06-11 03:15:51.429999
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_expected = {}
    fc_expected['fibre_channel_wwn'] = ['21000014ff52a9bb']
    collector = FcWwnInitiatorFactCollector()
    fc_facts = collector.collect(module=None, collected_facts=None)
    assert fc_facts == fc_expected

# Generated at 2022-06-11 03:15:55.100273
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # noinspection PyUnresolvedReferences
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # noinspection PyUnresolvedReferences
    module = Collector()
    fc_facts = FcWwnInitiatorFactCollector().collect(module=module)
    assert isinstance(fc_facts, dict)

# Generated at 2022-06-11 03:15:57.485317
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-11 03:15:59.824065
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    # assert name of fact
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:27.219531
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    collected_facts = collector.collect()
    # test if the facts is empty or not
    if collected_facts:
        assert collected_facts['fibre_channel_wwn'] != []

# Generated at 2022-06-11 03:16:29.983261
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts is not None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:36.013438
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Validating constructor of FcWwnInitiatorFactCollector class
    """
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-11 03:16:45.815569
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule(object):
        def __init__(self, module_name, bin_path_value, cmd, rc, out, err):
            self.module_name = module_name
            self.bin_path_value = bin_path_value
            self.cmd = cmd
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, module_name, opt_dirs=[]):
            if module_name == self.module_name:
                return self.bin_path_value
            else:
                return None

        def run_command(self, cmd):
            if cmd == self.cmd:
                return self.rc, self.out, self.err
            else:
                return None, None, None

    # no fc adapters

# Generated at 2022-06-11 03:16:48.499824
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    assert(fc_facts.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb']})

# Generated at 2022-06-11 03:16:50.959931
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    fact_collector.collect()

# Generated at 2022-06-11 03:16:56.544905
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    #
    # The following lines generate the required objects to call the method
    # collect.
    #
    class Module:
        def __init__(self):
            self.run_command = lambda cmd: (0, '', '')
            self.get_bin_path = lambda cmd: True

    class FactCollector:
        def __init__(self):
            self.ansible_facts = {'ansible_distribution': 'Debian'}

    module = Module()
    facts = FactCollector()

    #
    # The following line actually invokes the method collect of the class
    # FcWwnInitiatorFactCollector.
    #

# Generated at 2022-06-11 03:16:59.318370
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:01.417596
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:06.086188
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_module
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    fc_collector = FcWwnInitiatorFactCollector()
    fc_collector.collect(module=collector_module())

# Generated at 2022-06-11 03:17:33.432840
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-11 03:17:36.731293
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:17:37.715266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-11 03:17:41.592569
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    facts_collector = FcWwnInitiatorFactCollector()
    assert facts_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:45.527124
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# collect fiber channel WWN from sysfs on Linux

# Generated at 2022-06-11 03:17:52.790366
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''
    Test FcWwnInitiatorFactCollector class.

    >>> from ansible.module_utils.facts.collector import BaseFactCollector
    >>> c = FcWwnInitiatorFactCollector()
    >>> c.name
    'fibre_channel_wwn'
    >>> isinstance(c, BaseFactCollector)
    True
    '''
    pass

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 03:17:56.580685
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert not fc.collected_facts
    assert not fc.depends_on
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:08.050278
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Generate an instance of FcWwnInitiatorFactCollector, and call collect on it.
    The collect method will return a dictionary in the form
    {'fibre_channel_wwn': <values>}.

    This test ensures that the returned 'fibre_channel_wwn' key has a value.
    """
    import platform
    from ansible.module_utils.facts.collector import Collector
    g = FcWwnInitiatorFactCollector()
    collector = Collector(module={})
    fc_facts = g.collect(None, collector)
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts.keys()
    assert isinstance(fc_facts['fibre_channel_wwn'], list)

# Generated at 2022-06-11 03:18:19.095320
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector to
    test if correct facts are collected regarding fibre channel wwn on
    different platforms.
    """
    # platform to test on:
    #   linux - tested on ubuntu 18.04
    #   solaris - tested on solaris 11
    #   aix - tested on AIX 5, 7 and 7.2
    #   hp-ux - tested on hp-ux 11.31
    #   unsupported - not supported platform
    platform_list = ['linux', 'solaris', 'aix', 'hp-ux', 'unsupported']
    # expected result for the different platforms
    #   valid - list of 1 or more WWN expected
    #   empty - no WWN expected
    #   none  - no WWN expected and result should be None
    expected

# Generated at 2022-06-11 03:18:26.045486
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    FcWwnInitiatorFactCollector._fact_ids = set()
    class FakeModule(object):
        def __init__(self, platform, lsdev_out, fcinfo_out, lscfg_out):
            self.platform = platform
            self.lsdev_out = lsdev_out
            self.fcinfo_out = fcinfo_out
            self.lscfg_out = lscfg_out

        def run_command(self, cmd):
            if 'lsdev' in cmd:
                return 0, self.lsdev_out, ''
            if 'fcinfo' in cmd:
                return 0, self.fcinfo_out, ''
            if 'lscfg' in cmd:
                return 0, self.lsc

# Generated at 2022-06-11 03:19:23.575978
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Set up mock module object
    import sys
    import mock

    class TestModule(object):
        def __init__(self, name=None, bin_path=None, run_command=None, get_bin_path=None):
            self.name = name
            self.bin_path = bin_path
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    sys.modules['__main__'] = mock.Mock()
    sys.modules['__main__'].module = TestModule

    # Set up mock run_command function
    mock_run_command = mock.Mock()
    mock_run_command.return_value = 0, "", ""

    # Set up mock get_bin_path function
    mock_get_bin_path = mock.Mock()


# Generated at 2022-06-11 03:19:35.150359
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule, MockCollectedFacts
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collectors import find_collection_plugin, get_collector_instance

    module = MockModule()
    facts = Facts(module, MockCollectedFacts())
    find_collection_plugin(facts, 'fibre_channel_wwn')
    collector = get_collector_instance(facts, 'fibre_channel_wwn')
    collected_facts = collector.collect(module=module)
    assert 'fibre_channel_wwn' in collected_facts
    assert len(collected_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:19:35.901091
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-11 03:19:43.013396
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        m = FcWwnInitiatorFactCollector()
        assert isinstance(m, FcWwnInitiatorFactCollector)
    except Exception as e:
        print("%s test_FcWwnInitiatorFactCollector() exception: %s " % (__file__, str(e)))

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:45.773928
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'
    assert result.collect() is None

# Generated at 2022-06-11 03:19:48.782244
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwniFactCol = FcWwnInitiatorFactCollector()
    assert isinstance(fcwwniFactCol, BaseFactCollector)
    assert fcwwniFactCol.name == "fibre_channel_wwn"


# Generated at 2022-06-11 03:20:00.611541
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import re
    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import fc_wwn
    from ._utils.subtest import Subtest

    # example output of fcinfo hba-port
    output_sunos = """
HBA Port WWN: 21000014ff52a9bb
  OS Device Name: /dev/cfg/c1
  Manufacturer: SUN
  Model: 501-7116
  Firmware Version: 0.0
  Supported Speeds: 2Gb 4Gb 8Gb 16Gb
  Current Speed: 16Gb
"""
    # example output of lscfg -vpl fcs3

# Generated at 2022-06-11 03:20:04.154603
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc._fact_ids

# Generated at 2022-06-11 03:20:14.583854
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import FactsCollector
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    facts_collector = FactsCollector(module=module, collectors=default_collectors)

    # Generate expected results for linux based systems
    if sys.platform.startswith('linux'):
        test_facts = {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:20:18.086816
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:21:57.745488
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:21:58.954767
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-11 03:22:01.659874
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)

# Generated at 2022-06-11 03:22:11.732596
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Unit test namespace
    class AnsibleModule:
        def get_bin_path(self, command, opt_dirs=[]):
            if command == 'lsdev':
                return '/usr/sbin/lsdev'
            elif command == 'lscfg':
                return '/usr/sbin/lscfg'
            elif command == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif command == 'ioscan':
                return '/usr/sbin/ioscan'
            elif command == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            else:
                return None


# Generated at 2022-06-11 03:22:23.293703
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import util
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
            filter=dict(default='*', type='str'),
            fact_path=dict(default='/etc/ansible/facts.d', type='path'),
            fact_file=dict(default='network.fact', type='str'),
        )
    )

    # set up the python module
    collector = Collector(module=module, collected_facts=dict())

    # create a new

# Generated at 2022-06-11 03:22:25.607539
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_facts = FcWwnInitiatorFactCollector()

    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:31.767913
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.builtin.plugins.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    c = FcWwnInitiatorFactCollector()
    assert c.collect()['fibre_channel_wwn'] == ['21000014FF52A9BB'], "Collector collect() should return list of Fibre Channel initiator WWN addresses"


# Generated at 2022-06-11 03:22:33.997925
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:37.647293
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for FcWwnInitiatorFactCollector class
    """
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts is not None

# Generated at 2022-06-11 03:22:39.416074
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'