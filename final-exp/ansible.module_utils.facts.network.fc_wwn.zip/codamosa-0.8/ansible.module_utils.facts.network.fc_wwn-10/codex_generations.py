

# Generated at 2022-06-11 03:15:04.268464
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleFactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # Uncomment this line to be able to run the unit test from local machine
    # module_utils_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', '..', 'module_utils')
    # sys.path.append(module_utils_path)
    # Uncomment this line to be able to run the unit test from local machine


# Generated at 2022-06-11 03:15:07.118437
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:17.034754
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test basics
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == {'fibre_channel_wwn': []}

    # tests for Linux based systems
    if sys.platform.startswith('linux'):
        # test reading of fc_host/path_name
        glob.glob = lambda x: ['/sys/class/fc_host/fc_host1/path_name',
                               '/sys/class/fc_host/fc_host2/path_name']
        get_file_lines = lambda x: ['0x1000090fa1658de\n',
                                    '0x1000090fa1657ce\n']


# Generated at 2022-06-11 03:15:28.985759
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    # example output from /sys/class/fc_host/host*/port_name
    fake_command_output = """21000014ff52a9bb
21000014ff52a9bc"""
    # example output from prtconf -pv | grep -A2 hba-port

# Generated at 2022-06-11 03:15:30.092199
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-11 03:15:38.740244
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils.facts import modules
    from ansible.module_utils._text import to_bytes

    # Modules class is a "singelton"
    modules_obj = modules.Modules()

    # Initialize connection object
    connection_obj = basic.AnsibleConnectionBase(
        task_uuid=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )

# Generated at 2022-06-11 03:15:45.470632
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert fcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert isinstance(fcWwnInitiatorFactCollector._fact_ids, set)
    assert not fcWwnInitiatorFactCollector._fact_ids

# Generated at 2022-06-11 03:15:50.993730
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test FcWwnInitiatorFactCollector constructor and basic object fields."""

    obj = FcWwnInitiatorFactCollector()
    assert obj
    assert obj.name == 'fibre_channel_wwn'
    if sys.version_info[0] >= 3:
        assert obj._fact_ids == set()
    else:
        assert obj._fact_ids == set([])


# Generated at 2022-06-11 03:15:52.754144
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:56.662178
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    answers = dict(ansible_facts=dict())
    fc_facts = FcWwnInitiatorFactCollector().collect(collected_facts=answers)
    assert fc_facts is not None

# Generated at 2022-06-11 03:16:09.652131
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test the constructor."""
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids is not None

# Generated at 2022-06-11 03:16:16.179404
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()
    facts_dict = Collector.collect(FcWwnInitiatorFactCollector_obj)
    assert facts_dict['ansible_fibre_channel_wwn'] == FcWwnInitiatorFactCollector_obj.collect()

# Generated at 2022-06-11 03:16:18.684987
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:22.494695
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector(None).name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector(None)._fact_ids == set()


# Generated at 2022-06-11 03:16:30.498216
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import json
    import os
    from ansible.module_utils.facts import collector

    # Create an instance of FcWwnInitiatorFactCollector Class
    fcwwn = FcWwnInitiatorFactCollector()

    # Create empty object to store the collected facts
    test_facts = {}

    # Mock method available_collectors of the AnsibleModuleUtils FactsCollector class
    def mock_available_collectors(self):
        return {'fibre_channel_wwn': fcwwn}

    collector.FactsCollector.available_collectors = mock_available_collectors

    # Mock method get_bin_path of the AnsibleModuleUtils FactsCollector class

# Generated at 2022-06-11 03:16:33.415168
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-11 03:16:37.145209
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-11 03:16:41.870172
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    # check if an empty list is returned for a fake os
    collected_facts = fact_collector.collect(module=FakeModule(), collected_facts=None)
    assert collected_facts['ansible_facts'] == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:16:45.308543
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector.name == 'fibre_channel_wwn'
    assert fc_facts_collector.collect() is not False

# Generated at 2022-06-11 03:16:49.231916
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test of constructor of class FcWwnInitiatorFactCollector.
    Use this to test the constructor is sane.
    """
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact is not None

# Generated at 2022-06-11 03:17:18.991569
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    # Test class
    class TestFcWwnInitiatorFactCollector(FcWwnInitiatorFactCollector):
        def get_file_lines(self, file):
            test_file_data = {
                '/sys/class/fc_host/host0/port_name': ['0x50060b00006975ec'],
                '/sys/class/fc_host/host1/port_name': ['0x50060b00006975ed'],
            }
            return test_file_data[file]


# Generated at 2022-06-11 03:17:22.118188
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_collector.name == "fibre_channel_wwn"

# Generated at 2022-06-11 03:17:26.041383
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    c = FcWwnInitiatorFactCollector()
    fc_facts = c.collect()
    print (fc_facts)

# only run the unit test if this program is called directly
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:17:27.204711
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_object = FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:17:29.971685
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert fcWwnInitiatorFactCollector is not None

# Generated at 2022-06-11 03:17:33.738658
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)
    assert len(fc._fact_ids) == 0

# Generated at 2022-06-11 03:17:35.387333
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:17:39.394477
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector("fibre_channel_wwn")
    assert f is not None
    assert f.name == "fibre_channel_wwn"

# Generated at 2022-06-11 03:17:42.858657
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create and test collector
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts.collect()
    assert type(fc_facts.collect()) is dict


# Generated at 2022-06-11 03:17:48.419256
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """

    mock = BaseFactCollector()
    actual = FcWwnInitiatorFactCollector(mock)
    assert actual.__class__.__name__ == 'FcWwnInitiatorFactCollector'

# Generated at 2022-06-11 03:18:34.585758
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test to test method collect of class FcWwnInitiatorFactCollector
    """
    fc_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_collector.collect()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-11 03:18:44.594585
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import os
    import imp
    global module_utils
    try:
        import ansible.module_utils.facts.collectors.network.fibre_channel_initiator
        module_utils = ansible.module_utils.facts.collectors.network.fibre_channel_initiator
    except ImportError:
        module_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        module_utils = imp.load_source('module_utils', module_path)
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'

# Unit test of FcWwnInitiatorFactCollector.collect method

# Generated at 2022-06-11 03:18:55.962219
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test if the content of the files under /sys/class/fc_host is returned.
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector

    _module = AnsibleModuleMock()
    _base_fact_collector = BaseFactCollector(_module, Facts())
    _fc_collector = FcWwnInitiatorFactCollector(_base_fact_collector)

    # collect is called with empty parameter (collected_facts and module)
    _fc_collector.collect(collected_facts=None, module=AnsibleModuleMock())

    # expected result
    _

# Generated at 2022-06-11 03:18:58.236315
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    f = FcWwnInitiatorFactCollector()
    print(f.collect())

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:19:00.804790
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:11.948717
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import FactCollector, ansible_collector
    from ansible.module_utils._text import to_text

    fc = FcWwnInitiatorFactCollector()
    assert isinstance(fc, FactCollector)
    assert isinstance(fc, ansible_collector)
    assert hasattr(fc, 'name')
    assert hasattr(fc, 'collect')
    result = fc.collect()
    assert isinstance(result, dict)
    assert 'fibre_channel_wwn' in result

# Run tests
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:19:15.624870
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector._fact_ids == set()

# Generated at 2022-06-11 03:19:21.224381
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():  # pylint: disable=missing-docstring
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)

# Generated at 2022-06-11 03:19:26.359997
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-11 03:19:30.942761
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:20:59.525059
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock
    FcWwnInitiatorFactCollector.collect(module)

# Generated at 2022-06-11 03:21:09.644658
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module_args
    from ansible.module_utils.facts import ansible_facts

    # create mock module
    module = mock_module_args()
    module.exit_json = mock_module_args()
    module.run_command = mock_module_args()

    # create a test collector and make the test
    test_collector = FcWwnInitiatorFactCollector()
    result = test_collector.collect(module=module, collected_facts=ansible_facts)

    if sys.platform.startswith('linux'):
        # no device available is ok too
        assert (len(result['fibre_channel_wwn']) == 0 or len(result['fibre_channel_wwn'][0]) == 16)

# Generated at 2022-06-11 03:21:19.706276
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import filecmp
    import platform
    import glob

    try:
        from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    except ImportError:
        print("failed=True " + \
            "msg=Prerequisite for this test is Ansible 2.5.5 or higher.")
        sys.exit(4)
    except Exception:
        print("failed=True " + \
            "msg=Unexpected error during 'Prerequisite for this test " + \
            "is Ansible 2.5.5 or higher.': " + str(sys.exc_info()[0]))
        sys.exit(4)

    #TODO: test on solar

# Generated at 2022-06-11 03:21:23.920253
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    obj = FcWwnInitiatorFactCollector()
    result = obj.collect()
    assert result
    assert 'fibre_channel_wwn' in result
# end unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-11 03:21:25.112954
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:21:27.630294
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_class = FcWwnInitiatorFactCollector()
    assert test_class.name == 'fibre_channel_wwn'
    assert test_class._fact_ids == set()

# Generated at 2022-06-11 03:21:29.684294
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()

# Generated at 2022-06-11 03:21:33.181169
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-11 03:21:36.394721
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Create a FcWwnInitiatorFactCollector object.
    """
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:21:43.908000
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    # Run collect of method collect in class FcWwnInitiatorFactCollector
    # return result is facts
    facts = get_collector_instance('fibre_channel_wwn').collect()

    # Test for facts is instance, and has expected content.
    assert facts is not None
    assert isinstance(facts, dict)
    assert 'fibre_channel_wwn' in facts