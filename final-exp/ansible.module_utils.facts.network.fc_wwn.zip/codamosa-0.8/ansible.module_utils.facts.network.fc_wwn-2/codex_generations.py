

# Generated at 2022-06-11 03:15:00.178742
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test instantiation
    collector = FcWwnInitiatorFactCollector()
    assert collector is not None

# Generated at 2022-06-11 03:15:02.689723
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fn_wwn = FcWwnInitiatorFactCollector()
    assert fn_wwn.name == 'fibre_channel_wwn'
    assert fn_wwn._fact_ids == set()
    assert fn_wwn.collect() == {}

# Generated at 2022-06-11 03:15:13.525228
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import Collector

    def collect_mock(self, module=None, collected_facts=None):
        facts = {
            'fibre_channel_wwn': ['0x21000014ff52a9bb']
        }
        return facts
    Collector.collect = collect_mock

    if not platform.system().startswith('SunOS'):
        # mock module object
        class MockModule:
            def __init__(self):
                self.params = {}
            def fail_json(self, *args, **kwargs):
                pass
            def get_bin_path(self, *args, **kwargs):
                return ''

# Generated at 2022-06-11 03:15:16.329411
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    # just test if the list is empty
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:15:20.050929
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Unit test
    module = AnsibleModuleMock()
    fc = FcWwnInitiatorFactCollector(module=module)
    fc_facts = fc.collect()
    assert 'fibre_channel_wwn' in fc_facts


# Generated at 2022-06-11 03:15:28.110278
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_collector.collect()
    assert type(fc_facts) == dict
    assert 'fibre_channel_wwn' in fc_facts.keys()
    for wwn in fc_facts['fibre_channel_wwn']:
        assert len(wwn) == 16
        assert (wwn.isalnum() and not wwn.isalpha())

# Generated at 2022-06-11 03:15:32.880271
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'


if __name__ == '__main__':
    # Unit test for constructor of class FcWwnInitiatorFactCollector
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:15:40.128443
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

    def run_command_mock(command):
        return 0, " HBA Port WWN: 10000090fa1458de\n", ""

    module_mock = type('module', (object,), {})()
    module_mock.run_command = run_command_mock
    module_mock.get_bin_path = lambda self, name, opt_dirs=[] : "/usr/bin/%s" % name

    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.collect(module_mock)['fibre_channel_wwn'] == ['10000090fa1458de']

# Generated at 2022-06-11 03:15:41.322106
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-11 03:15:45.232478
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwi = FcWwnInitiatorFactCollector()
    assert fcwi.name == 'fibre_channel_wwn'
    assert fcwi._fact_ids == set()


# Generated at 2022-06-11 03:15:57.383139
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-11 03:16:07.793766
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # unit test for method collect of class FcWwnInitiatorFactCollector

    # import python libs
    import os
    import sys
    import unittest # noqa pylint: disable=unused-import
    import tempfile
    import shutil

    # import 3rd party libs
    try:
        from unittest import mock
        import pytest
    except ImportError:
        mock = None
        pytest = None

    # Mock library for files
    class OpenMock(object):
        def __init__(self):
            self.file = None
            self.captured_lines = list()
            self.captured_lines.append('0x21000014ff52a9bb')
            self.captured_lines.append('0x21010014ff52a9bc')

# Generated at 2022-06-11 03:16:20.462894
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    import ansible.module_utils.facts.collector.fibre_channel_wwn as fcwwn

    class MockModule:
        def __init__(self):
            self.exit_json = Common()
            self.fail_json = Common()

        def get_bin_path(self, app, opt_dirs=[]):
            if app == "fcinfo":
                return "/usr/sbin/fcinfo"
            if app == "fcmsutil" and opt_dirs == ["/opt/fcms/bin"]:
                return "/opt/fcms/bin/fcmsutil"

    class Common:
        def __init__(self):
            pass


# Generated at 2022-06-11 03:16:26.906292
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test method collect of class FcWwnInitiatorFactCollector.
    """
    collector = FcWwnInitiatorFactCollector()
    # result expected for Linux
    resultLinux = {
        "ansible_facts": {
            "fibre_channel_wwn": [
                "21000014ff52a9bb",
                "2100001503381159"
            ]
        }
    }
    assert collector.collect(collected_facts=dict()) == resultLinux

# Generated at 2022-06-11 03:16:28.540550
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """FcWwnInitiatorFactCollector - collect"""
    FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-11 03:16:40.828837
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    TODO: write unit test
    """

    # init
    #collector = FcWwnInitiatorFactCollector()



# Generated at 2022-06-11 03:16:42.510016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()

    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:45.308880
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect(collected_facts={})
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-11 03:16:48.058795
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_init_obj = FcWwnInitiatorFactCollector()
    assert fc_wwn_init_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:49.871219
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO
    pass

# Generated at 2022-06-11 03:17:22.700027
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # import needed for unit testing
    from ansible.module_utils.facts import runner
    from ansible.module_utils.facts import collector

    # create the collector instance
    fc_col = FcWwnInitiatorFactCollector()

    # run the collection with a mocked module (see lib/ansible/module_utils/facts/__init__.py)
    # it's important that the mocked module is created in the test method to prevent cacheing
    with collector.standalone_facts_runner() as ans_runner:
        fc_facts = fc_col.collect(ans_runner.module)

    # test the result
    assert isinstance(fc_facts, dict)
    assert fc_facts['fibre_channel_wwn'][0] == '21000014FF52A9BB'


# Generated at 2022-06-11 03:17:30.206188
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import platform
    import glob
    import io
    import tempfile
    import shutil
    import os
    import stat

    class MockModule(object):
        def __init__(self, params):
            self.params = params
        def run_command(self, cmd):
            return 0, "", ""
        def get_bin_path(self, arg1, opt_dirs=None):
            return None

    class MockOs(object):
        def __init__(self):
            self.path = os.path
        def mkdir(self, dir):
            os.mkdir(dir)
        def unlink(self, file):
            os.unlink(file)
        def symlink(self, src, dest):
            os.symlink(src,dest)

# Generated at 2022-06-11 03:17:33.081193
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:17:37.351220
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # instance should be of FcWwnInitiatorFactCollector
    fcwwn = FcWwnInitiatorFactCollector()
    assert isinstance(fcwwn, FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:17:49.999479
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def mock_get_file_lines(path):
        return ['0x21000014ff52a9bb']

    def mock_get_bin_path(cmd, opt_dirs=None):
        return cmd

    def mock_run_command(cmd):
        if cmd == 'fcinfo hba-port':
            return 0, "HBA Port WWN: 10000090fa1658de", None
        if cmd == 'lsdev -Cc adapter -l fcs*':
            return 0, "fcs3 Available 19-08-00-3,0 FC Adapter\nfcs4 Defined  19-08-00-4,0 FC Adapter", None

# Generated at 2022-06-11 03:17:51.427135
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-11 03:17:57.599055
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for FcWwnInitiatorFactCollector

    Returns:
    True if the test passed
    """

    my_obj = FcWwnInitiatorFactCollector()

    assert (my_obj.name == "fibre_channel_wwn")
    assert (my_obj._fact_ids == set())

    return True



# Generated at 2022-06-11 03:18:00.436176
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:03.666734
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 03:18:06.748713
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.collect() == {}
    assert collector._fact_ids == set()

# Generated at 2022-06-11 03:19:00.651944
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import DummyModule
    import platform

    # Prepare a dummy Module for unit testing
    module = DummyModule()
    module.run_command = lambda x: (0, '', '')

    # Prepare a fake FcWwnInitiatorFactCollector
    fwwn = FcWwnInitiatorFactCollector()

    # Prepare fake ansible_facts
    if sys.version_info[0] >= 3:
        unicode = str

    facts = {'ansible_facts': {},
             'ansible_fibre_channel_wwn': unicode([])}

    # Perform the unit test
    fwwn.collect(module=module, collected_facts=facts)

    # Verify results
    assert facts['ansible_fibre_channel_wwn']

# Generated at 2022-06-11 03:19:04.060954
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert len(fc_obj._fact_ids) == 1
    assert fc_obj._fact_ids.pop() == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:04.981027
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:14.502353
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append("50060b00006975ec")
    fc_facts['fibre_channel_wwn'].append("50060b00006975ee")
    facts = FcWwnInitiatorFactCollector("FcWwnInitiatorFactCollector")
    assert facts.collect() == fc_facts

# Generated at 2022-06-11 03:19:18.600699
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_Collector = FcWwnInitiatorFactCollector()
    assert fact_Collector.name == 'fibre_channel_wwn'
    assert len(fact_Collector._fact_ids) == 0


# Generated at 2022-06-11 03:19:20.244411
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()


# Generated at 2022-06-11 03:19:22.321310
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:34.677636
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector

    class MockModule(object):
        def __init__(self):
            pass
        
        def get_bin_path(self, executable, opt_dirs=[]):
            if opt_dirs:
                if 'fcms/bin' in opt_dirs:
                    if executable == 'ioscan':
                        return "data"
                    elif executable == 'fcmsutil':
                        return "data"
            if executable == 'fcinfo':
                return "data"

# Generated at 2022-06-11 03:19:45.729846
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class Arg(object):
        def __init__(self, module=None, collected_facts=None):
            self.module = module
            self.collected_facts = collected_facts

    class Module(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x,check_rc=None: (0, [0x21000014ff52a9bb], [])
            self.get_bin_path = lambda x: None

    class Facts(object):
        def __init__(self, facts=None):
            self.facts = facts

    module = Module()
    collected_facts = Facts()
    fc_plugin = FcWwnInitiatorFactCollector()
    fc_facts = fc_plugin.collect(Arg(module, collected_facts))

# Generated at 2022-06-11 03:19:54.243958
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock, patch

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):

        @patch.object(FcWwnInitiatorFactCollector, 'collect')
        def test_sample(self, collect_mock):
            """
            Simply test that this method successfully calls the `collect` method to satisfy unit test coverage
            """
            FcWwnInitiatorFactCollector().collect()
            self.assertTrue(collect_mock.called)

    unittest.main()

# Generated at 2022-06-11 03:21:32.463746
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:21:44.461023
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # import json

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            if name == 'fcinfo':
                return "../../../test/files/fcinfo.out"
            elif name == 'lscfg':
                return "../../../test/files/lscfg.out"
            elif name == 'lsdev':
                return "../../../test/files/lsdev.out"
            elif name == 'ioscan':
                return "../../../test/files/ioscan.out"
            elif name == 'fcmsutil':
                return "../../../test/files/fcmsutil.out"
            return None


# Generated at 2022-06-11 03:21:54.342258
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import set_module_args
    from ansible.module_utils.facts.utils import AnsibleFakeModule

    # set sys.platform to a supported value
    sys.platform = 'linux'

    # create BaseFactCollector object
    base_fact_collector = BaseFactCollector()

    # create Collector object, this represents the AnsibleModule object
    testmodule = Collector(module=AnsibleFakeModule())

    # create FcWwnInitiatorFactCollector object


# Generated at 2022-06-11 03:22:04.256433
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collection import FactsCollection
    from ansible.module_utils.facts.collector.fibre_channel_wwn import \
        FcWwnInitiatorFactCollector

    # Setup of Fact Collector
    collection_name = 'fibre_channel_wwn'
    facts_collection = FactsCollection()
    fact_collector = Collector(
        facts_collection=facts_collection,
        collection_name=collection_name
    )
    fact_collector.collectors.append(FcWwnInitiatorFactCollector())

    # Collection of facts
    fact_collector.collect()

    # Assert after collection
    fact = facts_collection.get(collection_name=collection_name)

# Generated at 2022-06-11 03:22:15.120579
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    # set sys.platform to linux
    sys.platform = "linux2"
    # set environment variable ANSIBLE_CACHE_PLUGIN_CONNECTION to be able to create the ansible.module_utils.facts.cache.ansible_facts_cache.ConnectionCache plugin
    os.environ["ANSIBLE_CACHE_PLUGIN_CONNECTION"] = "jsonfile"
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import ansible.module_utils.facts.cache as facts_cache
    fw = FcWwnInitiatorFactCollector("test")
    m = BaseFactCollector

# Generated at 2022-06-11 03:22:17.988081
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    # Test the class name
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:20.988902
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-11 03:22:26.180482
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn', "incorrect fact name"
    assert 'fibre_channel_wwn' in fc_obj._fact_ids, "fact not in fact_ids"


# Generated at 2022-06-11 03:22:27.416640
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:22:31.148469
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert 'fibre_channel_wwn' in facts

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()