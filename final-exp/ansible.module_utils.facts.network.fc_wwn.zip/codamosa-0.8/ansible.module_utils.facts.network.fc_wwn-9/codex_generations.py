

# Generated at 2022-06-11 03:15:04.299391
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert not fc is None

# Generated at 2022-06-11 03:15:07.184901
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert isinstance(f, FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:15:09.601113
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:17.783850
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils import basic
    import os
    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    collector = Collector(module=module)
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(module=module)
    print("fibre_channel_wwn: %s" % facts['fibre_channel_wwn'])
    assert facts['fibre_channel_wwn']

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:15:21.065839
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()
    assert isinstance(facts, dict)
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-11 03:15:28.771346
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

    m = builtins.__dict__['__import__']('ansible.module_utils.facts.collector.fibre_channel_wwn_initiator')
    fcwwn = m.FcWwnInitiatorFactCollector()

    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:37.991120
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import ansible_runner

    class ModuleMock(object):

        def __init__(self, params=[]):
            self.params = params

        def get_bin_path(self, arg, *args, **kwargs):
            return arg

        def run_command(self, arg, *args, **kwargs):
            return 0, arg, None

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-11 03:15:49.788260
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleExitModule
    # define module mock
    def get_bin_path(module, cmd, opt_dirs=[]):
        bin_path = None
        if cmd == 'fcinfo':
            bin_path = '/usr/bin/fcinfo'
        if cmd == 'lsdev':
            bin_path = '/usr/sbin/lsdev'
        if cmd == 'lscfg':
            bin_path = '/usr/bin/lscfg'
        if cmd == 'ioscan':
            bin_path = '/usr/sbin/ioscan'
        if cmd == 'fcmsutil':
            bin_path = '/opt/fcms/bin/fcmsutil'
        return bin_path

    def run_command(cmd):
        rc = 0
        fcout

# Generated at 2022-06-11 03:15:51.786792
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcFactsCollector = FcWwnInitiatorFactCollector()
    assert fcFactsCollector is not None

# Generated at 2022-06-11 03:15:58.778127
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    my_module = AnsibleModule()
    if sys.platform.startswith('linux'):
        my_module.run_command = lambda x: (0, to_bytes('0x21000014ff52a9bb\n'), '')

# Generated at 2022-06-11 03:16:13.536680
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector(None)
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:16.119757
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:19.079198
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.collect()  is not None


# Generated at 2022-06-11 03:16:28.606541
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, cmd, opt_dirs=[]):
            return self.params['path']

        def run_command(self, cmd):
            return self.params['rc'], '', ''

    # Initialize a linux-based platform with fc_host files
    if sys.platform.startswith('linux'):
        fc_i_fact_collector = FcWwnInitiatorFactCollector()
        params = {'path': '/bin/not_used',
                  'rc': 0}
        module = MockModule(params)
        fc_facts = fc_i_fact_collector.collect(module=module)

# Generated at 2022-06-11 03:16:40.874205
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # create Mock module, Mock command and Mock module utils
    m = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=True
    )
    m.params = m.load_params()

    # Mock of Collector Class
    collector = Collector()
    collector.module = m

    # Mock of FcWwnInitiatorFactCollector
    FcWwnInitiatorFactCollector.name = 'fibre_channel_wwn'
    FcWwnInitiatorFactCollector.collect(collector)
    result = collector.get_facts()

# Generated at 2022-06-11 03:16:51.000577
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collectors.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.utils import get_file_lines
    import mock

    class MockModule(mock.MagicMock):

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'ioscan':
                return executable
            elif executable == 'fcmsutil':
                return executable
            else:
                raise Exception



# Generated at 2022-06-11 03:16:54.641537
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    fc = FcWwnInitiatorFactCollector()
    print("Running tests for %s" % fc)
    assert isinstance(fc, BaseFactCollector)
    assert fc.name == 'fibre_channel_wwn'

if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:16:56.758712
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO: Implement test case
    print("Not implemented test case for method collect of class "
          "FcWwnInitiatorFactCollector")

# Generated at 2022-06-11 03:17:00.185415
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_obj = FcWwnInitiatorFactCollector()
    collected = fc_obj.collect()
    assert collected == fc_obj.collect()

# Generated at 2022-06-11 03:17:03.729901
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factCollector = FcWwnInitiatorFactCollector()
    assert factCollector
    assert factCollector.name == 'fibre_channel_wwn'
    assert factCollector._fact_ids == set()


# Generated at 2022-06-11 03:17:27.974722
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-11 03:17:29.663819
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn = FcWwnInitiatorFactCollector()
    fcwwn.collect()

# Generated at 2022-06-11 03:17:33.431438
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwifc = FcWwnInitiatorFactCollector()
    assert fwifc is not None
    assert fwifc.name == 'fibre_channel_wwn'
    assert fwifc._fact_ids is not None

# Generated at 2022-06-11 03:17:41.182211
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_collector.name == 'fibre_channel_wwn'
    assert len(fc_wwn_initiator_collector._fact_ids) == 1
    assert fc_wwn_initiator_collector._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-11 03:17:52.949238
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for FcWwnInitiatorFactCollector.collect method. Tests if the
    facts are collected in the right way.
    """
    class MockModule(object):

        def get_bin_path(self, binary, opt_dirs=[]):
            return "/usr/bin/" + binary

        def run_command(self, cmd, check_rc=False, close_fds=True, data=None):
            return(0, '', '')

    module = MockModule()

    from ansible.module_utils.facts import collector
    fc_wwn_fact_collector = collector.get_collector('fibre_channel_wwn')

    fc_wwn_fact_collector.collect(module=module)

# Generated at 2022-06-11 03:18:00.581811
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {
        "fibre_channel_wwn": [
            "21000014ff52a9bb"
        ]
    }

    collector = FcWwnInitiatorFactCollector()

    result = collector.collect(collected_facts=None)
    assert 'fibre_channel_wwn' in result

    for fcwwn_fact in result['fibre_channel_wwn']:
        assert fcwwn_fact in fc_fa

# Generated at 2022-06-11 03:18:10.304496
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ansible_virtual_machines

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

    # test all cases
    Collector.collectors = []
    Collector.collectors.append(FcWwnInitiatorFactCollector())

    # run test
    facts = ansible_virtual_machines('Linux', fc_facts)
    # test
    assert facts['fibre_channel_wwn'] == ['21000014ff52a9bb']


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:18:13.747068
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-11 03:18:18.262396
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    result = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in result
    assert result['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-11 03:18:22.432657
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test FcWwnInitiatorFactCollector class."""

    os_facts = {'distribution': 'Solaris'}
    fc_wwn_fact = FcWwnInitiatorFactCollector(os_facts)
    assert fc_wwn_fact.name == 'fibre_channel_wwn'
    assert fc_wwn_fact._fact_ids == set()

# Generated at 2022-06-11 03:19:11.949340
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector
    facts = FcWwnInitiatorFactCollector().collect()
    assert facts == {}


# Generated at 2022-06-11 03:19:14.837422
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:24.126551
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    This is a unit test for construction of FcWwnInitiatorFactCollector class.
    """

    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fcwwn_fact_collector, FcWwnInitiatorFactCollector)
    assert fcwwn_fact_collector.name == 'fibre_channel_wwn'
    assert '_fact_ids' in fcwwn_fact_collector.__dict__
    assert 'collect' in fcwwn_fact_collector.__dict__

if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:35.820110
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector._platform = 'linux'
    FcWwnInitiatorFactCollector._module = object()
    FcWwnInitiatorFactCollector._get_file_lines = []
    collected_facts = {}

    # test without data
    p = FcWwnInitiatorFactCollector()
    p.collect(collected_facts=collected_facts)
    assert 'fibre_channel_wwn' not in collected_facts

    # test with non-matching files
    with open('/tmp/dummyfile', 'w') as f:
        f.write('')
    with open('/tmp/dummyfile2', 'w') as f:
        f.write('')
    FcWwnInitiatorFactCollector._get_file_lines = []

# Generated at 2022-06-11 03:19:42.859034
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    facts = {}
    fc.collect(module=None, collected_facts=facts)
    assert isinstance(facts['ansible_fibre_channel_wwn'], list)
    assert isinstance(facts['ansible_fibre_channel_wwn'][0], str)
    assert len(facts['ansible_fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:19:51.438927
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    module = FakeAnsibleModule()
    if sys.platform.startswith('linux'):
        """
        TBD:
        - add tests for linux
        """
        pass
    elif sys.platform.startswith('sunos'):
        collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:20:03.159270
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # run method collect of class FcWwnInitiatorFactCollector
    factCollector = FcWwnInitiatorFactCollector()
    facts = factCollector.collect()
    fc_wwn = facts.get("fibre_channel_wwn", None)
    print("fibre_channel_wwn = %s" % fc_wwn)
    assert fc_wwn is not None
    assert fc_wwn is not []

if __name__ == '__main__':
    try:
        from ansible.module_utils.facts.collector import main
        main(FcWwnInitiatorFactCollector)
    except ImportError:
        test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:20:06.200324
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    facts = fcwwn_initiator_fact_collector.collect()
    assert facts['fibre_channel_wwn']
    for wwn in facts['fibre_channel_wwn']:
        assert wwn in ['50060b00006975ec', '50060b00006975eb']


# Generated at 2022-06-11 03:20:15.622232
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.utils
    # Mock module object
    module = ansible.module_utils.facts.utils.get_module_object(
        'ansible.module_utils.facts.collectors.fibre_channel_wwn.FcWwnInitiatorFactCollector')

    # Mock 'get_file_lines' method of module
    def mock_get_file_lines(self, pathname):
        contents = [
            '0x21000014ff52a9bb',
            '0x21000014ff52a9bc'
        ]
        return contents
    module.get_file_lines = mock_get_file_lines

    # Create object
    fcwwn = FcWwnInitiatorFactCollector()
    # call method
    result = fcwwn.collect

# Generated at 2022-06-11 03:20:17.650357
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:22:03.437156
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """
    res = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in res.keys()
    assert isinstance(res['fibre_channel_wwn'], list)
    if len(res['fibre_channel_wwn']) == 0:
        print("Test for FcWwnInitiatorFactCollector method collect was not executed. No WWN found.")

# Generated at 2022-06-11 03:22:11.457850
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  """
  This method is used as a unit test for the FcWwnInitiatorFactCollector class.
  """
  assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
  assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)
  assert FcWwnInitiatorFactCollector._fact_ids == set()
  assert isinstance(FcWwnInitiatorFactCollector.collect(), dict)
  assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-11 03:22:14.302329
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:15.243006
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:22:26.259340
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Test the method collect of class FcWwnInitiatorFactCollector. """

    # Test collect on Linux
    if sys.platform.startswith('linux'):
        test_collector = FcWwnInitiatorFactCollector()
        wwns = test_collector.collect()['fibre_channel_wwn']
        assert len(wwns) > 0, "There should be at least 1 WWN (fibre channel initiator)."
        for wwn in wwns:
            assert len(wwn) == 16, "The length of the WWN is not 16, wrong WWN written in /sys/class/fc_host/<n>/port_name."

# Generated at 2022-06-11 03:22:37.423375
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import tempfile

    (tmpfd, tmpfile) = tempfile.mkstemp()
    os.close(tmpfd)
    os.remove(tmpfile)
    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = [ 'fibre_channel_wwn' ]
            self.params['gather_timeout'] = 0

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/' + arg
        def run_command(self, cmd):
            platform_type = platform.system()
            if platform_type == 'Linux':
                cmd = cmd.replace('/bin/', '')

# Generated at 2022-06-11 03:22:39.489713
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert not obj._fact_ids

# Generated at 2022-06-11 03:22:50.744929
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector

    facts = { 'ansible_facts': {} }
    fake_module = BaseFactCollector(facts)
    collector = FcWwnInitiatorFactCollector(fake_module)

    the_results = collector.collect()

    print("the_results= %s" % the_results)

    assert the_results is not None
    assert the_results['fibre_channel_wwn'] is not None


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:22:58.892017
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test if returned dictionary has the corrent keys and values as defined.
    """

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    class MockModule(object):
        def __init__(self, config=None):
            self.params = config
            self.config = {'fail_json': False}
            self.exit_json = {}

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif binary == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            elif binary == 'lsdev':
                return '/usr/sbin/lsdev'

# Generated at 2022-06-11 03:23:02.936751
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_collector = FcWwnInitiatorFactCollector()
    assert test_collector.name == 'fibre_channel_wwn'
    assert not test_collector._fact_ids
    assert test_collector._platform == ''
