

# Generated at 2022-06-11 03:15:07.013192
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:08.905480
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-11 03:15:12.627487
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.collector == 'fibre_channel_wwn_collector'

# Generated at 2022-06-11 03:15:20.166070
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MyModule(object):
        def get_bin_path(arg1, opt_dirs=None):
            return 'cmd'


# Generated at 2022-06-11 03:15:23.272859
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:34.654599
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import inspect
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector

    test_obj = FcWwnInitiatorFactCollector()

    # Get the method to test
    test_method = getattr(test_obj, 'collect')

    # Replace module and func args
    args = list(inspect.getargvalues(inspect.currentframe()).args)
    for i in range(0, len(args)):
        if (args[i] == 'module'):
            # Skip module in list of args to pass to method
            continue

# Generated at 2022-06-11 03:15:37.003437
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:39.645132
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector('')
    except:
        assert False
    assert True

# Generated at 2022-06-11 03:15:43.566504
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    collected_facts = None
    fact_collector = FcWwnInitiatorFactCollector(module=module, collected_facts=collected_facts)
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:47.955597
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:11.361729
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # mock ansible module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.exit_json = {}
            self.fail_json = None
        def run_command(self, cmd, opt_dirs=None):
            if cmd.startswith('fcinfo'):
                return (0, 'HBA Port WWN: 10000090fa1658de\n', '')

# Generated at 2022-06-11 03:16:23.699009
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import ModuleFacts

    # test on linux
    package_facts = {'ansible_facts': {'ansible_python_version': '2.6.6'}, 'changed': False}
    module = ModuleFacts(dict(ansible_python_version='2.6.6'))
    module.run_command = MagicMock(return_value=(0, 'no output', 'no stderr'))
    module.get_bin_path = MagicMock(return_value='/bin/ls')


# Generated at 2022-06-11 03:16:31.142276
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test of method FcWwnInitiatorFactCollector.collect
    """

    # this is required to bootstrap the unit test
    module = AnsibleModule(argument_spec={})
    module.params = {}

    # work around some weirdness with python2/ansible where
    # module_utils may appear to be a relative import on
    # some platforms
    sys.modules['ansible'] = type('DummyModule', (object,), {})

    # the following import statement had to be rewritten to make it work
    # for some reason, it's not possible to simply do an import here
    #
    # from ansible.module_utils.facts.collector.network import FcWwnInitiatorFactCollector
    #
    # this is the workaround

# Generated at 2022-06-11 03:16:33.532212
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fw = FcWwnInitiatorFactCollector()
    assert fw is not None

# Generated at 2022-06-11 03:16:41.778696
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = mock.Mock(
        params={},
        get_bin_path=mock.Mock(return_value='/bin/ls'),
        run_command=mock.Mock(return_value=[0, '0x21000024ff52a9bb', '']),
    )

    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect(module=module)
    assert fc_facts == {
        'fibre_channel_wwn': ['21000024ff52a9bb']
    }

# Generated at 2022-06-11 03:16:43.481981
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:51.759110
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_result = {'fibre_channel_wwn': ['50060b00006975ec', '50060b00006733e1', '50060b000066f9d7']}
    module = MockModule()

    sys.platform = 'linux'
    module.run_command = Mock(return_value=(0, '0x50060b00006975ec', ''))
    test = FcWwnInitiatorFactCollector().collect(module=module, collected_facts={})
    assert test['fibre_channel_wwn'] == test_result['fibre_channel_wwn']



# Generated at 2022-06-11 03:16:54.100953
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_class = FcWwnInitiatorFactCollector()
    print(fcwwn_class.name)

# Generated at 2022-06-11 03:16:56.250874
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_test = FcWwnInitiatorFactCollector()
    assert fc_test


# Generated at 2022-06-11 03:17:00.882878
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()
    assert collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:17:18.376880
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FC_EXPECTED_WWN = '21000014ff52a9bb'
    FcWwnInitiatorFactCollector.collect_func = lambda self: {'fibre_channel_wwn': ['21000014ff52a9bb']}
    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect()
    assert len(fc_facts['fibre_channel_wwn']) == 1
    assert fc_facts['fibre_channel_wwn'][0] == FC_EXPECTED_WWN

# Test for ansible module

# Generated at 2022-06-11 03:17:20.277623
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:24.036769
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fcwwn.collect()

# Generated at 2022-06-11 03:17:25.479796
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    pass

# Generated at 2022-06-11 03:17:35.934399
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector

    Test the content of the result:
    - fact has a name
    - fact has a list of WWN

    """

    if sys.platform.startswith('linux'):
        out = b"""0x21000014ff52a9bb
0x21000014ff52a9c3
0x21000014ff52a9cb
0x22000014ff52a9bb
0x22000014ff52a9c3
0x22000014ff52a9cb"""
        fcwwn_fact = FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:17:37.439255
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # no exception should be raised
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:17:42.735451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import __builtin__
    setattr(__builtin__, '__file__', '/Users/ksator/ansible/hacking/test_module.py')
    from ansible.module_utils.facts import ModuleUtilsFacts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    m = ModuleUtilsFacts('/opt')
    facts_fibre_channel_wwn_fact_collector = FcWwnInitiatorFactCollector(m)
    facts_fibre_channel_wwn = facts_fibre_channel_wwn_fact_collector.collect()

# Generated at 2022-06-11 03:17:44.757016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector() is not None

# Generated at 2022-06-11 03:17:49.463678
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_facts = FcWwnInitiatorFactCollector()
    assert fcwwn_facts.name == 'fibre_channel_wwn', 'Invalid fact name'
    assert bool(fcwwn_facts._fact_ids) is False, 'Invalid fact_ids'

# Generated at 2022-06-11 03:17:51.706893
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:25.425203
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for FcWwnInitiatorFactCollector.collect method.
    """

    fc_facts = {}

    # test linux
    try:
        from ansible.module_utils.basic import AnsibleModule
        fc = FcWwnInitiatorFactCollector()
        fc._module = AnsibleModule(argument_spec={})

    except ImportError:
        sys.platform = 'linux'
        fc = FcWwnInitiatorFactCollector()

    fc_facts = fc.collect()
    assert fc_facts['fibre_channel_wwn'] == []

    # test solaris
    sys.platform = 'sunos'
    fc = FcWwnInitiatorFactCollector()
    fc._module = AnsibleModule(argument_spec={})


# Generated at 2022-06-11 03:18:32.042056
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.collect(collector=Collector(module='MockedModule')) == \
        {'fibre_channel_wwn': []}


# Generated at 2022-06-11 03:18:34.271008
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:44.632389
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    # unit test for Linux with 2 WWN
    data = {'fibre_channel_wwn': []}
    data_linux_2wwn = [
             "0x21000014ff52a9bb",
             "0x21000014ff52a9bc",
             ]
    platform_linux = "linux"
    fact_collector = Collector(platform=platform_linux,
                               collected_facts=data)
    fact_collector.collect_platform_facts = lambda module: {}
    fact_collector.get_files_from_path = lambda arg: ["/sys/class/fc_host_test1/port_name", "/sys/class/fc_host_test2/port_name" ]

# Generated at 2022-06-11 03:18:49.276968
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = dict()
    fact_collector.collect(collected_facts=collected_facts)
    assert collected_facts == {'fibre_channel_wwn': [u'21000024ffffec5d', u'21000024ffffec5d']}

# Generated at 2022-06-11 03:18:59.708429
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = Mocker()
    collected_facts_mock = Mocker()
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append("0x21000014ff52a9bb")
    module_helper_mock = Mocker()
    module_helper_mock.fibre_channel_wwn()

    module_mock.get_bin_path('ioscan', opt_dirs=['/opt/fcms/bin'])

    # mocks for ioscan output
    module_mock.run_command('ioscan -fnC FC')
    fcmsu_cmd = "fcmsutil /dev/fcd"

# Generated at 2022-06-11 03:19:05.629938
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    fact_collector = FcWwnInitiatorFactCollector(
        module=module,
        collected_facts={}
    )
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.collected_facts == {}
    assert fact_collector._fact_ids == set()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:14.790792
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json
    from ansible.module_utils.facts import ansible_collector

    # Setup
    fc_collector = ansible_collector.get_collector('fibre_channel_wwn')

    # Test
    fc_facts = fc_collector.collect(module=None, collected_facts=None)

    # Assert
    assert fc_facts['fibre_channel_wwn']

if __name__ == '__main__':
    # Unit test
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:19:16.996951
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_module = FcWwnInitiatorFactCollector()
    assert fact_module.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:26.541538
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import _populate_fact_cache

    class MockModule:
        def __init__(self):
            pass

        @staticmethod
        def get_bin_path(bin, opt_dirs=[]):
            # mock method get_bin_path of module ansible.module_utils.facts.collector.Collector
            # will be replaced with our implementation
            if bin == "fcinfo":
                return "/bin/fcinfo"

# Generated at 2022-06-11 03:20:18.660888
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import platform
    import glob
    import random
    # import string
    import fileinput

    # set test-flags to run platform specific tests
    # if platform.system() == "Linux":
    #     linux_test = True
    # else:
    #     linux_test = False
    linux_test = False
    # if platform.system() == "SunOS":
    #     sunos_test = True
    # else:
    #     sunos_test = False
    sunos_test = False
    # if platform.system() == "AIX":
    #     aix_test = True
    # else:
    #     aix_test = False
    aix_test = False
    # if platform.system() == "HP-UX":
    #     hp_test = True


# Generated at 2022-06-11 03:20:26.801186
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    mock_module = type('module', (), {})
    mock_module.get_bin_path = lambda self, cmd, required=False, opt_dirs=[] : 'command'
    mock_module.run_command = lambda self, cmd : (0, '', '')

    fc = FcWwnInitiatorFactCollector(mock_module)

    for platform in ('linux', 'sunos', 'aix', 'hp-ux'):
        setattr(sys, 'platform', platform)
        fc.collect(mock_module)

# Generated at 2022-06-11 03:20:31.530764
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert sorted(fc._fact_ids) == ['fibre_channel_wwn']
    assert fc.collect_fn == fc.collect
    assert repr(fc) == 'FcWwnInitiatorFactCollector(name:fibre_channel_wwn, fact_ids:fibre_channel_wwn)'

# unit test for method collect

# Generated at 2022-06-11 03:20:41.911421
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts import collector
    test_class_obj = FcWwnInitiatorFactCollector()

    # create Collector() with the test class
    collector_obj = Collector(test_class_obj)
    # create a mocked module object
    module_obj = FakeModule()
    facts = collector_obj.collect(module=module_obj)
    assert 'fibre_channel_wwn' in facts
    assert isinstance(facts['fibre_channel_wwn'], list)

# Generated at 2022-06-11 03:20:52.511175
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Checks the collect method of class FcWwnInitiatorFactCollector
    """
    # import Ansible ModuleUtils for the test
    from ansible.module_utils import facts

    # create a mock module object
    module = facts.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # create a mock provider object
    provider = facts.FactCollector(module=module)

    # create the object to test and add it to the provider
    fc = FcWwnInitiatorFactCollector(provider=provider)
    provider.add_collector(fc)

    # run the collection
    collected_facts = provider.collect(module=module)

    # assert 'fibre_channel_wwn' is in collected_facts

# Generated at 2022-06-11 03:20:57.493181
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    module = MockModule()

    ffact_collector = FcWwnInitiatorFactCollector(module=module)
    # invoked method should return a dict
    result = ffact_collector.collect()
    assert isinstance(result, dict)
    assert 'fibre_channel_wwn' in result



# Generated at 2022-06-11 03:20:58.062156
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-11 03:21:08.337158
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule():
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

        def run_command(self, cmd):
            return self.rc, self.stdout, self.stderr

        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd

    class TestFcWwnInitiatorFactCollector(FcWwnInitiatorFactCollector):
        def collect(self, module=None, collected_facts=None):
            return {}

    fc = TestFcWwnInitiatorFactCollector()

    # Test aix
    rc = 0

# Generated at 2022-06-11 03:21:09.281404
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:21:13.258873
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = {}
    fact_collector.collect(collected_facts)
    assert isinstance(collected_facts, dict)
    assert isinstance(collected_facts['fibre_channel_wwn'], list)

# Generated at 2022-06-11 03:22:49.462058
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-11 03:22:51.064305
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()



# Generated at 2022-06-11 03:22:59.049285
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    # get a FcWwnInitiatorFactCollector instance
    fcWwnInitiatorFactCollector = get_collector_instance(FcWwnInitiatorFactCollector)

    # create a fake module object
    class FakeModule:
        def __init__(self, bin_paths):
            self.bin_path = bin_paths

        def get_bin_path(self, binary, opt_dirs=[]):
            return self.bin_path.get(binary)

        def run_command(self, command):
            return 1, "", ""

    # create a fake module object with fake binary paths to commands

# Generated at 2022-06-11 03:23:10.092958
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.collectors.fibre_channel

    fcwwn_collected_facts = {
        'fibre_channel_wwn': []
    }

    if sys.platform.startswith('linux'):
        fcwwn_collected_facts = {
            'fibre_channel_wwn': [
                '21000014ff52a9bb'
            ]
        }

    fcwwn_facts_collector = ansible.module_utils.facts.collectors.fibre_channel.FcWwnInitiatorFactCollector()
    fcwwn_collected_facts = fcwwn_facts_collector.collect()
    assert fcwwn_collected_facts == fcwwn_collected_facts

# Generated at 2022-06-11 03:23:15.794358
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors import FcWwnInitiatorFactCollector
    fc_fc = FcWwnInitiatorFactCollector()
    fc = fc_fc.collect()
    assert isinstance(fc, dict)
    assert fc.get('fibre_channel_wwn')

# Generated at 2022-06-11 03:23:25.294982
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import glob

    import unittest
    from mock import patch, Mock

    from ansible.module_utils.facts import collector

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):
        def setUp(self):
            collector.sys = Mock(platform='linux')
            collector.glob = Mock(return_value=['/sys/class/fc_host/host0/port_name'])
            collector.get_file_lines = Mock(return_value=['0x21000014ff52a9bb'])

        def test_linux(self):
            collector.sys.platform = 'linux'
            collector.glob = Mock(return_value=['/sys/class/fc_host/host0/port_name'])

# Generated at 2022-06-11 03:23:27.254695
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj
    assert 'fibre_channel_wwn' == test_obj.name

# Generated at 2022-06-11 03:23:31.344917
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids == set()


# Generated at 2022-06-11 03:23:40.007486
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector.
    """
    def run(module):
        """
        Mock module run method.
        """
        return (0, '', '')

    module = type('MyModule', (object,), {'run_command': run, 'get_bin_path': lambda self, path, opt_dirs=None: path})
    output = FcWwnInitiatorFactCollector().collect(module=module)
    assert isinstance(output, dict)
    assert 'fibre_channel_wwn' in output

# Generated at 2022-06-11 03:23:47.178051
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Return a class instance with the collected facts.
    """
    FcWwnInitiatorFactCollector._fact_ids = set()
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts
    if sys.platform.startswith('sunos') or sys.platform.startswith('aix') or sys.platform.startswith('hp-ux'):
        assert len(fc_facts['fibre_channel_wwn']) > 0
    return fc_facts