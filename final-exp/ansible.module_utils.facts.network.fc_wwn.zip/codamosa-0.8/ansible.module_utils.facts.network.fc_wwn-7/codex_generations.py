

# Generated at 2022-06-11 03:15:04.609367
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-11 03:15:15.696219
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # check if module utils is available
    if not sys.modules.get('ansible.module_utils.facts.collector.base'):
        module_utils = __import__('ansible.module_utils.facts.collector.base',
                                  globals(), locals(), ['BaseFactCollector'])
        sys.modules['ansible.module_utils.facts.collector.base'] = module_utils
    if not sys.modules.get('ansible.module_utils.facts.utils'):
        utils = __import__('ansible.module_utils.facts.utils',
                           globals(), locals(), ['get_file_lines'])
        sys.modules['ansible.module_utils.facts.utils'] = utils

# Generated at 2022-06-11 03:15:19.222845
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"
    assert fc.collect() == {}


# Generated at 2022-06-11 03:15:22.590365
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert len(fc._fact_ids) == 0

# Generated at 2022-06-11 03:15:34.153377
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    fc = FcWwnInitiatorFactCollector()
    # mock glob.glob
    import __builtin__
    original_glob = __builtin__.glob
    fc_host_list = ['/sys/class/fc_host/host0/port_name',
                    '/sys/class/fc_host/host2/port_name',
                    '/sys/class/fc_host/host3/port_name']
    def mock_glob(path):
        if path == '/sys/class/fc_host/*/port_name':
            return fc_host_list
        else:
            return original_glob(path)
    __builtin__.glob = mock_glob

    # mock_open
   

# Generated at 2022-06-11 03:15:36.717759
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_obj = FcWwnInitiatorFactCollector()

    assert facts_obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:15:48.840995
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # this test is not relevant on non-Linux and non-SunOS platforms
    if not sys.platform.startswith('linux') and not sys.platform.startswith('sunos'):
        return
    # check that collector class is present
    if not sys.modules.get('ansible.module_utils.facts.collector.base'):
        return
    # check that some globals are present
    if not sys.modules.get('ansible.module_utils.facts.utils'):
        return
    # Create a test class derived from FcWwnInitiatorFactCollector
    class TestFactCollector(FcWwnInitiatorFactCollector):
        name = 'test'
    # Create an instance of the test class
    test_collector = TestFactCollector()
    # test collection
    collected_facts = test

# Generated at 2022-06-11 03:15:51.022126
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

# Generated at 2022-06-11 03:15:55.520578
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def class_method(self, module=None, collected_facts=None):
        return {'test1': 'test fcw_fact'}
    FcWwnInitiatorFactCollector.collect = class_method
    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector
    fcfacts = FcWwnInitiatorFactCollector()
    fcfacts.collect()

# Generated at 2022-06-11 03:15:59.009008
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts.collect()

# Generated at 2022-06-11 03:16:12.947482
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == {}


# Generated at 2022-06-11 03:16:17.844381
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert isinstance(x, BaseFactCollector)
    assert x.name == 'fibre_channel_wwn'
    assert set(x._fact_ids) == set(['fibre_channel_wwn'])

# Generated at 2022-06-11 03:16:23.433468
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert fcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert fcWwnInitiatorFactCollector._fact_ids == set()
    assert fcWwnInitiatorFactCollector.collect() == {}

# Generated at 2022-06-11 03:16:30.986636
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector

       Args:
           None

       Returns
           None
    """

    FAKE_DATA = '''
        HBA Port WWN: 10000090fa1658de
        Port Mode: Initiator
    '''

    from ansible.module_utils.facts.utils import ModuleData
    from ansible.module_utils.facts.collector import FactsCollector

    module_data = ModuleData(module_args='', persist_files=False, debug=False)
    facts_collector = FactsCollector(module_data)
    fc_fact_collector = FcWwnInitiatorFactCollector(facts_collector)

    fc_fact_collector._fcinfo_out = FAKE_DATA

    res = fc_fact_collect

# Generated at 2022-06-11 03:16:42.532229
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import module_utils
    tests_module_utils = basic.AnsibleModule(
        argument_spec=dict(),
    )
    module_utils.HAS_FCMSUTIL = True
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    # sample output of fcmsutil /dev/fcd0

# Generated at 2022-06-11 03:16:52.578098
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
        """Unit test for method collect of class FcWwnInitiatorFactCollector."""
        # create instance of class for testing
        fc_fact_collector = FcWwnInitiatorFactCollector()
        fc_fact_collector._module = None
        # run actual collect routine
        fc_facts = fc_fact_collector.collect()
        assert 'fibre_channel_wwn' in fc_facts
        # check if WWN is in expected format (16 hex chars)
        assert len(fc_facts['fibre_channel_wwn']) > 0
        for wwn in fc_facts['fibre_channel_wwn']:
            assert len(wwn) == 16
            for char in wwn:
                assert char in '0123456789abcdef'

# Generated at 2022-06-11 03:16:55.788292
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test constructor of the FcWwnInitiatorFactCollector class."""
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:00.349403
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    wwn_object = FcWwnInitiatorFactCollector()
    assert wwn_object.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in wwn_object.collect()


# Generated at 2022-06-11 03:17:03.083207
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-11 03:17:04.929240
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test = FcWwnInitiatorFactCollector()
    assert test.collect() == test.info

# Generated at 2022-06-11 03:17:32.033227
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'
    assert fact.collect() == {
                         'fibre_channel_wwn': []
                    }

# Generated at 2022-06-11 03:17:35.038511
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()

# Generated at 2022-06-11 03:17:39.172331
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    result = fc_facts.collect()
    assert(len(result['fibre_channel_wwn']) > 0)

# Generated at 2022-06-11 03:17:47.521192
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    FcWwnInitiatorFactCollector_collect = FcWwnInitiatorFactCollector()
    res = FcWwnInitiatorFactCollector_collect.collect()
    print(res)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# vim: se ft=python ai sw=4 ts=4 sts=4

# Generated at 2022-06-11 03:17:54.924354
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class module_mock:
        def __init__(self):
            self.params = {}
            self.params['collect_subset'] = ['min']
            self.params['gather_subset'] = ['min', 'fibre_channel_wwn']

        def get_bin_path(self, cmd, opt_dirs=[]):
            dict = { 'fcinfo': '/usr/sbin/fcinfo', 'lsdev': '/usr/sbin/lsdev',
                     'lscfg': 'lscfg', 'ioscan': 'ioscan', 'fcmsutil': 'fcmsutil' }
            return dict[cmd] if cmd in dict else ''
        # mock module.run_command()

# Generated at 2022-06-11 03:17:59.512314
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Call constructor of class FcWwnInitiatorFactCollector
    test_fact = FcWwnInitiatorFactCollector()
    assert test_fact.name == 'fibre_channel_wwn'
    assert test_fact._fact_ids == set()

# Generated at 2022-06-11 03:18:10.020995
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    import os.path

    # init the collector
    fc_collector = AnsibleCollector(
        module=None,
        paths=AnsibleFactCollector(module=None).collect(),
        collected_facts=dict()
    )


    # init the FcWwnInitiatorFactCollector class
    fc_fac_collector = FcWwnInitiatorFactCollector(fc_collector)

    # test for a valid platform
    if os.path.exists("/etc/debian_version"):
        fc_facts = fc_fac_collector.collect(module=None, collected_facts=None)

# Generated at 2022-06-11 03:18:12.960390
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector('fibre_channel_wwn')
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:19.580650
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create class instance
    collector = FcWwnInitiatorFactCollector()
    # Define module which is required for backward compatibility
    module = type('AnsibleModule', (object,), {'run_command': lambda: ('', '', '')})
    # call collect method
    facts = collector.collect(module=module)
    assert facts == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:18:26.388373
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # setup test
    sys.path.append('../../')
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import basic

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            return

    class MockOs(object):
        def get_platform(self):
            return 'linux'

    class MockGlob(object):
        def glob(self, path):
            return ['/sys/class/fc_host/host1/port_name']

    class MockGetFileLines(object):
        def __init__(self, *args, **kwargs):
            self.data = ["0x21000014ff52a9bb"]
           

# Generated at 2022-06-11 03:19:22.452405
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a mock module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    attrs = {
        '_ansible_check_mode': False,
    }
    module.params = attrs
    # create a mock module class
    class Collecter():
        def __init__(self, module, collected_facts=None):
            self.module = module
            self.collected_facts = collected_facts

        def get_bin_path(self, cmd, opt_dirs=[]):
            # check if ioscan is available
            ioscan_cmd = '/usr/sbin/ioscan'
            if cmd == 'ioscan':
                return ioscan_cmd
            # check if fcmsutil is available

# Generated at 2022-06-11 03:19:31.374715
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector._module = {'run_command':
                                            {'fibre_channel_wwn': ['0x21000014ff52a9bb']}}
    fc_facts = FcWwnInitiatorFactCollector.collect()['fibre_channel_wwn']
    assert len(fc_facts) == 1
    assert fc_facts[0] == '21000014ff52a9bb'

# Generated at 2022-06-11 03:19:39.219436
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    class FakeModule(BaseFactCollector):
        def __init__(self):
            self.params = {}

    def get_file_lines_side_effect(path):
        if path == '/sys/class/fc_host/host1/port_name':
            return ['0x21000014ff52a9bb']
        elif path == '/sys/class/fc_host/host2/port_name':
            return ['0x21000014ff52a9aa']
        else:
            return []

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

# Generated at 2022-06-11 03:19:43.837917
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert isinstance(fc, FcWwnInitiatorFactCollector)
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-11 03:19:46.776388
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()



# Generated at 2022-06-11 03:19:51.292181
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collections import network
    from ansible.module_utils.facts.collections.network import FcWwnInitiatorFactCollector

    facts_collector = FactsCollector(FcWwnInitiatorFactCollector())
    facts_collector.collect()

# Generated at 2022-06-11 03:19:53.263712
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj

# Generated at 2022-06-11 03:19:58.362859
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    FcFactCollector = FcWwnInitiatorFactCollector()
    facts = FcFactCollector.collect()
    print(facts)
    assert facts['fibre_channel_wwn']

# Generated at 2022-06-11 03:20:02.419772
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.modules.utils import MockModule

    fact_collector_obj = FcWwnInitiatorFactCollector()
    fact_collector_obj.collect(MockModule(), {})

# Generated at 2022-06-11 03:20:13.115976
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock

    class _module_mock:
        def __init__(self):
            self.params = {}
            self.tmpdir = '/tmp'

        def get_bin_path(self, name, warn_script=True, opt_dirs=[]):
            if name == 'fcinfo':
                name = './fcinfo.stdout'
            command_path = 'test/unit/ansible_collections/ansible/community/tests/unit/modules/fibre_channel_wwn/' + name
            return command_path


# Generated at 2022-06-11 03:21:48.067124
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    foo = FcWwnInitiatorFactCollector()
    assert foo.name == 'fibre_channel_wwn'
    assert foo._fact_ids == set()

# Generated at 2022-06-11 03:21:51.101033
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-11 03:21:56.080669
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Test that the collect method of FcWwnInitiatorFactCollector class
    returns the correct facts when data is available
    '''
    test_collector_class = FcWwnInitiatorFactCollector
    test_collector_obj = test_collector_class()
    test_fcs = [ '0x21000014ff52a9bb' ]
    result = test_collector_obj.collect()
    assert result['fibre_channel_wwn'] == test_fcs

# Generated at 2022-06-11 03:22:05.327539
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Facts
    import os
    import tempfile
    import mock
    # setup temp test environment
    fd, mytemp = tempfile.mkstemp()
    os.environ["ANSIBLE_CACHE_PLUGIN"] = mytemp
    os.environ["ANSIBLE_CACHE_PLUGIN_CONNECTION"] = "local"
    os.environ["ANSIBLE_CACHE_PLUGIN_PREFIX"] = ""
    os.environ['ANSIBLE_UNIT_TESTING'] = '1'
    # reset facts
    facts = Facts({}, {})
    # Create a mock environment

# Generated at 2022-06-11 03:22:09.807575
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    fcwwn_fact_ids = fcwwn._fact_ids
    assert len(fcwwn_fact_ids) == 0

# Generated at 2022-06-11 03:22:20.906857
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test of ansible.module_utils.facts.fibre_channel_wwn.FcWwnInitiatorFactCollector.collect

    Run with:
    python -m ansible.module_utils.facts.fibre_channel_wwn ansible.module_utils.facts.fibre_channel_wwn.FcWwnInitiatorFactCollector_collect

    """
    from ansible.module_utils.facts import collector

    # test data not available for all platforms
    if 'aix' not in sys.platform and 'hp-ux' not in sys.platform and 'sunos' not in sys.platform:
        f = FcWwnInitiatorFactCollector()
        for name, value in f.collect(collected_facts={}).items():
            print(name, value)



# Generated at 2022-06-11 03:22:29.887145
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    collector = FcWwnInitiatorFactCollector()
    # positive test
    facts = {}
    # dummy module object
    class DummyModule(object):
        def get_bin_path(self, name, opt_dirs=None):
            return '/path/dummy/bin'
        def run_command(self, cmd):
            return 0, '', ''
    dmymod = DummyModule()
    fc_facts = collector.collect(module=dmymod,
                                 collected_facts=facts)
    assert 'fibre_channel_wwn' in fc_facts


#
# Test execution
#
if __name__ == '__main__':
    # test the collect method
    test_

# Generated at 2022-06-11 03:22:37.225348
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert globals()['FcWwnInitiatorFactCollector'] is not None
    assert sys.platform == 'linux2'
    assert sys.platform == 'linux2'
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts is not None
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts.collect()



# Generated at 2022-06-11 03:22:48.192452
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import sys

    # ansible_facts from linux system
    linux_facts = {
        'ansible_facts': {
            'fibre_channel_wwn': [
                '21000014FF52A9BB'
            ]
        },
        'changed': False
    }

    # ansible_facts from solaris system
    solaris_facts = {
        'ansible_facts': {
            'fibre_channel_wwn': [
                '10000090fa1658de'
            ]
        },
        'changed': False
    }

    # ansible_facts from aix system

# Generated at 2022-06-11 03:22:52.373323
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts.collect()
