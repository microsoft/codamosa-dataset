

# Generated at 2022-06-11 03:15:04.691453
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  collector = FcWwnInitiatorFactCollector()
  assert collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:15:08.227471
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except Exception:
        assert False, "Failed to create FcWwnInitiatorFactCollector object"


# Generated at 2022-06-11 03:15:17.837092
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Setup
    FACT_NAME = 'fibre_channel_wwn'
    MOCK_ROOT_DIR = "/sys/class/fc_host"
    MOCK_FIBRE_CHANNEL_HOST_PATH_1 = "%s/host1" % MOCK_ROOT_DIR
    MOCK_FIBRE_CHANNEL_HOST_PATH_2 = "%s/host2" % MOCK_ROOT_DIR
    MOCK_FIBRE_CHANNEL_HOST_PATH_3 = "%s/host3" % MOCK_ROOT_DIR
    MOCK_FIBRE_CHANNEL_WWN_FILE_PATH_1 = "%s/port_name" % MOCK_FIBRE_CHANNEL_HOST_PATH_1
    MOCK_FIBRE_CHANN

# Generated at 2022-06-11 03:15:29.830791
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import platform
    import os
    import tempfile
    import shutil
    # store platform
    platform = platform.system()

    # fake sys.platform = linux
    sys.platform = 'linux'

    # create fake /sys/class/fc_host/
    tempdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tempdir, "fc_host"))
    # create fake file: /sys/class/fc_host/host1/port_name
    f = open(os.path.join(tempdir, "fc_host","host1","port_name"), "w")
    f.write("0x21000014ff52a9bb")
    f.close()
    # create fake file: /sys/class/fc_host/host2/port_name

# Generated at 2022-06-11 03:15:31.302741
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:34.458916
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_data = FcWwnInitiatorFactCollector()
    assert fc_data is not None
    assert fc_data.name == 'fibre_channel_wwn'
    assert len(fc_data._fact_ids) == 0

# Generated at 2022-06-11 03:15:38.564389
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnFactCol=FcWwnInitiatorFactCollector()
    assert FcWwnFactCol.name == 'fibre_channel_wwn'
    assert FcWwnFactCol._fact_ids == set()

# Unit test of method collect

# Generated at 2022-06-11 03:15:41.605880
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    t_fact = FcWwnInitiatorFactCollector()
    assert t_fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:44.041032
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:15:46.822078
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    print ("%s" % fc_wwn_collector)


# Generated at 2022-06-11 03:16:02.510755
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.fibre_channel_wwn import FcWwnInitiatorFactCollector

    test_obj = FcWwnInitiatorFactCollector()
    result = test_obj.collect()

    assert result.get('fibre_channel_wwn', False) is not False


# Generated at 2022-06-11 03:16:15.143770
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_object
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts.collector import CollectorFailureException

    # setup arguments
    module = None
    collected_facts = None
    fc_fact_collector_cls = get_collector_class('fibre_channel_wwn')
    fc_fact_collector = get_collector_object(fc_fact_collector_cls, module=module, collected_facts=collected_facts)
    # get facts
    facts = get_collector_facts(fc_fact_collector)

# Generated at 2022-06-11 03:16:18.065004
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fw = FcWwnInitiatorFactCollector()
    assert fw.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:16:21.480695
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert (fcwwn.name == 'fibre_channel_wwn')
    assert (fcwwn._fact_ids is not None)

# Generated at 2022-06-11 03:16:24.623264
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """

    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj is not None

# Generated at 2022-06-11 03:16:28.606424
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fcwwn_fact_collector.name == 'fibre_channel_wwn'
    assert len(fc_fcwwn_fact_collector._fact_ids) == 0
    assert fc_fcwwn_fact_collector.collect() == {}

# Generated at 2022-06-11 03:16:33.526539
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_obj = FcWwnInitiatorFactCollector()
    assert fcwwn_obj.name == 'fibre_channel_wwn'
# end of test_FcWwnInitiatorFactCollector()



# Generated at 2022-06-11 03:16:44.245047
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        fc_facts = fact_collector.collect(None)
        assert 'fibre_channel_wwn' in fc_facts
        assert len(fc_facts['fibre_channel_wwn']) > 0
    elif sys.platform.startswith('sunos'):
        fc_facts = fact_collector.collect(None)
        assert 'fibre_channel_wwn' in fc_facts
        assert len(fc_facts['fibre_channel_wwn']) > 0
    elif sys.platform.startswith('aix'):
        fc_facts = fact_collector.collect(None)

# Generated at 2022-06-11 03:16:46.895691
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_facts = FcWwnInitiatorFactCollector()
    assert my_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:50.705261
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_ini_facts = FcWwnInitiatorFactCollector()
    # test if name property is set correctly
    assert fc_wwn_ini_facts.name == 'fibre_channel_wwn'



# Generated at 2022-06-11 03:17:24.222842
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import shutil
    import tempfile
    import platform
    import unittest
    import unittest.mock
    import ansible.module_utils.facts.collector.base

    #
    # Linux
    #
    class TestFcWwnInitiatorFactCollector_collect_Linux(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.sys_platform = sys.platform
            sys.platform = 'linux'
            # mock module
            self.mock_module = unittest.mock.MagicMock(name='mock_module')
            # mock module.run_command(cmd)

# Generated at 2022-06-11 03:17:29.046893
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    sys.path.append('/tmp')
    from ansible.module_utils.facts.collectors.fibre_channel_wwn import FcWwnInitiatorFactCollector as fcwwnfc
    result = fcwwnfc().collect()
    assert 'fibre_channel_wwn' in result

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:17:41.182835
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method fact_collector.FcWwnInitiatorFactCollector.collect
    """

    from ansible.module_utils.facts.collector import collector
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution.aix import AixDistributionFactCollector
    from ansible.module_utils.facts.system.distribution.sunguard import SunOsDistributionFactCollector
    from ansible.module_utils.facts.system.distribution.suselinux import SuseLinuxDistributionFactCollector

# Generated at 2022-06-11 03:17:44.649732
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert len(x._fact_ids) == 0

# Generated at 2022-06-11 03:17:48.924586
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = AnsibleModuleMock()
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)

# Generated at 2022-06-11 03:17:54.417198
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert 'fibre_channel_wwn' in fc_facts.keys()

    if sys.platform.startswith('linux'):
        assert len(fc_facts['fibre_channel_wwn']) > 0
    else:
        assert len(fc_facts['fibre_channel_wwn']) == 0


# Generated at 2022-06-11 03:18:06.174510
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This function returns a FcWwnInitiatorFactCollector class with a mocked
    method run_command, glob, so we can test without dependencies
    """
    class FcWwnInitiatorFactCollectorWithMockedCall(FcWwnInitiatorFactCollector):
        def __init__(self, module):
            super(FcWwnInitiatorFactCollectorWithMockedCall, self).__init__(module)

        def run_command(self, command):
            if command == 'fcinfo hba-port':
                # output from fcinfo hba-port
                return (0, "HBA Port WWN: 10000090fa1658de", "")

# Generated at 2022-06-11 03:18:10.022818
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    x = Collector.fetch_fact_collector(FcWwnInitiatorFactCollector.name)
    assert x.__class__.__name__ == 'FcWwnInitiatorFactCollector'


# Generated at 2022-06-11 03:18:11.160550
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x is not None

# Generated at 2022-06-11 03:18:15.924292
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn', fc.name
    # Test if dictionaries are returned
    assert isinstance(fc.collect(), dict), fc.collect()

# Generated at 2022-06-11 03:18:41.139280
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import Facts
    FcWwnInitiatorFactCollector.collect(None, Facts())


# Generated at 2022-06-11 03:18:50.949069
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.hardware import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleExitJson
    from ansible.module_utils.facts.utils import AnsibleFailJson
    from ansible.module_utils.facts.utils import ModuleStub
    import os
    import sys

    if sys.platform.startswith('linux'):
        sample_file_contents = ['0x21000014ff52a9bb']
        sys_device_path = '../ansible_collections/ansible/os_firewall/tests/unit/module_utils/facts/files/linux_fc_host_port_name'

# Generated at 2022-06-11 03:19:00.437141
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    import sys
    import glob

    # initialize
    fc_facts = FcWwnInitiatorFactCollector()
    ans_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=False)
    module = ans_module
    collected_facts = {}
    platforms = [
        "aix",
        "darwin",
        "freebsd",
        "hpux",
        "linux",
        "netbsd",
        "openbsd",
        "sunos",
    ]

# Generated at 2022-06-11 03:19:03.892441
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    _fact_ids = set()
    assert FcWwnInitiatorFactCollector._fact_ids == _fact_ids

# Generated at 2022-06-11 03:19:08.698350
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # if sys.platform.startswith('linux'):
    #     return
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert isinstance(facts['fibre_channel_wwn'], list)
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:19:12.373529
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert hasattr(obj, 'name')
    assert hasattr(obj, '_fact_ids')
    assert hasattr(obj, 'collect')

# Generated at 2022-06-11 03:19:16.791409
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:19:26.510039
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This test is used to verify the collect method of FcWwnInitiatorFactCollector class.
    :return:
    """
    from ansible.module_utils.facts import Collector
    class MockModule:
        def run_command(self, cmd):
            return 0, "0x21000014ff52a9bb", ""

        def get_bin_path(self, cmd, opt_dirs=None):
            if cmd == 'fcinfo':
                return cmd
            elif cmd == 'lsdev':
                return cmd
            elif cmd == 'lscfg':
                return cmd
            elif cmd == 'ioscan':
                return cmd
            elif cmd == 'fcmsutil':
                return cmd
            else:
                return None


# Generated at 2022-06-11 03:19:37.164758
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    facts_module = FactCollector(None, None)

    # Test the Linux platform, no data available
    facts_module.collector.collectors[0]._platform = 'Linux'
    fc_wwn_initiator_collector = get_collector_instance(facts_module.collector, FcWwnInitiatorFactCollector)
    fc_wwn_initiator_collector._platform = 'Linux'


# Generated at 2022-06-11 03:19:39.945811
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:20:31.246996
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector
    assert x.name == 'fibre_channel_wwn'
    if sys.platform.startswith('linux') or sys.platform.startswith('sunos') \
        or sys.platform.startswith('aix') or sys.platform.startswith('hp-ux'):
        assert x.collect()['fibre_channel_wwn'] == []
    else:
        assert x.collect() == {}

# Generated at 2022-06-11 03:20:32.489674
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:20:39.228479
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleDataCollector
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collectors.fibre_channel_wwn

    result = {}
    fc_wwn_coll = FcWwnInitiatorFactCollector()
    fc_wwn_coll.collect(module=basic, collected_facts=result)
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-11 03:20:46.482816
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import collector_registry
    from ansible.module_utils.facts.collector import BaseFactCollector

    assert 'fibre_channel_wwn' in collector_registry._collector_registry
    assert isinstance(collector_registry._collector_registry['fibre_channel_wwn'],
                      type(FcWwnInitiatorFactCollector))
    assert issubclass(FcWwnInitiatorFactCollector, BaseFactCollector)

# Generated at 2022-06-11 03:20:50.879764
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fcInitiatorFactCollector.name
    assert isinstance(fcInitiatorFactCollector._fact_ids, set)


# Generated at 2022-06-11 03:20:53.534470
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Returns:
            An empty dict for each platform with the exception of Linux.

    """
    collector = FcWwnInitiatorFactCollector()
    collected_facts = collector.collect()

    assert {} == collected_facts


# Generated at 2022-06-11 03:20:56.664397
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert len(fc_facts._fact_ids) == 0

# Generated at 2022-06-11 03:21:07.221131
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test method collect of class FcWwnInitiatorFactCollector
    """

    #########################################################################
    #
    # Preparations (done in every test)
    #
    #########################################################################

    # collect module import
    from ansible.module_utils.facts import collector
    if sys.version_info[0] < 3:
        from ansible.module_utils.facts import collector
    else:
        from ansible.module_utils.facts.collector import Collector

    # import the module under test
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # create an instance of the module under test
    fc_wwn_collector = FcWwnInitiatorFactCollector()

    # create a mock

# Generated at 2022-06-11 03:21:10.227310
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector.name == 'fibre_channel_wwn'
    assert fc_facts_collector._fact_ids == set()

# Generated at 2022-06-11 03:21:18.444889
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_collector
    ansible_collector.collect_not_set = set()
    facts_collector = FactsCollector(collectors=[FcWwnInitiatorFactCollector()],
                                     namespace='ansible_collected_facts')
    collected_facts = facts_collector.collect(None)
    assert type(collected_facts) is dict
    assert 'fibre_channel_wwn' in collected_facts.keys()
    assert type(collected_facts['fibre_channel_wwn']) is list

# Generated at 2022-06-11 03:22:58.097179
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule():
        params = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/echo'

        def run_command(self, cmd, check_rc=False, close_fds=True, exec_prefix=''):
            return 0, "", ""
    from ansible.module_utils.facts import collector
    collector.collector.add_collector(FcWwnInitiatorFactCollector)
    out = collector.collector.collect(TestModule())
    assert len(out['ansible_facts']['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:23:08.991534
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors import FcWwnInitiatorFactCollector


# Generated at 2022-06-11 03:23:19.655070
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import AnsibleExit
    from ansible.module_utils import basic

    class MockModule(object):
        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/' + arg

        def run_command(self, arg):
            if arg.startswith('/bin/lsdev'):
                return 0, 'ent0 Available 04-08-11 IBM,8247', None

# Generated at 2022-06-11 03:23:22.103030
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwc = FcWwnInitiatorFactCollector()
    assert (fwc.name == "fibre_channel_wwn")
    assert (fwc.priority == 80)

# Generated at 2022-06-11 03:23:24.962471
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert isinstance(fcwwn.collect(None, None), dict)

# Generated at 2022-06-11 03:23:26.649292
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None



# Generated at 2022-06-11 03:23:29.947872
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 03:23:41.508359
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.

    This test is using a filesystem hierarchy on python level only,
    it is not using any files on a real filesystem.
    """
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    initiator_module = AnsibleFactCollector()
    initiator = FcWwnInitiatorFactCollector(initiator_module)

    # example output for file /sys/class/fc_host/host2/port_name on linux
    content = "0x21000014ff52a9bb"
    # create a dummy file on python level only
    initiator_module.files

# Generated at 2022-06-11 03:23:50.161779
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    testmodule = sys.modules[__name__]
    testsystem = testmodule.__dict__.get('sys', None)
    if testsystem is None:
        testsystem = testmodule.sys = type('sys', (object, ), {})
    testsystem.platform = 'linux'

    module = None
    collected_facts = None

    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(module, collected_facts)
    assert 'fibre_channel_wwn' in facts


if __name__ == '__main__':
    # running this module from the command line
    test_FcWwnInitiatorFactCollector_collect()
    sys.exit(0)

# Generated at 2022-06-11 03:23:54.653497
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = None
    # test on all available plattforms
    for platform in ['linux', 'sunos', 'aix', 'hp-ux']:
        test_collected_facts = {'ansible_system': platform}
        result = FcWwnInitiatorFactCollector(None, test_collected_facts, None).collect()
        if result == fc_facts:
            print("PASSED")
        else:
            print("FAILED")

# call collect method for local testing
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()