

# Generated at 2022-06-11 03:15:04.805624
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method `collect` of class FcWwnInitiatorFactCollector
    """

    # get the current class
    cls = sys.modules[__name__].FcWwnInitiatorFactCollector
    # initialize it
    fc = cls()
    # run the collect method
    fc_facts = fc.collect()
    # check if the fact is empty
    assert fc_facts['fibre_channel_wwn'] == [] or fc_facts['fibre_channel_wwn'] is None

# Generated at 2022-06-11 03:15:15.695405
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {}
    # on AIX:
    if sys.platform.startswith('aix'):
        fc_facts = {'fibre_channel_wwn':
                    ['10000090FA551509', '10000090FA551510']}
    # on HP-UX:
    elif sys.platform.startswith('hp-ux'):
        fc_facts = {'fibre_channel_wwn':
                    ['0x50060b00006975ec', '0x50060b00006976f1']}
    # on Linux:
    elif sys.platform.startswith('linux'):
        fc_facts = {'fibre_channel_wwn':
                    ['21000014ff52a9bb']}
    # on Solaris:
    el

# Generated at 2022-06-11 03:15:28.110674
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    FC_WWN_INITIATOR_PATH_LINUX = 'tests/unit/module_utils/facts/files/linux/sys/class/fc_host/host0/port_name'
    FC_WWN_INITIATOR_PATH_SOLARIS = 'tests/unit/module_utils/facts/files/solaris/dev/fibre-channel/fp0/port_name'
    FC_WWN_INITIATOR_PATH_AIX = 'tests/unit/module_utils/facts/files/aix/proc/driver/fcs0/port_name'
    FC_WWN_INITIATOR_PATH_HP_UX = 'tests/unit/module_utils/facts/files/hp-ux/dev/fcd0/port_name'


# Generated at 2022-06-11 03:15:30.558428
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:15:32.672071
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts = {}
    collector = FcWwnInitiatorFactCollector(None, facts)
    result = collector.collect()

    assert result['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-11 03:15:35.042397
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:37.302829
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    if o.collect() is not None:
        assert 'fibre_channel_wwn' in o.collect()

# Generated at 2022-06-11 03:15:49.430744
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile
    from ansible.utils.path import unfrackpath
    from ansible.utils.unicode import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    class FakeModule():
        def get_bin_path(self, binary, opt_dirs=None):
            if binary == 'lsdev' or binary == 'fcmsutil':
                return '/usr/sbin/' + binary
            elif binary == 'fcinfo' or binary == 'lscfg':
                return '/usr/bin/' + binary
            elif binary == 'ioscan':
                return '/usr/sbin/ioscan'
        def run_command(self, command):
            return 0, None, None
    fc_initiator_collector = FcWwnInitiatorFact

# Generated at 2022-06-11 03:15:54.363600
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == "fibre_channel_wwn"
    assert isinstance(fc_facts, BaseFactCollector)
    assert isinstance(fc_facts._fact_ids, set)
    assert not fc_facts._fact_ids

# Generated at 2022-06-11 03:16:03.086743
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    if sys.platform.startswith('linux'):
        assert fc_fact_collector.platforms == ['Linux']
    elif sys.platform.startswith('sunos'):
        assert fc_fact_collector.platforms == ['SunOS']
    elif sys.platform.startswith('aix'):
        assert fc_fact_collector.platforms == ['AIX']
    elif sys.platform.startswith('hp-ux'):
        assert fc_fact_collector.platforms == ['HPUX']



# Generated at 2022-06-11 03:16:24.220649
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    # verify that the class itself is returned with list() function
    assert list(fc) == [fc]

if __name__ == '__main__':
    # Unit test for module
    import sys
    MyFactCollector = sys.modules[__name__]
    fc = MyFactCollector.FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:27.515022
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for FcWwnInitiatorFactCollector
    :return:
    """

    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:39.794257
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils._text import to_bytes
    test_hostname = 'testhostname'
    test_module = DummyModule()
    test_module.params['gather_subset'] = ['all']
    test_module.params['gather_timeout'] = 10
    test_module.fail_json = Mock(return_value=dict(changed=False))
    test_module.run_command = Mock(return_value=dict(rc=0, stdout='', stderr='', start='', end='', delta=''))
    fc_wwn_initiator_collector = FcWwnInitiatorFactCollector(test_module)

# Generated at 2022-06-11 03:16:42.807839
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:16:45.309365
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fww = FcWwnInitiatorFactCollector()
    assert fww.name == 'fibre_channel_wwn'



# Generated at 2022-06-11 03:16:54.056231
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    test method collect of class FcWwnInitiatorFactCollector
    """

    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    # test for linux
    sys.platform = 'linux'
    factCollector = FcWwnInitiatorFactCollector()
    facts = factCollector.collect(module, dict())
    assert facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

    # test for solaris
    sys.platform = 'sunos'
    factCollector = FcWwnInitiatorFactCollector()
    facts = factCollector.collect(module, dict())
    assert facts['fibre_channel_wwn'] == ['10000090fa1658de']

    # test for aix
    sys

# Generated at 2022-06-11 03:17:05.246574
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    import os

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.exit_json = self.fail_json = None

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'fcmsutil':
                return os.path.join(os.getcwd(), 'MockScripts', 'hp-ux_fake_fcmsutil')
            elif executable == 'ioscan':
                return '/usr/sbin/ioscan'

# Generated at 2022-06-11 03:17:12.370504
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # arrange
    file_name = '/sys/class/fc_host/host0/port_name'
    file_content = '0x21000014ff52a9bb'
    fcwwn = FcWwnInitiatorFactCollector()

    # mock
    fcwwn.get_file_lines = lambda file_name: file_content

    # act
    result = fcwwn.collect()

    # assert
    assert result['fibre_channel_wwn'][0] == '21000014ff52a9bb'



# Generated at 2022-06-11 03:17:15.545566
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:22.270506
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test FcWwnInitiatorFactCollector.collect on linux and solaris.
    """
    import platform
    import re
    import os
    import sys
    import tempfile
    from ansible.module_utils.facts import get_module_args

    test_module = sys.modules[__name__]
    test_platform = "<TEST_PLATFORM>:"
    test_data = dict()

    def get_bin_path(name, opt_dirs=[]):
        """
        Return command path on test platform.
        """
        if test_platform == "linux:":
            # return command path on linux
            return "/bin/%s" % name
        if test_platform == "solaris:":
            # return command path on solaris
            return "/usr/bin/%s" % name

# Generated at 2022-06-11 03:17:37.711159
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fc_facts.name
    assert '[]' == str(fc_facts.collect())

# Generated at 2022-06-11 03:17:43.960617
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector class.
    """
    fc_class = FcWwnInitiatorFactCollector()
    assert fc_class.name == 'fibre_channel_wwn'
    # test _fact_ids
    assert fc_class._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-11 03:17:50.842772
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Initialise test object
    fc_obj = FcWwnInitiatorFactCollector()
    module = ansible_module_mock()
    # import pdb; pdb.set_trace()
    fc_result = fc_obj.collect(module=module)
    print("fc_result: ", fc_result)
    assert len(fc_result['fibre_channel_wwn']) > 0



# Generated at 2022-06-11 03:17:53.740751
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Method collect of class FcWwnInitiatorFactCollector
    """
    f = FcWwnInitiatorFactCollector()
    assert f.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:18:05.484334
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    class TestModule:
        def get_bin_path(self, binary):
            return binary
        def run_command(self, cmd):
            file_path = '/opt/ansible-facter-collection/ansible/module_utils/facts/fibre_channel_wwn_test'
            try:
                file = open(file_path, 'r')
                lines = file.readlines()
                file.close()
                return 0, lines, ''
            except:
                # file not found
                return 0, [], ''


    aix_file_path = '/opt/ansible-facter-collection/ansible/module_utils/facts/fibre_channel_wwn_test'
    hpux_file_

# Generated at 2022-06-11 03:18:13.499657
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import os
    import sys
    import unittest
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils

    if sys.version_info[0] == 2:
        # We are on python 2.7
        reload(ansible.module_utils.facts.collector)

    # Constructor test
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector
    assert isinstance(fact_collector, FcWwnInitiatorFactCollector)
    assert isinstance(fact_collector, ansible.module_utils.facts.collector.BaseFactCollector)
    assert fact_collector._name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:18:16.135260
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector is not None


# Generated at 2022-06-11 03:18:26.008694
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.caching import BaseFactCache
    from ansible.module_utils.facts.cache.memory import MemoryCache
    from ansible.module_utils.facts.cache.file import FileCache

    class Module(object):
        def __init__(self):
            pass

        def get_bin_path(self, executable, opt_dirs=[]):
            cmd = executable
            return cmd


# Generated at 2022-06-11 03:18:30.690639
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    col = FcWwnInitiatorFactCollector()
    assert col.name == 'fibre_channel_wwn'
    assert isinstance(col._fact_ids, set)
    assert hasattr(col, 'collect')
    assert col.collect() is None  # collect() returns None by default

# Generated at 2022-06-11 03:18:32.749836
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:04.932574
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # get os platform
    platform = sys.platform
    platform = platform.strip().lower()

    # set module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # get get_bin_path results
    # if no binary command is found, assume that there is not fibre channel hardware
    cmd_fcinfo = module.get_bin_path('fcinfo')
    cmd_ioscan = module.get_bin_path('ioscan')
    cmd_lscfg = module.get_bin_path('lscfg')
    cmd_fcmsutil = module.get_bin_path('fcmsutil', opt_dirs=['/opt/fcms/bin'])

    cmds = {}
    cmds['solaris'] = []

# Generated at 2022-06-11 03:19:16.794196
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    class MockModule(object):
        """
        Mock class of module
        """
        def __init__(self):
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            """
            Mock method of get_bin_path
            """
            return '/bin/foo'

        def run_command(self, cmd):
            """
            Mock method of run_command
            """
            if cmd == '/bin/foo hba-port':
                rc = 0
                out = """
                HBA Port WWN: 210000e08b4b4233
                HBA Port WWN: 210000e08b4b4234"""
            else:
                rc = 1

# Generated at 2022-06-11 03:19:21.265010
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # unit test for constructor
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert repr(fc)

# Generated at 2022-06-11 03:19:33.534304
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Make sure we have availability of the module_utils
    fact_module = sys.modules['ansible.module_utils.facts.fibre_channel.fibre_channel']
    if fact_module is None:
        pytest.fail("Ansible module_utils 'ansible.module_utils.facts.fibre_channel.fibre_channel' does not exist")
    # Make sure we have the required class
    if 'FcWwnInitiatorFactCollector' not in dir(fact_module):
        pytest.fail("Ansible module_utils 'ansible.module_utils.facts.fibre_channel.fibre_channel' does not contain required class 'FcWwnInitiatorFactCollector'")
    # Create an object of the FcWwnInitiatorFactCollector class
    f

# Generated at 2022-06-11 03:19:42.335803
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    import os
    from ansible.module_utils.facts import get_default_collectors
    fcwwn_facts = get_default_collectors(os.path.join(os.path.dirname(
        os.path.realpath(__file__)), 'platforms'), None, 'fibre_channel_wwn')['fibre_channel_wwn']
    facts = fcwwn_facts.collect()
    assert 'fibre_channel_wwn' in facts
    print(facts)
    assert facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-11 03:19:43.740791
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mock_module = MockModule()
    f = FcWwnInitiatorFactCollector()
    fact = f.collect(module=mock_module)
    assert fact['fibre_channel_wwn'] == ['10000090fa1658de']

# Generated at 2022-06-11 03:19:51.918807
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    if sys.version_info[0] >= 3:
        from unittest.mock import mock_open, patch
    else:
        from mock import mock_open, patch

    results = {
        'ansible_facts': {
            'fibre_channel_wwn': ['50060b00006975ec', '50060b00006975ed'],
        },
        'changed': False,
        'failed': False,
        'warnings': [],
    }

    facts_data = {
        'fcinfo': '/usr/sbin/fcinfo',
        'fcs': [
            {'status': 'Available', 'fc_name': 'fcs0'},
            {'status': 'Available', 'fc_name': 'fcs3'}
        ]
    }


# Generated at 2022-06-11 03:19:54.768149
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except NameError:
        assert False, "FcWwnInitiatorFactCollector constructor failed"


# Generated at 2022-06-11 03:20:07.460157
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # set up a dummy module
    module = type('module', (object,), {'get_bin_path': lambda self, x: None,
                                        'run_command': lambda self, x: (0, "", "")})()

    # set up a dummy get_file_lines function
    def get_file_lines_dummy(filename):
        file_lines = []

# Generated at 2022-06-11 03:20:09.889197
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts
    assert isinstance(fc_facts, FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:21:03.408114
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    print(type(fc.collect()))
    print(fc.collect())


# Generated at 2022-06-11 03:21:12.353785
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This unit test uses the sys.platform to target specific platform test.
    """
    from ansible.module_utils.facts.collector.fc_wwn_initiator import (
        platform, FcWwnInitiatorFactCollector
    )
    from ansible.module_utils.facts.collector import Collector

    module = Collector()
    module.get_bin_path = lambda x: x
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector(module=module)
    fc_wwn_initiator_facts = fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-11 03:21:13.430047
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-11 03:21:17.450730
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = AnsibleModuleMock()
    fc_facts = FcWwnInitiatorFactCollector(module, 'fibre_channel_wwn').collect()
    # if no fc device are attached, we expect an empty list
    assert fc_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-11 03:21:23.228950
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create instance of FcWwnInitiatorFactCollector
    test_obj=FcWwnInitiatorFactCollector()
    # check if __init__ function works correctly
    assert test_obj.name=='fibre_channel_wwn'
    assert test_obj.fact_ids==['fibre_channel_wwn']

# Generated at 2022-06-11 03:21:25.642572
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:21:29.283505
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_collector = FcWwnInitiatorFactCollector()
    fcwwn = ['50060b00006975ec', '50060b00006975ec']
    assert fc_collector.collect() == {'fibre_channel_wwn': fcwwn}

# Generated at 2022-06-11 03:21:33.890950
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test that the class FcWwnInitiatorFactCollector() is working properly.
    """

    fc_obj = FcWwnInitiatorFactCollector()

    assert fc_obj.name == 'fibre_channel_wwn'
    assert fc_obj._fact_ids == set()

# Generated at 2022-06-11 03:21:45.721450
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import mock_module

    test_cases = [
        {'platform': 'linux2', 'fc_fact': ['100000090fa1658de', '100000090fa165900']},
        {'platform': 'sunos', 'fc_fact': ['10000090fa1658de']},
        {'platform': 'aix', 'fc_fact': ['10000090FA551509']},
        {'platform': 'hp-ux', 'fc_fact': ['50060B00006975EC']},
        {'platform': 'freebsd', 'fc_fact': []},
        {'platform': 'openbsd', 'fc_fact': []}
    ]

    # fake module
    module = mock_module(platform=test_cases[0]['platform'])

   

# Generated at 2022-06-11 03:21:47.962345
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_collector = FcWwnInitiatorFactCollector()
    assert facts_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:23:17.362822
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:23:21.063314
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = object()
    fact_collector = FcWwnInitiatorFactCollector(module)
    assert fact_collector is not None


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:23:27.379194
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    collected_facts = fc_facts_collector.collect()
    assert type(collected_facts) is dict
    assert type(collected_facts['fibre_channel_wwn']) is list
    assert len(collected_facts['fibre_channel_wwn']) > 0
    assert len(collected_facts['fibre_channel_wwn'][0]) == 16
    assert len(collected_facts['fibre_channel_wwn'][0].strip("0123456789abcdefABCDEF")) == 0

# Generated at 2022-06-11 03:23:39.575487
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import tempfile
    import pytest

    def os_platform_factory(platform):
        def is_platform(self, *args, **kwargs):
            return platform
        return is_platform

    def get_file_lines_factory(lines):
        def get_file_lines(self, *args, **kwargs):
            return lines
        return get_file_lines


    class Module():
        """ Fake implementation of AnsibleModule class """
        def __init__(self, *args, **kwargs):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, *args, **kwargs):
            return 'fake_bin_path'


# Generated at 2022-06-11 03:23:49.233438
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # create instance of FcWwnInitiatorFactCollector
    fc_collector = FcWwnInitiatorFactCollector()

    # mock module input parameter ansible_facts
    ansible_facts = {}

    # mock module
    mock_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    mock_module.run_command = MagicMock(return_value=(0, '', ''))
    mock_module.get_bin_path = MagicMock(return_value=None)

    # run method collect of FcWwnInitiatorFactCollector
    returned_data = fc_collector.collect(module=mock_module, collected_facts=ansible_facts)

    # check if returned data is empty

# Generated at 2022-06-11 03:24:01.413317
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command
    cmd1 = "/usr/sbin/fcinfo hba-port"
    cmd2 = ("/usr/sbin/ioscan -fnC FC")
    cmd3 = ("/opt/fcms/bin/fcmsutil /dev/fcd1")
    cmd4 = ("/usr/sbin/lscfg -vpl fcs3")

    if sys.platform.startswith('sunos'):
        cmd1_out = "HBA Port WWN: 10000090fa1658de"

# Generated at 2022-06-11 03:24:07.017285
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json
    import os
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.fc_wwn_initiator import FcWwnInitiatorFactCollector

    MOCK_RETURNS = {'ansible_facts': {'fibre_channel_wwn': ['21000014ff52a9bb']}}
    MOCK_PATH = 'ansible.module_utils.facts.fc_wwn_initiator.FcWwnInitiatorFactCollector'

    mock_targets = {}

# Generated at 2022-06-11 03:24:10.253210
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    local_collector = FcWwnInitiatorFactCollector()
    # test whether fc_facts is dict
    assert isinstance(local_collector.collect(), dict)
    assert local_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:24:12.078693
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:24:21.369426
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.facts.collector.system import FcWwnInitiatorFactCollector
    import os
    import json

    class MockModule():
        def run_command(self, cmd, check_rc=None, environ_update=None, data=None, binary_data=False):
            class MyRun():
                if os.path.basename(cmd).startswith('lsd'):
                    stdout = "Virtual I/O Device (VIO) Disk_24 100CC.PCI.SAS-M.DD66.00-24-1 /dev/disk/disk_24"