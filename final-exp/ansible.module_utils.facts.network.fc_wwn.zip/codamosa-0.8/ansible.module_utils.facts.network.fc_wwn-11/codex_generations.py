

# Generated at 2022-06-11 03:15:13.441045
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule():
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = []
            self.params['filter'] = ''
            self.params['gather_timeout'] = 5
            self.params['filter_default_facts'] = True
            self.params['list_facts'] = False
        def get_bin_path(self, bin_path, opt_dirs=[]):
            if bin_path == "fcinfo":
                return "./test/fixtures/fcinfo"
            if bin_path == "ioscan" and opt_dirs:
                return "./test/fixtures/ioscan"
            if bin_path == "fcmsutil":
                return "./test/fixtures/fcmsutil"

# Generated at 2022-06-11 03:15:16.869613
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_wwn = FcWwnInitiatorFactCollector()
    result = fc_wwn.collect(module)
    assert result['fibre_channel_wwn'] == ['21000014FF52A9BB']



# Generated at 2022-06-11 03:15:18.949959
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FACTS = FcWwnInitiatorFactCollector()
    assert FACTS.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:15:23.980341
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # creation of class object
    obj_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    # verify that it is an object of the correct class
    assert isinstance(obj_FcWwnInitiatorFactCollector, FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:15:28.409455
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''Unit test for constructor of class FcWwnInitiatorFactCollector'''
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:37.739520
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import copy

    mysystem = platform.system()
    if mysystem == "Linux":
        from ansible.module_utils import basic
        from ansible.module_utils._text import to_bytes

        class TestModule(object):
            def __init__(self):
                self.params = {}
                self.params['command_warnings'] = False
                self.params['command_response'] = {}
                self.params['command_response']['stderr'] = None
                self.params['command_response']['rc'] = 0
                self.params['command_response']['stdout'] = None


# Generated at 2022-06-11 03:15:47.611466
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # initialize an empty collected facts
    collected_facts = {}

    # create an instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    # collect all facts; call method collect() of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector.collect(collected_facts=collected_facts)
    # check whether facts collection is successful
    assert(type(collected_facts['fibre_channel_wwn']) is list)

# Generated at 2022-06-11 03:15:59.391280
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a module class
    class TestModule(object):
        def __init__(self):
            self.module = None
            self.params = None
        def run_command(self, cmd):
            return ([0, "test"], "", "")
        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd
    module = TestModule()
    # create a class for the retrieved facts
    class TestFacts(dict):
        def __init__(self):
            self._facts = {}
            self._data = {}
            self._setup = None
            self.clear()
        def __getattr__(self, key):
            return self[key]
        def __setattr__(self, key, value):
            self[key] = value

# Generated at 2022-06-11 03:16:02.413375
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect()
    result = fc_facts['fibre_channel_wwn']
    assert result
    assert isinstance(result, list)

# Generated at 2022-06-11 03:16:03.882926
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:17.426901
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    result = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-11 03:16:27.594339
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test to check:
    - if the method collect returns a valid dict
    - if the dict contains the expected elements (using 'linux' as test case)
    """
    sys.modules['ansible'] = type('AnsibleMock', (), {'__file__': '/dev/null'})
    sys.modules['ansible.module_utils.facts.utils'] = type('FactsCollectorUtilsMock', (), {'get_file_lines': mock_get_file_lines})
    sys.modules['ansible.module_utils.facts.collector'] = type('FactsCollectorMock', (), {'BaseFactCollector': BaseFactCollector})

# Generated at 2022-06-11 03:16:35.909313
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # test the default constructor
    x = FcWwnInitiatorFactCollector()
    
    assert x.name == 'fibre_channel_wwn', "FcWwnInitiatorFactCollector() has wrong name"
    
    assert type(x._fact_ids) == set, "FcWwnInitiatorFactCollector() fact_ids is not a set"
    assert x._fact_ids == set(), "FcWwnInitiatorFactCollector() has non-empty fact_ids"

# Generated at 2022-06-11 03:16:40.084206
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts
    assert '_fact_ids' in fc_facts.__dict__


# Generated at 2022-06-11 03:16:41.657876
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

# Generated at 2022-06-11 03:16:51.830100
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.community.plugins.module_utils.facts import collector
    import ansible_collections.ansible.community.plugins.module_utils.facts.collectors.network.fc_wwn_initiator

    FcWwnInitiatorFactCollector = ansible_collections.ansible.community.plugins.module_utils.facts.collectors.network.fc_wwn_initiator.FcWwnInitiatorFactCollector
    C = collector.Collector(FcWwnInitiatorFactCollector, 'network')
    facts = C.collect(module=None, collected_facts=None)
    assert type(facts) == dict, 'bad facts'
    assert 'fibre_channel_wwn' in facts, 'bad facts'

# Generated at 2022-06-11 03:16:56.524259
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_mock = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_mock.collect(collected_facts={}) == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-11 03:16:59.318859
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_fc = FcWwnInitiatorFactCollector()
    assert fcwwn_fc.collect() == {}



# Generated at 2022-06-11 03:17:09.649574
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test FcWwnInitiatorFactCollector.collect method
    """
    import platform
    if platform.system() == 'Linux':
        try:
            import openstackansible.openstack_module_runtime.lib.bifrost as openstackansible
        except ImportError:
            import openstack_module_runtime.lib.bifrost as openstackansible

        # initializing the ansible module object for the following tests
        module = openstackansible.AnsibleModule(argument_spec=dict())
        module.params['debug'] = True
        module.params['log_path'] = '/var/log/ansible/facts.log'
        # creating the FcWwnInitiatorFactCollector using the module initialized
        fc = FcWwnInitiatorFactCollector(module=module)
       

# Generated at 2022-06-11 03:17:18.194515
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for Fibre Channel WWN initiator related facts collection of
        class FcWwnInitiatorFactCollector
    """

    # mock ansible.module_utils.facts.collector.BaseFactCollector
    class MockBaseFactCollector:
        def filter_facts(self, facts):
            return facts

    # mock ansible.module_utils.facts.utils.get_file_lines
    def mock_get_file_lines(path, *args, **kwargs):
        return ['0x21000014ff52a9bb']

    # mock ansible.module_utils.facts.collector.BaseFactCollector.collect
    def mock_BaseFactCollector_collect(self, *args, **kwargs):
        return {}

    # test for linux
    # patching BaseFactCollector.filter_facts and Base

# Generated at 2022-06-11 03:17:41.646210
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert isinstance(obj.name, str)


# Generated at 2022-06-11 03:17:46.014804
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = {}
    module = None
    collected_facts = {}
    collector.collect(module=module, collected_facts=collected_facts)


# Generated at 2022-06-11 03:17:47.576750
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:17:51.970762
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    expected_fact_ids = ['fibre_channel_wwn']
    assert c.name == 'fibre_channel_wwn'
    assert c._fact_ids == set(expected_fact_ids)


# Generated at 2022-06-11 03:18:04.296773
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcWwnInitiatorFactCollector - testing method collect
    """
    class TestModule():
        def __init__(self, platform=None, run_params=None, bin_path=None):
            self.platform = sys.platform
        def get_bin_path(self, executable, opt_dirs=None):
            return executable
        def run_command(self, cmd, check_rc=False):
            if executable == 'fcinfo':
                """
                on solaris 10 or solaris 11 should use `fcinfo hba-port`
                TBD (not implemented): on solaris 9 use `prtconf -pv`
                """
                if 'hba-port' in cmd:
                    return out

    executable = '/bin/cat'
    if sys.platform.startswith('linux'):
        out

# Generated at 2022-06-11 03:18:07.039495
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert fcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:18:12.504801
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # Build Instantiation of test object
    fccollector = FcWwnInitiatorFactCollector()
    fc_facts = fccollector.collect()

    print("%s" % fc_facts['fibre_channel_wwn'])


# Execute test
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:18:18.262892
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    if not fact_collector.name == 'fibre_channel_wwn':
        raise AssertionError("Expected fact name to be 'fibre_channel_wwn', got {0}".format(fact_collector.name))

# Generated at 2022-06-11 03:18:20.121105
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:18:22.330656
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()
    assert x.collect() == {}

# Generated at 2022-06-11 03:19:06.584830
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test the constructor of class FcWwnInitiatorFactCollector
    """

    FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:19:09.542446
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:21.763758
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Unit tests for Ansible module 'setup'
    # -------------------------------------------------------------------
    # Test class FcWwnInitiatorFactCollector
    # Test method collect of class FcWwnInitiatorFactCollector
    # Example contents /sys/class/fc_host/*/port_name:
    #
    # 0x21000014ff52a9bb
    #

    testobj = FcWwnInitiatorFactCollector()
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

# Generated at 2022-06-11 03:19:24.300065
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:35.973314
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    ###########################################################################
    # testing the happy path:
    # on linux:
    #   check that the list of lines read from the test file
    #   is equal to the list of list element
    ###########################################################################
    # test file
    sys.platform = 'linux'

# Generated at 2022-06-11 03:19:40.445632
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None

if __name__ == '__main__':
    fact_collector = FcWwnInitiatorFactCollector()
    print(fact_collector.collect())

# Generated at 2022-06-11 03:19:46.237862
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create instance and check if it is of the right type
    obj = FcWwnInitiatorFactCollector()
    assert type(obj) == FcWwnInitiatorFactCollector

    # check name value of instance
    assert obj.name == 'fibre_channel_wwn'

    # check _fact_ids value of instance
    assert obj._fact_ids == set()

# Generated at 2022-06-11 03:19:48.492587
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc is not None
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:20:00.242071
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Create instance of class FcWwnInitiatorFactCollector
    fc_fact_collector = FcWwnInitiatorFactCollector()

    # Create a dummy module object
    module = AnsibleModule(argument_spec=dict())

    # Check return value of method collect of class FcWwnInitiatorFactCollector
    ret = fc_fact_collector.collect(module=module)

    assert ret is not None
    assert 'fibre_channel_wwn' in ret
    assert len(ret['fibre_channel_wwn']) > 0
    assert type(ret['fibre_channel_wwn']) == list

if __name__ == '__main__':
    from ansible.module_utils.facts import AnsibleModule

# Generated at 2022-06-11 03:20:07.728044
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    collector = FcWwnInitiatorFactCollector()
    my_collected_facts = {}
    my_collected_facts = collector.collect()
    print("my_collected_facts %s" % my_collected_facts)


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:21:41.084387
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:21:42.768823
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert not f._fact_ids

# Generated at 2022-06-11 03:21:53.041382
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys
    import unittest
    sys.modules['ansible'] = unittest.mock.MagicMock()
    sys.modules['ansible.module_utils'] = unittest.mock.MagicMock()
    sys.modules['ansible.module_utils.facts'] = unittest.mock.MagicMock()
    sys.modules['ansible.module_utils.facts.utils'] = unittest.mock.MagicMock()
    sys.modules['ansible.module_utils.facts.collector'] = unittest.mock.MagicMock()
    sys.modules['ansible.module_utils.facts.collector.BaseFactCollector'] = unittest.mock.MagicMock()

    FcWwnInitiatorFactCollectorClass = FcWwnInitiatorFactCollect

# Generated at 2022-06-11 03:21:57.952349
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result
    assert result.name == 'fibre_channel_wwn'
    assert result._fact_ids == set()
    assert hasattr(result, 'collect')
    assert callable(getattr(result, 'collect', None))

# Generated at 2022-06-11 03:22:04.149753
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    test_collector = get_collector_instance(FactsCollector, FcWwnInitiatorFactCollector)
    result = test_collector.collect()
    assert result.get('fibre_channel_wwn')
    assert result.get('fibre_channel_wwn') is not []


# Generated at 2022-06-11 03:22:14.995780
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    # add_module is necessary to mock the module for AnsibleModule constructor
    # the return value is a mock.MagicMock
    fcWwnInitiatorFactCollector.add_module(name='ansible.builtin.get_platform_subclass',
                                           source='from ansible.module_utils.facts.platform.base import BaseFactCollector'
                                           )
    fcWwnInitiatorFactCollector.add_module(name='ansible.module_utils.system',
                                           source='from ansible.module_utils.system import *'
                                           )

# Generated at 2022-06-11 03:22:23.246812
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    if 'fibre_channel_wwn' in fc_facts:
        print("Returned fibre_channel_wwn: %s" % (fc_facts['fibre_channel_wwn']))
    else:
        print("Returned facts: %s" % (fc_facts))

# Run test method test_FcWwnInitiatorFactCollector_collect()
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:22:24.834372
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:22:31.611068
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self,*args, **kwargs):
            raise Exception("fail_json")
        def get_bin_path(self, arg, opt_dirs=None):
            if arg == 'fcinfo':
                return '/usr/bin/fcinfo'
            elif arg == 'lsdev':
                return '/usr/bin/lsdev'
            elif arg == 'lscfg':
                return '/usr/bin/lscfg'
            elif arg == 'ioscan':
                return '/usr/sbin/ioscan'
            elif arg == 'fcmsutil' and opt_dirs == ['/opt/fcms/bin']:
                return '/opt/fcms/bin/fcmsutil'

# Generated at 2022-06-11 03:22:41.343687
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import unittest
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):

        def setUp(self):
            class TestModule:
                def run_command(self, cmd, check_rc=True, close_fds=True, executable='/bin/sh', data=None, binary_data=False):
                    if cmd == '/usr/sbin/fcmsutil /dev/fcd0':
                        fcmsutil_content