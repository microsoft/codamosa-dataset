

# Generated at 2022-06-11 03:15:07.246228
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert fcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fcWwnInitiatorFactCollector._fact_ids

# Generated at 2022-06-11 03:15:16.017656
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    fc_fact_collector = FcWwnInitiatorFactCollector(test_module)

    result = fc_fact_collector.collect()

    # test method collect returns a list of WWN values
    assert isinstance(result, dict)
    assert list in [type(x) for x in result.values()]
    assert str in [type(x) for x in result['fibre_channel_wwn']]


# Generated at 2022-06-11 03:15:28.217876
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import tempfile
    import os
    import shutil
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.tests.test_module_utils_facts_collector as test_base
    from ansible.module_utils.facts import collector 
    # create tmp directory
    my_test_dir = tempfile.mkdtemp()
    os.chmod(my_test_dir, 0o777)
    # create txt file with contents
    my_fc_wwn_file = '%s/fc_wwn' % my_test_dir
    fp = open(my_fc_wwn_file, 'w')
    fp.write('0x21000014ff52a9bb')
    fp.close()

# Generated at 2022-06-11 03:15:34.368472
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import mock
    import sys
    module = mock.Mock()
    module.get_bin_path.return_value = None
    fcwwn_fc = FcWwnInitiatorFactCollector()
    fcwwn_fc.collect(module=module)
    assert fcwwn_fc.name == "fibre_channel_wwn"
    module.get_bin_path.return_value = "/usr/bin/fcinfo"
    fcwwn_fc.collect(module=module)
    assert fcwwn_fc.name == "fibre_channel_wwn"
    module.get_bin_path.side_effect = ["/usr/bin/fcinfo", "/usr/sbin/lscfg"]
    fcwwn_fc.collect(module=module)
    assert f

# Generated at 2022-06-11 03:15:35.912039
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:15:39.169005
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import collector

    my_obj = collector.FcWwnInitiatorFactCollector()
    assert my_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:50.363607
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a test fixture
    from ansible.module_utils.facts.hw.fibre_channel import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts import BaseFactCollector
    from ansible.module_utils.facts.collector import FactCollectorCache
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    fact_collector_cache = FactCollectorCache()

    # test
    if __name__ == '__main__':
        fact_collector_cache.collect(base_collector_classes=[FcWwnInitiatorFactCollector])
        facts = fact_collector_cache.get_facts()
        print(facts)
    else:
        if fc_wwn_collector.is_available():
            fc_w

# Generated at 2022-06-11 03:16:00.944529
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()

    # Test 1 - linux system
    class LinuxModule:
        def __init__(self, system_info):
            self.system_info = system_info

        def run_command(self, cmd):
            return 0, """
            0x21000014ff52a9bb
            0x21000014ff52a9bc
            """, None

    class LinuxSystemInfo:
        def __init__(self):
            self.platform = "linux"

    module = LinuxModule(LinuxSystemInfo())
    facts = collector.collect(module)
    assert len(facts["fibre_channel_wwn"]) == 2
    assert facts["fibre_channel_wwn"][0] == "21000014ff52a9bb"

# Generated at 2022-06-11 03:16:03.504258
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:05.938126
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:35.072550
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcFacts = FcWwnInitiatorFactCollector()
    assert fcFacts.name == 'fibre_channel_wwn'
    assert fcFacts._fact_ids == set()


# Generated at 2022-06-11 03:16:40.873249
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=None):
            return '/somepath'

        def run_command(self, cmd):
            print(cmd)
            return 0, "", ""

    obj = FcWwnInitiatorFactCollector()
    obj.collect(TestModule())

# Generated at 2022-06-11 03:16:45.515089
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector_class = FcWwnInitiatorFactCollector
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_fact_collector, fact_collector_class)
    assert len(fc_wwn_fact_collector._fact_ids) == 0


# Generated at 2022-06-11 03:16:47.251986
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector
    assert True == True

# Generated at 2022-06-11 03:16:52.725063
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    ansible_module = DummyAnsibleModule()
    facts = collector.collect(ansible_module)
    assert facts == {
        'fibre_channel_wwn': ['21000024ff52a9bb', '21000014ff52a9bc']
    }

# Unit test (not complete)
# Simply checks if the class can be instantiated

# Generated at 2022-06-11 03:16:54.886832
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    c = FcWwnInitiatorFactCollector()

    assert c.collect() == {}

# Generated at 2022-06-11 03:16:57.805961
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-11 03:17:01.378774
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-11 03:17:11.179431
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    # Test method collect on Linux platform
    platform = 'linux'
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '0x21000014ff52a9bb', '')
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = "/usr/bin/fcinfo"
    module.get_bin_path.side_effect = get_bin_path_side_effect
    facts = {'kernel': platform}
    fc_wwn_facts = fc_wwn_fact_collector.collect(module=module, collected_facts=facts)
    assert f

# Generated at 2022-06-11 03:17:15.283714
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


if __name__ == '__main__':
    # Unit test for FcWwnInitiatorFactCollector
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:18:01.014903
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    ssh_facts = FcWwnInitiatorFactCollector()
    assert ssh_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:03.032370
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:18:05.810011
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-11 03:18:13.871347
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    collectors = Collectors()
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    collectors.add(fc_wwn_initiator)

    # check that we are using right class
    assert isinstance(fc_wwn_initiator, BaseFactCollector)
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'

    # check that 'fibre_channel_wwn' is in the list of already collected
    # facts
    for fact, collector in collectors.items():
        assert fact in fc_

# Generated at 2022-06-11 03:18:17.990131
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = {
              'fibre_channel_wwn': [u'21000014ff52a9bb'],
             }
    assert FcWwnInitiatorFactCollector().collect() == result

# Generated at 2022-06-11 03:18:25.163895
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Prepare
    class ModuleStub(object):
        def __init__(self):
            self._bin_path = 'bin'
            self.run_command_calls = []
        def get_bin_path(self, name, **kwargs):
            return '%s/%s' % (self._bin_path, name)
        def run_command(self, command):
            self.run_command_calls.append(command)
            rc = 0
            if command == 'bin/fcinfo hba-port':
                out = '''HBA Port WWN: 10000090fa1658de'''

# Generated at 2022-06-11 03:18:30.032970
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_class_instance = FcWwnInitiatorFactCollector()
    assert (FcWwnInitiatorFactCollector_class_instance.collect(
    ) == {'fibre_channel_wwn': ["50060b00006975ec", "50060b00006975ec"]})

# Generated at 2022-06-11 03:18:41.349824
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Mock AnsibleModule object
    class AnsibleModuleMock(object):
        def __init__(self):
            self.run_command_result = ('', '', '')
            self.get_bin_path_result = ('/usr/bin/lsdev', '', '')
        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return self.get_bin_path_result
        def run_command(self, cmd, check_rc=True):
            return self.run_command_result



# Generated at 2022-06-11 03:18:45.483547
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    result = FcWwnInitiatorFactCollector().collect(module)
    assert result['ansible_facts']['fibre_channel_wwn'] == ['50060b00006975ec',
                                                            '50060b00006975ec']

# Generated at 2022-06-11 03:18:48.295967
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_class = FcWwnInitiatorFactCollector()
    assert test_class.name == 'fibre_channel_wwn'
    assert test_class._fact_ids == set()

# Generated at 2022-06-11 03:19:34.982815
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn', fc.name


# Generated at 2022-06-11 03:19:42.440918
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector_obj = FcWwnInitiatorFactCollector()
    returned_facts = collector_obj.collect()
    assert 'fibre_channel_wwn' in returned_facts
    assert isinstance(returned_facts['fibre_channel_wwn'], list)
    returned_facts['fibre_channel_wwn'].sort()
    expected = ['21000014ff52a9bb']
    expected.sort()
    assert returned_facts['fibre_channel_wwn'] == expected

# Generated at 2022-06-11 03:19:43.987842
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:19:52.020893
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # =========================================================================
    #  Prepare parameters / command line arguments
    # =========================================================================
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    # =========================================================================
    #  Collect facts
    # =========================================================================
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(collected_facts=fc_facts)
    # =========================================================================
    #  Update facts returned by module
    # =========================================================================
    # init our facts list
    fc_facts['fibre_channel_wwn'] = facts['fibre_channel_wwn']
    # update the facts returned by module (facts.py)
    fc_facts.update(facts)
    # =========================================================================
    #  Print the facts
    # =========================================================================

# Generated at 2022-06-11 03:19:57.547506
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # init class
    obj = FcWwnInitiatorFactCollector()
    # execute method
    facts = obj.collect()
    assert 'fibre_channel_wwn' in facts
    assert facts['fibre_channel_wwn']
    # assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:20:09.406273
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    test_object = FcWwnInitiatorFactCollector()
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.exit_json = lambda x: None
            self.fail_json = lambda **kwargs: None

# Generated at 2022-06-11 03:20:14.465429
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {}
    oFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    fc_facts = oFcWwnInitiatorFactCollector.collect()
    assert fc_facts['fibre_channel_wwn']
# END of Unit test for constructor of class FcWwnInitiatorFactCollector


# Generated at 2022-06-11 03:20:17.446523
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:20:20.332966
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except:
        raise Exception('FcWwnInitiatorFactCollector() not working')

# Generated at 2022-06-11 03:20:23.211479
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test1 = FcWwnInitiatorFactCollector()
    assert test1.name == 'fibre_channel_wwn'
    assert test1._fact_ids == set()

# Generated at 2022-06-11 03:22:02.384277
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector._fact_ids == set()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:08.730660
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc is not None, 'Failed to instantiate FcWwnInitiatorFactCollector'
    assert fc.name == 'fibre_channel_wwn', 'Failed to set name of FcWwnInitiatorFactCollector'
    assert fc._fact_ids == set(), 'Failed to set _fact_ids of FcWwnInitiatorFactCollector'


# Generated at 2022-06-11 03:22:11.304919
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    assert o.name == 'fibre_channel_wwn'
    assert o._fact_ids == set()

# Generated at 2022-06-11 03:22:20.765532
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
  from unittest.mock import Mock, patch
  from ansible.module_utils.facts import Facts

  module = Mock()
  fc_collector = FcWwnInitiatorFactCollector(module=module)
  fc_collector.collect()

  assert fc_collector
  assert module._name == 'FcWwnInitiatorFactCollector'
  assert module.run_command.call_count == 3
  assert module.get_bin_path.call_count == 4


# Generated at 2022-06-11 03:22:29.797951
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # we need a class from ansible.module_utils.common
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.utils import module_hide_deprecated_facts

    # init collector
    fc = FcWwnInitiatorFactCollector()
    # init module
    # we mock the module here to make the unit test work
    class FakeModule():
        def __init__(self):
            self.params = {
                'collect_subset': 'all'
            }
            self.config = {}
            self.exit_json = lambda: None
        def get_bin_path(self, name, opt_dirs=[]):
            return None

    module = FakeModule()

    # init collector result
    collected_facts = {}
    # init

# Generated at 2022-06-11 03:22:40.450060
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import unittest
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    class LinuxFaker():
        @staticmethod
        def get_bin_path(cmd):
            return cmd

    class AixFaker():
        @staticmethod
        def get_bin_path(cmd):
            return cmd

    class HpFaker():
        @staticmethod
        def get_bin_path(cmd):
            return cmd

    class SolarisFaker():
        @staticmethod
        def get_bin_path(cmd):
            return cmd

    class FakeTmpClass(BaseFactCollector):
        pass


# Generated at 2022-06-11 03:22:43.709215
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert hasattr(collector, 'collect')

# Generated at 2022-06-11 03:22:48.820315
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set(['fibre_channel_wwn'])
    assert fc_facts.collect() == {}

# Generated at 2022-06-11 03:22:53.173241
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert '0x2100004db04d4d4c' in fc_facts['fibre_channel_wwn']

# Generated at 2022-06-11 03:22:57.134824
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts_list = fc_facts.collect()
    assert type(fc_facts_list) is dict
    assert 'fibre_channel_wwn' in fc_facts_list
    assert type(fc_facts_list['fibre_channel_wwn']) is list