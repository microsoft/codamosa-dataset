

# Generated at 2022-06-11 03:15:02.571963
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:12.457994
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Get the test facts dictionary
    test_facts = FactsCollector().get_facts()

    # Create a new FcWwnInitiatorFactCollector
    fc_wwn_collector = FcWwnInitiatorFactCollector()

    # Add the facts collected by FcWwnInitiatorFactCollector
    fc_wwn_collector.collect(test_facts)

    # Check if fibre_channel_wwn key is in the facts dictionary
    assert 'fibre_channel_wwn' in test_facts

    # Check if the fibre_channel_wwn key is a list
    assert isinstance(test_facts['fibre_channel_wwn'], list)


# Generated at 2022-06-11 03:15:14.166957
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'



# Generated at 2022-06-11 03:15:16.766325
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mc = FcWwnInitiatorFactCollector()
    mc._module = 'some_module'
    facts = mc.collect()
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-11 03:15:28.600856
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.collector

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.config = {}
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outputs = []
            self.get_bin_path_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            self.get_bin_path_calls.append([name, opt_dirs])
            if "not_existing_binary" in name:
                return None
            return name



# Generated at 2022-06-11 03:15:32.474093
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    :return:
    """
    o_obj = FcWwnInitiatorFactCollector()
    assert o_obj is not None


# Generated at 2022-06-11 03:15:43.278791
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import io

    m = basic.AnsibleModule(argument_spec=dict())
    m.run_command = lambda *a, **kw: (0, to_bytes('''HBA Port WWN: 10000090fa1658de
HBA Port WWN: 10000090fa1658dd
HBA Port WWN: 10000090fa1658df'''), '')
    m.get_bin_path = lambda *a, **kw: 'fcinfo'

    c = Collector(m)
    c._collectors

# Generated at 2022-06-11 03:15:52.826295
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append('21000014ff52a9bb')
    if sys.platform.startswith('linux'):
        import __builtin__
        __builtin__.open = open
        try:
            fc_facts_linux = FcWwnInitiatorFactCollector().collect()
        finally:
            del __builtin__.open
        # 'fibre_channel_wwn' key is present and equal
        assert fc_facts_linux['fibre_channel_wwn'][0] == fc_facts['fibre_channel_wwn'][0]
        # 'fibre_channel_wwn' is present only once


# Generated at 2022-06-11 03:15:54.467625
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-11 03:16:03.330926
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    class LinuxFcWwnUUT(object):
        def __init__(self, fc_wwn):
            self.fc_wwn = fc_wwn

        def __call__(self, *args, **kwargs):
            # parse params (args and kwargs)
            module_args = args[0]
            method = module_args['method']
            path = module_args['path']
            if method == 'glob':
                return self.fc_wwn
            elif method == 'get_file_lines':
                assert path == '/sys/class/fc_host/*/port_name'
                return ['0x20000000c950a1f5']


# Generated at 2022-06-11 03:16:18.582333
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc1 = FcWwnInitiatorFactCollector()

    assert 'fibre_channel_wwn' == fc1.name
    assert set() == fc1._fact_ids

# Generated at 2022-06-11 03:16:21.068081
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_module = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == facts_module.name

# Generated at 2022-06-11 03:16:23.208005
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-11 03:16:28.742471
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert str(x) == '<ansible.module_utils.facts.system.fibre_channel_wwn.FcWwnInitiatorFactCollector object at 0x7f046106aac8>'
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:36.334550
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import CollectorsRegistry
    fc_wwn_collector = CollectorsRegistry.get_collector("fibre_channel_wwn")
    assert fc_wwn_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_collector.__class__.__name__ == 'FcWwnInitiatorFactCollector'

# Generated at 2022-06-11 03:16:46.062669
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    collector = FcWwnInitiatorFactCollector()

    # test if collect method returns right info for platform
    fc_facts = collector.collect(module)
    if sys.platform.startswith('linux'):
        assert len(fc_facts['fibre_channel_wwn']) == 1
        assert fc_facts['fibre_channel_wwn'][0] == '21000014ff52a9bb'
    elif sys.platform.startswith('sunos'):
        assert len(fc_facts['fibre_channel_wwn']) == 2

# Generated at 2022-06-11 03:16:52.202091
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mock_module = object
    mock_module.run_command = lambda x: (0, '', '')
    mock_module.get_bin_path = lambda x: ':' + x
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = fcwwn_fact_collector.collect(module=mock_module)
    assert collected_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-11 03:17:03.561104
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method FcWwnInitiatorFactCollector.collect
    """
    class Module(object):
        """
        Mock class for the module
        """


# Generated at 2022-06-11 03:17:07.272458
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create instance of class FcWwnInitiatorFactCollector
    test_obj = FcWwnInitiatorFactCollector()
    # run method collect from class FcWwnInitiatorFactCollector
    test_obj.collect()

# Run
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:17:10.161609
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)

# Generated at 2022-06-11 03:17:38.317523
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = type('Dummy', (object,), {'get_bin_path': lambda self, p: p})
    collector = FcWwnInitiatorFactCollector(module)
    assert collector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in collector.collect()

# Generated at 2022-06-11 03:17:50.792354
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import mock
    import module_utils.facts.hardware.fibre_channel_wwn_initiator

    # set up mocks
    fake_module = mock.Mock()
    fake_module.params = {}
    fake_collected_facts = {}

    # create instance to be tested
    fcwwn_fact_collector = module_utils.facts.hardware.fibre_channel_wwn_initiator.FcWwnInitiatorFactCollector()

    # call method collect of class FcWwnInitiatorFactCollector    
    facts = fcwwn_fact_collector.collect(fake_module, fake_collected_facts)

    # assertions
    assert isinstance(facts, dict)

# Generated at 2022-06-11 03:17:57.525309
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ModuleDataCollector

    class TestModule(object):
        def __init__(self):
            self.run_command_environ_backup = {}
            self.params = { 'gather_subset': ['all'] }
            self.run_command_environ_backup = {}
            self.run_command_calls = []
            self.run_command_results = []
            self.run_command_correct_args = False
            self.fail_json_result = {}
            self.command_calls = []
            self.command_results = []
            self.command_correct_args = False
            self.parsed_params = {}


# Generated at 2022-06-11 03:17:59.989579
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:08.008295
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.params = {}
    fc_collector = FcWwnInitiatorFactCollector()
    facts = fc_collector.collect(module=module)
    assert isinstance(facts, dict)
    if 'fibre_channel_wwn' in facts:
        # we expect a list of strings
        assert isinstance(facts['fibre_channel_wwn'], list)
        for item in facts['fibre_channel_wwn']:
            assert isinstance(item, str)


# Generated at 2022-06-11 03:18:09.153256
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert str(FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:18:12.565736
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    col = FcWwnInitiatorFactCollector()
    assert col.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:18:24.101069
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert 'fibre_channel_wwn' not in sys.modules['ansible.module_utils.facts.fibre_channel_wwn'].FACT_SUBSETS
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.priority == 80
    assert FcWwnInitiatorFactCollector.__doc__ == '''
        Collects Fibre Channel WWN initiator related facts.
        '''

# Generated at 2022-06-11 03:18:35.479997
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule(object):
        def __init__(self, results):
            self.results = results

        def get_bin_path(self, executable, opt_dirs=[]):
            return executable

        def run_command(self, cmd):
            return self.results[cmd]

    class MockAnsibleModule(object):
        def __init__(self, results):
            self.run_command = MockModule(results).run_command
            self.get_bin_path = MockModule(results).get_bin_path

    class MockCollectedFacts(object):
        def __init__(self, fc_facts):
            self.fc_facts = fc_facts

        def __getitem__(self, key):
            return self.fc_facts[key]


# Generated at 2022-06-11 03:18:36.514734
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:23.714512
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for FcWwnInitiatorFactCollector.collect"""

    # collect
    test_collector = FcWwnInitiatorFactCollector()
    test_collector.collect()

# Generated at 2022-06-11 03:19:25.918826
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-11 03:19:30.101077
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    ffc = FcWwnInitiatorFactCollector()
    assert ffc.name == 'fibre_channel_wwn'
    assert 'Fibre Channel WWN' in ffc.collect().keys()

# Generated at 2022-06-11 03:19:33.905771
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert fc_wwn._fact_ids == set()


# Generated at 2022-06-11 03:19:36.441519
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Unit tests for collect() of class FcWwnInitiatorFactCollector

# Generated at 2022-06-11 03:19:39.738451
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_facts = FcWwnInitiatorFactCollector()
    assert fc_wwn_facts._fact_ids is not None

# Generated at 2022-06-11 03:19:49.938592
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-11 03:19:53.615511
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:19:58.261606
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'
    assert fc_obj._fact_ids == set()
    assert fc_obj.collect() == {}

# Generated at 2022-06-11 03:20:01.777681
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'
    assert a._fact_ids == set()

# Generated at 2022-06-11 03:21:40.389900
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:21:41.040331
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-11 03:21:44.619239
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()

# Generated at 2022-06-11 03:21:54.483399
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import os
    import tempfile
    import platform
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts

    mock_module = ansible.module_utils.facts.collector.AnsibleModuleMock()
    mock_module.run_command = ansible.module_utils.facts.collector.run_command
    mock_module.get_bin_path = ansible.module_utils.facts.collector.get_bin_path

    # write solaris fcinfo output to temporary file

# Generated at 2022-06-11 03:21:57.644869
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:00.298383
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fw = FcWwnInitiatorFactCollector()
    assert fw.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:05.967238
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector.collect() == {} # can not be implemeneted on windows due to missing wmic command


# Generated at 2022-06-11 03:22:06.977148
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TBD: test code
    pass

# Generated at 2022-06-11 03:22:12.965614
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factCollector = FcWwnInitiatorFactCollector(None)
    assert factCollector.name == 'fibre_channel_wwn'

# Get facts: If a FAKE_COLLECTOR_FACT_DIR environment variable is set then
# load the facts from that directory and return the results, otherwise perform
# normal fact collection and return the results.

# Generated at 2022-06-11 03:22:16.690333
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Fact collecting test.

    :return:
    """
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.collect()

    #sys.exit(2)
