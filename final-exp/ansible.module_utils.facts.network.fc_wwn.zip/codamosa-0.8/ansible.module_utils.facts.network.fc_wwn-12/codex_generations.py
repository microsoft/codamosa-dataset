

# Generated at 2022-06-11 03:15:05.755149
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert type(x._fact_ids) == set



# Generated at 2022-06-11 03:15:12.886611
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = dict()
    fc_facts['fibre_channel_wwn'] = []

    expected_fc_facts = dict()
    expected_fc_facts['fibre_channel_wwn'] = []

    fc_facts_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_facts_collector.collect(module=None, collected_facts=fc_facts)

    assert fc_facts == expected_fc_facts


# Generated at 2022-06-11 03:15:20.331889
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts import collect_solaris_10_or_11_fcinfo
    from ansible.module_utils.facts import collect_aix_fcinfo
    from ansible.module_utils.facts import collect_hp_ux_fcinfo
    import os
    import sys
    import glob
    import shutil

    # prepare
    test_file_path = "/tmp/test_ansible_facts_fibre_channel_wwn"
    test_file_path_glob = os.path.join(test_file_path,"*/")
    class MockModule():
        def run_command(self, cmd, check_rc=False, close_fds=True, executable=None, data=None):
            return

# Generated at 2022-06-11 03:15:32.757853
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.facts import FactCollector

    if sys.version_info.major >= 3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    test_mock = basic.AnsibleModule(
        argument_spec={},
    )

    test_mock.run_command = lambda x: (0, 'some_out', '')

    test_collector = FcWwnInitiatorFactCollector(test_mock)
    fc_facts = test_collector.collect()
    assert isinstance(fc_facts, dict)

    collected_facts = {}

# Generated at 2022-06-11 03:15:44.388362
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    collectorClasses = Collector.get_collector_classes()

    # retrieve class for FcWwnInitiatorFactCollector
    fcclass = None
    for collectorClass in collectorClasses:
        if collectorClass.__name__ == "FcWwnInitiatorFactCollector":
            fcclass = collectorClass
            break

    # test
    if fcclass:
        fccollector = fcclass()
        fccollector.collect()
        assert "fibre_channel_wwn" in fccollector.collect()
        assert isinstance(fccollector.collect(), dict)
        assert fccollector.collect_

# Generated at 2022-06-11 03:15:53.087392
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    # define fact collector
    fact_collector = FcWwnInitiatorFactCollector(module=module)
    # collect facts
    facts = fact_collector.collect(module=module)
    # test facts
    # fibrec_channel_wwn should be a list
    assert isinstance(facts['fibre_channel_wwn'], list)
    for factid in facts:
        # factid should only contain characters [a-zA-Z0-9_]
        assert re.match(r'^[a-zA-Z0-9_]+$', factid)
        # fact data should not be empty
        assert facts[factid]
        # each fact should be a list
        assert isinstance(facts[factid], list)
        # each list

# Generated at 2022-06-11 03:16:02.916355
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock
    from ansible.module_utils.facts import ansible_collections
    from ansible.module_utils.facts.collector import BaseFactCollector
    import os

    class ModuleMock(object):
        def __init__(self):
            self.run_command = MagicMock(return_value=(0, '', ''))
            self.get_bin_path = MagicMock(return_value='/tmp/does/not/exist')

    module = ModuleMock()
    def get_file_lines(*args, **kwargs):
        return ['0x21000014ff52a9bb\n']

# Generated at 2022-06-11 03:16:15.356132
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

    fc_facts_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_facts_collector.collect()

    # tests assertions:
    # on linux
    assert fc_facts['fibre_channel_wwn'][0] == '21000014ff52a9bb'
    # on solaris 10, solaris 11
    assert fc_facts['fibre_channel_wwn'][0] == '10000090fa1658de'
    # on aix

# Generated at 2022-06-11 03:16:16.038712
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-11 03:16:26.986910
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    AnsibleModule mock object which will be used for unit testing
    """

    module = AnsibleModuleMock()

    if sys.platform.startswith('linux'):
        module.get_bin_path.side_effect = lambda x: "/bin/" + x
    elif sys.platform.startswith('sunos'):
        module.get_bin_path.side_effect = lambda x: "/usr/sbin/" + x
    elif sys.platform.startswith('aix'):
        module.get_bin_path.side_effect = lambda x: "/usr/sbin/" + x
    elif sys.platform.startswith('hp-ux'):
        module.get_bin_path.side_effect = lambda x, opt_dirs: x


# Generated at 2022-06-11 03:16:41.929194
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:16:47.291516
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test the constructor of class FcWwnInitiatorFactCollector with
    different input values.
    """
    # test with valid input
    fc_collector = FcWwnInitiatorFactCollector()

    # test with invalid input
    try:
        fc_collector = FcWwnInitiatorFactCollector('')
    except:
        pass


# Generated at 2022-06-11 03:16:55.205458
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    class MockModule:
        def __init__(self):
            self.params = dict()
            self.exit_json = basic.AnsibleModule.exit_json
            self.fail_json = basic.AnsibleModule.fail_json

    class MockCollector:
        def __init__(self):
            self.collector = {}

        def collect(self, module, collected_facts):
            self.collector = FcWwnInitiatorFactCollector.collect(self, module, collected_facts)
            return self.collector

    mock_module = MockModule()
    mock_collector = MockCollector()
    collector.add_collector(mock_collector)


# Generated at 2022-06-11 03:17:05.908442
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test class method 'collect' of class FcWwnInitiatorFactCollector.
    """

    # pylint: disable=import-error
    module = ansible_module_mock

    # pylint: disable=no-member
    module.run_command = run_command_mock

    # pylint: disable=attribute-defined-outside-init
    # pylint: disable=attribute-defined-outside-init
    class FcWwnInitiatorFactCollectorMock:
        """
        Mock class for FcWwnInitiatorFactCollector.
        """
        def __init__(self, module):
            """
            Test class constructor.

            :param module: The Ansible module
            """
            self.module = module


# Generated at 2022-06-11 03:17:07.647489
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids ==  set()

# Generated at 2022-06-11 03:17:16.363356
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import ansible_collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import unittest

    class MockModule(object):

        def __init__(self):
            self.run_command_results = []
            self.run_command_expectations = []

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/path/to/bin/' + arg

        def run_command(self, cmd):
            expected_cmd = self.run_command_expectations.pop(0)

# Generated at 2022-06-11 03:17:19.119497
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test = FcWwnInitiatorFactCollector()
    assert test.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in test._fact_ids

# Generated at 2022-06-11 03:17:26.648055
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.__class__.__name__ == FcWwnInitiatorFactCollector.__name__
    assert fc_collector.__class__.__name__ == "FcWwnInitiatorFactCollector"
    assert fc_collector.__class__.__doc__ == FcWwnInitiatorFactCollector.__doc__
    assert fc_collector.name == "fibre_channel_wwn"
    assert fc_collector._fact_ids == set()

# Generated at 2022-06-11 03:17:36.132251
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', '!min']

    class MockFactCollector(object):
        def __init__(self, module):
            self.module = module

    test_ansible_module = MockModule()
    test_fact_collector = MockFactCollector(test_ansible_module)

    fc_wwn_collector = FcWwnInitiatorFactCollector(test_ansible_module, test_fact_collector)

    assert fc_wwn_collector.name == "fibre_channel_wwn"

# Generated at 2022-06-11 03:17:39.100381
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:18:07.414496
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = MockModule()
    fc_facts_obj = FcWwnInitiatorFactCollector()
    # Check if object is of type FcWwnInitiatorFactCollector
    assert isinstance(fc_facts_obj, FcWwnInitiatorFactCollector)


# Generated at 2022-06-11 03:18:11.933201
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector

    collector = Collector(FcWwnInitiatorFactCollector('fibre_channel_wwn'))
    facts = collector.fetch_facts()
    fc = facts['fibre_channel_wwn']

    assert isinstance(fc, list)
    for wwn in fc:
        assert isinstance(wwn, str)

# Generated at 2022-06-11 03:18:21.758734
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector

    The constructor should save the name of the fact it's going to collect in
    an attribute called name. Then based on that name it should dynamically
    create the name of the fact that it will return.

    It should also create a list of fact ids that it will return. Those fact ids
    should also be based on the name attribute.
    """
    obj = FcWwnInitiatorFactCollector()

    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-11 03:18:24.186669
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_collector is not None

# Generated at 2022-06-11 03:18:29.755828
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass
#    from ansible.module_utils.facts.collector import Collector
#    from ansible.module_utils.facts.facts import Facts
#
#    facts = Facts({})
#    collector = Collector(facts, None)
#    fc = FcWwnInitiatorFactCollector(collector)
#    result = fc.collect()
#    print(result)

# Generated at 2022-06-11 03:18:32.209189
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:42.873436
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.network import NetworkCollector
    network_collector = NetworkCollector()
    collect_net = network_collector.collect()

    # mock module
    class ModuleFake:
        def __init__(self):
            self.params = {}
            self.run_command = run_command
        def get_bin_path(self, arg, opt_dirs=None):
            return "/bin/%s" % arg

    # mock run_command

# Generated at 2022-06-11 03:18:47.786755
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collection_mock

    ansible_collection_mock. AnsibleCollectionMock()
    obj = FcWwnInitiatorFactCollector()
    facts = obj.collect()

    assert len(facts) > 0
    assert facts['fibre_channel_wwn'] is not None
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:18:50.635801
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result


# Generated at 2022-06-11 03:18:56.726645
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector.collect()
    assert 'fibre_channel_wwn' in fc_facts, \
        "did not find fc port names in output of FcWwnInitiatorFactCollector"
    assert len(fc_facts['fibre_channel_wwn']), \
        "FcWwnInitiatorFactCollector returned empty list of fc port names"

# Generated at 2022-06-11 03:19:46.975939
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector({})
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:49.033634
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_dict = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in facts_dict

# Generated at 2022-06-11 03:19:50.244730
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:20:03.020271
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # all methods of class BaseFactCollector are mocked
    obj = FcWwnInitiatorFactCollector(None, None)
    # create mocked section in configuration 'fibre_channel_wwn'
    obj.configuration = {'fibre_channel_wwn': {'fact_fibre_channel_wwn_root_key': 'fibre_channel_wwn'}}

# Generated at 2022-06-11 03:20:13.655700
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create test class
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        # create mock ansible module
        class AnsibleModule(object):
            def __init__(self):
                pass
            def get_bin_path(self, name, opt_dirs=None):
                if name == 'lsdev':
                    return 'lsdev'
                if name == 'lscfg':
                    return 'lscfg'
                if name == 'fcinfo':
                    return 'fcinfo'

# Generated at 2022-06-11 03:20:16.882554
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x
    assert x.name == "fibre_channel_wwn"
    assert x._fact_ids == set()

# Generated at 2022-06-11 03:20:19.681888
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()

# Generated at 2022-06-11 03:20:29.981781
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """FcWwnInitiatorFactCollector - collect"""
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    module = AnsibleExitJson()
    # Mock module parameters
    module._debug = True
    # Setup test set of input with expected output

# Generated at 2022-06-11 03:20:36.274327
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Arrange
    fc_facts = {}
    module = MagicMock()
    collector = FcWwnInitiatorFactCollector(module)

    # Act
    fc_facts = collector.collect()

    # Assert
    assert len(fc_facts['fibre_channel_wwn']) > 0, \
        'FcWwnInitiatorFactCollector().collect() should return a list of the' +\
        ' WWN for all FC interfaces on the system'



# Generated at 2022-06-11 03:20:47.194621
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    fc_wwn_init_collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:22:29.287489
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-11 03:22:39.979753
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import json
    import os


    # create dummy class with instance variables
    class MockedModule(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            if args[0] == 'lsdev':
                return True
            if args[0] == 'lscfg':
                return True
            if args[0] == 'ioscan':
                return True

# Generated at 2022-06-11 03:22:52.061058
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create mocked module object
    # note: Mock only supports the magic methods __getattr__, __setattr__, __call__ and __len__
    module_obj = Mock()

    # create mocked class object of class FcWwnInitiatorFactCollector
    fc_wwn_obj = Mock()

    # create instance of class FcWwnInitiatorFactCollector
    fc_wwn_collector = FcWwnInitiatorFactCollector()

    # Test collect method of class FcWwnInitiatorFactCollector
    #
    # mock sys.platform attribute
    # linux like platform
    sys.platform = "linux"

    # create dummy host_name files
    host_names=["0x21000024ff52a9bc","0x21000014ff52a9bb"]

    # read_

# Generated at 2022-06-11 03:22:54.998670
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_f = FcWwnInitiatorFactCollector()
    assert fc_f.name == 'fibre_channel_wwn'
    assert fc_f.collect() == {}

# Generated at 2022-06-11 03:23:05.568363
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()
    assert 'fibre_channel_wwn' in facts
    if sys.platform.startswith('aix'):
        assert len(facts['fibre_channel_wwn']) == 1
        assert '10000090fa1658de' in facts['fibre_channel_wwn']
    elif sys.platform.startswith('hp-ux'):
        assert len(facts['fibre_channel_wwn']) > 0
        assert '0x50060b00006975ec' in facts['fibre_channel_wwn']
    elif sys.platform.startswith('sunos'):
        assert len(facts['fibre_channel_wwn']) > 0


# Generated at 2022-06-11 03:23:16.086836
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            pass
        def get_bin_path(self, binary, opt_dirs=[]):
            return '/bin/%s' % binary

        def run_command(self, cmd):
            return (0, 'PRETEND_OUTPUT', '')

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            pass

    class MockFactsCollector(object):
        def __init__(self):
            self.facts = {}


# Generated at 2022-06-11 03:23:19.752654
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_info = FcWwnInitiatorFactCollector()
    assert fc_info.name == 'fibre_channel_wwn'
    assert fc_info.priority == 10
    assert fc_info._fact_ids == set()

# Generated at 2022-06-11 03:23:23.896844
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector_class = FcWwnInitiatorFactCollector()
    fact_collector_class.collect()
    assert fact_collector_class.name == 'fibre_channel_wwn'
    assert fact_collector_class._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-11 03:23:26.059083
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert isinstance(c.name, str)


# Generated at 2022-06-11 03:23:28.531847
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'fibre_channel_wwn'