

# Generated at 2022-06-11 03:15:05.450007
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_object = FcWwnInitiatorFactCollector()
    assert test_object
    assert test_object.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:15.977143
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # mock module and collected_facts
    from ansible_collections.ansible.netcommon.plugins.module_utils.facts.facts import Facts
    from ansible_collections.ansible.netcommon.plugins.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector
    from ansible_collections.ansible.netcommon.plugins.module_utils.facts.utils import get_file_content

    module = AnsibleModuleMock()
    collected_facts = Facts(module)

    # set platform to linux and collect facts
    module.set_platform('linux')
    FcWwnInitiatorFactCollector(module=module).collect(module=module, collected_facts=collected_facts)
    # expected facts
    facts = {}

# Generated at 2022-06-11 03:15:19.652726
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_initiator = FcWwnInitiatorFactCollector()
    assert fc_initiator.name == 'fibre_channel_wwn'
    assert fc_initiator._fact_ids == set()

# Generated at 2022-06-11 03:15:29.045767
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    collector = Collector()
    fc_collector = FcWwnInitiatorFactCollector(collector)
    collected_facts = {}
    fc_collector.collect(collected_facts=collected_facts)
    assert 'fibre_channel_wwn' in collected_facts


if __name__ == '__main__':
    # Unit test
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:15:32.474092
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:35.715415
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    Collector.add_collector(FcWwnInitiatorFactCollector)
    facts = Collector.collect(do_refresh=False, cached=True)
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-11 03:15:41.208763
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector
    collector = Collector.load_collectors([FcWwnInitiatorFactCollector])
    assert isinstance(collector, FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:15:45.121358
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()


# Generated at 2022-06-11 03:15:48.137984
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  oFcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
  assert oFcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'



# Generated at 2022-06-11 03:15:59.883343
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method tests the collect method of FcWwnInitiatorFactCollector with
     following cases:
    1) linux case
    2) sunos case
    3) aix case
    4) hp-ux case
    """
    from ansible.module_utils.facts.collector.platform.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils.platform import Platform

    class TestPlatform(Platform):
        def get_file_lines(self, filename):
            """
            This method returns list of file lines, in this test case we are
            hardcoding the return value.
            """

# Generated at 2022-06-11 03:16:20.093181
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class MockModule(object):
        def get_bin_path(self, name, opt_dirs=None, required=False):
            if name == 'fcinfo' and sys.platform.startswith('sunos'):
                return name
            if name == 'ioscan' and sys.platform.startswith('hp-ux'):
                return name
            if name == 'fcmsutil':
                return name

    FcWwnInitiatorFactCollector(MockModule)

# Generated at 2022-06-11 03:16:25.871745
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import unittest
    import ansible.utils.py3compat
    from ansible.module_utils.facts import ansible_collector

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):

        def test_collect_empty(self):
            temp_collector = ansible_collector.get_collector('fibre_channel_wwn')
            temp_collector.collect = lambda self: {}
            temp_collector.collect()
            expected_result = {'fibre_channel_wwn': []}
            self.assertEqual(ansible_collector.get_ansible_module_facts()['fibre_channel_wwn'],
                             expected_result['fibre_channel_wwn'])


# Generated at 2022-06-11 03:16:37.586673
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json

    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()

    # Example (wwn of fibre-channel initiator)
    test_input = '0x21000014ff52a9bb'
    test_in_f = '/tmp/fc_host'
    test_in_file = test_in_f + '/port_name'
    test_in_dir = test_in_f[:-1]
    if sys.version_info[0] < 3:
        with open(test_in_file, mode='wb') as test_file:
            test_file.write(test_input)

# Generated at 2022-06-11 03:16:38.751708
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-11 03:16:48.381224
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector

    class DummyModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda v, **kwargs: sys.exit(0)
            self.fail_json = lambda **kwargs: sys.exit(1)

        def get_bin_path(self, binary_name, opt_dirs=[]):
            if binary_name == 'lscfg' and sys.platform == 'aix':
                return binary_name
            if binary_name == 'lsdev' and sys.platform == 'aix':
                return binary_name
            if binary_name == 'ioscan' and sys.platform == 'hp-ux':
                return binary_name

# Generated at 2022-06-11 03:16:52.840186
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Facts
    fc_facts = FcWwnInitiatorFactCollector(Facts())
    fc_wwn_facts = fc_facts.collect()
    # check if facts are collected properly
    assert len(fc_wwn_facts['fibre_channel_wwn']) >= 1

# Generated at 2022-06-11 03:17:04.175004
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule(object):
        def __init__(self, run_command_result=None, bin_path_result=None):
            self.run_command_result = run_command_result
            self.bin_path_result = bin_path_result

        def run_command(self, cmd):
            return self.run_command_result

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path_result

    # Test case 1: linux - simple
    test_module = TestModule(run_command_result=(0, '', ''))
    test_collector = FcWwnInitiatorFactCollector()
    result = test_collector.collect(test_module)

# Generated at 2022-06-11 03:17:05.998867
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector.collect()
    assert(len(fc_facts['fibre_channel_wwn']) > 0)

# Generated at 2022-06-11 03:17:11.672308
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collectors.network.fibre_channel_wwn as FibreChannelWwnModule
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector

    module = basic.AnsibleModule(arg_spec=dict())
    module.exit_json = basic.AnsibleModule.exit_json

    # Mock for the glob.glob call
    def mock_glob(pathname):
        return ["/sys/class/fc_host/host1/port_name"]

    # Mock for the get_file_lines call
    def mock_get_file_lines(file):
        return ["0x21000014ff52a9bb"]

    # Mock

# Generated at 2022-06-11 03:17:13.105617
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:17:25.799433
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:17:28.501929
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# class FcWwnInitiatorFactCollector

# Generated at 2022-06-11 03:17:30.866450
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:34.720827
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == {'fibre_channel_wwn'}

# Generated at 2022-06-11 03:17:38.815492
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()


# Generated at 2022-06-11 03:17:51.141133
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class FakeModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'lsdev':
                return 'lsdev'
            if executable == 'fcinfo':
                return 'fcinfo'
            if executable == 'lscfg':
                return 'lscfg'
            if executable == 'ioscan':
                return 'ioscan'
            if executable == 'fcmsutil':
                return 'fcmsutil'
            return None


# Generated at 2022-06-11 03:17:52.437721
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:18:04.665527
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module = basic.AnsibleModule(
            argument_spec={},
            supports_check_mode=True)

    set_module_args({})

    mocked_class_collector = 'ansible_collections.ansible.community.plugins.module_utils.facts.platform.fibre_channel.FcWwnInitiatorFactCollector'
    with unittest.mock.patch(mocked_class_collector) as mocked_collector:
        mocked_collector._fact_ids = set()
        mocked_

# Generated at 2022-06-11 03:18:08.004825
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    if not isinstance(obj, FcWwnInitiatorFactCollector):
        raise AssertionError('Cannot instantiate FcWwnInitiatorFactCollector')


# Generated at 2022-06-11 03:18:09.978269
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwi_fc = FcWwnInitiatorFactCollector()
    assert fwi_fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:42.490953
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = dict()
    fc_facts['fibre_channel_wwn'] = []

    # run tested method and assert results
    fc_initiator_collector = FcWwnInitiatorFactCollector()
    assert fc_initiator_collector.collect() == fc_facts

if __name__ == '__main__':
    # abspath needed for coverage to be picked up for the test run
    import os
    os.chdir(os.path.abspath(os.path.dirname(__file__)))
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:18:49.449965
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if sys.platform.startswith('hp-ux'):
        cmd = '/sbin/ioscan'
        fcmsu_cmd = '/opt/fcms/bin/fcmsutil'
        if cmd and fcmsu_cmd:
            cmd = cmd + " -fnC FC"
            rc, ioscan_out, err = module.run_command(cmd)
            if rc == 0 and ioscan_out:
                for line in ioscan_out.splitlines():
                    line = line.strip()
                    if '/dev/fcd' in line:
                        dev = line.split(' ')
                        # get device information
                        cmd = fcmsu_cmd + " %s" % dev[0]
                        rc, fcmsutil_out, err = module.run_command(cmd)
                        # lookup the following line


# Generated at 2022-06-11 03:18:59.412724
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestAnsibleModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            return name

        def run_command(self, cmd):
            return 0, "", ""

    class TestCollector(object):
        def collected_facts(self):
            return {}

    test_module = TestAnsibleModule()
    test_collector = TestCollector()
    fc_fact_collector = FcWwnInitiatorFactCollector(test_module, test_collector)
    fc_facts = fc_fact_collector.collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:19:01.331836
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:04.060387
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert isinstance(f._fact_ids, set)

# Generated at 2022-06-11 03:19:06.079944
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:10.227514
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  fc_info_facts = FcWwnInitiatorFactCollector()
  assert len(fc_info_facts.collect()) == 1

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:11.498703
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:13.446967
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector(None)
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-11 03:19:19.456599
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fake_module = FakeModule()
    fcs = FcWwnInitiatorFactCollector(fake_module)
    fc_facts = fcs.collect()
    assert fc_facts == {u'fibre_channel_wwn': [u'21000014ff52a9bb']}


# Test class for FcWwnInitiatorFactCollector

# Generated at 2022-06-11 03:20:06.288662
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-11 03:20:11.135091
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert test_FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert test_FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-11 03:20:14.385590
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Testing constructor of the class FcWwnInitiatorFactCollector
    fwwin =  FcWwnInitiatorFactCollector()
    assert fwwin.name == 'fibre_channel_wwn'
    assert fwwin._fact_ids == set()

# Generated at 2022-06-11 03:20:18.010425
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    print(fc_collector.name)
    print(fc_collector._fact_ids)


# Generated at 2022-06-11 03:20:29.071425
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    test_collected_facts = {}

# Generated at 2022-06-11 03:20:36.273615
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import ansible_runner
    import os
    import pytest
    fc_resource = FcWwnInitiatorFactCollector()
    with pytest.raises(Exception) as excinfo:
        fc_resource.collect()
    assert excinfo.value.args[0] == "Failed to get fc_host/port_name: List index out of range"


# Generated at 2022-06-11 03:20:47.194374
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MyModule(object):
        def __init__(self, name):
            self.name = name
            self._command_result = {}
            self._command_result['stdout'] = ''
            self._command_result['cmd'] = ''
            self._command_result['rc'] = 0

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'fcinfo':
                return 'fcinfo'
            elif name == 'lsdev':
                return 'lsdev'
            elif name == 'lscfg':
                return 'lscfg'
            elif name == 'ioscan':
                return 'ioscan'
            elif name == 'fcmsutil':
                return 'fcmsutil'
            else:
                return ''


# Generated at 2022-06-11 03:20:51.855089
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_fact_collector = FcWwnInitiatorFactCollector(module)
    fc_facts = fc_fact_collector.collect()

    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-11 03:20:54.043715
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()


# Generated at 2022-06-11 03:20:56.944218
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test class FcWwnInitiatorFactCollector with dummy values
    """
    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts.collect(None, None)

# Generated at 2022-06-11 03:22:36.967558
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f is not None
    assert f.name == "fibre_channel_wwn"

# Generated at 2022-06-11 03:22:38.869959
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:39.981602
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj=FcWwnInitiatorFactCollector()
    print (obj)

# Generated at 2022-06-11 03:22:42.863847
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_obj = FcWwnInitiatorFactCollector()
    assert(my_obj.name == 'fibre_channel_wwn')

# Generated at 2022-06-11 03:22:50.745320
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import collect_subset
    from ansible.module_utils.facts.collector import get_collector_instance

    fc_facts = Collector.get_ansible_facts(subset='fibre_channel_wwn', collector=FcWwnInitiatorFactCollector)
    assert type(fc_facts) is dict
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-11 03:22:53.128008
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert isinstance(f, FcWwnInitiatorFactCollector)

# Generated at 2022-06-11 03:22:59.953609
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # the glob should return at least one file
    sys.modules['glob'].glob = lambda pattern: ['/sys/class/fc_host/host0/port_name']

    # mock class module
    class MockModule:
        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'fcinfo':
                return 'mock_fcinfo'
            elif path == 'lsdev':
                return 'mock_lsdev'
            elif path == 'lscfg':
                return 'mock_lscfg'
            elif path == 'ioscan':
                return "mock_ioscan"
            elif path == 'fcmsutil':
                return "mock_fcmsutil"


# Generated at 2022-06-11 03:23:10.533790
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test class FcWwnInitiatorFactCollector.

    """
    module = AnsibleModule(argument_spec={})
    fact_collector = FcWwnInitiatorFactCollector(module=module)
    result = fact_collector.collect(module=module, collected_facts={})
    # representation of a list of two dictionaries:
    # [{'uname': 'Linux', 'os_family': 'RedHat', 'os_facts': {'system': 'Linux',
    #                                                          'os_family': 'RedHat',
    #                                                          'distribution_version':
    #                                                          '7.3', 'distribution': 'CentOS',
    #                                                          'distribution_major_version': '7'
    #                                                          'distribution_

# Generated at 2022-06-11 03:23:12.696687
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:23:14.842738
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'