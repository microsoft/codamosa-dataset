

# Generated at 2022-06-11 03:15:02.856765
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == "fibre_channel_wwn"
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-11 03:15:06.103053
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name ==  'fibre_channel_wwn'


# Generated at 2022-06-11 03:15:08.447883
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.collect()

# Generated at 2022-06-11 03:15:10.789170
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:13.566612
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-11 03:15:19.154222
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform

    if platform.system() != 'Linux':
        print("Unable to execute unit test: Platform not supported")
        return

    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.module_utils.facts import FactsCollector

    c = FcWwnInitiatorFactCollector()
    ret = c.collect()
    assert ret['fibre_channel_wwn'] == ['21000014FF52A9BB']



# Generated at 2022-06-11 03:15:22.110144
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:33.764789
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import unittest.mock as mock
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    collector.sys = mock.Mock()
    collector.get_file_lines = mock.Mock()
    collector.BaseFactCollector = mock.Mock()
    collector.sys.platform = 'linux'

    # all tests below assume that collector.get_file_lines returns a list of strings
    # and collector.BaseFactCollector.collect returns an empty dictionary

    # case 1: get_file_lines returns an empty list

# Generated at 2022-06-11 03:15:40.616200
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}

    class TestFcWwnInitiatorFactCollector():
        """
        Test class for FcWwnInitiatorFactCollector class
        """
        class TestModule():
            """
            Test class for AnsibleModule class
            """
            def __init__(self):
                """
                Initialize TestModule
                """
                self.params = {}
                self.args = [ 'fibre_channel_wwn' ]

        def run_command(self, cmd, **kw):
            """
            Test run_command method
            """
            class TestRC():
                """
                Test class for RC class
                """
                class TestStdout():
                    """
                    Test class for STDOUT class
                    """
                    def readlines(self):
                        """
                        Test readlines method
                        """

# Generated at 2022-06-11 03:15:48.625566
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector

    Run like this:
    python test_FcWwnInitiatorFactCollector.py

    """
    module = None
    collected_facts = {}
    fc_facts = FcWwnInitiatorFactCollector()
    # run actual test
    fc_facts.collect(module, collected_facts)

# run unit test in standalone mode
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:02.412931
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()


# Generated at 2022-06-11 03:16:15.014830
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a new instance of FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    # We need to fake the following methods:
    # module.run_command
    # module.get_bin_path
    # ansible.module_utils.facts.utils.get_file_lines

    class FakeModule:
        def __init__(self):
            self.run_command_result = None

        def run_command(self, cmd):
            return self.run_command_result

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/%s' % name

    class FakeFileLines:
        def __init__(self):
            self.readlines_result = None

        def readlines(self):
            return

# Generated at 2022-06-11 03:16:19.358629
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_facts = FcWwnInitiatorFactCollector(module, {}).collect()
    assert fc_facts is not None
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-11 03:16:22.218324
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'
    assert a._fact_ids == set()

# Generated at 2022-06-11 03:16:27.813025
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert sys.version_info >= (2, 6)
    assert sys.platform.startswith('linux') or sys.platform.startswith('sunos') or sys.platform.startswith('aix') or sys.platform.startswith('hp-ux')
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector().collect().keys()

# Generated at 2022-06-11 03:16:40.181547
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import namespace_manager

    import os.path
    import shutil
    import tempfile

    def doit(facts):
        my_ns = namespace_manager.NamespaceManager(facts)
        my_ns.populate_namespace()
        collectors = Collector.load_collectors(my_ns.namespace)
        for collector_name in [ 'fibre_channel_wwn' ]:
            collector = collectors[collector_name]()
            #collector.collect(facts=facts)
            collector.collect()
        return my_ns.namespace

    tmpdir = tempfile.mkdtemp()
    test_filename = os.path.join(tmpdir, 'port_name')

# Generated at 2022-06-11 03:16:43.834157
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Test collect method of FcWwnInitiatorFactCollector"""
    # create a class object
    factcoll = FcWwnInitiatorFactCollector()
    # retrieve facts
    facts = factcoll.collect()
    # was fact fibre_channel_wwn retrieved ?
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-11 03:16:53.245822
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    sys.modules['ansible'] = type('FakeAnsibleModule', (object,), dict(
        AnsibleModule=type('FakeAnsibleModuleClass', (object,), dict(
            run_command=lambda self, args: (0, '0x21000014ff52a9bb', ''),
            get_bin_path=lambda self, cmd, opt_dirs=[] : cmd))))
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert '21000014ff52a9bb' in fc_facts['fibre_channel_wwn']

# Generated at 2022-06-11 03:16:57.717589
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Constructor of class FibreChannelWwnFactCollector.
    """
    fcfact = FcWwnInitiatorFactCollector()
    assert fcfact.name == 'fibre_channel_wwn'
    assert fcfact._fact_ids == set()


# Generated at 2022-06-11 03:17:01.261912
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collected_facts = {}
    fcwwn = FcWwnInitiatorFactCollector()
    fcwwn.collect(module=None, collected_facts=None)

# Generated at 2022-06-11 03:17:17.297006
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-11 03:17:27.034954
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # Create object to collect test facts
    test_obj = Collector({},{},"","")
    if "fibre_channel_wwn_initiator" in test_obj.facts:
        if test_obj.facts['fibre_channel_wwn_initiator']:
            # Test successful dictionary returned
            assert isinstance(test_obj.facts['fibre_channel_wwn_initiator'], dict)
            # Test dictionary element 'fibre_channel_wwn' returned
            assert "fibre_channel_wwn" in test_obj.facts['fibre_channel_wwn_initiator']
        # Test empty list returned

# Generated at 2022-06-11 03:17:30.709419
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FCW = FcWwnInitiatorFactCollector()
    facts = FCW.collect()
    assert ('fibre_channel_wwn' in facts.keys())
    assert (facts['fibre_channel_wwn'])

# Generated at 2022-06-11 03:17:43.289297
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    import os
    import sys

    # mock machine type
    sys_mock = {
        'linux': 'Linux',
        'sunos': 'SunOS',
        'aix': 'AIX',
        'hp-ux': 'HP-UX',
        'windows': 'Windows',
        'darwin': 'Darwin'
    }
    sys.platform = sys_mock['linux']

    # mock module
    class ModuleMock:
        def get_bin_path(self, name='', path='', opt_dirs=None, required=False):
            # mock return
            return '/bin/' + name


# Generated at 2022-06-11 03:17:51.847917
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    _module = MockModule()
    _FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector(_module)
    _FcWwnInitiatorFactCollector.collect()
    assert len(_FcWwnInitiatorFactCollector._facts) > 0
    assert 'fibre_channel_wwn' in _FcWwnInitiatorFactCollector._facts
    assert len(_FcWwnInitiatorFactCollector._facts['fibre_channel_wwn']) > 0

# MockClass to avoid module import failure

# Generated at 2022-06-11 03:17:55.256219
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = AnsibleModule(argument_spec={})
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:59.415738
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import rw_device_facts

    t_fc_facts = rw_device_facts(FcWwnInitiatorFactCollector)

    assert isinstance(t_fc_facts, dict)

# Generated at 2022-06-11 03:18:05.609712
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  m = AnsibleModule(argument_spec = dict())
  f = FcWwnInitiatorFactCollector()
  fc_wwns = f.collect(module=m)
  #fc_wwns = {'fibre_channel_wwn': ['21000014ff52a9bb']}
  m.exit_json(ansible_facts=fc_wwns)

# Generated at 2022-06-11 03:18:08.176305
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''
    # Test facts collection of class FcWwnInitiatorFactCollector
    '''
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.collect() == {}

# Generated at 2022-06-11 03:18:19.320875
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # data for test
    cmd = 'fcinfo hba-port'
    cmd_rc = 0
    cmd_stdout = '''
HBA Name: fcs0
HBA Driver Name: ql2300
HBA Driver Version: v5.2.0
Port WWN: 10000000c9b6a25d
OS Device Name: /dev/cfg/c3
Manufacturer: QLogic Corp.
Model: 2300
Firmware Version: 20.03.00
Serial Number: 3024
Driver Name: ql2300
Hardware Version: 1.0
Driver Version: 5.2.0
Option ROM Version: 01.0.0
Link Speed: 2Gb
Max Frame Size: 2048
OS: Solaris
        '''
    cmd_stderr = ''

    # create mock module
    mock_module = MockModule()

# Generated at 2022-06-11 03:18:37.220836
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'fibre_channel_wwn'

# Unit test stub to run this module independently
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:18:41.118615
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts
    assert fc_facts.name == 'fibre_channel_wwn'
    assert not fc_facts._fact_ids

# Generated at 2022-06-11 03:18:43.042583
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:45.189109
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test 1: pass module as None
    test1 = FcWwnInitiatorFactCollector()
    assert test1.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:18:52.825985
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    facts = FcWwnInitiatorFactCollector.collect()
    assert type(facts['fibre_channel_wwn']) is list
    assert facts['fibre_channel_wwn'], 'fact fibre_channel_wwn should not be empty'
    assert facts['fibre_channel_wwn'][0], 'fact fibre_channel_wwn[0] should not be empty'

# Generated at 2022-06-11 03:19:01.366750
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import unittest

    # For testing, set up a Linux system
    sys.platform = 'linux'

    # and dummy system files to match (one for each facts item)
    class MockFile(object):
        def __init__(self, my_list):
            self.my_list = my_list
        def readline(self):
            return self.my_list.pop(0)

    import os
    def my_open(filepath):
        if filepath == '/sys/class/fc_host/host1/port_name':
            return MockFile(['0x21000014ff52a9bb'])
        if filepath == '/sys/class/fc_host/host2/port_name':
            return MockFile(['0x21000014ff52a9bc'])

# Generated at 2022-06-11 03:19:03.765532
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:05.771933
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    wwnInit = FcWwnInitiatorFactCollector()
    assert wwnInit.name == "fibre_channel_wwn"

# Generated at 2022-06-11 03:19:08.871690
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() is not None

# Generated at 2022-06-11 03:19:12.102579
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 03:19:36.301020
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import TestAnsibleModule
    from ansible.module_utils.facts.utils import CoreNetworkCollector

    test_module = TestAnsibleModule()

    # testing without any facts defined
    core_network_collector = CoreNetworkCollector()
    result = core_network_collector.collect(test_module)
    assert 'fibre_channel_wwn' not in result

    # testing with fibre_channel_wwn fact defined
    FcWwnInitiatorFactCollector.collect(test_module)
    result = core_network_collector.collect(test_module)
    assert 'fibre_channel_wwn' in result
    assert type(result['fibre_channel_wwn']) is list

# Generated at 2022-06-11 03:19:39.635941
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert(obj.name == 'fibre_channel_wwn')
    assert(obj.collect() == {})

# Generated at 2022-06-11 03:19:42.550185
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    assert(len(fc_facts.collect()) > 0)

# Generated at 2022-06-11 03:19:51.247746
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # init
    t = FcWwnInitiatorFactCollector()

    # example content of /sys/class/fc_host/*/port_name
    fc_host_port_name_content = """[
    root@t-aer-elx-testbed-01 ~]# cat /sys/class/fc_host/host1/port_name
    0x21000014ff52a9bb
    ]
    """

    # example output of fcinfo hba-port on solaris

# Generated at 2022-06-11 03:19:55.149726
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FC_WWN = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == FC_WWN.name
    assert FC_WWN.collect()

# Generated at 2022-06-11 03:19:59.424056
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.platforms == ['Linux', 'SunOS', 'AIX', 'HP-UX']


# Generated at 2022-06-11 03:20:03.550988
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.name in FcWwnInitiatorFactCollector.collect()


# Generated at 2022-06-11 03:20:08.492617
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test 1
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert c._fact_ids == set()


#Unit test to verify if given wwn is populated in
#fibre_channel_wwn list

# Generated at 2022-06-11 03:20:13.328186
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert c.collect() == {
        'fibre_channel_wwn': [
            '1000090fa1658de',
            '10000090fa551509',
            '50060b00006975ec'
        ]
    }

# Generated at 2022-06-11 03:20:22.105379
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.cache import FactCache
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    c = Collector()
    c.collectors = []
    c.collectors.append(fc)
    facts_cache = FactCache()
    facts = c.collect(module=None, collected_facts=facts_cache)
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-11 03:20:49.592961
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collectors.network.fc_wwn_initiator import FcWwnInitiatorFactCollector
    import platform, os

    class MockModule:
        def __init__(self):
            self.p1 = platform.system()
            self.p2 = os.name
        def get_bin_path(self, name, opt_dirs=[]):
            return "/bin/%s" % name

    class MockPopen:
        def __init__(self, cmd, stdout=None, stderr=None, rc=0):
            self.cmd = cmd
            self.stdout = stdout
            self.stderr = stderr

# Generated at 2022-06-11 03:20:56.427925
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test the collect method of FcWwnInitiatorFactCollector.
    """
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    # Create a MockModule for testing
    module = basic.AnsibleModule(
        argument_spec={}
    )
    # Create a MockFactCollector and register our fact class
    fact_collector = collector.FactCollector(module=module)
    fact_collector.register_collector(FcWwnInitiatorFactCollector(module=module))
    # Run the collect method and verify the result
    result = fact_collector.collect()
    assert isinstance(result, dict)
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-11 03:20:59.143985
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:21:04.121525
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_device = FcWwnInitiatorFactCollector()
    assert fc_device._fact_ids == set()
    assert fc_device.name == 'fibre_channel_wwn'
    assert fc_device.priority > 0

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:21:06.168336
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:21:09.485346
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-11 03:21:11.392007
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name is not None

# Generated at 2022-06-11 03:21:22.163892
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class SystemModule:
        def __init__(self, module_name, bin_path_list=[]):
            self.module_name = module_name

        class run_command:
            def __init__(self, returncode, stdout, stderr):
                self.rc = returncode
                self.stdout = stdout
                self.stderr = stderr

            def __call__(self, cmd, check_rc=True, close_fds=True, executable=None,
                         data=None, binary_data=False, path_prefix=None,
                         cwd=None, use_unsafe_shell=False, prompt_regex=None,
                         environ_update=None, read_end=None,
                         pty=False):
                return self.rc, self.stdout, self.stderr

# Generated at 2022-06-11 03:21:26.079639
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_fc_facts = {}
    test_fc_facts['fibre_channel_wwn'] = ['21000014ff52a9bb']

    m = FcWwnInitiatorFactCollector()
    fc_facts = m.collect()

    assert fc_facts == test_fc_facts

# Generated at 2022-06-11 03:21:31.592451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
   # Set up the object for testing
   fc_collector = FcWwnInitiatorFactCollector()
   fc_collector.collect(module=None, collected_facts=None)
   fc_facts = fc_collector.get_facts()
   # Assert that there is at least one FC WWN (port name)
   assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:21:54.984721
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # define module stub
    class ModuleStub:
        def __init__(self):
            self.run_command_counter = 0
            self.run_command_calls = []

        def get_bin_path(self, binary, opt_dirs=[]):
            # TODO
            return binary

        def run_command(self, command, check_rc=True):
            self.run_command_calls.append(command)
            self.run_command_counter += 1

            if self.run_command_counter == 1:
                # simulate ioscan output
                return 0, "0/0/2    0   FC fcd0        CLAIMED  INTERFACE  HP      FCD1A0", None
            elif self.run_command_counter == 2:
                # simulate successful fcmsutil output
                return 0

# Generated at 2022-06-11 03:22:03.236926
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = MockModule()
    fc_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_initiator_facts = fc_initiator_fact_collector.collect(module=module_mock)

    """
    Example facts for fibre_channel_wwn:
    - 21000014ff52a9bb
    - 21000014ff52a9bc
    - 21000014ff52a9bd
    """
    assert fc_initiator_facts['fibre_channel_wwn'] == fc_initiator_facts_fixture


# Generated at 2022-06-11 03:22:06.665927
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts._fact_ids

# Generated at 2022-06-11 03:22:14.303130
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test case for method collect of class FcWwnInitiatorFactCollector.
    """
    Module = MockModule()
    FcWwnInitiatorFactsCollector = FcWwnInitiatorFactCollector()
    res = FcWwnInitiatorFactsCollector.collect(Module)
    assert res == {'fibre_channel_wwn': ['20000014ff52a9bb', '21000014ff52a9bb']}


# Generated at 2022-06-11 03:22:18.664494
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    col_fc = FcWwnInitiatorFactCollector()
    collected_facts = {}
    fc_facts = col_fc.collect(collected_facts=collected_facts)
    assert fc_facts.get('fibre_channel_wwn') is not None

# Generated at 2022-06-11 03:22:23.145865
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_initiator = FcWwnInitiatorFactCollector()
    assert fc_initiator is not None
    assert fc_initiator.name == 'fibre_channel_wwn'
    assert fc_initiator._fact_ids == set()


# Generated at 2022-06-11 03:22:26.758783
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert set(fc_facts.collect().keys()) == set(['fibre_channel_wwn'])

# Generated at 2022-06-11 03:22:28.795622
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:22:31.992411
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is not None


# Generated at 2022-06-11 03:22:35.698222
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create an instance of class FcWwnInitiatorFactCollector
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert_true(fc_fact_collector is not None)

# Generated at 2022-06-11 03:23:05.965045
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    print(facts)
    assert facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:23:07.968230
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collect = FcWwnInitiatorFactCollector()
    assert collect.name == 'fibre_channel_wwn'



# Generated at 2022-06-11 03:23:13.576458
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Test for constructor of class FcWwnInitiatorFactCollector"""
    module = None
    fact_collector = FcWwnInitiatorFactCollector(module)
    assert isinstance(fact_collector, FcWwnInitiatorFactCollector)
    assert hasattr(fact_collector, 'name')
    assert hasattr(fact_collector, '_fact_ids')

# Generated at 2022-06-11 03:23:23.499206
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # setup mocks
    from ansible_collections.anisble.community.tests.unit.modules.utils import AnsibleModuleExt
    module = AnsibleModuleExt()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/bin/%s' % x
    module.get_bin_path.__name__ = 'mock_get_bin_path'
    # run test
    fc = FcWwnInitiatorFactCollector()
    collected_facts = fc.collect(module=module, collected_facts=None)
    # assert result
    assert collected_facts['fibre_channel_wwn'] == ['50060b0000828bc8', '50060b0000828bc9']

# Generated at 2022-06-11 03:23:26.828513
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_collector = FcWwnInitiatorFactCollector()
    test_facts = test_collector.collect()
    # output for solaris 10
    assert test_facts == {'fibre_channel_wwn': ['500009605b904802']}

# Generated at 2022-06-11 03:23:38.374060
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import collector

    def get_bin_path(executable, opt_dirs=None):
        """
        noop function for testing purposes
        """
        return '/bin/bogus-command'

    def get_file_lines(filename):
        """
        noop function for testing purposes
        """
        return []

    def run_command(cmd, check_rc=False):
        """
        noop function for testing purposes
        """
        return 0, "", ""

    # setup test-specific variables
    test_collector = None
    test_platform = 'linux'
    test_data = {}
    # patch sys.platform


# Generated at 2022-06-11 03:23:43.865785
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    test_obj = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        try:
            test_obj.collect()
        except:
            assert False
        assert True
    else:
        assert "Unsupported platform"

# Generated at 2022-06-11 03:23:46.708013
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock({})
    collector = FcWwnInitiatorFactCollector(module)
    facts = collector.collect()
    assert 'fibre_channel_wwn' in facts
    return True

# Generated at 2022-06-11 03:23:47.933283
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Placeholder for unit tests.
    """
    pass

# Generated at 2022-06-11 03:23:53.788775
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector.fibre_channel import FibreChannelFactCollector

    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_fact_collector.collect()
    fc_fact_collector.add_to_collection(fc_facts)
    # TODO: add unit test

# vim: expandtab:tabstop=4:shiftwidth=4