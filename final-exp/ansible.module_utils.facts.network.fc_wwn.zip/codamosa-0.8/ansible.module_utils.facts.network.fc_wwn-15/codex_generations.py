

# Generated at 2022-06-11 03:15:05.145204
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # pylint: disable=line-too-long
    test_facts = {"kernel": "Linux", "ansible_facts": {}, "fibre_channel_wwn": ["21000014ff52a9bb"]}
    # pylint: enable=line-too-long
    test_collected_facts = {"kernel": "Linux"}
    # Create an instance of class FcWwnInitiatorFactCollector
    fact_collector = FcWwnInitiatorFactCollector()
    # Call collect (we just test if no exception is raised)
    fact_collector.collect(collected_facts=test_collected_facts)
    # Do these facts match?
    assert test_facts == test_collected_facts

# Generated at 2022-06-11 03:15:09.395871
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:15:12.596511
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    testobj = FcWwnInitiatorFactCollector()
    testobj.collect()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:15:15.127831
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_test = FcWwnInitiatorFactCollector()
    assert fc_fact_test.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:18.225375
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector(None, None)
    assert fact_collector is not None

# Generated at 2022-06-11 03:15:29.045698
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # test linux & sunos
    module = dict(run_command=lambda x, check_rc=True: (0, '', ''))
    obj = FcWwnInitiatorFactCollector(module=module)
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'fibre_channel_wwn'

    # test aix
    module = dict(run_command=lambda x, check_rc=True: (0, '', ''))
    obj = FcWwnInitiatorFactCollector(module=module)
    assert isinstance(obj, BaseFactCollector)
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:15:36.512165
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # initialize module_utils.basic.AnsibleModule object
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.exit_json = Mock()
    module.run_command = Mock()
    if sys.platform.startswith('linux'):
        module.run_command.return_value = (
            0,
            "0x21000014ff52a9bb\n0x21000014ff52a9dd",
            ''
        )

# Generated at 2022-06-11 03:15:37.721527
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()


# Generated at 2022-06-11 03:15:49.748462
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    FcWwnInitiatorFactCollector._platform = 'Linux'
    FcWwnInitiatorFactCollector._get_file_lines = lambda self, file: file.splitlines()
    module = BaseFactCollector()
    fcfacts = FcWwnInitiatorFactCollector().collect(module)
    assert fcfacts is not None
    assert 'fibre_channel_wwn' in fcfacts
    assert len(fcfacts['fibre_channel_wwn']) == 1
    assert fcfacts['fibre_channel_wwn'][0] == "21000014ff52a9bb"


# Generated at 2022-06-11 03:15:55.017946
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    setattr(sys, 'platform', 'linux')
    fc = FcWwnInitiatorFactCollector()
    # test empty storage
    assert fc.collect() == {'fibre_channel_wwn': []}
    # test name
    assert fc.name == 'fibre_channel_wwn'
    return True


# Generated at 2022-06-11 03:16:21.534567
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'


if __name__ == '__main__':
   test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:28.203432
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # create instance of FcWwnInitiatorFactCollector class
    fibre_cl_wwn_initiator = FcWwnInitiatorFactCollector()

    # collect facts
    output = fibre_cl_wwn_initiator.collect(module=None, collected_facts=None)
    # print(output)

    # assert output
    assert 'fibre_channel_wwn' in output, 'missing key "fibre_channel_wwn" in returned dictionary'

# Generated at 2022-06-11 03:16:40.461309
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):
        @patch('ansible.module_utils.facts.collectors.network.FcWwnInitiatorFactCollector.collect')
        def test_collect(self, mock_fcwwn_fc):
            test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:43.721324
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''
    Test the constructor of class FcWwnInitiatorFactCollector.

    :return:
    '''

    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()


# Generated at 2022-06-11 03:16:52.515117
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test the method collect of class FcWwnInitiatorFactCollector
    """
    fc_path = '/sys/class/fc_host/*/port_name'
    fc_dict = {}
    fc_dict['fibre_channel_wwn'] = []
    for fcfile in glob.glob(fc_path):
        for line in get_file_lines(fcfile):
            fc_dict['fibre_channel_wwn'].append(line.rstrip()[2:])
    con = FcWwnInitiatorFactCollector()
    fc_col = con.collect()
    assert fc_col == fc_dict

# Generated at 2022-06-11 03:17:03.868412
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def run_command(self, cmd):
            class MockOut(object):
                def __init__(self, out):
                    self.out = out
                def splitlines(self):
                    return self.out
            return 0, MockOut(['HBA Port WWN: 10000090fa1658de']), ''
        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name
    class MockFactCollector(FcWwnInitiatorFactCollector):
        def __init__(self):
            self.collector = dict()
    fact_collector = MockFactCollector()
    fact_collector.collect(module=MockModule())

# Generated at 2022-06-11 03:17:06.472462
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    os_facts = FcWwnInitiatorFactCollector()
    result = os_facts.collect(collected_facts=None, module=None)
    assert(len(result['fibre_channel_wwn']) > 0)

# Generated at 2022-06-11 03:17:08.660716
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj


# Generated at 2022-06-11 03:17:11.583792
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-11 03:17:14.748262
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert fc._fact_ids == set()

# Generated at 2022-06-11 03:18:05.756100
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = mock.Mock()
    module_mock.run_command.return_value = (0, '10000090fa1658de', '')
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append('10000090fa1658de')
    # test code execution
    obj = FcWwnInitiatorFactCollector()
    assert fc_facts == obj.collect(module_mock)

# Generated at 2022-06-11 03:18:14.516807
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    mock_module = mock.Mock()
    mock_module.run_command.return_value =(0, '0x21000014ff52a9bb', '')

    with patch.object(FcWwnInitiatorFactCollector, '_platform', 'linux'):
        with patch.object(FcWwnInitiatorFactCollector, '_module', mock_module):
            assert FcWwnInitiatorFactCollector.collect(mock_module) == {'fibre_channel_wwn': ['21000014ff52a9bb']}

    mock_module = mock

# Generated at 2022-06-11 03:18:18.626395
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()


# Generated at 2022-06-11 03:18:25.719121
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''unit test for FcWwnInitiatorFactCollector.collect()'''

    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import TestModule
    import platform

    # create instance of TestModule
    test_module = TestModule()
    test_module.exit_json = TestModule
    test_module.run_command = TestModule
    test_module.get_bin_path = TestModule

    # create instance of FcWwnInitiatorFactCollector
    fci = FcWwnInitiatorFactCollector(module=test_module)

    # test collect on Linux

# Generated at 2022-06-11 03:18:28.354445
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-11 03:18:35.344016
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """
    module = None
    collected_facts = None
    fc = FcWwnInitiatorFactCollector()
    result = fc.collect(module, collected_facts)
    if 'fibre_channel_wwn' in result:
        for wwn in result['fibre_channel_wwn']:
            assert len(wwn) == 16

# Generated at 2022-06-11 03:18:37.077455
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
        x = FcWwnInitiatorFactCollector()
        assert x


# Generated at 2022-06-11 03:18:39.504804
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    assert collector.collect()



# Generated at 2022-06-11 03:18:40.846961
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()



# Generated at 2022-06-11 03:18:46.442665
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.fc_wwn_initiator import FcWwnInitiatorFactCollector

    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts_list = FactsCollector().collect(collectors=fc_facts, module=None, collected_facts={})
    assert fc_facts_list == { 'fibre_channel_wwn': ['10000090fa1658de'] }

# Generated at 2022-06-11 03:20:14.919314
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj.collect() == {}

# Generated at 2022-06-11 03:20:26.591562
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # instantiate a class object
    fc_facts = FcWwnInitiatorFactCollector()

    # define a file name
    sys_file = '/tmp/sys_file'

    # define file contents
    file_contents = '0x21000014ff52a9bb'

    # open a file in write mode
    f = open(sys_file, 'w')

    # write file contents
    f.write(file_contents)

    # close the file
    f.close()

    # call method collect of class FcWwnInitiatorFactCollector
    # and pass file name as an argument
    fc_facts.collect(sys_file)

    # define an expected list
    exp_list = [file_contents]

    # check if the actual list matches the expected list
    assert fc_

# Generated at 2022-06-11 03:20:29.188231
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test = FcWwnInitiatorFactCollector()
    assert test.name == 'fibre_channel_wwn'
    assert test._fact_ids == set()


# Unit tests for collect()

# Generated at 2022-06-11 03:20:31.801867
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:20:42.294503
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import platform
    
    # instantiate a new object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    
    # create a dictionary and execute method collect 
    collected_facts = {}
    fc_wwn_initiator_fact_collector.collect(collected_facts = collected_facts)
    
    # check that facts were added to the dictionary 
    assert 'fibre_channel_wwn' in collected_facts
    
    # check that the list contains at least one element
    assert len(collected_facts['fibre_channel_wwn']) > 0

    # check if the first entry is

# Generated at 2022-06-11 03:20:46.039184
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_wwn._fact_ids

# Generated at 2022-06-11 03:20:50.093461
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector.priority == 30


# Generated at 2022-06-11 03:20:52.306021
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
  assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-11 03:20:55.010862
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()

    assert result['fibre_channel_wwn']

# Generated at 2022-06-11 03:21:00.250548
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

    collector = FcWwnInitiatorFactCollector()
    # collector.collect()
    # print(json.dumps(fc_facts, indent=4, sort_keys=True))
    assert fc_facts['fibre_channel_wwn'] is not None

# Generated at 2022-06-11 03:22:31.681791
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    s = FcWwnInitiatorFactCollector()
    assert s.name is not None
    assert s._fact_ids is not None

# Generated at 2022-06-11 03:22:41.404431
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class Options(object):
        def __init__(self):
            self.custom_facts = []
    class ModuleUtil(object):
        def __init__(self):
            self.options = Options()
        def get_bin_path(self, _, opt_dirs=[]):
            return None
    class Module(object):
        def __init__(self):
            self.params = { 'gather_subset': [] }
            self.module_name = 'setup'
            self.module_execution_id = '42'
            self.module_utils = ModuleUtil()
        def run_command(self):
            return (0, "", "")

    # test all possible init conditions
    facts_list = ['all', 'network', 'fibre_channel_wwn']

# Generated at 2022-06-11 03:22:46.322686
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert len(fc_facts) > 0
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-11 03:22:56.371165
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    test_fc_facts = {}
    test_fc_facts['fibre_channel_wwn'] = []

    # test for linux
    sys.platform = 'linux2'
    fc = FcWwnInitiatorFactCollector()
    fc.collect(None, fc_facts)
    test_fc_facts['fibre_channel_wwn'].append('21000014ff52a9bb')
    assert fc_facts == test_fc_facts

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    test_fc_facts = {}
    test_fc_facts['fibre_channel_wwn'] = []

    # test

# Generated at 2022-06-11 03:23:07.059501
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_collector = FcWwnInitiatorFactCollector()
    # output on solaris 11
    fcwwn_collector.content = """
HBA Port WWN: 10000090fa1658de
HBA Driver Name: elxiscsi
HBA Manufacturer: Emulex Corporation
HBA Model: LP11000-E
HBA Firmware Version: 5.0.643
HBA Description: Emulex LP11000-E
HBA Serial Number: FPZGGC3150
Port Type: FC
Supported Speeds:  4Gb,  8Gb
Current Speed: 8Gb
Node WWN: 10000090fa1658e0
Max Frame Size: 2112
OS Device Name: /dev/cfg/c6
"""

# Generated at 2022-06-11 03:23:10.180527
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()

# Generated at 2022-06-11 03:23:20.844861
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector.subprocess_base import SubprocessBaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content, get_mount_points, get_file_lines
    from ansible.module_utils.facts.sys_info import get_platform_subclass
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution.aix import AixDistribution

# Generated at 2022-06-11 03:23:22.836959
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fac = FcWwnInitiatorFactCollector()
    assert fc_fac.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:23:24.338224
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:23:35.269142
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for FcWwnInitiatorFactCollector.collect()"""
    test_cases = (
        {
            "path":'/sys/class/fc_host/*/port_name',
            "returned_input":(0, '0x21000014ff52a9bb\n 0x21000014ff527c73', ''),
            "fact_data": { 'fibre_channel_wwn': ['21000014ff52a9bb', '21000014ff527c73'] }
        },
    )

    import platform
    import shutil
    import tempfile

    import pytest

    from ansible.module_utils.facts.collector import Collector, BaseFactCollector

    class TestFactCollectorModule:

        class TestCollector(Collector):
            name = 'test_collector'