

# Generated at 2022-06-11 03:15:01.468407
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    print(obj)
    assert obj is not None


# Generated at 2022-06-11 03:15:06.614914
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect for class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_lines

    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector.network import NetworkCollector
    from ansible.module_utils.facts.collector.network import InterfaceCollector
    from ansible.module_utils.facts.collector.network import HardwareInterfaceCollector

    # create instances of all registered fact collectors
    fc_fact_collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:15:16.659466
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # prepare mock module object
    class TestModule:
        def __init__(self, name, opt_dirs):
            self.name = name
            self.opt_dirs = opt_dirs
        def get_bin_path(self, name, opt_dirs=[]):
            # dummy return value
            if name == 'ioscan' or name == 'fcmsutil':
                return '%s_path' % name
            else:
                return '/bin/%s' % name
    module = TestModule('ioscan', ['/opt/fcms/bin'])

    # prepare mock responses for subprocess calls
    class TestPopen:
        def __init__(self, cmd, stdout, stderr, returncode):
            self.cmd = cmd
            self.stdout = stdout

# Generated at 2022-06-11 03:15:23.022002
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import Collector
    collected_facts = Collector(None).collect(None, None)
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(None, collected_facts)
    assert 'fibre_channel_wwn' in facts

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:15:26.435035
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_object = FcWwnInitiatorFactCollector()
    assert test_object
    assert test_object.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:28.870421
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:15:33.059390
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fc = FcWwnInitiatorFactCollector()
    assert fc_wwn_fc.name == 'fibre_channel_wwn'
    assert fc_wwn_fc._fact_ids == set()


# Generated at 2022-06-11 03:15:44.785996
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import glob
    import os

    from ansible.module_utils.facts.utils import get_file_lines

    class MyModule:
        def get_bin_path(self, arg1, opt_dirs=None):
            if arg1 == 'fcinfo' and sys.platform.startswith('sunos'):
                return '/usr/sbin/fcinfo'
            if arg1 == 'lsdev' and sys.platform.startswith('aix'):
                return '/usr/bin/lsdev'
            if arg1 == 'lscfg' and sys.platform.startswith('aix'):
                return '/usr/bin/lscfg'

# Generated at 2022-06-11 03:15:47.910025
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == {'fibre_channel_wwn': fc.collect()['fibre_channel_wwn']}

# Generated at 2022-06-11 03:15:51.698978
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    assert o.name == 'fibre_channel_wwn'
    assert o._fact_ids == set()


# Generated at 2022-06-11 03:16:15.306511
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json
    import re
    import os
    import sys
    import platform
    import shutil
    import tempfile

    # define tempdir
    tempdir = tempfile.mkdtemp()
    # copy mock /sys/class/fc_host/host*/port_name files to tempdir
    test_files = []
    for i in range(4):
        test_files.append("host%d" % i)
    for file in test_files:
        shutil.copy(os.path.join(os.path.dirname(__file__), 'data', 'fibre_channel_wwn', 'port_name', file), os.path.join(tempdir, file))

    # create mock module

# Generated at 2022-06-11 03:16:26.463561
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    import os

    # setup defaults
    collected_facts = dict()
    module = BaseFactCollector.get_module(collected_facts)

    fc_wwn = FcWwnInitiatorFactCollector()

    if os.path.exists("/sys/class/fc_host/host5"):
        # test collect linux
        fc_wwn.collect(module=module, collected_facts=collected_facts)

# Generated at 2022-06-11 03:16:27.317994
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:16:35.960950
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockedModule(object):
        @staticmethod
        def run_command(cmd):
            return (0, '0x21000014ff52a9bb', '')

        @staticmethod
        def get_bin_path(cmd, *args, **kwargs):
            return cmd

    ansible_module = MockedModule()

    collector = FcWwnInitiatorFactCollector()
    result = collector.collect(ansible_module)

    assert result['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-11 03:16:38.497016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:16:47.975088
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = basic.AnsibleModule.exit_json
            self.fail_json = basic.AnsibleModule.fail_json
            self.result = {}
            self.fail_on_missing_params = basic.AnsibleModule.fail_on_missing_params
    module = MockModule()
    fact_collector = collector.get_collector(FcWwnInitiatorFactCollector.name, module)
    facts = fact_collector.collect(module=module, collected_facts=None)
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-11 03:16:52.001511
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-11 03:16:56.990784
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_inst = FcWwnInitiatorFactCollector()
    assert fc_wwn_inst.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_wwn_inst._fact_ids
    assert fc_wwn_inst.collect() == {}

# Generated at 2022-06-11 03:17:00.461074
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_facts = FcWwnInitiatorFactCollector()
    fc_facts.collect()
    assert 'fibre_channel_wwn' in fc_facts.facts

# Generated at 2022-06-11 03:17:10.362214
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    # create instance of class FcWwnInitiatorFactCollector
    fc_test = FcWwnInitiatorFactCollector()

    # set values of _fact_ids and platform
    fc_test._fact_ids = set()
    sys.platform = 'linux'

    # create a list of test data
    fcfile_test_data = [
        '/sys/class/fc_host/host2/port_name',
        '/sys/class/fc_host/host3/port_name',
        '/sys/class/fc_host/host4/port_name',
    ]

    # set contents of the test

# Generated at 2022-06-11 03:17:35.648078
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:37.273338
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector('')
    assert fc_obj is not None

# Generated at 2022-06-11 03:17:40.116207
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:17:48.014155
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {
        "fibre_channel_wwn":[
            "21000014ff52a9bb",
            "10000090fa1658de"
        ]
    }
    # get FcWwnInitiatorFactCollector instance
    fwfc = FcWwnInitiatorFactCollector()
    # collect facts
    ft = fwfc.collect()
    # check if facts were collected as expected
    assert ft == fc_facts

# Generated at 2022-06-11 03:17:49.503734
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:17:51.752788
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector({})
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:54.661247
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:17:59.655724
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector.priority == 85

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:18:01.925743
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert hasattr(x, 'name')

# Generated at 2022-06-11 03:18:06.795932
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This is a unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # Arrange
    collector = FcWwnInitiatorFactCollector()
    collection = set()

    # Act
    facts = collector.collect()

    # Assert
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-11 03:18:52.496748
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcFactCollector = FcWwnInitiatorFactCollector()
    assert fcFactCollector is not None


# Generated at 2022-06-11 03:18:55.376526
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_object = FcWwnInitiatorFactCollector()
    assert test_object
    assert test_object.name == 'fibre_channel_wwn'

# Generated at 2022-06-11 03:19:04.786946
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    testobj = FcWwnInitiatorFactCollector()
    assert testobj.name == 'fibre_channel_wwn'
    assert testobj._fact_ids == set()


# Generated at 2022-06-11 03:19:14.648311
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    myfact = FcWwnInitiatorFactCollector()
    fc_facts = myfact.collect({'get_bin_path': lambda x, opt_dirs=None: x}, None)

    assert 'fibre_channel_wwn' in fc_facts
    assert len(fc_facts['fibre_channel_wwn']) > 0
    for wwn in fc_facts['fibre_channel_wwn']:
        assert  len(wwn) == 16

# Generated at 2022-06-11 03:19:21.031977
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print(FcWwnInitiatorFactCollector.name)
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:19:22.694740
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_obj = FcWwnInitiatorFactCollector()
    test_obj.collect()

# Generated at 2022-06-11 03:19:29.035793
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # Testing the defined collector
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(None, None)
    assert facts
    assert facts['fibre_channel_wwn']

# Generated at 2022-06-11 03:19:34.181737
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print ("TESTING: FcWwnInitiatorFactCollector collect")
    if sys.platform == "linux":
        collector = FcWwnInitiatorFactCollector()
        result = collector.collect()
        assert result['fibre_channel_wwn'] == ['21000014ff52a9bb']


# Generated at 2022-06-11 03:19:44.970765
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import read_file
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    module_data = {}
    # set default values for AnsibleModule constructor
    module_data['argument_spec'] = dict(
        gather_subset=dict(required=False, type='list'),
    )
    module = AnsibleModule(**module_data)
    module.run_command = mock.Mock(return_value=(0, "", ""))
    module.get_bin_path = mock.Mock(return_value=True)
    # initialize Collector
    Collector

# Generated at 2022-06-11 03:19:49.901243
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    collected_facts = {}
    fc_collector = FcWwnInitiatorFactCollector()
    fc_collector.collect(module, collected_facts)
    assert collected_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-11 03:21:24.097792
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    collected_facts = None
    fc_wwn_obj = FcWwnInitiatorFactCollector(module, collected_facts)
    assert fc_wwn_obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-11 03:21:31.277811
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(module=module, collected_facts={})
    assert len(facts['fibre_channel_wwn']) > 0
    assert facts['fibre_channel_wwn'][0] == '1000090fa1658de'

# test-module -s /usr/share/ansible/ -m ../../../library/system/fibre_channel_wwn.py
if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    from test.units.compat import unittest

    class AnsibleModuleMock(object):
        def run_command(self, cmd):
            dest, device_name, key,

# Generated at 2022-06-11 03:21:33.844820
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name is not None
    assert collector._fact_ids is not None



# Generated at 2022-06-11 03:21:40.779454
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fact_collector = FcWwnInitiatorFactCollector(
        module=module
    )
    # execute fact collection
    fact_collector.collect()

    # test if fact collection worked
    fc_facts = module.exit_json['ansible_facts']
    assert 'fibre_channel_wwn' in fc_facts.keys()

# Generated at 2022-06-11 03:21:45.538319
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector(None)
    print(fc_fact._fact_ids)
    assert set(["fibre_channel_wwn"]) == fc_fact._fact_ids

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-11 03:21:50.587531
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock(argument_spec=dict())
    base_collector = BaseFactCollector(module=module)
    collector = FcWwnInitiatorFactCollector(base_collector)
    assert collector.collect()['fibre_channel_wwn'] == ['21000014ff52a9bb']



# Generated at 2022-06-11 03:21:54.757040
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    # check that class raises an exception on wrong platform (Windows).
    if sys.platform.startswith('win'):
        try:
            fc_facts.collect()
        except NotImplementedError:
            pass
        else:
            raise AssertionError("Should raise an exception")


# Generated at 2022-06-11 03:22:04.555243
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector
    # Test on Linux
    sys.platform = 'linux'
    method_collect = class_FcWwnInitiatorFactCollector.collect
    assert method_collect() == {'fibre_channel_wwn': ['210000144d0c6480', '210000144d0c6481']}
    
    # Test on AIX
    sys.platform = 'aix'
    method_collect = class_FcWwnInitiatorFactCollector.collect
    assert method_collect() == {'fibre_channel_wwn': ['10000090fa1658de']}

    # Test on HP-UX
    sys.platform = 'hp-ux'
    method_collect = class_FcWwnIn

# Generated at 2022-06-11 03:22:15.425423
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    config = {}
    # mock AnsibleModule
    mock_AnsibleModule = type('AnsibleModule', (object,), {
        'check_mode': False,
        '_socket_path': '',
        'run_command': FcWwnInitiatorFactCollector.run_command,
        'get_bin_path': FcWwnInitiatorFactCollector.get_bin_path
    })
    mock_module = mock_AnsibleModule()
    collector = FcWwnInitiatorFactCollector(mock_module)
    # collect facts (by side effect)

# Generated at 2022-06-11 03:22:19.722426
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert hasattr(x, 'collect')
    assert x._fact_ids == set()
    assert isinstance(x._fact_ids, set)