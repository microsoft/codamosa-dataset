

# Generated at 2022-06-24 22:40:20.094321
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:40:27.422256
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.__class__.__name__ == "FcWwnInitiatorFactCollector"


# Generated at 2022-06-24 22:40:34.091146
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector_test = FcWwnInitiatorFactCollector()
    print("assert type(fact_collector_test) == FcWwnInitiatorFactCollector")
    assert type(fact_collector_test) == FcWwnInitiatorFactCollector


# Generated at 2022-06-24 22:40:38.533040
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Testing for invalid input
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # Testing for valid input
    fc_facts = fc_wwn_initiator_fact_collector.collect()
    print(fc_facts)

if __name__ == '__main__':
    test_case_0()
   # test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:43.875901
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test constructor of FcWwnInitiatorFactCollector
    """

    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-24 22:40:47.416329
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-24 22:40:56.495418
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:40:59.045343
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-24 22:41:10.715579
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Structural test
    #
    # Check if class FcWwnInitiatorFactCollector has method collect
    assert hasattr(FcWwnInitiatorFactCollector, "collect"), "FcWwnInitiatorFactCollector should have method collect"
    #
    # Unit test for method collect
    #
    # Note: we do not yet test for the actual returned values
    #
    # Instantiate a FcWwnInitiatorFactCollector object
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

    # Check if the method collect returns something
    assert fc_wwn_initiator_fact_collector_1.collect() is not None, "FcWwnInitiatorFactCollector method collect should return something"

    # Check

# Generated at 2022-06-24 22:41:17.231423
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector
    collector._collectors.update({
        'fibre_channel_wwn': FcWwnInitiatorFactCollector
    })
    test_obj = Collector()
    test_obj.collect()

    assert 'fibre_channel_wwn' in test_obj._collected_facts


if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:36.983088
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("\n-----------------------------------------------------\n")
    print("Test for method collect of class FcWwnInitiatorFactCollector")

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect()

    print("\n-----------------------------------------------------\n")


# Generated at 2022-06-24 22:41:47.119519
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Functional test for method collect of class FcWwnInitiatorFactCollector
    '''
    from ansible.module_utils.facts.collector import Collector
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.custom_module_utils.facts import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils._text import to_bytes

    def mock_get_file_lines(file):
        retval = []
        if file == '/sys/class/fc_host/host1/port_name':
            retval = [ to_bytes('0x21000014ff52a9bb') ]

# Generated at 2022-06-24 22:41:54.570410
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    if sys.platform.startswith('linux'):
        def mock_get_file_lines_0(file):
            return ['0x21000014ff52a9bb']

        def mock_get_file_lines_1(file):
            return ['0x21000014ff52a9bc']

        glob.glob = lambda dir: ['/sys/class/fc_host/host0/port_name', '/sys/class/fc_host/host1/port_name']

    elif sys.platform.startswith('sunos'):
        def mock_get_file_lines_0(file):
            return []

        def mock_get_file_lines_1(file):
            return []


# Generated at 2022-06-24 22:41:59.023814
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    result = {'fibre_channel_wwn': ['50060b00006975ec']}
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()
    assert(fc_wwn_initiator_fact_collector_0.collect() == result)


# Generated at 2022-06-24 22:42:09.476411
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    collected_facts_0 = {};
    ansible_module_0 = AnsibleModule(argument_spec = dict(module = dict(type = 'str', required = True, choices = ['setup', 'command', 'shell', 'fact', 'debug', 'meta']), gather_subset = dict(type = 'list', default = ['all'], elements = 'str', choices = ['all', 'network', 'virtual', 'hardware', 'fibre_channel_wwn'])), supports_check_mode = True)
    fc_wwn_initiator_fact_collector_0.collect(ansible_module_0, collected_facts_0)


# Generated at 2022-06-24 22:42:13.082788
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'



# Generated at 2022-06-24 22:42:16.410727
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    try:
        test_case_0()
    except Exception as e:
        print(e)
        sys.exit(1)


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:21.254453
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name
    assert FcWwnInitiatorFactCollector._fact_ids


if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:25.461681
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector.name
    assert 'ADD_HOSTNAME' in FcWwnInitiatorFactCollector._fact_ids


# Generated at 2022-06-24 22:42:26.948861
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 22:42:39.173604
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:42:46.067335
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_obj = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector_obj.collect()
    # It should be return dict
    assert isinstance(var, dict)

# Generated at 2022-06-24 22:42:55.609938
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
# AssertionError: {'fibre_channel_wwn': []} != {'fibre_channel_wwn': ['21000024ff52a9bb']}
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': []}, 'Expected values do not match'

test_case_0()
test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:43:01.431203
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn', 'The attribute "name" should be equal to "fibre_channel_wwn" but it is: ' + FcWwnInitiatorFactCollector.name
    assert FcWwnInitiatorFactCollector._fact_ids == set(), 'The attribute "_fact_ids" should be equal to the set "{}" but it is: ' + repr(FcWwnInitiatorFactCollector._fact_ids)


# Generated at 2022-06-24 22:43:09.487044
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    str_0 = repr(fc_wwn_initiator_fact_collector_0)
    assert str_0 == '<ansible.module_utils.facts.collectors.hardware.fibre_channel_wwn.FcWwnInitiatorFactCollector object at 0x7f63fa4e5898>'
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert not fc_wwn_initiator_fact_collector_0._fact_ids

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()
    test_case_

# Generated at 2022-06-24 22:43:14.465679
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:43:16.365728
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:24.619336
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_2 = fc_wwn_initiator_fact_collector_1.collect()
    assert(var_2['fibre_channel_wwn']) == [u'21000024ff52a9bb']
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_3 = fc_wwn_initiator_fact_collector_1.collect()
    assert(var_3['fibre_channel_wwn']) == [u'21000014ff52a9bb']
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollect

# Generated at 2022-06-24 22:43:28.286182
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 is not None


# Generated at 2022-06-24 22:43:34.833044
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:44:01.154008
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:44:02.273943
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try: FcWwnInitiatorFactCollector()
    except: return 1
    return 0


# Generated at 2022-06-24 22:44:02.728143
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass



# Generated at 2022-06-24 22:44:09.016537
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 is not None
    assert 'fibre_channel_wwn' in var_1


# Generated at 2022-06-24 22:44:10.879507
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    print(fc_wwn_initiator_fact_collector.collect())


# Generated at 2022-06-24 22:44:14.111459
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:44:16.877170
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:44:19.559172
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_0.collect()

test_case_0()

# Generated at 2022-06-24 22:44:20.456952
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-24 22:44:27.067564
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {
        'fibre_channel_wwn': [
            '21000014ff52a9bb'
        ]
    }


# Generated at 2022-06-24 22:45:21.309963
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 22:45:23.252036
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:45:28.016837
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.collect() == {'fibre_channel_wwn': []}


# Generated at 2022-06-24 22:45:36.748354
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert repr(fc_wwn_initiator_fact_collector_0).find("FcWwnInitiatorFactCollector") != -1
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:45:40.276253
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass


# Generated at 2022-06-24 22:45:43.371918
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:45:46.912570
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test_case_0
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert len(var_0) == 1



# Generated at 2022-06-24 22:45:49.306105
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()



# Generated at 2022-06-24 22:45:54.632140
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:45:59.630897
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:47:35.128188
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': []}, repr(var_0)



# Generated at 2022-06-24 22:47:40.544003
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:47:45.612069
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_1 = var_0.collect()
    assert var_0.name == 'fibre_channel_wwn'
    assert var_1['fibre_channel_wwn'] == []


# Generated at 2022-06-24 22:47:50.218252
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:47:53.756816
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 22:47:58.427010
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Mock input parameters
    module = MagicMock()

    # Invoke the method under test
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(module)

# Generated at 2022-06-24 22:48:04.631149
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert len(var_1) == 1
    assert isinstance(var_1['fibre_channel_wwn'], list) == True
    assert isinstance(var_1['fibre_channel_wwn'][0], str) == True


# Generated at 2022-06-24 22:48:05.994394
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("Test collect of class FcWwnInitiatorFactCollector")
    test_case_0()



# Generated at 2022-06-24 22:48:10.651318
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()
    test_case_0()

# Generated at 2022-06-24 22:48:12.557273
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()