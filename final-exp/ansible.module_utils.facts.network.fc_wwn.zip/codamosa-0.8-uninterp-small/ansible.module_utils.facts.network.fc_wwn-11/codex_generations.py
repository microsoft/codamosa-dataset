

# Generated at 2022-06-24 22:40:17.911658
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector._fact_ids == set()


# Generated at 2022-06-24 22:40:20.043863
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()

    assert ('fibre_channel_wwn' in facts)

# Generated at 2022-06-24 22:40:26.976830
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:40:28.537892
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:40:33.116982
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert type(FcWwnInitiatorFactCollector()) == FcWwnInitiatorFactCollector


# Generated at 2022-06-24 22:40:38.486326
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector
    """
    print(FcWwnInitiatorFactCollector)
    assert FcWwnInitiatorFactCollector

if __name__ == "__main__":
    """
    Unit test for FcWwnInitiatorFactCollector
    """
    #test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:48.948962
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    print("")
    print("Constructor of FcWwnInitiatorFactCollector")
    print("----------------------------------------")
    print("Name of Class       : %s" % FcWwnInitiatorFactCollector.__name__)
    print("Name of Super Class : %s" % FcWwnInitiatorFactCollector.__bases__[0].__name__)
    print("Base Fact Collector fact_ids (all)  : %s" % str(FcWwnInitiatorFactCollector._fact_ids))

# Generated at 2022-06-24 22:40:54.843123
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:40:57.269497
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:41:03.897258
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_case = [
          ['linux', 'linux', 'linux'],
          ['sunos', 'solaris', 'sunos'],
          ['aix', 'aix', 'aix'],
          ['hp-ux', 'hp-ux', 'hp-ux'],
    ]

    for tt in test_case:
        if tt[0] == tt[1]:
            print("\nTesting method FcWwnInitiatorFactCollector.collect on %s" % tt[0])
            fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
            fcfacts = fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:41:15.909037
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:41:20.373367
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:26.103816
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Testing class FcWwnInitiatorFactCollector initialisation")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    print("\tTest: printing default attribute name")
    print(fc_wwn_initiator_fact_collector_0.name)


# Generated at 2022-06-24 22:41:32.096690
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    FcWwnInitiatorFactCollector: Tests that the FcWwnInitiatorFactCollector class can be instantiated.
    :return:
    """
    fc_initiator_facts = FcWwnInitiatorFactCollector()
    assert fc_initiator_facts



# Generated at 2022-06-24 22:41:34.894855
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:41:45.038979
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    facts_collector_obj = FactsCollector()
    fc_wwn_initiator_fact_collector_obj = FcWwnInitiatorFactCollector()

    facts_collector_obj.collectors.append(fc_wwn_initiator_fact_collector_obj)

    fc_collector_list = facts_collector_obj.collect(module=None, collected_facts=None)
    fc_initiator_list = fc_collector_list['ansible_facts']['fibre_channel_wwn']

    assert len(fc_initiator_list) > 0

# Generated at 2022-06-24 22:41:46.888434
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:49.822161
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-24 22:41:50.237267
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass

# Generated at 2022-06-24 22:41:54.558343
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    if isinstance(fc_wwn_initiator_fact_collector_1, BaseFactCollector):
        sys.exit(0)
    else:
        sys.exit(1)


# Generated at 2022-06-24 22:42:08.509628
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert(fc_wwn_initiator_fact_collector is not None)



# Generated at 2022-06-24 22:42:16.373096
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.__module__ == 'ansible.module_utils.facts.network.fibre_channel_wwn', \
        'Has wrong value for FcWwnInitiatorFactCollector.__module__'
    assert FcWwnInitiatorFactCollector.__doc__ == 'Fibre Channel WWN initiator related facts collection for ansible.', \
        'Has wrong value for FcWwnInitiatorFactCollector.__doc__'
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn', \
        'Has wrong value for FcWwnInitiatorFactCollector.name'


# Generated at 2022-06-24 22:42:21.567359
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    if None:
        assert '' == ''
    assert var_0 is None

# Generated at 2022-06-24 22:42:24.375209
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_ = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:26.430051
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass


# Generated at 2022-06-24 22:42:30.653867
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-24 22:42:37.554291
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn', "Failed to setup correct name for FcWwnInitiatorFactCollector"
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()

# Generated at 2022-06-24 22:42:40.620716
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_1 = True
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    try:
        var_2 = fc_wwn_initiator_fact_collector_0.collect()
    except Exception:
        var_1 = False
    assert var_1


# Generated at 2022-06-24 22:42:45.250724
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'


if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:51.936990
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:43:15.925144
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:43:17.055830
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:43:18.661751
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert FcWwnInitiatorFactCollector().collect() is not None



# Generated at 2022-06-24 22:43:22.076963
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:43:26.994346
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Test class for base class BaseFactCollector

# Generated at 2022-06-24 22:43:31.921225
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() is not None


# Generated at 2022-06-24 22:43:36.581960
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    except NameError as e:
        assert True


if __name__ == '__main__':
    # test_FcWwnInitiatorFactCollector()
    test_case_0()

# Generated at 2022-06-24 22:43:38.969090
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    collector_1 = FcWwnInitiatorFactCollector()
    expected_1 = {}
    actual_1 = collector_1.collect()
    assert actual_1 == expected_1

# Generated at 2022-06-24 22:43:41.943620
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 == ('fibre_channel_wwn', [])



# Generated at 2022-06-24 22:43:46.443263
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert test_case_0() == None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()
    sys.exit(0)

# Generated at 2022-06-24 22:44:31.780527
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    with pytest.raises(NotImplementedError):
        fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:44:34.276701
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
  fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:44:36.233988
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:44:41.409133
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert len(var_1['fibre_channel_wwn']) >= 0, "Fibre Channel WWN initiator facts collection failed."


# Generated at 2022-06-24 22:44:52.169251
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Test case - try to use collector under linux platform
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': [u'21000014ff52a9bb']}
    # Test case - try to use collector under solaris platform
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 == {'fibre_channel_wwn': [u'10000090fa1658de']}
   

# Generated at 2022-06-24 22:44:54.196226
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:44:54.812635
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert True == True



# Generated at 2022-06-24 22:45:03.444841
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_1, FcWwnInitiatorFactCollector)
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set()

# test_case_0()
# test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:45:07.876176
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:45:10.692369
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:46:33.491747
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    with pytest.raises(TypeError):
        FcWwnInitiatorFactCollector('FcWwnInitiatorFactCollector')

# Generated at 2022-06-24 22:46:40.371266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict) == True


# Generated at 2022-06-24 22:46:44.423814
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    #check if the class exists
    if 'FcWwnInitiatorFactCollector' in globals():
        print ("Successfully instantiated FcWwnInitiatorFactCollector class.")
        test_case_0()
    else:
        print ("Failed to instantiate FcWwnInitiatorFactCollector Class")

# Generated at 2022-06-24 22:46:46.737821
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 22:46:54.708318
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0['fibre_channel_wwn'] == []

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(args=[sys.argv[0], "-s", "test_FcWwnInitiatorFactCollector_collect.py"])

# Generated at 2022-06-24 22:47:00.828118
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 22:47:05.048274
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-24 22:47:10.941237
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:47:14.401480
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except NameError:
        print("Failed to instantiate FcWwnInitiatorFactCollector class")
        raise
    else:
        print("Instance of FcWwnInitiatorFactCollector class is created successfully")


# Generated at 2022-06-24 22:47:19.585334
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    assert type(var_0).__name__ == 'FcWwnInitiatorFactCollector'
    assert var_0.collect() == dict()