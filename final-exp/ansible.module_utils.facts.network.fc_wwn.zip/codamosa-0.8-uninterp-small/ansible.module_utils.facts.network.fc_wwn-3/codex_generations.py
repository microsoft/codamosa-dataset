

# Generated at 2022-06-24 22:40:22.841297
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    type(fc_wwn_initiator_fact_collector_0).name = property(lambda self: str('_test_case_0'))
    module_0 = object()
    type(module_0).params = property(lambda self: str('_test_case_0'))
    fc_wwn_initiator_fact_collector_0.collect(module=module_0)


# Generated at 2022-06-24 22:40:28.196480
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print("test class FcWwnInitiatorFactCollector:" + str(fc_wwn_initiator_fact_collector_0))
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:40:35.084427
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    if fc_wwn_initiator_fact_collector_0.name != 'fibre_channel_wwn':
        result = False
    else:
        result = True
    return result


# Generated at 2022-06-24 22:40:39.722591
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # set up testing environment
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1._fact_ids = set()

    fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:40:41.728180
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Call test_case_0 from FcWwnInitiatorFactCollectorTestCase
    test_case_0()


# Generated at 2022-06-24 22:40:50.982415
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    # call the collect method of class FcWwnInitiatorFactCollector with a mock module
    # https://docs.ansible.com/ansible/latest/dev_guide/developing_modules_general.html#testing-modules
    fc_wwn_initiator_fact_collector_1.collect(module=None, collected_facts=None)
    # check if Fibre Channel WWN facts were collected
    assert len(fc_wwn_initiator_fact_collector_1.collect().keys()) > 0

# Generated at 2022-06-24 22:40:56.596088
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    base_fact_collector_0 = BaseFactCollector()
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect()
    fc_wwn_initiator_fact_collector_1.collect(base_fact_collector_0)


# Generated at 2022-06-24 22:40:59.475510
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:10.741644
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit tests for FcWwnInitiatorFactCollector

    This test class uses the pytest framework.
    """
    class args:
        def __init__(self):
            self.timeout = 10
            self.connection = 'local'
            self.module_path = ''
            self.tree = None
            self.args = ''
            self.remote_user = ''
            self.remote_pass = None
            self.private_key_file = None
            self.verbosity = 0
            self.no_log = False
            self.inventory = None
            self.subset = None
            self.extra_vars = None
            self.ask_vault_pass = False
            self.vault_password_files = []
            self.new_vault_password_file = None
            self.output_

# Generated at 2022-06-24 22:41:17.233527
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    if fc_wwn_initiator_fact_collector.name != 'fibre_channel_wwn':
        print("Output of FcWwnInitiatorFactCollector().name: {}".format(fc_wwn_initiator_fact_collector.name))
        raise ValueError("name doesn't match expected value: {}".format(fc_wwn_initiator_fact_collector.name))


# Generated at 2022-06-24 22:41:31.700014
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_dict = fc_wwn_initiator_fact_collector.collect()
    print(fc_wwn_initiator_dict)

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:34.456402
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:41:41.099304
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Create a new instance of a class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    # Test if the method collect of the class FcWwnInitiatorFactCollector can be called.
    fc_wwn_initiator_fact_collector_0.collect()



# Generated at 2022-06-24 22:41:44.826628
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in fc_wwn_initiator_fact_collector_1._fact_ids


# Generated at 2022-06-24 22:41:46.059558
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:41:50.263852
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert 'fibre_channel_wwn' == FcWwnInitiatorFactCollector().name

# Generated at 2022-06-24 22:41:52.571612
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Testing the constructor and name attribute of class FcWwnInitiatorFactCollector")
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:54.979584
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:58.535562
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert isinstance(fc_wwn_initiator_fact_collector._fact_ids, set)

# Generated at 2022-06-24 22:42:02.975779
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_wwn_initiator_fact_collector.collect()
    print(fc_facts)

# Generated at 2022-06-24 22:42:20.190331
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_collect_0 = FcWwnInitiatorFactCollector()
    module_0_arg_spec = dict(
        gather_subset=dict(type='list'),
        filter=dict(type='str')
    )
    module_0 = AnsibleModule(argument_spec=module_0_arg_spec)
    collected_facts_0 = dict()
    collected_facts_0.update({'__ansible_module_name': 'ioscan'})
    collected_facts_0.update({'__ansible_sys_module_name': 'ioscan'})
    collected_facts_0.update({'__ansible_sys_module_arguments': ' -fnC FC'})

# Generated at 2022-06-24 22:42:24.331280
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()
    print("Unit tests for FcWwnInitiatorFactCollector done")

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:28.170237
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:40.167203
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Test: test_FcWwnInitiatorFactCollector")
    print("==============================")

    # instanciation of class
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print("  fc_wwn_initiator_fact_collector_0: ")
    print("    %s" % fc_wwn_initiator_fact_collector_0)
    print("  type(fc_wwn_initiator_fact_collector_0): ")
    print("    %s" % type(fc_wwn_initiator_fact_collector_0))
    print("  id(fc_wwn_initiator_fact_collector_0): ")

# Generated at 2022-06-24 22:42:43.015696
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:42:48.636044
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO: mock module and fact_collector, get expected facts for each platform

    # platform: linux
    # call method collect
    # assert facts returned
    pass

    # platform: sunos
    # call method collect
    # assert facts returned
    pass

    # platform: aix
    # call method collect
    # assert facts returned
    pass

    # platform: hp-ux
    # call method collect
    # assert facts returned
    pass

# Test case for class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:42:55.900589
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0._fact_ids = [ 'fibre_channel_wwn' ]
    assert fc_wwn_initiator_fact_collector_0.collect(None, None) == { 'fibre_channel_wwn' : [ 'aabbccddeeaa', 'bbccddeeaabb' ] }


# Generated at 2022-06-24 22:43:03.368144
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("== Testing constructor FcWwnInitiatorFactCollector ==")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print(fc_wwn_initiator_fact_collector_0)
    assert fc_wwn_initiator_fact_collector_0 is not None


# Generated at 2022-06-24 22:43:08.604868
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts_collected = collector.collect()
    facts_expected = {'fibre_channel_wwn' : []}

    if 'linux' in sys.platform:
        facts_expected = {'fibre_channel_wwn' : ['21000014ff52a9bb']}
    elif 'sunos' in sys.platform:
        facts_expected = {'fibre_channel_wwn' : ['10000090fa1658de']}
    elif 'aix' in sys.platform:
        facts_expected = {'fibre_channel_wwn' : ['21000014ff52a9bb']}

# Generated at 2022-06-24 22:43:09.696168
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:43:23.977919
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 == {}


# Generated at 2022-06-24 22:43:28.261120
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:43:35.686096
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts_dict = dict()
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(collected_facts=facts_dict)
    assert var_0 == 'AnsibleModule'


# Generated at 2022-06-24 22:43:37.529544
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:41.867497
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert isinstance(var_1, dict)
    assert 'fibre_channel_wwn' in var_1
    assert len(var_1['fibre_channel_wwn']) == 0

# Generated at 2022-06-24 22:43:52.523708
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    # Test with valid values
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    if 'fibre_channel_wwn' in var_1:
        var_2 = var_1['fibre_channel_wwn']
        assert len(var_2) > 0
    fc_wwn_initiator_fact_collector_1._fact_ids = set()
    fc_wwn_initiator_fact_collector_1.name = None


# Generated at 2022-06-24 22:44:03.182334
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        file_name_0 = '/sys/class/fc_host/host0/port_name'
        file_name_1 = '/sys/class/fc_host/host1/port_name'
        file_name_2 = '/sys/class/fc_host/host2/port_name'
        file_result = open(file_name_0, 'w')
        file_result.write('0x21000014ff52a9bb')
        file_result.close()
        file_result = open(file_name_1, 'w')
        file_result.write('0x21000014ff52a9bb')

# Generated at 2022-06-24 22:44:07.045811
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 22:44:18.599442
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    try:
        assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)
    except AssertionError as ae:
        raise AssertionError(ae)
    else:
        try:
            assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
            assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
        except AssertionError as ae:
            raise AssertionError(ae)
        else:
            pass
    finally:
        pass


# Generated at 2022-06-24 22:44:20.836844
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fixture_0 = FcWwnInitiatorFactCollector()
    assert fixture_0

    # Call test_case_0
    test_case_0()


# Generated at 2022-06-24 22:44:45.528203
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() == {'fibre_channel_wwn': ['5001438008d3a308', '5001438008d3a309']}

# Generated at 2022-06-24 22:44:54.043944
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Test strings for assert on method collect of class FcWwnInitiatorFactCollector
    # assert FcWwnInitiatorFactCollector.collect(module=None, collected_facts=None) == {}
    assert False
    # assert FcWwnInitiatorFactCollector.collect(module=None, collected_facts=None) == []
    assert False
    # assert FcWwnInitiatorFactCollector.collect(module=None, collected_facts=None) == 0
    assert False

if __name__ == '__main__':
    test_case_0()

    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:45:00.312293
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # case 0
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 is not None, "Case: 0"


# Generated at 2022-06-24 22:45:06.614435
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': ['21000014ff52a9bb']}



# Generated at 2022-06-24 22:45:07.940480
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:45:15.245873
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Assert if instances have properly initialized data attributes
    assert(hasattr(fc_wwn_initiator_fact_collector_0, '_fact_ids'))
    assert(hasattr(fc_wwn_initiator_fact_collector_0, 'name'))

    # Assert if instances _fact_ids has been properly assigned value
    # Use set() to get rid of duplicates
    assert(fc_wwn_initiator_fact_collector_0._fact_ids == set(['fibre_channel_wwn']))

    # Assert if instances name has been properly assigned value

# Generated at 2022-06-24 22:45:20.811182
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert test_case_0() == None, "Test Failed!"


# Generated at 2022-06-24 22:45:26.134930
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mock_module_0 = MagicMock(name='ansible.module_utils.facts.collector.get_file_lines')
    mock_module_0.return_value = 'result'
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(module=mock_module_0)
    assert var_0 == {}

# Generated at 2022-06-24 22:45:28.605798
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fibrec = FcWwnInitiatorFactCollector()
    assert fibrec.collect() != {}

# Generated at 2022-06-24 22:45:34.069791
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:46:23.030543
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.name
    var_1 = fc_wwn_initiator_fact_collector_0._fact_ids
    var_2 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == 'fibre_channel_wwn'
    assert var_1 == set()
    assert var_2 == {}

# Generated at 2022-06-24 22:46:26.908750
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_1 = var_0.collect()


# Generated at 2022-06-24 22:46:30.324435
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:46:37.047134
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    if fc_wwn_initiator_fact_collector_0:
        print("constructor of class FcWwnInitiatorFactCollector EXIT_SUCCESS")
    else:
        print("constructor of class FcWwnInitiatorFactCollector EXIT_FAILURE")


# Generated at 2022-06-24 22:46:41.811987
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("test_FcWwnInitiatorFactCollector_collect()")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:46:50.245015
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()
    try:
        assert isinstance(var_1, dict)
    except AssertionError as e:
        raise AssertionError(e.message)
    else:
        var_2 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:46:56.524978
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector.name is not None
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:47:00.875731
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 is None


# Generated at 2022-06-24 22:47:07.533146
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0_obj = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0_obj.collect()


# Generated at 2022-06-24 22:47:14.052071
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Test method collect of class FcWwnInitiatorFactCollector"""
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    # AssertionError: False is not true : Fibre Channel WWN initiator collector execution failed
    assert var_1

# Generated at 2022-06-24 22:48:49.570388
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Example contents /sys/class/fc_host/*/port_name:
    # 0x21000014ff52a9bb
    # Example output:
    # [
    #     {
    #         "ansible_facts": {
    #             "fibre_channel_wwn": [
    #                 "21000014ff52a9bb"
    #             ]
    #         },
    #         "changed": false
    #     }
    # ]
    pass

# Generated at 2022-06-24 22:48:52.508447
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Init variables
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0['fibre_channel_wwn'] == [], "'fibre_channel_wwn' not match"



# Generated at 2022-06-24 22:48:55.523841
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-24 22:48:57.547835
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:49:03.672131
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    # create object
    var_1 = {}
    var_1['fibre_channel_wwn'] = []
    # test case
    var_2 = fc_wwn_initiator_fact_collector_1.collect(module=var_1)
    assert var_1 == var_2

# Generated at 2022-06-24 22:49:06.641434
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Test case 0
    test_case_0()
    

# Generated at 2022-06-24 22:49:10.942390
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Unit test for method collect of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:49:12.909975
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:49:17.314605
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass


# Generated at 2022-06-24 22:49:18.206251
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()
