

# Generated at 2022-06-24 22:40:22.473783
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_1, FcWwnInitiatorFactCollector)
    assert hasattr(fc_wwn_initiator_fact_collector_1, 'name')
    assert hasattr(fc_wwn_initiator_fact_collector_1, '_fact_ids')
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:40:23.924988
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()

# Generated at 2022-06-24 22:40:25.671203
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:40:37.560977
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    if len(fc_wwn_initiator_fact_collector_0.conditions) != 1:
        raise Exception('Test case 0 failed')
    if fc_wwn_initiator_fact_collector_0.name != 'fibre_channel_wwn':
        raise Exception('Test case 1 failed')
    if len(fc_wwn_initiator_fact_collector_0._fact_ids) != 0:
        raise Exception('Test case 2 failed')
    if fc_wwn_initiator_fact_collector_0.condition_applies(dict(gather_subset='network')):
        raise Exception('Test case 3 failed')


# Generated at 2022-06-24 22:40:41.685546
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_obj.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector_obj._fact_ids == set()

# Generated at 2022-06-24 22:40:47.593885
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:40:51.229233
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() == {'fibre_channel_wwn': []}


# Generated at 2022-06-24 22:40:57.892846
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        assert test_case_0()
    except AssertionError as e:
        print("Unit test for constructor of class FcWwnInitiatorFactCollector - FAILED")
    else:
        print("Unit test for constructor of class FcWwnInitiatorFactCollector - PASSED")

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:59.981830
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()

# Generated at 2022-06-24 22:41:03.335561
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:36.922207
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # Test case to run collect on linux.
    if sys.platform.startswith('linux'):
        for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
            for line in get_file_lines(fcfile):
                fc_facts = {}
                fc_facts['fibre_channel_wwn'] = []
                fc_facts['fibre_channel_wwn'].append(line.rstrip()[2:])
                fc_wwn_initiator_fact_collector.collect(module=None, collected_facts=fc_facts)
    # Test case to run collect on SunOS.
    # TBD (not implemented): on

# Generated at 2022-06-24 22:41:41.770311
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_wwn_initiator_fact_collector_0 = test_case_0()

    ret = fc_wwn_initiator_fact_collector_0.collect()

    print(ret)

# Unit test execution
#test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:42.761165
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # TODO need to implement
    return True


# Generated at 2022-06-24 22:41:45.283184
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()

# Generated at 2022-06-24 22:41:50.680686
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.collect() == {}


# Generated at 2022-06-24 22:41:54.402583
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    collected_facts = {}
    result_0 = fc_wwn_initiator_fact_collector_0.collect(collected_facts=collected_facts)
    assert (result_0 == {'fibre_channel_wwn': []})


# Generated at 2022-06-24 22:41:56.747377
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:41:59.326708
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print(sys.platform)
    assert sys.platform.startswith('linux') or sys.platform.startswith('sunos') or sys.platform.startswith('aix') or sys.platform.startswith('hp-ux')

# Generated at 2022-06-24 22:42:03.503447
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_collect = fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:42:10.337250
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_result = fc_wwn_initiator_fact_collector.collect()
    assert fc_wwn_initiator_fact_collector_result is not None
    assert fc_wwn_initiator_fact_collector_result.get('fibre_channel_wwn') is not None


# Generated at 2022-06-24 22:42:37.533414
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert hasattr(FcWwnInitiatorFactCollector, 'name')
    assert hasattr(FcWwnInitiatorFactCollector, 'collect')

# Generated at 2022-06-24 22:42:43.905020
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    if fc_wwn_initiator_fact_collector_0.name != 'fibre_channel_wwn':
        raise Exception("sys.stderr", "TestFailed: test_FcWwnInitiatorFactCollector")
    else:
        print("sys.stderr", "TestSuccess: test_FcWwnInitiatorFactCollector")


# Generated at 2022-06-24 22:42:46.890138
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:42:53.054138
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-24 22:42:55.675252
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:42:57.497131
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:43:01.511086
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 22:43:09.540576
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Unit test using the unittest framework
from ansible.module_utils.facts.collector import BaseFactCollector
from mock import Mock
from ansible.module_utils.facts import collector
import unittest
import sys
import glob

# Example output of `fcinfo hba-port` on Solaris 11

# Generated at 2022-06-24 22:43:12.773562
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:43:13.691281
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()


# Generated at 2022-06-24 22:43:41.157669
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Input parameters and expected results
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()



# Generated at 2022-06-24 22:43:43.754621
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:49.010102
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    var_0 = FcWwnInitiatorFactCollector()
    assert var_0.name == 'fibre_channel_wwn', 'Failed at test_FcWwnInitiatorFactCollector()'


if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:43:50.094542
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass  # run test_case_0

# Generated at 2022-06-24 22:43:56.189536
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class_var = FcWwnInitiatorFactCollector()
    if class_var.name != 'fibre_channel_wwn':
        print("class_var.name = %s" % class_var.name)
        assert False

    if class_var._fact_ids != set():
        print("class_var._fact_ids = %s" % class_var._fact_ids)
        assert False


# Generated at 2022-06-24 22:44:00.682195
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Constructor of class FcWwnInitiatorFactCollector.
    """
    assert('fibre_channel_wwn' in FcWwnInitiatorFactCollector().collect())


# Generated at 2022-06-24 22:44:02.050076
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert True

#  vim: set ts=4 sw=4 et fileencoding=utf-8 :

# Generated at 2022-06-24 22:44:02.724941
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()


# Generated at 2022-06-24 22:44:07.359016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.__doc__ == 'Fibre Channel WWN initiator related facts collection for ansible.'

# Generated at 2022-06-24 22:44:12.475822
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    if ((fc_wwn_initiator_fact_collector_1._fact_ids is not None) and
            (hasattr(fc_wwn_initiator_fact_collector_1._fact_ids, '__call__') and
             hasattr(fc_wwn_initiator_fact_collector_1._fact_ids, '__len__'))):
        print('Failed to create an instance of FcWwnInitiatorFactCollector')
        return False
    else:
        return True


# Generated at 2022-06-24 22:45:06.136665
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector != None


# Generated at 2022-06-24 22:45:08.163515
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()
    return test_FcWwnInitiatorFactCollector_obj


# Generated at 2022-06-24 22:45:11.735657
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    var_2 = {}
    var_2['fibre_channel_wwn'] = []
    assert var_1 == var_2


# Generated at 2022-06-24 22:45:14.317330
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:45:19.014479
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()

# Unit tests for class FcWwnInitiatorFactCollector class.

# Generated at 2022-06-24 22:45:22.237394
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector_0.collect()



# Generated at 2022-06-24 22:45:26.678411
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert glob.glob('/sys/class/fc_host/*/port_name') != None
    assert glob.glob('/sys/class/fc_host/*/port_name') != []
    # Test for raising exceptions
    assert glob.glob('/sys/class/fc_host/*/port_name') == glob.glob('/sys/class/fc_host/*/port_name')

# Generated at 2022-06-24 22:45:32.568300
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:45:36.489314
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()



# Generated at 2022-06-24 22:45:41.297265
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:47:23.737357
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var = FcWwnInitiatorFactCollector()
    print("Contents of var: " + str(var))
    assert True


# Generated at 2022-06-24 22:47:24.687548
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass


# Generated at 2022-06-24 22:47:30.001301
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # call method collect
    var = fc_wwn_initiator_fact_collector.collect()


if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:47:31.748505
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:47:36.365660
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    test_case_0()

if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:47:41.293397
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None, "Failed to create FcWwnInitiatorFactCollector"


# Generated at 2022-06-24 22:47:46.922280
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.collect()['fibre_channel_wwn'] == []

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:47:50.657459
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()
    test_case_0()



# Generated at 2022-06-24 22:47:51.609076
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:47:54.483619
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1
