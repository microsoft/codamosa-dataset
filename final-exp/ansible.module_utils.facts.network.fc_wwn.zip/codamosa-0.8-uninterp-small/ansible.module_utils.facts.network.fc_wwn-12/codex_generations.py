

# Generated at 2022-06-24 22:40:19.033631
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwns = fc_wwn_initiator_fact_collector.collect()
    if len(fc_wwns) > 0:
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:40:21.809157
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:40:26.140212
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:29.795224
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:40:34.226602
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()

# Generated at 2022-06-24 22:40:41.032317
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector
    assert isinstance(fc_wwn_initiator_fact_collector, FcWwnInitiatorFactCollector)
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:46.279401
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # this will fail if running other than on linux platform
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:40:47.363961
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    test_case_0()

# Generated at 2022-06-24 22:40:52.678024
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    loaded_facts = {}
    assert "fibre_channel_wwn" in fc_wwn_initiator_fact_collector.collect(module=None, collected_facts=loaded_facts), \
        "Failed to collect facts for fact_collector 'fibre_channel_wwn'"



# Generated at 2022-06-24 22:40:55.813613
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:41:11.036298
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector.collect()
    assert len(var['fibre_channel_wwn']) > 0

test_case_0()

# Generated at 2022-06-24 22:41:12.485104
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:18.607279
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:41:19.548618
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:41:21.041168
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
   fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:27.275688
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    fc_wwn_initiator_fact_collector_obj_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_obj_0, FcWwnInitiatorFactCollector)
    assert isinstance(fc_wwn_initiator_fact_collector_obj_0, BaseFactCollector)


# Generated at 2022-06-24 22:41:32.644931
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # var_0 = fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:41:41.569919
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 is not None, "Unable to instantiate FcWwnInitiatorFactCollector"

    # Test the name() method
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn', "Name does not match"

    # Test the collect() method
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:41:46.214148
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:41:48.579706
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_20 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_20.collect()


# Generated at 2022-06-24 22:42:13.707399
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:42:17.262639
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    test_case_0()

if __name__ == '__main__':
    # test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:21.392476
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts_0 = FcWwnInitiatorFactCollector()
    facts_1 = FcWwnInitiatorFactCollector()
    facts_1._fact_ids = set(['fibre_channel_wwn'])
    __logger = facts_1.collect()


# Generated at 2022-06-24 22:42:32.472922
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    fc_wwn_initiator_fact_collector_2 = FcWwnInitiatorFactCollector()
    var_2 = fc_wwn_initiator_fact_collector_2.collect()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 22:42:39.206797
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

if __name__ == "__main__":
    # execute only if run as a script
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:42:43.685530
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert hasattr(fc_wwn_initiator_fact_collector_1, 'name')
    assert hasattr(fc_wwn_initiator_fact_collector_1, '_fact_ids')


# Generated at 2022-06-24 22:42:46.616614
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    var_1 = FcWwnInitiatorFactCollector()
    var_2 = var_1.collect()
    assert var_2['fibre_channel_wwn'] == []

# Generated at 2022-06-24 22:42:50.249341
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:42:56.089843
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()



# Generated at 2022-06-24 22:42:59.425794
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    except NameError:
        print("NameError exception when constructing FcWwnInitiatorFactCollector")



# Generated at 2022-06-24 22:43:45.285150
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:46.304852
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:43:47.595981
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # ISSUE: test is not implemented
    assert True == True

# Generated at 2022-06-24 22:43:53.966093
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print('Unit test for constructor of class FcWwnInitiatorFactCollector')
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:44:00.986979
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # get instance
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    # Initialization test
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.name == "fibre_channel_wwn"



# Generated at 2022-06-24 22:44:10.607371
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys

    if sys.version_info[0] == 2:
        import mock

        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector('name', set())
        var_1 = fc_wwn_initiator_fact_collector_0.name
        assert var_1 == 'name'
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector('name', set())
        var_2 = fc_wwn_initiator_fact_collector_0._fact_ids
        assert var_2 == set()
    else:
        import unittest.mock

        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollect

# Generated at 2022-06-24 22:44:13.762322
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # run method collect of class FcWwnInitiatorFactCollector
    test_case_0()

# Generated at 2022-06-24 22:44:16.971750
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    if not sys.platform.startswith('linux'):
        return

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': ['210000e08b5365c4', '21000024ff4f4d4c']}



# Generated at 2022-06-24 22:44:17.482554
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


# Generated at 2022-06-24 22:44:19.311503
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.__dict__['name'] == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:45:47.568889
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass

# Generated at 2022-06-24 22:45:49.873778
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:45:53.970486
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_1 = FcWwnInitiatorFactCollector()
    var_2 = 'ansible_facts'
    var_3 = FcWwnInitiatorFactCollector()
    var_4 = 'fibre_channel_wwn'
    var_3.collect(module=ansible_facts, collected_facts=ansible_facts)
    var_1.collect(module=ansible_facts, collected_facts=ansible_facts)
    output_1 = var_1.collect(module=ansible_facts, collected_facts=ansible_facts)
    output_2 = var_3.collect(module=ansible_facts, collected_facts=ansible_facts)
    assert output_1 == output_2

# Generated at 2022-06-24 22:46:00.032985
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.collect() == {'fibre_channel_wwn': []}


# this module is not testable with unit tests

# Generated at 2022-06-24 22:46:01.998306
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:46:08.770531
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("test_FcWwnInitiatorFactCollector_collect")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-24 22:46:14.723140
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()

# Generated at 2022-06-24 22:46:18.714621
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert str(fc_wwn_initiator_fact_collector) == 'FcWwnInitiatorFactCollector'
    assert repr(fc_wwn_initiator_fact_collector) == 'FcWwnInitiatorFactCollector'


# Generated at 2022-06-24 22:46:20.572606
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert test_case_0() is None

# Generated at 2022-06-24 22:46:23.915355
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.platform == 'Base'
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:49:38.543895
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fixture_0 = FcWwnInitiatorFactCollector()
    var_0 = fixture_0.collect()

# Generated at 2022-06-24 22:49:47.139897
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("#### test_FcWwnInitiatorFactCollector_collect() ####")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    print("collect() returned")
    print("fibre_channel_wwn: {}".format(var_0['fibre_channel_wwn']))

if __name__ == "__main__":
    #test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:49:50.543874
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 is not None

test_case_0()

# Generated at 2022-06-24 22:49:54.817468
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert 'facts_d' in globals()
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 is not None


# Generated at 2022-06-24 22:49:55.889760
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except:
        assert False