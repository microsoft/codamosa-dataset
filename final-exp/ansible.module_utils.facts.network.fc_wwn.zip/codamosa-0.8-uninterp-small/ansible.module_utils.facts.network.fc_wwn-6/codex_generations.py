

# Generated at 2022-06-24 22:40:15.867913
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect()

# Generated at 2022-06-24 22:40:16.322176
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-24 22:40:19.419720
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    facts_returned = fc_wwn_initiator_fact_collector.collect()
    assert isinstance(facts_returned, dict)
    assert isinstance(facts_returned['fibre_channel_wwn'], list)

# Generated at 2022-06-24 22:40:25.401786
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)
    assert isinstance(fc_wwn_initiator_fact_collector_0, BaseFactCollector)
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:37.208615
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Searches for fibre channel WWN initiator facts file and
    creates dictionary object.
    """
    fc_fc_wwn_initiator_fact_collector_obj = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_data_dict = fc_fc_wwn_initiator_fact_collector_obj.collect()
    print (fc_wwn_initiator_fact_collector_data_dict)
    assert 'fibre_channel_wwn' in fc_wwn_initiator_fact_collector_data_dict
    assert '2' in fc_wwn_initiator_fact_collector_data_dict['fibre_channel_wwn'][0]


# Generated at 2022-06-24 22:40:39.726126
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # print(fc_wwn_initiator_fact_collector_0)



# Generated at 2022-06-24 22:40:40.204092
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()



# Generated at 2022-06-24 22:40:43.716399
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() == {'fibre_channel_wwn': []}


# Generated at 2022-06-24 22:40:47.310979
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:40:50.679809
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert(fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn')

# Generated at 2022-06-24 22:41:04.806034
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # Commented out: AnsibleModule module
    fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:41:09.413248
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:12.589817
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 is not None


# Generated at 2022-06-24 22:41:21.589200
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  if sys.platform.startswith('linux'):
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1['fibre_channel_wwn'] == ['21000014ff52a9bb']
  if sys.platform.startswith('aix'):
    fc_wwn_initiator_fact_collector_2 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_2.collect()
    assert var_1['fibre_channel_wwn'] == ['10000090fa551509']

# Generated at 2022-06-24 22:41:24.660977
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:41:27.245474
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()
    expected_0 = []
    assert var_1 == expected_0


# Generated at 2022-06-24 22:41:31.970054
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()

# Generated at 2022-06-24 22:41:37.399687
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:41.046713
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:41:49.281546
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    sys.path.insert(0, '../ansible/module_utils')
    from facts.collector import BaseFactCollector
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda x, check_rc=True: (0, '', '')

    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_1,BaseFactCollector)
    assert fc_wwn_initiator_fact_collector_1.collect(module)[0] == {}
    assert fc_wwn_initiator_fact_collector_1.collect(module)[1] == set()

# Unit

# Generated at 2022-06-24 22:42:16.000878
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print(fc_wwn_initiator_fact_collector_0.name)
    print(fc_wwn_initiator_fact_collector_0._fact_ids)


# Generated at 2022-06-24 22:42:19.930717
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except NameError as e:
        assert "global name 'BaseFactCollector' is not defined" in e.message


# Generated at 2022-06-24 22:42:25.751278
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:42:27.580800
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Constructor of class FcWwnInitiatorFactCollector invoked")


# Generated at 2022-06-24 22:42:29.110870
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert isinstance(FcWwnInitiatorFactCollector().collect(), dict)



# Generated at 2022-06-24 22:42:30.208659
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()


# Generated at 2022-06-24 22:42:38.795971
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''Test method FcWwnInitiatorFactCollector.collect'''

    if sys.platform.startswith('linux'):
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
        var_0 = fc_wwn_initiator_fact_collector_0.collect()
        assert var_0 == {u'fibre_channel_wwn': [u'21000014ff52a9bb']}

# Generated at 2022-06-24 22:42:47.003971
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    # var_0 should be of type dict
    assert isinstance(var_0, dict)
    # The keys of var_0 should contain 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in var_0.keys()
    # var_0['fibre_channel_wwn'] should be of type list
    assert isinstance(var_0['fibre_channel_wwn'], list)
    # var_0['fibre_channel_wwn'] should contain at least one item

# Generated at 2022-06-24 22:42:48.996440
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:42:55.859545
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fib_0 = FcWwnInitiatorFactCollector()
    dic_0 = {}
    dic_0['ansible_facts'] = fib_0.collect()
    ansible_facts_0 = dic_0['ansible_facts']
    fib_1 = ansible_facts_0['fibre_channel_wwn']
    # test case 0
    assert len(fib_1) == 1
    val_0 = fib_1[0]
    assert len(val_0) == 16

# Generated at 2022-06-24 22:43:43.461531
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 22:43:45.644596
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print(test_case_0.__doc__)
    test_case_0()



# Generated at 2022-06-24 22:43:49.286972
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert hex(id(fc_wwn_initiator_fact_collector_0)) == '0x7f68699eaf50'


# Generated at 2022-06-24 22:43:53.036430
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:44:00.417555
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    try:
        assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    except AssertionError as ae:
        print('Assertion test for attribute "name" in class FcWwnInitiatorFactCollector has failed!')
        print(ae)


# Generated at 2022-06-24 22:44:05.845387
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Check if the method collect of class FcWwnInitiatorFactCollector returns a dict
    fc_wwn_initiator_fact_collector_0 = FcWwwInitiatorFactCollector()

    assert isinstance(fc_wwn_initiator_fact_collector_0.collect(), dict)



# Generated at 2022-06-24 22:44:09.399215
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 is not False


# Generated at 2022-06-24 22:44:11.578450
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:44:13.140085
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert (FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn')
    assert (FcWwnInitiatorFactCollector()._fact_ids == set())

# Generated at 2022-06-24 22:44:15.134098
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == "fibre_channel_wwn"


# Generated at 2022-06-24 22:45:44.689184
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:45:48.733939
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert set(var_0['fibre_channel_wwn']) == set()


# Generated at 2022-06-24 22:45:55.243484
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 is not None


# Generated at 2022-06-24 22:45:59.192166
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:46:07.153679
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_cache = FcWwnInitiatorFactCollector()

    user_fc_wwn_facts = {'fibre_channel_wwn': '0x10000090FA551509'}
    fc_facts_0 = fc_facts_cache.collect(module=None, collected_facts=None)
    if fc_facts_0 == user_fc_wwn_facts:
        print("fc_facts_0 = %s" % fc_facts_0)
        print("user_fc_wwn_facts = %s" % user_fc_wwn_facts)
    return True



# Generated at 2022-06-24 22:46:14.330906
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert len(var_0) == 1
    assert var_0['fibre_channel_wwn'] == []
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert isinstance(var_0, dict)
    assert isinstance(var_0['fibre_channel_wwn'], list)

# Generated at 2022-06-24 22:46:23.306910
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(module=ModuleStub())
    var_1 = var_0['fibre_channel_wwn']
    assert len(var_1) == 1
    assert var_1[0] == "150508B100000012"
    var_2 = var_0['ansible_facts']
    assert 'fibre_channel_wwn' in var_2

# Generated at 2022-06-24 22:46:28.253836
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_instance = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector_instance.collect()

if __name__ == '__main__':
    test_case_0()

test_case_0()

# Generated at 2022-06-24 22:46:37.101080
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

    # if implemented for this platform, there should be at least one fibre channel WWN
    assert len(fc_wwn_initiator_fact_collector_0.collect()['fibre_channel_wwn']) > 0

# Generated at 2022-06-24 22:46:39.204654
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
