

# Generated at 2022-06-24 22:40:18.225978
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:40:22.630460
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Check the instantiation of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:40:24.729342
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("TEST: test_FcWwnInitiatorFactCollector")
    test_case_0()

if __name__ == '__main__' :
    print("TEST: __main__")
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:30.406449
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_output = fc_wwn_initiator_fact_collector.collect()

    # Check returned data is as expected
    assert fc_wwn_initiator_output is not None
    if fc_wwn_initiator_output:
        assert isinstance(fc_wwn_initiator_output, dict)
        assert 'fibre_channel_wwn' in fc_wwn_initiator_output
        for fc_wwn_initiator in fc_wwn_initiator_output['fibre_channel_wwn']:
            assert isinstance(fc_wwn_initiator, str)
            assert len

# Generated at 2022-06-24 22:40:35.600303
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:40:39.406062
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:40:43.050559
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:40:50.114248
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.system = {'kernel': 'Linux'}
    fc_wwn_initiator_fact_collector.collect(True, {})
    assert fc_wwn_initiator_fact_collector.ansible_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-24 22:40:53.010667
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:40:55.829031
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:41:26.046230
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.collect() == fc_wwn_initiator_fact_collector_1._fact_id


# Generated at 2022-06-24 22:41:34.080081
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    rc1 = sys.getrefcount(FcWwnInitiatorFactCollector)
    print("rc1: %d" % rc1)
    fcwwn = FcWwnInitiatorFactCollector()
    rc2 = sys.getrefcount(fcwwn)
    print("rc2: %d" % rc2)
    rc3 = sys.getrefcount(FcWwnInitiatorFactCollector)
    print("rc3: %d" % rc3)
    assert rc2 == rc1 + 1


# Generated at 2022-06-24 22:41:39.406560
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert hasattr(fc_wwn_initiator_fact_collector, 'name')

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-24 22:41:44.578741
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:41:49.951971
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    print("fc_wwn_initiator_fact_collector_1 type = ", type(fc_wwn_initiator_fact_collector_1))
    print("fc_wwn_initiator_fact_collector_1 vars = ", vars(fc_wwn_initiator_fact_collector_1))

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:55.419679
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1._fact_ids == {'fibre_channel_wwn'}, 'Test Failed: test_FcWwnInitiatorFactCollector() #1'


# Generated at 2022-06-24 22:42:02.495905
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'.strip()
    try:
        assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)
    except:
        assert False
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0
    try:
        fc_wwn_initiator_fact_collector_0_name = fc_wwn_initiator_fact_collector_0.name
        assert fc_wwn_initiator_fact_collector_0_name == 'fibre_channel_wwn'.strip()
    except:
        assert False


# Generated at 2022-06-24 22:42:07.775499
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 22:42:15.601667
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    if sys.platform.startswith('linux'):
        assert 'fibre_channel_wwn' == fc_wwn_initiator_fact_collector.name
        assert fc_wwn_initiator_fact_collector._fact_ids == set()


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:22.349555
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert fc_wwn_initiator_fact_collector_0 is not None
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert isinstance(fc_wwn_initiator_fact_collector_0._fact_ids, set)
    assert len(fc_wwn_initiator_fact_collector_0._fact_ids) == 0

# Generated at 2022-06-24 22:43:14.456641
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # verify if the class properties are initialized properly
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-24 22:43:18.666276
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    facts = fc_wwn_initiator_fact_collector_1.collect()
    assert type({}) == type(facts)

# Generated at 2022-06-24 22:43:22.107020
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert(
        'fibre_channel_wwn' in FcWwnInitiatorFactCollector.collect()
    )

if __name__ == '__main__':
    """
    Run this test case on the command line.
    """
    test_case_0()

# Generated at 2022-06-24 22:43:27.129719
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if not FcWwnInitiatorFactCollector.__doc__:
        raise AssertionError()
    try:
        test_case_0()
    except:
        raise AssertionError()


# Generated at 2022-06-24 22:43:31.775248
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert (FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn')
    try:
        test_case_0()
    except:
        assert(False)

# Generated at 2022-06-24 22:43:32.405519
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:43:33.465120
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector('')

# Generated at 2022-06-24 22:43:44.021288
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    ansible_module = AnsibleModuleStub()
    ansible_module.run_command = stub_run_command

    fc_wwn_initiator_facts = fc_fact_collector.collect(ansible_module)
    assert "fibre_channel_wwn" in fc_wwn_initiator_facts
    assert len(fc_wwn_initiator_facts["fibre_channel_wwn"]) == 3
    assert fc_wwn_initiator_facts["fibre_channel_wwn"][0] == '21000014ff52a9bb'


# Generated at 2022-06-24 22:43:46.620356
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:43:51.493149
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None and isinstance(fc_wwn_initiator_fact_collector, FcWwnInitiatorFactCollector)

# Generated at 2022-06-24 22:45:33.071112
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:45:38.948562
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:45:44.779045
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:45:47.369968
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except NameError as e:
        assert False , "Test case 0: " + str(e)
#


# Generated at 2022-06-24 22:45:48.733911
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert fc_wwn_initiator_fact_collector_0 is not None

# Generated at 2022-06-24 22:45:54.476515
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

test_case_0()
#test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:46:03.540442
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    ansible_module = MagicMock()
    ansible_module.get_bin_path.return_value = 'bin_path'
    ansible_module.run_command.return_value = (rc, out, err)
    ansible_module.params = {}
    ansible_module.config.side_effect = lambda: None
    result = FcWwnInitiatorFactCollector.collect(fc_wwn_initiator_fact_collector, ansible_module)
    assert result == expected_result

# Generated at 2022-06-24 22:46:08.797833
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

if __name__ == "__main__":
    #test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:46:14.975622
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:46:18.240482
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector_1.collect()
    assert isinstance(result, dict)
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-24 22:48:05.491328
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': ['21000024ffab57bd', '21000024ffab57bc', '21000024ffab57bb', '21000024ffab57ba', '21000024ffab57b9', '21000024ffab57b8', '21000024ffab57b7', '21000024ffab57b6']}

# Generated at 2022-06-24 22:48:06.411587
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_case_0()

# Generated at 2022-06-24 22:48:09.108038
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()



# Generated at 2022-06-24 22:48:14.209826
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert 'fibre_channel_wwn' in var_1
    assert 'fibre_channel_wwn_id' not in var_1

if __name__ == '__main__':
   test_case_0()
   test_FcWwnInitiatorFactCollector_collect()
   print("Unit tests for FcWwnInitiatorFactCollector: completed")

# Generated at 2022-06-24 22:48:17.589410
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create the instance with default values
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Run the method with no arguments
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    # Verify the result
    assert(var_0 == "Not implemented")


# Generated at 2022-06-24 22:48:25.427225
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # FcWwnInitiatorFactCollector instance.
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Call method collect of fc_wwn_initiator_fact_collector_0 with
    # argument None.
    var_0 = fc_wwn_initiator_fact_collector_0.collect(None)
    # Assert isinstance of var_0 to FcWwnInitiatorFactCollector.
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:48:27.864920
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # no initialization parameter, check defaults
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:48:28.369153
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
        test_case_0()

# Generated at 2022-06-24 22:48:30.118336
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:48:34.431343
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
