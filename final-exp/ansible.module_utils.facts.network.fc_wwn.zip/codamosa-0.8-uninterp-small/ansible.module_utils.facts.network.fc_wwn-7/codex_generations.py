

# Generated at 2022-06-24 22:40:15.899504
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None

# Generated at 2022-06-24 22:40:18.965727
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:40:21.965334
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = test_case_0()
    fc_wwn_initiator_fact_collector_0.collect()


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:28.893791
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    assert 'name' in FcWwnInitiatorFactCollector.__dict__
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert '_fact_ids' in FcWwnInitiatorFactCollector.__dict__
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


# Generated at 2022-06-24 22:40:30.500236
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:40:34.450090
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except Exception as e:
        assert False , "Failed test_case_0: %s" % e

# Generated at 2022-06-24 22:40:44.508016
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_collect_facts = {
        'fibre_channel_wwn': [
            '2000001d9d946b4c',
            '2000001d9d946b4d',
            '2100001b335f28b8',
            '2100001b335f28b9',
            '100000051a1b523d',
            '2000001d9d946b4e',
            '2000001d9d946b4f',
            '2100001b335f28ba',
            '2100001b335f28bb'
        ]
    }

    fc = FcWwnInitiatorFactCollector()
    fc.collect(module=None, collected_facts=None)

# Generated at 2022-06-24 22:40:49.887874
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:40:56.720890
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:40:58.635846
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:41:13.878498
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()
    test_case_0()

# Generated at 2022-06-24 22:41:19.551015
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Getting the instance of the FcWwnInitiatorFactCollector class
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Calling method collect of the class FcWwnInitiatorFactCollector
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    # Printing results for debug purposes
    print(var_0)


# Generated at 2022-06-24 22:41:28.143981
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert "fibre_channel_wwn" in var_0
    assert isinstance(var_0["fibre_channel_wwn"], list)
    assert len(var_0["fibre_channel_wwn"]) > 0
    for wwn in var_0["fibre_channel_wwn"]:
        assert isinstance(wwn, str)

    # Unit test for method collect of class FcWwnInitiatorFactCollector

test_FcWwnInitiatorFactCollector_collect()


# Generated at 2022-06-24 22:41:30.704749
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:36.161637
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector.collect()
    assert var == {'fibre_channel_wwn': ['21000024ff52e5da', '21000024ff52b644']}


# Generated at 2022-06-24 22:41:42.532860
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("## Unit test for method collect of class FcWwnInitiatorFactCollector")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert type(var_0) is dict, 'var_0 is {}'.format(type(var_0))



# Generated at 2022-06-24 22:41:46.968620
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set([])

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:57.629033
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    var_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.__init__()
    var_2 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Test of attributes of class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:42:01.449337
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert fc_wwn_initiator_fact_collector._platform == 'Generic'


# Generated at 2022-06-24 22:42:07.242027
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    global FcWwnInitiatorFactCollector, sys

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):
        def setUp(self):
            self.fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

        def tearDown(self):
            self.fc_wwn_initiator_fact_collector_0 = None

        def test__collect(self):
            self.fc_wwn_initiator_fact_collector_0._collect()


# Generated at 2022-06-24 22:42:35.100506
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.__class__.__name__ == 'FcWwnInitiatorFactCollector'


# Generated at 2022-06-24 22:42:39.806543
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 22:42:41.818188
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:42:47.471601
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if sys.platform.startswith('linux'):
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
        assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    else:
        print('SKIPPED: The test is not supported on this platform')


# Generated at 2022-06-24 22:42:51.382851
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:42:56.120660
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiatorfactcollector = FcWwnInitiatorFactCollector()
    if FcWwnInitiatorFactCollector is not type(fc_wwn_initiatorfactcollector):
        raise AssertionError(fc_wwn_initiatorfactcollector)


# Generated at 2022-06-24 22:42:59.175924
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_1.collect(), dict)



# Generated at 2022-06-24 22:43:01.706306
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:43:03.419856
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()

# Generated at 2022-06-24 22:43:05.314113
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_obj = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_obj is not None


# Generated at 2022-06-24 22:43:52.379342
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_instance = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector_instance.collect()


# Generated at 2022-06-24 22:43:57.087109
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        print("Unit test for constructor of class FcWwnInitiatorFactCollector FAILED")
        sys.exit(-1)
    print("Unit test for constructor of class FcWwnInitiatorFactCollector PASSED")
    sys.exit(0)

# Generated at 2022-06-24 22:44:01.246847
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert not (FcWwnInitiatorFactCollector().name)


# Generated at 2022-06-24 22:44:09.174264
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    print("TESTING: fc_wwn_initiator_fact_collector_1.name -> %s" % fc_wwn_initiator_fact_collector_1.name)
    print("TESTING: fc_wwn_initiator_fact_collector_1.collect() -> %s" % fc_wwn_initiator_fact_collector_1.collect())


# Generated at 2022-06-24 22:44:19.377089
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)
    mock_module_0 = Mock()
    mock_module_0.run_command.return_value = 'Error: Some simulation error'
    details = {}
    details['ansible_facts'] = {}
    details['ansible_facts']['fibre_channel_wwn'] = []
    assert fc_wwn_initiator_fact_collector_0.collect(mock_module_0, details) == details


# Generated at 2022-06-24 22:44:20.904813
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_instance = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_instance.collect() == {'fibre_channel_wwn': []}, 'Incorrect value returned'


# Generated at 2022-06-24 22:44:25.470438
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # arrange
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # act
    fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:44:26.986228
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:44:31.534779
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.collect() == {}


# Generated at 2022-06-24 22:44:36.475598
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_1 = var_0.collect()
    var_2 = FcWwnInitiatorFactCollector()
    var_3 = var_2.collect()


# Generated at 2022-06-24 22:46:08.631200
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector_instance = FcWwnInitiatorFactCollector()
    pass


# Generated at 2022-06-24 22:46:14.541038
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_1 = var_0.collect()
    var_2 = type(var_1)
    assert var_2 == dict
    var_3 = var_1['fibre_channel_wwn']
    var_4 = type(var_3)
    assert var_4 == list
    var_5 = var_3[0]
    var_6 = type(var_5)
    assert var_6 == str


# Generated at 2022-06-24 22:46:17.760690
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:46:23.172340
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Parameters
    module = None
    collected_facts = None

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(module=module, collected_facts=collected_facts)



# Generated at 2022-06-24 22:46:28.030930
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:46:31.957220
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    res = fc_wwn_initiator_fact_collector.collect()
    assert (res == "fibre_channel_wwn")


# Generated at 2022-06-24 22:46:34.650073
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert test_case_0() == None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:46:37.779233
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert True


# Generated at 2022-06-24 22:46:41.314259
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    print(var_0)


# Generated at 2022-06-24 22:46:44.259666
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
