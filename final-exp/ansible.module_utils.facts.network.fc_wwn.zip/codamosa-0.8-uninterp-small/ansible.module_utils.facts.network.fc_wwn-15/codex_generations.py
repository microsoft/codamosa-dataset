

# Generated at 2022-06-24 22:40:18.225952
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector.collect()
    assert result is not None

# Generated at 2022-06-24 22:40:20.892604
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:40:27.046129
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() == {}


# Generated at 2022-06-24 22:40:29.107852
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = test_case_0()

# Generated at 2022-06-24 22:40:35.129797
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert(fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn')


# Generated at 2022-06-24 22:40:39.303182
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector.collect()
    assert isinstance(result, dict)
    assert 'fibre_channel_wwn' in result
    result = result['fibre_channel_wwn']
    assert isinstance(result, list)

# Generated at 2022-06-24 22:40:45.370719
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    global fc_facts
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_facts = fc_wwn_initiator_fact_collector_0.collect()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()
    for key in fc_facts['fibre_channel_wwn']:
        print(key)

# Generated at 2022-06-24 22:40:53.568061
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()
    assert(type(facts) == dict)
    assert("fibre_channel_wwn" in facts)
    if sys.platform.startswith("linux"):
        assert(type(facts["fibre_channel_wwn"]) == list)
    elif sys.platform.startswith("sunos"):
        # TBD
        pass
    elif sys.platform.startswith("aix"):
        # TBD
        pass
    elif sys.platform.startswith("hp-ux"):
        # TBD
        pass

# Generated at 2022-06-24 22:41:03.240936
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    content = '0x21000014ff52a9bb'
    content_lines = content.splitlines()
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    fc_wwn_initiator._get_file_lines = lambda x: content_lines
    facts_dict = dict()
    facts_dict['ansible_fibre_channel_wwn'] = []
    fc_wwn_initiator.collect(collected_facts=facts_dict)
    assert facts_dict['ansible_fibre_channel_wwn'][0] == content
    facts_dict = dict()
    facts_dict['ansible_fibre_channel_wwn'] = []
    fc_wwn_initiator.collect(collected_facts=facts_dict)

# Generated at 2022-06-24 22:41:10.446945
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create FcWwnInitiatorFactCollector 0
    FcWwnInitiatorFactCollector_0 = FcWwnInitiatorFactCollector()
    # Assert that the method collect of FcWwnInitiatorFactCollector return is
    # equal to the following dict:
    # {'fibre_channel_wwn': []}
    assert FcWwnInitiatorFactCollector_0.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:41:41.818453
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector.priority == 70


# Generated at 2022-06-24 22:41:42.408704
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:41:45.944424
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'



# Generated at 2022-06-24 22:41:53.941371
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert isinstance(fc_wwn_initiator_fact_collector._fact_ids, set)
    assert not fc_wwn_initiator_fact_collector._fact_ids



# Generated at 2022-06-24 22:42:02.745945
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    assert FcWwnInitiatorFactCollector.__bases__[0] == BaseFactCollector
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    FcWwnInitiatorFactCollector._fact_ids.add('fibre_channel_wwn')
    assert FcWwnInitiatorFactCollector._fact_ids == set(['fibre_channel_wwn'])

if __name__ == '__main__':
    in_test = True
    import argparse
    PARSER = argparse.ArgumentParser()
    PARSER.add_argument('-t', '--test', dest='test', help='Test case to run: 0')
   

# Generated at 2022-06-24 22:42:08.327883
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Test when sys.platform is 'linux'
    if sys.platform.startswith('linux'):
        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
        module = 'dummy'
        collected_facts = {}
        results = fc_wwn_initiator_fact_collector.collect(module, collected_facts)
        print(results)

# Generated at 2022-06-24 22:42:11.110061
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert True == hasattr(FcWwnInitiatorFactCollector, 'name')
    assert 'fibre_channel_wwn' == FcWwnInitiatorFactCollector.name



# Generated at 2022-06-24 22:42:14.843325
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector, FcWwnInitiatorFactCollector)

# Generated at 2022-06-24 22:42:20.556519
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.collect() == {}

# Generated at 2022-06-24 22:42:28.938395
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FC_WWN_INITIATOR_FACTS = {
        'fibre_channel_wwn': [
            '21000014ff52a9bb'
        ]
    }
    os = 'LINUX'
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector(os)
    fc_wwn_initiator_facts = fc_wwn_initiator_fact_collector_1.collect()
    assert FC_WWN_INITIATOR_FACTS == fc_wwn_initiator_facts

# Generated at 2022-06-24 22:42:53.009098
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert fc_wwn_initiator_fact_collector_0


# Generated at 2022-06-24 22:42:54.953842
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    assert fc_wwn_initiator_fact_collector_0.__class__ == FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:42:57.459532
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == "fibre_channel_wwn"
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-24 22:43:04.732169
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except NameError as e:
        assert False , "Failed to create instance of FcWwnInitiatorFactCollector"

if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:43:16.483220
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)

# Generated at 2022-06-24 22:43:19.017799
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector != None


# Generated at 2022-06-24 22:43:27.551235
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0._module = fc_wwn_initiator_fact_collector_1._module
    #
    ret0 = fc_wwn_initiator_fact_collector_0.collect()
    #
    assert ret0 is not None


# Generated at 2022-06-24 22:43:34.940628
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except Exception as e:
        print("Failed in module testing of class FcWwnInitiatorFactCollector:" + str(e))
        sys.exit(1)
    sys.exit(0)


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:43:38.943415
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:41.682077
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:44:08.732238
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_init_fact_coll = FcWwnInitiatorFactCollector()
    assert fcwwn_init_fact_coll.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:44:11.680471
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # get an instance of the class to be tested
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    # test the method collect of class FcWwnInitiatorFactCollector with invalid parameters
    try:
        fc_wwn_initiator_fact_collector_1.collect(collected_facts=None, module=None)
    except TypeError:
        pass



# Generated at 2022-06-24 22:44:12.857157
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:44:14.635763
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:44:18.280861
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()
    var_2 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert isinstance(var_1, dict)
    assert isinstance(var_2, dict)


# Generated at 2022-06-24 22:44:23.008342
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = {}
    collected_facts = fc_wwn_initiator_fact_collector.collect(collected_facts)
    assert not collected_facts['fibre_channel_wwn']


# Generated at 2022-06-24 22:44:29.033304
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.collector == 'FcWwnInitiatorFactCollector'


# Generated at 2022-06-24 22:44:35.533530
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0
    var_1 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:44:40.573841
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert len(var_0) == 1
    assert var_0['fibre_channel_wwn'] == []

# Generated at 2022-06-24 22:44:41.598793
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert True == True



# Generated at 2022-06-24 22:45:32.539778
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:45:42.969485
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Input params and expected result.
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    # Execution of the function under test.
    var_1 = fc_wwn_initiator_fact_collector_0._name('fibre_channel_wwn')
    # Evaluation of the result.
    var_2 = fc_wwn_initiator_fact_collector_0._fact_ids('fibre_channel_wwn')
    var_3 = fc_wwn_initiator_fact_collector_0.name
    var_4 = fc_wwn_initiator_fact_collector_0.collect

# Generated at 2022-06-24 22:45:48.555047
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.collect() is not None


# Generated at 2022-06-24 22:45:53.977948
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:46:00.969075
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:46:03.578983
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:46:08.075067
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert (fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn')


# Generated at 2022-06-24 22:46:13.901016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    except NameError as err:
        assert False


# Generated at 2022-06-24 22:46:16.195163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:46:23.434747
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0['fibre_channel_wwn'] == []

# Generated at 2022-06-24 22:48:03.374958
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print('')

    # Define methods and instantiate objects for testing
    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()
    #TODO: define test methods

    # Perform tests
    #TODO: test methods


# Start program
if __name__ == "__main__":
    print('')
    print('Testing ...')
    print('')
    test_FcWwnInitiatorFactCollector_collect()
    test_case_0()
    print('')
    print('Testing module ...')
    print('')
    print('Done!')
    print('')

# Generated at 2022-06-24 22:48:10.399902
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert 'fibre_channel_wwn' in var_1

# Generated at 2022-06-24 22:48:14.734586
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    except Exception:
        assert False


# Generated at 2022-06-24 22:48:18.705947
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name is 'fibre_channel_wwn'


# Generated at 2022-06-24 22:48:27.618645
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Eliminate this entire function call and its output if there are
    # no assertions in the function body.
    test_case_0()

# ------------------------------------------------------------------------------
# Example 'fibre_channel_wwn' fact data.
# ------------------------------------------------------------------------------

fibre_channel_wwn_fact_data = [
    {'fibre_channel_wwn': ['50060b00006975ec']}
]

# ------------------------------------------------------------------------------
# Unit tests for FcWwnInitiatorFactCollector class.
# ------------------------------------------------------------------------------

if __name__ == '__main__':
    # Run unit tests.
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:48:29.096195
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert not var_0

# Generated at 2022-06-24 22:48:34.471748
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1 is not None


# Generated at 2022-06-24 22:48:45.801199
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Test if the class is defined
    assert(fc_wwn_initiator_fact_collector_0 is not None)
    # Test if the subclass is correctly inherited from the parent
    assert(isinstance(fc_wwn_initiator_fact_collector_0, BaseFactCollector))
    # Test if the class implements 'collect' method
    assert(hasattr(fc_wwn_initiator_fact_collector_0, "collect"))
    # Test if the class implements '_fact_ids' property
    assert(hasattr(fc_wwn_initiator_fact_collector_0, "_fact_ids"))



# Generated at 2022-06-24 22:48:48.120403
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:48:50.988191
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Initial test setup
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()

    # validate call to method
    assert fc_wwn_initiator_fact_collector.collect() is None