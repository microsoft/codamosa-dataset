

# Generated at 2022-06-24 22:40:18.637509
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:40:20.971609
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:40:26.787358
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None, 'FcWwnInitiatorFactCollector constructor error'
    assert fc_wwn_initiator_fact_collector.name.lower() == 'fibre_channel_wwn', 'FcWwnInitiatorFactCollector name error'



# Generated at 2022-06-24 22:40:30.401995
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:40:40.999609
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Create an instance of the class to be tested.
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    # Read in the contents of the test file and return a list of lines.
    test_file_data = fc_wwn_initiator_fact_collector._load_file('/sys/class/fc_host/host2/port_name')
    test_file_lines = [line for line in test_file_data.split('\n') if line != '']

    # Loop through the test file lines
    for line in test_file_lines:
        # Remove the trailing newline character
        line = line.rstrip()


# Generated at 2022-06-24 22:40:49.096250
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector.collect()
    assert len(result.keys()) == 1
    assert result.get('fibre_channel_wwn') is not None

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:56.820979
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_facts = fc_wwn_initiator_fact_collector_0.collect()
    print (fc_wwn_initiator_facts)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:59.947853
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:41:02.564048
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector_0 = FcWwnInitiatorFactCollector()
    fact_collector_1 = FcWwnInitiatorFactCollector()

if __name__ == '__main__':
    test_case_0()

    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:07.452462
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    #TODO: use a mock module to be able to test on different platforms
    fc_facts = fc_wwn_fact_collector.collect(module=None, collected_facts=None)
    return

# Generated at 2022-06-24 22:41:26.673557
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert len(var_0['fibre_channel_wwn']) == 2
    assert var_0['fibre_channel_wwn'][0] == '21000014ff52a9bb'
    assert var_0['fibre_channel_wwn'][1] == '21000014ff52a9bb'

# Generated at 2022-06-24 22:41:27.218425
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert True

# Generated at 2022-06-24 22:41:31.593212
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test case for method collect of class FcWwnInitiatorFactCollector
    """
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    # verify initialization of member _fact_ids
    assert isinstance(var_1, dict)
    # check that member _fact_ids is not empty
    assert var_1 == {'fibre_channel_wwn': []}

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:38.161488
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn', 'Class FcWwnInitiatorFactCollector is not correct'
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector.collect()
    assert var == {}, 'Class FcWwnInitiatorFactCollector is not correct'

# Generated at 2022-06-24 22:41:42.057714
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:41:45.323413
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:41:49.814928
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:53.849964
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

test_case_0()
test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:55.626362
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


if __name__ == '__main__':
    print('Starting module test')
    sys.exit(test_case_0())

# Generated at 2022-06-24 22:41:58.247385
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:42:25.415364
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:42:26.551927
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass



# Generated at 2022-06-24 22:42:33.178090
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'fibre_channel_wwn' in var_0
    assert len(var_0['fibre_channel_wwn']) == 0
    assert isinstance(var_0['fibre_channel_wwn'], list)


# Generated at 2022-06-24 22:42:38.133235
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    except:
        var_1 = False
    else:
        var_1 = True
    finally:
        assert var_1


# Generated at 2022-06-24 22:42:44.158132
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    collected_facts_0 = dict()
    fc_wwn_initiator_fact_collector_retval_0 = fc_wwn_initiator_fact_collector_0.collect(collected_facts_0)
    # Test for correct return type
    assert(type(fc_wwn_initiator_fact_collector_retval_0) is dict)


# Generated at 2022-06-24 22:42:48.244827
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:42:52.021860
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'


test_case_0()

# Generated at 2022-06-24 22:42:53.188380
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-24 22:42:56.161815
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector.collect()
    print(var)



# Generated at 2022-06-24 22:43:07.612347
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.sys_info.fibre_channel_wwn import FcWwnInitiatorFactCollector

    module = AnsibleModuleFake()
    Collector.set_module(module)
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 in (None, {})
    Collector.set_module(None)



# Generated at 2022-06-24 22:44:04.539252
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


if __name__ == '__main__':
    for test_func in [test_FcWwnInitiatorFactCollector, test_case_0]:
        print(test_func.__name__)
        test_func()
        print('\n')

# Generated at 2022-06-24 22:44:11.368683
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Unit test of method 'collect' of class 'FcWwnInitiatorFactCollector'
    print('Testing gather of Fibre-Channel WWN initiator facts on linux')
    # Test case 0
    # test_case_0()
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    print('fcwwn (linux): %s' % var_0)
    assert var_0 != {}

# Generated at 2022-06-24 22:44:12.144319
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # unit test case for not implemented yet
    pass


# Generated at 2022-06-24 22:44:14.281218
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    var1 = FcWwnInitiatorFactCollector()
    assert var1.name == 'fibre_channel_wwn'
    assert var1._fact_ids == {('name', 'fibre_channel_wwn')}
    assert len(var1._fact_ids) == 1


# Generated at 2022-06-24 22:44:18.215616
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if sys.platform.startswith('linux'):

        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
        assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
        expected_set = {'fibre_channel_wwn'}
        assert fc_wwn_initiator_fact_collector._fact_ids == expected_set

# Generated at 2022-06-24 22:44:25.005809
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
        print(fc_wwn_initiator_fact_collector_1)
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_case_0()
    # Test class FcWwnInitiatorFactCollector
    #test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:44:30.683735
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test mocking with argument 0
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector(0)
    var = fc_wwn_initiator_fact_collector.collect()
    assert True == type(var) is dict



# Generated at 2022-06-24 22:44:35.916524
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert len(FcWwnInitiatorFactCollector().name)
    assert len(FcWwnInitiatorFactCollector()._fact_ids)


# Generated at 2022-06-24 22:44:41.937195
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set(), 'Attribute _fact_ids is not set to an empty set'
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn', 'Attribute name is not set to a value'


# Generated at 2022-06-24 22:44:46.927159
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:46:25.943692
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # initialize fact collector
    fact_collector = FcWwnInitiatorFactCollector()
    # collect facts
    facts = fact_collector.collect()
    # check return type
    if not isinstance(facts, dict):
        raise AssertionError("Failed to collect facts. Return type: {}".format(type(facts)))
    # check collected facts
    if 'fibre_channel_wwn' not in facts:
        raise AssertionError("Failed to collect facts. Missing facts: 'fibre_channel_wwn'")
    else:
        if not isinstance(facts['fibre_channel_wwn'], list):
            raise AssertionError("Failed to collect facts. Return type: {}".format(type(facts['fibre_channel_wwn'])))

# Generated at 2022-06-24 22:46:29.282400
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:46:31.387292
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:46:38.542767
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert len(fc_wwn_initiator_fact_collector_0._fact_ids) == 0



# Generated at 2022-06-24 22:46:40.580843
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:46:42.613383
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:46:45.806981
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector


# Generated at 2022-06-24 22:46:51.716225
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:46:53.055750
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:46:58.164365
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
