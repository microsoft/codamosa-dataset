

# Generated at 2022-06-24 22:40:16.021687
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print(fc_wwn_initiator_fact_collector_0.collect())

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:24.727153
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Testing constructor of FcWwnInitiatorFactCollector")
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn', "Assertion of FcWwnInitiatorFactCollector failed."

# Unit test main
# Reference: https://docs.python.org/2/library/unittest.html#basic-example
import unittest


# Generated at 2022-06-24 22:40:26.519542
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:40:30.401729
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0._collect()


# Generated at 2022-06-24 22:40:38.764394
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import collector

    # Add this class to the list of available fact collectors
    collector.add_collector(FcWwnInitiatorFactCollector)

    # Create an instance of FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print(repr(fc_wwn_initiator_fact_collector_0))


# Generated at 2022-06-24 22:40:42.762700
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Testing class FcWwnInitiatorFactCollector")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:49.589561
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    class TestModule(object):
        def run_command(self, argv):
            return 0, argv, ''
        def get_bin_path(self, argv, opt_dirs = []):
            return argv
    test_module_0 = TestModule()
    fc_wwn_initiator_fact_collector_0.collect(test_module_0)

test_case_0()

# Generated at 2022-06-24 22:40:55.107626
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:01.879945
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    from ansible.module_utils.facts.utils import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=[], type='list')),
        supports_check_mode=True)

    # test case 1: verify that wwn list is empty
    fc_facts = fc_wwn_initiator_fact_collector.collect(module=module, collected_facts={})
    assert fc_facts['fibre_channel_wwn'] is not None
    assert len(fc_facts['fibre_channel_wwn']) == 0

# Generated at 2022-06-24 22:41:08.166670
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    results = fc_wwn_initiator_fact_collector_0.collect()
    #results = fc_wwn_initiator_fact_collector_0.collect(module=ansible_module_0)
    assert 'fibre_channel_wwn' in results


# Generated at 2022-06-24 22:41:33.531468
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-24 22:41:41.310040
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect()
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set([('fibre_channel_wwn', None)])
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:41:46.625292
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

    """
    Example contents /sys/class/fc_host/*/port_name:

    0x21000014ff52a9bb

    """

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    if sys.platform.startswith('linux'):
        for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
            for line in get_file_lines(fcfile):
                fc_facts['fibre_channel_wwn'].append(line.rstrip()[2:])

# Generated at 2022-06-24 22:41:53.037761
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector_0.collect()
    assert result == {}, "Result: %s" % result


# Generated at 2022-06-24 22:41:56.934319
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in fc_wwn_initiator_fact_collector._fact_ids,\
        'Failed to create FcWwnInitiatorFactCollector, missing variable fibre_channel_wwn in _fact_ids'

# Generated at 2022-06-24 22:42:01.991729
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.__class__.__name__ == 'FcWwnInitiatorFactCollector'
    assert repr(fc_wwn_initiator_fact_collector) == '<ansible.module_utils.facts.collector.FcWwnInitiatorFactCollector>'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-24 22:42:07.571571
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_facts_dict = fc_wwn_initiator_fact_collector_0.collect()

    # Verify if the result is 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts_dict

# Generated at 2022-06-24 22:42:10.337176
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector_0.collect()
    print(result)

# Generated at 2022-06-24 22:42:21.253506
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:42:27.741856
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:42:50.659535
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'



# Generated at 2022-06-24 22:42:55.063876
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()


# Generated at 2022-06-24 22:42:59.711529
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

    class MockModule:
        pass

    class MockFacts:
        pass

    ansible_module = MockModule()
    ansible_facts = MockFacts()

    c = FcWwnInitiatorFactCollector()
    c.collect(None)




# Generated at 2022-06-24 22:43:09.125767
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fake_module = FakeAnsibleModule()
    fake_module.set_collector(FcWwnInitiatorFactCollector())

    if sys.platform.startswith('linux'):
        data = """0x21000014ff52a9bb
        0x21000014ff52a9bc
        """
        fake_module.set_content_one_file('/sys/class/fc_host/host0/port_name', data)
        fake_module.set_content_one_file('/sys/class/fc_host/host1/port_name', data)
        test_data = { 'fibre_channel_wwn': ['21000014ff52a9bb', '21000014ff52a9bb', '21000014ff52a9bc', '21000014ff52a9bc'] }

# Generated at 2022-06-24 22:43:11.357539
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert(fc.name == 'fibre_channel_wwn')

# Generated at 2022-06-24 22:43:12.424009
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-24 22:43:15.408469
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None

# Generated at 2022-06-24 22:43:19.569285
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:43:22.621705
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:43:27.949731
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert test_case_0() is None


fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
fc_wwn_initiator_fact_collector.collect()

# Generated at 2022-06-24 22:43:54.993952
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0.collect(), dict) == True
    assert len(fc_wwn_initiator_fact_collector_0.collect()) == 1


# Generated at 2022-06-24 22:43:59.568077
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector.name
    assert FcWwnInitiatorFactCollector._fact_ids == set()



# Generated at 2022-06-24 22:44:04.957367
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:44:08.656000
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    var_1 = FcWwnInitiatorFactCollector()
    assert var_1.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:44:12.424482
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()
    test_case_0()

# Generated at 2022-06-24 22:44:16.212678
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()
    if 'fibre_channel_wwn' not in var_1:
        var_1['fibre_channel_wwn'].append("")
        var_1['fibre_channel_wwn'].append("")
    else:
        assert len(var_1['fibre_channel_wwn']) == 2



# Generated at 2022-06-24 22:44:23.765037
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict) == True
    assert var_0.keys() == ['fibre_channel_wwn']
    assert isinstance(var_0['fibre_channel_wwn'], list) == True


# Generated at 2022-06-24 22:44:28.025949
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)

# Generated at 2022-06-24 22:44:33.266815
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': [0x21000014ff52a9bb]}


# Generated at 2022-06-24 22:44:36.221988
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:45:27.444531
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert sys.platform.startswith('linux')

    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()

    assert len(var_1.keys()) == 1 and 'fibre_channel_wwn' in var_1.keys()
    assert var_1['fibre_channel_wwn'] and isinstance(var_1['fibre_channel_wwn'], list)
    assert len(var_1['fibre_channel_wwn']) >= 1



# Generated at 2022-06-24 22:45:30.017286
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except Exception as e:
        print("Testcase Failed: {}".format(e))
        raise e
    finally:
        print("Testcase Passed")
        return


# Unit test driver
if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:45:32.050400
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Unit tests for this class

# Generated at 2022-06-24 22:45:35.957890
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    except NameError as e:
        print(e)

test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:45:41.822410
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # Global setup for method collect of class FcWwnInitiatorFactCollector
    var = fc_wwn_initiator_fact_collector.collect()
    if "fibre_channel_wwn" in var:
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:45:43.371637
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()


# Generated at 2022-06-24 22:45:50.635248
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    When the constructor of the class FcWwnInitiatorFactCollector
    is called, then the attribute 'name' is set to the value 'fibre_channel_wwn'.
    Additionally, all fact identifiers are added to the set '_fact_ids'.

    Input parameters:
        None

    Expected results:
        The attribute 'name' is set to the value 'fibre_channel_wwn'.
        The attribute '_fact_ids' is an instance of the class set.
        The set '_fact_ids' contains the elements
            - 'fibre_channel_wwn'
    """

    # the constructor of the class FcWwnInitiatorFactCollector is called
    # and the result is stored in the variable 'fc_wwn_initiator_fact_collector'
    fc_w

# Generated at 2022-06-24 22:45:54.718444
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Run tests
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:46:01.156999
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == "fibre_channel_wwn"
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 22:46:05.474050
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector_0 = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_0._fact_ids == set([])
    assert FcWwnInitiatorFactCollector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:47:31.952155
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass  # TODO: add unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:47:37.587872
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:47:41.239027
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:47:47.944866
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector( )
    var_0 = fc_wwn_initiator_fact_collector_0.name
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector( name='fc_wwn')
    var_1 = fc_wwn_initiator_fact_collector_1.name
    return (var_0, var_1)


# Generated at 2022-06-24 22:47:58.104362
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    var_0 = FcWwnInitiatorFactCollector()
    var_1 = FcWwnInitiatorFactCollector()
    var_2 = FcWwnInitiatorFactCollector()
    var_3 = FcWwnInitiatorFactCollector()
    var_4 = FcWwnInitiatorFactCollector()
    var_5 = FcWwnInitiatorFactCollector()
    var_6 = FcWwnInitiatorFactCollector()
    var_7 = FcWwnInitiatorFactCollector()

    # Call method collect of var_0
    var_0.collect(module=None, collected_facts=None)

    # Call method collect of var_1
    var_1.collect(module=None, collected_facts=None)

    # Call method collect of var

# Generated at 2022-06-24 22:48:00.982863
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:48:07.910827
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)
    assert hasattr(fc_wwn_initiator_fact_collector_0, '_fact_ids')
    assert hasattr(fc_wwn_initiator_fact_collector_0, '_platform')
    assert hasattr(fc_wwn_initiator_fact_collector_0, '_subscriptions')
    assert hasattr(fc_wwn_initiator_fact_collector_0, '_subscriptions')
    assert fc_wwn_initiator_fact_collector_0._subscriptions == set()


# Generated at 2022-06-24 22:48:11.642056
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict, var_0)
    # assert var_0 == {}


# Generated at 2022-06-24 22:48:12.585133
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass
# no class docstring, has method docstring

# Generated at 2022-06-24 22:48:13.229584
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass