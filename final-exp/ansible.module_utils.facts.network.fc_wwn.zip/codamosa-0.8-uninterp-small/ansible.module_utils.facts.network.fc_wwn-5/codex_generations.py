

# Generated at 2022-06-24 22:40:25.040146
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_2 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_3 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_4 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_5 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_6 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_7 = F

# Generated at 2022-06-24 22:40:28.854255
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Testing to see if constructor of FcWwnInitiatorFactCollector class works as expected")
    result = FcWwnInitiatorFactCollector()
    assert result
    print("Tests of constructor of FcWwnInitiatorFactCollector class completed successfully")


# Generated at 2022-06-24 22:40:36.552414
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  # Test for case 0
  fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
  try:
    fc_wwn_initiator_fact_collector_0.collect()
  except Exception:
    # Exception was thrown
    assert False
  else:
    # No exception was thrown
    assert True


# Generated at 2022-06-24 22:40:38.288139
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:40:40.356165
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:40:47.665352
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert(FcWwnInitiatorFactCollector.name == "fibre_channel_wwn")
    assert(FcWwnInitiatorFactCollector._fact_ids == set())
    assert(FcWwnInitiatorFactCollector._fact_ids.add("fibre_channel_wwn"))
    assert(FcWwnInitiatorFactCollector._fact_ids == set(["fibre_channel_wwn"]))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:40:49.887442
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except Exception as err:
        print("Failed: FcWwnInitiatorFactCollector()")

# Generated at 2022-06-24 22:40:58.109113
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock

    mock_module = mock.Mock()
    mock_module.run_command.return_value = (0, 'success', '')

    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.collect(module=mock_module) == {u'fibre_channel_wwn': []}

    fc_wwn_initiator_fact_collector_2 = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:06.012122
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    collected_facts = dict()
    result = fc_wwn_initiator_fact_collector_0.collect(collected_facts=collected_facts)
    assert result.get('fibre_channel_wwn') == []

    # add one item to the list
    fc_wwn_initiator_fact_collector_0._fact_ids.add('fibre_channel_wwn')
    collected_facts = dict()
    collected_facts['fibre_channel_wwn'] = ['10000090fa1658de']
    result = fc_wwn_initiator_fact_collector_0.collect(collected_facts=collected_facts)
   

# Generated at 2022-06-24 22:41:11.195094
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector_0.collect()
    assert result == {u'fibre_channel_wwn': []}, 'Failed to collect facts.'


# Generated at 2022-06-24 22:41:37.260980
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert (fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn')

# Generated at 2022-06-24 22:41:41.721977
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert (fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn')


# Generated at 2022-06-24 22:41:45.708511
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print('[Test for FcWwnInitiatorFactCollector object]')
    test_case_0()
    print('[Pass]')

# Run 'nosetests -v' to execute unit tests.
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:48.169864
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.fibre_channel_wwn is not None

# Generated at 2022-06-24 22:41:53.941370
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set([])

# Unit tests for method FcWwnInitiatorFactCollector.collect

# Generated at 2022-06-24 22:41:56.634569
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:42:00.576091
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # case 1:
    Fc = FcWwnInitiatorFactCollector()
    print(Fc.collect())

    # case 2:
    print(Fc.collect())

     # case 3:
    print(Fc.collect())

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:42:06.831924
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    collected_facts = {}
    collected_facts['ansible_facts'] = {}
    collected_facts['ansible_facts']['fibre_channel_wwn']= ["0x21000014ff52a9bb"]
    assert collected_facts == fc_wwn_initiator_fact_collector_0.collect(collected_facts)


# Generated at 2022-06-24 22:42:11.380259
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:42:13.380492
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:03.129474
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:43:08.891964
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    except Exception as e:
        print('Failed to instantiate class FcWwnInitiatorFactCollector')
        print(e)
        sys.exit(-1)
    else:
        print('Class FcWwnInitiatorFactCollector is instantiated')
        sys.exit(0)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:43:16.676107
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # following returns dictionary (module.run_command result)
    faked_module = FakeModule()
    # following returns list of 2 entries
    # ['fcs0', 'fcs1']
    expected_result = {'fibre_channel_wwn': ['10000090fa1658de', '10000090fa551509']}
    actual_result = fc_wwn_initiator_fact_collector.collect(module=faked_module)
    assert actual_result == expected_result


# Generated at 2022-06-24 22:43:19.619486
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:43:26.211472
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert str(fc_wwn_initiator_fact_collector) == "<FcWwnInitiatorFactCollector: fibre_channel_wwn>"

if __name__ == '__main__':
    print("Running test cases")
    print("===============")
    print("test_case_0: test constructor of class FcWwnInitiatorFactCollector")
    print("======================================================")
    print("FC WWN Initiator Facts Collector Collector Tests")
    test_case_0()
    test_FcWwnInitiatorFactCollector()
    print("")

# Generated at 2022-06-24 22:43:28.657882
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    print(fc_wwn_initiator_fact_collector.collect())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:43:35.953176
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create instance of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    # Check method collect of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:43:40.861310
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    print(fc_wwn_initiator_fact_collector_1.collect())


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:43:42.641478
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert not FcWwnInitiatorFactCollector._fact_ids



# Generated at 2022-06-24 22:43:49.648556
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector.collect()
    assert(type(result) == dict)
    assert(result == {})

# Generated at 2022-06-24 22:44:36.221931
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)
    assert True



# Generated at 2022-06-24 22:44:39.454061
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:44:40.269300
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:44:46.357228
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'fibre_channel_wwn' in var_0
    fibmax = len(var_0['fibre_channel_wwn'])
    # at least one WWN should be reported
    assert fibmax > 0
    if sys.platform == 'aix7':
        # on aix7 3 WWNs are available
        assert fibmax == 3

# Generated at 2022-06-24 22:44:47.869476
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    print(my_FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:44:53.813970
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == '__main__':
    # test_FcWwnInitiatorFactCollector()
    test_case_0()

# Generated at 2022-06-24 22:44:54.838424
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert callable(FcWwnInitiatorFactCollector.collect)


# Generated at 2022-06-24 22:44:59.962894
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:45:06.234834
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect(fc_wwn_initiator_fact_collector_1)
    assert 'fibre_channel_wwn' in var_1

# Generated at 2022-06-24 22:45:12.756446
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # mock the module argument spec for the collect function
    m_arg_spec = {'run_command': {'type': 'list', 'default': 'module.run_command', 'elements': 'str', 'version_added': None, 'required': True, 'aliases': []}, 'get_bin_path': {'type': 'str', 'default': 'module.get_bin_path', 'version_added': None, 'required': True, 'aliases': []}, '_ansible_module': {'type': 'dict', 'default': 'module._ansible_module', 'version_added': None, 'required': True, 'aliases': []}}
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator

# Generated at 2022-06-24 22:46:00.958658
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("\n\nRunning unit test(s) for method collect of class FcWwnInitiatorFactCollector")
    test_case_0()

# Generated at 2022-06-24 22:46:11.013367
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Tests instantiation with parameter
    # Tests that returned FcWwnInitiatorFactCollector object is not None
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 is not None

    # Tests that returned FcWwnInitiatorFactCollector object has attribute name
    assert hasattr(fc_wwn_initiator_fact_collector_0, "name")

    # Tests that returned FcWwnInitiatorFactCollector object has attribute _fact_ids
    assert hasattr(fc_wwn_initiator_fact_collector_0, "_fact_ids")

    # Tests that returned FcWwnInitiatorFactCollector object has method collect
    assert hasattr

# Generated at 2022-06-24 22:46:15.340288
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_1.priority == 30



# Generated at 2022-06-24 22:46:18.089794
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 22:46:23.854477
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_1.collect(fc_wwn_initiator_fact_collector_1)


# Generated at 2022-06-24 22:46:32.838980
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)
    fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:46:38.731486
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert(fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn')



# Generated at 2022-06-24 22:46:43.238033
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:46:46.979251
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)
    assert isinstance(var_0, dict)



# Generated at 2022-06-24 22:46:49.291193
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector


# Generated at 2022-06-24 22:48:24.300162
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)

# Generated at 2022-06-24 22:48:30.048292
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:48:37.629528
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0) == dict()

# Generated at 2022-06-24 22:48:41.289408
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_0.collect()

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:48:46.005559
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-24 22:48:47.441035
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector(FcWwnInitiatorFactCollector).name


# Generated at 2022-06-24 22:48:55.057513
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  assert glob.glob('/sys/class/fc_host/*/port_name')
  assert sys.platform.startswith('linux')
  assert sys.platform.startswith('sunos')
  assert sys.platform.startswith('aix')
  assert sys.platform.startswith('hp-ux')
  assert sys.platform.startswith('not_a_platform')
  assert not sys.platform.startswith('not_a_platform')
  assert sys.platform.startswith('not_a_platform')

# Generated at 2022-06-24 22:48:58.833321
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    global var_0
    assert var_0 == {'fibre_channel_wwn': ['0x21000014ff52a9bb', '0x21000014ff52a9bc']}

# Generated at 2022-06-24 22:49:04.227096
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_1 = var_0.collect()


# Generated at 2022-06-24 22:49:12.653698
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()
    assert repr(fc_wwn_initiator_fact_collector).startswith('<FcWwnInitiatorFactCollector()')
    assert repr(fc_wwn_initiator_fact_collector) == "<FcWwnInitiatorFactCollector()>"