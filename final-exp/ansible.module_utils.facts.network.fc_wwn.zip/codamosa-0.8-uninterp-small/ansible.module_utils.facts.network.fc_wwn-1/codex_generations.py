

# Generated at 2022-06-24 22:40:14.902489
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_wwn_initiator_fact_collector._fact_ids


# Generated at 2022-06-24 22:40:16.743197
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:40:20.277775
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()



# Generated at 2022-06-24 22:40:27.452099
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print ("Test for object FcWwnInitiatorFactCollector ",
            fc_wwn_initiator_fact_collector_0.__dict__)


# Generated at 2022-06-24 22:40:34.495839
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fcwwn_initiator_fact_collector_0.collect(module=None, collected_facts=None)
    fcwwn_initiator_fact_collector_0.name


# Generated at 2022-06-24 22:40:39.124997
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set([])


# Generated at 2022-06-24 22:40:40.808820
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:46.155217
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector() is not None


# Generated at 2022-06-24 22:40:51.067344
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Test Data
    test_data = {
        'fibre_channel_wwn': [
            '21000014ff52a9bb'
        ]
    }

    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.collect() == test_data

# Generated at 2022-06-24 22:40:56.385540
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_wwn_initiator_fact_collector.collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    assert isinstance(fc_facts['fibre_channel_wwn'][0], str)

# Generated at 2022-06-24 22:41:10.940231
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1 is not None, "Unit test for method collect of class FcWwnInitiatorFactCollector failed"

# Generated at 2022-06-24 22:41:13.046660
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert fc_wwn_initiator_fact_collector_0.name == FcWwnInitiatorFactCollector.name

# Generated at 2022-06-24 22:41:16.185237
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:41:17.553675
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert FcWwnInitiatorFactCollector().collect() == {}


# Generated at 2022-06-24 22:41:22.256861
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert '_fact_ids' in dir(FcWwnInitiatorFactCollector)
    assert '_platform' in dir(FcWwnInitiatorFactCollector)
    assert '_platforms' in dir(FcWwnInitiatorFactCollector)
    assert 'collect' in dir(FcWwnInitiatorFactCollector)
    assert 'name' in dir(FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:41:25.853686
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    module = None
    collected_facts = None
    fc_wwn_initiator_fact_collector.collect(module, collected_facts)

# Generated at 2022-06-24 22:41:32.178197
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:41:36.115257
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    if not isinstance(a,FcWwnInitiatorFactCollector):
        raise AssertionError('Instance is not of type FcWwnInitiatorFactCollector')

# Generated at 2022-06-24 22:41:41.310239
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    fc_wwn_initiator_fact_collector_1.collect()

# Generated at 2022-06-24 22:41:42.716849
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector, object)

# Generated at 2022-06-24 22:41:57.315746
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    for element in var_0:
        print("variable element = {0!r}".format(element))


# Generated at 2022-06-24 22:42:00.715329
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:42:09.862496
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO: We must write additional tests for class FcWwnInitiatorFactCollector.
    pass

if __name__ == '__main__':
    import os
    import pytest

    from ansible.module_utils.facts import Collector

    # TODO: Improve this test.
    def test_collector(fq_name, collected_facts=None):
        module_path = os.path.dirname(os.path.abspath(__file__))
        test_data = os.path.join(module_path, 'test.yml')
        facts_under_test = Collector.load_collectors_from_yaml(test_data)
        return facts_under_test[fq_name].collect(collected_facts=collected_facts)


# Generated at 2022-06-24 22:42:15.410031
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)

if __name__ == '__main__':
    try:
        test_FcWwnInitiatorFactCollector()
        test_case_0()
    except Exception as e:
        print('Caught exception: ' + repr(e))
        exit(1)
    else:
        exit(0)

# Generated at 2022-06-24 22:42:21.704350
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == "fibre_channel_wwn"
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 22:42:24.862521
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:42:25.793203
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

#

# Generated at 2022-06-24 22:42:28.515457
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:42:34.593353
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector, FcWwnInitiatorFactCollector)
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:42:39.152345
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:43:01.007985
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    var_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:02.211509
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:04.732460
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:43:15.182752
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fixture_data = {
        # Test case 0
        'empty': {
            'result_facts': {
                'fibre_channel_wwn': []
            },
            'result_facts_empty': {
            }
        }
    }

    for test_case, test_data in fixture_data.items():
        for key in test_data.keys():
            if key.startswith('result_'):
                fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
                assert test_data[key] == fc_wwn_initiator_fact_collector.collect()
                break


# Generated at 2022-06-24 22:43:19.377129
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_result_dict = fc_wwn_initiator_fact_collector.collect()
    assert fc_wwn_initiator_fact_collector_result_dict is not None

# Generated at 2022-06-24 22:43:22.427619
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # check for dictionary
    assert isinstance(FcWwnInitiatorFactCollector().collect(), (dict))
    # check for correct values
    assert FcWwnInitiatorFactCollector().collect()['fibre_channel_wwn'] == []

# Generated at 2022-06-24 22:43:28.588996
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 22:43:32.973731
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:37.714933
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:43:39.593815
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert isinstance(x._fact_ids, set)


# Generated at 2022-06-24 22:44:29.144362
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': ['21000014ff52a9bb'], 'fibre_channel_wwn_initiator': ['21000014ff52a9bb']}



# Generated at 2022-06-24 22:44:34.233352
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var = FcWwnInitiatorFactCollector()
    # var.collect
    pass


# Generated at 2022-06-24 22:44:39.874322
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  try:
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # unit test for collect method
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
  except Exception as e:
    print(str(e))
    assert(False)


# Generated at 2022-06-24 22:44:41.439864
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:44:46.115773
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:44:51.132376
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

import sys
#from ansible.module_utils.facts import collector
if __name__ == '__main__':
    #test_FcWwnInitiatorFactCollector()
    test_case_0()

# Generated at 2022-06-24 22:44:53.356387
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except Exception as err:
        print("\tFAIL: FcWwnInitiatorFactCollector(): An exception is raised.")
        print("\tException is: %s" % err)


test_case_0()
test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:44:56.473478
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:45:05.761891
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    # Testing correct instantiation
    try:
        fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    except Exception:
        assert False

    # Testing incorrect instantiation
    try:
        fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector(missing='missing')
        assert False
    except TypeError:
        assert True

    # Testing with no parameters
    try:
        fc_wwn_initiator_fact_collector_2 = FcWwnInitiatorFactCollector.__new__(FcWwnInitiatorFactCollector)
    except Exception:
        assert False

    # Testing with arbtrary parameters

# Generated at 2022-06-24 22:45:11.497646
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

    var_0 = {}
    var_0['ansible_facts'] = {}
    var_0['ansible_facts']['fibre_channel_wwn'] = []

    with pytest.raises(AnsibleUndefinedVariable):
        fc_wwn_initiator_fact_collector_1.collect()

    assert fc_wwn_initiator_fact_collector_1.collect(module=None, collected_facts=None) == var_0

# Generated at 2022-06-24 22:46:42.125858
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # call constructor
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    # parse the arguments
    print(str(fc_wwn_initiator_fact_collector_0.name))
    assert _collector_module_name == fc_wwn_initiator_fact_collector_0.name
    assert _fact_ids == fc_wwn_initiator_fact_collector_0._fact_ids


# Generated at 2022-06-24 22:46:46.863115
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()
    var_1.pop('ansible_facts', None)
    assert var_1 == {'fibre_channel_wwn': []}


# Generated at 2022-06-24 22:46:52.059125
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.name
    assert var_1 == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:46:57.915077
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print("Testing test_FcWwnInitiatorFactCollector_collect")
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0['fibre_channel_wwn'] == "0x21000014ff52a9bb"


# Generated at 2022-06-24 22:47:02.720567
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Instantiation
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

    # Call method collect
    fc_wwn_initiator_fact_collector_1.collect()


# Generated at 2022-06-24 22:47:04.159787
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fact_collector_0.collect() == {}



# Generated at 2022-06-24 22:47:14.681309
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Test method name of class FcWwnInitiatorFactCollector
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

    # Test attribute name of class FcWwnInitiatorFactCollector
    try:
        assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    except AssertionError as e:
        print("Check if attribute _fact_ids of class FcWwnInitiatorFactCollector could be read.")
        raise(e)

    # Test method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:47:18.645691
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    if not sys.platform.startswith('linux'):
        return
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    module = AnsibleModule()
    var_1 = fc_wwn_initiator_fact_collector_1.collect(module=module)


# Generated at 2022-06-24 22:47:20.716990
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()



# Generated at 2022-06-24 22:47:25.469366
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_instance = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector_instance.collect()

if __name__ == '__main__':
    test_case_0()