

# Generated at 2022-06-24 22:40:18.985088
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == '__main__' and __package__ is None:
    import sys
    import pytest
    sys.path.insert(0, '.')
    pytest.main([__file__])

# Generated at 2022-06-24 22:40:26.147716
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_fact = fc_wwn_initiator_fact_collector_0.collect()
    assert 'fibre_channel_wwn' in fc_fact


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:40:31.928490
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector.collect()

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:36.921681
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except:
        import traceback
        print(traceback.print_exc())
        raise

# Generated at 2022-06-24 22:40:37.749911
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:40:44.712364
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.__doc__ is not None
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.collect.__doc__ is not None
    try:
        assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)
    except:
        assert False


# Generated at 2022-06-24 22:40:45.831859
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:40:48.474898
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector is not None

# Generated at 2022-06-24 22:40:52.176481
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect(None) == {
        'fibre_channel_wwn': []
    }


# Generated at 2022-06-24 22:40:55.258814
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert fc_wwn_initiator_fact_collector_0
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:41:16.328882
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect(fc_wwn_initiator_fact_collector_1)
    print (var_1['fibre_channel_wwn'])
    assert var_1['fibre_channel_wwn'] is not None
    assert var_1['fibre_channel_wwn'] is not ''
    assert len(var_1['fibre_channel_wwn']) != 0
    assert isinstance(var_1['fibre_channel_wwn'], list)

test_case_0()
test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:41:20.734411
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fixture_0 = test_case_0
    expected_0 = {
        'fibre_channel_wwn': ['21000014ff52a9bb', '21000014ff52a9c6', '21000014ff52a9d2']
    }
    var_1 = fixture_0()
    assert var_1 == expected_0


# Generated at 2022-06-24 22:41:27.652477
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Arrange and act:
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)

    # Assert:
    assert(var_0 == {'fibre_channel_wwn': []})

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()
    sys.exit(0)

# Generated at 2022-06-24 22:41:30.704470
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)

# Generated at 2022-06-24 22:41:33.534590
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print('\n'+'# Test constructor of class FcWwnInitiatorFactCollector')
    try:
        test_case_0()
    except:
        print('Expected exception')



# Generated at 2022-06-24 22:41:40.891201
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    try:
        var_1 = fc_wwn_initiator_fact_collector_1.collect(fc_wwn_initiator_fact_collector_1)
    except SystemExit as exception:
        print(exception)
        assert False
    except Exception as exception:
        print(exception)
        assert False


# Generated at 2022-06-24 22:41:47.722659
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  try:
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)
  except:
    print("Exception in test_FcWwnInitiatorFactCollector_collect")
    import sys
    import traceback
    print('-' * 60)
    traceback.print_exc(file=sys.stdout)
    print('-' * 60)
    raise


# Generated at 2022-06-24 22:41:50.259082
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # setup
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    # verify
    assert isinstance(fc_wwn_initiator_fact_collector, FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:41:50.812600
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_case_0()


# Generated at 2022-06-24 22:41:53.930232
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:42:21.918882
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    path = 'ansible.module_utils.facts.hardware.fibre_channel.fibre_channel_wwn'
    with mock.patch(path) as mock_FcWwnInitiatorFactCollector:
        mock_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
        mock_FcWwnInitiatorFactCollector.collect()


# Generated at 2022-06-24 22:42:26.639137
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    output = "random"
    fc_wwn_initiator_fact_collector.collect(module, output)


# Generated at 2022-06-24 22:42:27.539019
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()


# Generated at 2022-06-24 22:42:29.070795
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert callable(FcWwnInitiatorFactCollector.collect)


# Generated at 2022-06-24 22:42:34.082109
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1.collect(fc_wwn_initiator_fact_collector_1)


# Generated at 2022-06-24 22:42:38.698574
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert type(fc_wwn_initiator_fact_collector._fact_ids) == type(set())



# Generated at 2022-06-24 22:42:41.508725
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        assert issubclass(FcWwnInitiatorFactCollector, BaseFactCollector)
    except AssertionError as e:
        print(e)



# Generated at 2022-06-24 22:42:47.178879
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Make sure that collect raises an exception if fc_wwn_initiator_fact_collector is None.
    with pytest.raises(AttributeError):
        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
        fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:42:51.340282
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name is not None
    assert FcWwnInitiatorFactCollector._fact_ids is not None
    assert FcWwnInitiatorFactCollector.collect is not None

# Generated at 2022-06-24 22:42:54.019423
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:38.474608
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:43:40.869275
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()


# Generated at 2022-06-24 22:43:45.748209
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except:
        raise AssertionError("An exception occurred in the constructor of the \
        class FcWwnInitiatorFactCollector")


# Generated at 2022-06-24 22:43:47.858345
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:43:48.840450
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Generated at 2022-06-24 22:43:55.414818
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fixture_0 = type('', (), {})()
    fixture_0.name = 'fibre_channel_wwn'

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:44:04.860862
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print()
    print('test_constructor_FcWwnInitiatorFactCollector()')
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print('var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)')
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:44:10.974144
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # First instantiate the class
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

    # test case for successful completion of the collect method
    job_input = {'input_job_var': 'TestData'}
    #if fc_wwn_initiator_fact_collector_1.collect(fc_wwn_initiator_fact_collector_1, ansible_module):
    #    return 1



# Generated at 2022-06-24 22:44:13.758565
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None

# Generated at 2022-06-24 22:44:15.569471
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()



# Generated at 2022-06-24 22:45:49.788745
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1 is not None
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_1._fact_ids == set()


# Generated at 2022-06-24 22:45:57.056163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_1 = FcWwnInitiatorFactCollector()
    var_2 = var_1.collect(var_1)
    assert (var_2['fibre_channel_wwn'][0] == "210F0014FF000000")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:46:02.083814
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()



# Generated at 2022-06-24 22:46:07.962494
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        pass
    elif sys.platform.startswith('sunos'):
        pass
    elif sys.platform.startswith('aix'):
        pass
    elif sys.platform.startswith('hp-ux'):
        pass
    return var_0

# Generated at 2022-06-24 22:46:11.661591
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:46:15.258506
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)


# Generated at 2022-06-24 22:46:16.071233
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    raise NotImplemented()


# Generated at 2022-06-24 22:46:24.408339
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)
    var_1 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)
    var_2 = fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)

# Generated at 2022-06-24 22:46:27.332680
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass


# Generated at 2022-06-24 22:46:29.706524
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:49:43.732075
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:49:47.857486
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect(fc_wwn_initiator_fact_collector_0)


# Generated at 2022-06-24 22:49:51.702589
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:49:55.903519
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect(fc_wwn_initiator_fact_collector_1)