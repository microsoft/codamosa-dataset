

# Generated at 2022-06-24 22:40:22.528352
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Unit test for method collect of class FcWwnInitiatorFactCollector
    # For collect method to function, the return value of method collect of class FcWwnInitiatorFactCollector
    # must be a dictionary
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    ansible_facts = fc_wwn_initiator_fact_collector_1.collect()
    assert isinstance(ansible_facts, dict)


# Generated at 2022-06-24 22:40:25.291234
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    print(fc_wwn_initiator_fact_collector.name)
    print(fc_wwn_initiator_fact_collector.fact_ids)
    print(fc_wwn_initiator_fact_collector._fact_ids)

# Generated at 2022-06-24 22:40:37.134145
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # run collection
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    facts = fc_wwn_initiator_fact_collector_0.collect()
    # test returned facts - look for presence of:
    # fibre_channel_wwn / fibre_channel_wwn_0 / fibre_channel_wwn_1
    i = 0
    for fact in facts['fibre_channel_wwn']:
        fact_name = 'fibre_channel_wwn_' + str(i)
        if fact_name in facts.keys():
            i += 1
        else:
            break
    if i:
        return 0
    else:
        return 1

if __name__ == '__main__':
    test_case_0

# Generated at 2022-06-24 22:40:45.524385
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_0.collect()
    #assert fc_wwn_initiator_fact_collector_0.fc_facts['fibre_channel_wwn'] is not None, 'fc_wwn_initiator_fact_collector_0.fc_facts[\'fibre_channel_wwn\'] should not be None!'


# Generated at 2022-06-24 22:40:50.068495
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    result0 = fc_wwn_initiator_fact_collector_0.collect()
    print("\nresult0=" + str(result0))


# Generated at 2022-06-24 22:40:54.547750
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print('Test case 0')
    fc_facts_0 = FcWwnInitiatorFactCollector().collect()
    print(fc_facts_0)


if __name__ == '__main__':
    print('Testing')
    print('=======')
    print('Unit tests')
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:40:57.973555
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0 != None

# Unit test of method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:41:01.818130
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_1.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_1.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:41:03.196063
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:41:04.441578
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()


# Unit test to run collect

# Generated at 2022-06-24 22:41:33.245209
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:41:39.725806
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    This tests test_FcWwnInitiatorFactCollector.
    """
    # try with exception
    try:
        fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
        fc_wwn_initiator_fact_collector.collect()
    except Exception:
        assert False, "Exception: error occurred while collecting facts."

# Generated at 2022-06-24 22:41:46.603170
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Initialize the fc_wwn_initiator_fact_collector_0
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Call the collect method of class fc_wwn_initiator_fact_collector_0
    fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:41:55.538149
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert len(fc_wwn_initiator_fact_collector_1._fact_ids) == 1
    assert 'fibre_channel_wwn' in fc_wwn_initiator_fact_collector_1._fact_ids

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:57.877036
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Testing execute of method collect. This method is not directly tested.
    pass



# Generated at 2022-06-24 22:42:03.256356
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector is not None
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:42:07.498257
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:42:13.914415
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert  'fibre_channel_wwn' in fc_wwn_initiator_fact_collector._fact_ids
    assert  'fibre_channel_wwn' == fc_wwn_initiator_fact_collector.name
    return

# Generated at 2022-06-24 22:42:16.181720
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts = FcWwnInitiatorFactCollector().collect()
    assert len(facts.get('fibre_channel_wwn', [])) > 0

# Generated at 2022-06-24 22:42:21.918965
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    # Test case 1: no kernel path
    fc_wwn_initiator_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-24 22:43:11.401952
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0.priority == 6

# Generated at 2022-06-24 22:43:16.750728
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert type(fc_wwn_initiator_fact_collector_1) == FcWwnInitiatorFactCollector
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-24 22:43:23.131465
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {
        'fibre_channel_wwn': [
            '21000014ff52a9bb',
            '21000014ff52a9bc',
            '21000014ff52a9bd',
            '21000014ff52a9be',
            '21000014ff52a9bf',
            '21000014ff52a9c0',
            '21000014ff52a9c1',
            '21000014ff52a9c2',
            '21000014ff52a9c3'
        ]
    }

# Generated at 2022-06-24 22:43:28.416956
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    collected_facts={}
    fc_wwn_initiator_fact_collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-24 22:43:33.600104
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    return fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:43:38.473247
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert(fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn')

# Generated at 2022-06-24 22:43:41.730402
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # Test for equality with a known result.
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    # Test for equality with a known result.
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:43:51.645504
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    if isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector):
        print('Test passed : (fc_wwn_initiator_fact_collector_0 is an instance of FcWwnInitiatorFactCollector)')
    else:
        print('Test failed : (fc_wwn_initiator_fact_collector_0 is not an instance of FcWwnInitiatorFactCollector)')


# Generated at 2022-06-24 22:44:02.373478
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    module_0 = AnsibleModule(
        argument_spec={
        },
        supports_check_mode=True,
    )

    if not HAS_PARAMIKO:
        module_0.fail_json(msg='paramiko is required but does not appear to be installed')

    if not HAS_FCS:
        module_0.fail_json(msg='fcs is required but does not appear to be installed')

    fc_facts = fc_wwn_initiator_fact_collector_0.collect(module_0)
    pprint(fc_facts)

if __name__ == '__main__':
    test_case_0()
    test_FcWwnInitiator

# Generated at 2022-06-24 22:44:10.406974
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_facts_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert isinstance(fc_wwn_initiator_facts_0, dict)
    assert 'fibre_channel_wwn' in fc_wwn_initiator_facts_0
    assert fc_wwn_initiator_facts_0['fibre_channel_wwn'] == []

# Generated at 2022-06-24 22:45:01.292266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = 0
    var_1 = '[{"fibre_channel_wwn": ["21000014ff52a9bb"]}]'
    var_0 = FcWwnInitiatorFactCollector().collect()
    assert var_0 == var_1

# Generated at 2022-06-24 22:45:06.034358
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert(fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn')


# Generated at 2022-06-24 22:45:09.733341
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:45:13.436004
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:45:18.231964
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    instance = FcWwnInitiatorFactCollector()
    if instance:
        print("Instance of FcWwnInitiatorFactCollector successfully created")


# Generated at 2022-06-24 22:45:23.870635
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_result = fc_wwn_initiator_fact_collector.collect()
    assert isinstance(fc_wwn_initiator_fact_collector_result['fibre_channel_wwn'], list)

# Generated at 2022-06-24 22:45:33.066960
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': ['21000014ff52a9bb']}
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'


# Generated at 2022-06-24 22:45:38.439413
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == fc_wwn_initiator_fact_collector_1.name



# Generated at 2022-06-24 22:45:46.843632
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    arg_count = 2
    args = sys.argv[1:]
    if len(args) != arg_count:
        raise AssertionError("Expected argument count: %d, actual argument count: %d" % (arg_count, len(args)))
    test_case_to_run = args[0]
    test_case_arg = int(args[1])
    if test_case_to_run == 'test_case_0':
        test_case_0(test_case_arg)
    else:
        raise AssertionError("Unrecognized test case: %s" % test_case_to_run)


# Generated at 2022-06-24 22:45:49.023034
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()


# Generated at 2022-06-24 22:47:23.836077
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:47:28.947988
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 is not None and var_1 is not False


# Generated at 2022-06-24 22:47:31.603929
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:47:34.888800
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()



# Generated at 2022-06-24 22:47:38.294770
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()


# Generated at 2022-06-24 22:47:45.142533
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_0.collect()
    assert len(var_1) == 1
    assert 'fibre_channel_wwn' in var_1
    assert var_1['fibre_channel_wwn'] == []

test_case_0()

# Generated at 2022-06-24 22:47:47.405169
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:47:48.072019
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass



# Generated at 2022-06-24 22:47:50.016115
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name() == 'fibre_channel_wwn'



# Generated at 2022-06-24 22:47:58.465032
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # fixture
    fact_collector_fixture = FcWwnInitiatorFactCollector()

    # fixture - mock module
    module_mock = Mock(return_value=MagicMock())

    # fixture - mock command
    command_mock = Mock(return_value=MagicMock())

    # Test for method collect of class FcWwnInitiatorFactCollector
    result = fact_collector_fixture.collect(module=module_mock, collected_facts=None)

    # Assert the result
    assert result == {}