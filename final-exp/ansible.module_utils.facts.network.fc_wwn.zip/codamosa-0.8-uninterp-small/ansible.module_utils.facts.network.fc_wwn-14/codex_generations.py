

# Generated at 2022-06-24 22:40:14.267527
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:40:15.662550
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:40:21.218802
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    print("fc_wwn_initiator_fact_collector_0: " + str(fc_wwn_initiator_fact_collector_0))
    print("fc_wwn_initiator_fact_collector_0.name: " + str(fc_wwn_initiator_fact_collector_0.name))
    # assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:40:27.279450
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_1, FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:40:36.644283
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)
    result = fc_wwn_initiator_fact_collector_0.collect()
    assert result is not None
    assert len(result) == 1
    # Test for keys not being empty
    for key in result.keys():
        assert len(key) > 0

# Generated at 2022-06-24 22:40:44.968432
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)

    """
    print(json.dumps(fc_wwn_initiator_fact_collector_0.collect(), indent=4))
    {"fibre_channel_wwn": ["21000024ff3d32f2"]}
    """


# Generated at 2022-06-24 22:40:48.058911
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector

# Unit test to check if the fibe_channnel_wwn facts has been collected

# Generated at 2022-06-24 22:40:50.810534
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert (FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn')

# Unit test to verify return value for collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-24 22:40:57.043918
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector_0.collect()
    assert result != None


# Generated at 2022-06-24 22:40:59.838994
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0.collect(), dict)

# Generated at 2022-06-24 22:41:14.537026
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.collect() is None

# Generated at 2022-06-24 22:41:16.393697
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Calling constructor of class FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()


# Generated at 2022-06-24 22:41:17.730519
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_case_0()

# Unit test function facts_get()

# Generated at 2022-06-24 22:41:20.334670
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()

# Generated at 2022-06-24 22:41:23.277993
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

if __name__ == "__main__":
    if sys.platform.startswith('linux'):
        test_case_0()
        test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:41:26.255761
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert (var_0 == {'fibre_channel_wwn': []})


# Generated at 2022-06-24 22:41:31.928137
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)


# Generated at 2022-06-24 22:41:34.047575
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass


if __name__ == '__main__':
    import sys
    sys.exit(1)
    test_case_0()

# Generated at 2022-06-24 22:41:45.283519
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    var_1 = fc_wwn_initiator_fact_collector_0.name
    assert var_1 == 'fibre_channel_wwn'
    if sys.platform.startswith('sunos'):
        assert var_0 == dict(fibre_channel_wwn=['10000090fa1658de'])
    elif sys.platform.startswith('linux'):
        assert var_0 == {'fibre_channel_wwn': []}

# Generated at 2022-06-24 22:41:48.073950
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert isinstance(fc_wwn_initiator_fact_collector_0, FcWwnInitiatorFactCollector)



# Generated at 2022-06-24 22:42:17.847808
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    # var_0 is an instance of type FcWwnInitiatorFactCollector
    var_0 = FcWwnInitiatorFactCollector()
    assert isinstance(var_0, FcWwnInitiatorFactCollector)
    # constructor accepts two parameters
    var_1 = FcWwnInitiatorFactCollector(None, None)


# Generated at 2022-06-24 22:42:21.447149
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Normal case when class FcWwnInitiatorFactCollector is created
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector is not None


# Generated at 2022-06-24 22:42:27.579692
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    _fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    _var_0 = _fc_wwn_initiator_fact_collector_0.collect()
    assert _var_0['fibre_channel_wwn'] == _var_0['fibre_channel_wwn']

test_case_0()

# Generated at 2022-06-24 22:42:33.178455
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector_0.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_0._fact_ids == set()


# Generated at 2022-06-24 22:42:35.234161
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    var_1 = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:40.300386
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector.collect()
    assert var is None
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-24 22:42:46.320196
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    if (str(type(fc_wwn_initiator_fact_collector_0)) == "<class 'ansible.module_utils.facts.hardware.fibre_channel_wwn.FcWwnInitiatorFactCollector'>"):
        print("Test 0 - Successful")

if __name__ == "__main__":
    test_case_0()
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:42:51.253599
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-24 22:42:56.326286
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert len(var_0) == 1
    assert isinstance(var_0['fibre_channel_wwn'], list)


# Generated at 2022-06-24 22:43:01.333963
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:43:52.855385
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    print(var_0)


# Generated at 2022-06-24 22:43:55.846736
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        test_case_0()
    except Exception as msg:
        print("Test case 0 FAILED: {0}".format(msg))
        raise Exception("Test case 0 FAILED: {0}".format(msg))


# Generated at 2022-06-24 22:43:56.557528
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-24 22:44:01.029850
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    try:
        FcWwnInitiatorFactCollector()
    except Exception:
        assert False, "Unable to instantiate FcWwnInitiatorFactCollector"
    assert True


# Generated at 2022-06-24 22:44:03.332867
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-24 22:44:09.140327
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    assert type(fc_wwn_initiator_fact_collector_1) == FcWwnInitiatorFactCollector


# Generated at 2022-06-24 22:44:11.383183
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 22:44:13.782240
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    var_0 = FcWwnInitiatorFactCollector()
    var_1 = var_0.collect()
    assert var_1 == {'fibre_channel_wwn': []}


# Generated at 2022-06-24 22:44:21.291960
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_instance = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector_instance
    assert fc_wwn_initiator_fact_collector_instance.__dict__ == {'_fact_ids': set(),
                                                   'name': 'fibre_channel_wwn'}

# Unit tests for method collect of class FcWwnInitiatorFactCollector
# @pytest.mark.skipif(sys.platform.startswith('aix'), reason="Skipping this test for aix for now")
# def test_collect_0(fc_wwn_initiator_fact_collector_0):
#     assert fc_wwn_initiator_fact_collector_0

# Generated at 2022-06-24 22:44:29.095894
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()
    var_1 = fc_wwn_initiator_fact_collector_1.collect()
    assert var_1 == {'fibre_channel_wwn': ["1000001e07179d5f", "10000005e8ff5c25"]}


# Generated at 2022-06-24 22:46:12.046316
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    # No input
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert len(var_0) == 1
    assert var_0['fibre_channel_wwn'] is not None
    assert type(var_0['fibre_channel_wwn']) is list


# Generated at 2022-06-24 22:46:15.612943
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == 'fibre_channel_wwn'
    assert not fcwwnfc._fact_ids

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:46:23.255600
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    FcWwnInitiatorFactCollector_instance = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector_instance.collect() == {'fibre_channel_wwn': []}, \
    'FcWwnInitiatorFactCollector.collect() returned {}'.format(FcWwnInitiatorFactCollector_instance.collect())

# Generated at 2022-06-24 22:46:32.383927
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # unit test for method collect of class FcWwnInitiatorFactCollector
    # informations on the generated tests
    print('Starting test collect')
    print('Testing class FcWwnInitiatorFactCollector')
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()
    assert var_0 == {'fibre_channel_wwn': []}



# Generated at 2022-06-24 22:46:33.398007
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert (test_case_0() == None)

# Generated at 2022-06-24 22:46:37.311192
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj != None


# Generated at 2022-06-24 22:46:40.492708
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector_0 = FcWwnInitiatorFactCollector()
    var_0 = fc_wwn_initiator_fact_collector_0.collect()



# Generated at 2022-06-24 22:46:43.197110
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    var = fc_wwn_initiator_fact_collector.collect()


# Generated at 2022-06-24 22:46:45.202956
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector_1 = FcWwnInitiatorFactCollector()

# Generated at 2022-06-24 22:46:46.252279
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_case_0()

if __name__ == '__main__':
    test_case_0()