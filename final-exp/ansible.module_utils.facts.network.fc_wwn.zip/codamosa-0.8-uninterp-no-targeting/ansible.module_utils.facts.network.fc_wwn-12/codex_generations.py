

# Generated at 2022-06-20 17:59:37.676431
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector"""

    # module case
    class MyModule(object):
        """A fake module."""
        def __init__(self):
            """Initialization."""
            self.params = {}

        def get_bin_path(self, coomand, opt_dirs=[]):
            """Returns a path to a command."""
            return "/bin/ls"

        def run_command(self, command):
            """Dummy command execution."""
            return (0, "a\nb\nc\n", "")

    module = MyModule()
    fc = FcWwnInitiatorFactCollector(module)
    expected_fc_facts = {"fibre_channel_wwn": ['a', 'b', 'c']}
    fc

# Generated at 2022-06-20 17:59:40.780604
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 17:59:48.062467
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    fc_collector = FcWwnInitiatorFactCollector()
    
    # test empty case (no valid platform)
    fc_facts = fc_collector.collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert len(fc_facts['fibre_channel_wwn']) == 0

    


# Generated at 2022-06-20 17:59:50.508284
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    assert type(result) == dict
    assert 'fibre_channel_wwn' in result

# Generated at 2022-06-20 17:59:53.862318
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:55.904518
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcp = FcWwnInitiatorFactCollector()
    assert fcp.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:04.340032
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mock_module = type('module', (), {'get_bin_path': lambda self, name, opt_dirs=[]: '/bin/' + name})()

# Generated at 2022-06-20 18:00:07.830401
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_obj = FcWwnInitiatorFactCollector()
    assert fc_wwn_obj.name == 'fibre_channel_wwn'
    assert fc_wwn_obj.priority == 6


# Generated at 2022-06-20 18:00:19.945220
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # initialize environment
    module = AnsibleModuleMock()
    # create instance of class FcWwnInitiatorFactCollector
    fc_collector = FcWwnInitiatorFactCollector(module=module)
    # test method collect
    fc_collector.collect()
    # check returned facts
    assert 'fibre_channel_wwn' in fc_collector.collect()
    # check if we have the correct number of wwns
    assert len(fc_collector.collect()['fibre_channel_wwn']) == 6
    # check if we got the correct wwpn
    assert '50060b00006975ec' in fc_collector.collect()['fibre_channel_wwn']
    assert '21000014ff52a9bb' in fc_collector

# Generated at 2022-06-20 18:00:30.879180
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector"""

    import os
    import sys
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a module util mock object
    collected_facts = Collector()
    module = BaseFactCollector()
    module.exit_json = lambda x: True
    module.fail_json = lambda x: True
    module.get_bin_path = lambda x, opt_dirs: x

    # create some test files
    sys.platform='linux'
    os.mkdir(tmpdir + "/sys/class/fc_host/host0/")

# Generated at 2022-06-20 18:00:57.433779
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:01:05.847151
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class InitModule(object):

        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=[]):
            """
            name    command name
            opt_dirs optional list of directories to search
            """
            if self.bin_path:
                return self.bin_path

            if opt_dirs:
                for path in opt_dirs:
                    cmd = self._search_bin(name, path)
                    if cmd:
                        return cmd

            return self._search_bin(name)

        def _search_bin(self, name, path=''):
            """
            search a given path for a command and return the command path
            name    command name
            path    path to search for command
            """

# Generated at 2022-06-20 18:01:10.459049
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Declaring FcWwnInitiatorFactCollector object
    fcwwn_inst = FcWwnInitiatorFactCollector()

    # Calling collect method of FcWwnInitiatorFactCollector
    fcwwn_inst.collect()

# Generated at 2022-06-20 18:01:15.385587
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:01:20.805688
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # example of FcWwnInitiatorFactCollector object
    fc_wwn_initiator_obj = FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:01:27.699092
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.collectors.system.fibre_channel_wwn_initiator as fibre_channel_wwn_initiator

    tmp_collector = Collector()
    test_obj = fibre_channel_wwn_initiator.FcWwnInitiatorFactCollector(tmp_collector)

    assert 'fibre_channel_wwn' in test_obj.collect()

# Generated at 2022-06-20 18:01:39.305327
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import LazyFactsCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.facts import FactManager
    from ansible.module_utils.facts.utils import get_file_lines
    import sys
    import glob

    class TestAnsibleModule():
        def __init__(self):
            self.run_command_called = False

        def run_command(self, cmd):
            self.run_command_called = True

# Generated at 2022-06-20 18:01:41.456707
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fc = FcWwnInitiatorFactCollector()
    assert fc_fc.name == 'fibre_channel_wwn'
    assert bool(fc_fc._fact_ids) is False

# Generated at 2022-06-20 18:01:51.696690
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    When /sys/class/fc_host/host*/port_name exists
    """
    # if we're on linux - run this test
    if sys.platform.startswith('linux'):
        # mock module
        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True)
        module.run_command = MagicMock(return_value=(0, '', ''))
        module.get_bin_path = MagicMock(return_value=None)
        module.get_file_lines = MagicMock(return_value=['0x21000014ff52a9bb','0x21000014ff52a9cc'])
        # create instance of class FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:01:57.109613
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()

    assert(facts['fibre_channel_wwn'] == [])

# Generated at 2022-06-20 18:02:27.503883
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcWwnInitiatorFactCollector.collect()
    """
    fcwwn = FcWwnInitiatorFactCollector({})
    ans_list = fcwwn.collect()
    assert ans_list == {'fibre_channel_wwn': ['21000014ff52a9bb',
                                              '50060b00006975ec']}

# Generated at 2022-06-20 18:02:28.857627
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:02:40.160902
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.run_command = AnsibleRunCommandMock
    module.get_bin_path = AnsibleGetBinPathMock
    module.params = {}
    facts_collector = FcWwnInitiatorFactCollector()
    facts_collector.collect(module=module)
    facts = facts_collector.get_facts()
    # assert if our mock gives same results as actual output on a real system
    # this requires root access for a successful execution
    assert facts['fibre_channel_wwn'] == [u'5005076802031f7c']



# Generated at 2022-06-20 18:02:46.765185
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector.
    """
    import ansible.module_utils.facts.collector.fibre_channel_wwn as collector
    c = collector.FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:48.921676
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.__class__.__name__ == 'FcWwnInitiatorFactCollector'


# Generated at 2022-06-20 18:03:02.233163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Mocking methods used in the code
    class MockModule(object):
        def __init__(self):
            self.FAKE_RC = 0
            self.FAKE_ERROR = "mocked error"
            self.FAKE_STDOUT = "mocked standard output"
            self.FAKE_BIN_PATH = "fake/path"
            self.FAKE_FCINFO_OUT = 'HBA Port WWN: 10000090fa1658de'
            self.FAKE_FILE_LINES = [
                '0x21000014ff52a9bb',
                '0x21000014ff52a9bc',
            ]

        def get_bin_path(self, executable, opt_dirs=None):
            return self.FAKE_BIN_PATH

        def run_command(self, cmd):
            return

# Generated at 2022-06-20 18:03:06.361682
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mc = FcWwnInitiatorFactCollector()
    facts_dict = mc.collect()
    assert facts_dict == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-20 18:03:09.789922
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert fc_facts
    assert 'fibre_channel_wwn' in fc_facts
    assert fc_facts['fibre_channel_wwn']

# Generated at 2022-06-20 18:03:21.253201
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    # Add WWN
    fc_facts['fibre_channel_wwn'].append('2100001B32B28180')
    fc_facts['fibre_channel_wwn'].append('2100001B32B28181')

    # Test if the collect method is able to collect our data back
    fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = fact_collector.collect(None, fc_facts)
    # check if fibre_channel_wwn is present, it should be
    assert 'fibre_channel_wwn' in collected_facts
    # check if the size of the list is 2, it should be

# Generated at 2022-06-20 18:03:25.664723
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_collect = FcWwnInitiatorFactCollector().collect
    dict_res = FcWwnInitiatorFactCollector_collect()
    assert dict_res == {}

# Generated at 2022-06-20 18:04:11.281655
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    os.path.exists("/sys/class/fc_host/host2/port_name")
    fc_fact_collector = FcWwnInitiatorFactCollector()
    facts = fc_fact_collector.collect()
    assert len(facts['fibre_channel_wwn']) == 1

# Generated at 2022-06-20 18:04:21.505595
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # variables used in test
    test_module = None
    test_collected_facts = None
    test_result = None
    test_condition = None
    # test with linux system
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    class MockLinuxModule(object):
        def get_bin_path(self, module):
            return "/bin/ls"
        def run_command(self, module):
            return 0, """0x21000014ff52a9bb\n""", None
    sys.platform = 'linux'
    test_result = test_FcWwnInitiatorFactCollector.collect(MockLinuxModule(), test_collected_facts)
    test_condition = test_result.get('fibre_channel_wwn')
    assert test

# Generated at 2022-06-20 18:04:32.638271
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class NullModule:
        def __init__(self):
            pass

        def get_bin_path(self, command, required=False, opt_dirs=[]):
            if command == "fcinfo":
                return "fcinfo"
            return None

        def run_command(self, command):
            if "fcinfo hba-port" in command:
                return (0, "HBA Port WWN: 10000090fa1658de", "")
            return (1, "", "")

    class OutputModule:
        def __init__(self, an_arg):
            self.ansible_facts = an_arg

    nullModule = NullModule()
    fc_wwn_ini_fc = FcWwnInitiatorFactCollector()

    # Unit tests for fc_wwn_init_facts = fc

# Generated at 2022-06-20 18:04:39.596243
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts import Collector

    TestModule.TEST_DATA = {}
    TestModule.TEST_DATA['ansible_local'] = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    TestModule.TEST_DATA['ansible_facts'] = {'ansible_local': {'fibre_channel_wwn': ['21000014ff52a9bb']}}

    test_obj = Collector(module=TestModule())
    test_obj.collect()
    test_obj.populate()
    assert test_obj.facts == TestModule.TEST_DATA

# Generated at 2022-06-20 18:04:45.440850
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils import basic

    FakeModule = basic.AnsibleModule
    mc = FcWwnInitiatorFactCollector()

    assert mc.name == 'fibre_channel_wwn'
    assert mc.priority == 70
    assert mc._fact_ids == set([])
    assert mc._collect_methods == [mc.collect]

# Generated at 2022-06-20 18:04:57.081013
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector

    # replace the existing fc collector with our own
    collector.collectors['fc_wwn'] = FcWwnInitiatorFactCollector()

    # add other collectors to be tested
    collectors = ['fibre_channel_wwn']

    expected_ansible_facts = {
        'fibre_channel_wwn': [
            '0001'
            '0002'
            '0003'
        ]
    }

    # fake get_file_lines function

# Generated at 2022-06-20 18:05:07.662615
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import glob
    import os
    sys.modules['ansible'] = os
    sys.modules['ansible.module_utils.facts'] = os
    sys.modules['ansible.module_utils.facts.utils'] = os
    sys.modules['ansible.module_utils.facts.utils'].get_file_lines = os
    sys.modules['ansible.module_utils.facts.collector'] = os
    sys.modules['ansible.module_utils.facts.collector'].BaseFactCollector = object

    FcWwnInitiatorFactCollector.glob = glob
    fc_facts = FcWwnInitiatorFactCollector().collect()
    print(fc_facts)

    # TODO: Add assertions


if __name__ == '__main__':
    base = BaseFact

# Generated at 2022-06-20 18:05:10.892416
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_collector = FcWwnInitiatorFactCollector()
    test_collector.platform = 'Linux'
    output = test_collector.collect()
    assert output['fibre_channel_wwn']

# Generated at 2022-06-20 18:05:23.145287
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ test_FcWwnInitiatorFactCollector_collect
    This is going to be a bit of a mess.  I'll need to mock out the
    BaseFactCollector class (done), add a mocked out platform (done),
    and update sys.platform with a mocked platform prior to creating an
    instance of the FcWwnInitiatorFactCollector class.  I'll also need
    to use the mocked out subclass which requires setting sys.modules.
    Finally, I can call the collect() method and check the resulting
    dictionary (fibre_channel_wwn key).
    """

    # python3
    try:
        from unittest.mock import patch, MagicMock
    # python2
    except:
        from mock import patch, MagicMock

    # Import module for testing

# Generated at 2022-06-20 18:05:31.567441
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test collecting fibre_channel_wwn fact with
    FcWwnInitiatorFactCollector class of
    ansible/module_utils/facts/collectors/network/fibre_channel_wwn.py
    """

    # Create the FcWwnInitiatorFactCollector instance
    fcf = FcWwnInitiatorFactCollector()

    # Create a class for passing the module object of unit test
    class MyModule(object):
        def __init__(self, run_command_ans, get_bin_path_ans):
            self.run_command_ans = run_command_ans
            self.get_bin_path_ans = get_bin_path_ans

        def run_command(self, cmd):
            return self.run_command_ans


# Generated at 2022-06-20 18:07:11.105223
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.network import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.module import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_content

    # test solaris 10
    fc_facts = {}
    fc_facts = FcWwnInitiatorFactCollector().collect()
    if sys.platform.startswith('sunos'):
        assert 'fibre_channel_wwn' in fc_facts
        assert len(fc_facts['fibre_channel_wwn']) == 2

# Generated at 2022-06-20 18:07:19.595060
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import pytest

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append("0x21000014ff52a9bb")

    class FakeModule(object):
        def __init__(self, platform, bin_paths):
            self.platform = platform
            self.bin_paths = bin_paths

        def get_bin_path(self, name, opt_dirs=None):
            if name in self.bin_paths:
                return self.bin_paths[name]
            return None


# Generated at 2022-06-20 18:07:26.533569
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact=FcWwnInitiatorFactCollector()
    assert isinstance(fc_fact,FcWwnInitiatorFactCollector)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:07:29.235138
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert isinstance(facts, FcWwnInitiatorFactCollector)

# Generated at 2022-06-20 18:07:42.373591
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import tempfile
    import os

    module_name = 'ansible.module_utils.facts'
    facts_to_collect = 'fibre_channel_wwn'

    if sys.platform.startswith('linux'):
        test_files = [
            '/sys/class/fc_host/host0/port_name',
            '/sys/class/fc_host/host1/port_name'
        ]
        test_contents = [
            '0x21000014ff52a9bb',
            '0x21000014ff52a9bc'
        ]
        expected_result = {
            'fibre_channel_wwn': [
                '000014ff52a9bb',
                '000014ff52a9bc',
            ]
        }

# Generated at 2022-06-20 18:07:45.409934
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert(obj.name == 'fibre_channel_wwn')

# Generated at 2022-06-20 18:07:50.133089
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test FcWwnInitiatorFactCollector
    """
    fc_wwn_fact = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact.name == 'fibre_channel_wwn'
    assert isinstance(fc_wwn_fact._fact_ids, set)
    assert fc_wwn_fact.collect() == {}

# Generated at 2022-06-20 18:07:57.571529
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnFactCollector = FcWwnInitiatorFactCollector()
    assert fcwwnFactCollector is not None
    assert fcwwnFactCollector.name == 'fibre_channel_wwn'
    assert fcwwnFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:08:04.985126
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # unit test for collect method of class FcWwnInitiatorFactCollector
    # if no facts file, then the whole result is empty
    f = open('/tmp/facts.yaml', 'w')
    f.close()
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == {}
    # if facts file is present and has one word it is returned
    f = open('/tmp/facts.yaml', 'w')
    f.write('abc: 123\n')
    f.close()
    assert fc.collect() == {'abc': '123'}

# Generated at 2022-06-20 18:08:08.235077
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''
    unit test for constructor of class FcWwnInitiatorFactCollector
    '''
    o_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert o_FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'