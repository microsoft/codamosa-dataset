

# Generated at 2022-06-20 17:59:30.559786
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'
    assert fc_obj._fact_ids == set()


# Generated at 2022-06-20 17:59:33.887451
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Implements unit test for constructor of class FcWwnInitiatorFactCollector
    """
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 17:59:47.187071
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test the collect method of the FcWwnInitiatorFactCollector class.
    """

    class MockModule(object):
        """
        Mock class for AnsibleModule.
        """

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, cmd, opt_dirs=[]):
            """
            Mock function for AnsibleModule.get_bin_path.
            """

            return '/bin/' + cmd

        def run_command(self, cmd):
            """
            Mock function for AnsibleModule.run_command.
            """

            return 0, '', ''

    params = {'platform': 'Linux'}
    testmodule = MockModule(params)
    result = FcWwnInitiatorFactCollector(params).collect(testmodule)


# Generated at 2022-06-20 17:59:50.631570
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    res = FcWwnInitiatorFactCollector().collect()
    assert isinstance(res, dict)
    assert 'fibre_channel_wwn' in res
    assert isinstance(res['fibre_channel_wwn'], list)


# Generated at 2022-06-20 17:59:57.776367
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    # we assume that we have at least one HBA WWN entry present
    assert len(fc_wwn_initiator_fact_collector.collect()['fibre_channel_wwn']) >= 1

# Generated at 2022-06-20 18:00:09.029368
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector

    sys_platform = sys.platform
    sys.platform = 'linux'

    module_mock = DummyAnsibleModule()
    fc_facts = FcWwnInitiatorFactCollector()
    facts = fc_facts.collect(module=module_mock)
    assert facts['fibre_channel_wwn'][0] == "21000014FF52A9BB" and len(facts['fibre_channel_wwn']) == 1

    sys.platform = sys_platform


# Generated at 2022-06-20 18:00:09.766211
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:12.139953
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert facts.name == 'fibre_channel_wwn'
    assert 'fc_host' in facts.collect()['fibre_channel_wwn']
    assert len(facts._fact_ids) == 0

# Generated at 2022-06-20 18:00:20.370690
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Use the mock_module fixture to mock the module and gave it a fake
    # ansible_facts dictionary
    mock_module = {}
    mock_module.update({'ansible_facts': {'fibre_channel_wwn': []}})
    # call method collect of class FcWwnInitiatorFactCollector
    FcWwnInitiatorFactCollector().collect(module=mock_module)
    # check if fibre_channel_wwn has been populated
    assert len(mock_module['ansible_facts']['fibre_channel_wwn']) > 0

# Generated at 2022-06-20 18:00:24.378139
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts =  {'fibre_channel_wwn': [u'21000014ff52a9bb', u'2100001552a9bb']}
    faked_module = FakeModule(ansible_module_results={})
    test_collector = FcWwnInitiatorFactCollector(faked_module, 'fibre_channel_wwn')
    facts = test_collector._load_platform_subset_facts(test_collector.collect(faked_module))
    assert facts == fc_facts

# Unit test class for testing method collect() of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:00:39.455929
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.collect() == {}

# Generated at 2022-06-20 18:00:44.821565
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcts = FcWwnInitiatorFactCollector()
    assert fcts.name == 'fibre_channel_wwn'
    assert fcts._fact_ids is not None

# Generated at 2022-06-20 18:00:47.682242
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_collector = FcWwnInitiatorFactCollector()
    assert facts_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:00:55.069095
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            raise Exception(kwargs['msg'])
        def get_bin_path(self, *args, **kwargs):
            if kwargs['opt_dirs']:
                dirs = kwargs['opt_dirs']
            else:
                return
            for directory in dirs:
                if os.path.exists(directory):
                    path = os.path.join(directory, args[0])
                    return path
    # test for linux
    if platform.system() == 'Linux':
        module = MockModule()
        f = FcWwnInitiatorFactCollector()
        print(f.collect(module))

# Generated at 2022-06-20 18:01:05.197476
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import tempfile
    import random
    class mock_module(object):
        def __init__(self):
            self.params = {}
        def run_command(self, cmd):
            if cmd == "fcinfo hba-port":
                return 0, """\
HBA Port WWN: 10000090fa1658de"""
            elif cmd == "lsdev -Cc adapter -l fcs*":
                return 0, """\
fcs0 Available 06-08 FC Adapter (df1000f108004595)
fcs1 Available 06-09 FC Adapter (df1000f108010070)"""

# Generated at 2022-06-20 18:01:09.347890
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert c.collect() in [True, False]


# Generated at 2022-06-20 18:01:11.268195
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:24.746149
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # set up necessary mocks
    collected_facts = {}
    class MockModule:
        def run_command(self, cmd, check_rc=True, close_fds=True, data=None, executable=None,
                        data_encoding='base64', binary_data=False, path_prefix=None, cwd=None):
            class MockRC:
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.stdout = out
                    self.stderr = err


# Generated at 2022-06-20 18:01:27.687606
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def run_command(self):
            return 0, '', ''

        def get_bin_path(self):
            return True

    mock_module = MockModule()
    fcf = FcWwnInitiatorFactCollector()
    fcf.collect(mock_module)

# Generated at 2022-06-20 18:01:35.308991
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_all = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts_all, dict)
    assert 'fibre_channel_wwn' in fc_facts_all
    assert isinstance(fc_facts_all['fibre_channel_wwn'], list)


# Generated at 2022-06-20 18:02:02.194341
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)

# Generated at 2022-06-20 18:02:14.472403
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    import os
    from ansible.module_utils.facts import defaults
    from ansible.module_utils.facts.utils import nest_dictionaries
    file_collected_facts = defaults.get_module_facts(module_name='setup',
                                                     collected_facts=dict())
    file_collected_facts['ansible_system'] = os.uname()[0]
    facts_collector = FactsCollector(collected_facts=file_collected_facts,
                                     namespace='ansible')
    fcwwn_collector = FcWwnInitiatorFactCollector()
    fcwwn_fact = fcwwn_collector.collect(module=None,
                                         collected_facts=facts_collector)
    nested

# Generated at 2022-06-20 18:02:19.795421
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    facts_collector = FcWwnInitiatorFactCollector(module)
    assert facts_collector.name == 'fibre_channel_wwn'
    assert isinstance(facts_collector.collect(), dict)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:02:24.380376
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:26.633545
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:33.820909
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    module = None
    collected_facts = {}

    # create instance of fact collector
    fact_collector = FcWwnInitiatorFactCollector(module=module, collected_facts=collected_facts)

    # test method collect with mocked values
    fact_collector.collect()

    # test if the method collect returned a dictionary
    assert isinstance(collected_facts, dict)
    # test if the method collect returned the right keys
    assert 'fibre_channel_wwn' in collected_facts

# Generated at 2022-06-20 18:02:39.938304
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method `FcWwnInitiatorFactCollector.collect`
    """

    import os
    import tempfile

    # mock class for module, the module instance is used by the collector
    # to execute module functions
    class MyModule(object):
        def __init__(self, tmp_path_prefix='ansible_fibre_channel_wwn'):
            self.tmp_dir = tempfile.mkdtemp(prefix=tmp_path_prefix)
            self.tmp_path_prefix = tmp_path_prefix

        def run_command(self, cmd, check_rc=True):
            """
            example for a simple command, stub method for unittest
            """
            return 0, '', ''


# Generated at 2022-06-20 18:02:44.226016
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc.collected_facts

# Generated at 2022-06-20 18:02:53.306116
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcWwnInitiatorFactCollector: Test collect method
    """
    m_module = MagicMock()
    m_collect_cmd = MagicMock()
    m_collect_cmd.return_value = "10000090fa1658de"
    m_module.run_command.return_value = (0, m_collect_cmd, '')

    FcWwnInitiatorFactCollector._get_platform = MagicMock()
    FcWwnInitiatorFactCollector._get_platform.return_value = "SunOS"

    FcWwnInitiatorFactCollector._get_file_lines = MagicMock()
    FcWwnInitiatorFactCollector._get_file_lines.return_value = []


# Generated at 2022-06-20 18:03:00.195759
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    # setup mock dependencies
    class MockModule():
        class run_command():
            def __init__(self,commands,check_rc=True):
                self.commands = commands

            def __call__(self,command):
                if command.startswith('fcinfo'):
                    """
                    on solaris 10 or solaris 11 use `fcinfo hba-port`
                    """
                    out = "HBA Port WWN: 10000090fa1658de"
                elif command.startswith('lsdev'):
                    """
                    on solaris 10 or solaris 11 should use `fcinfo hba-port`
                    TBD (not implemented): on solaris 9 use `prtconf -pv`
                    """
                   

# Generated at 2022-06-20 18:03:54.851257
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(argument_spec=dict())
    ms = ansible_collector.get_module_shared_state(module)
    ms.gather_subset = set(['fibre_channel_wwn'])
    ms.gather_timeout = 10
    ms.all_collectors = [Collector('fibre_channel_wwn',
                                   FcWwnInitiatorFactCollector,
                                   False,
                                   module)]
    facts = {'ansible_collector': ms}
    fc_facts = FcWwn

# Generated at 2022-06-20 18:04:06.431421
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test of method collect of class FcWwnInitiatorFactCollector
    """
    # Run only on linux
    if sys.platform.startswith('linux'):
        from ansible.module_utils.facts import ModuleArgsParser
        import ansible.module_utils.facts.collector
        import ansible.module_utils.facts.utils
        import ansible.module_utils.facts.collectors.network
        import ansible.module_utils.facts.collectors.storage
        import ansible.module_utils.facts.collectors.peripheral

        # Create an empty class object. Will use the function collect from this class to test.
        fc_wwn_collector = ansible.module_utils.facts.collectors.fibre_channel_wwn.FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:04:18.848959
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Make sure the method can be used stand-alone
    from ansible.module_utils.facts import module_utils
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_instance
    module_utils.basic.AnsibleModule = object
    collector.FactsCollector = object
    collector.Collector = object
    c1 = FcWwnInitiatorFactCollector()

    class FakeModule():
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = []
            self.params['gather_timeout'] = 1
            self.run_command = self.run_command

# Generated at 2022-06-20 18:04:22.795124
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    collect = fc.collect()
    assert 'fibre_channel_wwn' in collect.keys()

# Generated at 2022-06-20 18:04:25.898125
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    results = collector.collect()
    assert([]) == results.get('fibre_channel_wwn')

# Generated at 2022-06-20 18:04:36.860475
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils._text import to_text
    fc = Collector()
    if sys.version_info[0] < 3:
        class TestModule(object):
            def run_command(self, command, check_rc=True, close_fds=True, data=None, cwd=None, binary_data=False):
                return 0, '', ''
            def get_bin_path(self, command, opt_dirs=[]):
                return command
    else:
        from ansible.module_utils.six.moves.mock import Mock
        # mock the TestModule

# Generated at 2022-06-20 18:04:38.463568
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:41.914575
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:54.016386
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:04:57.702701
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    obj = Collector()
    assert isinstance(obj.collector['fibre_channel_wwn'], FcWwnInitiatorFactCollector)


# Generated at 2022-06-20 18:06:47.176540
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_values = [['0x21000014ff52a9bb', '0x21000014ff52a9bb', '0x21000014ff52a9bb']]
    # create instance of FcWwnInitiatorFactCollector class
    collector = FcWwnInitiatorFactCollector()
    # create mock module
    module = True
    collected_facts = True
    # test collect method
    module.get_bin_path = true_mock_get_bin_path
    module.run_command = true_mock_run_command
    facts = collector.collect(module, collected_facts)
    # assert if result is as expected
    assert facts == test_values


# Generated at 2022-06-20 18:06:49.283860
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert isinstance(FcWwnInitiatorFactCollector, object)

# Generated at 2022-06-20 18:06:56.746118
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    collector = FcWwnInitiatorFactCollector()
    data = collector.collect(module=module)
    assert data is not None
    assert 'fibre_channel_wwn' in data
    # assert len(data['fibre_channel_wwn']) > 0


# Generated at 2022-06-20 18:07:08.174979
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector

    class Module(object):
        def get_bin_path(self, arg1, opt_dirs=[]):
            return 1
        def run_command(self, arg1):
            return 1,1,1

    module = Module()
    a = FcWwnInitiatorFactCollector(module)
    assert a._module == module
    assert a.name == 'fibre_channel_wwn'
    assert a._fact_ids == set()

# Generated at 2022-06-20 18:07:19.798017
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    module = AnsibleModuleMock()
    if platform.system() == 'SunOS':
        module.run_command.return_value = (0,
            'HBA Port WWN: 10000090fa1658de\n', '')
        module.get_bin_path.return_value = '/usr/bin/fcinfo'
    elif platform.system() == 'Linux':
        module.run_command.return_value = (0, '', '')
        module.get_bin_path.return_value = '/usr/bin/fcinfo'
    elif platform.system() == 'HP-UX':
        module.run_command.return_value = (0,
            '/dev/fcd3        0/0/1/0.0x2000000000000000  \n', '')
        module.get_

# Generated at 2022-06-20 18:07:27.168672
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_collector._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-20 18:07:28.205673
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:07:30.413934
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
  fc = FcWwnInitiatorFactCollector()
  assert len(fc.collect()) > 0

# Generated at 2022-06-20 18:07:39.197799
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    sys.modules['ansible'] = __import__('offline_mock_ansible')
    mock_module = __import__('offline_mock_ansible').AnsibleModule
    fcwi = FcWwnInitiatorFactCollector()
    assert fcwi.name == 'fibre_channel_wwn'
    assert not fcwi._fact_ids
    assert type(fcwi.collect()) == dict

# Generated at 2022-06-20 18:07:50.556659
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a dummy module object
    module = type('AnsibleModule', (object,), {'run_command': fake_run_command})
    # create a dummy facts object
    collected_facts = type('AnsibleModule', (object,), {})
    # create a FcWwnInitiatorFactCollector object
    fc_wwn = FcWwnInitiatorFactCollector()
    # call method collect
    fc_facts = fc_wwn.collect(module, collected_facts)
    # test if key 'fibre_channel_wwn' is in fact dictionary
    assert 'fibre_channel_wwn' in fc_facts
    # test if 'fibre_channel_wwn' dict has key 'aix'