

# Generated at 2022-06-20 17:59:37.548483
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def run_command(self, command):
            return 0, '', ''
        def get_bin_path(self, app, opt_dirs=[]):
            return app
    fc_facts = ['0x21000014ff52a9bb', '0x10000000c9556ec0', '0x21000014ff52a9bc']
    fc_expected_facts = {'fibre_channel_wwn': fc_facts}
    fc = FcWwnInitiatorFactCollector()
    result = fc.collect(module=MockModule(params={}))
    assert result == fc_expected_facts

# Generated at 2022-06-20 17:59:39.498357
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 17:59:43.197380
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 17:59:55.802610
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create instance of class FcWwnInitiatorFactCollector
    init_fc_col = FcWwnInitiatorFactCollector()
    # init modules
    module_args = dict(
        foo='bar',
        ansible_facts={'fibre_channel_wwn': ['0x21000014ff52a9bb']}
    )
    from ansible.module_utils.facts import ModuleFacts
    module = ModuleFacts(**module_args)
    # collect facts
    init_fc_col.collect(module=module)
    # get facts
    ansible_facts = module.exit_json['ansible_facts']
    # assert facts collection
    assert 'fibre_channel_wwn' in ansible_facts


# Generated at 2022-06-20 18:00:04.264357
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule(object):
        def get_bin_path(self, arg1, opt_dirs=None):
            if arg1 == "fcinfo" and opt_dirs is None:
                return "/opt/fcms/bin/fcinfo"
            if arg1 == "ioscan" and opt_dirs is None:
                return "/opt/fcms/bin/ioscan"
            if arg1 == "fcmsutil" and opt_dirs == ["/opt/fcms/bin"]:
                return "/opt/fcms/bin/fcmsutil"
    
    class MockModuleUtil(object):
        def run_command(self, arg1):
            out = "HBA Port WWN: 10000090fa1658de"
            return 0, out, None
    
    module = MockModule()
    module.run

# Generated at 2022-06-20 18:00:05.052150
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:00:18.176141
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    ###########################################################################
    # Mocking arguments and results
    ###########################################################################
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg, opt_dirs=None):
            if arg == 'ioscan':
                return '/usr/sbin/ioscan'
            elif arg == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            else:
                return None

        def run_command(self, cmd):
            if cmd == '/usr/sbin/ioscan -fnC FC':
                return 0, 'fcd0 0/0/1/0.0.0 /dev/fcd0', None

# Generated at 2022-06-20 18:00:27.481424
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    mock_module = type('module', (object, ), dict(run_command=lambda x: (0, b'', b'')))()
    mock_module.get_bin_path = lambda x, opt_dirs=None: x

    collector = FcWwnInitiatorFactCollector(mock_module)
    facts = collector.collect(mock_module)

    assert type(facts) is dict, 'facts is not a dictionary'
    assert 'fibre_channel_wwn' in facts, 'missing expected key'

# Generated at 2022-06-20 18:00:32.342904
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-20 18:00:40.764219
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a temporary class object to test collect method
    class_obj = FcWwnInitiatorFactCollector()
    # Create a temporary ansible module object to test collect method
    class module(object):
        def __init__(self):
            pass
        def get_bin_path(self, arg1):
            return arg1

    # Create a temporary ansible module object
    m = module()
    # Check the result of collect method
    assert class_obj.collect(m) == {'fibre_channel_wwn': ['1000090fa1658de']}

# Generated at 2022-06-20 18:00:54.274596
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:00:55.121636
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:01:01.396687
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create an instance of FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()

    # Create a dummy module
    import ansible.module_utils.facts.facts as ans_facts
    module = ans_facts.AnsibleModule()

    # Call the collect method of FcWwnInitiatorFactCollector
    facts = fc.collect(module)

    # Print facts
    import json
    print(json.dumps(facts, indent=4))

if __name__ == '__main__':
    # test_FcWwnInitiatorFactCollector_collect()
    fc = FcWwnInitiatorFactCollector()
    print(fc.collect())

# Generated at 2022-06-20 18:01:05.618195
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:10.195936
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert fc_facts_collector.name == 'fibre_channel_wwn'
    assert not fc_facts_collector.collect()


# Generated at 2022-06-20 18:01:16.782090
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Constructor of class FcWwnInitiatorFactCollector.
    """
    module = AnsibleModuleMock()
    fact_collector = FcWwnInitiatorFactCollector(module=module)
    assert fact_collector


# Generated at 2022-06-20 18:01:22.892645
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-20 18:01:27.039384
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector.
    """
    sys.modules.pop('ansible_facts', None)
    obj = FcWwnInitiatorFactCollector()
    assert(obj.name == 'fibre_channel_wwn')

# Generated at 2022-06-20 18:01:35.881157
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts import FactCollector

    # array for the facts to be collected
    collected_facts = dict()

    # instantiate a FcWwnInitiatorFactCollector object
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()

    # call collect
    fc_wwn_fact_collector.collect(collected_facts=collected_facts)



# Generated at 2022-06-20 18:01:49.673668
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    input_fakestdout = """0x21000014ff52a9bb
    0x50000973f0014487"""
    expected_result = ['21000014ff52a9bb', '50000973f0014487']

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import StringIO

    module = None
    collector = Collector(module=module, facts={},
                          collected_facts=None)
    collector.collect_platform_facts()
    collector.collector = [FcWwnInitiatorFactCollector]

    fakestdout = StringIO()

# Generated at 2022-06-20 18:02:08.304650
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert isinstance(fc_facts, FcWwnInitiatorFactCollector)
    assert fc_facts.name == 'fibre_channel_wwn'
    assert len(fc_facts._fact_ids) == 0


# Generated at 2022-06-20 18:02:13.239928
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test of method collect of class FcWwnInitiatorFactCollector"""
    col = FcWwnInitiatorFactCollector()
    result = col.collect()
    # result must be of type dict
    assert isinstance(result, dict)
    # result['fibre_channel_wwn'] must be of type dict
    assert isinstance(result['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:02:18.452484
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    # return empty dictionary, since the module_utils.facts.utils.get_file_lines is mocked
    assert fc.collect() == {'fibre_channel_wwn': []}


# Generated at 2022-06-20 18:02:29.228958
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes
    c = Collector()
    fc_wwn_facts = FcWwnInitiatorFactCollector(c)

    # return facts
    collected_facts = fc_wwn_facts.collect()

    assert collected_facts != {}
    assert collected_facts['fibre_channel_wwn'] != 0

    # make sure the collected facts could be encoded
    # into JSON properly
    to_bytes(collected_facts)

# Generated at 2022-06-20 18:02:35.891821
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.platform is None
    assert obj.distribution is None
    assert obj.collector is None
    assert obj.name is not None
    assert obj._fact_ids is not None
    assert obj._fact_ids == set()

# Generated at 2022-06-20 18:02:44.642496
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Returns the expected result when invoking the collect method of the FcWwnInitiatorFactCollector
    """

    FcWwnInitiatorFactCollector._platform = "linux"

    contents_linux_fcfile = """
    0x21000014ff52a9bb
    """

    FcWwnInitiatorFactCollector._module = MockModuleUtils(contents_linux_fcfile)

    contents_linux_expected_result = {'fibre_channel_wwn': ['21000014ff52a9bb']}

    assert FcWwnInitiatorFactCollector.collect() == contents_linux_expected_result

    FcWwnInitiatorFactCollector._platform = "sunos"

# Generated at 2022-06-20 18:02:50.184502
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    fc_fact_collector = FcWwnInitiatorFactCollector()
    collected_facts = {}
    facts_dict = fc_fact_collector.collect(collected_facts=collected_facts)
    print (facts_dict)
    assert 'fibre_channel_wwn' in facts_dict.keys()

if __name__=='__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:02:56.893367
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator._fact_ids == set()

# Generated at 2022-06-20 18:02:59.179970
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # initialize instance
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:03:03.357031
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert(FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn')
    assert(FcWwnInitiatorFactCollector._fact_ids == set())

# Generated at 2022-06-20 18:03:32.765425
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc=FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:44.896936
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import get_collector_instance
    from ansible.module_utils.facts.utils import AnsibleFactsCollector
    from ansible.module_utils._text import to_text
    import os, sys

    if not os.path.exists(sys.argv[1]):
        os.makedirs(sys.argv[1])
    # create files
    f = open("/sys/class/fc_host/host2/port_name", "w")
    f.write("0x21000014ff52a9bb")
    f.close()
    f = open("/sys/class/fc_host/host3/port_name", "w")

# Generated at 2022-06-20 18:03:55.256424
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import Collector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            return 0, MockModule.result, ''

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'ioscan':
                path = '/sbin/ioscan'
            elif name == 'fcmsutil':
                path = '/opt/fcms/bin/fcmsutil'
            else:
                path = ''
            return path

    module = MockModule()

    # Mock result of 'ioscan -fnC FC' command

# Generated at 2022-06-20 18:04:06.524830
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import Facter
    import platform
    import sys

    fact_collector = FcWwnInitiatorFactCollector()

    if sys.platform.startswith('aix'):
        # test with fcs3, which is not available
        cmd = ['lscfg', '-vpl', 'fcs3']
        rc, lscfg_out, err = Facter.run_command(cmd)
        fact_collector._platform_file_exists = (rc == 0)
        assert fact_collector.platform_file_exists() is False
        fact_collector._platform_file_exists = None
        # open fcs0

# Generated at 2022-06-20 18:04:09.797343
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    ffc = FcWwnInitiatorFactCollector()
    assert ffc.name == "fibre_channel_wwn"

# Generated at 2022-06-20 18:04:20.639413
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import unittest

    # mock os.path.isdir(path)
    class MockOsPathIsDir(object):
        def __init__(self, glob_paths):
            self.glob_paths = glob_paths

        def __call__(self, path):
            return path in self.glob_paths

    # mock glob.glob(pathname)
    class MockGlobGlob(object):
        def __init__(self, glob_paths):
            self.glob_paths = glob_paths

        def __call__(self, pathname):
            return self.glob_paths


# Generated at 2022-06-20 18:04:22.753431
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:33.361931
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:04:41.404955
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    from ansible_collections.community.general.tests.unit.compat.mock import Mock

    class ModuleMock(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if cmd == "fcinfo hba-port":
                return 0, """HBA Port WWN: 10000090fa1658de
HBA Port WWN: 10000090fa1658de
HBA Port WWN: 10000000c9741c3c
HBA Port WWN: 10000000c9741c3c""", ""

# Generated at 2022-06-20 18:04:43.523737
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_obj = FcWwnInitiatorFactCollector()
    assert fcwwn_obj is not None


# Generated at 2022-06-20 18:05:40.767931
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    fc_facts = {'fibre_channel_wwn': ['21000025ee812e1e']}
    assert fc.collect(collected_facts=None) == fc_facts

# Generated at 2022-06-20 18:05:53.149821
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    aix_s = "Available  0-1-1-0  fcs3                    Virtual FC Adapter"
    hpux_s = "/dev/fcd   0/1/1/0  0x0  0x4fb4eb   0x4fb4eb  0x0  sdisk  FC"
    solaris_s = "HBA Port WWN: 10000090fa1658de"
    linux_s = "0x21000014ff52a9bb"
    # using windows because of the nice facts module_utils module
    # it would be ~500 lines to mock Facter

# Generated at 2022-06-20 18:05:56.976555
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()

# Generated at 2022-06-20 18:05:59.377734
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:08.445545
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module = Mock()
    module.run_command = Mock(return_value=('', '', ''))
    module.get_bin_path = Mock(return_value='/anypath')
    set_module_args({'gather_subset': 'all'})

    result = dict(fibre_channel_wwn=['21000014ff52a9bb'])
    assert FcWwnInitiatorFactCollector.collect(module=module) == result

# Generated at 2022-06-20 18:06:12.061934
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids == set()

# Generated at 2022-06-20 18:06:20.699354
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    result = fact_collector.collect()
    assert result
    assert 'fibre_channel_wwn' in result
    assert isinstance(result['fibre_channel_wwn'], list)
    assert len(result['fibre_channel_wwn'])

# Generated at 2022-06-20 18:06:24.817286
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"
    assert fc.collect() is None

# Generated at 2022-06-20 18:06:30.794233
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factCollector = FcWwnInitiatorFactCollector()
    assert factCollector.name == 'fibre_channel_wwn'
    assert factCollector._fact_ids == set(['fibre_channel_wwn'])
    

# Generated at 2022-06-20 18:06:38.662437
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys, os
    test_dir = os.path.join(os.path.dirname(sys.path[0]), 'utils')
    # on Linux (Ubuntu)
    if sys.platform.startswith('linux'):
        test_FcWwnInitiatorFactCollector_collect_linux(test_dir)
    # on Solaris:
    if sys.platform.startswith('sunos'):
        test_FcWwnInitiatorFactCollector_collect_solaris(test_dir)
    # on AIX
    if sys.platform.startswith('aix'):
        test_FcWwnInitiatorFactCollector_collect_aix(test_dir)
    # on HP-UX:
    if sys.platform.startswith('hp-ux'):
        test_

# Generated at 2022-06-20 18:08:43.331534
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print('----- test_FcWwnInitiatorFactCollector_collect -----')

    fcwwns = []
    fcwwns.append('21000014ff52a9bb')
    fcwwns.append('21000014ff52a9bc')
    fcwwns.append('21000014ff52a9bd')

    obj = FcWwnInitiatorFactCollector()
    result = obj.collect()
    print('type(result): ' + str(type(result)))
    print('result: ' + str(result))
    assert type(result) == dict
    assert 'fibre_channel_wwn' in result
    for fcwwn in fcwwns:
        assert fcwwn in result['fibre_channel_wwn']

# Unit test

# Generated at 2022-06-20 18:08:49.949942
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_names = set()
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()
    for key in facts:
        fact_names.add(key)
    assert fact_names == ['fibre_channel_wwn']

# Generated at 2022-06-20 18:08:51.381579
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcFact = FcWwnInitiatorFactCollector()
    assert fcFact is not None


# Generated at 2022-06-20 18:08:56.771686
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'
    assert a._fact_ids == set()


# Generated at 2022-06-20 18:09:06.325736
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for method collect of class FcWwnInitiatorFactCollector """
    (tmp_path, log_path) = tempfile.mkstemp()


# Generated at 2022-06-20 18:09:08.656199
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'