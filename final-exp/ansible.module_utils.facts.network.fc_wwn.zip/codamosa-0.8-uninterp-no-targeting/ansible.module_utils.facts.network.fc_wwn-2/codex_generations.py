

# Generated at 2022-06-20 17:59:30.775113
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:33.402740
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fct = FcWwnInitiatorFactCollector()
    assert fc_fct is not None

# Generated at 2022-06-20 17:59:47.081711
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    if sys.version_info[0] >= 3:
        import unittest
        import ansible.module_utils.facts.collectors.network.fibre_channel.fc_wwn_initiator as fc_wwn_initiator_collector_module

        class TestFcWwnInitiatorFactCollector(unittest.TestCase):
            def setUp(self):
                self.fact_subclass = fc_wwn_initiator_collector_module.FcWwnInitiatorFactCollector

            def test_instance(self):
                fact_instance = self.fact_subclass(dict())
                self.assertIsInstance(fact_instance, self.fact_subclass)

            def test_get_facts(self):
                fact_instance = self.fact_subclass(dict())


# Generated at 2022-06-20 17:59:58.103340
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import mock
    import sys

    if sys.version_info[0] == 2:
        builtin_import = '__builtin__.__import__'
    else:
        builtin_import = 'builtins.__import__'

    def moduleloader(name, path):
        if name == 'platform':
            class MockModule(object):
                @staticmethod
                def system():
                    return 'SunOS'
            return MockModule()

    module = mock.MagicMock()
    module.run_command.return_value = 0, '', ''
    module.get_bin_path.return_value = '/usr/bin/'
    with mock.patch(builtin_import, side_effect=moduleloader):
        fc_facts = FcWwnInitiatorFactCollector({}).collect(module=module)


# Generated at 2022-06-20 18:00:06.063738
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    fc_keys = fc_facts.collect()
    if not fc_keys:
        raise Exception("Failed to acquire Fibre-channel FC WWN information")


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:00:06.690693
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:00:17.090445
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_obj = FcWwnInitiatorFactCollector()
    fcwwn_facts = fcwwn_obj.collect()
    #print('Fibre Channel WWN of host: %s' % fcwwn_facts['fibre_channel_wwn'])
    for fcwwn in fcwwn_facts['fibre_channel_wwn']:
        print(fcwwn)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:00:29.980628
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class FakeModule(object):
        def __init__(self):
            self.facts = {}
        def run_command(self):
            return 0, """HBA Port WWN: 10000090fa1658de
HBA Port WWN: 10000090fa165877""", ''
        def get_bin_path(self, arg, opt_dirs=[]):
            return '/opt/fcms/bin/' + arg
    fc = FcWwnInitiatorFactCollector()
    out = fc.collect(FakeModule())
    print(out)
    assert out['fibre_channel_wwn'][0] == '10000090fa1658de'
    assert out['fibre_channel_wwn'][1] == '10000090fa165877'

# Generated at 2022-06-20 18:00:39.412976
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_class = FcWwnInitiatorFactCollector()
    fc_facts = fc_facts_class.collect()
    assert fc_facts['fibre_channel_wwn'] == []
    fc_facts['fibre_channel_wwn'].append('12345')
    assert fc_facts['fibre_channel_wwn'] == ['12345']

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:00:43.022482
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_class = FcWwnInitiatorFactCollector()
    my_class.collect()


# Generated at 2022-06-20 18:00:55.962116
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pass

# Generated at 2022-06-20 18:01:05.434253
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = sys.modules[__name__]
    # Dummy module class for unit test of collect method of FcWwnInitiatorFactCollector
    class DummyModule(object):
        def __init__(self, platform=None, bin_paths=None):
            self.platform = platform
            self.bin_paths = bin_paths
            self.run_command_rc = 0
            self.run_command_stdout = None
            self.run_command_stderr = None

        def get_bin_path(self, arg, opt_dirs=None):
            if self.bin_paths and arg in self.bin_paths:
                return self.bin_paths[arg]
            return None



# Generated at 2022-06-20 18:01:15.026415
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # pylint: disable=protected-access
    class ModuleMock(object):
        def __init__(self, params):
            self.params = params
            self.bin_path = None

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'fcinfo':
                return "/usr/sbin/fcinfo"
            elif name == 'lscfg':
                return "/usr/sbin/lscfg"
            elif name == 'lsdev':
                return "/usr/bin/lsdev"
            elif name == 'ioscan':
                return "/usr/sbin/ioscan"
            elif name == 'fcmsutil':
                return "/opt/fcms/bin/fcmsutil"

        def run_command(self, command):
            pass

    # mock

# Generated at 2022-06-20 18:01:17.930394
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_obj = FcWwnInitiatorFactCollector()
    assert fcwwn_obj.name == 'fibre_channel_wwn'
    assert fcwwn_obj._fact_ids == set()

# Generated at 2022-06-20 18:01:21.709283
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'



# Generated at 2022-06-20 18:01:32.008125
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys

    # set up a dummy instance
    class Mod:
        def run_command(self, cmd):
            return 0, "fcinfo_out", "a_string"

        def get_bin_path(self, cmd):
            return "cmd"

    mod = Mod()
    fc = FcWwnInitiatorFactCollector()
    facts = {}
    # test linux
    facts['distribution'] = 'Debian'
    facts['distribution_major_version'] = '8'
    sys.platform = 'linux'
    fc.collect(mod, facts)
    if facts['fibre_channel_wwn']:
        assert (len(facts['fibre_channel_wwn']) >= 1)
    # test solaris
    facts['distribution'] = 'Solaris'

# Generated at 2022-06-20 18:01:37.201336
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)
    assert hasattr(fc, 'collect')
    # make sure the collect() method is callable as 'fc.collect()'
    collect = getattr(fc, 'collect', None)
    assert callable(collect)

# Generated at 2022-06-20 18:01:46.907429
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible_facts.utils
    from ansible.module_utils.facts import FactCollector

    pci_subsystem_ids_value = []
    collected_facts = ansible_facts.utils.get_collected_facts(
        gather_subset=['all'],
        fact_collectors=[FactCollector],
        ansible_module=None)
    assert type(collected_facts['fibre_channel_wwn']) is list

# Generated at 2022-06-20 18:02:00.306451
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:02:05.383921
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an instance of class FcWwnInitiatorFactCollector
    facter = FcWwnInitiatorFactCollector()
    facter.collect()
    #facter.write_cache()

# Generated at 2022-06-20 18:02:41.516575
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcCollector = FcWwnInitiatorFactCollector()
    # Test on Windows/WSL
    if sys.platform.startswith('linux'):
        # Test for Linux
        for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
            fcCollector.collect()
    elif sys.platform.startswith('sunos'):
        # Test for Solaris 10 or 11
        fcCollector.collect()
    elif sys.platform.startswith('aix'):
        # Test for AIX
        fcCollector.collect()
    elif sys.platform.startswith('hp-ux'):
        # Test for HP-UX
        fcCollector.collect()



# Generated at 2022-06-20 18:02:43.363609
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is not None

# Generated at 2022-06-20 18:02:49.999115
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_world_wide_name = ['21000014ff52a9bb', '10000090fa1658de', '10000090fa1658de', '10000090FA551509']
    def run_command(self, command):
        return (0, fc_world_wide_name, None)

    test_module = AnsibleModule({})
    test_module.run_command = run_command
    fact_collector = FcWwnInitiatorFactCollector(test_module)
    result = fact_collector.collect()
    assert_equals({'fibre_channel_wwn': ['21000014ff52a9bb', '10000090fa1658de', '10000090fa1658de', '10000090FA551509']}, result)

# Generated at 2022-06-20 18:02:57.934455
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcfc = FcWwnInitiatorFactCollector()
    assert fcfc.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    # Unit test for constructor of class FcWwnInitiatorFactCollector
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:03:04.039170
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    collector = FcWwnInitiatorFactCollector()
    module = AnsibleModuleMock()
    ansible_facts = {}
    # mock all needed methods
    module.get_bin_path = MagicMock(name="get_bin_path")
    fc_faits = collector.collect(module=module, collected_facts=ansible_facts)
    # check results
    assert fc_faits['fibre_channel_wwn'] == ['21000014ff52a9bb']



# Generated at 2022-06-20 18:03:09.999603
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_fc_wwn_initiator_fact_collector_obj = FcWwnInitiatorFactCollector()
    assert test_fc_wwn_initiator_fact_collector_obj.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in test_fc_wwn_initiator_fact_collector_obj._fact_ids

# Generated at 2022-06-20 18:03:11.925199
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector.name == "fibre_channel_wwn"


# Generated at 2022-06-20 18:03:15.662505
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector(None)

    assert fc is not None
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:25.930554
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """The FcWwnInitiatorFactCollector class implements the collect method
    which returns a hash which includes the fibre_channel_wwn key which stores
    a list of Fibre Channel WWN initiator identifiers.
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.network.fibre_channel_wwn as fibre_channel_wwn
    import importlib
    import sys
    import unittest
    import os

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):

        """
        Methods required to auto-discover and run all tests
        """

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-20 18:03:29.540043
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = AnsibleModule(argument_spec=dict())
    facts_collector = FcWwnInitiatorFactCollector(module=module)
    assert facts_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:04:18.049162
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-20 18:04:26.529121
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    ## First mock the module returned values, check if the method get_file_lines() from base class run correctly
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MockOSFunc:
        def __init__(self):
            pass
        def listdir(self, *args, **kwargs):
            return ['fc_host1', 'fc_host2']

    original_rlf = BaseFactCollector.get_file_lines
    ## Then mock the method get_file_lines()
    BaseFactCollector.get_file_lines = lambda intf, a: ['0x21000014ff52a9bb']

    # Then mock the module
    import ansible.module_utils.facts.system.fibre_channel_wwn as fc_wwn
    original_mkd = fc_

# Generated at 2022-06-20 18:04:36.172105
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = FakeAnsibleModule()
    test_module_name = 'FcWwnInitiatorFactCollector'
    test_module._ansible_version = '2.4.0.0'
    test_module._ansible_module_name = test_module_name
    test = FcWwnInitiatorFactCollector(module=test_module)
    result = test.collect()
    assert 'fibre_channel_wwn' in result
    assert result['fibre_channel_wwn'] == ['10000090fa1658de']

# ---------------------------------------
# Mocking section
# This section contains helper methods to be used by unit tests
# ---------------------------------------


# Generated at 2022-06-20 18:04:42.005580
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fcwwn._fact_ids


if __name__ == '__main__':
    # Unit tests for this class can be run in this file
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:04:42.957607
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:04:55.175477
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import pytest
    
    ################
    # Mock modules #
    ################
    class MockModule():
        def __init__(self):
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            return

        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/test"


# Generated at 2022-06-20 18:05:03.820813
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    with open("test/unittests/fixtures/ansible_facts_fibre_channel_wwn_linux.out", 'r') as f:
        fc_facts = f.read()
    fc_facts_obj = FcWwnInitiatorFactCollector(None, None)
    fc_facts_obj.collect()
    assert fc_facts_obj.name == 'fibre_channel_wwn'
    assert fc_facts_obj._fact_ids == set()
    assert fc_facts_obj.collect() == eval(fc_facts)

# Generated at 2022-06-20 18:05:06.602682
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect()
    assert 'fibre_channel_wwn' in facts


# Generated at 2022-06-20 18:05:10.728902
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert wwn_initiator_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:05:22.841299
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a FcWwnInitiatorFactCollector instance
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # create a mock AnsibleModule instance
    from ansible.module_utils.facts import ansible_module
    from unittest.mock import Mock
    import platform
    ansible_module_instance = ansible_module()
    # define some mock return values for AnsibleModule methods
    import sysconfig
    sysconfig_get_paths_value = "/usr/local/bin"
    sysconfig_get_paths_return_value = {"purelib": sysconfig_get_paths_value}
    sysconfig.get_paths.return_value = sysconfig_get_paths_return_value
    sysconfig_get_path_return_

# Generated at 2022-06-20 18:06:57.142393
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    m = FcWwnInitiatorFactCollector()
    print(m.collect())
    print(m._fact_ids)


# Generated at 2022-06-20 18:07:01.503316
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:12.321167
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Init an instance of FcWwnInitiatorFactCollector
    fc_wwn_initiator_fact_collector_instance = FcWwnInitiatorFactCollector()

    # assert name of FcWwnInitiatorFactCollector is 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector_instance.name == 'fibre_channel_wwn'

    # assert the return of method _fact_ids of FcWwnInitiatorFactCollector is set
    assert isinstance(fc_wwn_initiator_fact_collector_instance._fact_ids, set)

    # assert the return of method collect of FcWwnInitiatorFactCollector is dictionary

# Generated at 2022-06-20 18:07:20.386031
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    test_collector = Collector()
    test_collector.collectors = [FcWwnInitiatorFactCollector()]
    if sys.platform.startswith('linux'):
        assert "fibre_channel_wwn" in test_collector.collect().keys()
    elif sys.platform.startswith('sunos'):
        assert "fibre_channel_wwn" in test_collector.collect().keys()
    elif sys.platform.startswith('aix'):
        assert "fibre_channel_wwn" in test_collector.collect().keys

# Generated at 2022-06-20 18:07:23.000766
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts._fact_ids

# Generated at 2022-06-20 18:07:25.780435
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:32.949320
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_file_lines

    module = ansible.module_utils.facts.collector
    base_fact_collector_class = ansible.module_utils.facts.collector.BaseFactCollector
    FcWwnInitiatorFactCollector_class = FcWwnInitiatorFactCollector
    open = open
    glob = glob
    sys = sys
    to_bytes = to_bytes
    get_file_lines = get_file_lines

    # Mock class BaseFactCollector(object).


# Generated at 2022-06-20 18:07:36.417504
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_obj = FcWwnInitiatorFactCollector()
    assert fc_wwn_obj is not None

# Generated at 2022-06-20 18:07:39.161880
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:43.899451
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcfacts = FcWwnInitiatorFactCollector()
    assert fcfacts.name == 'fibre_channel_wwn'
    assert fcfacts._fact_ids == set()
