

# Generated at 2022-06-20 17:59:29.137621
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-20 17:59:33.623128
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-20 17:59:40.565980
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert isinstance(fc, FcWwnInitiatorFactCollector)
    assert fc.name == 'fibre_channel_wwn'
    assert isinstance(fc._fact_ids, set)

# Generated at 2022-06-20 17:59:45.502839
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts_collection = {'fibre_channel_wwn': []}

    class MyModule:
        def __init__(self, out, err, returncode, out1, out2, out3, out4):
            self.run_command_out = out
            self.err = err
            self.rc = returncode
            self.facts = {}

        def run_command(self, cmd):
            if cmd == 'fcinfo hba-port':
                return (self.rc, self.run_command_out, self.err)
            elif cmd == 'lscfg -vpl fcs3':
                return (0, out1, '')
            elif cmd == 'lscfg -vpl fcs4':
                return (0, out2, '')

# Generated at 2022-06-20 17:59:48.206300
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_obj = FcWwnInitiatorFactCollector()
    assert facts_obj
    assert facts_obj.name == 'fibre_channel_wwn'
    assert facts_obj._fact_ids == set()


# Generated at 2022-06-20 17:59:58.991160
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    In this test case the function FcWwnInitiatorFactCollector.collect is
    tested. The test setup uses the class FcWwnInitiatorFactCollector as
    a context manager.
    """

    import os.path
    import socket
    import platform
    import pytest

    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.collector import BaseFactCollector

    # The facts for this test case.
    t_facts = {
        'fibre_channel_wwn': [
            '2100001B320A2480', '2100001B320A2481', '21000024FF52A9BB'
        ]
    }

    # The collector instance for this test case
    t_collector = FcWwn

# Generated at 2022-06-20 18:00:12.310168
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method tests method collect of class FcWwnInitiatorFactCollector.
    """

    import sys
    import unittest
    import platform

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector

    from ansible_collections.netapp.ontap.plugins.module_utils.netapp.dataontap.facts.facts import NetAppONTAPFacts
    from ansible_collections.netapp.ontap.plugins.module_utils.netapp.dataontap.facts.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # set up our test class
    module = NetAppONTAPFacts()

# Generated at 2022-06-20 18:00:16.925883
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact = FcWwnInitiatorFactCollector()
    facts = fact.collect()
    assert isinstance(facts, dict)
    assert isinstance(facts['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:00:21.667043
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() == {}

# Generated at 2022-06-20 18:00:25.377503
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:51.305643
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test if FcWwnInitiatorFactCollector.collect works as expected
    :return:
    """
    # create fake module
    from ansible.module_utils.facts.utils import AnsibleModule
    fake_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    # create FcWwnInitiatorFactCollector instance and test collect
    collector = FcWwnInitiatorFactCollector(fake_module)
    facts = collector.collect()
    print(facts)

    if sys.platform.startswith('linux'):
        # assume at least one fibre channel wwn
        assert facts['fibre_channel_wwn']
    else:
        # assume no fibre channel wwn
        assert not facts['fibre_channel_wwn']

# Generated at 2022-06-20 18:01:03.916121
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fcwwn = FcWwnInitiatorFactCollector()
    # manually test the result on solaris 11
    #fibre_channel_wwn = fcwwn.collect(module)
    #print fibre_channel_wwn
    # manually test the result on solaris 10
    #fibre_channel_wwn = fcwwn.collect(module)
    #print fibre_channel_wwn
    # manually test the result on linux
    #fibre_channel_wwn = fcwwn.collect(module)
    #print fibre_channel_wwn
    # manually test the result on aix
    fibre_channel_wwn = fcwwn.collect(module)

# Generated at 2022-06-20 18:01:11.448203
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test for method collect of class FcWwnInitiatorFactCollector
    """
    # init a mock module
    module = AnsibleModule(argument_spec={})

    # get collector instance
    fcwwninitiator = FcWwnInitiatorFactCollector()
    fc_facts = fcwwninitiator.collect(module)
    assert 'fibre_channel_wwn' in fc_facts



# Generated at 2022-06-20 18:01:24.518000
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import tempfile
    import shutil

    # we create a fake sys.platform based on the current one
    # this will allow us to check for supported platforms only
    platform = sys.platform
    sys.platform = "linux"
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # store original PATH
    orig_path = os.environ['PATH']
    # store original sys.path
    orig_sys_path = sys.path

    # create a temp dir for testing
    tempdir = tempfile.mkdtemp(dir='/tmp', prefix='ansible-fcwwn-test-')

    # create temp sys.path
    sys.path = [tempdir]

    # create collector

# Generated at 2022-06-20 18:01:28.510991
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an empty ansible module class instance
    module = AnsibleModule(argument_spec=dict())
    result = dict()
    # create an instance of FcWwnInitiatorFactCollector class
    fcwww = FcWwnInitiatorFactCollector()
    # call method collect
    result = fcwww.collect(module=module)
    assert "fibre_channel_wwn" in result


# Generated at 2022-06-20 18:01:32.121117
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts =  FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn', 'test_FcWwnInitiatorFactCollector assert#1 has failed.'

# Generated at 2022-06-20 18:01:39.858230
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import sys
    import unittest

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.params['check_invalid_spec'] = False
            self.run_command_environ_update = {}
            self.run_command_environ_backup = {}
            self.run_command_invocation = None
            self.run_command_supports_check_rc = True
            self.get_bin_path_rc = None
            self.get_bin_path_paths = []
            self.get_bin_path_paths_set = set()
            self.get_bin_path_rc_map = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            self.get_bin_path_path

# Generated at 2022-06-20 18:01:41.297278
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:01:47.734540
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.plugins.modules.system.collect_facts import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts import utils


# Generated at 2022-06-20 18:01:54.712106
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    coll = FcWwnInitiatorFactCollector()
    assert coll.name == 'fibre_channel_wwn'
    assert coll.priority == 10
    assert coll._fact_ids == set()
    assert coll.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-20 18:02:10.225936
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x is not None

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:02:15.010798
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == "fibre_channel_wwn"
    assert fc_wwn.collect(collected_facts=None) != "undefined"

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:02:21.949580
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create an empty module
    module = AnsibleModule(argument_spec={})
    # set custom attributes to support unit tests with the module:
    module.get_bin_path = Mock(return_value=None)
    module.run_command = Mock(return_value=(0, '', ''))
    # execute collect method
    result = FcWwnInitiatorFactCollector().collect(module)
    # assert for some expected content
    assert "fibre_channel_wwn" in result
    assert result['fibre_channel_wwn'] == []


# Generated at 2022-06-20 18:02:33.084624
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.resource_facts import FactsCache
    import tempfile
    import os
    facts_cache = FactsCache(None)
    fact_collector = get_collector_instance(FcWwnInitiatorFactCollector,
                                            facts_cache=facts_cache)
    assert isinstance(fact_collector, FcWwnInitiatorFactCollector)

    fake_fchost = tempfile.mkdtemp(prefix='fake_fchost')
    with open(os.path.join(fake_fchost, 'port_name'), 'w') as f:
        f.write("0x21000014ff586b78\n")

# Generated at 2022-06-20 18:02:37.982611
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts._fact_ids

# Generated at 2022-06-20 18:02:45.565922
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_mock = {
        'get_bin_path': lambda: '/usr/bin'
    }
    test_collector = FcWwnInitiatorFactCollector(module=test_mock)
    module_name = 'fake_module'

    # define test data for AIX
    test_fcinfo_output_aix = '''
AIX vios_aix21 1 7 00F213F1C4C0
Fibre Channel Adapter Information
==================================

fcs0 Available 00-00-00-00-00-00-00-00
fcs1 Available 00-00-00-00-00-00-00-00
fcs2 Available 02-00-1B-00-23-00-01
fcs3 Available 02-00-1B-00-23-00-02
'''
   

# Generated at 2022-06-20 18:02:47.976084
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(
        argument_spec={})
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect(module=module)
    assert facts['fibre_channel_wwn']



# Generated at 2022-06-20 18:02:49.975516
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factCollector = FcWwnInitiatorFactCollector()
    assert factCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:02.301273
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    fc = FcWwnInitiatorFactCollector()
    fc_dict = fc.collect()
    assert fc_dict.get('fibre_channel_wwn', None) is not None
    if sys.platform.startswith('linux'):
        assert len(fc_dict['fibre_channel_wwn']) > 0
    elif sys.platform.startswith('sunos') or sys.platform.startswith('hp-ux') or sys.platform.startswith('aix'):
        assert len(fc_dict['fibre_channel_wwn']) > 0
    else:
        assert len(fc_dict['fibre_channel_wwn']) == 0

# Generated at 2022-06-20 18:03:12.009111
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # instantiate a empty class
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    # run collect
    result = fc_wwn_initiator_fact_collector.collect()

    # result should be a dictionary with key fibre_channel_wwn and a list of WWN as string
    assert isinstance(result, dict)
    assert 'fibre_channel_wwn' in result
    assert isinstance(result['fibre_channel_wwn'], list)
    assert isinstance(result['fibre_channel_wwn'][0], str)
    return None


# Generated at 2022-06-20 18:03:41.313877
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    m = FcWwnInitiatorFactCollector()
    assert m.name == 'fibre_channel_wwn'
    facts = m.collect()
    assert facts is not None
    assert 'fibre_channel_wwn' in facts.keys()


# Generated at 2022-06-20 18:03:52.378665
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test to check method collect of class FcWwnInitiatorFactCollector
    """
    class TestModule(object):
        """
        Class to test method collect of class FcWwnInitiatorFactCollector.
        """
        def __init__(self):
            self.params = {}
            self.exit_json = mock_exit_json
            self.run_command = mock_run_command
            self.get_bin_path = mock_get_bin_path

    def mock_exit_json(self, rc, stdout, stderr):
        """
        Function to test exit_json method of TestModule Class.
        """
        pass

    def mock_run_command(self, cmd):
        """
        Function to test run_command method of TestModule Class.
        """
        return 0, cmd

# Generated at 2022-06-20 18:03:57.860755
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """This is a test of the FcWwnInitiatorFactCollector class"""
    fc_obj = FcWwnInitiatorFactCollector()
    assert fc_obj.name == 'fibre_channel_wwn'
    assert fc_obj._fact_ids == {'fibre_channel_wwn'}


# Generated at 2022-06-20 18:04:07.733842
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Try to run the collect method
    # It will call the module, therefor the module must be available
    from ansible.module_utils.facts.collector import get_collector_facts
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.utils import FactsParams
    import os
    import sys

    # define this module
    test_module = {
        "ANSIBLE_MODULE_ARGS": {
            "gather_subset": [
                "all",
                "hardware"
            ]
        }
    }
    # Make sure we are in a path that contains this module
    path = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-20 18:04:17.679040
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    content of /sys/class/fc_host/*/port_name
    0x21000014ff52a9bb
    """

    testfilecontent = '0x21000014ff52a9bb'
    test_collector = FcWwnInitiatorFactCollector()
    test_collector.content["/sys/class/fc_host/*/port_name"] = testfilecontent
    fc_facts = test_collector.collect()
    assert fc_facts['fibre_channel_wwn'][0] == "21000014ff52a9bb"



# Generated at 2022-06-20 18:04:19.331475
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector is not None


# Generated at 2022-06-20 18:04:25.896872
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Constructor of Class FcWwnInitiatorFactCollector
    """
    fc = FcWwnInitiatorFactCollector()

    assert fc.name == 'fibre_channel_wwn', \
        'Constructor of FcWwnInitiatorFactCollector failed. Expected value "fibre_channel_wwn" for member "name".'

# Generated at 2022-06-20 18:04:32.424651
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Tests if ansible.module_utils.facts.wwn.fc_wwn_initiator.FcWwnInitiatorFactCollector.collect()
        returns the expected facts.
        """
    testobj = FcWwnInitiatorFactCollector()
    testobj.collect()
    facts = testobj.get_facts()
    assert 'fibre_channel_wwn' in facts
    assert len('fibre_channel_wwn') > 0

# Generated at 2022-06-20 18:04:34.198977
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:37.565836
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Create instance of class FcWwnInitiatorFactCollector
    fc = FcWwnInitiatorFactCollector()
    assert type(fc).__name__ == 'FcWwnInitiatorFactCollector'

# Test the collect method of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:05:44.856673
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import collect_facts
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import (
        FcWwnInitiatorFactCollector
    )
    from ansible.module_utils.facts.utils import AnsibleFactCollector


# Generated at 2022-06-20 18:05:52.997234
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a class object and invoke collect
    # results to be checked later
    fcwwn = FcWwnInitiatorFactCollector()
    collected_facts = fcwwn.collect()
    #print (collected_facts)
    assert collected_facts['fibre_channel_wwn'] != ''
    assert type(collected_facts['fibre_channel_wwn']) == list
    assert len(collected_facts['fibre_channel_wwn']) > 0
    assert len(collected_facts['fibre_channel_wwn'][0]) == 16
    # note: test only works on a linux machine with installed fcs and WWN module
    # note: test only works on a sunos machine with installed fcs, fcinfo and WWN module
    # note: test only works on a

# Generated at 2022-06-20 18:06:02.912587
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Testing FcWwnInitiatorFactCollector.collect() method.
    """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    collector.collectors['fibre_channel_wwn'] = FcWwnInitiatorFactCollector()

    (collected_facts, failed, faithfull) = collector.collect(['fibre_channel_wwn'])
    assert collected_facts.keys() == ['fibre_channel_wwn']
    assert len(collected_facts['fibre_channel_wwn']) != 0

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:06:13.291555
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn', \
            "test_FcWwnInitiatorFactCollector: expected name to be 'fibre_channel_wwn'"
    assert fact_collector._fact_ids == set(), \
            "test_FcWwnInitiatorFactCollector: expected _fact_ids to be an empty set"
    assert fact_collector.files is None, \
            "test_FcWwnInitiatorFactCollector: expected files to be None"

# Generated at 2022-06-20 18:06:19.167050
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import pytest  # pylint: disable=import-error
    from ansible.module_utils.facts import FactManager

    # Crate instance of FactManager
    fact_collector = FactManager()
    # Create FcWwnInitiatorFactCollector instance
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    # Set parameters
    setattr(fcwwn_fact_collector, 'name', 'fibre_channel_wwn')
    setattr(fcwwn_fact_collector, '_fact_ids', set())
    setattr(fcwwn_fact_collector, '_module', None)
    setattr(fcwwn_fact_collector, '_collect_subset', None)

    # Call method collect of FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:06:24.817998
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    facts = fc_fact_collector.collect()
    fc_facts = facts['fibre_channel_wwn']
    assert len(fc_facts) > 0


# Generated at 2022-06-20 18:06:30.792151
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """ Unit test for constructor of class FcWwnInitiatorFactCollector """
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()


# Generated at 2022-06-20 18:06:36.029683
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectorModule
    from ansible.module_utils.facts.collector.fc_wwn import FcWwnInitiatorFactCollector

    test_module = CollectorModule(
        argument_spec={},
        supports_check_mode=False)

    fc_wwn_collector = FcWwnInitiatorFactCollector()
    fc_wwn_collector.collect(module=test_module)


# Generated at 2022-06-20 18:06:47.497629
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_coll = FcWwnInitiatorFactCollector()
    fc_facts = fcwwn_coll.collect()
    # At least one WWN is expected for the unit test to succeed
    assert len(fc_facts['fibre_channel_wwn']) >= 1
    # WWN must be of type string
    assert isinstance(fc_facts['fibre_channel_wwn'][0], str)
    # WWN must match the specification (16 hex digits)
    assert len(fc_facts['fibre_channel_wwn'][0]) == 16
    assert fc_facts['fibre_channel_wwn'][0].isalnum()

# Generated at 2022-06-20 18:06:58.915996
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    if 'fibre_channel_wwn' in fc_facts:
        assert isinstance(fc_facts['fibre_channel_wwn'], list)
    # check if WWN is valid
    if 'fibre_channel_wwn' in fc_facts:
        for line in fc_facts['fibre_channel_wwn']:
            assert len(line.rstrip()) == 16
            for l in line.rstrip():
                assert l.lower() in '0123456789abcdef'

# Generated at 2022-06-20 18:09:01.485226
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:09:07.530654
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector