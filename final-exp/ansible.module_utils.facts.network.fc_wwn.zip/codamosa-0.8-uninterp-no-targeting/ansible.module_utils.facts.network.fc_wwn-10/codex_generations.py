

# Generated at 2022-06-20 17:59:33.696870
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test that collection worked.
    """
    from ansible.module_utils.facts.collector import Collector
    test_collector = Collector()
    test_collector.collect_all()
    assert test_collector.collected_facts['ansible_facts']['fibre_channel_wwn']
    for port in test_collector.collected_facts['ansible_facts']['fibre_channel_wwn']:
        assert len(port) == 16

# Generated at 2022-06-20 17:59:47.150207
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

    test_data_path = os.path.join(module_utils.get_data_root(), 'sys_class_fc_host_')
    if os.path.exists(test_data_path):
        test_data_path = os.path.join(test_data_path, 'port_name')
    else:
        test_data_path = os.path.join(module_utils.get_data_root(), 'fc_facts')

    test_fc_facts = FcWwnInitiatorFactCollector()
    fc_facts = test_fc_facts.collect(module=None, collected_facts=fc_facts)

# Generated at 2022-06-20 17:59:50.319588
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwnfc = FcWwnInitiatorFactCollector()
    fcwwn_facts = fcwwnfc.collect()
    assert 'fibre_channel_wwn' in fcwwn_facts

# Generated at 2022-06-20 18:00:00.262464
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()


if __name__ == '__main__':
    # Unit test this module
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', 'network'], type='list')
        ),
        supports_check_mode=True
    )

    # Collect and process all facts
    facts_dict = {}

# Generated at 2022-06-20 18:00:12.995112
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule:
        def __init__(self):
            self.params = {}
            self.failed = False
            self.run_command_data = []

        def run_command(self, cmd):
            data = self.run_command_data.pop(0)
            return data[0], data[1], data[2]

        def fail_json(self, **kwargs):
            self.failed = True

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'ioscan':
                ret = 'loscan'
            elif name == 'fcmsutil':
                ret = 'fcmsutil'
            elif name == 'lsdev':
                ret = 'lsdev'
            elif name == 'lscfg':
                ret = 'lscfg'
            el

# Generated at 2022-06-20 18:00:19.109960
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    collector = FcWwnInitiatorFactCollector()
    fc_facts = collector.collect()
    # Note: Values here depend on the host system and may need to be adjusted
    assert fc_facts['fibre_channel_wwn'] == ['500507680cxxxxxx'] or fc_facts['fibre_channel_wwn'] == ['21000014xxxxxx']

# Generated at 2022-06-20 18:00:30.525919
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os

    class TestModule(object):
        def __init__(self, opt_bin_path, bin_path):
           self.params = {'opt_bin_path': opt_bin_path, 'bin_path': bin_path}

        def get_bin_path(self, name, opt_dirs=None):
            if name == 'fcinfo' and opt_dirs == None:
                return self.bin_path + '/fcinfo'
            elif name == 'lsdev' and opt_dirs == None:
                return self.bin_path + '/lsdev'
            elif name == 'lscfg' and opt_dirs == None:
                return self.bin_path + '/lscfg'

# Generated at 2022-06-20 18:00:42.628956
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import get_collector_by_name
    from ansible.module_utils.facts.utils import AnsibleCollector

    FcWwnInitiatorFactCollector = get_collector_by_name(FcWwnInitiatorFactCollector.name)
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    ansible_collector_obj = AnsibleCollector(FcWwnInitiatorFactCollector)

    # Create a mock module object
    class MockModule(object):
        pass
    mock_module = MockModule()

    # Create a mock command module object
    class MockRunCmd(object):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 18:00:49.074425
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.resources.sysinfo.fc_wwn_initiator import FcWwnInitiatorFactCollector

    my_collector = FcWwnInitiatorFactCollector()
    my_collector.collect()


# Generated at 2022-06-20 18:01:00.501830
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import variable_manager

    fc_fact_tpl = """
{
    "fibre_channel_wwn": [
        "21000024ff8155f6"
    ]
}
"""

    fc_facts = Collector()
    fc_facts.collect(module=None, collected_facts=None)
    assert fc_facts.get_facts() == variable_manager.VarsModule().parse(fc_fact_tpl)



# Generated at 2022-06-20 18:01:15.088313
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_collected_facts = FcWwwInitiatorFactCollector()
    assert fcwwn_collected_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:23.041557
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """

    class MockModule(object):
        def get_bin_path(self, arg):
            """
            Mock method of get_bin_path.
            """
            return 'MOCK_BIN_PATH'

        def run_command(self, arg):
            """
            Mock method of run_command.
            """
            return 0, '', ''

    my_obj = FcWwnInitiatorFactCollector()
    my_obj.collect(MockModule())

# Generated at 2022-06-20 18:01:32.613290
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.util_dummy import AnsibleModule
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.processor import get_processor_instance

    # mocks for AnsibleModule
    _ansible_module = AnsibleModule(
        argument_spec={}
    )

    # mock for get_collector_instance
    _fc_collector = get_collector_instance(FcWwnInitiatorFactCollector, _ansible_module)

    # mock for get_processor_instance
    _fc_processor = get_processor_instance(_ansible_module)

    # run method collect of class FcWwnInitiatorFactCollector
    facts = _fc_collector.collect(_ansible_module, {})



# Generated at 2022-06-20 18:01:36.476277
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collected_facts = {}
    fc_wwn_obj = FcWwnInitiatorFactCollector(collected_facts)
    assert fc_wwn_obj.name == 'fibre_channel_wwn'



# Generated at 2022-06-20 18:01:42.242095
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'
    assert a._fact_ids == set()


# Generated at 2022-06-20 18:01:51.978454
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a mock module
    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': ['!all', 'fibre_channel_wwn']}

    mock_module = MockModule()

    # Create a mock class with a mock method
    class MockCollector(BaseFactCollector):
        def __init__(self, module):
            super(MockCollector, self).__init__(module)
            self.name = 'Mock_fact'
            self._fact_ids = set()

        def collect(self, module, collected_facts):
            fact = dict()
            fact['Mock_fact'] = 'Mock_value'
            collected_facts['Mock_fact'] = fact
            return collected_facts

    # Mock the fact collectors that are returned with the module

# Generated at 2022-06-20 18:02:02.726507
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # make dummy module object
    class TestModule:
        def __init__(self, executed_module_name, params):
            self.params = params
            self.failed = False
            self.executed_commands = []

        def get_bin_path(self, executable, opt_dirs=[]):
            # print("get_bin_path:", executable, opt_dirs)
            return executable

        def run_command(self, cmd):
            print("run_command:", cmd)
            self.executed_commands.append(cmd)
            return 0, "", ""

    # run method collect
    collector = FcWwnInitiatorFactCollector()
    print("collect facts")
    facts = collector.collect(TestModule('/bin/ansible', {}))
    print("collected facts:", facts)

# Generated at 2022-06-20 18:02:09.434925
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    c = FcWwnInitiatorFactCollector('FcWwnInitiatorFactCollector')
    assert c.collect() == {'fibre_channel_wwn': []}

# unit test execution
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:02:11.126919
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.collect() == {}

# Generated at 2022-06-20 18:02:17.803591
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Test constructor of class FcWwnInitiatorFactCollector
    :return:
    """

    # If constructor does not fail, return True
    try:
        obj = FcWwnInitiatorFactCollector()
        return True
    except:
        return False


# Generated at 2022-06-20 18:02:51.359163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import tempfile
    import pytest
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.six

    # example contents of /sys/class/fc_host/*/port_name:
    # 0x00000002530a5c39
    # 0x00000002530a5c3a
    if platform.system() == "Linux":
        with tempfile.TemporaryDirectory() as tempdir:
            for i in range(0,2):
                os.makedirs(os.path.join(tempdir, "fc_host", "host" + str(i)))
                filename = os.path.join(tempdir, "fc_host", "host" + str(i), "port_name")
               

# Generated at 2022-06-20 18:02:56.893428
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert '/sys/class/fc_host/*/port_name' in collector.files

# Generated at 2022-06-20 18:03:00.446594
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()

    # fs.file_max_fact value should be int
    assert type(obj).__name__ == "FcWwnInitiatorFactCollector"

# Generated at 2022-06-20 18:03:03.566468
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:03:04.960706
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:03:13.252385
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collectors.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    import ansible.module_utils.facts.collectors
    ansible.module_utils.facts.collectors.os = 'linux'
    module = AnsibleFactCollector()
    collector = get_collector_instance(FcWwnInitiatorFactCollector)
    # override contents of /sys/class/fc_host/host*/port_name
    collector._read_file_lines = lambda line: get_file_lines_mock(line)


# Generated at 2022-06-20 18:03:17.712664
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = fact_collector.collect()
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-20 18:03:26.893726
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import get_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3


# Generated at 2022-06-20 18:03:33.795245
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector.
    """
    FcWwnInitiatorFactCollector._fact_ids = set()
    module = MagicMock()
    fc_facts = {}
    collected_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    if sys.platform.startswith('linux'):
        for fcfile in glob.glob('/sys/class/fc_host/*/port_name'):
            for line in get_file_lines(fcfile):
                fc_facts['fibre_channel_wwn'].append(line.rstrip()[2:])

# Generated at 2022-06-20 18:03:45.584741
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    test_result = {}
    test_result['fibre_channel_wwn'] = []
    if platform.system().startswith('SunOS'):
        test_result['fibre_channel_wwn'].append("10000090fa1658de")
    elif platform.system().startswith('AIX'):
        test_result['fibre_channel_wwn'].append("10000090FA551509")
    elif platform.system().startswith('HP-UX'):
        test_result['fibre_channel_wwn'].append("50060B00006975EC")

# Generated at 2022-06-20 18:04:32.878224
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert c._fact_ids != None

# Generated at 2022-06-20 18:04:33.685266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TBD
    assert 1 == 0

# Generated at 2022-06-20 18:04:37.369851
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    collector = Collector()
    facts = collector.collect(['fibre_channel_wwn'])
    assert facts is not None
    assert 'fibre_channel_wwn' in facts
    assert facts['fibre_channel_wwn'] is not None

# Generated at 2022-06-20 18:04:39.934055
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_init = FcWwnInitiatorFactCollector()



# Generated at 2022-06-20 18:04:42.186957
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    newobj = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == newobj.name



# Generated at 2022-06-20 18:04:45.810082
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    connector = FcWwnInitiatorFactCollector()
    facts = connector.collect()
    assert type(facts) is dict
    assert 'fibre_channel_wwn' in facts.keys()

# Generated at 2022-06-20 18:04:53.126083
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class Module:
        def get_bin_path(self, name):
            return name
    class Facts:
        facts = {}
    m = Module()
    f = Facts()
    fcwwn = FcWwnInitiatorFactCollector(m, f)

    fcwwn.collect()
    assert 'fibre_channel_wwn' in f.facts


if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:05:05.133317
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self, platform, virtual):
            self.platform = platform
            self.virtual = virtual
            self.params = {}
            if sys.version_info[0] < 3:
                self.params['_ansible_sysroot'] = to_bytes(sysroot)
            else:
                self.params['_ansible_sysroot'] = sysroot


# Generated at 2022-06-20 18:05:09.972403
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fcwwn.name
    assert '' == fcwwn.collect()['fibre_channel_wwn'][0]

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:05:13.146957
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collector == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:51.346939
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:56.664630
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact = FcWwnInitiatorFactCollector()
    result = fact.collect()
    # check that fibre_channel_wwn contains at least one entry
    assert len(result['fibre_channel_wwn']) > 0

# Generated at 2022-06-20 18:07:10.612653
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsHelper
    import platform

    def is_hpux():
        if "hp-ux" in platform.system().lower():
            return True
        else:
            return False

    def is_aix():
        if "aix" in platform.system().lower():
            return True
        else:
            return False

    def is_solaris():
        if "sunos" in platform.system().lower():
            return True
        else:
            return False

    def is_linux():
        if "linux" in platform.system().lower():
            return True
        else:
            return False

    # mock get_file_lines, get_bin_path and run_command for linux


# Generated at 2022-06-20 18:07:21.016916
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import os
    import unittest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import pprint

    # create a test class
    class TestModule:

        def __init__(self):
            self.run_command_calls = 0
            self.command_string = ''
            self.module_args = ''
            self.return_values = []

        def get_bin_path(self, cmd, opt_dirs=[]):
            if cmd == 'fcmsutil':
                # test for hp-ux
                if os.path.isfile(os.path.expandvars('$HOME/fcmsutil')):
                    return

# Generated at 2022-06-20 18:07:26.531159
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_wwn = FcWwnInitiatorFactCollector()
    fc = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    assert  fc_wwn.collect() == fc

# Generated at 2022-06-20 18:07:29.709349
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x
    assert not x._fact_ids
    assert x.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:07:33.439187
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:38.935202
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_col = FcWwnInitiatorFactCollector()
    assert fact_col.name == 'fibre_channel_wwn'
    assert fact_col._fact_ids == set(['fibre_channel_wwn'])


# Generated at 2022-06-20 18:07:48.295398
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector

    Input:
    - no argument

    Expected output:
    - instance of FcWwnInitiatorFactCollector
    """

    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    fwf = FcWwnInitiatorFactCollector()
    assert isinstance(fwf, FcWwnInitiatorFactCollector)

# Generated at 2022-06-20 18:07:57.843584
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Here we create and initialise a FcWwnInitiatorFactCollector class instance
    by invoking the collect method to get the facts.
    """
    fc_init = FcWwnInitiatorFactCollector()
    fc_init_facts = fc_init.collect()
    assert isinstance(fc_init_facts, dict)
    assert len(fc_init_facts['fibre_channel_wwn']) > 0