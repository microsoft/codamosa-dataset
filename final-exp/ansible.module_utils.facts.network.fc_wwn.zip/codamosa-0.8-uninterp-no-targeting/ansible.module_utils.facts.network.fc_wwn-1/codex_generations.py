

# Generated at 2022-06-20 17:59:34.241715
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_initiator = FcWwnInitiatorFactCollector()
    print("asserting name")
    assert fc_initiator.name == "fibre_channel_wwn"
    print("asserting no facts set")
    assert len(fc_initiator._fact_ids) == 0
    print("asserting name is in valid names")
    assert fc_initiator.name in fc_initiator.valid_names


# Generated at 2022-06-20 17:59:47.224107
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os

    class FakeModule(object):
        class FakeResult(object):
            rc = 0
            stdout = ''
            stderr = ''

        def __init__(self, params=None):
            self.params = params
            self.run_command_count = 0

        def get_bin_path(self, *args, **kwargs):
            return os.path.realpath('/bin/ls')

        def run_command(self, cmd, *args, **kwargs):
            self.run_command_count += 1
            if 'linux' in cmd:
                if self.run_command_count == 1:
                    return FakeResult('''0x21000014ff52a9bb''')

# Generated at 2022-06-20 17:59:49.515820
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:57.547201
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {'fibre_channel_wwn': []}
    sys.modules['ansible'].run_command = lambda *args, **kwargs: ('', '', '')
    sys.modules['ansible'].get_file_lines = lambda *args, **kwargs: ()
    sys.modules['ansible'].get_bin_path = lambda *args, **kwargs: None
    if sys.platform.startswith('linux'):
        sys.modules['ansible'].glob.glob = lambda *args, **kwargs: ('')
    test_fc_facts = FcWwnInitiatorFactCollector().collect()
    assert test_fc_facts == fc_facts

# Generated at 2022-06-20 18:00:03.057716
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    myobj = FcWwnInitiatorFactCollector()
    # check if object name is as expected
    assert myobj.name == 'fibre_channel_wwn', "Failed to set object name"

# Generated at 2022-06-20 18:00:10.452996
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    fc_wwn_collector = FcWwnInitiatorFactCollector()
    fc_wwns = fc_wwn_collector.collect()

    assert 'fibre_channel_wwn' in fc_wwns
    assert type(fc_wwns['fibre_channel_wwn']) is list

# Generated at 2022-06-20 18:00:20.067741
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector_collect = FcWwnInitiatorFactCollector()
    subset = {'lsdev-Cc_adapter_-l_fcs*': 'fcs3 Available 00-08 fcs  Fibre Channel SCSI Adapter',
              'lscfg_-vl_fcs3': 'Network Address.............10000090FA551509'}
    collected_facts = {'ansible_facts': {'fibre_channel_wwn': []}}
    expected_facts = {'ansible_facts': {'fibre_channel_wwn': ['10000090FA551509']}}
    FcWwnInitiatorFactCollector_collect._module_mock = MagicMock()
    FcWwnInitiatorFactCollector_collect._module_mock.run_command = Magic

# Generated at 2022-06-20 18:00:26.938285
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    FAKE_CONTENTS_1 = '0x21000014ff52a9bb'
    FAKE_CONTENTS_2 = '0x21000014ff52a9bb\n0x21000014ff52a9cc'

    test_facts = dict()

    test_facts['ansible_fibre_channel_wwn'] = []

    from ansible.module_utils.facts import collector

    fc_collector = FcWwnInitiatorFactCollector(collected_facts=test_facts)
    assert isinstance(fc_collector, FcWwnInitiatorFactCollector) is True

    test_module = collector.get_fake_module(test_facts)

    # test with one WWN value
    collected_fc_facts = fc_collector.collect(module=test_module)
   

# Generated at 2022-06-20 18:00:34.262928
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector

    class FcWwnModuleMocker(object):
        def __init__(self):
            self.params = dict()
            self.exit_json = dict()
            self.name = 'fibre_channel_wwn'

        def get_bin_path(self, bin_path, opt_dirs=[]):
            if bin_path == 'fcinfo':
                return 'fcinfo'
            elif bin_path == 'ioscan':
                return 'ioscan'
            elif bin_path == 'fcmutil':
                return 'fcmutil'
            elif bin_path == 'lsdev':
                return 'lsdev'
            elif bin_path == 'lscfg':
                return 'lscfg'



# Generated at 2022-06-20 18:00:37.316868
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
	FcWwnInitiatorFactCollector()
	
test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:00:56.128314
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert fc.collect() == {}

# Generated at 2022-06-20 18:01:04.139673
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector

    # Create instance of FcWwnInitiatorFactCollector
    fc_wwn_init_fc = FcWwnInitiatorFactCollector()
    # Call collect method
    fc_wwn_init_fc.collect()
    # Create instance of FactsCollector
    facts = FactsCollector()
    # Call add_fact_collector method with instance of FcWwnInitiatorFactCollector
    facts.add_fact_collector(fc_wwn_init_fc)

    assert len(facts.get_facts())

# Generated at 2022-06-20 18:01:08.327365
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Very Ghetto way of testing, since it depends on calling the real collect method
    from ansible.module_utils.facts.collector import collector_module
    assert collector_module().get_collection()

# Generated at 2022-06-20 18:01:11.563745
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """

    fcs = FcWwnInitiatorFactCollector()
    assert fcs.collect() == {}

# Generated at 2022-06-20 18:01:17.290790
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = AnsibleModuleMock()
    test_module.mk_command("fcinfo")
    test_module.mk_command("fcmsutil")
    test_module.mk_command("lscfg")
    test_module.mk_command("lsdev")
    test_module.mk_command("ioscan")
    test_module.run_command.return_value = (0, "0x5000c5007dbd13c0\n0x5000c5007dbd13c1", "")
    test_module.run_command.return_value = (0, "HBA Port WWN: 10000090fa1658de\nHBA Port Symbolic Name: ", "")

# Generated at 2022-06-20 18:01:21.703374
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-20 18:01:26.111545
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Without params:
    >>> collector = FcWwnInitiatorFactCollector()
    >>> collector.collect()
    {'fibre_channel_wwn': [u'0x21000014ff52a9bb']}
    """
    pass

# Generated at 2022-06-20 18:01:30.548163
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    assert fc.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-20 18:01:40.149386
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # test fc_facts
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append("21000014ff52a9bb")

    # test class
    class TestModule:
        def get_bin_path(self, command, opt_dirs=None):
            """test method to get the binary path for a give command"""
            return None

        def run_command(self, arg):
            """test method to run a command"""
            return 0, '',''

    testmodule = TestModule()

    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector(testmodule)
    result = test_FcWwnInitiatorFactCollector.collect()

    #

# Generated at 2022-06-20 18:01:44.521219
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert not x._fact_ids

# Generated at 2022-06-20 18:02:10.272080
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    FcWwnInitiatorFactCollector_obj = FcWwnInitiatorFactCollector()
    fc_facts = FcWwnInitiatorFactCollector_obj.collect()
    print(fc_facts)
    assert 'fibre_channel_wwn' in fc_facts.keys()

if __name__ == "__main__":
    import sys
    # sys.exit(test_FcWwnInitiatorFactCollector_collect())
    fc_facts = FcWwnInitiatorFactCollector().collect()
    print(fc_facts)

# Generated at 2022-06-20 18:02:15.411985
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    m = FcWwnInitiatorFactCollector()
    assert m.name == 'fibre_channel_wwn'
    # empty list
    assert m._fact_ids == set()


# Generated at 2022-06-20 18:02:19.293470
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    my_collector = FcWwnInitiatorFactCollector()
    assert my_collector.name == 'fibre_channel_wwn'
    assert my_collector._fact_ids == set()


# Generated at 2022-06-20 18:02:32.056691
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.system import SystemFactCollector

    class TestModule:
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, *args, **kwargs):
            if args[0] == 'lsdev':
                return '/usr/sbin/lsdev'
            if args[0] == 'lscfg':
                return '/usr/sbin/lscfg'
            if args[0] == 'ioscan':
                return '/usr/sbin/ioscan'
            if args[0] == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            else:
                return None


# Generated at 2022-06-20 18:02:39.124916
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry

    class MockModule():
        """The mock ansible module that's used for testing."""
        class MockRunCommand():
            def __init__(self, rc, fcinfo_out, err):
                self.rc = rc
                self.fcinfo_out = fcinfo_out
                self.err = err

            def run_command(self, cmd):
                return (self.rc, self.fcinfo_out, self.err)

        def __init__(self):
            self.get_bin_path = MockRunCommand(0, '', '')
            self.run_command = MockRunCommand(0, '', '')

    mock_module = MockModule()
    collector = FcWwnInitiatorFactCollector(mock_module)

# Generated at 2022-06-20 18:02:50.878731
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.network.fibre_channel import FcWwnInitiatorFactCollector

    # create a fake module object
    module = AnsibleFakeModule()

    # create a FactsCollector object and put our collector in it
    collector = FactsCollector(module)
    collector.add_collector(FcWwnInitiatorFactCollector)

    # calling the method collect will execute the code of the collectors
    # and update the FactsCollector.facts dict
    collector.collect()

    # now we can check the content of FactsCollector.facts
    # we expect some facts about network interfaces
    assert(collector.facts['network'] is not None)
    # and no fact about Fibre Channel WWN

# Generated at 2022-06-20 18:02:55.735983
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'
    assert '_fact_ids' in result.__dict__

# Generated at 2022-06-20 18:03:01.460958
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''
    Test the constructor of class FcWwnInitiatorFactCollector
    '''
    fc_initiator = FcWwnInitiatorFactCollector()
    assert fc_initiator.name == 'fibre_channel_wwn'
    assert fc_initiator._fact_ids == set()


# Generated at 2022-06-20 18:03:05.671605
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    expected = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    assert result == expected

# Generated at 2022-06-20 18:03:08.811691
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create an object of class FcWwnInitiatorFactCollector
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()


# Generated at 2022-06-20 18:03:34.775460
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    :return:
    """

    from ansible.module_utils.facts.collector.solaris import SolarisDMI
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    my_obj = FcWwnInitiatorFactCollector()
    my_obj.collect()

# Generated at 2022-06-20 18:03:37.427037
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:03:42.166266
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for constructor of class FcWwnInitiatorFactCollector.
    """
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:53.152670
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for class FcWwnInitiatorFactCollector
    """

    def fake_file_lines():
        """
        This function is used to replace get_file_lines in order to
        test the class FcWwnInitiatorFactCollector.
        """

        return ["0x21000014ff52a9bb\n", "0x21000014ff52a9bc\n"]

    class FakeModule(object):

        def __init__(self):
            self.run_command_exit_status = 0
            self.run_command_out = None


# Generated at 2022-06-20 18:04:04.797137
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    o = FcWwnInitiatorFactCollector()
    o._module = FakeModule()
    o._module.run_command = lambda x: ('', """
                                       HBA Port WWN: 20000000c97419ec
                                       HBA Port WWN: 21000014ff52a9bb
                                       HBA Port WWN: 20000000c97419ef
                                       HBA Port WWN: 21000014ff52a9be
                                       HBA Port WWN: 20000000c97419ee
                                       HBA Port WWN: 21000014ff52a9bd
                                       HBA Port WWN: 20000000c97419ed
                                       HBA Port WWN: 21000014ff52a9bc
                                       HBA Port WWN: 20000000c97419f0
                                       """.strip(), '')
   

# Generated at 2022-06-20 18:04:17.849003
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This test method can be used to unit test the method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils import facts
    from ansible.module_utils.facts import utils
    from ansible.module_utils._text import to_bytes
    import json
    # create a basic class with the collector to be tested
    test_fact_collector = FcWwnInitiatorFactCollector()
    # create a basic module mock to be used
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = Mock(side_effect=self.exit_json)
            self.exit_json = Mock()
            # create a basic ans

# Generated at 2022-06-20 18:04:26.414849
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel import FcWwnInitiatorFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg1, opt_dirs=None):
            if arg1 == "fcinfo":
                return "/usr/sbin/fcinfo"
            if arg1 == "lsdev":
                return "/usr/sbin/lsdev"
            if arg1 == "lscfg":
                return "/usr/sbin/lscfg"

# Generated at 2022-06-20 18:04:37.092324
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test of method collect of class FcWwnInitiatorFactCollector.
    Note: collect method requires an ansible_module_init argument,
    so this test just asserts that the method does not return None,
    and does not raise an exception.
    If a proper test method is defined, this should probably be removed.
    """
    collector = FcWwnInitiatorFactCollector()
    print("Testing FcWwnInitiatorFactCollector_collect")
    try:
        data = collector.collect()
        print("data:\n" + str(data))
        assert data != None
    except Exception as e:
        print("Caught exception: " + str(e))
        print("Failed test FcWwnInitiatorFactCollector_collect")
        assert False

# Generated at 2022-06-20 18:04:49.217627
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    import os

    def myfunc(module):
        return (0, '', '')

    def myfunc_which(module, opt_dirs=None):
        return "/usr/sbin/fcinfo"

    AnsibleFactCollector.get_file_lines = lambda self, filename: ['0x21000014ff52a9bb']
    AnsibleFactCollector.run_command = myfunc
    AnsibleFactCollector.get_bin_path = myfunc_which
    os.path.isfile = lambda self: True

    fc_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:04:56.266273
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    sys.modules['ansible.module_utils.facts.collector.BaseFactCollector'] = BaseFactCollector
    sys.modules['ansible.module_utils.facts.Collector'] = Collector
    fc_collector = FcWwnInitiatorFactCollector()
    print(fc_collector.collect())

# Generated at 2022-06-20 18:05:54.640713
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import platform
    import textwrap
    import unittest

    class FakeModule(object):
        def __init__(self, platform, osname):
            self.sys_platform = platform
            self.os_name = osname
            self.fake_cmd_result = {}

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable.startswith('lsdev'):
                return 'lsdev'
            if executable.startswith('ioscan'):
                return 'ioscan'
            if executable.startswith('fcmsutil'):
                return 'fcmsutil'
            if executable.startswith('lscfg'):
                return 'lscfg'
            if executable.startswith('fcinfo'):
                return 'fcinfo'


# Generated at 2022-06-20 18:05:58.671072
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids == set()

# Generated at 2022-06-20 18:06:04.422702
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import os
    import sys
    import tempfile
    import shutil
    import pytest

    # Create a temporary directory and add it to the module search path
    test_dir = tempfile.mkdtemp()
    sys.path.append(test_dir)
    test_dir = os.path.realpath(test_dir)

    # Create a fake module in the temporary directory
    module = 'fake_ansible_module.py'

# Generated at 2022-06-20 18:06:10.344501
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    initiator_facts = FcWwnInitiatorFactCollector.collect(None, None)
    assert 'fibre_channel_wwn' in initiator_facts
    assert '50060b00006975ec' in initiator_facts['fibre_channel_wwn']

# Generated at 2022-06-20 18:06:14.483436
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:06:21.570502
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test for constructor of class FcWwnInitiatorFactCollector
    """

    fc_wwn_init_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_init_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:23.055319
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:26.971168
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert facts
    assert isinstance(facts['fibre_channel_wwn'], list)
    assert facts['fibre_channel_wwn'][0].startswith('21000014ff')

# Generated at 2022-06-20 18:06:36.311861
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test for facts for fibre channel wwn initiator.
    """
    import platform
    import re
    import unittest

    module_mock = unittest.mock.MagicMock()
    module_mock.debug = False
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.return_value = ''

    fc = FcWwnInitiatorFactCollector(module=module_mock)

    if 'sunos' in platform.system().lower():
        # SunOS
        module_mock.get_bin_path.return_value = '/usr/sbin/fcinfo'

# Generated at 2022-06-20 18:06:45.433933
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    import sys
    import platform
    sys.modules['platform'] = platform
    sys.platform = 'linux'
    assert isinstance(FcWwnInitiatorFactCollector(), FcWwnInitiatorFactCollector)
    assert isinstance(FcWwnInitiatorFactCollector().collect(), dict)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:08:53.396038
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Returns a dictionary with the following keys:

    fibre_channel_wwn

    Example:
    {'fibre_channel_wwn': ['50060b00006975ec']}
    """

    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector

    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = dict()
            self.run_command_calls = list()


# Generated at 2022-06-20 18:08:56.916535
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    if sys.platform.startswith('linux'):
        FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-20 18:09:02.482259
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    fact_collector = FcWwnInitiatorFactCollector(module)
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()
    assert fact_collector._platform_fact_class == None

# Generated at 2022-06-20 18:09:04.214213
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fci = FcWwnInitiatorFactCollector()
    assert fci.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:09:14.226555
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Create a temporary file with a known data
    import tempfile
    f = tempfile.NamedTemporaryFile("w", prefix='ansible_collected_test_', delete=True)
    f.write("0x21000014ff52a9bb\n")
    f.seek(0)

    import subprocess
    class FakeModule:
        def get_bin_path(self, arg1, arg2=None):
            if arg1 == "fcinfo":
                f.seek(0)
                p = subprocess.Popen(['cat', f.name],
                                     stdout=subprocess.PIPE)
                return p.stdout

        def run_command(self, cmd):
            return 0, "0x21000014ff52a9bb", ""

    from ansible.module_utils.facts import collector