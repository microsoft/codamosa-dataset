

# Generated at 2022-06-20 17:59:28.230135
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids is None

# Generated at 2022-06-20 17:59:33.828266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fakeModule = FakeFcInitiatorModule()
    fcCollector = FcWwnInitiatorFactCollector()
    fcCollector.collect(fakeModule)
    assert fakeModule.ansible_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']


# Generated at 2022-06-20 17:59:39.427982
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector
    # test: assert name == 'fibre_channel_wwn'
    assert fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:49.714195
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.fibre_channel_wwn import FcWwnInitiatorFactCollector

    module = MagicMock()

    if sys.platform.startswith('linux'):
        module.run_command.return_value = 0, 'fcinfo_out', 'err'
        module.get_bin_path.return_value = 'cmd'
        FcWwnInitiatorFactCollector.collect(module=module)
        fcinfo_cmd = "cmd hba-port"
        module.get_bin_path.assert_called_with('fcinfo')
        module.run_command.assert_called_with(fcinfo_cmd)

# Generated at 2022-06-20 17:59:55.041910
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    facts_collector = FcWwnInitiatorFactCollector()
    assert facts_collector.name == 'fibre_channel_wwn'
    assert facts_collector._fact_ids == set()


# Unit test to test collect() method of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 17:59:58.818871
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:12.185834
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Example file /sys/class/fc_host/*/port_name
    # 0x21000014ff52a9bb
    # 0x20000014ff52a9bc
    #
    # Output of collect expected:
    # 'fibre_channel_wwn': [
    #    '21000014ff52a9bb',
    #    '20000014ff52a9bc'
    #]
    import mock

    module_mock = mock.Mock()

    """
    mock module.run_command()
    """
    # mock for linux
    module_mock.run_command().return_value = (0, '', '')
    module_mock.get_bin_path.return_value = None

# Generated at 2022-06-20 18:00:16.400262
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:21.244842
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_module = MockModule()
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector(test_module)
    fc_facts = test_FcWwnInitiatorFactCollector.collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts
    assert fc_facts['fibre_channel_wwn'] == ['346d8ef9ee9e9e71']


# Generated at 2022-06-20 18:00:24.527821
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_initiators = FcWwnInitiatorFactCollector()
    assert fcwwn_initiators.name == 'fibre_channel_wwn'
    assert fcwwn_initiators.collect() == {}

# Generated at 2022-06-20 18:00:48.608871
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 18:00:55.196642
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:01:05.207352
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # init collector
    fact_collector = FcWwnInitiatorFactCollector()
    # test collect on linux
    assert fact_collector.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb', '21000014ffffa9bb']}
    # test collect on solaris
    assert fact_collector.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb']}
    # test collect on aix
    assert fact_collector.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb']}
    # test collect on hp-ux
    assert fact_collector.collect() == {'fibre_channel_wwn': ['21000014ff52a9bb']}
    

# Generated at 2022-06-20 18:01:14.892172
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Tests FcWwnInitiatorFactCollector.collect method.

    :param module_mock: mock of ansible.module_utils.basic.AnsibleModule class
    :returns result: tuple with passed and failed test names
    """
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts.collector import FactsCollector

    class ModuleMock(AnsibleModule):
        def get_bin_path(self, arg, opt_dirs=[]):
            "Mock for get_bin_path method"
            return 'mocked_output'


# Generated at 2022-06-20 18:01:24.392551
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Mimic module input parameters, for collecting facts
    module_args = {}
    ansible_facts = {}
    # Instantiate FcWwnInitiatorFactCollector object
    fc_wwn_init_facts = FcWwnInitiatorFactCollector(module_args, ansible_facts)
    # invoke the method FcWwnInitiatorFactCollector.collect()
    fc_wwn_init_facts.collect()

if __name__ == '__main__':
    # Unit test FcWwnInitiatorFactCollector.collect method
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:01:30.095771
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.processor import FactsProcessor
    from ansible.module_utils.facts import ModuleFactsCollector
    import pprint
    import os

    if os.path.exists("/sys/class/fc_host"):
        os.environ['PATH'] = os.environ['PATH'] + os.pathsep + "/bin"
        c = Collector()
        f = FactsProcessor()
        m = ModuleFactsCollector()

        mod = ""
        class Args(object):
            path = "/sys/class/fc_host"

        module = Args()


# Generated at 2022-06-20 18:01:30.990004
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    assert True

# Generated at 2022-06-20 18:01:38.001444
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """
    fc_facts = FcWwnInitiatorFactCollector.collect(None, {})
    assert len(fc_facts) == 1
    assert 'fibre_channel_wwn' in fc_facts.keys()
    assert len(fc_facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-20 18:01:44.521315
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print ("Constructor test for class FcWwnInitiatorFactCollector")
    fc_wwn = FcWwnInitiatorFactCollector()
    print ("fc_wwn = " + str(fc_wwn))


# Generated at 2022-06-20 18:01:49.132897
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts._fact_ids

# Unit test to check the overridden collect() method of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:02:11.042531
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()



# Generated at 2022-06-20 18:02:22.266866
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, a, b=[]):
            if a == 'lsdev':
                return 'lsdev'
            elif a == 'lscfg':
                return 'lscfg'
            elif a == 'ioscan':
                return 'ioscan'
            elif a == 'fcmsutil':
                return 'fcmsutil'
            elif a == 'fcinfo':
                return 'fcinfo'
            return None

# Generated at 2022-06-20 18:02:27.250435
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(dict())
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect(module)
    assert dict == type(result)
    assert 2 == len(result)
    for k, v in result.items():
        assert isinstance(k, str)
        assert isinstance(v, list)

# Generated at 2022-06-20 18:02:29.025588
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:02:35.163269
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()
    assert fc.collect() == {'fibre_channel_wwn': []}

# Generated at 2022-06-20 18:02:37.680690
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:50.679996
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # build module object
    module = DummyModule()
    # build collector object
    collector = FcWwnInitiatorFactCollector(module=module)
    # run collect method
    result = collector.collect()

    # assert fc_facts is not None
    assert result is not None
    # assert fc_facts is not empty
    assert len(result) > 0
    # assert fc_facts has 'fibre_channel_wwn' as key
    assert all(item in result for item in ['fibre_channel_wwn'])
    # assert fibre_channel_wwn is not None
    assert result['fibre_channel_wwn'] is not None
    # assert fibre_channel_wwn is not empty
    assert len(result['fibre_channel_wwn']) > 0

# Unit

# Generated at 2022-06-20 18:02:55.511192
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:01.647682
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect(None, None)
    assert type(fc_facts['fibre_channel_wwn']) == list
    assert len(fc_facts['fibre_channel_wwn']) > 0
    assert max([len(wwn) for wwn in fc_facts['fibre_channel_wwn'] if wwn]) == 16

# Generated at 2022-06-20 18:03:05.817526
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factCollector = FcWwnInitiatorFactCollector()
    assert factCollector.name == 'fibre_channel_wwn'
    assert factCollector._fact_ids == set()

# Generated at 2022-06-20 18:03:28.548528
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:03:33.852410
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fcwwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fcwwn_initiator_fact_collector._fact_ids == set()
    assert fcwwn_initiator_fact_collector.collect() == {}

# Generated at 2022-06-20 18:03:38.612424
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Sample output from method collect
    fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb', '21000014ff52a9bc']}

    FcWwnInitiatorFactCollector.collect() == fc_facts

# Generated at 2022-06-20 18:03:50.744015
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # use the mock module to mock the module parameter,
    # and mock the 'run_command' method of the mocked module
    # to return output data and return code
    module = sys.modules['ansible.module_utils.facts.system.fibre_channel_wwn']
    module_mock = MagicMock(spec=module)
    sys.modules['ansible.module_utils.facts.system.fibre_channel_wwn'] = module_mock
    module_mock.get_bin_path.return_value = '/bin'
    module_mock.run_command.return_value = (0, 'HBA Port WWN: 10000090fa1658de', '')
    # create the object under test, passing the mocked module instance as module parameter
    fcwwn_collector = FcWwnIn

# Generated at 2022-06-20 18:04:02.235399
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # case 1: no wwn
    import time
    import random
    import tempfile

    testdir = tempfile.mkdtemp()
    open(testdir + '/port_name', 'a').close()
    sys.platform = "linux"
    sys.modules['ansible.module_utils.facts.utils'] = DummyUtilsModule(testdir)
    fc = FcWwnInitiatorFactCollector()
    facts = {}
    ret = fc.collect(module=None, collected_facts=facts)
    assert ret == {'fibre_channel_wwn': []}

    # case 2: wwns
    testdir = tempfile.mkdtemp()

# Generated at 2022-06-20 18:04:04.886330
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()

    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:04:15.497451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts = {}
    fc_fact_collector = FcWwnInitiatorFactCollector()
    try:
        fc_facts = fc_fact_collector.collect()
    except:
        fc_facts = {}

    if fc_facts:
        facts = fc_facts
        facts['fibre_channel_wwn'] = []
        if len(facts['fibre_channel_wwn']) > 0:
            print('fibre_channel_wwn:')
            for wwn in facts['fibre_channel_wwn']:
                print(wwn)

# Generated at 2022-06-20 18:04:16.624815
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO
    assert False

# Generated at 2022-06-20 18:04:24.330651
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.collector import get_collector_instance

    my_module = basic.AnsibleModule(argument_spec={})
    my_facts = facts.AnsibleFacts(module=my_module)
    my_fact_collector = get_collector_instance(FcWwnInitiatorFactCollector)
    my_fact_collector.collect(module=my_module, collected_facts=my_facts)

    assert 'fibre_channel_wwn' in my_facts
    assert type(my_facts['fibre_channel_wwn']) is list

# Generated at 2022-06-20 18:04:35.700031
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes
    import sys

    test_platform = 'linux'
    sys.platform = test_platform
    test_glob_fc_host = '/sys/class/fc_host/host*/port_name'
    test_glob_fc_host_file_contents = [u'0x50060160c0a841b7\n', u'0x50060160c0a841b7\n']
    test_glob_fc_host_file_results = [u'50060160c0a841b7', u'50060160c0a841b7']

    test_module = DummyModule()

# Generated at 2022-06-20 18:05:24.524303
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnfc = FcWwnInitiatorFactCollector()
    assert fcwwnfc.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fcwwnfc.collec

# Generated at 2022-06-20 18:05:32.397188
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    class FakeModule(basic.AnsibleModule):

        def __init__(self):
            basic.AnsibleModule.__init__(self)

        def get_bin_path(self, arg1, opt_dirs=None):
            return "fake"

        def run_command(self, arg2):
            stdout = list()
            stdout.append("line1")
            stdout.append("line2")
            return 0, stdout, None

        def set_fact(self, key, value):
            return True

    # create fake module for unit test
    fake_

# Generated at 2022-06-20 18:05:44.536278
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class UnitTestModule(object):
        def __init__(self):
            self.bin_path = '/usr/bin'
        def get_bin_path(self, arg):
            return self.bin_path

# Generated at 2022-06-20 18:05:51.098267
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """test FcWwnInitiatorFactCollector.collect()"""
    from ansible.module_utils.facts import FactsCollector
    c = FactsCollector()
    c.collectors.append(FcWwnInitiatorFactCollector())
    f = c.collect()
    # result
    assert 'fibre_channel_wwn' in f

# Generated at 2022-06-20 18:05:58.471602
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModule(argument_spec={})
    class_instance = FcWwnInitiatorFactCollector()
    facts_dictionary = class_instance.collect(module=module)
    assert len(facts_dictionary.keys()) == 1
    assert facts_dictionary['fibre_channel_wwn'] is not None


# Generated at 2022-06-20 18:06:08.546572
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    class MockModule:
        def __init__(self, run_command_output):
            self.run_command_output = run_command_output
            self.params = {}

        def run_command(self, cmd):
            return self.run_command_output[cmd]

        def get_bin_path(self, arg1, opt_dirs=None):
            if opt_dirs:
                return opt_dirs[0] + '/' + arg1
            else:
                return '/opt/bin/' + arg1

    class MockCollector(FcWwnInitiatorFactCollector):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-20 18:06:17.962004
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    The test is intended to be executed as a unit test within a unittest framework
    It will simulate the execution of the collect method of class FcWwnInitiatorFactCollector
    without requiring the AnsibleHostsInterface class and without the inventory plugin
    """
    import sys
    import unittest

    class ModuleStub(object):

        def __init__(self):
            self.register_returns = []
            self.register_called = 0

        def run_command(self, cmds):
            return (0, '', '')

        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd

    class AnsibleModuleStub(object):

        def __init__(self):
            self.params = {}

    module_stub = ModuleStub()
    ansible_

# Generated at 2022-06-20 18:06:23.684829
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    result = dict(fibre_channel_wwn=["5000d31000f7e1b2", "5000d31000f7e1b3"])
    collector = FcWwnInitiatorFactCollector()
    assert collector.collect() == result

# Generated at 2022-06-20 18:06:29.718136
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:06:38.268973
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class Mock_BASE_COMMAND_MODULE:
        def get_bin_path(self, cmd, opt_dirs=[]):
            return '/opt/fcms/bin/fcmsutil'


# Generated at 2022-06-20 18:08:18.867043
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_wwn_initiators = FcWwnInitiatorFactCollector()
    test_fc_wwn_initiators = fc_wwn_initiators.collect()
    fc_facts['fibre_channel_wwn'].append(test_fc_wwn_initiators['fibre_channel_wwn'])
    assert fc_facts == test_fc_wwn_initiators


# Generated at 2022-06-20 18:08:24.348553
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = dict()
    fc_facts['fibre_channel_wwn'] = [u'50060b000013c573', u'50060b000013c574', u'50060b000013c575']
    mock_module = type('MockModule', (), dict())
    mock_module.run_command = lambda self, cmd: (0, '', '')
    mock_module.get_bin_path = lambda self, cmd: ''
    facts_collector = FcWwnInitiatorFactCollector()
    collected_facts = facts_collector.collect(module=mock_module, collected_facts=dict())
    assert collected_facts == fc_facts

# Generated at 2022-06-20 18:08:27.163522
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts is not None


# Generated at 2022-06-20 18:08:37.603595
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # set up a module to pass to the fact collector
    class TestModule(object):
        def get_bin_path(self, arg1, opt_dirs=None):
            if arg1 == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif arg1 == 'lsdev':
                return '/usr/sbin/lsdev'
            elif arg1 == 'lscfg':
                return '/usr/sbin/lscfg'
            elif arg1 == 'ioscan':
                return '/usr/sbin/ioscan'
            elif arg1 == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'


# Generated at 2022-06-20 18:08:40.867279
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Create object of FcWwnInitiatorFactCollector
    fc_wwn = FcWwnInitiatorFactCollector()
    assert fc_wwn.name == 'fibre_channel_wwn'
    assert fc_wwn._fact_ids == set()


# Generated at 2022-06-20 18:08:50.090265
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    # set empty module
    module = type('', (), {})
    module.run_command = run_command
    # execute method
    result = collector.collect(module)

    assert(result == {'fibre_channel_wwn': ['21000014ff52a9bb']})


# Generated at 2022-06-20 18:08:52.952411
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mc = FcWwnInitiatorFactCollector()
    fc_facts = mc.collect()
    assert 'fibre_channel_wwn' in fc_facts
    assert fc_facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-20 18:09:01.969756
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector

    fc_wwn_collector = FcWwnInitiatorFactCollector()
    fact_collection = FactCollector()
    fact_collection.collectors.append(fc_wwn_collector)
    facts = fact_collection.get_facts(module=None, cache=None)
    assert 'fibre_channel_wwn' in facts



# Generated at 2022-06-20 18:09:07.206087
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes

    # create an instance of the FcWwnInitiatorFactCollector
    fc_wwn_initiator = FcWwnInitiatorFactCollector()

    # the expected results for the collect method
    expected_result = dict()

    # create a test module
    test_module = AnsibleModule(argument_spec=dict())

    # get the facts and check if they are equal to the expected results
    actual_result = fc_wwn_initiator.collect(module=test_module)
    assert dict_equal(expected_result, actual_result)