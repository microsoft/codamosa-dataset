

# Generated at 2022-06-20 17:59:28.657172
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Arrange

    import glob
    import os
    import tempfile

    test_fc_port_name_file_pattern = '/sys/class/fc_host/host*/port_name'
    test_fc_port_name_file_num = 3

    if os.path.exists(test_fc_port_name_file_pattern):
        # skip collect routine and proceed with test
        # port_name file pattern should exist on system for collect routine to work
        for fc_port in glob.glob(test_fc_port_name_file_pattern):
            os.remove(fc_port)


# Generated at 2022-06-20 17:59:35.932512
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_host_data = {
        'name': 'fibre_channel_wwn',
        'platform': sys.platform,
        'command_paths': {'echo': '/bin/echo'},
        'collected_facts': {}
    }
    fc_fact_collector = FcWwnInitiatorFactCollector(fc_host_data)
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector.platform == sys.platform

# Generated at 2022-06-20 17:59:37.468424
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:41.708444
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn', 'FcWwnInitiatorFactCollector name failed'

# Generated at 2022-06-20 17:59:44.114608
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:46.233293
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    return True


# Generated at 2022-06-20 17:59:49.580423
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    os_facts = FcWwnInitiatorFactCollector()
    assert os_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:52.891113
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts = FcWwnInitiatorFactCollector()
    assert facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:01.323479
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method collect of class FcWwnInitiatorFactCollector
    """

    o_fcwwn = FcWwnInitiatorFactCollector()
    o_fcwwn._module = object()
    o_fcwwn._module.run_command = lambda cmd: (1, '', 'Failed')
    o_fcwwn._module.get_bin_path = lambda cmd: "/usr/bin/fcinfo"
    facts = {}
    o_fcwwn.collect(facts)
    assert len(facts['fibre_channel_wwn']) == 0

    o_fcwwn._module.run_command = lambda cmd: (0, 'HBA Port WWN: 10000090fa1658de', '')
    facts = {}
    o_fcwwn.collect(facts)

# Generated at 2022-06-20 18:00:13.383548
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule(object):
        def get_bin_path(self, arg, opt_dirs=None):
            if arg == "fcinfo":
                return "/usr/sbin/fcinfo"
            elif arg == "lsdev":
                return "/usr/sbin/lsdev"
            elif arg == "lscfg":
                return "/usr/sbin/lscfg"
            elif arg == "ioscan":
                return "/sbin/ioscan"
            elif arg == "fcmsutil":
                return "/opt/fcms/bin/fcmsutil"
            else:
                return None

        def run_command(self, command):
            if command == "/usr/sbin/fcinfo hba-port":
                return 0, "HBA Port WWN: 10000090fa1658de", None


# Generated at 2022-06-20 18:00:32.283126
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    import sys
    import os

    if sys.platform.startswith('linux'):
        # mock sys.platform
        platform.system = lambda: 'Linux'
    elif sys.platform.startswith('sunos'):
        # mock sys.platform
        platform.system = lambda: 'SunOS'
        platform.release = lambda: '11.3'
    elif sys.platform.startswith('aix'):
        # mock sys.platform
        platform.system = lambda: 'AIX'
    elif sys.platform.startswith('hp-ux'):
        # mock sys.platform
        platform.system = lambda: 'HP-UX'

    fc_test = FcWwnInitiatorFactCollector()

    # mock all paths and results to get a reproducable test result
   

# Generated at 2022-06-20 18:00:39.000978
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    test_func_collected_facts = {'kernel': 'SunOS', 'python': {'version': {'major': 2, 'full': '2.7.5', 'minor': 7, 'build': 5}}, 'fibre_channel_wwn': ['21000014ff52a9bb']}
    test_func_collector = get_collector_instance('FcWwnInitiatorFactCollector')
    test_func_collector_result = test_func_collector.collect()
    assert test_func_collector_result['fibre_channel_wwn'] == test_func_collected_facts['fibre_channel_wwn']


if __name__ == '__main__':
    test_F

# Generated at 2022-06-20 18:00:39.815903
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:00:52.345601
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collections.fibre_channel_wwn import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import exec_command

    config_data = """
[root@localhost ~]# cat /sys/class/fc_host/host0/port_name
0x21000014ff52a9bb
[root@localhost ~]# echo $?
0
"""

    fc_wwn_fc = FcWwnInitiatorFactCollector()

    class TestModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            return "/bin/cat"

        def run_command(self, *args, **kwargs):
            return 0, config_

# Generated at 2022-06-20 18:01:02.262304
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    result = FcWwnInitiatorFactCollector().collect(module)
    assert result['fibre_channel_wwn']
    result = FcWwnInitiatorFactCollector().collect(module)
    assert result['fibre_channel_wwn']
    FcWwnInitiatorFactCollector().collect(module)
    assert len(result['fibre_channel_wwn']) > 0

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:01:09.206730
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append('21000014ff52a9bb')
    assert fc_facts == FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-20 18:01:15.440777
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    sys.platform = 'linux'
    from ansible.module_utils.facts import collector

    # test with given values
    fc_facts = {'fibre_channel_wwn': ['0x21000014ff52a9bb']}
    assert collector.get_file_content('/sys/class/fc_host/host0/port_name') == '0x21000014ff52a9bb'
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.collect() == fc_facts

# Generated at 2022-06-20 18:01:20.228537
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc1  = FcWwnInitiatorFactCollector()
    fc_facts = fc1.collect()
    assert fc_facts is not None

# Generated at 2022-06-20 18:01:28.308252
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    test_class = FcWwnInitiatorFactCollector()

    def mock_get_file_lines(arg):
        # this is just a test, so we hardcode files
        if arg == '/sys/class/fc_host/host0/port_name':
            lines = ['0x21000014ff52a9bb']
        elif arg == '/sys/class/fc_host/host1/port_name':
            lines = ['0x20000014ff52a9ba']
        else:
            lines = []
        return lines

    test_class.get_file_lines = mock_get_file_lines
    test_class.collect(collected_facts=fc_facts)

# Generated at 2022-06-20 18:01:34.534244
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts['fibre_channel_wwn'], list)
    assert '21000014ff52a9bb' in fc_facts['fibre_channel_wwn']

# Generated at 2022-06-20 18:02:03.538729
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()
    assert obj.get_fact_ids() == set()

# Generated at 2022-06-20 18:02:07.648892
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    assert type(fc_obj.collect()).__name__ == 'dict'

# Generated at 2022-06-20 18:02:20.799751
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import sys
    # create temporary files
    # not tested:
    #    solaris 9
    #    solaris 10, solaris 11
    #    aix
    #    hp-ux
    temp_file_sys_class_fc_host_port_name = "0x1111111111111111"

    # create a mock object of class Collector
    mock_Collector = Collector()
    mock_Collector.module = MockModuleUtilsFactsModule()
    mock_Collector.module.run_command = MockModuleUtilsFactsModuleRunCommand()
   

# Generated at 2022-06-20 18:02:30.547842
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create instance of class
    fcwwnifc = FcWwnInitiatorFactCollector()
    # test that the name is set correctly
    assert fcwwnifc.name == 'fibre_channel_wwn'
    # test that the right keys are present
    assert sorted(fcwwnifc.collect().keys()) == ['ansible_facts', 'failed', 'fibre_channel_wwn', 'ignore_errors']
    # test that _fact_ids is set
    assert fcwwnifc._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-20 18:02:39.414489
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
  fact_collector = FcWwnInitiatorFactCollector()
  facts = fact_collector.collect()
  assert 'fibre_channel_wwn' in facts
  assert len(facts['fibre_channel_wwn']) > 0
  for wwn in facts['fibre_channel_wwn']:
    assert len(wwn) == 16
    assert isinstance(wwn, str) or isinstance(wwn, unicode)

# Generated at 2022-06-20 18:02:42.473604
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:47.219465
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'
    assert isinstance(fact_collector._fact_ids, set)
    assert len(fact_collector._fact_ids) == 0

    # Add some fact ids
    fact_collector._fact_ids.add('id1')
    assert len(fact_collector._fact_ids) == 1



# Generated at 2022-06-20 18:02:49.954790
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    instance = FcWwnInitiatorFactCollector(dict(), None)
    assert instance.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in instance.collect()

# Generated at 2022-06-20 18:02:55.370035
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcObj = FcWwnInitiatorFactCollector()
    fc_facts = fcObj.collect()
    assert fc_facts['fibre_channel_wwn'] is not None

# Generated at 2022-06-20 18:03:04.879112
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import FallbackModuleUtilsModule

    def get_bin_path(arg, opt_dirs=[]):
        return arg

    FALLBACK_UTILS = FallbackModuleUtilsModule(get_bin_path)
    FALLBACK_UTILS.run_command = lambda cmd: (0, '', '')
    FALLBACK_UTILS.get_bin_path = get_bin_path
    FACTS_COLLECTOR = FcWwnInitiatorFactCollector(FALLBACK_UTILS)

    assert isinstance(FACTS_COLLECTOR.collect(), dict) and FACTS_COLLECTOR.collect() != {}, \
        "FcWwnInitiatorFactCollector collects facts"

# Generated at 2022-06-20 18:04:03.124458
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    sys.modules['ansible'] = type('FakeAnsibleModule', (), {})()
    sys.modules['ansible'].module_utils = type('FakeAnsibleModuleUtils', (), {})()
    sys.modules['ansible'].module_utils.facts = type('FakeFactsCollector', (), {})()
    sys.modules['ansible'].module_utils.facts.collector = type('FakeFactCollector', (), {})()
    sys.modules['ansible'].module_utils.basic = type('FakeBasic', (), {})()
    sys.modules['ansible'].module_utils.basic.AnsibleModule = type('FakeAnsibleModule', (), {})()
    sys.modules['ansible'].module_utils.basic.AnsibleModule.run_command = type('FakeRunCommand', (), {})

# Generated at 2022-06-20 18:04:06.690293
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcFactsObj = FcWwnInitiatorFactCollector()
    assert fcFactsObj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:08.772000
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    t_class = FcWwnInitiatorFactCollector
    t_class()

# Generated at 2022-06-20 18:04:14.815251
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    fc_facts = FcWwnInitiatorFactCollector().collect()

    assert isinstance(fc_facts, dict)
    # if there is no WWN return an empty list (should be no exception)
    assert isinstance(fc_facts['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:04:17.028916
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:20.637900
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fci = FcWwnInitiatorFactCollector()
    facts = {}
    errors = []
    warnings = []
    fci.collect(None, facts, errors, warnings)
    assert isinstance(facts['fibre_channel_wwn'], list)
    print(facts)

# Generated at 2022-06-20 18:04:23.067853
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_obj = FcWwnInitiatorFactCollector()
    # checking name of class
    assert fc_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:26.857965
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc
    assert not fc._fact_ids
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:04:30.719110
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    data = fc_facts.collect()
    assert data['fibre_channel_wwn'] == ['21000014ff52a9bb']



# Generated at 2022-06-20 18:04:31.852703
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print(FcWwnInitiatorFactCollector)

# Generated at 2022-06-20 18:06:13.147067
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    pf = FcWwnInitiatorFactCollector()
    assert pf is not None
    assert pf.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:13.597404
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:06:16.230682
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x
    assert x.name == 'fibre_channel_wwn'
    assert x._fact_ids == set()

# Generated at 2022-06-20 18:06:21.265602
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc.collect() is None


# Generated at 2022-06-20 18:06:26.748413
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = [] # expected result
    fc_facts_test = {} # actual result
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts_test = fc_wwn_fact_collector.collect()
    assert fc_facts_test == fc_facts


# Generated at 2022-06-20 18:06:31.108720
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert isinstance(FcWwnInitiatorFactCollector._fact_ids, set)



# Generated at 2022-06-20 18:06:38.748028
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create a temporary dir to store files /sys/class/fc_host/*/port_name
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    import atexit
    atexit.register(lambda: shutil.rmtree(tmp_dir, ignore_errors=True))

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    # init collector object
    fact_collector = FactsCollector()
    # init FcWwnInitiatorFactCollector object
    fc = FcWwnInitiatorFactCollector()
    # create temporary test files

# Generated at 2022-06-20 18:06:40.367332
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # collect facts
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-20 18:06:49.565341
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import tempfile
    import os
    from ansible.module_utils.facts.collector import should_collect

    # test platform must be linux
    sys.platform = 'linux'

    # prepare some content for test files
    fc_files = {
        '/sys/class/fc_host/host1/port_name':'0x21000014ff52a9bb',
        '/sys/class/fc_host/host2/port_name':'0x21000014ff52a9cc',
        '/sys/class/fc_host/host3/port_name':'0x21000014ff52a9dd'
    }

    # create temp directory
    test_dir = tempfile.mkdtemp()

    # write content to files

# Generated at 2022-06-20 18:06:53.280195
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == "fibre_channel_wwn"