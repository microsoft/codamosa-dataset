

# Generated at 2022-06-20 17:59:35.024795
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import collector

    # Initialize
    collector.FactsCollector()

    # Register & Initialize
    collector.register(FcWwnInitiatorFactCollector())
    collector.initialize()

    # Get facts from above collector
    facts = collector.get_facts(module=None, collected_facts={})
    # Test to make sure we have correct facts
    if len(facts['fibre_channel_wwn']) > 0:
        return True
    else:
        return False

if __name__ == '__main__':
    print(test_FcWwnInitiatorFactCollector())

# Generated at 2022-06-20 17:59:47.431688
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    import os
    import copy
    import platform

    fixture = {
        'ansible_facts': {},
        'ansible_local': {},
    }

    # create testclass
    fc_testclass = FcWwnInitiatorFactCollector()

    # create mock module
    test_module = type('test_module', (object,), {})()
    test_module.get_bin_path = os.getenv
    test_module.run_command = os.getenv

    if platform.system().lower() == 'linux':
        fixture['ansible_facts']['fibre_channel_wwn'] = ['21000014ff52a9bb']

# Generated at 2022-06-20 17:59:53.358038
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert cmp(fc_facts.collect(), {'fibre_channel_wwn': []})

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 17:59:57.725410
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'
    assert fact._fact_ids == set()
    assert fact.collect() == {}

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:00:02.569799
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    instrumented_code = FcWwnInitiatorFactCollector()
    assert instrumented_code.name == "fibre_channel_wwn"


# Generated at 2022-06-20 18:00:05.911151
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    assert a.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:07.717536
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact is not None


# Generated at 2022-06-20 18:00:19.593666
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """confirm that data is collected as we expect it"""

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name, opt_dirs=[]):
            return name

        def run_command(self, cmd):
            return "0, cmd_output, ''"

    params = {'sysroot': '/', 'module_name': ''}
    test_module = MockModule(params)
    test_fact_collector = FcWwnInitiatorFactCollector(test_module)

    test_facts = test_fact_collector.collect()

    assert 'fibre_channel_wwn' in test_facts

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:00:26.236844
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert len(fc_wwn_initiator_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 18:00:28.571875
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_initiator_fc = FcWwnInitiatorFactCollector()
    fc_initiator_fc.collect()

# Generated at 2022-06-20 18:01:03.991415
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class DummyModule():

        def __init__(self):
            self._ansible_solaris = True

        def get_bin_path(self, arg, opt_dirs=None):
            return '/bin/%s' % arg

        def run_command(self, arg):
            out = ""
            if arg == "/bin/fcinfo hba-port":
                out = (0, "   HBA Port WWN: 10000090fa1658de \nHBA Port WWN: 10000090fa1657dd\n", "")


# Generated at 2022-06-20 18:01:12.811304
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.parsers.storage.fibre_channel_wwn import FcWwnInitiatorFactCollector
    import pytest
    import os
    from ansible.module_utils.six import PY3, b
    from ansible.module_utils._text import to_bytes
    import subprocess
    import sys

    # dummy module and facts
    test_module = 'test'
    test_facts = {'ansible_test': 'test_fact'}

    # test setup
    os_data = [to_bytes(os.name), to_bytes(sys.platform)]
    env_data = 0
    module_params = 'test'

# Generated at 2022-06-20 18:01:17.801176
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set()



# Generated at 2022-06-20 18:01:27.351381
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    On two supported platforms (Linux, Solaris), run collect method of
    FcWwnInitiatorFactCollector class and check that the output is as expected.

    The tests are executed only if the platform which is tested supports fibre
    channel connectivity. In this case fibre channel host ports / adapters are
    expected to be detected.

    """

    # import needed modules, as these tests are not executed via ansible
    import os
    import platform
    import inspect

    import ansible.module_utils.facts.collectors.network.fibre_channel_wwn as fcwwn

    # prepare test data
    data_root = os.path.dirname(inspect.getfile(inspect.currentframe())) + '/data/'
    test_data = {}

# Generated at 2022-06-20 18:01:32.638879
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in FcWwnInitiatorFactCollector._fact_ids

# Generated at 2022-06-20 18:01:36.755996
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'
    assert len(x._fact_ids) == 0
    x.collect()
    assert len(x._fact_ids) == 1

# Generated at 2022-06-20 18:01:41.288426
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    assert o.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:45.298553
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    o = FcWwnInitiatorFactCollector()
    assert o.name == "fibre_channel_wwn"
    assert not o._fact_ids

# Generated at 2022-06-20 18:01:53.713422
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts import ansible_collector
    import unittest

    class FakeModule(object):
        class FakeCmdClass(object):
            pass

        def run_command(self, cmd, check_rc=True, close_fds=True):
            self.cmd = cmd
            cmd_output = b"N_Port Port World Wide Name = 0x50060b00006975ec"
            return 0, cmd_output, b''

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/' + arg


# Generated at 2022-06-20 18:01:57.935199
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_coll = FcWwnInitiatorFactCollector()
    assert fcwwn_coll.name == 'fibre_channel_wwn'
    assert len(fcwwn_coll._fact_ids) == 0

# Generated at 2022-06-20 18:02:29.840052
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors import FcWwnInitiatorFactCollector
    collector = FcWwnInitiatorFactCollector()
    # if os.path.exists('/sys/class/fc_host/host3/port_name'):
    #     self.assertEqual(collector.collect(), { 'fibre_channel_wwn': ['21000014ff52a9bb']})
    # else:
    #     self.assertEqual(collector.collect(), { 'fibre_channel_wwn': []})
    #
    # self.assertEqual(collector.collect(), {
    #     'fibre_channel_wwn': ['21000014ff52a9bb'],
    #         })


# Generated at 2022-06-20 18:02:39.774490
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # pylint: disable=import-error, no-name-in-module, too-few-public-methods
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector
    fact_collector = Collector(FcWwnInitiatorFactCollector())
    collected_facts = fact_collector.collect()
    assert 'fibre_channel_wwn' in collected_facts

# Generated at 2022-06-20 18:02:41.696345
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:02:45.742045
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    if sys.platform.startswith('linux'):
        fc_facts.collect()
        assert (fc_facts.name) == 'fibre_channel_wwn'
        assert (fc_facts._fact_ids) == fc_facts.__dict__['_fact_ids']

# Generated at 2022-06-20 18:02:50.984723
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Method collect of FcWwnInitiatorFactCollector
    """
    fc_facts = FcWwnInitiatorFactCollector()

    # Expected result
    expected_result = {
        "fibre_channel_wwn": ["10000090fa1658de"]
    }
    # Call collect method
    result = fc_facts.collect()
    # Compare expected result with real result
    assert result == expected_result

# Generated at 2022-06-20 18:02:51.825831
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:02:56.189454
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:03:05.147412
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from datetime import datetime
    from ..utils.module_docs_fragments import get_test_data_dict

    testdata = get_test_data_dict()
    data = testdata['facts']['ansible_local']
    obj = FcWwnInitiatorFactCollector()
    result = obj.collect(module=None, collected_facts={'time': datetime.utcnow()})

    def has_wwn(wwn):
        for item in result['fibre_channel_wwn']:
            if item == wwn:
                return True
        return False

    assert 'fibre_channel_wwn' in result
    assert len(result['fibre_channel_wwn']) > 0
    assert has_wwn('21000014ff52a9bb')
    assert has_

# Generated at 2022-06-20 18:03:06.684945
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    a = FcWwnInitiatorFactCollector()
    a.collect()
    facts_dict = a.get_facts()
    return a.get_fact_names()

# Generated at 2022-06-20 18:03:10.200323
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    unit test for constructor of class FcWwnInitiatorFactCollector
    """
    # Define the arguments of class FcWwnInitiatorFactCollector
    fc_fact_collector = FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:03:59.028731
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:04:03.067750
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Initialization
    collector = FcWwnInitiatorFactCollector()
    collected_facts = {}

    # Test
    result = collector.collect(collected_facts=collected_facts)

    # Evaluation
    assert result == {'fibre_channel_wwn': []}

# Generated at 2022-06-20 18:04:08.108242
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()


# Generated at 2022-06-20 18:04:14.600479
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Construtor test
    obj = FcWwnInitiatorFactCollector()
    assert obj
    # instance attributes test
    assert hasattr(obj, 'name')
    assert obj.name == 'fibre_channel_wwn'
    assert hasattr(obj, '_fact_ids')
    assert obj._fact_ids

# Generated at 2022-06-20 18:04:17.959842
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.fc_wwn import FcWwnInitiatorFactCollector
    f = FcWwnInitiatorFactCollector()
    assert isinstance(f, Collector)

# Generated at 2022-06-20 18:04:18.897328
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:04:24.419922
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test for constructor of class FcWwnInitiatorFactCollector"""
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert type(fc._fact_ids) is set

# Generated at 2022-06-20 18:04:28.738126
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    test_object = FcWwnInitiatorFactCollector()
    assert test_object.collect() == {
        'fibre_channel_wwn': [
            '21000014ff52a9bb',
        ],
    }

# Generated at 2022-06-20 18:04:32.718445
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import Collector

    my_collector = FcWwnInitiatorFactCollector()
    assert isinstance(my_collector, Collector)
    assert my_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:38.245016
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This unit test does not test the actual class (FcWwnInitiatorFactCollector),
    but only its method collect which is the entry point to the class
    """
    class_dict = {
        'run_command': lambda x, check_rc=False: (0, '', ''),
    }
    module = type('AnsibleModule', (), class_dict)()
    fact_dict = FcWwnInitiatorFactCollector().collect(module=module)
    assert 'fibre_channel_wwn' in fact_dict

# Generated at 2022-06-20 18:06:17.181852
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:22.206999
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert f._fact_ids == set()
    assert f.collect() == {}

# Generated at 2022-06-20 18:06:25.259341
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:36.354451
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import Collector

    print("Testing FcWwnInitiatorFactCollector_collect")
    fc_facts = {'fibre_channel_wwn': [u'21000014ff52a9ba', u'21000014ff52a9bb']}
    fc_temp_facts = Collector(FcWwnInitiatorFactCollector).collect(module=None, collected_facts=None)
    if fc_temp_facts != fc_facts and fc_temp_facts != {}:
        print(fc_temp_facts)
        #raise Exception("FcWwnInitiatorFactCollector_collect failed")

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:06:41.787262
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()


# Generated at 2022-06-20 18:06:49.097309
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts import get_collector_facts

    module = AnsibleModule()
    result = get_collector_facts(module,
                                 [FcWwnInitiatorFactCollector])

    if sys.platform.startswith('linux'):
        assert 'fibre_channel_wwn' in result
    else:
        assert 'fibre_channel_wwn' not in result

# Generated at 2022-06-20 18:06:55.254221
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert len(fc_facts.name) > 0
    assert fc_facts.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:06:59.152966
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test FcWwnInitiatorFactCollector.collect()
    """
    # create a FcWwnInitiatorFactCollector
    fact_collector = FcWwnInitiatorFactCollector()

    assert fact_collector.collect() == {'fibre_channel_wwn': []}


# Generated at 2022-06-20 18:07:07.110845
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.platforms == ('Linux', 'Solaris', 'Aix', 'HpUx')

    assert collector.requirements == {}
    assert collector.required_collectors == (None,)


# Generated at 2022-06-20 18:07:17.028253
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule(object):
        def __init__(self, bin_paths):
            self.bin_paths = bin_paths

        def get_bin_path(self, names, opt_dirs=[]):
            return self.bin_paths[names]

        def run_command(self, cmd, check_rc=True, data='', binary_data=False):
            return (0, '', '')

    class MockOptions(object):
        def __init__(self, ansible_facts):
            self.ansible_facts = ansible_facts

    class MockAnsibleModule(object):
        def __init__(self, bin_paths):
            self.module = MockModule(bin_paths)

        def exit_json(self, ansible_facts):
            assert ansible_facts == self