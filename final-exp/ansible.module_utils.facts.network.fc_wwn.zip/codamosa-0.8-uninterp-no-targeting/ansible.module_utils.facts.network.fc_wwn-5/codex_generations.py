

# Generated at 2022-06-20 17:59:28.806640
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import FcWwnInitiatorFactCollector
    import os

    module = AnsibleModuleMock()
    collector = Collector()

    collector.collect(module)
    assert 'fibre_channel_wwn' in collector.facts
    assert 'fibre_channel_wwn_count' in collector.facts

    fcwwn_collector = FcWwnInitiatorFactCollector()
    fcwwn_collector.collect(module)
    assert 'fibre_channel_wwn' in fcwwn_collector.facts

    fcwwn_collector.facts['fibre_channel_wwn'].append('12345')

# Generated at 2022-06-20 17:59:32.485067
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == "fibre_channel_wwn"
    assert fc._fact_ids == set()

# Generated at 2022-06-20 17:59:39.374266
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test with input data (fcs3 on AIX)
    """
    # input data

# Generated at 2022-06-20 17:59:43.072183
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_collector = FcWwnInitiatorFactCollector()
    assert facts_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 17:59:46.808048
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method serves as unit test for method collect of class
    FcWwnInitiatorFactCollector.
    """
    collector = FcWwnInitiatorFactCollector()

    result = collector.collect()
    assert 'fibre_channel_wwn' in result.keys()

# Generated at 2022-06-20 17:59:52.373288
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Unit test for class FcWwnInitiatorFactCollector
    """
    fc_wwn_fact = FcWwnInitiatorFactCollector()
    fc_wwn_fact._module = None
    fc_wwn_fact.collect()

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 17:59:54.268872
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:58.145084
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts

if __name__ == "__main__":
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:00:03.045315
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    coll = FcWwnInitiatorFactCollector()
    assert coll.name == 'fibre_channel_wwn'
    assert coll._fact_ids == set()

# Generated at 2022-06-20 18:00:08.591383
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()

    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:00:20.885279
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:00:25.160435
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()



# Generated at 2022-06-20 18:00:37.689545
# Unit test for method collect of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:00:42.424046
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == "fibre_channel_wwn"
    assert fact.collect() is not None

# Generated at 2022-06-20 18:00:49.640867
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    test_FcWwnInitiatorFactCollector._module = None
    test_FcWwnInitiatorFactCollector._collect_platform_subset = [
        'linux',
        'sunos'
    ]
    assert test_FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-20 18:01:03.280327
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    import unittest

    class TestFcWwnInitiatorFactCollector(unittest.TestCase):
        def test_fc_wwn_collection(self):
            from ansible.module_utils.facts.collector.network import FcWwnInitiatorFactCollector
            fc = FcWwnInitiatorFactCollector()
            facts = fc.collect()
            # self.assertEqual(facts['fibre_channel_wwn'], data_expected)

    sys.modules[__name__] = TestFcWwnInitiatorFactCollector()
    from . import fibre_channel_wwn_initiator
#     from .module_utils.facts.collector.network import FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:01:12.190408
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # instantiate a test class
    fact_collector = FcWwnInitiatorFactCollector()
    # create a test method
    def fake_run_command(module, cmd):
        """Fake run_command"""
        # success is indicated by 0, stdout lines and empty stderr
        return 0, ['line1', 'line2'], ''
    # mock run_command
    import __builtin__
    if not hasattr(__builtin__, '__original_import__'):
        __builtin__.__original_import__ = __builtin__.__import__
    __builtin__.__import__ = lambda x: __builtin__ if x == 'ansible.module_utils.facts.utils' else __builtin__.__original_import__(x)
    # mock run_command
    import ansible

# Generated at 2022-06-20 18:01:20.182908
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    # Create object
    fc_wwn_facts = FcWwnInitiatorFactCollector()

    # List of facts
    result = fc_wwn_facts.collect()
    assert 'fibre_channel_wwn' in result
    # fibgte_channel_wwn is a list
    assert isinstance(result['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:01:21.741181
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect(None, None)

# Generated at 2022-06-20 18:01:27.080200
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    myL_fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb', '21000014ffa2b2f6']}
    myL_collector = FcWwnInitiatorFactCollector()
    myL_facts = myL_collector.collect()
    assert myL_facts == myL_fc_facts

# Generated at 2022-06-20 18:01:41.846663
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc is not None

# Generated at 2022-06-20 18:01:50.864452
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.utils import AnsibleImmutableDict
    mock_module = BaseFactCollector()
    mock_module.run_command = lambda x : ('', '', '')
    mock_module.get_bin_path = lambda x : x
    facts = FcWwnInitiatorFactCollector().collect(mock_module, AnsibleImmutableDict())
    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-20 18:01:55.400226
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj.name == 'fibre_channel_wwn'
    assert test_obj._fact_ids == set()


# Generated at 2022-06-20 18:01:58.189054
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcfacts = FcWwnInitiatorFactCollector()
    assert fcfacts.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:02:03.070653
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:02:08.845542
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'
    assert fc_fact_collector._fact_ids == set()



# Generated at 2022-06-20 18:02:18.336848
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for method collect of class FcWwnInitiatorFactCollector """
    from ansible.module_utils.facts.utils import AnsibleFactCollector

    collected_facts = AnsibleFactCollector()
    fc_fc_info = FcWwnInitiatorFactCollector(collected_facts)
    facts = fc_fc_info.collect()
    # run collect() and check if output is empty
    assert len(facts) > 0


# Generated at 2022-06-20 18:02:22.394185
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:27.868196
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    if sys.platform.startswith('linux'):
        import os
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts.facts import Facts
        from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector

        fc_file = '/sys/class/fc_host/host0/port_name'

        fc_facts = {}
        fc_facts['fibre_channel_wwn'] = []
        fc_facts['fibre_channel_wwn'].append('21000014ff52a9bb')
        expected_facts = dict(fibre_channel_wwn=fc_facts['fibre_channel_wwn'])

# Generated at 2022-06-20 18:02:33.924448
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test if we can get all fibre_channel_wwn facts.
    :return: None
    """
    class TestModule(object):
        pass

    test_module = TestModule()
    test_module.run_command = run_command
    test_module.get_bin_path = get_bin_path
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector.collect(module=test_module)

    assert result is not None
    assert 'fibre_channel_wwn' in result, 'fibre_channel_wwn key not in result'

# Generated at 2022-06-20 18:02:45.413141
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method is needed for unit testing module FcWwnInitiatorFactCollector.
    :return:
    """
    pass

# Generated at 2022-06-20 18:02:49.637517
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test class constructor
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj._fact_ids == set()
    assert hasattr(obj, 'collect')
    assert callable(obj.collect)

# Generated at 2022-06-20 18:02:53.186917
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test = FcWwnInitiatorFactCollector()
    assert test.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:03.860969
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collectors.network.fc_wwn import (
        FcWwnInitiatorFactCollector
    )
    from ansible.module_utils.facts.collector import FactsCollector

    module = mock.MagicMock()

    # Mock platform and os.path
    sys.platform = 'linux'
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    # Mock contents of /sys/class/fc_host/*/port_name
    fcfile = '/sys/class/fc_host/host0/port_name'
    data = mock.MagicMock()
    data.rstrip.return_value = '0x21000014ff52a9bb'
    lines = mock.MagicMock()
    lines.__iter

# Generated at 2022-06-20 18:03:07.541539
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.facts.collector

    # Step 1: Set up environment
    # Save current working dir
    cwd = os.getcwd()

    # Create temp dir
    tmpdir = tempfile.mkdtemp()

    # Change working dir to temp dir
    os.chdir(tmpdir)

    # Set up sys.platform
    sys.platform = 'linux'

    # Set up paths
    sys.path = [tmpdir + '/ansible', tmpdir + '/ansible/module_utils']

    # Step 2: Set up test data

# Generated at 2022-06-20 18:03:09.752628
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert 'fibre_channel_wwn' == FcWwnInitiatorFactCollector.name

# Generated at 2022-06-20 18:03:15.247264
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()

    fc_facts = fc_fact_collector.collect()

    if sys.platform.startswith('linux'):
        assert fc_facts['fibre_channel_wwn'] == [u'21000014FF52A9BB']
    else:
        assert fc_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-20 18:03:17.906007
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:22.745715
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Test case where fcinfo is not installed
    gfc = FcWwnInitiatorFactCollector(None, None)
    assert gfc.name is 'fibre_channel_wwn'
    assert gfc.collect() == {}



# Generated at 2022-06-20 18:03:28.118935
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Unit tests for method collect() of class FcWwnInitiatorFactCollector
# TBD

# Generated at 2022-06-20 18:03:41.244708
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts import GatheringFactCollector
    FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' in GatheringFactCollector.collected_facts.keys()
    assert GatheringFactCollector.collected_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-20 18:03:42.306764
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:03:44.804387
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:48.730045
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert sorted(collector._fact_ids) == ['fibre_channel_wwn']
    assert collector._platform == 'all'

# Generated at 2022-06-20 18:03:57.457837
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Prepare the test environment
    class test_module():
        def __init__(self):
            self.run_command_received_params = {}
        def get_bin_path(self, binary, opt_dirs=[]):
            if binary in ['fcinfo', 'ioscan', 'fcmsutil']:
                return binary
            return None
        def run_command(self, cmd, *_args, **_kwargs):
            self.run_command_received_params = {'cmd': cmd}
            if cmd == 'fcinfo hba-port':
                return 0, """
                HBA Port WWN: 10000090fa1658de
                HBA Port WWN: 20000090fa1658de
                HBA Port WWN: 30000000fa1658de
                """, ''

# Generated at 2022-06-20 18:04:03.341365
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile
    import sys
    import shutil

    sys.modules['ansible.module_utils.facts.utils'] = __import__('ansible.module_utils.facts.utils')
    sys.modules['ansible.module_utils.facts.collector'] = __import__('ansible.module_utils.facts.collector')
    sys.modules['ansible.module_utils.facts.utils'].glob = __import__('glob')
    sys.modules['ansible.module_utils.facts.utils'].get_file_lines = __import__('ansible.module_utils.facts.utils').get_file_lines

    from ansible.module_utils.facts import collector

    class FakeModule:
        def __init__(self):
            self.run_command_environ_update = os

# Generated at 2022-06-20 18:04:08.754231
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    data_dict = {'ansible_facts': {'fibre_channel_wwn': ['21000014ff52a9bb']}}
    testobj = FcWwnInitiatorFactCollector(None, None)

    assert testobj.collect() == {'fibre_channel_wwn': []}
    assert testobj.collect(module=True, collected_facts=data_dict) == {'fibre_channel_wwn': ['21000014ff52a9bb']}

# Generated at 2022-06-20 18:04:20.462454
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts import FallbackModuleUtils
    from ansible.module_utils.facts.utils import FactsParseError
    from ansible.module_utils import basic
    FcWwnInitiatorFactCollector.name = 'fibre_channel_wwn'
    FcWwnInitiatorFactCollector._fact_ids = set()
    FcWwnInitiatorFactCollector._fact_ids.add('fibre_channel_wwn')
    facts = CollectedFacts({})
    f = FcWwnInitiatorFactCollector()
    f.collect(module=None, collected_facts=facts)

# Generated at 2022-06-20 18:04:30.202375
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Testing constructor of FcWwnInitiatorFactCollector")
    fc_facts = {}
    pprint(fc_facts)
    assert "fibre_channel_wwn" not in fc_facts
    fc_wwn_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_fact_collector.name == "fibre_channel_wwn"
    pprint(fc_wwn_fact_collector._fact_ids)
    assert fc_wwn_fact_collector._fact_ids == set()

# Generated at 2022-06-20 18:04:38.506255
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    mock_module = MagicMock(name="mock_module")
    # first fake fcinfo without output -> should return empty dict
    mock_module.get_bin_path.return_value = None
    fc_collector = FcWwnInitiatorFactCollector(mock_module)
    result = fc_collector.collect()
    assert result == {}
    # retry with fcinfo output and check results
    mock_module.run_command.return_value = 0, "HBA Port WWN: 10000090fa1658de", ""
    fc_collector = FcWwnInitiatorFactCollector(mock_module)
    result = fc_collector.collect()
    assert result == {'fibre_channel_wwn': ['10000090fa1658de']}
   

# Generated at 2022-06-20 18:05:06.942597
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)
    result = dict(
        changed=False,
        ansible_facts=dict(
            fibre_channel_wwn=['0x21000014ff52a9bb']
        )
    )
    fc = FcWwnInitiatorFactCollector(module)
    assert fc.collect() == result['ansible_facts']


# Generated at 2022-06-20 18:05:08.841191
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # TODO: add unit test
    pass

# Generated at 2022-06-20 18:05:20.325181
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = True
    module.run_command.return_value = (0, '\n'.join(['HBA Port WWN: 10000090fa1658de',
                                                     'HBA Port WWN: 10000090fa1658df']), '')
    fc = FcWwnInitiatorFactCollector()
    assert(fc.collect(module=module, collected_facts={}) == {'fibre_channel_wwn': ['10000090fa1658de', '10000090fa1658df']})



# Generated at 2022-06-20 18:05:23.343248
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'
    assert c._fact_ids == set()

# Generated at 2022-06-20 18:05:29.541043
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    host_command = None
    try:
        # Create an instance of FcWwnInitiatorFactCollector
        fc_wwn_initiator_facts = FcWwnInitiatorFactCollector(
            host_command,
            '0x21000014ff52a9bb',
            '/sys/class/fc_host/host1/port_name'
        )
    except Exception as e:
        raise Exception('Failed to create FcWwnInitiatorFactCollector ' + str(e))


# Generated at 2022-06-20 18:05:34.523941
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    assert isinstance(fc_facts_collector, FcWwnInitiatorFactCollector)
    assert fc_facts_collector.name is not None

# Generated at 2022-06-20 18:05:46.009252
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    sys.path.append('/path_to_ansible_module_utils/ansible/module_utils/facts/collector')
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeAnsibleModule(object):
        def __init__(self):
            self.facts = dict()
            self.params = dict()

        def exit_json(self, result):
            self.facts = result

        def fail_json(self, result):
            self.facts = result

    platform_to_wwns = {
    'linux': ['21000014ff52a9bb'],
    'sunos': [],
    'aix': [],
    'hp-ux': []
    }

    module = FakeAnsibleModule()
    sys.platform = 'linux'

# Generated at 2022-06-20 18:05:55.682833
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    modules = [BaseFactCollector, get_file_content]
    # create mock module object

# Generated at 2022-06-20 18:05:57.774089
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:03.787416
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Returns ansible module arguments
    :return:
    """
    from ansible.module_utils.facts.utils import AnsibleFakeModule

    ansible_module = AnsibleFakeModuleName()

    """
    instantiate FcWwnInitiatorFactCollector
    """
    c = FcWwnInitiatorFactCollector()
    a = c.collect(ansible_module)
    """
    check results
    """
    assert isinstance(a, dict)
    assert a == {'fibre_channel_wwn': []}

# Generated at 2022-06-20 18:06:59.122170
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # typical elxis output
    FB = b"""
        0x500601602e7c76f2"""

    # typical solaris output
    FB_SOL = b"""
            HBA Port WWN: 10000090fa1658de"""

# Generated at 2022-06-20 18:07:01.214649
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    Constructor should check for required platform
    """
    sut = FcWwnInitiatorFactCollector()
    assert sut.platforms == ['Linux', 'SunOS', 'AIX', 'HP-UX']

# Generated at 2022-06-20 18:07:09.884818
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    collector = FcWwnInitiatorFactCollector()
    facts_out = collector.collect(module=None, collected_facts=None)
    if facts_out is not fc_facts:
        # raise Exception('FcWwnInitiatorFactCollector: test_FcWwnInitiatorFactCollector(), fc_facts != facts_out')
        pass

#test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:07:13.265502
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    result = fc.collect()
    assert result['fibre_channel_wwn']
    assert isinstance(result['fibre_channel_wwn'], list)
    assert len(result['fibre_channel_wwn']) > 0

# Generated at 2022-06-20 18:07:17.774763
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_fc = FcWwnInitiatorFactCollector()
    assert fc_wwn_fc.name == "fibre_channel_wwn"
    assert len(fc_wwn_fc._fact_ids) == 0

# Generated at 2022-06-20 18:07:24.077836
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids.__len__ == 0

# Generated at 2022-06-20 18:07:32.527694
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleCollector

    # Fake module
    class FakeModule():
        def __init__(self):
            self.fake_module = 'fake_module'

        def run_command(self, cmd):
            return 0, 'fake_output', None

        def get_bin_path(self, cmd, opt_dirs=[]):
            return None

    # Fake collected facts
    class FakeCollectedFacts():
        def __init__(self):
            self.fake_collected_facts = 'fake_collected_facts'

    test_module = FakeModule()
    test_collected_facts = FakeCollectedFacts()

    # Create object of class FcWwnInitiatorFactCollector
    test_fc_wwn_fac_col = FcWwnIn

# Generated at 2022-06-20 18:07:37.659471
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_fact_collector = FcWwnInitiatorFactCollector()
    assert test_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:40.103542
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    result = fc_facts.collect()
    assert result['fibre_channel_wwn'] == ['21000014FF52A9BB']

# Generated at 2022-06-20 18:07:43.967422
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()