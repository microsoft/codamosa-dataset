

# Generated at 2022-06-20 17:59:35.648697
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This method is used for unit testing of method collect of class FcWwnInitiatorFactCollector
    """
    import json
    import os
    import platform
    import sys
    import unittest.mock

    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.hardware.fibre_channel import FcWwnInitiatorFactCollector

    result = {'ansible_fibre_channel_wwn': ['21000014ff52a9bb']}
    if platform.system() == 'SunOS':
        result = {'ansible_fibre_channel_wwn': ['10000090fa1658de']}

    if platform.system() == 'Linux':
        # mock class BaseFactCollector
        base_fact_

# Generated at 2022-06-20 17:59:40.096152
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import mock
    import sys
    import glob
    module = mock.MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/bin/lsdev'
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/opt/fcms/bin/fcmsutil'
    if sys.platform.startswith('aix'):
        module.run_command.return_value = (0, 'fcs3 Available 06-08-02 FC Adapter\nfcs4 Available 06-08-02 FC Adapter\nfcs5 Available 06-08-02 FC Adapter\nfcs6 Available 06-08-02 FC Adapter', '')

# Generated at 2022-06-20 17:59:41.304875
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # unit test needs to be implemented
    return True

# Generated at 2022-06-20 17:59:42.893515
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert isinstance(facts['fibre_channel_wwn'], list)

# Generated at 2022-06-20 17:59:43.287391
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    yield False, None

# Generated at 2022-06-20 17:59:49.453210
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    attrs = dir(result)
    optional_attrs = ['name', '_fact_ids']
    for optional_attr in optional_attrs:
        assert optional_attr in attrs
    assert result.name == "fibre_channel_wwn"

# Generated at 2022-06-20 17:59:57.987924
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_lines

    class MockModule:
        def get_bin_path(self, *args, **kwargs):
            if args[0] == 'ioscan':
                return '/usr/sbin/ioscan'
            if args[0] == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            return None

        def run_command(self, *args, **kwargs):
            if args[0] == '/usr/sbin/ioscan -fnC FC':
                return 0, "fcd0  0/0/2/0.6.0     /dev/fcd0", None

# Generated at 2022-06-20 17:59:59.406061
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-20 18:00:00.237699
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:00:05.245683
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_fact_collector.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:00:21.739025
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert obj.collect() is None

# Generated at 2022-06-20 18:00:31.394181
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collectors import FcWwnInitiatorFactCollector

    # create temporary file
    port_name_file_fd, port_name_file_path = tempfile.mkstemp()


# Generated at 2022-06-20 18:00:34.873620
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwfc = FcWwnInitiatorFactCollector()
    assert isinstance(fwfc, FcWwnInitiatorFactCollector)
    assert fwfc.name == 'fibre_channel_wwn'
    assert fwfc._fact_ids == set()

# Generated at 2022-06-20 18:00:44.259215
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def mock_run_commands(cmd):
        """
        example output of fcinfo hba-port:
        HBA Port WWN: 21000024ff3d3a54
        """
        data = dict()
        data["rc"] = 0
        data["stdout"] = "HBA Port WWN: 21000024ff3d3a54\n"
        data["stderr"] = ""
        return data

    # Create a FcWwnInitiatorFactCollector object for testing
    ff = FcWwnInitiatorFactCollector()

    # save original run_command method
    orig_run_commands = ff.run_commands

# Generated at 2022-06-20 18:00:48.654527
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in collector.collect()

# Generated at 2022-06-20 18:00:52.720431
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:56.208901
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:02.906693
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Results to check with
    unix_results = {
        'fibre_channel_wwn': ['50060b00006975ec', '50060b00006975ed']
    }
    host_unix = 'hp_ux'
    # Run the test
    module = 'fake'
    # Run the test
    results = FcWwnInitiatorFactCollector().collect(module)
    # Check results
    assert unix_results == results

# Generated at 2022-06-20 18:01:04.367262
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    print(result)


# Generated at 2022-06-20 18:01:07.438104
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    facts_obj = FcWwnInitiatorFactCollector()
    assert facts_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:36.399101
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fc_wwn_initiator import FcWwnInitiatorFactCollector
    from ansible.module_utils._text import to_bytes

    collector = FcWwnInitiatorFactCollector()
    results = collector.collect()
    assert results.get('fibre_channel_wwn') == []

# Generated at 2022-06-20 18:01:44.673290
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create the class
    fc_fact_collector = FcWwnInitiatorFactCollector()
    fc_facts = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    test_output = fc_fact_collector.collect()
    assert test_output == fc_facts

# Generated at 2022-06-20 18:01:51.961688
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a FcWwnInitiatorFactCollector object
    fwifc = FcWwnInitiatorFactCollector()

    # The fact collector should have a name `fibre_channel_wwn`
    assert fwifc.name == 'fibre_channel_wwn'

    # The fact collector should have a single fact `fibre_channel_wwn`
    assert 'fibre_channel_wwn' in fwifc._fact_ids

    # Check the default return value of method collect (list)
    assert fwifc.collect() == {'fibre_channel_wwn': []}


# Generated at 2022-06-20 18:02:02.726727
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.ansible.misc.plugins.module_utils.facts import FactCollector
    from ansible_collections.ansible.misc.plugins.module_utils import basic
    from ansible_collections.ansible.misc.plugins.module_utils.facts.collector.solaris import FcWwnInitiatorFactCollector

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    fc_facts = FactCollector(module=module, collected_facts=None)

    fc_facts.clear_facts()
    fc_facts.collect(module=module, collected_facts=None)
    fc_actual_facts = fc_facts.get_facts()
    # print(fc_actual_facts)

# Generated at 2022-06-20 18:02:07.938897
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn = FcWwnInitiatorFactCollector()
    assert fcwwn.name == 'fibre_channel_wwn'
    assert fcwwn._fact_ids == set()

# Generated at 2022-06-20 18:02:13.777490
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_facts = FcWwnInitiatorFactCollector()
    assert len(fcwwn_facts._fact_ids) > 0
    assert 'fibre_channel_wwn' in fcwwn_facts._fact_ids

# Generated at 2022-06-20 18:02:20.134752
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = FakeModule()
    setattr(module, 'run_command', module_run_command)
    setattr(module, 'get_bin_path', module_get_bin_path)
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect(module=module, collected_facts=None)
    assert result['fibre_channel_wwn'] == ['50060b00006975ec']


# Generated at 2022-06-20 18:02:24.380645
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result
    assert hasattr(result, 'collect')

# Generated at 2022-06-20 18:02:31.214525
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    from ansible.module_utils.facts.collector import Cacheable
    from ansible.module_utils.facts import collector

    my_facts = FcWwnInitiatorFactCollector()
    assert isinstance(my_facts, FcWwnInitiatorFactCollector)
    assert isinstance(my_facts, Cacheable)
    assert isinstance(my_facts, collector.BaseFactCollector)
    assert(my_facts.name == 'fibre_channel_wwn')
    assert(isinstance(my_facts._fact_ids, set))
    assert(len(my_facts._fact_ids) == 0)



# Generated at 2022-06-20 18:02:42.548041
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_collector = FcWwnInitiatorFactCollector()
    # Test FC WWN facts on Linux
    fc_facts = {'fibre_channel_wwn': []}
    fc_facts_collector.sys_platform = 'linux'
    fc_facts_collector.glob_glob = lambda x: ['/sys/class/fc_host/host1/port_name',
                                              '/sys/class/fc_host/host2/port_name']
    fc_facts_collector.get_file_lines = lambda x: ['0x21000014ff52a9bb', '0x21000014ff52a9cc']
    fc_facts_collector.collect()
    assert fc_facts == fc_facts_collector.collect()
    #

# Generated at 2022-06-20 18:03:34.136069
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collectors.network.fibre_channel_wwn import FcWwnInitiatorFactCollector
    fcwwn_fc = FcWwnInitiatorFactCollector()
    fcwwn_fc.collect()

# Generated at 2022-06-20 18:03:38.613339
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()
    assert FcWwnInitiatorFactCollector.collect() == {}

# Generated at 2022-06-20 18:03:41.267745
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector != None

# Generated at 2022-06-20 18:03:53.134982
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = ['50060b00006975ec', '50060b00006977ec',
                                     '50060b00006978ec', '50060b00006979ec']
    module = type('', (), {})
    module.run_command = type('', (), {})

# Generated at 2022-06-20 18:03:57.310769
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result.name == 'fibre_channel_wwn'
    assert result._fact_ids == {'fibre_channel_wwn'}

# Generated at 2022-06-20 18:04:04.302726
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule:
        def get_bin_path(self, arg, opt_dirs=None):
            return None
        def run_command(self, arg):
            return 0, None, None

    collected_facts = {}
    mock_module = MockModule()
    fcww = FcWwnInitiatorFactCollector()
    fcww.collect(module=mock_module, collected_facts=collected_facts)
    assert 'fibre_channel_wwn' in collected_facts

# Generated at 2022-06-20 18:04:11.590078
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fact = FcWwnInitiatorFactCollector()

    # example output for Linux
    input1 = [
        '0x21000014ff52a9bb',
    ]

    # example output for SunOS

# Generated at 2022-06-20 18:04:18.984474
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """
    # Dummy class to avoid the execution of the code
    class DummyModule(object):
        def get_bin_path(self, arg, opt_dirs=None):
            return arg

    dummy_module = DummyModule()

    # Case valid output
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    fcwwn_fact_collector.collect(dummy_module)

# Generated at 2022-06-20 18:04:23.697034
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts
    assert hasattr(fc_facts, 'name')
    assert hasattr(fc_facts, '_fact_ids')


# Generated at 2022-06-20 18:04:27.014386
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # At least the class FcWwnInitiatorFactCollector should be defined.
    assert 'FcWwnInitiatorFactCollector' in globals()


# Generated at 2022-06-20 18:06:03.917777
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    facts = {}
    fc.collect(collected_facts=facts)
    assert 'fibre_channel_wwn' in facts



# Generated at 2022-06-20 18:06:13.110087
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FallbackModule
    import os

    class TestCollector(Collector):
        def __init__(self):
            self.facts = dict()
            self.facts['fibre_channel_wwn'] = []

    c = TestCollector()
    FcWwnInitiatorFactCollector().collect(module=FallbackModule(), collected_facts=c.facts)

    assert c.facts['fibre_channel_wwn']

# Generated at 2022-06-20 18:06:15.970937
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:06:20.315585
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwnf = FcWwnInitiatorFactCollector()
    assert fcwwnf.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:25.502861
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class args(object):
        def __init__(self):
            self.timeout = 5
            self.connection = 'local'
            self.cache = False
            self.become = False
    module = args
    facts = FcWwnInitiatorFactCollector(module)
    assert facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:29.239582
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    os = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == os.name

# Generated at 2022-06-20 18:06:34.352572
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """
    FcWwnInitiatorFactCollector = FcWwnInitiatorFactCollector()
    facts = FcWwnInitiatorFactCollector.collect()
    assert (facts['fibre_channel_wwn'] == [] or type(facts['fibre_channel_wwn']) == list)

# Generated at 2022-06-20 18:06:46.312042
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule(object):
        def __init__(self, rc=0, bin_path='/mockbin'):
            self.rc = rc
            self.bin_path = bin_path

        def get_bin_path(self, app, opt_dirs=[]):
            return self.bin_path

        def run_command(self, cmd):
            return (self.rc, '', '')

    m = MockModule()
    f = FcWwnInitiatorFactCollector()
    facts = f.collect(m)

    assert facts == {'fibre_channel_wwn': []}

# Generated at 2022-06-20 18:06:50.459721
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector.platform_independent == True



# Generated at 2022-06-20 18:06:52.689028
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()