

# Generated at 2022-06-20 17:59:35.615987
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.collectors.fibre_channel_wwn as fcwwn_collector
    import ansible.module_utils.facts.utils as utils
    from ansible.module_utils.facts.utils import is_string
    import ansible.module_utils.facts.virtual as virtual

    # test invalid data
    fcwwn = fcwwn_collector.FcWwnInitiatorFactCollector()
    assert fcwwn.collect(module=None, collected_facts=None) == {}

    # test valid data
    test_data = {'fibre_channel_wwn': [u'50060b00006975ec']}
    # mock virtual.collect() to

# Generated at 2022-06-20 17:59:37.999661
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    result = FcWwnInitiatorFactCollector()
    assert result is not None


# Generated at 2022-06-20 17:59:39.427545
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector().collect()

# Generated at 2022-06-20 17:59:43.179288
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # expected out for test_FcWwnInitiatorFactCollector_collect()
    # {'fibre_channel_wwn': ['21000014FF52A9BB']}
    fci = FcWwnInitiatorFactCollector()
    assert fci.collect() == {'fibre_channel_wwn': ['21000014FF52A9BB']}


# Generated at 2022-06-20 17:59:45.350479
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collecter = FcWwnInitiatorFactCollector()
    assert collecter.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:49.441091
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:55.268328
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This test tests if FcWwnInitiatorFactCollector method collect returns correct output
    """
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    test_obj = FcWwnInitiatorFactCollector()
    assert fc_facts == test_obj.collect()

# Generated at 2022-06-20 18:00:00.846821
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set(['fibre_channel_wwn'])

# Generated at 2022-06-20 18:00:11.895808
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys

    sys.path.append('/home/aduchateau/ansible/ansible/modules/core/')
    import ansible.module_utils.facts.utils
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestModule(object):
        @staticmethod
        def run_command(cmd):
            stdout = """
                HBA Port WWN: 10000090fa1658de
                """
            return 0, stdout.encode(), ''

        @staticmethod
        def get_bin_path(cmd, opt_dirs=''):
            return '/usr/bin/' + cmd

    class TestBaseFactCollector(BaseFactCollector):
        def __init__(self, module):
            BaseFactCollector.__init__(self, module)

    TestBaseFact

# Generated at 2022-06-20 18:00:17.914070
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    print('###')
    print('### Test method collect of class FcWwnInitiatorFactCollector')
    print('###')
    TestClass = FcWwnInitiatorFactCollector()
    TestClass.collect()
    print('### Test method collect of class FcWwnInitiatorFactCollector:')
    print('### END')
    print('###')

# Unit test of class FcWwnInitiatorFactCollector

# Generated at 2022-06-20 18:00:44.660045
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()

    assert fc_facts.name == 'fibre_channel_wwn'
    assert not fc_facts._fact_ids

# Generated at 2022-06-20 18:00:53.940403
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    In order to run this unit test, invoke the following:
    ansible-test units --python -v test_FcWwnFactCollector.py
    """
    from ansible.module_utils.facts import collector
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.collector.s390x import FcWwnInitiatorFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import os
    c = FcWwnInitiatorFactCollector()
    facts_dict = collector.collect(c)
    host_name = os.uname()[1]
    print("hostname: %s" % host_name)

# Generated at 2022-06-20 18:01:04.764901
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.

    :return:
    """
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # retrieve instance of FcWwnInitiatorFactCollector
    fact_collector = get_collector_instance(module)
    assert isinstance(fact_collector, FcWwnInitiatorFactCollector)
    facts_dict = fact_collector.collect(module=module)
    # check if fibre_channel_wwn is in facts_dict
    assert 'fibre_channel_wwn' in facts_dict

# Generated at 2022-06-20 18:01:14.776655
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    my_collector = FcWwnInitiatorFactCollector()
    my_paths = '/sys/class/fc_host/*/port_name'
    my_collector.get_file_lines = lambda x: [
        '0x21000014ff52a9bb',
        '0x21000014ff52a9bc',
        '0x21000014ff52a9bd'
    ]
    my_collector.glob = lambda x: [
        '/sys/class/fc_host/host0/port_name',
        '/sys/class/fc_host/host1/port_name',
        '/sys/class/fc_host/host2/port_name'
    ]
    my_collector.collect()
    assert my_collector.data['fibre_channel_wwn']

# Generated at 2022-06-20 18:01:17.069249
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector.prefix is None

# Generated at 2022-06-20 18:01:21.262628
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create instance of class FcWwnInitiatorFactCollector
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj



# Generated at 2022-06-20 18:01:25.373913
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:01:31.333112
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c1 = FcWwnInitiatorFactCollector()
    assert c1.name == 'fibre_channel_wwn'
    assert c1.__class__.__name__ == 'FcWwnInitiatorFactCollector'

# Generated at 2022-06-20 18:01:35.117592
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    test_obj = FcWwnInitiatorFactCollector()
    assert test_obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:01:42.348962
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def run_ansible(module_args):
        # Load the required python modules
        module_path = './library/ansible/module_utils/facts/collector/fibre_channel_wwn.py'
        module = load_module(module_path)
        if sys.version_info[0] < 3:
            module.run_command = run_command_python2
        else:
            module.run_command = run_command_python3
        module.get_bin_path = get_bin_path

        # Initialize the class to test
        test_module = FcWwnInitiatorFactCollector()

        # Run the main function of the module
        if sys.version_info[0] < 3:
            results = test_module.collect(module, None)
        else:
            results = test_

# Generated at 2022-06-20 18:02:15.570570
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform

    class TestModule(object):
        def __init__(self, distro, version_info, platform):
            self.distro = distro
            self.version_info = version_info
            self.platform = platform

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'fcinfo':
                return '/usr/local/bin/fcinfo'
            if binary == 'lsdev':
                return '/usr/sbin/lsdev'
            if binary == 'lscfg':
                return '/usr/sbin/lscfg'
            return None

        def run_command(self, cmd):
            if cmd == '/usr/sbin/lsdev -Cc adapter -l fcs*':
                return (0, 'fcs0 Available 05-08 FC Adapter', None)

# Generated at 2022-06-20 18:02:16.709971
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass



# Generated at 2022-06-20 18:02:19.625509
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:24.380130
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_fact = FcWwnInitiatorFactCollector()
    assert fc_fact.name == 'fibre_channel_wwn', 'test_FcWwnInitiatorFactCollector - Constructor failed'
    return

# Generated at 2022-06-20 18:02:32.316742
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Create MemoryFactCollector class instance and test collect method.
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_bytes

    facts_dict = Collector.collect(FcWwnInitiatorFactCollector)
    assert facts_dict[to_bytes('fibre_channel_wwn')] == []

    # There will be 2 dummy facts collected by MemoryFactCollector
    # (platform_dist_freq, platform_dist_name, platform_dist_version, platform_subsystem)
    # assert len(facts_dict) == 2

# Generated at 2022-06-20 18:02:39.310496
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import inspect
    import sys
    import platform
    from ansible.module_utils.facts.collector import BaseFactCollector

    TEST_DIR = os.path.dirname(inspect.getfile(BaseFactCollector))
    sys.path.append(os.path.join(TEST_DIR, '../'))
    from test_utils.compat import unittest
    from test_utils.compat.mock import patch


# Generated at 2022-06-20 18:02:44.724748
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_fact_collector = FcWwnInitiatorFactCollector()
    x = fc_fact_collector.collect()
    print("fibre_channel_wwn fact: %s" % x.get("fibre_channel_wwn"))

# Generated at 2022-06-20 18:02:48.801518
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-20 18:03:02.164609
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json
    import os
    import sys
    import tempfile
    import unittest

    class os_mock():
        def __init__(self, platform):
            self.platform = platform
            self.sep = os.sep
            if sys.version_info > (3,):
                self.linesep = os.linesep
            else:
                self.linesep = os.linesep.decode('utf-8')
        def system(self, code):
            if not code.startswith('fcinfo hba-port'):
                return 1
            self.code = code
            self.fcinfo_path = '/usr/sbin/fcinfo'

# Generated at 2022-06-20 18:03:10.684978
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcfile = '/tmp/fibre_channel_wwn_file'
    content = ['0x21000014ff52a9bb']
    fp = open(fcfile, 'w')
    fp.write("\n".join(content))
    fp.close()

    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect(module=None, collected_facts=None)

    # clean up
    import os
    os.remove(fcfile)

    assert facts['fibre_channel_wwn'] == ['21000014ff52a9bb']

# Generated at 2022-06-20 18:04:06.608681
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class Opt:
        def __init__(self):
            self.gather_subset = None
            self.filter = None
            self.fqdn = None

    class Module:
        def __init__(self):
            self.params = Opt()

    module = Module()
    fc_facts = FcWwnInitiatorFactCollector(module, {}).collect()
    assert fc_facts
    assert 'fibre_channel_wwn' in fc_facts
    if sys.platform.startswith('linux'):
        assert len(fc_facts['fibre_channel_wwn'])>0
    elif sys.platform.startswith('sunos'):
        assert len(fc_facts['fibre_channel_wwn'])>0

# Generated at 2022-06-20 18:04:09.296314
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    facts = collector.collect()
    assert type(facts['fibre_channel_wwn'] is list)
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-20 18:04:14.673979
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    module = BaseFactCollector
    fc = FcWwnInitiatorFactCollector()
    # on linux
    if sys.platform.startswith('linux'):
        fc_facts = fc.collect(module)
        assert "fibre_channel_wwn" in fc_facts
        assert fc_facts['fibre_channel_wwn'][0] == '21000014ff52a9bb'
        assert len(fc_facts['fibre_channel_wwn']) == 1
    # on solaris or aix or hp-ux

# Generated at 2022-06-20 18:04:24.419905
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MyModule:
        def get_bin_path(name, opt_dirs=None):
            return name

    mp = MyModule()
    fc = FcWwnInitiatorFactCollector(mp)
    rc = fc.collect()
    assert isinstance(rc, dict)
    assert len(rc) == 1
    assert isinstance(rc['fibre_channel_wwn'], list)
    assert len(rc['fibre_channel_wwn']) == 0
    return True

if __name__ == '__main__':
    print(test_FcWwnInitiatorFactCollector_collect())

# Generated at 2022-06-20 18:04:33.394574
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    import ansible.module_utils.facts.collector

    # create instance of FcWwnInitiatorFactCollector
    test_collector = FcWwnInitiatorFactCollector()
    # set result to empty dict
    result = {}
    # call method collect of class FcWwnInitiatorFactCollector
    test_collector.collect(None, result)
    # assert result
    assert 'fibre_channel_wwn' in result
    if 'fibre_channel_wwn' in result:
        assert isinstance(result['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:04:35.512673
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factCollector = FcWwnInitiatorFactCollector()
    assert factCollector.name == 'fibre_channel_wwn'
    assert factCollector.collect() == {}

# Generated at 2022-06-20 18:04:38.790858
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert isinstance(fc_facts._fact_ids, set)
    assert len(fc_facts._fact_ids) == 0


# Generated at 2022-06-20 18:04:46.970310
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Tests that collect returns a list of strings, each string has
    # length of 32 (this means a WWN)
    fc_facts = FcWwnInitiatorFactCollector().collect()
    if fc_facts['fibre_channel_wwn']: # fact can be empty
        for fc_initiator in fc_facts['fibre_channel_wwn']:
            assert len(fc_initiator) == 32, "Resulting WWN is not 32 characters long"


# Generated at 2022-06-20 18:04:58.807802
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MyModule():
        def __init__(self, cmd):
            self.cmd = cmd
        def get_bin_path(self, mycmd, opt_dirs=[]):
            return self.cmd
        def run_command(self, cmd):
            lines = []
            if cmd == "fcinfo hba-port":
                lines = [
                    "HBA Port WWN: 10000090fa1658de",
                    "HBA Port WWN: 10000090fa1658df",
                    "HBA Port WWN: 10000090fa1658e0",
                ]

# Generated at 2022-06-20 18:05:05.046837
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes
    import ansible.constants as C

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10

        def get_bin_path(self, arg, **kwargs):
            if arg == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif arg == 'lsdev':
                return '/usr/bin/lsdev'
            elif arg == 'lscfg':
                return '/usr/bin/lscfg'

# Generated at 2022-06-20 18:06:47.897610
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    This test case exercises the functionality of the method FcWwnInitiatorFactCollector.collect
    """
    # get a new instance of FcWwnInitiatorFactCollector
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    # exercise the collect method
    fact_result = fcwwn_fact_collector.collect(module=None, collected_facts={})
    if fact_result['fibre_channel_wwn'] == []:
        print("No fibre-channel WWNs found")
    else:
        print("fibre-channel WWNs collected: %s" % fact_result['fibre_channel_wwn'])

# run the test case
if __name__ == '__main__':
    test_FcWwnInitiatorFact

# Generated at 2022-06-20 18:06:50.888198
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:56.135995
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    f = FcWwnInitiatorFactCollector()
    assert f.name == 'fibre_channel_wwn'
    assert len(f._fact_ids) == 0


# Generated at 2022-06-20 18:06:57.590671
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:07:09.772559
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    expected_module_name = 'ansible.module_utils.facts'
    expected_class_name = 'FcWwnInitiatorFactCollector'
    ff = FcWwnInitiatorFactCollector('fibre_channel_wwn')
    assert ff.name == 'fibre_channel_wwn'

    # test the imported name
    imported_mod_name = '.'.join(ff.__module__.split('.')[:-1])
    assert imported_mod_name == expected_module_name

    # test the class name
    class_name = ff.__class__.__name__
    assert class_name == expected_class_name

# Generated at 2022-06-20 18:07:11.468459
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert 'fibre_channel_wwn' in fc_facts

# Generated at 2022-06-20 18:07:17.083436
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    obj = FcWwnInitiatorFactCollector()
    obj._module = True
    obj._module.run_command = True
    obj._module.run_command.return_value = (0, '', '')
    obj.collect()

    # this is an empty test, just to make sure there are no errors

# Generated at 2022-06-20 18:07:30.387225
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector, Collectors
    from ansible.module_utils.facts.utils import Facts

    def test_module(module_name=None, module_args=None):
        if module_name == 'setup':
            module_instance = AnsibleModule(argument_spec=dict())
        return module_instance

    AnsibleModule = None
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins

    # Create a dummy AnsibleModule object
    class AnsibleModule:
        def __init__(self, argument_spec=None):
            builtins.__dict__["file"] = open

        def run_command(self, command):
            return 0, command, None


# Generated at 2022-06-20 18:07:35.383077
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # collect without parameters
    thecollector = FcWwnInitiatorFactCollector()
    myfacts = thecollector.collect()

    assert ('fibre_channel_wwn' in myfacts)

# Generated at 2022-06-20 18:07:47.284358
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test that method collect returns expected result.
    """
    import platform
    import tempfile

    # make a tempfile to be used as FC port_name file to be read
    test_file, tmp_file_name = tempfile.mkstemp()

    # expected result
    expected_result = {'fibre_channel_wwn': ['50060b0000d27a52'], 'module_hw': True}

    # when a test directory is available
    if platform.system() == "Linux":
        # write a single line to the test file
        with open(tmp_file_name, 'w') as f:
            f.write('0x50060b0000d27a52')

        # create a test instance
        fc_fact_collector = FcWwnInitiatorFactCollector()
        # assert