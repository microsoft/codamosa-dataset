

# Generated at 2022-06-20 17:59:29.959056
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fh = FcWwnInitiatorFactCollector()
    # those variables should be defined
    assert fh.name is not None
    assert fh._fact_ids is not None


# Generated at 2022-06-20 17:59:38.347503
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector.system import SystemFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    sys_fact = SystemFactCollector()
    sys_fact.collect()
    osname = sys_fact._collected_facts.get('system').get('name')
    # initialize a fact module
    fact_module = FactCollector(module_name='TestFacts')
    # return a instance of the fact collector
    fact_collector = get_collector_instance(fact_module, 'fibre_channel_wwn')
    # test the collect method of the fact
    facts = fact_collector.collect()
    # on solaris 10 or solaris 11 should return a list

# Generated at 2022-06-20 17:59:44.461682
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import FcWwnInitiatorFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import AnsibleFactError
    import sys

    # mock module
    class CollectedFacts:
        def __init__(self):
            self.ansible_facts = {}

    class MockModule:
        def run_command(self, cmd):
            return (0, '', '')

        def get_bin_path(self, name):
            return "fake"

    # mock platform
    class MockPlatform:
        def linux_distribution(self):
            return None

# Generated at 2022-06-20 17:59:57.061399
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''Unit test for method collect of class FcWwnInitiatorFactCollector'''

    # set up test environment
    import os
    import shutil
    from ansible.module_utils.facts.collector import BaseFactCollector

    # create folder test_FcWwnInitiatorFactCollector_collect in temp dir
    tmp_dir = os.path.realpath(os.path.dirname(__file__)) + '/test_FcWwnInitiatorFactCollector_collect'
    os.mkdir(tmp_dir)

    # create test files
    open(tmp_dir + '/port_name_1', 'a').close()
    test_file_1 = open(tmp_dir + '/port_name_1', 'w')

# Generated at 2022-06-20 18:00:03.698927
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    module = None
    setattr(module, 'file_root', '/root/')
    fc = FcWwnInitiatorFactCollector(module)
    data = fc.collect()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:14.374254
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts import FactCollector, Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class APlatform:
        LINUX = 'linux'
        SOLARIS = 'sunos'
        AIX = 'aix'
        HPUX = 'hp-ux'
        UNKNOWN = 'unknown'

    def get_platform():
        if sys.platform.startswith('linux'):
            return APlatform.LINUX
        elif sys.platform.startswith('sunos'):
            return APlatform.SOLARIS
        elif sys.platform.startswith('aix'):
            return APlatform.AIX
        elif sys.platform.startswith('hp-ux'):
            return APlatform.HPUX

# Generated at 2022-06-20 18:00:16.476599
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:00:20.012274
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector.fibre_channel_wwn_initator import FcWwnInitiatorFactCollector

    module = type('module', (object,), {})
    fc_collector = FcWwnInitiatorFactCollector()
    fc_collector.collect(module)

# Generated at 2022-06-20 18:00:30.907478
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = ['00024b934c0a35bb', '00024b934c0a35bc']
    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False

        def get_bin_path(self, cmd, opt_dirs=[]):
            return None

        def run_command(self, cmd):
            self.run_command_called = True
            # return something which looks like an error
            # to test that we do not append the data
            return [1, 'foo', 'bar']

    class FakeCollector(FcWwnInitiatorFactCollector):
        def __init__(self):
            self.sys_platform = 'linux'


# Generated at 2022-06-20 18:00:38.828954
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'
    assert 'fibre_channel_wwn' in fc_facts._fact_ids
    assert fc_facts._collect_fn is not None
    assert fc_facts._collect_fn.__name__ == fc_facts.collect.__name__


# Generated at 2022-06-20 18:00:54.657769
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:01:05.046464
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    In this unit test, we test the collected facts of
    FcWwnInitiatorFactCollector with following conditions:
    First, we create a FcWwnInitiatorFactCollector with the name.
    Then, we make a fact_subset and check whether the fact_subset
    is correctly collected by the FcWwnInitiatorFactCollector.
    In this test, the /SYS/CLASS/FC_HOST/PORT_NAME file is
    pre-created to be ready for reading by the collector.
    If the file is not empty and readable, the collect method
    should collect the facts from the file.
    """
    TEST_FILE_NAME = "/tmp/ansible_facts_fc_wwn_initiator_collector_test_file"


# Generated at 2022-06-20 18:01:06.387403
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:01:12.529937
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    sys.modules['ansible.module_utils.facts.collector.base'] = __import__('ansible.module_utils.facts.collector.base')
    sys.modules['ansible.module_utils.facts.collector'] = __import__('ansible.module_utils.facts.collector')
    my_obj = FcWwnInitiatorFactCollector()
    assert my_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:15.680306
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts=FcWwnInitiatorFactCollector()
    assert fc_facts.name=='fibre_channel_wwn'

# Generated at 2022-06-20 18:01:21.464680
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set(['fibre_channel_wwn'])
    fc._collect()

# Generated at 2022-06-20 18:01:25.179767
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    assert isinstance(fc_facts['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:01:29.216493
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:36.320454
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    # Method collect should return a dict
    facts = fc.collect()
    assert isinstance(facts, dict)
    # The method should collect 2 facts
    assert 'fibre_channel_wwn' in facts
    # Check that values are well formed
    for value in facts['fibre_channel_wwn']:
        assert value.isalnum()

# Generated at 2022-06-20 18:01:38.997649
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector.
    """
    pass

# Generated at 2022-06-20 18:02:08.350075
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """Unit test for constructor of class FcWwnInitiatorFactCollector."""

    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:02:19.098299
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    FcWwnInitiatorFactCollector = sys.modules[__name__].FcWwnInitiatorFactCollector
    #
    # Unit test for Linux
    #
    # test for collect if file exists and has a zero length
    fc_wwn_initiator_facts_collector = FcWwnInitiatorFactCollector()
    fc_wwn_initiator_facts_collector.files['/sys/class/fc_host/*/port_name'] = None
    fc_wwn_initiator_facts_collector.files_contents[
        '/sys/class/fc_host/*/port_name'] = ''
    result = fc_wwn_initiator_facts_collector.collect()
    assert result['fibre_channel_wwn'] == []
   

# Generated at 2022-06-20 18:02:31.955567
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from __main__ import FakeModule
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_collector

    collectors = FactsCollector()
    collector = FcWwnInitiatorFactCollector()
    collectors.add(collector)
    ansible_collector._COLLECTORS = collectors
    module = FakeModule(
        ansible_facts_module=ansible_collector
    )
    # TODO: get list of ports from fcinfo and lscfg
    # one port on Intel Optane DC SSD
    fctest_data = ['10000000c9f0d4af']
    test_fcinfo_out = "HBA Port WWN: 10000000c9f0d4af"

# Generated at 2022-06-20 18:02:42.030039
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    module = BaseFactCollector.setup_module_object()
    module.run_command = lambda *args: (0, '', None)
    fcwwn_collector = FcWwnInitiatorFactCollector()
    res = fcwwn_collector.collect(module)
    print(res)
    assert 'fibre_channel_wwn' in res
    assert isinstance(res['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:02:46.511604
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []

    obj = FcWwnInitiatorFactCollector()

    assert obj._fact_ids == set()

    obj.collect(module=None, collected_facts=None)

    assert obj.name == 'fibre_channel_wwn'

    assert fc_facts['fibre_channel_wwn'] == []

# Generated at 2022-06-20 18:02:52.759479
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Unit test for method collect of class FcWwnInitiatorFactCollector"""
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collectors
    from ansible.module_utils._text import to_bytes

    # create a temporary Collector instance
    module = Collector()

    # create a temporary FcWwnInitiatorFactCollector instance
    collector = FcWwnInitiatorFactCollector()

    # check if collect method returns a dictionary
    assert isinstance(collector.collect(module=module), dict)

    # check if collect method adds 'fibre_channel_wwn' to the result
    assert 'fibre_channel_wwn' in collector.collect(module=module)

    # check if collect method returns empty 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:58.170294
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwf = FcWwnInitiatorFactCollector()
    assert fwf.name == 'fibre_channel_wwn'
    assert fwf.platform == 'all'

# Generated at 2022-06-20 18:02:59.390005
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()



# Generated at 2022-06-20 18:03:00.731228
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:03:02.771887
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_type = FcWwnInitiatorFactCollector()
    assert 'fibre_channel_wwn' == fact_type.name
    assert isinstance(fact_type._fact_ids, set)
    assert 0 == len(fact_type._fact_ids)

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:04:02.563533
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    # get FcWwnInitiatorFactCollector
    fc_facts = FactsCollector('fibre_channel_wwn_initiator', [FcWwnInitiatorFactCollector])
    # set value for module
    fc_facts.collectors[0].collector._module = None
    # run collect
    fc_facts.collect()

    assert 'fibre_channel_wwn' in fc_facts.facts

# Generated at 2022-06-20 18:04:04.772019
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:17.849462
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    Test with mocked module and facts collector.
    """
    from ansible.module_utils.facts.collector import base_collect
    from ansible.module_utils.facts import config
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.fibre_channel_wwn import FcWwnInitiatorFactCollector

    module_mock = MagicMock()
    module_mock.get_bin_path.side_effect = ['/bin/ioscan', '/usr/sbin/fcmsutil']

# Generated at 2022-06-20 18:04:23.749847
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    collector = FcWwnInitiatorFactCollector()
    result = collector.collect()
    # check general structure of result
    assert 'kernel_name' in result
    assert 'fibre_channel_wwn' in result
    assert type(result['fibre_channel_wwn']) is list

# Generated at 2022-06-20 18:04:33.069672
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import FactCollector, get_collection_exceptions

    Collectors.add_collector(FcWwnInitiatorFactCollector)
    facts = FactCollector().collect(list_exceptions=get_collection_exceptions())

    assert isinstance(facts, dict)
    assert 'fibre_channel_wwn' in facts
    assert isinstance(facts['fibre_channel_wwn'], list)
    assert len(facts['fibre_channel_wwn']) > 0
    assert isinstance(facts['fibre_channel_wwn'][0], str)

    # cleanup
    Collectors.pop_collector(FcWwnInitiatorFactCollector)

# Generated at 2022-06-20 18:04:41.156879
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    '''
    Test for method collect of class FcWwnInitiatorFactCollector
    '''
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collectors as facts_collectors
    from ansible.module_utils.facts.collector import get_collector_instance

    class TestBaseFactCollector(BaseFactCollector):
        name = ''
        fact_ids = set()

        def collect(self, module=None, collected_facts=None):
            pass

    class TestFcWwnInitiatorFactCollector(BaseFactCollector):
        name = 'test_fibre_channel_wwn'
        fact_ids = set()


# Generated at 2022-06-20 18:04:53.326639
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test method 'collect' of class FcWwnInitiatorFactCollector.
    """

    # construct a mock object for module_utils.facts.collector.BaseFactCollector
    base_fact_collector_instance = object.__new__(BaseFactCollector)

    # collect facts
    fc_wwn_initiator_fact_collector_instance = FcWwnInitiatorFactCollector()
    result = fc_wwn_initiator_fact_collector_instance.collect(base_fact_collector_instance)

    # check results
    if result is None:
        print("Return value is not valid (None).")
        return False

    if len(result) == 0:
        print("Return value does not contain any results.")
        return False


# Generated at 2022-06-20 18:04:55.700245
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    pass

# Generated at 2022-06-20 18:04:57.852240
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for FcWwnInitiatorFactCollector::collect method
    """
    pass

# Generated at 2022-06-20 18:05:09.032546
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.run_command=MOCK_run_command
            self.get_bin_path=MOCK_get_bin_path

    class MockRc(dict):
        def __init__(self):
            self['rc'] = 0
            self['stdout'] = """HBA Port WWN: 10000090fa1658de
HBA Port WWN: 10000090fa1658df
"""
            self['stderr'] = ""

    class MockIoscanRc(dict):
        def __init__(self):
            self['rc'] = 0

# Generated at 2022-06-20 18:06:49.766462
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector(None, None)
    assert collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:55.954153
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Call constructor of class and
    # check result
    fcwwnfactcollector = FcWwnInitiatorFactCollector()
    assert fcwwnfactcollector.name == 'fibre_channel_wwn'



# Generated at 2022-06-20 18:07:04.183616
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module_mock = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    fc_facts = FcWwnInitiatorFactCollector.collect(module=module_mock)
    module_mock.exit_json(ansible_facts=fc_facts)


# Generated at 2022-06-20 18:07:14.611785
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test case to cover the collect method of FcWwnInitiatorFactCollector
    """
    def mock_get_file_lines(f):
        if f == "/sys/class/fc_host/host3/port_name":
            return ["0x21000014ff52a9bb", "0x21000014ff52a9ba"]
        return []

    def mock_get_bin_path(b, opt_dirs=None):
        if b == "fcinfo":
            return "/usr/sbin/fcinfo"
        elif b == "lsdev":
            return "/usr/sbin/lsdev"
        elif b == "lscfg":
            return "/usr/sbin/lscfg"

# Generated at 2022-06-20 18:07:15.421518
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    pass

# Generated at 2022-06-20 18:07:18.602436
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'
    assert fact._fact_ids == set()
    assert fact.collect() == {}


# Generated at 2022-06-20 18:07:23.137602
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:27.988634
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # return instance of class FcWwnInitiatorFactCollector
    fc_facts = FcWwnInitiatorFactCollector()
    assert isinstance(fc_facts, FcWwnInitiatorFactCollector)

# Generated at 2022-06-20 18:07:40.860098
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    define a class that inherits from the FcWwnInitiatorFactCollector
    class and returns empty values where needed.
    """

    class MyFcWwnInitiatorFactCollector(FcWwnInitiatorFactCollector):
        def __init__(self):
            pass

        def _find_fc_files(self):
            return ['/sys/class/fc_host/host1/port_name', '/sys/class/fc_host/host2/port_name']

        def _read_fc_file(self, filename):
            if filename == '/sys/class/fc_host/host1/port_name':
                return ['0x21000014ff52a9bb', '0x21000014ff52a9bc']

# Generated at 2022-06-20 18:07:45.751834
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector()
    assert FcWwnInitiatorFactCollector().name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector()._fact_ids == set()