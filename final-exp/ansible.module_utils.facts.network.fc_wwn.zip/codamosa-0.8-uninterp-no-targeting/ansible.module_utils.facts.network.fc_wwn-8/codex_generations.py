

# Generated at 2022-06-20 17:59:23.603701
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert fc_facts.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:36.130602
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    try:
        import sys
    except ImportError:
        import platform
        if platform.system() == 'AIX':
            # not supported for AIX
            pass
        else:
            raise
        return

    import os
    from ansible.module_utils.facts import ModuleFactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes

    fctest = FcWwnInitiatorFactCollector()
    fctest.collect_callback(None, None)

    # assertions
    print("fc_facts: %s" % repr(fctest.facts), file=sys.stderr)
    assert fctest.facts
    assert 'fibre_channel_wwn' in fctest

# Generated at 2022-06-20 17:59:47.743247
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test collect method of class FcWwnInitiatorFactCollector
    """
    fc = FcWwnInitiatorFactCollector()
    facts = fc.collect()
    assert 'fibre_channel_wwn' in facts
    if sys.platform.startswith('linux'):
        assert len(facts['fibre_channel_wwn']) == 1
        assert facts['fibre_channel_wwn'][0] == '21000014ff52a9bb'
    elif sys.platform.startswith('sunos'):
        assert len(facts['fibre_channel_wwn']) == 1
        assert facts['fibre_channel_wwn'][0] == '10000090fa1658de'

# Generated at 2022-06-20 17:59:49.356505
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fci = FcWwnInitiatorFactCollector()
    assert fci is not None

# Generated at 2022-06-20 17:59:57.010712
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule(object):
        def get_bin_path(self, arg, opt_dirs=None):
            return arg

    test_module = TestModule()

    class CollectedFacts(dict):
        pass

    collected_facts = CollectedFacts()
    test_collector = FcWwnInitiatorFactCollector()
    result = test_collector.collect(test_module, collected_facts)
    assert result['fibre_channel_wwn'] == []

# Generated at 2022-06-20 18:00:10.759210
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.collectors import network

    FcWwnInitiatorFactCollector.init_cache()

    test_module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    fc_facts = FcWwnInitiatorFactCollector.collect(module=test_module)
    assert fc_facts
    assert isinstance(fc_facts['fibre_channel_wwn'], list)

    network_facts = network.NetworkFactCollector.collect(module=test_module)
    assert network_facts


# Generated at 2022-06-20 18:00:20.323658
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Initalize test variables
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    # add some test data
    fc_facts['fibre_channel_wwn'].append('210000e08b45f420')
    fc_facts['fibre_channel_wwn'].append('210000e08b45f421')

    # Create test object
    fc_obj = FcWwnInitiatorFactCollector()

    # check data
    assert len(fc_obj.collect()['fibre_channel_wwn']) >= 2, "This test will check the system for at least 2 fibre-channel ports. Please setup for this test."

    assert fc_facts['fibre_channel_wwn'][0] == fc_obj.collect

# Generated at 2022-06-20 18:00:31.002204
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import ansible.module_utils.facts.collectors.fibre_channel_wwn as fc_collector
    import ansible.module_utils.facts.utils as fact_utils
    import os
    import tempfile
    import shutil
    import textwrap

    # create a temporary test directory in the system
    temp_dir = tempfile.mkdtemp()

    # create a temporary file and append some contant to it

# Generated at 2022-06-20 18:00:38.152063
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_collector = FcWwnInitiatorFactCollector()
    assert fc_collector.name == 'fibre_channel_wwn'
    assert fc_collector._fact_ids is not None
    assert len(fc_collector._fact_ids) >= 1
    assert fc_collector not in BaseFactCollector._fact_collectors

# Generated at 2022-06-20 18:00:46.028426
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = FcWwnInitiatorFactCollector()
    assert isinstance(fc_facts, BaseFactCollector)
    assert fc_facts.name == 'fibre_channel_wwn'

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:01:11.190575
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:01:18.763059
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    module = None

    fc_facts = FcWwnInitiatorFactCollector(module)

    assert fc_facts.name == 'fibre_channel_wwn'
    assert fc_facts._fact_ids == set(['fibre_channel_wwn'])



# Generated at 2022-06-20 18:01:26.220696
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.system.fibre_channel_wwn import FcWwnInitiatorFactCollector

    fact_collector = Collector()
    fact_collector.add_collector(FcWwnInitiatorFactCollector())
    facts = fact_collector.collect(module=None, collected_facts=None)
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-20 18:01:33.136981
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # create an instance of object
    obj = FcWwnInitiatorFactCollector()
    # No unit test possible - this is just a placeholder
    assert obj != None

# unit test execution
if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:01:38.195462
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    '''Unit test for constructor of class FcWwnInitiatorFactCollector'''
    fc_fct = FcWwnInitiatorFactCollector()
    assert fc_fct.name == 'fibre_channel_wwn'
    assert isinstance(fc_fct._fact_ids, set)
    assert fc_fct._fact_ids == set()


# Generated at 2022-06-20 18:01:47.083136
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_file = sys.modules[__name__].__file__
    fact_dir = os.path.dirname(fact_file)
    collector = FcWwnInitiatorFactCollector(module=None, collected_facts=None)
    assert collector.name == 'fibre_channel_wwn'
    assert collector.priority == 50
    assert collector.required_facts == set()


# Generated at 2022-06-20 18:02:00.425740
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    def _mock_module_run_command(cmd):
        if cmd == 'fcinfo hba-port':
            return 0, "HBA Port WWN: 10000090fa1658de\n", 0

# Generated at 2022-06-20 18:02:13.321272
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile

    fcwwn_facts = dict()
    fcwwn_facts['fibre_channel_wwn'] = list()
    fcwwn_facts['fibre_channel_wwn'].append('21000014ff52a9bb')
    fcwwn_facts['fibre_channel_wwn'].append('21000014ff52a9bc')


# Generated at 2022-06-20 18:02:17.320187
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    tstclass = FcWwnInitiatorFactCollector()
    assert tstclass.name == "fibre_channel_wwn"
    assert tstclass._fact_ids == set()
    assert callable(getattr(tstclass, 'collect'))

# Generated at 2022-06-20 18:02:20.093888
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:46.192385
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    factCollector = FcWwnInitiatorFactCollector()
    assert factCollector is not None
    assert factCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:49.203412
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()

# Generated at 2022-06-20 18:02:53.306048
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector({},None)
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:54.474462
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:57.856869
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:03:00.569202
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids is not None

# Generated at 2022-06-20 18:03:04.760446
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    coll = FcWwnInitiatorFactCollector()
    assert coll.name == 'fibre_channel_wwn'
    assert coll._fact_ids == set()


# Generated at 2022-06-20 18:03:13.185150
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Tests the method collect of class FcWwnInitiatorFactCollector """
    collected_facts = {}
    fact_collector = FcWwnInitiatorFactCollector()
    facts_data = fact_collector.collect(None, collected_facts)
    assert 'fibre_channel_wwn' in facts_data
    assert isinstance(facts_data['fibre_channel_wwn'], list)
    if sys.platform.startswith('linux') or sys.platform.startswith('aix') or sys.platform.startswith('hp-ux'):
        assert '21000014FF52A9BB' in facts_data['fibre_channel_wwn']
    elif sys.platform.startswith('sunos'):
        assert '2100002400336e82' in facts_

# Generated at 2022-06-20 18:03:16.223425
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_obj = FcWwnInitiatorFactCollector()
    assert fcwwn_obj is not None

# Generated at 2022-06-20 18:03:21.485416
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fcwwn_obj = FcWwnInitiatorFactCollector()
    assert type(fcwwn_obj).__name__ == 'FcWwnInitiatorFactCollector'
    assert fcwwn_obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:04:09.048222
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert len(fc.collect().keys()) == 0
    assert isinstance(fc.collect()['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:04:14.510894
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method FcWwnInitiatorFactCollector.collect.
    """
    # Test when /sys/class/fc_host/*/port_name is accessible
    import os
    import tempfile
    import sys

# Generated at 2022-06-20 18:04:23.781033
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    class MockModule(object):
        def __init__(self):
            self.params = {}
        def run_command(self, cmd):
            if 'ioscan' in cmd:
                if cmd.split(' ')[-1] == 'FC':
                    return 0, ioscan_fc_output, None
                else:
                    return 1, '', 'ioscan failed'
            elif 'fcmsutil' in cmd:
                return 0, fcmsutil_output, None
            elif 'lsdev' in cmd:
                return 0, lsdev_out, None
            elif 'lscfg' in cmd:
                return 0, lscfg_out, None
            elif 'fcinfo' in cmd:
                return 0, fcinfo_out, None
            else:
                return 1, '', 'Test Failed'



# Generated at 2022-06-20 18:04:24.567382
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:04:27.901477
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'

    assert fc._fact_ids == set()

# Generated at 2022-06-20 18:04:37.566747
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd):
            if 'ioscan' in cmd:
                return (0,
                        '\n  Class  I  H/W Path  Driver\n   S/W   State  H/W Type  Description\n  =====  ====  =========  ========\n  FC     2    0/4/0/0    fcd\n  FC     2    0/5/0/0    fcd\n  FC     2    0/6/0/0    fcd\n  FC     2    0/7/0/0    fcd\n',
                        '')

# Generated at 2022-06-20 18:04:40.347926
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    x = FcWwnInitiatorFactCollector()
    assert x
    assert len(x._fact_ids) == 1
    assert x.name == "fibre_channel_wwn"
    assert x.name in x._fact_ids

# Generated at 2022-06-20 18:04:43.432890
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'
    assert FcWwnInitiatorFactCollector._fact_ids == set()


# Generated at 2022-06-20 18:04:49.351712
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    assert fc_facts.has_key('fibre_channel_wwn')
    assert isinstance(fc_facts['fibre_channel_wwn'], list)


# Generated at 2022-06-20 18:05:01.363312
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class TestModule():
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def fail_json(self, **kwargs):
            assert False

        def get_bin_path(self, arg, **kwargs):
            if arg == 'fcinfo':
                return '/usr/sbin/fcinfo'
            if arg == 'lsdev':
                return '/usr/sbin/lsdev'
            if arg == 'lscfg':
                return '/usr/sbin/lscfg'
            if arg == 'ioscan':
                return '/usr/sbin/ioscan'

# Generated at 2022-06-20 18:06:33.698463
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:06:47.812173
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    sys.path.append('/usr/lib/python2.7/site-packages/ansible')
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.fibre_channel
    fact_collector = ansible.module_utils.facts.collector.BaseFactCollector()
    fact_collector.collectors = [ansible.module_utils.facts.system.fibre_channel.FcWwnInitiatorFactCollector]
    ansible.module_utils.facts.utils.get_file_lines = \
        lambda file: ['21000014ff52a9bb\n']
    facts = fact_collector.collect(module=None, collected_facts={})

# Generated at 2022-06-20 18:06:53.355443
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector().collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts.keys()


# Generated at 2022-06-20 18:06:56.786683
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    wwn = FcWwnInitiatorFactCollector()
    assert wwn.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:03.962876
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact_collector = FcWwnInitiatorFactCollector()
    assert fact_collector is not None
    assert fact_collector.name == 'fibre_channel_wwn'
    #TODO: Add tests

# Unit test of main function

# Generated at 2022-06-20 18:07:13.624113
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    FcWwnInitiatorFactCollector: Test function for collect method.
    """

    class MyModule(object):
        def get_bin_path(self, exe, opt_dirs=[]):
            return exe

        def run_command(self, cmd):
            return 0, cmd, ""


    with open("fcs_debug.out", "r") as f:
        fcs_debug_out = f.read()

    class MyFile(object):
        def __init__(self, ext):
            if ext == 'linux':
                self.content = "0x21000014ff52a9bb\n"
            elif ext == 'sunos':
                self.content = fcs_debug_out

# Generated at 2022-06-20 18:07:17.530837
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    myFacts = FcWwnInitiatorFactCollector()
    assert myFacts.name == 'fibre_channel_wwn'
    assert myFacts.collect() is None


# Generated at 2022-06-20 18:07:30.650994
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print('')
    print('+++++ Testing constructor of class FcWwnInitiatorFactCollector')
    print('+++++ Testing constructor of class BaseFactCollector')
    BaseFactCollector()
    fcwwn_fact_collector = FcWwnInitiatorFactCollector()
    print('+++++ Testing constructor of class FcWwnInitiatorFactCollector again')
    fcwwn_fact_collector_again = FcWwnInitiatorFactCollector()
    print('+++++ Testing method collect() of class BaseFactCollector')
    BaseFactCollector.collect()
    print('+++++ Testing method collect() of class FcWwnInitiatorFactCollector')
    FcWwnInitiatorFactCollector.collect()

# Generated at 2022-06-20 18:07:43.147053
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """Test if inventory data is properly collected"""

    # Dummy module and facts
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    collected_facts = {}

    # The fact collector instance
    fact_collector = FcWwnInitiatorFactCollector()

    # Dummy facts
    fc_facts = fact_collector.collect(module=module, collected_facts=collected_facts)

    fibrecwwn = fc_facts['fibre_channel_wwn']

    assert fibrecwwn is not None, "fibre_channel_wwn is none"
    assert isinstance(fibrecwwn, list), "fibre_channel_wwn is not of type list"

# Generated at 2022-06-20 18:07:50.432870
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import platform
    import unittest
    import io

    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import collector


    # Mock module
    class MockModule():
        def __init__(self):
            self.params = {}
            self.options = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'ioscan':
                return '/usr/sbin/ioscan'
            elif arg == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            elif arg == 'fcinfo':
                return '/usr/sbin/fcinfo'
            else:
                return None
