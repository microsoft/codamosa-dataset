

# Generated at 2022-06-20 17:59:33.195398
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    class Module(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, tool, opt_dirs=None):
            return None

    module = Module()
    fc = FcWwnInitiatorFactCollector(module)
    assert fc.name == 'fibre_channel_wwn'

    assert fc.collect() == {'fibre_channel_wwn':[]}

# Generated at 2022-06-20 17:59:35.900698
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    unit_test_obj = FcWwnInitiatorFactCollector()
    assert unit_test_obj.name == "fibre_channel_wwn"
    assert id(unit_test_obj._fact_ids) == id(unit_test_obj.collect())


# Generated at 2022-06-20 17:59:42.513484
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():

    fc_collector = FcWwnInitiatorFactCollector()

    assert fc_collector.name == 'fibre_channel_wwn'

    assert 'fibre_channel_wwn' in fc_collector.get_facts()
    assert 'fibre_channel_wwn' in fc_collector._fact_ids

# Generated at 2022-06-20 17:59:45.576676
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    arg_facts = {}
    obj = FcWwnInitiatorFactCollector(None, arg_facts)
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 17:59:47.288499
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    facts = FcWwnInitiatorFactCollector.collect({})
    assert len(facts['fibre_channel_wwn']) > 0

# Generated at 2022-06-20 17:59:58.280338
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import sys
    if sys.platform.startswith('linux'):
        expected = {'fibre_channel_wwn': [u'21000014ff52a9bb']}
    elif sys.platform.startswith('sunos'):
        expected = {'fibre_channel_wwn': [u'21000014ff52a9bb']}
    elif sys.platform.startswith('aix'):
        expected = {'fibre_channel_wwn': [u'21000014FF52A9BB']}
    elif sys.platform.startswith('hp-ux'):
        expected = {'fibre_channel_wwn': [u'21000014FF52A9BB']}
    else:
        expected = {'fibre_channel_wwn': []}

# Generated at 2022-06-20 18:00:05.008479
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts = FcWwnInitiatorFactCollector()
    result = fc_facts.collect()
    assert sorted(result.keys()) == ['fibre_channel_wwn']
    assert isinstance(result['fibre_channel_wwn'], list)

# Generated at 2022-06-20 18:00:09.450690
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc = FcWwnInitiatorFactCollector()
    fc_facts = fc.collect()
    assert fc_facts['fibre_channel_wwn'] == ['50060b00006975ec','50060b00006975ec','50060b00006975ec','50060b00006975ec']

# Generated at 2022-06-20 18:00:10.199521
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc is not None

# Generated at 2022-06-20 18:00:15.793405
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule(object):
        def __init__(self):
            self.params = None

        @staticmethod
        def get_bin_path(binary):
            if binary == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif binary == 'lsdev':
                return '/usr/sbin/lsdev'
            elif binary == 'lscfg':
                return '/usr/sbin/lscfg'
            elif binary == 'ioscan':
                return '/usr/sbin/ioscan'
            elif binary == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            else:
                return None

# Generated at 2022-06-20 18:00:40.646988
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """ Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    import tempfile
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector

    class FakeAnsibleModule (object):

        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return


# Generated at 2022-06-20 18:00:46.093756
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Test constructor of class FcWwnInitiatorFactCollector")
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:00:49.835098
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'
    assert isinstance(obj._fact_ids, set)
    assert obj._fact_ids == set()


# Generated at 2022-06-20 18:01:03.396260
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import platform
    testFacts = {}
    if platform.system() == 'Linux':
        testFacts = {'fibre_channel_wwn': ['21000014ff52a9bb']}
    elif platform.system() == 'SunOS':
        testFacts = {'fibre_channel_wwn': ['10000090fa1658de']}
    elif platform.system() == 'AIX':
        testFacts = {'fibre_channel_wwn': ['10000090FA551509']}
    elif platform.system() == 'HP-UX':
        testFacts = {'fibre_channel_wwn': ['50060b00006975ec']}
    else:
        testFacts = {'fibre_channel_wwn': ['Unknown platform']}
    this

# Generated at 2022-06-20 18:01:12.306749
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """

    # initialize the class
    fc = FcWwnInitiatorFactCollector()

    # prepare data
    module = FakeAnsibleModule()

    # test if module is not available
    if not fc.get_bin_path(module, 'fcinfo'):
        assert fc.collect(FcWwnInitiatorFactCollector(), module) == {}
        return


# Generated at 2022-06-20 18:01:14.241605
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fwfc = FcWwnInitiatorFactCollector()
    assert fwfc.name == 'fibre_channel_wwn'
    assert fwfc.priority == 80

# Generated at 2022-06-20 18:01:25.079332
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.facts import FACT_CACHE
    import os, tempfile
    tmp_dir = tempfile.mkdtemp()
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = ['all']
            self.params['gather_timeout'] = 10
            self._socket_path = tmp_dir
        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return True

# Generated at 2022-06-20 18:01:35.046807
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    """
    This unit test verifies the constructor method of the class
    FcWwnInitiatorFactCollector.
    """

    # Construct the class and check it was done with success
    obj = FcWwnInitiatorFactCollector()
    assert(obj is not None)
    assert(isinstance(obj, FcWwnInitiatorFactCollector))

    # Check the name property
    assert(obj.name == 'fibre_channel_wwn')


# Generated at 2022-06-20 18:01:37.191397
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    print("Test symmetric_encryption value")
    c = FcWwnInitiatorFactCollector()
    assert c.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:01:50.452895
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import tempfile
    from ansible.module_utils.facts import Facts

    # Make temporary filesystem
    files = {}
    root = tempfile.mkdtemp(prefix='ansible_test_local')

    def cleanup():
        for f in files.values():
            try:
                os.unlink(f)
            except:
                pass
        try:
            os.removedirs(root)
        except:
            pass

    # Prepare temp filesystem content
    files['/sys/class/fc_host/1/port_name'] = '/sys/class/fc_host/1/port_name'
    f = open(files['/sys/class/fc_host/1/port_name'], 'w')
    f.write("0x21000014ff52a9bb")
    f.close()

# Generated at 2022-06-20 18:02:23.230373
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Unit test for method collect of class FcWwnInitiatorFactCollector
    """
    import platform
    import ansible.module_utils.facts.collector

    class MockModule(object):
        """
        Mock class for AnsibleModule
        """
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            """
            fail_json mock
            """
            raise Exception(args[0])

        def run_command(self, *args, **kwargs):
            """
            run_command mock
            """
            # on Solaris 10 or Solaris 11

# Generated at 2022-06-20 18:02:33.923829
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcwwn_fc_host_paths = set()
    fcwwn_fc_host_paths.add("/sys/class/fc_host/host0/port_name")
    fcwwn_fc_host_paths.add("/sys/class/fc_host/host1/port_name")
    test_files = {
        '/sys/class/fc_host/host0/port_name': """0x21000014ff52a9bb""",
        '/sys/class/fc_host/host1/port_name': """0x21000014ff52a9bc"""
    }
    fc = FcWwnInitiatorFactCollector(None)
    fc_facts = fc.collect({'get_file_lines': lambda x: test_files[x]}, None)

# Generated at 2022-06-20 18:02:35.266460
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    assert FcWwnInitiatorFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:40.712068
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector

    module = AnsibleModuleMock()
    modules = [ 'fcinfo','lscfg','ioscan','fcmsutil' ]
    paths = [ '/usr/sbin', '/opt/fcms/bin' ]

    for mod in modules:
        module.get_bin_path.add_custom_answer(mod, None, paths)

    module.run_command.add_custom_answer("which ioscan", 0, "/usr/sbin/ioscan")
    module.run_command.add_custom_answer("which fcmsutil", 0, "/opt/fcms/bin/fcmsutil")

    facts_collector = FactCollector(module=module)

# Generated at 2022-06-20 18:02:43.414707
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    osFacts = { 'distribution': 'solaris' }
    fcFactCollector = FcWwnInitiatorFactCollector(None, None, osFacts)
    assert fcFactCollector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:02:48.489117
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    unit test for collect
    """

    # initialize
    facts = {}
    expected = {'fibre_channel_wwn': ['21000014ff52a9bb']}

    # initialize
    fc = FcWwnInitiatorFactCollector()

    # mock read_file lines
    fc.read_file_lines = mock_read_file_lines

    # call collect
    fc.collect(facts=facts)

    # test result
    assert facts['fibre_channel_wwn'] == expected['fibre_channel_wwn']


# Generated at 2022-06-20 18:02:51.173742
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_facts = {}
    fc_facts['fibre_channel_wwn'] = []
    fc_facts['fibre_channel_wwn'].append('21000014ff52a9bb')
    assert fc_facts == FcWwnInitiatorFactCollector()

# Generated at 2022-06-20 18:03:00.528042
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # Create a FcWwnInitiatorFactCollector object
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    # Create a dictionary to pass module_utils params
    module_params = {}
    # Collect the facts
    facts = fc_wwn_initiator_fact_collector.collect(module=module_params)
    # Assert that the returned dictionary is not empty
    assert len(facts) > 0

# Generated at 2022-06-20 18:03:08.527947
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts import ansible_collection
    collector = ansible_collection.get_collector(Collectors, 'fibre_channel_wwn')
    fc_facts = collector.collect()
    assert isinstance(fc_facts, dict)
    assert 'fibre_channel_wwn' in fc_facts



# Generated at 2022-06-20 18:03:10.934376
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fact = FcWwnInitiatorFactCollector()
    assert fact.name == 'fibre_channel_wwn'
    assert fact._fact_ids == set()


# Generated at 2022-06-20 18:04:05.665439
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    test_data = {
        'fibre_channel_wwn': ['21000014ff52a9bb', '21000014ff52a9bc'],
    }

    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=('0', test_data['fibre_channel_wwn'][0], ''))
    fc_oci = FcWwnInitiatorFactCollector(None)
    result =  fc_oci.collect(module=module)
    assert result == test_data



# Generated at 2022-06-20 18:04:18.260689
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import json
    import sys

    class MockModule:
        def __init__(self):
            self.run_command_args = None

        def run_command(self, args):
            self.run_command_args = args
            return 0, '', ''

    class MockSystem:
        def __init__(self, os_name, machine):
            self.os_name = os_name
            self.machine = machine

    class MockOS:
        def __init__(self):
            self.system = MockSystem('linux', 'x86_64')

    sys.modules['os'] = MockOS()

    module = MockModule()
    fact_collector = FcWwnInitiatorFactCollector()
    facts = fact_collector.collect(module=module)
    assert isinstance(facts, dict)

# Generated at 2022-06-20 18:04:31.403454
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    # Write testcase(s)
    # Pass special keyword arguments to constructor
    # that are supported by the constructed object
    o = FcWwnInitiatorFactCollector(name='testname')
    # Check if constructor gives desired results
    if o.name != 'testname':
        raise Exception("Failed to create an instance of FcWwnInitiatorFactCollector with valid keyword arguments")
    # Pass invalid keyword argument to constructor
    # and check if exception is raised
    raised = False
    try:
        o = FcWwnInitiatorFactCollector(invalid='invalid')
    except BaseException as e:
        raised = True
    if not raised:
        raise Exception("Failed to raise exception for invalid keyword argument for FcWwnInitiatorFactCollector")

    # if you want to test the collect method,

# Generated at 2022-06-20 18:04:39.337807
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.test_utils import get_test_data

    output_dict = {}
    output_dict['fibre_channel_wwn'] = ['21000014ff52a9bb',
                                        '21000014ff52a9b7',
                                        '21000014ff52a9b8',
                                        '21000014ff52a9bb',
                                        '21000014ff52a9bc']
    output_file = get_test_data('fcwwn_output_linux.txt')
    with open(output_file, 'r') as f:
        output = f.read()
    collector = Collector()

# Generated at 2022-06-20 18:04:41.282356
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'


# Generated at 2022-06-20 18:04:44.652900
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc = FcWwnInitiatorFactCollector()
    assert fc.name == 'fibre_channel_wwn'
    assert fc._fact_ids == set()

# Generated at 2022-06-20 18:04:56.266155
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    import os
    import mock
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collectors

    mock_module = mock.MagicMock()
    mock_module.get_bin_path.return_value = 'SomePath'
    mock_module.run_command.side_effect = [
      ('0', 'SomePath', ''),
      ('0', 'ioscan: ', ''),
      ('0', 'SomePath', '')
    ]

    mock_collector = Collector()
    mock_collector.collect.return_value = {'fibre_channel_wwn': ['1', '2', '3']}


# Generated at 2022-06-20 18:05:01.038518
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_obj = FcWwnInitiatorFactCollector()
    fact_list = fc_obj.collect()
    assert 'fibre_channel_wwn' in fact_list
    assert fact_list['fibre_channel_wwn']

# Generated at 2022-06-20 18:05:05.421182
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """
    Test FcWwnInitiatorFactCollector.collect()

    """

    from ansible.module_utils.facts.collector import Collector
    import pytest

    facts = Collector().collect(validate_extracted_facts=False)

    assert 'fibre_channel_wwn' in facts

# Generated at 2022-06-20 18:05:06.601996
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()


# Generated at 2022-06-20 18:06:04.108523
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fc_facts_result = {
        'fibre_channel_wwn': ['21000014ff52a9bb'],
        'fibre_channel_wwn_count': 1
    }

    class MockModule(object):
        def get_bin_path(self, arg1, arg2=None):
            # simulate that command exists
            return 'test_fcinfo'

        def run_command(self, arg1):
            # simulate that command was executed
            return 0, 'test_out', 'test_error'

    def test_run_command(arg1):
        return 0, 'test_out', 'test_error'

    fc_facts_collector = FcWwnInitiatorFactCollector()
    fc_facts = fc_facts_collector.collect(MockModule())
   

# Generated at 2022-06-20 18:06:09.598040
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator_fact_collector = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator_fact_collector.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:06:13.328268
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fw = FcWwnInitiatorFactCollector()
    assert fw.name == 'fibre_channel_wwn'
    assert fw._fact_ids == set()
    assert fw.names == {'fibre_channel_wwn'}

# Generated at 2022-06-20 18:06:20.793743
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    # create empty module
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    # create empty facts
    facts = {}
    # obtain facts with module
    fc_collector = FcWwnInitiatorFactCollector(module=module, facts=facts)
    new_facts = fc_collector.collect(module=module, collected_facts=facts)
    # check if we have the right set of facts
    fc_facts = new_facts.get('fibre_channel_wwn', None)
    assert fc_facts is not None
    # ensure we have at least one value in the list
    assert len(fc_facts) > 0
    # ensure we have the right values in the list
    # linux: '0x21000014ff52a9bb'
    # solaris

# Generated at 2022-06-20 18:06:28.510740
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    """

    Unit test for method collect of class FcWwnInitiatorFactCollector

    """

    fc_facts = dict()

    fc_facts['fibre_channel_wwn'] = ['0x21000014ff52a9bb']

    fcwwn_fc = FcWwnInitiatorFactCollector()
    my_facts = fcwwn_fc.collect()

    assert fc_facts == my_facts

if __name__ == '__main__':
    test_FcWwnInitiatorFactCollector_collect()

# Generated at 2022-06-20 18:06:31.294630
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    module = AnsibleModuleMock()
    fc_facts = FcWwnInitiatorFactCollector().collect(module)
    assert fc_facts['fibre_channel_wwn']

# Generated at 2022-06-20 18:06:34.155513
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    collector = FcWwnInitiatorFactCollector()
    assert collector.name == 'fibre_channel_wwn'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 18:06:46.558906
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():

    import mock
    import sys

    # setup mock object and set the return value of sys.platform
    mock_open = mock.mock_open()
    with mock.patch('ansible.module_utils.facts.collector.open', mock_open, create=True):
        collected_facts = FcWwnInitiatorFactCollector().collect()

    # only linux is supported right now
    assert 'fibre_channel_wwn' in collected_facts

    # test if the mock was called with the correct paramaters
    mock_open.assert_called_with('/sys/class/fc_host/*/port_name')



# Generated at 2022-06-20 18:06:49.843020
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    obj = FcWwnInitiatorFactCollector()
    assert obj.name == 'fibre_channel_wwn'

# Generated at 2022-06-20 18:07:00.869140
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    fcp = FcWwnInitiatorFactCollector()
    # construct a module object with default values, returning suitable fakes for
    # get_bin_path and run_command.
    class FakeModule(object):
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'lsdev':
                return '/usr/sbin/lsdev'
            elif name == 'lscfg':
                return '/usr/sbin/lscfg'
            elif name == 'fcinfo':
                return '/usr/sbin/fcinfo'
            elif name == 'ioscan':
                return '/usr/sbin/ioscan'
            elif name == 'fcmsutil':
                return '/opt/fcms/bin/fcmsutil'
            return None

# Generated at 2022-06-20 18:08:58.215053
# Unit test for constructor of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector():
    fc_wwn_initiator = FcWwnInitiatorFactCollector()
    assert fc_wwn_initiator.name == 'fibre_channel_wwn'
    assert fc_wwn_initiator._fact_ids == set()


# Generated at 2022-06-20 18:09:01.972263
# Unit test for method collect of class FcWwnInitiatorFactCollector
def test_FcWwnInitiatorFactCollector_collect():
    factClass = FcWwnInitiatorFactCollector()
    print(factClass.collect())
    assert isinstance(factClass.collect(), dict)
