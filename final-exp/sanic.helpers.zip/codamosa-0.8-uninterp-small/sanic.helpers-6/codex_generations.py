

# Generated at 2022-06-26 03:25:11.091470
# Unit test for function import_string
def test_import_string():
    class_1 = import_string('dataclasses.dataclass')
    assert(class_1.__name__ == "dataclass")

# Generated at 2022-06-26 03:25:17.165094
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({'allow': 'GET, POST', 'content-type': 'text/html; charset=utf-8',
                                  'content-range': '100-200/300',
                                  'connection': 'close', 'keep-alive': '10', 'proxy-authenticate': 'ok',
                                  'proxy-authorization': 'ok'}) == {'allow': 'GET, POST'}



# Generated at 2022-06-26 03:25:23.334862
# Unit test for function has_message_body
def test_has_message_body():
    dict_1 = {}
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False


# Generated at 2022-06-26 03:25:25.793519
# Unit test for function import_string
def test_import_string():
    result = import_string("http.cookies.SimpleCookie")
    assert result.value == "SimpleCookie"



# Generated at 2022-06-26 03:25:27.374939
# Unit test for function import_string
def test_import_string():
    print(import_string("test_main.test_case_0"))


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:25:34.281448
# Unit test for function import_string
def test_import_string():
    assert import_string('typing.Union') == Union
    assert import_string('typing.Any', package='typing') == Any
    assert import_string('typing.Any') == Any

# Generated at 2022-06-26 03:25:45.917099
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    dict_1 = {}
    dict_1["Accept-language".lower()] = "en-US,en;q=0.9"
    dict_1["Accept-Encoding".lower()] = "gzip, deflate, br"
    dict_1["Accept".lower()] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"
    dict_1["Cookie".lower()] = "__cfduid=dca2d0cc24e2c2ff1b9323679ce0f9b0e1525883817"
    dict_1["Pragma".lower()] = "no-cache"
    dict_1["Cache-Control".lower()] = "no-cache"
   

# Generated at 2022-06-26 03:25:55.958579
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # Test case 0
    dict_0 = {'Content-Type': 'text/html', 'Content-Location': 'http://www.w3schools.com/images/myw3schoolsimage.jpg', 'Content-Length': '45454545'}
    var_0 = remove_entity_headers(dict_0)
    assert var_0 == {'Content-Location': 'http://www.w3schools.com/images/myw3schoolsimage.jpg', 'Content-Length': '45454545'}
    # Test case 1

# Generated at 2022-06-26 03:26:02.483690
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    dict_0 = {}
    dict_0.update({"Content-Type": "application/json", "Expire": "now"})
    dict_0.update({"Expires": "now"})
    dict_1 = {"Content-Type": "application/json", "Expire": "now"}
    assert(dict_0 == dict_1)
    dict_0 = {"Content-Type": "application/json", "Expire": "now"}
    dict_1 = remove_entity_headers(dict_0)
    dict_2 = {"Expire": "now"}
    assert(dict_1 == dict_2)
    dict_1 = remove_entity_headers(dict_0, ['Expire'])
    dict_2 = {"Expire": "now"}
    assert(dict_1 == dict_2)

# Generated at 2022-06-26 03:26:07.774096
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(102)
    assert has_message_body(200)
    assert has_message_body(404)
    assert has_message_body(200)
    assert has_message_body(400)


# Generated at 2022-06-26 03:26:12.945206
# Unit test for function import_string
def test_import_string():
    # Case list
    cases = [
        {
            "name": "test_case_0",
        },
    ]

    for case in cases:
        print("---> Case %s:" % (case["name"]))
        # Build up
        var_0 = {}
        # Execute
        globals()[case["name"]]()
        # Verify
        assert (var_0 == case["expected"])



# Generated at 2022-06-26 03:26:23.221532
# Unit test for function import_string
def test_import_string():
    assert import_string("os.path") is not None
    assert import_string("os.path.isfile") is not None
    assert import_string("os.path.isfile") is not None
    assert import_string("os.path") is not None
    assert import_string("os.path.isfile") is not None
    assert import_string("os.path") is not None
    assert import_string("os.path.isfile") is not None
    assert import_string("os.path.isfile") is not None
    assert import_string("os.path.isfile") is not None
    assert import_string("os.path.isfile") is not None
    assert import_string("os.path") is not None
    assert import_string("os.path.isfile") is not None

# Generated at 2022-06-26 03:26:27.938992
# Unit test for function import_string
def test_import_string():
    print("Testing import_string()")

    try:
        test_case_0()
        assert(True)
    except:
        assert(False)
    print("Passed all tests!")


# Run tests for import_string
if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:26:29.169006
# Unit test for function import_string
def test_import_string():
    assert(test_case_0() == None)

# Generated at 2022-06-26 03:26:35.011529
# Unit test for function import_string
def test_import_string():
    # Test case for successful import
    assert import_string("hashlib.md5").hexdigest(b"") == "d41d8cd98f00b204e9800998ecf8427e"
    # Test case for partial import
    assert import_string("os.walk").hexdigest(b"") == "d41d8cd98f00b204e9800998ecf8427e"



# Generated at 2022-06-26 03:26:38.872352
# Unit test for function import_string
def test_import_string():
    assert ismodule(import_string("importlib.import_module"))
    assert ismodule(import_string("_frozen_importlib", "importlib"))

print("Testing function import_string")
test_import_string()

# Generated at 2022-06-26 03:26:40.160917
# Unit test for function import_string
def test_import_string():
    pass


# Generated at 2022-06-26 03:26:52.141660
# Unit test for function import_string
def test_import_string():
    url = "https://github.com/juancarlospaco/sociosync"
    assert import_string(url).geturl() == url
    assert import_string(url).headers["User-Agent"] == "Mozilla/5.0 Gecko/20100101 Firefox/68.0"
    assert import_string(url).geturl() != None
    assert import_string(url).info().get_content_type() == "text/html"
    assert import_string(url).getcode() == 200
    assert import_string(url).info()["content-length"] > 10
    assert import_string(url).info()["content-length"] > 200
    assert import_string(url).info().get_content_maintype() == "text"

# Generated at 2022-06-26 03:26:58.105319
# Unit test for function import_string
def test_import_string():
    # Simple importation
    assert import_string("autobahn.asyncio.wamp.ApplicationSession")

    # Import and instanciation of a class
    assert isinstance(
        import_string("autobahn.wamp.protocol.WampServerFactory"),
        import_module("autobahn.wamp.protocol").WampServerFactory,
    )

    # Import a module
    assert import_string("autobahn.websocket.types")

    # Import and instanciation of a class
    assert isinstance( import_string("autobahn.websocket.protocol.WebSocketServerFactory"),
                       import_module("autobahn.websocket.protocol").WebSocketServerFactory)

    var_0 = {}

# Generated at 2022-06-26 03:27:10.417714
# Unit test for function import_string
def test_import_string():
    var_0 = import_string("datasets.utf8.utf8_samples")
    assert isinstance(var_0, module)
    var_0 = import_string("datasets.utf8.utf8_samples.ValidUTF8Sample")
    assert isinstance(var_0, ValidUTF8Sample)
    var_0 = import_string("datasets.utf8.utf8_samples.InvalidUTF8Sample")
    assert isinstance(var_0, InvalidUTF8Sample)
    assert var_0.data == b"\xf1\x80\x80\x80"
    assert var_0.description == "a 4 byte sequences with only 3 bytes of data"
    var_0 = import_string("datasets.utf8.utf8_samples.Sample")