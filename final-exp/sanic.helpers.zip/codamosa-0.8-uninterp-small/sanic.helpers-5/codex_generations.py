

# Generated at 2022-06-26 03:25:09.196969
# Unit test for function import_string
def test_import_string():
    """
    Test import_string

    """
    from .utils import FakeHeaders
    from .handlers import BaseHTTPRequestHandler
    headers = FakeHeaders()
    headers["content-location"] = "www.sample.com"
    headers["expires"] = "2020-12-12"
    teste = import_string("http.server.BaseHTTPRequestHandler");
    assert (teste == BaseHTTPRequestHandler)

# Generated at 2022-06-26 03:25:19.901364
# Unit test for function import_string
def test_import_string():
    # Case 0
    test_case_0()
    # Case Absolute path
    from test_module import test_class
    assert import_string("test_module.test_class") == test_class
    assert isinstance(import_string("test_module.test_class"), test_class)
    # Case Relative path
    from tests.test_http.test_module import test_class as test_class_1
    assert import_string("test_module.test_class", "tests.test_http") == test_class_1
    assert isinstance(import_string("test_module.test_class", "tests.test_http"), test_class_1)
    # Case No package
    assert isinstance(import_string("test_module.test_class"), test_class)

# Generated at 2022-06-26 03:25:27.165940
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    var_0 = {'Content-Length': '0',
             'Content-Range': 'bytes 0-0/0'}
    var_1 = remove_entity_headers(var_0)

# Generated at 2022-06-26 03:25:29.216437
# Unit test for function import_string
def test_import_string():
    res = import_string("aiohttp.web.Application")
    res.__class__.__name__ == 'Application'



# Generated at 2022-06-26 03:25:34.280590
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False

if __name__ == "__main__":
    test_case_0() 
    test_has_message_body()

# Generated at 2022-06-26 03:25:43.154378
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    dict_0 = dict(content_location = "examples/test.py", expires = "testing")
    dict_1 = remove_entity_headers(dict_0, allowed = ["content_type", "expires"])
    assert dict_1 == dict(content_location = "examples/test.py")
    dict_0 = dict(content_location = "examples/test.py", expires = "testing")
    dict_1 = remove_entity_headers(dict_0, allowed = ["expires"])
    assert dict_1 == dict(content_location = "examples/test.py", expires = "testing")


# Generated at 2022-06-26 03:25:45.427358
# Unit test for function import_string
def test_import_string():
    obj_0 = import_string("helloworld.helloworld", package=None)
    assert obj_0.__class__.__name__ == "HelloWorld"


# Generated at 2022-06-26 03:25:47.625456
# Unit test for function import_string
def test_import_string():
    # Test for import module
    module_name = "httpcore.utilities.header"
    obj = import_string(module_name)
    assert obj.__name__ == module_name

# Generated at 2022-06-26 03:25:50.059685
# Unit test for function has_message_body
def test_has_message_body():
    int_0 = 500
    bool_0 = has_message_body(int_0)


# Generated at 2022-06-26 03:25:51.674644
# Unit test for function import_string
def test_import_string():
    assert import_string("tests.test_http.import_string")


# Generated at 2022-06-26 03:26:01.018824
# Unit test for function import_string
def test_import_string():
    valid_module = "httpolice.citation.citation"
    assert isinstance(import_string(valid_module), object)

    valid_class = "httpolice.citation.citation.Citation"
    assert isinstance(import_string(valid_class), object)

    invalid_class = "httpolice.citation.citation.Citation1"
    assert isinstance(import_string(invalid_class), object) == False

    invalid_module = "httpolice.citation.citation1"
    assert isinstance(import_string(invalid_module), object) == False

    invalid_module = "httpolice.citation.citation1.Citation1"
    assert isinstance(import_string(invalid_module), object) == False

# Generated at 2022-06-26 03:26:03.770712
# Unit test for function has_message_body
def test_has_message_body():
    status_0 = None
    bool_0 = has_message_body(status_0)
    print("bool_0 = " + str(bool_0))


# Generated at 2022-06-26 03:26:07.435130
# Unit test for function import_string
def test_import_string():
    try:
        import_string("standard.http_core.has_message_body")
    except ImportError:
        print("Error: function import_string not found")
        raise AssertionError


# Generated at 2022-06-26 03:26:15.679692
# Unit test for function has_message_body
def test_has_message_body():
    status = 100
    print(
        "has_message_body(status): {0}".format(has_message_body(status))
    )



# Generated at 2022-06-26 03:26:21.931404
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(205)
    assert has_message_body(206)


# Generated at 2022-06-26 03:26:23.382116
# Unit test for function import_string
def test_import_string():
    assert import_string("aiohttp.web", __package__)

# Generated at 2022-06-26 03:26:27.358874
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert has_message_body(200)
    assert has_message_body(400)



# Generated at 2022-06-26 03:26:28.623388
# Unit test for function import_string
def test_import_string():
    var_1 = import_string(var_0)


# Generated at 2022-06-26 03:26:30.639906
# Unit test for function has_message_body
def test_has_message_body():
    assert (has_message_body(100))
    assert (has_message_body(200))


# Generated at 2022-06-26 03:26:32.601936
# Unit test for function has_message_body
def test_has_message_body():
    num_0 = 100
    bool_0 = has_message_body(num_0)



# Generated at 2022-06-26 03:26:43.136123
# Unit test for function import_string
def test_import_string():
    #
    print('testing import_string() ...')
    #
    # test case 0
    str_0 = 'aiohttp.web'
    module_0 = import_string(str_0)
    print('module: ', module_0)

    # test case 1
    str_1 = 'aiohttp.web.Application'
    app_1 = import_string(str_1)
    print('app: ', app_1)

    # test case 2
    #str_2 = 'aiohttp.web.Response'
    #Response_2 = import_string(str_2)
    #print('Response: ', Response_2)

    # test case 3
    #str_3 = 'aiohttp.web.Application.make_handler'
    #make_handler_3 = import_string(str_3)


# Generated at 2022-06-26 03:26:47.205213
# Unit test for function import_string
def test_import_string():
    import_string(str_0)

if __name__ == "__main__":
    # Unit test for function test_case_0
    test_case_0()

    # Unit test for function import_string
    test_import_string()

# Generated at 2022-06-26 03:26:48.007181
# Unit test for function import_string
def test_import_string():
    pass


# Generated at 2022-06-26 03:26:48.599347
# Unit test for function import_string
def test_import_string():
    test_case_0()

# Generated at 2022-06-26 03:26:49.916770
# Unit test for function import_string
def test_import_string():
    import_string(str_0)


# Generated at 2022-06-26 03:26:56.730371
# Unit test for function import_string
def test_import_string():
    str_0 = 'aiohttp.web'
    result_0 = import_string(str_0)

# Generated at 2022-06-26 03:27:01.798071
# Unit test for function import_string
def test_import_string():

    # str_0 = 'my_package.my_subpackage.my_module.my_class'
    str_0 = 'aiohttp.web'

    # import module my_subpackage.my_module
    module = import_string(str_0, 'aiohttp')
    print(module)


# Generated at 2022-06-26 03:27:08.371285
# Unit test for function import_string
def test_import_string():
    assert import_string('aiohttp.web'), 'module aiohttp.web not imported'
    assert import_string('aiohttp.web.Application.run_app'), 'module aiohttp.web.Application not imported'
    assert import_string('aiohttp.web.Application.run_app')
    assert import_string('aiohttp.web.Application.run_app')


# Generated at 2022-06-26 03:27:16.511368
# Unit test for function import_string
def test_import_string():
    print('test_import_string():')
    print()
    case_0 = 'aiohttp.web'
    case_1 = 'aiohttp.web.Application'
    case_2 = 'aiohttp.web:Application'
    case_3 = 'asyncio.get_event_loop'
    case_4 = 'asyncio.get_event_loop'
    case_list = (case_0, case_1, case_2, case_3, case_4)
    for case in case_list:
        print(case, import_string(case))
    print()
    print('end of test_import_string()')
    print()

# Generated at 2022-06-26 03:27:17.271380
# Unit test for function import_string
def test_import_string():
    # test case 0
    assert test_case_0() == 'aiohttp.web'

# Generated at 2022-06-26 03:27:21.371498
# Unit test for function import_string
def test_import_string():
    import_string("datetime")
    import_string("datetime.datetime")



# Generated at 2022-06-26 03:27:23.451207
# Unit test for function import_string
def test_import_string():
    string_0 = 'app.app'
    module_0 = import_string(string_0)
    assert module_0



# Generated at 2022-06-26 03:27:29.455209
# Unit test for function import_string
def test_import_string():
    module_name = "example.package.module_name"
    assert module_name == import_string(module_name).__name__
    class_name = "example.package.ClassName"
    assert class_name == import_string(class_name).__class__.__name__


# Generated at 2022-06-26 03:27:31.828485
# Unit test for function import_string
def test_import_string():
    module = "test_http.test_case_0"
    package = "hypercorn.test"
    obj = import_string(module, package)

    assert not obj.var_0

# Generated at 2022-06-26 03:27:37.900849
# Unit test for function import_string
def test_import_string():
    import sys
    import_string("")
    import_string("sys")
    import_string("sys.version_info")
    import_string("sys.version_info.")
    import_string("sys.version_info.major")
    import_string("sys.version_info.minor")
    import_string("sys.version_info.micro")


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:27:39.791996
# Unit test for function import_string
def test_import_string():
    assert import_string("pwd") == import_module("pwd")
    assert import_string("pathlib.Path") == import_module("pathlib").Path

# Generated at 2022-06-26 03:27:42.927368
# Unit test for function import_string
def test_import_string():
    from .units import test_class_a
    obj = import_string('falcon.units.test_class_a')
    assert isinstance(obj, test_class_a)


# Generated at 2022-06-26 03:27:45.793786
# Unit test for function import_string
def test_import_string():
    test_module_string = "http.server.SimpleHTTPRequestHandler"
    assert ismodule(import_string(test_module_string))


test_case_0()
test_import_string()

# Generated at 2022-06-26 03:27:52.310972
# Unit test for function import_string
def test_import_string():
    from .views import some_view
    from .urls import some_urlpattern
    import unittest
    module = import_string("hikstest.views.some_view")
    self.assertEqual(module, some_view)
    klass = import_string("hikstest.urls.some_urlpattern")
    self.assertIsInstance(klass, some_urlpattern)


# Valid tests for has_message_body
# 100

# Generated at 2022-06-26 03:27:57.808847
# Unit test for function import_string
def test_import_string():
    module_1 = import_string(__name__ + ".basic_http")
    assert(module_1 is not None)
    assert(hasattr(module_1, "has_message_body"))
    module_2 = import_string(__name__ + ".basic_http", __name__)
    assert(module_1 == module_2)


# Generated at 2022-06-26 03:28:03.614642
# Unit test for function import_string
def test_import_string():
    # module_name: str with path of module or path to import and
    module_name = 'http.server'
    result = import_string(module_name)
    assert(result is not None)

# Generated at 2022-06-26 03:28:04.996486
# Unit test for function import_string
def test_import_string():
    global int
    int = None
    test_case_4()


# Generated at 2022-06-26 03:28:10.874745
# Unit test for function import_string
def test_import_string():
    import time

    assert time is import_string("time", "time")
    assert time.time is import_string("time.time", "time.time")

    # testing with classes
    import sys

    assert sys.version_info is import_string("sys:version_info", "sys")


if __name__ == "__main__":
    test_case_0()
    test_import_string()

# Generated at 2022-06-26 03:28:18.225642
# Unit test for function import_string
def test_import_string():
    import sys
    import random
    import string
    import pytest
    from types import ModuleType
    from urllib.request import Request
    from urllib.parse import urlparse 
    from requests.packages.urllib3.response import HTTPResponse
    from requests.packages.urllib3.util import ssl_
    from requests.packages.urllib3.exceptions import (
        ConnectTimeoutError,
        MaxRetryError,
    )
    from requests.packages.urllib3.connection import VerifiedHTTPSConnection
    from requests.packages.urllib3.connectionpool import (
        HTTPConnectionPool,
        HTTPSConnectionPool,
        connection_from_url,
        HTTPConnection,
        HTTPSConnection,
    )
    from requests.exceptions import ConnectTimeout
    import requests.packages.ur

# Generated at 2022-06-26 03:28:25.091169
# Unit test for function import_string
def test_import_string():
    obj = import_string("http.client")
    assert ismodule(obj)
    obj = import_string("http.client.HTTPResponse")
    from io import BytesIO
    stream = BytesIO(b"data")
    obj = obj.from_stream(stream, 0, 10)
    assert obj.read() == b"data"

# Generated at 2022-06-26 03:28:28.574415
# Unit test for function import_string
def test_import_string():
    import unittest
    from unittest.mock import patch
    from pyfaketcp import test_utils
    import_string = import_string
    module_name = "test_utils.test_utils.test_case_0"
    case_0 = import_string(module_name)
    assert callable(case_0)



# Generated at 2022-06-26 03:28:36.311197
# Unit test for function import_string
def test_import_string():
    import status
    result = import_string('status.Status')()
    assert result.code == 200
    assert result.reason == b"OK"
    assert result.version == "HTTP/1.1"
    assert result.status_line == b"HTTP/1.1 200 OK"

if __name__ == "__main__":
    from yapic.di import Injector

    Injector.test_case()
    Injector.test_configure_function_func()
    Injector.test_configure_function_decorator()

# Generated at 2022-06-26 03:28:38.448899
# Unit test for function import_string
def test_import_string():
    import_string("aiohttp.web_app.Application")
    import_string("app.app_factory.ApplicationFactory")
    import_string("app.app_factory.ApplicationFactory")

# Generated at 2022-06-26 03:28:44.278766
# Unit test for function import_string
def test_import_string():
    from kmip.pie.client import KMIPProxy
    from kmip.pie.server import KMIPServer

    # Import module
    module = import_string("kmip.pie.server")
    assert module is KMIPServer

    # Import and instanciate class
    object = import_string("kmip.pie.client.KMIPProxy")
    assert isinstance(object, KMIPProxy)

    # Import and instanciate class with custom package
    object = import_string("client.KMIPProxy", package="kmip.pie")
    assert isinstance(object, KMIPProxy)

# Generated at 2022-06-26 03:28:46.699525
# Unit test for function import_string
def test_import_string():
    from flask import Flask
    obj = import_string(module_name='flask.Flask')
    assert isinstance(obj, Flask)

