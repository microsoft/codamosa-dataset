

# Generated at 2022-06-26 03:25:16.036536
# Unit test for function has_message_body
def test_has_message_body():

    assert has_message_body(100) == True
    assert has_message_body(999) == True
    assert has_message_body(999) == True
    assert has_message_body(999) == True
    assert has_message_body(999) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_message_body(100) == True
    assert has_

# Generated at 2022-06-26 03:25:20.648584
# Unit test for function import_string
def test_import_string():
    import tempfile
    temp_file_name = tempfile.mktemp()
    str_0 = '@$b~.V*i\x0cZxTs.9s'
    with open(temp_file_name, 'w') as f:
        f.write(str_0)
    content = import_string(temp_file_name)
    assert content == str_0

# Generated at 2022-06-26 03:25:26.484630
# Unit test for function import_string
def test_import_string():
    assert import_string("asyncio") == import_module("asyncio")
    assert callable(import_string("http.client.HTTPConnection"))
    assert issubclass(import_string("asyncio.events.AbstractEventLoop"), object)


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:25:34.753612
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers('@$b~.V*i\x0cZxTs.9s') == '@$b~.V*i\x0cZxTs.9s'
    assert remove_entity_headers({'content-range': '\x1e\x16\x10\x01(4$\x0eV\x1e'}) == {'content-range': '\x1e\x16\x10\x01(4$\x0eV\x1e'}
    assert remove_entity_headers({'allow': 'T\x1d\x16\x04L'}, {'allow': 'T\x1d\x16\x04L'}) == {'allow': 'T\x1d\x16\x04L'}
    assert remove_entity_headers

# Generated at 2022-06-26 03:25:42.836369
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert len(remove_entity_headers("abc")) == 0
    assert len(remove_entity_headers("set-cookie")) == 0
    assert len(remove_entity_headers("content-length")) == 0
    assert len(remove_entity_headers("transfer-encoding")) == 0
    assert len(remove_entity_headers("expires")) == 1


# Generated at 2022-06-26 03:25:45.239413
# Unit test for function import_string
def test_import_string():
    assert import_string('srca.scripts.test') == 'test'

# Generated at 2022-06-26 03:25:55.196181
# Unit test for function import_string
def test_import_string():
    import pathlib
    d = pathlib.Path("pulse/app.py")
    # pathlib.Path.__str__() returns self.as_posix()
    path = str(d.resolve())
    module = import_string(path)
    print(module)
    # __package__ = ''
    assert module.__package__ == ''
    assert module.__name__ == 'pulse.app'
    # remove the .py from the end of the name
    path = path[:-3]
    module = import_string(path)
    print(module)
    # __package__ = 'pulse'
    assert module.__package__ == 'pulse'
    assert module.__name__ == 'pulse.app'
    # Test relative path
    # __package__ = 'pulse'

# Generated at 2022-06-26 03:25:58.843403
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(200) == True

# Test for function import_string

# Generated at 2022-06-26 03:26:09.801638
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # Test case 0
    # '@$b~.V*i\x0cZxTs.9s'
    str_0 = '@$b~.V*i\x0cZxTs.9s'
    var_0 = remove_entity_headers(str_0)
    assert isinstance(var_0, set)

    # Test case 1
    # '=[RSr~$H6U|>E{!b\x15h\x07<'
    str_0 = '=[RSr~$H6U|>E{!b\x15h\x07<'
    var_0 = remove_entity_headers(str_0)
    assert isinstance(var_0, set)

    # Test case 2
    # '\x0e\x03\x16\x15\

# Generated at 2022-06-26 03:26:11.324500
# Unit test for function import_string
def test_import_string():
    import_string('http.client')
    return True


# Generated at 2022-06-26 03:26:16.813608
# Unit test for function import_string
def test_import_string():
    assert import_string('http.client') == import_module('http.client')
    assert import_string('http.client.HTTPResponse') == import_module('http.client').HTTPResponse


# Generated at 2022-06-26 03:26:18.120707
# Unit test for function import_string
def test_import_string():
    test_case_0()

test_import_string()

# Generated at 2022-06-26 03:26:20.976767
# Unit test for function import_string
def test_import_string():
    str_0 = '@$b~.V*i\x0cZxTs.9s'
    module_name = 'test_case_0'
    package = None
    import_string(module_name, package)



# Generated at 2022-06-26 03:26:23.688550
# Unit test for function import_string
def test_import_string():
    class_0 = import_string('framework.utils.base.Tests.test_import_string.class_0')
    assert class_0.value == 5

class_0 = 5


# Generated at 2022-06-26 03:26:24.399197
# Unit test for function import_string
def test_import_string():
    test_case_0()

# Main function

# Generated at 2022-06-26 03:26:27.313040
# Unit test for function import_string
def test_import_string():
    assert(import_string('sys.version_info') is not None)
    assert(import_string('os', 'sys') is not None)


# Generated at 2022-06-26 03:26:28.918119
# Unit test for function import_string
def test_import_string():
    target = import_string('http.HTTPStatus', package='http')
    assert target == HTTPStatus


# Generated at 2022-06-26 03:26:30.801746
# Unit test for function import_string
def test_import_string():
    assert(import_string('yy.tt', 'xx') == None), "Fail"


# Generated at 2022-06-26 03:26:32.440435
# Unit test for function import_string
def test_import_string():
    # Test case 0
    assert import_string(test_case_0()) == None

# Generated at 2022-06-26 03:26:42.444380
# Unit test for function import_string
def test_import_string():
    test_case_0()
    test_import_string()
    assert import_string('yarl.query.QueryBuilder') is not None
    assert import_string(
        'yarl.query.QueryBuilder') is not None
    assert import_string('yarl.query.QueryBuilder') \
        is not None


if __name__ == "__main__":
    import_string
    import_string
    import_string
    import_string
    assert import_string('yarl.query.QueryBuilder') is not None
    import_string('yarl.query.QueryBuilder')
    import_string
    assert import_string('yarl.query.QueryBuilder') is not None
    import_string('yarl.query.QueryBuilder')
    import_string
    assert import_string('yarl.query.QueryBuilder') is not None