

# Generated at 2022-06-26 03:25:15.259556
# Unit test for function import_string
def test_import_string():
    from . import test0
    from .test0 import TestCase
    from .test0 import ExceptionCase

    test0_import = import_string("exhaust.http11.test0")
    assert test0_import.__name__ == "exhaust.http11.test0"

    test0_import = import_string("exhaust.http11.test0.TestCase")
    assert test0_import.__name__ == "TestCase"

    test0_import = import_string("exhaust.http11.test0.TestCase")
    assert isinstance(test0_import, TestCase)

    test0_import = import_string("exhaust.http11.test0.ExceptionCase")
    assert isinstance(test0_import, ExceptionCase)

# Generated at 2022-06-26 03:25:23.752503
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    str_0 = dict()
    str_0['Accept'] = "application/json"
    str_0['Connection'] = "close"
    str_0['Content-Type'] = "application/json"
    str_0["Content-Length"] = "20"
    str_0['Host'] = "localhost"
    var_0 = remove_entity_headers(str_0, ('content-location', 'expires'))
    assert('Accept' in var_0)
    assert(var_0['Accept'] == "application/json")
    assert('Connection' in var_0)
    assert(var_0['Connection'] == "close")
    assert('Content-Type' in var_0)
    assert(var_0['Content-Type'] == "application/json")
    assert('Host' in var_0)

# Generated at 2022-06-26 03:25:33.126681
# Unit test for function import_string
def test_import_string():
    assert import_string("a.b") == "b"
    assert import_string("a.b", "a") == "b"
    assert import_string("a.b", "x") == "b"
    assert import_string("a.b.c") == "c"
    assert import_string("a.b.c", "a.b") == "c"
    assert import_string("a.b.c", "x.y") == "c"
    assert import_string("a.b.c.d") == "d"
    assert import_string("a.b.c.d", "a.b.c") == "d"
    assert import_string("a.b.c.d", "x.y.z") == "d"
    assert import_string("a.b.c.d.e")

# Generated at 2022-06-26 03:25:42.053093
# Unit test for function import_string
def test_import_string():
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    from yolo.shortcuts import import_string

    str_0 = "tests.test_http_utils"
    module_0 = import_string(str_0)
    assert module_0.__name__ == 'tests.test_http_utils'

    str_0 = "yolo.shortcuts.import_string"
    int_0 = import_string(str_0)
    assert int_0() == 'import_string'


# Generated at 2022-06-26 03:25:53.426208
# Unit test for function import_string
def test_import_string():
    from importlib import reload
    from .helper import reload_mock
    module_name = 'httpx.tests.test_helper'
    reload(import_module('httpx.tests'))
    reload(import_module('httpx.tests.test_helper'))
    reload_mock.reload_times += 1
    assert import_string(module_name) == reload_mock
    reload_mock.reload_times += 1
    assert import_string(module_name).reload_times == reload_mock.reload_times
    reload_mock.reload_times += 1
    klass = 'ReloadMock'
    assert import_string(module_name + "." + klass).reload_times == reload_mock.reload_times

# Generated at 2022-06-26 03:25:57.659095
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) is False
    assert has_message_body(200) is True
    assert has_message_body(204) is False
    assert has_message_body(304) is False
    assert has_message_body(400) is True
    assert has_message_body(500) is True


# Generated at 2022-06-26 03:26:01.905048
# Unit test for function import_string
def test_import_string():
    str_0 = 'test_http.test_case_0'
    var_0 = import_string(str_0)
    print(var_0)
    print(var_0())
    print(ismodule(var_0))


# Generated at 2022-06-26 03:26:03.351503
# Unit test for function import_string
def test_import_string():
    import_string("swift_http.http_standard.STATUS_CODES")

# Generated at 2022-06-26 03:26:08.808335
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        'Content-Type': 'application/json',
        'Transfer-Encoding': 'chunked',
        'Expires': 'Thu, 01 Jan 1970 00:00:00 GMT',
        'Server': 'meinheld/0.6.1'
    }
    var_0 = remove_entity_headers(headers)
    return var_0

# Generated at 2022-06-26 03:26:10.428627
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # Check if str_0 does not contain Var_0
    assert str_0 not in var_0



# Generated at 2022-06-26 03:26:13.823318
# Unit test for function import_string
def test_import_string():
    path = 'japronto.compat.BaseHTTPRequestHandler'
    obj = import_string(path)
    assert obj.__name__ == 'BaseHTTPRequestHandler'



# Generated at 2022-06-26 03:26:16.407949
# Unit test for function import_string
def test_import_string():
    obj = import_string('asyncio')
    assert obj.__name__ == 'asyncio'



# Generated at 2022-06-26 03:26:25.644662
# Unit test for function import_string
def test_import_string():
    from aiohttp import web
    from werkzeug.test import Client
    from werkzeug.wrappers import BaseResponse
    from aiohttp.web_request import Request
    from aiohttp.web_response import StreamResponse
    from aiohttp.web_response import Response

    class SampleClass:
        def __init__(self):
            self.name = "Sample class"

    class SampleClass1:
        def __init__(self):
            pass
        def hello_world(self):
            print("Hello World")

    class SampleClass2:
        def __init__(self):
            pass
        async def hello_world(self):
            print("Hello World")

    class SampleClass3:
        def __init__(self):
            pass

# Generated at 2022-06-26 03:26:33.596548
# Unit test for function import_string
def test_import_string():
    import unittest
    import math
    import os

    class TestImportString(unittest.TestCase):

        @unittest.expectedFailure
        def test_with_invalid_module(self):
            self.assertIsNone(import_string("Math"))

        def test_with_valid_module(self):
            self.assertIs(import_string("math.ceil"), math.ceil)

        def test_with_a_valid_path(self):
            self.assertIsNot(import_string("os.path.abspath"), None)

        @unittest.expectedFailure
        def test_with_path_that_not_is_a_class(self):
            self.assertIsNot(import_string("os.path.abspath"), None)


# Generated at 2022-06-26 03:26:36.341073
# Unit test for function import_string
def test_import_string():
    import pytest
    with pytest.raises(ModuleNotFoundError) as e:
        import_string('not_a_module')


# Generated at 2022-06-26 03:26:43.425434
# Unit test for function import_string
def test_import_string():
    assert import_string('sys') == sys
    assert import_string('sys.path') == sys.path
    s = import_string('string.whitespace')
    assert s == '\t\n\x0b\x0c\r '
    assert import_string('collections.deque')().__str__() == deque().__str__()
    assert import_string('inspect').__str__() == inspect.__str__()
    assert import_string('os.getcwd').__str__() == os.getcwd().__str__()
    assert import_string('os.getcwd').__str__() == os.getcwd().__str__()


# Generated at 2022-06-26 03:26:48.050063
# Unit test for function import_string
def test_import_string():
    str_0 = "http.server.HTTPHeaderDict"
    var_0 = import_string(str_0)
    print(var_0)


if __name__ == "__main__":
    test_case_0()
    test_import_string()

# Generated at 2022-06-26 03:26:49.266539
# Unit test for function import_string
def test_import_string():
    mod = import_string("aiohttp.hdrs.REFERER")
    assert mod == "Referer"


#test_import_string()
test_case_0()

# Generated at 2022-06-26 03:26:51.324849
# Unit test for function import_string
def test_import_string():
    import_string("http.server", package="http")


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:26:58.694679
# Unit test for function import_string
def test_import_string():
    print("Testing import_string function")
    assert str(import_string("http.client.HTTPConnection")) == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
