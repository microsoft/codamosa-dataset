

# Generated at 2022-06-26 03:25:10.535415
# Unit test for function import_string
def test_import_string():
    float_0 = 0.1
    var_0 = import_string(float_0)


# Generated at 2022-06-26 03:25:18.463814
# Unit test for function has_message_body
def test_has_message_body():
    print("Testing has_message_body")
    try:
        # status with message body
        assert not has_message_body(204)
        assert not has_message_body(304)
        assert has_message_body(200)
        assert has_message_body(201)
        # status without message body
        assert has_message_body(100)
        assert has_message_body(101)
        assert has_message_body(102)
        assert has_message_body(103)
        print("Test Passed")
    except:
        print("Test Failed")


# Generated at 2022-06-26 03:25:24.104584
# Unit test for function has_message_body
def test_has_message_body():
    print ("Testing has_message_body")
    assert has_message_body(100) == True
    assert has_message_body(200) == True
    assert has_message_body(300) == True
    assert has_message_body(400) == True
    assert has_message_body(500) == True


# Generated at 2022-06-26 03:25:26.139378
# Unit test for function import_string
def test_import_string():
    str_0 = "http.client"
    var_0 = import_string(str_0)


# Generated at 2022-06-26 03:25:28.833824
# Unit test for function import_string
def test_import_string():
    assert import_string('os.path') is os.path
    assert import_string('os.path.join') == os.path.join
    # assert import_string('http.server.SimpleHTTPRequestHandler') is http.server.SimpleHTTPRequestHandler
    # assert import_string('http.server.SimpleHTTPRequestHandler').__module__ == 'http.server'


# Generated at 2022-06-26 03:25:34.284600
# Unit test for function import_string
def test_import_string():
    assert import_string("urllib.parse") is not None
    assert import_string("urllib.parse.urlparse") is not None


# Generated at 2022-06-26 03:25:38.435891
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({'content-md5': 'md5hash'}) == {}
    assert remove_entity_headers({'content-md5': 'md5hash'}, allowed=('content-md5', )) == {'content-md5': 'md5hash'}

# Generated at 2022-06-26 03:25:46.415422
# Unit test for function import_string
def test_import_string():
    # var_0 = 'valid_path.module'
    var_0 = 'backend.urls'

    # Unit test for function remove_entity_headers
    # var_0 = {'key':'value'}
    # remove_entity_headers(var_0)

    # var_0 = {'key':'value'}
    # remove_entity_headers(var_0)

    import_string(var_0)

if __name__ == '__main__':
    # test_import_string()
    test_case_0()

# Generated at 2022-06-26 03:25:47.658507
# Unit test for function import_string
def test_import_string():
    assert import_string("aiohttp.web.Application")



# Generated at 2022-06-26 03:25:50.897180
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    rh = remove_entity_headers({"allow": "content-encode"})
    print ("Test remove_entity_headers: ", rh == {"allow": "content-encode"})
