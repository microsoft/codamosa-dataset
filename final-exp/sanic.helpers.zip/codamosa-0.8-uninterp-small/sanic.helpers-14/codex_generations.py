

# Generated at 2022-06-26 03:25:00.110755
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({"Content-Type": "text/html"}) == {}

# Generated at 2022-06-26 03:25:02.205918
# Unit test for function import_string
def test_import_string():
    assert import_string("falcon.status_codes", "falcon") == STATUS_CODES


if __name__ == "__main__":
    test_case_0()
    test_import_string()

# Generated at 2022-06-26 03:25:03.434653
# Unit test for function import_string
def test_import_string():
    module_name = 'http.client'
    package = 'http'
    import_string(module_name, package)

# Generated at 2022-06-26 03:25:04.579462
# Unit test for function import_string
def test_import_string():
    import_string("humanize.unintcomma")


# Generated at 2022-06-26 03:25:15.002108
# Unit test for function import_string
def test_import_string():
    # import a module
    module = import_string("http_util.status_codes")

    # import a class
    from http_util.status_codes import BAD_REQUEST
    obj = import_string("http_util.status_codes.BAD_REQUEST")
    assert obj == BAD_REQUEST

    from http_util.helpers import Headers
    headers = Headers()
    headers["Connection"] = "close"
    headers["Via"] = "1.1 vegur"
    headers["X-Foo"] = "bar"
    headers["X-Bar"] = "foo"
    headers["X-Foo2"] = "foo2"

    headers = remove_entity_headers(headers)

# Generated at 2022-06-26 03:25:16.052982
# Unit test for function import_string
def test_import_string():
    import_string("tests.test_http.test_case_0")

# Generated at 2022-06-26 03:25:18.908744
# Unit test for function import_string
def test_import_string():
    if import_string("h11.protocol.H2Protocol") == import_module("h11.protocol").H2Protocol:
        return True
    else:
        return False



# Generated at 2022-06-26 03:25:30.080660
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # Test 1
    headers = {'foo': 'moo'}
    headers = remove_entity_headers(headers, allowed=('content-location', 'expires'))
    assert headers == {'foo': 'moo'}
    # Test 2
    headers = {'content-location': 'moo'}
    headers = remove_entity_headers(headers, allowed=('content-location', 'expires'))
    assert headers == {'content-location': 'moo'}
    # Test 3
    headers = {'content-location': 'content-location'}
    headers = remove_entity_headers(headers, allowed=('content-location', 'expires'))
    assert headers == {'content-location': 'content-location'}
    # Test 4

# Generated at 2022-06-26 03:25:42.937104
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # Test case 0
    headers = {
        b"Allow": b"GET, HEAD, POST, PUT, DELETE, TRACE, OPTIONS",
        b"Content-Length": b"45",
        b"Content-Location": b"/index.htm",
        b"Content-MD5": b"Q2hlY2sgSW50ZWdyaXR5IQ==",
        b"Content-Range": b"bytes 21010-47021/47022",
        b"Content-Type": b"text/html",
        b"Expires": b"Tue, 20 Aug 2013 18:46:39 GMT",
        b"Last-Modified": b"Tue, 1 Sep 2019 17:00:00 GMT",
        b"NullValue": None,
        b"IntValue": b"45",
    }
    expected_output

# Generated at 2022-06-26 03:25:44.713365
# Unit test for function import_string
def test_import_string():
    import_string("rfc2616.app")


# Generated at 2022-06-26 03:25:48.760992
# Unit test for function import_string
def test_import_string():
    import sys
    import pathlib
    assert import_string("sys.path") == sys.path
    assert import_string("pathlib.Path")() == pathlib.Path()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 03:25:58.675541
# Unit test for function import_string
def test_import_string():
    assert import_string("aiohttp.web", package="aiohttp")
    assert import_string("aiohttp.web.application", package="aiohttp")
    assert import_string("aiohttp.abc.abc", package="aiohttp")
    assert import_string("aiohttp.abc.abc", package="aiohttp")
    assert import_string("aiohttp.abc.abc.abc", package="aiohttp")
    assert import_string("aiohttp.abc.abc.abc.abc", package="aiohttp")
    assert import_string("aiohttp.abc.abc.abc.abc.abc", package="aiohttp")
    assert import_string("aiohttp.abc.abc.abc.abc.abc.abc", package="aiohttp")

# Generated at 2022-06-26 03:26:01.069072
# Unit test for function import_string
def test_import_string():
    test_string_0 = 'tests.test_http.test_case_0'
    result = import_string(test_string_0)
    result()

# Generated at 2022-06-26 03:26:02.593473
# Unit test for function import_string
def test_import_string():
    import_string(test_case_0)


# Entry point for tests

# Generated at 2022-06-26 03:26:12.062709
# Unit test for function import_string
def test_import_string():
    """
    Testing function import_string
    :return:
    """
    from os import environ
    from os.path import dirname, join
    from sys import path

    # root directory is two directories above this file
    root = dirname(dirname(dirname(__file__)))

    # Add the project root directory to the Python path (sys.path)
    path.insert(0, root)
    # Set environment variable DJANGO_SETTINGS_MODULE
    environ['DJANGO_SETTINGS_MODULE'] = 'rest.settings.dev'

    from rest.users.serializers import UserSerializer
    #import_string with a module
    module = import_string('rest.users.serializers')

# Generated at 2022-06-26 03:26:13.514563
# Unit test for function import_string
def test_import_string():
    import_string("motor.motor_asyncio.AsyncIOMotorClient")


# Generated at 2022-06-26 03:26:19.507189
# Unit test for function import_string
def test_import_string():
    import sys
    import unittest

    import_string("unittest.TestCase", sys.modules[__name__])
    import_string("unittest.TestCase")
    import_string("tests.import_string", sys.modules[__name__])
    import_string("tests.import_string", sys.modules[__name__])
    import_string("tests.import_string")



# Generated at 2022-06-26 03:26:25.768359
# Unit test for function import_string
def test_import_string():
    # module_name start with dot
    assert import_string(".test_http.test_case_0") == test_case_0
    # module name start with relative path
    assert import_string("test_http.test_case_0") == test_case_0
    # module name start with absolute path
    assert import_string("test_http.test_case_0", package="test") == test_case_0



# Generated at 2022-06-26 03:26:31.944449
# Unit test for function import_string
def test_import_string():
    import os
    import sys
    import subprocess
    root = os.path.join(os.path.abspath(os.path.dirname(__file__)), '../')
    protocol = subprocess.Popen(
        [sys.executable, '-m', 'pytest', '-k', 'import_string',
        os.path.join(root, 'tests/test_http.py')],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE)
    (_, err) = pro

# Generated at 2022-06-26 03:26:42.084693
# Unit test for function import_string
def test_import_string():
    print('Testing import_string...', end='')
    assert(import_string('http.client.HTTPConnection') ==
           HTTPConnection)
    assert(import_string('http.client.HTTPConnection')() ==
           HTTPConnection())
    assert(import_string('http.client.HTTPResponse') ==
           HTTPResponse)
    assert(import_string('http.client.HTTPResponse')() ==
           HTTPResponse())
    assert(import_string('http.client.HTTPSConnection') ==
           HTTPSConnection)
    assert(import_string('http.client.HTTPSConnection')() ==
           HTTPSConnection())
    assert(import_string('http.client.HTTPSHandler') ==
           HTTPSHandler)