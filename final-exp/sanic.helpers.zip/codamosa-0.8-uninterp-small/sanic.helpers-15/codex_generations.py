

# Generated at 2022-06-26 03:25:20.688159
# Unit test for function has_message_body
def test_has_message_body():
    var_0 = has_message_body(200)
    assert var_0 == True, "assert failed"
    #var_1 = has_message_body(100)
    #assert var_1 == False, "assert failed"
    var_2 = has_message_body(1)
    assert var_2 == True, "assert failed"
    var_3 = has_message_body(500)
    assert var_3 == True, "assert failed"
    var_4 = has_message_body(2)
    assert var_4 == True, "assert failed"
    var_5 = has_message_body(1)
    assert var_5 == True, "assert failed"
    var_6 = has_message_body(200)
    assert var_6 == True, "assert failed"
    var_7 = has_message

# Generated at 2022-06-26 03:25:27.654351
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"non-entity-header": "value"}
    result = remove_entity_headers(headers)
    assert result == headers

    headers = {"non-entity-header": "value", "content-type": "text/html"}
    result = remove_entity_headers(headers)
    assert result == headers

    headers = {"content-encoding": "gzip"}
    result = remove_entity_headers(headers)
    assert result == {}



# Generated at 2022-06-26 03:25:42.937377
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # Positive Test
    headers = {
        "Connection": "keep-alive",
        "Keep-alive": "timeout=10, max=1000",
        "Content-Length": "624",
        "Content-Type": "text/html",
    }
    headers = remove_entity_headers(headers)
    assert headers == {"Connection": "keep-alive", "Keep-alive": "timeout=10, max=1000"}

    # Negative Test
    headers = {
        "Connection": "keep-alive",
        "Keep-alive": "timeout=10, max=1000",
        "Content-Length": "624",
        "Content-Type": "text/html",
    }
    headers = remove_entity_headers(headers)

# Generated at 2022-06-26 03:25:46.331306
# Unit test for function import_string
def test_import_string():
    assert import_string('fastapi.utils.importlib_metadata')
    assert import_string('fastapi.utils.importlib_metadata.version', 'fastapi.utils')


# Generated at 2022-06-26 03:25:48.312687
# Unit test for function import_string
def test_import_string():
    assert import_string("aiohttp.HttpVersion11")
    assert import_string("aiohttp.client.ClientSession")



# Generated at 2022-06-26 03:25:53.055931
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # First test case
    headers_0 = {"content-location": "", "expires": "", "content-encoding": "", "content-md5": "", "content-length": "", "content-language": "", "content-type": "", "content-range": "", "last-modified": ""}
    headers_1 = remove_entity_headers(headers_0)
    print("Pass test case 0 when headers_1 is ", headers_1)



# Generated at 2022-06-26 03:25:54.815827
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    dict_0 = None
    dict_1 = remove_entity_headers(dict_0)


# Generated at 2022-06-26 03:25:57.916818
# Unit test for function import_string
def test_import_string():
    assert import_string('examples.wsgi.hello_world')
    assert import_string('examples.wsgi.hello_world.__init__')
    assert import_string('examples.wsgi.hello_world.application')


# Generated at 2022-06-26 03:26:07.434426
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
        "Host": "httpbin.org",
        "User-Agent": "python-requests/2.19.1",
    }
    new_headers = {
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
        "Host": "httpbin.org",
        "User-Agent": "python-requests/2.19.1",
    }
    new_headers = remove_entity_headers(headers)
    print("entity headers removed")
    print(new_headers)


# Generated at 2022-06-26 03:26:20.243546
# Unit test for function import_string
def test_import_string():
    assert isinstance(import_string("aiohttp.web.Application"), Application)
    assert import_string("aiohttp.web.Application")
    assert import_string("aiohttp.web.Application", package="aiohttp.web")
    assert import_string("aiohttp.web.Application", package="aiohttp")
    assert import_string("aiohttp.web.Application", package="aiohttp")

# Next import_string will cause a SystemExit
# assert import_string("aiohttp.web.Application", package="aiohttp.web.Application")




# Generated at 2022-06-26 03:26:25.244879
# Unit test for function import_string
def test_import_string():
    assert import_string("http.HTTPStatus") is import_module("http").HTTPStatus
    assert import_string("http.cookies.BaseCookie")() is import_module("http.cookies").BaseCookie()

# Generated at 2022-06-26 03:26:27.811825
# Unit test for function import_string
def test_import_string():
    import OSErrors
    test_1 = import_string('OSErrors')
    assert test_1 == OSErrors


# Generated at 2022-06-26 03:26:30.591188
# Unit test for function import_string
def test_import_string():
    module_string = "falcon.request.Request"
    obj = import_string(module_string)
    msg = "Type of object {} is not {}".format(obj, "Request")
    assert type(obj) is Request, msg


# Generated at 2022-06-26 03:26:40.196206
# Unit test for function import_string
def test_import_string():
    expected_1 = 'module_import_string.ClassImportString'
    expected_2 = 'some_string'
    expected_3 = (module_import_string, 'ModuleImportString')
    expected_4 = ('ClassImportString', 'ClassImportString')

    assert import_string('module_import_string.ClassImportString').str_1() == expected_1
    assert import_string('module_import_string.ClassImportString').str_2() == expected_2
    assert import_string('module_import_string.ModuleImportString') == expected_3
    assert import_string('module_import_string.ClassImportString', package='module_import_string') == expected_4

# Generated at 2022-06-26 03:26:52.182302
# Unit test for function import_string
def test_import_string():
    import sys
    import gc
    import random
    import string
    import datetime
    import inspect
    import unittest
    import importlib
    import pytest
    import importlib.abc
    import builtins

    # Create a list of all modules
    all_modules = [
        importlib.import_module(module_name)
        for module_name in sys.builtin_module_names
    ]

    # Create a list of all packages
    package_names = [
        module_name for module_name in sys.builtin_module_names
        if importlib.find_loader(module_name)
    ]
    packages = [
        importlib.import_module(package_name)
        for package_name in package_names
    ]

    # Create a list of all classes

# Generated at 2022-06-26 03:26:56.436808
# Unit test for function import_string
def test_import_string():
    # Test case 0
    module_name = "http.server"
    actual = import_string(module_name)
    expected = import_module(module_name)
    assert expected == actual

    # Test case 1
    module_name = "http.server.SimpleHTTPRequestHandler"
    actual = import_string(module_name)
    expected = getattr(import_module(module_name), SimpleHTTPRequestHandler)
    assert expected == actual



# Generated at 2022-06-26 03:27:01.541436
# Unit test for function import_string
def test_import_string():
    # Test case 1
    var_0 = import_string('tests.test_utils.test_case_0')
    assert var_0() == None

    # Test case 2
    var_1 = import_string('tests.test_utils.test_case_0')
    assert var_1() == None

# Generated at 2022-06-26 03:27:13.133365
# Unit test for function import_string
def test_import_string():
    test_mod = import_string("aiohttp.test_utils.helpers")
    assert not isinstance(test_mod, str)
    assert repr(test_mod).startswith("<module ")
    assert repr(test_mod).endswith("aiohttp.test_utils.helpers>")

    test_c_0 = import_string("aiohttp.test_utils.helpers.TestCase")
    assert not isinstance(test_c_0, str)
    assert repr(test_c_0).startswith("<class ")
    assert repr(test_c_0).endswith("aiohttp.test_utils.helpers.TestCase>")

    test_c_1 = import_string("aiohttp.test_utils.helpers.TestCase")

# Generated at 2022-06-26 03:27:16.180432
# Unit test for function import_string
def test_import_string():
    t1 = import_string(module_name="hello.world", package=None)
    assert t1 == "hello world"

    t2 = import_string(module_name="math.pi", package=None)
    assert t2 == 3.141592653589793

# Generated at 2022-06-26 03:27:19.370498
# Unit test for function import_string
def test_import_string():
    from g1.asyncs.bases import test_utils
    assert import_string('g1.asyncs.bases.test_utils') == test_utils
    assert import_string('g1.asyncs.bases.test_utils.TestClass') == test_utils.TestClass()



# Generated at 2022-06-26 03:27:29.271443
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(300) == True
    assert has_message_body(399) == True
    assert has_message_body(400) == True
    assert has_message_body(404) == True
    assert has_message_body(500) == True
    assert has_message_body(599) == True


# Generated at 2022-06-26 03:27:35.087740
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(109) == False
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(100) == True
    assert has_message_body(200) == True
    assert has_message_body(300) == True
    assert has_message_body(400) == True
    assert has_message_body(500) == True



# Generated at 2022-06-26 03:27:42.291131
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert not has_message_body(201)
    assert not has_message_body(301)
    assert not has_message_body(399)

    assert has_message_body(200)
    assert has_message_body(300)
    assert has_message_body(400)
    assert has_message_body(500)
    assert has_message_body(199)

# Generated at 2022-06-26 03:27:49.266146
# Unit test for function has_message_body
def test_has_message_body():
    assert(has_message_body(100) == False)
    assert(has_message_body(199) == False)
    assert(has_message_body(200) == True)
    assert(has_message_body(204) == False)
    assert(has_message_body(299) == True)
    assert(has_message_body(300) == True)
    assert(has_message_body(304) == False)
    assert(has_message_body(399) == True)



# Generated at 2022-06-26 03:27:55.835618
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(status=201) == False
    assert has_message_body(status=204) == False
    assert has_message_body(status=304) == False
    assert has_message_body(status=101) == False
    assert has_message_body(status=102) == True
    assert has_message_body(status=200) == True
    assert has_message_body(status=299) == True


# Generated at 2022-06-26 03:27:57.107228
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(int(input())) == True


# Generated at 2022-06-26 03:28:08.065274
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(1)
    assert has_message_body(2)
    assert has_message_body(3)
    assert has_message_body(4)
    assert has_message_body(5)
    assert has_message_body(6)
    assert has_message_body(7)
    assert has_message_body(8)
    assert has_message_body(9)
    assert has_message_body(100)
    assert has_message_body(101)
    assert has_message_body(102)
    assert has_message_body(103)
    assert has_message_body(200)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(204)
    assert has_message_body(205)
   

# Generated at 2022-06-26 03:28:11.803214
# Unit test for function has_message_body
def test_has_message_body():

    for status in STATUS_CODES:
        if (status in (204, 304) or (status >= 100 and status < 200)):
            assert not has_message_body(status)
        else:
            assert has_message_body(status)


# Generated at 2022-06-26 03:28:13.312604
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == True
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False


# Generated at 2022-06-26 03:28:19.595567
# Unit test for function has_message_body
def test_has_message_body():
    global HttpStandard
    status = 204
    result = HttpStandard().has_message_body(status)
    if result != False:
        raise Exception("Test for has_message_body failed! (1)")
    status = 304
    result = HttpStandard().has_message_body(status)
    if result != False:
        raise Exception("Test for has_message_body failed! (2)")
    status = 199
    result = HttpStandard().has_message_body(status)
    if result != False:
        raise Exception("Test for has_message_body failed! (3)")
    status = 200
    result = HttpStandard().has_message_body(status)
    if result != True:
        raise Exception("Test for has_message_body failed! (4)")

