

# Generated at 2022-06-26 03:25:19.704549
# Unit test for function import_string
def test_import_string():
    # Asserts for valid path to class
    assert import_string("http.cookies.SimpleCookie")
    assert import_string("http.cookies.SimpleCookie").__class__.__name__ == "SimpleCookie"
    assert import_string("http.cookies.SimpleCookie").__class__.__module__ == "http.cookies"
    # Asserts for invalid path to class
    assert import_string("http.cookies.SimpleCookie", package=True)
    assert import_string("http.cookies.SimpleCookie", package=True).__class__.__name__ == "SimpleCookie"
    assert import_string("http.cookies.SimpleCookie", package=True).__class__.__module__ == "http.cookies"
    # Asserts for valid path to module
    assert import_

# Generated at 2022-06-26 03:25:25.793920
# Unit test for function import_string
def test_import_string():
    import sys
    sys.path.append(".")
    assert import_string("test_import_string")

    class TestString:
        def __repr__(self):
            return "test_import_string.TestString"
    assert str(import_string("test_import_string.TestString")) == "test_import_string.TestString"

test_import_string()

# Generated at 2022-06-26 03:25:28.721568
# Unit test for function import_string
def test_import_string():
    assert import_string('asyncio.Future')
    assert import_string('tests.test_http.test_case_0')
    assert import_string('tests.test_http.test_case_0').__name__ == 'test_case_0'
    assert import_string('tests.test_http.test_case_0').__doc__ == test_case_0.__doc__

# Generated at 2022-06-26 03:25:42.937798
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({
        'a': 1,
        'b': 2,
        'c': 3
    }) == {
        'a': 1,
        'b': 2,
        'c': 3
    }

    assert remove_entity_headers({
        'a': 1,
        'b': 2,
        'c': 3,
        'content-length': 200
    }) == {
        'a': 1,
        'b': 2,
        'c': 3
    }


# Generated at 2022-06-26 03:25:44.770347
# Unit test for function import_string
def test_import_string():
    print (import_string('string.BaseString'))


# Generated at 2022-06-26 03:25:45.400620
# Unit test for function import_string
def test_import_string():
    import_string()
    assert True


# Generated at 2022-06-26 03:25:49.103009
# Unit test for function import_string
def test_import_string():
    var_0 = import_string('httptools.parser.parser_base')
    assert var_0.__class__ == 'httptools.parser.parser_base.HttpParserBase'


if __name__ == "__main__":
    test_case_0()
    test_import_string()

# Generated at 2022-06-26 03:25:52.214030
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-location": "testing", "expires": "12.23.4444"}
    fn = remove_entity_headers(headers)
    assert fn == headers

# Generated at 2022-06-26 03:25:58.306778
# Unit test for function import_string
def test_import_string():
    assert import_string("fastapi.__main__:cli")
    assert import_string("fastapi.__main__:cli")()

    assert import_string("fastapi.tests.test_main:test_case_0")
    assert import_string("fastapi.tests.test_main:test_case_0")()

    assert import_string("multiprocessing.dummy.connection:Pipe")
    assert import_string("multiprocessing.dummy.connection:Pipe")()



# Generated at 2022-06-26 03:26:06.643507
# Unit test for function import_string
def test_import_string():
    assert import_string("httpx.client.Client")
    assert import_string("httpx.client.Client").__name__ == "Client"

    assert import_string("httpx.client.Client", package="httpx.client")
    assert import_string("httpx.client.Client", package="httpx.client").__name__ == "Client"

    assert import_string("httpx")
    assert import_string("httpx").__name__ == "httpx"

    assert import_string("json")
    assert import_string("json").__name__ == "json"



# Generated at 2022-06-26 03:26:18.648345
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(100) == False
    assert has_message_body(201) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == True
    assert has_message_body(304) == False
    assert has_message_body(999) == True
    assert has_message_body(0) == True


# Generated at 2022-06-26 03:26:23.882199
# Unit test for function import_string
def test_import_string():
    assert import_string(tuple) == tuple
    assert import_string("tuple") == tuple
    assert import_string("collections.namedtuple") == import_module("collections").namedtuple
    assert import_string("builtins.tuple") == tuple
    test_case_0()



# Generated at 2022-06-26 03:26:26.122010
# Unit test for function import_string
def test_import_string():
    print("Testing import_string")
    test_case_0()
if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:26:30.321670
# Unit test for function has_message_body
def test_has_message_body():
    for status in [200, 201]:
        assert has_message_body(status) is True


# Generated at 2022-06-26 03:26:32.602627
# Unit test for function import_string
def test_import_string():
    var_0 = import_string("http.server")
    assert var_0 == import_module("http.server")



# Generated at 2022-06-26 03:26:37.543362
# Unit test for function import_string
def test_import_string():
    assert import_string("string") == str
    assert import_string("string.ascii_lowercase") == "abcdefghijklmnopqrstuvwxyz"
    assert import_string("http.client.HTTPConnection") is not None, "No implementation in Python"


# Generated at 2022-06-26 03:26:44.405818
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(status=1) == False
    assert has_message_body(status=100) == False
    assert has_message_body(status=204) == False
    assert has_message_body(status=304) == False
    assert has_message_body(status=200) == True
    assert has_message_body(status=201) == True
    assert has_message_body(status=202) == True
    assert has_message_body(status=203) == True
    assert has_message_body(status=300) == True
    assert has_message_body(status=400) == True
    assert has_message_body(status=401) == True
    assert has_message_body(status=500) == True



# Generated at 2022-06-26 03:26:46.898618
# Unit test for function import_string
def test_import_string():
    assert callable(import_string)
    assert isinstance(import_string, object)


# Generated at 2022-06-26 03:26:49.500415
# Unit test for function import_string
def test_import_string():
    module1 = import_string("http.client.client")
    assert module1.__name__ == "http.client" 


# Generated at 2022-06-26 03:26:52.750770
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(100) == False
    assert has_message_body(1234) == False
    assert has_message_body(204) == False
    assert has_message_body(304) == False



# Generated at 2022-06-26 03:26:55.340654
# Unit test for function import_string
def test_import_string():
    import_string("sanic.websocket.WebSocketProtocol")
    test_case_0()

# Generated at 2022-06-26 03:27:03.736995
# Unit test for function import_string
def test_import_string():
    base_module = 'sanic.response'
    from sanic.response import HTTPResponse

    assert import_string(base_module) == import_module(base_module)
    assert import_string(base_module + '.HTTPResponse') == HTTPResponse

    class_module = 'sanic.constants'

    # import a module and instanciate a class inside the module
    assert (import_string(class_module + '.HTTP_METHODS') ==
            import_module(class_module).HTTP_METHODS)



# Generated at 2022-06-26 03:27:08.768167
# Unit test for function import_string
def test_import_string():
    var_0 = import_string('modules.simple_math')
    assert var_0.sum(1, 2) == 3

    var_1 = import_string('modules.simple_math.SimpleMath', 'modules')
    assert var_1.sum(4, 3) == 7



# Generated at 2022-06-26 03:27:10.517784
# Unit test for function import_string
def test_import_string():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 03:27:15.036168
# Unit test for function import_string
def test_import_string():
    mod = import_string("simple.simple_http_server")
    assert mod.__name__ == "simple.simple_http_server"

    from simple.simple_http_server import Server
    s = import_string("simple.simple_http_server.Server")
    assert isinstance(s, Server)


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:27:18.236621
# Unit test for function import_string
def test_import_string():
    assert import_string("http.server.BaseHTTPRequestHandler")
    assert import_string("http.server.SimpleHTTPRequestHandler")
    assert import_string("http.server.test_case_0")
    assert import_string("http.server.test_import_string")


# Generated at 2022-06-26 03:27:21.504364
# Unit test for function import_string
def test_import_string():
    import unittest.mock as mock
    module_path = "pulsar.utils.httpurl.import_module"
    string_mock = "string_mock"
    # Setting up mocks
    with mock.patch(module_path) as module:
        # Executing test
        test_case_0()
        # Asserting calls
        module.assert_called_once_with(string_mock)

# Generated at 2022-06-26 03:27:22.434471
# Unit test for function import_string
def test_import_string():
    assert test_case_0() == None


# Generated at 2022-06-26 03:27:23.409453
# Unit test for function import_string
def test_import_string():
    var_0 = import_string()



# Generated at 2022-06-26 03:27:26.693215
# Unit test for function import_string
def test_import_string():
    # test case 0
    #
    # Assert True:
    assert test_case_0() == None, "test_case_0 false"