

# Generated at 2022-06-26 03:25:23.510379
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    This method tests to make sure that entity headers are correctly
    removed from a list of headers.
    """
    headers = {
        "key1": "value1",
        "key2": "value2",
        "Cache-Control": "max-age=0",
        "Content-Length": "25",
        "Content-Type": "text/html; charset=utf-8",
        "Date": "Wed, 17 Jun 2020 20:04:12 GMT",
        "Expires": "Wed, 17 Jun 2020 20:04:11 GMT",
        "Server": "WSGIServer/0.2 CPython/3.8.2",
        "Vary": "Cookie",
        "X-Frame-Options": "SAMEORIGIN",
    }


# Generated at 2022-06-26 03:25:26.912932
# Unit test for function import_string
def test_import_string():
    obj = import_string("aiohttp.client_reqrep.ClientResponse")
    assert obj
    obj = import_string("aiohttp.protocol.HttpVersion")
    assert obj

# Generated at 2022-06-26 03:25:31.963262
# Unit test for function import_string
def test_import_string():
    import unittest
    import io
    import mock

    class TestCase(unittest.TestCase):
        def test_import_string(self):
            # TODO: This test does not appear to test anything.
            module = import_string("io")
            assert isinstance(module, io.IOBase)
            assert isinstance(module, io.BytesIO)

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-26 03:25:37.781532
# Unit test for function import_string
def test_import_string():
    module = import_string('http.server')
    assert module

    module_2 = import_string('http.server.test_server')
    assert module_2

    class_instance = import_string('http.cookies.SimpleCookie')
    assert isinstance(class_instance, type(import_module('http.cookies').SimpleCookie()))


# Generated at 2022-06-26 03:25:40.606764
# Unit test for function import_string
def test_import_string():
    class_0 = import_string("test_http_standard.test_case_0")
    
    obj_0 = class_0()



# Generated at 2022-06-26 03:25:44.365557
# Unit test for function import_string
def test_import_string():
    assert import_string(__name__, "AIOHTTP") == import_module(__name__)

    class Test:
        pass

    assert type(import_string(f"{__name__}.{Test.__name__}")) == Test

# Generated at 2022-06-26 03:25:54.540048
# Unit test for function remove_entity_headers

# Generated at 2022-06-26 03:25:59.176352
# Unit test for function import_string
def test_import_string():
    import string
    import random
    assert callable(import_string)
    assert import_string('string.letters') == string.letters
    assert import_string('string.ascii_letters') == string.ascii_letters
    assert import_string('string.punctuation') == string.punctuation
    assert import_string('string.printable') == string.printable


# Generated at 2022-06-26 03:26:06.553605
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(300) == True
    assert has_message_body(304) == False
    assert has_message_body(500) == True
    return True

if __name__ == "__main__":
    test_has_message_body()
    test_case_0()

# Generated at 2022-06-26 03:26:08.632366
# Unit test for function has_message_body
def test_has_message_body():
    status_0 = -1073741824
    res = has_message_body(status_0)
    return res


# Generated at 2022-06-26 03:26:17.820045
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    dict_0 = {}
    dict_0[0] = ("!!!", 0)
    dict_0[1] = ("", 1)
    dict_0[2] = ("", 2)
    dict_0[3] = ("", 3)
    dict_0[4] = ("", 4)
    dict_0[5] = ("", 5)
    dict_0[6] = ("", 6)
    dict_0[7] = ("", 7)
    dict_0[8] = ("", 8)
    dict_0[9] = ("", 9)
    dict_0[10] = ("", 10)
    dict_0[11] = ("", 11)
    dict_0[12] = ("", 12)
    dict_0[13] = ("", 13)

# Generated at 2022-06-26 03:26:25.676327
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    var_0 = "p~WYkC"
    var_1 = "*8%!5&"
    var_2 = ")|DdFH"
    var_3 = "kFzCQe"
    var_4 = "H6m*Ux"
    var_5 = {}
    var_5[var_0] = var_1
    var_5[var_2] = var_3
    var_5[var_4] = var_0
    var_5 = remove_entity_headers(var_5)
    assert var_4 in var_5.keys()
    assert var_3 == var_5[var_2]

# Generated at 2022-06-26 03:26:33.617749
# Unit test for function remove_entity_headers

# Generated at 2022-06-26 03:26:37.955520
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {'Content-Encoding': 'gzip', 'Expires': 'Sun, 4 Mar 2018 08:32:24 GMT'}
    headers = remove_entity_headers(headers)
    assert 'Content-Encoding' not in headers
    assert 'Expires' in headers

# Generated at 2022-06-26 03:26:40.261963
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-type":"text/html; charset=utf-8"}
    assert(remove_entity_headers(headers)=={})

# Generated at 2022-06-26 03:26:52.221465
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({}) == {}
    assert remove_entity_headers({"Foo": "Bar"}) == {"Foo": "Bar"}
    assert (
        remove_entity_headers({"Content-Type": "text/html", "Connection": "keep-alive"})
        == {}
    )
    assert (
        remove_entity_headers(
            {
                "Content-Type": "text/html",
                "Content-Location": "localhost",
                "Expires": "tomorrow",
            }
        )
        == {}
    )

# Generated at 2022-06-26 03:26:54.016595
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    dict_0 = {'Host': '0.0.0.0:8080'}

    remove_entity_headers(dict_0)

# Generated at 2022-06-26 03:27:00.845137
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers_0 = {'Connection': 'close', 'Content-Type': 'text/html', 'Expires': 'Thu, 19 Nov 1981 08:52:00 GMT'}
    headers_1 = {'Connection': 'close', 'Expires': 'Thu, 19 Nov 1981 08:52:00 GMT'}
    assert remove_entity_headers(headers_0) == headers_1

# Generated at 2022-06-26 03:27:12.407683
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    This method tests whether the remove_entity_header method works
    """
    try:
        if remove_entity_headers({"Connection": "close", "Location": "index.html"}) != {"Location": "index.html"}:
            raise ValueError()
        else:
            print("test_remove_entity_headers test passed")
    except ValueError:
        print("test_remove_entity_headers test failed")

# # Unit test for function has_message_body
# def test_has_message_body():
#     print("Running test_has_message_body test...")
#     try:
#         if has_message_body(200) != True:
#             raise ValueError()
#         else:
#             print("test_has_message_body test passed")
#     except ValueError:
#         print

# Generated at 2022-06-26 03:27:18.710270
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "100",
        "Expires": "15/03/2014",
        "Content-Location": "www.example.com/new",
        "Transfer-Encoding": "chunked",
    }
    new_headers = remove_entity_headers(headers)
    assert new_headers == {"Content-Location": "www.example.com/new", "Expires": "15/03/2014"}
    new_headers = remove_entity_headers(headers, allowed=())
    assert len(new_headers) == 0

