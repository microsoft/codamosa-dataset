

# Generated at 2022-06-26 03:25:03.411082
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # message_body_headers = {"content-type" : "application/json"}
    message_body_headers = {"content-type" : "application/json", "content-length" : "3"}
    headers_after_removing = remove_entity_headers(message_body_headers)
    assert "content-type" in headers_after_removing
    assert "content-length" not in headers_after_removing



# Generated at 2022-06-26 03:25:13.519846
# Unit test for function import_string
def test_import_string():
    from importlib import reload
    from aiohttp.web import Application, run_app

    async def handler(request):
        assert request.app.name.upper() == "MY APP"

        text = "Hello, world"
        return web.Response(text=text)

    def build(loop):
        app = Application(loop=loop)
        app.router.add_get("/", handler)
        name = "my app"
        app["name"] = name

        return app

    BODY = [
        b"GET / HTTP/1.1",
        b"Host: 0.0.0.0:8080",
        b"User-Agent: curl/7.43.0",
        b"Accept: */*",
        b"",
        b"",
    ]

# Generated at 2022-06-26 03:25:16.197373
# Unit test for function import_string
def test_import_string():
    mod = import_string("tests.test_http.test_case_0")
    print("mod={}".format(mod))


if __name__ == '__main__':
    test_import_string()

# Generated at 2022-06-26 03:25:23.621411
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    dct_1 = {}
    result_0 = remove_entity_headers(dct_1)
    assert result_0 == {}
    dct_1 = {"c": "a", "Content-Type": "a", "d": "b"}
    result_0 = remove_entity_headers(dct_1)
    assert result_0 == {"c": "a", "d": "b"}
    dct_1 = {"c": "a", "Content-Type": "a", "d": "b"}
    result_0 = remove_entity_headers(dct_1, ["Content-Type"])
    assert result_0 == {"c": "a", "Content-Type": "a", "d": "b"}

# Generated at 2022-06-26 03:25:28.547737
# Unit test for function import_string
def test_import_string():
    module = import_string("http.status")
    result = module.status_codes[200]
    expected = b"OK"
    assert result == expected

    class TestClass():
        def __init__(self):
            self.a = "Hello World!"

    assert import_string("tests.test_http.TestClass").a == "Hello World!"

# Generated at 2022-06-26 03:25:33.126480
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers_test = {"content-length": "100", "content-encoding": "gzip",
                    "blah": "blah"}
    result = remove_entity_headers(headers_test)
    assert("content-encoding" not in result
           and "content-length" not in result)



# Generated at 2022-06-26 03:25:36.542036
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({'Content-Type': 'text/html', 'Cache-Control': 'no-cache'}) == {
        "cache-control": "no-cache"
    }



# Generated at 2022-06-26 03:25:48.117828
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({'header1': 1, 'header2': 2}) == {'header1': 1, 'header2': 2}
    assert remove_entity_headers({'content-type': 1, 'header2': 2}) == {'content-type': 1, 'header2': 2}
    assert remove_entity_headers({'content-location': 1, 'header2': 2}) == {'content-location': 1, 'header2': 2}
    assert remove_entity_headers({'allow': 1, 'header2': 2}) == {'header2': 2}
    assert remove_entity_headers({'content-encoding': 1, 'header2': 2}) == {'header2': 2}
    assert remove_entity_headers({'content-language': 1, 'header2': 2}) == {'header2': 2}
   

# Generated at 2022-06-26 03:25:53.278779
# Unit test for function import_string
def test_import_string():
    from hamcrest import assert_that
    from hamcrest import equal_to

    module = import_string('http_basic.utils')
    assert_that(module.STATUS_CODES, equal_to({}))


if __name__ == "__main__":
    import pytest
    import sys
    pytest.main(sys.argv)

# Generated at 2022-06-26 03:25:57.212548
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = [
        ("Content-Type", "text/html"),
        ("Connection", "close"),
        ("Content-Length", "200"),
        ("Content-Location", "external"),
    ]
    assert remove_entity_headers(dict(headers)) == {"Content-Location": "external"}



# Generated at 2022-06-26 03:26:00.661573
# Unit test for function import_string
def test_import_string():
    from . import test_module
    assert import_string("httptools.http_protocol.test_module") == test_module

# Generated at 2022-06-26 03:26:03.023487
# Unit test for function import_string
def test_import_string():
    module_name = "http_standard"
    package = import_string(module_name)
    assert ismodule(package)


# Generated at 2022-06-26 03:26:06.688993
# Unit test for function import_string
def test_import_string():
    assert import_string("asyncio.events.BaseDefaultEventLoopPolicy")
    assert import_string("asyncio")
    assert import_string("http.cookies.SimpleCookie")

# Generated at 2022-06-26 03:26:10.215276
# Unit test for function has_message_body
def test_has_message_body():
    list_0 = []
    var_0 = has_message_body(list_0)
    assert (var_0 == True), "wrong answer"
    var_0 = has_message_body([])
    assert (var_0 == True), "wrong answer"


# Generated at 2022-06-26 03:26:13.316429
# Unit test for function import_string
def test_import_string():
    from types import ModuleType
    module = import_string("tests.http.test_http")
    assert isinstance(module, ModuleType)
    test_module = module()
    assert isinstance(test_module, test_module.TestHttp)

# Generated at 2022-06-26 03:26:14.866656
# Unit test for function import_string
def test_import_string():
    pass

# Generated at 2022-06-26 03:26:23.785779
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == True
    assert has_message_body(101) == True
    assert has_message_body(102) == True
    assert has_message_body(103) == True
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(202) == True
    assert has_message_body(203) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == True
    assert has_message_body(206) == True
    assert has_message_body(207) == True
    assert has_message_body(208) == True
    assert has_message_body(226) == True
    assert has_message_body(300) == True
    assert has_

# Generated at 2022-06-26 03:26:32.688457
# Unit test for function import_string
def test_import_string():

    import os
    import sys

    # Initialization
    path = os.path.dirname(os.path.realpath(__file__))
    path = path.replace('/tests', '')
    sys.path.append(path)

    from aiohttp import web
    from aiohttp import client
    from pineboolib.loader.main import init_cli

    os.environ["PINEBOO_DIR"] = path
    init_cli()

    # Test
    app = web.Application()
    app_import = import_string(
        "pineboolib.application.application.application.load", package=path
    )

    app_import.load_includes(app)
    client_mng = client.ClientSession()
    app_import.load_web(app)
    # Test End
    assert 1 == 1

# Generated at 2022-06-26 03:26:41.023524
# Unit test for function import_string
def test_import_string():
    """
    Function to test import_string function
    """
    from examples.middlewares.middleware_sample import HelloWorld
    module = import_string("examples.middlewares.middleware_sample.HelloWorld")
    assert module == HelloWorld, "Error importing module by string"

    instance = import_string(
        "examples.middlewares.middleware_sample.HelloWorld"
    )
    assert instance.__class__.__name__ == "HelloWorld", "Error importing class by string"


if __name__ == "__main__":
    test_case_0()
    test_import_string()

# Generated at 2022-06-26 03:26:46.444803
# Unit test for function import_string
def test_import_string():
    assert import_string("string.ascii_lowercase") == "abcdefghijklmnopqrstuvwxyz"
    assert import_string("string.ascii_uppercase") == "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

# Generated at 2022-06-26 03:27:01.055484
# Unit test for function import_string
def test_import_string():
    import pytest
    from importlib import reload

    class App:
        pass

    assert import_string("asyncio.tasks.py34") is not None
    assert import_string("aiohttp.web.application") is not None
    assert import_string("aiohttp.abc.abc") is not None

    assert import_string(__name__ + ".test_import_string") is not None

    try:
        import aiohttp.web.run_app
    except ModuleNotFoundError:
        pass
    else:
        reload(aiohttp.web)
        reload(aiohttp.web.run_app)

        assert import_string("tests.utils.App") is App
        assert import_string("aiohttp.web.run_app") is aiohttp.web.run_app

# Generated at 2022-06-26 03:27:05.241122
# Unit test for function import_string
def test_import_string():
    obj_0 = import_string('hawk.middleware.CredentialsCheck')
    obj_1 = import_string('gevent.select.poll')


if __name__ == '__main__':
    test_case_0()
    test_import_string()

# Generated at 2022-06-26 03:27:10.606702
# Unit test for function import_string
def test_import_string():
    assert hasattr(import_string("socket", "socket"), "socket")
    assert hasattr(import_string("tests.utils.fixtures.mock_object"), "f1")
    assert import_string("tests.utils.fixtures.mock_object").f1()
    assert import_string("socket.socket").socket

# Generated at 2022-06-26 03:27:13.007744
# Unit test for function import_string
def test_import_string():
    mod = import_string('http.server')
    assert(mod is not None)
    assert(hasattr(mod, 'BaseHTTPRequestHandler'))


# Generated at 2022-06-26 03:27:20.556920
# Unit test for function import_string
def test_import_string():
    # Testing for correct import of module
    test_module = import_string("quoridor.http.common")
    assert test_module is not None
    assert ismodule(test_module) is True
    assert test_module.__name__ == "quoridor.http.common"
    # Testing for correct import of class and instanciation
    test_class = import_string("quoridor.__main__.Quoridor")
    assert test_class is not None
    assert test_class.__class__.__name__ == "Quoridor"
    # Testing for non-existing module
    try:
        import_string("random_module.random_class")
    except (ImportError, AttributeError):
        assert True
    else:
        assert False

# Generated at 2022-06-26 03:27:22.681378
# Unit test for function import_string
def test_import_string():
    import_str = import_string("http.HTTPStatus.NOT_FOUND")
    assert import_str == 404, "error in http status code"



# Generated at 2022-06-26 03:27:24.885808
# Unit test for function import_string
def test_import_string():
    assert import_string("http.cookies")
    assert import_string("http.cookies.SimpleCookie")

# Generated at 2022-06-26 03:27:27.273266
# Unit test for function import_string
def test_import_string():
    list_0 = []
    assert import_string("app.Application") == import_string("app.Application")

# Generated at 2022-06-26 03:27:33.697157
# Unit test for function import_string
def test_import_string():
    import omniORB
    var0 = import_string("omniORB.CORBA")
    assert var0 == omniORB.CORBA
    import six
    var1 = import_string("six.moves", package="six")
    assert var1 == six.moves
    list_1 = []
    var2 = import_string(" six.moves ", package="six")
    assert var2 == six.moves

# Generated at 2022-06-26 03:27:40.455853
# Unit test for function import_string
def test_import_string():
    print("test for import_string")
    assert(import_string("http.client.HTTPConnection") ==
        import_module("http.client").HTTPConnection)
    assert(import_string("http.client.HTTPConnection") !=
        import_module("http.client").HTTPSConnection)
    assert(import_string("http.client.HTTPSConnection") ==
        import_module("http.client").HTTPSConnection)
    assert(import_string("http.client.HTTPSConnection") !=
        import_module("http.client").HTTPConnection)
