

# Generated at 2022-06-26 03:25:07.849410
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(104) == True
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(400) == True
    assert has_message_body(401) == True
    assert has_message_body(402) == True
    assert has_message_body(403) == True
    assert has_message_body(404) == True
    assert has_message_body(405) == True
    assert has_message_body(406) == True
    assert has_

# Generated at 2022-06-26 03:25:18.908092
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        b"Content-Type": b"*/*",
        b"Content-Encoding": b"gzip",
        b"Content-Length": b"100",
        b"Content-Location": b"index.html"
    }

    headers = remove_entity_headers(headers)
    assert (b"Content-Type" in headers)
    assert (b"Content-Encoding" in headers)
    assert (b"Content-Length" in headers)
    assert (b"Content-Location" not in headers)


# Generated at 2022-06-26 03:25:30.080683
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({}) == {}
    assert remove_entity_headers({"a": "b"}) == {}
    assert remove_entity_headers({"allow": "b"}) == {}
    assert remove_entity_headers({"a": "b", "allow": "b"}) == {"a": "b"}
    assert remove_entity_headers({"a": "b", "allow": "b"}, allowed=()) == {"a": "b"}
    assert remove_entity_headers({"a": "b", "allow": "b"}, allowed=("allow",)) == {}
    assert remove_entity_headers({"a": "b", "allow": "b"}, allowed=("a",)) == {"a": "b"}
    assert remove_entity_headers({"a": "b", "allow": "b"}, allowed=("a", "allow"))

# Generated at 2022-06-26 03:25:42.936380
# Unit test for function import_string
def test_import_string():
    # Test import_string with module_name
    module_a = import_string(module_name='module_a')
    assert module_a.foo() == 'bar'

    # Test import_string with module_name and package
    module_a = import_string(module_name='module_a', package='package_a')
    assert module_a.foo() == 'bar'

    # Test import_string with class_name
    cls_a = import_string(module_name='module_a.ClsA')
    assert cls_a.foo() == 'bar'

    # Test import_string with class_name and package
    cls_a = import_string(module_name='module_a.ClsA', package='package_a')
    assert cls_a.foo() == 'bar'

# Generated at 2022-06-26 03:25:45.605475
# Unit test for function import_string
def test_import_string():
    """
    import_string should import and return a module object.
    """
    module_obj = import_string("net_http.parse_url")
    assert module_obj



# Generated at 2022-06-26 03:25:47.607733
# Unit test for function import_string
def test_import_string():
    import_string("werkzeug.datastructures.content_security_policy_nonce_in_style_src")


# Generated at 2022-06-26 03:25:51.516131
# Unit test for function import_string
def test_import_string():
    module_name = "http.server"
    result = import_string(module_name)
    str_0 = isinstance(result, module)
    assert str_0 is True

# Boilerplate for testing
if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-26 03:25:54.343787
# Unit test for function import_string
def test_import_string():
    if import_string("os.path") == os.path:
        print("Success")
        return 0
    else:
        print("Failure")
        return 1



# Generated at 2022-06-26 03:25:59.655290
# Unit test for function import_string
def test_import_string():
    import_string("aiohttp.web")
    import_string("aiohttp.web.Application")
    import_string("aiohttp.web.Application", package="aiohttp")
    import_string("aiohttp.web.Application", "aiohttp")

# Generated at 2022-06-26 03:26:03.188219
# Unit test for function import_string
def test_import_string():
    with pytest.raises(ModuleNotFoundError):
        import_string("not_a_valid_path.to.Class")

    mod = import_string("http.server")
    assert isinstance(mod, module)



# Generated at 2022-06-26 03:26:13.105203
# Unit test for function import_string
def test_import_string():
    import datetime
    from email.utils import formatdate
    from email.utils import format_datetime
    from http.cookies import SimpleCookie
    from types import ModuleType
    assert type(import_string("datetime")) == ModuleType
    assert type(import_string("email.utils.formatdate")) == type(formatdate)
    assert type(import_string("email.utils.format_datetime")) == type(format_datetime)
    assert type(import_string("http.cookies.SimpleCookie")) == type(SimpleCookie)
    try:
        import_string("datetime.datetime", None)
    except ValueError:
        pass
    else:
        assert False
    try:
        import_string("datetime", None)
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-26 03:26:18.878606
# Unit test for function import_string
def test_import_string():
    assert import_string("json.JSONDecoder")
    assert import_string("json.JSONEncoder")
    assert import_string("http.cookiejar.MozillaCookieJar")
    assert not import_string("json.nonexistent")
    assert not import_string("json.JSONCoder")
    assert not import_string("nonexistent.JSONDecoder")



# Generated at 2022-06-26 03:26:24.107941
# Unit test for function import_string
def test_import_string():
    try:
        from .plugin.plugin import PluginBase
        plugin = import_string('.plugin.plugin.PluginBase')
        assert isinstance(plugin, PluginBase)
    except Exception:
        assert False

if __name__ == "__main__":
    test_case_0()
    test_import_string()

# Generated at 2022-06-26 03:26:30.805893
# Unit test for function import_string
def test_import_string():
    import sys
    from os import path
    from unittest.mock import patch

    sys.modules["mymod"] = import_module("mymod")

    with patch("importlib.import_module") as mock_import_module:
        # patch the import_module
        mock_import_module.return_value = path
        obj = import_string("os.path")
        assert obj == path
        # import module and class
        obj = import_string("unittest.mock.patch")
        assert isinstance(obj, type(patch))



# Generated at 2022-06-26 03:26:36.704008
# Unit test for function import_string
def test_import_string():
    assert import_string("__main__") == __main__
    assert import_string("pip.utils") == pip.utils
    assert import_string("utils") == utils
    assert isinstance(import_string("utils.import_string"),
                      utils.import_string)
    assert isinstance(import_string("utils.HttpRequest"),
                      utils.HttpRequest)

# Generated at 2022-06-26 03:26:41.969494
# Unit test for function import_string
def test_import_string():
    import pytest
    with pytest.raises(AttributeError) as err:
        import_string("pytest.ini")
    assert str(err.value) == "module 'pytest' has no attribute 'ini'"
    with pytest.raises(ImportError) as err:
        import_string("pytest.ini.nonexistent_mod")
    assert str(err.value) == "No module named 'pytest.ini.nonexistent_mod'"

# Generated at 2022-06-26 03:26:44.264892
# Unit test for function import_string
def test_import_string():
    import_string('builtins', package=None)

# Checking if the expected result is the same as the actual result generated

# Generated at 2022-06-26 03:26:51.030434
# Unit test for function import_string
def test_import_string():
    import unittest

    class TestImportString(unittest.TestCase):
        """Tests the import_string function."""

        def test_import_class(self):
            """Tests that a class can be imported."""
            from f8a_worker.http import http

            self.assertTrue(http.HTTPResultResponse(status=200))


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 03:26:52.364728
# Unit test for function import_string
def test_import_string():
    import_string_case0()
    import_string_case1()
    import_string_case2()


# Generated at 2022-06-26 03:26:57.846405
# Unit test for function import_string
def test_import_string():
    assert import_string("httptools.http2_server.Http2Server") is not None
    assert import_string("httptools.http2_server.Http2Server").__class__ is type 


if __name__ == "__main__":
    import sys
    import cProfile

    if len(sys.argv) == 1:
        sys.exit(0)

    elif sys.argv[1] == "test_import_string":
        profile = cProfile.Profile()
        profile.enable()

        test_import_string()
        profile.disable()
        profile.print_stats(sort="cumtime")

        sys.exit(0)