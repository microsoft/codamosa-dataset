

# Generated at 2022-06-12 08:59:13.722194
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    Test remove_entity_headers function with a
    HTTP/1.1 200 OK
    Content-Length: 10
    Content-Type: text/html

    The output is:
    HTTP/1.1 200 OK
    Content-Length: 10
    Content-Type: text/html

    """
    input_headers = {
        "content-length": 10,
        "content-type": "text/html",
        "content-location": "temp",
        "expires": "Wed 01 Jan 2020 23:59:59 GMT",
    }
    output_headers = remove_entity_headers(input_headers, ("content-location", "expires"))
    assert len(output_headers) == 2

# Generated at 2022-06-12 08:59:23.463748
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(104) == False
    assert has_message_body(105) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(202) == True
    assert has_message_body(203) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == False
    assert has_message_body(206) == True
    assert has_message_body(207) == True
    assert has_message_body(208) == False
    assert has_

# Generated at 2022-06-12 08:59:30.357405
# Unit test for function import_string
def test_import_string():
    from .request import Request
    from .response import Response
    from .route import Route
    from .server import Server
    for module in [Request, Response, Route, Server]:
        module_name = import_string(module.__module__+"."+module.__name__)
        assert module_name == module

if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 08:59:38.986542
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(103)
    assert not has_message_body(167)
    assert not has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(212)
    assert has_message_body(301)
    assert has_message_body(302)
    assert not has_message_body(304)
    assert has_message_body(305)
    assert has_message_body(400)
    assert has_message_body(401)
    assert has_message_body(404)
    assert has_message_body(405)
    assert has_message_body(500)
    assert has_message

# Generated at 2022-06-12 08:59:42.484756
# Unit test for function import_string
def test_import_string():
    from .http import HttpRequest, HttpResponse
    from . import http
    assert import_string("falcon.http.HttpRequest") == HttpRequest
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HttpResponse")() == HttpResponse()
    assert import_string("falcon.http.HttpResponse") == HttpResponse

# Generated at 2022-06-12 08:59:44.629790
# Unit test for function import_string
def test_import_string():
    from aiohttp.abc import Application
    from aiohttp import web
    assert issubclass(import_string("aiohttp.abc"), Application)



# Generated at 2022-06-12 08:59:46.331363
# Unit test for function import_string
def test_import_string():
    from . import base
    import_string('aiohttp.web.base.View')
    import_string('aiohttp.web.base.View', 'aiohttp.web') == base.View

# Generated at 2022-06-12 08:59:51.974182
# Unit test for function import_string
def test_import_string():
    """Test for import_string function"""
    from .. import HttpProtocol
    from ..middleware import BaseMiddleware

    assert import_string("asab.http.HttpProtocol") == HttpProtocol
    assert isinstance(import_string("asab.http.middleware.BaseMiddleware"), BaseMiddleware)

# Generated at 2022-06-12 09:00:02.515194
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-location": "/index.html", "expires": "Fri, 01 Jan 2000 00:00:00 GMT"}
    headers = remove_entity_headers(headers)
    for k in headers:
        if k != 'content-location' and k != 'expires':
            assert False
    headers = {"content-location": "/index.html"}
    headers = remove_entity_headers(headers)
    for k in headers:
        if k != 'content-location':
            assert False
    headers = {"content-location": "/index.html", "expires": "Fri, 01 Jan 2000 00:00:00 GMT",
               "content-md5": "whatever"}
    headers = remove_entity_headers(headers)
    for k in headers:
        if k != 'content-location' and k != 'expires':
            assert False

# Generated at 2022-06-12 09:00:05.662472
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False

# Generated at 2022-06-12 09:00:17.243291
# Unit test for function import_string
def test_import_string():
    """Tests import string, import module and class"""
    from itertools import count
    from .base import BaseView # noqa

    class View(BaseView):
        """A simple view for test."""

        def __init__(self, name: str):
            """Sets a name."""
            self.name = name

        async def dispatch(self, request):
            """Returns name."""
            return self.name

    module = import_string(__name__ + ".test_http.test_import_string.View")
    assert module is View

    view1 = import_string(__name__ + ".test_http.test_import_string.View", package=__name__)
    view2 = import_string(__name__ + ".test_http.test_import_string.View", package=__name__)

# Generated at 2022-06-12 09:00:22.467917
# Unit test for function import_string
def test_import_string():
    from urllib.parse import urlparse
    from uvicorn.config import Config

    config = Config(limit_max_headers=1000, debug=True, log_config=dict(level="info"))
    assert(isinstance(import_string(".config.Config", package="uvicorn"), Config))
    assert(isinstance(import_string("uvicorn.config.Config"), Config))
    assert(isinstance(import_string("urllib.parse.urlparse"), urlparse))

# Generated at 2022-06-12 09:00:25.436693
# Unit test for function import_string
def test_import_string():
    """Test the import_string function"""
    assert import_string("http.client.HTTPResponse") == import_module("http.client").HTTPResponse


# Generated at 2022-06-12 09:00:32.398428
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import Request
    from .http import Response
    from .handlers import BaseHandler
    from .handlers import IndexHandler

    assert import_string("inhttp.http") == http
    assert import_string("inhttp.http.Request") == Request
    assert import_string("inhttp.http.Response") == Response
    assert import_string("inhttp.handlers.BaseHandler") == BaseHandler
    assert isinstance(import_string("inhttp.handlers.IndexHandler"), IndexHandler)

# Generated at 2022-06-12 09:00:43.680409
# Unit test for function import_string
def test_import_string():
    import os.path
    from urllib.parse import unquote_plus

    from quart.static import StaticResource

    this_dir = os.path.dirname(os.path.abspath(__file__))

    # Should return module object
    assert issubclass(
        import_string("quart.static.StaticResource"), StaticResource
    )

    # Should return class object
    assert issubclass(
        import_string("quart.static.StaticResource"), StaticResource
    )

    # Should allows use of / in the module name
    assert issubclass(
        import_string("quart/static.StaticResource"), StaticResource
    )

    # Should raise ValueError if not found
    try:
        import_string("quart.static.NonexistentClass")
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-12 09:00:47.398225
# Unit test for function import_string
def test_import_string():
    from . import request

    assert isinstance(
        import_string("aioserve.http.protocol.request.Request"), request.Request
    )

    assert isinstance(
        import_string("aioserve.http.protocol.request"), request
    )



# Generated at 2022-06-12 09:00:55.806204
# Unit test for function import_string
def test_import_string():
    from types import ModuleType
    package_name = "mylib.sublib.subsublib"
    module_name = package_name + ".mymodule"
    class_name = "MyClass"
    module = import_string(module_name, package=package_name)
    assert isinstance(module, ModuleType)
    assert module.__name__ == module_name
    assert module.__package__ == package_name
    myclass = import_string(class_name, package=module_name)
    assert isinstance(myclass, type)
    assert myclass.__name__ == class_name
    assert myclass().__class__ == myclass

# Generated at 2022-06-12 09:01:02.244556
# Unit test for function import_string
def test_import_string():
    """
    this function import a class from module test_utils.mock_objects.
    then we check if it is an instance from MockRequest class
    """
    module_name = "wladimircomputacao.http.protocol.test_utils.mock_objects.MockRequest"
    req = import_string(module_name)
    assert req
    assert isinstance(req, MockRequest)



# Generated at 2022-06-12 09:01:09.051803
# Unit test for function import_string
def test_import_string():
    from pytest import raises

    # Test import module
    module = import_string("http.server")
    assert module

    # Test import class
    klass = import_string("http.server.BaseHTTPRequestHandler")
    assert klass()

    # Test import not existing module
    with raises(ModuleNotFoundError):
        import_string("not_existing")

    # Test import not existing class
    with raises(AttributeError):
        import_string("http.server.NotExisting")

    # Test import not existing module without package context
    with raises(ModuleNotFoundError):
        import_string("not_existing_package.not_existing")

# Generated at 2022-06-12 09:01:09.598131
# Unit test for function import_string
def test_import_string():

    return True