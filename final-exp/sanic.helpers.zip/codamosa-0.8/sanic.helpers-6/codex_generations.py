

# Generated at 2022-06-12 08:59:18.945906
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-encoding": "gzip",
        "Content-Language": "en",
        "Content-Length": "100",
        "Content-Location": "china",
        "Content-MD5": "100",
        "Content-Range": "100",
        "Content-Type": "text/html",
        "Expires": "Fri, 30 Oct 1998 14:19:41 GMT",
        "Last-Modified": "Wed, 15 Nov 1995 04:58:08 GMT",
        "Extension-Header": "Mon, 20 Nov 1995 19:12:08 GMT",
    }

# Generated at 2022-06-12 08:59:23.081114
# Unit test for function import_string
def test_import_string():
    from sanic.response import HTTPResponse
    from sanic.request import Request
    assert import_string("sanic.response.HTTPResponse") == HTTPResponse
    assert isinstance(import_string("sanic.request.Request"), Request)

# Generated at 2022-06-12 08:59:28.849289
# Unit test for function import_string
def test_import_string():
    """
    Test if import_string return a valid object
    """
    import aiohttp
    import socket
    assert import_string("aiohttp")
    assert isinstance(import_string("socket.socket"), socket.socket)

# Generated at 2022-06-12 08:59:37.905759
# Unit test for function import_string
def test_import_string():
    import uvicorn  # noqa: F401
    from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware  # noqa: F401
    from uvicorn.lifespan import Lifespan  # noqa: F401
    import uvicorn.lifespan
    from asgi_lifespan import Lifespan as Lifespan2  # noqa: F401
    import asgi_lifespan
    # Import module and class succefully
    assert import_string("uvicorn.middleware.proxy_headers.ProxyHeadersMiddleware") == ProxyHeadersMiddleware
    # Import one module succefully
    assert import_string("uvicorn.lifespan") == uvicorn.lifespan
    assert import_string("uvicorn.lifespan.Lifespan") == Lifespan

# Generated at 2022-06-12 08:59:44.525776
# Unit test for function import_string
def test_import_string():
    from uvicorn.importer import import_from_string
    import sys
    import pytest

    def check_import(package=None, module=None, class_path=None, instance=False):
        if module is not None and class_path is not None:
            path = '{}.{}'.format(module, class_path)
        elif module is not None:
            path = module
        elif class_path is not None:
            path = class_path
        else:
            raise ValueError('check_import must have a module or a class_path')
        result = import_from_string(path, package=package)
        if instance:
            assert isinstance(result, imported_module)

# Generated at 2022-06-12 08:59:47.873197
# Unit test for function import_string
def test_import_string():
    from anyhttp import http
    assert import_string(http.__name__) is import_string(http.__name__)
    from anyhttp._base import Response
    assert import_string(http.__name__) is import_string(http.__name__)
    assert import_string(Response.__name__) is import_string(Response.__name__)

    assert import_string(http.__name__) is http
    assert import_string(Response.__name__) is Response

# Generated at 2022-06-12 08:59:50.650493
# Unit test for function import_string
def test_import_string():
    from http import client
    client_module = import_string("http.client")
    assert(client_module is client)


# Generated at 2022-06-12 08:59:54.688470
# Unit test for function import_string
def test_import_string():
    from werkzeug.exceptions import NotFound
    assert import_string("werkzeug.exceptions.NotFound") is NotFound
    assert import_string("werkzeug.exceptions.NotFound")() is NotFound


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 09:00:05.580474
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    import pytest
    from .test_util import META_FIELDS

    headers = {
        "content-type": "aaa",
        "content-length": "bbb",
        "content-md5": "ccc",
        "Content-Location": "ddd",
        "content-location": "eee",
        "expires": "fff",
        "Expires": "ggg",
        "Content-Md5": "hhh",
    }
    expected_output = {
        "Content-Location": "ddd",
        "content-location": "eee",
        "expires": "fff",
        "Expires": "ggg",
    }

    actual_output = remove_entity_headers(headers, allowed=META_FIELDS)
    assert actual_output == expected_output

    actual

# Generated at 2022-06-12 09:00:09.734537
# Unit test for function has_message_body
def test_has_message_body():
    assert(has_message_body(200) == True)
    assert(has_message_body(204) == False)
    assert(has_message_body(304) == False)
    assert(has_message_body(100) == False)
    assert(has_message_body(101) == True)
    assert(has_message_body(102) == True)

# Generated at 2022-06-12 09:00:21.320870
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """Unit test for function remove_entity_headers"""
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "Length",
        "Content-Encoding": "UTF-8",
        "Content-Language": "en",
        "Content-Location": "Location",
        "Expires": "Expires",
        "Last-Modified": "Last-Modified",
        "Extension-Header": "Extension-Header",
    }
    expected = {
        "Content-Location": "Location",
        "Expires": "Expires",
    }
    assert remove_entity_headers(headers) == expected
    allowed = ["Expires"]
    assert remove_entity_headers(headers, allowed) == {"Expires": "Expires"}



# Generated at 2022-06-12 09:00:29.467999
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "identity",
        "Content-Language": "tr",
        "Content-Location": "foo.txt",
        "Expires": "tomorrow",
        "Last-Modified": "now",
        "Extension-Header": "abc",
    }
    expected = {}
    expected.update({
        "Content-Location": "foo.txt",
        "Expires": "tomorrow"
    })
    assert remove_entity_headers(headers) == expected

# Generated at 2022-06-12 09:00:32.446723
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Length": "200", "Content-Type": "application/json"}
    expected_headers = {"Content-Type": "application/json"}
    assert remove_entity_headers(headers) == expected_headers

# Generated at 2022-06-12 09:00:36.347602
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Length": "20", "Content-Type": "text/plain"}
    allowed = ("content-length",)
    headers = remove_entity_headers(headers, allowed)
    assert headers == {"Content-Length": "20"}

# Generated at 2022-06-12 09:00:45.692038
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({"a": "b", "c": "d"}) == {
        "a": "b",
        "c": "d",
    }
    assert remove_entity_headers({"Content-Length": "123", "c": "d"}) == {
        "c": "d",
    }
    assert remove_entity_headers({"content-length": "123", "c": "d"}) == {
        "c": "d",
    }
    assert (
        remove_entity_headers({"Content-Location": "123", "c": "d"}, allowed=["content-location"])
        == {"c": "d", "content-location": "123"}
    )

# Generated at 2022-06-12 09:00:55.390720
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-location": "abc",
        "expires": "abc",
        "content-language": "abc",
        "content-length": "abc",
        "content-md5": "abc",
        "content-range": "abc",
        "content-type": "abc",
        "last-modified": "abc",
    }

    remove_entity_headers(headers)
    assert headers == {}

    headers = {
        "content-location": "abc",
        "content-length": "abc",
        "expires": "abc",
    }
    remove_entity_headers(headers)
    assert headers == {
        "content-location": "abc",
        "expires": "abc"
    }

# Generated at 2022-06-12 09:01:06.313927
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({}) == {}
    assert remove_entity_headers({"Expires": "Thu, 01 Dec 1994 16:00:00 GMT"}) == {}
    assert remove_entity_headers({"Content-Location": "http://example.com"}) == {}
    assert remove_entity_headers({"Date": "Thu, 01 Dec 1994 16:00:00 GMT"}) == {"Date": "Thu, 01 Dec 1994 16:00:00 GMT"}
    assert remove_entity_headers({"Expires": "Thu, 01 Dec 1994 16:00:00 GMT"}, allowed=("Date",)) == {}

# Generated at 2022-06-12 09:01:16.968590
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Connection": "close",
        "Content-Encoding": "gzip",
        "Content-Length": "0",
        "Content-Type": "image/jpeg",
        "Date": "Tue, 15 Nov 1994 08:12:31 GMT",
        "Location": "https://www.google.com",
        "Server": "nginx/1.10.3",
    }

    # Remove entity headers function
    _headers = remove_entity_headers(headers)
    assert "Connection" in _headers
    assert "Date" in _headers
    assert "Location" in _headers
    assert "Server" in _headers
    assert "Content-Encoding" not in _headers
    assert "Content-Length" not in _headers
    assert "Content-Type" not in _headers

    # Remove entity headers function allowing some

# Generated at 2022-06-12 09:01:26.493260
# Unit test for function remove_entity_headers

# Generated at 2022-06-12 09:01:31.434524
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # normal case
    headers = {"Content-length": "12", "content-encoding": "utf-8"}
    expected_headers = {}
    assert remove_entity_headers(headers) == expected_headers

    # not in list of entity headers
    headers = {"expires": "5", "content-length": "12"}
    expected_headers = {"expires": "5"}
    assert remove_entity_headers(headers) == expected_headers

    # keep the allowed ones
    headers = {
        "Content-length": "12",
        "content-encoding": "utf-8",
        "content-location": "http://example.com",
    }
    expected_headers = {"content-location": "http://example.com"}
    assert remove_entity_headers(headers) == expected_headers