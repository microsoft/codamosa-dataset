

# Generated at 2022-06-12 08:59:10.798672
# Unit test for function import_string
def test_import_string():
    from .http import Request

    path = "uvicorn.protocols.http.httptools_impl.HttpToolsRequest"
    assert id(import_string(path)) == id(Request)



# Generated at 2022-06-12 08:59:16.512700
# Unit test for function import_string
def test_import_string():
    from .test_utils import MockClass

    obj = import_string("aiohttp.test_utils.MockClass")
    assert isinstance(obj, MockClass)

    obj = import_string("aiohttp.test_utils.MockClass", "aiohttp")
    assert isinstance(obj, MockClass)

    assert import_string("aiohttp.test_utils") == import_module("aiohttp.test_utils")



# Generated at 2022-06-12 08:59:26.789190
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-language": "en",
        "last-modified": "Thu, 01 Jan 1970 00:00:00 GMT",
        "content-md5": "Q2hlY2sgSW50ZWdyaXR5IQ==",
        "content-type": "text/html; charset=utf-8",
        "content-length": "25",
        "content-location": "http://pulsar.readthedocs.org/en/latest/",
        "expires": "Thu, 01 Jan 2038 00:00:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert "content-location" in headers
    assert "expires" in headers
    assert "content-type" not in headers
    assert "content-language" not in headers

# Generated at 2022-06-12 08:59:33.674988
# Unit test for function import_string
def test_import_string():
    from server.middlewares.middleware import BaseMiddleware
    from server.middlewares.base import Base
    middleware = import_string("server.middlewares.middleware.BaseMiddleware")
    base = import_string("server.middlewares.base.Base")
    assert isinstance(middleware, BaseMiddleware)
    assert isinstance(base, Base)
    assert base

# Generated at 2022-06-12 08:59:43.085418
# Unit test for function import_string
def test_import_string():
    from starlette.middleware import middleware_class_factory
    from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware
    from starlette.middleware.gzip import GZipMiddleware
    from starlette.middleware.cors import CORSMiddleware
    from starlette.middleware.trustedhost import TrustedHostMiddleware
    from starlette.middleware.authentication import AuthenticationMiddleware
    from starlette.middleware.sessions import SessionMiddleware
    from starlette.middleware.basicauth import BasicAuthMiddleware
    from starlette.middleware.errorhandlers import ErrorHandlerMiddleware
    from starlette.middleware.profiler import ProfilerMiddleware
    from starlette.middleware.proxyconverter import ProxyConverterMiddleware


# Generated at 2022-06-12 08:59:49.287075
# Unit test for function import_string
def test_import_string():
    from .config import test_packages
    from .config import Config

    config = Config({})

    for package in test_packages:
        assert ismodule(
            import_string(package, package=config.packages_path)
        ), "Error: %s is not a module" % package

        assert hasattr(
            import_string(package, package=config.packages_path),
            "app",
        ), "Error: module %s has not app attr" % package



# Generated at 2022-06-12 08:59:55.161982
# Unit test for function import_string
def test_import_string():
    from . import middleware
    from .view import View
    from .http import Request
    from .request import RequestHandler
    from .response import Response

    assert import_string("falcon.API") == middleware.API
    assert import_string("falcon.View") == View
    assert import_string("falcon.Request") == Request
    assert import_string("falcon.RequestHandler") == RequestHandler
    assert import_string("falcon.Response") == Response

# Generated at 2022-06-12 09:00:05.950226
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-location": "",
        "expires": "",
        "content-type": "",
        "content-md5": "",
        "content-range": "",
        "content-encoding": "",
        "content-language": "",
        "content-length": "",
    }

    headers_without_entity_headers = remove_entity_headers(headers)

    # Verify if the Content-Location, Expires and extension-header are
    # in headers_without_entity_headers
    assert "content-location" in headers_without_entity_headers
    assert "expires" in headers_without_entity_headers
    assert "extension-header" in headers_without_entity_headers

    # Verify if the other entity headers are not in the
    # headers_without_entity_headers
   

# Generated at 2022-06-12 09:00:07.700860
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers(
        {
            "CONTENT-LENGTH": "10",
            "CONTENT-TYPE": "text/plain",
            "CONTENT-LOCATION": "/test",
            "CONTENT-ENCODING": "gzip",
        }
    ) == {"CONTENT-LOCATION": "/test"}

# Generated at 2022-06-12 09:00:17.798009
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    h = {
        "Allow": "GET,POST",
        "content-length": "50",
        "content-location": "http://example.com/index.html",
        "expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "connection": "keep-alive",
        "content-language": "en-US,en",
        "proxy-authorization": "Basic 5mFtcDpzdXBlcmFkbWlu"
    }
    e = {
        "connection": "keep-alive",
        "content-location": "http://example.com/index.html",
        "expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "proxy-authorization": "Basic 5mFtcDpzdXBlcmFkbWlu"
    }

   

# Generated at 2022-06-12 09:00:21.706382
# Unit test for function import_string
def test_import_string():
    """ Functions import_string should import a module class """
    from vaurienclient.protocols._base import BaseProtocol
    assert BaseProtocol == import_string("vaurienclient.protocols._base.BaseProtocol")

# Generated at 2022-06-12 09:00:25.242838
# Unit test for function import_string
def test_import_string():
    assert import_string("aiohttp.web") == import_module("aiohttp.web")
    assert import_string("aiohttp.web.Application") == import_module("aiohttp.web").Application
    
test_import_string()

# Generated at 2022-06-12 09:00:31.035072
# Unit test for function import_string
def test_import_string():
    # Test import module app
    assert import_string("app.app")
    # Test import app class
    assert import_string("app.app.App")
    # Test import app class
    assert import_string("app.app.App").get_settings() == {
        "debug": True,
        "TEMPLATES_DIR": "templates",
        "STATIC_DIR": "static",
    }

# Generated at 2022-06-12 09:00:33.631616
# Unit test for function import_string
def test_import_string():
    assert import_string("aiohttp.web.Application") == import_module("aiohttp.web").Application

if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 09:00:38.095776
# Unit test for function import_string
def test_import_string():
    from .router import Router
    assert import_string("falcon.router.Router") == Router
    assert import_string("falcon.router.Router").__class__ == Router
    assert import_string("falcon.router.Router")() == Router()

# Generated at 2022-06-12 09:00:41.211565
# Unit test for function import_string
def test_import_string():
    from bliss.http.server import BaseHTTPRequestHandler

    server = import_string('bliss.http.server.BaseHTTPRequestHandler')
    assert issubclass(server, BaseHTTPRequestHandler)

# Generated at 2022-06-12 09:00:47.466595
# Unit test for function import_string
def test_import_string():
    print(import_string("shadowsocks.crypto.evp_cipher"))
    print(import_string("shadowsocks.crypto.evp_cipher", "shadowsocks"))
    print(import_string("shadowsocks.crypto.evp_cipher.Cipher"))
    print(import_string("shadowsocks.crypto.evp_cipher.Cipher", "shadowsocks"))
    print(import_string("shadowsocks.crypto.evp_cipher.Cipher"))

if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 09:00:49.181490
# Unit test for function import_string
def test_import_string():
    from . import serializer
    assert import_string('httpcore.serializer') is serializer

# Generated at 2022-06-12 09:00:57.077089
# Unit test for function import_string
def test_import_string():
    import os
    import tempfile
    import sys
    from io import StringIO
    my_code = """
    class HelloWorld:
        pass
    """
    file_path = tempfile.mktemp(suffix='.py')
    root_path = os.path.dirname(file_path)
    with open(file_path, 'w') as f:
        f.write(my_code)
    sys.path.insert(0, root_path)
    try:
        from . import HelloWorld
        assert HelloWorld is import_string('.HelloWorld', package=root_path)
    finally:
        os.remove(file_path)
        del sys.path[0]

# Generated at 2022-06-12 09:01:07.375516
# Unit test for function import_string
def test_import_string():
    # import string and class
    from waitress.utilities import import_string
    from waitress.utilities import import_string
    from waitress.utilities import assert_raises
    from waitress.utilities import assert_equals

    # import and instatiate class
    ut = import_string("waitress.utilities.import_string")
    assert_equals(type(ut), type(ut))

    # import module, not class
    ut = import_string("waitress.utilities")
    assert_equals(type(ut), type(ut))
    ut = import_string("waitress.utilities.import_string")
    assert_equals(type(ut), type(ut))
    exc = assert_raises(ImportError, import_string,
                        "waitress.utilities.notexist")

# Generated at 2022-06-12 09:01:13.635497
# Unit test for function import_string
def test_import_string():
    class Cls:
        """Class to be imported using the import_string function."""

    class_path = 'serve.utils.http.test_import_string.Cls'
    class_obj = import_string(class_path)
    assert isinstance(class_obj, Cls)

# Generated at 2022-06-12 09:01:16.857552
# Unit test for function import_string
def test_import_string():
    from datetime import date
    assert import_string("datetime.date") == date
    assert import_string("datetime.date").today() == date.today()

# Generated at 2022-06-12 09:01:18.170057
# Unit test for function import_string
def test_import_string():
    assert import_string("aiohttp.web.Application") is Application



# Generated at 2022-06-12 09:01:20.077644
# Unit test for function import_string
def test_import_string():
    from sanic import Sanic
    assert import_string(".app.Sanic", "test_package") == Sanic

# Generated at 2022-06-12 09:01:26.453468
# Unit test for function import_string
def test_import_string():
    from hypercorn.config import Config
    c1 = import_string("hypercorn.config.Config")
    c2 = import_string("hypercorn.config.Config")
    c3 = import_string("hypercorn.config:Config")
    c4 = import_string("hypercorn.config:Config")
    assert isinstance(c1, Config)
    assert isinstance(c2, Config)
    assert isinstance(c3, Config)
    assert isinstance(c4, Config)
    assert c1 is not c2
    assert c3 is not c4

# Generated at 2022-06-12 09:01:29.893660
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string

    """
    # import module
    obj = import_string('inspect')
    assert ismodule(obj)
    # import class and instanciate it
    obj = import_string('inspect.getsource')
    assert callable(obj)

# Generated at 2022-06-12 09:01:32.326995
# Unit test for function import_string
def test_import_string():
    from .http import HTTPRequest
    import sys
    sys.modules[__name__] = None
    assert HTTPRequest == import_string("http.HTTPRequest")
    assert HTTPRequest().__class__ == import_string("http.HTTPRequest").__class__

# Generated at 2022-06-12 09:01:37.563387
# Unit test for function import_string
def test_import_string():
    assert import_string("test.test") == import_module("test.test")
    assert import_string("test.test.test") == getattr(
        import_module("test.test"), "test"
    )
    assert type(import_string("test.test.test.Test")) == type(import_module("test.test"))
    assert (
        import_string("test.test.test.Test").__name__
        == "Test"
    )

# Generated at 2022-06-12 09:01:44.931628
# Unit test for function import_string
def test_import_string():
    from . import master
    from . import app

    assert import_string("dynamic_rest.master") == master
    assert import_string("dynamic_rest.master:Master") == master.Master
    try:
        import_string("dynamic_rest.app.app")
        assert False, "Should be an ImportError"
    except ImportError:
        pass

    assert import_string("dynamic_rest.app.app:App") == app.app.App
    assert import_string("dynamic_rest.app.app", package="dynamic_rest") == app.app.App

    try:
        import_string("dynamic_rest.master:Master.test")
        assert False, "Should be an AttributeError"
    except AttributeError:
        pass



# Generated at 2022-06-12 09:01:48.451386
# Unit test for function import_string
def test_import_string():
    assert import_string("builtins.str") is str
    from .client import Client
    assert import_string("aiohttp.client.Client") is Client
    assert isinstance(import_string("aiohttp.client.Client"), Client)

# Generated at 2022-06-12 09:01:52.308870
# Unit test for function import_string
def test_import_string():
    """Test import_string function"""
    assert import_string("hypercorn.config.Config")


# Generated at 2022-06-12 09:01:59.756848
# Unit test for function import_string
def test_import_string():
    import pytest

    module_name = "test_import_string"
    with pytest.raises(ImportError):
        import_string(module_name)

    module_name = "http.server"
    module = import_string(module_name)
    assert module.__name__ == "http.server"

    module_name = "http.server.MyHandler"
    with pytest.raises(AttributeError):
        import_string(module_name)

    class_name = "http.server.BaseHTTPRequestHandler"
    my_handler = import_string(class_name)
    assert my_handler.__module__ == "http.server"



# Generated at 2022-06-12 09:02:04.643526
# Unit test for function import_string
def test_import_string():
    import os

    package_path = os.path.abspath(os.path.dirname(__file__))
    os.path.join(package_path, "test_import_string.py")
    module_name = "aiohttpdemo_polls.test_import_string.TestClass"
    module = import_string(module_name)
    assert isinstance(module, type)

# Generated at 2022-06-12 09:02:07.206211
# Unit test for function import_string
def test_import_string():
    assert import_string("unittest.TestCase") == import_module("unittest").TestCase
    assert isinstance(import_string("http.server.BaseHTTPRequestHandler"), import_module("http.server").BaseHTTPRequestHandler)
    assert import_string("a") is None



# Generated at 2022-06-12 09:02:16.683938
# Unit test for function import_string
def test_import_string():
    expected = bytes
    result = import_string("bytes")
    assert expected == result
    from uvicorn.protocols.http.httptools_impl import HttpToolsProtocol
    expected = HttpToolsProtocol
    result = import_string("uvicorn.protocols.http.httptools_impl.HttpToolsProtocol")
    assert expected == result
    result = import_string("uvicorn.protocols.http.httptools_impl.HttpToolsProtocol")
    assert expected == result
    expected = HttpToolsProtocol
    result = import_string("uvicorn.protocols.http.httptools_impl.HttpToolsProtocol").__class__
    assert expected == result

# Generated at 2022-06-12 09:02:25.676480
# Unit test for function import_string
def test_import_string():
    assert import_string("http.HTTPStatus")
    assert import_string("aiohttp.web.HTTPInternalServerError")
    assert isinstance(import_string("aiohttp.web.HTTPInternalServerError"),
                      import_string("aiohttp.web.HTTPInternalServerError"))
    assert import_string("http.client.HTTPConnection")
    assert isinstance(import_string("http.client.HTTPConnection",
                                    package="http.client"),
                      import_string("http.client.HTTPConnection",
                                    package="http.client"))
    assert import_string("http.server.BaseHTTPRequestHandler",
                          package="http.server")

# Generated at 2022-06-12 09:02:30.893962
# Unit test for function import_string
def test_import_string():
    # TODO: test code is ugly, see if we can improve
    import tests.application_test as application_test
    import tests.application_test as application_test_class
    assert import_string("tests.application_test") == application_test
    assert import_string("tests.application_test.ApplicationTest") == application_test_class.ApplicationTest

# Generated at 2022-06-12 09:02:36.200567
# Unit test for function import_string
def test_import_string():

    class _Test(object):
        pass

    assert import_string('time.ctime')
    assert isinstance(import_string(__name__ + '._Test'), _Test)
    try:
        import_string(__name__ + '._Test.a')
    except AttributeError:
        pass
    else:
        raise AssertionError("AttributeError expected")
    try:
        import_string('ctime')
    except ImportError:
        pass
    else:
        raise AssertionError("ImportError expected")

# Generated at 2022-06-12 09:02:40.552340
# Unit test for function import_string
def test_import_string():
    from . import http, base

    assert import_string("falcon.http.Line") is http.Line
    assert import_string("falcon.base.APIMetaclass") is base.APIMetaclass

    # Change the module PATH to be test
    assert import_string("test_base.test_http.Line") is http.Line
    assert import_string(
        "test_base.test_http.Line", package="falcon.base"
    ) is http.Line



# Generated at 2022-06-12 09:02:41.719618
# Unit test for function import_string
def test_import_string():
    assert ismodule(import_string("inspect"))



# Generated at 2022-06-12 09:02:54.948569
# Unit test for function import_string
def test_import_string():
    from unittest import TestCase, main
    from unittest.mock import MagicMock

    class FakeClass(object):
        def __init__(self):
            self.fake_attribute = "fake"

    class TestImportString(TestCase):
        def test_imports_a_module(self):
            from sys import version_info
            import_string("sys")
            self.assertEqual(version_info, version_info)

        def test_imports_a_class_and_instanciate_it(self):
            self.assertEqual(
                import_string("__main__.FakeClass").fake_attribute, "fake"
            )


# Generated at 2022-06-12 09:02:57.208610
# Unit test for function import_string
def test_import_string():
    from fastapi import FastAPI
    fastapi = import_string("fastapi.FastAPI")
    assert issubclass(fastapi, FastAPI)

# Generated at 2022-06-12 09:03:02.282456
# Unit test for function import_string
def test_import_string():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.extra.pytz import timezones
    from pytz import utc

    @given(text())
    def test_import_string(module_name):
        try:
            import_string(module_name)
        except ImportError:
            assert module_name == "invalid module"
        else:
            assert module_name == "pytz.utc"

    test_import_string()

# Generated at 2022-06-12 09:03:11.311430
# Unit test for function import_string
def test_import_string():
    from unittest import TestCase

    def check_import_string(module_name):
        import_string(module_name)

    class TestImportString(TestCase):

        def test_imports(self):
            test_import_string("unittest.TestCase")
            test_import_string("unittest.mock.mock_open")
            test_import_string("asyncio.Future")

        def test_imports_with_errors(self):
            with self.assertRaises(ImportError):
                test_import_string("a")
            with self.assertRaises(ImportError):
                test_import_string("")
            with self.assertRaises(ImportError):
                test_import_string(".a")
            with self.assertRaises(ImportError):
                test_import_string

# Generated at 2022-06-12 09:03:13.058332
# Unit test for function import_string
def test_import_string():
    from . import middlewares
    assert import_string("abstractserver.middlewares.base.BaseMiddleware") == middlewares.base.BaseMiddleware

# Generated at 2022-06-12 09:03:16.463397
# Unit test for function import_string
def test_import_string():
    from .config import Config
    from .middleware import Middleware

    # Test module without class
    assert import_string("falcon.config") is Config

    # Test module with class
    assert isinstance(import_string("falcon.middleware.Middleware"), Middleware)

# Generated at 2022-06-12 09:03:19.283493
# Unit test for function import_string
def test_import_string():
    # 1) Simple module import
    from . import core
    assert core is import_string(".core")
    # 2) Simple import and class instance
    from .utils import Headers
    assert isinstance(import_string(".utils.Headers"), Headers)

# Generated at 2022-06-12 09:03:21.365265
# Unit test for function import_string
def test_import_string():
    from httpolice.input.ir import IR
    assert import_string("httpolice.input.ir.IR") == IR
    assert import_string("httpolice.input.ir.IR").run("a", "b") == "a b"

# Generated at 2022-06-12 09:03:24.798439
# Unit test for function import_string
def test_import_string():
    """
    Test for import_string.
    """
    from pyhttp2.http import Request
    assert Request == import_string("pyhttp2.http.Request")
    from pyhttp2.http.server import Server
    assert Server() == import_string("pyhttp2.http.server.Server")

# Generated at 2022-06-12 09:03:28.654708
# Unit test for function import_string
def test_import_string():
    from .middleware import SimpleMiddleware
    from .http import SimpleRequestResponse
    obj_1=import_string('hypercorn.middleware.SimpleMiddleware')
    obj_2=import_string('hypercorn.http.SimpleRequestResponse')
    assert(isinstance(obj_1, SimpleMiddleware))
    assert(isinstance(obj_2, SimpleRequestResponse))

# Generated at 2022-06-12 09:03:40.897579
# Unit test for function import_string
def test_import_string():
    assert isinstance(import_string("test_http.test_utils.test_import_string"),
                      test_import_string)
    assert isinstance(import_string("test_http.test_utils"), test_utils)

# Generated at 2022-06-12 09:03:43.833133
# Unit test for function import_string
def test_import_string():
    import io

    sio = import_string("io.StringIO")
    assert isinstance(sio, type)
    sio = sio()
    assert isinstance(sio, io.StringIO)

# Generated at 2022-06-12 09:03:49.127245
# Unit test for function import_string
def test_import_string():
    from web.http import HttpRequest
    assert import_string("web.http.HttpRequest") == HttpRequest
    assert type(import_string("web.http.HttpRequest")) == type
    assert import_string("web.http.HttpRequest").__name__ == "HttpRequest"
    assert isinstance(import_string("web.http.HttpRequest"), HttpRequest)
    assert not ismodule(import_string("web.http.HttpRequest"))

# Generated at 2022-06-12 09:03:51.909487
# Unit test for function import_string
def test_import_string():
    from trio_http.server.router import Router
    from trio_http.server.static import Static

    assert import_string("trio_http.server.router.Router") == Router
    assert isinstance(import_string("trio_http.server.static.Static"), Static)

# Generated at 2022-06-12 09:03:58.601665
# Unit test for function import_string
def test_import_string():
    """
    Unit test for function import_string
    """
    from napps.kytos.napps.of_core.utils import import_string as import_string
    # module with a class
    module_name = "napps.kytos.napps.of_core.v0x05.base.event.EventBase"
    module = import_string(module_name)
    assert module.__name__ == "napps.kytos.napps.of_core.v0x05.base.event"
    assert module.EventBase.__name__ == "EventBase"

    # module without a class
    module_name = "napps.kytos.napps.of_core.v0x05.switch.switch_03"
    module_03 = import_string(module_name)
    assert module_

# Generated at 2022-06-12 09:04:01.634333
# Unit test for function import_string
def test_import_string():
    """
    This function serves as unit test for function import_string

    """
    assert import_string("test_http.test_import_string")
    assert import_string("test_http.test_import_string")()

# Generated at 2022-06-12 09:04:04.999128
# Unit test for function import_string
def test_import_string():
    from pprint import pprint
    from . import encoder

    pprint(encoder.__dict__)
    http_encoder = import_string(
        "httpcore.encoder.HTTPEncoder")
    assert http_encoder.__class__.__name__ == "HTTPEncoder"



# Generated at 2022-06-12 09:04:07.893222
# Unit test for function import_string
def test_import_string():
    import uvicorn.protocols.http.wsgi

    module = import_string("uvicorn.protocols.http.wsgi")
    assert ismodule(module)
    assert module == uvicorn.protocols.http.wsgi


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 09:04:11.009948
# Unit test for function import_string
def test_import_string():
    """Asserts that import_string works as expected."""
    from . import auth
    from .auth import basic

    assert import_string("aiohttp.auth") == auth
    assert import_string("aiohttp.auth.basic") == basic
    assert import_string("aiohttp.auth:basic") == auth.basic

# Generated at 2022-06-12 09:04:15.740593
# Unit test for function import_string
def test_import_string():
    assert import_string("asgi_socks.http.http_0_9") == import_module("asgi_socks.http.http_0_9")
    assert import_string("asgi_socks.http.http_1_0") == import_module("asgi_socks.http.http_1_0")
    assert import_string("asgi_socks.http.http_1_1") == import_module("asgi_socks.http.http_1_1")
    assert import_string("asgi_socks.http.http_2_0") == import_module("asgi_socks.http.http_2_0")

# Generated at 2022-06-12 09:04:29.105436
# Unit test for function import_string
def test_import_string():
    from . import router
    # Tests import_string function
    assert import_string("duap.router.Router") == router.Router
    assert import_string("duap.router.Router").__class__.__name__ == "Router"

# Doctest for function import_string

# Generated at 2022-06-12 09:04:32.906550
# Unit test for function import_string
def test_import_string():
    from types import ModuleType
    from tormysql import ConnectionPool
    assert isinstance(import_string('tormysql.ConnectionPool'), ConnectionPool)
    assert isinstance(import_string('tormysql'), ModuleType)

# Generated at 2022-06-12 09:04:36.060255
# Unit test for function import_string
def test_import_string():
    import copy
    import pytest
    from starlette.middleware.sessions import SessionMiddleware

    assert import_string("copy.copy") is copy.copy
    assert type(import_string("starlette.middleware.sessions.SessionMiddleware")) is SessionMiddleware

# Generated at 2022-06-12 09:04:39.526485
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function.
    """
    mod = import_string("tests.test_httputils.Mock")
    assert mod.__name__ == "Mock"

    obj = import_string("tests.test_httputils.Mock.MockClass")
    assert obj.__class__.__name__ == "MockClass"

# Generated at 2022-06-12 09:04:42.215533
# Unit test for function import_string
def test_import_string():
    from .http_utils import HeadersParser
    assert import_string(".http_utils.HeadersParser") is HeadersParser
    assert isinstance(import_string(".http_utils.HeadersParser"), HeadersParser)
    assert import_string("redis.StrictRedis")

# Generated at 2022-06-12 09:04:43.912115
# Unit test for function import_string
def test_import_string():
    import hiku.types
    import hiku.util
    assert import_string('hiku.types') == hiku.types
    assert import_string('hiku.util.import_string') == import_string

# Generated at 2022-06-12 09:04:48.856559
# Unit test for function import_string
def test_import_string():

    class A():

        def __init__(self):
            self.a = 1

        def func(self):
            return self.a * 10

    m = import_string("http.http_core.A")
    assert m.func() == 10
    assert m.a == 1

    m = import_string("http.http_core")
    assert m.__name__ == "http.http_core"



# Generated at 2022-06-12 09:04:52.814893
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function.
    """
    import json
    assert import_string("json") == json
    from . import http
    assert import_string("aiohttp.protocol.http") == http
    # test with a class
    from .http_writer import StreamWriter
    assert isinstance(import_string("aiohttp.protocol.http_writer.StreamWriter"), StreamWriter)

# Generated at 2022-06-12 09:04:54.205524
# Unit test for function import_string
def test_import_string():
    pass
#    assert import_string("tests.unit.http.http.test_import_string")

# Generated at 2022-06-12 09:05:00.177593
# Unit test for function import_string
def test_import_string():
    # Test normal import
    module = import_string('http.server')
    assert module.__name__ == 'http.server'

    # Test import of class
    from http.server import HTTPServer
    assert isinstance(import_string('http.server.HTTPServer'), HTTPServer)

    # Test import of object
    from http.server import HTTPServer
    assert isinstance(import_string('http.server.HTTPServer()'), HTTPServer)

    # Test import of class and object
    from http.server import HTTPServer
    assert isinstance(import_string('http.server.HTTPServer.HTTPServer()'), HTTPServer)