

# Generated at 2022-06-12 08:59:06.149636
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string
    """
    sys = import_string("sys.version_info")
    assert ismodule(sys)
    assert sys.__name__ == "sys.version_info"
    io = import_string("io.StringIO")
    assert io.__class__.__name__ == "StringIO"

# Generated at 2022-06-12 08:59:06.929015
# Unit test for function import_string
def test_import_string():
    pass

# Generated at 2022-06-12 08:59:11.001252
# Unit test for function import_string
def test_import_string():
    import sys
    sys.path.append('.')
    from server import Application

    module = import_string('server.Application')
    app = Application()
    assert module is app.__class__

# Generated at 2022-06-12 08:59:20.095706
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    h = {
        "content-length": 200,
        "content-md5": "fdsfds",
        "content-location": "http://fdsfds",
        "content-encoding": "gzip",
        "expires": "now",
        "server": "http4k",
    }
    h2 = remove_entity_headers(h)
    assert h2 == {
        "content-location": "http://fdsfds",
        "expires": "now",
        "server": "http4k",
    }
    h3 = remove_entity_headers(h, allowed=("content-location",))
    assert h3 == {"content-location": "http://fdsfds", "server": "http4k"}

# Generated at 2022-06-12 08:59:26.895784
# Unit test for function import_string
def test_import_string():
    from .responder import MockResponder
    from .request import MockRequest
    from .router import Router
    obj = import_string("falcon_multipart.responder.MockResponder")
    assert isinstance(obj, MockResponder)
    obj = import_string("falcon_multipart.request.MockRequest")
    assert isinstance(obj, MockRequest)
    obj = import_string("falcon_multipart.router.Router")
    assert isinstance(obj, Router)

# Generated at 2022-06-12 08:59:37.174727
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100)
    assert has_message_body(200)
    assert has_message_body(400)
    assert has_message_body(500)
    assert not has_message_body(1)
    assert not has_message_body(101)
    assert not has_message_body(200)
    assert not has_message_body(203)
    assert not has_message_body(300)
    assert not has_message_body(304)
    assert not has_message_body(305)
    assert not has_message_body(311)
    assert not has_message_body(403)
    assert not has_message_body(404)
    assert not has_message_body(500)

# Generated at 2022-06-12 08:59:41.889498
# Unit test for function import_string
def test_import_string():

    module_name = "django.http.request"
    obj = import_string(module_name)
    assert obj.__name__ == "django.http.request"
    assert type(obj.HttpRequest) == type
    assert type(obj.HttpRequest()) == obj.HttpRequest

    module_name = "django.http.request.HttpRequest"
    obj = import_string(module_name)
    assert type(obj) == obj.HttpRequest
    assert type(obj) == type(obj.HttpRequest())

# Generated at 2022-06-12 08:59:51.653347
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers_test = {
        "Connection": "Upgrade",
        "Content-Type": "text/html",
        "Content-Location": "index.html",
    }
    assert remove_entity_headers(headers_test) == {"Connection": "Upgrade"}
    assert remove_entity_headers(headers_test, allowed=["expires"]) == {
        "Connection": "Upgrade"
    }
    assert remove_entity_headers(headers_test, allowed=["content-location"]) == {
        "Connection": "Upgrade",
        "Content-Location": "index.html",
    }
    assert remove_entity_headers(headers_test, allowed=["expires", "content-location"]) == {
        "Connection": "Upgrade",
        "Content-Location": "index.html",
    }

# Generated at 2022-06-12 08:59:57.635866
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Location": "", "Expires": "", "Content-Length": ""}
    headers_allowed = remove_entity_headers(headers, allowed=("content-location", "expires"))
    assert headers == headers_allowed
    headers = {"Content-Location": "", "Content-Length": ""}
    headers = remove_entity_headers(headers)
    assert "content-length" not in headers.keys()
    assert "content-location" in headers.keys()

# Generated at 2022-06-12 09:00:00.192821
# Unit test for function import_string
def test_import_string():
    a = import_string("simple.simple")
    assert not a.a
    a = import_string("simple.simple.A")
    assert isinstance(a, type)

# Generated at 2022-06-12 09:00:03.981147
# Unit test for function import_string
def test_import_string():
    import this

    from . import hello

    assert import_string("this") == this
    assert import_string("hypercorn.url") == hello.UrlWrap

# Generated at 2022-06-12 09:00:12.133494
# Unit test for function import_string
def test_import_string():
    class Base:
        def __init__(self): pass

    class MyClass(Base):
        def __init__(self): pass

    # import a module
    assert import_string("tests.test_http.test_import_string") == test_import_string

    # import parent module
    assert import_string("tests.test_http.test_import_string", package="tests") == test_import_string
    assert import_string("tests.test_http", package="tests") == test_import_string
    assert import_string("tests", package="tests") == test_import_string

    # import class
    assert import_string("tests.test_http.test_import_string.MyClass") == MyClass
    assert import_string("tests.test_http.test_import_string", package="tests").MyClass == MyClass



# Generated at 2022-06-12 09:00:21.730557
# Unit test for function import_string
def test_import_string():
    from unittest import TestCase, main

    class Dummy:
        pass

    class DummyTest(TestCase):
        def setUp(self):
            self.obj = Dummy()
            self.mod_name = "tests.test_http.test_import_string.Dummy"
            self.path_module = "tests.test_http"

        def test_import_module(self):
            mod = import_string(self.path_module)
            self.assertTrue(mod.test_import_string)

        def test_import_class(self):
            obj = import_string(self.mod_name)
            self.assertEquals(self.obj.__class__, obj.__class__)

    main()

# Generated at 2022-06-12 09:00:32.445947
# Unit test for function import_string
def test_import_string():
    from tempfile import mkdtemp
    from os import path, makedirs
    from shutil import rmtree
    import sys

    import_string("six")
    try:
        import_string("fake_six")
    except ModuleNotFoundError as e:
        assert str(e) == 'No module named "fake_six"'
    else:
        assert False, "Should raise ModuleNotFoundError"

    import_string("test_util.test_import_string")

    tmp_dir = mkdtemp()

# Generated at 2022-06-12 09:00:36.991544
# Unit test for function import_string
def test_import_string():
    res = import_string('pydantic.schema')
    assert res.__name__ == 'pydantic.schema'
    res = import_string('pydantic.schema.SchemaModel')
    assert res.__name__ == 'SchemaModel'

# Generated at 2022-06-12 09:00:39.339419
# Unit test for function import_string
def test_import_string():
    assert import_string("tests.test_utils.TestHTTPBasics")
    assert import_string("tests.test_utils")



# Generated at 2022-06-12 09:00:41.050793
# Unit test for function import_string
def test_import_string():
    from .middleware import RequestTimeMiddleware  # noqa

# Generated at 2022-06-12 09:00:44.549421
# Unit test for function import_string
def test_import_string():
    from phanterpwa.tools.constants import PWA_CONFIG_APPLICATION
    assert import_string(PWA_CONFIG_APPLICATION)
    assert import_string(PWA_CONFIG_APPLICATION).__name__ == "phanterpwa-test-project"

# Generated at 2022-06-12 09:00:48.485546
# Unit test for function import_string
def test_import_string():
    from .utils import get_logger

    assert get_logger == import_string("uvicorn.config.utils.get_logger")
    assert ismodule(import_string("uvicorn.config.utils"))
    assert not ismodule(import_string("uvicorn.logging.Logger"))



# Generated at 2022-06-12 09:00:53.257140
# Unit test for function import_string
def test_import_string():
    """
    Simple test to function import_string
    """
    from importlib import reload
    from . import app

    reload(app)

    assert import_string("http.app") == app.App
    assert import_string("http.server") == app.server



# Generated at 2022-06-12 09:00:57.169884
# Unit test for function import_string
def test_import_string():
    assert import_string("math") is math
    assert import_string("math.cos") is math.cos
    assert import_string("httptools.HttpResponseParser") is httptools.HttpResponseParser

# Generated at 2022-06-12 09:01:04.868821
# Unit test for function import_string
def test_import_string():
    from .http import HTTPStatus, HTTP

    assert HTTP is import_string("http.HTTP")
    assert HTTPStatus is import_string("http.base.HTTPStatus")

    from .plugins import CORS, Compression

    assert CORS is import_string("http.plugins.CORS")
    assert Compression is import_string("http.plugins.Compression")
    assert isinstance(CORS(), import_string("http.plugins.CORS"))
    assert isinstance(Compression(), import_string("http.plugins.Compression"))


# Generated at 2022-06-12 09:01:07.855035
# Unit test for function import_string
def test_import_string():

    import_string_test = import_string('test_http.test_import_string', None)
    assert callable(import_string_test)
    assert import_string_test() == 'import_string'

if __name__ == '__main__':
    test_import_string()

# Generated at 2022-06-12 09:01:15.496871
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string
    """
    from .middleware.middleware import RequestMiddleware
    from .middleware.middleware import ResponseMiddleware
    module = import_string(module_name='asab.web.middleware.middleware')
    assert ismodule(module)

    obj = import_string(module_name='asab.web.middleware.middleware.RequestMiddleware')
    assert isinstance(obj, RequestMiddleware)

    obj = import_string(module_name='asab.web.middleware.middleware.ResponseMiddleware')
    assert isinstance(obj, ResponseMiddleware)

# Generated at 2022-06-12 09:01:23.055361
# Unit test for function import_string
def test_import_string():
    from . import views
    from . import views as views2

    assert import_string("http.views") is import_string("http.views")
    assert import_string("http.views") is views
    assert import_string("http.views") is views2

    from . import views
    from . import views as views2

    assert import_string("http.views.index") is import_string("http.views.index")
    assert import_string("http.views.index") is views.index
    assert import_string("http.views.index") is views2.index



# Generated at 2022-06-12 09:01:30.004182
# Unit test for function import_string
def test_import_string():
    module = import_string("os.path")
    assert module.abspath("/tmp") == "/tmp"
    module = import_string("os.path.abspath", package=None)
    assert module("/tmp") == "/tmp"
    module = import_string("os.path.exists", package=None)
    assert module("/tmp") is True
    module = import_string("os.path.isfile", package=None)
    assert module("/tmp") is False
    module = import_string("websauna.tests.test_http.test_import_string", package=None)
    assert module() is None



# Generated at 2022-06-12 09:01:33.246770
# Unit test for function import_string
def test_import_string():
    obj = import_string("tests.test_http.test_import_string")
    assert obj.__name__ == 'test_import_string'
    obj = import_string("tests.test_http.TestWatcher")
    assert obj.__class__.__name__ == "TestWatcher"

# Generated at 2022-06-12 09:01:38.959917
# Unit test for function import_string
def test_import_string():
    from math import isnan
    from cgi import FieldStorage
    from http import cookies

    assert import_string("math.isnan", package="math") == isnan
    assert import_string("cgi.FieldStorage", package="cgi") == FieldStorage
    assert import_string("http.cookies", package="http") == cookies
    assert import_string("http.cookies.SimpleCookie", package="http")()
    assert import_string("http.HTTPStatus", package="http").OK == 200

# Generated at 2022-06-12 09:01:43.976157
# Unit test for function import_string
def test_import_string():
    simple = import_string("mock.hello")
    assert simple.mock() == "Hello"

    simple_package = import_string("mock.hello", package=__name__)
    assert simple_package.mock() == "Hello"

    hello = import_string("mock.hello.Hello")
    assert hello.mock() == "Hello"

    hello_package = import_string("mock.hello.Hello", package=__name__)
    assert hello_package.mock() == "Hello"

# Generated at 2022-06-12 09:01:49.389109
# Unit test for function import_string
def test_import_string():
    import_string_test = "asyncio.BaseEventLoop"
    assert import_string(import_string_test) == import_module(import_string_test)
    import_string_test = "asyncio.Future"
    assert isinstance(import_string(import_string_test), import_module(import_string_test).Future)