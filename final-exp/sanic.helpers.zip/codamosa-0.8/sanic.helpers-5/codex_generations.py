

# Generated at 2022-06-12 08:59:13.876363
# Unit test for function import_string
def test_import_string():
    from urllib.parse import parse_qsl
    from http.cookies import SimpleCookie
    
    obj_a = import_string('urllib.parse.parse_qsl')
    assert obj_a == parse_qsl
    obj_b = import_string('http.cookies.SimpleCookie')
    assert isinstance(obj_b, SimpleCookie)
    obj_c = import_string('datetime.datetime')
    assert isinstance(obj_c, datetime.datetime)

# Generated at 2022-06-12 08:59:23.546293
# Unit test for function remove_entity_headers

# Generated at 2022-06-12 08:59:35.169737
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "ETag": "798a580",
        "Content-Location": "/index.htm",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Date": "Tue, 15 Nov 1994 08:12:31 GMT",
        "Last-Modified": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Server": "Apache/2.4.1 (Unix)",
        "Accept-Ranges": "bytes",
        "Content-Length": "111",
        "Keep-Alive": "timeout=5, max=100",
        "Connection": "Keep-Alive",
        "Content-Type": "text/html",
        "Age": "12"
    }
    res = remove_entity_headers(headers, allowed=("Expires"))

# Generated at 2022-06-12 08:59:39.256881
# Unit test for function import_string
def test_import_string():
    from pyserver.http import Request, Response
    from pyserver.socket import Socket
    from pyserver.basic import BaseHandler
    from pyserver.core import Handler

    assert(import_string("pyserver.http.Request") == Request)
    assert(import_string("pyserver.http.Response") == Response)
    assert(import_string("pyserver.socket.Socket") == Socket)
    assert(import_string("pyserver.basic.BaseHandler") == BaseHandler)
    assert(import_string("pyserver.core.Handler") == Handler)




# Generated at 2022-06-12 08:59:42.696953
# Unit test for function import_string
def test_import_string():
    path_to_module = 'aiohttp.web_reqrep'
    request_module = 'aiohttp.web_request.Request'
    from aiohttp.web_reqrep import StreamResponse
    from aiohttp.web_request import Request
    assert StreamResponse == import_string(path_to_module)
    assert Request == import_string(request_module)


# Generated at 2022-06-12 08:59:53.035052
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    allowed = ('content-location','expires')

    headers = {'content-location': 'http://localhost',
                'expires': 'Fri, 01 Jan 1990 00:00:00 GMT'}
    headers_test = remove_entity_headers(headers, allowed)
    assert headers_test == headers

    headers = {'content-location': 'http://localhost',
                'expires': 'Fri, 01 Jan 1990 00:00:00 GMT',
                'content-type': 'text/html'}
    headers_test = remove_entity_headers(headers, allowed)
    # assert headers_test == {'content-location': 'http://localhost', 'expires': 'Fri, 01 Jan 1990 00:00:00 GMT'}
    assert headers_test == headers


# Generated at 2022-06-12 09:00:04.028740
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "application/json",
        "Keep-Alive": "timeout=5, max=100",
        "Connection": "Keep-Alive",
        "Date": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Server": "Apache/2.4.12 (Ubuntu)",
        "Content-Length": "88",
        "Content-Location": "path/to/resource"
    }
    headers = remove_entity_headers(headers)

# Generated at 2022-06-12 09:00:07.877477
# Unit test for function import_string
def test_import_string():
    class Example(object):
        pass

    assert import_string("mockup.http.basics.test_import_string.Example")
    assert isinstance(
        import_string("mockup.http.basics.test_import_string.Example"), Example
    )
    assert import_string("mockup.http.basics") == basics

# Generated at 2022-06-12 09:00:14.239544
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "host": "localhost:8080",
        "content-type": "text/html; charset=utf-8",
        "content-length": "14",
        "content-location": "http://google.com/",
    }
    filtered_headers = {
        "host": "localhost:8080",
        "content-location": "http://google.com/",
    }
    assert remove_entity_headers(headers) == filtered_headers

# Generated at 2022-06-12 09:00:23.557819
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string.
    """
    import pytest
    from importlib import reload
    import __main__
    from .fixtures import basic

    # Instance from class
    object_ = import_string("sanic.response.HTTPResponse")
    assert isinstance(object_, basic.HTTPResponse)

    # Module
    object_ = import_string("sanic.response")
    assert isinstance(object_, basic.response)

    # Module with class
    object_ = import_string("sanic.response.HTTPResponse")
    assert object_ == basic.HTTPResponse

    # Module with class
    object_ = import_string("sanic.response.HTTPResponse", package="__main__")
    assert object_ == basic.HTTPResponse



# Generated at 2022-06-12 09:00:31.895386
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(100)
    assert has_message_body(500)

# Generated at 2022-06-12 09:00:35.739117
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(204)
    assert has_message_body(200)
    assert has_message_body(404)
    assert has_message_body(301)

# Generated at 2022-06-12 09:00:46.066377
# Unit test for function has_message_body
def test_has_message_body():
    """Test function has_message_body.
    Check if http status codes with and without message body
    are properly identified.

    """
    # These should be identified as having no message body
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)

    # These should be identifed as having message body
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(205)
    assert has

# Generated at 2022-06-12 09:00:56.295031
# Unit test for function has_message_body
def test_has_message_body():
    import pytest


# Generated at 2022-06-12 09:01:05.431925
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(204) == False
    assert has_message_body(300) == True
    assert has_message_body(301) == True
    assert has_message_body(304) == False
    assert has_message_body(400) == True
    assert has_message_body(500) == True

# Generated at 2022-06-12 09:01:07.482412
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(201)
    assert not has_message_body(204)
    assert not has_message_body(304)



# Generated at 2022-06-12 09:01:12.076187
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) is False
    assert has_message_body(199) is False
    assert has_message_body(200) is True
    assert has_message_body(204) is False
    assert has_message_body(300) is True
    assert has_message_body(400) is True



# Generated at 2022-06-12 09:01:18.710641
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(300) == True
    assert has_message_body(304) == False
    assert has_message_body(400) == True
    assert has_message_body(404) == True
    assert has_message_body(500) == True
    assert has_message_body(650) == True

# Generated at 2022-06-12 09:01:23.813001
# Unit test for function has_message_body
def test_has_message_body():
    message_status = [200, 201, 401, 401, 404, 500, 503]
    for status in message_status:
        assert has_message_body(status) is True

    no_message_status = [100, 101, 302, 304, 204]
    for status in no_message_status:
        assert has_message_body(status) is False



# Generated at 2022-06-12 09:01:25.045297
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
