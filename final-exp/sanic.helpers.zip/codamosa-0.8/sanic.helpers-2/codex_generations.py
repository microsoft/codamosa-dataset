

# Generated at 2022-06-12 08:59:09.856302
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("aiohttp.http")
    assert http.server == import_string("aiohttp.http.server")
    assert isinstance(import_string("aiohttp.web", "aiohttp"), object)
    assert isinstance(import_string("aiohttp.web.Application"), object)

# Generated at 2022-06-12 08:59:12.941172
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)



# Generated at 2022-06-12 08:59:15.852607
# Unit test for function import_string
def test_import_string():
    import yhttp.status as status

    assert import_string("yhttp.status") == status
    assert import_string("yhttp.status.StatusResponse") == status.StatusResponse


# Generated at 2022-06-12 08:59:25.744123
# Unit test for function import_string
def test_import_string():
    """
    Unit test for :func:`import_string`
    """
    import types
    from xotl.tools.context import import_from
    from xotl.tools.future.strings import Literal

    assert isinstance(import_string("os.path"), types.ModuleType)
    with Literal.from_string as import_from:
        assert isinstance(import_string("os.path"), types.ModuleType)
    with Literal.from_bytes as import_from:
        assert isinstance(import_string("os.path"), types.ModuleType)
    assert isinstance(import_string("xotl.tools.context.import_from", "xotl.tools"), import_from)

# Generated at 2022-06-12 08:59:33.570537
# Unit test for function import_string
def test_import_string():
    class TestClass():
        def test_method(self):
            return "test_method"

    from uvicorn.protocols.http.http11 import HTTPProtocol

    class_ = import_string("uvicorn.protocols.http.http11.HTTPProtocol")
    assert class_ == HTTPProtocol
    assert import_string("uvicorn.protocols.http.http11") == HTTPProtocol.__module__

    import_string("uvicorn.protocols.http.http11")

    class_ = import_string("uvicorn.protocols.http.http11.HttpProtocol.test_method")
    assert class_.test_method() == "test_method"

    import_string("uvicorn.test_string.test_string.TestClass")

# Generated at 2022-06-12 08:59:37.486776
# Unit test for function import_string
def test_import_string():
    from .response import Response
    assert import_string("http.response.Response") == Response
    assert import_string("http.response.Response").__class__ == Response
    assert import_string("http.response.Response")() == Response()



# Generated at 2022-06-12 08:59:40.889721
# Unit test for function import_string
def test_import_string():
    from importlib import import_module
    import_string = import_string
    assert issubclass(import_string("collections.abc.Sequence"), list)
    assert isinstance(import_string("collections.UserDict"), dict)
    assert import_module("collections.abc.Sequence") == import_string("collections.abc.Sequence")

# Generated at 2022-06-12 08:59:52.069937
# Unit test for function import_string
def test_import_string():
    import pathlib
    import importlib.util
    import sys

    # load a module with a class inside

    path = pathlib.Path(__file__).parent / "test_import_string.py"
    spec = importlib.util.spec_from_file_location("test_module", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)

    # import class
    klass = import_string("test_import_string.TestClass")
    assert klass.__class__.__name__ == "TestClass"
    assert klass.attr == 10

    # import module
    mod = import_string("test_import_string")
    assert mod.__name__ == "test_import_string"

# Generated at 2022-06-12 08:59:57.252283
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(399)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(199)
    assert not has_message_body(100)
    assert not has_message_body(200)
    assert not has_message_body(102)

# unit tests for function remove_entity_headers

# Generated at 2022-06-12 09:00:07.650011
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """Unit test for function remove_entity_headers."""
    # example 1
    example_1 = {"header-1": "value1", "header-2": "value2"}
    assert remove_entity_headers(example_1) == {"header-1": "value1", "header-2": "value2"}

    # example 2
    example_2 = {
        "header-1": "value1",
        "header-2": "value2",
        "content-md5": "md5hash",
        "content-length": "12",
    }
    assert remove_entity_headers(example_2) == {
        "header-1": "value1",
        "header-2": "value2",
    }

    # example 3

# Generated at 2022-06-12 09:00:19.100436
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    hd = {"connection": "keep-alive", "Content-Length": 234}
    rhd = remove_entity_headers(hd)
    assert rhd == {"connection": "keep-alive"}
    rhd = remove_entity_headers(hd, allowed=["connection"])
    assert rhd == {"connection": "keep-alive"}
    rhd = remove_entity_headers(hd, allowed=["Content-Length"])
    assert rhd == {"connection": "keep-alive", "Content-Length": 234}
    rhd = remove_entity_headers(hd, allowed=["Content-Length", "connection"])
    assert rhd == {"connection": "keep-alive", "Content-Length": 234}

# Generated at 2022-06-12 09:00:26.474313
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """Test the function remove_entity_headers."""
    headers = {"Content-length": "1", "Content-Location": "2", "C": "3"}
    assert remove_entity_headers(headers) == {"Content-Location": "2", "C": "3"}
    headers = {
        "Content-length": "1",
        "Expiration": "2",
        "Content-Location": "2",
        "C": "3",
    }
    assert remove_entity_headers(headers) == {
        "Expiration": "2",
        "Content-Location": "2",
        "C": "3",
    }

# Generated at 2022-06-12 09:00:37.810104
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    hdrs = {
        "Allow": "GET,HEAD,OPTIONS",
        "Content-Language": "en",
        "Content-Length": 25,
        "Content-Location": "http://localhost:5010/index.html",
        "Content-MD5": "test",
        "Content-Range": "test",
        "Content-Type": "test",
        "Expires": "Fri, 01 Dec 2017 16:00:00 GMT",
        "Last-Modified": "Fri, 01 Dec 2017 16:00:00 GMT",
        "Extension-Header": "Extension-Header",
    }

# Generated at 2022-06-12 09:00:47.223347
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-type": "text/plain", "Content-Length": "0"}
    assert remove_entity_headers(headers) == headers

    headers = {"Content-Range": "0/60", "Content-Length": "0"}
    assert remove_entity_headers(headers) == {"Content-Length": "0"}

    headers = {"Content-type": "text/plain", "Expires": "now"}
    assert remove_entity_headers(headers) == {"Expires": "now"}

    headers = {"Content-type": "text/plain", "Content-Length": "0", "Expires": "now"}
    assert remove_entity_headers(headers) == {"Expires": "now"}

    headers = {"Content-type": "text/plain", "Content-Length": "0", "Expires": "now"}
    assert remove_entity

# Generated at 2022-06-12 09:00:57.010820
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers(
        {"content-length": "1234"}
    ) == {"content-length": "1234"}
    assert remove_entity_headers({}) == {}
    assert remove_entity_headers({"allow": "GET"}) == {"allow": "GET"}
    assert remove_entity_headers({"content-location": "0"}) == {"content-location": "0"}
    assert remove_entity_headers(
        {"content-location": "0", "x-foo": "bar"}, allowed=("content-location",)
    ) == {"content-location": "0"}
    assert remove_entity_headers(
        {"expires": "never", "x-foo": "bar"}, allowed=("expires",)
    ) == {"expires": "never"}

# Generated at 2022-06-12 09:01:07.339960
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-length": "100",
        "Content-encoding": "utf-8",
        "Content-language": "en-us",
        "Content-Range": "test",
        "Content-Type": "text/html",
        "Expires": "Mon, 01 Jan 1990 00:00:00 GMT",
        "Last-Modified": "Tue, 11 Jul 2017 01:23:45 GMT",
        "Extension-Header": "ho",
    }
    headers = remove_entity_headers(headers)
    expected = {}
    assert headers == expected

# Generated at 2022-06-12 09:01:16.667087
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html; charset=utf-8",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Length": "348",
        "Content-Location": "index.htm",
        "Expires": "Tue, 01 Jan 2030 00:00:00 GMT",
        "Last-Modified": "Tue, 01 Jan 2019 00:00:00 GMT",
        "Extension-Headers": "some-value",
    }
    assert remove_entity_headers(headers) == {"Content-Location": "index.htm", "Expires": "Tue, 01 Jan 2030 00:00:00 GMT"}

# Generated at 2022-06-12 09:01:26.216975
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    Test the function remove_entity_headers
    """
    headers = {
        "CONTENT-LOCATION": "123",
        "CONTENT-LENGTH": "abc",
        "CONTENT-TYPE": "application/json",
        "ALLOW": "GET",
        "EXPIRES": "Tue, 18 Oct 2016 08:07:01 UTC",
        "content-MD5": "123",
        "transfer-encoding": "chunked",
        "content-range": "bytes 0-50",
        "connection": "keep-alive",
        "trailers": "",
        "etag": "1",
    }
    new_headers = remove_entity_headers(headers)

# Generated at 2022-06-12 09:01:31.417484
# Unit test for function remove_entity_headers
def test_remove_entity_headers():

    headers = {
        b"content-length": b"0",
        b"content-type": b"text/html; charset=utf-8",
        b"content-md5": b"20cd4d849f73a9e9b9d7eef098b34cce",
        b"content-location": b"index.html",
    }
    assert remove_entity_headers(headers) == {b"content-location": b"index.html"}


test_remove_entity_headers()

# Generated at 2022-06-12 09:01:33.712955
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({"allow": "GET"}, allowed=["allow"]) == {
        "allow": "GET"
    }

