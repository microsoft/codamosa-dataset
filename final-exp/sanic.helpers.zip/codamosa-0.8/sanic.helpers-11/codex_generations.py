

# Generated at 2022-06-12 08:59:11.912786
# Unit test for function import_string
def test_import_string():
    from sanic.server import HttpProtocol

    # import a module
    assert import_string("sanic.server") == HttpProtocol.__module__

    # import a class and instantiate
    from sanic.views import HTTPMethodView
    assert import_string("sanic.views.HTTPMethodView")() == HTTPMethodView()

# Generated at 2022-06-12 08:59:14.978031
# Unit test for function import_string
def test_import_string():
    """Test import_string function"""
    from shirka.http import Request
    assert Request.__class__ == import_string("shirka.http.request").__class__


# Generated at 2022-06-12 08:59:22.382252
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Encoding": "UTF-8",
        "Content-Language": "pt-br",
        "Content-Length": "99",
        "Content-Location": "http://localhost:8000/",
        "Content-Range": "bytes 0-49/99",
        "Content-Type": "text/html; charset=utf-8",
        "Expires": "Sat, 01 Jan 2000 00:00:00 GMT",
        "Last-Modified": "Thu, 01 Jan 1970 00:00:00 GMT",
    }
    expected = {
        "Content-Location": "http://localhost:8000/",
        "Expires": "Sat, 01 Jan 2000 00:00:00 GMT",
    }
    clean_headers = remove_entity_headers(headers)
    assert clean_headers == expected

# Generated at 2022-06-12 08:59:28.762402
# Unit test for function import_string
def test_import_string():
    import cookiecutter.tasks
    re = import_string(
        "cookiecutter.tasks.display_project"
    )
    expected = cookiecutter.tasks.display_project
    assert re == expected



# Generated at 2022-06-12 08:59:31.927075
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(301)
    assert has_message_body(404)
    assert has_message_body(500)
    assert not has_message_body(100)
    assert not has_message_body(204)
    assert not has_message_body(304)

# Generated at 2022-06-12 08:59:35.601208
# Unit test for function import_string
def test_import_string():
    from .test_http import MyMiddlewareClass, MyMiddlewareModule
    assert import_string("falcon.http.test_http.MyMiddlewareModule") == MyMiddlewareModule
    assert type(import_string("falcon.http.test_http.MyMiddlewareClass")) == MyMiddlewareClass


# Generated at 2022-06-12 08:59:37.486184
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(101)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(200)
    assert has_message_body(500)

# Generated at 2022-06-12 08:59:40.334437
# Unit test for function import_string
def test_import_string():

    module_name = "python.import_string"
    package = None

    assert import_string(module_name, package) is import_string

    module_name = "python.version.Version"
    package = "python"
    assert import_string(module_name, package) is Version

# Generated at 2022-06-12 08:59:50.429937
# Unit test for function import_string
def test_import_string():
    from .route import Route

    # Valid import
    obj = import_string("httptools.route.Route")
    assert obj is Route

    # Valid import and instanciate
    obj = import_string("httptools.route.Route", package="aiohttp")
    assert isinstance(obj, Route)

    # Invalid import
    import pytest
    with pytest.raises(ImportError):
        import_string("httptools.invalid.Route", package="aiohttp")

    # Invalid import and instanciate
    with pytest.raises(ImportError):
        import_string("httptools.route.InvalidClass", package="aiohttp")

# Generated at 2022-06-12 09:00:00.311015
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers(
        {"Content-type": "text/html", "Accept": "text/html"}
    ) == {"Accept": "text/html"}

    assert remove_entity_headers(
        {"Content-type": "text/html", "Accept": "text/html"}
    ) == {"Accept": "text/html"}

    assert remove_entity_headers(
        {"Content-type": "text/html", "Accept": "text/html"},
        allowed=("content-type",),
    ) == {"Accept": "text/html", "Content-type": "text/html"}
