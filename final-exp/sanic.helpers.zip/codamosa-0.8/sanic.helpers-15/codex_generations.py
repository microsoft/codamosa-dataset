

# Generated at 2022-06-12 08:59:12.298013
# Unit test for function import_string
def test_import_string():
    import sys
    import logging
    from starlette.background import BackgroundTask

    logger = import_string("logging.Logger")(__name__)
    sorteo = import_string("app.sorteo.Sorteo")()
    logger.debug(sorteo.do_sorteo())
    logger.debug(import_module('app.sorteo'))
    logger.debug(import_string('app.sorteo.Sorteo')().do_sorteo())
    logger.debug(import_string('app.sorteo.Sorteo').do_sorteo())
    logger.debug(BackgroundTask(logger_name=__name__))
    logger.debug(BackgroundTask(logger_name=__name__, logger_level=logging.DEBUG))

# Generated at 2022-06-12 08:59:19.036357
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({}) == {}

    assert remove_entity_headers({"Content-Type": "text/plain"}) == {}

    headers = {
        "content-length": 10,
        "content-type": "text/plain",
        "Content-Location": "http://example.com/foo/bar",
        "expires": 10,
    }
    expected = {
        "Content-Location": "http://example.com/foo/bar",
        "expires": 10,
    }
    assert remove_entity_headers(headers) == expected

# Generated at 2022-06-12 08:59:27.648906
# Unit test for function import_string
def test_import_string():
    class Cls(object):
        pass
    assert import_string(__name__ + ".Cls") is Cls
    assert import_string(__name__ + ".import_string") is import_string
    assert import_string(__name__ + ".Cls")() is not Cls()
    assert import_string(__name__ + ".Cls", __name__)() is not Cls()
    assert import_string(__name__ + ".Cls", "xxxxx")() is not Cls()
    assert import_string(__name__ + ".Cls", package=__name__)() is not Cls()


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 08:59:33.368432
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {b"CONTENT-length": b"0", b"last-modified": b"date"}
    assert remove_entity_headers(headers) == {b"last-modified": b"date"}
    assert remove_entity_headers(
        headers, allowed=("content-length",)
    ) == {b"CONTENT-length": b"0", b"last-modified": b"date"}
    assert remove_entity_headers(
        headers, allowed=("content-location",)
    ) == {b"CONTENT-length": b"0"}

# Generated at 2022-06-12 08:59:38.301311
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True
    assert has_message_body(404) == True
    assert has_message_body(204) == False


# Generated at 2022-06-12 08:59:43.560335
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """Test function remove_entity_headers"""
    dic = {
        "content-location": "www.location.com",
        "expires": "expires today",
        "content-length": "1234",
    }
    dic1 = {"content-location": "www.location.com", "expires": "expires today"}
    assert remove_entity_headers(dic) == dic1
    dic1 = {"content-location": "www.location.com"}
    assert remove_entity_headers(dic, allowed=("content-location",)) == dic1

# Generated at 2022-06-12 08:59:48.801369
# Unit test for function import_string
def test_import_string():
    from . import http11
    assert HTTP11Protocol == import_string('httpcore.http11.HTTP11Protocol')
    assert HTTP11Protocol == import_string('httpcore.HTTP11Protocol', package='httpcore')
    assert http11.HTTP11Protocol() == import_string('httpcore.http11.HTTP11Protocol', package='httpcore')


from .http11 import HTTP11Protocol

# Generated at 2022-06-12 08:59:55.257416
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers_dict = {'content-length': '1234',
                    'content-md5': 'md5',
                    'retry-after': '10'}
    headers_without_entity_headers = remove_entity_headers(headers_dict)
    assert 'content-length' not in headers_without_entity_headers
    assert 'content-md5' not in headers_without_entity_headers
    assert 'retry-after' in headers_without_entity_headers

# Generated at 2022-06-12 09:00:00.122464
# Unit test for function import_string
def test_import_string():
    import aiohttp

    # testing import with object that not is a class
    assert aiohttp == import_string("aiohttp")

    # testing import with class
    assert isinstance(import_string("aiohttp.web.Application"), aiohttp.web.Application)
    assert isinstance(import_string("aiohttp:web:Application"), aiohttp.web.Application)



# Generated at 2022-06-12 09:00:10.094103
# Unit test for function remove_entity_headers

# Generated at 2022-06-12 09:00:17.518265
# Unit test for function import_string
def test_import_string():
    from mach9 import Protocol11, Protocol12

    assert import_string("mach9.protocols.Protocol11") == Protocol11
    assert import_string("mach9.protocols.Protocol12") == Protocol12
    assert import_string("mach9.protocols.Protocol11")() == Protocol11()
    assert import_string("mach9.protocols.Protocol12")() == Protocol12()

# Generated at 2022-06-12 09:00:24.975330
# Unit test for function import_string
def test_import_string():
    """
    import_string function should return a module if given a module path
    or a class instance if given a path to class
    """
    from importlib import resources
    import core
    import core.server

    # if module_name is a string to module, it returns module
    assert import_string("core.server") == core.server

    # if module_name is a string to class, it returns module.class()
    assert isinstance(import_string("core.utils.Validator"),
                      core.utils.Validator)

    # if module_name is a string to class, it returns module.class()
    assert isinstance(import_string("core.resources.index"),
                      resources.path)

    assert isinstance(import_string("core.resources.index.index_html"),
                      resources.path)


# Generated at 2022-06-12 09:00:28.832990
# Unit test for function import_string
def test_import_string():
    from aiohttp import web
    module = import_string("aiohttp.web")
    assert(module == web)

    m = import_string("aiohttp.web.StreamResponse")
    assert(callable(m))
    assert(isinstance(m(), web.StreamResponse))

# Generated at 2022-06-12 09:00:40.272138
# Unit test for function import_string
def test_import_string():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import mkdir, remove
    from os.path import exists
    from jinja2 import Environment, FileSystemLoader
    from .template import TemplateEngine

    dir_tmp = mkdtemp(prefix="tmp_test_import_string")
    cur_dir = dir_tmp + "/"
    file_test = cur_dir + "test.html"
    file_test_2 = cur_dir + "test_2.html"

    def create_temp_file(file, content):
        with open(file, 'w') as fd:
            fd.write(content)


# Generated at 2022-06-12 09:00:44.509697
# Unit test for function import_string
def test_import_string():
    assert import_string("importlib.import_module") is import_module
    assert ismodule(
        import_string("importlib.import_module", package="aiohttp.server")
    )
    assert import_string("json.dumps")
    assert import_string("aiohttp.server.Server")



# Generated at 2022-06-12 09:00:47.357922
# Unit test for function import_string
def test_import_string():
    module_name = "uvicorn.loops.auto"
    module = import_string(module_name)
    assert module.__name__ == "uvicorn.loops.auto"



# Generated at 2022-06-12 09:00:53.599348
# Unit test for function import_string
def test_import_string():
    from .test_app import app

    assert import_string("falcon.asgi.test_app.app") == app
    assert import_string("falcon.asgi.test_app.app")() == app()
    assert import_string("falcon.asgi.test_app.app")()() == app()()
    assert import_string("django.contrib.sessions.backends.db.SessionStore")

# Generated at 2022-06-12 09:00:57.044133
# Unit test for function import_string
def test_import_string():
    class Test:
        pass

    import_string("http.server")
    assert import_string("http.server") is import_module("http.server")

    assert import_string("http.server.Test") is import_string("http.server.Test")
    assert isinstance(import_string("http.server.Test"), Test)

# Generated at 2022-06-12 09:01:03.250257
# Unit test for function import_string
def test_import_string():
    module = import_string("h2.events")
    from h2.events import RequestReceived
    assert RequestReceived is module.RequestReceived

    codec = import_string("h2.codec.base64_decoder.Base64Decoder")
    from h2.codec.base64_decoder import Base64Decoder
    assert codec is Base64Decoder
    assert isinstance(codec, Base64Decoder)

# Generated at 2022-06-12 09:01:07.518886
# Unit test for function import_string
def test_import_string():
    from types import ModuleType
    from hamlish_jinja import HamlishExtension
    hamlish = import_string('hamlish_jinja.HamlishExtension')
    assert isinstance(hamlish, ModuleType)
    hamlish = import_string('hamlish_jinja.HamlishExtension:HamlishExtension')
    assert isinstance(hamlish, HamlishExtension)