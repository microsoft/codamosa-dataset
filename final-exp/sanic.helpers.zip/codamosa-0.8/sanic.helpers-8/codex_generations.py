

# Generated at 2022-06-12 08:59:02.149348
# Unit test for function import_string
def test_import_string():
    from http.cookies import SimpleCookie
    obj_cookie = import_string("http.cookies.SimpleCookie")
    assert isinstance(obj_cookie, SimpleCookie)
    assert type(obj_cookie) == type(SimpleCookie())
    assert id(obj_cookie) != id(SimpleCookie())



# Generated at 2022-06-12 08:59:03.983302
# Unit test for function import_string
def test_import_string():
    module = import_string("socket")
    assert ismodule(module)
    assert module.__name__ == "socket"
    assert hasattr(module, "socket")


# Generated at 2022-06-12 08:59:07.556367
# Unit test for function import_string
def test_import_string():
    from uvicorn.main import Config as config

    assert import_string("uvicorn.main.Config") == config
    assert import_string("uvicorn.main.Config", package="uvicorn") == config
    assert import_string("uvicorn.main.Config").__class__ == config
    assert import_string("uvicorn.main.Config", package="uvicorn").__class__ == config

# Generated at 2022-06-12 08:59:10.238647
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True



# Generated at 2022-06-12 08:59:12.095985
# Unit test for function import_string
def test_import_string():
    from app.config import Config

    config = import_string('app.config.Config')
    assert config is Config, config


if __name__ == "__main__":
    # Unit test for import_string
    test_import_string()

# Generated at 2022-06-12 08:59:18.589519
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "application/json",
        "Content-Length": 123,
        "Content-Location": "/static/image.png",
        "Last-Modified": "Sat, 29 Oct 1994 19:43:31 GMT",
        "Extension-Header": "foobar",
    }
    headers = remove_entity_headers(headers, allowed=["content-location"])
    assert set(headers) == {
        "content-location",
        "last-modified",
        "extension-header",
    }

# Generated at 2022-06-12 08:59:20.836179
# Unit test for function import_string
def test_import_string():
    """
    Assert import string loads module and a class
    """
    import inspect
    assert inspect.ismodule(import_string("http.server"))
    assert isinstance(import_string("http.server.BaseHTTPRequestHandler"), object)


# Generated at 2022-06-12 08:59:24.617918
# Unit test for function import_string
def test_import_string():
    import test_http as test_module
    assert import_string("test_http.test_module") is test_module
    obj = import_string("test_http.TestClass")
    assert isinstance(obj, test_module.TestClass)
    assert obj.value == "foo"

# Generated at 2022-06-12 08:59:32.807925
# Unit test for function import_string
def test_import_string():
    from .detectors import BasicDetector
    from .contrib import json_translator
    from .contrib import form_translator

    detector = import_string("transfugio.detectors.BasicDetector")
    assert BasicDetector == detector

    json_translator_ = import_string("transfugio.contrib.json_translator")
    assert json_translator_ == json_translator

    form_translator_ = import_string("transfugio.contrib.form_translator")
    assert form_translator_ == form_translator

# Generated at 2022-06-12 08:59:39.614387
# Unit test for function import_string
def test_import_string():
    import sys
    import importlib
    if sys.version_info[:2] < (3, 5):
        importlib.reload = importlib.reload
    import_string('test.test_http.test_import_string')
    from .test_import_string import test_import_string
    assert test_import_string() == 'test ok'
    import_string('test.test_http:test_import_string')
    assert test_import_string() == 'test ok'
    import_string('test.test_http.test_import_string:test_import_string')
    assert test_import_string() == 'test ok'

# Itertools: cycle

# Generated at 2022-06-12 08:59:48.843101
# Unit test for function import_string
def test_import_string():
    """Testing import_string function with good parameters."""
    assert (import_string('wsgi.http.HTTPStatus').CONTINUE == 100)
    assert (import_string('wsgi.http.HTTPStatus').OK == 200)
    assert (import_string('wsgi.http.HTTPStatus').INTERNAL_SERVER_ERROR == 500)
    assert (import_string('wsgi.http.HTTPStatus').NETWORK_AUTHENTICATION_REQUIRED == 511)



# Generated at 2022-06-12 08:59:52.246902
# Unit test for function import_string
def test_import_string():
    from . import hello
    from .hello import HelloApp

    assert import_string("hello.hello") == hello
    assert import_string("hello.hello.HelloApp") == HelloApp()



# Generated at 2022-06-12 08:59:56.230974
# Unit test for function import_string
def test_import_string():
    from .__main__ import HttpServer
    from . import Request

    assert HttpServer == import_string("http_server.HttpServer")
    assert Request == import_string("http_server.Request")

    from . import h11_server as m

    assert m == import_string("http_server.h11_server")

# Generated at 2022-06-12 08:59:59.213032
# Unit test for function import_string
def test_import_string():
    import sys

    assert import_string("pathlib.Path") == sys.modules["pathlib.Path"]
    assert import_string("io.StringIO") == sys.modules["io"].StringIO



# Generated at 2022-06-12 09:00:09.397178
# Unit test for function import_string
def test_import_string():
    from importlib import import_module
    import collections
    import operator
    import http.cookies
    import pyramid.compat
    # import_string with a module path should return a module
    m = import_string('collections')
    assert m is collections
    m = import_string('operator')
    assert m is operator
    m = import_string('http.cookies')
    assert m is http.cookies
    m = import_string('pyramid.compat')
    assert m is pyramid.compat
    # import_string with a class path should return an instance
    m = import_string('collections.deque')
    assert isinstance(m, collections.deque)
    m = import_string('http.cookies.Morsel')
    assert isinstance(m, http.cookies.Morsel)

# Generated at 2022-06-12 09:00:11.027556
# Unit test for function import_string
def test_import_string():
    obj = import_string(__name__ + ".import_string")
    assert obj(__name__ + ".import_string") == import_string



# Generated at 2022-06-12 09:00:12.926244
# Unit test for function import_string
def test_import_string():
    import pytest
    assert import_string('mahno.utils.standard_http.import_string')

# Generated at 2022-06-12 09:00:16.783442
# Unit test for function import_string
def test_import_string():

    # function with a module path
    assert import_string("os") == os

    # function with a class path
    assert type(import_string("tests.http.HttpParser")) == HttpParser


# Generated at 2022-06-12 09:00:18.434206
# Unit test for function import_string
def test_import_string():
    class A:
        pass

    assert import_string("tests.test_header.A")



# Generated at 2022-06-12 09:00:22.817068
# Unit test for function import_string
def test_import_string():
    obj = import_string("physalis.http.request")
    assert obj.__name__ == 'Request'
    assert obj.__module__ == 'physalis.http'

    obj = import_string("physalis.test.test_http.test_utils")
    assert obj.__name__ == 'test_utils'
    assert obj.__module__ == 'physalis.test.test_http'

# Generated at 2022-06-12 09:00:32.094145
# Unit test for function import_string
def test_import_string():
    module = import_string("builtins")
    assert "basestring" in dir(module)
    assert "basestring".encode() in dir(module)

    class_module = import_string("webservice.tests.TestClass")
    assert isinstance(class_module, TestClass)
    assert class_module.msg == "Hello world"

    class_module = import_string("webservice.tests.TestClass.TestClass")
    assert isinstance(class_module, TestClass)
    assert class_module.msg == "Hello world"


# Generated at 2022-06-12 09:00:39.563286
# Unit test for function import_string
def test_import_string():
    import wsgi_light.tests.test_routing
    module = import_string("wsgi_light.tests.test_routing.TestRouting")
    assert module.__name__ == "wsgi_light.tests.test_routing.TestRouting"
    assert ismodule(module)
    app = import_string("wsgi_light.tests.test_routing.TestApp")
    assert isinstance(app, wsgi_light.tests.test_routing.TestApp)



# Generated at 2022-06-12 09:00:45.115588
# Unit test for function import_string
def test_import_string():
    # test import a class
    assert import_string("h2.events.ConnectionTerminated")
    # test import a module
    assert import_string("h2.events")
    # test with package
    assert import_string("h2", package="hyperframe") == import_module("h2")
    # test with invalid path
    with raises(ImportError):
        import_string("invalid_path")

# Generated at 2022-06-12 09:00:48.755315
# Unit test for function import_string
def test_import_string():
    m = import_string("sanic.blueprints.blueprint.Blueprint.register")
    assert m.__name__ == "register"
    m = import_string("sanic.blueprints.blueprint")
    assert m.__name__ == "sanic.blueprints.blueprint"

# Generated at 2022-06-12 09:00:53.721495
# Unit test for function import_string
def test_import_string():
    from urllib.parse import urlparse

    assert import_string("urllib.parse.urlparse") == urlparse
    assert import_string("urllib.parse:urlparse") == urlparse
    assert import_string("urllib.parse", "urlparse") == urlparse



# Generated at 2022-06-12 09:00:56.462301
# Unit test for function import_string
def test_import_string():
    import sys
    import json

    assert STATUS_CODES == import_string("aiohttp.client.helpers.STATUS_CODES")
    assert json == import_string("json")
    assert sys == import_string("sys", package=json)

# Generated at 2022-06-12 09:00:59.939483
# Unit test for function import_string
def test_import_string():
    from . import mocks
    assert import_string("wsgi.mocks.Mock") is mocks.Mock
    assert import_string("wsgi.mocks.Mock", __package__) is mocks.Mock

# Generated at 2022-06-12 09:01:05.024553
# Unit test for function import_string
def test_import_string():
    import os
    import tempfile

    def write_file(name: str, content: str):
        f = tempfile.NamedTemporaryFile(mode="w", delete=False)
        f.write(content)
        f.close()
        return f.name

    # Import a module

# Generated at 2022-06-12 09:01:06.833538
# Unit test for function import_string
def test_import_string():
    from .middlewares import RequestLogMiddleware
    assert import_string("pyweb.middlewares.RequestLogMiddleware") == RequestLogMiddleware

# Generated at 2022-06-12 09:01:11.553268
# Unit test for function import_string
def test_import_string():
    from uvloop.loops import _LOOPS
    from uvloop.loops._selector_events import SelectorEventLoop, SelectorSockHub
    import_string("uvloop.loops._selector_events.SelectorEventLoop")
    import_string("uvloop.loops._selector_events.SelectorSockHub")

# Generated at 2022-06-12 09:01:14.981684
# Unit test for function import_string
def test_import_string():
    import klein
    assert import_string("klein") == klein
    assert import_string("klein.app") == klein.app

# Generated at 2022-06-12 09:01:17.940631
# Unit test for function import_string
def test_import_string():
    import aiohttp
    ssl_context = import_string("aiohttp.Fingerprint")
    assert isinstance(ssl_context, aiohttp.Fingerprint)

# Generated at 2022-06-12 09:01:21.686483
# Unit test for function import_string
def test_import_string():
    def import_string_coverage():
        """Import a module and a class by valid path."""
        import_string("falcon.asgi.handler")
        import_string("falcon.asgi.handler.ComposedHandler")

test_import_string()

# Generated at 2022-06-12 09:01:25.607991
# Unit test for function import_string
def test_import_string():
    class A:
        def __init__(self):
            self.test = 1

    import sys
    import_string(__name__ + ".A") == A
    import_string(__name__ + ".A")()
    assert hasattr(import_string(__name__ + ".A")(), "test")



# Generated at 2022-06-12 09:01:29.705081
# Unit test for function import_string
def test_import_string():
    expected_class = 'Object'
    obj = import_string('tests.apps.object')
    assert obj.__name__ == expected_class
    obj = import_string('tests.apps.object.Object')
    assert isinstance(obj, Object) is True
    assert obj.name == expected_class

# Import test Objects
from tests.apps.object import Object

# Generated at 2022-06-12 09:01:30.458006
# Unit test for function import_string
def test_import_string():
    assert import_string("http.cookiejar.CookieJar")

# Generated at 2022-06-12 09:01:36.070314
# Unit test for function import_string
def test_import_string():
    class Class(object):
        pass

    def _test():
        import sys
        import pathlib
        assert isinstance(import_string(pathlib.Path(__file__).as_posix()), type) #noqa
        import_string(sys.__name__ + ".stdout")
        import_string(sys.__name__ + ".stdout.flush")
        import_string(__file__ + ":Class")
        # TODO test if is a module
    _test()



# Generated at 2022-06-12 09:01:38.719281
# Unit test for function import_string
def test_import_string():
    class TestClass(object):
        pass

    test_module = import_string('http import.test_http.TestClass')
    assert isinstance(test_module, TestClass)

# Generated at 2022-06-12 09:01:44.056850
# Unit test for function import_string
def test_import_string():
    """
    test import_string
    """
    import aiohttp
    from .server import HttpServer
    assert isinstance(import_string("aiohttp.web"), aiohttp.web.Application)
    assert isinstance(import_string("aiohttp.web.Application"),
                      aiohttp.web.Application)
    assert isinstance(import_string("aiohttp.web", "module"),
                      aiohttp.web.Application)
    assert isinstance(import_string("aioweb.server.HttpServer"),
                      HttpServer)

# Generated at 2022-06-12 09:01:53.863590
# Unit test for function import_string
def test_import_string():
    import sys
    import tempfile
    import unittest

    class A:
        pass

    class B:
        pass

    class TestImport(unittest.TestCase):
        def setUp(self):
            ind = sys.path.index(".")
            self.old_sys_path = sys.path[ind:]
            sys.path[ind:] = []
            self.tmp_path = tempfile.mkdtemp()

        def tearDown(self):
            sys.path[sys.path.index("."):] = self.old_sys_path

        def test_basic_import(self):
            sys.path.append(self.tmp_path)
            with tempfile.NamedTemporaryFile(dir=self.tmp_path,
                                             delete=False, mode="wt") as f:
                f.write

# Generated at 2022-06-12 09:02:04.753375
# Unit test for function import_string
def test_import_string():
    from importlib import import_module
    from inspect import isclass
    from pathlib import Path
    from unittest import TestCase

    base_dir = Path(__file__).parent.absolute()
    test_module_path = f"{base_dir}/fixtures/test_module.py"
    test_module = import_module(test_module_path)

    class TestImportString(TestCase):
        def test_import_string_module(self):
            self.assertEqual(
                test_module,
                import_string(f"{test_module_path}")
            )

        def test_import_string_class(self):
            self.assertTrue(
                isclass(import_string(f"{test_module_path}.TestClass")))

# Generated at 2022-06-12 09:02:07.958247
# Unit test for function import_string
def test_import_string():
    from hapic import Hapic
    hapic = import_string("hapic.Hapic")
    assert(isinstance(hapic, Hapic))
    hapic = import_string("hapic.Hapic.Hapic")
    assert(isinstance(hapic, Hapic))

# Generated at 2022-06-12 09:02:10.845030
# Unit test for function import_string
def test_import_string():
    class A:
        pass

    assert (import_string(__name__ + ".test_import_string") ==
            test_import_string)
    assert (isinstance(
        import_string(__name__ + ".test_import_string.A"), A))

# Generated at 2022-06-12 09:02:15.421164
# Unit test for function import_string
def test_import_string():
    url_map = import_string('daphne.endpoints.http_protocol.HttpRequestParser')
    assert url_map.__dict__['__module__'] == 'daphne.endpoints.http_protocol'
    assert url_map.__class__.__name__ == 'HttpRequestParser'

# Generated at 2022-06-12 09:02:24.589872
# Unit test for function import_string
def test_import_string():
    import os
    import tempfile
    import shutil
    import sys
    # Create a temporary directory
    tmp_src = tempfile.mkdtemp()


# Generated at 2022-06-12 09:02:32.730545
# Unit test for function import_string
def test_import_string():
    def import_string_module_with_module_path_returns_module():
        module = import_string("http.client")
        assert module.__name__ == "http.client"

    def import_string_module_with_class_path_returns_instance_of_class():
        instance = import_string(
            "aiohttp.client_exceptions.ClientConnectionError"
        )
        assert isinstance(instance, type)

    def import_string_module_with_invalid_path_returns_AttributeError():
        import pytest

        with pytest.raises(AttributeError):
            import_string("not.exist")

# Generated at 2022-06-12 09:02:36.851027
# Unit test for function import_string
def test_import_string():
    from . import Server
    from . import WSGIServer
    s = Server("127.0.0.1", 8000)
    assert import_string(s.__class__.__module__ + "." + s.__class__.__name__)
    assert import_string("http.server.Server")
    assert not import_string("http.server.Server.Server")
    assert isinstance(import_string("http.server.WSGIServer"), WSGIServer)

# Generated at 2022-06-12 09:02:38.460273
# Unit test for function import_string
def test_import_string():
    import_string('falcon.request_helpers')
    import_string('falcon.request_helpers.Request')


# Generated at 2022-06-12 09:02:44.135680
# Unit test for function import_string
def test_import_string():
    from pyhttp.exceptions import ImporError

    assert import_string("pyhttp.http.http11.HttpProtocol")
    try:
        import_string("pyhttp.http.https.HttpProtocol")
    except ImporError:
        pass
    else:
        assert False, "Import string should fail"
    assert import_string("pyhttp.http.http11.HttpProtocol").__class__.__name__ == "HttpProtocol"



# Generated at 2022-06-12 09:02:49.233180
# Unit test for function import_string
def test_import_string():
    """Testing function import_string"""
    obj_str = "h2.__version__"
    obj_str2 = "h2.connection"
    obj = import_string(obj_str)
    obj2 = import_string(obj_str2)
    assert obj == "2.8.0" and obj2.__name__ == "connection"

# Generated at 2022-06-12 09:02:55.185295
# Unit test for function import_string
def test_import_string():
    from strictyaml.load import Loader
    assert Loader == import_string("strictyaml.load.Loader")

if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 09:02:58.900950
# Unit test for function import_string
def test_import_string():
    from uvicorn.main import Config
    config = import_string("uvicorn.main.Config")
    assert isinstance(config, Config)
    config = import_string("uvicorn.main.Config", package="uvicorn")
    assert isinstance(config, Config)



# Generated at 2022-06-12 09:03:01.215241
# Unit test for function import_string
def test_import_string():
    import uvicorn  # noqa
    expected = uvicorn.Config
    result = import_string("uvicorn.Config")
    assert expected == result


# Generated at 2022-06-12 09:03:04.736580
# Unit test for function import_string
def test_import_string():
    module = import_string("http.server")
    assert module.__name__ == "http.server"
    handler = import_string("http.server.BaseHTTPRequestHandler")
    assert isinstance(handler, object)
    assert handler.__class__.__name__ == "BaseHTTPRequestHandler"

# Generated at 2022-06-12 09:03:09.055351
# Unit test for function import_string
def test_import_string():
    class TestClass(object):
        pass
    assert isinstance(import_string(__name__ + ".test_import_string.TestClass"), TestClass)
    assert import_string(__name__) == import_module(__name__)
    assert import_string(__name__ + "t") is None



# Generated at 2022-06-12 09:03:17.627703
# Unit test for function import_string
def test_import_string():
    import unittest
    from io import StringIO

    def assert_import_error(string):
        with self.assertRaises(ImportError, msg=f"Did not fail to import {string}"):
            import_string(string)

    class MyTestCase(unittest.TestCase):
        def test_import_module(self):
            my_module = import_string("asyncblink.testing_utils")
            self.assertEqual(my_module.__name__, "asyncblink.testing_utils")
            self.assertTrue(hasattr(my_module, "tcp_echo_client"))
            self.assertTrue(hasattr(my_module, "tcp_echo_server"))


# Generated at 2022-06-12 09:03:20.815502
# Unit test for function import_string
def test_import_string():

    # Test import a module
    assert import_string("http.server")

    # Test import a class
    assert isinstance(import_string("http.server.CGIHTTPRequestHandler"), type)

if __name__ == "__main__":
    print("Unit test function import_string: ...")
    test_import_string()
    print("Done")

# Generated at 2022-06-12 09:03:26.380282
# Unit test for function import_string
def test_import_string():
    from .asgi import Request
    from .utils import CaseInsensitiveDict
    from .websocket import WebSocketReader, WebSocketWriter
    from .errors import PayloadTooLarge

    assert import_string(TEST_APP_NAME) is TEST_APP_OBJECT
    assert import_string(REQUEST_CLASS_NAME) is Request
    assert import_string(CASESENSITIVE_DICT_NAME) is CaseInsensitiveDict
    assert import_string(WEBSOCKET_READER_NAME) is WebSocketReader
    assert import_string(WEBSOCKET_WRITER_NAME) is WebSocketWriter
    assert import_string(PAYLOAD_TOO_LARGE_NAME) is PayloadTooLarge


# Fixtures for testing function import_string

# Generated at 2022-06-12 09:03:28.040466
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection")
    assert import_string("http.client.HTTPResponse")



# Generated at 2022-06-12 09:03:36.624748
# Unit test for function import_string
def test_import_string():
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse

    assert isinstance(import_string(Starlette.__module__ + "." + Starlette.__name__), Starlette)
    assert isinstance(import_string(JSONResponse.__module__ + "." + JSONResponse.__name__), JSONResponse)
    assert callable(import_string(JSONResponse.__module__ + "." + JSONResponse.__name__))
    assert isinstance(import_string(JSONResponse.__module__ + "." + JSONResponse.__name__)(), JSONResponse)