

# Generated at 2022-06-12 08:59:02.149520
# Unit test for function import_string
def test_import_string():
    assert ismodule(import_string("os"))
    import datetime
    assert callable(import_string("datetime.date"))
    assert import_string("datetime.date") == datetime.date
    assert isinstance(import_string("datetime.date"), datetime.date)



# Generated at 2022-06-12 08:59:05.280636
# Unit test for function import_string
def test_import_string():
    obj = import_string("tests.test_http.test_http.TestClass")
    assert obj.a == 1
    assert isinstance(obj, TestClass)
    assert import_string("tests.test_http.test_http") == test_http



# Generated at 2022-06-12 08:59:15.399986
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        module_path = os.path.join(tmpdirname, "imported_module.py")
        with open(module_path, "w") as module_file:
            module_file.write(
                """class TestClass:
    def __init__(self):
        self.name = "test_import_string"
"""
            )
            sys.path.append(tmpdirname)
            res = import_string("imported_module.TestClass")
            assert res.name == "test_import_string", "Test import_string failed"

# Generated at 2022-06-12 08:59:17.655606
# Unit test for function import_string
def test_import_string():
    from .response import Response
    assert import_string("hypercorn.response.Response") is Response


# Generated at 2022-06-12 08:59:25.784200
# Unit test for function import_string
def test_import_string():
    from . import middleware
    assert import_string("falcon.middleware.MiddlewareComponent") == middleware.MiddlewareComponent
    assert type(import_string("falcon.middleware.MiddlewareComponent")) == middleware.MiddlewareComponent
    assert type(import_string("falcon.middleware.RequireJSON")) == middleware.RequireJSON
    assert hasattr(import_string("falcon.middleware.RequireJSON"), 'process_request')
    assert hasattr(import_string("falcon.middleware.RequireJSON"), 'process_response')

# Generated at 2022-06-12 08:59:33.574347
# Unit test for function import_string
def test_import_string():
    cls = import_string("aiohttp.web.web_middlewares.middleware")
    assert cls is import_module("aiohttp.web.web_middlewares").middleware
    cls = import_string("aiohttp.web.web_middlewares.middleware.BaseMiddleware")
    assert cls is import_module("aiohttp.web.web_middlewares").middleware.BaseMiddleware
    cls = import_string("aiohttp.web.web_middlewares.middleware.BaseMiddleware", package="aiohttp.web")
    assert cls is import_module("aiohttp.web.web_middlewares").middleware.BaseMiddleware

# Generated at 2022-06-12 08:59:37.104536
# Unit test for function import_string
def test_import_string():
    from .config import Settings

    assert import_string("simple_server.config.Settings") == Settings()
    assert import_string("simple_server.config.Settings") is not Settings()



# Generated at 2022-06-12 08:59:39.577189
# Unit test for function import_string
def test_import_string():
    """
    import a module class by string path.
    """
    # import a module
    assert import_string("http.cookies").CookieError
    # import a class
    assert import_string("http.cookies.CookieError")

# Generated at 2022-06-12 08:59:51.283745
# Unit test for function import_string
def test_import_string():
    from email.message import Message
    from io import StringIO
    from email.parser import Parser
    assert import_string('email.message.Message') == Message
    assert import_string('email.parser.Parser').parse(StringIO('')) == Parser()
    from email.policy import SMTP
    assert import_string('email.policy.SMTP') == SMTP
    from http.client import HTTPConnection
    assert import_string('http.client.HTTPConnection') == HTTPConnection
    assert import_string('http.client.HTTPConnection')._http_vsn_str == 'HTTP/1.1'
    from urllib.parse import parse_qs
    assert import_string('urllib.parse.parse_qs') == parse_qs

# Generated at 2022-06-12 08:59:55.710569
# Unit test for function import_string
def test_import_string():
    module_name = "falcon.asgi.ASGIApp"
    from falcon.asgi import ASGIApp as klass
    module = import_string(module_name)
    assert issubclass(module, klass)
    module = import_string(module_name)()
    assert isinstance(module, klass)

# Generated at 2022-06-12 09:00:02.222740
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(500)
    assert has_message_body(200)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(101)
    assert not has_message_body(102)



# Generated at 2022-06-12 09:00:06.745376
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(101) == False
    assert has_message_body(204) == False
    assert has_message_body(304) == False

    assert has_message_body(200) == True
    assert has_message_body(400) == True
    assert has_message_body(404) == True



# Generated at 2022-06-12 09:00:12.165887
# Unit test for function has_message_body
def test_has_message_body():
    """
    >>> test_has_message_body()
    True
    """
    assert not has_message_body(1)
    assert not has_message_body(204)
    assert not has_message_body(304)

    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)

    assert has_message_body(200)



# Generated at 2022-06-12 09:00:22.296356
# Unit test for function remove_entity_headers

# Generated at 2022-06-12 09:00:28.496945
# Unit test for function has_message_body
def test_has_message_body():
    """
    Test case for function has_message_body

    This test validates the function is returning a correct
    value for each status.

    """
    assert has_message_body(200)
    assert has_message_body(404)
    assert has_message_body(100)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(101)


# Generated at 2022-06-12 09:00:39.970185
# Unit test for function has_message_body
def test_has_message_body():
    assert(has_message_body(100) == False)
    assert(has_message_body(101) == False)
    assert(has_message_body(102) == True)
    assert(has_message_body(103) == True)
    assert(has_message_body(200) == True)
    assert(has_message_body(201) == True)
    assert(has_message_body(202) == True)
    assert(has_message_body(203) == False)
    assert(has_message_body(204) == False)
    assert(has_message_body(205) == False)
    assert(has_message_body(206) == True)
    assert(has_message_body(207) == True)
    assert(has_message_body(208) == True)

# Generated at 2022-06-12 09:00:45.693057
# Unit test for function has_message_body
def test_has_message_body():
    # The response MUST NOT include a message-body
    assert not has_message_body(1)
    assert not has_message_body(4)
    assert not has_message_body(100)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(200)
    assert has_message_body(300)
    assert has_message_body(500)

# Generated at 2022-06-12 09:00:51.711534
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "expires": "123",
        "content-length": "123",
        "content-type": "text/html",
        "content-location": "http://123.com",
    }

    headers2 = {
        "content-length": "123",
        "content-location": "http://123.com",
    }

    assert remove_entity_headers(headers) == headers2

# Generated at 2022-06-12 09:00:56.132245
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    test_headers = {
        "content-location": "/index.html",
        "content-length": "10",
        "expires": "datetime",
        "Some-Header": "value",
    }
    assert remove_entity_headers(test_headers) == {
        "expires": "datetime",
        "Some-Header": "value",
    }

# Generated at 2022-06-12 09:01:05.692662
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({}) == {}
    assert remove_entity_headers({"X-foo": 1}) == {"X-foo": 1}
    assert remove_entity_headers({"Content-Location": 1}) == {"Content-Location": 1}
    assert remove_entity_headers({"Expires": 1}) == {"Expires": 1}
    assert remove_entity_headers({"Content-location": 1}) == {"Content-location": 1}
    assert remove_entity_headers({"expires": 1}) == {"expires": 1}
    assert remove_entity_headers({"Content-Type": 1}) == {}
    assert remove_entity_headers({"content-type": 1}) == {}