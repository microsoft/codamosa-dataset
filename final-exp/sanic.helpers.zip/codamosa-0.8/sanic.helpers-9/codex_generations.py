

# Generated at 2022-06-12 08:59:12.014405
# Unit test for function import_string
def test_import_string():
    from falcon import Request, Response
    module = import_string('falcon.request')
    assert ismodule(module)
    instance = import_string('falcon.request.Request')
    assert isinstance(instance, Request)
    instance = import_string('falcon.response.Response')
    assert isinstance(instance, Response)

# Generated at 2022-06-12 08:59:20.737899
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == True
    assert has_message_body(101) == True
    assert has_message_body(102) == True
    assert has_message_body(103) == True
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(202) == True
    assert has_message_body(203) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == True
    assert has_message_body(206) == True
    assert has_message_body(207) == True
    assert has_message_body(208) == True
    assert has_message_body(226) == True
    assert has_message_body(300) == True
    assert has_

# Generated at 2022-06-12 08:59:30.306612
# Unit test for function import_string
def test_import_string():
    import pytest
    from http import HTTPStatus
    from server import Server
    from validators import IPValidator
    assert import_string("http.HTTPStatus") == HTTPStatus
    assert import_string("http.HTTPStatus.OK") == HTTPStatus.OK
    assert import_string("server.Server") == Server
    assert isinstance(import_string("server.Server"), Server)
    assert import_string("server.Server.run") == Server.run
    assert import_string("validators.IPValidator") == IPValidator
    assert isinstance(import_string("validators.IPValidator"), IPValidator)
    assert import_string("validators.IPValidator.validate") == IPValidator.validate
    with pytest.raises(AttributeError):
        import_string("validators")

# Generated at 2022-06-12 08:59:38.952908
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(1)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(200)
    assert not has_message_body(203)
    assert not has_message_body(204)
    assert not has_message_body(300)
    assert not has_message_body(304)
    assert not has_message_body(305)
    assert not has_message_body(401)
    assert not has_message_body(402)
    assert not has_message_body(403)
    assert not has_message_body(404)
    assert not has_message_body(405)
    assert not has_message_body(406)
    assert not has_message_body

# Generated at 2022-06-12 08:59:40.889152
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import os.path as path

    file_name = path.join(os.getcwd(), "http.py")
    import_string(file_name)

# Generated at 2022-06-12 08:59:47.223051
# Unit test for function import_string
def test_import_string():
    from wsgiref.simple_server import demo_app
    from http import HTTPStatus
    # import module
    assert import_string("http.HTTPStatus") == HTTPStatus
    # import class
    assert isinstance(
        import_string("http.server.BaseHTTPRequestHandler"), type
    )
    # import and get instance
    assert import_string("wsgiref.simple_server.demo_app") is demo_app



# Generated at 2022-06-12 08:59:56.891057
# Unit test for function import_string
def test_import_string():
    """Tests the import string function."""
    # Tests a module path
    assert import_string("test") is not None
    # Tests a module path with package
    assert import_string("test", "test") is not None
    # Tests a path which is not a module or class
    assert import_string("test.path") is None
    # Tests a class
    assert import_string("test.core.http.http") is not None
    # Tests a class with package
    assert import_string("core.http.http", "test") is not None
    # Tests a class without module
    assert import_string("http") is None
# End of unit test


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-12 09:00:07.382607
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    test_headers = {
        b"content-md5": b"test_contentmd5",
        b"content-range": b"bytes test_contentrange",
        b"content-type": b"text/html; charset=UTF-8",
        b"status": b"test_status",
        b"foo": b"bar",
        b"content-location": b"test_contentLocation",
        b"expires": b"test_expires",
        b"content-language": b"test_contentlanguage",
        b"content-length": b"test_contentlength",
        b"last-modified": b"test_lastmodified",
    }


# Generated at 2022-06-12 09:00:17.153813
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    Tests remove_entity_headers function
    """
    test_headers = {
        "Content-Length": 12345,
        "Content-Type": "text/html",
        "Content-Encoding": "gzip",
        "Content-Location": "index.html",
        "Content-Language": "en",
        "Content-Range": "bytes 21010-47021/47022",
        "Content-MD5": "test",
        "Last-Modified": "Mon, 05 Mar 2018 21:47:21 GMT",
        "Expires": "Tue, 05 Mar 2019 21:47:21 GMT",
    }
    reference_headers = {
        "Content-Location": "index.html",
        "Expires": "Tue, 05 Mar 2019 21:47:21 GMT",
    }
    response = remove_entity_headers

# Generated at 2022-06-12 09:00:20.653458
# Unit test for function import_string
def test_import_string():
    from .test_application import TestApplication
    assert import_string("httptools.HTTPParser") == HTTPParser
    assert isinstance(import_string("tests.test_application.TestApplication"),
                      TestApplication)
    assert import_string("tests.test_application.app") == app

# Generated at 2022-06-12 09:00:26.070078
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"foo": "bar", "Content-length": "10", "content-encoding": "gzip"}
    assert remove_entity_headers(headers) == {"foo": "bar"}

# Generated at 2022-06-12 09:00:28.776873
# Unit test for function import_string
def test_import_string():
    from werkzeug.test import create_environ
    app = import_string("werkzeug.test:create_environ")
    assert callable(app)

# Generated at 2022-06-12 09:00:32.848479
# Unit test for function import_string
def test_import_string():
    module = import_string("asyncio.tasks")
    assert module.sleep
    cors = import_string("aiohttp.web_middlewares.cors.CorsMiddleware")
    assert cors.__class__.__name__ == "CorsMiddleware"

# Generated at 2022-06-12 09:00:38.209509
# Unit test for function import_string
def test_import_string():
    """
    test import_string function
    """
    assert import_string("datetime.datetime") == datetime.datetime
    assert import_string("collections.OrdereDict") == collections.OrderedDict
    assert import_string("collections.OrdereDict").__class__.__name__ == "OrderedDict"

# Generated at 2022-06-12 09:00:44.586970
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "10",
        "Content-Location": "path",
        "Content-Encoding": "gzip",
        "Content-Type": "text/html",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
    }
    expected = {"Content-Location": "path", "Expires": "Thu, 01 Dec 1994 16:00:00 GMT"}
    assert remove_entity_headers(headers) == expected

# Generated at 2022-06-12 09:00:48.562135
# Unit test for function import_string
def test_import_string():
    import uvicorn
    assert import_module("uvicorn") == import_string("uvicorn")
    assert uvicorn.Server == import_string("uvicorn.Server")
    assert import_module("uvicorn", package="uvicorn") == import_string("uvicorn", package="uvicorn")

# Generated at 2022-06-12 09:00:51.465305
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    a = remove_entity_headers({"Content-Encoding": "gzip", "Content-Length": 3})
    assert a == {"Content-Length": 3}

# Generated at 2022-06-12 09:00:55.656098
# Unit test for function import_string
def test_import_string():
    """
    Tests the function *import_string*
    """
    from .test import test_asyncapi

    assert import_string(__name__ + ".test_asyncapi") is test_asyncapi
    assert import_string(__name__ + ".test_asyncapi.TestAsyncapi")()

# Generated at 2022-06-12 09:01:03.710513
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-type": "application/json",
        "Content-Encoding": "gzip",
        "Content-Location": "http://localhost:5000",
        "Content-Length": "2048",
    }

    headers_no_entity = remove_entity_headers(headers)
    assert "Content-type" not in headers_no_entity
    assert "Content-Encoding" not in headers_no_entity
    assert "Content-Length" not in headers_no_entity
    assert "Content-Location" in headers_no_entity

# Generated at 2022-06-12 09:01:06.380054
# Unit test for function import_string
def test_import_string():
    module_name = "falcon.asgi.transport_helpers.asgi_helpers.HTTPStatus"
    mod = import_string(module_name)
    assert mod.CONTINUE == 100

