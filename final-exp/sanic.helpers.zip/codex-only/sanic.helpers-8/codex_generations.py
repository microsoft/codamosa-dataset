

# Generated at 2022-06-24 03:51:18.797604
# Unit test for function is_entity_header
def test_is_entity_header():
    """Test for is_entity_header"""
    assert is_entity_header("content-type")
    assert is_entity_header("Content-Type")
    assert is_entity_header("Content-type")
    assert not is_entity_header("not-entity-header")
    assert not is_entity_header(None)



# Generated at 2022-06-24 03:51:26.329070
# Unit test for function is_entity_header
def test_is_entity_header():
    assert not is_entity_header("Content-Type")
    assert not is_entity_header("content-type")
    assert is_entity_header("Content-Range")
    assert is_entity_header("content-range")
    assert is_entity_header("Expires")
    assert is_entity_header("expires")
    assert is_entity_header("Last-Modified")
    assert is_entity_header("last-modified")
    assert is_entity_header("Content-Length")
    assert is_entity_header("content-length")
    assert is_entity_header("Content-Encoding")
    assert is_entity_header("content-encoding")
    assert is_entity_header("Content-MD5")
    assert is_entity_header("content-md5")
    assert is_entity_header("Content-Language")

# Generated at 2022-06-24 03:51:29.493752
# Unit test for function import_string
def test_import_string():
    import uvicorn.protocols.http.parser

    assert import_string("uvicorn.protocols.http.parser") == uvicorn.protocols.http.parser



# Generated at 2022-06-24 03:51:33.610703
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Expires")
    assert is_entity_header("expires")
    assert not is_entity_header("something else")

# Unit tests for function is_hop_by_hop_header

# Generated at 2022-06-24 03:51:36.919057
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header(b"Content-Location")
    assert is_entity_header(b"content-location")
    assert is_entity_header(b"Expires")
    assert not is_entity_header(b"Host")



# Generated at 2022-06-24 03:51:46.303691
# Unit test for function remove_entity_headers

# Generated at 2022-06-24 03:51:49.246315
# Unit test for function import_string
def test_import_string():
    from proton import core
    assert core == import_string("proton.core")
    from proton.response import Response
    resp = import_string('proton.response.Response')
    assert isinstance(resp, Response)

# Generated at 2022-06-24 03:51:52.737382
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("CONNECTION") == True
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("Not-Name") == False
    assert is_hop_by_hop_header("Content-Type") == False


# Generated at 2022-06-24 03:51:54.848082
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Length": "128", "Connection": "keep-alive"}
    assert remove_entity_headers(headers) == {"Connection": "keep-alive"}

# Generated at 2022-06-24 03:52:03.536296
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    from .parser import Parser


# Generated at 2022-06-24 03:52:09.079585
# Unit test for function import_string
def test_import_string():
    import sys
    from httoop.util import UDP6
    from httoop.util import import_string
    assert UDP6 is import_string('httoop.util.UDP6')
    assert UDP6 is import_string('httoop.util.UDP6', sys.modules[__name__])

# Generated at 2022-06-24 03:52:13.150036
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("coNNECTION")
    assert is_hop_by_hop_header("connection")
    assert not is_hop_by_hop_header("Content-Type")
    assert not is_hop_by_hop_header("content-type")
    assert not is_hop_by_hop_header("CONTENT-TYPE")


# Generated at 2022-06-24 03:52:17.387252
# Unit test for function import_string
def test_import_string():
    from .app import Application
    assert import_string("tests.app.Application") is Application
    assert import_string("tests.app.Application")() is not None
    assert import_string("tests.app") is not None

if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-24 03:52:22.201727
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(101)
    assert has_message_body(102)
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(404)

# Generated at 2022-06-24 03:52:25.422899
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    h = {
        "cache-control": "public",
        "content-language": "en-US",
        "content-length": "0",
        "content-md5": "Q2hlY2sgSW50ZWdyaXR5IQ==",
        "expires": "Fri, 01 Dec 2014 16:00:00 GMT",
    }
    headers = remove_entity_headers(h)
    assert not headers.keys() & _ENTITY_HEADERS
    assert headers["cache-control"] == "public"

# Generated at 2022-06-24 03:52:26.878368
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert not is_hop_by_hop_header("Host")
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("Keep-Alive")


# Generated at 2022-06-24 03:52:28.970242
# Unit test for function import_string
def test_import_string():
    from . import BaseHTTPRequestHandler

    import_ = import_string("asyncer.http.BaseHTTPRequestHandler")
    assert import_ is BaseHTTPRequestHandler

# Generated at 2022-06-24 03:52:31.362002
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False

# Generated at 2022-06-24 03:52:36.294004
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("connection")
    assert not is_hop_by_hop_header("content-length")
    assert not is_hop_by_hop_header("Content-Length")

# Generated at 2022-06-24 03:52:41.852352
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string to ensure it is working
    """
    module = import_string("email.message.Message")
    assert module.Message is not None
    from email.message import Message
    msg = import_string("email.message.Message")()
    assert isinstance(msg, Message)
    assert msg.as_string() == "None\n"

# Generated at 2022-06-24 03:52:47.739684
# Unit test for function import_string
def test_import_string():
    from . import TestCase
    from .test_utils import get_test_config

    config = get_test_config()
    class_name = "chaos.server.server.Server"
    Server = import_string(class_name)
    new_server = Server(config)
    TestCase.assert_is_instance(new_server, Server)

# Generated at 2022-06-24 03:52:54.000480
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Length": "2", "Connection": "close"}
    new_headers = remove_entity_headers(headers)
    assert "Content-Length" not in new_headers



# Generated at 2022-06-24 03:52:56.785417
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    test_dict = {"allow": "GET", "Content-Type": "text/html"}
    response = remove_entity_headers(test_dict)
    assert response == {"allow": "GET"}



# Generated at 2022-06-24 03:53:03.802616
# Unit test for function has_message_body
def test_has_message_body():
    """Defines test function has_message_body"""
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(300) == True
    assert has_message_body(400) == True
    assert has_message_body(500) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False

# Generated at 2022-06-24 03:53:05.301481
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header('allow')


# Generated at 2022-06-24 03:53:08.421480
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert(is_hop_by_hop_header("connection"))
    assert(not is_hop_by_hop_header("Connection"))
    assert(not is_hop_by_hop_header("test"))


# Generated at 2022-06-24 03:53:15.823699
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-encoding": "gzip", "expires": "gzip"}
    headers = remove_entity_headers(headers)
    assert headers == {"expires": "gzip"}
    headers = remove_entity_headers(headers, allowed=[])
    assert headers == {}
    headers = {"content-encoding": "gzip", "expires": "gzip"}
    headers = remove_entity_headers(headers, allowed=["expires"])
    assert headers == {"expires": "gzip"}


# Generated at 2022-06-24 03:53:18.045098
# Unit test for function import_string
def test_import_string():
    assert import_string("mock.Mock")

    mock = import_string("mock.Mock")
    assert mock() == mock.Mock()

# Generated at 2022-06-24 03:53:25.911711
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(205)


# Generated at 2022-06-24 03:53:30.627017
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    _TEST_HEADERS = {
        "Content-Length": "20",
        "Content-Type": "application/json",
        "Content-Location": "/",
    }
    _EXPECTED_HEADERS = {
        "Content-Location": "/",
    }
    assert _EXPECTED_HEADERS == remove_entity_headers(_TEST_HEADERS)

# Generated at 2022-06-24 03:53:34.866408
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Location": "cactus",
        "Expires": "yesterday",
        "Content-Length": "many",
        "Content-Type": "nothing"
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "cactus",
        "Expires": "yesterday",
    }


# Generated at 2022-06-24 03:53:47.076097
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    hop_by_hop_headers = (
        "Connection",
        "Keep-Alive",
        "Proxy-Authenticate",
        "Proxy-Authorization",
        "TE",
        "Trailers",
        "Transfer-Encoding",
        "Upgrade"
    )

    for header in hop_by_hop_headers:
        assert is_hop_by_hop_header(header) is True, "{} should be True".format(header)

    assert is_hop_by_hop_header("Accept-Encoding") is False, "Accept-Encoding should be False"
    assert is_hop_by_hop_header("Cookie") is False, "Cookie should be False"
    assert is_hop_by_hop_header("") is False, "Empty string should be False"
    assert is_hop_by_hop_header

# Generated at 2022-06-24 03:53:51.760787
# Unit test for function has_message_body
def test_has_message_body():
    from . import http_constants
    for status in range(1, 600):
        if status == (204 or 304 or 100 <= status < 200):
            assert not http_constants.has_message_body(status)
        else:
            assert http_constants.has_message_body(status)

# Generated at 2022-06-24 03:54:02.278843
# Unit test for function has_message_body
def test_has_message_body():
    # TODO: Replace by a unit test with pytest
    status_codes_with_message_body = [200, 201, 202, 203, 206,
                                      300, 301, 302, 303, 305, 307,
                                      400, 401, 402, 403, 404, 405, 406,
                                      407, 408, 409, 410, 411, 412, 413,
                                      414, 415, 416, 417, 422, 423, 424,
                                      426, 428, 429, 431, 500, 501, 502,
                                      503, 504, 505, 506, 507, 508, 510]
    status_codes_without_message_body = [100, 101, 102, 103, 204, 304]
    for status_code in status_codes_with_message_body:
        assert has_message_body(status_code)


# Generated at 2022-06-24 03:54:04.182097
# Unit test for function import_string
def test_import_string():
    from fastapi_skeleton.config import settings

    assert import_string(settings.AUTH_MODULE)



# Generated at 2022-06-24 03:54:08.010649
# Unit test for function import_string
def test_import_string():
    """ Doctest to import string."""
    import math
    import os.path

    assert import_string(__name__ + ".test_import_string") is test_import_string
    assert import_string("math") == math
    assert import_string("os.path") == os.path

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:54:14.668056
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("connection")
    assert not is_hop_by_hop_header("Content-Length")
    assert not is_hop_by_hop_header("content-length")
    assert not is_hop_by_hop_header("Content-MD5")

if __name__ == '__main__':
    test_is_hop_by_hop_header()

# Generated at 2022-06-24 03:54:23.671623
# Unit test for function has_message_body
def test_has_message_body():
    status_list = (1, 10, 100, 101, 102, 103, 200, 201, 202, 203, 204, 205, 206, 207, 208, 226)
    for status in status_list:
        assert not has_message_body(status)

    status_list = (300, 301, 302, 303, 304, 305, 307, 308, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 422, 423, 424, 426, 428, 429, 431, 451, 500, 501, 502, 503, 504, 505, 506, 507, 508, 510, 511)
    for status in status_list:
        assert has_message_body(status)


# Generated at 2022-06-24 03:54:34.593459
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert is_entity_header("content-encoding")
    assert is_entity_header("content-language")
    assert is_entity_header("content-length")
    assert is_entity_header("content-location")
    assert is_entity_header("content-md5")
    assert is_entity_header("content-range")
    assert is_entity_header("content-type")
    assert is_entity_header("expires")
    assert is_entity_header("last-modified")
    assert is_entity_header("extension-header")
    assert not is_entity_header("not-a-entity-header")


# Generated at 2022-06-24 03:54:37.250583
# Unit test for function import_string
def test_import_string():
    from httptools import HttpRequestParser
    parser = import_string("httptools.HttpRequestParser")
    assert isinstance(parser, HttpRequestParser)

# Generated at 2022-06-24 03:54:47.313836
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(202) == True
    assert has_message_body(203) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == True
    assert has_message_body(206) == True
    assert has_message_body(207) == True
    assert has_message_body(208) == True
    assert has_message_body(226) == True
    assert has_message_body(300) == True
    assert has_

# Generated at 2022-06-24 03:54:51.878713
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-location": "https://google.com", "expires": "2030"}
    headers = remove_entity_headers(headers)
    assert "content-location" in headers and "expires" in headers



# Generated at 2022-06-24 03:54:54.341647
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    h2 = is_hop_by_hop_header("connection")
    assert h2 == True



# Generated at 2022-06-24 03:54:56.243581
# Unit test for function has_message_body
def test_has_message_body():
    for status in (100, 200, 204, 304):
        assert not has_message_body(status)



# Generated at 2022-06-24 03:54:57.944241
# Unit test for function import_string
def test_import_string():
    assert STATUS_CODES == import_string('http.STATUS_CODES')

# Generated at 2022-06-24 03:55:03.623393
# Unit test for function has_message_body
def test_has_message_body():
    """Unit test for function has_message_body."""
    assert has_message_body(100) is False
    assert has_message_body(199) is False
    assert has_message_body(200) is True
    assert has_message_body(204) is False
    assert has_message_body(304) is False
    assert has_message_body(400) is True
    assert has_message_body(500) is True

# Generated at 2022-06-24 03:55:06.733708
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = [("Content-Encoding", "gzip"), ("Transfer-Encoding", "chunked")]
    expected = [("Transfer-Encoding", "chunked")]
    headers = remove_entity_headers(headers)
    assert headers == expected

# Generated at 2022-06-24 03:55:09.377166
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection")
    assert not is_hop_by_hop_header("x-frame-options")


# Generated at 2022-06-24 03:55:20.742520
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_body(302)
    assert has_message_body(303)
    assert has_message_body(305)
    assert has_message_body(400)
    assert has_message_body(401)
    assert has_message_

# Generated at 2022-06-24 03:55:23.293741
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-length")


# Generated at 2022-06-24 03:55:32.798898
# Unit test for function import_string
def test_import_string():
    import sys
    import os.path

    def add_to_path(path):
        if path not in sys.path:
            sys.path.insert(0, path)

    path = os.path.join(os.path.dirname(__file__), "test_files_import_string")
    add_to_path(path)
    m = import_string("module_import_string")
    assert m.function() == "function from module"
    c = import_string("module_import_string:ClassTest")
    assert c.function() == "function from class"

# Generated at 2022-06-24 03:55:35.646079
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == True
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False

# Generated at 2022-06-24 03:55:41.238356
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(301) == True
    assert has_message_body(304) == False
    assert has_message_body(400) == True

# Generated at 2022-06-24 03:55:53.396983
# Unit test for function import_string
def test_import_string():
    # with valid path of a module
    obj = import_string(module_name="os.path")
    assert ismodule(obj)
    assert obj == import_module("os.path")

    # with valid path of a class
    obj = import_string(module_name="os.path.PathLike")
    assert not ismodule(obj)

    # with valid path of a class and its methods
    obj = import_string(module_name="os.path.PathLike.__fspath__")
    assert callable(obj)

    # with invalid path
    obj = import_string(module_name="os.path.PathLike.__fspath_")
    assert obj is None

    # with a string like a class
    obj = import_string(module_name="str")
    assert not ismodule(obj)

    #

# Generated at 2022-06-24 03:55:56.548830
# Unit test for function import_string
def test_import_string():
    from falcon.request import Request
    print(import_string("falcon.request.Request"))
    assert import_string("falcon.request.Request") == Request

# Generated at 2022-06-24 03:55:59.840181
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    sample_headers = {
        'Content-Type': 'application/json',
        'Content-Length': '200'
    }

    assert remove_entity_headers(sample_headers) == {'Content-Type': 'application/json'}

# Generated at 2022-06-24 03:56:05.434104
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Allow") is True
    assert is_entity_header("allow") is True
    assert is_entity_header("ContEnt-lOcAtIoN") is True
    assert is_entity_header("Content-Location") is True
    assert is_entity_header("Content-location") is True
    assert is_entity_header("content-location") is True
    assert is_entity_header("Extension-header") is True
    assert is_entity_header("extension-header") is True



# Generated at 2022-06-24 03:56:11.308605
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type") == True
    assert is_entity_header("Content-TYPE") == True
    assert is_entity_header("Content-Type") == True
    assert is_entity_header("content-language") == True
    assert is_entity_header("allow") == True
    assert is_entity_header("conteNT-typE ") == True
    assert is_entity_header("asdfa") == False



# Generated at 2022-06-24 03:56:22.457861
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection") is True
    assert is_hop_by_hop_header("keep-alive") is True
    assert is_hop_by_hop_header("proxy-authenticate") is True
    assert is_hop_by_hop_header("proxy-authorization") is True
    assert is_hop_by_hop_header("te") is True
    assert is_hop_by_hop_header("trailers") is True
    assert is_hop_by_hop_header("transfer-encoding") is True
    assert is_hop_by_hop_header("upgrade") is True
    assert is_hop_by_hop_header("content-length") is False
    assert is_hop_by_hop_header("content-type") is False
    assert is_hop_by_hop_header

# Generated at 2022-06-24 03:56:24.954655
# Unit test for function import_string
def test_import_string():
    """Tests import_string function"""
    assert import_string("http.HTTPStatus") == HTTPStatus
    assert import_string("http.cookies.SimpleCookie")().__class__.__name__ == "SimpleCookie"

# Generated at 2022-06-24 03:56:29.814473
# Unit test for function import_string
def test_import_string():
    from .response import Response  # NOQA
    from .request import Request  # NOQA
    assert import_string("falcon.request.Request") is Request
    assert isinstance(import_string("falcon.response.Response"), Response)

# Generated at 2022-06-24 03:56:32.489868
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert is_entity_header("CONTENT-ENCODING")
    assert not is_entity_header("host")


# Generated at 2022-06-24 03:56:37.482087
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(400) == True

# Generated at 2022-06-24 03:56:39.885918
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(200)

# Generated at 2022-06-24 03:56:45.598359
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(200) == True


# Generated at 2022-06-24 03:56:55.518026
# Unit test for function has_message_body
def test_has_message_body():
    """
    HTTP status flags about message body
    1XX Informational
    2XX Success
    3XX Redirect
    4XX Client Error
    5XX Server Error
    """
    assert(has_message_body(100) == False)
    assert(has_message_body(199) == False)
    assert(has_message_body(200) == True)
    assert(has_message_body(301) == True)
    assert(has_message_body(400) == True)
    assert(has_message_body(500) == True)
    assert(has_message_body(204) == False)
    assert(has_message_body(304) == False)



# Generated at 2022-06-24 03:56:57.659567
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header('content-length') == True
    assert is_entity_header('hello') == False


# Generated at 2022-06-24 03:57:05.988148
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)

    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message_body(226)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_body(302)
    assert has_message_body(303)

# Generated at 2022-06-24 03:57:13.145006
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == True


# Generated at 2022-06-24 03:57:19.545834
# Unit test for function has_message_body
def test_has_message_body():
    """Unit tests for function has_message_body"""
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(203)
    assert has_message_body(400)



# Generated at 2022-06-24 03:57:21.775431
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Language")
    assert is_entity_header("content-md5")
    assert is_entity_header("Allow")
    assert not is_entity_header("Connection")



# Generated at 2022-06-24 03:57:31.909266
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    import pytest
    from werkzeug.datastructures import Headers
    headers = Headers()
    headers["Content-Type"] = "text/plain"
    headers["content-language"] = "en-US"
    headers["content-location"] = "/index.html"
    headers["expires"] = "0"
    headers["max-forwards"] = "10"
    headers["transfer-encoding"] = "chunked"
    headers["Connection"] = "close"
    headers["Proxy-Authenticate"] = "Basic"
    headers = remove_entity_headers(headers)
    assert "Content-Type" not in headers
    assert "content-language" not in headers
    assert headers["content-location"] == "/index.html"
    assert headers["expires"] == "0"

    headers = Headers()


# Generated at 2022-06-24 03:57:38.143590
# Unit test for function import_string
def test_import_string():
    """
    Test for import_string
    """
    from .test import test_http_utils
    import_string("falcon.test.test_http_utils")
    assert isinstance(import_string("falcon.test.test_http_utils.TestResource"), test_http_utils.TestResource)



# Generated at 2022-06-24 03:57:42.257356
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("content-length") is False
    assert is_hop_by_hop_header("Custom-Header") is False



# Generated at 2022-06-24 03:57:44.140431
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("not_connection") == False



# Generated at 2022-06-24 03:57:48.522351
# Unit test for function import_string
def test_import_string():
    # Import module
    import aiohttp

    # Import module
    assert import_string("aiohttp.web") == aiohttp.web

    # Import class
    from aiohttp.web import Application

    assert issubclass(import_string("aiohttp.web.Application"), Application)

    # Import instance
    inctance = import_string("aiohttp.web.Application")
    assert isinstance(inctance, Application)

# Generated at 2022-06-24 03:57:53.642834
# Unit test for function is_entity_header
def test_is_entity_header():
    # regular Entity header should return true
    assert is_entity_header("content-length")
    assert is_entity_header("Content-Length")
    # Hop By Hop header should return false
    assert not is_entity_header("connection")
    assert not is_entity_header("transfer-encoding")
    # Non-Entity header should return false
    assert not is_entity_header("server")


# Generated at 2022-06-24 03:57:55.541701
# Unit test for function import_string
def test_import_string():
    try:
        import_string("http.server.BaseHTTPRequestHandler")
    except ImportError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 03:58:07.992229
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Type")
    assert is_entity_header("Content-Length")
    assert is_entity_header("Content-Encoding")
    assert is_entity_header("Expires")
    assert is_entity_header("Content-language")
    assert is_entity_header("allow")
    assert is_entity_header("content-MD5")
    assert is_entity_header("content-range")
    assert is_entity_header("content-location")
    assert is_entity_header("Last-modified")
    assert is_entity_header("Extension-header")
    assert not is_entity_header("connection")
    assert not is_entity_header("Set-Cookie")
    assert not is_entity_header("something")
    assert not is_entity_header("Random-Header")

# Generated at 2022-06-24 03:58:12.137141
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(1)
    assert has_message_body(100)
    assert has_message_body(199)
    assert not has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)

# Generated at 2022-06-24 03:58:21.946386
# Unit test for function remove_entity_headers

# Generated at 2022-06-24 03:58:26.993381
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-length": "123",
        "content-encoding": "gzip",
        "content-type": "application/json",
        "content-location": "http://cocococococo.co",
        "expires": "123",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "content-location": "http://cocococococo.co",
        "expires": "123",
    }

# Generated at 2022-06-24 03:58:38.558743
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert (
        remove_entity_headers({"Last-Modified": "Fri, 01 Jan 2010 00:00:00 GMT"})
        == {}
    )
    assert (
        remove_entity_headers({"Last-Modified": "Fri, 01 Jan 2010 00:00:00 GMT"}, ("last-modified",))
        == {"Last-Modified": "Fri, 01 Jan 2010 00:00:00 GMT"}
    )
    assert (
        remove_entity_headers({"Last-Modified": "Fri, 01 Jan 2010 00:00:00 GMT"}, ("content-location",))
        == {}
    )

# Generated at 2022-06-24 03:58:48.041354
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    import pytest
    assert(is_hop_by_hop_header('connection'))
    assert(is_hop_by_hop_header('CONNECTION'))
    assert(is_hop_by_hop_header('Connection'))
    assert(not is_hop_by_hop_header('conection'))
    assert(not is_hop_by_hop_header('CONECTION'))
    assert(not is_hop_by_hop_header('Conection'))
    assert(not is_hop_by_hop_header('con'))
    assert(not is_hop_by_hop_header('CON'))
    assert(not is_hop_by_hop_header('Con'))
    with pytest.raises(TypeError):
        assert(is_hop_by_hop_header(None))

# Generated at 2022-06-24 03:58:52.663913
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Length": "100", "Expires": "value"}
    assert remove_entity_headers(headers) == {"Expires": "value"}
    headers = {"Content-Length": "100", "content-location": "value"}
    assert remove_entity_headers(headers) == {
        "content-location": "value"
    }
    headers = {"Content-Length": "100", "content-location": "value",
               "content-MD5": "test"}
    assert remove_entity_headers(headers) == {"content-location": "value"}

# Generated at 2022-06-24 03:58:56.534866
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    headers = ["Connection", "Keep-Alive", "Proxy-Authenticate", "Proxy-Authorization", "TE",
               "Trailers", "Transfer-Encoding", "Upgrade"]
    for h in headers:
        assert is_hop_by_hop_header(h)

# Generated at 2022-06-24 03:58:59.806333
# Unit test for function has_message_body
def test_has_message_body():
    message_body = has_message_body(200)
    assert message_body
    message_body = has_message_body(201)
    assert message_body
    message_body = has_message_body(204)
    assert not message_body
    message_body = has_message_body(304)
    assert not message_body
    message_body = has_message_body(100)
    assert not message_body

# Generated at 2022-06-24 03:59:07.624887
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    entity_headers = {
        "content-location": "a value",
        "expires": "a value",
        "Content-Location": "a value",
        "Expires": "a value",
        "content-Length": "a value",
        "content-language": "a value",
        "content-md5": "a value",
        "content-range": "a value",
        "content-type": "a value",
        "last-modified": "a value",
        "extension-header": "a value",
        "allow": "a value"
    }

    allowed = ["content-location", "expires", "content-Length"]

# Generated at 2022-06-24 03:59:13.587143
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    header = "connection"
    assert is_hop_by_hop_header(header)
    header = "proxy-authenticate"
    assert is_hop_by_hop_header(header)
    header = "connection"
    assert is_hop_by_hop_header(header)
    header = "connection"
    assert is_hop_by_hop_header(header)
    header = "Connection"
    assert is_hop_by_hop_header(header)


# Generated at 2022-06-24 03:59:21.226188
# Unit test for function import_string
def test_import_string():
    from quoridor.http import Request
    assert Request == import_string('quoridor.http.Request')
    from quoridor.contrib.auth.models import User
    assert User == import_string('quoridor.contrib.auth.models.User')
    instance = import_string('quoridor.contrib.auth.models.User')
    assert isinstance(instance, User)

# Generated at 2022-06-24 03:59:29.409538
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "content-Location": "/index.htm",
    }
    assert remove_entity_headers(headers) == headers
    assert remove_entity_headers(headers, ()) == {}

    headers = dict(headers)
    headers["content-type"] = "text/html"
    headers["Content-Length"] = "4821"
    assert remove_entity_headers(headers) == headers
    assert remove_entity_headers(headers, ()) == {}


# Generated at 2022-06-24 03:59:32.274594
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Type")
    assert is_entity_header("Content-Encoding")
    assert is_entity_header("Expires")
    assert not is_entity_header("Cache-Control")



# Generated at 2022-06-24 03:59:35.332992
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        b"CONTENT-TYPE": "application/json",
        b"EXPIRES": "Sat, 18 Nov 2019 12:57:31 GMT",
        b"CONNECTION": "keep-alive"
    }

    expected_headers = {
        b"EXPIRES": "Sat, 18 Nov 2019 12:57:31 GMT"
    }

    assert expected_headers == remove_entity_headers(headers)

# Generated at 2022-06-24 03:59:42.944639
# Unit test for function is_entity_header
def test_is_entity_header():
    """
    Tests the function is_entity_header.
    """
    for header in _ENTITY_HEADERS:
        assert is_entity_header(header)
    for header in ("content-encoding", "content-language"):
        assert is_entity_header(header)
    assert not is_entity_header("another-header")
    assert is_entity_header("extension-header")


# Generated at 2022-06-24 03:59:49.211125
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204), "Should not have a body"
    for status in (100, 101, 102, 200, 201, 205, 206, 207, 208, 226, 300, 301, 302, 303, 305, 307, 308,):
        assert has_message_body(status), "Should have a body"
    assert not has_message_body(204), "Should not have a body"
    assert not has_message_body(304), "Should not have a body"


# Generated at 2022-06-24 04:00:00.918123
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("keep-alive") == True
    assert is_hop_by_hop_header("Proxy-Authenticate") == True
    assert is_hop_by_hop_header("Proxy-Authorization") == True
    assert is_hop_by_hop_header("te") == True
    assert is_hop_by_hop_header("Trailers") == True
    assert is_hop_by_hop_header("Transfer-Encoding") == True
    assert is_hop_by_hop_header("Upgrade") == True

    assert is_hop_by_hop_header("content-length") == False
    assert is_hop_by_hop_header("content-type") == False



# Generated at 2022-06-24 04:00:09.826397
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("Keep-Alive") == True
    assert is_hop_by_hop_header("keep-alive") == True
    assert is_hop_by_hop_header("Proxy-Authenticate") == True
    assert is_hop_by_hop_header("proxy-authenticate") == True
    assert is_hop_by_hop_header("Proxy-Authorization") == True
    assert is_hop_by_hop_header("proxy-authorization") == True
    assert is_hop_by_hop_header("Te") == True
    assert is_hop_by_hop_header("TE") == True
    assert is_hop_by_hop_header

# Generated at 2022-06-24 04:00:18.016501
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-type": "text/plain",
        "content-length": "1",
        "content-encoding": "gzip",
        "expires": "Tue, 15 Jan 2014 21:47:38 GMT",
        "cache-control": "no-store",
    }
    expected = {
        "expires": "Tue, 15 Jan 2014 21:47:38 GMT",
        "cache-control": "no-store",
    }
    assert remove_entity_headers(headers) == expected
    assert remove_entity_headers(
        headers=headers, allowed=("content-location", "expires")
    ) == expected

    headers = {
        "content-type": "text/plain",
        "content-length": "1",
        "content-encoding": "gzip",
    }
   

# Generated at 2022-06-24 04:00:20.409361
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False

# Generated at 2022-06-24 04:00:25.428268
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    """Test that hop-by-hop-headers are recognized as such."""
    for header_name in _HOP_BY_HOP_HEADERS:
        if not is_hop_by_hop_header(header_name):
            assert False, "{} should be hop-by-hop".format(header_name)



# Generated at 2022-06-24 04:00:30.652650
# Unit test for function import_string
def test_import_string():
    string = "http.server.BaseHTTPRequestHandler"
    handler = import_string(string)
    assert handler
    assert issubclass(handler, BaseHTTPRequestHandler)
    assert handler is not BaseHTTPRequestHandler
    handler = import_string("http.server.SimpleHTTPRequestHandler")
    assert handler
    assert issubclass(handler, SimpleHTTPRequestHandler)
    assert handler is not SimpleHTTPRequestHandler



# Generated at 2022-06-24 04:00:35.201519
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(404)
    assert has_message_body(500)
    assert not has_message_body(304)
    assert not has_message_body(304)
    assert not has_message_body(100)



# Generated at 2022-06-24 04:00:37.558773
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-length")
    assert not is_entity_header("new-header-test")


# Generated at 2022-06-24 04:00:38.151807
# Unit test for function import_string
def test_import_string():
    from os import pat

# Generated at 2022-06-24 04:00:40.744941
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header('connection') is False
    assert is_entity_header('Content-Language') is True

# Generated at 2022-06-24 04:00:52.154468
# Unit test for function import_string
def test_import_string():
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.views import CompositionView

    assert import_string("sanic.server.HttpProtocol") == HttpProtocol
    assert import_string("sanic.server.HttpProtocol")() == HttpProtocol()

    assert import_string("sanic.websocket.WebSocketProtocol") == \
        WebSocketProtocol
    assert import_string("sanic.websocket.WebSocketProtocol")() == \
        WebSocketProtocol()

    assert import_string("sanic.app.Sanic") == Sanic

# Generated at 2022-06-24 04:00:55.470614
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == True
    assert has_message_body(200) == True
    assert has_message_body(404) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False



# Generated at 2022-06-24 04:01:01.064275
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("CONNECTION")
    assert is_hop_by_hop_header("CoNnEcTiOn")
    assert not is_hop_by_hop_header("Content-Type")
    assert not is_hop_by_hop_header("Content-type")
    assert not is_hop_by_hop_header("content-type")
    assert not is_hop_by_hop_header("CONTEnt - TyPE")


# Generated at 2022-06-24 04:01:09.902548
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(200)
    assert not has_message_body(304)
    assert not has_message_body(204)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert has_message_body(1)
    assert has_message_body(400)
    assert has_message_body(494)
    assert has_message_body(494)
    assert has_message_body(599)


# Generated at 2022-06-24 04:01:18.798827
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Type": "text/html", "Content-Length": "0"}
    new_headers = remove_entity_headers(headers)
    assert "content-type" not in new_headers
    assert "content-length" not in new_headers
    assert "content-location" not in new_headers
    assert "expires" not in new_headers
    assert "allow" not in new_headers
    assert "content-encoding" not in new_headers
    assert "content-language" not in new_headers
    assert "content-location" not in new_headers
    assert "content-md5" not in new_headers
    assert "content-range" not in new_headers
    assert "last-modified" not in new_headers
    assert "extension-header" not in new_headers
