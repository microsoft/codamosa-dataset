

# Generated at 2022-06-18 05:28:14.722903
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHTTP") == test_http.TestHTTP
    assert import_string("http.test_http.TestHTTP")() == test_http.TestHTTP()

# Generated at 2022-06-18 05:28:19.646663
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(299)


# Generated at 2022-06-18 05:28:25.867678
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)


# Generated at 2022-06-18 05:28:31.950215
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__

# Generated at 2022-06-18 05:28:37.047040
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Allow": "GET, POST, HEAD",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Length": "348",
        "Content-Location": "index.htm",
        "Content-MD5": "Q2hlY2sgSW50ZWdyaXR5IQ==",
        "Content-Range": "bytes 21010-47021/47022",
        "Content-Type": "text/html",
        "Expires": "Tue, 04 Dec 2018 12:45:26 GMT",
        "Last-Modified": "Tue, 04 Dec 2018 12:45:26 GMT",
        "Extension-Header": "My-Extension: My-Value",
    }

# Generated at 2022-06-18 05:28:41.594965
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:28:46.356670
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").test_method() == "test"
    assert import_string("falcon.test_utils.TestClass").test_method_2() == "test2"

# Generated at 2022-06-18 05:28:57.216254
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(300)
    assert has_message_body(400)
    assert has_message_body(500)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert not has_message_body(201)
    assert not has_message_body(202)
    assert not has_message_body(203)

# Generated at 2022-06-18 05:29:00.459432
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:29:02.868051
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:07.450258
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert isinstance(import_string("falcon.http.Response"), http.Response)

# Generated at 2022-06-18 05:29:18.638632
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    expected = {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    assert remove_entity_headers

# Generated at 2022-06-18 05:29:28.312162
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:32.987609
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__
    assert import_string("http.http.HTTP").__class__.__name__ == "HTTP"

# Generated at 2022-06-18 05:29:43.060855
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-length": "10",
        "content-type": "text/html",
        "content-encoding": "gzip",
        "content-language": "en",
        "content-location": "http://localhost/",
        "expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "last-modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "extension-header": "foo",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "content-location": "http://localhost/",
        "expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:48.410695
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHTTP") == test_http.TestHTTP
    assert import_string("http.test_http.TestHTTP")() == test_http.TestHTTP()

# Generated at 2022-06-18 05:29:51.640263
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")().__class__.__name__ == "Response"

# Generated at 2022-06-18 05:29:58.736153
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:30:04.467217
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:30:13.965006
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestImportString(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.old_path = sys.path[:]
            sys.path.insert(0, self.tempdir)

        def tearDown(self):
            sys.path = self.old_path
            shutil.rmtree(self.tempdir)

        def test_import_string(self):
            module_name = "test_module"
            module_path = os.path.join(self.tempdir, module_name + ".py")
            with open(module_path, "w") as f:
                f.write("def test():\n    return 'test'")


# Generated at 2022-06-18 05:30:17.233106
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:19.310493
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:24.835824
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.get_body") == http.get_body
    assert import_string("falcon.http.get_header") == http.get_header
    assert import_string("falcon.http.get_headers") == http.get_headers
    assert import_string("falcon.http.get_param") == http.get_param

# Generated at 2022-06-18 05:30:27.509384
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:30.663224
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:37.188195
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response
    assert import_string("falcon.http.Response").__class__.__name__ == "Response"

# Generated at 2022-06-18 05:30:40.503786
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.HTTPStatus") is http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK is http.HTTPStatus.OK

# Generated at 2022-06-18 05:30:45.920826
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:50.379235
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:54.086055
# Unit test for function import_string
def test_import_string():
    from .test_http import TestHttp
    assert import_string("http.test_http.TestHttp") == TestHttp
    assert import_string("http.test_http.TestHttp")() == TestHttp()

# Generated at 2022-06-18 05:31:01.614613
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request").__class__ is http.Request
    assert import_string("falcon.http.Response").__class__ is http.Response

# Generated at 2022-06-18 05:31:05.584496
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:07.090288
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:31:10.461126
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:19.620881
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import importlib.util
    import importlib.machinery
    importlib.invalidate_caches()
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the temporary module
    module_name = "test_module"
    module_path = os.path.join(tmp_dir, module_name + ".py")
    with open(module_path, "w") as f:
        f.write("class TestClass:\n")
        f.write("    def __init__(self):\n")
        f.write("        self.test_var = 'test_var'\n")
        f.write("    def test_method(self):\n")

# Generated at 2022-06-18 05:31:22.653283
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:31.266016
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(tmp_dir, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_file = os.path.join(package_dir, "mymodule.py")
    with open(module_file, "w") as f:
        f.write("class MyClass:\n    pass\n")
    # Add the directory to the python path
    sys.path.append(tmp_dir)
    # Import the module
    module = import_string("mypackage.mymodule")
    # Remove the directory from python path

# Generated at 2022-06-18 05:31:34.858897
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response").__name__ == "Response"

# Generated at 2022-06-18 05:31:38.879010
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http") == http
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:31:41.260993
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()

# Generated at 2022-06-18 05:31:52.600635
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response
    assert import_string("falcon.http.Response").__class__.__name__ == "Response"
    assert import_string("falcon.http.Response").__class__.__module__ == "falcon.http"
    assert import_string("falcon.http") == http
    assert import_string("falcon.http").__class__ == module
    assert import_string("falcon.http").__class__.__name__ == "module"
    assert import_string("falcon.http").__class__.__module__ == "builtins"
    assert import_string("falcon.http").__class__.__module__ == "builtins"

# Generated at 2022-06-18 05:31:56.686276
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus(200) == import_string("http.http.HTTPStatus")

# Generated at 2022-06-18 05:32:00.995917
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:02.643543
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:32:06.361318
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")().status == "200 OK"

# Generated at 2022-06-18 05:32:08.670637
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:14.934130
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    importlib.invalidate_caches()
    tmpdir = tempfile.mkdtemp()
    sys.path.insert(0, tmpdir)

# Generated at 2022-06-18 05:32:19.190280
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:24.549721
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:32:26.651994
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:33.492298
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:36.937428
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function
    """
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP

# Generated at 2022-06-18 05:32:42.617662
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:32:45.495697
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert isinstance(import_string("falcon.http.Response"), http.Response)

# Generated at 2022-06-18 05:32:54.128098
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a test package
    tmp_dir = tempfile.mkdtemp()
    sys.path.insert(0, tmp_dir)

# Generated at 2022-06-18 05:32:56.436239
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    from .http_error import HTTPError
    assert isinstance(import_string("falcon.http_error.HTTPError"), HTTPError)

# Generated at 2022-06-18 05:32:59.198925
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert isinstance(import_string("falcon.http.HTTPStatus"), http.HTTPStatus)

# Generated at 2022-06-18 05:33:03.396583
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:33:05.645052
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:09.245559
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:17.956592
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Request")() == http.Request()

# Generated at 2022-06-18 05:33:20.015329
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:23.614529
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:33:25.609712
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:33.908213
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:33:38.159881
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:33:41.623072
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:33:45.666024
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:33:47.597488
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:50.208273
# Unit test for function import_string
def test_import_string():
    from aiohttp import web
    assert import_string("aiohttp.web") == web
    assert isinstance(import_string("aiohttp.web.Application"), web.Application)

# Generated at 2022-06-18 05:34:07.879405
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string

# Generated at 2022-06-18 05:34:10.040869
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:34:14.028451
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__.__name__ == "TestClass"

# Generated at 2022-06-18 05:34:18.231130
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:22.784684
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:34:29.167438
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the temporary project
    project = os.path.join(tmpdir, "project")
    os.mkdir(project)
    # Create the temporary package
    package = os.path.join(project, "package")
    os.mkdir(package)
    # Create the temporary module
    module = os.path.join(package, "module.py")
    with open(module, "w") as f:
        f.write("class Test: pass")
    # Add the directory to the python path
    sys.path.append(project)
    # Test the import
    assert import_string("package.module.Test")
    # Remove the directory from the python path
    sys

# Generated at 2022-06-18 05:34:35.152676
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request").__class__ == http.Request
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:34:42.991893
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.Media") == http.Media
    assert import_string("falcon.http.RequestOptions") == http.RequestOptions
    assert import_string("falcon.http.ResponseOptions") == http.ResponseOptions
    assert import_string("falcon.http.Stream") == http.Stream
    assert import_string("falcon.http.WSGIInput")

# Generated at 2022-06-18 05:34:44.329471
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:46.322824
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:35:05.192678
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")().__class__.__name__ == "Request"

# Generated at 2022-06-18 05:35:16.287541
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection") == import_module("http.client").HTTPConnection
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__class__.__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__qualname__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__class__.__qualname__ == "HTTPConnection"

# Generated at 2022-06-18 05:35:18.740302
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:35:22.076930
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response").__class__ is http.Response


# Generated at 2022-06-18 05:35:24.716244
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus")() == http.HTTPStatus()

# Generated at 2022-06-18 05:35:27.276306
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:35:30.778202
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:35:34.355228
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:35:44.376081
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestImportString(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.syspath = sys.path[:]
            sys.path.insert(0, self.tmpdir)

        def tearDown(self):
            sys.path = self.syspath
            shutil.rmtree(self.tmpdir)

        def test_import_module(self):
            module_name = "test_module"
            module_path = os.path.join(self.tmpdir, module_name + ".py")
            with open(module_path, "w") as f:
                f.write("")
            module = import_string(module_name)


# Generated at 2022-06-18 05:35:47.535567
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__.__name__ == "TestClass"