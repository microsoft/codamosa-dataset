

# Generated at 2022-06-18 05:28:25.827548
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert not has_message_body(205)
    assert not has_message_body(206)
    assert not has_message_body(207)
    assert not has_message_body(208)
    assert not has_message_body(226)
    assert not has_message_body(300)

# Generated at 2022-06-18 05:28:31.943761
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(400) == True
    assert has_message_body(500) == True


# Generated at 2022-06-18 05:28:36.563218
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Last-Modified": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
    }

# Generated at 2022-06-18 05:28:45.074813
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:28:48.163517
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:28:52.163479
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Last-Modified": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
    }

# Generated at 2022-06-18 05:28:55.634977
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:58.488095
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:29:01.008736
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:08.965407
# Unit test for function remove_entity_headers

# Generated at 2022-06-18 05:29:20.560673
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.HTTPStatus") is http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK is http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").BAD_REQUEST is http.HTTPStatus.BAD_REQUEST
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND is http.HTTPStatus.NOT_FOUND
    assert import_string("falcon.http.HTTPStatus").METHOD_NOT_ALLOWED is http.HTTPStatus.METHOD_NOT_ALLOWED
    assert import_string("falcon.http.HTTPStatus").UNSUPPORTED_MEDIA_TYPE is http.HTTPStatus.UNSUPPORTED_MEDIA_TYPE

# Generated at 2022-06-18 05:29:24.587741
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:27.965545
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:31.712806
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:29:34.028147
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:43.098750
# Unit test for function import_string
def test_import_string():
    from .router import Router
    from .middleware import Middleware
    from .server import Server
    from .request import Request
    from .response import Response
    from .http_parser import HttpParser

    assert import_string("http.router.Router") == Router
    assert import_string("http.middleware.Middleware") == Middleware
    assert import_string("http.server.Server") == Server
    assert import_string("http.request.Request") == Request
    assert import_string("http.response.Response") == Response
    assert import_string("http.http_parser.HttpParser") == HttpParser

# Generated at 2022-06-18 05:29:46.322264
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:51.966090
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:55.563056
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:30:03.053059
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the temporary module
    module_name = "temp_module"
    module_path = os.path.join(tmpdir, module_name + ".py")
    with open(module_path, "w") as f:
        f.write("class TempClass:\n")
        f.write("    pass\n")

    # Add the directory to the python path
    sys.path.append(tmpdir)

    # Import the module
    module = import_string(module_name)
    assert ismodule(module)

    # Import the class
    klass = import_string(module_name + ".TempClass")
    assert isinstance(klass, module.TempClass)



# Generated at 2022-06-18 05:30:08.382574
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:30:12.496023
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon") == import_module("falcon")

# Generated at 2022-06-18 05:30:15.680198
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:22.742625
# Unit test for function import_string
def test_import_string():
    import_string("http.client")
    import_string("http.client.HTTPResponse")
    import_string("http.client.HTTPResponse", package="http")
    import_string("http.client.HTTPResponse", package="http.client")
    import_string("http.client.HTTPResponse", package="http.client.HTTPResponse")
    import_string("http.client.HTTPResponse", package="http.client.HTTPResponse.HTTPResponse")
    import_string("http.client.HTTPResponse", package="http.client.HTTPResponse.HTTPResponse.HTTPResponse")

# Generated at 2022-06-18 05:30:26.938534
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("aiohttp.http")
    assert http.HttpVersion11 == import_string("aiohttp.http.HttpVersion11")
    assert http.HttpVersion11() == import_string("aiohttp.http.HttpVersion11")

# Generated at 2022-06-18 05:30:30.080229
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:40.322083
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string(".http", package="falcon") == http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:30:47.451936
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:30:54.840165
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock

    class TestImportString(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            sys.path.append(self.tmpdir)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)
            sys.path.remove(self.tmpdir)

        def test_import_string_module(self):
            module_name = "test_module"
            module_path = os.path.join(self.tmpdir, module_name + ".py")
            with open(module_path, "w") as f:
                f.write("")
            module = import_string(module_name)


# Generated at 2022-06-18 05:31:01.769430
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function
    """
    from pytest import raises
    from .exceptions import ImproperlyConfigured

    with raises(ImproperlyConfigured):
        import_string("tests.test_http.test_import_string")

    assert import_string("tests.test_http.test_import_string") == test_import_string

    from .exceptions import HttpError
    assert isinstance(import_string("tests.exceptions.HttpError"), HttpError)