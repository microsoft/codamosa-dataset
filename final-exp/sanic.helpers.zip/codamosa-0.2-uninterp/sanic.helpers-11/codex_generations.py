

# Generated at 2022-06-18 05:28:09.398182
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:28:17.144097
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:28:20.488262
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:28:22.637445
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:28:29.386219
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function
    """
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()

# Generated at 2022-06-18 05:28:33.401970
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHttp") == test_http.TestHttp
    assert import_string("http.test_http.TestHttp")() == test_http.TestHttp()

# Generated at 2022-06-18 05:28:45.455544
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }

# Generated at 2022-06-18 05:28:54.134830
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create the temporary package
    package_dir = os.path.join(tmp_dir, "mypackage")
    os.mkdir(package_dir)

    # Create the module
    module_path = os.path.join(package_dir, "module.py")
    with open(module_path, "w") as module:
        module.write("class MyClass:\n")
        module.write("    pass\n")

    # Add the directory to the path
    sys.path.insert(0, tmp_dir)

    # Import the module
    module = import_string("mypackage.module")

    # Test the module

# Generated at 2022-06-18 05:29:03.600693
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message_body(226)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_body(302)
    assert has_message_body(303)
    assert not has_message_body(304)
    assert has_message_body(305)
    assert has_message_body(307)
    assert has_message_body(308)

# Generated at 2022-06-18 05:29:08.203733
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response", "falcon")() == http.Response()

# Generated at 2022-06-18 05:29:11.972676
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:29:14.154559
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:29:22.716684
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.get_body") == http.get_body
    assert import_string("falcon.http.get_header") == http.get_header
    assert import_string("falcon.http.parse_header_val") == http.parse_header_val
    assert import_string("falcon.http.parse_query_string") == http.parse_query_string

# Generated at 2022-06-18 05:29:25.305001
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:31.313473
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request

# Generated at 2022-06-18 05:29:34.508204
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:38.900959
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:42.007791
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HttpProtocol == import_string("http.http.HttpProtocol")
    assert http.HttpProtocol() == import_string("http.http.HttpProtocol")

# Generated at 2022-06-18 05:29:43.538716
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:49.020862
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from test_import_string import TestClass
    assert import_string("test_import_string.TestClass") == TestClass
    assert import_string("test_import_string.TestClass").test() == "test"

# Generated at 2022-06-18 05:29:55.756109
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp()
    os.close(fd)

    # Write the following python code to the temporary file

# Generated at 2022-06-18 05:29:59.870718
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:30:01.950194
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:05.094878
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:07.132285
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:09.862450
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()
    assert import_string("falcon.test_app") == test_app

# Generated at 2022-06-18 05:30:12.443445
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:14.943282
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:18.704864
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:20.608122
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:27.593185
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http") == http


# Generated at 2022-06-18 05:30:30.698980
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:42.015315
# Unit test for function import_string
def test_import_string():
    import sys
    from pathlib import Path
    from importlib import reload
    from importlib.util import spec_from_file_location, module_from_spec

    # Create a module
    path = Path(__file__).parent / "test_import_string.py"
    spec = spec_from_file_location("test_import_string", str(path))
    module = module_from_spec(spec)
    spec.loader.exec_module(module)

    # Import module
    module_imported = import_string("test_import_string")
    assert module_imported.__name__ == "test_import_string"

    # Import class
    class_imported = import_string("test_import_string.TestClass")
    assert class_imported.__class__.__name__ == "TestClass"

   

# Generated at 2022-06-18 05:30:45.874608
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:30:50.044056
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string
    """
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")



# Generated at 2022-06-18 05:30:53.120645
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:55.384868
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:30:59.006927
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:01.454625
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:06.320694
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__

# Generated at 2022-06-18 05:31:19.097674
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_

# Generated at 2022-06-18 05:31:22.424159
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:31:25.430738
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:30.053597
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:31:33.350013
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:31:41.467600
# Unit test for function import_string
def test_import_string():
    import sys
    from os import path
    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
    from aiohttp import web
    from aiohttp.web import Application
    from aiohttp.web import Request
    from aiohttp.web import Response
    from aiohttp.web import StreamResponse
    from aiohttp.web import json_response
    from aiohttp.web import FileResponse
    from aiohttp.web import Response
    from aiohttp.web import HTTPException
    from aiohttp.web import HTTPNotFound
    from aiohttp.web import HTTPMethodNotAllowed
    from aiohttp.web import HTTPForbidden
    from aiohttp.web import HTTPBadRequest
    from aiohttp.web import HTTPInternalServerError

# Generated at 2022-06-18 05:31:44.773500
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:47.589261
# Unit test for function import_string
def test_import_string():
    from . import test_utils
    assert import_string("falcon.test_utils.TestClass") == test_utils.TestClass()
    assert import_string("falcon.test_utils") == test_utils

# Generated at 2022-06-18 05:31:50.915219
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:31:52.620116
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:32:01.992897
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")().status == "200 OK"

# Generated at 2022-06-18 05:32:06.886299
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:32:11.818906
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") != http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:32:19.905728
# Unit test for function import_string
def test_import_string():
    import sys
    from types import ModuleType
    from types import FunctionType
    from types import BuiltinFunctionType
    from types import MethodType
    from types import BuiltinMethodType
    from types import CodeType
    from types import FrameType
    from types import TracebackType
    from types import GeneratorType
    from types import CoroutineType
    from types import AsyncGeneratorType
    from types import AsyncIterableType
    from types import AsyncIteratorType
    from types import ClassMethodDescriptorType
    from types import GetSetDescriptorType
    from types import MemberDescriptorType
    from types import MethodDescriptorType
    from types import ModuleType
    from types import WrapperDescriptorType
    from types import DynamicClassAttribute
    from types import NotImplementedType
    from types import EllipsisType

# Generated at 2022-06-18 05:32:23.042071
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:32:33.492570
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    def create_module(name, content):
        module_dir = tempfile.mkdtemp()
        module_path = os.path.join(module_dir, name + ".py")
        with open(module_path, "w") as f:
            f.write(content)
        sys.path.insert(0, module_dir)
        return module_dir

    def remove_module(module_dir):
        sys.path.remove(module_dir)
        shutil.rmtree(module_dir)

    def test_import_module():
        module_dir = create_module("test_module", "")
        module = import_string("test_module")
        assert module.__name__ == "test_module"
       

# Generated at 2022-06-18 05:32:35.719035
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:38.162765
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:42.957540
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()

# Generated at 2022-06-18 05:32:45.764414
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:32:53.059586
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:56.040163
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:33:00.419296
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_import_string import TestClass
    assert import_string("test_import_string.TestClass") == TestClass
    assert import_string("test_import_string.TestClass").test() == "test"

# Generated at 2022-06-18 05:33:04.728288
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:33:07.565548
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()

# Generated at 2022-06-18 05:33:10.252643
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()
    assert import_string("falcon.test_app") == test_app

# Generated at 2022-06-18 05:33:12.158979
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:14.976054
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:33:19.575576
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__.__name__ == "TestClass"

# Generated at 2022-06-18 05:33:23.120510
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:33:33.111024
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:33:37.338032
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:33:40.953650
# Unit test for function import_string
def test_import_string():
    from . import test_server
    assert import_string("http.server.test_server.TestServer") == test_server.TestServer
    assert import_string("http.server.test_server") == test_server

# Generated at 2022-06-18 05:33:45.168424
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK

# Generated at 2022-06-18 05:33:53.420529
# Unit test for function import_string
def test_import_string():
    from importlib import import_module
    from inspect import ismodule
    from typing import Dict

    assert import_string("http.HTTPStatus") == import_module("http").HTTPStatus
    assert ismodule(import_string("http.HTTPStatus"))
    assert import_string("http.HTTPStatus").__name__ == "HTTPStatus"
    assert import_string("http.HTTPStatus").__module__ == "http"

    assert import_string("http.cookies.SimpleCookie") == import_module("http.cookies").SimpleCookie
    assert not ismodule(import_string("http.cookies.SimpleCookie"))
    assert import_string("http.cookies.SimpleCookie").__name__ == "SimpleCookie"
    assert import_string("http.cookies.SimpleCookie").__module__ == "http.cookies"

   

# Generated at 2022-06-18 05:33:56.022297
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:33:58.138867
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:34:03.219583
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:34:07.291956
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")().status == "200 OK"

# Generated at 2022-06-18 05:34:13.443439
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection") == import_module("http.client").HTTPConnection
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__class__.__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__bases__ == (object,)
    assert import_string("http.client.HTTPConnection").__class__.__dict__ == {"__module__": "http.client", "__doc__": None}

# Generated at 2022-06-18 05:34:33.148095
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:34:41.406586
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    def create_module(name, content):
        path = os.path.join(tempfile.gettempdir(), name)
        with open(path, "w") as f:
            f.write(content)
        sys.path.append(tempfile.gettempdir())
        return path

    def remove_module(path):
        sys.path.remove(tempfile.gettempdir())
        os.remove(path)

    def test_import_module():
        path = create_module("test_module.py", "")
        assert import_string("test_module")
        remove_module(path)

    def test_import_class():
        path = create_module("test_class.py", "class TestClass: pass")
        assert import_string

# Generated at 2022-06-18 05:34:44.737841
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:34:47.858135
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:34:51.049218
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:34:53.265808
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:56.217625
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:34:59.115098
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request")
    assert import_string("falcon.http.Response")

# Generated at 2022-06-18 05:35:01.538854
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    from .http import HttpProtocol
    assert HttpProtocol == import_string("http.http.HttpProtocol")
    assert HttpProtocol() == import_string("http.http.HttpProtocol")

# Generated at 2022-06-18 05:35:04.139220
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:35:36.788838
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:35:40.544207
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:35:43.128820
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:35:45.091752
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:35:46.899990
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:35:49.746872
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:35:52.188383
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:35:55.950473
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:36:05.240462
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response.__class__
    assert import_string("falcon.http.Response").__class__ == http.Response.__class__
    assert import_string("falcon.http.Request").__class__ == http.Request.__class__
    assert import_string("falcon.http.Request").__class__ == http.Request.__class__
    assert import_string("falcon.http") == http
    assert import_string("falcon.http").__class__ == http.__class__
    assert import_string("falcon.http").__class__ == http.__class__

# Generated at 2022-06-18 05:36:07.859850
# Unit test for function import_string
def test_import_string():
    from . import http
    from . import http_parser
    assert import_string("http.http") == http
    assert import_string("http.http_parser") == http_parser
    assert import_string("http.http_parser.HttpParser") == http_parser.HttpParser

# Generated at 2022-06-18 05:37:24.402126
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:37:27.780608
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK

# Generated at 2022-06-18 05:37:30.639286
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:37:32.658605
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:37:36.176759
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").test_method() == "test"

# Generated at 2022-06-18 05:37:39.811119
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:37:41.358371
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:37:50.509519
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_

# Generated at 2022-06-18 05:37:59.511442
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    from importlib import reload
    from importlib.util import spec_from_file_location, module_from_spec

    # Create a temporary directory
    temp_dir_path = tempfile.mkdtemp()
    # Create the temporary module file
    module_file_path = os.path.join(temp_dir_path, "temp_module.py")
    with open(module_file_path, "w") as module_file:
        module_file.write("class TempClass:\n")
        module_file.write("    pass\n")
    # Create the temporary package directory
    package_dir_path = os.path.join(temp_dir_path, "temp_package")
    os.mkdir(package_dir_path)

# Generated at 2022-06-18 05:38:02.457229
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response", package="falcon")() == http.Response()