

# Generated at 2022-06-18 05:28:05.878890
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:14.456829
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    assert remove_entity_headers(headers) == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    assert remove_entity_headers(headers, allowed=()) == {}

# Generated at 2022-06-18 05:28:20.335557
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_METHODS") == http.HTTP_METHODS
    assert import_string("falcon.http.STATUS_CODES") == http.STATUS_CODES
    assert import_string("falcon.http.has_message_body") == http.has_message_body
    assert import_string("falcon.http.is_entity_header") == http.is_entity_header
    assert import_string("falcon.http.is_hop_by_hop_header") == http.is_hop_by_hop_header

# Generated at 2022-06-18 05:28:24.833408
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(400) == True
    assert has_message_body(500) == True


# Generated at 2022-06-18 05:28:34.240642
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "123",
        "Content-Type": "text/html",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "foo",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:28:45.828894
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "123",
        "Content-Type": "text/html",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "http://example.com/index.htm",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Last-Modified": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Extension-Header": "FooBar",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "http://example.com/index.htm",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Extension-Header": "FooBar",
    }

# Generated at 2022-06-18 05:28:47.625688
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response


# Generated at 2022-06-18 05:28:51.671366
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:59.957191
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-length": "10",
        "content-location": "http://example.com/",
        "content-type": "text/html",
        "expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "last-modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "content-location": "http://example.com/",
        "expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:07.994807
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    expected = {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    assert remove_entity_headers(headers) == expected

# Generated at 2022-06-18 05:29:11.477711
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:14.306653
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:29:19.396291
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHttp") == test_http.TestHttp
    assert isinstance(import_string("http.test_http.TestHttp"), test_http.TestHttp)

# Generated at 2022-06-18 05:29:30.893318
# Unit test for function import_string
def test_import_string():
    import_string("http.server")
    import_string("http.server.HTTPServer")
    import_string("http.server.HTTPServer", package="http")
    import_string("http.server.HTTPServer", package="http.server")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer.HTTPServer")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer.HTTPServer.HTTPServer")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer.HTTPServer.HTTPServer.HTTPServer")

# Generated at 2022-06-18 05:29:38.413297
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestImportString(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            sys.path.append(self.tmpdir)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)
            sys.path.remove(self.tmpdir)

        def test_import_string_module(self):
            module_name = "test_module"
            module_path = os.path.join(self.tmpdir, module_name + ".py")
            with open(module_path, "w") as f:
                f.write("")
            module = import_string(module_name)

# Generated at 2022-06-18 05:29:41.530246
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert isinstance(import_string("falcon.http.Response"), http.Response)

# Generated at 2022-06-18 05:29:47.401416
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:50.487378
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:59.235536
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(tmp_dir, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_file = os.path.join(package_dir, "mymodule.py")
    with open(module_file, "w") as f:
        f.write("class MyClass(object):\n")
        f.write("    pass\n")
    # Add the directory to the python path
    sys.path.append(tmp_dir)
    # Import the module
    module = import_string("mypackage.mymodule")
    assert module.MyClass
    # Import the class

# Generated at 2022-06-18 05:30:01.376852
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response").__name__ == "Response"