

# Generated at 2022-06-18 05:28:16.033887
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES

# Generated at 2022-06-18 05:28:24.980642
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    expected = {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    assert remove_entity_headers(headers) == expected

# Generated at 2022-06-18 05:28:31.716512
# Unit test for function import_string
def test_import_string():
    from . import test_http
    import_string("falcon.test_http")
    import_string("falcon.test_http.TestCase")
    import_string("falcon.test_http.TestCase").__class__.__name__ == "TestCase"
    import_string("falcon.test_http.TestCase").__class__.__module__ == "falcon.test_http"

# Generated at 2022-06-18 05:28:38.045847
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response")

# Generated at 2022-06-18 05:28:43.965726
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:53.023058
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message

# Generated at 2022-06-18 05:29:01.377669
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:04.958806
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string
    """
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:29:14.036602
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    expected = {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    result = remove_entity_headers(headers)
    assert result == expected

# Generated at 2022-06-18 05:29:19.759759
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:25.209517
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:29:30.112259
# Unit test for function import_string
def test_import_string():
    from .middlewares import Middleware
    from .middlewares import SimpleMiddleware
    assert import_string("falcon.middlewares.Middleware") == Middleware
    assert import_string("falcon.middlewares.SimpleMiddleware") == SimpleMiddleware
    assert import_string("falcon.middlewares.SimpleMiddleware").__class__ == SimpleMiddleware

# Generated at 2022-06-18 05:29:32.720541
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("aiohttp.http")
    assert http.HttpVersion11 == import_string("aiohttp.http.HttpVersion11")

# Generated at 2022-06-18 05:29:39.385579
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)
    assert import_string("falcon.http.Response") is http.Response
    assert isinstance(import_string("falcon.http.Response"), http.Response)

# Generated at 2022-06-18 05:29:42.643554
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response

# Generated at 2022-06-18 05:29:45.144286
# Unit test for function import_string
def test_import_string():
    from aiohttp.web import Application
    assert import_string("aiohttp.web.Application") == Application
    assert import_string("aiohttp.web.Application").__class__ == Application
    assert import_string("aiohttp.web.Application").__class__.__name__ == "Application"
    assert import_string("aiohttp.web.Application").__class__.__module__ == "aiohttp.web"

# Generated at 2022-06-18 05:29:51.275545
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_import_string import TestClass
    assert import_string("test_import_string.TestClass") == TestClass
    assert import_string("test_import_string.TestClass").name == "TestClass"

# Generated at 2022-06-18 05:29:54.361055
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:29:56.575344
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:07.680054
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection") == import_module("http.client").HTTPConnection
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__name__ == "type"
    assert import_string("http.client.HTTPConnection").__class__.__module__ == "builtins"
    assert import_string("http.client.HTTPConnection").__class__.__bases__ == (object,)
    assert import_string("http.client.HTTPConnection").__class__.__dict__["__module__"] == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__dict__