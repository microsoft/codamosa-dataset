

# Generated at 2022-06-18 05:28:22.269045
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(202) == True
    assert has_message_body(203) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == True
    assert has_message_body(206) == True
    assert has_message_body(207) == True
    assert has_message_body(208) == True
    assert has_message_body(226) == True
    assert has_message_body(300) == True
    assert has_

# Generated at 2022-06-18 05:28:26.193670
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:28:36.197284
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(tmp_dir, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_file = os.path.join(package_dir, "mymodule.py")
    with open(module_file, "w") as f:
        f.write("class MyClass:\n")
        f.write("    pass\n")
    # Add the directory to the python path
    sys.path.append(tmp_dir)
    # Import the module
    module = import_string("mypackage.mymodule")
    # Check that the module is imported
   

# Generated at 2022-06-18 05:28:40.209066
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:28:44.639980
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(299)


# Generated at 2022-06-18 05:28:46.607542
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:28:58.630858
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    def _create_module(path, content):
        with open(path, "w") as f:
            f.write(content)

    def _create_package(path, content):
        os.mkdir(path)
        _create_module(os.path.join(path, "__init__.py"), content)

    def _create_class(path, content):
        _create_module(path, content)

    def _create_package_with_class(path, content):
        _create_package(path, content)
        _create_class(os.path.join(path, "test.py"), content)

    def _create_package_with_subpackage_with_class(path, content):
        _create_package

# Generated at 2022-06-18 05:29:02.310125
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:09.080774
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:19.972581
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.RequestOptions")()
    assert import_string("falcon.http.HTTPStatus")()
    assert import_string("falcon.http.HTTP_STATUS") == http.HTTP_STATUS
    assert import_string("falcon.http.HTTP_METHODS") == http.HTTP_METHODS
    assert import_string("falcon.http.MEDIA_JSON") == http.MEDIA_JSON
    assert import_string("falcon.http.MEDIA_MSGPACK") == http.MEDIA_MSGPACK
   

# Generated at 2022-06-18 05:29:24.109820
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:29:33.893922
# Unit test for function import_string
def test_import_string():
    from . import http
    from . import http_parser
    from . import http_protocol
    from . import http_request
    from . import http_response
    from . import http_server
    from . import http_stream
    from . import http_websocket
    from . import http_websocket_handler
    from . import http_websocket_server
    from . import http_websocket_stream
    from . import http_websocket_upgrade
    from . import http_websocket_upgrade_handler
    from . import http_websocket_upgrade_server
    from . import http_websocket_upgrade_stream
    from . import http_websocket_upgrade_websocket
    from . import http_websocket_websocket
    from . import http_websocket

# Generated at 2022-06-18 05:29:38.857327
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:40.936707
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:43.680083
# Unit test for function import_string
def test_import_string():
    from .test_http import TestHttp
    assert import_string("http.test_http.TestHttp") == TestHttp
    assert import_string("http.test_http.TestHttp").__class__ == TestHttp

# Generated at 2022-06-18 05:29:50.355438
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:29:59.134575
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response

# Generated at 2022-06-18 05:30:09.149477
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestImportString(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.sys_path = sys.path[:]
            sys.path.insert(0, self.test_dir)

        def tearDown(self):
            sys.path = self.sys_path
            shutil.rmtree(self.test_dir)

        def test_import_string(self):
            module_name = "test_module"
            module_path = os.path.join(self.test_dir, module_name + ".py")
            with open(module_path, "w") as f:
                f.write("")
            module = import_string

# Generated at 2022-06-18 05:30:11.972104
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    from .http import HttpProtocol
    assert isinstance(import_string("http.http.HttpProtocol"), HttpProtocol)

# Generated at 2022-06-18 05:30:15.271518
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:30:21.584577
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:24.342443
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:25.782310
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:28.580865
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:31.207747
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:35.280420
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:40.875532
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:30:46.323899
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:54.262259
# Unit test for function import_string
def test_import_string():
    import sys
    from types import ModuleType

    assert isinstance(import_string("sys"), ModuleType)
    assert isinstance(import_string("sys.version_info"), tuple)
    assert isinstance(import_string("sys.version_info.major"), int)
    assert isinstance(import_string("sys.version_info.minor"), int)
    assert isinstance(import_string("sys.version_info.micro"), int)
    assert isinstance(import_string("sys.version_info.releaselevel"), str)
    assert isinstance(import_string("sys.version_info.serial"), int)
    assert isinstance(import_string("sys.version_info.hexversion"), int)
    assert isinstance(import_string("sys.version_info.is_final"), bool)

# Generated at 2022-06-18 05:30:56.818480
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:03.138422
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") != http.Response
    assert import_string("falcon.http.Response") != http.Request

# Generated at 2022-06-18 05:31:08.252577
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:31:11.027978
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:15.041299
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:31:20.904831
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response.__class__
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response")().__class__ == http.Response().__class__
    assert import_string("falcon.http") == http
    assert import_string("falcon.http").__class__ == http.__class__

# Generated at 2022-06-18 05:31:26.350433
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:31:30.657891
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:34.217282
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:31:37.017409
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:40.919701
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:31:51.650778
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:55.182200
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:58.025998
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:32:06.922990
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection") == import_module("http.client").HTTPConnection
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__qualname__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__class__.__name__ == "type"
    assert import_string("http.client.HTTPConnection").__class__.__module__ == "builtins"
    assert import_string("http.client.HTTPConnection").__class__.__qualname__ == "type"
    assert import_string("http.client.HTTPConnection").__class__.__class__.__name__ == "type"


# Generated at 2022-06-18 05:32:10.989960
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:32:14.848861
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:32:25.977760
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response").__name__ == "Response"
    assert import_string("falcon.http.Response").__module__ == "falcon.http"
    assert import_string("falcon.http.Response").__qualname__ == "Response"
    assert import_string("falcon.http.Response").__class__.__name__ == "type"
    assert import_string("falcon.http.Response").__class__.__qualname__ == "type"
    assert import_string("falcon.http.Response").__class__.__module__ == "builtins"

# Generated at 2022-06-18 05:32:29.495137
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:33.492531
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").test_method() == "test"

# Generated at 2022-06-18 05:32:37.567114
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()