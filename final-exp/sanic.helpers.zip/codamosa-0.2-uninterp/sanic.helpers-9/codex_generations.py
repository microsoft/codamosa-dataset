

# Generated at 2022-06-18 05:28:22.021312
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message

# Generated at 2022-06-18 05:28:29.991744
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the temporary package
    tmp_package_dir = os.path.join(tmp_dir, "mypackage")
    os.mkdir(tmp_package_dir)
    # Create the module
    module_name = "mymodule"
    module_file = os.path.join(tmp_package_dir, module_name + ".py")
    with open(module_file, "w") as f:
        f.write("class MyClass:\n    pass\n")
    # Add the directory to the python path
    sys.path.append(tmp_dir)
    # Import the module
    module = import_string("mypackage.mymodule")


# Generated at 2022-06-18 05:28:34.578732
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND == http.HTTPStatus.NOT_FOUND

# Generated at 2022-06-18 05:28:43.241123
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:28:52.475284
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_path = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(tmp_path, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_path = os.path.join(package_dir, "mymodule.py")
    with open(module_path, "w") as module:
        module.write("class MyClass(object):\n")
        module.write("    pass\n")
    # Add the directory to the Python path
    sys.path.append(tmp_path)
    # Perform the import
    imported_module = import_string("mypackage.mymodule")
    assert imported_module

# Generated at 2022-06-18 05:29:02.480020
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    def create_module(name, content):
        path = os.path.join(tempdir, name)
        with open(path, "w") as f:
            f.write(content)
        return path

    def create_package(name, content):
        path = os.path.join(tempdir, name)
        os.mkdir(path)
        with open(os.path.join(path, "__init__.py"), "w") as f:
            f.write(content)
        return path

    def create_class(name, content):
        path = os.path.join(tempdir, name)
        with open(path, "w") as f:
            f.write(content)
        return path

   

# Generated at 2022-06-18 05:29:06.859010
# Unit test for function import_string
def test_import_string():
    from . import test_import_string
    assert test_import_string.__name__ == "test_import_string"
    assert test_import_string.__package__ == "httpcore"
    assert import_string("httpcore.test_import_string") == test_import_string
    assert import_string("httpcore.test_import_string.TestClass") == test_import_string.TestClass()

# Generated at 2022-06-18 05:29:15.613820
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND == http.HTTPStatus.NOT_FOUND
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND.value == http.HTTPStatus.NOT_FOUND.value
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND.phrase == http.HTTPStatus.NOT_FOUND.phrase

# Generated at 2022-06-18 05:29:19.832223
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request", "falcon") == http.Request
    assert import_string("falcon.http.Response", "falcon") == http.Response

# Generated at 2022-06-18 05:29:23.933721
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:28.696130
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:37.319987
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import importlib.util
    import importlib.machinery

    def create_module(module_name, content):
        """
        Create a module with the given name and content.
        """
        module_path = os.path.join(temp_dir, module_name + ".py")
        with open(module_path, "w") as f:
            f.write(content)
        return module_path

    def create_package(package_name, content):
        """
        Create a package with the given name and content.
        """
        package_path = os.path.join(temp_dir, package_name)
        os.mkdir(package_path)

# Generated at 2022-06-18 05:29:40.548182
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:29:43.020549
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:44.845096
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:49.818880
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:29:53.171101
# Unit test for function import_string
def test_import_string():
    """
    Test for function import_string
    """
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:55.920832
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:00.108153
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:04.408724
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp
    assert import_string("falcon.test_app") == test_app
    assert import_string("falcon.test_app.TestApp")() == test_app.TestApp()

# Generated at 2022-06-18 05:30:11.696151
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__.__name__ == "TestClass"

# Generated at 2022-06-18 05:30:15.354060
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response", "falcon")() == http.Response()

# Generated at 2022-06-18 05:30:17.514738
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:19.570515
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()


# Generated at 2022-06-18 05:30:30.868458
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.get_body") == http.get_body
    assert import_string("falcon.http.get_header") == http.get_header
    assert import_string("falcon.http.get_headers") == http.get_headers
    assert import_string("falcon.http.get_param") == http.get_param

# Generated at 2022-06-18 05:30:37.989655
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp
    assert import_string("falcon.test_app") == test_app
    assert import_string("falcon.test_app.TestApp", package="falcon") == test_app.TestApp
    assert import_string("falcon.test_app", package="falcon") == test_app

# Generated at 2022-06-18 05:30:41.132870
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:30:46.326929
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:30:50.298782
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:54.044506
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol") == HttpProtocol
    assert import_string("aiohttp.http") == http

# Generated at 2022-06-18 05:31:10.595754
# Unit test for function import_string
def test_import_string():
    import_string("http.server")
    import_string("http.server.HTTPServer")
    import_string("http.server.HTTPServer", package="http")
    import_string("http.server.HTTPServer", package="http.server")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer.HTTPServer")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer.HTTPServer.HTTPServer")
    import_string("http.server.HTTPServer", package="http.server.HTTPServer.HTTPServer.HTTPServer.HTTPServer")

# Generated at 2022-06-18 05:31:19.732585
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection") == import_module("http.client").HTTPConnection
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__class__.__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__class__.__bases__[0].__name__ == "HTTPBase"
    assert import_string("http.client.HTTPConnection").__class__.__bases__[0].__module__ == "http.client"

# Generated at 2022-06-18 05:31:22.475288
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") != http.Response
    assert import_string("falcon.http.Response") != http.Request
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:31:25.430627
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:31.221150
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:31:36.671472
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:31:39.069919
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:49.509821
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.HTTP_METHODS") == http.HTTP_METHODS
    assert import_string("falcon.http.MEDIA_JSON") == http.MEDIA_JSON
    assert import_string("falcon.http.MEDIA_MSGPACK") == http.MEDIA_MSGPACK
    assert import_string("falcon.http.MEDIA_YAML") == http.MEDIA_YAML
   

# Generated at 2022-06-18 05:31:52.071204
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:54.989538
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
