

# Generated at 2022-06-18 05:28:14.804562
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:28:20.396694
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    def create_module(path, content):
        with open(path, "w") as f:
            f.write(content)

    def create_package(path, content):
        os.mkdir(path)
        with open(os.path.join(path, "__init__.py"), "w") as f:
            f.write(content)

    def create_class(path, content):
        with open(path, "w") as f:
            f.write(content)

    def create_package_with_class(path, content):
        os.mkdir(path)
        with open(os.path.join(path, "__init__.py"), "w") as f:
            f.write(content)


# Generated at 2022-06-18 05:28:25.951510
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(300)
    assert has_message_body(400)
    assert has_message_body(500)



# Generated at 2022-06-18 05:28:31.948372
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__

# Generated at 2022-06-18 05:28:37.737963
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-location": "http://example.com/index.htm",
        "content-type": "text/html",
        "content-language": "en",
        "content-length": "348",
        "expires": "Tue, 04 Aug 2009 07:59:32 GMT",
        "last-modified": "Tue, 04 Aug 2009 07:58:32 GMT",
    }
    headers = remove_entity_headers(headers)
    assert "content-location" in headers
    assert "expires" in headers
    assert "content-type" not in headers
    assert "content-language" not in headers
    assert "content-length" not in headers
    assert "last-modified" not in headers

# Generated at 2022-06-18 05:28:42.573578
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:28:47.062244
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from http import HTTPStatus
    from http.server import BaseHTTPRequestHandler
    assert import_string("http.HTTPStatus") == HTTPStatus
    assert import_string("http.server.BaseHTTPRequestHandler") == BaseHTTPRequestHandler
    assert import_string("http.server.BaseHTTPRequestHandler")()

# Generated at 2022-06-18 05:28:58.630993
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Content-MD5": "Q2hlY2sgSW50ZWdyaXR5IQ==",
        "Content-Range": "bytes 21010-47021/47022",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Last-Modified": "Tue, 15 Nov 1994 12:45:26 GMT",
        "Extension-Header": "FooBar",
    }
    headers = remove_entity_headers(headers)

# Generated at 2022-06-18 05:29:05.910162
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:08.392837
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:12.223808
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:16.784546
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:19.550400
# Unit test for function import_string
def test_import_string():
    from aiohttp.web import Application
    app = import_string("aiohttp.web.Application")
    assert isinstance(app, Application)
    app = import_string("aiohttp.web.Application")
    assert isinstance(app, Application)

# Generated at 2022-06-18 05:29:24.066017
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:29:27.842609
# Unit test for function import_string
def test_import_string():
    """
    Test for function import_string
    """
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:30.487580
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:33.822227
# Unit test for function import_string
def test_import_string():
    from . import http
    from . import http_parser
    assert import_string("http.http") == http
    assert import_string("http.http_parser") == http_parser
    assert import_string("http.http_parser.HttpParser") == http_parser.HttpParser

# Generated at 2022-06-18 05:29:38.810217
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("falcon.http")
    assert http.Request == import_string("falcon.http.Request")
    assert http.Request() == import_string("falcon.http.Request")

# Generated at 2022-06-18 05:29:49.862705
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib
    import importlib.util
    import importlib.machinery

    def create_module(name, content):
        """
        Create a temporary module with the given name and content.
        """
        module_dir = tempfile.mkdtemp()
        module_file = os.path.join(module_dir, name + ".py")
        with open(module_file, "w") as f:
            f.write(content)
        sys.path.insert(0, module_dir)
        return module_dir

    def remove_module(module_dir):
        """
        Remove a temporary module.
        """
        sys.path.remove(module_dir)
        shutil.rmtree(module_dir)


# Generated at 2022-06-18 05:29:52.254879
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request


# Generated at 2022-06-18 05:29:58.006830
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response")() is not http.Response
    assert import_string("falcon.http.Response")() is not http.Response()

# Generated at 2022-06-18 05:30:02.652418
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHTTP") == test_http.TestHTTP
    assert import_string("http.test_http.TestHTTP")() == test_http.TestHTTP()

# Generated at 2022-06-18 05:30:05.182654
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:06.523627
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:08.422185
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:30:12.107362
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response", "falcon")() == http.Response()

# Generated at 2022-06-18 05:30:15.639283
# Unit test for function import_string
def test_import_string():
    from . import http
    from . import http_parser
    assert import_string("http.http") == http
    assert import_string("http.http_parser") == http_parser
    assert import_string("http.http_parser.HttpParser") == http_parser.HttpParser

# Generated at 2022-06-18 05:30:19.429201
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("http.http") == http
    assert import_string("http.http.HttpProtocol") == HttpProtocol
    assert import_string("http.http.HttpProtocol").__class__ == HttpProtocol

# Generated at 2022-06-18 05:30:23.937678
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") != http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:30:27.386175
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()
    assert import_string("falcon.test_app") == test_app

# Generated at 2022-06-18 05:30:42.213493
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http == import_string("http.http.http")
    assert http == import_string("http.http.http.http")
    assert http == import_string("http.http.http.http.http")
    assert http == import_string("http.http.http.http.http.http")
    assert http == import_string("http.http.http.http.http.http.http")
    assert http == import_string("http.http.http.http.http.http.http.http")
    assert http == import_string("http.http.http.http.http.http.http.http.http")
    assert http == import_string("http.http.http.http.http.http.http.http.http.http")

# Generated at 2022-06-18 05:30:52.662256
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    from importlib import reload

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the temporary project
    project_dir = os.path.join(tmpdir, "project")
    os.mkdir(project_dir)

    # Create the temporary package
    package_dir = os.path.join(project_dir, "package")
    os.mkdir(package_dir)

    # Create the temporary module
    module_path = os.path.join(package_dir, "module.py")
    with open(module_path, "w") as module:
        module.write("class Klass():\n")
        module.write("    pass\n")

    # Add the temporary directory to the python path
    sys.path

# Generated at 2022-06-18 05:30:56.013422
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:01.170661
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHTTP") == test_http.TestHTTP
    assert isinstance(import_string("http.test_http.TestHTTP"), test_http.TestHTTP)

# Generated at 2022-06-18 05:31:05.537574
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()
    assert import_string("falcon.test_app") == test_app

# Generated at 2022-06-18 05:31:08.251939
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:17.696935
# Unit test for function import_string
def test_import_string():
    import sys
    from importlib import reload
    from types import ModuleType
    from types import FunctionType
    from types import ClassType
    from types import MethodType
    from types import BuiltinFunctionType
    from types import BuiltinMethodType
    from types import CodeType
    from types import FrameType
    from types import TracebackType
    from types import GeneratorType
    from types import DynamicClassAttribute
    from types import MemberDescriptorType
    from types import GetSetDescriptorType
    from types import MappingProxyType
    from types import AsyncGeneratorType
    from types import CoroutineType
    from types import ModuleSpec
    from types import SimpleNamespace
    from types import _GeneratorWrapper
    from types import _Finalizing
    from types import _WrapperDescriptor
    from types import _MethodWrapper

# Generated at 2022-06-18 05:31:20.632853
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:25.528917
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:36.920900
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestImportString(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.old_path = sys.path[:]
            sys.path.append(self.tmpdir)

        def tearDown(self):
            sys.path = self.old_path
            shutil.rmtree(self.tmpdir)

        def test_import_string_module(self):
            module_name = "test_import_string"
            module_path = os.path.join(self.tmpdir, module_name + ".py")
            with open(module_path, "w") as f:
                f.write("")

# Generated at 2022-06-18 05:31:50.825575
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").OK.value == 200
    assert import_string("falcon.http.HTTPStatus").OK.name == "OK"

# Generated at 2022-06-18 05:31:56.149674
# Unit test for function import_string
def test_import_string():
    from .middlewares import BaseMiddleware

    assert import_string("falcon.middlewares.BaseMiddleware") == BaseMiddleware
    assert import_string("falcon.middlewares.BaseMiddleware").__name__ == "BaseMiddleware"
    assert import_string("falcon.middlewares.BaseMiddleware").__module__ == "falcon.middlewares"

# Generated at 2022-06-18 05:31:59.006235
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()

# Generated at 2022-06-18 05:32:00.409535
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:32:02.964445
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHTTP") == test_http.TestHTTP
    assert import_string("http.test_http.TestHTTP")() == test_http.TestHTTP()

# Generated at 2022-06-18 05:32:07.116966
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("http.http") is http
    assert import_string("http.HttpProtocol") is HttpProtocol
    assert import_string("http.HttpProtocol")() is not HttpProtocol()

# Generated at 2022-06-18 05:32:10.747829
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:16.019879
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:32:19.483086
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").BAD_REQUEST == http.HTTPStatus.BAD_REQUEST

# Generated at 2022-06-18 05:32:22.040634
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:42.386078
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:32:45.915237
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHTTP") == test_http.TestHTTP
    assert import_string("http.test_http.TestHTTP")() == test_http.TestHTTP()

# Generated at 2022-06-18 05:32:54.019569
# Unit test for function import_string
def test_import_string():
    import sys
    from importlib import reload
    from . import http
    reload(http)
    assert http.import_string("http.http") == http
    assert http.import_string("http.http.HTTP") == http.HTTP
    assert http.import_string("http.http.HTTP", package=sys.modules["http"]) == http.HTTP
    assert http.import_string("http.http.HTTP", package=sys.modules["http.http"]) == http.HTTP
    assert http.import_string("http.http.HTTP", package=sys.modules["http.http.http"]) == http.HTTP
    assert http.import_string("http.http.HTTP", package=sys.modules["http.http.http.http"]) == http.HTTP

# Generated at 2022-06-18 05:32:57.120325
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHttp") == test_http.TestHttp
    assert import_string("http.test_http.TestHttp").__class__ == test_http.TestHttp

# Generated at 2022-06-18 05:33:00.390938
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("aiohttp.http")
    assert http.HttpVersion11 == import_string("aiohttp.http.HttpVersion11")
    assert http.HttpVersion11() == import_string("aiohttp.http.HttpVersion11")

# Generated at 2022-06-18 05:33:11.257778
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # create a temp folder
    temp_dir = tempfile.mkdtemp()
    # create a temp file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    # create a temp module
    temp_file.write(b"class TempClass(object):\n    pass\n")
    temp_file.close()
    # add the temp folder to the path
    sys.path.insert(0, temp_dir)
    # import the temp module
    temp_module = importlib.import_module(os.path.basename(temp_file.name))
    # import the temp class
    temp_class = import_string(temp_module.__name__ + ".TempClass")


# Generated at 2022-06-18 05:33:14.543571
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:33:18.753055
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("aiohttp.http") == http
    assert import_string("aiohttp.http.HttpProtocol") == HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol")() == HttpProtocol()

# Generated at 2022-06-18 05:33:23.196929
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:33:26.842208
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:34:02.351438
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:34:05.081581
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:08.091495
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:34:10.185694
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:34:16.021583
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:34:19.559489
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol") == http.HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol")() == HttpProtocol()

# Generated at 2022-06-18 05:34:21.878607
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:25.497025
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:34:31.089485
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") != http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:34:36.475127
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request").__class__ is http.Request
    assert import_string("falcon.http.Response").__class__ is http.Response

# Generated at 2022-06-18 05:35:46.769096
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()

# Generated at 2022-06-18 05:35:49.256208
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string
    """
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK

# Generated at 2022-06-18 05:35:51.689310
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:35:55.657387
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string(".http.HTTPStatus", package="http")
    assert http.HTTPStatus == import_string("http.HTTPStatus", package="http")
    assert http.HTTPStatus == import_string("HTTPStatus", package="http")
    assert http.HTTPStatus == import_string("HTTPStatus", package=http)

# Generated at 2022-06-18 05:36:03.418999
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus.OK == import_string("http.http.HTTPStatus.OK")
    assert http.HTTPStatus.OK == import_string("http.http.HTTPStatus.OK")
    assert http.HTTPStatus.OK == import_string("http.http.HTTPStatus.OK")
    assert http.HTTPStatus.OK == import_string("http.http.HTTPStatus.OK")

# Generated at 2022-06-18 05:36:06.764099
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response") is http.Response

# Generated at 2022-06-18 05:36:08.521531
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:36:17.000219
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(tmp_dir, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_file = os.path.join(package_dir, "mymodule.py")
    with open(module_file, "w") as f:
        f.write("class MyClass(object):\n")
        f.write("    def __init__(self):\n")
        f.write("        self.value = 'my_value'\n")
    # Create the __init__.py file

# Generated at 2022-06-18 05:36:18.448162
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:36:22.900629
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http