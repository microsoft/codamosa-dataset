

# Generated at 2022-06-18 05:28:14.722953
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:17.472916
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:28:27.399895
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    def create_module(module_name, content):
        """
        Create a module with content in a temp directory.
        """
        temp_dir = tempfile.mkdtemp()
        sys.path.append(temp_dir)
        module_path = os.path.join(temp_dir, module_name)
        with open(module_path, "w") as f:
            f.write(content)
        return temp_dir

    def remove_module(temp_dir):
        """
        Remove temp directory.
        """
        sys.path.remove(temp_dir)
        shutil.rmtree(temp_dir)

    def test_import_module():
        """
        Test import module.
        """

# Generated at 2022-06-18 05:28:34.084277
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:28:40.073178
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:28:48.617411
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:28:49.992888
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:57.642085
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message

# Generated at 2022-06-18 05:29:00.182174
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:08.428668
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "0",
        "Content-Type": "text/html",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "http://www.example.com/index.htm",
        "Expires": "Tue, 03 Jul 2001 06:00:00 GMT",
        "Last-Modified": "Tue, 03 Jul 2001 06:00:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "http://www.example.com/index.htm",
        "Expires": "Tue, 03 Jul 2001 06:00:00 GMT",
        "Extension-Header": "My-Extension",
    }

# Generated at 2022-06-18 05:29:20.299712
# Unit test for function import_string
def test_import_string():
    from . import http
    import_string("falcon.http")
    import_string("falcon.http.Request")
    import_string("falcon.http.Response")
    import_string("falcon.http.Request")
    import_string("falcon.http.Response")
    import_string("falcon.http.Request")
    import_string("falcon.http.Response")
    import_string("falcon.http.Request")
    import_string("falcon.http.Response")
    import_string("falcon.http.Request")
    import_string("falcon.http.Response")
    import_string("falcon.http.Request")
    import_string("falcon.http.Response")
    import_string("falcon.http.Request")
    import_string("falcon.http.Response")


# Generated at 2022-06-18 05:29:24.543777
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") != http.Request

# Generated at 2022-06-18 05:29:28.311989
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:29:32.043188
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response").__name__ == "Response"

# Generated at 2022-06-18 05:29:35.150189
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:39.298128
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:42.943631
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:29:48.252215
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() is not None
    assert import_string("falcon.http.Response")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:51.873482
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()

# Generated at 2022-06-18 05:29:53.927206
# Unit test for function import_string
def test_import_string():
    from . import test_server
    assert import_string("http.server.test_server.TestServer") == test_server.TestServer()

# Generated at 2022-06-18 05:30:03.258755
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()
    assert import_string("falcon.test_app") == test_app
    assert import_string("falcon.test_app.TestApp", "falcon") == test_app.TestApp()
    assert import_string("falcon.test_app", "falcon") == test_app

# Generated at 2022-06-18 05:30:06.573731
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:08.785921
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:11.650196
# Unit test for function import_string
def test_import_string():
    from . import test_server
    assert import_string("http.server.test_server.TestServer") == test_server.TestServer()
    assert import_string("http.server.test_server") == test_server

# Generated at 2022-06-18 05:30:14.133599
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:16.792659
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp
    assert import_string("falcon.test_app") == test_app

# Generated at 2022-06-18 05:30:20.337650
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__.__name__ == "TestClass"

# Generated at 2022-06-18 05:30:23.487958
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:32.885804
# Unit test for function import_string
def test_import_string():
    from .test_utils import test_app
    assert import_string("falcon.API") == falcon.API
    assert isinstance(import_string("falcon.API"), falcon.API)
    assert import_string("falcon.API", package="falcon") == falcon.API
    assert isinstance(import_string("falcon.API", package="falcon"), falcon.API)
    assert import_string("falcon.API", package="falcon.api") == falcon.API
    assert isinstance(import_string("falcon.API", package="falcon.api"), falcon.API)
    assert import_string("falcon.test.test_utils.test_app") == test_app
    assert isinstance(import_string("falcon.test.test_utils.test_app"), test_app)

# Generated at 2022-06-18 05:30:37.840618
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("aiohttp.http")
    assert http.HttpVersion11 == import_string("aiohttp.http.HttpVersion11")
    assert http.HttpVersion11() == import_string("aiohttp.http.HttpVersion11")

# Generated at 2022-06-18 05:30:47.962255
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK

# Generated at 2022-06-18 05:30:50.744670
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:54.087383
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:58.559310
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:31:01.372941
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:05.818033
# Unit test for function import_string
def test_import_string():
    from . import test_utils
    assert import_string("aiohttp.test_utils.TestClient") == test_utils.TestClient
    assert import_string("aiohttp.test_utils") == test_utils

# Generated at 2022-06-18 05:31:08.477364
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:11.646666
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:31:15.982610
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.RequestOptions")()

# Generated at 2022-06-18 05:31:18.969975
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus.OK == import_string("http.http.HTTPStatus.OK")

# Generated at 2022-06-18 05:31:32.147521
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").OK.value == 200
    assert import_string("falcon.http.HTTPStatus").OK.name == "OK"
    assert import_string("falcon.http.HTTPStatus").OK.phrase == b"OK"
    assert import_string("falcon.http.HTTPStatus").OK.description == "OK"
    assert import_string("falcon.http.HTTPStatus").OK.is_informational == False
    assert import_string("falcon.http.HTTPStatus").OK.is_success == True

# Generated at 2022-06-18 05:31:37.915328
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response.__class__
    assert import_string("falcon.http.Response").__class__ == http.Response.__class__
    assert import_string("falcon.http.Response").__class__ == http.Response.__class__

# Generated at 2022-06-18 05:31:46.333355
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("aiohttp.http") == http
    assert import_string("aiohttp.http.HttpVersion") == http.HttpVersion
    assert import_string("aiohttp.http.HttpVersion11") == http.HttpVersion11
    assert import_string("aiohttp.http.HttpVersion10") == http.HttpVersion10
    assert import_string("aiohttp.http.HttpVersion11")() == http.HttpVersion11()
    assert import_string("aiohttp.http.HttpVersion10")() == http.HttpVersion10()

# Generated at 2022-06-18 05:31:49.728213
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:31:52.059125
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:57.988804
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp
    assert import_string("falcon.test_app") == test_app
    assert import_string("falcon.test_app.TestApp").__class__ == test_app.TestApp
    assert import_string("falcon.test_app.TestApp").__class__.__name__ == "TestApp"

# Generated at 2022-06-18 05:32:02.605681
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function
    """
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:32:04.484120
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:08.977202
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHttp") == test_http.TestHttp
    assert import_string("http.test_http.TestHttp").__class__ == test_http.TestHttp

# Generated at 2022-06-18 05:32:18.725720
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.STATUS_CODES") == http.STATUS_CODES
    assert import_string("falcon.http.has_message_body") == http.has_message_body
   

# Generated at 2022-06-18 05:32:37.931427
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    from importlib import reload
    from importlib import import_module
    from importlib import machinery

    # Test import module
    module_name = "http.server"
    module = import_string(module_name)
    assert module.__name__ == module_name

    # Test import class
    module_name = "http.server.BaseHTTPRequestHandler"
    module = import_string(module_name)
    assert module.__name__ == module_name.rsplit(".", 1)[1]

    # Test import class with package
    module_name = "http.server.BaseHTTPRequestHandler"
    module = import_string(module_name, package="http")
    assert module.__name__ == module_name.rsplit(".", 1)[1]

    # Test import class with package and relative

# Generated at 2022-06-18 05:32:42.296487
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:32:44.589803
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:46.922019
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:49.271852
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")() is not None

# Generated at 2022-06-18 05:32:57.151893
# Unit test for function import_string
def test_import_string():
    import os
    import sys
    import tempfile
    import unittest

    class TestImportString(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.TemporaryDirectory()
            self.tmpdir_path = self.tmpdir.name
            self.tmpfile_path = os.path.join(self.tmpdir_path, "test.py")
            self.tmpfile = open(self.tmpfile_path, "w")
            self.tmpfile.write("class Test: pass")
            self.tmpfile.close()
            sys.path.append(self.tmpdir_path)

        def tearDown(self):
            self.tmpdir.cleanup()
            sys.path.remove(self.tmpdir_path)


# Generated at 2022-06-18 05:32:59.423681
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:33:03.020813
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:10.620987
# Unit test for function import_string
def test_import_string():
    from .middlewares import BaseMiddleware
    from .middlewares import Middleware
    from .middlewares import MiddlewareManager

    assert import_string("falcon.middlewares.BaseMiddleware") == BaseMiddleware
    assert import_string("falcon.middlewares.Middleware") == Middleware
    assert import_string("falcon.middlewares.MiddlewareManager") == MiddlewareManager

    assert isinstance(import_string("falcon.middlewares.Middleware"), Middleware)
    assert isinstance(import_string("falcon.middlewares.MiddlewareManager"), MiddlewareManager)

# Generated at 2022-06-18 05:33:12.720932
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()