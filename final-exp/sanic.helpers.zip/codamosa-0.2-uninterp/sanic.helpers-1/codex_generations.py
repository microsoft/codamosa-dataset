

# Generated at 2022-06-18 05:28:17.526096
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Location": "http://example.com/index.htm",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
    }
    headers = remove_entity_headers(headers)
    assert headers == {"Content-Location": "http://example.com/index.htm", "Expires": "Thu, 01 Dec 1994 16:00:00 GMT"}

# Generated at 2022-06-18 05:28:24.060421
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request").__name__ == "Request"
    assert import_string("falcon.http.Response").__name__ == "Response"
    assert import_string("falcon.http").__name__ == "http"

# Generated at 2022-06-18 05:28:28.018912
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:28:32.118683
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:45.828936
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(202) == True
    assert has_message_body(203) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == True
    assert has_message_body(206) == True
    assert has_message_body(207) == True
    assert has_message_body(208) == True
    assert has_message_body(226) == True
    assert has_message_body(300) == True
    assert has_

# Generated at 2022-06-18 05:28:54.411549
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    def _create_module(name, content):
        # Create a module with the given name and content
        # and add it to the python path
        tmpdir = tempfile.mkdtemp()
        sys.path.append(tmpdir)
        module_path = os.path.join(tmpdir, name + ".py")
        with open(module_path, "w") as f:
            f.write(content)
        return tmpdir

    def _remove_module(tmpdir):
        # Remove the module from the python path
        # and delete the temporary directory
        sys.path.remove(tmpdir)
        shutil.rmtree(tmpdir)

    # Test import module
    tmpdir = _create_module("test_import_string", "")


# Generated at 2022-06-18 05:29:03.879112
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    def create_module(name, content):
        """
        Create a module with the given name and content.
        """
        module_dir = tempfile.mkdtemp()
        module_file = os.path.join(module_dir, name + ".py")
        with open(module_file, "w") as f:
            f.write(content)
        sys.path.insert(0, module_dir)
        return importlib.import_module(name)

    def remove_module(module):
        """
        Remove the module from the system path.
        """
        sys.path.remove(module.__path__[0])
        shutil.rmtree(module.__path__[0])

    module = create_module

# Generated at 2022-06-18 05:29:12.668639
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    assert remove_entity_headers(headers) == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:21.811557
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message_body(226)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_body(302)
    assert has_message_body(303)
    assert not has_message_body(304)
    assert has_message_body(305)
    assert has_message_body(307)
    assert has_message_body(308)

# Generated at 2022-06-18 05:29:24.409886
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:29.069185
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:33.787347
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:39.122566
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response", package="falcon")() == http.Response()

# Generated at 2022-06-18 05:29:41.530231
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:44.542638
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("falcon.http")
    assert http.Response == import_string("falcon.http.Response")
    assert http.Response() == import_string("falcon.http.Response")

# Generated at 2022-06-18 05:29:55.920400
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    def create_module(name, content):
        """
        Create a module with the given name and content.
        """
        path = os.path.join(tempfile.gettempdir(), name)
        with open(path, "w") as f:
            f.write(content)
        sys.path.append(tempfile.gettempdir())
        return path

    def remove_module(path):
        """
        Remove a module from the path.
        """
        sys.path.remove(tempfile.gettempdir())
        os.remove(path)

    def test_import_module():
        """
        Test import a module.
        """
        path = create_module("test_import_string.py", "")
        module = import_string

# Generated at 2022-06-18 05:30:00.107497
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:02.166492
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:05.648122
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:30:08.626019
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:30:13.963274
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:30:18.251236
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:30:21.664589
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:25.919704
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string(".http", package="falcon") == http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:30.965780
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http.http
    assert import_string("http.http.HTTP") == http.http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.http.HTTP
    assert import_string("http.http.HTTP").__class__.__name__ == "HTTP"



# Generated at 2022-06-18 05:30:32.737292
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:36.856981
# Unit test for function import_string
def test_import_string():
    from .test_http import test_http
    assert import_string("http.test_http.test_http") == test_http
    assert import_string("http.test_http.test_http")() == test_http()

# Generated at 2022-06-18 05:30:39.299080
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()

# Generated at 2022-06-18 05:30:46.832385
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:30:48.935184
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:55.252729
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:04.762028
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")

# Generated at 2022-06-18 05:31:08.986679
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:12.510298
# Unit test for function import_string
def test_import_string():
    from . import test_utils
    assert import_string("httpolice.test_utils.test_import_string") == test_utils.test_import_string
    assert import_string("httpolice.test_utils.TestClass") == test_utils.TestClass()

# Generated at 2022-06-18 05:31:21.246758
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil

    def create_temp_package(name):
        path = tempfile.mkdtemp()
        sys.path.insert(0, path)
        package_path = os.path.join(path, name)
        os.mkdir(package_path)
        return package_path

    def create_temp_module(name, package_path):
        module_path = os.path.join(package_path, name + ".py")
        with open(module_path, "w") as f:
            f.write("")
        return module_path

    def create_temp_class(name, package_path):
        module_path = os.path.join(package_path, name + ".py")

# Generated at 2022-06-18 05:31:25.219972
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:27.554188
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:33.427693
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from test_import_string import TestImportString
    assert import_string("test_import_string.TestImportString") == TestImportString
    assert import_string("test_import_string.TestImportString").__class__ == TestImportString

# Generated at 2022-06-18 05:31:41.489500
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection") == import_module("http.client").HTTPConnection
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__module__ == "http.client"
    assert import_string("http.client.HTTPConnection").__qualname__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__class__.__name__ == "type"
    assert import_string("http.client.HTTPConnection").__class__.__module__ == "builtins"
    assert import_string("http.client.HTTPConnection").__class__.__qualname__ == "type"
    assert import_string("http.client.HTTPConnection").__class__.__class__.__name__ == "type"


# Generated at 2022-06-18 05:31:46.126294
# Unit test for function import_string
def test_import_string():
    from . import test_import_string
    from . import test_import_string2
    assert import_string("aiohttp.test_utils.test_import_string") == test_import_string
    assert import_string("aiohttp.test_utils.test_import_string2.TestClass") == test_import_string2.TestClass()