

# Generated at 2022-06-18 05:28:16.335488
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "10",
        "Content-Type": "text/html",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "http://www.example.com/index.htm",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Last-Modified": "Thu, 01 Dec 1994 16:00:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "http://www.example.com/index.htm",
        "Expires": "Thu, 01 Dec 1994 16:00:00 GMT",
    }

# Generated at 2022-06-18 05:28:21.882812
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:27.400460
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Type": "text/html", "Content-Length": "0"}
    headers = remove_entity_headers(headers)
    assert "Content-Type" not in headers
    assert "Content-Length" not in headers
    headers = {"Content-Type": "text/html", "Content-Length": "0"}
    headers = remove_entity_headers(headers, allowed=("content-length",))
    assert "Content-Type" not in headers
    assert "Content-Length" in headers

# Generated at 2022-06-18 05:28:32.118810
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:28:44.799020
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "100",
        "Content-Type": "text/html",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Custom-Header",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:28:47.987820
# Unit test for function import_string
def test_import_string():
    from . import http

    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:28:52.520986
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response").__name__ == "Response"

# Generated at 2022-06-18 05:29:01.378015
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:05.891225
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()
    assert import_string("falcon.http.Request", package="falcon")()

# Generated at 2022-06-18 05:29:08.085056
# Unit test for function import_string
def test_import_string():
    from aiohttp.web import Application
    assert import_string("aiohttp.web.Application") == Application
    assert import_string("aiohttp.web.Application")() == Application()

# Generated at 2022-06-18 05:29:10.936754
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:13.185573
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:17.172342
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:18.884750
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:29:26.172858
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response
    assert import_string("falcon.http.Response").__class__.__name__ == "Response"
    assert import_string("falcon.http.Response").__class__.__module__ == "falcon.http"

# Generated at 2022-06-18 05:29:31.315375
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response", package="falcon")() == http.Response()
    assert import_string("falcon.http.Response", package="falcon.http")() == http.Response()

# Generated at 2022-06-18 05:29:38.641056
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").OK == 200
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTP_200
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus(200)
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus("200")
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus("OK")

# Generated at 2022-06-18 05:29:40.720214
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:44.112958
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:29:49.355187
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http") == http
    assert import_string("falcon.http") is not None

# Generated at 2022-06-18 05:29:54.629747
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")().__class__.__name__ == "Response"

# Generated at 2022-06-18 05:29:57.417853
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:01.366246
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:30:03.626528
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:08.260331
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND == http.HTTPStatus.NOT_FOUND

# Generated at 2022-06-18 05:30:17.644221
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.get_body") == http.get_body
    assert import_string("falcon.http.parse_header_links") == http.parse_header_links
    assert import_string("falcon.http.dt_to_http") == http.dt_to_http
    assert import_string("falcon.http.http_date_to_dt") == http.http_date_to_dt
   

# Generated at 2022-06-18 05:30:20.054846
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:23.482384
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:26.660282
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:30.122157
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:37.540585
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:41.604398
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    from .http_error import HTTPError
    assert import_string("falcon.http_error.HTTPError") == HTTPError()
    from .http_error import HTTPError
    assert import_string("falcon.http_error.HTTPError") == HTTPError()

# Generated at 2022-06-18 05:30:46.415940
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:30:54.339173
# Unit test for function import_string
def test_import_string():
    import sys
    from os.path import dirname, join
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from unittest.mock import patch

    class TestClass:
        pass

    class TestCaseImportString(TestCase):
        def setUp(self):
            self.tmp_dir = TemporaryDirectory()
            self.tmp_dir_path = self.tmp_dir.name
            self.test_module_path = join(self.tmp_dir_path, "test_module.py")
            self.test_module_name = "test_module"
            self.test_class_name = "TestClass"
            self.test_class_path = ".".join(
                [self.test_module_name, self.test_class_name]
            )
            self.test_module_

# Generated at 2022-06-18 05:30:56.960690
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:02.896395
# Unit test for function import_string
def test_import_string():
    """
    Test function import_string
    """
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__

# Generated at 2022-06-18 05:31:07.291273
# Unit test for function import_string
def test_import_string():
    from .test_http import TestHttp
    assert import_string("http.test_http.TestHttp") == TestHttp()
    assert import_string("http.test_http") == import_module("http.test_http")

# Generated at 2022-06-18 05:31:12.118556
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES

# Generated at 2022-06-18 05:31:14.996071
# Unit test for function import_string
def test_import_string():
    assert import_string("http.server")
    assert import_string("http.server.HTTPServer")
    assert import_string("http.server.HTTPServer").__name__ == "HTTPServer"

# Generated at 2022-06-18 05:31:18.088323
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)