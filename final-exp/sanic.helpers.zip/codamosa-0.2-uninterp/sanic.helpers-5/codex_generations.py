

# Generated at 2022-06-18 05:28:15.621890
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__

# Generated at 2022-06-18 05:28:26.154932
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_string("http.http.HTTPStatus")
    assert http.HTTPStatus == import_

# Generated at 2022-06-18 05:28:30.725972
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:28:37.738158
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message

# Generated at 2022-06-18 05:28:49.743869
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(199)
    assert not has_message_body(201)
    assert not has_message_body(202)
    assert not has_message_body(203)
    assert not has_message_body(205)
    assert not has_message_body(206)
    assert not has_message_body(207)
    assert not has_message_body(208)
    assert not has_message_body(226)
    assert not has_message_body

# Generated at 2022-06-18 05:28:53.838951
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from server import Server
    assert import_string("server.Server") == Server
    assert isinstance(import_string("server.Server"), Server)

# Generated at 2022-06-18 05:28:58.892102
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:29:02.217556
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:29:09.610585
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.HTTPStatus")()
    assert import_string("falcon.http.HTTP_METHODS") == http.HTTP_METHODS
    assert import_string("falcon.http.MEDIA_JSON") == http.MEDIA_JSON
    assert import_string("falcon.http.MEDIA_MSGPACK") == http.MEDIA_MSGPACK
    assert import_string("falcon.http.MEDIA_YAML") == http.MEDIA_YAML

# Generated at 2022-06-18 05:29:12.075312
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response").__name__ == "Response"
    assert import_string("falcon.http.Response").__module__ == "falcon.http"

# Generated at 2022-06-18 05:29:18.280216
# Unit test for function import_string
def test_import_string():
    from . import test_utils

    assert import_string("falcon.test_utils.TestUtils") == test_utils.TestUtils()
    assert import_string("falcon.test_utils") == test_utils

# Generated at 2022-06-18 05:29:22.373443
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:29:24.501008
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:33.319460
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:29:44.270323
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.HTTPStatus") is http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK is http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND is http.HTTPStatus.NOT_FOUND
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND.value == 404
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND.description == b"Not Found"
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND.name == "NOT_FOUND"
    assert import_string("falcon.http.HTTPStatus").NOT_FOUND.phrase == b"Not Found"

# Generated at 2022-06-18 05:29:55.635988
# Unit test for function import_string
def test_import_string():
    from . import server
    assert import_string("http.server.Server") == server.Server
    assert import_string("http.server.Server").__class__ == server.Server.__class__
    assert import_string("http.server.Server").__class__ == server.Server.__class__
    assert import_string("http.server.Server").__class__ == server.Server.__class__
    assert import_string("http.server.Server").__class__ == server.Server.__class__
    assert import_string("http.server.Server").__class__ == server.Server.__class__
    assert import_string("http.server.Server").__class__ == server.Server.__class__
    assert import_string("http.server.Server").__class__ == server.Server.__class__

# Generated at 2022-06-18 05:29:58.288558
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:01.769150
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:30:05.275161
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:30:07.740158
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:30:12.899309
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:15.026212
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:30:17.835661
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("falcon.http")
    assert http.Request == import_string("falcon.http.Request")
    assert http.Request() == import_string("falcon.http.Request")

# Generated at 2022-06-18 05:30:23.576072
# Unit test for function import_string
def test_import_string():
    from . import test_import_string
    assert import_string("aiohttp.test_utils.test_import_string") is test_import_string
    assert import_string("aiohttp.test_utils.test_import_string.TestClass") is test_import_string.TestClass
    assert import_string("aiohttp.test_utils.test_import_string.TestClass")() is not None

# Generated at 2022-06-18 05:30:27.061765
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:30.204972
# Unit test for function import_string
def test_import_string():
    """Test import_string function"""
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")() is not None

# Generated at 2022-06-18 05:30:34.787068
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:37.742359
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()



# Generated at 2022-06-18 05:30:40.002517
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:45.694953
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("aiohttp.http")
    assert http.HttpVersion11 == import_string("aiohttp.http.HttpVersion11")
    assert http.HttpVersion11() == import_string("aiohttp.http.HttpVersion11")

# Generated at 2022-06-18 05:30:51.860122
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HttpProtocol == import_string("http.http.HttpProtocol")
    assert http.HttpProtocol() == import_string("http.http.HttpProtocol")

# Generated at 2022-06-18 05:30:56.275328
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus

# Generated at 2022-06-18 05:31:00.437885
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:03.104693
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus

# Generated at 2022-06-18 05:31:07.892216
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert isinstance(import_string("falcon.http.Response"), http.Response)

# Generated at 2022-06-18 05:31:09.968014
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:13.929847
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:16.458504
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:31:20.220163
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").OK == 200

# Generated at 2022-06-18 05:31:23.217792
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp

# Generated at 2022-06-18 05:31:30.936595
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:34.176250
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http")
    assert http.Request == import_string("http.Request")
    assert http.Request() == import_string("http.Request")

# Generated at 2022-06-18 05:31:36.521059
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:38.723631
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:43.176123
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:31:45.968627
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:31:50.914225
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("aiohttp.http")
    assert http.HttpVersion == import_string("aiohttp.http.HttpVersion")
    assert http.HttpVersion(1, 1) == import_string("aiohttp.http.HttpVersion")
    assert http.HttpVersion(1, 1) == import_string("aiohttp.http.HttpVersion()")

# Generated at 2022-06-18 05:31:53.142371
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:32:01.467722
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES
    assert import_string("falcon.http.get_body") == http.get_body
    assert import_string("falcon.http.get_headers") == http.get_headers
    assert import_string("falcon.http.get_param") == http.get_param
    assert import_string("falcon.http.get_param_as_int") == http.get_param_as_int

# Generated at 2022-06-18 05:32:03.402049
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    from .http import HttpProtocol
    assert isinstance(import_string("http.http.HttpProtocol"), HttpProtocol)

# Generated at 2022-06-18 05:32:17.454483
# Unit test for function import_string
def test_import_string():
    import sys
    from importlib import reload
    from . import http
    reload(http)
    assert http.import_string("falcon.http.http") == http
    assert http.import_string("falcon.http.http.HTTPStatus") == http.HTTPStatus
    assert http.import_string("falcon.http.http.HTTPStatus") == http.HTTPStatus
    assert http.import_string("falcon.http.http.HTTPStatus") == http.HTTPStatus
    assert http.import_string("falcon.http.http.HTTPStatus") == http.HTTPStatus
    assert http.import_string("falcon.http.http.HTTPStatus") == http.HTTPStatus
    assert http.import_string("falcon.http.http.HTTPStatus") == http.HTTPStatus

# Generated at 2022-06-18 05:32:21.929672
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:32:24.551600
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:32:26.650757
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:31.056231
# Unit test for function import_string
def test_import_string():
    from . import test_import_string
    assert import_string("falcon.test_import_string") == test_import_string
    assert import_string("falcon.test_import_string.TestImportString") == test_import_string.TestImportString()

# Generated at 2022-06-18 05:32:34.287456
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:38.646204
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:32:44.140503
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response")() != http.Response()

# Generated at 2022-06-18 05:32:46.774308
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:32:49.111071
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:59.501757
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:33:03.102232
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response


# Generated at 2022-06-18 05:33:08.049967
# Unit test for function import_string
def test_import_string():
    class Test:
        def __init__(self):
            self.name = "test"

    assert import_string("tests.test_http.test_import_string.Test").name == "test"
    assert import_string("tests.test_http.test_import_string").__name__ == "tests.test_http.test_import_string"

# Generated at 2022-06-18 05:33:10.819977
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")().__class__.__name__ == "Response"

# Generated at 2022-06-18 05:33:12.904553
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:33:17.666499
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:33:23.763194
# Unit test for function import_string
def test_import_string():
    from . import utils
    assert import_string("falcon.utils") == utils
    assert import_string("falcon.utils.uri") == utils.uri
    assert import_string("falcon.utils.uri.encode") == utils.uri.encode
    assert import_string("falcon.utils.uri.encode")() == utils.uri.encode()
    assert import_string("falcon.utils.uri.encode", package="falcon")() == utils.uri.encode()

# Generated at 2022-06-18 05:33:27.183225
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__

# Generated at 2022-06-18 05:33:30.965528
# Unit test for function import_string
def test_import_string():
    from . import test_import_string
    assert import_string("falcon.test_import_string") is test_import_string
    assert import_string("falcon.test_import_string.TestClass") is test_import_string.TestClass()

# Generated at 2022-06-18 05:33:33.652487
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:33:52.095666
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_import_string import TestClass
    assert TestClass == import_string("test_import_string.TestClass")
    assert TestClass() == import_string("test_import_string.TestClass")

# Generated at 2022-06-18 05:33:54.452122
# Unit test for function import_string
def test_import_string():
    from . import test_server
    assert import_string("aiohttp.test_server.TestServer") == test_server.TestServer
    assert import_string("aiohttp.test_server") == test_server

# Generated at 2022-06-18 05:33:57.967950
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", package="falcon") == http.Request
    assert import_string("falcon.http.Response", package="falcon") == http.Response

# Generated at 2022-06-18 05:34:01.776092
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:34:09.892179
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_path = tempfile.mkdtemp()

    # Create the temporary project tree
    package_dir = os.path.join(tmp_path, 'mypackage')
    os.makedirs(package_dir)

    # Create an empty __init__.py file
    open(os.path.join(package_dir, '__init__.py'), 'a').close()

    # Create a test module
    module_file = os.path.join(package_dir, 'test_module.py')

# Generated at 2022-06-18 05:34:14.013663
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request", "falcon") == http.Request
    assert import_string("falcon.http.Response", "falcon") == http.Response

# Generated at 2022-06-18 05:34:18.230657
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:26.382752
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from test_import_string import TestClass
    assert import_string("test_import_string.TestClass") == TestClass()
    assert import_string("test_import_string.TestClass") == TestClass()
    assert import_string("test_import_string.TestClass") == TestClass()
    assert import_string("test_import_string.TestClass") == TestClass()
    assert import_string("test_import_string.TestClass") == TestClass()
    assert import_string("test_import_string.TestClass") == TestClass()
    assert import_string("test_import_string.TestClass") == TestClass()

# Generated at 2022-06-18 05:34:32.497884
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES

# Generated at 2022-06-18 05:34:34.318352
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:35:29.535779
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("quart.http.HttpProtocol") is HttpProtocol
    assert import_string("quart.http") is http
    assert import_string("quart.http.HttpProtocol").__class__ is HttpProtocol
    assert import_string("quart.http.HttpProtocol").__class__.__name__ == "HttpProtocol"

# Generated at 2022-06-18 05:35:36.740888
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__
    assert import_string("http.http.HTTP")() == http.HTTP()
    assert import_string("http.http.HTTP")().__class__ == http.HTTP().__class__

# Generated at 2022-06-18 05:35:46.138119
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import unittest

    class TestImportString(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            sys.path.append(self.tempdir)

        def tearDown(self):
            sys.path.remove(self.tempdir)
            shutil.rmtree(self.tempdir)

        def test_import_module(self):
            module_name = "test_module"
            module_path = os.path.join(self.tempdir, module_name + ".py")
            with open(module_path, "w") as f:
                f.write("")
            module = import_string(module_name)
            self.assertTrue(module)
            self

# Generated at 2022-06-18 05:35:51.275327
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTPStatus").OK == http.HTTPStatus.OK
    assert import_string("falcon.http.HTTPStatus").OK == 200
    assert import_string("falcon.http.HTTPStatus").CONTINUE == 100
    assert import_string("falcon.http.HTTPStatus").SWITCHING_PROTOCOLS == 101
    assert import_string("falcon.http.HTTPStatus").PROCESSING == 102
    assert import_string("falcon.http.HTTPStatus").EARLY_HINTS == 103
    assert import_string("falcon.http.HTTPStatus").OK == 200
    assert import_string("falcon.http.HTTPStatus").CREATED == 201
    assert import_string

# Generated at 2022-06-18 05:35:55.782011
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()

# Generated at 2022-06-18 05:36:00.672978
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.ResponseOptions")()
    assert import_string("falcon.http.RequestOptions")()

# Generated at 2022-06-18 05:36:02.332393
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:36:05.090344
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response



# Generated at 2022-06-18 05:36:07.980199
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:36:10.730944
# Unit test for function import_string
def test_import_string():
    from .test_http import TestHTTP
    assert import_string("falcon.test_http.TestHTTP") == TestHTTP
    assert import_string("falcon.test_http.TestHTTP").__class__ == TestHTTP
    assert import_string("falcon.test_http.TestHTTP").__class__.__name__ == "TestHTTP"

# Generated at 2022-06-18 05:36:57.711398
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:36:59.320563
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response


# Generated at 2022-06-18 05:37:01.172334
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:37:02.691091
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:37:07.703054
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:37:10.786093
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("falcon.http")
    assert http.Request == import_string("falcon.http.Request")
    assert http.Request() == import_string("falcon.http.Request")

# Generated at 2022-06-18 05:37:13.031792
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:37:14.784615
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()



# Generated at 2022-06-18 05:37:16.386939
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:37:24.013928
# Unit test for function import_string
def test_import_string():
    """
    Test for import_string function
    """
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response").__class__ is http.Response
    assert import_string("falcon.http.Response").__class__.__name__ == "Response"