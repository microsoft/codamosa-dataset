

# Generated at 2022-06-18 05:28:14.722963
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Request").__class__ is http.Request
    assert import_string("falcon.http.Response").__class__ is http.Response

# Generated at 2022-06-18 05:28:16.584855
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:28:26.316777
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert headers == {
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-18 05:28:30.857257
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HttpProtocol == import_string("http.http.HttpProtocol")
    assert http.HttpProtocol() == import_string("http.http.HttpProtocol")

# Generated at 2022-06-18 05:28:33.833280
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(400) == True
    assert has_message_body(500) == True


# Generated at 2022-06-18 05:28:44.171304
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(299)
    assert has_message_body(300)
    assert has_message_body(399)
    assert has_message_body(400)
    assert has_message_body(499)
    assert has_message_body(500)
    assert has_message_body(599)


# Generated at 2022-06-18 05:28:47.375009
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol") == http.HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol")() == HttpProtocol()

# Generated at 2022-06-18 05:28:52.191016
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:02.520767
# Unit test for function import_string
def test_import_string():
    """Unit test for function import_string"""
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(tmpdir, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_file = os.path.join(package_dir, "mymodule.py")
    with open(module_file, "w") as module:
        module.write("class MyClass:\n")
        module.write("    pass\n")
    # Add the directory to the python path
    sys.path.insert(0, tmpdir)
    # Import the module
    module = import_string("mypackage.mymodule")


# Generated at 2022-06-18 05:29:13.027127
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "Content-Length": "0",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Extension-Header": "My-Extension",
    }
    headers = remove_entity_headers(headers)
    assert "Content-Type" in headers
    assert "Content-Length" in headers
    assert "Content-Encoding" in headers
    assert "Content-Language" in headers
    assert "Content-Location" in headers
    assert "Expires" in headers

# Generated at 2022-06-18 05:29:22.782488
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(tmp_dir, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_file = os.path.join(package_dir, "mymodule.py")
    with open(module_file, "w") as f:
        f.write("class MyClass(object):\n")
        f.write("    pass\n")
    # Add the directory to the python path
    sys.path.append(tmp_dir)
    # Import the module
    module = import_string("mypackage.mymodule")
    # Test the module
   

# Generated at 2022-06-18 05:29:25.388542
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:27.841517
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:29:31.579036
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:29:34.190528
# Unit test for function import_string
def test_import_string():
    from . import test_http_parser
    assert import_string("http.test_http_parser") == test_http_parser
    assert import_string("http.test_http_parser.TestHttpParser") == test_http_parser.TestHttpParser()

# Generated at 2022-06-18 05:29:40.323206
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:29:51.322256
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function
    """
    import sys
    import os
    import tempfile
    import shutil
    import importlib

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create the temporary package
    package_dir = os.path.join(temp_dir, "mypackage")
    os.mkdir(package_dir)
    # Create the module
    module_file = os.path.join(package_dir, "mymodule.py")
    with open(module_file, "w") as module:
        module.write("class MyClass:\n")
        module.write("    pass\n")
    # Add the directory to the python path
    sys.path.insert(0, temp_dir)
    # Test import module

# Generated at 2022-06-18 05:29:53.210903
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:29:57.533691
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:00.749324
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:06.787249
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:30:09.524525
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:30:13.227191
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("quart.http.HttpProtocol") == HttpProtocol
    assert import_string("quart.http") == http
    assert import_string("quart.http.HttpProtocol")() == HttpProtocol()

# Generated at 2022-06-18 05:30:15.639530
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:30:19.924312
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest == import_string("http.http:HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http:HTTPRequest")

# Generated at 2022-06-18 05:30:24.115597
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:30:30.162979
# Unit test for function import_string
def test_import_string():
    from . import http

    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:30:35.179829
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:30:39.506669
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP

# Generated at 2022-06-18 05:30:44.076087
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert import_string("falcon.http.Response")() is not http.Response()

# Generated at 2022-06-18 05:30:54.490385
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("http.http") == http
    assert import_string("http.http.HTTP") == http.HTTP
    assert import_string("http.http.HTTP").__class__ == http.HTTP.__class__

# Generated at 2022-06-18 05:31:00.968018
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("hypercorn.http")
    assert http.HTTPStatus == import_string("hypercorn.http.HTTPStatus")
    assert http.HTTPStatus == import_string("hypercorn.http.HTTPStatus")
    assert http.HTTPStatus == import_string("hypercorn.http.HTTPStatus")
    assert http.HTTPStatus == import_string("hypercorn.http.HTTPStatus")

# Generated at 2022-06-18 05:31:02.787074
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:07.894055
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:31:17.318420
# Unit test for function import_string
def test_import_string():
    from . import http
    from . import http_parser
    from . import http_request
    from . import http_response
    from . import http_server
    from . import http_stream
    from . import http_websocket
    from . import http_websocket_client
    from . import http_websocket_server
    from . import http_websocket_stream
    from . import http_websocket_utils
    from . import http_websocket_wsgi
    from . import http_wsgi
    from . import http_wsgi_server
    from . import http_wsgi_websocket
    from . import http_wsgi_websocket_server
    from . import http_wsgi_websocket_utils
    from . import http_wsgi_websocket_wsgi

# Generated at 2022-06-18 05:31:21.272828
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() == http.Request()
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:26.433753
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:31:31.104440
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:38.263279
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response

# Generated at 2022-06-18 05:31:41.216460
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:31:51.690790
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:31:56.329352
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("http.test_http") == test_http
    assert import_string("http.test_http.TestHTTP") == test_http.TestHTTP
    assert import_string("http.test_http.TestHTTP")() == test_http.TestHTTP()

# Generated at 2022-06-18 05:31:58.868357
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:32:02.094770
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:32:03.710318
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:32:05.564622
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()


# Generated at 2022-06-18 05:32:12.143833
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Request").__class__ == http.Request
    assert import_string("falcon.http.Request").__class__.__name__ == "Request"
    assert import_string("falcon.http.Request").__class__.__module__ == "falcon.http"

# Generated at 2022-06-18 05:32:14.099146
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()

# Generated at 2022-06-18 05:32:16.891181
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:20.957475
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:37.715776
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:42.056405
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:32:44.703269
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:32:46.737013
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:50.395950
# Unit test for function import_string
def test_import_string():
    from .test_http import TestHttp
    from .test_http import TestHttp as TestHttp2
    assert import_string("falcon.test_http.TestHttp") == TestHttp
    assert import_string("falcon.test_http.TestHttp") == TestHttp2

# Generated at 2022-06-18 05:32:52.135792
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:32:54.241868
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:32:56.540632
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:33:07.579089
# Unit test for function import_string
def test_import_string():
    """
    Test import_string function
    """
    assert import_string("http.client.HTTPConnection")
    assert import_string("http.client.HTTPConnection").__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection").__module__ == "http.client"
    assert import_string("http.client.HTTPConnection")()
    assert import_string("http.client.HTTPConnection")().__class__.__name__ == "HTTPConnection"
    assert import_string("http.client.HTTPConnection")().__class__.__module__ == "http.client"
    assert import_string("http.client.HTTPConnection")().__class__.__module__ == "http.client"
    assert import_string("http.client.HTTPConnection")().__class__.__module__ == "http.client"

# Generated at 2022-06-18 05:33:09.992433
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()


# Generated at 2022-06-18 05:33:23.309988
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:33:24.947376
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()

# Generated at 2022-06-18 05:33:29.246595
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:33:36.536773
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    import shutil
    from importlib import reload

    temp_dir = tempfile.mkdtemp()
    sys.path.append(temp_dir)

# Generated at 2022-06-18 05:33:40.518710
# Unit test for function import_string
def test_import_string():
    from . import http
    assert http == import_string("http.http")
    assert http.HTTPRequest == import_string("http.http.HTTPRequest")
    assert http.HTTPRequest() == import_string("http.http.HTTPRequest")

# Generated at 2022-06-18 05:33:43.980705
# Unit test for function import_string
def test_import_string():
    from . import http
    from .http import HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol") == http.HttpProtocol
    assert import_string("aiohttp.http.HttpProtocol")() == HttpProtocol()

# Generated at 2022-06-18 05:33:47.322495
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Response") is http.Response
    assert isinstance(import_string("falcon.http.Response"), http.Response)

# Generated at 2022-06-18 05:33:49.682748
# Unit test for function import_string
def test_import_string():
    from . import test_app
    assert import_string("falcon.test_app.TestApp") == test_app.TestApp()

# Generated at 2022-06-18 05:33:51.415362
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:33:54.368491
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:34:16.591318
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")() == http.Response()
    assert import_string("falcon.http.Response", package="falcon")() == http.Response()

# Generated at 2022-06-18 05:34:20.805174
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:34:23.318734
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response

# Generated at 2022-06-18 05:34:25.498815
# Unit test for function import_string
def test_import_string():
    from . import test_module
    assert import_string("http.test_module") == test_module
    assert import_string("http.test_module.TestClass") == test_module.TestClass()

# Generated at 2022-06-18 05:34:28.186387
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:34.726211
# Unit test for function import_string
def test_import_string():
    from . import test_import_string
    assert import_string("falcon.tests.test_import_string") is test_import_string
    assert import_string("falcon.tests.test_import_string.TestImportString") is test_import_string.TestImportString
    assert import_string("falcon.tests.test_import_string.TestImportString").__class__ is test_import_string.TestImportString

# Generated at 2022-06-18 05:34:39.046427
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.HTTPStatus") == http.HTTPStatus
    assert import_string("falcon.http.HTTP_STATUS_CODES") == http.HTTP_STATUS_CODES

# Generated at 2022-06-18 05:34:42.552995
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response")() == http.Response()

# Generated at 2022-06-18 05:34:44.182838
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:34:46.653279
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").test_method() == "test"

# Generated at 2022-06-18 05:35:27.718493
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").status == "200 OK"

# Generated at 2022-06-18 05:35:31.048510
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:35:34.256827
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()


# Generated at 2022-06-18 05:35:37.412141
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:35:41.952734
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    from . import errors
    assert import_string("falcon.errors.HTTPBadRequest") == errors.HTTPBadRequest
    assert import_string("falcon.errors.HTTPBadRequest")()


# Generated at 2022-06-18 05:35:44.343487
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()

# Generated at 2022-06-18 05:35:47.781870
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:35:51.350887
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response", package="falcon")()

# Generated at 2022-06-18 05:35:55.533263
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:36:00.671489
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Request")() is not None
    assert import_string("falcon.http.Response")() is not None

# Generated at 2022-06-18 05:37:32.586196
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http.Response").__class__ == http.Response
    assert import_string("falcon.http.Response").__class__.__name__ == "Response"
    assert import_string("falcon.http.Response").__class__.__module__ == "falcon.http"

# Generated at 2022-06-18 05:37:35.518438
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)

# Generated at 2022-06-18 05:37:38.354229
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Response").__name__ == "Response"

# Generated at 2022-06-18 05:37:41.424576
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__.__name__ == "TestClass"

# Generated at 2022-06-18 05:37:45.518196
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http.Request") == http.Request
    assert import_string("falcon.http.Response") == http.Response
    assert import_string("falcon.http") == http

# Generated at 2022-06-18 05:37:46.897894
# Unit test for function import_string
def test_import_string():
    import_string("http.server")
    import_string("http.server.BaseHTTPRequestHandler")


# Generated at 2022-06-18 05:37:50.708030
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") == http
    assert import_string("falcon.http.Request")()
    assert import_string("falcon.http.Response")()
    assert import_string("falcon.http.Request", "falcon")()
    assert import_string("falcon.http.Response", "falcon")()

# Generated at 2022-06-18 05:37:56.386514
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    from test_import_string import TestClass
    assert import_string("test_import_string.TestClass") == TestClass
    assert import_string("test_import_string.TestClass").__class__ == TestClass
    assert import_string("test_import_string.TestClass").__class__.__name__ == "TestClass"

# Generated at 2022-06-18 05:37:59.653495
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestClass
    assert import_string("falcon.test_utils.TestClass") == TestClass
    assert import_string("falcon.test_utils.TestClass").__class__ == TestClass
    assert import_string("falcon.test_utils.TestClass").test_method() == "test"

# Generated at 2022-06-18 05:38:01.976304
# Unit test for function import_string
def test_import_string():
    from . import http
    assert import_string("falcon.http") is http
    assert import_string("falcon.http.Request") is http.Request
    assert isinstance(import_string("falcon.http.Request"), http.Request)