

# Generated at 2022-06-21 22:56:18.235588
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("proxy-Authenticate") == True
    assert is_hop_by_hop_header("Authorization") == False



# Generated at 2022-06-21 22:56:22.641430
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(99) == False
    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True
    assert has_message_body(299) == True
    assert has_message_body(300) == True
    assert has_message_body(400) == True


# Generated at 2022-06-21 22:56:24.052613
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(101) == False



# Generated at 2022-06-21 22:56:26.448508
# Unit test for function import_string
def test_import_string():
    from aiohttp.test_utils import TestServer
    assert isinstance(import_string("aiohttp.test_utils.TestServer"), TestServer)

# Generated at 2022-06-21 22:56:35.011042
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    input_headers = {"Date" : "Sat, 07 Sep 2019 11:44:47 GMT",
                    "Server" : "Apache/2.4.29 (Ubuntu)",
                    "Last-Modified" : "Sat, 07 Sep 2019 06:27:47 GMT",
                    "ETag" : '"2a2-595684e6d08a8"',
                    "Accept-Ranges" : "bytes",
                    "Content-Length" : "730",
                    "Keep-Alive" : "timeout=5, max=100",
                    "Connection" : "Keep-Alive",
                    "Content-Type" : "text/html; charset=UTF-8"}

# Generated at 2022-06-21 22:56:43.098496
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-encoding": "gzip",
        "content-language": "en",
        "content-length": "1024",
        "content-location": "/",
        "content-md5": "gzip",
        "expires": "never",
        "content-range": "bytes 0-1024/1024",
        "content-type": "text/html",
        "last-modified": "2018-07-05 15:36:20",
    }

    assert remove_entity_headers(headers) == {
        "content-location": "/",
        "expires": "never",
    }

# Generated at 2022-06-21 22:56:45.752100
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Language")
    assert not is_entity_header("Pragma")
    assert is_entity_header("content-length")
    assert not is_entity_header("contentlength")


# Generated at 2022-06-21 22:56:55.242073
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection") is True
    assert is_hop_by_hop_header("keep-alive") is True
    assert is_hop_by_hop_header("Proxy-Authenticate") is True
    assert is_hop_by_hop_header("transfer-encoding") is True
    assert is_hop_by_hop_header("upgrade") is True
    assert is_hop_by_hop_header("date") is False
    assert is_hop_by_hop_header("content-type") is False
    assert is_hop_by_hop_header("content-length") is False
    assert is_hop_by_hop_header("content-Range") is False


# Generated at 2022-06-21 22:57:05.951272
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) is False
    assert has_message_body(101) is False
    assert has_message_body(102) is False
    assert has_message_body(103) is False
    assert has_message_body(200) is True
    assert has_message_body(201) is True
    assert has_message_body(202) is True
    assert has_message_body(203) is True
    assert has_message_body(204) is False
    assert has_message_body(205) is True
    assert has_message_body(206) is True
    assert has_message_body(207) is True
    assert has_message_body(208) is True
    assert has_message_body(226) is True
    assert has_message_body(300) is True
    assert has_

# Generated at 2022-06-21 22:57:06.944439
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")


# Generated at 2022-06-21 22:57:12.793531
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Connection": "close", "Content-Length": 0, "Keep-Alive": True}
    assert remove_entity_headers(headers) == {"Keep-Alive": True}



# Generated at 2022-06-21 22:57:17.604101
# Unit test for function has_message_body
def test_has_message_body():
    status: int = 100
    if status in (204, 304):
        assert not has_message_body(status)
    elif status < 200:
        assert not has_message_body(status)
    elif status >= 200:
        assert has_message_body(status)


# Generated at 2022-06-21 22:57:20.846168
# Unit test for function is_entity_header
def test_is_entity_header():
    header = "Content-Type"
    assert is_entity_header(header) is True

    header = "Allow"
    assert is_entity_header(header) is True



# Generated at 2022-06-21 22:57:25.220914
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("CONNECTION")
    assert not is_hop_by_hop_header("Accept")



# Generated at 2022-06-21 22:57:31.698546
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == True
    assert has_message_body(102) == True
    assert has_message_body(103) == True
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(305) == True

# Unit Test for function is_entity_header

# Generated at 2022-06-21 22:57:37.221623
# Unit test for function is_entity_header
def test_is_entity_header():
    # test for is_entity_header when given header is an entity header
    assert(is_entity_header("Content-Location") == True)
    assert(is_entity_header("Content-Encoding") == True)
    assert(is_entity_header("Content-Language") == True)
    assert(is_entity_header("Content-Length") == True)
    assert(is_entity_header("Content-Location") == True)
    assert(is_entity_header("Content-MD5") == True)
    assert(is_entity_header("Content-Range") == True)
    assert(is_entity_header("Content-Type") == True)
    assert(is_entity_header("Expires") == True)
    assert(is_entity_header("Last-Modified") == True)

# Generated at 2022-06-21 22:57:45.382552
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Etag": "blablah",
        "content-type": "text/html",
        "content-encoding": "gzip",
        "content-location": "index.html",
        "content-length": "1024",
    }
    assert headers == remove_entity_headers(headers, allowed=())
    assert headers == remove_entity_headers(headers, allowed=("content-location",))
    assert headers == remove_entity_headers(headers, allowed=("expires",))
    assert headers == remove_entity_headers(
        headers, allowed=("content-location", "expires")
    )
    assert {
        "Etag": "blablah",
        "content-location": "index.html",
    } == remove_entity_headers(headers, allowed=("content-location",))

# Generated at 2022-06-21 22:57:48.138552
# Unit test for function is_entity_header
def test_is_entity_header():
    """Test for function is_entity_header"""

    assert is_entity_header("Content-Type")
    assert not is_entity_header("My-Header")


# Generated at 2022-06-21 22:57:50.129616
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert not is_hop_by_hop_header("Content-Type")


# Generated at 2022-06-21 22:57:52.627890
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)==True
    assert has_message_body(204)==False
    assert has_message_body(304)==False
    assert has_message_body(101)==False


# Generated at 2022-06-21 22:57:58.189381
# Unit test for function import_string
def test_import_string():
    module_name = "tests.unit.test_http.test_import_string"
    import_string(module_name)

# Generated at 2022-06-21 22:58:04.721867
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) is True
    assert has_message_body(204) is False
    assert has_message_body(304) is False
    assert has_message_body(100) is False
    assert has_message_body(199) is False
    assert has_message_body(200) is True
    assert has_message_body(201) is True
    assert has_message_body(300) is True
    assert has_message_body(399) is True



# Generated at 2022-06-21 22:58:07.064595
# Unit test for function is_entity_header
def test_is_entity_header():
    header_list = ["content-length", "content-type", "allow", "expires", "extension-header"]
    for header in header_list:
        assert is_entity_header(header)


# Generated at 2022-06-21 22:58:11.851462
# Unit test for function has_message_body
def test_has_message_body():
    for i in range(100, 200):
        assert not has_message_body(i)
    for i in range(200, 300):
        assert has_message_body(i)
    for i in range(300, 400):
        assert not has_message_body(i)
    for i in range(400, 500):
        assert has_message_body(i)
    for i in range(500, 600):
        assert not has_message_body(i)

# Generated at 2022-06-21 22:58:13.628475
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    input = 'connection'
    expected_output = True
    actual_output = is_hop_by_hop_header(input)
    assert actual_output == expected_output



# Generated at 2022-06-21 22:58:17.938074
# Unit test for function import_string
def test_import_string():
    """
    test_import_string
    """
    from asgiref.http import http_protocol
    path = "asgiref.http.http_protocol.HttpProtocol"
    http_path = import_string(path)
    assert http_path() == http_protocol.HttpProtocol()

# Generated at 2022-06-21 22:58:23.249406
# Unit test for function has_message_body
def test_has_message_body():
    """Test has_message_body function"""
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert has_message_body(200)
    assert has_message_body(300)

# Generated at 2022-06-21 22:58:26.696803
# Unit test for function import_string
def test_import_string():
    from starlette.templating import Jinja2Templates  # type: ignore
    templates = import_string("starlette.templating.Jinja2Templates")
    assert isinstance(templates, Jinja2Templates)

# Generated at 2022-06-21 22:58:30.845099
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)

# Generated at 2022-06-21 22:58:33.847690
# Unit test for function is_entity_header
def test_is_entity_header():
    for i in _ENTITY_HEADERS:
        assert is_entity_header(i)

    for i in _HOP_BY_HOP_HEADERS:
        assert not is_entity_header(i)



# Generated at 2022-06-21 22:58:42.616848
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert has_message_body(103)

# Generated at 2022-06-21 22:58:51.537268
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": 12,
        "Content-Type": "image/png",
        "Content-Language": "en",
        "Content-Range": "bytes",
        "Content-Location": "http://www.google.com",
        "Expires": "Never",
    }
    headers = remove_entity_headers(headers)
    assert len(headers) == 1
    assert headers["Content-Location"] == "http://www.google.com"



# Generated at 2022-06-21 22:58:54.311067
# Unit test for function import_string
def test_import_string():
    from uvicorn.config import Config
    from uvicorn.config import get_default_config
    config = Config()
    config.load(get_default_config())
    assert hasattr(import_string('uvicorn.config.Config'), '__call__')

test_import_string()

# Generated at 2022-06-21 22:58:58.144261
# Unit test for function import_string
def test_import_string():
    from . import server
    from . import response
    from . import request
    from . import http_protocol

    assert import_string("http.server") is server
    assert import_string("http.server.tcp_server").__class__.__name__ == "TCPServer"
    assert import_string("http.server.thread_pool_server").__class__.__name__ == "ThreadPoolServer"
    assert import_string("http.response") is response
    assert import_string("http.request") is request
    assert import_string("http.http_protocol") is http_protocol

# Generated at 2022-06-21 22:59:00.691293
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Encoding")
    assert is_entity_header("content-encoding")
    assert not is_entity_header("via")



# Generated at 2022-06-21 22:59:09.950516
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    test_headers = {
        "Allow": "A",
        "Content-Encoding": "B",
        "Content-Language": "C",
        "Content-Length": "D",
        "Content-Location": "E",
        "Content-MD5": "F",
        "Content-Range": "G",
        "Content-Type": "H",
        "Expires": "I",
        "Last-Modified": "J",
        "extension-header": "K",
    }
    result_headers = {
        "Content-Location": "E",
        "Expires": "I",
        "extension-header": "K",
    }

    headers = remove_entity_headers(test_headers, allowed=("Expires",))
    assert headers == result_headers



# Generated at 2022-06-21 22:59:17.884427
# Unit test for function import_string
def test_import_string():
    from importlib import reload
    import sys
    from httpcore import _base

    reload(_base)
    test_module_path = _base.__file__
    m = import_string(test_module_path)
    sys.modules.pop("httpcore._base")
    assert import_string(test_module_path) == m



# Generated at 2022-06-21 22:59:21.924948
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    res = remove_entity_headers({
        "content-type": "text/html",
        "content-length": "1234",
        "expires": "Today",
        "content-Location": "Nowhere",
        "location": "v.here",
    })
    assert res == {
        "expires": "Today",
        "content-Location": "Nowhere",
        "location": "v.here",
    }

# Generated at 2022-06-21 22:59:26.034423
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-length": "100",
               "content-range": "100",
               "content-location": "100",
               "content-type": "100",
               "expires": "100",
               "last-modified": "100",
               "foobar": "100"}
    headers = remove_entity_headers(headers)
    assert "content-length" not in headers
    assert "content-range" not in headers
    assert "content-location" in headers
    assert "content-type" not in headers
    assert "expires" in headers
    assert "last-modified" not in headers
    assert "foobar" in headers

# Generated at 2022-06-21 22:59:33.474631
# Unit test for function has_message_body
def test_has_message_body():
    for status in (1, 2, 3):
        for code in (100, 199):
            assert has_message_body(code + (100 * status))
    for status in range(4, 6):
        for code in (100, 199):
            assert not has_message_body(code + (100 * status))
    assert not has_message_body(204)
    assert not has_message_body(304)


# Generated at 2022-06-21 22:59:41.768326
# Unit test for function is_entity_header
def test_is_entity_header():
    entity_header = "content-type"
    hop_by_hop_header = "connection"
    assert is_entity_header(entity_header)
    assert not is_entity_header(hop_by_hop_header)


# Generated at 2022-06-21 22:59:46.249542
# Unit test for function import_string
def test_import_string():
    import types
    from .response import Response
    assert isinstance(import_string("http.response.Response"), Response)
    assert isinstance(import_string("http.response"), types.ModuleType)

## This tests that import_string works with
# package names containing "."
# Ex: package.subpackage.module

# Generated at 2022-06-21 22:59:49.046457
# Unit test for function import_string
def test_import_string():
    module = import_string("httptools.http_parser")
    assert module.HttpParser
    parser = import_string("httptools.http_parser.HttpParser")
    assert isinstance(parser, module.HttpParser)



# Generated at 2022-06-21 22:59:53.682857
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-location": "http://example.com",
               "content-type": "text/html"}
    assert "content-location" in remove_entity_headers(headers)
    assert "content-type" not in remove_entity_headers(headers)

# Generated at 2022-06-21 23:00:06.836524
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("fancy-connection") == False
    assert is_hop_by_hop_header("keep-alive") == True
    assert is_hop_by_hop_header("Fancy-Keep-Alive") == False
    assert is_hop_by_hop_header("proxy-authenticate") == True
    assert is_hop_by_hop_header("proxy-Authorization") == True
    assert is_hop_by_hop_header("fancy-proxy-authenticate") == False
    assert is_hop_by_hop_header("te") == True
    assert is_hop_by_hop_header("Trailers") == True
    assert is_

# Generated at 2022-06-21 23:00:12.797146
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    headers = [
      "Connection",
      "Keep-Alive",
      "Proxy-Authenticate",
      "Proxy-Authorization",
      "TE",
      "Trailers",
      "Transfer-Encoding",
      "Upgrade",
    ]
    for header in headers:
        if not is_hop_by_hop_header(header):
            raise ValueError(
                "The header: '{}' is not recognized as Hop By Hop header.".format(
                    header
                )
            )


# Generated at 2022-06-21 23:00:13.432377
# Unit test for function import_string
def test_import_string():
    pass

# Generated at 2022-06-21 23:00:27.397052
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(202) == True
    assert has_message_body(203) == True
    assert has_message_body(204) == False
    assert has_message_body(205) == True
    assert has_message_body(206) == True
    assert has_message_body(207) == True
    assert has_message_body(208) == True
    assert has_message_body(226) == True
    assert has_message_body(300) == True
    assert has_

# Generated at 2022-06-21 23:00:31.502439
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Encoding": "gzip", "Content-Type": "application/json"}
    assert remove_entity_headers(headers) == {}



# Generated at 2022-06-21 23:00:40.085203
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(100)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_body(302)
    assert has_message_body(303)
    assert has_message_body(400)
    assert has_message_body(401)

# Generated at 2022-06-21 23:00:56.115323
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Type": "text/html",
        "ETag": "testing",
        "Content-MD5": "12345",
        "Content-Location": "root",
        "Content-Range": "0-1/1",
        "Content-Language": "en",
        "Expires": "today",
        "Content-Encoding": "gzip",
        "Allow": "GET",
        "Last-Modified": "yesterday",
    }
    headers = remove_entity_headers(headers)
    assert "Content-Type" not in headers
    assert "Content-MD5" not in headers
    assert "Content-Range" not in headers
    assert "Content-Language" not in headers
    assert "Content-Encoding" not in headers
    assert "Last-Modified" not in headers

# Generated at 2022-06-21 23:01:05.345407
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("ConnEction") == True
    assert is_hop_by_hop_header("Trailers") == True
    assert is_hop_by_hop_header("transfer-encoding") == True
    assert is_hop_by_hop_header("transfer-encoding") == True
    assert is_hop_by_hop_header("a") == False


# Generated at 2022-06-21 23:01:16.564671
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "allow": "GET",
        "content-length": "42",
        "content-md5": "some_hash",
        "content-location": "some_location",
        "date": "2018-08-02T11:19:10.460007+00:00",
        "server": "some_server",
    }
    assert remove_entity_headers(headers) == {
        "allow": "GET",
        "content-location": "some_location",
        "date": "2018-08-02T11:19:10.460007+00:00",
        "server": "some_server",
    }



# Generated at 2022-06-21 23:01:28.745532
# Unit test for function has_message_body
def test_has_message_body():
    """
    Test suite for function has_message_body
    """
    export_status_code = [100, 101, 102, 103, 200, 201, 202, 203, 204, 205, 206, 207, 208, 226, 300, 301, 302, 303, 304, 305, 307, 308, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 422, 423, 424, 426, 428, 429, 431, 451, 500, 501, 502, 503, 504, 505, 506, 507, 508, 510, 511]
    import_status_code = [204,304]
    assert any(str(x) for x in export_status_code) == any(str(x) for x in import_status_code)

# Generated at 2022-06-21 23:01:36.284190
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow") is True
    assert is_entity_header("content-encoding") is True
    assert is_entity_header("content-language") is True
    assert is_entity_header("content-length") is True
    assert is_entity_header("content-location") is True
    assert is_entity_header("content-md5") is True
    assert is_entity_header("content-range") is True
    assert is_entity_header("content-type") is True
    assert is_entity_header("expires") is True
    assert is_entity_header("last-modified") is True
    assert is_entity_header("extension-header") is True
    assert is_entity_header("test") is False


# Generated at 2022-06-21 23:01:38.567763
# Unit test for function is_entity_header
def test_is_entity_header():
    header = "content-type"
    assert is_entity_header(header) == True

# Generated at 2022-06-21 23:01:48.469133
# Unit test for function import_string
def test_import_string():
    from asgineer import http
    import asgineer.http

    mod = import_string('asgineer.http')
    assert mod == http

    mod = import_string('asgineer.http.HTTPError')
    assert mod == http.HTTPError
    
    from asgineer import application
    app_mod = import_string('asgineer')
    assert app_mod is application

    from asgineer import application
    app_mod = import_string('asgineer.application.Application')
    assert app_mod is application.Application

# Generated at 2022-06-21 23:01:51.663102
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("foo") == False

# Generated at 2022-06-21 23:01:59.990579
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("Proxy-Authenticate") == True
    assert is_hop_by_hop_header("Upgrade") == True
    assert is_hop_by_hop_header("Transfer-Encoding") == True
    assert is_hop_by_hop_header("Authenticate") == False
    assert is_hop_by_hop_header("Authorization") == False
    assert is_hop_by_hop_header("Host") == False
    assert is_hop_by_hop_header("Content-Type") == False
    assert is_hop_by_hop_header("Content-Length") == False


# Generated at 2022-06-21 23:02:01.981748
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Type": "application/json",
               "Content-Length": 1,
               "Content-Language": "en",
               "Date": "Tue, 03 May 2016 15:21:11 GMT"}

    headers = remove_entity_headers(headers)

    assert headers == {}

# Generated at 2022-06-21 23:02:10.816085
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Type") == True
    assert is_entity_header("content-TYPE") == True
    assert is_entity_header("no-entity") == False


# Generated at 2022-06-21 23:02:17.468848
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) is False
    assert has_message_body(200) is True
    assert has_message_body(204) is False
    assert has_message_body(300) is True
    assert has_message_body(404) is True
    assert has_message_body(504) is True



# Generated at 2022-06-21 23:02:22.275338
# Unit test for function import_string
def test_import_string():
    module = import_string("abstract.ctypes")
    assert issubclass(module.BaseClass, object) is True
    assert isinstance(module.BaseClass(), object) is True

    module = import_string("ctypes.util")
    assert issubclass(module.find_library, object) is True
    assert callable(module.find_library) is True

# Generated at 2022-06-21 23:02:28.903892
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({"content-type": "text/html"}) == {}
    assert remove_entity_headers({"expires": "Tue, 25 Jul 2017 01:31:42 GMT"}) == {
        "expires": "Tue, 25 Jul 2017 01:31:42 GMT"
    }
    assert remove_entity_headers({"content-location": "http://localhost"}) == {
        "content-location": "http://localhost"
    }
    assert remove_entity_headers({"content-range": "bytes 1-2/2"}) == {}
    assert remove_entity_headers({"content-type": "text/html"}, allowed=["content-type"]) == {
        "content-type": "text/html"
    }

# Generated at 2022-06-21 23:02:35.445503
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type") == True
    assert is_entity_header("content-length") == True
    assert is_entity_header("Content-Type") == True
    assert is_entity_header("CONTENT-TYPE") == True


# Generated at 2022-06-21 23:02:37.630306
# Unit test for function import_string
def test_import_string():
    from kyukon.middlewares.cors import CORSMiddleware
    corsobj = import_string('kyukon.middlewares.cors.CORSMiddleware')
    assert isinstance(corsobj, CORSMiddleware)

# Generated at 2022-06-21 23:02:45.138274
# Unit test for function import_string
def test_import_string():
    """TODO: Docstring for test_import_string.
    :returns: TODO

    """
    # import module
    import test_module
    # import class and instanciate
    from test_module import TestClass
    test = import_string("test_module.TestClass")
    assert ismodule(test_module)
    assert test.__class__ == TestClass

test_import_string()

# Generated at 2022-06-21 23:02:49.611042
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-length": "10", "content-type": "plain/text"}
    headers = remove_entity_headers(headers)
    assert headers == {}

    headers = {"content-length": "10", "content-type": "plain/text"}
    headers = remove_entity_headers(headers, allowed=["content-length"])
    assert headers == {"content-length": "10"}



# Generated at 2022-06-21 23:02:54.302502
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {b'Allow': b'PUT',
               b'Content-Encoding': b'gzip',
               b'Content-Type': b'application/json'}
    headers = remove_entity_headers(headers)
    assert headers == {b'Allow': b'PUT'}

# Generated at 2022-06-21 23:02:59.170260
# Unit test for function is_entity_header
def test_is_entity_header():
    print("Testing is_entity_header")
    for header in _ENTITY_HEADERS:
        assert is_entity_header(header)
    assert not is_entity_header("Connection")
    assert not is_entity_header("content-encoding ")
    assert not is_entity_header("Content-Encoding")



# Generated at 2022-06-21 23:03:14.485314
# Unit test for function is_entity_header
def test_is_entity_header():
    headers = ["content-length", "content-type", "content-location"]
    for header in headers:
        assert is_entity_header(header)
    headers = ["connection", "transfer-encoding", "upgrade"]
    for header in headers:
        assert not is_entity_header(header)


# Generated at 2022-06-21 23:03:16.465730
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header('Connection') == True
    assert is_hop_by_hop_header('connection') == True
    assert is_hop_by_hop_header('TEST') == False

# Generated at 2022-06-21 23:03:21.110466
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    headers = (
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailers",
        "transfer-encoding",
        "upgrade",
    )
    for header in headers:
        assert is_hop_by_hop_header(header) is True



# Generated at 2022-06-21 23:03:22.309345
# Unit test for function import_string
def test_import_string():
    import_string("aiohttp.web.HTTPRequest")
    import_string("aiohttp.web.HTTPRequest")

# Generated at 2022-06-21 23:03:24.382359
# Unit test for function is_entity_header
def test_is_entity_header():
    assert not is_entity_header("connection")
    assert is_entity_header("content-type")
    assert is_entity_header("content-encoding")
    assert is_entity_header("extension-header")



# Generated at 2022-06-21 23:03:36.717086
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message_body(226)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_body(302)
    assert has_message_body

# Generated at 2022-06-21 23:03:41.116886
# Unit test for function is_entity_header
def test_is_entity_header():
    """Unit test for function is_entity_header"""

    assert is_entity_header("allow")
    assert is_entity_header("Content-Encoding")
    assert is_entity_header("content-type")



# Generated at 2022-06-21 23:03:44.030990
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("proxy-authenticate")
    assert not is_hop_by_hop_header("fake-header")

# Generated at 2022-06-21 23:03:53.167323
# Unit test for function import_string
def test_import_string():
    """
    Tests the import_string function.
    """
    assert STATUS_CODES == import_string("asyncio_http.http.codes.STATUS_CODES")
    assert getattr(import_string("asyncio_http.http.codes"), "STATUS_CODES") == STATUS_CODES
    assert not hasattr(import_string("asyncio_http.http.codes.STATUS_CODES"), "STATUS_CODES")
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert is_entity_header("content-type")
    assert not is_entity_header("accept-encoding")
    assert is_hop_by

# Generated at 2022-06-21 23:03:58.192893
# Unit test for function import_string
def test_import_string():
    import_string("tests.test_helpers")
    import_string(".test_helpers", "tests")
    import_string(".test_helpers")
    import_string("tests.test_helpers.TestClass")
    import_string(".test_helpers.TestClass", "tests")