

# Generated at 2022-06-21 22:56:02.783115
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Allow": "GET, HEAD, POST",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Length": "348",
        "Content-Location": "/index.htm",
        "Content-MD5": "Q2hlY2sgSW50ZWdyaXR5IQ==",
        "Content-Range": "bytes 21010-47021/47022",
        "Content-Type": "text/html",
        "Expires": "Tue, 04 Dec 2018 12:45:26 GMT",
        "Last-Modified": "Tue, 04 Dec 2018 12:45:26 GMT",
        "Extension-Header": "",
    }

# Generated at 2022-06-21 22:56:03.552681
# Unit test for function import_string
def test_import_string():
    from . import routing
    assert routing == import_string("h2.server.routing")

# Generated at 2022-06-21 22:56:08.393096
# Unit test for function import_string
def test_import_string():

    from importlib import resources
    import pytest

    def _get_uri_path(exp_path):
        # Open and read the uri
        data_file_uri = resources.path(__package__, exp_path)
        with open(data_file_uri, "rb") as f:
            data = f.read()
        return data.decode()

    # Assert base path
    uri = _get_uri_path("data/app_base.html")
    assert uri == import_string("app.responses.html.base")

    # Assert subclass path
    uri = _get_uri_path("data/app_custom.html")
    assert uri == import_string("app.responses.html.custom")

    # Assert that import raise error

# Generated at 2022-06-21 22:56:11.425847
# Unit test for function is_entity_header
def test_is_entity_header():
    """is_entity_header returns True when
    the header given is an entity header"""
    header = "content-length"
    assert is_entity_header(header)



# Generated at 2022-06-21 22:56:13.945180
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Length")
    assert is_entity_header("CoNTent-lengTH")
    assert not is_entity_header("Accept")
    assert not is_entity_header("Host")



# Generated at 2022-06-21 22:56:16.439196
# Unit test for function import_string
def test_import_string():
    from pyramid.config import Configurator
    configurator = import_string("pyramid.config.Configurator")
    assert isinstance(configurator, Configurator)

# Generated at 2022-06-21 22:56:24.892122
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers1 = {
        "content-location": "http://example.com/index.htm",
        "content-type": "text/html; charset=UTF-8",
        "content-length": "348",
    }
    headers1 = remove_entity_headers(headers1)
    assert headers1 == {"content-location": "http://example.com/index.htm"}

    headers2 = {"content-type": "text/html; charset=UTF-8"}
    headers2 = remove_entity_headers(headers2)
    assert headers2 == {}

# Generated at 2022-06-21 22:56:33.276510
# Unit test for function is_entity_header
def test_is_entity_header():
    """
    Test the function is_entity_header
    """
    for header in _ENTITY_HEADERS:
        assert is_entity_header(header) is True
    header = "CONTENT-TYPE"
    assert is_entity_header(header) is True
    header = "Content-type"
    assert is_entity_header(header) is True
    header = "content-type"
    assert is_entity_header(header) is True
    header = "Content-Type"
    assert is_entity_header(header) is True
    header = "my-custom-header"
    assert is_entity_header(header) is False


# Generated at 2022-06-21 22:56:36.889584
# Unit test for function is_entity_header
def test_is_entity_header():
    import pytest
    assert is_entity_header('content-encoding') == True
    assert is_entity_header('not-entity-header') == False


# Generated at 2022-06-21 22:56:39.673519
# Unit test for function import_string
def test_import_string():
    from .test_harness import TestHarness

    test_harness = import_string("quart.serving.test_harness.TestHarness")
    assert isinstance(test_harness, TestHarness)

# Generated at 2022-06-21 22:56:48.451717
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    expected = {
        "connection": "keep-alive",
        "host": "localhost:8080",
        "accept-encoding": "gzip, deflate",
        "content-range": "bytes 0-0/0",
        "content-type": "application/json",
    }
    headers = {
        "content-range": "bytes 0-0/0",
        "content-type": "application/json",
        "transfer-encoding": "chunked",
        "connection": "keep-alive",
        "host": "localhost:8080",
        "accept-encoding": "gzip, deflate",
    }
    assert expected == remove_entity_headers(headers)

# Generated at 2022-06-21 22:56:51.956829
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-length": 9,
        "content-location": "foo",
        "expires": "Sat, 18 Jul 2015 15:04:06 GMT",
    }
    assert not remove_entity_headers(headers).keys()



# Generated at 2022-06-21 22:57:03.120162
# Unit test for function import_string
def test_import_string():
    import sys
    import os
    import tempfile
    from aiohttp import web

    with tempfile.TemporaryDirectory() as tmp_directory:
        # Create a test module
        with open(os.path.join(tmp_directory, "test.py"), "w") as fp:
            fp.write("class TestClass: pass")
        # Add directory to sys.path in order to import it
        sys.path.append(tmp_directory)
        # Test module import
        module = import_string("test")
        assert ismodule(module)
        assert module.__name__ == "test"
        # Test class import
        klass = import_string("test.TestClass")
        assert not ismodule(klass)
        assert klass.__class__.__name__ == "TestClass"
        # Remove directory from sys

# Generated at 2022-06-21 22:57:07.900156
# Unit test for function import_string
def test_import_string():
    assert import_string("builtins") is __builtins__
    assert import_string("os.path") is os.path
    assert import_string("os.path.abspath", "os") is os.path.abspath
    assert import_string("test_import_string") is test_import_string
    assert import_string("unittest.mock.MagicMock").__name__ == "MagicMock"

# Generated at 2022-06-21 22:57:12.699946
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert not has_message_body(300)



# Generated at 2022-06-21 22:57:21.744230
# Unit test for function import_string
def test_import_string():
    import logging
    import sys
    import unittest

    from starlette.logger import Logger

    class TestImportString(unittest.TestCase):
        def test_import_module(self):
            module = import_string('logging')
            self.assertEqual(module, logging)

        def test_import_class(self):
            klass = import_string('starlette.logger.Logger')
            self.assertIsInstance(klass, Logger)

    if __name__ == "__main__":
        unittest.main()



# Generated at 2022-06-21 22:57:26.891832
# Unit test for function is_entity_header
def test_is_entity_header():
    headers_true = ["Allow", "Content-Location", "Expires"]
    headers_false = ["Connection", "Host", "Pragma"]

    for header in headers_true:
        assert is_entity_header(header) == True

    for header in headers_false:
        assert is_entity_header(header) == False


# Generated at 2022-06-21 22:57:28.935521
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header(b"connection")



# Generated at 2022-06-21 22:57:31.971487
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Encoding"), "Should be an entity header"
    assert is_entity_header("content-type"), "Should be an entity header"
    assert not is_entity_header("ConTent-lengtH"), "Should not be an entity header"



# Generated at 2022-06-21 22:57:42.047198
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """Test remove_entity_headers function"""
    import pprint

    headers = {
        'Content-Length': '123',
        'Content-Type': 'text/html',
        'Content-Encoding': 'gzip',
        'Content-Language': 'en',
        'Content-Location': 'doc/example.html',
        'Expires': 'Thu, 01 Dec 1994 16:00:00 GMT',
        'Date': 'Wed, 23 Dec 2015 17:17:25 GMT',
        'server': 'nginx'
    }
    pprint.pprint(headers)
    assert len(headers) == 8
    headers = remove_entity_headers(headers)
    pprint.pprint(headers)
    assert len(headers) == 2
    assert 'Expires' in headers
    assert 'Content-Location' in headers

# Generated at 2022-06-21 22:57:47.575400
# Unit test for function has_message_body
def test_has_message_body():
    assert(not (has_message_body(204) and has_message_body(304)))
    assert(not has_message_body(100))
    assert(has_message_body(200))

if __name__ == "__main__":
    test_has_message_body()

# Generated at 2022-06-21 22:57:50.975579
# Unit test for function import_string
def test_import_string():
    from waitress import serve
    serve_obj = import_string("waitress.serve")
    assert serve_obj == serve
    import waitress.server
    server_obj = import_string("waitress.server.Waitress")
    assert type(server_obj) == waitress.server.Waitress

# Generated at 2022-06-21 22:57:59.301464
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("Keep-alive") == True
    assert is_hop_by_hop_header("proxy-authenticate") == True
    assert is_hop_by_hop_header("proxy-authorization") == True
    assert is_hop_by_hop_header("Te") == True
    assert is_hop_by_hop_header("Trailers") == True
    assert is_hop_by_hop_header("Transfer-Encoding") == True
    assert is_hop_by_hop_header("Upgrade") == True
    assert is_hop_by_hop_header("trailers") == True
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("tE")

# Generated at 2022-06-21 22:58:07.885045
# Unit test for function import_string
def test_import_string():
    import unittest

    class TestClass:
        pass

    class TestCase(unittest.TestCase):
        def test_import_string(self):
            import_string_module = import_string("http.http")
            self.assertEqual(import_string_module, http)

            test_class = import_string("http.test_http.TestClass")
            self.assertEqual(test_class.__class__, TestClass)

            test_instance = import_string("http.test_http.TestClass")
            self.assertEqual(test_instance.__class__, TestClass)

            self.assertRaises(AttributeError, import_string, "http.not_exists")

    unittest.main(argv=["test_http"], verbosity=2)

# Generated at 2022-06-21 22:58:11.473682
# Unit test for function import_string
def test_import_string():
    """Function called in tests/test_web.py"""
    from .response import Response
    from .request import Request
    result = import_string("aiohttp.web.response.Response")
    assert result == Response
    result = import_string("aiohttp.web.request.Request")
    assert result == Request


# Generated at 2022-06-21 22:58:14.465426
# Unit test for function import_string
def test_import_string():
    from cotidia.docimport.tests import utils
    from cotidia.docimport.tests.example.models import Example
    assert import_string("cotidia.docimport.tests.utils") == utils
    assert import_string("cotidia.docimport.tests.example.models.Example") == Example

# Generated at 2022-06-21 22:58:22.944526
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("Proxy-Authenticate")
    assert is_hop_by_hop_header("Transfer-Encoding")
    assert not is_hop_by_hop_header("Content-Type")
    assert not is_hop_by_hop_header("Content-Length")
    assert not is_hop_by_hop_header("Date")
    assert not is_hop_by_hop_header("Location")


# Generated at 2022-06-21 22:58:33.190590
# Unit test for function import_string
def test_import_string():
    import sys

    import unittest
    from copy import copy

    class Foo:
        pass

    class Bar:
        pass

    foo_module = sys.modules[__name__]
    foo_module.__dict__["Foo"] = Foo
    foo_module.__dict__["Bar"] = Bar

    cls = import_string("%s.Foo" % __name__)
    assert isinstance(cls, Foo)

    # Can't import a class
    try:
        import_string("%s.Foo.Bar" % __name__)
    except Exception:
        assert True
    else:
        assert False

    cls = import_string("%s.Bar" % __name__)
    assert isinstance(cls, Bar)

    # Can't import a non existing module

# Generated at 2022-06-21 22:58:43.046046
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header('Connection') == True
    assert is_hop_by_hop_header('Keep-Alive') == True
    assert is_hop_by_hop_header('Proxy-Authenticate') == True
    assert is_hop_by_hop_header('Proxy-Authorization') == True
    assert is_hop_by_hop_header('TE') == True
    assert is_hop_by_hop_header('Trailers') == True
    assert is_hop_by_hop_header('Transfer-Encoding') == True
    assert is_hop_by_hop_header('Upgrade') == True


# Generated at 2022-06-21 22:58:44.915152
# Unit test for function is_entity_header
def test_is_entity_header():
    import pytest
    assert is_entity_header("content-type")
    assert not is_entity_header("server")


# Generated at 2022-06-21 22:58:49.661851
# Unit test for function is_entity_header
def test_is_entity_header():
    assert not is_entity_header("server")
    assert is_entity_header("Content-Range")
    assert is_entity_header("Last-Modified")
    assert is_entity_header("Content-Encoding")


# Generated at 2022-06-21 22:58:52.550865
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-encoding")
    assert not is_entity_header("faked-header")



# Generated at 2022-06-21 22:58:54.447484
# Unit test for function import_string
def test_import_string():
    assert import_string("tests.test_http.test_import_string") == test_import_string
    assert import_string("tests.test_http.FakeClass").text == "Foo Bar"

# Generated at 2022-06-21 22:59:00.684646
# Unit test for function import_string
def test_import_string():
    from .test_utils import TestUtils
    import sys

    sys.path.append("../")
    class_name = "test_utils.TestUtils"
    assert TestUtils == import_string(class_name)
    assert TestUtils() == import_string(class_name)

# Generated at 2022-06-21 22:59:12.263276
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """Unit test for function remove_entity_headers."""

# Generated at 2022-06-21 22:59:19.026230
# Unit test for function import_string
def test_import_string():
    class Foo(object):
        def __init__(self):
            pass
    
    class Bar(object):
        def __init__(self):
            pass

    assert import_string('basics.Foo') == Foo
    assert import_string('basics.Bar') == Bar



# Generated at 2022-06-21 22:59:27.780876
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Location": "/fabian",
        "Content-Type": "text",
        "Content-Range": "10",
        "Content-Length": "1",
        "Content-Encoding": "utf-8",
        "Content-Language": "ES",
        "Content-MD5": "algo",
        "Expires": "20",
        "Last-Modified": "19",
        "Extension-Header": "mkey",
    }
    headers = remove_entity_headers(headers)
    assert "Content-Location" in headers
    assert "Expires" in headers
    assert "Content-Type" not in headers
    assert "Content-Encoding" not in headers
    assert "Content-Length" not in headers
    assert "Content-Range" not in headers

# Generated at 2022-06-21 22:59:34.974875
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    import pytest
    headers = {
        b'content-encoding': b'gzip',
        b'content-length': b'1506',
        b'content-type': b'text/html;charset=utf-8',
        b'cache-control': b'max-age=3600',
        b'date': b'Sun, 01 Sep 2019 20:39:51 GMT',
        b'expires': b'Sun, 01 Sep 2019 21:39:51 GMT'
    }
    expected_headers = {
        b'cache-control': b'max-age=3600',
        b'date': b'Sun, 01 Sep 2019 20:39:51 GMT',
        b'expires': b'Sun, 01 Sep 2019 21:39:51 GMT'
    }
    result = remove_entity_headers(headers)

# Generated at 2022-06-21 22:59:44.741425
# Unit test for function import_string
def test_import_string():
    from hamcrest import assert_that, equal_to, is_
    import_string("http.cookies.SimpleCookie")
    assert_that(
        import_string("http.cookies.SimpleCookie"),
        is_(equal_to(import_module("http.cookies").SimpleCookie)),
    )
    assert_that(
        import_string("http.cookies.SimpleCookie")().__class__,
        is_(equal_to(import_module("http.cookies").SimpleCookie)),
    )

# Generated at 2022-06-21 22:59:51.016150
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert is_entity_header("Content-Encoding")
    assert is_entity_header("content-language")
    assert is_entity_header("content-length")
    assert is_entity_header("content-location")
    asser