

# Generated at 2022-06-21 22:56:29.238573
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("proxy-authenticate") == True

# Generated at 2022-06-21 22:56:34.967010
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    assert remove_entity_headers({"content-type": "text/html"}) == {}
    assert remove_entity_headers(
        {"content-type": "text/html"}, allowed=("content-location",)
    ) == {}
    assert remove_entity_headers({"content-type": "text/html", "content-location": "http://example.com"}) == {
        "content-location": "http://example.com"
    }
    assert remove_entity_headers(
        {"content-type": "text/html", "content-location": "http://example.com"},
        allowed=("content-location",),
    ) == {"content-location": "http://example.com"}


# Generated at 2022-06-21 22:56:38.254900
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header('content-length')
    assert not is_entity_header('host')
    assert not is_entity_header('x-custom-header')

# Generated at 2022-06-21 22:56:45.127111
# Unit test for function remove_entity_headers

# Generated at 2022-06-21 22:56:47.130700
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Keep-Alive") is True
    assert is_hop_by_hop_header("Keep-Alivea") is False



# Generated at 2022-06-21 22:56:56.085454
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    header = 'Connection'
    assert is_hop_by_hop_header(header)
    header = 'connection'
    assert is_hop_by_hop_header(header)
    header = 'keep-alive'
    assert is_hop_by_hop_header(header)
    header = 'proxy-authenticate'
    assert is_hop_by_hop_header(header)
    header = 'proxy-authorization'
    assert is_hop_by_hop_header(header)
    header = 'te'
    assert is_hop_by_hop_header(header)
    header = 'trailers'
    assert is_hop_by_hop_header(header)
    header = 'transfer-encoding'
    assert is_hop_by_hop_header(header)
    header = 'upgrade'

# Generated at 2022-06-21 22:57:05.099564
# Unit test for function import_string
def test_import_string():
    from httpcore import Server
    import_string("httpcore.Server") == Server
    # import_string(module) == module
    string = "httpcore.Server"
    module = import_module(string)
    import_string(string) == module
    # import_string(module.klass) == module.klass()
    string = "httpcore.Server"
    module = import_module(string)
    import_string(string) == Server()
    # import_string(package.module.klass) == package.module.klass()
    string = "httpcore.Server"
    module = import_module(string)
    import_string(string) == Server()

# Generated at 2022-06-21 22:57:12.264834
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)
    assert has_message_body(208)
    assert has_message_body(226)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_

# Generated at 2022-06-21 22:57:15.563845
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    import pytest
    h = _HOP_BY_HOP_HEADERS
    h.add("connection")
    t1 = _HOP_BY_HOP_HEADERS
    assert h == t1


# Generated at 2022-06-21 22:57:20.684263
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("keep-alive")
    assert not is_hop_by_hop_header("Content-Type")
    assert not is_hop_by_hop_header("content-type")
    assert not is_hop_by_hop_header("oups")


# Generated at 2022-06-21 22:57:26.000757
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"My-Header": "Value", "Content-type": "text/html"}
    headers = remove_entity_headers(headers)
    assert headers == {"My-Header": "Value"}

# Generated at 2022-06-21 22:57:31.034343
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-type": "text/html",
        "Content-length": 1024,
        "Content-encoding": "text/html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    assert remove_entity_headers(headers) == {
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT"
    }

# Generated at 2022-06-21 22:57:34.819463
# Unit test for function import_string
def test_import_string():
    class Bla:
        def __init__(self):
            return

    assert isinstance(import_string("http_pyramid.http_core.Bla").__class__, Bla)



# Generated at 2022-06-21 22:57:42.306114
# Unit test for function import_string
def test_import_string():

    # Import a module
    s = import_string("http.client")
    assert isinstance(s, module)

    # Import a function
    s = import_string("http.client.HTTPConnection.connect")
    assert "connect" in s.__name__

    # Import a method
    s = import_string("http.client.HTTPConnection.getresponse")
    assert "getresponse" in s.__name__

    # Import a class
    s = import_string("http.client.HTTPConnection")
    assert isinstance(s, type)

    # Import a object
    s = import_string("http.client.HTTPConnection", package="http")
    assert isinstance(s, object)



# Generated at 2022-06-21 22:57:46.310924
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-length")
    assert is_entity_header("Content-Length")
    assert not is_entity_header("content-encoding")
    assert not is_entity_header("Cache-Control")
    assert not is_entity_header("test")



# Generated at 2022-06-21 22:57:53.498742
# Unit test for function has_message_body
def test_has_message_body():
    """
    According to the following RFC message body and length SHOULD NOT
    be included in responses status 1XX, 204 and 304.
    https://tools.ietf.org/html/rfc2616#section-4.4
    https://tools.ietf.org/html/rfc2616#section-4.3
    """
    assert(has_message_body(100) == False)
    assert(has_message_body(101) == False)
    assert(has_message_body(204) == False)
    assert(has_message_body(304) == False)
    assert(has_message_body(200) == True)

# Generated at 2022-06-21 22:58:02.648252
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    # Test normal case
    headers = {"content-location": "test1", "expires": "test2", "content-type": "test3"}
    expected_headers = {"content-location": "test1", "expires": "test2"}
    result_headers = remove_entity_headers(headers)
    assert result_headers == expected_headers

    # Test case with not set allowed header
    headers = {"content-location": "test1", "expires": "test2", "content-type": "test3"}
    expected_headers = {"expires": "test2"}
    result_headers = remove_entity_headers(headers, allowed=["expires"])
    assert result_headers == expected_headers

    # Test case with empty header dict
    headers = {}
    expected_headers = {}
    result_headers = remove_entity_headers

# Generated at 2022-06-21 22:58:03.751939
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type") is True
    assert is_entity_header("foo") is False



# Generated at 2022-06-21 22:58:06.950692
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    from honeybadgerbft.core.common.exception import HoneyBadgerBFTException
    for header in _HOP_BY_HOP_HEADERS:
        assert is_hop_by_hop_header(header)
    assert not is_hop_by_hop_header("another")



# Generated at 2022-06-21 22:58:14.336992
# Unit test for function is_entity_header
def test_is_entity_header():
    #
    #  "allow",
    #  "content-encoding",
    #  "content-language",
    #  "content-length",
    #  "content-location",
    #  "content-md5",
    #  "content-range",
    #  "content-type",
    #  "expires",
    #  "last-modified",
    #  "extension-header",
    assert is_entity_header("allow") == True
    assert is_entity_header("content-encoding") == True
    assert is_entity_header("content-language") == True
    assert is_entity_header("content-length") == True
    assert is_entity_header("content-location") == True
    assert is_entity_header("content-md5") == True
    assert is_entity_header