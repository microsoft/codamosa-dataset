

# Generated at 2022-06-21 22:56:21.981880
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(101)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert not has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(400)
    assert has_message_body(401)



# Generated at 2022-06-21 22:56:25.628496
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-location")
    assert is_entity_header("Content-Location")
    assert is_entity_header("content-locationA")
    assert not is_entity_header("content-locate")



# Generated at 2022-06-21 22:56:34.030305
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-length")
    assert is_entity_header("content-type")
    assert is_entity_header("Content-Length")
    assert is_entity_header("Content-Type")
    assert not is_entity_header("host")
    assert not is_entity_header("Host")

# Generated at 2022-06-21 22:56:38.001587
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-length")


# Generated at 2022-06-21 22:56:43.254961
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(206) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(101) == False
    assert has_message_body(102) == False
    assert has_message_body(103) == False
    assert has_message_body(199) == False


# Generated at 2022-06-21 22:56:53.187062
# Unit test for function has_message_body
def test_has_message_body():
    """ Test has_message_body function

    Args:
    none

    Returns:
    None
    """

    assert has_message_body(100) == False
    assert has_message_body(199) == False
    assert has_message_body(200) == True
    assert has_message_body(201) == True
    assert has_message_body(204) == False
    assert has_message_body(300) == True
    assert has_message_body(304) == False
    assert has_message_body(400) == True

# Generated at 2022-06-21 22:56:54.795328
# Unit test for function import_string
def test_import_string():
    """
    runs test for import_string
    """
    import_string("json.JSONEncoder")

# Generated at 2022-06-21 22:57:05.909420
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(300)
    assert has_message_body(301)
    assert has_message_body(400)
    assert has_message_body(401)
    assert has_message_body(402)
    assert has_message_body(403)
    assert has_message_body(404)
    assert has_message_body(500)
    assert has_message_body(501)

# Generated at 2022-06-21 22:57:10.329197
# Unit test for function import_string
def test_import_string():
    import tap
    tap.eq(import_string("tap.Test"), tap.Test)
    tap.eq(import_string("tap.Test").__name__, "Test")
    tap.eq(import_string("tap.Test").__module__, "tap")

if __name__ == "__main__":
    import tap
    tap.run()

# Generated at 2022-06-21 22:57:12.549123
# Unit test for function is_entity_header
def test_is_entity_header():
    for i in _ENTITY_HEADERS:
        assert is_entity_header(i)
    assert not is_entity_header("not an entity header")

# Generated at 2022-06-21 22:57:26.366463
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert is_entity_header("content-encoding")
    assert is_entity_header("content-language")
    assert is_entity_header("content-length")
    assert is_entity_header("content-location")
    assert is_entity_header("content-md5")
    assert is_entity_header("content-range")
    assert is_entity_header("content-type")
    assert is_entity_header("expires")
    assert is_entity_header("last-modified")
    assert not is_entity_header('date')
    assert not is_entity_header('accept')
    assert not is_entity_header('cache-control')
    assert not is_entity_header('location')
    assert is_entity_header('extension-header')


# Generated at 2022-06-21 22:57:29.359860
# Unit test for function is_entity_header
def test_is_entity_header():
    """Unit test for function is_entity_header."""
    for e in _ENTITY_HEADERS:
        assert is_entity_header(e)

    assert not is_entity_header("foo")



# Generated at 2022-06-21 22:57:33.831341
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100)
    assert has_message_body(200)
    assert has_message_body(300)
    assert has_message_body(400)
    assert has_message_body(500)
    assert not has_message_body(204)
    assert not has_message_body(304)

# Generated at 2022-06-21 22:57:42.419278
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(102)
    assert not has_message_body(103)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert has_message_body(500)
    assert has_message_body(501)
    assert has_message_body(502)
    assert has_message_body(503)
    assert has_message_body(504)
    assert has_message_body(505)
    assert has_message_body(506)
    assert has_message_

# Generated at 2022-06-21 22:57:46.846006
# Unit test for function is_entity_header
def test_is_entity_header():
    #assert is_entity_header('cache-control') is False
    assert is_entity_header('Content-Length') is True
    assert is_entity_header('Content-MD5') is True
    assert is_entity_header('content-MD5') is True
    assert is_entity_header('extensio-header') is True

# Generated at 2022-06-21 22:57:51.716772
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)


# Generated at 2022-06-21 22:57:54.476998
# Unit test for function is_entity_header
def test_is_entity_header():
    header = "allow"
    header1 = "header1"
    header2 = "CONTENT-TYPE"

    assert is_entity_header(header)
    assert not is_entity_header(header1)
    assert is_entity_header(header2)

# Generated at 2022-06-21 22:57:58.080687
# Unit test for function has_message_body
def test_has_message_body():
    test_status_codes = [100, 200, 206, 300, 400, 500]

    for status in test_status_codes:
        assert has_message_body(status) is True

    test_status_codes = [204, 304]
    for status in test_status_codes:
        assert has_message_body(status) is False


# Generated at 2022-06-21 22:58:02.383680
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "100",
        "Content-Type": "text/html",
        "Content-Location": "/index.html",
        "Expires": "Mon, 12 Jun 2020 00:00:00 GMT",
    }

    assert remove_entity_headers(headers) == {
        "Content-Location": "/index.html",
        "Expires": "Mon, 12 Jun 2020 00:00:00 GMT",
    }

    assert remove_entity_headers(headers, allowed=()) == {}

# Generated at 2022-06-21 22:58:03.984442
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(204) == False



# Generated at 2022-06-21 22:58:09.628775
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("proxy-connnection") == False
    assert is_hop_by_hop_header("allow") == False
    assert is_hop_by_hop_header("Content-Length") == False
    assert is_hop_by_hop_header("Cache-Control") == False

test_is_hop_by_hop_header()


# Generated at 2022-06-21 22:58:13.709541
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(101)
    assert has_message_body(200)
    assert has_message_body(300)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(400)
    assert has_message_body(500)
    assert not has_message_body(503)



# Generated at 2022-06-21 22:58:25.709445
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    import pytest
    headers = {
        "content-location": "test",
        "content-length": "test",
        "content-language": "test",
        "content-md5": "test",
        "content-range": "test",
        "expires": "test",
        "last-modified": "test",
        "extension-header": "test",
    }
    assert remove_entity_headers(headers) == {
        "content-location": "test",
        "expires": "test",
    }

# Generated at 2022-06-21 22:58:30.239990
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(204) is False
    assert has_message_body(304) is False
    assert has_message_body(101) is False
    assert has_message_body(99) is False
    assert has_message_body(200) is True
    assert has_message_body(418) is True

# Generated at 2022-06-21 22:58:34.609945
# Unit test for function import_string
def test_import_string():
    import sys

    module_name = "http.server"
    assert import_string(module_name) == sys.modules[module_name]

    module_name = "http.server.HTTPServer"
    from http.server import HTTPServer

    assert import_string(module_name) == HTTPServer
    assert isinstance(import_string(module_name), HTTPServer)

# Generated at 2022-06-21 22:58:40.340347
# Unit test for function import_string
def test_import_string():
    from pywebsite.http.wsgi import WSGI
    wsgi = import_string(
        "pywebsite.http.wsgi.WSGI"
    )  # pywebsite.http.wsgi.WSGI
    assert isinstance(wsgi, WSGI)
    wsgi = import_string(
        "pywebsite.http.wsgi"
    )  # pywebsite.http.wsgi
    assert isinstance(wsgi, type(WSGI))
    wsgi = import_string(
        "pywebsite.http"
    )  # pywebsite.http
    assert isinstance(wsgi, type(WSGI))
    wsgi = import_string(
        "pywebsite"
    )  # pywebsite
    assert isinstance(wsgi, type(WSGI))

# Generated at 2022-06-21 22:58:53.352303
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert is_entity_header("content-encoding")
    assert is_entity_header("content-language")
    assert is_entity_header("content-length")
    assert is_entity_header("content-location")
    assert is_entity_header("content-md5")
    assert is_entity_header("content-range")
    assert is_entity_header("content-type")
    assert is_entity_header("expires")
    assert is_entity_header("last-modified")
    assert is_entity_header("extension-header")
    assert not is_entity_header("connection")
    assert not is_entity_header("keep-alive")
    assert not is_entity_header("proxy-authenticate")
    assert not is_entity_header("proxy-authorization")

# Generated at 2022-06-21 22:58:59.298859
# Unit test for function is_entity_header
def test_is_entity_header():
    headers = ["Content-Length", "Content-Type"]
    for header in headers:
        assert is_entity_header(header) is True


# Generated at 2022-06-21 22:59:07.558080
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-type": "application/json",
        "content-location": "example.com",
        "expires": "next week",
        "not-entity": "not-entity",
        "transfer-encoding": "identity"
    }
    headers = remove_entity_headers(headers)
    assert headers == {b'not-entity': b'not-entity', b'transfer-encoding': b'identity'}

# Generated at 2022-06-21 22:59:09.316920
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    header = "connection"
    assert is_hop_by_hop_header(header)

# Generated at 2022-06-21 22:59:17.814372
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header('Connection') == True
    assert is_hop_by_hop_header('CONNECTION') == True
    assert is_hop_by_hop_header('Content-Type') == False
    assert is_hop_by_hop_header('Accept') == False

# Generated at 2022-06-21 22:59:20.116251
# Unit test for function import_string
def test_import_string():
    assert import_string("falcon.api.API") == falcon.API

# Generated at 2022-06-21 22:59:22.901620
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("connection")
    assert not is_hop_by_hop_header("X-Connection")



# Generated at 2022-06-21 22:59:35.221726
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("CONNECTION")
    assert is_hop_by_hop_header("Keep-Alive")
    assert is_hop_by_hop_header("Proxy-Authenticate")
    assert is_hop_by_hop_header("proxy-authorization")
    assert is_hop_by_hop_header("te")
    assert is_hop_by_hop_header("Trailers")
    assert is_hop_by_hop_header("transfer-encoding")
    assert is_hop_by_hop_header("upgrade")

    assert not is_hop_by_hop_header("content-length")
    assert not is_hop_by_hop_header("Server")

# Generated at 2022-06-21 22:59:37.330028
# Unit test for function import_string
def test_import_string():
    import string
    assert import_string("string") == string



# Generated at 2022-06-21 22:59:48.724999
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"content-type": "application/json", "content-length": "0"}
    assert remove_entity_headers(headers) == {"content-length": "0"}
    assert remove_entity_headers(headers, allowed=("content-type",)) == headers

    headers = {"content-type": "application/json", "content-length": "0"}
    assert remove_entity_headers(headers) == {"content-length": "0"}
    assert remove_entity_headers(headers, allowed=("content-type",)) == headers

    headers = {"content-type": "application/json", "content-length": "0"}
    assert remove_entity_headers(headers) == {"content-length": "0"}
    assert remove_entity_headers(headers, allowed=("content-type",)) == headers

# Generated at 2022-06-21 22:59:50.353292
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) is True
    assert has_message_body(100) is False
    assert has_message_body(204) is False
    assert has_message_body(304) is False

# Generated at 2022-06-21 22:59:54.603007
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(101) == False
    assert has_message_body(200) == True
    assert has_message_body(204) == False
    assert has_message_body(204) == False
    assert has_message_body(304) == False

# Generated at 2022-06-21 23:00:00.675444
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type") == True
    assert is_entity_header("Content-Type") == True
    assert is_entity_header("content-encoding") == True
    assert is_entity_header("Content-Encoding") == True
    assert is_entity_header("content-length") == True
    assert is_entity_header("Content-Length") == True
    assert is_entity_header("Content-Range") == True
    assert is_entity_header("content-range") == True
    assert is_entity_header("extension-header") == True
    assert is_entity_header("Extension-Header") == True
    assert is_entity_header("host") == False
    assert is_entity_header("Host") == False


# Generated at 2022-06-21 23:00:13.712552
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Allow": "GET, POST",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Type": "application/json",
        "Content-Length": "1210",
        "Content-Location": "http://127.0.0.1:8080/",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Foo": "Bar",
        "Transfer-Encoding": "chunked",
        "content-Md5": "234092349",
    }
    headers = remove_entity_headers(headers)

# Generated at 2022-06-21 23:00:18.871771
# Unit test for function import_string
def test_import_string():
    from . import test_http
    assert import_string("asyncio.test_http.get_request_headers") == test_http.get_request_headers

# Generated at 2022-06-21 23:00:27.150332
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    r = dict()
    r['Content-Length'] = 4
    r['Content-Type'] = "text/html"
    r['Content-Language'] = "en"
    r['Content-Location'] = "test"
    r['Expires'] = "Today"
    r = remove_entity_headers(r)
    assert 'Content-Length' not in r
    assert 'Content-Type' not in r
    assert 'Content-Language' not in r
    assert 'Content-Location' in r
    assert 'Expires' in r

# Generated at 2022-06-21 23:00:38.526665
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-type": "text/plain", "From": "user@example.com"}
    assert {"From": "user@example.com"} == remove_entity_headers(headers)

    headers = {"Host": "www.example.org", "Date": "Sat, 04 Apr 2020 20:52:52 GMT"}
    assert {"Host": "www.example.org", "Date": "Sat, 04 Apr 2020 20:52:52 GMT"} == remove_entity_headers(headers)

    headers = {"Content-type": "text/plain", "From": "user@example.com", "Host": "www.example.org"}
    assert {"From": "user@example.com", "Host": "www.example.org"} == remove_entity_headers(headers)


# Generated at 2022-06-21 23:00:43.044446
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert is_entity_header("content-length")
    assert not is_entity_header("user-agent")
    assert not is_entity_header("USER-AGENT")

# Generated at 2022-06-21 23:00:50.934586
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow") == True
    assert is_entity_header("Content-Encoding") == True
    assert is_entity_header("Content-LanguagE") == True
    assert is_entity_header("Content-length") == True
    assert is_entity_header("Content-Location") == True
    assert is_entity_header("Content-MD5") == True
    assert is_entity_header("Content-range") == True
    assert is_entity_header("Content-type") == True
    assert is_entity_header("Expires") == True
    assert is_entity_header("Last-modified") == True
    assert is_entity_header("extension-header") == True
    assert is_entity_header("Connection") == False
    assert is_entity_header("keep-alive") == False

# Generated at 2022-06-21 23:01:01.615393
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow") == True
    assert is_entity_header("content-encoding") == True
    assert is_entity_header("content-language") == True
    assert is_entity_header("content-length") == True
    assert is_entity_header("content-location") == True
    assert is_entity_header("content-md5") == True
    assert is_entity_header("content-range") == True
    assert is_entity_header("content-type") == True
    assert is_entity_header("expires") == True
    assert is_entity_header("last-modified") == True
    assert is_entity_header("extension-header") == True
    assert is_entity_header("Server") == False
    assert is_entity_header("Date") == False

# Generated at 2022-06-21 23:01:06.829734
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    # Test lower and upper case
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("Connection")
    # Test one of the headers
    assert is_hop_by_hop_header("keep-alive")
    # Test non existent header
    assert not is_hop_by_hop_header("test")


# Generated at 2022-06-21 23:01:11.652896
# Unit test for function is_entity_header
def test_is_entity_header():
    entity_header = "Content-Encoding"
    non_entity_header = "Server"
    assert is_entity_header(entity_header)
    assert not is_entity_header(non_entity_header)


# Generated at 2022-06-21 23:01:17.711008
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(206)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert not has_message_body(199)



# Generated at 2022-06-21 23:01:22.611127
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert not is_hop_by_hop_header("Content-Type")
    assert not is_hop_by_hop_header("this does not exist")

# Generated at 2022-06-21 23:01:30.498495
# Unit test for function import_string
def test_import_string():
    from pathlib import Path
    from os import makedirs
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    package = TemporaryDirectory()
    package_name = "foo"
    module_name = "new_module"
    file_name = "new_file"
    class_name = "NewClass"
    module_with_file = f"{package_name}.{module_name}"
    class_with_file = f"{package_name}.{file_name}.{class_name}"
    module_path = Path(package.name, package_name)
    makedirs(module_path)

# Generated at 2022-06-21 23:01:37.647036
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert(is_hop_by_hop_header("connection") == True)
    assert(is_hop_by_hop_header("keep-alive") == True)
    assert(is_hop_by_hop_header("proxy-authenticate") == True)
    assert(is_hop_by_hop_header("proxy-authorization") == True)
    assert(is_hop_by_hop_header("te") == True)
    assert(is_hop_by_hop_header("trailers") == True)
    assert(is_hop_by_hop_header("transfer-encoding") == True)
    assert(is_hop_by_hop_header("upgrade") == True)
    assert(is_hop_by_hop_header("Accept") == False)

test_is_hop_by_hop_header()


# Generated at 2022-06-21 23:01:43.550574
# Unit test for function import_string
def test_import_string():
    assert import_string("pydantic.schema.Schema")
    assert import_string("pydantic.main.BaseModel")
    assert import_string("pydantic.main.BaseModel").schema



# Generated at 2022-06-21 23:01:46.675587
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(101)
    assert has_message_body(200)



# Generated at 2022-06-21 23:01:51.809868
# Unit test for function is_entity_header
def test_is_entity_header():
    """Test function is_entity_header"""
    assert is_entity_header("content-type")
    assert is_entity_header("te")
    assert not is_entity_header("server")
    assert not is_entity_header("foo-bar")

# Generated at 2022-06-21 23:01:54.149733
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection") == True
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("random") == False

# Generated at 2022-06-21 23:01:56.264978
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Type")
    assert not is_entity_header("Server")



# Generated at 2022-06-21 23:01:58.919734
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(100) == False
    assert has_message_body(200) == True

# Generated at 2022-06-21 23:02:10.654972
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert not is_hop_by_hop_header("Content-Length")
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("Keep-alive")
    assert is_hop_by_hop_header("Proxy-Authenticate")
    assert is_hop_by_hop_header("proxy-authorization")
    assert is_hop_by_hop_header("te")
    assert is_hop_by_hop_header("Trailers")
    assert is_hop_by_hop_header("Transfer-Encoding")
    assert is_hop_by_hop_header("upgrade")


if __name__ == "__main__":
    test_is_hop_by_hop_header()

# Generated at 2022-06-21 23:02:22.128678
# Unit test for function remove_entity_headers

# Generated at 2022-06-21 23:02:26.739557
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header('Content-Encoding')
    assert is_entity_header('Content-Language')
    assert is_entity_header('Content-Length')
    assert not is_entity_header('Connection')


# Generated at 2022-06-21 23:02:36.266080
# Unit test for function import_string
def test_import_string():
    """Should returns an object with callable method 'hello'"""
    class Hello:
        def hello(self):
            return "world"
    from contextlib import redirect_stdout
    from io import StringIO
    hello = StringIO()
    with redirect_stdout(hello):
        a = import_string("web.standard.test_standard.Hello")
        a.hello()
    assert hello.getvalue() == "world\n"


# Generated at 2022-06-21 23:02:38.054516
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header('connection')
    assert is_hop_by_hop_header('CONNECTION')
    assert not is_hop_by_hop_header('user-agent')

# Generated at 2022-06-21 23:02:40.463689
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type")
    assert not is_entity_header("x-forwarded-for")

# Generated at 2022-06-21 23:02:50.565833
# Unit test for function is_entity_header
def test_is_entity_header():
    assert(is_entity_header("Content-Length") == True)
    assert(is_entity_header("content-length") == True)
    assert(is_entity_header("Content-length") == True)
    assert(is_entity_header("Content-type") == True)
    assert(is_entity_header("content-type") == True)
    assert(is_entity_header("Content-Type") == True)
    assert(is_entity_header("Content-Language") == True)
    assert(is_entity_header("content-language") == True)
    assert(is_entity_header("Content-language") == True)
    assert(is_entity_header("Content-languagE") == True)
    assert(is_entity_header("content-languagE") == True)

# Generated at 2022-06-21 23:03:01.107935
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "content-encoding": "gzip",
        "date": "Wed, 29 Jul 2015 09:37:27 GMT",
        "accept-ranges": "bytes",
        "content-location": "index.html",
        "content-type": "text/html"
    }
    assert is_entity_header("Accept-Ranges") == False
    assert is_entity_header("content-type") == True
    assert is_entity_header("content-Location") == True
    assert is_entity_header("content-location") == True
    assert remove_entity_headers(headers) == {
        "date": "Wed, 29 Jul 2015 09:37:27 GMT",
        "accept-ranges": "bytes",
        "content-location": "index.html",
    }



# Generated at 2022-06-21 23:03:10.985631
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    '''Test function is_hop_by_hop_header'''
    assert is_hop_by_hop_header('Connection') == True
    assert is_hop_by_hop_header('Keep-Alive') == True
    assert is_hop_by_hop_header('proxy-authenticate') == True
    assert is_hop_by_hop_header('proxy-authorization') == True
    assert is_hop_by_hop_header('TE') == True
    assert is_hop_by_hop_header('Trailers') == True
    assert is_hop_by_hop_header('traNsfEr-EnCoDiNG') == True
    assert is_hop_by_hop_header('Upgrade') == True
    assert is_hop_by_hop_header('Via') == False


# Generated at 2022-06-21 23:03:16.819744
# Unit test for function import_string
def test_import_string():
    # Import module
    mod = import_string("meinheld.server")
    assert "Server" in dir(mod)

    # Import class and instanciate it
    obj = import_string("meinheld.server.Server")
    assert "run" in dir(obj)

# Generated at 2022-06-21 23:03:19.384927
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("cOnnEctIon")


# Generated at 2022-06-21 23:03:21.034420
# Unit test for function is_entity_header
def test_is_entity_header():
    for name in _ENTITY_HEADERS:
        assert is_entity_header(name) is True, "{0} should be an entity header".format(name)



# Generated at 2022-06-21 23:03:26.680432
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type")
    assert not is_entity_header("mime-type")
    assert not is_entity_header("x-nonsense")


# Generated at 2022-06-21 23:03:37.924455
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type") == True
    assert is_entity_header("content-length") == True
    assert is_entity_header("content-location") == True
    assert is_entity_header("content-md5") == True
    assert is_entity_header("content-range") == True
    assert is_entity_header("expires") == True
    assert is_entity_header("last-modified") == True
    assert is_entity_header("extension-header") == True
    assert is_entity_header("allow") == True
    assert is_entity_header("Accept-Encoding") == True
    assert is_entity_header("content-encoding") == True
    assert is_entity_header("content-language") == True
    assert is_entity_header("Server") == False
    assert is_entity

# Generated at 2022-06-21 23:03:51.382404
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    test = {
        "Content-Encoding": "gzip",
        "Content-Language": "fr",
        "Content-Length": "348",
        "Content-Location": "http://www.w3.org/pub/WWW/People.html",
        "Content-MD5": "Q2hlY2sgSW50ZWdyaXR5IQ==",
        "Content-Range": "bytes 21010-47021/47022",
        "Content-Type": "text/html",
        "Expires": "Tue, 04 Dec 2018 12:45:26 GMT",
        "Last-Modified": "Tue, 04 Dec 2018 12:45:26 GMT",
        "Extension-Header": "FooBar",
    }

# Generated at 2022-06-21 23:04:01.752129
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    Test remove_entity_headers function
    """
    headers = {
        "content-location": "my-location",
        "content-type": "text/html",
        "content-language": "es-es",
        "content-length": "1024",
        "content-md5": "hash",
        "content-range": "bytes 0-499/10000",
        "expires": "Fri, 31 Dec 1999 23:59:59 GMT",
        "last-modified": "Mon, 1 Jan 2018 12:00:00 GMT",
        "extension-header": "my-extension-header",
        "allowed": "GET,POST",
    }
    headers = remove_entity_headers(headers, allowed=("content-location", "expires"))
    assert "content-location" in headers
    assert "expires"

# Generated at 2022-06-21 23:04:11.381966
# Unit test for function import_string
def test_import_string():
    """Test for function import_string"""
    import sys
    import http.server
    assert isinstance(import_string(__name__), sys.modules[__name__].__class__)
    assert isinstance(import_string(__name__ + ".TCPServer"), http.server.TCPServer)
    assert import_string(__name__).__name__ == __name__
    assert import_string(__name__ + ".TCPServer").__name__ == "TCPServer"
    assert import_string(__name__ + ".Server").__name__ == "Server"

# Generated at 2022-06-21 23:04:13.553627
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(100) == False
    assert has_message_body(204) == False
    assert has_message_body(304) == False

# Generated at 2022-06-21 23:04:23.361212
# Unit test for function import_string
def test_import_string():
    import unittest
    import datetime
    from collections import defaultdict
    import json

    class A(object):
        pass

    class B(object):
        pass

    class TestImportString(unittest.TestCase):
        def test_no_path(self):
            obj = import_string("os.path")
            self.assertTrue(isinstance(obj, type(os.path)))

        def test_with_no_class_name_in_path(self):
            module = import_string("datetime")
            self.assertTrue(isinstance(module, type(datetime)))

        def test_with_class_name_in_path(self):
            obj = import_string("datetime.datetime")
            self.assertTrue(isinstance(obj, datetime.datetime))


# Generated at 2022-06-21 23:04:31.384206
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(199)
    assert has_message_body(199)
    assert has_message_body(299)
    assert not has_message_body(300)
    assert not has_message_body(399)

# Generated at 2022-06-21 23:04:40.928451
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": "10",
        "Content-Encoding": "gzip",
        "Content-Language": "es",
        "Content-Location": "foo",
        "Content-MD5": "hash",
        "Content-Range": "bytes",
        "Content-Type": "text",
        "Expires": "date",
        "Last-Modified": "date",
        "Extension-Header": "foo",
    }
    headers = remove_entity_headers(headers)
    assert headers == {"Content-Location": "foo", "Expires": "date"}

# Generated at 2022-06-21 23:04:47.239455
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(100)
    assert has_message_body(101)
    assert has_message_body(200)
    assert not has_message_body(204)
    assert not has_message_body(304)

