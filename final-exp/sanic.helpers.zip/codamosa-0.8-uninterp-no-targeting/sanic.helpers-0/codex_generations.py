

# Generated at 2022-06-21 22:56:30.740207
# Unit test for function has_message_body
def test_has_message_body():
    for status in (100, 101):
        assert not has_message_body(status)
    for status in (200, 201):
        assert has_message_body(status)
    assert not has_message_body(204)
    assert not has_message_body(304)

# Generated at 2022-06-21 22:56:38.830267
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(status=304)
    assert not has_message_body(status=204)
    assert not has_message_body(status=200)
    assert not has_message_body(status=101)
    assert not has_message_body(status=102)
    assert has_message_body(status=99)
    assert has_message_body(status=103)
    assert has_message_body(status=404)
    assert has_message_body(status=500)
    assert has_message_body(status=100)



# Generated at 2022-06-21 22:56:44.412590
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert not has_message_body(304)
    assert has_message_body(400)
    assert has_message_body(401)
    assert has_message_body(402)
    assert has_message_body(403)
    assert has_message_body(404)
    assert has_message_body(405)

# Generated at 2022-06-21 22:56:53.887982
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection")
    assert is_hop_by_hop_header("Keep-Alive")
    assert is_hop_by_hop_header("Proxy-Authenticate")
    assert is_hop_by_hop_header("Proxy-Authorization")
    assert is_hop_by_hop_header("TE")
    assert is_hop_by_hop_header("trailers")
    assert is_hop_by_hop_header("Transfer-Encoding")
    assert is_hop_by_hop_header("upgrade")


# Generated at 2022-06-21 22:57:04.920094
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Date": "Tue, 15 Nov 1994 08:12:31 GMT",
        "Server": "Apache/2.4.1 (Unix) OpenSSL/1.0.1e-fips",
        "Last-Modified": "Wed, 21 Oct 2015 07:28:00 GMT",
        "Etag": '"359670651+gzip+ident"',
        "Accept-Ranges": "bytes",
        "Content-Length": "4261",
        "Vary": "Accept-Encoding",
        "Connection": "close",
        "Content-Type": "text/html",
        "Expires": "Wed, 15 Nov 2017 08:12:31 GMT",
        "Cache-Control": "max-age=86400",
        "Age": "52002",
    }

    assert remove_entity_

# Generated at 2022-06-21 22:57:11.473078
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "allow": "GET,PUT",
        "content-encoding": "gzip",
        "content-length": "10",
        "content-location": "",
        "content-md5": "",
        "content-range": "",
        "content-type": "text/html",
        "expires": "",
        "last-modified": "",
        "extension-header": "",
    }
    expected_headers = {
        "allow": "GET,PUT",
        "content-location": "",
        "expires": "",
    }
    result = remove_entity_headers(headers, allowed=("content-location", "expires"))
    assert result == expected_headers

# Generated at 2022-06-21 22:57:18.860544
# Unit test for function is_entity_header
def test_is_entity_header():
    """ test if the is_entity_header function works properly
    """
    assert is_entity_header('allow')
    assert is_entity_header('content-encoding')
    assert is_entity_header('content-language')
    assert is_entity_header('content-length')
    assert is_entity_header('content-location')
    assert is_entity_header('content-md5')
    assert is_entity_header('content-range')
    assert is_entity_header('content-type')
    assert is_entity_header('expires')
    assert is_entity_header('last-modified')
    assert is_entity_header('extension-header')
    assert not is_entity_header('connection')
    assert not is_entity_header('keep-alive')

# Generated at 2022-06-21 22:57:22.047057
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Allow")
    assert is_entity_header("allow")
    assert not is_entity_header("Accept")
    assert not is_entity_header("accept")

# Generated at 2022-06-21 22:57:24.564173
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type")
    assert not is_entity_header("user-agent")


# Generated at 2022-06-21 22:57:31.310779
# Unit test for function import_string
def test_import_string():
    from importlib import reload
    from types import ModuleType

    import pblog

    class Mod():
        pass

    mod = Mod()
    assert import_string("pblog") == pblog
    assert isinstance(import_string("obj:pblog"), ModuleType)
    assert import_string("tests.test_http_utils:Mod") == Mod
    assert isinstance(import_string("tests.test_http_utils:Mod()"), Mod)
    reload(pblog)
    assert import_string("tests.test_http_utils:Mod") == Mod

# Generated at 2022-06-21 22:57:34.914938
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert is_entity_header("Accept")
    assert is_entity_header("content-range")
    assert is_entity_header("content-type")
    assert not is_entity_header("foo-bar")



# Generated at 2022-06-21 22:57:43.427063
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(1)
    assert not has_message_body(10)
    assert not has_message_body(99)
    assert has_message_body(100)
    assert has_message_body(101)
    assert has_message_body(102)
    assert has_message_body(103)
    assert has_message_body(104)
    assert has_message_body(199)
    assert has_message_body(200)
    assert has_message_body(201)
    assert has_message_body(202)
    assert has_message_body(203)
    assert not has_message_body(204)
    assert has_message_body(205)
    assert has_message_body(206)
    assert has_message_body(207)

# Generated at 2022-06-21 22:57:52.745095
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        b"Content-Language": b"en-US",
        b"allow": b"None",
        b"Content-Type": b"utf-8",
        b"Location": b"Somewhere",
        b"Last-Modified": b"today",
    }

    headers = remove_entity_headers(headers)
    assert headers == {
        b"Allow": b"None",
        b"Location": b"Somewhere",
    }

    headers = {
        b"Content-Location": b"Somewhere",
        b"Expires": b"Never",
    }
    headers = remove_entity_headers(headers)
    assert headers == {}


# Generated at 2022-06-21 22:58:00.498172
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "ABC": "123",
        "Date": "123",
        "Content-Length": "123",
        "Content-Language": "123",
        "Content-Location": "123",
        "Content-Type": "123",
        "DNT": "123",
        "Expires": "123",
        "P3P": "123",
        "WWW-Authenticate": "123",
        "X-Frame-Options": "123",
    }
    expected = {
        "ABC": "123",
        "Content-Location": "123",
        "DNT": "123",
        "Expires": "123",
        "P3P": "123",
        "WWW-Authenticate": "123",
        "X-Frame-Options": "123",
    }

    headers = remove_

# Generated at 2022-06-21 22:58:01.857706
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("CONTENT-LENGTH")
    assert is_entity_header("content-length")



# Generated at 2022-06-21 22:58:03.880645
# Unit test for function has_message_body
def test_has_message_body():
    import pytest
    assert has_message_body(404)
    assert not has_message_body(1)
    assert not has_message_body(204)
    assert has_message_body(200)
    assert not has_message_body(304)



# Generated at 2022-06-21 22:58:07.942617
# Unit test for function import_string
def test_import_string():
    import trio
    import trio_websocket as websocket
    assert import_string("trio") == trio
    assert websocket == import_string("trio_websocket")
    assert isinstance(import_string("trio_websocket.WebSocketConnection"),
                      websocket.WebSocketConnection)
    assert isinstance(import_string("trio_websocket.ClientWebSocketConnection"),
                      websocket.ClientWebSocketConnection)
    assert isinstance(import_string("trio_websocket.ServerWebSocketConnection"),
                      websocket.ServerWebSocketConnection)
    assert isinstance(import_string("trio_websocket.WebSocketError"),
                      websocket.WebSocketError)

# Generated at 2022-06-21 22:58:10.653054
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header('connection')
    assert is_hop_by_hop_header('CONNECTION')
    assert is_hop_by_hop_header('content-type') is False


# Generated at 2022-06-21 22:58:12.254292
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-type") == True
    assert is_entity_header("foo") == False


# Generated at 2022-06-21 22:58:15.076205
# Unit test for function is_entity_header
def test_is_entity_header():
    """
    Tests is_entity_header function
    """
    assert not is_entity_header("")
    assert not is_entity_header("ciao")
    assert is_entity_header("content-encoding")
    assert is_entity_header("Content-Encoding")


# Generated at 2022-06-21 22:58:25.665175
# Unit test for function import_string
def test_import_string():
    """
    test for function import_string
    """
    # Test for import module
    import sys
    import os

    assert import_string("sys") == sys
    assert import_string("os") == os
    assert import_string("__builtin__.dict") == dict

    # Test for import class
    from pathlib import Path
    assert import_string("pathlib.Path") == Path()


# TODO Move to another module

# Generated at 2022-06-21 22:58:31.291298
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("content-language") == True
    assert is_entity_header("Content-Language") == True
    assert is_entity_header("CONTENT-Language") == True
    assert is_entity_header("content-Location") == True
    assert is_entity_header("content-location") == True
    assert is_entity_header("Content-location") == True


# Generated at 2022-06-21 22:58:36.080817
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("CONNECTION")
    assert is_hop_by_hop_header("CONNECTION")
    assert is_hop_by_hop_header("CONNECTION")
    assert is_hop_by_hop_header("CONNECTION")
    assert is_hop_by_hop_header("CONNECTION")



# Generated at 2022-06-21 22:58:45.348950
# Unit test for function import_string
def test_import_string():
    class X:
        pass

    # Import a package
    package = import_string(__name__)
    assert ismodule(package)
    assert package.__name__ == __name__

    # Import a module
    module = import_string(__name__ + ".impl")
    assert ismodule(module)
    assert module.__name__ == __name__ + ".impl"

    # Import a class
    klass = import_string(__name__ + ".impl.X")
    assert klass.__class__ == X

    # Import and instantiated a class
    instance = import_string(__name__ + ".impl.X")
    assert instance.__class__ == X



# Generated at 2022-06-21 22:58:51.942466
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Length": 200,
        "Content-Type": b"text",
        "Expires": "yesterday",
        "Via": "this and that",
    }

    headers = remove_entity_headers(headers)

    assert "Content-Length" not in headers
    assert "Content-Type" not in headers
    assert "Expires" not in headers
    assert "Via" in headers

# Generated at 2022-06-21 22:58:57.818772
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header(b"connection")
    assert is_hop_by_hop_header(b"CONNECTION")
    assert is_hop_by_hop_header(b"coNNection")
    assert not is_hop_by_hop_header(b"connectionfoo")



# Generated at 2022-06-21 22:59:08.617116
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header('Connection') == True
    assert is_hop_by_hop_header('Transfer-Encoding') == True
    assert is_hop_by_hop_header('Trailers') == True
    assert is_hop_by_hop_header('Upgrade') == True
    assert is_hop_by_hop_header('Date') == False
    assert is_hop_by_hop_header('If-Modified-Since') == False
    assert is_hop_by_hop_header('Content-Type') == False
    assert is_hop_by_hop_header('Content-Length') == False


# Generated at 2022-06-21 22:59:10.496682
# Unit test for function import_string
def test_import_string():
    assert import_string("test.test_base:test_import_string") == test_import_string

# Generated at 2022-06-21 22:59:24.278786
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    This function tests the remove_entity_headers function
    """

# Generated at 2022-06-21 22:59:34.124203
# Unit test for function is_entity_header
def test_is_entity_header():
    """Test to check if the header is an entity header"""
    response = is_entity_header("Content-Type")
    assert response is True, "Failed for header Content-Type"
    response = is_entity_header("content-type")
    assert response is True, "Failed for header content-type"
    response = is_entity_header("Content-type")
    assert response is True, "Failed for header Content-type"
    response = is_entity_header("content-Type")
    assert response is True, "Failed for header content-Type"



# Generated at 2022-06-21 22:59:49.183170
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    header = 'Connection'
    assert is_hop_by_hop_header(header) == True
    header = 'Keep-Alive'
    assert is_hop_by_hop_header(header) == True
    header = 'Proxy-Authenticate'
    assert is_hop_by_hop_header(header) == True
    header = 'Proxy-Authorization'
    assert is_hop_by_hop_header(header) == True
    header = 'Te'
    assert is_hop_by_hop_header(header) == True
    header = 'Trailers'
    assert is_hop_by_hop_header(header) == True
    header = 'Transfer-Encoding'
    assert is_hop_by_hop_header(header) == True
    header = 'Upgrade'
    assert is_hop_by_hop_header

# Generated at 2022-06-21 22:59:57.752237
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    from os import path
    from tempfile import TemporaryDirectory
    from beirse.cache import DiskCache, MultiCache

    with TemporaryDirectory() as tmpdir:
        cache = MultiCache([DiskCache(path.join(tmpdir, "test"))])

    key = "/test"
    response = b"test"
    cache.set(key, response, headers={"Content-Type": "text/html"})

    class TestClass:
        pass

    headers = cache.get(key)[1]
    headers = remove_entity_headers(headers)
    assert "Content-Type" in headers
    assert "Content-Length" not in headers

# Generated at 2022-06-21 23:00:05.268392
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(199)
    assert has_message_body(202)
    assert has_message_body(299)
    assert has_message_body(302)
    assert has_message_body(403)
    assert not has_message_body(100)
    assert not has_message_body(304)
    assert not has_message_body(204)
    assert not has_message_body(304)



# Generated at 2022-06-21 23:00:07.258312
# Unit test for function is_entity_header
def test_is_entity_header():
    """
    Test if the given header is an Entity Header
    """
    assert is_entity_header("expires")



# Generated at 2022-06-21 23:00:08.996319
# Unit test for function import_string
def test_import_string():
    class_str = "http.server.HTTPRequestHandler"
    import_string(class_str)

test_import_string()

# Generated at 2022-06-21 23:00:17.338034
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Connection": "keep-alive",
        "Transfer-Encoding": "chunked",
        "Content-MD5": "lalala",
        "Cache-Control": "private",
        "Content-Length": "123",
        "Date": "Tue, 09 Jul 2013 22:07:45 GMT",
        "Server": "Proxy/2.0",
        "Via": "1.1 proxy",
    }
    headers_no_entity = remove_entity_headers(headers)
    assert "Connection" in headers_no_entity
    assert "Transfer-Encoding" not in headers_no_entity
    assert "Content-MD5" not in headers_no_entity
    assert "Cache-Control" in headers_no_entity
    assert "Content-Length" not in headers_no_entity

# Generated at 2022-06-21 23:00:28.851407
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {"Content-Type": "application/json", "Content-Location": "test"}
    headers = remove_entity_headers(headers)
    assert "content-location" in headers
    assert "content-type" not in headers

    headers = {
        "Content-Type": "application/json",
        "Content-Location": "test",
        "Expires": "2019",
    }
    headers = remove_entity_headers(headers)
    assert "content-location" in headers
    assert "content-type" not in headers
    assert "expires" in headers

    headers = {"Content-Type": "application/json", "Content-Location": "test"}
    headers = remove_entity_headers(headers, ["content-type"])
    assert "content-location" in headers
    assert "content-type" in headers


# Generated at 2022-06-21 23:00:36.262905
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    remove_entity_headers test function
    """
    headers = {
        "Content-Location": "https://www.google.com/",
        "Content-Type": "text/html",
        "Content-Language": "english",
    }
    response = remove_entity_headers(headers)
    assert "Content-Location" in response
    assert "Content-Type" not in response
    assert "Content-Language" not in response

# Generated at 2022-06-21 23:00:41.087050
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(200) == True
    assert has_message_body(100) == False
    assert has_message_body(204) == False
    assert has_message_body(304) == False


# Generated at 2022-06-21 23:00:42.754975
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(300)



# Generated at 2022-06-21 23:00:53.965888
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    headers = _HOP_BY_HOP_HEADERS
    for header in headers:
        assert is_hop_by_hop_header(header) is True
    headers = ["", "10", "a", "A", "&", "_", "-", " ", "nonexistent-header"]
    for header in headers:
        assert is_hop_by_hop_header(header) is False

# Generated at 2022-06-21 23:00:57.795006
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("CONNECTION")
    assert not is_hop_by_hop_header("content-type")
    assert not is_hop_by_hop_header("content-type")


# Generated at 2022-06-21 23:01:08.140304
# Unit test for function is_entity_header
def test_is_entity_header():
    assert not is_entity_header("something")
    assert not is_entity_header("seeminglyrandom")
    assert is_entity_header("allow")
    assert is_entity_header("content-encoding")
    assert is_entity_header("content-language")
    assert is_entity_header("content-length")
    assert is_entity_header("content-location")
    assert is_entity_header("content-md5")
    assert is_entity_header("content-range")
    assert is_entity_header("content-type")
    assert is_entity_header("expires")
    assert is_entity_header("last-modified")
    assert not is_entity_header("extension-header")


# Generated at 2022-06-21 23:01:14.480093
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    """
    Test remove_entity_headers function
    """
    headers = {
        "Host": "example.com",
        "Range": "bytes=0-1023",
        "Content-Type": "text/html; charset=UTF-8",
        "Content-Location": "index.html",
        "Content-Length": "123",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }
    headers_to_assert = {
        "Host": "example.com",
        "Range": "bytes=0-1023",
        "Content-Location": "index.html",
        "Expires": "Wed, 21 Oct 2015 07:28:00 GMT",
    }

# Generated at 2022-06-21 23:01:22.915918
# Unit test for function has_message_body
def test_has_message_body():
    """test_has_message_body: test cases for has_message_body function"""
    assert has_message_body(2) is False
    assert has_message_body(100) is False
    assert has_message_body(199) is False
    assert has_message_body(204) is False
    assert has_message_body(304) is False
    assert has_message_body(200) is True


# Generated at 2022-06-21 23:01:26.122607
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    # pylint: disable=redefined-outer-name
    from .http_parser import USER_AGENT
    assert is_hop_by_hop_header(USER_AGENT)



# Generated at 2022-06-21 23:01:33.793181
# Unit test for function import_string
def test_import_string():
    module = {'__name__': 'mock_module'}
    obj = {'__class__': MockClass}
    with patch("ti.core.http.request.import_module", return_value=module):
        with patch("ti.core.http.request.getattr", return_value=obj):
            assert import_string("mock.path") == MockClass()


# Generated at 2022-06-21 23:01:40.936462
# Unit test for function import_string
def test_import_string():
    class Foo:
        pass

    from httpcore.httpprotocol.protocol import test_import_string as func_under_test
    import sys

    class_path = f"{__name__}.{test_import_string.__qualname__}.Foo"
    mod_path = f"{__name__}.{test_import_string.__qualname__}"

    if "coverage" in sys.modules:
        class_path = f"{__name__}..{test_import_string.__qualname__}.Foo"
        mod_path = f"{__name__}..{test_import_string.__qualname__}"

    assert func_under_test(f"{class_path}") is Foo()
    assert func_under_test(f"{mod_path}") is func_under_test


# Generated at 2022-06-21 23:01:44.227805
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    """Unit test for function is_hop_by_hop_header"""
    assert is_hop_by_hop_header("Connection") is True

# Generated at 2022-06-21 23:01:52.865900
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header('Connection')
    assert is_hop_by_hop_header('connection')
    assert is_hop_by_hop_header('CONNECTION')
    assert is_hop_by_hop_header('Keep-Alive')
    assert is_hop_by_hop_header('keep-alive')
    assert is_hop_by_hop_header('KEEP-ALIVE')
    assert is_hop_by_hop_header('Proxy-Authenticate')
    assert is_hop_by_hop_header('proxy-authenticate')
    assert is_hop_by_hop_header('PROXY-AUTHENTICATE')
    assert is_hop_by_hop_header('Proxy-Authorization')
    assert is_hop_by_hop_header('proxy-authorization')

# Generated at 2022-06-21 23:02:08.730075
# Unit test for function has_message_body
def test_has_message_body():
    assert has_message_body(201) == True
    assert has_message_body(204) == False
    assert has_message_body(304) == False
    assert has_message_body(100) == False
    assert has_message_body(200) == True
    assert has_message_body(300) == True
if __name__ == '__main__':
    print("Testing function has_message_body:")
    test_has_message_body()

# Generated at 2022-06-21 23:02:14.275518
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(100)
    assert has_message_body(101)
    assert has_message_body(204)
    assert not has_message_body(304)
    assert has_message_body(500)


# Generated at 2022-06-21 23:02:16.348805
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Connection") is True

# Generated at 2022-06-21 23:02:19.213036
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Language")
    assert not is_entity_header("Cache-Control")
    assert is_entity_header("content-length")
    assert not is_entity_header("Cache-Control")


# Generated at 2022-06-21 23:02:23.604743
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("TE")
    assert is_hop_by_hop_header("connection")
    assert is_hop_by_hop_header("Connection")
    assert not is_hop_by_hop_header("via")
    assert not is_hop_by_hop_header("Via")


# Generated at 2022-06-21 23:02:29.882429
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        "Content-Location": "/",
        "Content-Encoding": "gzip",
        "Content-Language": "en",
        "Content-Length": "33",
        "Content-MD5": "123",
        "Content-Range": "bytes 200-1000/67589",
        "Content-Type": "text/html",
        "Expires": "Mon, 03 Aug 2020 00:00:00 GMT",
        "Last-Modified": "Sun, 02 Aug 2020 09:52:26 GMT",
        "Extension-Header": "extended",
    }
    assert remove_entity_headers(headers) == {
        "Content-Location": "/",
        "Expires": "Mon, 03 Aug 2020 00:00:00 GMT",
    }

# Generated at 2022-06-21 23:02:35.212549
# Unit test for function import_string
def test_import_string():
    assert import_string("shove.tests.test_http_utils:test_import_string") == import_string


if __name__ == "__main__":
    test_import_string()

# Generated at 2022-06-21 23:02:43.134672
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    assert is_hop_by_hop_header("Sec-Websocket-Accept") == False
    assert is_hop_by_hop_header("Connection") == True
    assert is_hop_by_hop_header("Upgrade") == True
    assert is_hop_by_hop_header("Proxy-Authenticate") == True
    assert is_hop_by_hop_header("Proxy-Authorization") == True
    assert is_hop_by_hop_header("Te") == True
    assert is_hop_by_hop_header("Trailers") == True
    assert is_hop_by_hop_header("Transfer-Encoding") == True
    assert is_hop_by_hop_header("Upgrade") == True


# Generated at 2022-06-21 23:02:46.294563
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Length") == True
    assert is_entity_header("Server") == False


# Generated at 2022-06-21 23:02:49.144285
# Unit test for function import_string
def test_import_string():
    assert import_string("http.client.HTTPConnection") == import_module("http.client").HTTPConnection
    assert import_string("falcon.API") == import_module("falcon").API
    assert import_string("falcon.request") == import_module("falcon").request



# Generated at 2022-06-21 23:03:11.504363
# Unit test for function is_hop_by_hop_header
def test_is_hop_by_hop_header():
    header = 'Connection'
    assert is_hop_by_hop_header(header) is True
    header = 'Keep-Alive'
    assert is_hop_by_hop_header(header) is True
    header = 'proxy-authenticate'
    assert is_hop_by_hop_header(header) is True
    header = 'Proxy-Authorization'
    assert is_hop_by_hop_header(header) is True
    header = 'TE'
    assert is_hop_by_hop_header(header) is True
    header = 'Trailers'
    assert is_hop_by_hop_header(header) is True
    header = 'Transfer-Encoding'
    assert is_hop_by_hop_header(header) is True
    header = 'Upgrade'
    assert is_hop_by_hop_header

# Generated at 2022-06-21 23:03:21.690411
# Unit test for function import_string
def test_import_string():
    """
    Test import_string method
    """
    from httpolice import version
    from httpolice.citation import Citation
    from httpolice.known import polyfills

    assert import_string("httpolice.version") == version
    assert import_string("httpolice.known.polyfills") == polyfills

    # With a class.
    citation = import_string("httpolice.citation.Citation")
    assert citation.__name__ == "Citation"
    assert citation.__module__ == "httpolice.citation"

    # With a module.
    known = import_string("httpolice.known")
    assert known.__name__ == "httpolice.known"

# Generated at 2022-06-21 23:03:22.859405
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("allow")
    assert not is_entity_header("cache-control")


# Generated at 2022-06-21 23:03:28.149382
# Unit test for function import_string
def test_import_string():
    """Unit test for function import_string"""
    import http.cookies as module
    class Foo:
        test = True

    # Test importing module
    assert import_string("http.cookies") is module
    # Test importing class and instanciating
    assert import_string("http.cookies.Foo") is Foo()
    # Test importing module and class
    assert import_string("http.cookies.Foo", package="http") is Foo()
    # Test no klass is given to import_string
    assert import_string("http.cookies", package="http") is module
    # Test if import_string raises a ValueError if klass
    # is not given
    try:
        import_string("http.cookies")
    except ValueError:
        pass



# Generated at 2022-06-21 23:03:34.416158
# Unit test for function is_entity_header
def test_is_entity_header():
    '''
    Tries with some entity headers and some non-entity headers.
    '''
    assert(is_entity_header("Content-Length"))
    assert(not is_entity_header("Content-length"))
    assert(not is_entity_header("Content-Encoding"))
    assert(not is_entity_header("Set-Cookie"))
    assert(is_entity_header("Content-Type"))


# Generated at 2022-06-21 23:03:42.530996
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    headers = {
        b"Content-Length": b"1",
        b"Content-Location": b"http://example.com/bar.html",
        b"Content-MD5": b"q2h1aQ==",
        b"Content-Range": b"bytes 21010-47021/47022",
        b"Content-Type": b"text/html",
        b"Expires": b"Tue, 15 Jan 2008 20:02:00 GMT",
        b"Last-Modified": b"Tue, 15 Jan 2008 20:02:00 GMT",
    }
    expected_headers = {
        b"Content-Location": b"http://example.com/bar.html",
        b"Expires": b"Tue, 15 Jan 2008 20:02:00 GMT",
    }
    assert expected_headers == remove_entity_headers

# Generated at 2022-06-21 23:03:47.483092
# Unit test for function has_message_body
def test_has_message_body():
    assert not has_message_body(204)
    assert not has_message_body(304)
    assert not has_message_body(100)
    assert not has_message_body(101)
    assert has_message_body(200)
    assert not has_message_body(201)
    assert has_message_body(202)


# Generated at 2022-06-21 23:03:57.589441
# Unit test for function import_string
def test_import_string():
    class Cls:
        pass

    class Cls2:
        pass

    assert import_string("aiohttp.web.web_middlewares.normalize_path_middleware") == getattr(import_module("aiohttp.web.web_middlewares"), "normalize_path_middleware")
    assert isinstance(import_string("tests.test_utils.test_import_string.Cls"), Cls)
    assert isinstance(import_string("tests.test_utils.test_import_string:Cls2"), Cls2)

# Generated at 2022-06-21 23:04:11.722500
# Unit test for function remove_entity_headers
def test_remove_entity_headers():
    test_headers = {
        b"connection": b"keep-alive",
        b"host": b"example.com",
        b"transfer-encoding": b"chunked",
        b"content-length": b"15",
        b"expires": b"Thu, 01 Dec 1994 16:00:00 GMT",
        b"content-type": b"application/json",
        b"set-cookie": b"session=abcdefg",
        b"content-location": b"http://example.com/index.html",
        b"date": b"Thu, 01 Dec 1994 16:00:00 GMT",
        b"server": b"Example",
    }

# Generated at 2022-06-21 23:04:15.479314
# Unit test for function is_entity_header
def test_is_entity_header():
    assert is_entity_header("Content-Length")
    assert not is_entity_header("Accept")
    assert not is_entity_header("Accept-Charset")

