

# Generated at 2022-06-17 00:11:38.164862
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts']
    assert hardware_facts['mounts'][0]['mount'] == '/'

# Generated at 2022-06-17 00:11:48.172399
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']
    assert hardware_facts['mounts'][0]['device']
    assert hardware_facts['mounts'][0]['mount']
    assert hardware_facts['mounts'][0]['fstype']
    assert hardware_facts['mounts'][0]['options']

# Generated at 2022-06-17 00:11:53.661049
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_minutes'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:11:55.927288
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:11:57.630777
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:59.893909
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:12:04.654426
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['memtotal'] > 0
    assert hardware.memory['swaptotal'] > 0
    assert hardware.mounts['/']['device'] == '/dev/hd0s1'
    assert hardware.mounts['/']['fstype'] == 'ext2fs'
    assert hardware.mounts['/']['mount'] == '/'


# Generated at 2022-06-17 00:12:08.261094
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert len(hw.mounts) > 0

# Generated at 2022-06-17 00:12:10.115738
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:17.413085
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0
    assert facts['uptime_seconds'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:12:26.573049
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    import pytest
    import os

    # Test case:
    # - no timeout
    # - no exception
    # - no collected facts
    # - expected result:
    #   - uptime facts
    #   - memory facts
    #   - mount facts
    def mock_get_uptime_facts(self):
        return {'uptime_seconds': 123}

    def mock_get_memory_facts(self):
        return {'memtotal_mb': 123}

    def mock_get_mount_facts(self):
        return {'mounts': [{'mount': '/', 'device': '/dev/sda1'}]}

    hardware = HurdHardware()
   

# Generated at 2022-06-17 00:12:29.592413
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.uptime_seconds > 0
    assert h.uptime_days > 0
    assert h.total_memory_mb > 0
    assert h.total_swap_mb > 0
    assert h.mounts

# Generated at 2022-06-17 00:12:33.844927
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.uptime['seconds'] > 0
    assert h.memory['memtotal'] > 0
    assert h.memory['swaptotal'] > 0
    assert h.mounts['/']['size_total'] > 0
    assert h.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:12:35.725650
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['total'] > 0
    assert hardware.mounts['/']['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:12:42.845442
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:12:44.112694
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:45.191162
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:49.334773
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:52.898473
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:13:01.245944
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:13:11.069938
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0
    assert hurd_hardware.mounts['/']['device'] == '/dev/hd0s1'
    assert hurd_hardware.mounts['/']['fstype'] == 'ext2fs'
    assert hurd_hardware.mounts['/']['mount'] == '/'
    assert hurd_hardware.mounts['/']['options'] == 'rw,relatime'
    assert hurd_hardware.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:13:14.438488
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:23.489242
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'

# Generated at 2022-06-17 00:13:24.902388
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:13:26.483478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:34.085523
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:13:35.334228
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:36.246189
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:13:38.497837
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:42.313579
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:50.344207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:13:51.865894
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:53.146666
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:03.226003
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareParser
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareParserError
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareParserTimeout
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareParserTimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareParserTimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareParserTimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

# Generated at 2022-06-17 00:14:08.996930
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts']
    assert hardware_facts['mounts'][0]['mount'] == '/'

# Generated at 2022-06-17 00:14:14.618501
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts

# Generated at 2022-06-17 00:14:22.293043
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:14:23.960635
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:30.345997
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:14:32.309933
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:34.797773
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:45.158141
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['swap']['total'] > 0
    assert hurd_hardware.memory['swap']['free'] > 0
    assert hurd_hardware.memory['swap']['used'] > 0
    assert hurd_hardware.memory['swap']['cached'] > 0
    assert hurd_hardware.memory['swap']['percent'] > 0
    assert hurd_hardware.memory['virtual']['total'] > 0

# Generated at 2022-06-17 00:14:52.629798
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_seconds'] > facts['uptime_hours'] * 3600
    assert facts['uptime_hours'] > facts['uptime_days'] * 24
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:14:53.715208
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:01.203618
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {
        'uptime_seconds': 0,
        'uptime_hours': 0,
        'uptime_days': 0,
        'uptime_timestamp': 0,
        'memtotal_mb': 0,
        'memfree_mb': 0,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'mounts': []
    }

# Generated at 2022-06-17 00:15:09.787417
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_seconds'] == hardware_facts['uptime_hours'] * 3600 + hardware_facts['uptime_days'] * 86400
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:15:13.609460
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hurd_hardware = HurdHardware()

    # Call the populate method
    hurd_hardware.populate()

    # Assert that the uptime facts are not empty
    assert hurd_hardware.uptime_facts != {}

    # Assert that the memory facts are not empty
    assert hurd_hardware.memory_facts != {}

    # Assert that the mount facts are not empty
    assert hurd_hardware.mount_facts != {}

# Generated at 2022-06-17 00:15:14.792252
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:15:16.049872
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:15:27.668966
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['total'] > 0
    assert hurd_hardware.memory['swapfree'] > 0
    assert hurd_hardware.memory['swaptotal'] > 0
    assert hurd_hardware.memory['memfree'] > 0
    assert hurd_hardware.memory['memtotal'] > 0
    assert hurd_hardware.memory['swapcached'] > 0
    assert hurd_hardware.memory['cached'] > 0
    assert hurd_hardware.memory['buffers'] > 0

# Generated at 2022-06-17 00:15:31.922447
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts['/']['device'] != ''

# Generated at 2022-06-17 00:15:41.726113
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memtotal_mb > 0
    assert hurd_hardware.memfree_mb > 0
    assert hurd_hardware.swaptotal_mb > 0
    assert hurd_hardware.swapfree_mb > 0
    assert hurd_hardware.mounts['/']['device'] == '/dev/hd0s1'
    assert hurd_hardware.mounts['/']['fstype'] == 'ext2fs'
    assert hurd_hardware.mounts['/']['mount'] == '/'
    assert hurd_

# Generated at 2022-06-17 00:15:42.440217
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:44.866838
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:56.529315
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['memfree'] >= 0
    assert hw.memory['swaptotal'] >= 0
    assert hw.memory['swapfree'] >= 0
    assert hw.memory['swapcached'] >= 0
    assert hw.memory['cached'] >= 0
    assert hw.memory['buffers'] >= 0
    assert hw.memory['active'] >= 0
    assert hw.memory['inactive'] >= 0
    assert hw.memory['high_total'] >= 0
    assert hw.memory['high_free'] >= 0
    assert hw.memory['low_total'] >= 0

# Generated at 2022-06-17 00:16:05.387351
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}
    hurd_hardware.populate(collected_facts)
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['uptime_days'] > 0
    assert collected_facts['uptime_hours'] > 0
    assert collected_facts['uptime_minutes'] > 0
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['memtotal_mb'] > 0
    assert collected_facts['memfree_mb'] > 0
    assert collected_facts['swaptotal_mb'] > 0
    assert collected_facts['swapfree_mb'] > 0
    assert collected_facts['mounts'] != []

# Generated at 2022-06-17 00:16:12.173981
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] >= 0
    assert hurd_hw.uptime['hours'] >= 0
    assert hurd_hw.uptime['days'] >= 0
    assert hurd_hw.memory['MemTotal'] >= 0
    assert hurd_hw.memory['MemFree'] >= 0
    assert hurd_hw.memory['SwapTotal'] >= 0
    assert hurd_hw.memory['SwapFree'] >= 0
    assert hurd_hw.memory['SwapCached'] >= 0
    assert hurd_hw.memory['Buffers'] >= 0
    assert hurd_hw.memory['Cached'] >= 0
    assert hurd_hw.memory['Active'] >= 0
    assert hurd_hw.memory['Inactive'] >= 0

# Generated at 2022-06-17 00:16:16.721985
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:16:18.638251
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.populate() is not None

# Generated at 2022-06-17 00:16:21.795271
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

    assert hurd_hardware.uptime_facts
    assert hurd_hardware.memory_facts
    assert hurd_hardware.mount_facts

# Generated at 2022-06-17 00:16:36.116714
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:16:37.011725
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()

# Generated at 2022-06-17 00:16:48.571908
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    hardware_facts.populate()
    assert hardware_facts.uptime['seconds'] > 0
    assert hardware_facts.memory['memtotal'] > 0
    assert hardware_facts.memory['swaptotal'] > 0
    assert hardware_facts.mounts['/']['device'] == '/dev/hd0s1'
    assert hardware_facts.mounts['/']['fstype'] == 'ext2fs'
    assert hardware_facts.mounts['/']['mount'] == '/'
    assert hardware_facts.mounts['/']['options'] == 'rw,relatime'
    assert hardware_facts.mounts['/']['size_available'] > 0
    assert hardware_facts.mounts['/']['size_total'] > 0
    assert hardware_facts

# Generated at 2022-06-17 00:16:53.162795
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:16:59.214448
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None


# Generated at 2022-06-17 00:17:00.751961
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware.

    :return:
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:17:03.897569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] >= 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:17:05.324891
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:17:13.417014
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert facts['uptime_seconds'] == 0
    assert facts['uptime_days'] == 0
    assert facts['uptime_hours'] == 0
    assert facts['uptime_minutes'] == 0
    assert facts['uptime_seconds'] == 0
    assert facts['memtotal_mb'] == 0
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['mounts'] == []

# Generated at 2022-06-17 00:17:18.860059
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    collected_facts = {}
    hw.populate(collected_facts)
    assert collected_facts['uptime_seconds'] == 0
    assert collected_facts['uptime_hours'] == 0
    assert collected_facts['uptime_days'] == 0
    assert collected_facts['memtotal_mb'] == 0
    assert collected_facts['memfree_mb'] == 0
    assert collected_facts['swaptotal_mb'] == 0
    assert collected_facts['swapfree_mb'] == 0
    assert collected_facts['mounts'] == []

# Generated at 2022-06-17 00:17:40.001607
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] >= 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:17:49.936393
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options'] == 'rw,relatime'

# Generated at 2022-06-17 00:17:55.127472
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:01.633405
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.mounts['/']
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:18:09.042367
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.facts['uptime_seconds'] > 0
    assert hurd_hw.facts['uptime_hours'] > 0
    assert hurd_hw.facts['uptime_days'] > 0
    assert hurd_hw.facts['memtotal_mb'] > 0
    assert hurd_hw.facts['memfree_mb'] > 0
    assert hurd_hw.facts['swaptotal_mb'] > 0
    assert hurd_hw.facts['swapfree_mb'] > 0
    assert hurd_hw.facts['mounts'] is not None

# Generated at 2022-06-17 00:18:15.684117
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] >= 0
    assert hardware_facts['uptime_minutes'] >= 0
    assert hardware_facts['uptime_seconds'] >= 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:18:19.519568
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:18:20.635712
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:18:25.506791
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.get('uptime')
    assert hurd_hardware.get('uptime_seconds')
    assert hurd_hardware.get('memtotal_mb')
    assert hurd_hardware.get('swaptotal_mb')
    assert hurd_hardware.get('mounts')

# Generated at 2022-06-17 00:18:30.658071
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapcached'] > 0
    assert hw.memory['cached'] > 0
    assert hw.memory['buffers'] > 0
    assert hw.memory['active'] > 0
    assert hw.memory['inactive'] > 0
    assert hw.memory['shared'] > 0

# Generated at 2022-06-17 00:19:11.177105
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']


# Generated at 2022-06-17 00:19:12.290905
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:17.251310
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.uptime['uptime'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.memfree_mb < hw.memtotal_mb
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.swapfree_mb < hw.swaptotal_mb
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert h

# Generated at 2022-06-17 00:19:26.537424
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['memfree_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0
    assert hurd_hardware.memory['swapfree_mb'] > 0
    assert hurd_hardware.mounts['/']['size_total'] > 0
    assert hurd_hardware.mounts['/']['size_available'] > 0
    assert hurd_hardware.mounts['/']['device'] == '/dev/hd0s1'
    assert hurd_hardware.mounts['/']['fstype'] == 'ext2fs'


# Generated at 2022-06-17 00:19:27.655387
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:19:29.621200
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:19:36.689261
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:19:39.926613
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:19:44.747758
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['memfree'] >= 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['swapfree'] >= 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:19:48.938265
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:21:11.268614
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:21:17.239168
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] is not None
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:21:24.276619
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0

    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

    assert len(facts['mounts']) > 0
    assert len(facts['filesystems']) > 0
    assert len(facts['filesystems_info']) > 0

# Generated at 2022-06-17 00:21:26.470897
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:21:27.618305
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:32.923493
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None