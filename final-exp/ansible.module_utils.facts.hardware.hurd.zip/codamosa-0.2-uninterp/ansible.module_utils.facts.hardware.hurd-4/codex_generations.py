

# Generated at 2022-06-17 00:11:39.288761
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['total'] > 0
    assert hurd_hardware.memory['free'] > 0
    assert hurd_hardware.memory['swapfree'] > 0
    assert hurd_hardware.memory['swaptotal'] > 0
    assert hurd_hardware.memory['swapcached'] > 0
    assert hurd_hardware.memory['buffers'] > 0
    assert hurd_hardware.memory['cached'] > 0
    assert hurd_hardware.memory['active'] > 0
    assert hurd_hardware.memory['inactive'] > 0

# Generated at 2022-06-17 00:11:48.762656
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['size_total'] > 0
    assert facts['mounts'][0]['size_available'] > 0
    assert facts['mounts'][0]['size_used'] > 0
    assert facts['mounts'][0]['device']
   

# Generated at 2022-06-17 00:11:53.287346
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:59.397597
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:12:00.659295
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:12:07.427720
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memtotal_mb > 0
    assert hardware.memfree_mb > 0
    assert hardware.swaptotal_mb > 0
    assert hardware.swapfree_mb > 0
    assert len(hardware.mounts) > 0

# Generated at 2022-06-17 00:12:15.892109
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.facts['uptime_seconds'] > 0
    assert hurd_hw.facts['uptime_hours'] > 0
    assert hurd_hw.facts['uptime_days'] > 0
    assert hurd_hw.facts['memtotal_mb'] > 0
    assert hurd_hw.facts['memfree_mb'] > 0
    assert hurd_hw.facts['swaptotal_mb'] > 0
    assert hurd_hw.facts['swapfree_mb'] > 0
    assert hurd_hw.facts['mounts'] != []

# Generated at 2022-06-17 00:12:22.441288
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:12:25.250137
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:26.406466
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:30.363439
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:12:39.349874
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware_facts = hurd_hardware.populate()
    assert 'uptime' in hurd_hardware_facts
    assert 'uptime_seconds' in hurd_hardware_facts
    assert 'memfree_mb' in hurd_hardware_facts
    assert 'memtotal_mb' in hurd_hardware_facts
    assert 'swapfree_mb' in hurd_hardware_facts
    assert 'swaptotal_mb' in hurd_hardware_facts
    assert 'mounts' in hurd_hardware_facts

# Generated at 2022-06-17 00:12:46.944295
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:12:49.518480
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:56.212731
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.data['uptime_seconds'] > 0
    assert hurd_hardware.data['uptime_hours'] > 0
    assert hurd_hardware.data['uptime_days'] > 0
    assert hurd_hardware.data['memtotal_mb'] > 0
    assert hurd_hardware.data['memfree_mb'] > 0
    assert hurd_hardware.data['swaptotal_mb'] > 0
    assert hurd_hardware.data['swapfree_mb'] > 0
    assert hurd_hardware.data['mounts'] != []

# Generated at 2022-06-17 00:13:02.420693
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:13:09.056440
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:13:16.065742
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['MemTotal'] > 0
    assert hurd_hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hurd_hw.mounts['/']['fstype'] == 'ext2fs'
    assert hurd_hw.mounts['/']['mount'] == '/'
    assert hurd_hw.mounts['/']['options'] == 'rw,relatime'

# Generated at 2022-06-17 00:13:20.699900
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:24.607206
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:13:38.068099
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['device'] == '/dev/hd0s1'
    assert facts['mounts'][0]['fstype'] == 'hfs'

# Generated at 2022-06-17 00:13:39.720199
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:46.201473
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['swap']['total'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:13:48.701903
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['size_available'] < hw.mounts['/']['size_total']

# Generated at 2022-06-17 00:13:50.097684
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:51.644479
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:02.204249
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] >= 0
    assert hw.memory['swaptotal'] >= 0
    assert hw.memory['memfree'] >= 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapfree_mb'] >= 0
    assert hw.memory['swaptotal_mb'] >= 0
    assert hw.memory['memfree_mb'] >= 0
    assert hw.memory['memtotal_mb'] > 0
    assert hw.memory['swapfree_gb'] >= 0

# Generated at 2022-06-17 00:14:08.184011
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:14:12.059693
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:14.110821
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:24.141083
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime_seconds > 0
    assert hurd_hardware.uptime_days > 0
    assert hurd_hardware.memtotal_mb > 0
    assert hurd_hardware.memfree_mb > 0
    assert hurd_hardware.swaptotal_mb > 0
    assert hurd_hardware.swapfree_mb > 0
    assert hurd_hardware.mounts

# Generated at 2022-06-17 00:14:27.227772
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:28.845483
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:37.738889
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime is not None
    assert hurd_hw.uptime_seconds is not None
    assert hurd_hw.memtotal_mb is not None
    assert hurd_hw.memfree_mb is not None
    assert hurd_hw.swaptotal_mb is not None
    assert hurd_hw.swapfree_mb is not None
    assert hurd_hw.mounts is not None

# Generated at 2022-06-17 00:14:45.921036
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['memtotal_mb'] > 0
    assert hurd_hw.memory['swaptotal_mb'] > 0
    assert hurd_hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hurd_hw.mounts['/']['fstype'] == 'ext2fs'
    assert hurd_hw.mounts['/']['mount'] == '/'
    assert hurd_hw.mounts['/']['options'] == 'rw,relatime'
    assert hurd_hw.mounts['/']['size_total'] > 0
    assert hurd_hw.mounts['/']['size_available'] > 0
   

# Generated at 2022-06-17 00:14:51.867382
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:14:53.136561
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:01.205404
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:15:06.945569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['swapfree'] > 0
    assert len(hw.mounts) > 0

# Generated at 2022-06-17 00:15:11.810431
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:15:17.258603
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:19.946019
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:26.007639
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:15:32.293490
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:15:34.915015
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['memtotal'] > 0
    assert hardware.memory['swaptotal'] >= 0
    assert hardware.mounts

# Generated at 2022-06-17 00:15:37.348139
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.mounts['/']

# Generated at 2022-06-17 00:15:39.031336
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:42.591228
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:15:44.977964
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:46.845111
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:57.525954
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:15:59.302557
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:16:00.447025
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:16:01.698245
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:05.290257
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:09.340297
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:16:14.692176
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:16:17.263842
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:16:24.717902
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:16:26.187587
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert hurd_hw.populate()

# Generated at 2022-06-17 00:16:34.504991
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:39.767903
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime_seconds > 0
    assert hw.uptime_days > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts
    assert hw.mounts[0]['mount'] == '/'
    assert hw.mounts[0]['size_total'] > 0
    assert hw.mounts[0]['size_available'] > 0
    assert hw.mounts[0]['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:16:48.480591
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:16:49.696748
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:16:55.986918
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.uptime['seconds'] > 0
    assert h.uptime['hours'] > 0
    assert h.uptime['days'] > 0
    assert h.memtotal_mb > 0
    assert h.memfree_mb > 0
    assert h.swaptotal_mb > 0
    assert h.swapfree_mb > 0
    assert h.mounts['/']['device'] == '/dev/hd0s1'
    assert h.mounts['/']['fstype'] == 'ext2fs'
    assert h.mounts['/']['mount'] == '/'
    assert h.mounts['/']['options'] == 'rw,relatime'
    assert h.mounts['/']['size_total'] > 0


# Generated at 2022-06-17 00:17:01.259026
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:17:08.984769
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:17:15.636969
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0
    assert facts['uptime_seconds'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts']

# Generated at 2022-06-17 00:17:23.086299
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime_seconds > 0
    assert hurd_hardware.uptime_days > 0
    assert hurd_hardware.memtotal_mb > 0
    assert hurd_hardware.memfree_mb > 0
    assert hurd_hardware.swaptotal_mb > 0
    assert hurd_hardware.swapfree_mb > 0
    assert hurd_hardware.mounts

# Generated at 2022-06-17 00:17:23.863273
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:17:33.799694
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:17:35.370578
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:17:39.488229
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:17:40.304765
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:17:44.634736
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:17:51.632122
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memory_mb']['real']['total'] > 0
    assert facts['memory_mb']['swap']['total'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:17:57.714595
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:18:02.504674
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {'uptime_seconds': 0, 'uptime_hours': 0, 'uptime_days': 0, 'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0}

# Generated at 2022-06-17 00:18:05.109329
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:18:09.222865
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:17.478494
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware = HurdHardware()
    # Call the method populate
    hardware.populate()
    # Check that the method populate returns a dictionary
    assert isinstance(hardware.populate(), dict)

# Generated at 2022-06-17 00:18:19.957440
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:18:21.051205
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:22.279361
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:18:29.106429
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {'uptime_seconds': 0, 'uptime_hours': 0, 'uptime_days': 0, 'uptime_minutes': 0, 'uptime_hours_minutes': '00:00', 'uptime_days_hours_minutes': '0 days, 00:00', 'uptime_seconds_days_hours_minutes': '0 days, 00:00:00', 'memtotal_mb': 0, 'memfree_mb': 0, 'swaptotal_mb': 0, 'swapfree_mb': 0, 'mounts': []}

# Generated at 2022-06-17 00:18:40.686358
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.mounts['/']['device'] == '/dev/root'
    assert hw.mounts['/']['fstype'] == 'ext2'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options'] == 'rw,relatime'
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:18:42.805642
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:53.700847
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options'] == 'rw,relatime'
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:19:05.148679
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware_obj = HurdHardware()

    # Call method populate
    hardware_facts = hardware_obj.populate()

    # Assert that the method populate returns a dictionary
    assert isinstance(hardware_facts, dict)

    # Assert that the dictionary returned by method populate contains
    # the key 'uptime_seconds'
    assert 'uptime_seconds' in hardware_facts

    # Assert that the dictionary returned by method populate contains
    # the key 'uptime_hours'
    assert 'uptime_hours' in hardware_facts

    # Assert that the dictionary returned by method populate contains
    # the key 'uptime_days'
    assert 'uptime_days' in hardware_facts

    # Assert that the dictionary returned by method populate contains
    # the key 'memtotal_mb'
   

# Generated at 2022-06-17 00:19:06.498424
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-17 00:19:15.025390
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:19:17.890280
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.uptime['seconds'] > 0
    assert h.memory['memtotal'] > 0
    assert h.memory['swaptotal'] > 0
    assert h.mounts['/']['device'] == '/dev/hda'

# Generated at 2022-06-17 00:19:19.016013
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:26.244988
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:19:37.100014
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] > 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['swapfree_mb'] > 0
    assert hw.memory['swaptotal_mb'] > 0
    assert hw.memory['memfree_mb'] > 0
    assert hw.memory['memtotal_mb'] > 0
    assert hw.memory['nocache_mb'] > 0
    assert hw.memory['cached_mb'] > 0
    assert hw.memory['active_mb'] > 0
    assert hw.memory['inactive_mb'] > 0

# Generated at 2022-06-17 00:19:45.644657
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_hours'] > 0
    assert hurd_hardware.facts['uptime_days'] > 0
    assert hurd_hardware.facts['memtotal_mb'] > 0
    assert hurd_hardware.facts['memfree_mb'] > 0
    assert hurd_hardware.facts['swaptotal_mb'] > 0
    assert hurd_hardware.facts['swapfree_mb'] > 0
    assert hurd_hardware.facts['mounts']

# Generated at 2022-06-17 00:19:49.097793
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

# Generated at 2022-06-17 00:19:52.503233
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:53.819536
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:19:57.777121
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:04.072927
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:07.471970
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:20:10.676058
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:14.250896
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:20:15.460157
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:23.756711
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:20:27.256682
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:20:28.313044
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:32.369851
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:37.319242
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0
    assert facts['uptime_seconds'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:20:42.908932
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:47.399418
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:20:50.852307
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['memtotal'] > 0
    assert hardware.memory['swaptotal'] > 0
    assert hardware.mounts['/']['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:20:53.062603
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:20:55.177168
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:21:00.116211
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:21:06.782564
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapcached'] > 0
    assert hw.memory['cached'] > 0
    assert hw.memory['buffers'] > 0
    assert hw.memory['active'] > 0
    assert hw.memory['inactive'] > 0
    assert hw.memory['high_total']

# Generated at 2022-06-17 00:21:10.920252
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:21:16.731522
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']


# Generated at 2022-06-17 00:21:25.563730
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_hours'] > 0
    assert hurd_hardware.facts['uptime_days'] > 0
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts