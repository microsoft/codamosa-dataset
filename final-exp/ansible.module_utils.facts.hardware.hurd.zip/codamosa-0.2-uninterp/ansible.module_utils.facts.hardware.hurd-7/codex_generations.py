

# Generated at 2022-06-17 00:11:33.183233
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:35.615049
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hh = HurdHardware()

    # Call method populate
    hh.populate()

    # Check that the method populate returns a dict
    assert isinstance(hh.populate(), dict)

# Generated at 2022-06-17 00:11:38.775374
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:39.954918
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:11:42.719705
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:11:48.893650
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:11:53.287934
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:11:59.150369
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None


# Generated at 2022-06-17 00:12:09.533428
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware_obj = HurdHardware()

    # Create a dictionary of facts

# Generated at 2022-06-17 00:12:11.094884
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:12:14.769706
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:12:21.136507
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:12:24.827613
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:12:30.260498
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:12:31.294956
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:38.845147
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']

# Generated at 2022-06-17 00:12:46.914129
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:12:53.509256
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

# Generated at 2022-06-17 00:13:03.756980
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    import pytest
    import os
    import os.path
    import sys
    import mock

    # Mock the LinuxHardware class
    class MockLinuxHardware(LinuxHardware):
        def __init__(self):
            self.uptime_facts = {'uptime_seconds': '12345'}
            self.memory_facts = {'memtotal_mb': '1024'}
            self.mount_facts = {'mounts': [{'mount': '/', 'device': '/dev/sda1'}]}

        def get_uptime_facts(self):
            return self.uptime_facts

# Generated at 2022-06-17 00:13:08.918429
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.uptime['seconds'] > 0
    assert h.memory['total'] > 0
    assert h.memory['swapfree'] >= 0
    assert h.memory['swaptotal'] >= 0
    assert h.memory['swapfree'] <= h.memory['swaptotal']
    assert h.memory['memfree'] >= 0
    assert h.memory['memtotal'] >= 0
    assert h.memory['memfree'] <= h.memory['memtotal']
    assert h.memory['buffers'] >= 0
    assert h.memory['cached'] >= 0
    assert h.memory['active'] >= 0
    assert h.memory['inactive'] >= 0
    assert h.memory['dirty'] >= 0
    assert h.memory['writeback'] >= 0
    assert h

# Generated at 2022-06-17 00:13:22.143797
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapcached'] > 0
    assert hw.memory['cached'] > 0
    assert hw.memory['swapfree_mb'] > 0
    assert hw.memory['swaptotal_mb'] > 0
    assert hw.memory['memfree_mb'] > 0

# Generated at 2022-06-17 00:13:31.107658
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:13:32.183440
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:13:38.440266
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:13:50.493817
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware = HurdHardware()
    # Call the populate method
    hardware.populate()
    # Check the result
    assert hardware.uptime['seconds'] > 0
    assert hardware.uptime['hours'] >= 0
    assert hardware.uptime['days'] >= 0
    assert hardware.memtotal_mb > 0
    assert hardware.memfree_mb > 0
    assert hardware.swaptotal_mb > 0
    assert hardware.swapfree_mb > 0
    assert hardware.mounts['/']['device'] == '/dev/hda1'
    assert hardware.mounts['/']['fstype'] == 'ext2'
    assert hardware.mounts['/']['mount'] == '/'

# Generated at 2022-06-17 00:13:59.361218
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:14:07.917197
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw_facts = hw.populate()

    assert hw_facts['uptime_seconds'] > 0
    assert hw_facts['uptime_hours'] > 0
    assert hw_facts['uptime_days'] > 0

    assert hw_facts['memtotal_mb'] > 0
    assert hw_facts['memfree_mb'] > 0
    assert hw_facts['swaptotal_mb'] > 0
    assert hw_facts['swapfree_mb'] > 0

    assert len(hw_facts['mounts']) > 0

# Generated at 2022-06-17 00:14:19.368470
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal'] > 0
    assert hurd_hardware.memory['memfree'] >= 0
    assert hurd_hardware.memory['swaptotal'] > 0
    assert hurd_hardware.memory['swapfree'] >= 0
    assert hurd_hardware.memory['cached'] >= 0
    assert hurd_hardware.memory['swapcached'] >= 0
    assert hurd_hardware.memory['active'] >= 0
    assert hurd_hardware.memory['inactive'] >= 0
    assert hurd_hardware.memory['high_total'] >= 0
    assert hurd_hardware.memory['high_free'] >= 0
    assert hurd_hardware.memory

# Generated at 2022-06-17 00:14:25.886856
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.facts.hardware.hurd as hurd_hw

    class HurdHardwareTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)
            self.procfs = os.path.join(self.tmpdir, 'proc')
            os.mkdir(self.procfs)
            os.mkdir(os.path.join(self.procfs, '1'))
            os.mkdir(os.path.join(self.procfs, 'uptime'))

# Generated at 2022-06-17 00:14:35.151732
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['total'] > 0
    assert hurd_hardware.memory['swapfree'] > 0
    assert hurd_hardware.memory['swaptotal'] > 0
    assert hurd_hardware.memory['memfree'] > 0
    assert hurd_hardware.memory['memtotal'] > 0
    assert hurd_hardware.memory['swapcached'] > 0
    assert hurd_hardware.memory['buffers'] > 0

# Generated at 2022-06-17 00:14:46.261501
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'

# Generated at 2022-06-17 00:14:52.100207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:14:59.910275
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    collected_facts = hardware_facts.populate()
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['uptime_hours'] > 0
    assert collected_facts['uptime_days'] > 0
    assert collected_facts['memtotal_mb'] > 0
    assert collected_facts['memfree_mb'] > 0
    assert collected_facts['swaptotal_mb'] > 0
    assert collected_facts['swapfree_mb'] > 0
    assert collected_facts['mounts'] != []

# Generated at 2022-06-17 00:15:06.947359
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:15:13.411443
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapfree_mb'] > 0
    assert hw.memory['swaptotal_mb'] > 0
    assert hw.memory['memfree_mb'] > 0
    assert hw.memory['memtotal_mb'] > 0
    assert hw.memory['swapfree_gb'] > 0

# Generated at 2022-06-17 00:15:25.064481
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['device'] == '/dev/hd0s1'
    assert facts['mounts'][0]['fstype'] == 'hfs'
    assert facts['mounts'][0]['options'] == 'rw,relatime'
    assert facts

# Generated at 2022-06-17 00:15:31.847243
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:15:33.049778
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:40.181525
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:15:43.263574
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:00.730388
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'

# Generated at 2022-06-17 00:16:01.372129
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:10.841943
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapcached'] > 0
    assert hw.memory['cached'] > 0
    assert hw.memory['active'] > 0
    assert hw.memory['inactive'] > 0
    assert hw.memory['buffers'] > 0
    assert hw.memory['dirty'] > 0

# Generated at 2022-06-17 00:16:12.010491
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:16:19.785686
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware = HurdHardware()

    # Call the populate method
    hardware.populate()

    # Assert that the uptime_facts method was called
    assert hardware.uptime_facts.called

    # Assert that the memory_facts method was called
    assert hardware.memory_facts.called

    # Assert that the mount_facts method was called
    assert hardware.mount_facts.called

# Generated at 2022-06-17 00:16:26.176255
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:16:35.082018
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []
    assert facts['fstype'] != []
    assert facts['device'] != []
    assert facts['mount'] != []
    assert facts['options'] != []
    assert facts['size_total'] != []
    assert facts['size_available'] != []
    assert facts['size_used'] != []
    assert facts['inode_total'] != []
    assert facts['inode_used'] != []
   

# Generated at 2022-06-17 00:16:37.102007
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts

# Generated at 2022-06-17 00:16:41.466606
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime_facts['uptime_seconds'] > 0
    assert hurd_hardware.memory_facts['memtotal_mb'] > 0
    assert hurd_hardware.mount_facts['mounts'] is not None

# Generated at 2022-06-17 00:16:50.801496
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}
    hurd_hardware.populate(collected_facts)
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['uptime_hours'] > 0
    assert collected_facts['uptime_days'] > 0
    assert collected_facts['memtotal_mb'] > 0
    assert collected_facts['memfree_mb'] > 0
    assert collected_facts['swaptotal_mb'] > 0
    assert collected_facts['swapfree_mb'] > 0
    assert collected_facts['mounts'] != []

# Generated at 2022-06-17 00:17:11.423357
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:17:17.363719
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] >= 0
    assert facts['uptime_days'] >= 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0
    assert facts['uptime_seconds'] >= 0
    assert facts['memtotal_mb'] >= 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:17:18.804340
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:17:23.451145
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:17:27.150959
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:17:33.494692
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:17:40.265992
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.uptime_days is not None
    assert hurd_hardware.uptime_hours is not None
    assert hurd_hardware.uptime_minutes is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.memavailable_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:17:44.248684
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:17:45.255507
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:17:48.945537
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:18:20.934127
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:26.661157
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

# Generated at 2022-06-17 00:18:27.464498
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:18:38.056947
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with empty collected_facts
    collected_facts = {}
    hh = HurdHardware(collected_facts=collected_facts)
    hh.populate()
    assert hh.facts['uptime_seconds'] == 0
    assert hh.facts['uptime_hours'] == 0
    assert hh.facts['uptime_days'] == 0
    assert hh.facts['memtotal_mb'] == 0
    assert hh.facts['memfree_mb'] == 0
    assert hh.facts['swaptotal_mb'] == 0
    assert hh.facts['swapfree_mb'] == 0
    assert hh.facts['mounts'] == []

# Generated at 2022-06-17 00:18:42.436709
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:18:51.204245
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:18:55.218590
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:19:06.467776
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['swapfree_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0
    assert hurd_hardware.memory['memfree_mb'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['nocache_mb'] > 0
    assert hurd_hardware.memory['cached_mb'] > 0
    assert hurd_hardware.memory['active_mb'] > 0

# Generated at 2022-06-17 00:19:10.904192
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None


# Generated at 2022-06-17 00:19:12.134574
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test HurdHardware.populate
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:20:36.099157
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:20:44.121806
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options'] == 'rw,relatime'
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:20:54.305305
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['swapfree_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0
    assert hurd_hardware.memory['memfree_mb'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['nocache_mb'] > 0
    assert hurd_hardware.memory['cached_mb'] > 0
    assert hurd_hardware.memory['active_mb'] > 0

# Generated at 2022-06-17 00:20:59.873289
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:21:01.273459
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:21:04.678974
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:07.327983
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:18.448653
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['total'] > 0
    assert hurd_hardware.memory['swapfree'] > 0
    assert hurd_hardware.memory['swaptotal'] > 0
    assert hurd_hardware.memory['swapused'] > 0
    assert hurd_hardware.memory['real']['total'] > 0
    assert hurd_hardware.memory['real']['available'] > 0
    assert hurd_hardware.memory['real']['used'] > 0
    assert hurd_hardware.memory['real']['free'] > 0

# Generated at 2022-06-17 00:21:20.878278
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-17 00:21:21.857795
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()