

# Generated at 2022-06-17 00:11:34.022621
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:38.616375
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:39.797810
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:47.776526
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:11:48.683126
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:11:56.221987
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['device']
    assert facts['mounts'][0]['fstype'] == 'hfs'
    assert facts['mounts'][0]['options']
    assert facts['mounts'][0]['size_total'] > 0

# Generated at 2022-06-17 00:11:57.035785
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:12:01.267158
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()

    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0

    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

    assert len(facts['mounts']) > 0

# Generated at 2022-06-17 00:12:08.249204
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal_mb'] > 0
    assert hw.memory['swaptotal_mb'] > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:12:10.115193
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:12:22.758562
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ufs'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options'] == 'rw,relatime'
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:12:25.285067
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:26.758260
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-17 00:12:29.194572
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.facts['uptime_seconds'] > 0
    assert h.facts['memtotal_mb'] > 0
    assert h.facts['mounts'] != []

# Generated at 2022-06-17 00:12:34.467231
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']

# Generated at 2022-06-17 00:12:35.283460
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:43.159237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:12:44.902379
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:49.335131
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:55.330749
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:13:04.046561
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert len(facts['mounts']) > 0

# Generated at 2022-06-17 00:13:08.339108
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:13:15.789447
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal_mb'] > 0
    assert hw.memory['memfree_mb'] > 0
    assert hw.memory['swaptotal_mb'] > 0
    assert hw.memory['swapfree_mb'] > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:13:20.698335
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()


# Generated at 2022-06-17 00:13:21.787768
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:27.866409
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hw = HurdHardware()

    # Create a dictionary of facts
    facts = {}

    # Populate the dictionary of facts
    facts = hw.populate(facts)

    # Check if the dictionary of facts is not empty
    assert facts != {}

# Generated at 2022-06-17 00:13:34.020959
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['ram']['total'] > 0
    assert hw.memory['swap']['total'] > 0
    assert hw.memory['swap']['total'] > 0
    assert len(hw.mounts) > 0


# Generated at 2022-06-17 00:13:34.962271
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:13:40.927047
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:13:42.222294
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:13:56.280505
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:13:57.862089
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:59.120296
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:08.904790
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an instance of HurdHardware
    hurd_hardware = HurdHardware()

    # Create a dictionary with the expected facts
    expected_facts = {
        'uptime_seconds': 0,
        'uptime_days': 0,
        'uptime_hours': 0,
        'uptime_minutes': 0,
        'memtotal_mb': 0,
        'memfree_mb': 0,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'mounts': []
    }

    # Call the method populate of class HurdHardware
    hurd_hardware.populate()

    # Check if the facts are the expected ones
    assert hurd_hardware.facts == expected_facts

# Generated at 2022-06-17 00:14:12.249606
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:23.438496
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    from ansible.module_utils.facts.hardware.hurd import HurdHardwareCollector
    from ansible.module_utils.facts.hardware.hurd import test_HurdHardware_populate
    from ansible.module_utils.facts.hardware.hurd import test_HurdHardwareCollector_populate
    from ansible.module_utils.facts.hardware.hurd import test_HurdHardware_get_mount_facts
    from ansible.module_utils.facts.hardware.hurd import test_HurdHardware_get_memory_facts

# Generated at 2022-06-17 00:14:24.484459
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:31.289881
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_seconds'] == hardware_facts['uptime_hours'] * 3600 + hardware_facts['uptime_days'] * 86400
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:14:39.158196
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0
    assert facts['uptime_seconds'] >= 0

    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0

    assert facts['mounts'] is not None
    assert len(facts['mounts']) > 0

# Generated at 2022-06-17 00:14:45.184441
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:15:04.205455
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] >= 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['swapfree_mb'] >= 0
    assert hw.memory['swaptotal_mb'] >= 0
    assert hw.memory['memfree_mb'] >= 0
    assert hw.memory['memtotal_mb'] >= 0
    assert hw.memory['nocache_mb'] >= 0
    assert hw.memory['cached_mb'] >= 0
    assert hw.memory['active_mb'] >= 0
    assert hw.memory['inactive_mb'] >= 0

# Generated at 2022-06-17 00:15:05.556613
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:15:06.823192
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:07.997865
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:10.975215
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert hw.populate() == {'uptime': {'seconds': 0, 'hours': 0, 'days': 0, 'minutes': 0}, 'memory': {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}, 'mounts': []}

# Generated at 2022-06-17 00:15:11.916325
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()

# Generated at 2022-06-17 00:15:13.637114
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:14.830224
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:15:22.958674
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['total'] > 0
    assert hardware.memory['swapfree'] >= 0
    assert hardware.memory['swaptotal'] >= 0
    assert hardware.memory['memfree'] >= 0
    assert hardware.memory['memtotal'] >= 0
    assert hardware.memory['swapfree'] <= hardware.memory['swaptotal']
    assert hardware.memory['memfree'] <= hardware.memory['memtotal']

# Generated at 2022-06-17 00:15:23.957907
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:46.448284
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware = HurdHardware()

    # Create a dictionary with the expected values
    expected_facts = {
        'uptime_seconds': 0,
        'uptime_hours': 0,
        'uptime_days': 0,
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
        'mounts': []
    }

    # Call the method populate of the object
    hardware_facts = hardware.populate()

    # Check if the returned dictionary is equal to the expected one
    assert hardware_facts == expected_facts

# Generated at 2022-06-17 00:15:55.311732
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    collected_facts = hardware_facts.populate()
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['uptime_hours'] > 0
    assert collected_facts['uptime_days'] > 0
    assert collected_facts['memtotal_mb'] > 0
    assert collected_facts['memfree_mb'] > 0
    assert collected_facts['swaptotal_mb'] > 0
    assert collected_facts['swapfree_mb'] > 0
    assert collected_facts['mounts'] != []

# Generated at 2022-06-17 00:15:58.117860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:59.392011
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:15:59.906141
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:07.972453
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['real']['used'] > 0
    assert hardware_facts['memory_mb']['real']['free'] > 0
    assert hardware_facts['memory_mb']['swap']['total'] > 0
    assert hardware_facts['memory_mb']['swap']['used'] > 0

# Generated at 2022-06-17 00:16:14.068377
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:16:20.804940
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']


# Generated at 2022-06-17 00:16:25.389487
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']

# Generated at 2022-06-17 00:16:34.672004
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['total'] > 0
    assert hurd_hw.memory['swapfree'] > 0
    assert hurd_hw.memory['swaptotal'] > 0
    assert hurd_hw.memory['memfree'] > 0
    assert hurd_hw.memory['memtotal'] > 0
    assert hurd_hw.memory['swapcached'] > 0
    assert hurd_hw.memory['cached'] > 0
    assert hurd_hw.memory['active'] > 0
    assert hurd_hw.memory['inactive'] > 0
    assert hurd_hw.memory['buffers'] > 0
    assert hurd_hw.memory['dirty'] > 0
    assert hurd_hw.memory['writeback']

# Generated at 2022-06-17 00:17:14.094000
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:17:14.859353
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:17:22.902643
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert hurd_hw.populate() == {
        'uptime_seconds': 0,
        'uptime_days': 0,
        'uptime_hours': 0,
        'uptime_minutes': 0,
        'memtotal_mb': 0,
        'memfree_mb': 0,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'mounts': []
    }

# Generated at 2022-06-17 00:17:29.169013
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['total'] > 0
    assert hurd_hw.memory['swapfree'] > 0
    assert hurd_hw.memory['swaptotal'] > 0
    assert hurd_hw.memory['memfree'] > 0
    assert hurd_hw.memory['memtotal'] > 0
    assert hurd_hw.memory['swapfree'] > 0
    assert hurd_hw.memory['swaptotal'] > 0
    assert hurd_hw.memory['cached'] > 0
    assert hurd_hw.memory['buffers'] > 0
    assert hurd_hw.memory['active'] > 0
    assert hurd_hw.memory['inactive'] > 0
    assert hurd_hw.memory['dirty']

# Generated at 2022-06-17 00:17:36.606075
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {'ansible_os_family': 'GNU'}
    hardware_facts = hurd_hardware.populate(collected_facts)
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:17:43.959915
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['total'] > 0
    assert hurd_hw.memory['swapfree'] > 0
    assert hurd_hw.memory['swaptotal'] > 0
    assert hurd_hw.memory['memfree'] > 0
    assert hurd_hw.memory['memtotal'] > 0
    assert hurd_hw.memory['swapcached'] > 0
    assert hurd_hw.memory['cached'] > 0
    assert hurd_hw.memory['active'] > 0
    assert hurd_hw.memory['inactive'] > 0
    assert hurd_hw.memory['buffers'] > 0
    assert hurd_hw.memory['dirty'] > 0
    assert hurd_hw.memory['writeback']

# Generated at 2022-06-17 00:17:50.475618
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['device'] == '/dev/hd0s1'
    assert facts['mounts'][0]['fstype'] == 'ext2fs'
    assert facts['mounts'][0]['options'] == 'rw,relatime'

# Generated at 2022-06-17 00:17:58.012104
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_minutes'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:17:58.724749
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:18:05.317398
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.memtotal is not None
    assert hw.memfree is not None
    assert hw.swaptotal is not None
    assert hw.swapfree is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:19:24.554107
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['total'] > 0
    assert hardware.memory['swapfree'] > 0
    assert hardware.memory['swaptotal'] > 0
    assert hardware.memory['memfree'] > 0
    assert hardware.memory['memtotal'] > 0
    assert hardware.memory['swapcached'] >= 0
    assert hardware.memory['cached'] >= 0
    assert hardware.memory['buffers'] >= 0
    assert hardware.memory['active'] >= 0
    assert hardware.memory['inactive'] >= 0
    assert hardware.memory['dirty'] >= 0
    assert hardware.memory['writeback'] >= 0
    assert hardware.memory['anonpages'] >= 0
    assert hardware.memory['mapped'] >= 0
    assert hardware

# Generated at 2022-06-17 00:19:29.528664
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:34.240958
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:19:37.201572
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:19:40.284581
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:47.848098
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['memtotal_mb'] > 0
    assert hurd_hw.memory['memfree_mb'] > 0
    assert hurd_hw.memory['swaptotal_mb'] > 0
    assert hurd_hw.memory['swapfree_mb'] > 0
    assert hurd_hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hurd_hw.mounts['/']['fstype'] == 'ext2fs'
    assert hurd_hw.mounts['/']['mount'] == '/'
    assert hurd_hw.mounts['/']['options'] == 'rw,relatime'
    assert hurd_hw.mounts

# Generated at 2022-06-17 00:19:49.675887
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:19:56.210637
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['size_available'] < hw.mounts['/']['size_total']

# Generated at 2022-06-17 00:19:59.785932
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hurd_hardware = HurdHardware()

    # Call the populate method
    hurd_hardware.populate()

    # Check if the method get_uptime_facts was called
    assert hurd_hardware.get_uptime_facts.called

    # Check if the method get_memory_facts was called
    assert hurd_hardware.get_memory_facts.called

    # Check if the method get_mount_facts was called
    assert hurd_hardware.get_mount_facts.called

# Generated at 2022-06-17 00:20:03.794907
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()