

# Generated at 2022-06-17 00:11:41.223232
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.uptime['seconds'] > 0
    assert h.memory['memtotal'] > 0
    assert h.memory['memfree'] >= 0
    assert h.memory['swaptotal'] > 0
    assert h.memory['swapfree'] >= 0
    assert h.mounts['/']['size_total'] > 0
    assert h.mounts['/']['size_available'] > 0
    assert h.mounts['/']['device'] == '/dev/hd0s1'
    assert h.mounts['/']['fstype'] == 'ext2fs'
    assert h.mounts['/']['mount'] == '/'
    assert h.mounts['/']['options'] == 'rw,relatime'

# Generated at 2022-06-17 00:11:50.741581
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] >= 0
    assert hardware_facts['uptime_minutes'] >= 0
    assert hardware_facts['uptime_seconds'] >= 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['mounts']

# Generated at 2022-06-17 00:11:53.175240
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:11:54.000621
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:12:02.749136
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:12:03.765839
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:08.558859
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {'ansible_os_family': 'GNU'}
    hurd_hardware.populate(collected_facts)
    assert collected_facts['ansible_os_family'] == 'GNU'
    assert 'ansible_uptime_seconds' in collected_facts
    assert 'ansible_memtotal_mb' in collected_facts
    assert 'ansible_mounts' in collected_facts

# Generated at 2022-06-17 00:12:15.449330
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert hw.populate() == {
        'uptime_seconds': 0,
        'uptime_days': 0,
        'uptime_hours': 0,
        'uptime_minutes': 0,
        'memtotal_mb': 0,
        'memfree_mb': 0,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'mounts': []
    }

# Generated at 2022-06-17 00:12:16.537569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:12:17.412478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:12:21.369241
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:12:25.142181
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:32.390953
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['minutes'] > 0
    assert hurd_hardware.memory['swapfree_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0
    assert hurd_hardware.memory['memfree_mb'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['nocache_mb'] > 0
    assert hurd_hardware.memory['cached_mb'] > 0

# Generated at 2022-06-17 00:12:40.449137
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hardware_facts = hurd_hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:12:42.179950
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:43.007595
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:12:49.372215
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with no facts
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {
        'uptime_seconds': 0,
        'uptime_hours': 0,
        'uptime_days': 0,
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
        'mounts': []
    }

    # Test with facts
    hurd_hardware = HurdHardware()
    hurd_hardware.uptime_seconds = 10
    hurd_hardware.uptime_hours = 10
    hurd_hardware.uptime_days = 10
    hurd_hardware.memfree_mb = 10
    hurd_hardware.memtotal_mb = 10
    hurd_hard

# Generated at 2022-06-17 00:12:50.685055
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:12:52.082971
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:56.037601
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:12:58.586450
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:05.739466
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:13:06.770498
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:12.574381
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] >= 0
    assert hardware_facts['uptime_minutes'] >= 0
    assert hardware_facts['uptime_seconds'] >= 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:13:21.811134
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    hardware_facts.populate()
    assert hardware_facts.facts['uptime_seconds'] > 0
    assert hardware_facts.facts['uptime_hours'] > 0
    assert hardware_facts.facts['uptime_days'] > 0
    assert hardware_facts.facts['memtotal_mb'] > 0
    assert hardware_facts.facts['memfree_mb'] > 0
    assert hardware_facts.facts['swaptotal_mb'] > 0
    assert hardware_facts.facts['swapfree_mb'] > 0
    assert hardware_facts.facts['mounts'] is not None

# Generated at 2022-06-17 00:13:25.047728
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:35.170860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['device'] == '/dev/hd0s1'
    assert facts['mounts'][0]['fstype'] == 'ext2fs'

# Generated at 2022-06-17 00:13:40.522804
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime_facts is not None
    assert hurd_hardware.memory_facts is not None
    assert hurd_hardware.mount_facts is not None

# Generated at 2022-06-17 00:13:42.527962
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:52.257986
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'

# Generated at 2022-06-17 00:13:56.498679
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:57.086640
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:13:57.889197
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()

# Generated at 2022-06-17 00:14:02.478655
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:10.565733
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:14:17.000199
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['memtotal'] > 0
    assert hurd_hw.memory['swaptotal'] > 0
    assert hurd_hw.mounts['/']['size_total'] > 0
    assert hurd_hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:14:19.821555
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.mounts['/']['device'] == '/dev/root'

# Generated at 2022-06-17 00:14:23.237458
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:27.280917
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:33.271809
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:14:43.117204
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:14:46.526813
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:14:47.154375
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:49.094284
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:55.588567
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'

# Generated at 2022-06-17 00:14:56.897301
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:06.400749
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware = HurdHardware()

    # Create a dictionary with the expected values
    expected_facts = {
        'uptime_seconds': 0,
        'uptime_hours': 0,
        'uptime_days': 0,
        'memtotal_mb': 0,
        'memfree_mb': 0,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'mounts': [],
    }

    # Call the method populate
    facts = hardware.populate()

    # Check if the result is the expected one
    assert facts == expected_facts

# Generated at 2022-06-17 00:15:11.406879
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:15:13.033430
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:14.391421
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:15:27.755862
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.uptime['hours'] > 0
    assert hardware.uptime['days'] > 0
    assert hardware.memory['memtotal_mb'] > 0
    assert hardware.memory['memfree_mb'] > 0
    assert hardware.memory['swaptotal_mb'] > 0
    assert hardware.memory['swapfree_mb'] > 0
    assert hardware.memory['nocache_mb'] > 0
    assert hardware.memory['active_mb'] > 0
    assert hardware.memory['inactive_mb'] > 0
    assert hardware.memory['available_mb'] > 0
    assert hardware.memory['buffers_mb'] > 0
    assert hardware.memory['cached_mb'] > 0

# Generated at 2022-06-17 00:15:35.894737
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options'] == 'rw,relatime'
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:15:37.659896
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:41.964245
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:48.563967
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.hardware.hurd import HurdHardwareCollector
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    import os
    import sys
    import unittest

    class MockLinuxHardware(LinuxHardware):
        def get_uptime_facts(self):
            return {'uptime_seconds': '12345'}

        def get_memory_facts(self):
            return {'memtotal_mb': '12345'}


# Generated at 2022-06-17 00:15:51.523438
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:53.349950
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:00.211257
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['total'] > 0
    assert hurd_hw.mounts['/'] is not None

# Generated at 2022-06-17 00:16:07.519164
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:16:14.038210
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

# Generated at 2022-06-17 00:16:17.224129
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:16:25.918168
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['device'] == '/dev/hd0s1'
    assert facts['mounts'][0]['fstype'] == 'ext2fs'
    assert facts['mounts'][0]['options'] == 'rw,relatime'

# Generated at 2022-06-17 00:16:28.417824
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:32.678587
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime is not None
    assert hardware.uptime_seconds is not None
    assert hardware.memtotal_mb is not None
    assert hardware.memfree_mb is not None
    assert hardware.swaptotal_mb is not None
    assert hardware.swapfree_mb is not None
    assert hardware.mounts is not None

# Generated at 2022-06-17 00:16:36.727748
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:16:43.231327
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:16:44.830545
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:16:50.200391
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.facts['uptime_seconds'] > 0
    assert hurd_hardware.facts['memory_mb']['real']['total'] > 0
    assert hurd_hardware.facts['mounts']

# Generated at 2022-06-17 00:16:57.564036
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0
    assert hurd_hardware.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:17:06.967234
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] >= 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['swapfree_mb'] >= 0
    assert hw.memory['swaptotal_mb'] >= 0
    assert hw.memory['memfree_mb'] >= 0
    assert hw.memory['memtotal_mb'] >= 0
    assert hw.memory['nocache_mb'] >= 0
    assert hw.memory['cached_mb'] >= 0
    assert hw.memory['active_mb'] >= 0
    assert hw.memory['inactive_mb'] >= 0

# Generated at 2022-06-17 00:17:17.399481
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['memfree_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0
    assert hurd_hardware.memory['swapfree_mb'] > 0
    assert hurd_hardware.memory['nocache_mb'] > 0
    assert hurd_hardware.memory['active_mb'] > 0
    assert hurd_hardware.memory['inactive_mb'] > 0

# Generated at 2022-06-17 00:17:18.494409
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:17:24.628497
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:17:35.517219
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.uptime['uptime'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mount

# Generated at 2022-06-17 00:17:38.147235
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hurd_hw = HurdHardware()

    # Call method populate
    hurd_hw.populate()

    # Check if the method populate has been called
    assert hurd_hw.populate.call_count == 1


# Generated at 2022-06-17 00:17:48.997658
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] >= 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] >= 0
    assert hw.memory['swaptotal'] >= 0
    assert hw.memory['swapused'] >= 0
    assert hw.memory['real']['total'] > 0
    assert hw.memory['real']['free'] >= 0
    assert hw.memory['real']['used'] >= 0
    assert hw.memory['real']['used_percentage'] >= 0

# Generated at 2022-06-17 00:17:49.815894
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:17:53.068636
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:17:54.638395
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:17:55.984464
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:07.952127
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}
    hurd_hardware.populate(collected_facts)
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['uptime_hours'] > 0
    assert collected_facts['uptime_days'] > 0
    assert collected_facts['memtotal_mb'] > 0
    assert collected_facts['memfree_mb'] > 0
    assert collected_facts['swaptotal_mb'] > 0
    assert collected_facts['swapfree_mb'] > 0

# Generated at 2022-06-17 00:18:11.533827
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.mounts['/']

# Generated at 2022-06-17 00:18:19.506667
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:18:28.360509
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['MemTotal'] > 0
    assert hurd_hardware.memory['SwapTotal'] >= 0
    assert hurd_hardware.mounts['/']['device'] == '/dev/hd0s1'
    assert hurd_hardware.mounts['/']['fstype'] == 'ext2fs'
    assert hurd_hardware.mounts['/']['mount'] == '/'
    assert hurd_hardware.mounts['/']['options'] == 'rw,relatime'
    assert hurd_hardware.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:18:29.529296
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:18:30.619481
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:39.632916
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:18:51.353380
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert isinstance(hurd_hardware.facts, dict)
    assert 'uptime_seconds' in hurd_hardware.facts
    assert 'uptime_hours' in hurd_hardware.facts
    assert 'uptime_days' in hurd_hardware.facts
    assert 'memtotal_mb' in hurd_hardware.facts
    assert 'memfree_mb' in hurd_hardware.facts
    assert 'swaptotal_mb' in hurd_hardware.facts
    assert 'swapfree_mb' in hurd_hardware.facts
    assert 'mounts' in hurd_hardware.facts

# Generated at 2022-06-17 00:18:52.488773
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:03.785002
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] > 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] >= 0
    assert hw.memory['swaptotal'] >= 0
    assert hw.memory['memfree'] >= 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapfree'] >= 0
    assert hw.memory['swaptotal'] >= 0
    assert hw.memory['memfree'] >= 0
    assert hw.memory['memtotal'] > 0

# Generated at 2022-06-17 00:19:13.984222
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-17 00:19:14.755059
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:19:15.830671
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:19:19.570840
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:19:26.438795
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:19:30.017248
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:19:34.666401
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:19:38.687322
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:19:44.373115
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {
        'uptime_seconds': 0,
        'uptime_hours': 0,
        'uptime_days': 0,
        'memtotal_mb': 0,
        'memfree_mb': 0,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'mounts': []
    }

# Generated at 2022-06-17 00:19:45.121455
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:20:11.022006
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] >= 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['swapfree_mb'] >= 0
    assert hw.memory['swaptotal_mb'] >= 0
    assert hw.memory['memfree_mb'] >= 0
    assert hw.memory['memtotal_mb'] >= 0
    assert hw.memory['nocache_mb'] >= 0
    assert hw.memory['cached_mb'] >= 0
    assert hw.memory['swapcached_mb'] >= 0
    assert hw.memory['active_mb'] >= 0

# Generated at 2022-06-17 00:20:17.583637
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:20:21.408574
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:22.465255
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:20:27.399355
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h.uptime['seconds'] > 0
    assert h.memory['memtotal'] > 0
    assert h.memory['swaptotal'] > 0
    assert h.mounts['/']['device'] == '/dev/hd0s1'
    assert h.mounts['/']['fstype'] == 'ext2fs'
    assert h.mounts['/']['mount'] == '/'
    assert h.mounts['/']['options'] == 'rw,relatime'

# Generated at 2022-06-17 00:20:33.462019
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['memtotal'] > 0
    assert hurd_hw.memory['memfree'] > 0
    assert hurd_hw.memory['swaptotal'] > 0
    assert hurd_hw.memory['swapfree'] > 0
    assert hurd_hw.memory['cached'] >= 0
    assert hurd_hw.memory['swapcached'] >= 0
    assert hurd_hw.memory['active'] >= 0
    assert hurd_hw.memory['inactive'] >= 0
    assert hurd_hw.memory['buffers'] >= 0
    assert hurd_hw.memory['dirty'] >= 0
    assert hurd_hw.memory['writeback'] >= 0

# Generated at 2022-06-17 00:20:41.979486
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

# Generated at 2022-06-17 00:20:42.793170
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:20:43.709609
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:20:47.986384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:18.470992
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.uptime['hours'] > 0
    assert hurd_hardware.uptime['days'] > 0
    assert hurd_hardware.memory['total'] > 0
    assert hurd_hardware.memory['swapfree'] > 0
    assert hurd_hardware.memory['swaptotal'] > 0
    assert hurd_hardware.memory['memfree'] > 0
    assert hurd_hardware.memory['memtotal'] > 0
    assert hurd_hardware.memory['swapfree'] > 0
    assert hurd_hardware.memory['swaptotal'] > 0
    assert hurd_hardware.memory['memfree'] > 0

# Generated at 2022-06-17 00:21:21.166068
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:25.835393
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:21:27.406014
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-17 00:21:30.024387
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:31.039302
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()