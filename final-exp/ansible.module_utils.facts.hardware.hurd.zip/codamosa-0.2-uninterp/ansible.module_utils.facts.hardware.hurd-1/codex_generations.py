

# Generated at 2022-06-17 00:11:42.586603
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['total'] > 0
    assert hardware.memory['swapfree'] >= 0
    assert hardware.memory['swaptotal'] >= 0
    assert hardware.memory['swapused'] >= 0
    assert hardware.memory['used'] >= 0
    assert hardware.memory['free'] >= 0
    assert hardware.memory['available'] >= 0
    assert hardware.memory['active'] >= 0
    assert hardware.memory['inactive'] >= 0
    assert hardware.memory['buffers'] >= 0
    assert hardware.memory['cached'] >= 0
    assert hardware.memory['shared'] >= 0
    assert hardware.memory['real:used'] >= 0
    assert hardware.memory['real:free'] >= 0
    assert hardware.memory

# Generated at 2022-06-17 00:11:51.036778
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw_facts = hw.populate()
    assert hw_facts['uptime_seconds'] > 0
    assert hw_facts['uptime_days'] > 0
    assert hw_facts['memtotal_mb'] > 0
    assert hw_facts['memfree_mb'] > 0
    assert hw_facts['swaptotal_mb'] > 0
    assert hw_facts['swapfree_mb'] > 0
    assert hw_facts['mounts'] is not None

# Generated at 2022-06-17 00:11:53.456938
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:11:59.314875
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:12:08.656457
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_seconds'] == hardware_facts['uptime_hours'] * 3600 + hardware_facts['uptime_days'] * 86400

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts']
    assert hardware_facts['mounts'][0]['mount'] == '/'

# Generated at 2022-06-17 00:12:16.059452
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:12:20.489490
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.memory['total'] > 0
    assert hurd_hw.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:12:31.366564
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.mounts['/']['device'] == '/dev/root'
    assert hurd_hardware.mounts['/']['fstype'] == 'ext2'
    assert hurd_hardware.mounts['/']['mount'] == '/'
    assert hurd_hardware.mounts['/']['options'] == 'rw,relatime'
    assert hurd_hardware.mounts['/']['size_total'] > 0
    assert hurd_hardware.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:12:38.841791
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None


# Generated at 2022-06-17 00:12:39.898812
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:12:49.255043
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    import sys
    import tempfile
    import textwrap
    import unittest

    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    class TestHurdHardware(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(os.rmdir, self.tmpdir)
            self.addCleanup(os.chdir, os.getcwd())
            os.chdir(self.tmpdir)

            self.proc_uptime = os.path.join(self.tmpdir, 'proc_uptime')
            self.proc_meminfo = os.path.join(self.tmpdir, 'proc_meminfo')

# Generated at 2022-06-17 00:12:55.220746
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:12:56.497521
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:12:57.508293
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:03.729686
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:13:06.159247
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:07.198446
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:13:15.228886
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:13:18.044821
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:13:22.909924
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts['/']['size_total'] > 0
    assert hw.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:13:31.768314
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0

    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

    assert facts['mounts'] is not None

# Generated at 2022-06-17 00:13:41.893231
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['hours'] > 0
    assert hw.uptime['days'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapcached'] > 0
    assert hw.memory['cached'] > 0
    assert hw.memory['buffers'] > 0
    assert hw.memory['active'] > 0
    assert hw.memory['inactive'] > 0
    assert hw.memory['real:used']

# Generated at 2022-06-17 00:13:47.613858
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']

# Generated at 2022-06-17 00:13:56.498680
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:14:02.377525
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with empty collected facts
    collected_facts = {}
    hw = HurdHardware(collected_facts)
    hw.populate()
    assert hw.facts['uptime_seconds'] > 0
    assert hw.facts['uptime_days'] > 0
    assert hw.facts['memtotal_mb'] > 0
    assert hw.facts['memfree_mb'] > 0
    assert hw.facts['swaptotal_mb'] > 0
    assert hw.facts['swapfree_mb'] > 0
    assert hw.facts['mounts'] is not None

# Generated at 2022-06-17 00:14:07.241778
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:14:08.089918
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:14:08.791850
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:14:12.159121
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:23.360905
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['memtotal'] > 0
    assert hardware.memory['memfree'] > 0
    assert hardware.memory['swaptotal'] > 0
    assert hardware.memory['swapfree'] > 0
    assert hardware.mounts['/']['device'] == '/dev/hd0s1'
    assert hardware.mounts['/']['fstype'] == 'ext2fs'
    assert hardware.mounts['/']['mount'] == '/'
    assert hardware.mounts['/']['options'] == 'rw,relatime'
    assert hardware.mounts['/']['size_total'] > 0
    assert hardware.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:14:37.767210
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.uptime['days'] >= 0
    assert hardware.uptime['hours'] >= 0
    assert hardware.uptime['minutes'] >= 0
    assert hardware.memory['total'] > 0
    assert hardware.memory['swapfree'] >= 0
    assert hardware.memory['swaptotal'] >= 0
    assert hardware.memory['swapused'] >= 0
    assert hardware.memory['used'] >= 0
    assert hardware.memory['free'] >= 0
    assert hardware.memory['real']['total'] > 0
    assert hardware.memory['real']['used'] >= 0
    assert hardware.memory['real']['free'] >= 0
    assert hardware.memory['real']['free_percent'] >= 0
   

# Generated at 2022-06-17 00:14:44.085254
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] is not None


# Generated at 2022-06-17 00:14:46.964512
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:14:52.704883
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_minutes'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:14:54.073043
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-17 00:14:55.768225
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:15:02.822028
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:15:04.288932
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['total'] > 0
    assert hurd_hardware.mounts['/']['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:15:05.250166
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:15:06.568998
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:16.191192
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:15:27.798833
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['real']['free'] > 0
    assert hardware_facts['memory_mb']['real']['used'] > 0
    assert hardware_facts['memory_mb']['swap']['total'] > 0
    assert hardware_facts['memory_mb']['swap']['free'] > 0

# Generated at 2022-06-17 00:15:31.764610
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'

# Generated at 2022-06-17 00:15:32.613778
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:15:37.402088
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None


# Generated at 2022-06-17 00:15:43.194532
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime['seconds'] > 0
    assert hurd_hardware.memory['memtotal_mb'] > 0
    assert hurd_hardware.memory['swaptotal_mb'] > 0

# Generated at 2022-06-17 00:15:51.569363
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime is not None
    assert hw.uptime_seconds is not None
    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None
    assert hw.swaptotal_mb is not None
    assert hw.swapfree_mb is not None
    assert hw.mounts is not None

# Generated at 2022-06-17 00:15:56.320420
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime['seconds'] > 0
    assert hardware.memory['memtotal'] > 0
    assert hardware.memory['swaptotal'] > 0
    assert hardware.mounts['/']['size_total'] > 0
    assert hardware.mounts['/']['size_available'] > 0

# Generated at 2022-06-17 00:16:03.068607
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert 'uptime' in facts
    assert 'uptime_seconds' in facts
    assert 'uptime_hours' in facts
    assert 'uptime_days' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'mounts' in facts

# Generated at 2022-06-17 00:16:03.901882
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:16:25.083237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:16:26.233203
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-17 00:16:28.737625
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:16:29.663275
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:16:34.240565
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:16:39.377118
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0
    assert facts['uptime_seconds'] >= 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts']
    assert facts['mounts'][0]['mount']
    assert facts['mounts'][0]['device']

# Generated at 2022-06-17 00:16:46.119597
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:16:55.017057
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.mounts['/']['device'] == '/dev/hd0s1'
    assert hw.mounts['/']['fstype'] == 'ext2fs'
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options'] == 'rw,relatime'
    assert hw.mounts['/']['size_available'] > 0
    assert hw.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:17:02.974632
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] > 0
    assert hurd_hw.uptime['hours'] > 0
    assert hurd_hw.uptime['days'] > 0
    assert hurd_hw.memory['memtotal_mb'] > 0
    assert hurd_hw.memory['memfree_mb'] > 0
    assert hurd_hw.memory['swaptotal_mb'] > 0
    assert hurd_hw.memory['swapfree_mb'] > 0
    assert hurd_hw.memory['nocache_mb'] > 0
    assert hurd_hw.memory['active_mb'] > 0
    assert hurd_hw.memory['inactive_mb'] > 0
    assert hurd_hw.memory['available_mb'] > 0

# Generated at 2022-06-17 00:17:04.343842
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:17:45.324573
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.uptime_seconds is not None
    assert hurd_hardware.memtotal_mb is not None
    assert hurd_hardware.memfree_mb is not None
    assert hurd_hardware.swaptotal_mb is not None
    assert hurd_hardware.swapfree_mb is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-17 00:17:55.136140
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] > 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] >= 0
    assert hw.memory['swaptotal'] >= 0
    assert hw.memory['swapused'] >= 0
    assert hw.memory['free'] >= 0
    assert hw.memory['used'] >= 0
    assert hw.memory['active'] >= 0
    assert hw.memory['inactive'] >= 0
    assert hw.memory['available'] >= 0
    assert hw.memory['buffers'] >= 0
   

# Generated at 2022-06-17 00:17:56.379839
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:18:03.408741
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts'] != []

# Generated at 2022-06-17 00:18:04.505737
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:18:05.547257
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:18:10.457660
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:18:20.745641
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts']
    assert hardware_

# Generated at 2022-06-17 00:18:27.072541
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-17 00:18:31.829350
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {'uptime_seconds': 0, 'uptime_hours': 0, 'uptime_days': 0, 'uptime_minutes': 0, 'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0}

# Generated at 2022-06-17 00:19:09.370626
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:19:11.040402
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:16.226612
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] > 0
    assert hw.memory['swaptotal'] > 0
    assert hw.memory['memfree'] > 0
    assert hw.memory['memtotal'] > 0
    assert hw.memory['swapcached'] >= 0
    assert hw.memory['cached'] >= 0
    assert hw.memory['active'] >= 0
    assert hw.memory['inactive'] >= 0
    assert hw.memory['buffers'] >= 0
    assert hw.memory['dirty'] >= 0
    assert hw.memory['writeback'] >= 0
    assert hw.memory['anonpages'] >= 0

# Generated at 2022-06-17 00:19:21.212011
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime_seconds > 0
    assert hw.uptime_days > 0
    assert hw.memtotal_mb > 0
    assert hw.memfree_mb > 0
    assert hw.swaptotal_mb > 0
    assert hw.swapfree_mb > 0
    assert hw.mounts
    assert hw.mounts['/']
    assert hw.mounts['/']['device']
    assert hw.mounts['/']['fstype']
    assert hw.mounts['/']['mount'] == '/'
    assert hw.mounts['/']['options']
    assert hw.mounts['/']['size_total'] > 0

# Generated at 2022-06-17 00:19:24.269195
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:29.176011
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:30.218839
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:38.076525
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] == 0
    assert facts['uptime_hours'] == 0
    assert facts['uptime_days'] == 0
    assert facts['uptime_seconds'] == 0
    assert facts['uptime_hours'] == 0
    assert facts['uptime_days'] == 0
    assert facts['memtotal_mb'] == 0
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['mounts'] == []

# Generated at 2022-06-17 00:19:40.493501
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:19:42.159188
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:09.644712
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.uptime_seconds > 0
    assert hurd_hardware.uptime_days > 0
    assert hurd_hardware.memtotal_mb > 0
    assert hurd_hardware.memfree_mb > 0
    assert hurd_hardware.swaptotal_mb > 0
    assert hurd_hardware.swapfree_mb > 0
    assert len(hurd_hardware.mounts) > 0

# Generated at 2022-06-17 00:21:11.189589
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-17 00:21:13.114875
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-17 00:21:14.692087
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:21:23.563007
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-17 00:21:26.678305
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-17 00:21:34.553351
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime['seconds'] > 0
    assert hw.uptime['days'] > 0
    assert hw.uptime['hours'] >= 0
    assert hw.uptime['minutes'] >= 0
    assert hw.memory['total'] > 0
    assert hw.memory['swapfree'] >= 0
    assert hw.memory['swaptotal'] >= 0
    assert hw.memory['swapused'] >= 0
    assert hw.memory['used'] >= 0
    assert hw.memory['free'] >= 0
    assert hw.memory['real']['total'] > 0
    assert hw.memory['real']['used'] >= 0
    assert hw.memory['real']['free'] >= 0
    assert h