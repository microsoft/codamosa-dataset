

# Generated at 2022-06-24 22:08:56.441586
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
# Initialize test case environment
    hardware_obj = HurdHardware()
    collected_facts = {}
# Execute test case
    hardware_facts = hardware_obj.populate(collected_facts)
# Check test result
    assert hardware_facts != {}

# Generated at 2022-06-24 22:08:59.013547
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0._module = FakeAnsibleModule()
    if not hurd_hardware_0.populate():
        raise AssertionError()


# Fake AnsibleModule class to fix the method:
# module.run_command(cmd)

# Generated at 2022-06-24 22:09:00.884478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:02.270427
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:04.174191
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:12.084801
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test the collection of the file system_facts on a GNU/Hurd system
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_1 = hurd_hardware_collector_1.collect()
    assert(hurd_hardware_1['uptime_seconds'] > 0)
    assert(hurd_hardware_1['uptime_hours'] > 0)
    assert(hurd_hardware_1['uptime_days'] > 0)
    assert(hurd_hardware_1['memtotal_mb'] > 0)
    assert(hurd_hardware_1['mounts'] != [])
    assert(hurd_hardware_1['swapfree_mb'] > 0)
    assert(hurd_hardware_1['swaptotal_mb'] > 0)

# Generated at 2022-06-24 22:09:19.514669
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {'ansible_architecture': 'i386', 'ansible_distribution': 'GNU', 'ansible_distribution_version': '0.3'}

# Generated at 2022-06-24 22:09:27.620193
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    This function simulates the hardware information that is available under
    GNU/Hurd. Be aware that the validity of this information cannot be
    verified as it is created only for testing purpose.
    """

    hurd_hardware_collector = HurdHardwareCollector()
    test_hardware_facts = {}

    test_hardware_facts['uptime_seconds'] = 93798
    test_hardware_facts['uptime_days'] = 1
    test_hardware_facts['uptime_hours'] = 2
    test_hardware_facts['uptime_minutes'] = 35

    # The following values are taken from the host where this unit test is
    # performed.
    test_hardware_facts['memtotal_mb'] = 15769
    test_hardware_facts['memfree_mb'] = 5143
    test_

# Generated at 2022-06-24 22:09:29.439288
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    assert isinstance(hurd_hardware_0.populate(), dict)

# Generated at 2022-06-24 22:09:37.445457
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_1 = HurdHardware({'some': 'collected_facts'})

    collected_facts_0 = {'some': 'collected_facts'}
    collected_facts_1 = {}

    collected_facts_0 = hurd_hardware_0.populate(collected_facts_0)
    collected_facts_1 = hurd_hardware_1.populate(collected_facts_1)

    assert type(collected_facts_0) is dict
    assert type(collected_facts_1) is dict


# Generated at 2022-06-24 22:09:47.648945
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {'ansible_facts': {}}

    hurd_hardware_populate_result = hurd_hardware.populate(collected_facts)
    assert ['ansible_facts']['ansible_memtotal_mb'] in \
        hurd_hardware_populate_result
    assert ['ansible_facts']['ansible_memfree_mb'] in \
        hurd_hardware_populate_result

# Generated at 2022-06-24 22:09:49.266450
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:53.802138
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an object
    hurd_hardware_obj = HurdHardware()

    # Call method populate on it
    hurd_hardware_obj.populate()

    # Assert that the call went well
    assert hurd_hardware_obj._collector.get_memory_facts() is not None

# Generated at 2022-06-24 22:09:58.145876
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test the HurdHardware.populate() method"""
    hurd_hardware_0 = HurdHardware()
    collected_facts = { "distribution": { "distribution": "GNU" } }
    hurd_hardware_0.populate(collected_facts=collected_facts)


# Generated at 2022-06-24 22:10:04.679126
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initializing an instance of HurdHardware with no arguments
    hurd_hardware_0 = HurdHardware()
    # Calling populate on that instance
    hurd_hardware_0.populate()

if __name__ == '__main__':
    # 4 cases
    test_case_0()
    # Unit test for method populate of class HurdHardware
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:09.453750
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware().populate() == {
        'uptime_seconds': 0, 'uptime_hours': 0, 'memoryfree_mb': 0, 'uptime_days': 0,
        'swaptotal_mb': '0.00', 'memorytotal_mb': 0, 'swapfree_mb': '0.00'
    }

# Generated at 2022-06-24 22:10:11.171876
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:14.258731
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj_0 = HurdHardware()
    hurd_hardware_obj_0.populate()



# Generated at 2022-06-24 22:10:22.312959
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = {}
    hardware_facts.update({'mounts': [u'/', u'/home', u'fdescfs', u'procfs', u'linprocfs']})
    hardware_facts.update({'memfree_mb': 46, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 71})
    hardware_facts.update({'uptime_seconds': 7120, 'uptime_hours': 2, 'uptime_days': 0})
    hurd_hardware_0 = HurdHardware()

# Generated at 2022-06-24 22:10:32.269627
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Setup:
    hurd_hardware_0 = HurdHardware()
    collected_facts = dict()

    # Expectation:
    hardware_facts_0 = dict()
    uptime_facts_0 = dict()
    uptime_facts_0['uptime'] = 60588

    memory_facts_0 = dict()
    memory_facts_0['memfree_mb'] = 122
    memory_facts_0['memtotal_mb'] = 2554

    mount_facts_0 = dict()

# Generated at 2022-06-24 22:10:42.466533
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    collected_facts = {}
    collected_facts['ansible_os_family'] = 'GNU'
    collected_facts['ansible_system'] = 'GNU'

    hurd_hardware_fact_dict = hurd_hardware_0.populate(collected_facts)

    assert 'ansible_uptime_seconds' in hurd_hardware_fact_dict
    assert 'ansible_memtotal_mb' in hurd_hardware_fact_dict
    assert 'ansible_mounts' in hurd_hardware_fact_dict


test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:44.214294
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Run HurdHardware.populate with a mock object
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-24 22:10:46.064105
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0._collector = HurdHardwareCollector()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:48.457309
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # TODO implement
    pass

# Generated at 2022-06-24 22:10:57.637137
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils._text import to_bytes

    class TestClassLinux:
        platform = 'GNU'

        def get_uptime_facts(self):
            return {'ansible_uptime_seconds': 0}

        def get_memory_facts(self):
            return {'ansible_memtotal_mb': 0, 'ansible_swaptotal_mb': 0}

        def get_mount_facts(self):
            return {}


# Generated at 2022-06-24 22:10:59.504074
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:06.326279
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    # import pdb;pdb.set_trace()

    assert facts["uptime_seconds"] is not None
    assert facts["uptime_hours"] is not None
    assert facts["uptime_days"] is not None
    assert facts["mounts"] is not None
    assert facts["memory_mb"] is not None
    assert facts["memory_gb"] is not None
    assert facts["swapfree_mb"] is not None
    assert facts["swapfree_gb"] is not None

# Generated at 2022-06-24 22:11:07.810005
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:14.718976
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate(collected_facts=None)
    uptime_facts = hurd_hardware.get_uptime_facts()
    memory_facts = hurd_hardware.get_memory_facts()
    mount_facts = hurd_hardware.get_mount_facts()

    assert(uptime_facts['uptime_seconds'] > 0)

    assert(memory_facts['memtotal_mb'] > 0)
    assert(memory_facts['memfree_mb'] > 0)
    assert(memory_facts['swaptotal_mb'] >= 0)
    assert(memory_facts['swapfree_mb'] >= 0)

    assert(mount_facts['mounts'] > 0)

# Generated at 2022-06-24 22:11:16.074227
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:23.804045
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'PH_.*"b'
    hurd_hardware_0 = HurdHardware(str_0)
    collect_file_0 = '~(B'
    var_0 = hurd_hardware_0.populate(collect_file_0)


# Generated at 2022-06-24 22:11:26.181034
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:29.011353
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware('eo*J|')
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:33.773569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == "__main__":
    test_case_0()


# Generated at 2022-06-24 22:11:37.017395
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    # Populate the facts collected by HurdHardware
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:39.661611
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ')G[M}'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:43.320768
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:45.646517
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'J3m^'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:53.865931
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = 'D'
    str_2 = 'wtz'
    str_3 = '<' + 'Y' + 't>'
    str_4 = 'q' + 'w' + 'a'
    str_5 = str_3 + 't' + 'Y' + 'k'
    str_6 = 'q' + 'w' + 'i' + 'N' + 'b'
    str_7 = 'k' + 'P' + 'n' + 'G' + '7'
    int_0 = 42
    int_1 = -30
    int_2 = -30
    int_3

# Generated at 2022-06-24 22:12:00.384056
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ';]:x`'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = 'j9U'
    var_1 = hurd_hardware_0.get_uptime_facts(str_1)
    assert var_1 == var_0
# Test case for class HurdHardware


# Generated at 2022-06-24 22:12:09.474463
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
  var_0 = HurdHardware()
  var_1 = var_0.populate()


# Generated at 2022-06-24 22:12:13.094940
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:12:17.905560
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_1 = hurd_hardware_0.populate()
    assert var_1 == {}, "AssertionError"


# Generated at 2022-06-24 22:12:25.810757
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'x7'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert type(var_0) is dict

# Generated at 2022-06-24 22:12:29.445361
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 't'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:31.277712
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = '<\\:6M~'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    assert type(var_1) is dict
    assert len(var_1) == 4


# Generated at 2022-06-24 22:12:34.792801
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:39.163491
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:48.221716
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

    assert var_0 == {}

    str_1 = '~'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()

    assert var_1 == {}

    str_2 = 'y]q3'
    hurd_hardware_2 = HurdHardware(str_2)
    var_2 = hurd_hardware_2.populate()

    assert var_2 == {}

    str_3 = '*h>o'
    hurd_hardware_3 = HurdHardware(str_3)

# Generated at 2022-06-24 22:12:49.248356
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:13:08.896636
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
# unit test for class HurdHardwareCollector

# Generated at 2022-06-24 22:13:12.640359
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:13:22.171190
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    if True:
        str_0 = '<\\:6M~'
        hurd_hardware_0 = HurdHardware(str_0)
        var_0 = hurd_hardware_0.populate()
    str_0 = 'c%Mh'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_0 = '0L-j'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_0 = '%c\\['
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_0 = 'qs*y'
    hurd

# Generated at 2022-06-24 22:13:25.529447
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:31.392861
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # TODO
    def test_case_0():
        str_0 = '<\\:6M~'
        hurd_hardware_0 = HurdHardware(str_0)
        var_0 = hurd_hardware_0.populate()

    # TODO
    def test_case_1():
        str_0 = 'E=b:h;'
        hurd_hardware_0 = HurdHardware(str_0)
        var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:35.656459
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'T\x00|\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:39.976568
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|?f\x0b)#'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = isinstance(var_0, dict)
    assert var_1


# Generated at 2022-06-24 22:13:47.378647
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'NB'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.get_uptime_facts = MagicMock(return_value={'a':'b'})
    hurd_hardware_0.get_memory_facts = MagicMock(return_value={'c':'d'})
    hurd_hardware_0.get_mount_facts = MagicMock(return_value={'e':'f'})
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'a':'b', 'c':'d', 'e':'f'}
    hurd_hardware_0.get_uptime_facts.assert_called_once_with()

# Generated at 2022-06-24 22:13:49.704552
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('--> Test for class HurdHardware, method populate')
    test_case_0()

# Generated at 2022-06-24 22:13:51.339308
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:14:27.473054
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert isinstance(var_0, dict)
    # assert len(var_0) == 0
    assert var_0[''] == None

# Generated at 2022-06-24 22:14:31.032390
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '_oqh'
    hurd_hardware_0 = HurdHardware(str_0)
    str_0 = 'hurd'
    hurd_hardware_1 = HurdHardware(str_0)

# Generated at 2022-06-24 22:14:38.344369
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    expect_0 = '<\\:6M~'
    var_1 = hurd_hardware_0.platform
    assert var_1 == expect_0


# Generated at 2022-06-24 22:14:40.757796
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'HPDL-2000'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:45.633446
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:14:47.637356
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware()
    var_1.populate()


# Generated at 2022-06-24 22:14:55.573970
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime_seconds'] == 80
    assert var_0['uptime_days'] == 0
    assert var_0['memory_mb'] == 5
    assert var_0['mounts'] == [{'size_total': '<\\:6M~', 'fstype': '<\\:6M~', 'size_available': '<\\:6M~', 'device': '<\\:6M~', 'mount': '<\\:6M~'}]


# Generated at 2022-06-24 22:15:03.817953
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0
    str_0 = 'B`|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0
    str_0 = '\\'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0
    str_0 = '\\,y'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_

# Generated at 2022-06-24 22:15:09.122903
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'F2'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:14.019220
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    assert type(hurd_hardware_0.populate()) is dict

# Generated at 2022-06-24 22:15:56.379559
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    assert hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:58.573198
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:00.446598
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '#+'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:05.332759
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not False


# Generated at 2022-06-24 22:16:07.722095
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ''
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Functional test for class HurdHardware

# Generated at 2022-06-24 22:16:10.746454
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:16:14.487061
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_5 = '<\\:6M~'
    hurd_hardware_5 = HurdHardware(str_5)
    
    assert type(hurd_hardware_5.populate()) == dict


# Generated at 2022-06-24 22:16:15.636453
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:16:18.697580
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '{#>ch~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:21.649111
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with invalid input
    hurd_hardware_0 = HurdHardware(b'')
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:17:05.216190
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '`|Dd'
    str_1 = '<\\:6M~'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:08.459152
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'F:3)'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:17:12.355219
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '~XN'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:19.364835
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = """
    Uptime: 465817.38 Current time: 1564136288
    System Boot Time: 1558293786
    """
    str_2 = '<\\:6M~'
    hurd_hardware_1 = HurdHardware(str_2)
    var_1 = hurd_hardware_1.populate()
    print(var_1)
    
    
if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:17:24.021269
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '`x<7Iu'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.get_uptime_facts()
    assert var_0 is not None and len(var_0) > 0


# Generated at 2022-06-24 22:17:26.743113
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'Y*'
    hurd_hardware_0 = HurdHardware(str_0)
    result = hurd_hardware_0.populate()
    assert result is None


# Generated at 2022-06-24 22:17:28.918249
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:17:31.962710
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:33.620531
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ';u?QV'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:17:34.725407
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    case_0 = test_case_0()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:18:23.743482
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'nwtI'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()
    str_1 = '^J<2'
    hurd_hardware_1 = HurdHardware(str_1)
    hurd_hardware_1.populate()
    str_2 = 'j!;&'
    hurd_hardware_2 = HurdHardware(str_2)
    hurd_hardware_2.populate()
    str_3 = '+O,~'
    hurd_hardware_3 = HurdHardware(str_3)
    hurd_hardware_3.populate()


# Generated at 2022-06-24 22:18:26.931246
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'wO.H'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:30.059102
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7B<'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:39.045392
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'd{'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = '<\\:6M~'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    str_2 = '4x8W'
    hurd_hardware_2 = HurdHardware(str_2)
    var_2 = hurd_hardware_2.populate()
    str_3 = 'yf'
    hurd_hardware_3 = HurdHardware(str_3)
    var_3 = hurd_hardware_3.populate()


# Generated at 2022-06-24 22:18:41.540516
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'DB'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:42.328406
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:18:44.880498
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ''
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:18:47.537799
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '"'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {} 


# Generated at 2022-06-24 22:18:48.509719
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:18:57.034569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'X}'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None, "Unable to find expected value"
    # Test case verifies value of variable var_0 is not none.
    assert var_0 is not None, "Expected variable not none"
    variable_0 = var_0['uptime_seconds']
    variable_1 = var_0['uptime_seconds_float']
    variable_2 = var_0['uptime_hours']
    variable_3 = var_0['uptime_minutes']
    variable_4 = var_0['uptime_days']
    variable_5 = var_0['uptime_uptime']