

# Generated at 2022-06-24 22:08:59.079349
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhardware_populate_0 = HurdHardware()
    assert hurdhardware_populate_0.populate() is not None

# Generated at 2022-06-24 22:09:03.153128
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    # Test with no parameters
    result = hurd_hardware_0.populate()
    assert result.keys() == ['swap', 'uptime_seconds', 'uptime_hours', 'uptime', 'mounts', 'memtotal_mb', 'memfree_mb', 'memfree_percent']


# Generated at 2022-06-24 22:09:04.767754
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_fact_0 = HurdHardware()
    hurd_hardware_fact_0.populate()

# Generated at 2022-06-24 22:09:08.830424
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_populate_0 = HurdHardware()
    hurd_hardware_populate_0 = hurd_hardware_populate_0.populate()
    hurd_hardware_populate_0 = hurd_hardware_populate_0.get('ansible_processor')

    assert hurd_hardware_populate_0 == 'unknown'

# Generated at 2022-06-24 22:09:12.149762
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    collected_facts = {u'ansible_facts': {u'os_family': u'GNU/kFreeBSD'}}
    hurd_hardware_0.populate(collected_facts)

# Generated at 2022-06-24 22:09:18.546043
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    # Try to get available memory
    memory = hurd_hardware.get_memory_facts()
    memory_expected = {'memtotal_mb': '0', 'memfree_mb': '0', 'swaptotal_mb': '0', 'swapfree_mb': '0'}
    assert memory == memory_expected

    # Try to get uptime
    uptime = hurd_hardware.get_uptime_facts()
    uptime_expected = {'uptime_seconds': '0', 'uptime_hours': '0', 'uptime_days': '0'}
    assert uptime == uptime_expected

# Generated at 2022-06-24 22:09:21.700157
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:24.173264
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:28.972888
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the facts.hardware.linux module.
    """
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_0 = HurdHardware(hurd_hardware_collector_1)
    hurd_hardware_0.populate()
    return


# Generated at 2022-06-24 22:09:38.786344
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def get_uptime_facts_fake(self):
        return {'uptime_seconds': '4282'}

    def get_memory_facts_fake(self):
        return {'virtual_memory': {'total': '18453381163'}, 'swap': {'total': '0'}}

    def get_mount_facts_fake(self):
        return {'mounts': [{'mount': '/', 'device': '/dev/hdb1'}, {'mount': '/bin', 'device': '/dev/hdb1'}]}

    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.get_uptime_facts = get_uptime_facts_fake
    hurd_hardware_0.get_memory_facts = get_memory_facts_fake
    hurd_hardware_0

# Generated at 2022-06-24 22:09:48.764239
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Creation of an instance of class HurdHardware
    hurd_hardware_obj = HurdHardware()

    # Call method populate of HurdHardware with a list of 2 elements
    hurd_hardware_obj.populate(["hardware", "--name=value"])

    # Call method populate of HurdHardware with a list of 2 elements
    hurd_hardware_obj.populate(["uptime", "--name=value"])


# Generated at 2022-06-24 22:09:57.216852
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_class = HurdHardware()
    boottime_delta = ((test_class.get_boottime_timestamp() - test_class.get_file_content_as_dict(test_class.uptime_file, val_split_char=None))/60)

    boottime_delta_1 = ((test_class.get_boottime_timestamp() - test_class.get_file_content_as_dict(test_class._uptime_file, val_split_char=None))/60)

    test_class.uptime_file = "/dev/null"
    boottime_delta_2 = ((test_class.get_boottime_timestamp() - test_class.get_file_content_as_dict(test_class.uptime_file, val_split_char=None))/60)

   

# Generated at 2022-06-24 22:10:07.970209
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware_0 = hurd_hardware_collector.collect()

    assert hurd_hardware_0['boot_time'] == 'Mon, 16 Sep 2019 14:47:45 +0000'
    assert hurd_hardware_0['switch_count'] == 0
    assert hurd_hardware_0['total_mem'] == 524280
    assert hurd_hardware_0['mounts'] == [{
        'device': '/dev/disk/by-uuid/0b7e0f07-b256-4714-ade2-35a5e5bb9779',
        'fstype': 'ext4',
        'mount': '/',
        'options': 'rw,relatime'}]

# Generated at 2022-06-24 22:10:10.301126
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:14.258333
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-24 22:10:18.440679
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError
    hurd_hardware_0 = HurdHardware()
    try:
        hurd_hardware_0.get_mount_facts()
    except TimeoutError as e:
        assert(True)

# Generated at 2022-06-24 22:10:27.042764
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware = HurdHardware()
    HurdHardware._module = FakeModule()
    HurdHardware.populate()

from ansible.module_utils.facts.hardware.hurd import *
import ansible.module_utils.facts.hardware.hurd
from ansible.module_utils.facts.hardware.hurd import HurdHardware, HurdHardwareCollector
from ansible.module_utils.facts.hardware.base import HardwareCollector, LinuxHardware
import ansible.module_utils.facts.hardware.base
import ansible.module_utils.facts.hardware.linux
from ansible.module_utils.facts.timeout import TimeoutError
from ansible.module_utils.facts.hardware.linux import LinuxHardware
import ansible.module_utils.facts.timeout

# Generated at 2022-06-24 22:10:29.081502
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()

# Generated at 2022-06-24 22:10:32.670026
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate(collected_facts=None)


# Generated at 2022-06-24 22:10:40.781916
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = {
        "distribution": "GNU",
        "distribution_release": "Hurd",
        "distribution_version": "0.6"
    }
    facts = hurd_hardware_0.populate(collected_facts)
    assert facts['memory']['swap']['total'] == 1048576
    assert facts['mounts'][0]['mount'] == '/proc/self/fd'
    assert facts['mounts'][0]['options'] == 'rw'
    assert facts['mounts'][0]['type'] == 'procfs'
    assert facts['mounts'][0]['device'] == 'procfs'
    assert facts['mounts'][0]['fstype'] == 'procfs'
    assert facts

# Generated at 2022-06-24 22:10:53.686990
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
# Method populate of class HurdHardware
    collected_facts_0 = { 'virtual': 'physical', }
    collected_facts_1 = { 'virtual': 'physical', }
    collected_facts_2 = { 'virtual': 'physical', }
    collected_facts_3 = { 'virtual': 'physical', }
    collected_facts_4 = { 'virtual': 'physical', }
    collected_facts_5 = { 'virtual': 'physical', }
    collected_facts_6 = { 'virtual': 'physical', }
    collected_facts_7 = { 'virtual': 'physical', }
    collected_facts_8 = { 'virtual': 'physical', }
    collected_facts_9 = { 'virtual': 'physical', }
    collected_facts_10 = { 'virtual': 'physical', }
   

# Generated at 2022-06-24 22:10:59.857101
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    assert hurd_hardware_0.populate() == {
        'uptime': 0,
        'uptime_seconds': 0,
        'memtotal_mb': None,
        'memfree_mb': None,
        'swaptotal_mb': None,
        'swapfree_mb': None,
        'mounts': []
    }

# Generated at 2022-06-24 22:11:01.900556
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:04.784356
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_object_0 = HurdHardware()
    print(hurd_hardware_object_0.populate())


# Generated at 2022-06-24 22:11:06.455912
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:08.642292
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:10.592093
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initialize HurdHardware object
    hurd_hardware_0 = HurdHardware()
    

# Generated at 2022-06-24 22:11:15.906775
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    collected_facts = {}
    hw.populate(collected_facts)

    facts = hw.get_facts()
    assert facts['uptime_seconds'] > 0
    assert 'MemTotal' in facts['ansible_memfree_mb']
    assert 'MemFree' in facts['ansible_memfree_mb']
    assert 'SwapTotal' in facts['ansible_memfree_mb']
    assert 'SwapFree' in facts['ansible_memfree_mb']

# Generated at 2022-06-24 22:11:24.753050
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module_mock = mock.MagicMock()
    module_mock.params = {"gather_mount_points": "non_default"}
    module_mock.get_bin_path.side_effect = lambda x, required=False: x
    module_mock.run_command.return_value = (0, 'testout', None)

    hurd_hardware_0 = HurdHardware()
    result = hurd_hardware_0.populate(collected_facts={"ansible_module_mock": module_mock})
    assert "ansible_module_mock" in result
    assert "system_uptime" in result
    maxheap_pattern = re.compile(r'^[0-9]+$')
    assert re.search(maxheap_pattern, result["system_maxheap"])

# Generated at 2022-06-24 22:11:27.860616
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_object = HurdHardware()
    hurd_hardware_object.populate()

# Generated at 2022-06-24 22:11:33.558944
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:36.828310
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    # Case 0: Test with a dictionary with the needed keys
    hurd_hardware_0.populate()
    # Case 1: Test with a dictionary without the needed keys
    hurd_hardware_0.populate({})

# Generated at 2022-06-24 22:11:38.488734
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(None)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:46.719621
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    print("Unit test for method popualte of class HurdHardware")
    print("Uptime")
    print("Uptime : "+str(facts['uptime']))
    print("Uptime_seconds : "+str(facts['uptime_seconds']))

    print("Mount points")
    for device in facts['mounts']:
        print("Mount point : "+str(device))

    print("Memory")
    print("MemTotal : "+str(facts['mem_total']))
    print("SwapTotal : "+str(facts['swap_total']))

# Generated at 2022-06-24 22:11:53.157120
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()
    # Verify
    assert len(hurd_hardware_0.data['mounts']) > 0
    assert len(hurd_hardware_0.data['memory']) == 0
    assert hurd_hardware_0.data['uptime_days'] > 0
    assert hurd_hardware_0.data['uptime_seconds'] > 0
    assert hurd_hardware_0.data['uptime_hours'] > 0
    assert hurd_hardware_0.data['uptime_minutes'] > 0


# Generated at 2022-06-24 22:12:03.124194
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:12:05.974844
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate = hurd_hardware.populate()
    assert isinstance(hurd_hardware_populate, dict)


# Generated at 2022-06-24 22:12:16.919335
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = dict()

    # If module_utils.facts.hardware.linux.LinuxHardware.populate returned False
    hurd_hardware_populate_return = dict()
    hurd_hardware_populate_return = False
    hurd_hardware_populate_return = dict()
    hurd_hardware_populate_return = {'uptime_seconds': 459608.66, 'uptime_hours': 12.774560333333334, 'uptime_days': 0, 'uptime': '12 hours, 46 minutes'}
    linux_hardware_populate_return = dict()

# Generated at 2022-06-24 22:12:25.368815
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:12:28.074181
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-24 22:12:36.576340
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardware()

# Generated at 2022-06-24 22:12:43.769065
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    case_0_output = {
        'uptime_seconds': 18876,
        'uptime_hours': 5,
        'uptime_days': 0,
        'memtotal_mb': 512,
        'swaptotal_mb': 0,
        'processor_count': 1,
        'mounts': [
            {
                'device': '/dev/disk/by-label/root',
                'fstype': 'ext2',
                'mount': '/',
                'options': 'defaults'
            },
            {
                'device': '/dev/disk/by-label/root',
                'fstype': 'ext2',
                'mount': '/home',
                'options': 'defaults'
            },
        ]
    }
    assert case_0_output == HurdHardware().populate()

# Generated at 2022-06-24 22:12:46.530335
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_HurdHardware_populate_0 = HurdHardware()
    test_HurdHardware_populate_0_response = test_HurdHardware_populate_0.populate()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:12:49.208429
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# vim: expandtab filetype=python

# Generated at 2022-06-24 22:12:50.895262
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:53.437320
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an instance of HurdHardware
    hurd_hardware_instance = HurdHardware()
    
    # Call method populate of HurdHardware
    hurd_hardware_instance.populate()


# Generated at 2022-06-24 22:13:00.850175
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hardware_facts = hurd_hardware.populate()

    assert hardware_facts["uptime_seconds"] != 0
    assert hardware_facts["uptime_minutes"] != 0
    assert hardware_facts["memtotal_mb"] > 0
    assert hardware_facts["memfree_mb"] > 0
    assert hardware_facts["swaptotal_mb"] >= 0
    assert hardware_facts["swapfree_mb"] >= 0
    assert len(hardware_facts["mounts"]) > 0

# Generated at 2022-06-24 22:13:02.701486
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:04.840136
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:11.452071
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    platform = 'GNU'
    hurd_hardware = HurdHardware(platform)
    collected_facts = {}
    hardware_facts = hurd_hardware.populate()

    # get_uptime_facts returns a dictionary of uptime facts
    assert isinstance(hardware_facts, dict)
    # get_memory_facts returns a dictionary of memory facts
    assert isinstance(hardware_facts, dict)
    # get_mount_facts returns a dictionary of mount facts
    assert isinstance(hardware_facts, dict)

# Generated at 2022-06-24 22:13:17.916384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:20.092846
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert len(hurd_hardware.populate()) > 2

# Generated at 2022-06-24 22:13:29.594964
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts_0 = {}
    collected_facts_1 = {'ansible_facts': {'hardware': {'memory': {'swap': {'total_mb': 1023.851837158203}}}}}
    collected_facts_2 = {'ansible_facts': {'hardware': {'memory': {'swap': {'total_mb': 1023.851837158203}}}}}
    collected_facts_3 = {'ansible_facts': {'hardware': {'memory': {'swap': {'total_mb': 1023.851837158203}}}}}

# Generated at 2022-06-24 22:13:32.310413
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    assert hurd_hardware_0.populate() == {'memtotal_mb': 468, 'uptime_seconds': 2084, 'memfree_mb': 460}

# Generated at 2022-06-24 22:13:35.266695
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:38.548672
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_collector_0 = HurdHardwareCollector()

    result = hurd_hardware.populate()

    assert result.get('memory_mb') is not None
    assert result.get('uptime_seconds') is not None
    assert result.get('mounts') is not None

# Generated at 2022-06-24 22:13:48.781005
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_collector_0.platform = 'GNU'
    hurd_hardware_0.platform = 'GNU'
    hurd_hardware_0.uptime = {'seconds': 222006, 'hours': 6}
    file_path = "ansible/module_utils/facts/hardware/linux/meminfo"
    path_size = 923
    file_size = 923
    chunksize = 1024

# Generated at 2022-06-24 22:13:51.506602
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-24 22:13:52.929637
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_1 = HurdHardware()


# Generated at 2022-06-24 22:13:55.891831
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_1 = HurdHardware(hurd_hardware_collector_1)
    hurd_hardware_1.populate()


# Generated at 2022-06-24 22:14:11.735078
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_1 = HurdHardware()
    hurd_hardware_2 = HurdHardware()
    hurd_hardware_3 = HurdHardware()
    hurd_hardware_0.populate(collected_facts={})
    hurd_hardware_1.populate()
    hurd_hardware_2.populate()
    hurd_hardware_3.populate(collected_facts={})

# Generated at 2022-06-24 22:14:18.859147
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = {}
    collected_facts = {'virtualization_type': 'parsed', 'processor_vcpus': 32, 'processor_count': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0, 'uptime_seconds': 0, 'uptime_hours': 0, 'current_time': 0, 'uptime_days': 0}
    hurd_hardware_0.populate(collected_facts)
    assert collected_facts == {}

# Generated at 2022-06-24 22:14:27.151428
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = {'ansible_system': 'GNU'}

    result = hurd_hardware_0.populate(collected_facts)

    assert result.get('uptime_seconds') is not None
    assert result.get('uptime_days') is not None
    assert result.get('uptime_hours') is not None
    assert result.get('uptime_seconds') > 0

    assert result.get('total_physical_memory_mb') > 0
    assert result.get('total_physical_memory_kb') > 0

    assert result.get('mounts') is not None

# Generated at 2022-06-24 22:14:29.266953
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # test_0(HurdHardware):
    hurd_hardware_0 = HurdHardware()

# Generated at 2022-06-24 22:14:30.597320
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-24 22:14:33.491843
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0 = HurdHardware()
    facts = hurd_hardware_0.populate()
    assert facts == {}

# Generated at 2022-06-24 22:14:34.183277
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:14:42.825454
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:14:43.510984
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:14:47.177120
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_collector_0 = HurdHardwareCollector()
    assert isinstance(hurd_hardware_0.populate(), dict)


# Generated at 2022-06-24 22:15:04.965091
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Test with one node
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime': {'seconds': 4513}, 'swap': {'avail': 834697216, 'total': 834697216}, 'memory': {'avail': 4676096, 'real': {'free': 32943616, 'total': 54438912}, 'swap': {'free': 834697216, 'total': 834697216}}}

    # Test with another node
    int_1 = 98
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()

# Generated at 2022-06-24 22:15:07.948196
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}, 'Return value of HurdHardware.populate() is not equal to {} as expected'

# Unit tests for class HurdHardwareCollector


# Generated at 2022-06-24 22:15:09.313521
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise(e)


# Generated at 2022-06-24 22:15:11.777279
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert callable(HurdHardware.populate)

# Generated at 2022-06-24 22:15:15.040551
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    # Call method
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:24.151435
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:24.964485
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:15:28.076712
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:29.344820
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware.populate() == None


# Generated at 2022-06-24 22:15:32.893761
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert not var_0


# Generated at 2022-06-24 22:15:56.530218
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:16:01.031236
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    collect_0 = HurdHardwareCollector()
    var_0 = collect_0.collect()
    assert len(var_0) == 3
    assert var_0['mounts'][1]['device'] == '/dev/vda'
    assert var_0['memory']['MemTotal'] == 4194304
    assert var_0['uptime']['seconds'] == 154825

# Generated at 2022-06-24 22:16:11.461977
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import pytest
    import sys
    import builtins
    from unittest.mock import MagicMock, patch

    updict = {'proc_mounts': {'fstype': 'procfs', 'mount': '/proc', 'dev': '/proc'},
             'total_usable_ram_mb': 493,
             'hw_mem_free': 4483713,
             'hw_mem_total': 5128324,
             'hw_processor_cores': 1,
             'hw_mem_available': 4669052}

    class TestHardware:

        def __init__(self):
            self.facts = {'uptime': updict}

        def populate(self):
            return {'memory': self.facts}


# Generated at 2022-06-24 22:16:14.188182
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:15.730315
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # noop, see test_case_0 above
    pass

# Generated at 2022-06-24 22:16:18.333904
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    assert_equals(hurd_hardware_0.populate(), ())

# Generated at 2022-06-24 22:16:21.054429
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:24.028644
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 54
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:27.118872
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    with pytest.raises(AssertionError):
        int_0 = 90
        hurd_hardware_0 = HurdHardware(int_0)
        var_0 = hurd_hardware_0.populate(False)

# Generated at 2022-06-24 22:16:29.606947
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:49.922203
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:16:52.798324
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:00.503474
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert type(var_0) == dict
    assert var_0['uptime_seconds'] == 14
    assert var_0['uptime_hours'] == 0
    assert var_0['uptime_days'] == 0
    assert var_0['uptime_years'] == 0
    assert var_0['uptime_minutes'] == 0
    assert var_0['uptime_seconds_raw'] == 14
    assert var_0['uptime_hours_raw'] == 0
    assert var_0['uptime_days_raw'] == 0
    assert var_0['uptime_minutes_raw'] == 0
    assert var_0['uptime_timestamp']

# Generated at 2022-06-24 22:17:04.231913
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 200
    hurd_hardware_0 = HurdHardware(int_0)
    var_2 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:08.930013
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    assert set(hurd_hardware_0.populate()) == set(['uptime_seconds', 'vendor', 'uptime_days', 'uptime_hours', 'serial', 'uptime_hours_minutes'])


# Generated at 2022-06-24 22:17:12.144480
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:16.876514
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    # check the default value of variable var_0
    assert var_0 == {}
    # check the type of variable var_0
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 22:17:19.526307
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import json
    # Test the function with valid input
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 22:17:24.356842
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 78
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert len(var_0) == 3
    assert sorted(var_0.keys()) == ['uptime', 'uptime_seconds', 'virtual_memory']


# Generated at 2022-06-24 22:17:31.302007
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 100
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

    assert var_0['ansible_uptime_seconds'] == int_0
    assert var_0['ansible_uptime_hours'] == 0
    assert var_0['ansible_uptime_days'] == 0

    assert var_0['ansible_memtotal_mb'] > 0
    assert var_0['ansible_memory_mb']['nocache']['free'] > 0
    assert var_0['ansible_memory_mb']['nocache']['used'] > 0

# Generated at 2022-06-24 22:18:14.869743
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    assert isinstance(hurd_hardware_0.populate(), dict)

# Generated at 2022-06-24 22:18:24.387445
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)

    # Check if we are running under GNU/Hurd
    if hurd_hardware_0.platform != 'GNU/Hurd':
        return

    # Call method populate of class HurdHardware
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

    # Check if variables returned by method populate of class HurdHardware are in expected state

# Generated at 2022-06-24 22:18:27.023424
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 12
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:28.149089
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:18:29.936860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:32.272704
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:41.291805
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    int_1 = 90
    hurd_hardware_1 = HurdHardware(int_1)
    # Configure the mock interpreter.
    hurd_hardware_1.procfs_path = '/proc'
    hurd_hardware_1.python_version = 2
    hurd_hardware_1.virtual_alias = ('virtual',)
    hurd_hardware_1.virtual_alias += ('vmware',)
    hurd_hardware_1.virtual_alias += ('xenu',)
    hurd_hardware_1.virtual_alias += ('xen',)
    hurd_hardware_1.virtual_alias += ('kvm',)
    hurd_hardware_1.virtual_alias += ('qemu',)
    hurd

# Generated at 2022-06-24 22:18:44.428810
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware_0 = HurdHardware()

    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None



# Generated at 2022-06-24 22:18:48.549711
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 90
    hurd_hardware_0 = HurdHardware(int_0)
    try:
        hurd_hardware_0.populate()
        assert False
    except TimeoutError:
        assert True
    except:
        assert False

test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:18:50.566417
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_1 = 90
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()
