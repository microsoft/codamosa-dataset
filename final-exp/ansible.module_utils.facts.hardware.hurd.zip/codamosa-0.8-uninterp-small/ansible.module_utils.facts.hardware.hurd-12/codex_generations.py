

# Generated at 2022-06-24 22:08:56.773672
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hurd_hardware_0 = HurdHardware(0)

    assert callable(hurd_hardware_0.populate)


# Generated at 2022-06-24 22:08:59.350275
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)

    # Call method
    ret_value_0 = hurd_hardware_0.populate()

    # Test assertion(s)
    assert isinstance(ret_value_0, dict)


# Generated at 2022-06-24 22:09:02.806251
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -17740
    hurd_hardware_0 = HurdHardware(int_0)
    collected_facts = {
        'virtual': 'physical',
        'operating_system': 'GNU/Hurd'
    }
    hurd_hardware_0.populate(collected_facts)

# Generated at 2022-06-24 22:09:06.134644
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    collected_facts = None
    assert hurd_hardware_0.populate(collected_facts) is None


# Generated at 2022-06-24 22:09:10.197758
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -10000
    hurd_hardware_0 = HurdHardware(int_0)
    # Call method populate of hurd_hardware_0
    # The following exception was thrown during execution.
    # TypeError: unsupported operand type(s) for +=: 'dict' and 'NoneType'
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:18.573368
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(3)
    collected_facts = {}

# Generated at 2022-06-24 22:09:27.589529
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    collected_facts_0 = {};
    collected_facts_0['system'] = 'Linux'
    collected_facts_0['env'] = 'env'
    collected_facts_0['platform'] = 'Linux'
    collected_facts_0['distribution'] = 'RedHat'
    collected_facts_0['distribution_release'] = '6.1'
    collected_facts_0['distribution_version'] = '6.1'
    collected_facts_0['system'] = 'Linux'
    collected_facts_0['env'] = 'env'
    collected_facts_0['platform'] = 'Linux'
    collected_facts_0['distribution'] = 'RedHat'

# Generated at 2022-06-24 22:09:31.988128
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -1342
    hurd_hardware_0 = HurdHardware()
    collected_facts = HurdHardware()
    return_value_1 = hurd_hardware_0.populate(collected_facts)
    assert return_value_1 == int_0


# Generated at 2022-06-24 22:09:36.088210
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -3681
    hurd_hardware_0 = HurdHardware(int_0)
    collected_facts_0 = None
    try:
        collected_facts_1 = hurd_hardware_0.populate(collected_facts_0)
        assert False
    except TimeoutError as raised_exc:
        assert True
    except Exception as raised_exc:
        assert False, str(raised_exc)


# Generated at 2022-06-24 22:09:41.672599
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Case 0
    # Case 1
    # Case 2
    # Case 3
    # Case 4
    # Case 5
    # Case 6
    # Case 7
    # Case 8
    # Case 9
    # Case 10
    # Case 11
    # Case 12
    # Case 13
    # Case 14
    # Case 15
    # Case 16
    # Case 17
    # Case 18
    # Case 19
    pass


# Generated at 2022-06-24 22:09:47.850031
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -14906
    hurd_hardware_0 = HurdHardware(int_0)
    collected_facts_0 = None
    var_0 = hurd_hardware_0.populate(collected_facts_0)
    assert var_0 != None


# Generated at 2022-06-24 22:09:48.805762
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert var_0 == 0

# Generated at 2022-06-24 22:09:49.672097
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True == True


# Generated at 2022-06-24 22:09:53.085420
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -3670
    hurd_hardware_0 = HurdHardware(int_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 22:09:56.499131
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -6031
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:00.636822
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -2582
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:01.670450
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var = test_case_0()

# Generated at 2022-06-24 22:10:05.236203
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.populate()

#Unit test for method get_uptime_facts of class HurdHardware

# Generated at 2022-06-24 22:10:09.082877
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(0)
    try:
        hurd_hardware_0.populate()
    except (IOError, ValueError):
        pass
    else:
        assert False

# Generated at 2022-06-24 22:10:13.777049
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -17816
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:10:17.769961
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    assert isinstance(hurd_hardware_0.populate(), dict)


# Generated at 2022-06-24 22:10:19.964887
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -1924
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:21.842500
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -7
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:10:29.170238
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -9861
    hurd_hardware_0 = HurdHardware(int_0)

    # Test with arg self
    arg_0 = hurd_hardware_0
    arg_0 = None

    # Test with arg collected_facts
    arg_0 = hurd_hardware_0
    arg_1 = None
    var_0 = hurd_hardware_0.populate(arg_0, arg_1)


# Generated at 2022-06-24 22:10:33.208205
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 568
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:37.724707
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print(HurdHardware.populate.__doc__)
    try:
        int_0 = -5258
        hurd_hardware_0 = HurdHardware(int_0)
        var_0 = hurd_hardware_0.populate()
    except:
        var_0 = "Error"
    assert type(var_0) is dict
    assert var_0 == {}


# Generated at 2022-06-24 22:10:42.117790
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}



# Generated at 2022-06-24 22:10:47.389080
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # The following code is an 'unittest' for the 'populate' method of the 'HurdHardware' class.
    # This test is also an example of how to use the 'HurdHardware' class
    # Once you have edited this code, please run the following command:
    # python -c 'import json,unit_tests; print(json.dumps(unit_tests.test_HurdHardware_populate()))'
    # Dictionary to test the method
    int_0 = 0
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    # Dictionary to be used as reference by the test

# Generated at 2022-06-24 22:10:54.423135
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    if (var_0 == {'mounts': [{'mount': '/', 'device': '/dev/hd0s1', 'fstype': 'ext2fs'}, {'mount': '/proc', 'device': '/dev/proc', 'fstype': 'procfs'}, {'mount': '/gnu', 'device': '/dev/hd0s2', 'fstype': 'ext2fs'}], 'uptime_days': 0, 'uptime_hours': 0, 'uptime_seconds': 0, 'uptime_minutes': 0, 'memtotal_mb': 0}):
        var_0 = False
    else:
        var_0 = True


# Generated at 2022-06-24 22:10:55.640338
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True == True  # TODO: implement your test here

# Generated at 2022-06-24 22:11:00.197182
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -7589
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    return var_0

# Generated at 2022-06-24 22:11:03.229243
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -3874
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:05.386419
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -1881
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:06.922605
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    e = HurdHardware(None)
    e.populate(None)



# Generated at 2022-06-24 22:11:08.972630
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 478
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:11:10.243741
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()



# Generated at 2022-06-24 22:11:12.589169
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -39
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:17.165654
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -11121
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:11:21.438657
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == None

# Generated at 2022-06-24 22:11:24.616592
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -17776
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}, var_0


# Generated at 2022-06-24 22:11:29.785206
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert(False)


# Generated at 2022-06-24 22:11:31.561996
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:11:34.365076
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:37.469527
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    arg_0 = -5258
    arg_0 = HurdHardware(arg_0)
    # populate() missing 1 required positional argument: 'collected_facts'
    with pytest.raises(TypeError):
        arg_0.populate()

# Generated at 2022-06-24 22:11:38.357770
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 1 == 1


# Generated at 2022-06-24 22:11:45.147253
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert (var_0 == {'uptime': 105, 'uptime_seconds': 105, 'memory_mb': {'real': {'memtotal': 3960, 'swapfree': 0, 'memfree': 810, 'swaptotal': 0}}, 'mounts': []})

# Generated at 2022-06-24 22:11:46.317708
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # No test for a stub
    pass

# Generated at 2022-06-24 22:11:49.374934
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    #from ansible_fact_parser.utils.unit_test_utils import is_equal
    HurdHardware_0 = HurdHardware(0)
    var_0 = HurdHardware_0.populate()
    assert 1 == 1


# Generated at 2022-06-24 22:11:56.794350
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -11940
    hurd_hardware_0 = HurdHardware(int_0)
    num_0 = 10
    int_1 = -4
    hurd_hardware_0.populate()
    num_1 = 10
    num_2 = 10
    num_3 = 10
    int_2 = -28643
    int_3 = 10
    num_4 = 10
    int_4 = -7
    num_5 = 10
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:05.369399
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 64735
    hurd_hardware_0 = HurdHardware(int_0)
    int_0 = -15669
    string_0 = "Rlv4$4:>pZys.V=G.]e`<7M2aF5D5jj3m{]Iu8tfuBH[!lZt)2#W zb8c%_#eN08yC~+Xfwo8#+NI7VuqxLP@5]C;"
    boolean_0 = False
    long_0 = -24211
    string_1 = "`"
    byte_0 = 6
    byte_1 = 82
    byte_2 = -118
    byte_3 = 29
    byte_4 = 14
    byte_5 = -93
    byte_6 = 27
    byte

# Generated at 2022-06-24 22:12:10.369839
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware(0)
    var_1.populate()

# Generated at 2022-06-24 22:12:14.244093
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -4908
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)



# Generated at 2022-06-24 22:12:18.168238
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_1 = -10161
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1 == None

# Generated at 2022-06-24 22:12:24.088748
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    try:
        assert var_0.get('memfree_mb') == 3925
        assert var_0.get('uptime') == 997333
    except AssertionError as e:
        raise AssertionError(str(e) + '\nFailed test #0 of test_HurdHardware_populate')



# Generated at 2022-06-24 22:12:25.612601
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:30.856606
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'facter_mountpoints': {}, 'facter_swap': [], 'facter_system_uptime': ['0', '0', '0']}

# Generated at 2022-06-24 22:12:32.059196
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    prove_it(test_case_0,'test_case_0')

# Generated at 2022-06-24 22:12:39.208580
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -10671
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.get_distribution_facts()
    hurd_hardware_0.get_cpu_facts()
    hurd_hardware_0.get_virtualization_facts()
    var_0 = hurd_hardware_0.get_uptime_facts()
    var_1 = hurd_hardware_0.get_memory_facts()
    var_3 = hurd_hardware_0.get_mount_facts()


# Generated at 2022-06-24 22:12:45.015794
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    assert not isinstance(hurd_hardware_0, object)
    assert len(var_0) == 4
    assert var_0['mounts'] == {}
    assert var_0['uptime_seconds'] == 1

# Generated at 2022-06-24 22:12:53.612958
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 80245
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}
    int_1 = 92692
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1 == {}
    int_2 = 36230
    hurd_hardware_2 = HurdHardware(int_2)
    var_2 = hurd_hardware_2.populate()
    assert var_2 == {}

# Generated at 2022-06-24 22:13:03.695165
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -20281
    hurd_hardware_0 = HurdHardware(int_0)
    assert False


# Generated at 2022-06-24 22:13:07.719574
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -1747
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

    assert var_0 == {}

# Generated at 2022-06-24 22:13:13.420425
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -33446
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'memory': {'memtotal_mb': 3800, 'memfree_mb': 683, 'swaptotal_mb': 0, 'swapfree_mb': 0}}


# Generated at 2022-06-24 22:13:15.571006
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:18.010201
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -3359
    int_1 = -39
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_1 = HurdHardware(int_1)
    hurd_hardware_0.populate()
    hurd_hardware_1.populate()


# Generated at 2022-06-24 22:13:28.791764
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -7264
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.populate()

import sys

from ansible.module_utils.facts.hardware.hurd import HurdHardware

from ansible.module_utils.facts.hardware.hurd import test_case_0
from ansible.module_utils.facts.hardware.hurd import test_HurdHardware_populate

if __name__ == '__main__':
    if len(sys.argv) == 1:
        for f in sys.modules['ansible.module_utils.facts.hardware.hurd'].__dict__.keys():
            if f.startswith('test_'):
                print('Calling: {}'.format(f))

# Generated at 2022-06-24 22:13:31.490129
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # dummy_value = 0
    # dummy_value = int(dummy_value)
    # obj = HurdHardware(dummy_value)
    # obj.populate()
    pass


# Generated at 2022-06-24 22:13:42.927033
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -1
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:46.587795
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 378
    hurd_hardware_0 = HurdHardware(int_0)

    # test for return value of function populate
    assert hurd_hardware_0.populate() == None


# Generated at 2022-06-24 22:13:50.405338
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    int_1 = -5259
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()

# Generated at 2022-06-24 22:14:05.749217
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 1
    hurd_hardware_0 = HurdHardware(int_0)
    try:
        var_0 = hurd_hardware_0.populate()
    except Exception as e:
        var_0 = e
    else:
        var_0 = "unexpected output %s" % var_0
    assert var_0 == "unexpected output {'timestamp': 0}"

# Generated at 2022-06-24 22:14:08.551522
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 0
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:11.073066
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware(0)
    var_1 = var_0.populate()

# Generated at 2022-06-24 22:14:13.410793
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 156
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:14.988298
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    os_0 = HurdHardware(None)
    assert os_0.populate() == {}

# Generated at 2022-06-24 22:14:18.471629
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    for delay in range(0, 1):
        for precision in range(0, 1):
            for version in range(0, 1):
                for timeout in range(0, 1):
                    for gpgkey in range(0, 1):
                        test_case_0()

# Generated at 2022-06-24 22:14:23.687303
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -6999
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.get_uptime_facts()
    var_2 = hurd_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:14:24.549783
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:14:31.379153
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['memtotal_mb'] == 7
    assert 'uptime' in var_0
    assert var_0['mounts'] == ['procfs']
    assert var_0['memfree_mb'] == 7
    assert var_0['memavailable_mb'] == 7


# Generated at 2022-06-24 22:14:35.955498
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -11579
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:58.067390
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == None


# Generated at 2022-06-24 22:15:01.337087
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:03.866711
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None


# Generated at 2022-06-24 22:15:09.122736
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 != None


# Generated at 2022-06-24 22:15:11.543930
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # No test for now
    pass



# Generated at 2022-06-24 22:15:14.522804
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -2299
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:18.640458
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}, 'Found: %s' % str(var_0)


# Generated at 2022-06-24 22:15:21.317011
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:27.494081
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    assert isinstance(hurd_hardware_0, HurdHardware)
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.populate()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 22:15:32.739318
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    int_1 = -3438
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()
    int_2 = -1317
    hurd_hardware_2 = HurdHardware(int_2)
    var_2 = hurd_hardware_2.populate()
    int_3 = -4006
    hurd_hardware_3 = HurdHardware(int_3)
    var_3 = hurd_hardware_3.populate()
    int_4 = -5235
    hurd_hardware_4 = HurdHardware(int_4)

# Generated at 2022-06-24 22:16:15.773029
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert (var_0 is not None), 'Return value of method populate of class HurdHardware is None.'


# Generated at 2022-06-24 22:16:20.060657
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_1 = -8297
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()
    var_2 = None
    assert var_1 == var_2, "Instance attribute 'populate' is not 'None'"


# Generated at 2022-06-24 22:16:24.212367
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 1757
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = isinstance(var_0, dict)
    assert var_1


# Generated at 2022-06-24 22:16:28.072514
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -4181
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:31.557649
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -16097
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {
        'uptime_seconds': 0,
        'memtotal_mb': 0
    }


# Generated at 2022-06-24 22:16:34.003191
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    return var_0


# Generated at 2022-06-24 22:16:36.058369
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -7590
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:16:39.743379
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('''
----------------------------------------------------------------------
Ran 1 test in 0.001s

OK
----------------------------------------------------------------------
''')

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:42.109537
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Test for method populate of class HurdHardware')
    test_case_0()


if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:45.150180
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def verify_populate(arg_1):
        pass

    hurd_hardware_0 = HurdHardware(None)
    var_1 = hurd_hardware_0.populate()
    verify_populate(var_1)


# Generated at 2022-06-24 22:18:08.553881
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:18:11.133355
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test for case 0.
    try:
        test_case_0()
    except TimeoutError:
        pass


# Generated at 2022-06-24 22:18:15.108510
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None


# Generated at 2022-06-24 22:18:18.383366
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -9684
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None



# Generated at 2022-06-24 22:18:19.236638
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert test_case_0() == None

# Generated at 2022-06-24 22:18:27.315295
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:18:35.551070
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:40.222466
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -35160
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.get_uptime_facts()
    var_2 = hurd_hardware_0.get_memory_facts()
    var_3 = hurd_hardware_0.get_mount_facts()


# Generated at 2022-06-24 22:18:42.045403
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = -5258
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:47.772393
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    path_0 = '/proc'
    int_0 = -4004
    hurd_hardware_0 = HurdHardware(path_0, int_0)
    try:
        hurd_hardware_0.populate()
        assert False
    except TypeError:
        assert True
    except OSError:
        assert False
    except ValueError:
        assert False
    except IOError:
        assert False
    except TimeoutError:
        assert False
    except Exception:
        assert True