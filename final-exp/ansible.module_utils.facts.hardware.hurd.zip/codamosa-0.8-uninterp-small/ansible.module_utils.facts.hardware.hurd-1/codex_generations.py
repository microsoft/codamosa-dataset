

# Generated at 2022-06-24 22:08:59.962130
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    str_0 = "\"(\',BR n\\)zahe2bL\nX"
    hurd_hardware_0 = HurdHardware(str_0)
    uptime_facts = hurd_hardware_0.get_uptime_facts()

    memory_facts = hurd_hardware_0.get_memory_facts()

    mount_facts = {}
    try:
        mount_facts = hurd_hardware_0.get_mount_facts()
    except TimeoutError:
        pass

    hardware_facts = {}
    hardware_facts.update(uptime_facts)
    hardware_facts.update(memory_facts)
    hardware_facts.update(mount_facts)

    assert hardware_facts == dwells



# Generated at 2022-06-24 22:09:06.889830
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    input_0 = '"\x12\x14d\x1e<\x8b\x9b\xcc\xdf\x03\xc8f\xf1\x1f!\xcb\x19'
    hurd_hardware_0 = HurdHardware(input_0)
    collected_facts_0 = '#\xaa\x9b\x10\xb4\x1f\x8fV\xbc\xbb\x7f\x0e^\x9f\xa1\x04'
    collected_facts_0 = list(collected_facts_0)

# Generated at 2022-06-24 22:09:10.897601
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '/;{t]\x7fYH`'
    hurd_hardware_0 = HurdHardware(str_0)
    deque_0 = deque()
    hurd_hardware_1 = HurdHardware(deque_0)
    int_0 = hurd_hardware_1.populate(deque_0)
    assert(int_0 == -1)

# Generated at 2022-06-24 22:09:14.042532
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)

    # Test execution
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:18.882446
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '"(,BR n\\)zahe2bL\nX'
    hurd_hardware_0 = HurdHardware(str_0)

    # Test if the returned type is a dict
    assert isinstance(hurd_hardware_0.populate(), dict)


# Generated at 2022-06-24 22:09:23.994238
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    _0 = u'"(,BR n\\)zahe2bL\nX'
    hurd_hardware_0 = HurdHardware(_0)
    _1 = {}
    hurd_hardware_0.populate(_1)

# Generated at 2022-06-24 22:09:26.242153
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    n_0 = test_case_0()
    n_0.populate(collected_facts=None)


# Generated at 2022-06-24 22:09:31.988293
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '"(,BR n\\)zahe2bL\nX'
    hurd_hardware_0 = HurdHardware(str_0)

    try:
        r = hurd_hardware_0.populate()
    except (TimeoutError) as exc:
        r = False

    assert r == False


# Generated at 2022-06-24 22:09:40.261469
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '"%(e}y\/\'z/l\nP'
    hurd_hardware_0 = HurdHardware(str_0)
    collected_facts = {'os_family': 'RedHat'}

    collected_facts = hurd_hardware_0.populate(collected_facts)
    assert collected_facts == {'memfree_mb': 31, 'swapfree_mb': 37, 'memtotal_mb': 27, 'uptime_hours': 31, 'uptime_seconds': 22, 'uptime_days': 31, 'swaptotal_mb': 32, 'os_family': 'RedHat'}


# Generated at 2022-06-24 22:09:40.939027
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:09:44.307355
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except TimeoutError:
        pass


# Generated at 2022-06-24 22:09:51.132231
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'mem_total': None, 'uptime': 7, 'mem_available': None, 'uptime_seconds': 7, 'mem_used': None, 'uptime_days': 0, 'mounts': None}


# Generated at 2022-06-24 22:09:54.749722
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:09:58.253580
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:03.109939
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'w\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:07.656111
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware('7\x1f\x00\x00\x00\x00\x00\x00')
    var_1.populate()
    var_1 = HurdHardware('7\x1f\x00\x00\x00\x00\x00\x00')
    var_1.populate()

# Generated at 2022-06-24 22:10:11.503529
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    print(var_0)

# Generated at 2022-06-24 22:10:16.081229
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    res0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:16.609582
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 1 == 1

# Generated at 2022-06-24 22:10:21.529208
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'memfree_mb': 0, 'swapfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'uptime_seconds': 7}


# Generated at 2022-06-24 22:10:29.173666
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:39.832434
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    x86_64_0 = HurdHardware(str_0)
    var_0 = x86_64_0.populate()
    assert var_0['ansible_uptime_seconds'] == 2799, 'Ansible uptime seconds'
    assert var_0['ansible_uptime_days'] == 0, 'Ansible uptime days'
    assert var_0['ansible_uptime_hours'] == 0, 'Ansible uptime hours'
    assert var_0['ansible_uptime_minutes'] == 46, 'Ansible uptime minutes'
    assert 'ansible_mounts' in var_0, 'Mounts fact exists'

# Generated at 2022-06-24 22:10:45.069645
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert ('uptime' in var_0) == True


# Generated at 2022-06-24 22:10:54.120306
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {u'uptime': 7}
    str_1 = '14\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1 == {u'uptime': 14}
    str_2 = '1\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_2 = Hurd

# Generated at 2022-06-24 22:10:58.315039
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    assert hurd_hardware_0.populate() is None


# Generated at 2022-06-24 22:10:58.929940
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True

# Generated at 2022-06-24 22:11:03.038752
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:11:06.960300
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:12.164229
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime_days': 7, 'uptime_seconds': 63, 'uptime_hours': 0, 'uptime_minutes': 0}

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:11:19.600551
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

if __name__ == '__main__':
    # test_case_0()
    test_HurdHardware_populate()


#       # Mount facts
#       self.mounts = [mnt.split(' ') for mnt in self.file_grep('/etc/mtab', '^[a-zA-Z]')]
#       self.mountpoints = [mp[1] for mp in self.mounts]
#       self.fstypes = [fs[2] for fs in self.mounts]


# Generated at 2022-06-24 22:11:31.757169
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    print(var_0)



# Generated at 2022-06-24 22:11:37.757675
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = 'Failed to get mount facts'
    assert not var_0
    assert str_1 in test_HurdHardware_populate.logger.data['failures']


# Generated at 2022-06-24 22:11:38.316699
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True

# Generated at 2022-06-24 22:11:43.681444
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# unit test for class HurdHardwareCollector

# Generated at 2022-06-24 22:11:52.471739
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime_seconds': 7}
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_1 = HurdHardware(str_0)
    hurd_hardware_1.populate()
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    posix_uptime = HurdHardware(str_0)
    posix_uptime.populate()
   

# Generated at 2022-06-24 22:11:54.680432
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except Exception as err:
        assert 0


# Generated at 2022-06-24 22:11:58.712561
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:12:03.402120
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '8\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:09.375495
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    test_case_0(hurd_hardware_0)

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:12:13.382353
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:32.852913
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '5\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:34.969055
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:40.926451
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-24 22:12:43.808897
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
#

# Generated at 2022-06-24 22:12:47.592417
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_1 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:53.915408
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    name_0 = '/home/sebastian/ansible/test/units/module_utils/facts/hardware/hurd_hardware_populate'
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:54.811718
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:12:57.345063
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:00.600139
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:13:04.174339
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    input_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    var_0 = HurdHardware(input_0)
    var_1 = var_0.populate()
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 22:13:43.933688
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:48.882221
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    (var_0, var_1) = test_case_0()
    assert var_0 == '7\x1f\x00\x00\x00\x00\x00\x00'
    assert var_1 == '7\x1f\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 22:13:53.991407
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    input_str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(input_str_0)
    try:
        hurd_hardware_0.populate()
    except TimeoutError:
        pass

# Generated at 2022-06-24 22:14:04.036443
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    int_0 = 8
    int_1 = 8
    int_2 = 8
    float_0 = 0.0
    list_0 = [str_0, int_0, int_1, int_2, float_0]
    dict_0 = {'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1', 'test_key_2': 'test_value_2', 'test_key_3': 'test_value_3'}

# Generated at 2022-06-24 22:14:10.863842
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime': {'days': 0, 'hours': 0, 'seconds': 7, 'uptime': '7 seconds', 'minutes': 0}, 'memtotal': 33554432.0, 'swapfree': 0.0, 'swaptotal': 0.0, 'memfree': 32901120.0, 'mounts': [{'device': '/dev/hd0s1', 'mount': '/', 'fstype': 'hfs'}]}

# Generated at 2022-06-24 22:14:13.466375
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:17.704301
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:18.265763
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:14:22.323666
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    assert HurdHardware.populate(str_0) == None


# Generated at 2022-06-24 22:14:27.172473
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:50.039374
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:55.133108
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:02.067411
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    int_0 = 7
    int_1 = 31
    int_2 = 0
    int_3 = 0
    float_0 = 1.1838790817810059e-37
    float_1 = 1.1755702951431274e-313
    float_2 = 1.1823684805870056e-37
    str_1 = 'Linux'
    str_2 = '3.18.0-14-generic'
    str_3 = '#15-Ubuntu SMP Tue Mar 17 09:59:03 UTC 2015'
    str

# Generated at 2022-06-24 22:16:11.021860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.get_uptime_facts = lambda : var_0
    hurd_hardware_0.get_memory_facts = lambda : var_1
    hurd_hardware_0.get_mount_facts = lambda : var_2
    var_0 = 'A'
    var_1 = 2
    var_2 = 3
    assert var_0 == hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:15.335607
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:19.514067
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_cases = [
        (0, )
    ]
    for index, test_case in enumerate(test_cases):
        test_func_name = 'test_case_' + str(index)
        test_func = globals()[test_func_name]
        test_func(*test_case)

# Generated at 2022-06-24 22:16:23.750464
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:24.723367
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:16:26.341033
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('*** Testing HurdHardware.populate()')
    test_case_0()


# Generated at 2022-06-24 22:16:29.392102
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7\x1f\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
