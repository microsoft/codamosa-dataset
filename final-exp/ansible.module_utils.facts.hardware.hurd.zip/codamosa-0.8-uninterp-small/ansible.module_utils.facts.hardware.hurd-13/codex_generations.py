

# Generated at 2022-06-24 22:08:56.119838
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware_obj = HurdHardware()
    HurdHardware_obj.populate()



# Generated at 2022-06-24 22:09:00.425655
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '%s-%s'
    hurd_hardware_collector_0 = HurdHardwareCollector(str_0)
    hurd_hardware_0 = HurdHardware(hurd_hardware_collector_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:04.887923
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '%s-%s'
    hurd_hardware_collector_0 = HurdHardwareCollector(str_0)
    hurd_hardware_0 = HurdHardware(hurd_hardware_collector_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:12.679016
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '%s-%s'
    hurd_hardware_collector_0 = HurdHardwareCollector(str_0)
    str_1 = '%s-%s'
    hurd_hardware_collector_1 = HurdHardwareCollector(str_1)
    str_2 = hurd_hardware_collector_1.collect()
    str_3 = hurd_hardware_collector_0.collect()
    str_4 = 'HurdHardware'
    str_5 = hurd_hardware_collector_0.get_fact_class()
    str_6 = 'LinuxHardware'
    str_7 = hurd_hardware_collector_1.get_fact_class()
    str_8 = 'HurdHardware'
    str_9 = hurd_hardware_collector_0._fact_

# Generated at 2022-06-24 22:09:21.431763
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '%s-%s'
    hurd_hardware_collector_0 = HurdHardwareCollector(str_0)

    assert hurd_hardware_collector_0 != None
    assert len(hurd_hardware_collector_0.platforms) == 0
    assert hurd_hardware_collector_0.platforms == []

    hurd_hardware_collector_0.populate(str_0)

    assert hurd_hardware_collector_0 != None
    assert len(hurd_hardware_collector_0.platforms) == 1
    assert hurd_hardware_collector_0.platforms == ['GNU']

    hurd_hardware_collector_0.populate(str_0)

    assert hurd_hardware_collector_0 != None

# Generated at 2022-06-24 22:09:24.118781
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '%s-%s'
    hurd_hardware_collector_0 = HurdHardwareCollector(str_0)
    hurd_hardware_0 = hurd_hardware_collector_0.get_facts()
    assert hurd_hardware_0['uptime_seconds'] == 0


# Generated at 2022-06-24 22:09:26.243114
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:31.289432
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '%s-%s'
    hurd_hardware_collector_0 = HurdHardwareCollector(str_0)
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:32.150854
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:09:35.934243
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '%s-%s'
    hurd_hardware_collector_0 = HurdHardwareCollector(str_0)
    hurd_hardware_0 = HurdHardware(hurd_hardware_collector_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:49.313424
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:09:55.246286
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    collected_facts_0 = {}
    collected_facts_0 = None
    int_0 = hurd_hardware_0.populate(collected_facts_0)
    assert isinstance(int_0, dict)

# Generated at 2022-06-24 22:10:00.168052
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x03\x00\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)
    assert var_0 == {}



# Generated at 2022-06-24 22:10:09.669320
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xd8\xa4\xbc\xe2\x8f\xbc\x10\xc1\xd4\x8c\xab\x14\xd4\x86\x8c\xc3\x97\x11\x10\x8d\x15'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:12.869188
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:14.037531
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    record_0 = HurdHardware(b'')
    var_0 = record_0.populate()

# Generated at 2022-06-24 22:10:23.405464
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:26.935384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:29.951188
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        assert True
    except AssertionError:
        raise AssertionError('AssertionError raised')


# Generated at 2022-06-24 22:10:36.414556
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    hurd_hardware_0.populate()
    file_0 = open('/dev/null', 'r')
    hurd_hardware_0._get_uptime_facts(file_0)



# Generated at 2022-06-24 22:10:44.701551
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:50.799813
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_1 = b'\x0b\xaam\x8f\x91\x11o\xdf\x12\x1b\x0c\x1a\xe0\x8cP'
    hurd_hardware_1 = HurdHardware(bytes_1)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:10:58.750042
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

    bytes_1 = b'\x97\xe9\xac@\xc3\xfc\xad\x8d\xed\x97\xabQ\x14\xb4\x0f4'
    hurd_hardware_1 = HurdHardware(bytes_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1 == {}


# Generated at 2022-06-24 22:11:03.311846
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:07.647809
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_1 = b'\x1b\x92\xd4\xbb\xf8\xb47\xbf\x1d\x8c\x04\x94\xa7=\x08\xc9\xfb'
    hurd_hardware_1 = HurdHardware(bytes_1)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:11:11.675281
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:19.282630
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x94'
    bytes_1 = b'\x81\xf2\xad\xf5\xcf\x9e\xc5\xe1\xed\xf7\xde'

# Generated at 2022-06-24 22:11:26.654592
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Setup test case
    bytes_0 = b'\xa2\x84\xce\xb7\x0c\xadn\xbd\x18\xb8\xa4\xbf\xdd\xea\x9c\xabu'
    hurd_hardware_0 = HurdHardware(bytes_0)

    # Unit test body
    var_0 = hurd_hardware_0.populate()

    # Teardown test case
    # noinspection PyUnusedLocal
    del bytes_0
    # noinspection PyUnusedLocal
    del hurd_hardware_0
    # noinspection PyUnusedLocal
    del var_0

# Generated at 2022-06-24 22:11:37.363855
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:11:46.541393
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['memory']['swap']['total'] == 0
    assert var_0['memory']['swap']['used'] == 0
    assert var_0['memory']['swap']['free'] == 0
    assert var_0['memory']['swap']['cached'] == 0
    assert var_0['memory']['swap']['avail'] == 0
    assert var_0['memory']['real']['total'] == 0

# Generated at 2022-06-24 22:11:59.095515
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_1 = b'\x16N\x14\xa6\xfd\xa9\x9e\x93\xe1\xde\x8d\x8e\x17\xf7\xa3\xaf\x8c\xd3\xdd\xdc\x8f\x99\xbe\x0b'
    hurd_hardware_1 = HurdHardware(bytes_1)
    bytes_2 = b'\x1b\x1b\x19\x8b\x92\x80\x1b\x1b\xfd\xfc'
    var_1 = hurd_hardware_1.populate(bytes_2)


# Generated at 2022-06-24 22:12:03.971404
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'ws=\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:12.248932
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x1dl\x10\x05\x01\x00\x1e\xd7\x0f\x1d\x80\xa9\x0e\x1f\x05\x0e\x1c'
    bytes_1 = b'\x9f\xeb\xe6\x87\xd8\x80\xa0'
    bytes_2 = b'\xb2\xbe\x0f\x1c\x0e\x1f\x1d\x1e\x1f\x0e\x1d\x1e\x1f\x0e\x1d\x1e'

# Generated at 2022-06-24 22:12:23.206201
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0.keys() == {'hw_filesystems', 'hw_memtotal_mb', 'hw_uptime_seconds'}
    assert var_0['hw_filesystems'] == ['ext2', 'procfs', 'tmpfs', 'ufs', 'devfs']
    assert var_0['hw_memtotal_mb'] == 0
    assert var_0['hw_uptime_seconds'] == 92574

# Generated at 2022-06-24 22:12:23.969494
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True

# Generated at 2022-06-24 22:12:33.639005
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_1 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_1 = HurdHardware(bytes_1)
    var_1 = hurd_hardware_1.populate()
    total_memory = var_1.get('ansible_memtotal_mb')
    assert total_memory == 2046
    var_2 = hurd_hardware_1.populate()
    total_memory = var_2.get('ansible_memtotal_mb')
    total_swap = var_2.get('ansible_swaptotal_mb')
    assert total_memory == 2046
    assert total_swap == 1269
    test_case_0()

# Generated at 2022-06-24 22:12:40.759585
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xb2\x80\xa8\x83\xa3\xd3\xf7\x8a\x08\x97\x1c\x9f\x90\xa7\xec\x0f0\xb8\xef\x91\xea,\x9d'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:46.165635
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = (var_0 is not None and 'ansible_uptime_seconds' in var_0)
    assert var_1


# Generated at 2022-06-24 22:12:56.396977
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x0c\xcc\xba\xf5\xe2\xa0\x14\xc30\x94\xeb\x01\xed\x82\xac\x8aK\x9c'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert not var_0
    bytes_1 = b'\x0c\xcc\xba\xf5\xe2\xa0\x14\xc30\x94\xeb\x01\xed\x82\xac\x8aK\x9c'
    hurd_hardware_0 = HurdHardware(bytes_1)
    var_0 = hurd_hardware_0.populate()
    assert not var

# Generated at 2022-06-24 22:13:03.851236
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:13:15.688141
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    bytes_0 = b'M\x00\x00\x00\x00\x00\x00\'\x00\x00\x00\x0e\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:20.446787
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import ctypes

# Generated at 2022-06-24 22:13:29.636100
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'(\x08\x15\x04\x01'
    bytes_1 = b'\x96\x14\xd3\x1a\xa8)'
    bytes_2 = b'\x80\xa8\x8d\x15\x03'
    bytes_3 = b'\x95\x12\xd4\x1c\xab'
    bytes_4 = b'\xb2\xca\x99A'
    bytes_5 = b'\xbe>|\xcc'
    hurd_hardware_0 = HurdHardware(bytes_0, bytes_1, bytes_2, bytes_3, bytes_4, bytes_5)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:34.075933
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    collected_facts_0 = {}
    var_0 = hurd_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:13:36.781215
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:43.915964
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:13:48.334103
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b' \x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:53.265088
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:56.990144
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:01.071261
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:09.123084
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:13.243698
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:18.168002
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:14:28.633738
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(bytes_0)
    bytes_0 = b''
    hurd_hardware_0.set_sysfs_cpu_path(bytes_0)
    collected_facts_0 = None
    var_0 = hurd_hardware_0.populate(collected_facts_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:32.760468
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b"\xa3\x8d\x93\x1b\x9d\x8c\x93\x1b\x97"
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:33.979670
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:14:39.142758
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x8b\x06\xde\x1dK\x04\xda\x89@\x1aKg\x94'
    hurd_hardware_1 = HurdHardware(bytes_0)
    var_1 = hurd_hardware_1.populate()
    assert 'memory' in var_1


# Generated at 2022-06-24 22:14:46.823552
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xec\xdb\x1b\xd6\x9d\x08\x96\xec\xde\x16\x0c\xb1\x19H\x9d\x06\x14\xce'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-24 22:14:52.354432
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x8d\x1b\x1b\x9b-\x8cC\xfd\x17\xa2\x16d\xad)\xceu\xbf\x1a'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:01.768815
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.populate()
    assert var_1['swapfree_mb'] == var_0['swapfree_mb']
    assert var_1['swappart'] == var_0['swappart']
    assert var_1['uptime'] == var_0['uptime']
    assert var_1['swaptotal_mb'] == var_0['swaptotal_mb']
    assert var_1['memtotal_mb'] == var_0['memtotal_mb']
    assert var_

# Generated at 2022-06-24 22:15:11.664890
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:15:15.767331
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b"'J\x93\x80\xf9D\x04>\x8bK\x86\xd7"
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:20.696532
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:27.246646
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x12\x89!\x07\x9d\xd1?\xed\x8c\x03\xfa\xda\xec\x8c\x0c'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:32.576872
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x95\x86\xee\xe0\xf3\r\x1c\x14\xfb\xd8\t\xfd\xab\xe7\xce'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:42.614641
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xe7\x0f\x00\xa8\x97\xa7\xb4\xe1\xa6\x1b\x9b\x9d\xba\xa6\x0f\xaf\x83\x1b\x9a\xa4\x1d\xab\x9a\xb4\xe1\xa1\x1b\x9b\x9d\xba\xab\x9b\x9d\xb1'
    hurd_hardware_0 = HurdHardware(bytes_0)
    assert isinstance(hurd_hardware_0, HurdHardware)
    var_0 = hurd_hardware_0.populate()
    assert int(var_0.get('memtotal_mb')) == 2120


# Generated at 2022-06-24 22:15:46.744093
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x1b\x8a\xaa\xba\xba\x14\xd4\xa9)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:51.521147
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = u'machine'
    assert var_1 in var_0


# Generated at 2022-06-24 22:15:56.839400
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:01.658400
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # FIXME: What's the type of these parameters?
    bytes_1 = ''.encode('utf-8')
    hurd_hardware_1 = HurdHardware(bytes_1)
    # FIXME: Specify real parameters instead of None
    var_1 = hurd_hardware_1.uptime_facts(None)
    # FIXME: Specify real parameters instead of None
    var_2 = hurd_hardware_1.mount_facts(None)
    # FIXME: Specify real parameters instead of None
    var_3 = hurd_hardware_1.memory_facts(None)

# Generated at 2022-06-24 22:16:10.166304
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:17.554608
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert 'uptime' in var_0
    assert 'mounts' in var_0
    assert 'swap' in var_0
    assert 'memtotal_mb' in var_0


# Generated at 2022-06-24 22:16:20.250901
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xa9\x85\xa2\xfd\x01\xea^\x00\x12\xf4\x04\xb5l'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:25.522507
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    collected_facts_0 = None
    var_0 = hurd_hardware_0.populate(collected_facts_0)



# Generated at 2022-06-24 22:16:30.895517
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime': 0.0, 'memory': {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}, 'mounts': []}


# Generated at 2022-06-24 22:16:34.304329
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:16:38.551118
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'v|\x1a\x86\x86\x96\xee\x8a\xbe\xe1\xa1'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:41.587190
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert var_0 == {
        'uptime': '0:00:00:00.00',
        'mem_total': 0,
        'mem_swap_total': 0,
        'mounts': []
    }

# Generated at 2022-06-24 22:16:45.308508
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:16:49.135751
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:17:00.332560
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'#\x89\xda\x93\x8c4\xabi\x14d\xad),_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:17:05.051728
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:13.558022
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
  bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
  hurd_hardware_0 = HurdHardware(bytes_0)
  var_27 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:19.161174
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_1 = b'\x14z\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    hurd_hardware_1 = HurdHardware(bytes_1)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:17:23.773371
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:31.073199
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xecP\x7f]8\x92\r\xe1\xac\xab\x88\xbc\xd4'
    bytes_1 = b'\xecP\x7f]8\x92\r\xe1\xac\xab\x88\xbc\xd4'
    bytes_2 = b'\xecP\x7f]8\x92\r\xe1\xac\xab\x88\xbc\xd4'
    bytes_3 = b'\xecP\x7f]8\x92\r\xe1\xac\xab\x88\xbc\xd4'

# Generated at 2022-06-24 22:17:34.868531
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:37.726587
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_1 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:42.784860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    assert type(hurd_hardware_0.populate()) == type(dict())


# Generated at 2022-06-24 22:17:49.268570
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    global bytes_0
    global hurd_hardware_0
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    print(var_0)

if __name__ == "__main__":
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:18:08.084748
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x1e\x90\x02\xf4\t\xce\xb0\xfb\xcb\x95\xafX\x8ct\x95\xeb\xf7\x03\xcf\x17'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:12.215513
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:18:15.369133
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = bytes.fromhex('333536313738333930363537')
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    # AssertionError: <value>, != {'inactive': <value>, 'available': <value>, 'active': <value>, 'free': <value>, 'wired': <value>}


# Generated at 2022-06-24 22:18:17.982770
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:22.763259
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x15\x17\xcb\xa5A\x06\xa9\xe6\xbf\xe5\x0c\x05\x60\xc9\x9d\x0e\x1b'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:26.885988
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_1 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:18:27.734974
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True == True

# Generated at 2022-06-24 22:18:31.294223
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:18:32.945998
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print(test_case_0())

test_HurdHardware_populate()

# Generated at 2022-06-24 22:18:35.952662
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 'q{\x1a\x93\x8c4\xabi\x14d\xad)4_\xfb'.populate() == 'f'