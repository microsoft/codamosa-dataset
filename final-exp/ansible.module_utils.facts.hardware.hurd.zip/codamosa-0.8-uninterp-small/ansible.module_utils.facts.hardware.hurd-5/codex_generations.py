

# Generated at 2022-06-24 22:08:58.268893
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    x = HurdHardware()
    assert x.populate()


# Generated at 2022-06-24 22:09:00.309434
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    test_case_0()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:05.041838
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    linux_hardware_collector_0 = LinuxHardwareCollector()

    linux_hardware_collector_0._platform
    linux_hardware_collector_0._collector_class._fact_class

    linux_hardware_collector_0._platform = 'Linux'
    linux_hardware_collector_0._get_platform
    linux_hardware_collector_0._get_collector_class
    linux_hardware_collector_0.get_facts



# Generated at 2022-06-24 22:09:07.255335
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}
    hurd_hardware.populate(collected_facts)


# Generated at 2022-06-24 22:09:08.631110
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-24 22:09:17.581655
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Default parameters
    hostname = 'localhost'
    platform_type = 'Linux'
    os_distribution = 'GNU'
    os_version = '4.2.4-gnumach'

# Generated at 2022-06-24 22:09:20.969402
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts_0 = {}
    assert (hurd_hardware_0.populate(collected_facts_0) == {'memory': {}})
    assert (collected_facts_0 == {})



# Generated at 2022-06-24 22:09:23.990259
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = {}
    collected_facts.update({'kernel': 'GNU', 'os_family': 'Debian'})
    hurd_hardware_0.populate(collected_facts)

# Generated at 2022-06-24 22:09:26.562397
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    ret = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:37.511599
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print("Testing method populate of class HurdHardware ...")
    hurd_hardware_0 = HurdHardware()
    collected_facts_0 = {
        'distribution': 'GNU',
        'distribution_version': 'Hurd 0.5'
    }
    hurd_hardware_0.collected_facts = collected_facts_0
    hurd_hardware_0.get_uptime_facts = lambda : {'uptime_seconds': 5}
    hurd_hardware_0.get_memory_facts = lambda : {'memtotal_mb': 10}
    hurd_hardware_0.get_mount_facts = lambda : {'mounts': [
        {'size_total': 1000, 'fstype': 'ext4', 'size_available': 999}
    ]}
    assert hurd_hardware_0.pop

# Generated at 2022-06-24 22:09:49.833239
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    collected_facts_0 = dict()
    collected_facts_0['ansible_system'] = 'GNU'
    # Collect the following facts: uptime, mount, memory
    hurd_hardware_collector_0 = HurdHardwareCollector()

    # The following facts are mocked: uptime, memory
    hurd_hardware_collector_0.populate()
    assert collected_facts_0['ansible_uptime_seconds'] == 3019
    assert collected_facts_0['ansible_uptime_timetuple'].tm_year == 1970
    assert collected_facts_0['ansible_uptime_timetuple'].tm_mon == 1
    assert collected_facts_0['ansible_uptime_timetuple'].tm_mday == 1

# Generated at 2022-06-24 22:09:58.128750
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.get_mount_facts = MagicMock()
    hurd_hardware_0.populate(**{u'collected_facts': 'collected_facts'})
    assert not hurd_hardware_0.get_mount_facts.called
    hurd_hardware_0.get_mount_facts = MagicMock()
    hurd_hardware_0.populate(**{u'collected_facts': 'collected_facts'})
    assert not hurd_hardware_0.get_mount_facts.called
    hurd_hardware_0.get_mount_facts = MagicMock()
    hurd_hardware_0.get_mount_facts.side_effect = TimeoutError('TimeoutError message')
    hurd_hardware_0.populate

# Generated at 2022-06-24 22:10:08.938729
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    result = hurd_hardware_0.populate()
    assert result.get('uptime_seconds') >= 0
    assert result.get('uptime_seconds') <= 1
    assert result.get('uptime_days') >= 0
    assert result.get('uptime_days') <= 1
    assert result.get('uptime_hours') >= 0
    assert result.get('uptime_hours') <= 24
    assert result.get('uptime_minutes') >= 0
    assert result.get('uptime_minutes') <= 60
    assert result.get('uptime_seconds') >= 0
    assert result.get('uptime_seconds') <= 1
    assert result.get('memory_mb') >= 0
    assert result.get('memory_mb') <= 1

# Generated at 2022-06-24 22:10:10.556714
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()



# Generated at 2022-06-24 22:10:14.568417
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    results = hurd_hardware.populate()
    assert results["processor_0"] == "0"
    assert results["processor_count"] == 1

# Generated at 2022-06-24 22:10:21.342096
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_instance = HurdHardware()
    hurd_instance.uptime = {'seconds': 53325, 'hours': 14, 'days': 1, 'minutes': 32}
    hurd_uptime_facts = {'uptime_seconds': 53325, 'uptime_hours': 14, 'uptime_days': 1, 'uptime_minutes': 32}
    # Call populate with two known values to test for expected output
    hurd_hardware_facts = hurd_instance.populate()

    assert hurd_hardware_facts == hurd_uptime_facts

# Generated at 2022-06-24 22:10:28.617749
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collect_subset = ['all']
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_facts = hurd_hardware_obj.populate(['all'])
    expected_facts = {
        'uptime': {
            'days': 7,
            'hours': 3,
            'total_seconds': 618327,
            'seconds': 527
        },
        'memfree_mb': 0,
        'swapfree_mb': 0,
        'memtotal_mb': 0
    }
    for fact in list(expected_facts.keys()):
        assert fact in list(hurd_hardware_facts.keys())

# Generated at 2022-06-24 22:10:30.321461
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:36.018216
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    host_facts = {}
    host_facts["ansible_facts"] = {}

    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()
    host_facts["ansible_facts"].update({"hardware" : hurd_hardware_0.get_facts()})

    assert host_facts["ansible_facts"]["hardware"] != None


# Generated at 2022-06-24 22:10:40.390586
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    class Facts:
        pass

    facts = Facts()
    facts.ansible_system = 'GNU'
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:47.389404
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_collected_facts = hurd_hardware_obj.populate()
    assert isinstance(hurd_hardware_collected_facts, dict)
    assert "dummy_fact" in hurd_hardware_collected_facts
    assert isinstance(hurd_hardware_collected_facts["dummy_fact"], str)
    assert "dummy_fact" == hurd_hardware_collected_facts["dummy_fact"]
    assert "uptime" in hurd_hardware_collected_facts
    assert isinstance(hurd_hardware_collected_facts["uptime"], dict)
    assert "days" in hurd_hardware_collected_facts["uptime"]

# Generated at 2022-06-24 22:10:49.360859
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:51.466887
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:53.732897
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:56.333036
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate = hurd_hardware.populate()

# Generated at 2022-06-24 22:10:58.156739
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:59.188414
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # No test implemented yet
    pass

# Generated at 2022-06-24 22:11:03.014708
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test case 1
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:11:05.616439
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj_0 = HurdHardwareCollector.fetch_fact()
    hurd_hardware_obj_0.populate()

# Generated at 2022-06-24 22:11:14.603492
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware_class = HurdHardware(hurd_hardware_collector)
    collected_facts = {}
    

# Generated at 2022-06-24 22:11:18.615194
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:26.971817
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_1 = HurdHardware('localhost')
    var_0 = hurd_hardware_1.populate()
    assert var_0 != None and isinstance(var_0, dict)
    assert 'uptime' in var_0 and isinstance(var_0['uptime'], dict)
    assert 'hours' in var_0['uptime'] and isinstance(var_0['uptime']['hours'], int)
    assert 'days' in var_0['uptime'] and isinstance(var_0['uptime']['days'], int)
    assert 'minutes' in var_0['uptime'] and isinstance(var_0['uptime']['minutes'], int) and var_0['uptime']['minutes'] >= 0

# Generated at 2022-06-24 22:11:29.019144
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:32.997357
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware('localhost')
    var_1 = str('localhost')
    var_2 = var_0.populate(var_1)
    var_3 = var_0.populate()


# Generated at 2022-06-24 22:11:37.290886
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == None

###############################################################################
#
# Unit tests for class HurdHardwareCollector
#
###############################################################################


# Generated at 2022-06-24 22:11:38.227236
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:11:45.147113
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    lx_hw_0 = HurdHardware('localhost')
    result = lx_hw_0.populate()
    assert isinstance(result, dict)
    assert 'uptime' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'mounts' in result


# Generated at 2022-06-24 22:11:47.451912
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:55.160143
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'localhost'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    value_0 = var_1['ansible_mounts']
    assert len(value_0) > 0
    value_1 = var_1['ansible_memtotal_mb']
    assert value_1 > 0
    value_2 = var_1['ansible_uptime_seconds']
    assert value_2 > 0


# Generated at 2022-06-24 22:11:58.797917
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:12:05.214050
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:12:09.099516
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:12:12.277456
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None


# Generated at 2022-06-24 22:12:16.090024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Unit test case for class HurdHardwareCollector

# Generated at 2022-06-24 22:12:19.219353
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:20.122805
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:22.221420
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    return var_0


# Generated at 2022-06-24 22:12:25.769214
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:27.645431
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Testing populate')
    test_case_0()

# Generated at 2022-06-24 22:12:31.600784
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()



# Generated at 2022-06-24 22:12:41.911569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert(isinstance(test_case_0(), dict))

# Generated at 2022-06-24 22:12:44.294694
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0(HurdHardware, HurdHardwareCollector)

# Generated at 2022-06-24 22:12:48.557540
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'hostname'
    hurd_hardware_0 = HurdHardware(str_0)
    assert hurd_hardware_0.populate() is None


# Generated at 2022-06-24 22:12:50.791422
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    var_0

# Generated at 2022-06-24 22:12:54.702555
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    var_0 = hurd_hardware_0.populate()
    var_0 = hurd_hardware_0.populate()
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:55.810036
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    _UnitTestCase_0 = test_case_0()


# Generated at 2022-06-24 22:12:57.633478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:58.572827
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert test_case_0() is None



# Generated at 2022-06-24 22:13:02.557821
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:06.354328
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

    assert True


# Generated at 2022-06-24 22:13:27.729880
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:29.979279
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:33.506329
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    # Test if type of value returned by method populate of class HurdHardware is dict
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 22:13:34.625019
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:13:38.810071
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None
    assert 'ansible_uptime' in var_0

# Generated at 2022-06-24 22:13:39.935628
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:13:43.118100
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:46.280656
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:52.496221
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)

    map_0 = {}
    map_1 = hurd_hardware_0.get_uptime_facts()
    map_2 = hurd_hardware_0.get_memory_facts()
    map_3 = {}
    map_0 = dict(map_1.items() + map_2.items())
    try:
        map_4 = hurd_hardware_0.get_mount_facts()
        map_3 = dict(map_0.items() + map_4.items())
    except TimeoutError:
        pass

    assert map_3 == {}

# Generated at 2022-06-24 22:13:54.340191
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:14.467939
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:17.220683
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:19.044779
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:22.154296
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'localhost'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:14:25.917209
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:14:29.269522
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:33.146607
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:14:40.436150
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:14:42.865030
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:44.844526
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    t_0 = HurdHardware('localhost')
    t_0.populate()

# Generated at 2022-06-24 22:15:10.284561
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not False
    assert var_0 is not True
    assert var_0 is not None
    assert type(var_0) == dict


# Generated at 2022-06-24 22:15:16.762722
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware('localhost')
    assert hurd_hardware.populate() == {
        'uptime_seconds': 535198,
        'uptime_hours': 149,
        'uptime_days': 6,
        'date_time': '2018-03-02T07:59:29Z',
        'memfree_mb': 1121,
        'memtotal_mb': 1513,
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
    }

# Generated at 2022-06-24 22:15:19.674665
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:21.713411
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:26.423384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    # Test the different branches of the code
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:27.376503
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:15:29.906416
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:32.894024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = 'localhost'
    hurd_hardware_1 = HurdHardware(var_1)
    var_1 = hurd_hardware_1.populate()

# Generated at 2022-06-24 22:15:38.627541
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'mounts': {}, 'uptime_seconds': 501, 'uptime_hours': 0, 'uptime_days': 0}, "Unexpected result value for method HurdHardware.populate"


# Generated at 2022-06-24 22:15:44.073899
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    print_0 = 'Failed to get mount facts due to TimeoutError'
    try:
        hurd_hardware_0.get_mount_facts()
    except TimeoutError:
        print(print_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:28.467539
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert 'uptime_seconds' in var_0
    assert 'uptime' in var_0

# Generated at 2022-06-24 22:16:30.388121
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:32.523342
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'localhost'
    hurd_hardware_1 = HurdHardware(str_1)
    var_0 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:16:34.021165
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:36.601236
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:39.232160
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:16:47.934526
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    hurd_hardware_1 = HurdHardware('localhost')
    var_1 = hurd_hardware_1.populate()
    var_1.fetchall()
    hurd_hardware_0 = HurdHardware('localhost')
    var_0 = hurd_hardware_0.populate()
    var_0.fetchone()
    hurd_hardware_1 = HurdHardware('localhost')
    var_1 = hurd_hardware_1.populate()
    var_1.fetchone()
    hurd_hardware_0 = HurdHardware('localhost')
    var_0 = hurd_hardware_0.populate()
    var_

# Generated at 2022-06-24 22:16:57.583547
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_2 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_2)
    var_0 = hurd_hardware_0.populate()
    str_0 = 'null'
    str_1 = '['
    int_0 = 0
    str_3 = ']'

# Generated at 2022-06-24 22:16:59.714667
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:05.453677
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = 'ansible_facts'
    var_2 = 'hardware'
    var_3 = 'uptime_seconds'
    var_4 = 'ansible_uptime_seconds'
    var_5 = 'ansible_memtotal_mb'
    assert ((var_1 in var_0) and (var_2 in var_0[var_1]) and (var_3 in var_0[var_1][var_2])),\
        "Expected %s in var_0[var_1][var_2]" % var_3

# Generated at 2022-06-24 22:18:30.663100
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:18:31.481025
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:18:35.570705
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

    assert var_0 is not None


# Generated at 2022-06-24 22:18:37.839478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:40.697656
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


if __name__ == '__main__':
    # test_HurdHardware_populate()
    pass

# Generated at 2022-06-24 22:18:47.007943
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert hurd_hardware_0.up == 0.0
    assert hurd_hardware_0.memfree_mb == 0.0
    assert hurd_hardware_0.mounts['/'] == {'uuid': '0f9789a9-c175-47f0-8916-7105e1e1f8cf', 'fstype': 'ext2fs', 'device': '/dev/disk/discs/disc0/part0', 'mount': '/'}
    assert hurd_hardware_0.memtotal_mb == 0.0
    assert hurd_hardware_0.type == 'GNU'
    assert hurd_hardware_0.memavailable_mb == 0.0

test_case_0()

# Generated at 2022-06-24 22:18:49.207587
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'localhost'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:57.763384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    tmp_file_path_0 = '/proc/uptime'
    fh = open(tmp_file_path_0, 'r')
    lines = fh.readlines()
    fh.close()

    if lines:
        tmp_file_path_1 = '/proc/meminfo'
        fh = open(tmp_file_path_1, 'r')
        lines = fh.readlines()
        fh.close()

        if lines:
            str_0 = 'localhost'
            hurd_hardware_0 = HurdHardware(str_0)
            var_0 = hurd_hardware_0.populate()
        else:
            raise Exception("Unable to get contents of %s" % tmp_file_path_1)