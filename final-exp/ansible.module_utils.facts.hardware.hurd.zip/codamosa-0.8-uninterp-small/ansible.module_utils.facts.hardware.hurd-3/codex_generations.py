

# Generated at 2022-06-24 22:08:58.943278
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Ensure that we return the proper dictionary when calling
    # the `populate` method of HurdHardware

    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-24 22:09:02.641872
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0 = hurd_hardware_collector_0.collect()
    assert hurd_hardware_0.populate() == {'uptime': 0, 'memfree': 0, 'mounts': {}, 'memtotal': 0}

# Generated at 2022-06-24 22:09:11.220288
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a test object of class HurdHardware
    test_obj = HurdHardware()

    # Test case with expected results
    # Test memory and mount translation
    collected_facts = {'system_memory': {'real': {'total_mb': 1000}},
                       'system_mount': {'real': [{'device': '/dev/sda1',
                                                  'mount': '/',
                                                  'size_total': 1000},
                                                 {'device': '/dev/sda1',
                                                  'mount': '/home',
                                                  'size_total': 1000}]}}


# Generated at 2022-06-24 22:09:15.167804
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware(
        module=None,
        collected_facts={'_ansible_procfs_path': '/proc'})
    hurd_hardware_populate = hurd_hardware.populate()
    print("hurd_hardware_populate: ", hurd_hardware_populate)



# Generated at 2022-06-24 22:09:23.490818
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:09:33.860685
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_facts = hurd_hardware_0.populate()
    assert isinstance(hurd_hardware_facts, dict)
    assert 'uptime' in hurd_hardware_facts
    assert 'mounts' in hurd_hardware_facts
    assert 'mem_swap_free' in hurd_hardware_facts
    assert 'mem_swap_total' in hurd_hardware_facts
    assert 'mem_ram_total' in hurd_hardware_facts
    assert 'mem_swap_used' in hurd_hardware_facts
    assert 'mem_ram_used' in hurd_hardware_facts
    assert 'mem_ram_free' in hurd_hardware_facts


# Generated at 2022-06-24 22:09:36.108538
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:36.698149
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:09:45.454426
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initialize arguments used for testing this method
    collected_facts = {u'a': u'b'}

    # Set up mock attributes and method return values
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.uptime_facts = {u'a': u'b'}
    hurd_hardware_0.memory_facts = {u'c': u'd'}
    hurd_hardware_0.mount_facts = {u'e': u'f'}
    hurd_hardware_0.uptime_facts = {u'a': u'b'}

    # Call method
    result = hurd_hardware_0.populate(collected_facts)

    # Check for idempotency

# Generated at 2022-06-24 22:09:50.291789
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_object_0 = HurdHardware(uptime_facts=None)
    hurd_hardware_object_0.populate(collected_facts=None)


# Generated at 2022-06-24 22:10:02.155167
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Creation of fake class to simulate a Linux system
    class args_0(object):
        def __init__(self):
            self.timeout = 42

    class HurdHardware_0(HurdHardware):
        def __init__(self, args_):
            super(HurdHardware_0, self).__init__(args_)
            self.populate_with = list()

        def get_uptime_facts(self):
            self.populate_with.append('uptime')
            return {'uptime': 0}

        def get_memory_facts(self):
            self.populate_with.append('memory')
            return {'memory': 1}

        def get_mount_facts(self):
            self.populate_with.append('mount')
            return {'mount': 2}

    # creation of instance

# Generated at 2022-06-24 22:10:03.706416
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware('linux1')
    obj.populate()

# Generated at 2022-06-24 22:10:09.546468
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'A\nB\nC\nD\n'
    str_2 = 'A\n:B:C:D:\n'
    hurd_hardware_1 = HurdHardware(str_1)
    hurd_hardware_1.populate()
    hurd_hardware_2 = HurdHardware(str_2)
    hurd_hardware_2.populate()


# Generated at 2022-06-24 22:10:12.508823
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:22.867443
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

    assert type(var_0) == dict
    assert 'uptime' in var_0
    assert type(var_0['uptime']) == str
    assert 'uptime_seconds' in var_0
    assert type(var_0['uptime_seconds']) == int
    assert 'uptime_days' in var_0
    assert type(var_0['uptime_days']) == int
    assert 'memtotal' in var_0
    assert type(var_0['memtotal']) == int
    assert 'memfree' in var_0

# Generated at 2022-06-24 22:10:28.618566
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {u'memory_mb': {u'free': 3, u'swapfree': 0, u'swaptotal': 0, u'swapcached': 0, u'cached': 158, u'buffered': 10, u'active': 28, u'inactive': 27}, u'mounts': {u'/': u'/dev/hd0s1'}}


# Generated at 2022-06-24 22:10:30.938089
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '@m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:34.436224
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:38.233728
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = '_Y0S/~fv0aJ{Wp'
    hurd_hardware_1 = HurdHardware(str_1)
    assert hurd_hardware_1.populate() == {}

# Generated at 2022-06-24 22:10:42.842938
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:56.797194
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Test with pypy
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:00.197187
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:03.840522
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:13.537193
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
        collected_facts = {}


# Generated at 2022-06-24 22:11:18.023869
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'G X J:.g8!#W'
    try:
        var_42 = HurdHardware(str_0)
        var_0 = var_42.populate()
    except TimeoutError as exception_0:
        exception_0.message


# Generated at 2022-06-24 22:11:22.739765
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    arg_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(arg_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:25.744791
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:33.336685
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    str_1 = '_$4#3nX~'
    str_2 = '!5W5;8zPwi$}5w'
    str_3 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_2)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:34.700160
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Unit test for method populate of class HurdHardware FactCollector')


# Generated at 2022-06-24 22:11:38.489290
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'oMx%*]4qA3=BL$/hv>sW|;8P'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:11:45.393165
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:11:48.730634
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an object of the LinuxHardware class with the specified value
    hurd_hardware_0 = HurdHardware('string')

    # Populate the attribute of the object
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:49.862718
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:11:53.911691
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'GuRbIPg,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:00.430914
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime']['seconds'] == 0
    assert var_0['uptime']['hours'] == 0
    assert var_0['uptime']['days'] == 0

# Generated at 2022-06-24 22:12:05.124002
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_a = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_a = HurdHardware(str_a)
    var_a = hurd_hardware_a.populate()
    assert var_a == 'GNU'


# Generated at 2022-06-24 22:12:15.993828
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = '{;\'A\"/(y@*b=?S'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    str_2 = '"Zz!Rka#l|T)T`\'$'
    hurd_hardware_2 = HurdHardware(str_2)
    var_2 = hurd_hardware_2.populate()
    str_3 = 'qH@&a.w~)e.Z_J|C'

# Generated at 2022-06-24 22:12:18.778715
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test for method 'populate' of class HurdHardware"""
    # In HurdHardware class, method populate is not implemented

# Generated at 2022-06-24 22:12:19.398572
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:12:22.822413
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:40.367594
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    # AssertionError: ('Unexpected memory_facts: %s' % (memory_facts), {'swapfree_mb': 4, 'memtotal_mb': 0, 'swaptotal_mb': 4, 'memfree_mb': 0, 'high_total': 0, 'low_free': 0, 'high_free': 0, 'low_total': 0, 'cached': 0, 'cached_percent': 0, 'swapcached': 0})
    # AssertionError: ('Unexpected mount_facts: %s' % (mount_facts), {})
    # AssertionError:

# Generated at 2022-06-24 22:12:44.421378
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:49.870992
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '*C_MMgMdG,Z\tM\\oQ^+gf\\K'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:53.194792
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert type(var_0) == dict


# Generated at 2022-06-24 22:12:55.692035
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:00.044560
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate(str_0)


# Generated at 2022-06-24 22:13:07.129891
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Test that methods populate and get_memory_facts are working as expected')

    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert 'memory_mb' in var_0
    assert 'hw_memfree_mb' in var_0
    assert 'hw_swapfree_mb' in var_0
    assert 'swaptotal_mb' in var_0
    assert 'memory_kb' in var_0
    assert 'hw_memfree_kb' in var_0
    assert 'memtotal_mb' in var_0
    assert 'memtotal_kb' in var_0
    assert 'swaptotal_kb' in var_0

# Generated at 2022-06-24 22:13:08.603001
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 1 == 1
    # self.assertEqual(1, 1)

# Generated at 2022-06-24 22:13:12.729024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:16.711386
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:35.195450
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert var_0 is not None

# Generated at 2022-06-24 22:13:43.482176
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'aM-b,j\t;C*s\\&'
    hurd_hardware_2 = HurdHardware(str_1)
    hurd_hardware_2.populate()
    # Tests if function has returned a dictionary
    assert type(hurd_hardware_2.populate()) is dict
    # Tests if returned dictionary contains certain keys
    # assert 'mounts' in hurd_hardware_2.populate()
    assert 'ram' in hurd_hardware_2.populate()
    assert 'uptime' in hurd_hardware_2.populate()
    assert 'uptime_seconds' in hurd_hardware_2.populate()

# Generated at 2022-06-24 22:13:46.379592
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:47.690802
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass



# Generated at 2022-06-24 22:13:52.792156
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Test method populate of class HurdHardware.')
    # Run the test
    test_case_0()

if __name__ == '__main__':
    # Run the tests
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:13:55.766277
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_1 = HurdHardware(str_1)

    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:14:00.026054
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    print(var_0)
    print(len(var_0))


# Generated at 2022-06-24 22:14:03.858693
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:14:06.864467
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except (TypeError, ValueError) as error:
        print(error)
        assert False

test_HurdHardware_populate()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 22:14:10.773842
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:47.533061
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'u/7 V'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:48.462591
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:14:52.256443
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:14:53.945907
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware._platform == 'GNU'

# Generated at 2022-06-24 22:14:57.664581
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Unit tests for class HurdHardwareCollector

# Generated at 2022-06-24 22:15:01.450666
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'p0J0'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime'] > 0.0
    assert 'memtotal_mb' in var_0
    assert 'mounts' in var_0

# Generated at 2022-06-24 22:15:02.270815
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:15:04.960195
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:06.515521
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True


# Generated at 2022-06-24 22:15:10.160366
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:53.148840
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'J$f#,H\x02P\x16J)o\x0f\x1a'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:57.713506
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:58.256874
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:15:59.431542
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert isinstance(HurdHardware('').populate(), dict)

# Generated at 2022-06-24 22:16:09.408059
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    # Test method of class GNUHardware
    hurd_hardware_0.get_uptime_facts()
    # Test method of class GNUHardware
    hurd_hardware_0.get_memory_facts()
    # Test method of class GNUHardware
    hurd_hardware_0.get_mount_facts()
    # Test method of class GNUHardware
    hurd_hardware_0.get_commands_to_search()
    # Test method of class GNUHardware
    hurd_hardware_0.get_root_info(var_0)
    # Test method of class GNUHardware
    hurd_hardware

# Generated at 2022-06-24 22:16:13.541408
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:16.916134
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:20.067522
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    str_1 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()

    assert var_1 is not False


# Generated at 2022-06-24 22:16:29.521302
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    with mock.patch('ansible.module_utils.facts.hardware.hurd.HurdHardware.get_uptime_facts', autospec=True) as mock_uptime,\
         mock.patch('ansible.module_utils.facts.hardware.hurd.HurdHardware.get_memory_facts', autospec=True) as mock_memory,\
         mock.patch('ansible.module_utils.facts.hardware.hurd.HurdHardware.get_mount_facts', autospec=True) as mock_mount:
        str_1 = 'HmIo\x7f'
        str_2 = '\x0f\x01\x1f'
        str_3 = 'my\rX\x1c'

# Generated at 2022-06-24 22:16:30.362333
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert False



# Generated at 2022-06-24 22:17:16.570295
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # method populate of module ansible.module_utils.facts.hardware.hurd
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:19.938062
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()

# Generated at 2022-06-24 22:17:29.030676
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'b%fI@\n"=1C-L9.3Y$'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:34.200098
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = len(var_0)
    print(var_1)


# Generated at 2022-06-24 22:17:38.606505
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:17:42.685106
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:46.114705
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:49.351543
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:54.983770
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ''
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:17:57.934922
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1 == None


# Generated at 2022-06-24 22:18:40.772856
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:42.960409
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    with mock.patch.object(HurdHardware, 'populate', return_value='populate'):
        assert HurdHardware.populate() == 'populate'

# Generated at 2022-06-24 22:18:43.799397
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:18:46.886744
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:49.705158
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RP-B,m\t;T*q\\%Ms686l'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:18:58.249282
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'lGzf@!HBh*;e!'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()