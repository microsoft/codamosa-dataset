

# Generated at 2022-06-24 22:08:56.631742
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:08:59.121792
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:06.349217
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    platform = 'GNU'
    arch = 'x86_64'
    hurd_hardware_0 = HurdHardware(arch, platform)
    collected_facts = dict()

    def test_mock_module(module):
        module_ret = dict()
        return module_ret

    with patch.object(HurdHardware, 'get_uptime_facts') as mock_get_uptime_facts:
        with patch.object(HurdHardware, 'get_memory_facts') as mock_get_memory_facts:
            with patch.object(HurdHardware, 'get_mount_facts') as mock_get_mount_facts:
                mock_module = MagicMock()
                mock_module.params = dict()
                mock_module.params['gather_subset'] = 'all'
                mock_get_uptime_facts

# Generated at 2022-06-24 22:09:08.644848
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)

    # Testing
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:12.263809
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_1 = True
    hurd_hardware_1 = HurdHardware(bool_1)
    collected_facts_1 = {}
    var_arg_1 = collected_facts_1
    hurd_hardware_1.populate(var_arg_1)


# Generated at 2022-06-24 22:09:13.644267
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)



# Generated at 2022-06-24 22:09:22.799272
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    collected_facts_0 = None
    setattr(hurd_hardware_0, '_linux', None)
    setattr(hurd_hardware_0, '_populated', False)
    setattr(hurd_hardware_0, 'uptime_sec', 0)
    setattr(hurd_hardware_0, 'mem_info', 'hi')
    setattr(hurd_hardware_0, 'mem_facts', 0)
    setattr(hurd_hardware_0, '_mounts', set())
    setattr(hurd_hardware_0, '_mountinfo_path', ':')
    setattr(hurd_hardware_0, 'mount_facts', 0)
    #

# Generated at 2022-06-24 22:09:26.445242
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    assert hurd_hardware_0.populate() == {}

# Generated at 2022-06-24 22:09:37.513449
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_1 = True
    hurd_hardware_1 = HurdHardware(bool_1)
    collected_facts_1 = None

    # Call method of class HurdHardware
    result = hurd_hardware_1.populate(collected_facts_1)
    # Assert call (i.e. test) result
    assert result['memory_mb']['real']['total'] == float(768.0)
    assert result['processor_count'] == float(1.0)
    assert result['os_family'] == 'GNU/Hurd'
    assert result['architecture'] == 'powerpc'
    assert result['system']['product_name'] == 'QEMU Virtual Machine'
    assert result['system']['product_version'] == 'pc-i440fx-2.1'

# Generated at 2022-06-24 22:09:46.014315
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # case 1:
    bool_0 = False
    hurd_hardware_0 = HurdHardware(bool_0)

# Generated at 2022-06-24 22:09:49.926909
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()
    collected_facts = dict()
    test_case_0(obj, collected_facts)
    return

# Generated at 2022-06-24 22:09:52.338594
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware()
    var_0.populate()

# Generated at 2022-06-24 22:09:56.679323
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = {'ansible_uptime_seconds': 56431}
    var_2 = 'test_value_2'
    var_1 = var_2
    var_0 = dict(var_1)


# Generated at 2022-06-24 22:10:00.257036
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware()
    var_1 = dict()
    var_0._populate(var_1)
    assert True

# Generated at 2022-06-24 22:10:08.691514
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = dict()
    var_1 = dict()
    var_0 = {'HurdHardware': {'uptime': {'seconds': 10120}, 'memory': {'available_mb': 7526, 'swap': {'total_mb': 0, 'used_mb': 0}, 'total_mb': 7697}, 'mounts': {'/': {'mount': '/', 'device': '/dev/sda1', 'fstype': 'ufs', 'options': 'ro,nosuid,nodev,noexec', 'size_total': None}}}}
    var_1 = test_case_0()
    assert var_1 == var_0


# Generated at 2022-06-24 22:10:11.984873
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()

    pass

# Generated at 2022-06-24 22:10:14.928643
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware()
    var_2 = var_1.populate
    var_2()

# Generated at 2022-06-24 22:10:18.687409
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware()
    try:
        var_1.populate()
    except TimeoutError as exception_var_1:
        print("Test Case: HurdHardware_populate exception")
    assert True


# Generated at 2022-06-24 22:10:25.166446
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = {'ansible_facts': {'ansible_mounts': [], 'ansible_system_vendor': 'GNU', 'ansible_processor_vcpus': 1, 'ansible_uptime_seconds': 899, 'ansible_memtotal_mb': 0, 'ansible_product_serial': 'Not Specified', 'ansible_processor_cores': 1, 'ansible_system_capabilities_packages': {'name': 'hurd'}}}
    var_1 = test_case_0()

    assert var_1 == var_0

# Generated at 2022-06-24 22:10:27.254798
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware()
    var_1 = None
    var_0.populate(var_1)


# Generated at 2022-06-24 22:10:38.094087
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware()
    var_1 = var_0.populate()
    assert var_1 == { 'mounts': { '/': { 'available_bytes': 128255787008, 'capacity': 5, 'device': '/dev/sd1', 'fstype': 'ufs', 'options': None, 'size_bytes': 128255787008 } }, 'swap': { 'available_bytes': 0, 'capacity': 0, 'device': None, 'size_bytes': 0 }, 'uptime': { 'days': 0, 'hour': 0, 'minutes': 0, 'seconds': 0 } }


# Generated at 2022-06-24 22:10:39.239076
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:10:42.168537
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware(var_0)
    var_2 = var_1.populate()
    pass

# Generated at 2022-06-24 22:10:43.837442
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = dict()

    var_0 = HurdHardware().populate(var_0)



# Generated at 2022-06-24 22:10:48.313172
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware()
    var_1 = HurdHardware()
    var_1.populate(var_0)

# Generated at 2022-06-24 22:10:53.744763
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware(dict())
    var_0_populate = var_0.populate(dict())
    var_0_memory_facts = var_0.get_memory_facts(dict())
    var_0_uptime_facts = var_0.get_uptime_facts(dict())
    var_0_mount_facts = var_0.get_mount_facts(dict())


# Generated at 2022-06-24 22:10:56.744417
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert test_case_0() == hurd_hardware.populate()


# Generated at 2022-06-24 22:11:01.450665
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = dict(test_0="test_0")
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

    test_var_0 = HurdHardware()

    var_1.get('test_0', True)
    test_var_1 = test_var_0.populate(var_1)

# Generated at 2022-06-24 22:11:06.251023
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    populate_obj = HurdHardware()
    # Test if exception raised is of expected type
    try:
        assert isinstance(dict(), object)
    except AssertionError:
        raise AssertionError("Expected Exception to NativeException. Got Exception")


# Generated at 2022-06-24 22:11:08.600614
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware()
    var_1.populate()


# Generated at 2022-06-24 22:11:13.218402
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test method with default arguments
    test_case_0()

# Generated at 2022-06-24 22:11:17.082238
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:18.416516
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:11:22.232387
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:23.240390
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert test_case_0() == None

# Generated at 2022-06-24 22:11:26.182110
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)

    try:
        hurd_hardware_0.populate()
    except Exception as err:
        raise AssertionError(err)



# Generated at 2022-06-24 22:11:29.732955
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    hurd_hardware_0.populate()



# Generated at 2022-06-24 22:11:33.520383
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    ansible_facts = {'ansible_os_family': 'GNU'}
    collected_facts = {'ansible_facts': ansible_facts}
    hurd_hardware_0 = HurdHardware(collected_facts)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:38.816309
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None
    assert isinstance(var_0, dict)
    assert len(var_0.items()) == 3
    assert 'uptime' in var_0
    assert 'memory' in var_0
    assert 'mounts' in var_0


# Generated at 2022-06-24 22:11:46.903629
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    bool_0 = True
    collected_facts_0 = {'ansible_facts': bool_0}
    var_0 = hurd_hardware_0.populate(collected_facts_0)
    assert var_0['ansible_mounts']
    assert var_0['ansible_memtotal_mb']
    assert var_0['ansible_processor_vcpus']
    assert var_0['ansible_swaptotal_mb']
    assert var_0['ansible_uptime_seconds']


# Generated at 2022-06-24 22:11:56.624062
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:00.381734
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = False
    bool_1 = True
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate(bool_0)


# Generated at 2022-06-24 22:12:03.595835
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:08.609929
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    dict_0 = hurd_hardware_0.populate()
    bool_0 = dict_0['uptime_seconds'] is not None
    assert bool_0

# Generated at 2022-06-24 22:12:09.705836
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:10.844569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:13.961563
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    assert not hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:17.503812
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware(True)
    var_0.populate()
    var_1 = HurdHardware(True)
    var_1.populate(None)



# Generated at 2022-06-24 22:12:25.644857
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()
    issues = []

# Generated at 2022-06-24 22:12:29.975096
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:12:48.970670
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:49.963916
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:51.297699
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware.populate()



# Generated at 2022-06-24 22:12:52.768901
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:55.029931
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:58.927547
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:00.995914
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:13:03.416452
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:04.893722
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:13:08.924594
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:13:43.852308
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert test_case_0() == None

# Generated at 2022-06-24 22:13:51.899343
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    case1 = (
        [],
        {
            'uptime': {
                'days': 0,
                'hours': 0,
                'seconds': 10,
                'uptime': '10010',
                'uptime_format': 'seconds'
            },
            'swapfree_mb': 0,
            'swaptotal_mb': 0,
            'memfree_mb': 0,
            'memtotal_mb': 20,
        },
    )

# Generated at 2022-06-24 22:14:01.024089
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_1 = True
    hurd_hardware_1 = HurdHardware(bool_1)
    var_1 = hurd_hardware_1.populate()

    assert type(var_1) == dict
    assert var_1["processor"][0]["model"] == "unknown"
    assert var_1["processor"][0]["vendor"] == "unknown"
    assert var_1["processor"][0]["architecture"] == "unknown"
    assert var_1["processor"][0]["count"] == 1
    assert var_1["processor"][0]["threads_per_core"] == 1
    assert var_1["processor"][0]["cores_per_socket"] == 1
    assert var_1["processor"][0]["socket_count"] == 0

# Generated at 2022-06-24 22:14:03.325103
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # See test_case_0() in test_hurd_hardware
    pass


# Generated at 2022-06-24 22:14:06.734858
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:07.660249
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:14:11.975043
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Define arguments and expected results
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()
    # Perform the test
    test_case_0()


# Generated at 2022-06-24 22:14:13.754580
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:17.655849
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = False
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:18.253429
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:15:45.065213
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    output_list = []
    output_dict = {}
    hurd_hardware_0 = HurdHardware(True)
    output = hurd_hardware_0.populate()
    output_dict.update(output)
    if 'ansible_mounts' in output_dict:
        output_list.append(output_dict['ansible_mounts'])
    if 'ansible_processor_vcpus' in output_dict:
        output_list.append(output_dict['ansible_processor_vcpus'])
    if 'ansible_processor_count' in output_dict:
        output_list.append(output_dict['ansible_processor_count'])
    if 'ansible_processor' in output_dict:
        output_list.append(output_dict['ansible_processor'])

# Generated at 2022-06-24 22:15:50.960385
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = False
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'memory': {'memfree_mb': 814, 'swapfree_mb': 814}, 'uptime': {'seconds': 816, 'hours': 0, 'days': 0, 'minutes': 13}}


# Generated at 2022-06-24 22:15:52.372915
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:15:56.631609
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_var_1 = True
    hurd_hardware_obj_0 = HurdHardware(bool_var_1)
    # Call method populate of class HurdHardware
    hurd_hardware_obj_0.populate()

# Generated at 2022-06-24 22:15:58.871748
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    global answ
    answ = True
    return True

if __name__ == "__main__":
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:00.664223
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:01.566082
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:16:07.733699
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    time_0 = time()
    try:
        hurd_hardware_0 = HurdHardware(False)
        # Test execution
        var_0 = hurd_hardware_0.populate()
    except TimeoutError:
        pass

    # Test assertion
    assert((time() - time_0) < 1)

# Generated at 2022-06-24 22:16:09.629217
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_1 = True
    hurd_hardware_1 = HurdHardware(bool_1)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:16:12.880914
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bool_0 = True
    hurd_hardware_0 = HurdHardware(bool_0)
    var_0 = hurd_hardware_0.populate()
