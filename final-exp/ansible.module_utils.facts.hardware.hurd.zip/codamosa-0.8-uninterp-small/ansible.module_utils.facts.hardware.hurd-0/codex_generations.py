

# Generated at 2022-06-24 22:09:05.507179
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Given a dictionary collected_facts and the HurdHardware
    collected_facts = {}
    hurd_hardware = HurdHardware()

    # when
    hurd_hardware.populate(collected_facts)

    # then
    assert type(collected_facts) is dict
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['uptime_days'] > 0
    assert collected_facts['uptime_hours'] >= 0

    assert collected_facts['totalmem_mb'] > 0
    assert collected_facts['memfree_mb'] > 0
    assert collected_facts['memory_mb']['nocache']['free'] > 0
    assert collected_facts['swap']['total'] > 0

    assert collected_facts['mounts']
    assert type(collected_facts['mounts'])

# Generated at 2022-06-24 22:09:13.092787
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        typed_data = [
            {'architecture': 'i686',
             'system': 'HURD',
             'memtotal': '3487732',
             'fqdn': 'hurd.mi.hdm-stuttgart.de',
             'hostname': 'hurd',
             'processor': ['Genuine Intel(R) CPU T2300  @ 1.66GHz']
             }]
        hurdhw = HurdHardware()
        returned_facts = hurdhw.populate(typed_data)
    except NameError:
        print_exc()
        assert False

    assert returned_facts['system']['manufacturer'] == 'Hurd'
    assert returned_facts['system']['product'] == 'Hurd'

# Generated at 2022-06-24 22:09:15.474817
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = { "platform": { "system": "GNU" } }
    hurd_hardware.populate(collected_facts)

# Generated at 2022-06-24 22:09:18.847285
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test method HurdHardware.populate
    """
    hurd_hardware_object_0 = HurdHardware()
    hurd_hardware_object_0.populate()

# Generated at 2022-06-24 22:09:24.328639
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = {}
    hurd_hardware = HurdHardware()
    hurd_hardware.populate(hardware_facts)
    # Check that the required attributes/methods are present
    assert hasattr(hurd_hardware, 'populate')
    # TODO: Check return value

# Generated at 2022-06-24 22:09:28.371808
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    # Call method populate of HurdHardware
    hurd_hardware_0.populate()


if __name__ == "__main__":
    test_case_0()
    # test_HurdHardware_populate()

# Generated at 2022-06-24 22:09:29.933653
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    hurdhw.populate()

# Generated at 2022-06-24 22:09:32.781504
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:09:35.977641
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate_output = hurd_hardware.populate()
    assert hurd_hardware_populate_output is not None

# Generated at 2022-06-24 22:09:37.625730
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_obj.populate()


# Generated at 2022-06-24 22:09:44.264584
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate(collected_facts={u'ansible_a': {u'a': u'a', u'b': u'b'}, u'ansible_b': {u'a': u'a', u'b': u'b'}})

# Generated at 2022-06-24 22:09:54.220030
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_1 = HurdHardware()
    hurd_hardware_2 = HurdHardware()
    hurd_hardware_3 = HurdHardware()
    hurd_hardware_4 = HurdHardware()
    hurd_hardware_5 = HurdHardware()
    hurd_hardware_6 = HurdHardware()
    hurd_hardware_7 = HurdHardware()

    hurd_hardware_0.populate()
    hurd_hardware_1.populate()
    hurd_hardware_2.populate()
    hurd_hardware_3.populate()
    hurd_hardware_4.populate()
    hurd_hardware_5.populate()
    hurd_hardware_6.populate()
    hurd_hardware_7.populate()

# Generated at 2022-06-24 22:10:02.960121
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test populatte method of class HurdHardware"""
    hurd_hardware_0 = HurdHardware()

    hurd_hardware_0.populate()

    assert not hasattr(hurd_hardware_0, 'uptime')
    assert not hasattr(hurd_hardware_0, 'uptime_seconds')
    assert not hasattr(hurd_hardware_0, 'fqdn')
    assert not hasattr(hurd_hardware_0, 'device_links')
    assert not hasattr(hurd_hardware_0, 'interfaces')
    assert not hasattr(hurd_hardware_0, 'selinux')
    assert not hasattr(hurd_hardware_0, 'distribution')
    assert not hasattr(hurd_hardware_0, 'distribution_release')
   

# Generated at 2022-06-24 22:10:05.385541
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_collector = HurdHardwareCollector()

    hurd_hardware_collector.collect()

    hurd_hardware.populate(collected_facts=None)

# Generated at 2022-06-24 22:10:08.799981
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        hurd_hardware_0 = HurdHardware()
    except NameError:
        pass
    else:
        hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:17.291190
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    facts = hurd_hardware_0.populate()
    # 'uptime_seconds' in facts
    # 'uptime_hours' in facts
    # 'uptime_days' in facts
    # 'uptime' in facts
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['memavail_mb'] >= 0
    # 'swaptotal_mb' in facts
    # 'swapfree_mb' in facts
    assert isinstance(facts['mounts'], list)
    # 'fstype' in facts['mounts'][0]
    # 'uuid' in facts['mounts'][0]
    # 'device' in facts['mounts'][0]
    # 'mount' in facts

# Generated at 2022-06-24 22:10:18.471350
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardwa

# Generated at 2022-06-24 22:10:21.188120
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate = hurd_hardware.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:22.358813
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardwareCollector()
    hardware_facts.populate()

# Generated at 2022-06-24 22:10:24.082498
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    result = hurd_hardware_0.populate()
    assert result is None


# Generated at 2022-06-24 22:10:29.391837
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    collected_facts = {}
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:10:32.404861
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:33.662535
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:10:38.789761
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hurd_hardware_0 = HurdHardware()

    # Call method populate of hurd_hardware_0
    hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:45.104677
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    facts = hurd_hardware_0.populate()
    assert 'uptime' in facts
    assert 'timer_frequency' in facts
    assert 'timer_ticks' in facts
    assert 'memory' in facts
    assert 'swap' in facts
    assert 'mounts' in facts
    assert 'system' in facts


# Generated at 2022-06-24 22:10:54.120700
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware(module=None)
    collected_facts = {}
    hardware_facts = {}
    uptime_facts = {}
    uptime_facts['uptime'] = 43834.90
    uptime_facts['uptime_days'] = 0
    hardware_facts.update(uptime_facts)
    memory_facts = {}
    memory_facts['memtotal_mb'] = 16386
    memory_facts['memfree_mb'] = 16087
    memory_facts['swaptotal_mb'] = 2048
    memory_facts['swapfree_mb'] = 2048
    hardware_facts.update(memory_facts)
    mount_facts = {}

# Generated at 2022-06-24 22:10:56.320210
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:57.746887
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    my_HurdHardware = HurdHardware()
    my_HurdHardware.populate()

# Generated at 2022-06-24 22:10:59.600881
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:05.503358
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test for hardware_facts returned by method populate
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['mounts'] == [] or hardware_facts['mounts'] == None
    assert hardware_facts['uptime_seconds'] == 0 or hardware_facts['uptime_seconds'] == None
    assert hardware_facts['uptime_hours'] == 0 or hardware_facts['uptime_hours'] == None
    assert hardware_facts['uptime_days'] == 0 or hardware_facts['uptime_days'] == None


# Generated at 2022-06-24 22:11:08.601236
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_obj.populate()

# Generated at 2022-06-24 22:11:09.861263
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:11:12.588994
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    # Call method
    result = hurd_hardware.populate(collected_facts=None)
    assert len(result) >= 18


# Generated at 2022-06-24 22:11:17.490993
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_obj.populate(collected_facts={'ansible_facts': {'ansible_os_family': 'GNU', 'ansible_system': 'Hurd'}})


# Generated at 2022-06-24 22:11:24.389978
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {'uptime_seconds': 1884, 'uptime_days': 0, 'uptime_hours': 0, 'uptime_minutes': 31, 'uptime': '31 minutes', 'memtotal_mb': 357, 'memfree_mb': 303, 'memavail_mb': 303, 'swaptotal_mb': 0, 'swapfree_mb': 0}

# Generated at 2022-06-24 22:11:26.883869
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:36.957833
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

# Generated at 2022-06-24 22:11:38.615416
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:40.983207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-24 22:11:43.320295
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    # Check with correct data
    data = hurd_hardware.populate()

# Generated at 2022-06-24 22:11:45.941185
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:11:49.213985
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '"yXB!&x_#?>'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:55.373840
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '7Gk+]Y\x7f@f}z{mH'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


if __name__ == "__main__":
    import sys
    import pytest

    print(sys.version)
    pytest.main(sys.argv)

# Generated at 2022-06-24 22:11:58.961571
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:04.324281
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    assert(hurd_hardware_0.populate()) == ('\nHurdHardware\n')

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:12:09.165992
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'p5'
    str_2 = '@Dm!L'
    str_3 = '|eX/'
    hurd_hardware_0 = HurdHardware(str_1)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:19.440705
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:12:23.136729
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_2 = '>r`*\nG#ss]o'
    hurd_hardware_1 = HurdHardware(str_2)
    var_1 = hurd_hardware_1.populate()
    assert var_1 is not None


# Generated at 2022-06-24 22:12:27.165504
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '!;w!Dt\x0b'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:31.601227
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:43.620605
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None
    assert str(type(var_0)) == "<type 'dict'>"
    assert len(var_0) == 3
    assert str(type(var_0.get('ansible_uptime_seconds'))) == "<type 'int'>"
    assert var_0.get('ansible_uptime_seconds') == 0
    assert str(type(var_0.get('ansible_memfree_mb'))) == "<type 'int'>"
    assert var_0.get('ansible_memfree_mb') == 0

# Generated at 2022-06-24 22:12:48.810498
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    # Execution
    # No output
    try:
        var_0 = hurd_hardware_0.populate()
    except:
        var_0 = None
    # Verification
    assert var_0 is None


# Generated at 2022-06-24 22:12:57.533578
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime_seconds'] == '93.73'
    assert var_0['uptime_hours'] == '0.03'
    assert var_0['uptime_days'] == '0'
    assert var_0['uptime_minutes'] == '2'
    assert var_0['memory_mb']['real']['total'] == '38.59'
    assert var_0['memory_mb']['swap']['used'] == '0'
    assert var_0['memory_mb']['real']['available'] == '38.59'
    assert var_

# Generated at 2022-06-24 22:13:04.236563
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    str_0 = 'l]mG\x7fET'
    hurd_hardware_0 = HurdHardware(str_0)
    collected_facts = {}
    actual_result = hurd_hardware_0.populate(collected_facts)

    assert actual_result is not None

    str_0 = 'z\x7fW\x1aT\x1a'
    hurd_hardware_0 = HurdHardware(str_0)
    collected_facts = {}
    actual_result = hurd_hardware_0.populate(collected_facts)

    assert actual_result is not None

    str_0 = 'xq!L\n0y}\x16'
    hurd_hardware_0 = HurdHardware(str_0)
    collected_facts = {}
    actual_result = hurd_hard

# Generated at 2022-06-24 22:13:05.752638
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert test_case_0() is None

# Generated at 2022-06-24 22:13:08.550093
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('*' * 50)
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 22:13:13.376895
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test for no arguments, same as if path was None
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0


# Generated at 2022-06-24 22:13:14.714606
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-24 22:13:15.541891
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 0 == 0

# Generated at 2022-06-24 22:13:19.876109
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ';<uE.Vxv1'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = 'HurdHardware.populate'
    str_2 = 'HurdHardware.get_uptime_facts'
    str_3 = 'HurdHardware.get_memory_facts'
    str_4 = 'HurdHardware.get_mount_facts'
    if str_1 in var_0:
        var_1 = var_0[str_1]
        assert str_2 in var_1
        assert str_3 in var_1
        assert str_4 in var_1

# Generated at 2022-06-24 22:13:27.354347
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'q3!\x7f'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Unit tests for class HurdHardwareCollector

# Generated at 2022-06-24 22:13:29.772069
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:33.045792
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None



# Generated at 2022-06-24 22:13:43.481831
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.get_mount_facts = MagicMock()
    hurd_hardware_0.get_uptime_facts = MagicMock()
    hurd_hardware_0.get_memory_facts = MagicMock()
    var_0 = hurd_hardware_0.populate()
    assert var_0 == False
    hurd_hardware_0.get_mount_facts.assert_called_once_with()
    hurd_hardware_0.get_uptime_facts.assert_called_once_with()
    hurd_hardware_0.get_memory_facts.assert_called_once_with()

# Generated at 2022-06-24 22:13:47.615731
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:53.953011
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-24 22:13:57.690451
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = '>r`*\nG#ss]o'
    hurd_hardware_1 = HurdHardware(str_1)

    # TODO: is this the right way to test this? this doesn't verify any of the sub methods are being called.
    assert hurd_hardware_1.populate()

# Generated at 2022-06-24 22:14:01.069621
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:04.954207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:08.297465
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:19.450808
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:22.733331
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()



# Generated at 2022-06-24 22:14:25.829429
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '=U'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    return str(var_0)


# Generated at 2022-06-24 22:14:28.222653
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ' '
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:33.104428
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '8$?\x0f\x0c\x00\x04\x11\x01\x0b\x08\x12\x06'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}



# Generated at 2022-06-24 22:14:36.605909
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'J$y{uV'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:39.884464
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:41.520568
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 'timezone' in var_0
    assert 'uptime' in var_0

# Generated at 2022-06-24 22:14:52.420211
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware('Linux')
    str_0 = b'\xee\x81]E\x97\x8d\xc5\x1c\xbeL\xbe\x1e\x01\xc3\x97\xe8\x1b\xfa\x06\xa7\x9d\x0c\x1a\xdc\x8a\xcb\x14\xae\xb4\xa8\xae\x93\xf02\x1e\xeb\xfb\xf0\x0c\xcd\x14e'

# Generated at 2022-06-24 22:14:56.226862
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '1lLW8%iA'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None

# Generated at 2022-06-24 22:15:17.521708
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
  pass

# Generated at 2022-06-24 22:15:20.529848
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'G#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:22.795985
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:32.971248
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:15:36.244007
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:15:40.391134
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '=\x1b\\\x7f8'
    hurd_hardware_0 = HurdHardware(str_0)
    assert isinstance(hurd_hardware_0.populate(), dict)


# Generated at 2022-06-24 22:15:43.472359
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = 'E,0u/7|F'
    hurd_hardware_0 = HurdHardware(var_0)
    var_1 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:46.743024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:50.078457
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'Gm]o?HwGm]k'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:54.814797
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:14.489207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:16:20.451082
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    string_1 = '7e!5Dp'
    hurd_hardware_1 = HurdHardware(string_1)
    string_2 = ':7<Q,*{'
    hurd_hardware_1.get_mount_facts(string_2)
    hurd_hardware_1.populate()

if (__name__ == '__main__'):
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:29.807549
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = 'total'
    assert (var_0[str_1] == '0B')
    str_2 = 'available'
    assert (var_0[str_2] == '0B')
    str_3 = 'percent'
    assert (var_0[str_3] == '0%')
    str_4 = 'used'
    assert (var_0[str_4] == '0B')
    str_5 = 'free'
    assert (var_0[str_5] == '0B')
    str_6 = 'active'

# Generated at 2022-06-24 22:16:30.670468
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:16:39.900079
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:16:43.296919
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '&G"Z\x1b\x13\x0e\x03'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:16:44.158837
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:16:52.043339
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(str)
    str_0 = 'm%\x1d\x04\x1f\x14\x17\x16\x0c'
    var_0 = hurd_hardware_0.populate(str_0)

# Generated at 2022-06-24 22:16:53.102125
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:16:54.721908
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except Exception as e:
        print("Exception: ", repr(e))

# Generated at 2022-06-24 22:17:19.078500
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    for tc in test_cases:
        test_function = tc.pop('test_function', None)
        if test_function:
            test_function(tc)


# Generated at 2022-06-24 22:17:21.806292
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:26.358837
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test for class HurdHardware::populate."""
    str_0 = 'a4:y+\x7f\x1d*\x0f'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:31.649961
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = ':Q]ywf'
    hurd_hardware_1 = HurdHardware(str_1)
    print(hurd_hardware_1.populate())


# Generated at 2022-06-24 22:17:34.356635
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '-<\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()
    assert True


# Generated at 2022-06-24 22:17:38.175023
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'J-\x1a\x97\x7f\x1a'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert str_0 is not None


# Generated at 2022-06-24 22:17:41.472715
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:45.468610
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = "GNU"
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    str_2 = "GNU"
    assert var_1 != str_2


# Generated at 2022-06-24 22:17:54.124702
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    os_version = '3.0.1'
    os_version_major = '3'
    os_version_minor = '0'

    str_0 = 'GNU/Hurd'
    hurd_hardware_0 = HurdHardware(str_0)
    collecting_facts_from = '/usr/bin/freebsd-version'
    module_return_value0 = None
    module_return_value1 = None
    module_return_value2 = None
    module_return_value3 = None
    module_return_value4 = None
    module_return_value5 = None
    module_return_value6 = None
    module_return_value7 = None
    module_return_value8 = None
    module_return_value9 = None
    module_return_value10 = None
    module_return

# Generated at 2022-06-24 22:17:57.414048
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '$\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:41.299668
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = [
        'Linux',
        'Darwin'
    ]
    var_1 = 'Linux'
    var_2 = False
    if (var_1 in var_0):
        var_2 = True
    var_3 = not var_2
    if var_3:
        test_case_0()

# Generated at 2022-06-24 22:18:43.438531
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '$6^'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:46.170428
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'GNU'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:49.022250
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert type(var_0) == dict

# Generated at 2022-06-24 22:18:49.518789
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:18:51.507778
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '@'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:55.232818
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '>r`*\nG#ss]o'
    hurd_hardware_0 = HurdHardware(str_0)
    var_1 = hurd_hardware_0.populate()
    assert isinstance(var_1, dict) and len(var_1) == 0
