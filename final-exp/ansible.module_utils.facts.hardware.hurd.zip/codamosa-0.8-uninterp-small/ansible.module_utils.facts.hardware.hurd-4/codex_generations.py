

# Generated at 2022-06-24 22:09:02.044607
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    dict_0 = {
        'kernel': 'GNU',
    }
    hurd_hardware_0 = HurdHardware(dict_0)

# Generated at 2022-06-24 22:09:06.941608
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    dict_0 = {'ansible_facts': {'hardware': {'system': {'fqdn': 'localhost.localdomain'}, 'uptime_hours': '2'}}}
    hurd_hardware_0 = HurdHardware(dict_0)
    hurd_hardware_0.populate()
    assert dict_0 == dict_0


# Generated at 2022-06-24 22:09:07.843382
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:09:10.638121
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    dict_0 = {}
    hurd_hardware_0 = HurdHardware(dict_0)
    # Test for a zero length cpu list.
    res_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:09:13.460439
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    d = {}
    hurd_hardware_1 = HurdHardware(d)
    hurd_hardware_1.populate()


test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:09:18.084637
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    dict_0 = {}
    hurd_hardware_0 = HurdHardware(dict_0)
    dict_1 = hurd_hardware_0.populate()
    assert dict_1['uptime_seconds'] >= 0
    assert dict_1['memtotal_mb'] > 0

# Generated at 2022-06-24 22:09:24.129616
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    dict_0 = {}
    hurd_hardware_0 = HurdHardware(dict_0)
    dict_1 = {}
    dict_1 = hurd_hardware_0.populate(dict_1)
    assert len(dict_1) is not 0


# Generated at 2022-06-24 22:09:28.288377
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # initialize
    dict_0 = {}
    hurd_hardware_0 = HurdHardware(dict_0)

    # act
    ret_0 = hurd_hardware_0.populate()

    # assert
    assert ret_0 is not None


# Generated at 2022-06-24 22:09:32.201428
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    dict_0 = {}
    hurd_hardware_0 = HurdHardware(dict_0)
    args = ()
    kwargs = {}
    collected_facts = {}
    hurd_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:09:42.092513
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Define the arguments for HurdHardware.populate
    collected_facts = None

    # Define the expected return values for HurdHardware.populate
    hurddict_0 = {}

    # Set the return values for HurdHardware.get_uptime_facts
    hurd_hardware_0 = HurdHardware(hurddict_0)
    hurd_hardware_0.get_uptime_facts = Mock()
    hurduptime_0 = {}
    hurd_hardware_0.get_uptime_facts.return_value = hurduptime_0

    # Set the return values for HurdHardware.get_memory_facts
    hurd_hardware_0.get_memory_facts = Mock()
    hurdmemory_0 = {}
    hurd_hardware_0.get_memory_facts.return_value = hurdmemory

# Generated at 2022-06-24 22:09:51.366914
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts_expected = {
        'uptime_seconds': 0,
        'uptime_days': 0,
        'uptime_hours': 0,
        'uptime_minutes': 0,
    }
    collected_facts = hurd_hardware_0.populate()
    assert collected_facts['uptime_seconds'] >= 0
    assert collected_facts['uptime_days'] >= 0
    assert collected_facts['uptime_hours'] >= 0
    assert collected_facts['uptime_minutes'] >= 0

# Generated at 2022-06-24 22:09:55.535721
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    test_HurdHardware_populate
    """
    hurd_hardware_0 = HurdHardware()
    collected_facts_0 = {}
    hurd_hardware_0.populate(collected_facts_0)

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:09:58.909691
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0 = hurd_hardware_collector_0.collect()
    assert hurd_hardware_0['uptime_seconds'] == 0


# Generated at 2022-06-24 22:10:01.721601
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:10.428964
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # TODO Use test_case_0 to setup hurd_hardware_collector_0
    # TODO Use test_case_1 to setup hurd_hardware_0
    hurd_hardware_0 = hurd_hardware_collector_0.populate(
    )
    assert isinstance(hurd_hardware_0, dict)

# Generated at 2022-06-24 22:10:14.868391
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:17.554628
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = {}
    hurd_hardware_0.populate(collected_facts)

# Generated at 2022-06-24 22:10:25.731149
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    # Testing with no procfs
    hurd_hardware.set_procfs_path("")
    hardware_facts = hurd_hardware.populate()
    assert hardware_facts.get("uptime") is None
    assert hardware_facts.get("memfree_mb") is None
    assert hardware_facts.get("mounts") is None

    # Testing with a procfs
    hurd_hardware.set_procfs_path("/proc")
    hardware_facts = hurd_hardware.populate()
    assert hardware_facts.get("uptime") is not None
    assert hardware_facts.get("memfree_mb") is not None
    assert hardware_facts.get("mounts") is not None

# Generated at 2022-06-24 22:10:27.728998
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:29.760951
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_obj.populate()

# Generated at 2022-06-24 22:10:38.626275
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    _obj = HurdHardware()
    result = _obj.populate()
    assert isinstance(result, dict)
    assert 'mem_total' in result
    assert 'mem_swap_total' in result
    assert 'mem_swap_available' in result
    assert 'mem_free' in result
    assert 'mem_available' in result
    assert 'uptime' in result
    assert 'uptime_seconds' in result
    assert 'mounts' in result

# Generated at 2022-06-24 22:10:43.191807
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0.populate()
    hurd_hardware_collector_0.populate()

# Generated at 2022-06-24 22:10:45.192012
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# vim: set expandtab ts=4 sw=4 sts=4 tw=85:

# Generated at 2022-06-24 22:10:54.181698
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:10:58.368301
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = None
    returned_hardware_facts = hurd_hardware_0.populate(collected_facts)
    assert type(returned_hardware_facts) is dict


# Generated at 2022-06-24 22:11:02.392053
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate = hurd_hardware.populate()
    assert type(hurd_hardware_populate) == dict
    assert 'uptime_seconds' in hurd_hardware_populate
    assert 'uptime_seconds' in hurd_hardware_populate


# Generated at 2022-06-24 22:11:12.551908
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup

    output = {'ansible_facts': {'mounts': [{'device': '/dev/sda1', 'mount': '/', 'size_available': 20000000000,
                                           'size_total': 10000000000, 'fstype': 'ext4', 'options': 'rw,relatime'}],
                               'uptime_seconds': 2000, 'memfree_mb': 10, 'memtotal_mb': 20}}

    # Run
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.uptime = None
    hurd_hardware_0.mount = None
    hurd_hardware_0.memfree = None
    hurd_hardware_0.memtotal = None

    test_output = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:15.282872
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_obj.populate()

# Generated at 2022-06-24 22:11:17.369644
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:26.705973
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    result = hurd_hardware.populate()
    assert 'uptime' in result.keys()
    assert 'fqdn' in result.keys()
    assert 'domain' in result.keys()
    assert 'system_vendor' in result.keys()
    assert 'virtualization_role' not in result.keys()
    assert 'virtual' in result.keys()
    assert 'kernel' in result.keys()
    assert 'hostname' in result.keys()
    assert 'kernel_release' in result.keys()
    assert 'lsb' not in result.keys()
    assert 'distribution' in result.keys()
    assert 'kernel_version' in result.keys()
    assert 'swapfree_mb' in result.keys()
    assert 'memory_mb' in result.keys

# Generated at 2022-06-24 22:11:40.505290
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    # Unit test for method populate of class HurdHardware
    def test_method_get_memory_facts():
        memory_facts_0 = hurd_hardware_0.get_memory_facts()
        assert memory_facts_0['hw_memtotal_mb'] == 2048

    test_method_get_memory_facts()

    # Unit test for method populate of class HurdHardware
    def test_method_get_mount_facts():
        mount_facts_0 = hurd_hardware_0.get_mount_facts()

    test_method_get_mount_facts()

    # Unit test for method populate of class HurdHardware
    def test_method_get_uptime_facts():
        uptime_facts_0 = hurd_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:11:43.912786
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:11:52.598193
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Note: Software collection is based on tests/files/facts/Hurd/hardware.json
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()
    assert hurd_hardware_0.facts['uptime_seconds'] == 15745
    assert hurd_hardware_0.facts['uptime_hours'] == 4
    assert hurd_hardware_0.facts['uptime_days'] == 0
    assert hurd_hardware_0.facts['memtotal_mb'] == 324
    assert hurd_hardware_0.facts['memfree_mb'] == 48
    assert hurd_hardware_0.facts['swaptotal_mb'] == 2047
    assert hurd_hardware_0.facts['swapfree_mb'] == 2047

# Generated at 2022-06-24 22:11:56.292965
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_collector = HurdHardwareCollector()
    collected_facts = {'ansible_mounts': []}
    hurd_hardware_collector.collect(collected_facts)

# Generated at 2022-06-24 22:11:58.457396
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:00.662211
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:09.873517
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collected_facts = {
        'distribution': 'GNU',
        'distribution_release': '0.3',
        'distribution_version': '0.3',
        'lsb': {
            'distcodename': '',
            'distdescription': '',
            'distid': '',
            'distrelease': '0.3',
            'distributor_id': 'GNU',
            'majdistrelease': '0',
            'release': '0.3',
            'codename': '',
            'description': ''
        }
    }
    hurd_hardware_0 = HurdHardware(hurd_hardware_collected_facts)

# Generated at 2022-06-24 22:12:14.475986
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initializing object of class HurdHardware
    hurd_hardware_0 = HurdHardware()
    # Executing populate
    hardware_facts_dict = hurd_hardware_0.populate()
    # Verifying if hardware_facts_dict is populated
    assert hardware_facts_dict is not None

# Generated at 2022-06-24 22:12:18.364760
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    cdrom_obj = HurdHardware()

    cdrom_obj.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:12:21.162146
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_populate_0 = hurd_hardware_0.populate()
#

# Generated at 2022-06-24 22:12:29.278344
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:12:32.210084
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_0 = hurd_hardware_collector_1._fact_class()
    collected_facts = None
    hurd_hardware_0.populate(collected_facts)

# Generated at 2022-06-24 22:12:34.312093
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    my_HurdHardware = HurdHardware()

# Generated at 2022-06-24 22:12:43.640674
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    hurd_hardware_populate = hurd_hardware.populate()

    assert isinstance(hurd_hardware_populate, dict)
    assert 'uptime' in hurd_hardware_populate
    assert 'uptime_seconds' in hurd_hardware_populate
    assert 'uptime_hours' in hurd_hardware_populate
    assert 'uptime_days' in hurd_hardware_populate
    assert 'memory' in hurd_hardware_populate
    assert 'memtotal_mb' in hurd_hardware_populate
    assert 'memfree_mb' in hurd_hardware_populate
    assert 'swapfree_mb' in hurd_hardware_populate
    assert 'swaptotal_mb' in hurd_hardware_populate

# Generated at 2022-06-24 22:12:47.239125
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0 = hurd_hardware_collector_0.collect()
    assert isinstance(hurd_hardware_0.data, dict)



# Generated at 2022-06-24 22:12:49.871775
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}

    hurd_hardware.populate(collected_facts)


# Generated at 2022-06-24 22:12:58.149875
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the module's populate function for the following cases:
    """
    hw_0 = HurdHardware()

    # Case 1: Test populating hardware facts on GNU system
    #   This is the base case in an expected-to-work situation
    #   Expect: hardware fact dictionary with uptime, memory, and mount facts

# Generated at 2022-06-24 22:13:03.025086
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0 = hurd_hardware_collector_0.collect()
    assert type(hurd_hardware_0) is dict
    assert "uptime_seconds" in hurd_hardware_0
    assert "memory_mb" in hurd_hardware_0
    assert "swapfile" in hurd_hardware_0
    assert "fstype" in hurd_hardware_0
    assert "mount" in hurd_hardware_0


# Generated at 2022-06-24 22:13:12.836850
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    # Invoke method
    result = hurd_hardware.populate()

    assert type(result) is dict
    assert 'uptime_seconds' in result
    assert result['uptime_seconds'] in range(0, 1)
    assert 'memory_mb' in result
    assert result['memory_mb'] in range(0, 10)
    assert 'swap_mb' in result
    assert result['swap_mb'] in range(0, 10)
    assert 'mounts' in result
    assert type(result['mounts']) is list
    assert len(result['mounts']) in range(0, 10)


# Generated at 2022-06-24 22:13:21.866860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_collector_1.hardware.get_mount_facts = lambda: {'mounts': []}
    hurd_hardware_collector_1.hardware.get_memory_facts = lambda: {'memory': {'swap': {'total': '0'}}}
    hurd_hardware_collector_1.hardware.get_uptime_facts = lambda: {'uptime': {'seconds': 0}}
    facts = hurd_hardware_collector_1.populate()
    assert facts == {'mounts': [], 'memory': {'swap': {'total': '0'}}, 'uptime': {'seconds': 0}}



# Generated at 2022-06-24 22:13:34.341040
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_class_obj = HurdHardware()
    collected_facts = {'ansible_os_family': 'Linux',
                       'ansible_distribution': 'GNU/Linux',
                       'ansible_os_name': 'GNU/Linux',
                       'ansible_distribution_version': '1.0',
                       'ansible_distribution_major_version': '1',
                       'ansible_distribution_release': '1.0',
                       'ansible_distribution_file_parsed': True}

# Generated at 2022-06-24 22:13:36.639918
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:13:41.916986
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate_result = hurd_hardware.populate()
    assert 'uptime_seconds' in hurd_hardware_populate_result
    assert 'memory_details' in hurd_hardware_populate_result
    assert 'mounts' in hurd_hardware_populate_result or 'failed_mounts' in hurd_hardware_populate_result

# Generated at 2022-06-24 22:13:50.718204
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    uptime_facts = {
        'uptime_seconds': 1000,
        'uptime_timestamp': '2018-02-02 12:34:56.12345'
    }
    memory_facts = {
        'memfree_mb': 1000,
        'memtotal_mb': 2000
    }
    hurd_hardware_object_0 = HurdHardware()
    with patch('ansible.module_utils.facts.hardware.linux.LinuxHardware.get_uptime_facts', return_value=uptime_facts):
        with patch('ansible.module_utils.facts.hardware.linux.LinuxHardware.get_memory_facts', return_value=memory_facts):
            result_dict = hurd_hardware_object_0.populate()
    assert result_dict['uptime_seconds'] == 1000
    assert result_

# Generated at 2022-06-24 22:13:52.628875
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(module)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:55.161125
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

'''
TODO:
    - re-instate tests for methods:
        - get_uptime_facts
        - get_memory_facts
        - get_mount_facts
'''

# Generated at 2022-06-24 22:14:05.454326
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardwareCollector().collect()
    assert hurd_hardware_0['uptime_seconds'] == 59438.54
    assert hurd_hardware_0['uptime_hours'] == 16.51
    assert hurd_hardware_0['uptime_days'] == 0.69
    assert hurd_hardware_0['memory']['swapfree_mb'] == 64.00
    assert hurd_hardware_0['memory']['swaptotal_mb'] == 64.00
    assert hurd_hardware_0['memory']['memtotal_mb'] == 1788.00
    assert hurd_hardware_0['memory']['memfree_mb'] == 204.00
    assert hurd_hardware_0['memory']['memavailable_mb'] == 558.00
    assert hurd_

# Generated at 2022-06-24 22:14:07.367945
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:10.905540
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate_result = hurd_hardware.populate()
    assert hurd_hardware_populate_result is not None


# Generated at 2022-06-24 22:14:13.572934
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # set up test objects
    hurd_hardware_collector_1 = HurdHardwareCollector()

    # call the method
    hurd_hardware_collector_1.populate()


# Generated at 2022-06-24 22:14:20.179342
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 22:14:22.240456
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:24.315228
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-24 22:14:26.909286
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:31.549015
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_1 = HurdHardware()
    var_1 = hurd_hardware_1.populate(hurd_hardware_collector_1)
    var_expected_1 = {}
    assert var_1 == var_expected_1


# Generated at 2022-06-24 22:14:33.371312
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:35.568602
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test the method populate of class HurdHardware"""
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:39.386953
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime_seconds': 0, 'mounts': [], 'memtotal_mb': 0}


# Generated at 2022-06-24 22:14:41.732415
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:47.915089
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj_0 = HurdHardwareCollector().collect()
    check_values = [
        "memtotal",
        "os_family",
        "uptime",
        "memfree",
        "swap_memory"
    ]

    for key in check_values:
        if key not in hurd_hardware_obj_0:
            raise AssertionError()


# Generated at 2022-06-24 22:14:57.345439
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    assert isinstance(hurd_hardware_0.populate(), dict)


# Generated at 2022-06-24 22:14:59.273193
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    _5 = HurdHardware()
    _5.populate()

test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:15:02.205792
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:04.062792
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:04.798824
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware().populate()

# Generated at 2022-06-24 22:15:07.825227
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:09.264823
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_HurdHardware_populate_0()


# Generated at 2022-06-24 22:15:13.480269
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj_0 = HurdHardware()

    hurd_hardware_obj_0.populate()


# Generated at 2022-06-24 22:15:15.003330
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:16.719024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware().populate() != None


# Generated at 2022-06-24 22:15:34.610770
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.collect_platform_facts = 'test_value_1'
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:36.570998
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:42.235923
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    var_0 = hurd_hardware_collector_0.collect(hurd_hardware_collector_0)
    assert var_0.get('mounts')
    assert var_0.get('memory_mb')
    assert var_0.get('uptime')

# Generated at 2022-06-24 22:15:44.071990
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    var = hurd_hardware.populate()


# Generated at 2022-06-24 22:15:45.898615
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-24 22:15:47.996700
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:49.720087
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:50.546915
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:15:53.003559
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup test data
    hurd_hardware = HurdHardware()

    # Run the code to be tested
    hurd_hardware.populate()

# Generated at 2022-06-24 22:15:56.177246
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:27.256638
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:29.418150
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_1 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:32.482149
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    #  Base class populate
    hurd_hardware_0.populate()

    return

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:33.982256
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:35.757096
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:37.818764
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate(None)

# Generated at 2022-06-24 22:16:41.882234
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardwareCollector()
    hurd_hardware_data = hurd_hardware_obj.collect(None)
    assert "uptime" in hurd_hardware_data
    assert "mem_total" in hurd_hardware_data
    assert "swap_total" in hurd_hardware_data

# Generated at 2022-06-24 22:16:43.454287
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:49.502837
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    input_1 = {
    }
    expected_1 = {
        'mounts': [],
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'uptime_seconds': 0,
        'uptime_hours': 0,
        'uptime_days': 0
    }
    obj_1 = HurdHardware(input_1)
    obj_1.populate()
    assert expected_1 == obj_1.populate()


# Generated at 2022-06-24 22:16:51.928149
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_hurd_hardware_0 = HurdHardware()
    hurd_hardware_hurd_hardware_0.populate(None)

# Generated at 2022-06-24 22:18:03.724052
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initialize class instance
    hurd_hardware_instance = HurdHardware()
    # do not include facts from base class
    hurd_hardware_instance.populate = lambda: {}
    # Pass empty dict as collected_facts
    var_1 = {}
    # Call method populate of HurdHardware class instance with parametrized values
    var_2 = hurd_hardware_instance.populate(var_1)
    # AssertionError: {} != {'mounts': [], 'memfree_mb': 11, 'memtotal_mb': 46, 'uptime_seconds': 28}
    assert (var_2 == {'mounts': [], 'memfree_mb': 11, 'memtotal_mb': 46, 'uptime_seconds': 28})


test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:18:11.702534
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate(None)
    assert var_0 == {'uptime': {'days': 0, 'hours': 0, 'seconds': 3785, 'minutes': 63}, 'memswap': {'total': '', 'used': '', 'cached': '', 'available': '', 'free': ''}, 'memfree': {'total': '', 'used': '', 'cached': '', 'available': '', 'free': ''}, 'root_partition': {'available': '', 'mount': '/', 'size': '', 'options': '', 'used': ''}, 'virtual': 'physical'}


# Generated at 2022-06-24 22:18:13.858212
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    var_1 = HurdHardware()
    try:
        var_1.populate(hurd_hardware_collector_0)
    except TimeoutError:
        pass

# Generated at 2022-06-24 22:18:15.903081
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hurd_hardware_populate_0 = HurdHardware()
    var_0 = hurd_hardware_populate_0.populate()


# Generated at 2022-06-24 22:18:19.579096
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_populate_0 = hurd_hardware_0.populate()
    assert type(hurd_hardware_populate_0) is dict, 'Return type of HurdHardware.populate is not dict'

# Generated at 2022-06-24 22:18:22.765783
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

if __name__ == "__main__":
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:18:23.303619
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:18:25.065248
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:27.589029
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    assert hurd_hardware_0.populate() == {}


# Generated at 2022-06-24 22:18:29.700905
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate(hurd_hardware_0)
