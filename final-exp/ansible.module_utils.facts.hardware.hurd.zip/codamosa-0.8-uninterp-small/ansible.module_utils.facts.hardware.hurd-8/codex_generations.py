

# Generated at 2022-06-24 22:08:56.922115
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)

    collected_facts_0 = dict()
    collected_facts_0['os'] = 'GNU/Hurd'
    collected_facts_0['facter'] = 'GNU/Hurd'
    collected_facts_0['kernel'] = 'GNU/Hurd'
    collected_facts_0['kernel_version'] = '0.6'
    collected_facts_0['kernel_release'] = '0.6.0'

    output_0 = hurd_hardware_0.populate(collected_facts_0)

    assert output_0['uptime'] == '28 days, 16:42'
    assert output_0['memtotal_mb'] == 982

# Generated at 2022-06-24 22:08:59.518126
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)

    # Test lines to write here
    pass


# Generated at 2022-06-24 22:09:00.066195
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True  # dummy

# Generated at 2022-06-24 22:09:06.942893
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    collected_facts_0 = {}
    str_0 = 'hardware'
    dict_0 = {}
    dict_0['cpu_count'] = 2
    dict_1 = {}
    dict_1['ram'] = {'total': 524288, 'swapfree': 524288, 'swaptotal': 2097148, 'free': 524288}
    dict_0['mem'] = dict_1
    dict_2 = {}
    dict_2['/'] = {'space_used': 23797504, 'block_size': 4096, 'space_total': 41943040, 'space_free': 18145536}

# Generated at 2022-06-24 22:09:09.012155
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts_0 = {}
    hurd_hardware_0 = HurdHardware()
    assert hurd_hardware_0.populate(collected_facts_0) == {}

# Generated at 2022-06-24 22:09:17.888445
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with integers
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    assert(hurd_hardware_0.populate(collected_facts = None) == {'uptime_seconds': 980, 'mounts': [], 'memfree_mb': 20, 'swapfree_mb': 0, 'memtotal_mb': 38})

    # Test with floats
    float_0 = 538.73
    hurd_hardware_1 = HurdHardware(float_0)
    assert(hurd_hardware_1.populate(collected_facts = None) == {'uptime_seconds': 538, 'mounts': [], 'memfree_mb': 20, 'swapfree_mb': 0, 'memtotal_mb': 38})

    # Test with strings
    str_

# Generated at 2022-06-24 22:09:27.499119
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    collected_facts_0 = dict()
    hurd_hardware_0._collect_platform_info()
    hurd_hardware_0._collect_lsb_info()
    hurd_hardware_0._collect_device_info()
    hurd_hardware_0._collect_mount_info()
    hurd_hardware_0._collect_cpu_info()
    hurd_hardware_0._collect_mem_info()
    hurd_hardware_0._collect_dmi_info()
    hurd_hardware_0._collect_uptime_info()
    hurd_hardware_0._collect_selinux_info()
    hurd_hardware_0._collect_pkg_mgr_info()
    hurd_hardware_0

# Generated at 2022-06-24 22:09:35.198015
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware = HurdHardwareCollector._fact_class
    hurd_hardware_0 = HurdHardware(980)
    populated_hurd_hardware = hurd_hardware_0.populate()
    expected_hurd_hardware = {
        'uptime': None,
        'uptime_seconds': None,
        'memfree_mb': None,
        'memtotal_mb': None,
        'swapfree_mb': None,
        'swaptotal_mb': None,
        'mounts': None,
    }
    assert populated_hurd_hardware == expected_hurd_hardware

# Generated at 2022-06-24 22:09:41.932239
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 725
    hurd_hardware_0 = HurdHardware(int_0)
    dict_0 = hurd_hardware_0.populate()
    int_1 = 725
    hurd_hardware_1 = HurdHardware(int_1)
    dict_1 = hurd_hardware_1.populate()
    # assert dict_0 == dict_1
    # dict_2 = dict_0
    # dict_2.update(dict_1)
    # assert dict_0 == dict_2


# Generated at 2022-06-24 22:09:43.137832
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert False  # TODO: implement your test here


# Generated at 2022-06-24 22:09:47.745528
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
  int_0 = 980
  hurd_hardware_0 = HurdHardware(int_0)
  var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:50.473478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:53.184743
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:09:56.546996
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:00.636515
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 449
    hurd_hardware_1 = HurdHardware(int_0)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:10:03.362579
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:04.707090
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    assert True

# Generated at 2022-06-24 22:10:08.067532
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 424
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:10:16.835163
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    # Test the LinuxHardware class up until the error is raised.
    hardware_facts = LinuxHardware.populate(hurd_hardware_0)

# Generated at 2022-06-24 22:10:17.420809
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert hur

# Generated at 2022-06-24 22:10:23.368055
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 842
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.populate()
    print(var_0)


# Generated at 2022-06-24 22:10:25.802806
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_1 = 193
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:10:30.117453
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Case 1
    int_1 = 980
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()
    assert True == isinstance(var_1, dict)
    assert 3 <= len(var_1)



# Generated at 2022-06-24 22:10:33.622283
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 295
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:35.879871
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:10:39.240013
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except:
        assert False, "Unable to execute test_case_0."



# Generated at 2022-06-24 22:10:48.000218
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(980)

# Generated at 2022-06-24 22:10:51.331081
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 981
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = dict()
    var_1['ansible_facts'] = var_0
    return var_1


# Generated at 2022-06-24 22:10:54.239477
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_1 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:03.038168
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 628
    hurd_hardware_1 = HurdHardware(int_0)
    var_0 = hurd_hardware_1.populate()
    assert var_0 == {'uptime': 0, 'uptime_seconds': 0, 'uptime_days': 0, 'uptime_hours': 0, 'uptime_minutes': 0, 'memory_mb': {'real': {'total': 0, 'used': 0, 'free': 0, 'used_percentage': 0, 'free_percentage': 0}, 'swap': {'total': 0, 'used': 0, 'free': 0, 'used_percentage': 0, 'free_percentage': 0}}, 'mounts': {}}

# Generated at 2022-06-24 22:11:08.493023
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:11.181666
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    if (__name__ == '__main__'):
        test_case_0()

# Generated at 2022-06-24 22:11:18.166199
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:21.800377
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 543
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:24.585841
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == 980


# Generated at 2022-06-24 22:11:27.860441
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:37.886182
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import tempfile
    import os
    fd_0, path_0 = tempfile.mkstemp()
    os.close(fd_0)
    os.remove(path_0)
    fd_0, path_1 = tempfile.mkstemp()
    os.close(fd_0)
    os.remove(path_1)
    fd_0, path_2 = tempfile.mkstemp()
    os.close(fd_0)
    os.remove(path_2)
    fd_0, path_3 = tempfile.mkstemp()
    os.close(fd_0)
    os.remove(path_3)
    fd_0, path_4 = tempfile.mkstemp()
    os.close(fd_0)
    os.remove(path_4)


# Generated at 2022-06-24 22:11:40.657589
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 1520
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0.get('uptime') == 1018


# Generated at 2022-06-24 22:11:43.720734
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:47.090515
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 3
    hurd_hardware_0 = HurdHardware(int_0)
    assert type(hurd_hardware_0.populate()) is dict
    assert hurd_hardware_0.populate() == {}

# Generated at 2022-06-24 22:11:59.077636
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)

    # Call method populate of hurd_hardware_0
    with timeout(1):
        res_0 = hurd_hardware_0.populate()

    assert res_0 == {}

test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:12:02.861988
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_1 = 980
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_0.populate()
    assert var_0 == var_1


# Generated at 2022-06-24 22:12:11.371676
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from os import path
    from mock import patch
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.utils.test_utils import mock_open_file_read
    int_0 = 1984
    hurd_hardware_0 = HurdHardware(int_0)
    var_1 = path.exists('/proc/meminfo')
    with patch('ansible_collections.ansible.community.plugins.module_utils.facts.hardware.linux.open', mock_open_file_read(var_1)):
        var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:14.649260
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:19.298309
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    int_1 = 980
    var_1 = hurd_hardware_0.populate(int_1)
    assert var_1.items()

# Generated at 2022-06-24 22:12:21.339849
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_1 = HurdHardware()
    var_0 = hurd_hardware_1.populate()

# Generated at 2022-06-24 22:12:30.710735
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)

    # Run the method
    assert(hurd_hardware_0.populate() != None)
    # Verify that in case of method timeout, a TimeoutError was raised
    with HurdHardware.assertRaises(hurd_hardware_0.populate):
        assert TypeError
    # Verify that method populate() returned a dict type
    assert(type(hurd_hardware_0.populate()) == dict)


# Generated at 2022-06-24 22:12:37.774124
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 338
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = var_0['ansible_memory_mb']
    var_2 = var_0['ansible_swapfree_mb']
    var_3 = var_0['ansible_mounts'][0]['mount']
    assert var_1 == int_0
    assert var_2 == 0
    assert var_3 == '/boot'


# Generated at 2022-06-24 22:12:44.571594
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    i_int = 980
    i_dict = {'ansible_uptime_seconds': 52746}
    i_dict.update({'ansible_memtotal_mb': int(i_int / 1048576), 'ansible_memory_mb': {'nocache': {'used': 29}, 'real': {'total': i_int / 1048576, 'used': i_int / 1048576 - 29}}, 'ansible_swaptotal_mb': 0})
    i_dict.update({'ansible_mounts': []})
    assert HurdHardware(i_int).populate() == i_dict


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 22:12:48.797598
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 461
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:07.905490
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:11.367207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 2821
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert True


# Generated at 2022-06-24 22:13:14.830314
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    try:
        var_0 = hurd_hardware_0.populate()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-24 22:13:19.394338
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    ansible_facts_0 = hurd_hardware_0.populate()
    assert type(ansible_facts_0) is dict
    assert ansible_facts_0.get('ansible_facts') is not None

# Generated at 2022-06-24 22:13:22.396944
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_2 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:25.425886
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:13:30.215965
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    assert isinstance(hurd_hardware_0, HurdHardware)
    assert isinstance(hurd_hardware_0, LinuxHardware)
    assert isinstance(hurd_hardware_0, HardwareCollector)
    assert isinstance(hurd_hardware_0.populate(), dict)


# Generated at 2022-06-24 22:13:32.831089
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 0
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    print(var_0)


# Generated at 2022-06-24 22:13:43.596523
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_1 = 980
    hurd_hardware_1 = HurdHardware(int_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1.get('memory') == {'swap': {'total_mb': 0.0, 'total_gb': 0.0, 'free_mb': 0.0, 'free_gb': 0.0, 'used_mb': 0.0, 'used_gb': 0.0, 'used_percent': None}, 'real': {'total_mb': 980.0, 'total_gb': 0.953674, 'free_mb': 732.0, 'free_gb': 0.716272, 'used_mb': 248.0, 'used_gb': 0.237402, 'used_percent': 25.2}}



# Generated at 2022-06-24 22:13:45.974316
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    

# Generated at 2022-06-24 22:14:22.693059
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 420
    hurd_hardware_0 = HurdHardware(int_0)
    assert type(hurd_hardware_0.populate()) is dict


# Generated at 2022-06-24 22:14:23.567901
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True

test_case_0()

# Generated at 2022-06-24 22:14:30.169076
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 214
    hurd_hardware_0 = HurdHardware(int_0)
    assert hurd_hardware_0.populate() == {'uptime': {'days': 0, 'hours': 0, 'minutes': 0, 'seconds': 214}, 'memory': {'swapfree_mb': None, 'swaptotal_mb': None, 'memtotal_mb': None, 'memfree_mb': None}, 'mounts': {}}


# Generated at 2022-06-24 22:14:31.464702
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert callable(getattr(HurdHardware, "populate"))


# Generated at 2022-06-24 22:14:34.346135
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_3 = 553
    hurd_hardware_3 = HurdHardware(int_3)
    var_3 = hurd_hardware_3.populate()
    assert var_3 == {}


# Generated at 2022-06-24 22:14:38.591766
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:14:40.496161
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:49.140611
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:52.653622
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 544
    hurd_hardware_0 = HurdHardware(int_0)

    try:
        hurd_hardware_0.populate()
    except TimeoutError:
        var_0 = True
    else:
        var_0 = False
    assert var_0


# Generated at 2022-06-24 22:15:01.889678
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_1 = HurdHardware(None)
    var_2 = var_1.populate()
    var_3 = var_2['uptime_seconds']
    var_4 = var_3 == 980
    assert var_4 == True
    var_5 = var_2['uptime_days']
    var_6 = var_5 == 0
    assert var_6 == True
    var_7 = var_2['uptime_hours']
    var_8 = var_7 == 0
    assert var_8 == True
    var_9 = var_2['uptime_minutes']
    var_10 = var_9 == 0
    assert var_10 == True
    var_11 = var_2['memtotal_mb']
    var_12 = var_11 == 8192
    assert var_12 == True
    var

# Generated at 2022-06-24 22:15:45.952334
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 22
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    var_0 = hurd_hardware_0.populate()
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:49.271496
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 =={};

# Generated at 2022-06-24 22:15:59.945735
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    data_0 = {'uptime_seconds': 2.5636638, 'uptime_hours': 0.06872633333333333}
    data_1 = {'swapfree_mb': 0, 'swapfree': 0, 'swaptotal': 0, 'swaptotal_mb': 0, 'memfree_mb': 870, 'memfree': 900210688, 'memtotal': 887500800, 'memtotal_mb': 860}

# Generated at 2022-06-24 22:16:04.370108
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)

    # Test for no exception for function call
    try:
        hurd_hardware_0.populate()
    except TimeoutError:
        pass

# Generated at 2022-06-24 22:16:06.654004
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('<============Test_Case_0============>')
    test_case_0()
    print('<============Test_Case_0============>')


# Generated at 2022-06-24 22:16:10.199413
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        assert callable(HurdHardware.populate)
    except AssertionError as e:
        assert not e, 'Expected false but was true'
    #assert HurdHardware.populate(HurdHardware,<arg>) == <value>, 'Expected call does not give expected result'


# Generated at 2022-06-24 22:16:13.384875
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:16.497866
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not False


# Generated at 2022-06-24 22:16:19.239535
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:28.938329
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 913
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    result = {}
    pos1 = 1
    result[u'memory_mb'], pos1 = u"1332", FakeFile(pos1)
    pos2 = 1
    result[u'total_mem_mb'], pos2 = u"1332", FakeFile(pos2)
    pos3 = 1
    result[u'uptime_seconds'], pos3 = u"18001", FakeFile(pos3)
    pos4 = 1
    result[u'uptime_days'], pos4 = u"0", FakeFile(pos4)
    pos5 = 1
    result[u'uptime_hours'], pos5 = u"5", Fake

# Generated at 2022-06-24 22:17:12.861927
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:15.411952
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    int_0 = 811
    hurd_hardware_0 = HurdHardware(int_0)
    hurd_hardware_0.populate()
    assert True


# Generated at 2022-06-24 22:17:24.447999
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 880
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    int_0 = 120
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    int_0 = 679
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    int_0 = 692
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:31.352348
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    dict_0 = dict()
    str_0 = "key"
    int_1 = 474
    dict_0[str_0] = int_1
    str_1 = "key"
    int_2 = 779
    dict_0[str_1] = int_2
    str_2 = "key"
    int_3 = 634
    dict_0[str_2] = int_3
    str_3 = "key"
    int_4 = 685
    dict_0[str_3] = int_4
    str_4 = "key"
    int_5 = 941
    dict_0[str_4] = int_5
    str_5 = "key"
    int_

# Generated at 2022-06-24 22:17:39.945238
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 959
    hurd_hardware_0 = HurdHardware(int_0)
    int_1 = 982
    hurd_hardware_1 = HurdHardware(int_1)
    hurd_hardware_2 = HurdHardware(int_1)
    hurd_hardware_3 = HurdHardware(int_1)
    hurd_hardware_3._facts = {'system': 'Linux', 'system_dev': 'Linux'}
    hurd_hardware_4 = HurdHardware(int_1)
    hurd_hardware_4._facts = {'system': 'Linux', 'system_dev': 'Linux'}
    hurd_hardware_4._facts = {'system': 'Linux', 'system_dev': 'Linux'}
    hurd_hardware_5 = HurdHardware(int_1)


# Generated at 2022-06-24 22:17:47.003169
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime': {'days': '0', 'hours': '0', 'seconds': '0', 'minutes': '0'}, 'memory': {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 0}, 'mounts': []}

# Generated at 2022-06-24 22:17:55.122204
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    f = open('test/unit/module_utils/facts/hardware/fixtures/kernel', 'r')
    kernel_version = f.read().rstrip()
    f.close()
    f = open('test/unit/module_utils/facts/hardware/fixtures/meminfo', 'r')
    meminfo = f.read()
    f.close()
    f = open('test/unit/module_utils/facts/hardware/fixtures/proc_mounts', 'r')
    proc_mounts = f.read()
    f.close()
    f = open('test/unit/module_utils/facts/hardware/fixtures/uptime')
    uptime = f.read()
    f.close()

# Generated at 2022-06-24 22:17:57.383860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 980
    hurd_hardware_0 = HurdHardware(int_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:58.979405
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    case_0 = test_case_0()
    print(case_0)



# Generated at 2022-06-24 22:18:02.320743
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    int_0 = 471
    hurd_hardware_0 = HurdHardware(int_0)
    int_1 = 597
    hurd_hardware_0.timeout = int_1
    hurd_hardware_0.populate()