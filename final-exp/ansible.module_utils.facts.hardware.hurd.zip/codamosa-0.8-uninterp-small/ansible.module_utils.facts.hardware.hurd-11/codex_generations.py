

# Generated at 2022-06-24 22:08:56.437706
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:08:58.632664
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    assert isinstance(hurd_hardware_collector_0.facts['hardware'], dict)

# Generated at 2022-06-24 22:09:01.133184
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_HurdHardware = HurdHardware()

    # Test if the object can call method 'populate'
    try:
        assert(test_HurdHardware.populate())
    except:
        assert(False)

# Generated at 2022-06-24 22:09:04.319340
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hardware_facts = hurd_hardware.populate()
    assert hardware_facts['uptime_seconds'] >= 0
    assert hardware_facts['uptime_seconds'] > 0

    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0


# Generated at 2022-06-24 22:09:08.720876
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(module_name='ansible.module_utils.facts.hardware.linux')
    # should raise exception as procfs is not available
    exception = None
    try:
        hurd_hardware_0.populate()
    except Exception as e:
        exception = e
    assert(isinstance(exception, TimeoutError))

# Generated at 2022-06-24 22:09:11.734268
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_instance = HurdHardware()
    hurd_hardware_instance.populate()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:09:13.129118
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(None)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:21.701779
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware(module=None)
    collected_facts_0 = {'os_family': 'GNU/kFreeBSD'}
    x = hurd_hardware_0.populate(collected_facts=collected_facts_0)
    assert x['uptime_seconds'] >= 0
    assert x['uptime_hours'] >= 0
    assert x['uptime_days'] >= 0
    assert x['memory_mb']['real']['total'] >= 0
    assert x['mounts'] == [
        {
            'mount': '/',
            'size_total': 1048576,
            'device': '/dev/hda1'
        }
    ]

# Generated at 2022-06-24 22:09:22.587625
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:09:27.018039
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = None
    actualResult = hurd_hardware.populate(collected_facts)
    assert 'uptime' in actualResult
    assert 'uptime_seconds' in actualResult
    assert 'active_processor_count' in actualResult
    assert 'total_processor_count' in actualResult
    assert 'memTotal' in actualResult
    assert 'mounts' in actualResult

# Generated at 2022-06-24 22:09:33.303939
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

    # Test for line of code test_HurdHardware_populate (line 65 of file)


# Generated at 2022-06-24 22:09:36.918470
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:38.465982
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert callable(HurdHardware.populate)


# Generated at 2022-06-24 22:09:42.527310
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:46.196687
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:54.220210
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

    string_0 = 'Xe_g'
    string_1 = 'pE~`'
    tuple_0 = (string_0, string_1)
    string_2 = 'i(Mw'
    float_0 = 0.138251347063
    dict_0 = {
        string_0: float_0,
        string_2: tuple_0
    }
    assert (var_0 == dict_0)

# Generated at 2022-06-24 22:09:58.463550
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Case 0: No method 'get_mount_facts'
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:02.182816
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    # Test failure message:
    # 	Unexpected exception raised:
    # 	This is probably not a GNU/Hurd host

# Generated at 2022-06-24 22:10:03.705655
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()
    test_case_1()

# Generated at 2022-06-24 22:10:09.291056
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'Yd,<k]gj%[U\We`Uy'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:17.378116
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)

    # Call method to test
    var_0 = hurd_hardware_0.populate()



test_case_0()

# Generated at 2022-06-24 22:10:20.219413
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:28.371252
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    # Test the 'platform' attribute exist
    if not hasattr(hurd_hardware_0, 'platform'):
        raise AssertionError('HurdHardware.platform is not a property')

    # Test the 'platform' attribute is assignable
    if not isinstance(hurd_hardware_0.platform, str):
        raise AssertionError('HurdHardware.platform is not a string')

    # Test the 'platform' attribute is read-only
    with pytest.raises(AttributeError):
        hurd_hardware_0.platform = 'JVW~aRjD}9rvQ8W1'


# Generated at 2022-06-24 22:10:31.026694
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'bfoS\nna9'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:35.162961
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}, 'var_0 = %s' % (var_0)

# Generated at 2022-06-24 22:10:40.792101
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '!;E9|UeN]2Nlb^0`'
    hurd_hardware_0 = HurdHardware(str_0)
    collected_facts = {}
    var_0 = hurd_hardware_0.populate(collected_facts)
    assert len(var_0) == 8
    assert 'get_uptime_facts' in var_0
    assert 'get_memory_facts' in var_0
    assert 'get_mount_facts' in var_0

# Generated at 2022-06-24 22:10:43.914334
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '8i#yG:5R5(5S=K:(0zU^'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:48.927537
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ''
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None


# Generated at 2022-06-24 22:10:54.422312
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None, "Returned value (%s) of method populate of class HurdHardware is not (None)." % var_0
 

# Generated at 2022-06-24 22:11:04.157678
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:09.874648
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:11.983090
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware('str_arg_0')
    hurd_hardware.populate()


# Generated at 2022-06-24 22:11:14.803727
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:17.000339
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.populate(str_0)


# Generated at 2022-06-24 22:11:26.610898
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '/Hurd/Store/Files/servers/fsys/exec/mount'
    str_1 = 'g\x0b\x01\x1b'
    hurd_hardware_0 = HurdHardware(str_0)
    cmd_0 = [str_0, '-p']
    hurd_hardware_0._exec_cmd(cmd_0)
    cmd_1 = [str_0, '-p']
    hurd_hardware_0._exec_cmd(cmd_1)
    cmd_2 = [str_0, '-p']
    hurd_hardware_0._exec_cmd(cmd_2)
    cmd_3 = [str_0, '-p']
    hurd_hardware_0._exec_cmd(cmd_3)

# Generated at 2022-06-24 22:11:28.142868
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:11:32.328299
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:11:35.840479
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:37.840572
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:40.028335
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '/: '
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:11:46.407411
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:49.453327
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ')v5@GAzW!PBjf2V'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:50.535052
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:12:00.027165
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'kYp5$5Z`[#xa,,B'
    str_1 = '6E-Oyb@A0.0]2P{'
    hurd_hardware_0 = HurdHardware(str_1)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:04.417658
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Test: populate - no parameters')
    test_case_0()
    print('Test: populate - OK')

if __name__ == '__main__':
    print('Test started')
    test_HurdHardware_populate()
    print('Test finished')

# Generated at 2022-06-24 22:12:09.223817
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None
    # assert var_0 == ''

# Generated at 2022-06-24 22:12:12.794785
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:17.097563
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'q;Jb!%|TzZQT#'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:22.894290
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'foobar'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    # Test if instance is collection.MutableMapping
    # mostly it is a dict
    assert isinstance(var_0, dict)
    # Test if it is not empty
    # mostly it has at least one record
    assert len(var_0) > 0

# Generated at 2022-06-24 22:12:28.201455
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'd,y<Bt'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert 'ansible_mounts' in var_0



# Generated at 2022-06-24 22:12:40.866590
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '\x01\x10y"\x1a\x02'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:46.411283
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'b;kCT}&{^lZPx|'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1 == {
        'mounts': [
            {
                'device': '/dev/sda1',
                'mount': '/',
                'size_available': 2097152,
                'size_total': 524288,
                'fstype': 'ext3'
            }
        ],
        'memfree_mb': 123,
        'memtotal_mb': 456,
        'uptime_seconds': 12345678,
        'uptime_seconds_pretty': '14 days, 6:56:05 hours'
    }


# Generated at 2022-06-24 22:12:50.009050
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'QPt=I.qNn'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:57.290866
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'U5z6JDiM6C'
    hurd_hardware_0 = HurdHardware(str_0)

    str_1 = 'JBP8G7xu@F;Y+'
    var_0 = str_1
    hurd_hardware_0.command_timeout = var_0

    str_2 = 'crZT7Gd:0?R,G'
    var_1 = str_2
    hurd_hardware_0.boot = var_1

    str_3 = 'g+1L3qH5@S9Mz5'
    var_2 = str_3
    hurd_hardware_0.uptime = var_2

    str_4 = 'Y/7;JBjFsdA'
    var_3 = str_4
    hurd_hardware

# Generated at 2022-06-24 22:12:58.201237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert key == None


# Generated at 2022-06-24 22:13:04.914497
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test without error
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    # Test with error
    hurd_hardware_1 = HurdHardware(str_0)
    try:
        hurd_hardware_1.populate()
    except TimeoutError:
        pass


# Generated at 2022-06-24 22:13:08.962023
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:10.926445
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware('A')
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:14.305983
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'q3P'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:23.608028
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # get facts from generic Linux module
    str_0 = 'gpoW:S*0yDf'
    linux_hardware_0 = LinuxHardware(str_0)
    linux_facts = linux_hardware_0.populate()
    # instantiate HurdHardware with string 'MbNf;HJ,fgyZk:u' as parameter
    str_1 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_1)
    var_0 = hurd_hardware_0.populate()
    # assert that the uptime facts are the same
    assert linux_facts['uptime_ms'] == var_0['uptime_ms']
    assert linux_facts['uptime_seconds'] == var_0['uptime_seconds']
   

# Generated at 2022-06-24 22:13:31.536783
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:32.127349
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 1 == 1

# Generated at 2022-06-24 22:13:37.676523
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'jKDuszQQQn`qb=c'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

    assert True

# Generated at 2022-06-24 22:13:45.154945
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    i = 0
    for i in var_0:
        print("%s: %s" % (i, var_0[i]))

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:13:48.595986
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:54.066876
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'Zg4c$#W&B3+qw7J5'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert str_0 == 'Zg4c$#W&B3+qw7J5'


# Generated at 2022-06-24 22:13:57.079366
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:01.502698
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '8V_Ww1'
    hurd_hardware_0 = HurdHardware(str_0)
    int_0 = 10
    hurd_hardware_0.mount_timeout = int_0
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:14:06.138452
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:07.301424
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:14:15.437012
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:14:21.452925
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert not var_0

if __name__ == '__main__':
    test_case_0()

    test_HurdHardware_populate()

# Generated at 2022-06-24 22:14:27.915049
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 ==  {'uptime_seconds': 0,
                      'uptime_hours': 0,
                      'uptime_days': 0,
                      'uptime': '',
                      'mounts': {},
                      'memfree_mb': 0,
                      'memtotal_mb': 0}

# Generated at 2022-06-24 22:14:28.650899
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-24 22:14:37.584666
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = ''
    str_1 = 'MbNf;HJ,fgyZk:u'
    str_2 = 'MbNf;HJ,fgyZk:u'
    str_3 = 'MbNf;HJ,fgyZk:u'
    str_4 = 'MbNf;HJ,fgyZk:u'
    str_5 = 'MbNf;HJ,fgyZk:u'
    str_6 = 'MbNf;HJ,fgyZk:u'
    str_7 = 'MbNf;HJ,fgyZk:u'
    str_8 = 'MbNf;HJ,fgyZk:u'

# Generated at 2022-06-24 22:14:41.543076
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    str_1 = 'Oo<LH=bgQ'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_1 = HurdHardware(str_1)
    hurd_hardware_1.populate()


# Generated at 2022-06-24 22:14:42.689242
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()



# Generated at 2022-06-24 22:14:53.237859
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'Znl.g?<#wc4Ti3@I'
    hurd_hardware_1 = HurdHardware(str_1)
    assert str_1 == hurd_hardware_1.platform
    assert str_1 == hurd_hardware_1._platform
    assert not isinstance(hurd_hardware_1._fact_class, type(hurd_hardware_1))
    assert not isinstance(hurd_hardware_1._fact_class, type(str_1))
    assert not isinstance(hurd_hardware_1._platform, type(hurd_hardware_1))
    assert not isinstance(hurd_hardware_1._platform, type(str_1))
    assert isinstance(hurd_hardware_1, type(hurd_hardware_1))

# Generated at 2022-06-24 22:15:00.256702
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '*T#zA{c%X9"/ <|C'
    hurd_hardware_0 = HurdHardware(str_0)
    uptime_1 = HurdHardware.get_uptime_facts()
    memory_1 = HurdHardware.get_memory_facts()
    mount_1 = HurdHardware.get_mount_facts()
    var_0 = hurd_hardware_0.populate(uptime_1, memory_1, mount_1)


if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:15:03.577722
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:15.391605
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test case 0
    test_case_0()

# Unit test body for class HurdHardwareCollector

# Generated at 2022-06-24 22:15:18.679771
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:21.583754
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:26.270775
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)

    assert type(hurd_hardware_0.populate()) is dict


# Generated at 2022-06-24 22:15:27.247838
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:15:29.271338
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:34.342410
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    print(var_0)

test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:15:35.817715
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    case_0 = test_case_0


# Generated at 2022-06-24 22:15:39.265103
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'GcT`XGl`Z'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:43.874821
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()
    assert 'ansible_all_ipv4_addresses' in hurd_hardware_0


# Generated at 2022-06-24 22:16:06.694721
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_case_0()
    except SystemExit:
        raise Exception('test_case_0() generated a SystemExit exception')
    else:
        pass


# Generated at 2022-06-24 22:16:09.374950
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:20.500000
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:16:21.524507
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 0 == 0

# Generated at 2022-06-24 22:16:25.607691
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '0*RlW5z(M5'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None, var_0


# Generated at 2022-06-24 22:16:29.607308
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'

# Generated at 2022-06-24 22:16:33.010276
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    arg = 'r,-@!$&#wNk*%T?T'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:36.054063
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_2 = 'HurdHardware'
    hurd_hardware_2 = HurdHardware(str_2)
    var_1 = hurd_hardware_2.populate()
    assert var_1 is None


# Generated at 2022-06-24 22:16:42.578138
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'y`FbQSt_H$a["AQV'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    expected_value = {}
    expected_value['vendor'] = None
    expected_value['product'] = None

# Generated at 2022-06-24 22:16:45.269035
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'RQaDd!hXll&(@<d'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:33.568914
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.populate()
    assert var_0 == var_1


# Generated at 2022-06-24 22:17:39.179118
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'uptime_days': 0, 'uptime_hours': 0, 'uptime_seconds': 0}, 'Return value mismatch'

# Generated at 2022-06-24 22:17:43.605944
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'YjBbs?#<}O,QA^w'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:46.327795
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'mg8W,RGw'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:49.226531
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_1 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:17:51.916308
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'p,aDmIjK@nO|X;[:q'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:55.176851
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    assert var_1 == {'uptime_seconds': 267048.0, 'memtotal_mb': 640.0}


# Generated at 2022-06-24 22:17:57.833063
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'hurd_hardware_1'
    hurd_hardware_0 = HurdHardware(str_0)
    result_0 = hurd_hardware_0.populate()
    assert result_0 == {}

# Generated at 2022-06-24 22:18:00.885067
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populat

# Generated at 2022-06-24 22:18:03.604489
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = 'MbNf;HJ,fgyZk:u'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()

    assert(True)


# Generated at 2022-06-24 22:18:44.553467
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-24 22:18:53.364539
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_fact_subclass = 'Xe,T'
    str_uptime_facts = 'm,m,'
    str_memory_facts = 'r,r,'
    str_mount_facts = 'Nw^k{U,}f'
    str_hardware_facts = '{,{,'
    str_result = 'KwGH;nU+'
    hurd_hardware_0 = HurdHardware(str_fact_subclass)
    uptime_facts = {str_uptime_facts: str_uptime_facts}
    memory_facts = {str_memory_facts: str_memory_facts}
    mount_facts = {str_mount_facts: str_mount_facts}
    hardware_facts = {str_hardware_facts: str_hardware_facts}
    assert hurd_hardware_0