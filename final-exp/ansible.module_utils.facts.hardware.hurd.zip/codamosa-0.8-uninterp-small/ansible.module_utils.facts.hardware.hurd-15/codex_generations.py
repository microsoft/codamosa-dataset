

# Generated at 2022-06-24 22:08:56.718171
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    # Test no exception is raised
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:08:57.893884
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hu_hardware = HurdHardware()
    hu_hardware.populate()


# Generated at 2022-06-24 22:09:05.728848
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Arrange: simulator for OS type,  etc.
    HurdHardware._platform = 'GNU'

    # System has 6 GB of RAM, 96% occupied

# Generated at 2022-06-24 22:09:07.492221
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_obj.populate()

# Generated at 2022-06-24 22:09:08.886700
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-24 22:09:10.529152
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:16.440573
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    # Test if keys are present
    assert 'uptime' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'uptime_hours' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'mounts' in hardware_facts

# Generated at 2022-06-24 22:09:17.797163
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:21.796869
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # No other information is available
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:09:24.256402
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdHardwareInstance = HurdHardware()
    hurdHardwareInstance.populate()

test_case_0()

# Generated at 2022-06-24 22:09:26.860966
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass # This test always passes

# Generated at 2022-06-24 22:09:30.580827
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = None
    hurd_hardware_1 = hurd_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:09:32.285513
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    hurd_hardware_0.populate()



# Generated at 2022-06-24 22:09:33.422651
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware = HurdHardware()
    HurdHardware.populate()

# Generated at 2022-06-24 22:09:36.697305
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    hurd_hardware_obj.populate()


if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:09:44.670167
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert (hurd_hardware.populate()['system_uptime']['seconds'] >= 0)
    assert (hurd_hardware.populate()['system_uptime']['minutes'] >= 0)
    assert (hurd_hardware.populate()['system_uptime']['hours'] >= 0)
    assert (hurd_hardware.populate()['system_uptime']['days'] >= 0)
    # datetime.datetime.now() is usually in UTC, for GNU system
    # the timezone would be UTC
    assert (hurd_hardware.populate()['system_uptime']['timezone'] == 'UTC')

# Generated at 2022-06-24 22:09:54.417877
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware({'DEFAULT_HOSTNAME': 'test_hostname'})
    hardware_facts = hurd_hardware.populate()

    assert hardware_facts['uptime']['days'] > 0
    assert hardware_facts['uptime']['hours'] >= 0
    assert hardware_facts['uptime']['minutes'] >= 0
    assert hardware_facts['uptime']['seconds'] >= 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0


# Generated at 2022-06-24 22:09:57.058768
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    assert hurd_hardware_0.populate() is not False


# Generated at 2022-06-24 22:09:59.025304
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class_0 = HurdHardware()
    class_0.populate()


# Generated at 2022-06-24 22:10:03.055209
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_populate_return_value = hurd_hardware.populate()
    assert hurd_hardware_populate_return_value


# Generated at 2022-06-24 22:10:07.184591
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True



if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:10.087964
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initialization
    # Instantiation
    hurd_hardware_0 = HurdHardware('/proc')

    # Method populate
    # Initialization
    hurd_hardware_0.populate()



# Generated at 2022-06-24 22:10:12.653788
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
# --------------------------------------------------------------------------------

# Generated at 2022-06-24 22:10:16.687000
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:18.736045
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    params = ['|']
    test_0 = HurdHardware(params[0])
    var_0 = test_0.populate()

# Generated at 2022-06-24 22:10:22.174144
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:25.498188
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:29.954253
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    # Input parameters:
    # collected_facts: {}
    var_0 = hurd_hardware_0.populate({})


test_case_0()
test_HurdHardware_populate()

# Generated at 2022-06-24 22:10:33.720805
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '4'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None


# Generated at 2022-06-24 22:10:37.726008
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:10:44.142696
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    string = '|'
    hurd_hardware_0 = HurdHardware(string)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:10:51.330513
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    val_1 = hurd_hardware_0.get_uptime_facts()
    val_3 = hurd_hardware_0.get_memory_facts()
    hurd_hardware_0.get_mount_facts()
    var_4 = hurd_hardware_0.populate(val_1, val_3)
    return var_4


# Generated at 2022-06-24 22:10:54.774627
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Arrange
    hurd_hardware_0 = HurdHardware(str_0)
    # Assume
    # Act
    var_1 = hurd_hardware_0.populate()
    # Assert


# Generated at 2022-06-24 22:10:59.246318
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:10:59.816207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert 1 == 1

# Generated at 2022-06-24 22:11:02.930138
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:05.919579
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:07.858109
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:11:15.176237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = '!%s' % '!'
    str_2 = '|'
    hurd_hardware_1 = HurdHardware(str_2)
    var_1 = hurd_hardware_1.populate()
    str_3 = '='
    hurd_hardware_2 = HurdHardware(str_3)
    var_2 = hurd_hardware_2.populate()
    str_4 = 'F'
    hurd_hardware_3 = HurdHardware(str_4)
    var_3 = hurd_hardware_3.populate()
    str_5 = '}'
    hurd_hardware_4 = H

# Generated at 2022-06-24 22:11:17.873679
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:11:28.282750
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is None


# Generated at 2022-06-24 22:11:33.502859
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = HurdHardware('|')
    var_1 = var_0.populate()
    assert var_1 == {'uptime_hours': 0, 'uptime_seconds': 0, 'uptime_days': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0}

# Generated at 2022-06-24 22:11:35.193712
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert callable(getattr(HurdHardware, "populate", None))


# Generated at 2022-06-24 22:11:39.952025
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'

    hurd_hardware_0 = HurdHardware(str_0)

    var_0 = hurd_hardware_0.populate()

    str_1 = '|'

    hurd_hardware_1 = HurdHardware(str_1)

    var_1 = hurd_hardware_1.populate()

    assert var_0 == var_1


# Generated at 2022-06-24 22:11:42.144686
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:11:45.219469
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    var_0 = '|'
    hurd_hardware_0 = HurdHardware(var_0)
    var_1 = hurd_hardware_0.populate()
    assert var_1 is not None


# Generated at 2022-06-24 22:11:47.135833
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:52.386192
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = '|'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    str_2 = '|'
    hurd_hardware_2 = HurdHardware(str_2)
    var_2 = hurd_hardware_2.populate()

# Generated at 2022-06-24 22:11:56.246441
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:12:04.678931
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = type(var_0)
    assert(var_1 == dict)
    assert(type(var_0['memory']) == dict)
    assert(type(var_0['memory']['swapfree_mb']) == int)
    assert(type(var_0['memory']['memfree_mb']) == int)
    assert(type(var_0['memory']['swaptotal_mb']) == int)
    assert(type(var_0['memory']['memtotal_mb']) == int)
    assert(type(var_0['mounts']) == list)

# Generated at 2022-06-24 22:12:21.661324
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:23.699584
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # TODO: percona-server-server in the binpkgs_file cannot be imported,
    # that's why it remains untested
    assert True


# Generated at 2022-06-24 22:12:27.697257
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:33.468446
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    # Class instance hurd_hardware_0 is of type HurdHardware
    # Assert isinstance(arg_0, type(var_0))
    assert isinstance(hurd_hardware_0, type(var_0))


# Generated at 2022-06-24 22:12:37.421289
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_1 = '|'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()
    print(var_1)

# Generated at 2022-06-24 22:12:38.858139
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()
    test_case_0()

# Generated at 2022-06-24 22:12:43.500175
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:12:46.587458
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:52.621422
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.get_memory_facts = MagicMock(return_value='|')
    hurd_hardware_0.get_mount_facts = MagicMock(return_value=dict())
    hurd_hardware_0.get_uptime_facts = MagicMock(return_value=dict())
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:59.441144
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

  # Test case 0
  str_0 = '|'
  hurd_hardware_0 = HurdHardware(str_0)
  var_0 = hurd_hardware_0.populate()
  assert True
  #
  # Test case 1
  str_0 = '|'
  hurd_hardware_0 = HurdHardware(str_0)
  # dict_0 = { "ansible_uptime_seconds": None, "ansible_uptime_hours": None, "ansible_date_time": { "date": None, "time": None, "epoch": None }, "ansible_uptime_days": None, "ansible_uptime_minutes": None, "ansible_uptime_hours_long": None, "ansible_uptime_days_long": None, "ansible_uptime_minutes

# Generated at 2022-06-24 22:13:38.337150
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Variables to feed the test case
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)

    # The following lines are needed to cover the method.
    # Please, don't remove them.
    hurd_hardware_0.populate()

    # We are sure the method is covered, so we don't need to
    # assert anything.
    pass


# Generated at 2022-06-24 22:13:39.535083
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:13:42.805900
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:46.237884
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()



# Generated at 2022-06-24 22:13:53.050418
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['ansible_uptime_seconds'] == 611277
    assert var_0['ansible_uptime_days'] == 7
    assert var_0['ansible_uptime_hours'] == 1
    assert var_0['ansible_uptime_minutes'] == 45
    assert var_0['ansible_memory_mb']['real']['total'] == 1820
    assert var_0['ansible_memory_mb']['swap']['total'] == 2047

# Generated at 2022-06-24 22:13:53.964236
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True == False


# Generated at 2022-06-24 22:13:54.835670
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:13:57.211021
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:05.977515
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['memtotal_mb'] == 0
    assert var_0['memfree_mb'] == 0
    assert var_0['swaptotal_mb'] == 0
    assert var_0['swapfree_mb'] == 0
    assert var_0['mounts'][0]['size_total'] != 0
    assert var_0['mounts'][0]['size_available'] != 0
    assert var_0['mounts'][0]['size_used'] != 0


# Generated at 2022-06-24 22:14:12.106043
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'uptime_seconds': 0}


# Generated at 2022-06-24 22:15:29.788581
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    str_1 = '|'
    hurd_hardware_1 = HurdHardware(str_1)
    var_1 = hurd_hardware_1.populate()

# Generated at 2022-06-24 22:15:33.948230
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
# END Tests for HurdHardware


# BEGIN Tests for HurdHardwareCollector

# Generated at 2022-06-24 22:15:38.441453
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)
    assert var_0


# Generated at 2022-06-24 22:15:40.714105
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '='
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:50.065788
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:50.912115
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:15:53.051416
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Test for method populate of class HurdHardware')
    test_case_0()

# Generated at 2022-06-24 22:15:56.880344
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:16:00.193694
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()

# Generated at 2022-06-24 22:16:01.413429
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:18:42.529668
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:44.799786
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:18:53.554198
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    str_0 = '|'
    hurd_hardware_0 = HurdHardware(str_0)
    var_0 = hurd_hardware_0.populate()
    assert "uptime_seconds" in var_0
    assert 0 < var_0["uptime_seconds"]
    assert "swapfree_mb" in var_0
    assert "swaptotal_mb" in var_0
    assert "memfree_mb" in var_0
    assert "memtotal_mb" in var_0
    assert var_0["memtotal_mb"] > 0
    assert "mounts" in var_0
    assert isinstance(var_0["mounts"], list)
    assert "device" in var_0["mounts"][0]
    assert "mount" in var_0["mounts"][0]