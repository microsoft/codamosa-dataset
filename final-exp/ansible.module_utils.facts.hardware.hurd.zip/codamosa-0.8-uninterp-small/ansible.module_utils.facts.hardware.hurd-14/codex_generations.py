

# Generated at 2022-06-24 22:09:05.565455
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)

    # Set facts to a known value

# Generated at 2022-06-24 22:09:11.353752
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    collected_facts_0 = {}
    hurd_hardware_populated_0 = hurd_hardware_0.populate(collected_facts_0)
    assert hurd_hardware_populated_0['uptime_seconds'] == 0
    assert 'memory_mb' in hurd_hardware_populated_0
    assert 'mounts' in hurd_hardware_populated_0

# Generated at 2022-06-24 22:09:19.057767
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Input parameters
    collected_facts_0 = {}

    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)

    # Invoke method
    result = hurd_hardware_0.populate(collected_facts_0)

    # Verify Expected Result
    expected_result = {'ansible_memfree_mb': 57, 'ansible_memtotal_mb': 154, 'ansible_uptime_seconds': 567,
                       'ansible_mounts': [{'mount': '/', 'device': '/dev/sda1', 'fstype': 'ext2fs', 'options': 'rw,noatime'}]}


# Generated at 2022-06-24 22:09:23.991916
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:09:28.620025
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    assert not isinstance(hurd_hardware_0.populate(), dict)



# Generated at 2022-06-24 22:09:38.613562
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x8a[\xba\xa1\x0b\x8e\xdc\xe9\xfa\xd9'
    hurd_hardware_0 = HurdHardware(bytes_0)
    collected_facts = {
        'ansible_product_serial': 'bba0ba54',
        'ansible_system': 'GNU/Hurd',
        'ansible_machine_id': 'abcca6ea7c2542e5a422a8e5c49f9921',
        'ansible_lsb': {
            'major_release': '',
            'description': '',
            'id': '',
            'release': '',
            'codename': '',
            'distributor_id': ''
        }
    }
    result_0 = hurd

# Generated at 2022-06-24 22:09:49.471098
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_1 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_1 = HurdHardware(bytes_1)
    collected_facts = {}
    expected_facts = {}
    expected_facts['uptime_seconds'] = int(b'\xab\xd6', 16)
    expected_facts['uptime_hours'] = int(b'\xab\xd6', 16) / 3600
    expected_facts['uptime_days'] = int(b'\xab\xd6', 16) / (3600*24)
    expected_facts['totalmem'] = int(b'\xca2', 16) * 1024
    expected_facts['memfree'] = int(b'g\xe6', 16) * 1024
    output = hurd_hard

# Generated at 2022-06-24 22:09:55.316895
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)

    # Test with no args
    collected_facts_0 = {}
    hurd_hardware_0.populate(collected_facts_0)
    assert collected_facts_0['ansible_system_vendor'] == 'Neverware'


# Generated at 2022-06-24 22:09:59.452940
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    collected_facts = None
    hurd_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:10:09.553569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    collected_facts_0 = dict()
    collected_facts_0['cpu_num'] = 4
    collected_facts_0['mem_size'] = 1073741824
    collected_facts_0['manufacturer'] = 'FUJITSU SIEMENS'
    collected_facts_0['product_name'] = 'PRIMERGY TX300 S4'
    collected_facts_0['virtualization_type'] = 'xen'

# Generated at 2022-06-24 22:10:19.132686
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # test case for success
    hurd_hardware_0 = HurdHardware()
    collected_facts = dict()
    assert hurd_hardware_0.populate(collected_facts) == True

    # test case for failure
    hurd_hardware_1 = HurdHardware()
    collected_facts = dict()
    assert hurd_hardware_1.populate(collected_facts) == True

# Generated at 2022-06-24 22:10:23.084031
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0_populate = hurd_hardware_0.populate()
    assert type(hurd_hardware_0_populate.get('system_memory')) == type(dict())
    assert len(hurd_hardware_0_populate.keys()) == 4


# Generated at 2022-06-24 22:10:31.976459
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

    module_return_value_0 = {}
    module_return_value_1 = {}
    module_return_value_2 = {}
    module_return_value_3 = {}
    module_return_value_4 = {}
    module_return_value_5 = {}
    module_return_value_6 = {}
    module_return_value_7 = {}

    def side_effect_0(*args, **kwargs):
        return module_return_value_0

    def side_effect_1(*args, **kwargs):
        return module_return_value_1

    def side_effect_2(*args, **kwargs):
        return module_return_value_2

    def side_effect_3(*args, **kwargs):
        return module_return_value_

# Generated at 2022-06-24 22:10:39.767131
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test case where file /proc/meminfo exists, but has no content
    mocked_return_values = {
        '/proc/mounts': None,
        '/proc/meminfo': None
    }

    mocked_execute_command = mock.MagicMock(side_effect=lambda *args: mocked_return_values[args[0]])
    mocked_exists = mock.MagicMock(side_effect=lambda *args: True)

    # Create the object
    hurd_hardware_0 = HurdHardware(mocked_execute_command, mocked_exists)

    # Test
    hardware_facts = hurd_hardware_0.populate()

    assert hardware_facts == {}

# Generated at 2022-06-24 22:10:48.138594
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hurd_hardware_object = HurdHardware()

    # Call method
    hurd_hardware_populate_facts = hurd_hardware_object.populate()

    # Assert
    assert type(hurd_hardware_populate_facts) is dict
    assert 'cpu' in hurd_hardware_populate_facts
    assert 'mem_swap_mb' in hurd_hardware_populate_facts
    assert 'uptime_seconds' in hurd_hardware_populate_facts
    assert 'mounts' in hurd_hardware_populate_facts

    # Assert the type of each facts
    assert type(hurd_hardware_populate_facts['cpu']) is dict
    assert type(hurd_hardware_populate_facts['mem_swap_mb']) is dict

# Generated at 2022-06-24 22:10:50.071243
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    facts = hh.populate()
    assert facts

# Generated at 2022-06-24 22:10:52.323430
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
  hurd_hardware_0 = HurdHardware(module=None)
  assert isinstance(hurd_hardware_0.populate(), dict)

# Generated at 2022-06-24 22:10:58.225343
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_1 = hurd_hardware_collector_1._fact_class()
    gathered_facts = hurd_hardware_1.populate()
    assert 'memory' in gathered_facts
    assert 'mounts' in gathered_facts
    assert 'uptime' in gathered_facts


"""
    hurd_hardware = HurdHardware()
    gathered_facts = hurd_hardware.populate()

    assert 'memory' in gathered_facts
    assert 'mounts' in gathered_facts
    assert 'uptime' in gathered_facts
"""

# Generated at 2022-06-24 22:11:02.577442
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    collected_facts = {}
    hurd_hardware_obj.populate(collected_facts)
    assert collected_facts == {'uptime': 90429, 'uptime_days': 1, 'uptime_hours': 1, 'uptime_seconds': 90429, 'uptime_minutes': 15}

# Generated at 2022-06-24 22:11:04.784484
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:11:12.726096
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Method arguments:
    #   collected_facts:

    # Test with invalid argument:
    #  collected_facts = None
    #  Expected result:

    # Test with valid argument:
    collected_facts = {}
    #  Expected result:

    try:
        HurdHardware.populate(collected_facts=collected_facts)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 22:11:22.026988
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    collected_facts = {}
    collected_facts_ret = {}
    hardware_facts = {}
    uptime_facts = {}
    memory_facts = {}
    mount_facts = {}
    mount_facts_ret = {}
    hurd_hardware_0.populate(collected_facts)
    hurd_hardware_0.populate(collected_facts_ret)
    hurd_hardware_0.populate(hardware_facts)
    hurd_hardware_0.populate(uptime_facts)
    hurd_hardware_0.populate(memory_facts)
    hurd_hardware_0.populate(mount_facts)
    hurd_hardware_0.populate(mount_facts_ret)

# Generated at 2022-06-24 22:11:24.997495
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_1 = hurd_hardware_0.populate()
    assert 'memfree_mb' in hurd_hardware_1

# Generated at 2022-06-24 22:11:35.450038
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Initialize a HurdHardware object
    hurd_hardware = HurdHardware()

    # Populate the hurd hardware object with test data
    hurd_hardware.uptime_facts = dict(
        idle_time = 12.34
    )
    hurd_hardware.memory_facts = dict(
        virtual_memory = dict(
            total = 1234
        ),
        swap_memory = dict(
            total = 5678
        )
    )
    hurd_hardware.mount_facts = dict(
        mountpoints = dict(
            root = dict(
                options = dict(
                    size = 1
                )
            )
        )
    )

    # Call the populate method with an empty dictionary
    hurd_hardware.populate({})


# Generated at 2022-06-24 22:11:39.495397
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an object of class HurdHardware
    hurd_hardware_obj = HurdHardware()
    # Pass an object of class HurdHardwareCollector as argument to function populate
    hurd_hardware_collector_obj = HurdHardwareCollector()
    hurd_hardware_obj.populate(hurd_hardware_collector_obj)

# Generated at 2022-06-24 22:11:48.175601
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0_dict = hurd_hardware_0.populate()
    assert isinstance(hurd_hardware_0_dict, dict)
    assert 'uptime' in hurd_hardware_0_dict
    assert 'uptime_seconds' in hurd_hardware_0_dict
    assert isinstance(hurd_hardware_0_dict['uptime_seconds'], int)
    assert isinstance(hurd_hardware_0_dict['uptime'], str)
    assert 'swapfree_mb' in hurd_hardware_0_dict
    assert isinstance(hurd_hardware_0_dict['swapfree_mb'], int)
    assert 'memfree_mb' in hurd_hardware_0_dict

# Generated at 2022-06-24 22:11:50.535096
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_obj = HurdHardware()
    result = hurd_hardware_obj.populate()
    print(result)

# Generated at 2022-06-24 22:11:53.460383
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware.populate()

# Generated at 2022-06-24 22:11:56.539272
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print('Starting test_HurdHardware_populate')

    ret_val = HurdHardware().populate()

    print('test_HurdHardware_populate returns:')
    print(ret_val)


# Generated at 2022-06-24 22:11:58.754487
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:11.222632
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_0 = HurdHardwareCollector()
    hurd_hardware_0 = HurdHardware()
    
    res_mock = MagicMock()
    res_mock.return_value = {'virtualization_type': 'nope'}

    with patch.object(hurd_hardware_0, '_get_virtual', res_mock):
        with patch.object(HurdHardware, '_filter_sysfs', MagicMock(return_value=True)):
            res_mock.return_value = {'virtualization_type': 'nope'}

# Generated at 2022-06-24 22:12:13.276268
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert(hurd_hardware.populate() != {})

# Generated at 2022-06-24 22:12:15.884050
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector_1 = HurdHardwareCollector()
    hurd_hardware_collector_1.populate()

# Generated at 2022-06-24 22:12:21.593660
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    linux_hardware_0 = LinuxHardware()
    assert linux_hardware_0.get_memory_facts()
    assert linux_hardware_0.get_mount_facts()
    assert linux_hardware_0.get_uptime_facts()
    linux_hardware_0.populate()

# Generated at 2022-06-24 22:12:27.194287
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()

# Generated at 2022-06-24 22:12:34.979402
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:12:38.257782
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:12:41.827591
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:12:46.125791
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test that getting facts has no side effect
    """
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 22:12:56.365030
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Mock module_utils.facts.hardware.linux.LinuxHardware.get_uptime_facts()
    to return a mock uptime fact. Mock module_utils.facts.hardware.linux.LinuxHardware.get_memory_facts()
    to return a mock memory fact. Test the module_utils.facts.hardware.linux.LinuxHardware
    implementation of module_utils.facts.hardware.base.HardwareCollector.populate()
    using these mock facts, and assert that a dictionary containing both memory
    and uptime facts is returned by calling module_utils.facts.hardware.linux.LinuxHardware.populate().
    """
    expected_result = {
        'dummy_memory_fact': 'dummy_memory_factvalue',
        'dummy_uptime_fact': 'dummy_uptime_factvalue',
    }


# Generated at 2022-06-24 22:13:01.126491
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True

# Generated at 2022-06-24 22:13:02.857518
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()


# Generated at 2022-06-24 22:13:07.669604
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Populate a fact object for testing
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

if __name__ == '__main__':
    test_case_0();

    test_HurdHardware_populate();

# Generated at 2022-06-24 22:13:10.875076
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    argspec = inspect.getargspec(hurd_hardware_0.populate)
    assert argspec.args == ['self', 'collected_facts']

# Generated at 2022-06-24 22:13:15.477975
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()
    assert (hurd_hardware_0.memory is not None)
    assert (hurd_hardware_0.uptime is not None)
    assert (hurd_hardware_0.uptime_seconds is not None)

# Generated at 2022-06-24 22:13:17.693024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_0 = HurdHardware()
    hurd_hardware_0.populate()

# Generated at 2022-06-24 22:13:25.736018
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdles_0 = HurdHardware()
    hurdles_facts = hurdles_0.populate()
    assert hurdles_facts is not None
    assert hurdles_facts['uptime'] is not None
    assert hurdles_facts['uptime_seconds'] is not None
    assert hurdles_facts['memfree_mb'] is not None
    assert hurdles_facts['memtotal_mb'] is not None
    assert hurdles_facts['swaptotal_mb'] is not None
    assert hurdles_facts['swapfree_mb'] is not None
    assert hurdles_facts['mounts'] is not None


# Generated at 2022-06-24 22:13:34.417500
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    mocked_facts = {'ansible_system': 'GNU',
                    'ansible_machine': 'i686',
                    'ansible_processor': {'model': 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz', 'count': 4,
                                          'vendor_id': 'GenuineIntel'}}
    hurd_hardware_0 = HurdHardware()

# Generated at 2022-06-24 22:13:35.543029
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-24 22:13:42.019485
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    parser = HurdHardware.create_parser()
    args = parser.parse(['meminfo', 'uptime', 'mount'])
    hurd_hardware = HurdHardware(args, platform='GNU')
    hurd_hardware_facts = hurd_hardware.populate()
    assert 'uptime' in hurd_hardware_facts
    assert 'system_memory' in hurd_hardware_facts
    assert 'mounts' in hurd_hardware_facts

# Generated at 2022-06-24 22:13:50.581540
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime_seconds'] == b'\x06\x00\x00\x00\x00'

# Generated at 2022-06-24 22:13:54.550536
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}

# Generated at 2022-06-24 22:14:04.847749
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime_seconds'] == 0
    assert var_0['uptime_hours'] == 0
    assert var_0['uptime_days'] == 0
    assert var_0['uptime_seconds_with_fraction'] == 0
    #assert var_0['mounts'] == None
    assert var_0['memtotal_mb'] == 0
    assert var_0['memfree_mb'] == 0
    assert var_0['memavail_mb'] == 0
    assert var_0['swaptotal_mb'] == 0
    assert var

# Generated at 2022-06-24 22:14:08.730003
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:11.523655
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test method populate of class HurdHardware
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:15.392676
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x12\xdd3\xb9\x9dA\xe2\x19\xa1'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:18.857106
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:14:22.679037
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:14:31.378817
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict) == True
    assert var_0['mem_total'] == 77535968

if __name__ == '__main__':
    test_case_0()
    test_HurdHardware_populate()
    var_1 = HurdHardwareCollector.collect()
    print(var_1)

# Generated at 2022-06-24 22:14:36.369384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Create an instance of HurdHardware
    hurd_hardware_1 = HurdHardware()
    # Call method populate of HurdHardware
    var_1 = hurd_hardware_1.populate()


# Generated at 2022-06-24 22:14:51.543575
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'memfacts': {u'MemTotal': 16, u'SwapTotal': 0}, 'uptime_timet': '396489'}

# Generated at 2022-06-24 22:14:59.554437
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime': -1, 'procs': -1, 'memfree_mb': 0, 'user': -1, 'memtotal_mb': 0, 'swapfree_mb': -1, 'swaptotal_mb': 0, 'vmfree_mb': 0, 'vmtotal_mb': 0, 'vmactive_mb': 0}


# Generated at 2022-06-24 22:15:04.403165
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_1 = hurd_hardware_0.populate()
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 22:15:06.760320
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # No exception raised for input 0
    test_case_0()

# Generated at 2022-06-24 22:15:09.170645
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:14.784402
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:19.162913
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:15:26.276709
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime_seconds'] == 7064
    assert var_0['memtotal_mb'] == 743
    assert var_0['uptime_days'] == 16
    assert var_0['uptime_hours'] == 2
    assert var_0['uptime_minutes'] == 54
    assert var_0['swapfree_mb'] == 398
    assert var_0['memfree_mb'] == 412
    assert var_0['swaptotal_mb'] == 398

# Generated at 2022-06-24 22:15:29.944200
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:15:40.533367
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert isinstance(var_0, dict)

# Generated at 2022-06-24 22:16:09.350662
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xec\x1aX\xab\xd4"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:20.500394
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-24 22:16:24.680320
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:16:27.635718
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    var_1 = HurdHardware(bytes_0).populate()
    assert isinstance(var_1, dict)

# Generated at 2022-06-24 22:16:32.600100
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'memory_mb': {'swap_mb': {'free': 0, 'used': 0}}, 'uptime_seconds': 52759}


# Generated at 2022-06-24 22:16:39.189193
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    bytes_1 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_1 = HurdHardware(bytes_1)
    var_1 = hurd_hardware_1.populate()

# Generated at 2022-06-24 22:16:44.767135
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0.keys() == ['uptime', 'uptime_seconds', 'uptime_hours', 'uptime_days', 'memtotal_mb',
                            'swaptotal_mb']

# Generated at 2022-06-24 22:16:50.047427
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x17s\x9a\xf7c\x80\xde\xef\x15{*\xfd\xd2\xb6\x9b\x8c\x98\xe4#\x0c\x14\xbf\xc6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    # AssertionError: expected value of type <type 'dict'> but got <type 'NoneType'>


# Generated at 2022-06-24 22:16:55.464534
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert len(var_0) == 10


# Generated at 2022-06-24 22:17:05.277003
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {'uptime_seconds': 7764, 'uptime_days': 0, 'uptime_hours': 2, 'uptime_minutes': 9, 'memory_swapfree_mb': 0, 'memory_swaptotal_mb': 0, 'memory_mb': 992, 'memory_total': 992, 'memory_free': 992, 'memory_swapfree': 0, 'memory_swaptotal': 0}


# Generated at 2022-06-24 22:17:32.643856
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()


# Generated at 2022-06-24 22:17:37.139740
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    args = {}
    hurd_hardware_case_0 = HurdHardware(args)
    var_0 = hurd_hardware_case_0.populate()
    assert var_0 == {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0.0, 'swaptotal_mb': 0, 'uptime_seconds': 0}

# Generated at 2022-06-24 22:17:40.806791
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\x04\x02\x00\x00\x00\x00\x00\x00'
    hurd_hardware_0 = HurdHardware(bytes_0)
    str_0 = hurd_hardware_0.populate()
    str_1 = hurd_hardware_0.populate()
    assert str_0 != str_1


# Generated at 2022-06-24 22:17:45.691087
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0['uptime_seconds'] == 8662


# Generated at 2022-06-24 22:17:54.087111
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Parameters
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)

# Generated at 2022-06-24 22:18:00.053141
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()

# Generated at 2022-06-24 22:18:03.041266
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:18:06.558629
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes_0 = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware_0 = HurdHardware(bytes_0)
    var_0 = hurd_hardware_0.populate()
    var_1 = hurd_hardware_0.__init__(bytes_0)

# Generated at 2022-06-24 22:18:15.314236
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    bytes = b'\xf8\x19X\xab\xd6"\xca2g\xe6'
    hurd_hardware = HurdHardware(bytes)
    assert isinstance(hurd_hardware, HurdHardware) == True

# Generated at 2022-06-24 22:18:17.136858
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    assert True == False # FIXME replace with actual test for HurdHardware.populate