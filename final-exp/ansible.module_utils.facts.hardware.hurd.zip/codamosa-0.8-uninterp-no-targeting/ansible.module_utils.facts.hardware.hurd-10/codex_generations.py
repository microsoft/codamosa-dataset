

# Generated at 2022-06-20 17:28:00.756221
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # check if constructor is not empty
    obj = HurdHardwareCollector()
    assert obj

# Generated at 2022-06-20 17:28:02.281137
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()

    assert hurd_facts.platform == HurdHardware.platform

# Generated at 2022-06-20 17:28:04.798675
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert len(hardware.populate()) > 0
    assert hardware.populate().get('uptime_seconds') is not None

# Generated at 2022-06-20 17:28:05.893643
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-20 17:28:11.321583
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Without argument
    hhc = HurdHardwareCollector()
    assert hhc._fact_class == HurdHardware
    assert hhc._platform == 'GNU'

    # With wrong argument
    hhc = HurdHardwareCollector('foo')
    assert hhc._fact_class == HurdHardware
    assert hhc._platform == 'GNU'

# Generated at 2022-06-20 17:28:20.669792
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockTimeoutError:
        pass

    class MockHurdHardware(HurdHardware):
        def __init__(self):
            self.uptime_facts = {'ansible_uptime_seconds': 1}
            self.memory_facts = {'ansible_memfree_mb':1}
            self.mount_facts = {'mounts': [
                {'device': '/dev/sd0', 'mount': '/'}
            ]}

        def get_uptime_facts(self):
            return self.uptime_facts

        def get_memory_facts(self):
            return self.memory_facts

        def get_mount_facts(self):
            if self.memory_facts:
                return self.mount_facts
            else:
                raise TimeoutError

    hurd_facts = MockHurdHardware()

# Generated at 2022-06-20 17:28:24.708555
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.platform == 'GNU'
    assert hhc._fact_class == HurdHardware


# Generated at 2022-06-20 17:28:27.740546
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    '''
    Test object creation of class HurdHardware
    '''
    obj = HurdHardware({})
    assert isinstance(obj, HurdHardware)

# Generated at 2022-06-20 17:28:30.331423
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    hhc = HurdHardwareCollector(HurdHardware)
    hhc = HurdHardwareCollector(HurdHardware, 'GNU')

# Generated at 2022-06-20 17:28:31.834471
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'

# Generated at 2022-06-20 17:28:35.682758
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector
    assert isinstance(collector._fact_class, HurdHardware)

# Generated at 2022-06-20 17:28:42.147378
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = HurdHardware().populate()
    assert type(result) is dict
    assert type(result['uptime_seconds']) is float
    assert type(result['memtotal_mb']) is int
    assert type(result['mounts']) is list
    assert type(result['mounts'][0]) is dict
    assert 'device' in result['mounts'][0]
    assert 'mount' in result['mounts'][0]

# Generated at 2022-06-20 17:28:54.457882
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Return hardware facts"""

    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] == hardware_facts['memfree_mb'] + hardware_facts['swaptotal_mb'] + hardware_facts['swapfree_mb']
    assert hardware_facts['memtotal'] >= hardware_facts['memfree'] + hardware_facts['swaptotal'] + hardware_facts['swapfree']
    assert hardware_facts['memtotal'] == hardware_facts['memtotal_mb'] * 1048576

# Generated at 2022-06-20 17:28:56.138074
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._platform == 'GNU'

# Generated at 2022-06-20 17:29:04.164881
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] == 0
    assert hardware_facts['uptime_hours'] == 0
    assert hardware_facts['uptime_days'] == 0
    assert hardware_facts['memtotal_mb'] == 0
    assert hardware_facts['memfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0

# Generated at 2022-06-20 17:29:07.366244
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_instance = HurdHardware(None, None)
    assert hardware_instance.platform == 'GNU'
    assert hardware_instance._platform == 'GNU'

# Generated at 2022-06-20 17:29:13.104128
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Test case: HurdHardware with no modules argument
    # Expect:
    # - facts dictionary
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert isinstance(facts, dict)

    # Test case: HurdHardware with modules argument
    # Expect:
    # - facts dictionary
    hurd_hardware = HurdHardware(modules=None)
    facts = hurd_hardware.populate()
    assert isinstance(facts, dict)

# Generated at 2022-06-20 17:29:17.120668
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    uptime_facts = hardware.get_uptime_facts()
    memory_facts = hardware.get_memory_facts()
    mount_facts = hardware.get_mount_facts()

    facts = {}
    facts.update(uptime_facts)
    facts.update(memory_facts)
    facts.update(mount_facts)

    assert hardware_facts == facts

# Generated at 2022-06-20 17:29:18.582675
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """ Test case for HurdHardwareCollector"""
    HurdHardwareCollector()

# Generated at 2022-06-20 17:29:20.205230
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware
    assert hurdhw


# Generated at 2022-06-20 17:29:31.961314
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test some functions of the populate method of the HurdHardware class.
    """
    hw_obj = HurdHardware()

    # Test the sysctl command

# Generated at 2022-06-20 17:29:43.955306
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware._platform == 'GNU'
    assert hardware._fact_class is HurdHardware
    assert hardware._mount_facts_command == "/bin/mount"
    assert hardware._mount_facts_search_string == "^(?P<device>([\w/.-]+)) on (?P<mount>([\w/.-]*)) type (?P<fstype>[\w]*)( \((?P<options>[\w,]*)\))?$"
    assert hardware._memory_facts_command == "/bin/cat /proc/meminfo"
    assert hardware._uptime_facts_command == "/bin/cat /proc/uptime"

# Generated at 2022-06-20 17:29:45.787367
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:29:48.174266
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()

    assert hurd_hw._platform == 'GNU'
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-20 17:29:51.067478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert hurd_hardware.facts['uptime_seconds']
    assert hurd_hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:29:51.946318
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)

# Generated at 2022-06-20 17:29:53.425917
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    m = HurdHardware()
    assert m.platform == 'GNU'
    assert m.kernel == 'GNU'


# Generated at 2022-06-20 17:29:58.918748
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware, LinuxHardware)
    assert isinstance(hurd_hardware, HardwareCollector)


# Generated at 2022-06-20 17:30:02.019485
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    try:
        hurd_hardware = HurdHardware()
    except Exception:
        assert 0, "Exception raised"
    else:
        assert 1


# Generated at 2022-06-20 17:30:04.030014
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-20 17:30:06.545874
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware



# Generated at 2022-06-20 17:30:10.251197
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts_module = HurdHardware()
    facts = hurd_facts_module.populate()
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts

# Generated at 2022-06-20 17:30:13.504281
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    myHurd = HurdHardware()
    assert myHurd.platform == 'GNU', "Error in constructor with platform 'GNU'"

# Generated at 2022-06-20 17:30:21.720081
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    hurd_hw = HurdHardware()
    hurd_hw.populate(facts)
    assert 'mounts' in facts
    assert 'memtotal_mb' in facts
    assert 'uptime_seconds' in facts
    assert 'uptime_hours' in facts
    assert 'uptime_days' in facts
    assert type(facts['uptime_seconds']) is int
    assert type(facts['uptime_hours']) is int
    assert type(facts['uptime_days']) is int
    assert facts['uptime_seconds'] > 0


if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-20 17:30:25.195704
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    collected_facts = {}
    h_facts = h.populate(collected_facts)
    assert h_facts is not None

# Generated at 2022-06-20 17:30:34.766824
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test of HurdHardware on GNU/Hurd
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    import os
    import tempfile
    from ansible.module_utils.facts.timeout import TimeoutError

    # Build the expected results:
    expected_memory_facts = {
        "memfree_mb": 42,
        "memtotal_mb": 84,
        "swapfree_mb": 0,
        "swaptotal_mb": 0,
    }

# Generated at 2022-06-20 17:30:42.570656
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts import timeout
    import time

    # Prepare mocking of subclass methods
    class HurdHardwareSubclass(HurdHardware):
        def get_uptime_facts(self):
            return ((('uptime_seconds', 1234.0),),)

        def get_memory_facts(self):
            return ((('memory_mb', 1024),),)

        def get_mount_facts(self):
            return ((('/', {'device': '/dev/sda1', 'mount': '/',
                            'fstype': 'ext4', 'options': ['bar', 'baz']}),),)

    # Ensure that method TimeoutError is not mocked
    timeout.TimeoutError = TimeoutError

    # Preparation
    module = Test

# Generated at 2022-06-20 17:30:44.387130
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    assert hardware
    assert hardware.platform == 'GNU'

# Collect facts using HurdHardwareCollector

# Generated at 2022-06-20 17:30:47.399664
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()

    assert facts['memtotal_mb'] is not None
    assert facts['uptime_seconds'] is not None
    assert len(facts['mounts']) > 0 or len(facts['filesystems']) > 0

# Generated at 2022-06-20 17:30:48.281903
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Constructor test:
    #     Not implemented yet
    pass

# Generated at 2022-06-20 17:30:55.258176
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a instance of class
    hurd_hardware = HurdHardware()
    uptime_facts = hurd_hardware.get_uptime_facts()
    memory_facts = hurd_hardware.get_memory_facts()

    mount_facts = {}
    try:
        mount_facts = hurd_hardware.get_mount_facts()
    except TimeoutError:
        pass

    assert 'uptime_seconds' in uptime_facts
    assert 'uptime_seconds' in memory_facts
    assert 'uptime_seconds' in mount_facts
    assert isinstance(uptime_facts['uptime_seconds'], int)
    assert isinstance(memory_facts['uptime_seconds'], int)
    assert isinstance(mount_facts['uptime_seconds'], int)


# Generated at 2022-06-20 17:31:02.436237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_class = HurdHardware()
    data_dict = {
        'memory': {
            'MemTotal': 115548,
            'MemFree': 32912,
            'MemAvailable': 53580,
            'SwapTotal': 0,
            'SwapFree': 0,
        },
        'mounts': [
            {
                'device': '/dev/cdrom',
                'mount': '/cdrom',
                'fstype': 'iso9660',
                'opts': 'ro,noauto',
            }
        ]
    }

# Generated at 2022-06-20 17:31:09.082181
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    answers = dict(uptime=dict(seconds=1), memory=dict(MemTotal=1, MemFree=1, SwapTotal=1, SwapFree=1))
    hurd_hardware = HurdHardware()
    hurd_hardware.collect_answers = dict(answers)
    hurd_hardware.populate()

    assert hurd_hardware.uptime_facts == answers['uptime']

# Generated at 2022-06-20 17:31:13.332839
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'
    assert hh.system == 'Hurd'
    assert HurdHardware.platform == 'GNU'
    assert HurdHardware.system == 'Hurd'


# Generated at 2022-06-20 17:31:15.156271
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardware()
    assert hardware_obj.populate()

# Generated at 2022-06-20 17:31:25.417822
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj_hw = HurdHardware()
    assert hasattr(obj_hw, 'uptime_cmd')

    assert obj_hw.uptime_cmd.endswith('sysinfo -s')
    assert obj_hw.uptime_cmd.startswith('/usr/')
    assert obj_hw.uptime_cmd.count(' ') == 0

    assert hasattr(obj_hw, 'free_mem_cmd')

    assert obj_hw.free_mem_cmd.endswith('sysinfo -m')
    assert obj_hw.free_mem_cmd.startswith('/usr/')
    assert obj_hw.free_mem_cmd.count(' ') == 0

    assert hasattr(obj_hw, 'mount_cmd')

    assert obj_hw.mount_cmd.endswith('df -k')
   

# Generated at 2022-06-20 17:31:26.520558
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert hasattr(HurdHardware, 'platform')


# Generated at 2022-06-20 17:31:30.572947
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    args = dict()
    hurd_hardware_obj = HurdHardware(module, args)
    assert isinstance(hurd_hardware_obj, HurdHardware)


# Generated at 2022-06-20 17:31:35.931385
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collection = HurdHardwareCollector(None, None, None)
    facts = collection.get_facts()

    assert facts['uptime'] > 0
    assert facts['memory_mb']['real']['total'] > 0
    assert 'root' in facts['mounts']

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 17:31:37.536643
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """ Test for constructor of HurdHardwareCollector
    """
    hw_collector = HurdHardwareCollector()

# Generated at 2022-06-20 17:31:46.121624
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj._platform == 'GNU'

# Test case for method - get_uptime_facts

# Generated at 2022-06-20 17:31:47.919496
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()

    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:31:49.120825
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert isinstance(HurdHardware(), HardwareCollector)


# Generated at 2022-06-20 17:31:56.972748
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    uptime_facts = hurd_hardware.get_uptime_facts()
    memory_facts = hurd_hardware.get_memory_facts()
    mount_facts = hurd_hardware.get_mount_facts()
    hardware_facts = hurd_hardware.populate()
    assert hardware_facts is not None
    assert hardware_facts.get('uptime_seconds') == uptime_facts.get('uptime_seconds')
    assert hardware_facts.get('uptime_hours') == uptime_facts.get('uptime_hours')
    assert hardware_facts.get('uptime_days') == uptime_facts.get('uptime_days')
    assert hardware_facts.get('memtotal_mb') == memory_facts.get('memtotal_mb')
    assert hardware_facts

# Generated at 2022-06-20 17:32:01.192222
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.__class__.__name__ == 'HurdHardwareCollector'
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware


# Generated at 2022-06-20 17:32:02.574287
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware


# Generated at 2022-06-20 17:32:09.017383
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.timeout import TimeoutError

    test_facts = Facts(dict())
    task = HurdHardware(test_facts)

    # Fake an uptime
    task.read_file = lambda *args: 'a_long_time_ago\n'

    # The get_mount_facts method raises a TimeoutError exception
    task.get_mount_facts = lambda: task.get_mount_facts()
    with pytest.raises(TimeoutError):
        task.populate()


# Generated at 2022-06-20 17:32:11.077433
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'

# Generated at 2022-06-20 17:32:18.645796
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    har = HurdHardware()
    assert har.platform == "GNU"
    assert har.sysctl_path == "/proc/sys/"
    assert har.uptime_path == "/proc/uptime"
    assert har.meminfo_path == "/proc/meminfo"
    # The sysctl_path and meminfo_path are instances of the UTSConfig class
    assert repr(har.meminfo_path) == '<UTSConfig path="/proc/meminfo">'
    assert repr(har.sysctl_path) == '<UTSConfig path="/proc/sys/">'
    # The freebsd_devices and freebsd_swap_devices are instances of the
    # UTSConfig class
    assert repr(har.freebsd_devices) == '<UTSConfig path="/dev/">'

# Generated at 2022-06-20 17:32:20.813378
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:32:35.357966
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    processor = None
    expected = {'uptime': None, 'uptime_hours': None, 'uptime_seconds': None,
                'memfree_mb': None, 'memtotal_mb': None, 'memfree_mb': None,
                'swapfree_mb': None, 'swaptotal_mb': None, }

    hurd_hw = HurdHardware(processor)
    actual = hurd_hw.populate()

    assert expected['uptime'] == actual['uptime']
    assert expected['uptime_hours'] == actual['uptime_hours']
    assert expected['uptime_seconds'] == actual['uptime_seconds']
    assert expected['memfree_mb'] == actual['memfree_mb']
    assert expected['memtotal_mb'] == actual['memtotal_mb']
    assert expected['memfree_mb'] == actual

# Generated at 2022-06-20 17:32:36.809942
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert hurd_facts.platform == 'GNU'

# Generated at 2022-06-20 17:32:41.749421
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert 'uptime' in hurd_hardware.facts
    assert 'uptime_seconds' in hurd_hardware.facts
    assert 'memfree_mb' in hurd_hardware.facts
    assert 'swapfree_mb' in hurd_hardware.facts


# Generated at 2022-06-20 17:32:44.196847
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class() == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-20 17:32:45.747080
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert isinstance(HurdHardware(None, None), HurdHardware)

# Generated at 2022-06-20 17:32:47.325796
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware({})
    res = obj.populate()
    assert isinstance(res, dict)

# Generated at 2022-06-20 17:32:51.677425
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = dict()

    def mock_get_mount_facts():
        return dict({'mounts': 'foo'})

    HurdHardware.get_mount_facts = mock_get_mount_facts
    hardware = HurdHardware()
    hardware.populate(facts)
    expected = {
        'mounts': 'foo'
    }
    assert facts == expected

# Generated at 2022-06-20 17:32:53.967709
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert hw.populate() == {}

# Generated at 2022-06-20 17:32:58.684656
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurs_hardware = HurdHardware()
    assert hurs_hardware
    assert isinstance(hurs_hardware, HurdHardware)
    assert issubclass(hurs_hardware.__class__, HardwareCollector)

# Generated at 2022-06-20 17:33:07.659939
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    #Patch get_uptime_facts, get_memory_facts and get_mount_facts methods
    #of class HurdHardware
    hardware = HurdHardware()
    hardware.get_uptime_facts = lambda: {'uptime': 4327}
    hardware.get_memory_facts = lambda: {'memtotal': 2, 'memfree': 3}
    hardware.get_mount_facts = lambda: {'mounts': [1, 2, 3]}

    if hardware.populate()!={'uptime': 4327, 'memtotal': 2, 'memfree': 3,
                             'mounts': [1, 2, 3]} :
        #Test failed
        raise AssertionError('Could not retrieve facts')
    else:
        #Test passed
        pass

# Generated at 2022-06-20 17:33:18.219842
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    haste_hw = HurdHardware()

    assert haste_hw.platform == 'GNU'


# Generated at 2022-06-20 17:33:24.700161
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert(isinstance(hurd_hardware.uptime, int))
    assert(isinstance(hurd_hardware.memtotal_mb, int))
    assert(isinstance(hurd_hardware.mounts, list))

# Generated at 2022-06-20 17:33:25.978927
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    hardware_facts.populate()

# Generated at 2022-06-20 17:33:26.484392
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware()

# Generated at 2022-06-20 17:33:28.853894
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)
    assert isinstance(hurd_hw.populate(), dict)

# Generated at 2022-06-20 17:33:34.441455
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_obj = HurdHardware()
    assert hardware_obj.platform == 'GNU'
    uptime_facts = hardware_obj.get_uptime_facts()
    memory_facts = hardware_obj.get_memory_facts()
    mount_facts = hardware_obj.get_mount_facts()
    assert uptime_facts['uptime_seconds'] != ""
    assert memory_facts['memtotal_mb'] != ""
    assert mount_facts['mounts'] != ""

# Generated at 2022-06-20 17:33:35.783997
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector
    assert isinstance(collector._fact_class(), HurdHardware)

# Generated at 2022-06-20 17:33:36.516402
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    print(hw)

# Generated at 2022-06-20 17:33:38.931036
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    storage_obj = HurdHardware()
    storage_facts = storage_obj.populate()
    assert storage_obj == storage_facts

# Generated at 2022-06-20 17:33:40.864209
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector is not None

# Generated at 2022-06-20 17:34:11.901836
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fake_module = FakeModule()

    hhw = HurdHardware(module=fake_module)
    result = hhw.populate()
    assert 'uptime' in result
    assert 'uptime_seconds' in result
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'mounts' in result
    assert result['mounts'] != []
    assert 'fstype' in result['mounts'][0]
    assert 'mount' in result['mounts'][0]
    assert 'device' in result['mounts'][0]


# Helper class for unit testing method populate of class HurdHardware

# Generated at 2022-06-20 17:34:14.375549
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardwareCollector().collect()

    assert facts['uptime']['uptime'] > 0
    assert facts['memory']['total'] > 0
    assert facts['swap']['total'] >= 0

# Generated at 2022-06-20 17:34:16.551629
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)

# Generated at 2022-06-20 17:34:20.597990
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:34:22.023768
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardware()
    assert hardware_obj.populate()

# Generated at 2022-06-20 17:34:24.912376
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert hurd_hardware
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:34:34.580929
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    mount_facts = {
        'mounts': [
            {
                'block_available': 566713,
                'block_size': 1024,
                'block_total': 1133430,
                'block_used': 566717,
                'device': 'tmpfs',
                'fstype': 'tmpfs',
                'inode_available': 1310720,
                'inode_total': 1310720,
                'inode_used': 0,
                'options': 'rw,relatime',
                'size_available': 578944,
                'size_total': 1133424,
                'size_used': 554480,
                'uuid': None
            }
        ]
    }


# Generated at 2022-06-20 17:34:41.744208
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.collector import FactsCollector

    facts_collector = FactsCollector()
    HurdHardwareCollector(facts_collector)
    collected_facts = facts_collector.collect()

    assert collected_facts['ansible_facts']['ansible_mounts'][0]['mount'] == '/'
    assert collected_facts['ansible_facts']['ansible_mounts'][0]['device'] == '/dev/hda1'
    assert collected_facts['ansible_facts']['ansible_mounts'][0]['fstype'] == 'ext2'
    assert collected_facts['ansible_facts']['ansible_memtotal_mb'] == 1049545

# Generated at 2022-06-20 17:34:43.668215
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-20 17:34:53.428697
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware(None)

    try:
        import psutil
    except ImportError:
        hardware.uptime_fail = True
        hardware.mounted_filesystems_fail = True

    hardware_facts = hardware.populate()

    # The following variables check the existence of keys in the resulting
    # dictionary.
    assert 'uptime' in hardware_facts or hardware.uptime_fail is True
    assert 'uptime_seconds' in hardware_facts or hardware.uptime_fail is True
    assert 'memtotal_mb' in hardware_facts or hardware.uptime_fail is True
    assert 'memfree_mb' in hardware_facts or hardware.uptime_fail is True
    assert 'swaptotal_mb' in hardware_facts or hardware.uptime_fail is True
    assert 'swapfree_mb' in hardware_

# Generated at 2022-06-20 17:35:15.350391
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    _HurdHardware = HurdHardware()
    assert _HurdHardware.platform == 'GNU'

# Generated at 2022-06-20 17:35:15.892095
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-20 17:35:17.780925
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-20 17:35:20.561292
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)



# Generated at 2022-06-20 17:35:30.809915
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-20 17:35:32.290661
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.get_all() is not None

# Generated at 2022-06-20 17:35:35.447276
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'
    assert type(h._fact_class) == HurdHardware


# Generated at 2022-06-20 17:35:36.921399
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-20 17:35:38.412550
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:35:42.212891
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    expected_platform = 'GNU'
    expected_fact_class = HurdHardware

    # Test constructor
    hardware_collector = HurdHardwareCollector()

    # Test attributes
    fact_class = hardware_collector._fact_class
    platform = hardware_collector._platform

    assert fact_class == expected_fact_class
    assert platform == expected_platform


# Generated at 2022-06-20 17:36:29.265572
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Unit test for constructor of class HurdHardwareCollector.
    """

    # Construct HurdHardwareCollector object.
    hurd_hardware_collector = HurdHardwareCollector()

    # Check it has correct types.
    assert isinstance(hurd_hardware_collector, object)
    assert isinstance(hurd_hardware_collector._fact_class, type(HurdHardware))

# Generated at 2022-06-20 17:36:37.624831
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    test_input_facts = {'platform': 'GNU'}

    test_obj = HurdHardware(test_input_facts)

    test_result_facts = {'hardware_memtotal_mb': 0,
                         'hardware_memfree_mb': 0,
                         'hardware_swaptotal_mb': 0,
                         'hardware_swapfree_mb': 0,
                         'ansible_mounts': [],
                         'ansible_system_uptime_seconds': 0}

    assert test_obj._populate() == test_result_facts

# Generated at 2022-06-20 17:36:42.887590
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_os_distribution': 'Debian'}
    m = HurdHardware()
    res = m.populate(collected_facts)

    assert('memfree_mb' in res)
    assert('swapfree_mb' in res)
    assert('fstype_mountpoints' in res)
    assert('mounts' in res['fstype_mountpoints'])

# Generated at 2022-06-20 17:36:47.628148
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_hw = HurdHardware()

    results = test_hw.populate()

    assert results['uptime_seconds'] == 0

    memory_facts = test_hw.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts

    assert 'mounts' in results

# Generated at 2022-06-20 17:36:49.336113
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw is not None



# Generated at 2022-06-20 17:36:50.900600
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    # Test
    hurd_hardware.populate()

# Generated at 2022-06-20 17:36:54.730030
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert isinstance(hw, HurdHardwareCollector)

# Generated at 2022-06-20 17:36:55.586541
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware.populate()

# Generated at 2022-06-20 17:36:57.396710
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:36:59.707700
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h_collector = HurdHardwareCollector()
    assert h_collector._fact_class is HurdHardware
    assert h_collector._platform is 'GNU'