

# Generated at 2022-06-20 17:27:57.737377
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-20 17:27:59.467526
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware("")
    assert h.device == ""



# Generated at 2022-06-20 17:28:01.858027
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc.__class__.__name__ == 'HurdHardwareCollector'


# Generated at 2022-06-20 17:28:09.355722
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware_facts = {
        'uptime': '0',
        'uptime_format': 'seconds',
        'memory': {
            'swapfree_mb': 0,
            'swaptotal_mb': 0,
            'real': {
                'total': 0,
                'free': 0,
            }
        },
        'mounts': [],
    }

    assert hurd_hardware_facts == hurd_hardware.populate()

# Generated at 2022-06-20 17:28:15.582871
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test method populate of class HurdHardware
    """
    # check for uptime facts
    assert 'uptime_seconds' in HurdHardware(None).populate()

    # check for memory facts
    assert 'swapfree_mb' in HurdHardware(None).populate()

    # check for mount facts
    assert 'mounts' in HurdHardware(None).populate()

# Generated at 2022-06-20 17:28:18.422910
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._fact_class == HurdHardware
    assert hurd_hardware_collector._platform == 'GNU'


# Generated at 2022-06-20 17:28:19.892209
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'
    assert isinstance(hurd, LinuxHardware)

# Generated at 2022-06-20 17:28:20.704674
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()

# Generated at 2022-06-20 17:28:23.747763
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HardwareCollector._platform = 'GNU'
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:28:25.792811
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_test = HurdHardware()
    assert hurd_hardware_test is not None


# Generated at 2022-06-20 17:28:32.804428
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.collect()
    result = hardware.get_facts()

    # test empty result
    if ((result.get('mounts') or result.get('uptime_seconds')) or
            result.get('memtotal_mb') or result.get('memfree_mb') or
            result.get('swaptotal_mb') or result.get('swapfree_mb')):

        return False

    return True

# Generated at 2022-06-20 17:28:34.938452
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-20 17:28:36.434390
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware != None

# Generated at 2022-06-20 17:28:42.148410
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    uptime_facts = hw.get_uptime_facts()
    memory_facts = hw.get_memory_facts()
    mount_facts = hw.get_mount_facts()

    facts = hw.populate()

    assert facts == {**uptime_facts, **memory_facts, **mount_facts}

# Generated at 2022-06-20 17:28:48.306886
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_collector = HurdHardwareCollector(None)

    hardware_facts = hardware_collector.populate()

    assert hardware_facts.get('memory_mb') is not None
    assert hardware_facts.get('mounts') is not None
    assert hardware_facts.get('uptime') is not None

# Generated at 2022-06-20 17:28:58.476741
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()

# Generated at 2022-06-20 17:29:01.987376
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Test that class constructor sets platform correctly."""
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-20 17:29:04.239011
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw_instance = HurdHardware()
    assert hasattr(hw_instance, 'platform')
    assert hw_instance.platform == 'GNU'


# Generated at 2022-06-20 17:29:07.661485
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'
    assert obj._fact_class == HurdHardware


# Generated at 2022-06-20 17:29:08.982859
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    l = HurdHardware()
    assert l.platform == 'GNU'

# Generated at 2022-06-20 17:29:12.573346
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    # Check the constructor is a LinuxHardware instance
    assert isinstance(obj, LinuxHardware)

# Generated at 2022-06-20 17:29:14.858174
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._platform is 'GNU'
    assert isinstance(hc._fact_class, HurdHardware)

# Generated at 2022-06-20 17:29:15.929725
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware

# Generated at 2022-06-20 17:29:18.483232
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    obj.collect()
    assert obj.platform == 'GNU'

# Generated at 2022-06-20 17:29:29.423906
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.facts import Facts

    from unittest.mock import patch
    import sys

    def get_uptime_mock():
        uptime_facts = {
                'uptime_seconds': 91683,
                'uptime_hours': 2,
                'uptime_days': 0,
                'uptime': '2 hours, 5 minutes',
                'boot_time': 'Fri Mar 13 18:00:06 2020'
        }

        return uptime_facts


# Generated at 2022-06-20 17:29:41.187202
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    data = {'architecture': 'i386', 'distribution': 'GNU',
            'distribution_version': '0.3', 'lsb': {'distcodename': 'hurd',
            'distdescription': 'GNU/Hurd 0.3', 'distid': 'GNU Hurd',
            'distmajorrelease': '0', 'distrelease': '0.3',
            'majdistrelease': '0'}, 'os_family': 'GNU',
            'virtualization_role': 'guest'}
    hw = HurdHardwareCollector(data)


# Generated at 2022-06-20 17:29:43.135625
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == hardware_facts.platform

# Generated at 2022-06-20 17:29:47.526778
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Test the constructor of the class HurdHardware
    """
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-20 17:29:48.524181
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-20 17:29:49.883731
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware

# Generated at 2022-06-20 17:29:53.161972
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()

    assert(h is not None)


# Generated at 2022-06-20 17:29:54.747918
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
        hardware = HurdHardware()
        hardware.populate()

# Generated at 2022-06-20 17:30:00.910922
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    from ansible.module_utils.facts import get_mounts_facts
    # Collect facts
    h = HurdHardware()
    # Check if we get expected mount facts
    mount = get_mounts_facts()
    assert mount == h._facts['mounts']

# Generated at 2022-06-20 17:30:02.942953
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    a = HurdHardware()
    assert isinstance(a,HurdHardware)

# Generated at 2022-06-20 17:30:04.704441
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'



# Generated at 2022-06-20 17:30:06.975138
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-20 17:30:14.672867
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware._facts['uptime_seconds'] > 0
    assert hardware._facts['uptime_hours'] > 0
    assert hardware._facts['uptime_days'] > 0
    assert hardware._facts['memtotal_mb'] > 0
    assert hardware._facts['memfree_mb'] > 0
    assert hardware._facts['swaptotal_mb'] >= 0
    assert hardware._facts['swapfree_mb'] >= 0
    assert hardware._facts['mounts']

# Generated at 2022-06-20 17:30:17.420454
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.populate() == {}

# Generated at 2022-06-20 17:30:19.516408
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert(hurd_hardware.platform == 'GNU')


# Generated at 2022-06-20 17:30:26.578037
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware instance
    hurd_hardware_ins = HurdHardware()

    uptime_facts = {
        'uptime': '16 days',
        'uptime_seconds': 1382400
    }
    memory_facts = {
        'memfree_mb': 10.0,
        'memtotal_mb': 10.0
    }

# Generated at 2022-06-20 17:30:31.118880
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()

    assert obj._platform == 'GNU'
    assert obj._fact_class.__name__ == 'HurdHardware'

# Generated at 2022-06-20 17:30:34.401072
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import json
    import platform
    if platform.system() != 'GNU':
        return
    hurdhardware = HurdHardware()
    facts = hurdhardware.populate()
    assert json.dumps(facts)


# Generated at 2022-06-20 17:30:36.368493
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert hasattr(HurdHardware, '_platform') and hasattr(HurdHardware, 'get_memory_facts')


# Generated at 2022-06-20 17:30:37.793437
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.populate()
    assert h


# Generated at 2022-06-20 17:30:39.149863
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector({},{},{})
    assert type(h._fact_class) is HurdHardware

# Generated at 2022-06-20 17:30:42.938111
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    mock_module = 'module_utils.facts.hardware.hurd'
    with mock.patch(mock_module + '.open', mock.mock_open(read_data='data'), create=True) as mo:
        hw = HurdHardware()
        assert hw.platform == 'GNU'
        assert mo.call_count == 0


# Generated at 2022-06-20 17:30:53.370399
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """ Test resulting facts with a mock of /proc
    """

    class MockHurdHardware(HurdHardware):
        _files = {
            'uptime': 'vbox\n'
                     '13533.00 9604.17\n',
            'meminfo': 'vbox\n'
                      'MemTotal:       16777216 kB\n'
                      'MemFree:         6291456 kB\n',
            'vminfo': 'vbox\n'
                      'VmSwap:         16777212 kB\n',
            'mounts': 'vbox\n'
                      'proc /proc proc rw,relatime 0 0\n'
                      'dev /dev devfs rw,relatime 0 0\n',
        }


# Generated at 2022-06-20 17:30:55.696007
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()

    assert 'HurdHardware' == hurdHardware.__class__.__name__
    assert 'GNU' == hurdHardware.platform

# Generated at 2022-06-20 17:30:59.108575
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    assert hardware_facts.get('uptime_seconds', '') != ''
    assert hardware_facts.get('mounts', '') != ''
    assert hardware_facts.get('swapfree_mb', '') != ''

# Generated at 2022-06-20 17:31:04.118005
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # initialize the class and create a mock of the get_cpuinfo_facts method to
    # control the return value
    hurd_hardware = HurdHardware()
    hurd_hardware.get_cpuinfo = lambda: {'count': 1,
                                         'vendor_id': 'GenuineIntel',
                                         'cpu_family': 6,
                                         'model': 42,
                                         'model_name': 'Intel(R) Core(TM) i7-2720QM CPU @ 2.20GHz',
                                         'stepping': 7,
                                         'microcode': 937,
                                         'cpu_MHz': 1604.067,
                                         'cache_size': 6144}

    facts = hurd_hardware.populate()


# Generated at 2022-06-20 17:31:09.514661
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_collector = HurdHardwareCollector()
    assert fact_collector._platform == 'GNU'
    assert fact_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:31:12.361951
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert hurd_hardware._platform == 'GNU'
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:31:18.693084
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    results = hurd_hardware.populate()
    print("results: " + str(results))
    assert results['uptime_seconds'] is not None
    assert results['memtotal_mb'] is not None
    assert results['memfree_mb'] is not None


# Generated at 2022-06-20 17:31:19.911734
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:31:21.834163
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hhardware = HurdHardware()
    assert hhardware.default_mount_points == ['/', '/boot', '/usr', '/var']

# Generated at 2022-06-20 17:31:22.994582
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware


# Generated at 2022-06-20 17:31:26.271482
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Create an instance of HurdHardwareCollector
    """
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'


# Generated at 2022-06-20 17:31:31.884406
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()

    assert isinstance(hw_collector, HurdHardwareCollector)
    assert isinstance(hw_collector._platform, str)
    assert isinstance(hw_collector._fact_class, HurdHardware)

# Generated at 2022-06-20 17:31:35.299691
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()

    assert obj._platform == 'GNU'
    assert isinstance(obj._fact_class, HurdHardware)
    assert obj._fact_class._platform == 'GNU'

# Generated at 2022-06-20 17:31:36.579156
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == "GNU"

# Generated at 2022-06-20 17:31:48.318062
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test = HurdHardwareCollector()
    assert test._fact_class is HurdHardware, "test_HurdHardwareCollector: Failed to set fact_class."
    assert test._platform == "GNU", "test_HurdHardwareCollector: Failed to set platform"

# Generated at 2022-06-20 17:31:51.121218
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert type(hurd_hardware) == HurdHardware
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:31:54.863091
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector.platform == 'GNU'

# Generated at 2022-06-20 17:31:56.717406
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()
    assert hurdHardware is not None

# Generated at 2022-06-20 17:31:59.841534
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        HurdHardwareCollector()
    except Exception as e:
        print('Constructor of HurdHardwareCollector raised exception : ' + str(e))


# Generated at 2022-06-20 17:32:04.857844
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardwareCollector.collect()
    assert hardware['uptime']['seconds'] > 0
    assert 0 <= hardware['uptime']['days'] <= 9999
    assert hardware['uptime']['time'] is not None
    assert 0 <= hardware['memory']['total'] <= 999999999999
    assert 0 <= hardware['swap']['total'] <= 999999999999

# Generated at 2022-06-20 17:32:06.048493
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = HurdHardware().populate()
    assert result is not None

# Generated at 2022-06-20 17:32:07.493595
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'


# Generated at 2022-06-20 17:32:09.086994
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.collect() == HurdHardware().populate()

# Generated at 2022-06-20 17:32:12.308425
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # test what is returned with a class
    hurd_collector = HurdHardwareCollector()
    assert isinstance(hurd_collector, HurdHardwareCollector)

# Generated at 2022-06-20 17:32:26.243218
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.get_uptime_facts(), dict)
    assert isinstance(hurd_hardware.get_mount_facts(), dict)
    assert isinstance(hurd_hardware.get_memory_facts(), dict)
    assert isinstance(hurd_hardware.populate(), dict)



# Generated at 2022-06-20 17:32:32.398136
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()

    # Method populate returns a dict with the following keys
    expected_keys = [
        'uptime',
        'uptime_seconds',
        'uptime_hours',
        'uptime_days',
        'memfree_mb',
        'memtotal_mb',
        'swapfree_mb',
        'swaptotal_mb'
        ]

    # Ensure that the returned dict has the correct keys
    assert set(hurd.populate().keys()) == set(expected_keys)

# Generated at 2022-06-20 17:32:34.721939
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'

# Generated at 2022-06-20 17:32:36.606234
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().platform == 'GNU'

# Generated at 2022-06-20 17:32:45.620685
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    test_values = [
        {
            "os": {},
            "uptime": {
                "seconds": 5.0
            },
            "memory": {
                "total": 12345
            }
        },
        {
            "os": {},
            "uptime": {
                "seconds": 5.0
            },
            "memory": {
                "total": 12345
            },
            "mounts": [
                {
                    "device": "name",
                    "mount": "/mnt",
                    "fstype": "ext4"
                }
            ]
        }
    ]


# Generated at 2022-06-20 17:32:46.545346
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:32:48.129318
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware()._platform == 'GNU'


# Generated at 2022-06-20 17:32:49.942609
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'

# Test for populate method of class HurdHardwareCollector

# Generated at 2022-06-20 17:32:51.380413
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware
    assert hardware._platform == 'GNU'

# Generated at 2022-06-20 17:32:55.605687
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()

    assert facts['uptime_seconds'] == 750
    assert not facts['uptime_days']
    assert facts['uptime_hours'].startswith('20')
    assert facts['uptime_minutes'].startswith('55')

    assert facts['memory_mb'] == 16384
    assert facts['swap_mb'] == 20480
    assert facts['root_gb'] == 1
    assert facts['virt_type'] == 'kvm'
    assert facts['mounts'] == ['/']

# Generated at 2022-06-20 17:33:10.242620
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    This unit test is only meant to check if instantiating
    the HurdHardwareCollector class works.
    Any functional test should be done within the test_HurdHardware
    function below.
    """

    def __init__(self):
        facts_collector = HurdHardwareCollector()
        assert facts_collector._fact_class == HurdHardware
        assert facts_collector._platform == 'GNU'


# Generated at 2022-06-20 17:33:11.108526
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector

# Generated at 2022-06-20 17:33:15.963625
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
  hardware = HurdHardware()
  hardware_facts = hardware.populate()

  assert hardware_facts['uptime_seconds'] is not None
  assert hardware_facts['uptime_seconds'] >= 0
  assert hardware_facts['uptime_days'] is not None
  assert hardware_facts['uptime_days'] >= 0
  assert hardware_facts['swapfree_mb'] is not None
  assert hardware_facts['swapfree_mb'] >= 0
  assert hardware_facts['memtotal_mb'] is not None
  assert hardware_facts['memtotal_mb'] >= 0
  assert hardware_facts['memfree_mb'] is not None
  assert hardware_facts['memfree_mb'] >= 0
  assert hardware_facts['memavail_mb'] is not None
  assert hardware_facts['memavail_mb'] >= 0

# Generated at 2022-06-20 17:33:17.664718
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._fact_class == HurdHardware


# Generated at 2022-06-20 17:33:19.979593
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.get_host_info() == obj.hostinfo

# Generated at 2022-06-20 17:33:24.700528
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw_facts_inst = HurdHardware(None, "", "")
    hw_facts = hw_facts_inst.populate()
    assert ('uptime' in hw_facts)
    assert ('swapfree_mb' in hw_facts)
    assert ('fstype' in hw_facts)

# Generated at 2022-06-20 17:33:25.980289
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw._platform == 'GNU'

# Generated at 2022-06-20 17:33:28.356982
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert type(hhc) == HurdHardwareCollector
    assert hhc.platform == 'GNU'


# Generated at 2022-06-20 17:33:36.801566
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    import sys
    import stat
    import copy
    import datetime
    from time import time

    # Mock os.stat() and os.path.exists() methods,
    # and create time values to be used in mocks.
    def mocked_os_stat(path):
        if path == '/proc/uptime':
            st = os.stat_result((33206, 0, 0, 1, 0, 0, 64, int(time()), int(time()), int(time())))
            st.st_mode = stat.S_IFREG
            st.st_size = 24
            return st
        else:
            st = os.stat_result((16877, 0, 4119, 1, 0, 0, 8192, int(time()), int(time()), int(time())))
            st.st_

# Generated at 2022-06-20 17:33:43.142775
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    facts = hurdhw.populate()
    assert 'uptime' in facts
    assert 'uptime_seconds' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'mounts' in facts

# Generated at 2022-06-20 17:34:05.231460
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw = HurdHardwareCollector()
    assert isinstance(hurd_hw, HardwareCollector)

# Generated at 2022-06-20 17:34:09.202397
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw_facts = HurdHardware()
    assert hw_facts._supported_as_root
    assert hw_facts._platform == 'GNU'
    assert hw_facts._fact_class == HurdHardware


# Generated at 2022-06-20 17:34:12.445317
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test the constructor of the class HurdHardwareCollector.
    """
    hurd_hardware_collector = HurdHardwareCollector()

    assert hurd_hardware_collector._fact_class is HurdHardware
    assert hurd_hardware_collector._platform == 'GNU'

# Generated at 2022-06-20 17:34:17.737267
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test_hurd = HurdHardwareCollector()
    assert test_hurd._platform == 'GNU'
    assert test_hurd._fact_class == HurdHardware
    assert isinstance(test_hurd._fact_class(), HurdHardware)



# Generated at 2022-06-20 17:34:20.850795
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts_collector = HurdHardwareCollector()
    assert isinstance(facts_collector._fact_class, HurdHardware)

# Generated at 2022-06-20 17:34:25.276804
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h
    assert 'uptime_seconds' in h.get_uptime_facts()
    assert 'swapfree_mb' in h.get_memory_facts()
    assert 'mounts' in h.get_mount_facts()

# Generated at 2022-06-20 17:34:26.936619
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw


# Generated at 2022-06-20 17:34:35.931193
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys
    import subprocess

    class FakeHurdProc(object):
        def __init__(self, exitcode):
            self.exitcode = exitcode
            self.returncode = exitcode

        def communicate(self):
            return '\n'.encode(), b''

    class FakeHurdModule(object):
        def __init__(self):
            self.fail_json = lambda **kwargs: sys.exit(1)

        def run_command(self, args, **kwargs):
            return args, kwargs, FakeHurdProc(0)

    hurd_hardware = HurdHardware(FakeHurdModule(), 'module_name')
    fake_facts = {'ansible_lsb': {}}

    res_uptime = hurd_hardware.get_uptime_facts()
    assert res_

# Generated at 2022-06-20 17:34:37.173635
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HurdHardware)

# Generated at 2022-06-20 17:34:38.890670
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    assert isinstance(hurd_hardware_collector.collect(), dict)

# Generated at 2022-06-20 17:35:16.634793
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()

    assert 'mem_total' in facts

# Generated at 2022-06-20 17:35:19.498357
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert isinstance(hurd_facts, HurdHardware)


# Generated at 2022-06-20 17:35:20.903143
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-20 17:35:23.344410
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    GNUHardware = HurdHardware(HurdHardwareCollector, 'GNU')
    assert GNUHardware.platform == 'GNU'



# Generated at 2022-06-20 17:35:25.841424
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test_collector = HurdHardwareCollector()
    assert test_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:35:27.120814
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw is not None

# Generated at 2022-06-20 17:35:28.468055
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:35:29.616113
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware

# Generated at 2022-06-20 17:35:31.445776
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware



# Generated at 2022-06-20 17:35:32.896693
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)

# Generated at 2022-06-20 17:36:57.560228
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    collected_facts = {}
    collected_facts['device_facts'] = {'distribution': 'Hurd'}

    hurd_hardware = HurdHardware(collected_facts)
    hurd_hardware.populate()

# Generated at 2022-06-20 17:36:59.562287
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test_object = HurdHardwareCollector()
    assert test_object._platform == 'GNU'
    assert test_object._fact_class == HurdHardware

# Generated at 2022-06-20 17:37:01.199344
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # If constructor doesn't raise any exception, we pass the test
    assert HurdHardwareCollector

# Generated at 2022-06-20 17:37:05.214872
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    '''
    Test HurdHardware.populate method by mocking procfs file system and
    passing in the mock to the method.
    '''

    import errno
    import sys
    if sys.version_info.major == 2:
        import __builtin__ as builtins
    else:
        import builtins
    import mock

    # These variables will be used in the mock for open()
    UPTIME_FILE_NAME = "/proc/uptime"
    UPTIME_FILE_DATA = "3020.32 4286.62"
    UPTIME_FILE_DATA_ERROR = "3020.32"
    MEMINFO_FILE_NAME = "/proc/meminfo"
    MEMINFO_FILE_DATA = "MemTotal:       8127844 kB\nMemFree:        7871776 kB"
    MEMINFO

# Generated at 2022-06-20 17:37:06.798386
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'



# Generated at 2022-06-20 17:37:11.353567
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()

    facts = h.populate()

    assert h.platform == 'GNU'
    assert facts['uptime'] > 0.0
    assert facts['memory']['total'] > 0.0
    assert facts['memory']['swap']['total'] >= 0.0
    assert facts['mounts']
    assert facts['mounts']['/']['type'] == 'ext2'

# Generated at 2022-06-20 17:37:13.658461
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 17:37:20.492918
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['memavail_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0

    assert hardware_facts['mounts'] != []
    mount_paths = [mnt['mount'] for mnt in hardware_facts.get('mounts', [])]
    assert '/' in mount_paths

    assert hardware_facts['uptime_seconds'] >= 0

# Generated at 2022-06-20 17:37:24.425492
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    result = h.populate()
    assert result["uptime_seconds"] == 0
    assert result["uptime_days"] == 0
    assert result["uptime_hours"] == 0
    assert result["uptime_seconds"] == 0
    assert result["uptime_seconds"] == 0
    assert result["uptime_seconds"] == 0

# Generated at 2022-06-20 17:37:25.663365
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc
    assert hhc._fact_class == HurdHardware