

# Generated at 2022-06-20 17:28:04.415960
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    obj = HurdHardware()
    ansible_facts = obj.populate()

    assert ansible_facts.get(
        'ansible_memtotal_mb') > 0, "Memory size not recognizable"

    assert ansible_facts.get(
        'ansible_uptime_seconds') > 0, "Uptime not recognizable"

    assert 'ansible_mounts' in ansible_facts, "Mountpoint list not present"

    assert ansible_facts.get(
        'ansible_system') == "GNU", "System not recognized"

# Generated at 2022-06-20 17:28:07.759988
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    on_HurdHardwareCollector = HurdHardwareCollector()
    assert(on_HurdHardwareCollector._platform == 'GNU')
    assert(isinstance(on_HurdHardwareCollector._fact_class(), HurdHardware))

# Generated at 2022-06-20 17:28:11.159909
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    linux = LinuxHardwareCollector()
    linuxHardware = LinuxHardware()
    hurd = HurdHardwareCollector()
    hurdHardware = HurdHardware()

    uptime = linux.get_uptime_facts()
    memory = linux.get_memory_facts()
    mount = linuxHardware.get_mount_facts()

    hurdHardware.populate(linux.populate())


# Generated at 2022-06-20 17:28:13.724407
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class is HurdHardware
    assert obj._platform is 'GNU'

# Generated at 2022-06-20 17:28:14.915684
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector

# Generated at 2022-06-20 17:28:17.210026
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware, LinuxHardware)


# Generated at 2022-06-20 17:28:18.383366
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-20 17:28:21.621477
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    result = hw.populate()
    assert result['uptime']
    assert result['uptime_seconds'] > 0
    assert result['memory']['vendor']
    assert result['memory']['total'] > 0
    assert result['mounts']

# Generated at 2022-06-20 17:28:23.642820
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw_col = HurdHardwareCollector()
    assert(hurd_hw_col._fact_class == HurdHardware)
    assert(hurd_hw_col._platform == 'GNU')


# Generated at 2022-06-20 17:28:24.539992
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'

# Generated at 2022-06-20 17:28:28.297420
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()

# Generated at 2022-06-20 17:28:38.973543
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test various combinations of HurdHardware.populate()"""
    hurd_hardware = HurdHardware()

    # No timeout
    try:
        facts = hurd_hardware.populate()
    except TimeoutError:
        assert False
    else:
        assert 'uptime_seconds' in facts
        assert 'uptime_days' in facts

        assert 'memory_mb' in facts
        assert 'swap_mb' in facts

        # There are not necessarily any mounts
        if 'mounts' in facts:
            assert len(facts['mounts']) > 0

    # Timeout

# Generated at 2022-06-20 17:28:40.525664
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'


# Generated at 2022-06-20 17:28:46.505170
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    populate_facts = hardware_facts.populate()

    assert 'mounts' in populate_facts
    assert 'time_delta' in populate_facts
    assert 'memory' in populate_facts


# Generated at 2022-06-20 17:28:50.844082
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    is_hurd_collector = True
    try:
        HurdHardwareCollector(None)
    except:
        is_hurd_collector = False
    assert is_hurd_collector

# Generated at 2022-06-20 17:28:52.866276
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware

# Generated at 2022-06-20 17:28:53.820876
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-20 17:28:55.975734
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'



# Generated at 2022-06-20 17:28:59.479653
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # instantiate the HurdHardwareCollector class
    obj = HurdHardwareCollector()

    # check if the object is an instance of the class it should be
    assert isinstance(obj, HardwareCollector)

    # check if the object attribute has the right value
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 17:29:01.517727
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts = HurdHardwareCollector()
    assert facts._platform == 'GNU'

# Generated at 2022-06-20 17:29:14.277266
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    os_mock = {}
    os_mock["distribution"] = "GNU"
    os_mock["distribution_version"] = "1"
    os_mock["distribution_release"] = "1"
    os_mock["distribution_major_version"] = "1"
    os_mock["path"] = "/foo"
    os_mock["machine"] = "x86_64"
    os_mock["architecture"] = "x86_64"

    collected_facts = {}
    collected_facts["ansible_os_family"] = "GNU"
    collected_facts["ansible_system"] = "GNU/Hurd"
    collected_facts["ansible_distribution"] = os_mock["distribution"]

# Generated at 2022-06-20 17:29:15.773353
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == "GNU"


# Generated at 2022-06-20 17:29:16.895835
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_obj = HurdHardware()
    assert hardware_obj.platform == 'GNU'


# Generated at 2022-06-20 17:29:27.957387
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.collector import TestCollector

    # Create a instance of TestCollector class
    test_collector = TestCollector()

    # Create a HurdHardware instance
    hurd_hardware = HurdHardware()

    # Instantiate a mock object
    class Mock_HurdHardware:
        def populate(self, **kwargs):
            return {'f1': 'v1', 'f2': 'v2'}

    # Add the mock object to the TestCollector stack
    test_collector.add_mock(HurdHardware, Mock_HurdHardware)

    # Call the method under test
    result = hurd_hardware.populate()

    # Assert the result
    assert result == {'f1': 'v1', 'f2': 'v2'}

# Generated at 2022-06-20 17:29:40.837886
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-20 17:29:49.404890
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = HurdHardware().populate()
    assert result == {
        'uptime': {
            'seconds': 7,
            'hours': 0,
            'minutes': 0,
            'days': 0
        },
        'memory': {
            'total': 24,
            'swap': {
                'total': 0
            }
        },
        'mounts': [{
            'options': 'rw',
            'mount': '/',
            'device': '/dev/sda1'
        }]
    }

# Generated at 2022-06-20 17:29:52.445145
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.distribution == None


# Generated at 2022-06-20 17:29:54.747700
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    c = HurdHardwareCollector()
    assert c.platform == 'GNU'
    assert issubclass(c._fact_class, HurdHardware)

# Generated at 2022-06-20 17:30:00.910686
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._priority == 10.0



# Generated at 2022-06-20 17:30:04.522193
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardwareCollector.collect()
    assert hurd_hw['uptime_seconds'] > 0
    assert hurd_hw['memory_mb']['real']['total'] > 0
    assert 'mounts' in hurd_hw

# Generated at 2022-06-20 17:30:17.566801
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    facts_instance = Facts()
    hardware_instance = LinuxHardware()
    hurdhw_instance = HurdHardwareCollector(facts_instance, hardware_instance)
    assert hurdhw_instance.fact_class is LinuxHardware
    assert hurdhw_instance._platform is 'GNU'


# Generated at 2022-06-20 17:30:18.915258
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert hurd_facts.platform == 'GNU'

# Generated at 2022-06-20 17:30:19.922653
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 17:30:20.761602
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    x = HurdHardwareCollector()
    assert x.platform == 'GNU'

# Generated at 2022-06-20 17:30:32.050961
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    setup of mocked data
    """

    HurdHardware_get_uptime_facts_out = {
        'uptime_seconds': 1,
        'uptime_short': '0:00:01.00'
    }
    HurdHardware_get_memory_facts_out = {
        'memfree_mb': 2,
        'swapfree_mb': 3,
        'memtotal_mb': 4,
        'swaptotal_mb': 5,
    }

# Generated at 2022-06-20 17:30:34.312058
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware({})
    assert isinstance(h, HurdHardware)
    assert h.platform == 'GNU'

# Generated at 2022-06-20 17:30:36.279632
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc
    assert hhc._fact_class
    assert hhc._platform

# Generated at 2022-06-20 17:30:37.456435
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    assert hardware_facts.populate() is not None

# Generated at 2022-06-20 17:30:42.278499
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    # check the correct initialisation
    assert hurd_hw._collector is None
    assert hurd_hw.platform == 'GNU'
    assert hurd_hw.uptime is None
    assert hurd_hw.memfree == 0
    assert hurd_hw.memtotal == 0
    assert hurd_hw.swapfree == 0
    assert hurd_hw.swaptotal == 0
    assert hurd_hw.mounts == []
    assert hurd_hw.mounts_as_strings == []

# Generated at 2022-06-20 17:30:43.720914
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'


# Generated at 2022-06-20 17:31:02.584067
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware._fact_class == HurdHardware and hardware._platform == "GNU"

# Generated at 2022-06-20 17:31:04.827161
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts = HurdHardwareCollector().collect()
    assert "hw_processor_count" in facts, "No hw_processor_count field"

# Generated at 2022-06-20 17:31:06.360696
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    return collector

# Generated at 2022-06-20 17:31:09.089245
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.uptime is not None
    assert hurd_hardware.memory is not None
    assert hurd_hardware.mounts is not None

# Generated at 2022-06-20 17:31:14.246574
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test case for method populate of class HurdHardware
    """
    hurd_hw = HurdHardware()
    facts = {}
    result = hurd_hw.populate(facts)
    assert result.get('uptime', None)
    assert result.get('mounts', None)
    assert result.get('memfree_mb', None)
    assert result.get('swaptotal_mb', None)

# Generated at 2022-06-20 17:31:15.914618
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware({})
    assert hurd_hardware is not None

# Generated at 2022-06-20 17:31:17.971296
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd = HurdHardwareCollector()
    assert hurd.platform == 'GNU'

# Generated at 2022-06-20 17:31:20.230914
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact = HurdHardwareCollector()
    assert fact.platform == 'GNU'


# Generated at 2022-06-20 17:31:21.476375
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    os_obj = HurdHardware()
    assert os_obj

# Generated at 2022-06-20 17:31:24.744146
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert(isinstance(hw_collector, HardwareCollector))
    assert(isinstance(hw_collector._fact_class, HurdHardware))
    assert(hw_collector._platform == 'GNU')


# Generated at 2022-06-20 17:31:59.797428
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()


# Generated at 2022-06-20 17:32:02.223577
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert (hurd_facts.platform == "GNU"), "Error: HurdHardware.platform != 'GNU'"

# Generated at 2022-06-20 17:32:03.927802
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    x = HurdHardwareCollector()
    assert type(x) is HurdHardwareCollector


# Generated at 2022-06-20 17:32:06.801388
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert isinstance(hwc, HardwareCollector)
    assert issubclass(hwc._fact_class, HurdHardware)
    assert hwc._platform == 'GNU'


# Generated at 2022-06-20 17:32:07.852955
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-20 17:32:09.826733
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    "HurdHardwareCollector class should be instantiated"
    hwc = HurdHardwareCollector()
    assert hwc is not None
    assert hwc._platform == 'GNU'

# Generated at 2022-06-20 17:32:14.246768
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Create the HurdHardware class and check the
    platform attribute.
    """
    # HurdHardware is a subclass of LinuxHardware, so
    # creating an object of HurdHardware, it should have
    # a "platform" attribute as GNU.
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-20 17:32:15.084344
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_Hardware = HurdHardware()

# Generated at 2022-06-20 17:32:16.431522
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'
    assert not hurdhw.populate()

# Generated at 2022-06-20 17:32:18.348558
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw_collector = HurdHardwareCollector()
    assert hurd_hw_collector.platform == 'GNU'


# Generated at 2022-06-20 17:33:31.077202
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == HurdHardwareCollector._platform, 'Test Failed: Could not set _platform attribute in test'
    assert obj._fact_class == HurdHardwareCollector._fact_class, 'Test Failed: Could not set _fact_class attribute in test'

# Generated at 2022-06-20 17:33:32.509263
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    hardware_facts = h.populate()
    assert hardware_facts

# Generated at 2022-06-20 17:33:35.474248
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'
    assert obj.get_memory_facts() == {}
    assert obj.get_uptime_facts() == {}
    assert obj.get_mount_facts() == {}

# Generated at 2022-06-20 17:33:36.488191
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc

# Generated at 2022-06-20 17:33:41.316424
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import json
    collector = HurdHardwareCollector()
    result = collector.collect()
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-20 17:33:43.258454
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'

# Generated at 2022-06-20 17:33:44.540253
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware is not None

# Generated at 2022-06-20 17:33:54.580229
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = {}
    hh = HurdHardware()
    # method get_uptime_facts should return {'uptime': str}
    result.update(hh.get_uptime_facts())
    # method get_memory_facts should return {'memtotal_mb': int, 'memfree_mb': int}
    result.update(hh.get_memory_facts())
    # method get_mount_facts should return {'mounts': list}
    result.update(hh.get_mount_facts())
    assert sorted(result.keys()) == sorted([
        'uptime',
        'memtotal_mb',
        'memfree_mb',
        'mounts'
    ])

# Generated at 2022-06-20 17:33:58.948604
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    facts = hardware_facts.populate()
    assert facts['uptime_seconds'] == 0
    assert facts['uptime_hours'] == 0
    assert facts['uptime_days'] == 0
    assert facts['memtotal_mb'] == 0
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['mounts'] == []

# Generated at 2022-06-20 17:34:00.503719
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert isinstance(hw.populate(), dict)

# Generated at 2022-06-20 17:36:39.956514
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    hu = HurdHardware()
    hu.populate(facts)

# Generated at 2022-06-20 17:36:42.029063
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert isinstance(hc, HardwareCollector)

# Generated at 2022-06-20 17:36:44.164972
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert (hurd_hardware.platform == 'GNU')


# Generated at 2022-06-20 17:36:45.008294
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware().populate()

# Generated at 2022-06-20 17:36:53.267701
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    ret = hurdhw.populate()
    assert ret['uptime_seconds'] == 15
    assert ret['uptime_hours'] == 0
    assert ret['uptime_days'] == 0
    assert ret['memtotal_mb'] == 2967
    assert ret['memfree_mb'] == 2265
    retrieved = ['mounts', 'swapfree_mb', 'memfree_mb', 'memtotal_mb', 'uptime_days', 'uptime_hours', 'uptime_seconds']
    for item in retrieved:
        assert item in ret
    assert ret['mounts'][0]['device'] == '/dev/hd0s1'
    assert ret['mounts'][0]['fstype'] == 'ufs'
    assert ret['mounts'][0]['mount'] == '/'

# Generated at 2022-06-20 17:36:55.664266
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {}
    hurd_hardware = HurdHardware(collected_facts)
    facts = hurd_hardware.populate(collected_facts=collected_facts)
    assert isinstance(facts, dict)

# Generated at 2022-06-20 17:36:59.014799
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Test with an instance of class HurdHardwareCollector
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 17:37:01.388277
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)



# Generated at 2022-06-20 17:37:06.626459
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    mocked_facts = {
        'uptime_seconds': 0,
        'mounts': ['hello', 'What\'s', 'up', 'doc']
    }
    expected_facts = {
        'uptime_seconds': 0,
        'mounts': ['hello', 'What\'s', 'up', 'doc']
    }

    hardware_facts = HurdHardware(None, mocked_facts)
    hardware_facts.populate()

    for k, v in expected_facts.items():
        assert hardware_facts._facts[k] == v


# Generated at 2022-06-20 17:37:09.308614
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'
    assert hw._fact_class == HurdHardware
