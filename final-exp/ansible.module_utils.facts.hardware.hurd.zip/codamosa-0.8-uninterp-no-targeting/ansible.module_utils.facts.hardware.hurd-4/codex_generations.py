

# Generated at 2022-06-20 17:28:01.253584
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:28:03.231163
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

if __name__ == '__main__':
    test_HurdHardware()

# Generated at 2022-06-20 17:28:05.433686
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    expected_platform = 'GNU'
    hardware_collector = HurdHardwareCollector()

    assert expected_platform == hardware_collector._platform

# Generated at 2022-06-20 17:28:09.701460
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    '''Constructor of module HurdHardwareCollector'''

    test_HurdHardwareCollector_obj = HurdHardwareCollector()
    assert test_HurdHardwareCollector_obj.platform == 'GNU'
    assert test_HurdHardwareCollector_obj.collect()['uptime']['days'] != 0
    


# Generated at 2022-06-20 17:28:20.105116
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import tempfile
    import sys
    import time
    import os

    hw = HurdHardware()

    uptime_path = tempfile.NamedTemporaryFile(mode='w+')
    uptime_path.write('1 2 3 4 5 6 7')
    uptime_path.flush()

    memory_path = tempfile.NamedTemporaryFile(mode='w+')
    memory_path.write('\n'.join([
        'MemTotal: 332768 kB',
        'MemFree: 31188 kB',
        'MemShared: 0 kB',
        'Buffers: 0 kB',
        'Cached: 236988 kB',
        'SwapTotal: 734003 kB',
        'SwapFree: 734003 kB'
    ]))
    memory_path.flush()

# Generated at 2022-06-20 17:28:20.914693
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware() is not None

# Generated at 2022-06-20 17:28:31.653268
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """HurdHardware.populate() returns expected facts."""
    collect_hardware = HurdHardwareCollector().collect()
    assert collect_hardware['uptime'] == 1340635
    assert collect_hardware['uptime_seconds'] == 1340635
    assert collect_hardware['uptime_days'] == 15
    assert collect_hardware['uptime_hours'] == 14
    assert collect_hardware['uptime_minutes'] == 18

    assert collect_hardware['memfree_mb'] == 22304
    assert collect_hardware['memtotal_mb'] == 39229
    assert collect_hardware['memfree_percent'] == 56
    assert collect_hardware['memused_percent'] == 44

    assert collect_hardware['swapfree_mb'] == 7462

# Generated at 2022-06-20 17:28:32.741460
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.populate()

# Generated at 2022-06-20 17:28:34.892824
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    assert isinstance(hardware, HurdHardware)
    assert hardware.platform == 'GNU'

# Generated at 2022-06-20 17:28:37.952290
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware('', '', '', '')
    assert hurd_hardware is not None

# Generated at 2022-06-20 17:28:41.247509
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware({})
    assert isinstance(hurd_hardware, HurdHardware)

# Generated at 2022-06-20 17:28:45.507320
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.uptime_cmd == '/hurd/uptime'
    assert hurd_hw.swap_cmd == '/hurd/ps'
    assert hurd_hw.meminfo_files == ['/hurd/meminfo']
    assert hurd_hw.meminfo_files_pattern == ['/hurd/meminfo']
    assert hurd_hw.mount_files == ['/hurd/mounts']
    assert hurd_hw.mount_files_pattern == ['/hurd/mounts']

# Generated at 2022-06-20 17:28:46.686804
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-20 17:28:58.008279
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test to assert that the correct facts are set
    """
    hurdhw = HurdHardware()
    facts = hurdhw.populate()

    # Check if the facts above the LinuxHardware class are set
    assert facts['uptime'] > 0
    assert facts['uptime_format']
    memory_units = ['KiB', 'MiB', 'GiB', 'TiB']
    assert facts['memtotal_mb'] > 0
    assert facts['memtotal_gb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['memfree_gb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swaptotal_gb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['swapfree_gb'] >= 0

# Generated at 2022-06-20 17:29:00.553586
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()

    assert hh is not None

# Generated at 2022-06-20 17:29:02.655137
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)


# Generated at 2022-06-20 17:29:03.535079
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd is not None

# Generated at 2022-06-20 17:29:13.510961
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Tests population of HurdHardware facts"""

    # Test when memory and mount facts cannot be collected
    collected_facts = {'ansible_os_family': 'GNU'}
    test_obj = HurdHardware()
    test_obj.get_uptime = lambda: {'ansible_uptime_seconds': 1234}
    test_obj.get_memory_facts = lambda: {'ansible_memtotal_mb': 2048}
    test_obj.get_mount_facts = lambda: {}
    result = test_obj.populate(collected_facts)
    exp_result = {'ansible_uptime_seconds': 1234, 'ansible_memtotal_mb': 2048}
    assert (result==exp_result)

    # Test when all facts can be collected

# Generated at 2022-06-20 17:29:14.497427
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hdh = HurdHardware()
    assert hdh

# Generated at 2022-06-20 17:29:16.205938
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdHardware

# Generated at 2022-06-20 17:29:18.905979
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h is not None

# Generated at 2022-06-20 17:29:29.732018
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    import ansible.module_utils.facts.hardware.linux

    def mock_get_mount_facts():
        return {'mounts': []}

    def mock_get_memory_facts():
        return {'memtotal_mb': 2446}

    def mock_get_uptime_facts():
        return {'uptime': '10:23'}

    mocked_methods = {
        'get_mount_facts': mock_get_mount_facts,
        'get_memory_facts': mock_get_memory_facts,
        'get_uptime_facts': mock_get_uptime_facts,
    }

    # save original methods
    original_methods = {}

# Generated at 2022-06-20 17:29:37.059231
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()

    memory_facts = hurd_hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0

    uptime_facts = hurd_hw.get_uptime_facts()
    assert 'uptime_sec' in uptime_facts
    assert uptime_facts['uptime_sec'] > 0

    mount_facts = hurd_hw.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-20 17:29:39.378083
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    # TODO
    assert True

# Generated at 2022-06-20 17:29:42.200835
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    '''Test constructor of HurdHardwareCollector'''
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-20 17:29:44.045371
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector is not None

# Generated at 2022-06-20 17:29:54.747512
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import platform
    import os

    hurd_facts = HurdHardware()
    hurd_facts.populate()

    # The Linux files to be used by the class LinuxHardware
    proc_uptime = '/proc/uptime'
    proc_meminfo = '/proc/meminfo'
    proc_mounts = '/proc/mounts'

    # The files to be used by the class HurdHardware
    hurd_proc_uptime = '/proc/uptime'
    hurd_proc_meminfo = '/proc/meminfo'
    hurd_proc_mounts = '/proc/mounts'

    # The expected values for the 'uptime_*' facts
    uptime_facts = {
        'uptime_seconds': None,
        'uptime_hours': None,
        'uptime_days': None
    }

    # The expected values

# Generated at 2022-06-20 17:30:01.314525
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    result = hurd_hardware.populate()
    assert set(result.keys()) == set(('uptime', 'uptime_seconds', 'memfree_mb', 'memtotal_mb', 'mounts', 'swapfree_mb', 'swaptotal_mb'))

# Generated at 2022-06-20 17:30:04.521535
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert isinstance(obj, HardwareCollector)
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'


# Generated at 2022-06-20 17:30:06.663956
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_test_object = HurdHardware(None)

    assert hurd_hardware_test_object.platform == 'GNU'

# Generated at 2022-06-20 17:30:15.445384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hhw = HurdHardwareCollector().get_facts()[HurdHardware]

    collected_facts = { "ansible_system": "GNU" }

    assert hhw.populate(collected_facts)['ansible_uptime_seconds'] > 0
    assert hhw.populate(collected_facts)['ansible_swapfree_mb'] > 0
    assert hhw.populate(collected_facts)['ansible_memfree_mb'] > 0

# Generated at 2022-06-20 17:30:24.264278
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_obj = HurdHardware()
    # This is to supress 'too many local variables' warning.
    # pylint: disable=R0914
    def side_effect(arg):
        if 'proc/mounts' in arg:
            return r'''rootfs / rootfs rw 0 0
tmpfs /dev tmpfs rw,relatime,size=1K 0 0
devpts /dev/pts devpts rw,relatime,gid=5,mode=620,ptmxmode=000 0 0
<Some other filesystem...>
'''
        elif 'proc/uptime' in arg:
            return '12345678 12345678'

# Generated at 2022-06-20 17:30:25.784169
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert(collector.collect() is True)

# Generated at 2022-06-20 17:30:27.558978
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)


# Generated at 2022-06-20 17:30:28.868922
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # TODO: Find a way to mock GNU procfs and memory interface
    pass

# Generated at 2022-06-20 17:30:37.894004
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import json
    import pytest
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.hurd import HurdHardware

    hurd_hw = HurdHardware()
    hurd_hw.get_uptime_facts = lambda: {'uptime_seconds': 12345,
                                        'uptime_string': '5/5/5'}
    hurd_hw.get_memory_facts = lambda: {'memtotal_mb': 1024,
                                        'memfree_mb': 512}
    hurd_hw.get_mount_facts = lambda: {'mounts': [{"mount": "/"}]}
    collected_facts = hurd_hw.populate()


# Generated at 2022-06-20 17:30:39.255161
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h = h.populate()
    assert h['uptime'] > 0

# Generated at 2022-06-20 17:30:40.534634
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-20 17:30:42.072581
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts is not None

# Generated at 2022-06-20 17:30:43.223313
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:30:47.998465
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:30:51.028065
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector(None)
    assert hw._fact_class == HurdHardware
    assert hw._platform == 'GNU'

# Generated at 2022-06-20 17:30:52.649132
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector().platform == HurdHardwareCollector._fact_class.platform


# Generated at 2022-06-20 17:31:00.794088
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module = MagicMock()
    hardware_facts = HurdHardware(module)

    hardware_facts.get_uptime_facts = MagicMock(return_value={'uptime_seconds': 100})
    hardware_facts.get_memory_facts = MagicMock(return_value={'memtotal_mb': 1024})
    hardware_facts.get_mount_facts = MagicMock(return_value={'mounts': [{'device': '/dev/sda', 'mount': '/'}]})

    facts = hardware_facts.populate()
    assert facts.get('uptime_seconds') == 100
    assert facts.get('memtotal_mb') == 1024
    assert facts.get('mounts')[0]['device'] == '/dev/sda'



# Generated at 2022-06-20 17:31:03.055744
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_fact = HurdHardware()

    assert hardware_fact.platform == 'GNU'


# Generated at 2022-06-20 17:31:12.260969
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a new HurdHardware instance
    hardware = HurdHardware()

    # Dummy data for collected facts and facts to be returned
    collected_facts = {
        "ansible_processor": ["6"]
    }
    facts_to_return = {
        "ansible_processor": ["6"],
        "ansible_processor_cores": 6,
        "ansible_processor_threads_per_core": 1,
        "ansible_processor_vcpus": 6,
        "ansible_processor_count": 6,
        "ansible_memtotal_mb": 0.0,
        "ansible_mounts": []
    }

    # Call the populate method and compare the output
    assert(hardware.populate(collected_facts) == facts_to_return)

# Generated at 2022-06-20 17:31:15.678780
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware

# Generated at 2022-06-20 17:31:20.237413
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.get('uptime_seconds')
    assert h.get('mounts')
    assert h.get('memtotal_mb')
    assert h.get('ansible_facts')['ansible_processor_cores']

# Generated at 2022-06-20 17:31:22.137839
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:31:24.048879
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:31:34.406699
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()

    assert hw_collector._fact_class == HurdHardware
    assert hw_collector._platform == 'GNU'



# Generated at 2022-06-20 17:31:43.445063
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware(None)

    h.get_uptime_facts = lambda: {'uptime_seconds': 1}
    h.get_memory_facts = lambda: {'memtotal_mb': 2}
    h.get_mount_facts = lambda: {'mounts': [{'device': 'foo',
                                             'mount': '/',
                                             'fstype': 'tmpfs',
                                             'options': 'rw,relatime',
                                             'size_total': 3145728,
                                             'size_available': 19922944}]}

    facts = h.populate()

    assert isinstance(facts, dict)

# Generated at 2022-06-20 17:31:45.712274
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_Hardware = HurdHardware()
    hardware_facts = hurd_Hardware.populate()
    assert hardware_facts is not None
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert 'filesystems' in hardware_facts

# Generated at 2022-06-20 17:31:46.934230
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'

# Generated at 2022-06-20 17:31:55.845170
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}

# Generated at 2022-06-20 17:31:58.787965
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()

    assert hw_collector._fact_class == HurdHardware
    assert hw_collector._platform == 'GNU'

# Generated at 2022-06-20 17:32:04.564263
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collecting_object = HurdHardware()
    facts = collecting_object.populate()
    assert facts == {
        'memory': {
            'swap': {'available': '0', 'capacity': 0, 'total': '0'},
            'virtual': {'available': '0', 'capacity': 0, 'total': '0'},
        },
        'uptime': {'seconds': '0'},
    }

# Generated at 2022-06-20 17:32:06.727450
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw
    assert hurd_hw.uptime
    assert hurd_hw.memory
    assert hurd_hw.swapmem

# Generated at 2022-06-20 17:32:10.308993
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Creates a HurdHardware object and tries to retrieve the
    uptime, memory, mount facts.
    """
    hurd_hw_collector = HurdHardwareCollector()
    hurd_hw = hurd_hw_collector.collect(None, {})

    assert hurd_hw['uptime_seconds']
    assert hurd_hw['memtotal_mb']
    assert hurd_hw['mounts']

# Generated at 2022-06-20 17:32:14.247470
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware("/proc", "/mount")
    assert(hw.sysfs_mount == "/sys")
    assert(hw.procfs_mount == "/proc")
    assert(hw.mount_path == "/mount")
    assert(hw.platform == "GNU")


# Generated at 2022-06-20 17:32:33.107508
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    args = {'collected_facts': {'ansible_distribution': 'Hurd',
                                'ansible_distribution_version': '0.4'}}
    hw = HurdHardware(args, ansible_facts={})
    facts = hw.populate()

    assert isinstance(facts, dict)
    assert 'mounts' in facts
    assert 'swapfree_mb' in facts
    assert 'uptime' in facts
    assert 'uptime_hours' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-20 17:32:35.363894
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-20 17:32:36.545720
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._platform == 'GNU'

# Generated at 2022-06-20 17:32:45.590393
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts_dict = {'thread_as': '', 'thread_as_list': ['i386/i386', 'i386/x86_64'], 'page_size': '4096', 'page_size_list': ['4096'], 'thread_size': '4096', 'thread_size_list': ['4096'], 'system_type': 'hurd', 'system_type_list': ['hurd'], 'virtual': 'virtual', 'virtual_list': ['virtual']}

# Generated at 2022-06-20 17:32:48.566253
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class == HurdHardware
    assert hw_collector._platform == 'GNU'


# Generated at 2022-06-20 17:32:49.410847
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:32:51.158295
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert isinstance(collector._fact_class, HurdHardware)

# Generated at 2022-06-20 17:32:52.701360
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert(hurd_hw)

# Unit tests for HurdHardwareCollector

# Generated at 2022-06-20 17:32:56.132724
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:32:58.560526
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdh = HurdHardware()
    assert hurdh.platform == 'GNU'


# Generated at 2022-06-20 17:33:29.399233
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'


# Generated at 2022-06-20 17:33:32.549495
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Constructor test:
    #    Create an object of the class with its defined platform
    obj = HurdHardwareCollector()
    assert obj
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware


# Generated at 2022-06-20 17:33:34.889576
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        HurdHardwareCollector()
    except Exception as ex:
        print ("HurdHardwareCollector -> " + ex.message)


# Generated at 2022-06-20 17:33:37.595214
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardwareCollector({}, None)
    collected_facts = hardware.collect()

    assert 'uptime' in collected_facts
    assert 'uptime_seconds' in collected_facts
    assert 'uptime_hours' in collected_facts
    assert 'uptime_days' in collected_facts

# Generated at 2022-06-20 17:33:47.193591
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def get_mount_facts(self):
        raise TimeoutError
    import ansible.module_utils.facts.hardware.linux
    ansible.module_utils.facts.hardware.linux.LinuxHardware.get_mount_facts = get_mount_facts

    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert 'uptime_seconds' in hardware_facts
    assert 'uptime_hours' in hardware_facts
    assert 'uptime_days' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts

# Generated at 2022-06-20 17:33:50.799584
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Instanciate HurdHardware
    hardware = HurdHardware()

    # Call method populate of class HurdHardware
    # and check that method populate returns a
    # dictionary
    assert isinstance(hardware.populate(), dict)

# Generated at 2022-06-20 17:33:53.122154
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
   collector = HurdHardwareCollector()
   assert collector.platform == 'GNU'

# Generated at 2022-06-20 17:33:54.705071
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-20 17:33:56.166259
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.platform == 'GNU'


# Generated at 2022-06-20 17:33:57.297500
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    _hw_obj = HurdHardware()


# Generated at 2022-06-20 17:35:02.233965
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)
    assert HurdHardwareCollector._fact_class is HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'


# Generated at 2022-06-20 17:35:03.106607
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware.populate(None)

# Generated at 2022-06-20 17:35:04.930700
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()._platform == 'GNU'


# Generated at 2022-06-20 17:35:16.121648
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware._read_from_cmd = lambda x: "0123456789"
    hardware._read_from_file = lambda x: "0123456789"
    hardware.uptime = 1234
    hardware.sys_vendor = 'GNU/Hurd'
    hardware.kernel = 'GNU/Hurd'
    hardware.physical_memory_mb = 4 * 1024
    hardware.swap_mb = 4 * 1024
    hardware.partitions ={
        '/dev/ps0': {'mount': '/', 'fstype': 'ext2'},
        '/dev/ps1': {'mount': '/home', 'fstype': 'ext3'}
    }
    facts = hardware.populate()
    assert facts['uptime'] == 1234

# Generated at 2022-06-20 17:35:18.554025
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware and collector._platform == 'GNU'

# Generated at 2022-06-20 17:35:20.465249
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-20 17:35:21.369911
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    assert hardware.populate()['uptime_seconds'] != 0

# Generated at 2022-06-20 17:35:31.332816
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    total_mem, free_mem, buffer_mem, cache_mem, swap_total_mem, swap_free_mem, swap_cached_mem = hurd_hw.get_memory_facts()
    assert total_mem == 9217088
    assert free_mem == 2213888
    assert buffer_mem == 423424
    assert cache_mem == 5153024
    assert swap_total_mem == 0
    assert swap_free_mem == 0
    assert swap_cached_mem == 0
    uptime_secs, idle_secs = hurd_hw.get_uptime_facts()
    assert uptime_secs == 969
    assert idle_secs == 969
    mount_facts = hurd_hw.get_mount_facts()
    assert mount_facts['mounts']

# Generated at 2022-06-20 17:35:33.368169
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert('platform' in hurd_hardware.facts)
    assert(hurd_hardware.facts['platform'] == 'GNU')

# Generated at 2022-06-20 17:35:35.863558
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'


# Generated at 2022-06-20 17:37:55.617058
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    import os
    import platform
    import unittest

    class TestHurdHardware(unittest.TestCase):
        def test_constructor(self):
            hurd_hardware = HurdHardware()
            self.assertIsInstance(hurd_hardware, HurdHardware)
            self.assertEqual(hurd_hardware.mount_facts['devicefacts']['device_mountpoints']['/'], '/')
            self.assertEqual(hurd_hardware.mount_facts['devicefacts']['device_mountpoints']['/dev'], '/dev')
            self.assertIsInstance(hurd_hardware.uptime_facts['uptime'], int)

    def main():
        unittest.main()


# Generated at 2022-06-20 17:37:56.847442
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._platform == 'GNU'

# Generated at 2022-06-20 17:37:59.383078
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class is HurdHardware
    assert hhc._platform == 'GNU'