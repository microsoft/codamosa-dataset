

# Generated at 2022-06-20 17:28:00.181596
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:28:03.092308
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hc = HurdHardware()
    facts = hc.populate()
    assert facts == {}

# Generated at 2022-06-20 17:28:04.946985
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'


# Generated at 2022-06-20 17:28:07.274707
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert isinstance(h._fact_class, HurdHardware)
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:28:17.862422
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardware(dict())

    hardware_obj.get_uptime_facts = mock.Mock(return_value={'uptime_seconds': 1234567890})
    hardware_obj.get_memory_facts = mock.Mock(return_value={'memtotal_mb': 1234567890, 'memfree_mb': 1234567890})
    hardware_obj.get_mount_facts = mock.Mock(return_value={'mounts': [{'device': 'dev', 'mount': 'mnt', 'fstype': 'fst', 'opts': 'opts'}]})

    hardware_facts = hardware_obj.populate()

    assert hardware_facts['uptime_seconds'] == 1234567890
    assert hardware_facts['memtotal_mb'] == 1234567890
    assert hardware_

# Generated at 2022-06-20 17:28:18.516016
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-20 17:28:20.302301
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:28:21.384914
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-20 17:28:22.680981
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    gnuhardware = HurdHardware(None)

    assert gnuhardware is not None


# Generated at 2022-06-20 17:28:25.430423
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector(None, None, None)
    hurd_hardware = hurd_hardware_collector.collect(None, None)
    assert isinstance(hurd_hardware.get('uptime_seconds'), float)
    assert isinstance(hurd_hardware.get('memtotal_mb'), int)

# Generated at 2022-06-20 17:28:28.829497
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)


# Generated at 2022-06-20 17:28:32.804774
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._platform == 'GNU', "HurdHardwareCollector._platform = '{}' != 'GNU'".format(_platform)
    assert hhc._fact_class == HurdHardware, "HurdHardwareCollector._fact_class = '{}' != 'HurdHardware'".format(_fact_class)

# Generated at 2022-06-20 17:28:33.609655
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert 'LinuxHardware' in str(HurdHardware)

# Generated at 2022-06-20 17:28:34.627364
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware  # shut up pylint

# Generated at 2022-06-20 17:28:37.952339
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_class = HurdHardware()

    assert hurd_class.platform == 'GNU'


# Generated at 2022-06-20 17:28:39.193592
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware


# Generated at 2022-06-20 17:28:44.069682
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware()
    collected_facts = {
        'ansible_os_family': 'Debian',
        'ansible_virtualization_role': 'guest'
    }

    fact_class.populate(collected_facts)

    assert collected_facts['ansible_virtualization_type'] == 'virtualbox'
    assert collected_facts['ansible_distribution'] == 'Debian GNU/Hurd'
    assert collected_facts['ansible_distribution_major_version'] == "10"

# Generated at 2022-06-20 17:28:56.637918
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module_mock = Mock()
    module_mock.get_bin_path.return_value = '/'
    module_mock.run_command.return_value = dict(rc=0, stdout='')

# Generated at 2022-06-20 17:28:58.308889
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware({})

    hardware.populate({})

# Generated at 2022-06-20 17:29:05.775153
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import FactCollector
    from collections import defaultdict

    collector = FactCollector()
    collected_facts = defaultdict(dict)
    collected_facts["ansible_system"] = "GNU"
    collected_facts["ansible_system_vendor"] = "The Debian project"

    result = HurdHardware(collector=collector).populate(collected_facts=collected_facts)
    assert result["ansible_system"] == "GNU"

# Generated at 2022-06-20 17:29:11.159250
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Create an instance of class HurdHardwareCollector
    hwc = HurdHardwareCollector()

    # Check the name of the associated fact class
    assert hwc._fact_class.__name__ == 'HurdHardware'

    # Check the name of the associated platform
    assert hwc._platform == 'GNU'

# Generated at 2022-06-20 17:29:12.109443
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:29:13.724983
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhwc = HurdHardwareCollector()
    assert hhwc._platform == 'GNU'

# Generated at 2022-06-20 17:29:18.022226
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_collector = HurdHardwareCollector()
    hardware_instance = hardware_collector._factory()
    hardware_facts = hardware_instance.populate()
    assert hardware_facts is not None
    assert hardware_facts['uptime'] is not None
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-20 17:29:26.971674
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hhw =  HurdHardware()

    # test FactsLinux class
    assert hhw.get_facts()
    assert hhw.get_file_content('/proc/filesystems')
    assert hhw.get_file_content('/proc/meminfo')
    assert hhw.get_file_content('/proc/uptime')
    assert hhw.get_kernel_release() == '4.4.9'
    assert hhw.get_memory_facts()
    assert hhw.get_mount_facts()
    assert hhw.get_uptime_facts()
    assert hhw.kernel
    assert hhw.platform



# Generated at 2022-06-20 17:29:35.616277
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    dummy_LinuxHardware = HurdHardware()
    dummy_LinuxHardware.module = DummyModule()

# Generated at 2022-06-20 17:29:38.372948
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-20 17:29:43.945654
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    hw_collector = HurdHardwareCollector(None)
    hw = HurdHardware(hw_collector, facts)

    platform = 'GNU'
    hw_facts = hw.populate()

    assert 'platform' in hw_facts
    assert hw_facts['platform'] == platform

# Generated at 2022-06-20 17:29:45.737498
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware is not None

# Generated at 2022-06-20 17:29:49.355703
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware, LinuxHardware)
    assert isinstance(hurd_hardware, HardwareCollector)

# Generated at 2022-06-20 17:29:54.081088
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collected_facts = {}
    test_obj = HurdHardwareCollector(collected_facts)
    assert test_obj != None


# Generated at 2022-06-20 17:29:57.386748
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)


# Generated at 2022-06-20 17:30:08.832756
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    fs = [
        {'kb_size': '10', 'kb_used': '4', 'kb_available': '6', 'mount': '/'},
        {'kb_size': '12', 'kb_used': '5', 'kb_available': '7', 'mount': '/home'},
        {'kb_size': '14', 'kb_used': '6', 'kb_available': '8', 'mount': '/tmp'}
    ]
    with open('/tmp/meminfo', 'w') as f:
        f.write('MemTotal:       10 kB\n')
        f.write('MemFree:        4 kB\n')

# Generated at 2022-06-20 17:30:11.352476
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    f = HurdHardwareCollector()
    assert f.platform == 'GNU'
    assert f._fact_class == HurdHardware

# Generated at 2022-06-20 17:30:15.186887
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'
    assert hardware._uptime == []
    assert hardware._meminfo == []
    assert hardware.collector == 'Linux'



# Generated at 2022-06-20 17:30:16.643574
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    hardware.get_all()

# Generated at 2022-06-20 17:30:22.409058
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Set up object under test
    hw_facter = HurdHardware()

    # Call method under test
    result = hw_facter.populate()

    # Perform assertions
    assert type(result) is dict
    assert 'uptime' in result
    assert 'uptime_seconds' in result
    assert 'memory' in result
    assert type(result['memory']) is dict
    assert 'mounts' in result
    assert type(result['mounts']) is list

# Generated at 2022-06-20 17:30:24.704425
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()

    assert hurdHardware.platform == 'GNU'

# Generated at 2022-06-20 17:30:34.348694
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test for method populate of class HurdHardware"""

    import re
    from ansible.module_utils.facts.hardware.base import Hardware


# Generated at 2022-06-20 17:30:35.858954
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.uptime_proc is not None, "None uptime_proc"
    assert hw.meminfo_proc is not None, "None meminfo_proc"
    assert hw.mountinfo_proc is not None, "None mountinfo_proc"

# Generated at 2022-06-20 17:30:44.196889
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'


# Generated at 2022-06-20 17:30:46.606539
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    ret = h.populate()
    assert type(ret) is dict
    assert 'uptime_seconds' in ret
    assert 'memtotal_mb' in ret
    assert 'virtual' in ret

# Generated at 2022-06-20 17:30:50.923388
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware,HurdHardware)


# Generated at 2022-06-20 17:30:59.830384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware({'gather_subset': ['all']})
    hardware.populate()

    assert isinstance(hardware.uptime, tuple)
    assert len(hardware.uptime) == 3
    assert isinstance(hardware.uptime[0], int)
    assert isinstance(hardware.uptime[1], int)
    assert isinstance(hardware.uptime[2], int)
    assert hardware.uptime[0] >= 0
    assert hardware.uptime[1] >= 0
    assert hardware.uptime[2] >= 0

    assert isinstance(hardware.memory, dict)
    assert isinstance(hardware.memory['MemTotal'], int)
    assert isinstance(hardware.memory['SwapTotal'], int)

    assert isinstance(hardware.mounts, list)


# Generated at 2022-06-20 17:31:05.421543
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    facts_dict = hardware_facts.populate()
    assert 'uptime' in facts_dict
    assert 'memtotal_mb' in facts_dict
    assert 'vendor' in facts_dict
    assert 'product' in facts_dict
    assert 'version' in facts_dict


# Generated at 2022-06-20 17:31:10.908449
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """ Test the module constructor """
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'
    assert isinstance(hurdhw.get_mount_facts(), (dict, bool))
    assert isinstance(hurdhw.get_memory_facts(), (dict, bool))
    assert isinstance(hurdhw.get_uptime_facts(), (dict, bool))

# Generated at 2022-06-20 17:31:15.635213
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware

# Generated at 2022-06-20 17:31:18.825486
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Test construction of HurdHardwareCollector object"""
    hurd_hardware_collector = HurdHardwareCollector()

    assert hurd_hardware_collector

# Generated at 2022-06-20 17:31:27.121195
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # create fake fact class
    fact_class = HurdHardware()

    # create fake generator object which returns fake hardware information
    class Fake_Generator_Object:    # pylint: disable=no-init
        def get_memory_facts(self):
            return {'ansible_memtotal_mb': 256, 'ansible_swaptotal_mb': 512}

        def get_uptime_facts(self):
            return {'ansible_uptime_seconds': 62}


# Generated at 2022-06-20 17:31:29.981236
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:31:54.862755
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # The following argv is required to init a HurdHardware object.
    argv = ['/usr/bin/ansible', '--tree', '/tmp/ansible-47407n5kaY',
            '--module-path', '/tmp/ansible-47407n5kaY/library']

    hw = HurdHardware(argv)
    hw.populate()


if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-20 17:32:05.877394
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    os.environ['ANSIBLE_LOCAL'] = '/tmp/ansible_local'
    facts_obj = HurdHardware()
    facts = facts_obj.populate()
    assert facts['uptime_seconds'] == 18000
    assert facts['mounts'] == [{'mount': '/hurd', 'device': '/dev/hd1s1', 'fstype': 'hfs', 'options': 'rw,noexec,nosuid,nodev', 'uuid': 'abc123'}]
    # memory_facts
    assert facts['memfree_mb'] == 3928
    assert facts['swapfree_mb'] == 1982
    assert facts['ansible_memtotal_mb'] == 8196
    assert facts['ansible_swaptotal_mb'] == 4092
    # check swap warning values

# Generated at 2022-06-20 17:32:07.679182
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    result = hurd_hardware.populate()

    assert (result is not None) and (result['uptime'] is not None)

# Generated at 2022-06-20 17:32:08.397293
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()

# Generated at 2022-06-20 17:32:17.337415
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    # test for existing mount and memory proc directories
    collected_facts = { "ansible_mounts": [ { "device": "/dev/sda",
                                              "mount": "/",
                                              "fstype": "ext4"
                                            } ],
                        "ansible_memfree_mb": 512,
                        "ansible_memtotal_mb": 1024,
                        }
    hardware_facts = hw.populate(collected_facts)
    assert "memory_mb" in hardware_facts.keys()
    assert len(hardware_facts["memory_mb"]) == 2
    assert "swap_mb" in hardware_facts.keys()
    assert len(hardware_facts["swap_mb"]) == 2
    assert "filesystems" in hardware_facts.keys()

# Generated at 2022-06-20 17:32:21.239182
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """check HurdHardwareCollector constructor"""
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class == HurdHardware
    assert hw_collector._platform == 'GNU'


# Generated at 2022-06-20 17:32:27.821357
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert hw.populate() == {'uptime_seconds': 16984, 'uptime_hours': 4, 'uptime_days': 0, 'uptime_timestamp': 1603269512.545545, 'memtotal_mb': None, 'memfree_mb': None, 'memavailable_mb': None, 'swaptotal_mb': None, 'swapfree_mb': None, 'mounts': []}

# Generated at 2022-06-20 17:32:30.091993
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware.get_platform() == 'GNU', "Constructor of class HurdHardwareCollector test failed"

# Generated at 2022-06-20 17:32:32.136076
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_facts = HurdHardwareCollector()
    assert hw_facts._fact_class == HurdHardware

# Generated at 2022-06-20 17:32:35.770027
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hd = HurdHardwareCollector()
    assert hd is not None, "Failed to instantiate HurdHardwareCollector"

# Generated at 2022-06-20 17:33:13.998424
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'

# Generated at 2022-06-20 17:33:19.722038
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Method populate returns a dictionary representing the hardware information of
    the GNU/Hurd system.
    """
    # Call the function being tested with a mock object to simulate a GNU/Hurd
    # system.
    mock_os_data = {
        'path': {
            'available': '/proc/uptime',
            'mount': '/proc/mounts',
            'device': '/proc/partitions'
        }
    }

    mock_uptime = {
        'uptime_seconds': 60000,
        'uptime_string': '1 day, 16:40'
    }


# Generated at 2022-06-20 17:33:22.402945
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-20 17:33:26.924808
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    # Check if:
    # subclass name = 'HurdHardwareCollector'
    # _factClass = HurdHardware
    # _platform = 'GNU'
    assert h.__class__.__name__ == 'HurdHardwareCollector'
    assert h._fact_class.__name__ == 'HurdHardware'
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:33:28.999633
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware


# Generated at 2022-06-20 17:33:29.750918
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:33:36.699873
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    uptime_facts = hurd_hardware.get_uptime_facts()
    memory_facts = hurd_hardware.get_memory_facts()
    mount_facts = {}
    try:
        mount_facts = hurd_hardware.get_mount_facts()
    except TimeoutError:
        pass

    collected_facts = {}
    collected_facts.update(uptime_facts)
    collected_facts.update(memory_facts)
    collected_facts.update(mount_facts)

    hurd_hardware.populate()

    assert hurd_hardware._collected_facts == collected_facts

# Generated at 2022-06-20 17:33:40.950625
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhardware = HurdHardware()
    assert isinstance(hurdhardware, HurdHardware)
    assert isinstance(hurdhardware, LinuxHardware)
    assert isinstance(hurdhardware, HardwareCollector)

# Generated at 2022-06-20 17:33:43.513579
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test HurdHardwareCollector class instantiation.
    """
    facts = HurdHardwareCollector(None, None).collect()
    assert 'uptime_seconds' in facts

# Generated at 2022-06-20 17:33:45.686997
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-20 17:35:06.387844
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()

    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'

# Generated at 2022-06-20 17:35:10.597963
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardwareCollector().collect()

    assert type(hardware_facts.get("mounts")) == list, "mounts are not a list"
    assert type(hardware_facts.get("memfree_mb")) == int, "facter memfree_mb is not a int"

# Generated at 2022-06-20 17:35:12.577533
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.platform == 'GNU'


# Generated at 2022-06-20 17:35:15.674468
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    facts = hurdhw.populate()

    mount_facts = facts['mounts']
    memory_facts = facts['memory']

    # Are the mount point names in the facts dictionary?
    result = 'rootfs' in mount_facts
    assert result == True

    # Is the total number of available KiloBytes in the facts dictionary?
    result = 'total' in memory_facts
    assert result == True

    # Is the total number of available KiloBytes a positive integer?
    result = isinstance(memory_facts['total'], int)
    assert result == True
    if result:
        result = memory_facts['total'] > 0
        assert result == True

# Generated at 2022-06-20 17:35:17.622285
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:35:19.642792
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware.platform == "GNU"

# Generated at 2022-06-20 17:35:21.603607
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:35:24.974857
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """ Unit test for the constructor of class HurdHardwareCollector
    Assert correct initialization and execution of constructor
    """
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector
    assert isinstance(hurd_hardware_collector, HardwareCollector)
    assert hurd_hardware_collector.platform == 'GNU'

# Generated at 2022-06-20 17:35:26.332249
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector is not None

# Generated at 2022-06-20 17:35:28.149435
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert type(hurd_hardware.populate()) == dict

# Generated at 2022-06-20 17:36:53.994815
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hhw = HurdHardware()
    assert hhw.platform == "GNU"


# Generated at 2022-06-20 17:36:55.777942
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_HurdHardware_populate = HurdHardware.populate()
    assert type(test_HurdHardware_populate) == dict


# Generated at 2022-06-20 17:36:58.147436
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hhw = HurdHardware()
    assert isinstance(hhw, LinuxHardware)

# Generated at 2022-06-20 17:36:59.904922
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    ut = HurdHardwareCollector()
    assert ut._platform == 'GNU'
    assert ut._fact_class == HurdHardware

# Generated at 2022-06-20 17:37:05.764229
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    This unit test creates an instance of HurdHardwareCollector class and
    checks the basic initialization of this class
    """
    hurd_hw_collector = HurdHardwareCollector()
    assert hurd_hw_collector._platform == 'GNU'
    assert hurd_hw_collector._fact_class == HurdHardware
    assert hurd_hw_collector.collector == {}
    assert hurd_hw_collector.fallback_collector == {}
    assert hurd_hw_collector.collector_class == HurdHardware

# Generated at 2022-06-20 17:37:09.591840
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    res = hardware_facts.populate()

    # Test if each key in procfs_file_exists is a key of the result
    for key in hardware_facts.procfs_file_exists:
        assert key in res

# Generated at 2022-06-20 17:37:10.347144
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware()

# Generated at 2022-06-20 17:37:12.001277
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts_collector = HurdHardwareCollector()
    assert facts_collector
    assert facts_collector.platform == 'GNU'

# Generated at 2022-06-20 17:37:14.262204
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == "GNU"
    assert hh.facts == {}


# Generated at 2022-06-20 17:37:23.042418
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # setup
    hardware = HurdHardware()
    # execute
    hardware.populate()

    # assert
    assert hardware.uptime
    assert hardware.filesystem

    assert hardware.uptime['uptime']
    assert hardware.uptime['uptime_seconds']
    assert hardware.uptime['idletime']
    assert hardware.uptime['idletime_seconds']

    assert hardware.filesystem['/']['kb_size']
    assert hardware.filesystem['/']['kb_used']
    assert hardware.filesystem['/']['kb_available']
    assert hardware.filesystem['/']['capacity']
    assert hardware.filesystem['/']['mount']

    assert hardware.memory['total']
    assert hardware.memory['free']