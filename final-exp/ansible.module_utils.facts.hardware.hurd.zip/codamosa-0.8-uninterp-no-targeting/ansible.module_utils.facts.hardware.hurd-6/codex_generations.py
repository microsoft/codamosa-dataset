

# Generated at 2022-06-20 17:27:58.618360
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardwareCollector()
    hardware_obj.collect()
    hardware_obj.populate()

# Generated at 2022-06-20 17:28:01.212152
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'



# Generated at 2022-06-20 17:28:03.505345
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'
    assert h._fact_class == HurdHardware

# Generated at 2022-06-20 17:28:08.882202
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    To ensure we have the right initialization, we use this method to ensure
    the class HurdHardwareCollector has the right object.
    """
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class.__name__ == 'HurdHardware'
    assert collector.collect() == collector._fact_class().populate()['ansible_facts']

# Generated at 2022-06-20 17:28:12.696772
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class == HurdHardware

# test the HurdHardware class with mock data

# Generated at 2022-06-20 17:28:15.311582
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_os_family': 'GNU'}
    x = HurdHardware()
    x.populate(collected_facts)
    # need to assert something

# Generated at 2022-06-20 17:28:19.763357
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'
    assert hh._platform == 'GNU'
    assert hh.uptime_fn == '/proc/uptime'
    assert hh.sysctl_fn == '/proc/sysctl'
    assert hh.meminfo_fn == '/proc/meminfo'
    assert hh.mount_fn == '/proc/mounts'

# Generated at 2022-06-20 17:28:22.029638
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)

# Generated at 2022-06-20 17:28:23.861916
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:28:26.259220
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector(None)
    assert hardware._fact_class == HurdHardware
    assert hardware._platform == 'GNU'

# Generated at 2022-06-20 17:28:29.091705
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()


# Generated at 2022-06-20 17:28:30.592996
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert isinstance(hardware, HurdHardware)


# Generated at 2022-06-20 17:28:33.855373
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()

    # __init__() should set key 'uptime_seconds' to 0
    assert hurd_hw.facts['uptime_seconds'] == 0
    # __init__() should set key 'uptime_seconds' to 0
    assert hurd_hw.facts['uptime_hours'] == 0
    # __init__() should set key 'uptime_seconds' to 0
    assert hurd_hw.facts['uptime_days'] == 0

    # __init__() should set key 'ansible_memfree_mb' to 0
    assert hurd_hw.facts['ansible_memfree_mb'] == 0
    # __init__() should set key 'ansible_memtotal_mb' to 0
    assert hurd_hw.facts['ansible_memtotal_mb'] == 0
    # __init__() should

# Generated at 2022-06-20 17:28:42.422665
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test of the function populate of class HurdHardware."""

    # Test of correct functioning of the method populate
    hurd_hardware = HurdHardware()
    hardware_facts = hurd_hardware.populate()

    assert hardware_facts['uptime'] > 0
    assert hardware_facts['memory']['memtotal'] > 0
    assert hardware_facts['memory']['swaptotal'] >= 0

    mount_facts = hardware_facts['mounts']
    mounts = {}
    for fact in mount_facts:
        mounts[fact['mount']] = fact['device']

    assert mounts



# Generated at 2022-06-20 17:28:45.795949
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

    # This is a Linux module so we can directly access the child class
    assert isinstance(hw, LinuxHardware)



# Generated at 2022-06-20 17:28:50.618950
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform is None
    assert hw._has_platform_option is False
    assert hw._platform is None
    assert hw.get_filesystem_info() is None

# Generated at 2022-06-20 17:28:59.684774
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdHardware = HurdHardware()
    fake_collected_facts = {
        'distribution': 'GNU',
        'distribution_version': '0.3'
    }
    hurdHardware.populate(fake_collected_facts)
    assert 'uptime' in hurdHardware.populate(fake_collected_facts)

    assert 'active_processes' in hurdHardware.populate(fake_collected_facts)
    assert 'memoryfree_mb' in hurdHardware.populate(fake_collected_facts)
    assert 'memoryfree_mb' in hurdHardware.populate(fake_collected_facts)
    assert 'swapfree_mb' in hurdHardware.populate(fake_collected_facts)
    assert 'mounts' in hurdHardware.populate(fake_collected_facts)

# Unit test

# Generated at 2022-06-20 17:29:04.639159
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    expected = {'uptime_seconds': 135395.0, 'uptime_hours': 37.61,
        'uptime_days': 1.57, 'swapfree_mb': 0.0, 'swaptotal_mb': 0.0,
        'memfree_mb': 192.0, 'memtotal_mb': 1867.0}

    collected_facts = {
        'distribution_release': '5.6-gnu',
        'distribution_version': '5.6-gnu',
        'os_family': 'GNU/kFreeBSD',
        'os_name': 'GNU/Hurd'}
    actual_facts = hurd_hardware.populate(collected_facts)

    assert actual_facts == expected

# Generated at 2022-06-20 17:29:07.661104
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert(hc._platform == 'GNU')

# Generated at 2022-06-20 17:29:09.340589
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class._platform == 'GNU'

# Generated at 2022-06-20 17:29:17.068782
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    host = HurdHardware()
    assert isinstance(host._uptime, (int, float))
    assert host._uptime > 0

    assert isinstance(host._memory['physical']['total'], (int, float))
    assert host._memory['physical']['total'] > 0

    assert isinstance(host.uptime, (int, float))
    assert host.uptime > 0

    assert isinstance(host.memtotal_mb, (int, float))
    assert host.memtotal_mb > 0

# Generated at 2022-06-20 17:29:28.068639
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    facts = hurdhw.populate()

# Generated at 2022-06-20 17:29:31.867964
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    uptime = hardware.get_uptime_facts()
    memory = hardware.get_memory_facts()
    mount = hardware.get_mount_facts()
    hardware_facts = {**uptime, **memory, **mount}
    assert hardware_facts == hardware.populate()

# Generated at 2022-06-20 17:29:35.396834
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Test GNU/Hurd specific fact collection used in the constructor."""

    hurd_hw = HurdHardware()

    assert hurd_hw.platform == 'GNU'
    assert hurd_hw.distribution is None

# Generated at 2022-06-20 17:29:37.750742
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Test constructor of class HurdHardwareCollector"""

    try:
        obj = HurdHardwareCollector()
    except:
        assert False

# Generated at 2022-06-20 17:29:45.862047
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hints=['GNU']
    hhc = HurdHardwareCollector(None)
    assert hhc._platform == 'GNU'

    # Constructor with hints
    hhc = HurdHardwareCollector(None, hints=hints)
    assert hhc._platform == 'GNU'

    # Constructor with platform
    hhc = HurdHardwareCollector(None, platform='GNU')
    assert hhc._platform == 'GNU'



# Generated at 2022-06-20 17:29:49.012332
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()
    assert hw.uptime_facts is not None
    assert hw.memory_facts is not None
    assert hw.mount_facts is not None

# Generated at 2022-06-20 17:29:49.568973
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj is not None


# Generated at 2022-06-20 17:29:51.232105
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.__class__.__name__ == 'HurdHardwareCollector'


# Generated at 2022-06-20 17:29:52.313214
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert type(hurd_hw.populate()) == dict


# Generated at 2022-06-20 17:30:01.873495
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        import procfs
        assert HurdHardwareCollector.eventually_available()
    except ImportError:
        assert not HurdHardwareCollector.eventually_available()

# Generated at 2022-06-20 17:30:03.078749
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:30:04.475986
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(), HurdHardwareCollector)

# Generated at 2022-06-20 17:30:06.613371
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    target = HurdHardwareCollector()
    assert target._fact_class == HurdHardware
    assert target._platform == 'GNU'

# Generated at 2022-06-20 17:30:08.558301
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == "GNU"


# Generated at 2022-06-20 17:30:09.796225
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()


# Generated at 2022-06-20 17:30:13.176489
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Check whether the constructor of HurdHardwareCollector can be invoked without exceptions."""
    HurdHardwareCollector()


# Generated at 2022-06-20 17:30:14.774583
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw is not None

# Generated at 2022-06-20 17:30:15.849774
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
     HurdHardware().populate()

# Generated at 2022-06-20 17:30:17.684742
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:30:27.712513
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    os = 'GNU'
    obj = HurdHardwareCollector()
    hardware = obj.collect()
    assert hardware.platform == os and hardware.__class__.__name__ == 'HurdHardware'

# Generated at 2022-06-20 17:30:29.066212
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().platform == 'GNU'

# Generated at 2022-06-20 17:30:31.319838
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert (hwc._platform == 'GNU')
    assert (hwc._fact_class == HurdHardware)

# Generated at 2022-06-20 17:30:38.075718
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    har = HurdHardware()
    har.gather_uptime_facts = lambda: {'foo': 'uptime'}
    har.gather_memory_facts = lambda: {'bar': 'memory'}
    har.gather_mount_facts = lambda: {'baz': 'mount'}
    collected_facts = har.populate()
    assert collected_facts == {'bar': 'memory', 'baz': 'mount', 'foo': 'uptime'}

# Generated at 2022-06-20 17:30:39.322793
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()

    assert(isinstance(hh, HurdHardware))

# Generated at 2022-06-20 17:30:40.522056
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-20 17:30:44.981627
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw._platform == 'GNU'

    # check if the expected structure is returned
    if hurd_hw.get_mount_facts() or hurd_hw.get_memory_facts():
        assert True
    else:
        assert False

    # check if the expected structure is returned
    if hurd_hw.get_uptime_facts():
        assert True
    else:
        assert False


# Generated at 2022-06-20 17:30:46.386863
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_h = HurdHardware()
    assert isinstance(hurd_h.populate(), dict)


# Generated at 2022-06-20 17:30:53.407942
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()

    expected_memory_facts = {'swapfree_mb': 490.8,
                             'swaptotal_mb': 500.0,
                             'memfree_mb': 34.2,
                             'memtotal_mb': 500.0}
    assert hurd_hw.populate()['memory'] == expected_memory_facts

# Generated at 2022-06-20 17:30:55.695842
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware, LinuxHardware)


# Generated at 2022-06-20 17:31:04.347713
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h_hardware=HurdHardwareCollector()
    assert h_hardware

# Generated at 2022-06-20 17:31:06.748619
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector(None)
    assert collector.platform == "GNU"

# Generated at 2022-06-20 17:31:14.142469
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test HurdHardware class' method 'populate'.
    """

    # Test case: no collected_facts are provided in the argument of method
    # populate. It is verified that method get_memory_facts of class
    # LinuxHardware is called at least once, that get_mount_facts is called at
    # least once and that get_uptime_facts is called at least once.
    def mock_memory_facts(self, collected_facts=None):
        return {'mock_memory_facts': 'mock_memory_facts'}

    def mock_mount_facts(self, collected_facts=None):
        return {'mock_mount_facts': 'mock_mount_facts'}


# Generated at 2022-06-20 17:31:19.199066
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Since we have not means of properly unit testing this
    # method we are checking if it returns a dict type
    ansible_collector = HurdHardwareCollector()
    res = ansible_collector._calculate()
    assert isinstance(res, dict)

# Generated at 2022-06-20 17:31:20.746887
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test = HurdHardwareCollector()
    assert(isinstance(test, HardwareCollector))

# Generated at 2022-06-20 17:31:21.914588
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware({})
    assert hardware is not None

# Generated at 2022-06-20 17:31:24.174908
# Unit test for constructor of class HurdHardware
def test_HurdHardware():

    hurd_hardware = HurdHardware()
    assert 'GNU' in hurd_hardware.platform
    assert isinstance(hurd_hardware, LinuxHardware)


# Generated at 2022-06-20 17:31:25.596734
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'


# Generated at 2022-06-20 17:31:27.887911
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """
    # TODO: implement this test
    pass

# Generated at 2022-06-20 17:31:29.500324
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    pass

# Generated at 2022-06-20 17:31:41.481446
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    hardware_facts = hardware.populate()

    assert hardware_facts['uptime']['seconds'] > 0

# Generated at 2022-06-20 17:31:42.895236
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-20 17:31:46.357019
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    x = HurdHardware()
    assert x._platform ==  'GNU'
    assert x.platform == 'GNU'



# Generated at 2022-06-20 17:31:48.781832
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert isinstance(hurdhw, HardwareCollector)
    assert isinstance(hurdhw, HurdHardware)

# Generated at 2022-06-20 17:31:51.607868
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    if not isinstance(hurd_hardware, HurdHardware):
        raise AssertionError("HurdHardware clas constructor failed.")

# Generated at 2022-06-20 17:31:54.658336
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """
    # Create object for class HurdHardware
    HurdHardware_obj = HurdHardware()
    # Call method populate of class HurdHardware
    facts = HurdHardware_obj.populate()
    assert isinstance(facts, dict)

# Generated at 2022-06-20 17:31:57.452560
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    a = HurdHardware()
    assert a is not None
    assert isinstance(a, HurdHardware)


# Generated at 2022-06-20 17:31:59.152123
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd = HurdHardwareCollector()
    assert hurd._platform == 'GNU'

# Generated at 2022-06-20 17:32:01.107542
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:32:03.210637
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware

# Generated at 2022-06-20 17:32:13.268628
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()

    # check if the fact class is set correctly
    assert hw._fact_class == HurdHardware
    assert isinstance(hw._fact_class(), HurdHardware)

# Generated at 2022-06-20 17:32:14.018552
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector(None)

    assert hw is not None

# Generated at 2022-06-20 17:32:15.764835
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware


# Generated at 2022-06-20 17:32:17.799313
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Arrange
    hurd_hardware = HurdHardware()

    # Act
    facts = hurd_hardware.populate()

    # Assert
    assert 'kernel' in facts
    assert 'architecture' in facts

# Generated at 2022-06-20 17:32:19.042520
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result.platform == 'GNU'

# Generated at 2022-06-20 17:32:23.570925
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware
    assert obj.get_platform() == 'GNU'
    assert obj.get_fact_class() == HurdHardware

# Generated at 2022-06-20 17:32:26.243232
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert isinstance(obj._fact_class, HurdHardware)
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 17:32:31.791240
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    import pytest

    fc = HurdHardwareCollector()
    facts = fc.collect()
    uptime_facts = LinuxHardware.get_uptime_facts()
    hardware_facts = LinuxHardware.get_memory_facts()

    hardware_facts.update(uptime_facts)

    assert facts == hardware_facts

# Generated at 2022-06-20 17:32:43.207026
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware import Hardware

    class TestHurdHardware(HurdHardware):
        """
        Dummy subclass of HurdHardware for testing purposes.
        """

        def __init__(self):
            self.uptime = 0
            self._memoryinfo = os.path.realpath(os.path.join(os.path.dirname(__file__), 'proc_meminfo'))
            self._mounts = os.path.realpath(os.path.join(os.path.dirname(__file__), 'proc_mounts'))

        def get_uptime(self):
            return self.uptime

        def _get_proc_meminfo(self):
            return self._read_

# Generated at 2022-06-20 17:32:45.579361
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    instance = HurdHardwareCollector()
    assert instance._platform == 'GNU'
    assert instance._fact_class.platform == 'GNU'

# Generated at 2022-06-20 17:32:56.436765
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc._fact_class == HurdHardware

# Generated at 2022-06-20 17:32:59.674479
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_obj = HurdHardwareCollector()
    assert hardware_obj._fact_class == HurdHardware
    assert hardware_obj._platform == 'GNU'


# Generated at 2022-06-20 17:33:01.846773
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_obj = HurdHardware()
    mount_facts = hurd_obj.get_mount_facts()
    assert mount_facts is not None and len(mount_facts) > 0

# Generated at 2022-06-20 17:33:04.813897
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_col = HurdHardwareCollector()
    assert hw_col.platform == 'GNU'
    assert hw_col.fact_class == HurdHardware

# Generated at 2022-06-20 17:33:09.309459
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hu = HurdHardware()
    m = hu.get_memory_facts()
    assert 'memtotal_mb' in m
    assert 'memfree_mb' in m
    assert 'swaptotal_mb' in m
    assert 'swapfree_mb' in m



# Generated at 2022-06-20 17:33:10.872457
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'


# Generated at 2022-06-20 17:33:13.176581
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """ test the HurdHardwareCollector constructor """
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-20 17:33:14.590295
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-20 17:33:17.779126
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # This is a simple test to check the functionality of the
    # HurdHardware.populate() method.
    hurd = HurdHardware()
    facts = hurd.populate()
    assert "uptime_seconds" in facts
    assert "mounts" in facts
    assert "memfree_mb" in facts
    assert "swapfree_mb" in facts



# Generated at 2022-06-20 17:33:20.491485
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_obj = HurdHardware({})
    assert hardware_obj.platform == 'GNU'

# Generated at 2022-06-20 17:33:39.680974
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-20 17:33:46.845204
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {'uptime_seconds': 0,
                                        'uptime_hours': 0,
                                        'uptime_days': 0,
                                        'uptime_timestamp': 0,
                                        'memfree_mb': 0,
                                        'memtotal_mb': 0,
                                        'swapfree_mb': 0,
                                        'swaptotal_mb': 0,
                                        'mounts': []}

# Generated at 2022-06-20 17:33:50.003824
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_unit_test = HurdHardware()
    assert (isinstance(hurd_unit_test, HurdHardware))

#Unit test for get_uptime_facts() of class HurdHardware

# Generated at 2022-06-20 17:33:53.297638
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a test object of class HurdHardware and test the populate method
    h = HurdHardware()
    facts = h.populate()
    assert 'cpu0' in facts['ansible_processor']
    assert 'mounts' in facts

# Generated at 2022-06-20 17:33:54.580293
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    instance = HurdHardwareCollector()
    assert isinstance(instance, (HardwareCollector))

# Generated at 2022-06-20 17:33:56.366818
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class == HurdHardware
    assert hhc._platform == 'GNU'

# Generated at 2022-06-20 17:33:58.032921
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_instance = HurdHardware()

    assert isinstance(hurd_hardware_instance, HurdHardware)



# Generated at 2022-06-20 17:33:59.437999
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-20 17:34:01.045273
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:34:02.496972
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    pass


# Generated at 2022-06-20 17:34:46.660590
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    expected_hardware_facts = {'uptime_seconds': 1208, 'swapfree_mb': 0, 'memfree_mb': 22, 'memtotal_mb': 24, 'fstype': {'/': 'hfs'}, 'mountpoints': {'/': '/'}, 'swaptotal_mb': 0}

    actual_hardware_facts = hurd_hw.populate()

    assert actual_hardware_facts == expected_hardware_facts

# Generated at 2022-06-20 17:34:49.484454
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()

    assert hurdhw.files['mounts'] == '/proc/mounts'
    assert hurdhw.files['memory'] == '/proc/meminfo'
    assert hurdhw.files['uptime'] == '/proc/uptime'

# Generated at 2022-06-20 17:34:51.043431
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_collector = HurdHardwareCollector()
    assert fact_collector._platform == 'GNU'

# Generated at 2022-06-20 17:34:59.838329
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module_mock = type('module_mock', (object,), {
        'params': {
            'gather_timeout': 5
        }
    })
    hardware_object = HurdHardware(module_mock)
    hardware_object.distribution = 'Unknown'

    hardware_object.get_uptime_facts = type('uptime_mock', (object,), {
        'return_value': {
            'uptime': 666
        }
    })

    hardware_object.get_mount_facts = type('mount_mock', (object,), {
        'return_value': {
            'mounts': [
                {
                    'mount': '/',
                    'device': '/dev/hda1',
                    'fstype': 'ext3'
                }
            ]
        }
    })

   

# Generated at 2022-06-20 17:35:03.548379
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.platform == 'GNU'  # pylint: disable=E1101
    assert HurdHardwareCollector.priority == 1  # pylint: disable=E1101
    assert HurdHardwareCollector._platform == 'GNU'  # pylint: disable=W0212,E1101
    assert isinstance(HurdHardwareCollector._fact_class, type)  # pylint: disable=W0212,E1101


# Generated at 2022-06-20 17:35:04.980136
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact = HurdHardware()
    fact.populate()


# Generated at 2022-06-20 17:35:07.285831
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create HurdHardware object
    hh = HurdHardware()

    # Call method populate
    facts = hh.populate()

    assert facts != None

# Generated at 2022-06-20 17:35:11.154312
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test HurdHardwareCollector constructor
    """

    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:35:17.330316
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    facts = hurd.populate()
    assert facts == {'uptime': 153125.99, 'uptime_days': 1, 'uptime_hours': 13, 'uptime_seconds': 1314804, 'uptime_minutes': 849,
                     'swapfree_mb': 0, 'memfree_mb': 1382, 'swapsize_mb': 0, 'memtotal_mb': 2048, 'mounts': []}

# Generated at 2022-06-20 17:35:19.134165
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()

# Generated at 2022-06-20 17:36:39.117269
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    noparen = HurdHardware()
    assert noparen.populate() == {'uptime_seconds': 2095.88, 'uptime_hours': 57, 'uptime_days': 0}

# Generated at 2022-06-20 17:36:40.343602
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:36:41.833246
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()

# Generated at 2022-06-20 17:36:43.236490
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'


# Generated at 2022-06-20 17:36:46.549315
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware()
    collected_facts = {'kernel': 'GNU'}
    fact_class.populate(collected_facts)
    assert fact_class.facts['kernel'] == 'GNU'

# Generated at 2022-06-20 17:36:49.795546
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test that the constructor of HurdHardwareCollector does not
    raise any exception.
    """
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector is not None


# Generated at 2022-06-20 17:36:53.130119
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    collector = HurdHardwareCollector()
    facts = collector.collect()
    assert facts['kernel'] == 'GNU'
    assert '_ansible_system' in facts

# Generated at 2022-06-20 17:36:59.930699
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    collected_facts = {'ansible_os_family': 'GNU',
                       'ansible_distribution': 'Hurd',
                       'ansible_distribution_version': 'Hurd'}
    h.populate(collected_facts)
    assert h.populate(collected_facts)['mounts'] is not None
    assert h.populate(collected_facts)['uptime'] is not None
    assert h.populate(collected_facts)['memfree_mb'] is not None

# Generated at 2022-06-20 17:37:02.052850
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()._platform == 'GNU'

# Generated at 2022-06-20 17:37:03.992043
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == "GNU"
    assert hardware._uname_processor is None
    assert hardware._uname_machine is None