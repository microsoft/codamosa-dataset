

# Generated at 2022-06-20 17:27:57.016770
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collect = HurdHardwareCollector()
    assert collect._platform == 'GNU'

# Generated at 2022-06-20 17:28:04.308946
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup a 'mock' module that the HurdHardware class can use
    module = type('module', (object,), dict(params={}))
    module.run_command = lambda *a, **kw: {'rc': 0, 'stdout':'', 'stderr':''}

    # Setup some data for a HurdHardware instance to use
    collected_facts = dict()
    collected_facts['distribution'] = 'GNU'
    collected_facts['distribution_release'] = '0.3'

    # Create the HurdHardware instance
    hw = HurdHardware(module=module)

    # Exercise the populate method
    hw.populate(collected_facts)

# Generated at 2022-06-20 17:28:09.380364
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    # check if basic facts are not empty
    assert facts['uptime_seconds']
    assert facts['uptime_hours']
    assert facts['uptime_days']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['swaptotal_mb']
    assert facts['swapfree_mb']

# Generated at 2022-06-20 17:28:19.858527
# Unit test for constructor of class HurdHardware

# Generated at 2022-06-20 17:28:21.278173
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw._platform == 'GNU'


# Generated at 2022-06-20 17:28:23.579186
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    ur = HardwareCollector()
    sys_info = ur.collect()

    assert sys_info['uptime']
    assert sys_info['uptime_seconds']
    assert sys_info['memory_mb']
    assert sys_info['swap_mb']

# Generated at 2022-06-20 17:28:24.811187
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)

# Generated at 2022-06-20 17:28:27.735848
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert (collector._fact_class == HurdHardware)
    assert (collector._platform == 'GNU')

# Generated at 2022-06-20 17:28:29.978043
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test for constructor of HurdHardwareCollector class
    """
    hardware_collector = HurdHardwareCollector()
    assert(hardware_collector)

# Generated at 2022-06-20 17:28:31.502048
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:28:43.796331
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware({})

    with open("tests/hurd/test_HurdHardware_populate_uptime_facts") as f:
        hw.uptime_facts = f.read()

    # Populate HurdHardware instance with fake /proc and /mount data
    with open("tests/hurd/test_HurdHardware_populate_meminfo") as f:
        hw.meminfo_content = f.read()
    with open("tests/hurd/test_HurdHardware_populate_mounts") as f:
        hw.mounts_content = f.read()

    collected_facts = hw.populate()

    assert collected_facts["ansible_uptime_seconds"] == 1435512
    assert collected_facts["ansible_uptime_days"] == 16
    assert collected_facts

# Generated at 2022-06-20 17:28:46.570854
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'


# Generated at 2022-06-20 17:28:49.244814
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert isinstance(HurdHardware(), HurdHardware)


# Generated at 2022-06-20 17:28:50.336910
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:28:54.730496
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.get_file_content('/proc/meminfo') == hardware.meminfo_content
    assert hardware.get_file_content('/proc/mounts') == hardware.mountinfo_content
    assert hardware.get_file_content('/proc/uptime') == hardware.uptime_content

# Generated at 2022-06-20 17:29:02.737407
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """

    hrddhw = HurdHardware()

    # We only test the presence of facts, not their actual value, since
    # HurdHardware inherits from LinuxHardware and uses the same methods
    # to get the facts, which we already test.
    hrddhw.populate()

    assert 'dns' in hrddhw.facts

# Generated at 2022-06-20 17:29:04.360153
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'


# Generated at 2022-06-20 17:29:06.245506
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:29:08.236259
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()

    assert isinstance(hurd_facts, LinuxHardware)

# Generated at 2022-06-20 17:29:09.837650
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurddata = HurdHardwareCollector()
    assert hurddata.platform == 'GNU'

# Generated at 2022-06-20 17:29:21.721367
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    import sys
    import json

    # Set up fake file input
    uptime_file = os.path.join(os.path.dirname(__file__), 'uptime_test')
    uptime_fp = os.fdopen(os.open(uptime_file, os.O_RDONLY))

    memory_file = os.path.join(os.path.dirname(__file__), 'memory_test')
    memory_fp = os.fdopen(os.open(memory_file, os.O_RDONLY))

    mount_file = os.path.join(os.path.dirname(__file__), 'mount_test')
    mount_fp = os.fdopen(os.open(mount_file, os.O_RDONLY))

    # Set up fake input streams

# Generated at 2022-06-20 17:29:24.711938
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.populate()
    assert hardware_facts.uptime
    assert hardware_facts.memory
    assert hardware_facts.mounts

# Generated at 2022-06-20 17:29:26.214305
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.facts is None


# Generated at 2022-06-20 17:29:27.220644
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.platform == 'GNU'

# Generated at 2022-06-20 17:29:34.272530
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hwh = HurdHardware()
    hw = hwh.populate()

    assert hw['uptime_seconds'] > 0
    assert hw['uptime_string'].startswith('up ')
    assert hw['uptime_hours'] > 0
    assert hw['uptime_days'] > 0
    assert hw['uptime_years'] == 0

    assert hw['memtotal_mb'] > 0
    assert hw['memfree_mb'] > 0
    assert hw['swaptotal_mb'] > 0
    assert hw['swapfree_mb'] > 0



# Generated at 2022-06-20 17:29:36.029194
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:29:37.979704
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
	collector = HurdHardwareCollector()
	assert collector.platform == 'GNU'


# Generated at 2022-06-20 17:29:42.839951
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Creates an instance of HurdHardwareCollector and checks its various
    attributes.
    """
    hurd_hardware_collector = HurdHardwareCollector()

    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:29:45.429965
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts._platform == 'GNU'

# Generated at 2022-06-20 17:29:47.417774
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert isinstance(h, HurdHardwareCollector)

# Generated at 2022-06-20 17:29:51.009479
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h=HurdHardwareCollector()
    assert h._fact_class==HurdHardware
    assert h._platform=='GNU'

# Generated at 2022-06-20 17:29:53.330416
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Unit test for constructor of class HurdHardwareCollector"""
    facter = HurdHardwareCollector()
    assert facter._fact_class is HurdHardware
    assert facter._platform == "GNU"


# Generated at 2022-06-20 17:29:54.358587
# Unit test for constructor of class HurdHardware
def test_HurdHardware():

    hurdHardware = HurdHardware()
    assert hurdHardware is not None

# Generated at 2022-06-20 17:29:58.160566
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector, HurdHardwareCollector)

# Generated at 2022-06-20 17:29:59.091584
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.collect()



# Generated at 2022-06-20 17:30:05.554157
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    result = h.populate()
    assert 'uptime' in result
    assert 'uptime_seconds' in result
    assert result['uptime_seconds'] > 0
    assert 'memtotal' in result
    assert 'memfree' in result
    assert 'memavailable' in result
    assert 'swaptotal' in result
    assert 'swapfree' in result
    assert 'swapcached' in result

# Generated at 2022-06-20 17:30:07.944100
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdHardware

# Generated at 2022-06-20 17:30:11.592846
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    ins = HurdHardware()
    facts = ins.populate()

    assert facts
    assert facts['uptime']
    assert facts['uptime_seconds']
    assert facts['memory_mb']
    assert facts['mounts']

# Generated at 2022-06-20 17:30:21.008790
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.get_uptime_facts = lambda : {'hardware_uptime_seconds': 1000}
    hurd_hardware.get_memory_facts = lambda : {'ansible_memtotal_mb': 1234}
    hurd_hardware.get_mount_facts = lambda : {'ansible_mounts': [{'device': 'dev'}]}
    expected_facts = {'hardware_uptime_seconds': 1000,
                      'ansible_memtotal_mb': 1234,
                      'ansible_mounts': [{'device': 'dev'}]}
    assert hurd_hardware.populate() == expected_facts

# Generated at 2022-06-20 17:30:24.245413
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class is HurdHardware


# Generated at 2022-06-20 17:30:27.877906
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:30:37.055963
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    This method is the unit test for method populate of the class HurdHardware.
    """

    # Defining mock of class HurdHardware
    class MockHurdHardware:
        def __init__(self):
            pass

        @staticmethod
        def get_uptime_facts():
            # Return a dictionary as a fake from get_uptime_facts method
            return {"uptime": 10, "uptime_seconds": 10.0001}

        @staticmethod
        def get_memory_facts():
            # Return a dictionary as a fake from get_memory_facts method
            return {"ansible_memtotal_mb": 10, "ansible_memfree_mb": 10.0001}


# Generated at 2022-06-20 17:30:40.765008
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        HurdHardwareCollector()
    except Exception as e:
        assert False, "Could not instantiate HurdHardwareCollector: " \
            "%s" % e
    else:
        assert True



# Generated at 2022-06-20 17:30:45.743016
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    expected_facts = {
        'disk_info': {},
        'dns': {'domain': ''},
        'mounts': [],
        'uptime_seconds': 0,
        'uptime_string': '',
        'memory_mb': {'swapfree_mb': 0,
                      'swaptotal_mb': 0,
                      'memtotal_mb': 0,
                      'memfree_mb': 0}
        }
    facts = HurdHardware()
    assert expected_facts == facts.populate()

# Generated at 2022-06-20 17:30:48.430194
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()

    assert collector

# Generated at 2022-06-20 17:30:51.098367
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'


# Generated at 2022-06-20 17:30:54.092549
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert isinstance(hardware_collector, HardwareCollector)
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:30:56.740870
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert facts['uptime']['seconds'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['mounts']



# Generated at 2022-06-20 17:30:58.454183
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == "GNU"


# Generated at 2022-06-20 17:31:02.525657
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'


# Generated at 2022-06-20 17:31:06.651523
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
   assert HurdHardwareCollector

# Generated at 2022-06-20 17:31:09.081633
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class.platform == HurdHardware.platform
    assert collector._platform == HurdHardwareCollector._platform


# Generated at 2022-06-20 17:31:14.735049
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts is not None
    assert hardware_facts['uptime']['seconds'] > 0
    assert hardware_facts['uptime_format'] == '%H:%M:%S up %d day(s), %h:%m'
    assert hardware_facts['memory']['swap']['total'] > 0
    assert len(hardware_facts['mounts']) > 0



# Generated at 2022-06-20 17:31:20.137012
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = dict()
    hurd_hw = HurdHardware(facts)

    returned_facts = hurd_hw.populate()
    assert returned_facts.has_key('uptime')
    assert returned_facts.has_key('memtotal_mb')
    assert returned_facts.has_key('mounts')

# Generated at 2022-06-20 17:31:22.054954
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    global module
    module = AnsibleModule(argument_spec={})
    h = HurdHardware()
    h.populate()

# Generated at 2022-06-20 17:31:26.538579
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    test_keys = [
        'uptime',
        'uptime_seconds',
        'mem_swap_free',
        'mem_swap_total',
        'mem_total',
        'mounts',
    ]

    for test_key in test_keys:
        assert test_key in hardware_facts, '%s is not in hardware_facts' % test_key

# Generated at 2022-06-20 17:31:29.696857
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:31:30.779528
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    result = HurdHardware()
    assert result is not None

# Generated at 2022-06-20 17:31:33.277104
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    x = HurdHardwareCollector()
    assert x.get_platform() == 'GNU'
    assert x.get_fact_class() == HurdHardware

# Generated at 2022-06-20 17:31:43.911760
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    import os
    import shutil
    import tempfile
    import unittest

    class TestHurdHardware(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.procfs_path = os.path.join(self.test_dir, 'proc')
            os.mkdir(self.procfs_path)

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def create_procfs_file(self, file_path, file_content):
            file_path = os.path.join(self.procfs_path, file_path)
            with open(file_path, 'w') as procfs_file:
                procfs_file.write(file_content)


# Generated at 2022-06-20 17:31:53.972320
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from ansible_collections.gnu.hurd.plugins.module_utils.facts.hardware.hurd import HurdHardwareCollector
    hardwareCollector = HurdHardwareCollector()
    assert hardwareCollector._platform == 'GNU'
    assert isinstance(hardwareCollector._fact_class(), HurdHardware)

# Generated at 2022-06-20 17:31:57.139974
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    hhc.collect()
    assert hhc._fact_class.platform == HurdHardware.platform

# Generated at 2022-06-20 17:31:59.283817
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()

# Generated at 2022-06-20 17:32:09.087344
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # test with empty input
    facts = HurdHardware().populate(collected_facts={})

    # check for uptime facts
    assert facts.get('uptime_precision') == 'seconds'
    assert facts.get('uptime_seconds') > 0
    assert facts.get('uptime_seconds') == facts.get('uptime_days') * 86400 + facts.get('uptime_hours') * 3600 + facts.get('uptime_minutes') * 60

    # check for memory facts
    assert facts.get('swapfree_mb') > 0
    assert facts.get('swapfree_mb') == facts.get('swapfree') / 1024
    assert facts.get('swaptotal_mb') > 0
    assert facts.get('swaptotal_mb') == facts.get('swaptotal') / 1024

# Generated at 2022-06-20 17:32:14.016917
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    # test whether _fact_class is assigned to HurdHardware
    assert hhc._fact_class == HurdHardware
    # test whether _platform's value is 'GNU'
    assert hhc._platform == 'GNU'

test_HurdHardwareCollector()


# Generated at 2022-06-20 17:32:20.163615
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    assert hardware_facts['uptime_seconds'] >= 0
    assert hardware_facts['uptime_seconds'] == hardware_facts['uptime']
    assert hardware_facts['uptime_days'] >= 0
    assert hardware_facts['uptime_hours'] >= 0
    assert hardware_facts['uptime_minutes'] >= 0

    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['memtotal'] >= 0
    assert hardware_facts['memfree'] >= 0
    assert hardware_facts['swaptotal'] >= 0
    assert hardware_facts['swapfree'] >= 0

   

# Generated at 2022-06-20 17:32:23.727602
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test HurdHardware._populate()
    """
    fact_class = HurdHardware()
    gathered_facts = fact_class.populate()
    print(gathered_facts)


# Generated at 2022-06-20 17:32:26.018852
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test the constructor of class HurdHardwareCollector
    """
    HurdHardwareCollector(None)

# Generated at 2022-06-20 17:32:34.615339
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw_obj = HurdHardware()

# Generated at 2022-06-20 17:32:36.605394
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_h = HurdHardware()
    hurd_h.populate()

# Generated at 2022-06-20 17:33:04.483080
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with unset values
    uptime_facts = HurdHardware().populate()['ansible_facts']
    assert uptime_facts['uptime']
    assert uptime_facts['uptime_seconds']
    assert uptime_facts['uptime_hours']
    assert uptime_facts['uptime_days']
    assert uptime_facts['uptime_timestamp']
    assert uptime_facts['uptime_days'] == int(uptime_facts['uptime_timestamp'] / 86400)

    memory_facts = HurdHardware().populate()['ansible_facts']
    assert memory_facts['memtotal_mb']
    assert memory_facts['memtotal_gb']
    assert memory_facts['memavailable_mb']
    assert memory_facts['memavailable_gb']

# Generated at 2022-06-20 17:33:14.125260
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw_facts = hw.populate()
    assert isinstance(hw_facts, dict)
    assert 'uptime_seconds' in hw_facts
    assert isinstance(hw_facts['uptime_seconds'], int)
    assert 'uptime_hours' in hw_facts
    assert isinstance(hw_facts['uptime_hours'], int)
    assert 'uptime_minutes' in hw_facts
    assert isinstance(hw_facts['uptime_minutes'], int)
    assert 'uptime_days' in hw_facts
    assert isinstance(hw_facts['uptime_days'], int)
    assert 'memtotal_mb' in hw_facts
    assert isinstance(hw_facts['memtotal_mb'], int)

# Generated at 2022-06-20 17:33:23.008636
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module_args = dict()
    fake_fact_module = HurdHardware(module_args)
    # Calling the populate function to fully execute the code
    fake_fact_module.populate()
    if not isinstance(fake_fact_module.uptime, dict):
        raise AssertionError()
    if not isinstance(fake_fact_module.memfree_mb, int):
        raise AssertionError()
    if not isinstance(fake_fact_module.swapfree_mb, int):
        raise AssertionError()
    if not isinstance(fake_fact_module.mounts, list):
        raise AssertionError()


# Generated at 2022-06-20 17:33:31.991141
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    This is a testing function intended to be called by unit tests
    """
    har_instance = HurdHardware()
    facts = har_instance.populate()
    # Check a few facts
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] >= 0
    assert facts['total_mem'] > 0
    assert facts['total_swap'] > 0
    assert facts['available_mem'] > 0
    assert facts['available_swap'] > 0
    assert facts['mem_available_percent'] > 0.0
    assert facts['mem_available_percent'] < 100.0
    assert facts['swap_available_percent'] > 0.0
    assert facts['swap_available_percent'] < 100.0

# Generated at 2022-06-20 17:33:33.751835
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        hurd = HurdHardwareCollector()
        return True
    except:
        return False


# Generated at 2022-06-20 17:33:34.794746
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == "GNU"

# Generated at 2022-06-20 17:33:36.811548
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:33:41.074465
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector, HardwareCollector)
    assert collector.platform == 'GNU'
    assert collector._fact_class is HurdHardware

# Generated at 2022-06-20 17:33:42.696402
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector(None, None)
    assert h


# Generated at 2022-06-20 17:33:46.737798
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()
    assert isinstance(hurdHardware.kernel, str)
    assert isinstance(hurdHardware.uptime, int)
    assert isinstance(hurdHardware.uptime_seconds, int)
    assert isinstance(hurdHardware.swapfree_mb, int)


# Generated at 2022-06-20 17:34:26.995751
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector(): hw = HurdHardwareCollector()


# Generated at 2022-06-20 17:34:28.620457
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert(hurd_hw.populate()["uptime_seconds"] > 0)

# Generated at 2022-06-20 17:34:31.872618
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    collected_facts = {}
    returned_facts = hurd_hw.populate(collected_facts)

    assert all(isinstance(value, dict) for value in returned_facts.values())

    assert 'memfree_mb' in returned_facts

# Generated at 2022-06-20 17:34:34.871800
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert isinstance(hurd_hardware, LinuxHardware)
    assert HurdHardware.platform == 'GNU'
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:34:44.231970
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()

    assert 'fqdn' in facts
    assert facts['fqdn'].endswith('.gnu.org')
    assert 'system_uuid' in facts
    assert 'uptime' in facts
    assert 'uptime_days' in facts
    assert facts['uptime_days'] > 0
    assert 'uptime_hours' in facts
    assert 0 <= facts['uptime_hours'] < 24
    assert 'uptime_seconds' in facts
    assert facts['uptime_seconds'] > 0
    assert 'total_mem' in facts
    assert 0 < facts['total_mem'] < 1e9
    assert 'mounts' in facts
    assert isinstance(facts['mounts'], list)
    assert len(facts['mounts']) > 0

# Generated at 2022-06-20 17:34:53.878426
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class TestHurdHardware:
        def __init__(self):
            self.module = 'testmodule'

    class TestHurdHardwareClass:
        def __init__(self):
            self.module = TestHurdHardware()

    def TestGetMemTotal():
        return 1024

    def TestGetMemFree():
        return 512

    def TestGetMemUsed():
        return TestGetMemTotal() - TestGetMemFree()

    def TestGetMemSwapTotal():
        return 2048

    def TestGetMemSwapFree():
        return 1024

    def TestGetMemSwapUsed():
        return TestGetMemSwapTotal() - TestGetMemSwapFree()

    def TestGetMemSwapTotal():
        return 2048

    def TestGetMemSwapFree():
        return 1024

    def TestGetMemSwapUsed():
        return Test

# Generated at 2022-06-20 17:34:57.169357
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Constructor of class HurdHardware should accept an argument, which has been
    # passed to constructor of superclass LinuxHardware
    returned = HurdHardware({})

    # Assert that returned object is an instance of HurdHardware
    assert isinstance(returned, HurdHardware)

# Generated at 2022-06-20 17:35:04.033610
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    collected_facts = {
        "distribution": "GNU",
        "distribution_version": "0.5"
    }

# Generated at 2022-06-20 17:35:06.085466
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()

    assert hurdhw.platform == 'GNU'


# Generated at 2022-06-20 17:35:08.198988
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:36:28.912577
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class is HurdHardware
    assert obj._platform is 'GNU'

# Generated at 2022-06-20 17:36:29.977316
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == "GNU"

# Generated at 2022-06-20 17:36:39.995282
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys
    import subprocess
    import io
    import re
    import os

    class POpenMock:
        def __init__(self, mystdout, mystderr):
            self.stdout = mystdout
            self.stderr = mystderr

        def communicate(self, *args, **kwargs):
            out, err = self.stdout.read(), self.stderr.read()
            return out, err


    class PopenMock:
        def __init__(self, returncode):
            self.returncode = returncode

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

        def __call__(self, *args, **kwargs):
            return POpenMock

# Generated at 2022-06-20 17:36:42.954583
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hurd_hw = HurdHardware()
    # Call the method populate
    result_dict = hurd_hw.populate()
    assert "uptime_seconds" in result_dict.keys()

# Generated at 2022-06-20 17:36:44.242169
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()


# Generated at 2022-06-20 17:36:45.072227
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

# Generated at 2022-06-20 17:36:54.730281
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardware()
    test_facts = hurd_facts.populate()
    assert test_facts.get('uptime_seconds', None) is not None, \
        'Populate method of class HurdHardware did not return valid uptime seconds'

    assert test_facts.get('uptime_hours', None) is not None, \
        'Populate method of class HurdHardware did not return valid uptime hours'

    assert test_facts.get('uptime_days', None) is not None, \
        'Populate method of class HurdHardware did not return valid uptime days'

    assert test_facts.get('uptime_seconds_raw', None) is not None, \
        'Populate method of class HurdHardware did not return valid uptime seconds raw'


# Generated at 2022-06-20 17:36:57.572322
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        hw = HurdHardwareCollector.factory()
        assert True
    except ImportError:
        assert False

# Generated at 2022-06-20 17:36:58.936912
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    assert hardware.platform == 'GNU'

# Generated at 2022-06-20 17:37:00.465942
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'
