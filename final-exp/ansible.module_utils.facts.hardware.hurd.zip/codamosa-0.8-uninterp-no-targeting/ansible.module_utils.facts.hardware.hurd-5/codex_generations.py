

# Generated at 2022-06-20 17:27:57.776322
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware._module = None
    hardware._collector = HurdHardwareCollector
    hardware.populate()
    return 0

# Generated at 2022-06-20 17:28:01.820878
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.mount_options['nonfs'] == 'noproc,nosysfs,nonfs,noctty'

# Generated at 2022-06-20 17:28:04.556090
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_obj = HurdHardwareCollector()
    assert hurd_obj.collect()['ansible_facts']['ansible_processor'][0]['count'] > 0

# Generated at 2022-06-20 17:28:06.909599
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test of method populate of class HurdHardware"""
    hurd_facts = HurdHardware()
    assert hurd_facts.populate()

# Generated at 2022-06-20 17:28:09.355580
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.facts['memory_mb'] is not None
    assert hardware.facts['mounts'] is not None

# Generated at 2022-06-20 17:28:12.823307
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class is HurdHardware
    assert hhc._platform == 'GNU'

# Generated at 2022-06-20 17:28:13.976593
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware('facts')

# Generated at 2022-06-20 17:28:15.916236
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == "GNU"


# Generated at 2022-06-20 17:28:19.997631
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Create class instance
    hurdhw_instance = HurdHardware()
    hurdhw_instance.get_file_content = lambda file: 'unit_test_data'

    # Call method with empty collected_facts
    collected_facts = {}
    result_facts = hurdhw_instance.populate(collected_facts)

    # Assert method doesn't throw exception
    assert result_facts is not None

# Generated at 2022-06-20 17:28:21.943212
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert hurd_facts.platform == HurdHardware.platform

# Unit tests for constructor of class HurdHardwareCollector

# Generated at 2022-06-20 17:28:26.219399
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.get_all() is not None
    assert obj.get_platform() is not None

# Generated at 2022-06-20 17:28:28.460182
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)
    h.populate()

# Generated at 2022-06-20 17:28:32.866136
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_HurdHardware = HurdHardware()
    result = test_HurdHardware.populate()
    assert 'uptime' in result
    assert 'memfree_mb' in result
    assert 'mounts' in result
    assert 'total_memory_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'memtotal_mb' in result

# Generated at 2022-06-20 17:28:43.347629
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockLinuxHardware(object):
        pass
    class MockHurdHardwareCollector(object):
        def get_file_content(self, filename, module_set_locale=True):
            if filename == '/proc/uptime':
                return '10.42 12.33'

# Generated at 2022-06-20 17:28:45.515247
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector.collectors == []

# Generated at 2022-06-20 17:28:51.570539
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Unit test constructor of class HurdHardwareCollector
    """
    try:
        obj = HurdHardwareCollector()
    except NameError:
        assert False, 'Failed to create an instance of HurdHardwareCollector'
        return
    assert obj.platform == 'GNU'


# Generated at 2022-06-20 17:28:53.624549
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'


# Generated at 2022-06-20 17:28:55.749392
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Call constructor and create an instance of class HurdHardware
    hurd_hardware_instance = HurdHardware()

# Generated at 2022-06-20 17:28:56.815572
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:29:00.370602
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert type(obj._fact_class) == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 17:29:05.134454
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert 'memory' in hurd_hardware.data
    assert 'uptime' in hurd_hardware.data
    assert 'mounts' in hurd_hardware.data


# Generated at 2022-06-20 17:29:07.284643
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts_obj = HurdHardware()
    hardware_facts_obj.populate()

# Generated at 2022-06-20 17:29:09.353730
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts = HurdHardwareCollector()
    assert facts._fact_class == HurdHardware
    assert facts._platform == 'GNU'

# Generated at 2022-06-20 17:29:13.063338
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    linux_hardware = HurdHardware()
    collected_facts = {}

    populated_facts = linux_hardware.populate(collected_facts=collected_facts)

    assert 'uptime' in populated_facts

# Generated at 2022-06-20 17:29:15.550304
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    chassis_list = ['Notebook']
    hw_collector_object = HurdHardwareCollector(chassis_list)
    assert hw_collector_object._fact_class._platform == 'GNU'

# Generated at 2022-06-20 17:29:16.950266
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
   test_object = HurdHardwareCollector({})
   assert test_object.__class__.__name__ == 'HurdHardwareCollector'

# Generated at 2022-06-20 17:29:19.506017
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-20 17:29:21.847302
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 17:29:23.107939
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:29:25.456556
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert hurd_facts.__class__.__name__ == 'HurdHardware'


# Generated at 2022-06-20 17:29:31.867512
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    This function is used to test creation of the object of class
    HurdHardwareCollector.
    """
    obj = HurdHardwareCollector()
    assert obj is not None

# Unit test to test get_mount_facts method of class HurdHardwareCollector

# Generated at 2022-06-20 17:29:33.197352
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware

# Generated at 2022-06-20 17:29:37.389713
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware({})
    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware, LinuxHardware)
    assert isinstance(hurd_hardware, HardwareCollector)

# Generated at 2022-06-20 17:29:41.339435
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware
    facts = {}

    try:
        fact_class.populate(facts)
        fact_class.get_mount_facts()
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-20 17:29:45.688206
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_fact = HurdHardware(None)
    assert isinstance(hurd_hardware_fact, HurdHardware)
    assert hurd_hardware_fact.platform == 'GNU'

# Generated at 2022-06-20 17:29:47.675718
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert isinstance(hardware_collector, HardwareCollector)

# Generated at 2022-06-20 17:29:49.503772
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, LinuxHardware)

# Generated at 2022-06-20 17:29:50.943733
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-20 17:29:52.207273
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-20 17:29:54.271423
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    if isinstance(collector._fact_class(), LinuxHardware):
        assert True
    else:
        assert False


# Generated at 2022-06-20 17:30:04.076435
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()

    assert hwc._fact_class == HurdHardware
    assert hwc._platform == 'GNU'


# Generated at 2022-06-20 17:30:05.464089
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector(None, None).facts_class == HurdHardware

# Generated at 2022-06-20 17:30:07.484003
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    c = HurdHardwareCollector()  # noqa
    assert c.platform == 'GNU'

# Generated at 2022-06-20 17:30:09.756789
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector._get_fact_class()
    assert fact_class is not None
    assert issubclass(fact_class, HurdHardware)



# Generated at 2022-06-20 17:30:21.332109
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}

    collected_facts = hurd_hardware.populate(collected_facts)

    assert collected_facts['uptime_seconds'] is not None
    assert collected_facts['uptime_days'] is not None
    assert collected_facts['uptime_hours'] is not None
    assert collected_facts['uptime_minutes'] is not None

    assert collected_facts['memtotal_mb'] is not None
    assert collected_facts['memfree_mb'] is not None
    assert collected_facts['swaptotal_mb'] is not None
    assert collected_facts['swapfree_mb'] is not None

    for mount in collected_facts['mounts']:
        assert mount['device'] is not None
        assert mount['mount'] is not None

# Generated at 2022-06-20 17:30:23.491037
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.collect()

# Generated at 2022-06-20 17:30:29.606127
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['uptime_days']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['mounts']

# Generated at 2022-06-20 17:30:30.296894
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:30:32.430786
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert HurdHardwareCollector.platform == 'GNU'
    assert isinstance(hw_collector._fact_class(), HurdHardware)

# Generated at 2022-06-20 17:30:42.517836
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_instance = HurdHardware()
    hardware_facts = hardware_instance.populate()

    assert hardware_facts['uptime_seconds'] >= 0
    assert hardware_facts['uptime_seconds'] == hardware_facts['uptime']
    assert hardware_facts['uptime_days'] >= 0

    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['memavailable_mb'] >= 0
    assert hardware_facts['memtotal_mb'] >= hardware_facts['memavailable_mb']

    assert hardware_facts['nodename'] is not None
    assert hardware_facts['nodename'] == hardware_facts['hostname']
    assert hardware_facts['fqdn'] is not None
    assert hardware_facts['domain'] is not None

    for disk in hardware_facts['mounts']:
        assert disk['device']

# Generated at 2022-06-20 17:31:05.661018
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    hh.populate()
    assert hh.hw['memory']['memtotal_mb'] == '4082'
    assert hh.hw['memory']['swaptotal_mb'] == '4082'
    assert hh.hw['memory']['swapfree_mb'] == '4082'


# Generated at 2022-06-20 17:31:06.748536
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()

# Generated at 2022-06-20 17:31:08.080459
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert not hhc._facts

# Generated at 2022-06-20 17:31:11.380352
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:31:24.112557
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup an instance of class HurdHardware with parameters so
    # that the tested method will be able to run
    hurd_hardware = HurdHardware()

# Generated at 2022-06-20 17:31:25.524824
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'



# Generated at 2022-06-20 17:31:30.086069
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert isinstance(hurd, HurdHardware)
    assert isinstance(hurd, LinuxHardware)
    assert hasattr(hurd, 'platform')
    assert hurd.platform == 'GNU'

# Generated at 2022-06-20 17:31:40.861977
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}
    platform_key = 'ansible_hurd_platform'
    uptime_key = 'ansible_hurd_uptime_seconds'
    memory_key = 'ansible_hurd_memtotal_mb'
    mount_key = 'ansible_mounts'

    hardware_facts = hurd_hardware.populate(collected_facts)
    assert hardware_facts[platform_key] == 'GNU'
    assert isinstance(hardware_facts[uptime_key], int)
    assert isinstance(hardware_facts[memory_key], int)
    assert isinstance(hardware_facts[mount_key], (list, tuple))

# Generated at 2022-06-20 17:31:49.374858
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw_facts = hurd_hw.populate()

    assert isinstance(hurd_hw_facts, dict)
    assert isinstance(hurd_hw_facts['uptime_seconds'], float)
    assert isinstance(hurd_hw_facts['virtual_memory'], dict)
    assert isinstance(hurd_hw_facts['mounts'], list)

# Generated at 2022-06-20 17:31:51.524771
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
        hurd = HurdHardware({})
        assert(hurd.platform == 'GNU')


# Generated at 2022-06-20 17:32:32.363046
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_test_facts = {
        'uptime_seconds': 803319,
        'mounts': [
            {'mount': '/', 'device': 'procfs', 'fstype': 'procfs'},
            {'mount': '/boot', 'device': '/dev/sda', 'fstype': 'ext2'},
            {'mount': '/home', 'device': '/dev/sda', 'fstype': 'ext2'},
            {'mount': '/usr', 'device': '/dev/sda', 'fstype': 'ext2'},
            {'mount': '/tmp', 'device': '/dev/sda', 'fstype': 'ext2'}
        ],
        'memfree_mb': 397,
        'memtotal_mb': 480
    }

    hurd_hardware = Hurd

# Generated at 2022-06-20 17:32:41.637142
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}
    expected_facts = {
        'uptime_seconds': 'unknown',
        'uptime_hours': 'unknown',
        'uptime_days': 'unknown',
        'uptime': 'unknown',
        'memtotal_mb': 0,
        'memfree_mb': 0,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'mounts': [],
    }
    facts = hurd_hardware.populate(collected_facts)

    assert facts == expected_facts


# Generated at 2022-06-20 17:32:44.108714
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware({})
    assert hardware._platform == 'GNU'
    assert issubclass(hardware.__class__, LinuxHardware)

# Generated at 2022-06-20 17:32:46.072286
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-20 17:32:52.078844
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts
    assert 'uptime_seconds' in hardware_facts

    assert hardware_facts['uptime_seconds'] > 0

    assert 'mounts' in hardware_facts

    assert hardware_facts['available_memory_mb'] > 0
    assert hardware_facts['available_memory_mb'] == hardware_facts['available_memory_bytes'] / 2**20

    assert hardware_facts['total_memory_mb'] == hardware_facts['available_memory_mb']

# Generated at 2022-06-20 17:32:54.212450
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert(obj)


# Generated at 2022-06-20 17:32:55.721317
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware()


# Generated at 2022-06-20 17:32:57.329534
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-20 17:32:59.876153
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_instance = HurdHardwareCollector()
    assert hw_instance._platform == 'GNU'


# Generated at 2022-06-20 17:33:00.766507
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.collect()

# Generated at 2022-06-20 17:34:24.744472
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    mocked_facts = {}
    mocked_uptime_facts = {'uptime_seconds': 10}
    mocked_memory_facts = {'memtotal_mb': 10, 'memfree_mb': 5}
    mocked_mount_facts = {'mounts': [{'device': '/dev/sda1', 'mount': '/'}]}

    import ansible.module_utils.facts.hardware.linux
    ansible.module_utils.facts.hardware.linux.LinuxHardware.get_uptime_facts = lambda self: mocked_uptime_facts
    ansible.module_utils.facts.hardware.linux.LinuxHardware.get_memory_facts = lambda self: mocked_memory_facts
    ansible.module_utils.facts.hardware.linux.LinuxHardware.get_mount_facts = lambda self: mocked_mount_facts



# Generated at 2022-06-20 17:34:26.412119
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-20 17:34:29.102626
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'
    #assert isinstance(hurdhw, HurdHardware)
    #assert hurdhw.platform == 'GNU'


# Generated at 2022-06-20 17:34:29.972842
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector(None)

# Generated at 2022-06-20 17:34:37.627506
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_obj = HurdHardware()
    result = test_obj.populate()
    assert isinstance(result, dict)
    assert isinstance(result['uptime'], int)
    assert isinstance(result['uptime_seconds'], int)
    assert isinstance(result['memory']['swapfree_mb'], int)
    assert isinstance(result['memory']['memfree_mb'], int)
    assert isinstance(result['memory']['swaptotal_mb'], int)
    assert isinstance(result['memory']['memtotal_mb'], int)
    assert isinstance(result['mounts'][0], dict)

# Generated at 2022-06-20 17:34:47.551408
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object and run the populate method
    hurdhw = HurdHardware()
    collected_facts = {'kernel': 'GNU'}
    facts = hurdhw.populate(collected_facts)

    # Check if all the properties of class HurdHardware are added to the facts
    assert facts['uptime_seconds'] == 0
    assert facts['uptime_minutes'] == 0
    assert facts['uptime_hours'] == 0
    assert facts['uptime_days'] == 0
    assert facts['memtotal_mb'] == 0
    assert facts['memfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0

# Generated at 2022-06-20 17:34:48.343545
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    x = HurdHardware()
    assert x is not None

# Generated at 2022-06-20 17:34:49.320827
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()


# Generated at 2022-06-20 17:34:58.124758
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware

    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds']
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours']
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb']

# Generated at 2022-06-20 17:35:04.442576
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    uptime_facts = {'uptime_seconds': int('1585407.30'), 'uptime_hours': int('440.15'), 'uptime_days': int('18.34')}
    memory_facts = {
        'memtotal_mb': int('2047'), 'memfree_mb': int('922'), 'memavailable_mb': int('1710'),
        'swaptotal_mb': int('2047'), 'swapfree_mb': int('2047'), 'swapcached_mb': int('0')
    }

    # Value of swapfree_mb is different b/c open_subproc_pipe function is mocked
    test_facts = {**uptime_facts, **memory_facts, 'swapfree_mb': int('0')}
    test_hurd = HurdHardware()

    # No need to

# Generated at 2022-06-20 17:36:28.198636
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hc = HurdHardware()

    facts = {'distribution': 'GNU'}
    result = hc.populate(facts)
    assert result['uptime_seconds'] > 10
    assert result['uptime_days'] >= 0
    assert result['uptime_hours'] >= 0
    assert result['memfree_mb'] > 10
    assert result['swapfree_mb'] >= 0
    assert result['partitions']['/']['mount'] == '/'

# Generated at 2022-06-20 17:36:29.394144
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    hardware_facts = hurdhw.populate()
    assert 'system' in hardware_facts

# Generated at 2022-06-20 17:36:39.667052
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def get_uptime_facts_mock(self):
        uptime_facts = {
            'uptime_seconds': 1,
            'uptime_string': 'up 0 min'
        }
        return uptime_facts

    def get_memory_facts_mock(self):
        memory_facts = {
            'memfree_mb': 1,
            'memtotal_mb': 2,
            'swapfree_mb': 3,
            'swaptotal_mb': 4
        }
        return memory_facts


# Generated at 2022-06-20 17:36:40.492999
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()

# Generated at 2022-06-20 17:36:44.523068
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdHardwareCollector = HurdHardwareCollector()
    assert hurdHardwareCollector._platform == 'GNU', 'The value of _platform should be GNU.'
    assert hurdHardwareCollector._fact_class == HurdHardware, 'The value of _fact_class should be HurdHardware.'

# Generated at 2022-06-20 17:36:50.066619
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    data = hh.populate()
    assert data['uptime']['seconds'] >= 0
    assert 'MemTotal' in data['memory']
    assert 'MemFree' in data['memory']
    assert 'MemAvailable' not in data['memory']
    assert 'SwapTotal' in data['memory']
    assert 'SwapFree' in data['memory']

# Generated at 2022-06-20 17:36:51.562659
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test hardware.Hurd hardware facts
    """
    _testobj = HurdHardware()
    _testobj.populate()

# Generated at 2022-06-20 17:36:53.499215
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'

# Generated at 2022-06-20 17:36:54.911024
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
        collector = HurdHardwareCollector()
        assert collector._fact_class.platform == 'GNU'

# Generated at 2022-06-20 17:37:04.922963
# Unit test for method populate of class HurdHardware