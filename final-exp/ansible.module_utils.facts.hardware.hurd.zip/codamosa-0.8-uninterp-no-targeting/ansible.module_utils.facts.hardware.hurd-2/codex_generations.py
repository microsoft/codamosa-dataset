

# Generated at 2022-06-20 17:27:59.429871
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware(None)

    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:28:02.121183
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class is HurdHardware
    assert hhc._platform == 'GNU'


# Generated at 2022-06-20 17:28:05.557367
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Test HurdHardware constructor"""

    hurd_hardware = HurdHardware(None)

    assert isinstance(hurd_hardware, HurdHardware), \
        "Failed to create instance of HurdHardware"



# Generated at 2022-06-20 17:28:06.701706
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware()

# Generated at 2022-06-20 17:28:17.350510
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h._mounts = [['/dev/sda1', '/', 'ext4', 'rw']]
    h._meminfo = {'MemTotal': 6994924}
    h._uptime = {'duration_s': 12345}
    h._mem_swap_total = 6994924
    h._mem_swap_free = 6994924
    h._mem_swap_avail = 6994924
    h._mem_swap_used = 0
    h._mem_swap_used_percent = 0.0

    h.populate()


# Generated at 2022-06-20 17:28:24.627221
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from module_utils.facts.hardware.hurd import HurdHardware
    hardware = HurdHardware()
    hardware.get_uptime_facts = lambda: {'uptime_seconds': 'uptime_seconds'}
    hardware.get_memory_facts = lambda: {'mem_info': 'mem_info'}
    hardware.get_mount_facts = lambda: {'mounts': 'mounts'}
    hardware_facts = hardware.populate()
    assert hardware_facts == {'uptime_seconds': 'uptime_seconds', 'mem_info': 'mem_info', 'mounts': 'mounts'}
    hardware.get_mount_facts = lambda: TimeoutError

# Generated at 2022-06-20 17:28:27.338674
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    facts = hh.populate()
    print(facts)



# Generated at 2022-06-20 17:28:28.542637
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-20 17:28:29.428342
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    result = HurdHardware()

    assert result is not None

# Generated at 2022-06-20 17:28:30.955689
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw=HurdHardwareCollector()
    assert hw.platform == "GNU"


# Generated at 2022-06-20 17:28:35.524506
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware

    hurd = HurdHardware()
    facts = hurd.populate()
    assert type(facts) == dict

# Generated at 2022-06-20 17:28:39.043886
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(), HurdHardwareCollector)

# Generated at 2022-06-20 17:28:41.281775
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts1 = HurdHardwareCollector()
    assert facts1._fact_class == HurdHardware
    assert facts1._platform == 'GNU'



# Generated at 2022-06-20 17:28:43.294465
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    x = HurdHardware()
    assert isinstance(x, HurdHardware)


# Generated at 2022-06-20 17:28:48.051463
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    har = HurdHardwareCollector()
    assert str(type(har.facts['uptime']))=="<class 'ansible.module_utils.facts.hardware.linux.LinuxHardware'>"

# Generated at 2022-06-20 17:28:55.966033
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    generated_facts = hurd_hardware.populate({})

    import pprint
    pprint.pprint(generated_facts)

    assert 'uptime_seconds' in generated_facts
    assert 'uptime_hours' in generated_facts
    assert 'uptime_days' in generated_facts
    assert 'memory_mb' in generated_facts
    assert 'mounts' in generated_facts
    assert 'swapfree_mb' in generated_facts
    assert 'swaptotal_mb' in generated_facts



# Generated at 2022-06-20 17:29:02.399148
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_hardware_facts = {
        'uptime_seconds': 387445,
        'uptime_days': 4,
        'uptime_hours': 17,
        'uptime_minutes': 56,
        'processor': [u'i386'],
        'latitude': 0,
        'longitude': 0,
        'memoryfree_mb': 500,
        'memorysize': 4,
        'mounts': [],
        'virtual': u'physical',
    }
    hurd_hardware = HurdHardware()
    collected_facts = {
        'ansible_facts': {
            'uptime_seconds': 387445,
        },
    }
    # Assert that our method will return the same values as known facts
    assert hurd_hardware.populate(collected_facts) == test_hard

# Generated at 2022-06-20 17:29:03.613647
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-20 17:29:06.142718
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware import HardwareCollector
    hw = HurdHardwareCollector()
    hw.populate()

# Generated at 2022-06-20 17:29:08.095314
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Make sure method populate returns a dictionary
    assert isinstance(HurdHardware().populate(), dict)

# Generated at 2022-06-20 17:29:10.193020
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    pass

# Generated at 2022-06-20 17:29:20.292489
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class Mock(HurdHardware):
        def __init__(self, *args, **kwargs):
            super(Mock, self).__init__(*args, **kwargs)
            self.uptime_facts = {'uptime_seconds': 42}
            self.memory_facts = {'memtotal_mb': 32}
            self.mount_facts = {'mounts': [{'mount': '/'}]}

        def get_uptime_facts(self):
            return self.uptime_facts

        def get_memory_facts(self):
            return self.memory_facts

        def get_mount_facts(self):
            return self.mount_facts

    h = Mock()
    hw_facts = h.populate()
    assert 'uptime_seconds' in hw_facts

# Generated at 2022-06-20 17:29:22.296767
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.platform == 'GNU'
    assert HurdHardwareCollector.priority == 2

# Generated at 2022-06-20 17:29:23.947072
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HardwareCollector.factory('GNU'), HurdHardwareCollector)

# Generated at 2022-06-20 17:29:24.928934
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd

# Generated at 2022-06-20 17:29:26.024336
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:29:33.640965
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test for method populate of class HurdHardware."""
    hurd_hardware = HurdHardware()
    hardware_facts = hurd_hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['real']['free'] < hardware_facts['memory_mb']['real']['total']
    assert len(hardware_facts['mounts']) > 0
    assert len(hardware_facts['fstype']) > 0

# Generated at 2022-06-20 17:29:35.726654
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    assert hardware



# Generated at 2022-06-20 17:29:38.721124
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # create HurdHardwareCollector instance
    result = HurdHardwareCollector()

    # assert class of object
    assert type(result) is HurdHardwareCollector


# Generated at 2022-06-20 17:29:47.068255
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test to ensure that GNU Hurd specific method collect()
    of class HurdHardwareCollector returns facts dictonary."""

    # Create HurdHardwareCollector helper object and invoke method collect()
    hurdFacts = HurdHardwareCollector.collect()

    assert "uptime" in hurdFacts
    assert "uptime_seconds" in hurdFacts

    assert "memtotal_mb" in hurdFacts
    assert "memfree_mb" in hurdFacts

    assert "mounts" in hurdFacts

# Generated at 2022-06-20 17:29:54.747331
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import Collector

    # Dummy args, because these are filled in by AnsibleModule
    module_args = {}
    module = None
    facts_module = Collector(module_args, module)

    # Call populate
    hardware = HurdHardware(module, facts_module)
    hardware.populate(None)

    # Assert that mount facts are not empty
    assert len(hardware.mount_facts) > 1

# Generated at 2022-06-20 17:30:02.110518
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware({})
    collected_facts = {}
    hardware_facts = hardware.populate(collected_facts)
    assert len(hardware_facts) >= 1
    assert "kernel" in hardware_facts
    assert "uptime" in hardware_facts
    assert "memory" in hardware_facts
    assert "mounts" in hardware_facts


# Generated at 2022-06-20 17:30:13.392382
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    data = dict()
    data['virtual'] = 'hurd'
    data['ansible_facts'] = dict()
    test = HurdHardware(data)

    res = test.populate()

    assert res['uptime']['days'] == 5
    assert res['uptime']['hours'] == 2
    assert res['uptime']['seconds'] == 45611
    assert res['uptime']['uptime'] == '5 days, 2:42'

    assert 'active' in res['memfree']
    assert 'available' in res['memfree']
    assert 'total' in res['memfree']
    assert res['memfree']['active'] == 639188992
    assert res['memfree']['available'] == 639188992
    assert res['memfree']['total'] == 639188

# Generated at 2022-06-20 17:30:16.648876
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
# Test for method get_memory_facts()
    hardware_facts.get_memory_facts()
# Test for method populate()
    hardware_facts.populate()

# Generated at 2022-06-20 17:30:18.388909
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert isinstance(obj, HurdHardware)


# Generated at 2022-06-20 17:30:19.060716
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc.platform == 'GNU'

# Generated at 2022-06-20 17:30:19.696227
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert True

# Generated at 2022-06-20 17:30:22.124573
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_obj = HurdHardware({})
    assert isinstance(hurd_obj, HurdHardware)
    assert hurd_obj.platform == 'GNU'



# Generated at 2022-06-20 17:30:29.563899
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # -------------------------------------------------------------------
    # Check the method populate with a valid fact (uptime)

    # Get facts
    hurd_hardware = HurdHardware()
    all_facts = hurd_hardware.populate()
    assert 'uptime' in all_facts
    assert 'uptime_seconds' in all_facts

    # -------------------------------------------------------------------
    # Check the method populate with an invalid fact

    # Get facts
    hurd_hardware = HurdHardware()
    all_facts = hurd_hardware.populate()
    assert 'invalid' not in all_facts

# Generated at 2022-06-20 17:30:36.944807
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initialize the class object
    hurd_hw_fact_collector = HurdHardwareCollector()
    # Create the dictionary with the collected data from the system
    collected_facts = {}
    # Initialize the system name and system release values
    collected_facts['distribution'] = 'GNU'
    collected_facts['distribution_version'] = '0.3'
    # Call the method populate of HurdHardware() class
    hurd_hw_fact_collector._fact_class.populate(collected_facts)

# Execution of the unit test
if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-20 17:30:40.637921
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc

if __name__ == '__main__':
    test_HurdHardwareCollector()

# Generated at 2022-06-20 17:30:41.489946
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h != None

# Generated at 2022-06-20 17:30:48.789738
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    import sys
    import json
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    from ansible.module_utils.facts.hardware.hurd import HurdHardware

    hurdhw = HurdHardware()

    # Create the empty cachedir
    cache_dir = '/tmp/ansible_cache'
    os.makedirs(cache_dir)

    # Create the file to cache the LinuxHardware facts
    lhw_cache_file = os.path.join(cache_dir, 'ansible_' + LinuxHardware.platform.lower() + '_facts.json')

    # Create the file to cache the HurdHardware facts
    hhw_cache_file = os.path.join(cache_dir, 'ansible_' + HurdHardware.platform.lower() + '_facts.json')



# Generated at 2022-06-20 17:30:52.907912
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Check that the populate method of HurdHardware class fills
    the required fields for facts
    """
    hurd_hardware_obj = HurdHardware()
    collected_facts = {'ansible_os_family': 'GNU/Hurd'}
    facts = hurd_hardware_obj.populate(collected_facts)

    assert facts['uptime_days']
    assert facts['uptime_seconds']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['swaptotal_mb']
    assert facts['swapfree_mb']
    assert facts['mounts']

# Generated at 2022-06-20 17:30:55.133959
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Unit test for constructor of class HurdHardware
    """
    hurd_hardware_obj = HurdHardware()
    assert hurd_hardware_obj


# Generated at 2022-06-20 17:30:57.893350
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)
    assert isinstance(hurd_hw, LinuxHardware)
    assert isinstance(hurd_hw, HardwareCollector)

# Generated at 2022-06-20 17:31:01.581262
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Test successful, when no exception is raised
    HurdHardware()

# Generated at 2022-06-20 17:31:03.558838
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(), HardwareCollector)

# Generated at 2022-06-20 17:31:07.494657
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.get_platform() == 'GNU'
    assert isinstance(hhc.get_facts(), HurdHardware)

# Generated at 2022-06-20 17:31:08.751900
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert isinstance(hh, HurdHardware)

# Generated at 2022-06-20 17:31:14.795217
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'

# Generated at 2022-06-20 17:31:18.433636
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware("")
    result_hurd_hw = hurd_hw.populate()
    assert "kernel" in result_hurd_hw


# Generated at 2022-06-20 17:31:20.347538
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test_obj = HurdHardwareCollector()
    assert test_obj.platform == 'GNU'

# Generated at 2022-06-20 17:31:22.905937
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    # since the fact itself is tested somewhere else, no need to test more
    # than that we get some value
    assert hh.populate() is not None



# Generated at 2022-06-20 17:31:25.122139
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._platform == 'GNU'
    assert isinstance(hc._fact_class, HurdHardware)

# Generated at 2022-06-20 17:31:26.235158
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert HurdHardware.platform == 'GNU'

# Generated at 2022-06-20 17:31:30.291549
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class_obj = HurdHardwareCollector()
    assert fact_class_obj._fact_class == HurdHardware
    assert fact_class_obj._platform == 'GNU'

# Generated at 2022-06-20 17:31:41.980367
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    mocked_HurdHardware = HurdHardware()

    def mock_get_uptime_facts():
        return {'uptime_seconds': 111, 'uptime_hours': 333}

    def mock_get_memory_facts():
        return {'memtotal_mb': 222}

    def mock_get_mount_facts():
        return {'mounts': 123}

    mocked_HurdHardware.get_uptime_facts = mock_get_uptime_facts
    mocked_HurdHardware.get_memory_facts = mock_get_memory_facts
    mocked_HurdHardware.get_mount_facts = mock_get_mount_facts


    facts = mocked_HurdHardware.populate()

    assert facts['uptime_seconds'] == 111
    assert facts['uptime_hours'] == 333

# Generated at 2022-06-20 17:31:44.358677
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    # The collect method is only available after setting the facts and
    # knowing the platform
    h.collect = lambda x: {'platform': 'GNU'}
    h.facts = {}
    h.populate()

# Generated at 2022-06-20 17:31:46.112293
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware({})
    assert hardware_facts._fact_class._platform == 'GNU'

# Generated at 2022-06-20 17:31:51.647893
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware("test")
    assert h is not None

# Generated at 2022-06-20 17:31:53.080468
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    my_test = HurdHardwareCollector()
    assert my_test._platform == 'GNU'

# Generated at 2022-06-20 17:31:57.966589
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Create object of class HurdHardwareCollector
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware


# Generated at 2022-06-20 17:32:00.505332
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware(None)

    assert hurd_hardware._platform == 'GNU'

# Generated at 2022-06-20 17:32:02.624372
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdHardware

# Generated at 2022-06-20 17:32:04.440459
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc.platform == 'GNUHurd'

# Generated at 2022-06-20 17:32:05.634192
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts != None


# Generated at 2022-06-20 17:32:07.994178
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert type(h) == HurdHardwareCollector
    assert h._platform == 'GNU'
    assert h._fact_class == HurdHardware


# Generated at 2022-06-20 17:32:11.500223
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hhw = HurdHardware()
    # Populate the object with Hurd facts
    hhw_facts = hhw.populate()
    assert isinstance(hhw_facts, dict) and hhw_facts

# Generated at 2022-06-20 17:32:18.852680
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from unittest import TestCase
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    class TestHardware(TestCase):
        def test_get_mount_facts(self):
            # pylint: disable=too-many-instance-attributes
            # pylint: disable=too-many-locals
            # pylint: disable=too-many-branches
            # pylint: disable=too-many-statements
            # pylint: disable=too-many-public-methods
            # pylint: disable=protected-access
            class Mp(object):
                def __init__(self):
                    self.filesystems = []
                    self.filesystem = ''
                    self.mount = ''
                    self.fstype = ''
                    self.options = []
                   

# Generated at 2022-06-20 17:32:24.211784
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.collect() == {}

# Generated at 2022-06-20 17:32:26.414218
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw._platform == 'GNU'


# Generated at 2022-06-20 17:32:29.448799
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._platform == 'GNU'
    assert hw_collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:32:31.809946
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Check whether the constructor works
    assert HurdHardwareCollector() is not None

# Generated at 2022-06-20 17:32:34.720738
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:32:37.386623
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert(hurd_hardware.populate().get('uptime_seconds')) is not None

# Generated at 2022-06-20 17:32:39.624982
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-20 17:32:40.890172
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw is not None

# Generated at 2022-06-20 17:32:43.282150
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    required_facts = ['kernel', 'architecture']
    instance = HurdHardware(required_facts)
    assert isinstance(instance, HurdHardware)

# Generated at 2022-06-20 17:32:45.184452
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector.factory()
    assert isinstance(hw, HurdHardware)

# Generated at 2022-06-20 17:32:50.431134
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware().populate()

# Generated at 2022-06-20 17:32:56.185657
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hw = HurdHardware()

    # Check the content of the object
    assert hw.uptime == 0
    assert hw.swaptotal == 0
    assert hw.swapfree == 0
    assert hw.memtotal == 0
    assert hw.memfree == 0
    assert hw.memavail == 0
    assert hw.buffers == 0
    assert hw.cached == 0
    assert hw.swapcached == 0

    # Call the populate method
    hw.populate()

    # Check the content of the object
    assert hw.uptime != 0
    assert hw.swaptotal != 0
    assert hw.swapfree != 0
    assert hw.memtotal != 0
    assert hw.memfree != 0
   

# Generated at 2022-06-20 17:33:00.480689
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    collected_facts = {'ansible_facts': {'hardware': {}}}
    if hw.populate(collected_facts) is not None:
        assert len(hw.populate(collected_facts).keys()) == 3

# Generated at 2022-06-20 17:33:01.022765
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-20 17:33:07.635713
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Test if class HurdHardwareCollector can be initialized
    hurd_hardware_collector = HurdHardwareCollector()
    assert isinstance(hurd_hardware_collector, HardwareCollector)
    assert isinstance(hurd_hardware_collector._fact_class, HurdHardware)
    assert hurd_hardware_collector._fact_class._platform == 'GNU'


# Generated at 2022-06-20 17:33:10.244356
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime
    assert hardware.mounts
    assert hardware.memfree_mb

# Generated at 2022-06-20 17:33:12.276701
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == "GNU"
    assert obj._fact_class == HurdHardware


# Generated at 2022-06-20 17:33:16.600047
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Unit test for constructor of class HurdHardwareCollector"""
    hurd_hardware_collector = HurdHardwareCollector()
    assert isinstance(hurd_hardware_collector, HardwareCollector)
    assert isinstance(hurd_hardware_collector, HurdHardwareCollector)
    assert hurd_hardware_collector._fact_class == HurdHardware
    assert hurd_hardware_collector._platform == 'GNU'

# Generated at 2022-06-20 17:33:19.088849
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-20 17:33:29.362257
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import platform
    platform.system = lambda: 'GNU'
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    collected_facts = {'ansible_architecture': 'amd64'}
    HurdHardware().populate(collected_facts)

# Generated at 2022-06-20 17:33:49.891981
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()

# Generated at 2022-06-20 17:33:58.380275
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test HurdHardware.populate with mocked facts
    """

    # Mocked facts
    facts = {}
    facts['uptime_secs'] = 42
    facts['memtotal_mb'] = 2048

    # Mocked get_mount_facts
    def mocked_get_mount_facts():
        mount_facts = {}
        mount_facts['mounts'] = [{'fs_type': 'ext4', 'mount': '/'}]
        return mount_facts

    # Instantiate HurdHardware
    hd = HurdHardware()

    # Populate with mocked facts and mocked get_mount_facts
    hd.get_mount_facts = mocked_get_mount_facts
    populated_facts = hd.populate(facts)

    # Check facts

# Generated at 2022-06-20 17:34:00.454077
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Test the constructor of HurdHardware class."""
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None


# Generated at 2022-06-20 17:34:10.965265
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_collector = HurdHardwareCollector()
    hardware_facts = hardware_collector.collect()
    assert hardware_facts['uptime'] > 0
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['mounts'] == []

    # Since these tests call the populate() function of HurdHardware,
    # the populate() function of LinuxHardware is not tested, but
    # it is expected to work correctly.

# Generated at 2022-06-20 17:34:13.020053
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts_class_ref = HurdHardware()

    assert hardware_facts_class_ref
    assert hardware_facts_class_ref._platform == "GNU"


# Generated at 2022-06-20 17:34:18.580308
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import Timer
    from ansible.module_utils.facts.hardware.linux import LinuxHardware, MountFact
    from ansible.module_utils.facts.hardware.openbsd import OpenBSDHardware

    class MockLinuxHardware(LinuxHardware):
        def get_mount_facts(self):
            raise TimeoutError()

    try:
        hw_cls = HurdHardwareCollector(None, 'GNU', {}, Timer()).collect()
    except ImportError:
        hw_cls = None
    if hw_cls:
        assert hw_cls._fact_class is HurdHardware, "populate method of HurdHardware class not used"

# Generated at 2022-06-20 17:34:20.848831
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'

# Generated at 2022-06-20 17:34:24.914114
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware_inst = HurdHardware()
    HurdHardware_inst.populate()

# Run GNU Hurd specific function on GNU Hurd
if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-20 17:34:34.578426
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    hw = HurdHardware()
    try:
        hw.get_mount_facts()
    except TimeoutError:
        pass

    collected_facts = {'ansible_system': 'GNU'}
    mount_facts = hw.get_mount_facts()
    uptime_facts = hw.get_uptime_facts()
    memory_facts = hw.get_memory_facts()
    hardware_facts = hw.populate(collected_facts)

    assert hardware_facts['ansible_system'] == 'GNU'
    assert hardware_facts['ansible_uptime_seconds'] == uptime_facts['ansible_uptime_seconds']
   

# Generated at 2022-06-20 17:34:36.250464
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    collected_facts = {}
    assert hardware_facts.populate(collected_facts)

# Generated at 2022-06-20 17:35:00.475609
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    hurdhw.populate()

    assert hurdhw.facts['uptime_seconds'] == int
    assert hurdhw.facts['uptime_hours'] == int

    assert hurdhw.facts['memtotal_mb'] == int
    assert hurdhw.facts['memfree_mb'] == int
    assert hurdhw.facts['swaptotal_mb'] == int
    assert hurdhw.facts['swapfree_mb'] == int

# Generated at 2022-06-20 17:35:02.825957
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    collected_facts = dict()
    uut = HurdHardware(collected_facts)

    assert uut.platform == 'GNU'


# Generated at 2022-06-20 17:35:08.085777
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Params
    col_fact = HurdHardwareCollector()
    col_fact._collect_file_facts = lambda: {'path': '.', 'file_exists': True}
    col_fact.collect()
    # Call method
    col_fact._fact_class().populate()
    # Test assertion
    assert col_fact.hardware_facts

# Generated at 2022-06-20 17:35:08.975557
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:35:11.598458
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collect = HurdHardwareCollector()
    assert collect._fact_class == HurdHardware
    assert collect._platform == 'GNU'

# Generated at 2022-06-20 17:35:16.527636
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.uptime == hardware.uptime
    assert hardware.swapfree == hardware.swapfree
    assert hardware.swaptotal == hardware.swaptotal
    assert hardware.memfree == hardware.memfree
    assert hardware.memtotal == hardware.memtotal

# Generated at 2022-06-20 17:35:27.655075
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    # Check if we have the expected uptime
    uptime = facts.get('uptime', None)
    assert uptime is not None

    # Check if we have the expected memory
    memory = facts.get('memory', None)
    assert memory is not None
    assert memory['total'] > 0

    # Check if we have the expected mount points
    mount_points = facts.get('mounts', None)
    assert mount_points is not None
    assert len(mount_points) >= 0
    for mp in mount_points:
        assert mp['mount'] is not None
        assert mp['device'] is not None
        assert mp['fstype'] is not None

# Generated at 2022-06-20 17:35:37.074012
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.get_uptime_facts = lambda: {'uptime_seconds': 42}
    hurd_hw.get_memory_facts = lambda: {'memory_mb': {'nocache': {'free': 42}, 'real': {'total': 42}}}
    hurd_hw.get_mount_facts = lambda: {'mounts': [{'mount': '/', 'device': 'hurd'}]}
    # add call to populate
    facts = hurd_hw.populate()
    # Test uptime_seconds key value
    assert facts['uptime_seconds'] == 42
    # Test memory_mb key value
    assert facts['memory_mb'] == {'nocache': {'free': 42}, 'real': {'total': 42}}
    # Test mounts key value

# Generated at 2022-06-20 17:35:44.551525
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware.
    """
    hurd_hardware_collector = HurdHardwareCollector()

    hurd_hardware = hurd_hardware_collector.collect()

    assert isinstance(hurd_hardware.get('uptime'), (int, float))
    assert isinstance(hurd_hardware.get('uptime_seconds'), (int, float))

    assert isinstance(hurd_hardware.get('memtotal_mb'), int)
    assert isinstance(hurd_hardware.get('memfree_mb'), int)

    assert isinstance(hurd_hardware.get('mounts'), list)
    assert len(hurd_hardware.get('mounts')) > 0

# Generated at 2022-06-20 17:35:45.850304
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-20 17:36:40.830917
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys

    import mock
    assert mock is not None, "python-mock is required for this test"

    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector as LHC
    from ansible.module_utils.facts.hardware.linux import LinuxHardware as LH

    from ansible.module_utils.facts.hardware.hurd import HurdHardware as HH
    from ansible.module_utils.facts.hardware.hurd import HurdHardwareCollector as HHC

    # This test is only intended for the Hurd OS, so if the OS is not Hurd
    # skip the test.
    if sys.platform != 'gnu0':
        return

    class FakeFact(object):
        def __init__(self, dict):
            self.facts = dict


# Generated at 2022-06-20 17:36:43.025366
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    instance = HurdHardwareCollector()
    assert instance.platform == 'GNU'
    assert instance.fact_class == HurdHardware


# Generated at 2022-06-20 17:36:52.221263
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw_facts = HurdHardware()
    facts = hw_facts.populate()

    assert facts is not None
    assert facts['uptime'] is not None
    assert facts['uptime_seconds'] is not None
    assert facts['uptime_hours'] is not None

    assert facts['mounts'] is not None
    assert len(facts['mounts']) > 0
    if 'system' in facts['mounts']:
        assert len(facts['mounts']['system']) == 5

    assert type(facts['memtotal_mb']) is int
    assert facts['memtotal_mb'] > 0

    assert type(facts['memfree_mb']) is int
    assert facts['memfree_mb'] > 0

    assert type(facts['swaptotal_mb']) is int

# Generated at 2022-06-20 17:36:57.904127
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.uptime_cmd == '{0} --no-pager'.format(HurdHardware.uptime_cmd)
    assert hw.uptime_pattern == r'up (\d+) days? (\d+):(\d+),'
    assert hw.meminfo_pattern == r'MemTotal:\s*(\d+)\s*kB'

# Generated at 2022-06-20 17:37:03.012268
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_mock = HurdHardware(None)
    hardware_mock.get_uptime_facts = lambda: {'uptime_seconds': 0}
    hardware_mock.get_memory_facts = lambda: {'memory': {}}
    hardware_mock.get_mount_facts = lambda: {'mounts': []}
    hardware_mock.populate()



# Generated at 2022-06-20 17:37:05.622706
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an instance of class HurdHardware and check it
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HardwareCollector)
    assert isinstance(hurd_hw, HurdHardware)

# Generated at 2022-06-20 17:37:07.318562
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class is HurdHardware

# Generated at 2022-06-20 17:37:09.028596
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.populate() == {}

# Generated at 2022-06-20 17:37:13.551958
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    hardware = HurdHardware(facts)
    hardware_facts = hardware.populate()
    assert 'uptime' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'uptime_hours' in hardware_facts
    assert 'uptime_days' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts

# Generated at 2022-06-20 17:37:15.194000
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'