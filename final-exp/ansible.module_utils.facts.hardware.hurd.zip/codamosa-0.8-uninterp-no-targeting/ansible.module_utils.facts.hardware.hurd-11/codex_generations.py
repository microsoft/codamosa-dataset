

# Generated at 2022-06-20 17:28:01.006193
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.populate() is not None

# Generated at 2022-06-20 17:28:05.354119
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    #
    # Unit test for method populate of class HurdHardware.
    #
    cluster_name = 'test_cluster'
    #
    # Call populate and check for results.
    #
    print("Testing HurdHardware_populate: test_cluster")
    had = HurdHardware()
    had.populate()
    print("cluster_name: " + cluster_name)
    print("after had.populate")

# Generated at 2022-06-20 17:28:07.314715
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)

# Generated at 2022-06-20 17:28:13.175438
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_collection = HurdHardwareCollector(None, None, 'hurd')

    fact_collection.collect()
    fact_collection.populate()

    facts = fact_collection.get_facts()
    assert facts['uptime']
    assert facts['uptime_sec']
    assert facts['memory_mb']
    assert facts['swap']
    assert facts['swap_mb']

# Generated at 2022-06-20 17:28:15.786800
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert(h._fact_class == HurdHardware)
    assert(h._platform == 'GNU')



# Generated at 2022-06-20 17:28:18.961503
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()

    # Assert that the OS is GNU
    assert hurd_facts.platform.startswith('GNU')

    # Assert that mount facts is not empty
    assert isinstance(hurd_facts.populate(), dict)


# Generated at 2022-06-20 17:28:23.825704
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    expected_facts = {
        'uptime': {},
        'memory': {},
        'mounts': {}
    }
    hw = HurdHardwareCollector(None, None)
    assert hw.platform == 'GNU'
    assert hw.facts == expected_facts


# Generated at 2022-06-20 17:28:25.550845
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-20 17:28:31.801851
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    # Create a class instance for testing
    hurdhw = HurdHardware()

    # Define test variables for class HurdHardware
    hurdhw.get_uptime_facts = LinuxHardware.get_uptime_facts
    hurdhw.get_memory_facts = LinuxHardware.get_memory_facts
    hurdhw.get_mount_facts = LinuxHardware.get_mount_facts

    # Populate it
    hurdhw.populate()

# Generated at 2022-06-20 17:28:33.559492
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    assert facts.platform == 'GNU'

# Generated at 2022-06-20 17:28:40.403346
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware._platform is not None
    assert hardware._fact_class is not None
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware


# Generated at 2022-06-20 17:28:43.034664
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    checks = {'platform': 'GNU', '_fact_class': HurdHardware}
    test_obj = HurdHardwareCollector()
    for key, var in checks.items():
        assert getattr(test_obj, key) == var

# Generated at 2022-06-20 17:28:44.295099
# Unit test for constructor of class HurdHardware
def test_HurdHardware():

    hurdHardware = HurdHardware()

    return True


# Generated at 2022-06-20 17:28:48.258066
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    c = HurdHardwareCollector()
    assert issubclass(c._fact_class, HurdHardware)
    assert c._platform == 'GNU'

# Generated at 2022-06-20 17:28:54.731360
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    assert 'uptime_seconds' in facts
    assert 'uptime_hours' in facts
    assert 'memory_mb' in facts
    assert 'mounts' in facts
    assert isinstance(facts['mounts'], list)

    for mount in facts['mounts']:
        assert 'mount' in mount
        assert 'device' in mount
        assert 'fstype' in mount



# Generated at 2022-06-20 17:29:01.691705
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initializing a HurdHardware object
    hurd_hardware = HurdHardware()

    # Calling the populate method
    hurd_hardware_facts = hurd_hardware.populate()

    # Verifying that the returned value is not None
    assert hurd_hardware_facts is not None



# Generated at 2022-06-20 17:29:05.378109
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    uptime_facts = hardware.get_uptime_facts()
    memory_facts = hardware.get_memory_facts()
    mount_facts = hardware.get_mount_facts()
    assert uptime_facts != None
    assert memory_facts != None
    assert mount_facts != None

# Generated at 2022-06-20 17:29:08.177539
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware
    assert h._platform == 'GNU'

# Generated at 2022-06-20 17:29:11.199046
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()
    uptime_facts = hurdHardware.get_uptime_facts()
    memory_facts = hurdHardware.get_memory_facts()
    mount_facts = hurdHardware.get_mount_facts()

# Generated at 2022-06-20 17:29:14.235874
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert(HurdHardware({}).populate() == {
        'uptime_seconds': 0,
        'memtotal_mb': 0,
        'swaptotal_mb': 0,
        'mounts': [],
    })

# Generated at 2022-06-20 17:29:17.126658
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-20 17:29:20.866134
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    TestHurdHardware = HurdHardwareCollector.fetch_processor(None)
    hardware_facts = TestHurdHardware.populate()
    assert hardware_facts['uptime'] >= 0, "Uptime should be a positive value."



# Generated at 2022-06-20 17:29:24.785998
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'


# Generated at 2022-06-20 17:29:26.680084
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test_class = HurdHardwareCollector(None)
    assert test_class._fact_class is HurdHardware

# Generated at 2022-06-20 17:29:31.665161
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()

    collected_facts = {}
    hostvars = obj.populate(collected_facts)

    assert len(hostvars) > 1, 'hostvars is not populated correctly'
    assert hostvars['uptime_seconds'] == 0, 'uptime_seconds is not 0'
    assert hostvars['virtual'] == 'physical', 'virtual fact is not physical'

# Generated at 2022-06-20 17:29:33.412271
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw._platform == 'GNU'


# Generated at 2022-06-20 17:29:34.792256
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()


# Generated at 2022-06-20 17:29:47.373717
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector

    class MockLinuxHardware():
        def get_uptime_facts(self):
            return {'uptime_seconds': 0}
        def get_memory_facts(self):
            return {'ansible_memfree_mb': 1,
                    'ansible_memtotal_mb': 2}
        def get_mount_facts(self):
            raise TimeoutError


# Generated at 2022-06-20 17:29:55.494827
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    vars = HurdHardware()

    # Constants used for testing
    mem = vars.get_memory_facts()
    mem_total = mem['ansible_memtotal_mb']
    mem_free = mem['ansible_memfree_mb']
    swap_total = mem['ansible_swaptotal_mb']
    swap_free = mem['ansible_swapfree_mb']

    # Test that memory and swap totals are non-zero
    assert mem_total > 0
    assert mem_free > 0
    assert swap_total > 0
    assert swap_free > 0

    # Test that swap totals are less or equal than the actual swap partition
    assert swap_total <= swap_free

    # Test that memory totals are less or equal than the actual memory
    assert mem_total <= mem_free

# Generated at 2022-06-20 17:30:04.476925
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from . import fake_ansible_module

    module = fake_ansible_module()

    # Mock the facts module
    facts_module = HurdHardwareCollector(module)
    facts_module.collect()

    facts = module.exit_json['ansible_facts']
    # Check that some fundamental facts are present
    assert 'kernel' in facts
    assert facts['kernel'] == "GNU"
    assert 'memory_mb' in facts

    # Check that mount facts are present
    assert 'mounts' in facts

# Generated at 2022-06-20 17:30:08.063599
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test = HurdHardware()
    assert test.platform == 'GNU'


# Generated at 2022-06-20 17:30:09.296342
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.populate()


# Generated at 2022-06-20 17:30:11.591976
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    myHurdHardwareCollector = HurdHardwareCollector()
    assert myHurdHardwareCollector.platform == 'GNU'

# Generated at 2022-06-20 17:30:16.594759
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    '''Test of method populate of class HurdHardware'''
    hurd_hw = HurdHardware()
    hardware_facts = hurd_hw.populate()
    assert isinstance(hardware_facts.get('ansible_memtotal_mb'), int)
    assert hardware_facts.get('ansible_mounts') is not None

# Generated at 2022-06-20 17:30:21.180766
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    collected_facts = {}

    collected_facts = hurd_hw.populate(collected_facts)

    assert collected_facts['uptime']
    assert collected_facts['uptime_seconds']
    assert collected_facts['memtotal_mb']
    assert collected_facts['memfree_mb']


# Generated at 2022-06-20 17:30:32.103543
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    hurd_hardware = HurdHardwareCollector(BaseFactCollector)
    collected_facts = {
        'kernel_version': '3.19',
        'processor': ['x86_64'],
        'ansible_os_family': 'GNU/Linux'
    }
    expected_collected_facts = {
        'kernel_version': '3.19',
        'processor': ['x86_64'],
        'ansible_os_family': 'GNU/Linux',
        'uptime_seconds': 0,
        'memory_mb': {}
    }
    hurd_hardware.populate(collected_facts)
    assert collected_facts == expected_

# Generated at 2022-06-20 17:30:37.662811
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockCollector:
        def collect(self, module=None, collected_facts=None):
            return {'dmi_system_uuid': 'A3BA-3132'}
    hardware = HurdHardware(MockCollector())
    hardware.populate()
    assert hardware.get_all()['dmi_system_uuid'] == 'A3BA-3132'

# Generated at 2022-06-20 17:30:39.008591
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'


# Generated at 2022-06-20 17:30:45.028306
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw_collector = HurdHardwareCollector()
    facts = hurd_hw_collector.collect()

    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] >= 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_minutes'] >= 0

    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] >= 0

    assert facts['mounts'] != {}

# Generated at 2022-06-20 17:30:46.957416
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware, LinuxHardware)

# Generated at 2022-06-20 17:30:51.488409
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:30:53.449099
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc._platform == 'GNU'
    assert hwc._fact_class == HurdHardware

# Generated at 2022-06-20 17:30:54.979880
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert(hwc._platform == 'GNU')

# Generated at 2022-06-20 17:31:02.330570
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import _MAX_N_PROC_LIMIT

    # TODO evaluate if this test is worth keeping
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert(hurd_hardware.uptime_info['uptime_secs'] > 0)
    assert(hurd_hardware.uptime_info['idletime_secs'] > 0)
    assert(hurd_hardware.get_memory_facts()['memtotal_mb'] > 0)
    assert(hurd_hardware.get_mount_facts()['mounts'][0]['mount'])
    assert(hurd_hardware.get_mount_facts()['mounts'][0]['device'])

# Generated at 2022-06-20 17:31:05.342136
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import HurdHardware

    hurdhw = HurdHardware()
    facts = hurdhw.populate()

    assert isinstance(facts, dict)

# Generated at 2022-06-20 17:31:07.637037
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    a = HurdHardwareCollector()
    assert hasattr(a, '_fact_class') and hasattr(a, '_platform')

# Generated at 2022-06-20 17:31:08.500076
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().platform == 'GNU'

# Generated at 2022-06-20 17:31:09.411217
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts = HurdHardwareCollector()

# Generated at 2022-06-20 17:31:15.145578
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()
    obj.populate()

    #asserting for memory facts
    assert obj.facts['memory_mb']
    assert obj.facts['memtotal_mb']
    assert obj.facts['swaptotal_mb']

    #asserting for mount facts
    assert obj.facts['mounts']

    #asserting for uptime facts
    assert obj.facts['uptime']
    assert obj.facts['uptime_seconds']
    assert obj.facts['uptime_hours']

# Generated at 2022-06-20 17:31:17.971060
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdhw_collector_obj = HurdHardwareCollector()
    assert isinstance(hurdhw_collector_obj._fact_class, HurdHardware)

# Generated at 2022-06-20 17:31:25.233369
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert isinstance(hw, HurdHardware) is True

# Generated at 2022-06-20 17:31:26.999944
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts is not None

# Generated at 2022-06-20 17:31:32.339272
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()

    assert hw.get_facts() == {
        'architecture': 'x86_64'
    }
    assert hw.get_facts() == {
        'architecture': 'x86_64'
    }

# Generated at 2022-06-20 17:31:37.163393
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    collected_facts = {'ansible_distribution': 'GNU'}
    facts = hw.populate(collected_facts)
    assert 'uptime' in facts['ansible_facts']
    assert 'memory' in facts['ansible_facts']
    assert 'mount' in facts['ansible_facts']

# Generated at 2022-06-20 17:31:40.671567
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, LinuxHardware)
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-20 17:31:47.962121
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():

    hurdhwc = HurdHardwareCollector()

    assert isinstance(hurdhwc, HardwareCollector)
    assert isinstance(hurdhwc._fact_class, HurdHardware)
    assert hurdhwc._platform == 'GNU'


# Generated at 2022-06-20 17:31:51.074795
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()
    collected_facts = {'distribution': 'GNU Hurd'}
    facts = obj.populate(collected_facts)
    assert facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:31:57.663421
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware import HardwareCollector
    from ansible.module_utils.facts.facts import Facts

    class MockHurdHardware(HurdHardware):
        def _load_memory_facts_from_proc(self):
            return {
                'swap': {
                    'available_mb': 0,
                    'capacity': 0.0,
                    'total_mb': 0
                },
                "ram": {
                    "available_mb": 0,
                    "capacity": 0.0,
                    "total_mb": 0
                }
            }


# Generated at 2022-06-20 17:32:00.550423
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector()
    assert fact_class._fact_class == HurdHardware
    assert fact_class._platform == 'GNU'

# Generated at 2022-06-20 17:32:02.623871
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector('/fake/path')
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-20 17:32:17.666255
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    rh = HurdHardware()
    assert rh.platform == "GNU"
    assert rh.get_mount_facts() == {}


# Generated at 2022-06-20 17:32:21.995423
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class._platform == 'GNU'
    assert obj._fact_class._mount_proc_path == '/proc/mounts'


# Generated at 2022-06-20 17:32:23.888103
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert isinstance(obj, HardwareCollector)== True


# Generated at 2022-06-20 17:32:33.543089
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw_facts = HurdHardware()

# Generated at 2022-06-20 17:32:37.019413
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test for method HurdHardware.populate"""
    hw_facts = HurdHardware()
    assert isinstance(hw_facts.populate(), dict)

# Generated at 2022-06-20 17:32:39.966383
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector.collect(None, None)
    assert hardware['uptime']['seconds'] >= 0
    assert hardware['uptime']['days'] >= 0

# Generated at 2022-06-20 17:32:43.695523
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

if __name__ == '__main__':
    hw = HurdHardware()
    hw.populate()
    print(hw.get_facts())

# Generated at 2022-06-20 17:32:45.969444
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhwc = HurdHardwareCollector()
    assert hhwc is not None
    assert hhwc._fact_class is HurdHardware

# Generated at 2022-06-20 17:32:46.857394
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-20 17:32:48.072119
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-20 17:33:23.117715
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware(None, None, None)

    assert type(hurd) == HurdHardware
    assert hurd.collector == "Hurd"


# Generated at 2022-06-20 17:33:32.087667
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware import HardwareCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    class HurdHardware_populate_mockshelve():
        def open(self):
            return self

        def __getitem__(self, item):
            return self

        def __setitem__(self, key, value):
            return self

        def close(self):
            return True

    class HurdHardware_populate_mock_get_mount_facts():
        def __init__(self, fs_spec, fs_file, fs_vfstype):
            self.fs_vfstype = fs_vfstype
            self.fs_spec = fs_spec

# Generated at 2022-06-20 17:33:34.472991
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.platform == 'GNU'
    assert hhc.fact_class == HurdHardware


# Generated at 2022-06-20 17:33:34.968359
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware()

# Generated at 2022-06-20 17:33:36.286836
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-20 17:33:37.923533
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert(hurdhw)


# Generated at 2022-06-20 17:33:40.992526
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardwareCollector = HurdHardwareCollector()
    assert hardwareCollector._fact_class is HurdHardware
    assert hardwareCollector._platform is 'GNU'

# Generated at 2022-06-20 17:33:44.049659
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """ Test ansible.module_utils.facts.hardware.hurd """
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-20 17:33:54.102635
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facter_uptime = """{
    "ansible_uptime_seconds": 1284,
    "ansible_uptime_days": 1,
    "ansible_uptime_hours": 0,
    "ansible_uptime_minutes": 21,
    "ansible_uptime_seconds": 24
}"""

# Generated at 2022-06-20 17:33:55.226227
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'

# Generated at 2022-06-20 17:35:01.650885
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    This test creates a HurdHardwareCollector object and verifies if it is an instance of the class.
    """
    _hw = HurdHardwareCollector()
    assert isinstance(_hw, HardwareCollector)


# Generated at 2022-06-20 17:35:12.566281
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardware().populate()
    assert isinstance(hurd_facts['uptime_seconds'], int)
    assert hurd_facts['uptime_seconds'] >= 0

    assert isinstance(hurd_facts['uptime_days'], int)
    assert hurd_facts['uptime_days'] > 0

    required_keys = {'memtotal_mb', 'swaptotal_mb'}
    assert set(hurd_facts.keys()) & required_keys == required_keys

    required_keys = {'mounts'}
    assert set(hurd_facts.keys()) & required_keys == required_keys
    assert isinstance(hurd_facts['mounts'], list)
    assert len(hurd_facts['mounts']) >= 1

# Generated at 2022-06-20 17:35:16.235977
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'
    assert h.fact_class == HurdHardware
    assert h.fact_class().platform == 'GNU'

# Generated at 2022-06-20 17:35:18.637886
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector._fact_class(), HurdHardware)

# Generated at 2022-06-20 17:35:22.778845
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    facts = hurdhw.populate()
    assert 'uptime' in facts
    assert 'memfree' in facts
    assert 'memtotal' in facts
    assert 'ansible_mounts' in facts

# Generated at 2022-06-20 17:35:25.178514
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert(facts['uptime'])

# Generated at 2022-06-20 17:35:28.148699
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwcoll = HurdHardwareCollector()

    assert isinstance(hwcoll, HardwareCollector)
    assert hwcoll._fact_class == HurdHardware
    assert hwcoll._platform == 'GNU'

# Generated at 2022-06-20 17:35:31.871324
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdfacts = HurdHardware()
    facts = hurdfacts.populate()
    assert facts['uptime_seconds'] > 0
    assert 'ansible_mounts' in facts
    assert 'ansible_swapfree_mb' in facts
    assert 'ansible_memtotal_mb' in facts
    assert 'ansible_memfree_mb' in facts

# Generated at 2022-06-20 17:35:41.624421
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Create a fake HurdHardware object.
    """
    hurd_hardware = HurdHardware()
    # Fake memory fields, as returned by /proc/meminfo

# Generated at 2022-06-20 17:35:47.255293
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware import BaseHardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    hw = HurdHardware()
    # When population of a specific fact fails, then we expect that
    # the appropriate exception is raised and eventually a TimeoutError.
    # The only exception is the population of the mount fact which won't
    # raise a TimeoutError due to a population failure of its mount point
    # facts.

    timeout.__mtime__ = 0
    timeout.__calculate_timeout__()

    class LinuxHardware_Mockup(BaseHardware):
        def __init__(self):
            self.populate_called_times = 0