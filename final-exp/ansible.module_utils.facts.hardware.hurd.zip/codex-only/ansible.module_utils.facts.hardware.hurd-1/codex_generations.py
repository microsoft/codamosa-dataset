

# Generated at 2022-06-22 23:14:33.590877
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().platform == 'GNU'

# Generated at 2022-06-22 23:14:34.846023
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()._platform == 'GNU'

# Generated at 2022-06-22 23:14:35.935664
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector is not None


# Generated at 2022-06-22 23:14:40.273583
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_instance =  HurdHardwareCollector()
    assert hw_instance._fact_class == HurdHardware
    assert hw_instance._platform == 'GNU'

# Generated at 2022-06-22 23:14:42.641794
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # In GNUHurd, /proc/uptime is always 0.0
    assert HurdHardware().populate().get('uptime_seconds') == 0

# Generated at 2022-06-22 23:14:45.365668
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    hw_facts = hw_collector.collect()

    assert hw_facts['uptime'] is not None

# Generated at 2022-06-22 23:14:50.025901
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert isinstance(hurd, HurdHardware)
    assert hurd.platform == 'GNU'
    assert hurd.type == 'GNU'
    assert hurd.distribution is None
    assert hurd.distribution_version is None
    assert hurd.architecture is None

# Generated at 2022-06-22 23:14:58.604758
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['mounts']
    assert facts['mounts'][0]['size_total'] > 0
    assert facts['mounts'][0]['size_available'] > 0

# Generated at 2022-06-22 23:15:08.447605
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hhw = HurdHardware()
    uptime_facts = {'uptime_seconds': 1800}
    memory_facts = {'memtotal_mb': 5}
    mount_facts = {'disks': {'/': {'size_total': 100}}}
    try:
        hhw.get_mount_facts = lambda: mount_facts
    except TimeoutError:
        pass
    hhw.get_uptime_facts = lambda: uptime_facts
    hhw.get_memory_facts = lambda: memory_facts

    expected = uptime_facts
    expected.update(memory_facts)
    expected.update(mount_facts)
    collected_facts = {}
    assert hhw.populate(collected_facts) == expected

# Generated at 2022-06-22 23:15:19.383077
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_object = HurdHardware()
    hardware_facts = hardware_object.populate()
    assert hardware_facts["uptime_seconds"] == 0
    assert hardware_facts["uptime_hours"] == 0
    assert hardware_facts["uptime_days"] == 0
    assert hardware_facts["uptime_minutes"] == 0
    assert hardware_facts["uptime_last_pid"] == 0
    assert hardware_facts["memtotal_mb"] == 0
    assert hardware_facts["swaptotal_mb"] == 0
    assert hardware_facts["memfree_mb"] == 0
    assert hardware_facts["memavailable_mb"] == 0
    assert hardware_facts["swapfree_mb"] == 0
    assert hardware_facts["cached_mb"] == 0
    assert hardware_facts["swapcached_mb"] == 0
   

# Generated at 2022-06-22 23:15:20.905692
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == "GNU"

# Generated at 2022-06-22 23:15:22.519964
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw is not None

# Generated at 2022-06-22 23:15:32.097384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys, os
    libdir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'module_utils')
    sys.path.insert(0, libdir)
    from facts.facts import Facts
    from ansible.module_utils.facts.hardware.hurd import HurdHardwareCollector
    hurd = HurdHardwareCollector()
    facts = Facts(None, None, None, None, hurd)
    facts.populate()
    assert facts
    assert 'hardware' in facts.ansible_facts
    assert 'memtotal_mb' in facts.ansible_facts['hardware']


# Generated at 2022-06-22 23:15:35.992291
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_obj = HurdHardware()

    #check the platform
    assert hurd_hardware_obj.collect()['ansible_facts']['ansible_system'] == 'GNU'



# Generated at 2022-06-22 23:15:38.276214
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._fact_class == HurdHardware
    assert hw._platform == 'GNU'

# Generated at 2022-06-22 23:15:45.330926
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Class HurdHardware tests on Ubuntu 16.04.
    """
    hardware_inst = HurdHardware()
    hardware_facts = hardware_inst.populate()  # Full hardware facts
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['swap']['total'] > 0
    # mount facts unavailable for GNU/Hurd
    assert len(hardware_facts['mounts']) == 0

# Generated at 2022-06-22 23:15:48.614248
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None


if __name__ == '__main__':
    test_HurdHardware()

# Generated at 2022-06-22 23:15:52.044020
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw_collector = HurdHardwareCollector()
    hurdhw_collector.populate()
    hurdhw = hurdhw_collector.get_facts()
    assert isinstance(hurdhw, dict)

# Generated at 2022-06-22 23:15:54.231260
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'


# Generated at 2022-06-22 23:16:01.865055
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware()
    collected_facts = {}
    collected_facts['ansible_os_family'] = 'Linux'
    collected_facts['ansible_os'] = 'GNU Hurd'
    collected_facts['ansible_distribution'] = 'GNU'
    output = fact_class.populate(collected_facts)
    assert output.get('ansible_mounts') is not None
    assert output.get('ansible_memtotal_mb') is not None
    assert output.get('ansible_uptime_seconds') is not None

# Generated at 2022-06-22 23:16:05.884620
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:16:16.657720
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    # Test with a non existing memory file
    def exc_memory_facts(self):
        raise IOError
    hw.get_memory_facts = exc_memory_facts

    # Test with non existing mount file
    def exc_mount_facts(self):
        raise IOError
    hw.get_mount_facts = exc_mount_facts

    # Test with a non existing uptime file
    def exc_uptime_facts(self):
        raise IOError
    hw.get_uptime_facts = exc_uptime_facts

    try:
        facts = hw.populate()
    except IOError:
        assert False

    # Check that facts is a dict
    if type(facts) is not dict:
        assert False

    # Check that a default value is present

# Generated at 2022-06-22 23:16:22.662120
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from collections import namedtuple
    from ansible.module_utils.facts.hardware.hurd import HurdHardwareCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    Hardware = namedtuple('Hardware', ['collector', 'platform'])

    hardware = Hardware(HurdHardwareCollector, 'GNU')

    assert isinstance(hardware.collector(), HurdHardwareCollector)
    assert isinstance(hardware.collector().get_facts(), LinuxHardware)



# Generated at 2022-06-22 23:16:24.357532
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    collected_facts = hw.collect()
    mount_facts = collected_facts['mounts']
    uptime_facts = collected_facts['uptime_seconds']
    memory_facts = collected_facts['ansible_memtotal_mb']
    assert(mount_facts)
    assert(uptime_facts)
    assert(memory_facts)

# Generated at 2022-06-22 23:16:37.135860
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class TestHurdHardware(HurdHardware):
        def get_uptime_facts():
            return {'uptime_days': '42'}
        def get_memory_facts():
            return {'memory_mb': {'real': {'total': '1024'}, 'swap': {}}}
        def get_mount_facts():
            return {'mounts': [{'device': '/dev/disk0s2',
                                'size_total': '1234456',
                                'fstype': 'ext2',
                                'mount': '/'}]}

    hardware_facts = {}
    th = TestHurdHardware()
    hardware_facts = th.populate()

    assert hardware_facts['uptime_days'] == '42'

# Generated at 2022-06-22 23:16:39.040644
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result._platform == 'GNU'

# Generated at 2022-06-22 23:16:41.289062
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'


# Generated at 2022-06-22 23:16:44.011795
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert(obj.platform == "GNU")

# Generated at 2022-06-22 23:16:50.619569
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    facts = hw.populate()

    assert 'uptime' in facts
    assert facts['uptime'] > 0
    assert 'memtotal_mb' in facts
    assert facts['memtotal_mb'] > 0
    assert 'memfree_mb' in facts
    assert facts['memfree_mb'] > 0
    assert 'swaptotal_mb' in facts
    assert facts['swaptotal_mb'] > 0
    assert 'swapfree_mb' in facts
    assert facts['swapfree_mb'] > 0

# Generated at 2022-06-22 23:17:00.781684
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test populate method of HurdHardware class.
    :return:
    """
    hurd_hardware = HurdHardware()
    collected_facts = {
        'distribution': 'Debian',
        'distribution_version': '8',
        'hardwaremodel': 's390x',
        'virtualization_role':None,
        'virtualization_type':None
    }
    facts = hurd_hardware.populate(collected_facts)

# Generated at 2022-06-22 23:17:06.382977
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware({})
    assert hurd_hardware.platform == 'GNU'

# Collect hardware information for GNU
# Uncomment for testing on GNU platform
#if __name__ == '__main__':
#    hurd_hardware = HurdHardware({})
#    print(hurd_hardware.get_all_facts())

# Generated at 2022-06-22 23:17:10.530095
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

    assert hardware.uptime is not None
    assert hardware.uptime_seconds is not None

    assert hardware.memtotal_mb is not None
    assert hardware.memfree_mb is not None
    assert hardware.swaptotal_mb is not None
    assert hardware.swapfree_mb is not None

    assert hardware.mounts is not None

# Generated at 2022-06-22 23:17:17.939632
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.data['uptime'] == "timeval"

    # assertion of mount_facts is tricky because the newer procfs compatibility
    # translator uses a function that is not timed out by Ansible.
    # TODO: Replace assert mount_facts with mock, see:
    # https://github.com/ansible/ansible/pull/67847#discussion_r420567794

# Generated at 2022-06-22 23:17:19.505423
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector.get_platform_facts(), HurdHardware)

# Generated at 2022-06-22 23:17:22.512788
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class is not None

# Generated at 2022-06-22 23:17:23.601276
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.collect()

# Generated at 2022-06-22 23:17:25.533870
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == "GNU"


# Generated at 2022-06-22 23:17:26.147041
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware()

# Generated at 2022-06-22 23:17:27.938415
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:17:34.760414
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware()
    collected_facts = {}
    facts_dict = fact_class.populate(collected_facts)
    assert 'uptime_seconds' in facts_dict
    assert 'uptime' in facts_dict
    assert 'memfree_mb' in facts_dict
    assert 'memtotal_mb' in facts_dict
    assert 'mounts' in facts_dict

# Generated at 2022-06-22 23:17:36.417004
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert hw.populate()

# Generated at 2022-06-22 23:17:38.236783
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc._fact_class is HurdHardware

# Generated at 2022-06-22 23:17:40.601573
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Test if the constructor don't raise an exception
    h = HurdHardware()
    assert h  # It's OK if it don't raise an exception

# Generated at 2022-06-22 23:17:42.401223
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw_collector = HurdHardwareCollector()
    assert hurd_hw_collector.platform == 'GNU'

# Generated at 2022-06-22 23:17:44.997239
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.get_mount_facts()


# Generated at 2022-06-22 23:17:54.944927
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():

    class TestSystem:
        def __init__(self):
            self.system = 'GNU'
        def get_platform(self):
            return self.system

    class TestMachine:
        def __init__(self):
            self.machine = 'GNU'
        def get_platform(self):
            return self.machine

    class TestSystemUname:
        def __init__(self):
            self.system = 'Darwin'
        def get_platform(self):
            return self.system

    class TestMachineUname:
        def __init__(self):
            self.machine = 'GNU'
        def get_platform(self):
            return self.machine

    collector = HurdHardwareCollector()

    system = TestSystem()
    system_uname = TestSystemUname()
    machine = TestMachine()

# Generated at 2022-06-22 23:17:57.173554
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware


# Generated at 2022-06-22 23:17:58.294223
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    assert True

# Generated at 2022-06-22 23:18:02.030029
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'
    assert h._fact_class == HurdHardware
    assert h.platform == HurdHardware.platform

# Generated at 2022-06-22 23:18:11.808486
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from unittest import mock
    from ansible.module_utils.facts.hardware.hurd import HurdHardwareCollector
    from ansible.module_utils.facts.timeout import TimeoutError

    def get_uptime_facts_side_effect(*pargs, **kwargs):
        return {'test_uptime_facts': 'test_value'}

    def get_memory_facts_side_effect(*pargs, **kwargs):
        return {'test_memory_facts': 'test_value'}

    def get_mount_facts_side_effect(*pargs, **kwargs):
        return {'test_mount_facts': 'test_value'}

    with mock.patch.object(HurdHardwareCollector, '_find_fact_classes', return_value=[HurdHardware]):
        hardware = HurdHardware

# Generated at 2022-06-22 23:18:18.477686
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    facts_keys = facts.keys()

    # a few of the expected keys
    assert ('uptime' in facts_keys)
    assert ('uptime_seconds' in facts_keys)
    assert ('memtotal_mb' in facts_keys)
    assert ('swapfree_mb' in facts_keys)



# Generated at 2022-06-22 23:18:24.843444
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    assert hardware.uptime_cmd == 'procfs_uptime'
    assert hardware.mount_cmd == 'procfs_mount'
    assert hardware.mount_fsck_cmd == 'procfs_mount_fsck'
    assert hardware.mount_partitions_cmd == 'procfs_mount_partitions'
    assert hardware.sysctl_cmd == 'procfs_sysctl'
    assert hardware.vmstat_cmd == 'procfs_vmstat'
    assert hardware.swap_cmd == 'procfs_swap'
    assert hardware.sysctl_path == '/proc/sys'

    assert hardware.memory_full_info_keys == ['MemTotal', 'MemFree', 'MemAvailable']
    assert hardware.memory_info_keys == ['MemTotal', 'MemFree']

    assert hardware.uptime_

# Generated at 2022-06-22 23:18:26.934780
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware(None)
    assert hw.platform == 'GNU'


# Generated at 2022-06-22 23:18:28.634000
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware({}, None)
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:18:29.730531
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector is not None

# Generated at 2022-06-22 23:18:31.315109
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class.platform == 'GNU'


# Generated at 2022-06-22 23:18:34.053806
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:18:36.235940
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware.platform == 'GNU'


# Generated at 2022-06-22 23:18:37.222394
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:18:40.131482
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """ Unit test for constructor of class HurdHardwareCollector """
    instance = HurdHardwareCollector()
    assert instance.platform == 'GNU'
    assert instance._fact_class == HurdHardware


# Generated at 2022-06-22 23:18:43.354306
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware
    assert h._platform == 'GNU'
    assert h._has_subplatforms == False


# Generated at 2022-06-22 23:18:46.362701
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    facts = hh.populate()
    assert isinstance(facts['uptime_seconds'], int)
    assert isinstance(facts['memory_mb'], dict)

# Generated at 2022-06-22 23:18:49.535453
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test for constructor of class HurdHardwareCollector.
    """
    collector = HurdHardwareCollector()
    assert collector.__class__.__name__ == 'HurdHardwareCollector'

# Generated at 2022-06-22 23:18:53.360955
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {}
    collected_facts['ansible_system'] = 'GNU'
    fact_module = HurdHardware()
    hardware_facts = fact_module.populate(collected_facts=collected_facts)
    assert 'ansible_memfree_mb' in hardware_facts
    assert 'ansible_mounts' in hardware_facts

# Generated at 2022-06-22 23:18:54.577026
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:18:57.643021
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    c = HurdHardwareCollector()
    assert c.platform == 'GNU'
    assert c.fact_class == HurdHardware

# Generated at 2022-06-22 23:19:05.224840
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # create an instance of HurdHardware class
    hardware = HurdHardware()

    # create a dictionary of uptime facts provided by get_uptime_facts method of HurdHardware class
    uptime_facts = hardware.get_uptime_facts()
    # create a dictionary of memory facts provided by get_memory_facts method of HurdHardware class
    memory_facts = hardware.get_memory_facts()

    # create a dictionary of mount facts provided by get_mount_facts method of HurdHardware class
    mount_facts = {}
    try:
        mount_facts = hardware.get_mount_facts()
    except TimeoutError:
        pass

    # create a dictionary of hardware facts
    hardware_facts = {}
    # add uptime facts to hardware facts dictionary
    hardware_facts.update(uptime_facts)
    # add memory facts to hardware

# Generated at 2022-06-22 23:19:07.717154
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Test HurdHardwareCollector class constructor"""

    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:09.662972
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    f = HurdHardwareCollector()
    assert f._fact_class == HurdHardware
    assert f._platform == 'GNU'

# Generated at 2022-06-22 23:19:14.109627
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    accuracy = 1e-9
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class == HurdHardware

# Get facts by subclass HurdHardwareCollector of HardwareCollector
# Test data will be created by mocking HurdHardware.

# Generated at 2022-06-22 23:19:15.912299
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:19:25.022641
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    # Test the uptime_facts method
    uptime_facts = {
        'uptime_seconds': 12345,
        'uptime_days': 0,
        'uptime_hours': 3,
        'uptime_minutes': 25
    }

    # Test the memory_facts method
    memory_facts = {
        'ram': {
            'total': 100000000
        }
    }

    # Test the mount_facts method

# Generated at 2022-06-22 23:19:26.315486
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()

# Generated at 2022-06-22 23:19:28.938615
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facter = HurdHardwareCollector()
    assert facter.platform == 'GNU'
    assert facter.fact_class == HurdHardware

# Generated at 2022-06-22 23:19:32.758824
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # construct HurdHardwareCollector
    hurdHardwareCollector = HurdHardwareCollector()
    # get component name of HurdHardwareCollector object as string
    componentName = hurdHardwareCollector.get_componentName()
    # check component name is correct
    assert componentName == 'HurdHardwareCollector'

# Generated at 2022-06-22 23:19:38.455335
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    data = hw.populate()
    assert 'uptime' in data
    assert 'memfree_mb' in data
    assert 'swapfree_mb' in data
    assert 'mounts' in data

# Generated at 2022-06-22 23:19:47.439384
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # initialize
    hh = HurdHardware()

    # populate uptime facts
    hh.uptime = lambda: 10

    # populate memory facts
    hh.get_memory = lambda: {
        'MemTotal': 167980,
        'SwapTotal': 51148,
    }

    # populate mount facts
    hh.get_mount_facts = lambda: {'mounts': 'hello'}

    # test populate
    assert hh.populate() == {
        'uptime': 10,
        'memtotal': 167980,
        'swaptotal': 51148,
        'mounts': 'hello'
    }

# Generated at 2022-06-22 23:19:50.191055
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardware
    fact_collector = HurdHardwareCollector(fact_class)
    assert fact_collector.fact_class == fact_class

# Generated at 2022-06-22 23:19:51.969153
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:20:02.748638
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    # Test if hardware_collector is an instance of HardwareCollector
    assert isinstance(hardware_collector, HardwareCollector)
    # Test if hardware_collector is an instance of HurdHardwareCollector
    assert isinstance(hardware_collector, HurdHardwareCollector)
    # Test if hardware_collector has public attribute _fact_class
    assert hasattr(hardware_collector, '_fact_class')
    # Test if public attribute _fact_class is defined
    assert hardware_collector._fact_class is not None
    # Test if public attribute _fact_class is an instance of class HurdHardware
    assert isinstance(hardware_collector._fact_class, HurdHardware)
    # Test if hardware_collector has public attribute _platform
    assert hasattr

# Generated at 2022-06-22 23:20:04.964829
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hh = HurdHardwareCollector()
    assert hh is not None
    assert hh._fact_class == HurdHardware
    assert hh._platform == 'GNU'

# Generated at 2022-06-22 23:20:10.141582
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw_object = HurdHardware()
    assert hw_object.platform == 'GNU'
    assert hw_object.collector == 'HurdHardwareCollector'


# Generated at 2022-06-22 23:20:12.954712
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hd = HurdHardware()
    assert(hd.platform == 'GNU')

# Unit test to test the uptime fact

# Generated at 2022-06-22 23:20:14.108549
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware().populate()

# Generated at 2022-06-22 23:20:16.852531
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    class MockHurdHardwareCollector():
        _fact_class = HurdHardware

    mock = MockHurdHardwareCollector()
    assert mock is not None

# Generated at 2022-06-22 23:20:19.224099
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class is HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:20:24.459353
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert isinstance(hh.gather, dict)
    assert isinstance(hh.mount_facts, HurdHardware.get_mount_facts)
    assert isinstance(hh.memory_facts, LinuxHardware.get_memory_facts)
    assert isinstance(hh.uptime_facts, GNUHardware.get_uptime_facts)

# Generated at 2022-06-22 23:20:35.372717
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

# Generated at 2022-06-22 23:20:37.848779
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    instance = HurdHardware({'ansible_facts': {}})
    assert instance.populate() == {
        'distribution_release': 'Hurd',
        'distribution_version': '0.8'
    }

# Generated at 2022-06-22 23:20:40.412346
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result
    assert isinstance(result, HardwareCollector)
    assert result.platform == 'GNU'
    assert result.fact_class == HurdHardware

# Generated at 2022-06-22 23:20:41.935715
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_test = HurdHardware()
    assert hurd_test.platform == 'GNU'


# Generated at 2022-06-22 23:20:44.727736
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert isinstance(h, HurdHardwareCollector)

# Generated at 2022-06-22 23:20:52.913032
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware(None)

    # Mock the methods of the class HurdHardware
    hurd_hardware.get_uptime_facts = lambda: {'uptime_seconds': 101}
    hurd_hardware.get_memory_facts = lambda: {'memtotal_mb': 200}
    hurd_hardware.get_mount_facts = lambda: {'mounts': [
        {
            'mount': '/',
            'device': '/dev/hda1',
            'fstype': 'ext2',
            'options': 'rw,errors=remount-ro',
            'size_total': 10,
            'size_available': 5
        }
    ]}

    # Test the populate method
    facts = hurd_hardware.populate()
    assert facts['uptime_seconds'] == 101
   

# Generated at 2022-06-22 23:20:55.843509
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'


# Generated at 2022-06-22 23:21:00.273359
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    linux = HurdHardware()
    assert linux.uptime_stamp is not None
    assert linux.uptime_seconds is not None

# Generated at 2022-06-22 23:21:02.036627
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.platform == 'GNU'
    assert HurdHardwareCollector._fact_class()

# Generated at 2022-06-22 23:21:04.125293
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()['mounts'] == []

# Generated at 2022-06-22 23:21:07.644828
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class.platform == 'GNU'
    assert hardware_collector._fact_class.__name__ == 'HurdHardware'

# Generated at 2022-06-22 23:21:12.040127
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # pylint: disable=protected-access
    hurd_hw = HurdHardware()
    hurd_hw._populate()
    assert isinstance(hurd_hw.uptime, dict)
    assert isinstance(hurd_hw.memory, dict)
    assert isinstance(hurd_hw.mount, dict)

# Generated at 2022-06-22 23:21:13.007628
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:21:18.220646
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Create a new object of the HurdHardwareCollector class.
    obj = HurdHardwareCollector()

    # Check whether the object is an instance of HurdHardwareCollector.
    assert isinstance(obj, HurdHardwareCollector)

# Generated at 2022-06-22 23:21:19.256802
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'


# Generated at 2022-06-22 23:21:20.612714
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj
    assert obj.platform == "GNU"

# Generated at 2022-06-22 23:21:23.018262
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()
    assert isinstance(hurdHardware, LinuxHardware)


# Generated at 2022-06-22 23:21:25.055484
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardwareCollector()
    assert type(h.get_all()) == dict

# Generated at 2022-06-22 23:21:28.562159
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.uptime_facts == None
    assert hw.memory_facts == None
    assert hw.mount_facts == None

# Generated at 2022-06-22 23:21:32.361533
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Create an instance of HurdHardwareCollector, then assert that hasattr
       returns true for 'platform' and '_fact_class' variables.
    """
    hurdhw = HurdHardwareCollector()
    assert hasattr(hurdhw, 'platform')
    assert hasattr(hurdhw, '_fact_class')

# Generated at 2022-06-22 23:21:34.711281
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware


# Generated at 2022-06-22 23:21:37.549376
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw._platform == 'GNU'
    # On GNU/Hurd, kernel_name is the same as kernel_release, because the
    # kernel is not named
    assert hurd_hw.kernel_name == hurd_hw.kernel_release

# Generated at 2022-06-22 23:21:41.596721
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector_obj = HurdHardwareCollector()
    assert hasattr(hurd_hardware_collector_obj, '_fact_class')
    assert hasattr(hurd_hardware_collector_obj, '_platform')

# Generated at 2022-06-22 23:21:52.638805
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import pytest
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    # mocked call of LinuxHardware method to get uptime facts
    def uptime_facts():
        return {'uptime_seconds': 1234, 'uptime_hours': 42}
    # mocked call of LinuxHardware method to get memory facts

# Generated at 2022-06-22 23:21:55.759942
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    import platform
    platform_system = platform.system()
    if platform_system != 'GNU':
        raise Exception('Unit test for HurdHardware only runs on GNU Hurd platform')
    obj = HurdHardware()

# Generated at 2022-06-22 23:21:58.035058
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:22:00.585960
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result.platform == "GNU"
    assert result._fact_class == HurdHardware

# Generated at 2022-06-22 23:22:04.674647
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware({'ansible_system': 'GNU', 'ansible_machine': 'hurd-i386'})
    assert isinstance(hardware, HurdHardware)
    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:22:06.400441
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware({})

    hardware.populate()

# Generated at 2022-06-22 23:22:10.568148
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Get a reference to the Hurd Hardware Collector class
    HurdHardwareCollector.platform = 'GNU'
    hurd_hw_fact_col = HurdHardwareCollector()
    # Assert that the object is a reference to HurdHardwareCollector
    assert hurd_hw_fact_col, 'Object is not a reference to HurdHardwareCollector class'

# Generated at 2022-06-22 23:22:12.218705
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU', 'Platform is not GNU'


# Generated at 2022-06-22 23:22:15.082862
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd = HurdHardwareCollector()
    assert(hurd.platform == 'GNU')


# Generated at 2022-06-22 23:22:25.465125
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import mock
    import platform
    from collections import namedtuple

    with mock.patch.object(platform, 'system') as mock_system:
        mock_system.return_value = 'GNU'

        with mock.patch.object(HurdHardware, 'get_uptime_facts') as mock_get_uptime_facts:
            mock_get_uptime_facts.return_value = {'uptime_seconds': 100}

            with mock.patch.object(HurdHardware, 'get_memory_facts') as mock_get_memory_facts:
                mock_get_memory_facts.return_value = {'memtotal_mb': 512}


# Generated at 2022-06-22 23:22:33.430895
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    file_dict = {
        '/proc/uptime': '7496312.94 7236176.99',
        '/proc/meminfo': 'MemTotal:        1020164 kB\nMemFree:          124884 kB\n',
        '/proc/mounts': "overlay / overlay rw 0 0\ntmpfs /tmp tmpfs rw,nosuid,nodev 0 0\n"
    }
    hurd_hardware = HurdHardware(file_dict=file_dict)
    assert hurd_hardware.mounts
    assert hurd_hardware.memory



# Generated at 2022-06-22 23:22:35.283829
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert isinstance(hw, HurdHardware)
    assert hw.platform == 'GNU'


# Generated at 2022-06-22 23:22:40.150756
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Test HurdHardwareCollector constructor"""

    # Constructor without arguments
    hurd_hw_collector = HurdHardwareCollector()

    assert_equals(hurd_hw_collector._fact_class, HurdHardware)
    assert_equals(hurd_hw_collector._platform, 'GNU')



# Generated at 2022-06-22 23:22:41.103462
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()


# Generated at 2022-06-22 23:22:52.599852
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardwareCollector()
    collected_facts = {
        'ansible_uptime_seconds': 17781.757563362,
        'ansible_system_vendor': 'Debian',
        # Linux specific facts
        'ansible_swapfree_mb': 0.0,
        'ansible_swaptotal_mb': 0.0,
        'ansible_memfree_mb': 204.796875,
        'ansible_memtotal_mb': 993.25,
        'ansible_mounts': [],
        'ansible_devices': {},
        'ansible_cmdline': {}}

# Generated at 2022-06-22 23:22:54.111617
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware is not None

# Generated at 2022-06-22 23:22:56.607608
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    _HurdHardware = HurdHardware()
    assert _HurdHardware.populate() is not None

# Generated at 2022-06-22 23:22:57.834384
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:23:03.087393
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    h = HurdHardware(facts, None)
    h.populate()
    assert facts == {'uptime_seconds': 23,
                     'system_memory_free': 5,
                     'uptime_hours': 0,
                     'system_memory_swapfree': 0,
                     'system_memory_total': 10,
                     'uptime_days': 0}

# Generated at 2022-06-22 23:23:04.146417
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:23:05.805632
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class is HurdHardware

# Generated at 2022-06-22 23:23:07.719929
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """ Constructor for class HurdHardwareCollector
    """
    h_collector = HurdHardwareCollector
    assert h_collector._platform == 'GNU'

# Generated at 2022-06-22 23:23:10.219578
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    f = h.populate()
    assert f is not None
# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-22 23:23:18.142692
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    import time

    hurd_cpu_time_initial = LinuxHardware.get_cpu_time()
    time.sleep(1)
    hurd_cpu_time_final = LinuxHardware.get_cpu_time()
    hurd_uptime = LinuxHardware.get_uptime()
    hurd_mem = LinuxHardware.get_memory_info()

    hurd_mounts = []
    try:
        hurd_mounts = LinuxHardware.get_mounts()
    except TimeoutError:
        pass

    hurd = HurdHardware(None)
    hurd_facts = hurd.populate()
    assert hurd_facts['uptime_sec'] == hurd_uptime

# Generated at 2022-06-22 23:23:19.923212
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()


# Generated at 2022-06-22 23:23:22.709360
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform.startswith(HurdHardware._platform)


# Generated at 2022-06-22 23:23:24.734046
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == "GNU"


# Generated at 2022-06-22 23:23:26.329564
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'


# Generated at 2022-06-22 23:23:28.487720
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts._mount_facts_class.__name__ == "ProcFSTimeout"

# Generated at 2022-06-22 23:23:30.969092
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)
    assert isinstance(hurd_hw, LinuxHardware)

# Generated at 2022-06-22 23:23:32.476955
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HardwareCollector.factory('GNU')
    h.populate()

# Generated at 2022-06-22 23:23:35.976853
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()

    assert obj._fact_class is HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:23:39.372740
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert "uptime" in facts
    assert "memfree_mb" in facts or "memfree_mb" in facts
    assert "mounts" in facts



# Generated at 2022-06-22 23:23:48.398350
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test that the method populate of class HurdHardware returns all the
    facts needed for GNU Hurd.
    """
    hhw = HurdHardware()

    hhw.populate()

    assert hhw.uptime is not None, 'No uptime fact found'
    assert hhw.uptime_seconds is not None, 'No uptime_seconds fact found'
    assert hhw.memory_mb is not None, 'No memory_mb fact found'
    assert hhw.memtotal_mb is not None, 'No memtotal_mb fact found'
    assert hhw.memfree_mb is not None, 'No memfree_mb fact found'

    # mount facts
    #assert hhw.mounts is not None, 'No mounts fact found'
    assert hhw.devices is not None, 'No devices fact found'

# Generated at 2022-06-22 23:23:52.366404
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:23:53.211345
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()


# Generated at 2022-06-22 23:24:05.298441
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class CollectedFactsStub:
        pass

    # Mock _get_uptime_facts() method of class LinuxHardware
    def _get_uptime_facts(self):
        return {'uptime_seconds': 1}

    # Mock _get_memory_facts() method of class LinuxHardware
    def _get_memory_facts(self):
        return {'memory_details': 'StubMemoryDetails_1'}

    # Mock _get_mount_facts() method of class LinuxHardware
    def _get_mount_facts(self):
        return {'mounts': 'StubMounts_1'}

    hurd_hardware_obj = HurdHardware()

    # Mock _get_uptime_facts() method of class LinuxHardware to return uptime_facts
    hurd_hardware_obj._get_uptime_facts = _get

# Generated at 2022-06-22 23:24:08.453862
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector('_platform', '_fact_class')
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware


# Generated at 2022-06-22 23:24:17.195319
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    get_file_content = lambda *args, **kwargs: 'some string'
    ansible_module = MagicMock()
    ansible_module.get_bin_path = MagicMock(return_value='/usr/bin/fact-collector')
    ansible_module.run_command = MagicMock(return_value=['output', 0, ''])
    ansible_module.params = {'gather_subset': 'all'}

    collector = HurdHardwareCollector(ansible_module, get_file_content)
    assert collector.platform == 'GNU'
    assert collector.get_file_content == get_file_content

# Generated at 2022-06-22 23:24:18.023043
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:24:20.460216
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwCollector = HurdHardwareCollector()
    assert hwCollector != None


# Generated at 2022-06-22 23:24:23.052458
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hu = HurdHardware()
    assert hu is not None
    assert hu.mount_facts is not None


# Generated at 2022-06-22 23:24:24.569120
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collectr = HurdHardwareCollector()
    assert collectr is not None

# Generated at 2022-06-22 23:24:25.824348
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware._fact_class == HurdHardware

# Generated at 2022-06-22 23:24:36.564807
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock
    from ansible.module_utils.facts.hardware import HurdHardware

    with patch.object(HurdHardware, 'get_uptime_facts') as \
        mock_get_uptime_facts:
        with patch.object(HurdHardware, 'get_memory_facts') as \
            mock_get_memory_facts:
            with patch.object(HurdHardware, 'get_mount_facts') as \
                mock_get_mount_facts:
                with patch.object(HurdHardware, 'get_distribution') as \
                    mock_get_distribution:

                    mock_get_uptime_facts.return_value = {'uptime_seconds': 100}
                    mock_get_memory_facts