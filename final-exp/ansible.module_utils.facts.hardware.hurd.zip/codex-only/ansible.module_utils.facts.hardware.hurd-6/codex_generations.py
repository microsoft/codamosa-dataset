

# Generated at 2022-06-22 23:14:40.273400
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector().get_fact_class()
    assert fact_class == HurdHardware
    assert fact_class(None).platform == 'GNU'

# Generated at 2022-06-22 23:14:42.590685
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    x = HurdHardware()
    assert x.facts['system'] == 'Linux'
    assert x.facts['distribution'] == 'GNU'

# Generated at 2022-06-22 23:14:44.517350
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw_collector = HurdHardwareCollector()
    assert hurd_hw_collector

# Generated at 2022-06-22 23:14:50.316154
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0

    assert hardware_facts['mounts']
    assert len(hardware_facts['mounts']) > 0

# Generated at 2022-06-22 23:14:52.673160
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'


# Generated at 2022-06-22 23:14:56.196955
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Create a HurdHardware object and invoke method populate
    """
    hurdhw = HurdHardware()
    hurdhw.populate()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-22 23:14:57.971444
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert(h.platform == 'GNU')


# Generated at 2022-06-22 23:15:00.084523
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw_collector = HurdHardwareCollector()
    hw_collector.collect()

# Generated at 2022-06-22 23:15:10.122382
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a class object
    hardware_test = HurdHardware()
    hardware_test.set_mount_device("/dev/mapper/rootvg-lv_root")
    hardware_test.set_mount_type("ext4")
    hardware_test.set_mount_options("rw,relatime")
    hardware_test.set_mount_uuid("8198edb5-cc1d-4a05-9f9d-f0a2ef50af06")
    hardware_test.set_mount_point("/")
    hardware_test.set_mount_partition("/")

    hardware_test.set_mount_device("/dev/mapper/lv_home")
    hardware_test.set_mount_type("ext4")

# Generated at 2022-06-22 23:15:11.723570
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    assert hh.populate()


# Generated at 2022-06-22 23:15:13.009594
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()



# Generated at 2022-06-22 23:15:16.915115
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_collector = HurdHardwareCollector()
    hardware_facts = hardware_collector.collect()

    assert hardware_facts.get('uptime_seconds')
    assert hardware_facts.get('memory_mb')
    assert hardware_facts.get('mounts')

# Generated at 2022-06-22 23:15:19.558133
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()

    assert collector._fact_class.platform == 'GNU'
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:15:20.703569
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    instance = HurdHardwareCollector()

# Generated at 2022-06-22 23:15:21.933666
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:15:25.318384
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector
    assert hurd_hardware_collector._platform == 'GNU'


# Generated at 2022-06-22 23:15:36.899286
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    uptime_facts = {
        'uptime_hours': 734,
        'uptime_minutes': 44,
        'uptime_seconds': 145,
        'uptime': 4545
    }
    memory_facts = {
        'memfree_mb': 300,
        'memtotal_mb': 853,
        'swapfree_mb': 993,
        'swaptotal_mb': 1020
    }

# Generated at 2022-06-22 23:15:47.592873
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Return some basic facts from the method populate from class HurdHardware.
    """
    hurdfacts = HurdHardware()
    facts = hurdfacts.populate()

    uptime = facts['uptime']
    uptime_seconds = facts['uptime_secs']
    memtotal = facts['memtotal_mb']
    memfree = facts['memfree_mb']
    swapsize = facts['swapfree_mb']

    assert isinstance(uptime, int)
    assert uptime > 0
    assert isinstance(uptime_seconds, int)
    assert uptime_seconds > 0
    assert isinstance(memtotal, int)
    assert memtotal > 0
    assert isinstance(memfree, int)
    assert memfree < memtotal
    assert isinstance(swapsize, int)

# Generated at 2022-06-22 23:15:50.955304
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._platform == 'GNU'
    assert hc._fact_class.__name__ == 'HurdHardware'

# Generated at 2022-06-22 23:15:55.854392
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    instance = HurdHardwareCollector()
    assert isinstance(instance, HardwareCollector)
    assert isinstance(instance.platform, str)
    assert isinstance(instance.fact_class, HurdHardware)
    assert isinstance(instance.priority, int)
    assert isinstance(instance.fact_class.platform, str)


# Generated at 2022-06-22 23:15:58.391162
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwcollector = HurdHardwareCollector(None)
    assert hwcollector.platform is 'GNU'
    assert hwcollector.fact_class is HurdHardware


# Generated at 2022-06-22 23:16:00.286125
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    instance = HurdHardwareCollector()

    assert instance is not None

# Generated at 2022-06-22 23:16:03.724144
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()

    # Test if method returns expected dict
    assert type(hurd_hw.populate()) == dict, \
        'hurd_hw.populate() does not return a dict'

# Generated at 2022-06-22 23:16:07.114822
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'
    assert isinstance(h.fact_class, HurdHardware)


# Generated at 2022-06-22 23:16:09.998863
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Basic unit test for the constructor.
    """
    x = HurdHardwareCollector()
    assert x._platform == 'GNU'
    assert x._fact_class == HurdHardware


# Generated at 2022-06-22 23:16:12.275966
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_collector = HurdHardwareCollector()
    assert hurd_collector.platform == 'GNU'
    assert hurd_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:16:13.652949
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.linux_sysinfo is None
    assert h.mount_proc is None

# Generated at 2022-06-22 23:16:24.710102
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_device = HurdHardware()

    facts = hurd_device.populate()
    assert len(facts['mounts']) > 0
    assert 'MemTotal' in facts['memory']

    # test that the key 'mounts' is not present
    hurd_device.mounts = None
    facts = hurd_device.populate()
    assert 'mounts' not in facts

    # test that the key 'memory' is not present
    hurd_device.meminfo = None
    facts = hurd_device.populate()
    assert 'memory' not in facts

    # test that the key 'uptime' is not present
    hurd_device.uptime = None
    facts = hurd_device.populate()
    assert 'uptime' not in facts

# Generated at 2022-06-22 23:16:28.198564
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhardware = HurdHardware()
    assert(hurdhardware.platform == 'GNU')


# Generated at 2022-06-22 23:16:36.022478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    actual_output = hurd_hardware.populate()
    assert 'uptime' in actual_output
    assert 'swapfree_mb' in actual_output
    assert 'swaptotal_mb' in actual_output
    assert 'memtotal_mb' in actual_output
    assert 'memfree_mb' in actual_output
    assert 'memavailable_mb' in actual_output
    assert 'memcached_mb' in actual_output
    assert 'mounts' in actual_output

# Generated at 2022-06-22 23:16:46.802826
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    hh.populate()

    # Check basic facts
    assert hh.uptime is not None
    assert hh.uptime_seconds is not None

    assert hh.mem_total is not None
    assert hh.swap_total is not None

    # Check mount facts
    assert hh.mounts is not None
    assert isinstance(hh.mounts, list)
    assert len(hh.mounts) > 0
    assert hh.mounts[0].device is not None
    assert hh.mounts[0].mount is not None
    assert hh.mounts[0].fstype is not None
    assert hh.mounts[0].options is not None

# Generated at 2022-06-22 23:16:48.797918
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._platform == 'GNU'
    assert hw._fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:16:49.786700
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware(None)



# Generated at 2022-06-22 23:16:54.644520
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        assert hasattr(HurdHardwareCollector, '_fact_class')
        assert HurdHardwareCollector._fact_class is HurdHardware
        assert HurdHardwareCollector._platform is HurdHardware.platform
    except AssertionError:
        raise AssertionError(
            "Check the constructor of class HurdHardwareCollector."
        )

# Generated at 2022-06-22 23:17:02.783459
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

# Generated at 2022-06-22 23:17:05.137232
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert 'uptime_seconds' in hurd_hw.populate()

# Generated at 2022-06-22 23:17:07.535813
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)
    assert not hasattr(h, 'distribution')


# Generated at 2022-06-22 23:17:08.775863
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == HurdHardware._platform

# Generated at 2022-06-22 23:17:14.354544
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Test with no params
    obj = HurdHardwareCollector(module=None)
    assert isinstance(obj, HardwareCollector)
    assert obj.module is None
    assert obj._platform == 'GNU'
    assert obj.options is None
    assert isinstance(obj.facts,HurdHardware)



# Generated at 2022-06-22 23:17:17.433988
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class is HurdHardware
    assert hhc._platform == 'GNU'


# Generated at 2022-06-22 23:17:18.672767
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware({})
    h.populate()

# Generated at 2022-06-22 23:17:21.936712
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Test HurdHardware constructor
    hurd_hw = HurdHardware()
    assert hurd_hw


# Generated at 2022-06-22 23:17:26.925301
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    given_facts = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'GNU/Hurd'
    }
    collector = HurdHardwareCollector(given_facts, None)
    actual_fact_class = collector.collect()[0]
    assert actual_fact_class == HurdHardware

# Generated at 2022-06-22 23:17:27.893395
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h is not None

# Generated at 2022-06-22 23:17:30.777368
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware._platform == 'GNU'
    assert hardware._fact_class == HurdHardware

# Generated at 2022-06-22 23:17:37.551154
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware({'kernel': 'GNU'})
    facts = h.populate()
    assert 'uptime_seconds' in facts
    assert 'uptime_days' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'mounts' in facts


# Generated at 2022-06-22 23:17:45.877101
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Creating a stub for file /proc/uptime
    class StubUptimeFile:

        def readline(self):
            return '500 20\n'

    # Creating a stub for open
    class StubOpen:

        def __init__(self, file, mode):
            pass

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

        def __enter__(self):
            return StubUptimeFile()

    # Creating a stub for HurdHardware
    class StubHurdHardware(HurdHardware):

        def __init__(self):
            pass

        @staticmethod
        def get_mount_facts():
            return {'mounts': [{'device': '/dev/sda1', 'mount': '/', 'fstype': 'ext4'}]}


# Generated at 2022-06-22 23:17:49.709186
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    result = h.populate()
    assert result['memtotal_mb'] == 2
    assert result['swapfree_mb'] == 1
    assert result['uptime_seconds'] == 5
    assert result['mounts']['/'] is not None

# Generated at 2022-06-22 23:17:51.758501
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_info = HurdHardware()
    # class Hardware has no __init__ method
    assert isinstance(hardware_info, HurdHardware)

# Generated at 2022-06-22 23:18:00.147169
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    # First test with a fake hardware collection
    hardware = {
        'memtotal_mb': 2 * 1024,
        'memfree_mb': 1024,
        'swaptotal_mb': 4 * 1024,
        'swapfree_mb': 2 * 1024,
        'os_type': 'GNU',
    }
    expected = {
        'memfree_mb': 1024,
        'memtotal_mb': 2 * 1024,
        'swapfree_mb': 2 * 1024,
        'swaptotal_mb': 4 * 1024,
        'uptime_seconds': 0,
    }
    assert hurd.populate(hardware) == expected

    # Second test with no hardware collection given

# Generated at 2022-06-22 23:18:10.313083
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # TODO: use a proper mock object
    # Create a mock object built on class
    class MockHurdHardware(HurdHardware, object):
        def __init__(self):
            self.uptime_facts = {'uptime': 1234}
            self.memory_facts = {'memory': 2345}
            self.mount_facts = {'mounts': 3456}

        def get_uptime_facts(self):
            return self.uptime_facts

        def get_memory_facts(self):
            return self.memory_facts

        def get_mount_facts(self):
            return self.mount_facts

    hw = MockHurdHardware()
    facts = hw.populate()

    assert facts == {'uptime': 1234, 'memory': 2345, 'mounts': 3456}

# Generated at 2022-06-22 23:18:13.976971
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    assert type(hurd_hardware.populate()) is dict, "Return value of HurdHardware.populate is not a dict"


# Generated at 2022-06-22 23:18:18.858807
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.get_memory() == {}
    assert h.get_mounts() == []
    assert h.get_uptime() == {}
    assert h.get_cpu_facts() == {}

# Generated at 2022-06-22 23:18:21.111787
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-22 23:18:29.564022
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert(hardware_facts['uptime_minutes'] > 0)
    assert(hardware_facts['uptime_seconds'] > 0)
    assert(hardware_facts['uptime_seconds'] < 20000)
    assert(hardware_facts['memtotal_mb'] > 0)
    assert(hardware_facts['memtotal_mb'] < 100000)
    assert(hardware_facts['memfree_mb'] >= 0)
    assert(hardware_facts['swaptotal_mb'] >= 0)
    assert(hardware_facts['swapfree_mb'] >= 0)

# Generated at 2022-06-22 23:18:31.415364
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._platform == 'GNU'


# Generated at 2022-06-22 23:18:39.894354
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert 'uptime' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'uptime_days' in hardware_facts
    assert 'uptime_hours' in hardware_facts
    assert 'uptime_minutes' in hardware_facts

    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts

    assert 'mounts' in hardware_facts

# Generated at 2022-06-22 23:18:41.646015
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware('/proc')
    assert h.platform == 'GNU'



# Generated at 2022-06-22 23:18:49.248993
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    collected_facts = {'ansible_architecture': 'x86_64'}
    hardware_facts = hardware.populate(collected_facts)
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['mounts'] != []
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0

# Generated at 2022-06-22 23:18:50.970679
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facter = HurdHardware()
    assert hurd_facter.platform == 'GNU'

# Generated at 2022-06-22 23:18:53.402892
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:19:05.056499
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockHurdHardware(HurdHardware):
        def __init__(self):
            self._data = {}

        def fill_data_mock(self):
            # pylint: disable=protected-access
            self._data = {'processor': [{'model_name': 'some_model'}, {'model_name': 'some_other_model'}],
                          'system': {'product_name': 'some_product', 'manufacturer': 'some_manufacturer'}}

            self._data['memory'] = {'memtotal_mb': 500.0, 'memfree_mb': 100.0, 'swaptotal_mb': 100.0,
                                    'swapfree_mb': 50.0}
            self._data['uptime_seconds'] = 100.0

# Generated at 2022-06-22 23:19:05.776542
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware()


# Generated at 2022-06-22 23:19:07.757537
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware

# Generated at 2022-06-22 23:19:10.131402
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdhwc = HurdHardwareCollector()
    assert hurdhwc.platform == 'GNU'
    assert hurdhwc.fact_class == HurdHardware

# Generated at 2022-06-22 23:19:13.081500
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc._platform == 'GNU'
    assert hwc._fact_class == HurdHardware


# Generated at 2022-06-22 23:19:20.126138
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector.fetch_facts()
    assert hw['uptime_seconds'] >= 0, "Uptime should be positive"
    assert 'SwapFree' in hw, "SwapFree should be in the dictionary"
    assert 'MemTotal' in hw, "MemTotal should be in the dictionary"
    assert 'MemFree' in hw, "MemFree should be in the dictionary"

# Generated at 2022-06-22 23:19:21.706004
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware(None)
    assert hardware.mount_facts['proc']['space_total'] != -1

# Generated at 2022-06-22 23:19:23.141857
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(), HardwareCollector)


# Generated at 2022-06-22 23:19:24.196530
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj

# Generated at 2022-06-22 23:19:31.035717
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def test_memory_facts():
        assert hw_collector._fact_class.get_memory_facts()['ansible_memtotal_mb'] > 0

    def test_mount_facts():
        assert hw_collector._fact_class.get_mount_facts()['ansible_mounts']

    hw_collector = HurdHardwareCollector()
    test_memory_facts()
    test_mount_facts()

# Generated at 2022-06-22 23:19:44.372633
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # class mock for class HurdHardware and one of its dependencies
    class mock_LinuxHardware(object):
        def get_mount_facts(self):
            return {'mounts': ["/dev/sda1 on / type ext4 (rw,noatime)"],
                    'mounts_filesystems': [["/dev/sda1", "/", "ext4"]]}
        def get_uptime_facts(self):
            return {'uptime_seconds': 12345}
        def get_memory_facts(self):
            return {'memtotal_mb': 123}

# Generated at 2022-06-22 23:19:45.855928
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_instance = HurdHardware()
    assert hardware_instance.platform == 'GNU'

# Generated at 2022-06-22 23:19:54.740801
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    stub_collected_facts = {}
    stub_module = None
    stub_uptime_facts = { 'uptime_seconds': 2 }
    stub_memory_facts = { 'memtotal_mb': 1 }
    expected_collected_facts = { 'uptime_seconds': 2,
                                 'memtotal_mb': 1 }
    hurd_hardware = HurdHardware(stub_module)
    hurd_hardware.get_uptime_facts = lambda: stub_uptime_facts
    hurd_hardware.get_memory_facts = lambda: stub_memory_facts
    hurd_hardware.get_mount_facts = lambda: {}
    collected_facts = hurd_hardware.populate(stub_collected_facts)
    assert collected_facts == expected_collected_facts


# Generated at 2022-06-22 23:20:01.067769
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test the GNU Hurd Hardware module (HurdHardware)"""
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-22 23:20:07.808672
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw_facts = HurdHardwareCollector.collect()
    assert sorted(hurd_hw_facts['mounts'][0].keys()) == ['block_size', 'device', 'fstype', 'mount', 'options', 'size_available', 'size_total']

    assert 'memory_mb' in hurd_hw_facts
    assert isinstance(hurd_hw_facts['memory_mb']['real']['total'], int)
    assert isinstance(hurd_hw_facts['memory_mb']['real']['used'], int)
    assert isinstance(hurd_hw_facts['memory_mb']['real']['free'], int)
    assert isinstance(hurd_hw_facts['memory_mb']['swap']['total'], int)

# Generated at 2022-06-22 23:20:09.976869
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:20:11.719036
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-22 23:20:13.344154
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'

# Generated at 2022-06-22 23:20:15.349888
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Check If it is Hurd
    # Check If procfs is available
    # Check If uptime is available
    # Check If memory is available
    # Check If mount is available
    hurd_collector = HurdHardwareCollector()
    assert hurd_collector.platform == 'GNU'


# Generated at 2022-06-22 23:20:19.432895
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Test creating instance of HurdHardwareCollector class
    # without creating a subclass of the HurdHardwareCollector
    # class.
    # instance = HurdHardwareCollector()
    pass

if __name__ == '__main__':
    test_HurdHardwareCollector()

# Generated at 2022-06-22 23:20:22.461367
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.collect()


# Generated at 2022-06-22 23:20:33.303463
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup
    import os
    import sys
    import inspect
    import pytest
    from os.path import dirname
    from lib_under_test import HurdHardware

    linux_hardware_file = os.path.join(dirname(__file__), '..', '..', '..', 'module_utils', 'facts',
                                       'hardware', 'linux.py')
    linux_hardware_module = os.path.join(dirname(__file__), '..', '..', '..', 'module_utils', 'facts',
                                         'hardware', 'linux.pyc')
    # Avoid loading the linux module on GNU/Hurd
    if os.path.isfile(linux_hardware_module):
        os.remove(linux_hardware_module)

# Generated at 2022-06-22 23:20:36.859910
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)

if __name__ == '__main__':
    test_HurdHardware()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 23:20:38.943271
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-22 23:20:41.934394
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.get_mount_facts.__module__ == 'ansible.module_utils.facts.hardware.linux'
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:20:44.726936
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
   assert HurdHardwareCollector._fact_class == HurdHardware
   assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:20:46.637843
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardwareCollector()
    hardware_facts = collector.collect(None, None)

    assert hardware_facts.get('uptime_seconds') is not None
    assert hardware_facts.get('memtotal_mb') is not None
    assert hardware_facts.get('mounts') is not None

# Generated at 2022-06-22 23:20:48.585189
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHW = HurdHardware()
    assert hurdHW.platform == 'GNU'


# Generated at 2022-06-22 23:20:49.498952
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware({})
    assert type(obj) is HurdHardware


# Generated at 2022-06-22 23:20:52.160024
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.linux_sysinfo is not None
    assert h._mount_file == '/proc/mounts'
    assert h._uptime_file == '/proc/uptime'

    assert HurdHardware.platform == 'GNU'



# Generated at 2022-06-22 23:21:02.280693
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts_dict = hurd_hw.populate()

    # Expected values

# Generated at 2022-06-22 23:21:07.643793
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.get_file_content('/proc/uptime') == hurd_hardware.get_uptime_facts()
    assert hurd_hardware.get_file_content('/proc/meminfo') == hurd_hardware.get_memory_facts()
    assert hurd_hardware.get_file_content('/proc/mounts') == hurd_hardware.get_mount_facts()

# Generated at 2022-06-22 23:21:11.158331
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert (hurd.uptime_facts() == 'uptime')
    assert (hurd.get_memory_facts() == 'memory')
    assert (hurd.get_mount_facts() == 'mount')
    assert (hurd.platform == 'GNU')

# Generated at 2022-06-22 23:21:12.718121
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:21:18.657200
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_class = HurdHardware()
    test_collector = HurdHardwareCollector(test_class)
    test_facts = test_collector.collect(None, None)
    assert isinstance(test_facts, dict)
    assert sorted(test_facts.keys()) == ['mounts', 'memory', 'uptime']

# Generated at 2022-06-22 23:21:20.011384
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h is not None


# Generated at 2022-06-22 23:21:23.700736
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class Facts(object):
        def __init__(self):
            self.memory = {}
            self.uptime = {}
            self.mount = {}

    facts = HurdHardware(Facts()).populate()
    assert facts['uptime'] == {}
    assert facts['memory'] == {}
    assert facts['mounts'] == {}

# Generated at 2022-06-22 23:21:34.630287
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Dummy class definitions to test HurdHardware.populate()
    """
    class DummyModule:
        def __init__(self, **kwargs):
            for (key, value) in kwargs.items():
                setattr(self, key, value)

    class DummyHardware:
        def __init__(self, **kwargs):
            self.facts = {}
            self.__dict__.update(kwargs)

        def populate(self):
            return self.facts

        def get_mount_facts(self):
            raise TimeoutError

    def get_uptime_facts():
        return {'uptime_seconds': 42}

    def get_memory_facts():
        return {'memtotal_mb': 42}

    # Populate()

# Generated at 2022-06-22 23:21:37.037057
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()


# Generated at 2022-06-22 23:21:38.579784
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'


# Generated at 2022-06-22 23:21:50.524498
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    with open('/proc/mounts', 'r') as file:
        content = file.read()
    with open('/proc/uptime', 'r') as file:
        content2 = file.read()
    with open('/proc/meminfo', 'r') as file:
        content3 = file.read()

    # Try with content.
    GNU_Hardware_content = HurdHardware(content, content2, content3)
    assert GNU_Hardware_content.uptime_seconds == 0
    assert GNU_Hardware_content.uptime_string == "0 days, 0:00:00.00"

    assert GNU_Hardware_content.memtotal_mb == 0
    assert GNU_Hardware_content.memfree_mb == 0
    assert GNU_Hardware_content.memavailable_mb == 0
    assert GNU_Hardware_content.sw

# Generated at 2022-06-22 23:21:52.638468
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware

# Generated at 2022-06-22 23:21:54.392306
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'


# Generated at 2022-06-22 23:21:56.774668
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'
    assert type(h.facts) == dict


# Generated at 2022-06-22 23:22:08.263408
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector
    hurd_hw = HurdHardware({})
    mount_facts = LinuxHardwareCollector._get_mountfacts()


# Generated at 2022-06-22 23:22:11.748190
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Test HurdHardware constructor"""
    hurd = HurdHardware()
    assert hurd.get_file_path('mount') == '/proc/mounts'
    assert hurd.get_file_path('meminfo') == '/proc/meminfo'
    assert hurd.get_file_path('uptime') == '/proc/uptime'

# Generated at 2022-06-22 23:22:23.661997
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    facts = hurdhw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_seconds'] == facts['uptime_days'] * 24 * 60 * 60 + facts['uptime_hours'] * 60 * 60
    assert facts['memtotal_mb'] > 0
    assert facts['swaptotal_mb'] == 0

    mount_facts = facts.get('mounts', [])
    assert len(mount_facts) > 0
    assert mount_facts[0].get('device') == '/dev/hd0s1'
    assert mount_facts[0].get('fstype') == 'ext2'
    assert mount_facts[0].get('mount') == '/'
    assert mount_facts[0].get('options') == 'rw,noatime'

# Generated at 2022-06-22 23:22:30.236224
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime
    assert hurd_hw.memtotal
    assert hurd_hw.memfree
    assert hurd_hw.swaptotal
    assert hurd_hw.swapfree


# Tests for classes HurdHardware and HurdHardwareCollector
# are done in the tests of the GNU/Linux classes
# test_LinuxHardware, test_LinuxHardwareCollector

# Generated at 2022-06-22 23:22:31.107704
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector(None)


# Generated at 2022-06-22 23:22:33.474866
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU', \
        "GNU Hurd specific subclass of Hardware instance is expected"

# Generated at 2022-06-22 23:22:37.329125
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import collections
    hw = HurdHardware()
    facts = hw.populate()
    assert isinstance(facts, collections.Mapping)
    assert 'uptime' in facts
    assert 'uptime_seconds' in facts
    assert 'memfree_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'mounts' in facts


# Generated at 2022-06-22 23:22:38.511710
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector

# Generated at 2022-06-22 23:22:41.166429
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdd = HurdHardwareCollector()
    assert(isinstance(hurdd, HurdHardwareCollector))
    assert(isinstance(hurdd.collect(), dict))


# Generated at 2022-06-22 23:22:47.618360
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    def get_memory_facts_stub(self):
        return {'memory_mb': 10000}
    h.get_memory_facts = get_memory_facts_stub.__get__(h)

    def get_mount_facts_stub(self):
        return {'mounts': {'/': {'device': 'UUID=x', 'fstype': 'ext4'}}}
    h.get_mount_facts = get_mount_facts_stub.__get__(h)

    expected = {'memory_mb': 10000, 'mounts': {'/': {'device': 'UUID=x', 'fstype': 'ext4'}}}
    assert h.populate() == expected

# Generated at 2022-06-22 23:22:50.094178
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._fact_class == HurdHardware
    assert hc._platform == 'GNU'

# Generated at 2022-06-22 23:22:52.738829
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector.platform == 'GNU'


# Generated at 2022-06-22 23:22:54.161415
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:22:57.095573
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    system = HurdHardwareCollector()
    assert isinstance(system, HardwareCollector)
    assert isinstance(system._fact_class, HurdHardware)

# Generated at 2022-06-22 23:22:59.066743
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'



# Generated at 2022-06-22 23:23:01.522976
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware


# Generated at 2022-06-22 23:23:02.122599
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware()

# Generated at 2022-06-22 23:23:03.921328
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert isinstance(hc._fact_class, HurdHardware)

# Generated at 2022-06-22 23:23:05.246209
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:23:07.313125
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class == HurdHardware
    assert hhc._platform == 'GNU'



# Generated at 2022-06-22 23:23:09.602996
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:23:10.702028
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:23:11.688353
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:23:14.467357
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    if hh is not None:
        print("successful instantiation of object HurdHardware.")
    else:
        raise Exception("failed to instantiate object HurdHardware.")


# Generated at 2022-06-22 23:23:15.305489
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()


# Generated at 2022-06-22 23:23:27.170422
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys
    import os
    import json

    with open(os.path.join(sys.path[0], 'ansible_collected_facts.json'), 'r') as _json_file:
        json_string = _json_file.read()

    # Load ansible_collected_facts.json as a list of dictionaries
    ansible_collected_facts_list = json.loads(json_string)

    # Get the dictionary corresponding to GNU
    ansible_collected_facts_dict = [item for item in ansible_collected_facts_list if item['ansible_os_family'] == 'GNU'][0]

    # Create the instance to be tested
    tested_instance = HurdHardware(module=None)


# Generated at 2022-06-22 23:23:29.771809
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert isinstance(hurdhw, HurdHardware)
    assert isinstance(hurdhw, LinuxHardware)

# Generated at 2022-06-22 23:23:35.359182
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Create an instance of the HurdHardwareCollector class with the 'Hurd' platform
    and check if the platform and fact_class is set correctly
    """
    hurd_collector = HurdHardwareCollector()
    assert hurd_collector.platform == 'GNU'
    assert hurd_collector.fact_class == HurdHardware

# Generated at 2022-06-22 23:23:37.709840
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector, HardwareCollector)


# Generated at 2022-06-22 23:23:43.236654
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.uptime_file == '/proc/uptime'
    assert hurd_hardware.memory_file == '/proc/meminfo'
    assert hurd_hardware.mount_file == '/proc/mounts'

# Generated at 2022-06-22 23:23:46.078177
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test_obj = HurdHardwareCollector()
    assert test_obj._fact_class == HurdHardware
    assert test_obj._platform == 'GNU'


# Generated at 2022-06-22 23:23:55.532114
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Use values returned by Hurd when running the test
    HurdPopulate = {
        'uptime_seconds': 1298,
        'memfree_mb': 326,
        'memtotal_mb': 811,
        'mounts': [
            {'device': 'rootfs',
             'mount': '/',
             'fstype': 'rootfs',
             'options': 'rw'},
            {'device': '/dev/disk/by-uuid/2d51714c-b6a4-4a4a-b4be-c514b0695d9e',
             'mount': '/home',
             'fstype': 'ext4',
             'options': 'rw,relatime'}]
    }

    # Create a HurdHardware instance and set its attributes
    hurd_hw = HurdHardware

# Generated at 2022-06-22 23:23:57.079264
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()

# Generated at 2022-06-22 23:24:00.515919
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwg = HurdHardwareCollector()
    assert hwg.__class__.__name__ == 'HurdHardwareCollector'
    assert hwg.platform == 'GNU'


# Generated at 2022-06-22 23:24:04.961398
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw_collector = HurdHardwareCollector()
    assert hurd_hw_collector.platform == 'GNU'
    assert hurd_hw_collector._fact_class == HurdHardware

if __name__ == '__main__':
    test_HurdHardwareCollector()

# Generated at 2022-06-22 23:24:08.005600
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_col = HurdHardwareCollector()
    assert hw_col._fact_class == HurdHardware
    assert hw_col._platform == 'GNU'


# Generated at 2022-06-22 23:24:09.056686
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    my_facts = HurdHardware('/proc')

# Generated at 2022-06-22 23:24:12.320217
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()

    # number of partitions
    assert 'partitions' == hurdhw.partitions, 'Error in "partitions" parameter'

# Generated at 2022-06-22 23:24:19.272226
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create instance of HurdHardware
    _hw = HurdHardware()

    # Get all facts of HurdHardware
    facts = _hw.populate()
    fact_keys = list(facts.keys())
    fact_keys.sort()

    # We expect exactly all of these facts to be present
    expected_fact_keys = ['ansible_uptime_seconds', 'ansible_memfree_mb',
        'ansible_swaptotal_mb', 'ansible_mounts', 'ansible_memtotal_mb',
        'ansible_swapfree_mb']

    if fact_keys != expected_fact_keys:
        raise Excepti

# Generated at 2022-06-22 23:24:22.700978
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.collector == HurdHardware

# Generated at 2022-06-22 23:24:24.195825
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.__name__ == 'HurdHardwareCollector'

# Generated at 2022-06-22 23:24:26.072959
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware()
    assert fact_class.populate()

# Generated at 2022-06-22 23:24:31.188413
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert isinstance(HurdHardware().platform, str)
    assert isinstance(HurdHardware().get('memory'), dict)
    assert isinstance(HurdHardware().get('system'), dict)
    assert isinstance(HurdHardware().get('uptime'), dict)
    assert isinstance(HurdHardware().get('mounts'), list)

# Generated at 2022-06-22 23:24:33.306483
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Unit test for constructor of class HurdHardware"""

    hurd = HurdHardware()
    assert hurd.platform == 'GNU'



# Generated at 2022-06-22 23:24:35.343696
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'



# Generated at 2022-06-22 23:24:37.498820
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj=HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'
