

# Generated at 2022-06-22 23:14:36.710991
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware(None)
    assert hurd_hardware.platform == "GNU"

# Generated at 2022-06-22 23:14:47.757972
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    uptime_facts = {}
    memory_facts = {}
    mount_facts = {}
    try:
        uptime_facts = HurdHardwareCollector().get_uptime_facts()
        memory_facts = HurdHardwareCollector().get_memory_facts()
    except TimeoutError:
        pass
    try:
        mount_facts = HurdHardwareCollector().get_mount_facts()
    except TimeoutError:
        pass
    hardware_facts = uptime_facts
    hardware_facts.update(memory_facts)
    hardware_facts.update(mount_facts)

    assert hardware_facts['uptime_seconds'] == '1165'
    assert hardware_facts['uptime_hours'] == '0'
    assert hardware_facts['uptime_days'] == '0'

# Generated at 2022-06-22 23:14:49.784723
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'


# Generated at 2022-06-22 23:14:51.184390
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.populate()

# Generated at 2022-06-22 23:14:52.844902
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()


# Generated at 2022-06-22 23:15:03.627122
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {
        'ansible_system_vendor': 'Debian',
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
    }
    facts = hurd_hardware.populate(collected_facts)

    assert 'uptime_seconds' in facts
    assert 'total_bytes' in facts
    assert 'total_usable_bytes' in facts

    disk_facts = facts['disks']
    disk_by_size = sorted(disk_facts.values(), key=lambda k: k['size_total'], reverse=True)

    assert disk_by_size
    assert disk_by_size[0]
    assert disk_by_size[0]['size_total']

# Generated at 2022-06-22 23:15:05.509075
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()

    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:15:12.831807
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with no timeout
    hurdhw = HurdHardware()
    hurdhw.get_mount_facts = lambda: {'mounts': '/tmp'}
    assert hurdhw.populate() == {'mounts': '/tmp'}

    # Test with timeout
    hurdhw = HurdHardware()
    hurdhw.get_uptime_facts = lambda: {'uptime': 5}
    hurdhw.get_memory_facts = lambda: {'memtotal': 200}
    hurdhw.get_mount_facts = lambda: {'mounts': '/tmp'}
    hurdhw.get_mount_facts = lambda: {'timeout': True}
    assert hurdhw.populate() == {'uptime': 5, 'memtotal': 200, 'timeout': True}

# Generated at 2022-06-22 23:15:17.761554
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert type(hurd_hardware.uptime_facts) is list
    assert len(hurd_hardware.uptime_facts) == 2
    assert type(hurd_hardware.mount_facts) is dict
    assert type(hurd_hardware.memory_facts) is dict

# Generated at 2022-06-22 23:15:19.738930
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware._platform == 'GNU'

# Generated at 2022-06-22 23:15:30.866152
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    collected_facts = {}
    hw.populate(collected_facts=collected_facts)
    assert collected_facts["uptime_seconds"] > 0
    assert collected_facts["uptime_format"] == "0:00 hours, 0:00 mins"

    assert collected_facts["ansible_devices"]["hda1"]["size"] == "46002432"
    assert collected_facts["ansible_devices"]["hda1"]["vendor"] == ""
    assert collected_facts["ansible_devices"]["hda1"]["model"] == "HDD"
    assert collected_facts["ansible_devices"]["hda1"]["serial"] == "HDD"

# Generated at 2022-06-22 23:15:42.418162
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    sample_uptime_facts = {
        'uptime': 1720.08,
        'uptime_days': 2,
        'uptime_hours': 0,
        'uptime_minutes': 28,
        'uptime_seconds': 40,
    }

# Generated at 2022-06-22 23:15:46.217788
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # test_HurdHardwareCollector function is not a unittest
    # but is used to test the constructor of class HurdHardwareCollector
    hurd_hw = HurdHardwareCollector()
    assert isinstance(hurd_hw, HardwareCollector)
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:15:49.387386
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw_obj = HurdHardware()
    assert(hurd_hw_obj.platform == 'GNU')


# Generated at 2022-06-22 23:15:50.823683
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'


# Generated at 2022-06-22 23:15:52.323899
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()


# Generated at 2022-06-22 23:16:03.367031
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test method HurdHardware::populate
    """

    # Patch the method HurdHardware::get_mount_facts
    # which returns memory information
    def fake_get_memory_facts(self):
        return {'fake_memory_key': 'fake_memory_value'}

    # Patch the method HurdHardware::get_mount_facts
    # which returns mount information
    def fake_get_mount_facts(self):
        return {'fake_mount_key': 'fake_mount_value'}

    hurd_hardware = HurdHardware()
    # Patch get_memory_facts and get_mount_facts
    hurd_hardware.get_memory_facts = fake_get_memory_facts
    hurd_hardware.get_mount_facts = fake_get_mount_facts
    # The collected_facts parameter is not

# Generated at 2022-06-22 23:16:07.113683
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert isinstance(h, HardwareCollector)
    assert issubclass(h._fact_class, LinuxHardware)
    assert h._platform == 'GNU'

# Generated at 2022-06-22 23:16:09.645959
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc._fact_class == HurdHardware
    assert hwc._platform == 'GNU'


# Generated at 2022-06-22 23:16:11.633400
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware


# Generated at 2022-06-22 23:16:12.946372
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hardware_facts = hw.populate()
    assert hardware_facts['uptime_days']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['memory_mb']
    assert hardware_facts['mounts']

# Generated at 2022-06-22 23:16:20.097638
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hurd_facts = HurdHardware()
    hurd_facts.populate()

    assert(hurd_facts.facts['uptime_days'] != 0)

    assert(hurd_facts.facts['mem_total_mb'] != 0)
    assert(hurd_facts.facts['mem_real_free_mb'] != 0)
    assert(hurd_facts.facts['mem_real_used_mb'] != 0)
    assert(hurd_facts.facts['mem_swap_used_mb'] != 0)

    assert(len(hurd_facts.facts['mounts']) != 0)

# Generated at 2022-06-22 23:16:23.494538
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._fact_class is HurdHardware

# Generated at 2022-06-22 23:16:30.931001
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    uptime_facts = hurd_hardware.get_uptime_facts()
    memory_facts = hurd_hardware.get_memory_facts()
    # TODO: write a test for get_mount_facts,
    # as this method needs to run in a subprocess
    #mount_facts = hurd_hardware.get_mount_facts()

    expected_facts = {}
    expected_facts.update(uptime_facts)
    expected_facts.update(memory_facts)
    #expected_facts.update(mount_facts)

    collected_facts = hurd_hardware.populate()

    assert collected_facts == expected_facts, \
           "Collected facts %s is not equal to expected facts %s." % \
           (collected_facts, expected_facts)

# Generated at 2022-06-22 23:16:36.397898
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test if the HurdHardware._populate method returns a dict with at least
    the 'uptime_seconds' key with a float value.
    """
    hurd_hardware_ins = HurdHardware()

    returned_facts = hurd_hardware_ins.populate()

    assert 'uptime_seconds' in returned_facts
    assert returned_facts['uptime_seconds'] > 0.0

# Generated at 2022-06-22 23:16:44.310513
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = get_test_facts()
    hurd_hardware = HurdHardware(facts)

    assert 'uptime_seconds' in hurd_hardware.populate(facts)
    assert 'uptime_seconds' in hurd_hardware.populate()
    assert 'profiles' not in hurd_hardware.populate()
    assert 'swapfree_mb' in hurd_hardware.populate()
    assert 'mounts' in hurd_hardware.populate()



# Generated at 2022-06-22 23:16:54.274333
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys
    from ansible.module_utils.facts.collector import base
    from ansible.module_utils.facts import timeout

    # use a mock for Timout that does not try to sleep
    def mock_timeout(secs=0):
        res = timeout.Timeout()
        res.secs = secs
        res.start()
        return res

    timeout.Timeout = mock_timeout
    sys.modules['ansible.module_utils.facts.collector.base'] = base
    hw = HurdHardware()
    collected_facts = {}

    hw_facts = hw.populate(collected_facts)
    assert 'uptime' in hw_facts
    assert 'uptime_seconds' in hw_facts
    assert 'uptime_days' in hw_facts
    assert 'memory' in h

# Generated at 2022-06-22 23:16:57.361057
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware._platform == 'GNU'
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:17:03.709351
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.linux import LinuxHardware
    test_hurd_hardware = HurdHardware()
    LinuxHardware.populate = lambda self, collected_facts=None: {
        'memtotal_mb': 4194304,
        'swapfree_mb': 4194304,
        'uptime_seconds': 143,
        'virtualization_role': 'guest',
        'virtualization_type': 'xen'
    }
    LinuxHardware.get_mount_facts = lambda self: {'mounts': [{'device': '/dev/xvda1', 'mount': '/', 'fstype': 'ext4'}]}

# Generated at 2022-06-22 23:17:11.634024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    collected_facts = {'running_on_virtualized_system': 'Unknown'}
    hurd_hw.populate(collected_facts=collected_facts)
    assert collected_facts['ansible_facts']['uptime_seconds'] == 432
    assert collected_facts['ansible_facts']['mounts'] == [{'mount': '/', 'device': '/dev/disk0s1', 'fstype': 'hfs', 'mountoptions': None, 'options': 'rw,local'}]
    assert collected_facts['ansible_facts']['virtualization_role'] == 'guest'
    assert collected_facts['ansible_facts']['virtualization_type'] == 'virtualbox'

# Generated at 2022-06-22 23:17:16.834686
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()

    assert 'uptime_seconds' in facts
    assert 'uptime_hours' in facts
    assert 'uptime_days' in facts

    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    asser

# Generated at 2022-06-22 23:17:25.002334
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test case for Hurd with proc translator
    class MockModule:
        def __init__(self, params):
            self.params = params

    class MockFile:
        def __init__(self, contents):
            self.contents = contents

        def read(self):
            return self.contents

    class MockFact:
        def __init__(self, params):
            self.params = params

        def get(self, key, default=None):
            return self.params[key]

    params = {
        "module": MockModule({
            "timeout": 0
        }),
    }

    mock_facts = MockFact(params)

    hurd_hardware = HurdHardware('', mock_facts)

    # Tests with proc translator

# Generated at 2022-06-22 23:17:27.282790
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'
    assert hw.distribution == 'GNU'

# Generated at 2022-06-22 23:17:29.567102
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'
    assert hardware_collector.fact_class == HurdHardware

# Generated at 2022-06-22 23:17:36.667796
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    collected_facts = {'kernel': 'GNU',
                       'lsb': {'distributor_id': 'GNU/Linux'}}
    hardware_facts = hurd_hw.populate(collected_facts)
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0

# Generated at 2022-06-22 23:17:45.408633
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    cpuinfo = {
        "ansible_processor": "i386",
        "ansible_machine": "i386",
        "ansible_architecture": "i386"
    }
    hw = HurdHardware()
    hw.cpuinfo = lambda: cpuinfo
    hw.uptimecmd = lambda: '64'
    hw.meminfo = lambda: {}
    hw.mtd_info = lambda: {}
    hw.swapinfo = lambda: {}
    hw.df_cmd = lambda: {}
    hw.mount_info = lambda: {}
    hw.mount_info_filter = lambda: {}
    hw.get_mount_facts = lambda: {}
    hw.is_container = lambda: False
    hw.container_executable = lambda: None

# Generated at 2022-06-22 23:17:46.316292
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    pass

# Generated at 2022-06-22 23:17:55.803525
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """This test case is to check if method populate of class HurdHardware
    collects facts correctly for GNU Hurd platform.
    """
    hardware = HurdHardware()

# Generated at 2022-06-22 23:17:57.779432
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardwareCollector().collect()
    assert 'uptime_seconds' in hardware_facts
    assert 'mounts' in hardware_facts

# Generated at 2022-06-22 23:17:59.938902
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(None, None), HurdHardwareCollector)

# Generated at 2022-06-22 23:18:05.274271
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdh = HurdHardware()
    assert (hurdh.platform == 'GNU')
    assert (hurdh.hostname == hurdh.get_hostname())
    assert (hurdh.uptime == hurdh.get_uptime())
    assert (hurdh.uptime > 1)
    assert (hurdh.uptime < 1000000000)


# Generated at 2022-06-22 23:18:14.895161
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()

    # mock the files that this class relies on to exist for a successful run
    # at least for the information we are interesting in testing
    hurdhw.uptime_file = './test/files/uptime'
    hurdhw.files['meminfo'] = './test/files/meminfo'
    hurdhw.files['mountinfo'] = './test/files/mountinfo'

    hw_facts = hurdhw.populate()

    assert hw_facts['uptime'] == {'days': 1, 'hours': 2, 'seconds': 8643, 'minutes': 44}
    assert hw_facts['memtotal_mb'] == 3957
    assert hw_facts['swaptotal_mb'] == 2015


# Generated at 2022-06-22 23:18:19.733654
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd is not None
    assert hurd.uptime_facts() is not None
    assert hurd.memory_facts() is not None
    assert hurd.mount_facts() is not None


# Generated at 2022-06-22 23:18:21.382026
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw_obj = HurdHardware()
    assert hw_obj.platform == 'GNU'


# Generated at 2022-06-22 23:18:27.491330
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    platform = 'GNU'
    expected_output = 'ansible.module_utils.facts.hardware.hurd.HurdHardware'

    fact_collector = HurdHardwareCollector(platform, {})
    assert fact_collector.fact_class == expected_output, \
        'Expected %s got %s, HurdHardwareCollector constructor not working' \
        % (expected_output, fact_collector.fact_class)

# Generated at 2022-06-22 23:18:32.682881
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] >= 0
    assert hardware_facts['uptime_days'] >= 0

    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['swap']['total'] >= 0

    assert hardware_facts['mounts']

# Generated at 2022-06-22 23:18:36.274451
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware._facts['distribution'] == 'GNU'

# Generated at 2022-06-22 23:18:38.785002
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardware, LinuxHardware)
    assert isinstance(HurdHardwareCollector, HardwareCollector)
    assert HurdHardwareCollector._platform is 'GNU'

# Generated at 2022-06-22 23:18:41.268646
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdHardCollector = HurdHardwareCollector()
    assert hurdHardCollector.platform == 'GNU'
    assert isinstance(hurdHardCollector.fact_class(), HurdHardware)

# Generated at 2022-06-22 23:18:44.498401
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # HurdHardware object creation
    hurd_obj = HurdHardware()
    # print(hurd_obj)
    assert isinstance(hurd_obj, HurdHardware)


# Generated at 2022-06-22 23:18:47.135787
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwCollector = HurdHardwareCollector()
    assert hwCollector._platform == 'GNU'


# Generated at 2022-06-22 23:18:51.411165
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    facts = hurd.populate()
    assert facts
    assert facts['uptime_seconds'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:18:52.866202
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw is not None
    assert hurdhw.platform == 'GNU'

# Generated at 2022-06-22 23:18:54.412755
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:19:00.738302
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Test constructor of class HurdHardware
    """
    inittime = 0
    os_class = HurdHardware()
    assert os_class.uptime == inittime
    assert os_class.uptime_seconds == inittime
    assert os_class.uptime_string == inittime



# Generated at 2022-06-22 23:19:02.157885
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert hw.populate()

# Generated at 2022-06-22 23:19:04.413728
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert type(obj).__name__ == HurdHardwareCollector.__name__


# Generated at 2022-06-22 23:19:05.610248
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:19:16.740433
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Make sure that the facts returned by populate() method of
    HurdHardware class, contain all the facts defined as
    keys in _memory_facts dictionary.
    """

    # Define some arbitrary data
    uptime_seconds = 100
    uptime_string = '1 day, 1:00:00.00'
    total_memory = 1024
    free_memory = 512

    # Create a HurdHardware object
    hurd_hw = HurdHardware()

    # Define the data to be returned by get_uptime_facts method
    data_to_be_returned_by_get_uptime_facts_method = {
        'uptime_seconds': uptime_seconds,
        'uptime_string': uptime_string
    }

    # Define the data to be returned by get_memory_facts method
    data_

# Generated at 2022-06-22 23:19:26.605895
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts_obj = HurdHardware()
    uptime_facts = facts_obj.get_uptime_facts()
    memory_facts = facts_obj.get_memory_facts()
    mount_facts = facts_obj.get_mount_facts()

    actual_facts = facts_obj.populate()

    assert isinstance(actual_facts, dict)
    assert actual_facts['uptime_seconds'] == uptime_facts['uptime_seconds']
    assert actual_facts['uptime_seconds'] == uptime_facts['uptime_seconds']
    assert actual_facts['uptime_hours'] == uptime_facts['uptime_hours']
    assert actual_facts['uptime_days'] == uptime_facts['uptime_days']
    assert actual_facts['memtotal_mb'] == memory_facts['memtotal_mb']


# Generated at 2022-06-22 23:19:34.593608
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardware()
    hardware_facts = collector.populate()
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['uptime_hours']
    assert hardware_facts['uptime_days']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['memavailable_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['mounts']
    assert hardware_facts['num_cpus']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']

# Generated at 2022-06-22 23:19:36.524727
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert facts['uptime_seconds'] > 0

# Generated at 2022-06-22 23:19:38.729756
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert(isinstance(hurd_hardware.populate(), dict))

# Generated at 2022-06-22 23:19:39.404792
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    my_obj = HurdHardware()
    assert my_obj

# Generated at 2022-06-22 23:19:40.053875
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:19:42.000632
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # test for constructor
    hurdHardware = HurdHardware()
    assert isinstance(hurdHardware, HurdHardware)

# Generated at 2022-06-22 23:19:52.151490
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    exch = dict()
    exch['uptime_seconds'] = 5800
    exch['uptime_string'] = '1 hour, 30 minutes'
    exch['memory'] = {
        'swapfree_mb': 1023,
        'memfree_mb': 2047,
        'memtotal_mb': 4095,
        'swaptotal_mb': 2047,
    }

# Generated at 2022-06-22 23:19:54.595509
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert isinstance(hardware.distribution, dict)
    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:19:57.701098
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:20:01.383984
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert hasattr(HurdHardwareCollector, '_fact_class')
    assert HurdHardwareCollector._fact_class == HurdHardware

if __name__ == '__main__':
    test_HurdHardwareCollector()

# Generated at 2022-06-22 23:20:04.622190
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    result = hardware.populate()
    assert('uptime' in result)
    assert('memtotal' in result)
    assert('swaptotal' in result)
    assert('mounts' in result)

# Generated at 2022-06-22 23:20:10.526446
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Test that constructor of class HurdHardware defined
    # fact_class with proper class.
    hurd_hw_collector = HurdHardwareCollector()
    assert (hurd_hw_collector.fact_class == HurdHardware)

# Generated at 2022-06-22 23:20:13.828422
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Instantiate a HurdHardware object
    obj = HurdHardware({})
    # Call method populate
    data = obj.populate()

    print(data)

# Generated at 2022-06-22 23:20:19.130418
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardwareCollector()
    hardware_facts = collector.collect()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['mounts'] != {}
    assert hardware_facts['memtotal_mb'] > 0

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-22 23:20:21.556417
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:20:23.109198
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert(h.platform == 'GNU')

# Generated at 2022-06-22 23:20:24.830337
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU', 'expected GNU but got %s' % HurdHardwareCollector._platform

# Generated at 2022-06-22 23:20:26.469459
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj
    assert isinstance(obj, HardwareCollector)

# Generated at 2022-06-22 23:20:37.319688
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import \
        LinuxHardware, GNU_Hurd_FACTS, GNU_Hurd_MEMORY_FACTS
    # Create a hardware instance.
    hardware = HurdHardware()
    # Create a dictionary with gathered facts.
    collected_facts = {
        'distribution': 'GNU_Hurd',
        'distribution_version': '1.0',
        'os': 'GNU_Hurd',
        'os_family': 'GNU_Hurd',
        'processor_count': 4,
        'virtualization_role': 'hvm',
    }
    # Add time fake time.
    from ansible.module_utils.facts.timeout import Timeout
    from datetime import timedelta, datetime

# Generated at 2022-06-22 23:20:38.409034
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware().populate()

# Generated at 2022-06-22 23:20:40.101601
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test if method populate works correctly.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-22 23:20:41.593563
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector().get_collector(), HurdHardwareCollector._fact_class)

# Generated at 2022-06-22 23:20:44.726475
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware

# Generated at 2022-06-22 23:20:52.913201
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initialize Test Class
    test_class = HurdHardwareCollector()

    # Test populate method
    def test_populate(mocker):
        mocker.patch('ansible.module_utils.facts.hardware.linux.LinuxHardware.get_mount_facts', return_value={'mounts': []})
        mocker.patch('ansible.module_utils.facts.hardware.linux.LinuxHardware.get_memory_facts', return_value={'ansible_memfree_mb': 4098, 'ansible_swaptotal_mb': 0})
        mocker.patch('ansible.module_utils.facts.hardware.linux.LinuxHardware.get_uptime_facts', return_value={'ansible_uptime_seconds': 96548, 'ansible_uptime_days': 0})

        # Call populate method


# Generated at 2022-06-22 23:21:03.228090
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    uptime_facts = {'uptime_seconds': 67510}
    memory_facts = {'memtotal_mb': 3955,
                    'memfree_mb': 1343}

# Generated at 2022-06-22 23:21:03.760724
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-22 23:21:05.138233
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw


# Generated at 2022-06-22 23:21:07.013011
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'
    assert not hurd_hardware.populate()

# Generated at 2022-06-22 23:21:08.235476
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == HurdHardware._platform

# Generated at 2022-06-22 23:21:09.504266
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-22 23:21:13.539535
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    facts = hardware.populate()
    keys = (
        'mounts',
        'memfree_mb',
        'memfree_kb',
        'swapfree_mb',
        'swapfree_kb',
        'uptime_seconds',
        'uptime_hours',
        'uptime_days',
    )
    assert all(fact in facts for fact in keys)


# Generated at 2022-06-22 23:21:17.244745
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'


# Generated at 2022-06-22 23:21:19.378767
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'


# Generated at 2022-06-22 23:21:20.752342
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardwareCollector()
    assert hardware._platform == 'GNU'

# Generated at 2022-06-22 23:21:23.101058
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware() # constructor

    assert(hurdhw.platform == 'GNU')


# Generated at 2022-06-22 23:21:34.343856
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_module = HurdHardwareCollector()
    collected_facts = {}
    collected_facts['ansible_facts'] = {}
    collected_facts['ansible_facts']['uptime_seconds'] = 60
    collected_facts['ansible_facts']['ansible_memory_mb'] = {'real': {'total': 4}, 'swap': {'total': 8}}
    collected_facts['ansible_facts']['ansible_mounts'] = [{'device': '/dev/sdb1', 'fstype': 'vfat', 'mount': '/boot/efi', 'size_available': 60000, 'size_total': 80000}]
    fact_module.populate(collected_facts=collected_facts)
    assert fact_module.fact_class.platform == 'GNU'
    assert fact

# Generated at 2022-06-22 23:21:35.667204
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware(None).populate()

# Generated at 2022-06-22 23:21:37.572294
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert isinstance(hurd_facts, HurdHardware)

# Generated at 2022-06-22 23:21:49.391460
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # define global test variables
    HurdHardware._block_size = 4096
    HurdHardware._detected_platform = 'GNU'

# Generated at 2022-06-22 23:21:50.769435
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == "GNU"

# Generated at 2022-06-22 23:21:55.760252
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import hardware

    result = hardware.HurdHardware().populate(None)

    # Check that LinuxHardware.populate is called
    assert 'uptime' in result
    assert 'swapfree_mb' in result
    assert 'memfree_mb' in result

    # Check mount facts
    assert 'mounts' in result


# Generated at 2022-06-22 23:22:00.345663
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    # Can't test shell execution here because the get_memory_facts method
    # is overridden, but we can at least make sure the method exists
    assert hasattr(obj, 'get_memory_facts') and callable(getattr(obj, 'get_memory_facts'))

# Generated at 2022-06-22 23:22:03.345363
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, LinuxHardware) is True
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:22:07.628934
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_days'] == 0
    assert hardware_facts['uptime_seconds'] == 0
    assert hardware_facts['uptime_hours'] == 0
    assert hardware_facts['uptime_minutes'] == 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memavailable_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:22:17.658894
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    import time

    class Uptime(object):
        def get_uptime(self):
            return 42.5

    class Memory(object):
        def get_memory_facts(self):
            return {'memory_mb': {'free': 42}}

    class Mount(object):
        def get_mount_facts(self):
            return {'mounts': [{'mount': '/', 'size_total': 42, 'size_available': 42}]}

    hurd_hardware = HurdHardware(Uptime(), Memory(), Mount())

    collected_facts = {}

    res = hurd_hardware.populate(collected_facts)

    assert res['uptime'] == 42.5
    assert res['memory_mb']['free'] == 42
    assert res['mounts'][0]['size_total'] == 42
   

# Generated at 2022-06-22 23:22:19.557204
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.facts

# Generated at 2022-06-22 23:22:20.560168
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    a = HurdHardwareCollector()

# Generated at 2022-06-22 23:22:23.254251
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert HurdHardware.platform == 'GNU'
    assert isinstance(hurdhw,HurdHardware)


# Generated at 2022-06-22 23:22:31.555810
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdHardware = HurdHardware()
    result = hurdHardware.populate()
    assert type(result) == dict
    assert type(result['uptime_seconds']) == int
    assert type(result['uptime_hours']) == int
    assert type(result['uptime_days']) == int
    assert type(result['memtotal_mb']) == int
    assert type(result['swaptotal_mb']) == int
    assert type(result['swapfree_mb']) == int
    assert type(result['fstype_mountpoints']) == dict

# Generated at 2022-06-22 23:22:36.124226
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    # follow Ansible lookup module dictionary structure
    assert hardware_facts['ansible_facts'] == hardware_facts
    assert hardware_facts['ansible_local'] == hardware_facts
    assert hardware_facts['ansible_system'] == hardware_facts

    # test for content of populating method
    assert 'memtotal_mb' in hardware_facts

# Generated at 2022-06-22 23:22:38.465479
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Implement tests for method populate of class HurdHardware
    m = 'Missing test: method populate of class HurdHardware'
    assert False, m

# Generated at 2022-06-22 23:22:44.953932
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    '''Unit test for method populate of class HurdHardware'''
    import sys
    import os
    sys.path.insert(0, os.getcwd())
    from facts.hardware import hurd_hardware
    hurd_facts = hurd_hardware.HurdHardware()
    facts = hurd_facts.populate()
    assert 'memfree_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'fstype' in facts
    assert 'mount' in facts

# Generated at 2022-06-22 23:22:47.633137
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj
    assert isinstance(obj._fact_class, type)

# Generated at 2022-06-22 23:22:49.305183
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh


# Generated at 2022-06-22 23:22:50.345766
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-22 23:22:51.542025
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw

# Generated at 2022-06-22 23:22:56.703739
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_obj = HurdHardware()
    assert isinstance(hurd_hardware_obj, HurdHardware)
    assert hurd_hardware_obj.platform == 'GNU'

# test_HurdHardware will be called from platform GNU

# Generated at 2022-06-22 23:22:58.716144
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert isinstance(hurd_facts, HurdHardware)

# Generated at 2022-06-22 23:23:02.413291
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Instantiate subclass
    hw = HurdHardware()

    # Call method
    result = hw.populate()

    # Test fraction of result.
    assert result['mounts']


# Test class HurdHardwareCollector

# Generated at 2022-06-22 23:23:04.571755
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Instantiate an HurdHardware object
    hurd_instance = HurdHardware()
    # Invoke populate method
    hurd_instance.populate()

# Generated at 2022-06-22 23:23:06.433358
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'
    assert hw.os == 'GNU'


# Generated at 2022-06-22 23:23:14.710563
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    # test_memory_facts
    assert hardware.mem_facts['swapfree_mb'] == 0
    assert hardware.mem_facts['numanodes'] == 1
    assert hardware.mem_facts['swaptotal_mb'] == 0
    assert hardware.mem_facts['memfree_mb'] == 0
    assert hardware.mem_facts['memtotal_mb'] == 0

    # test_uptime_facts
    assert hardware.uptime_facts['uptime_seconds'] == 0

    # test_mount_facts
    assert hardware.mount_facts['mounts'] is None

# Generated at 2022-06-22 23:23:16.095459
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test = HurdHardwareCollector()
    assert test.platform == "GNU"


# Generated at 2022-06-22 23:23:17.521708
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:23:28.879809
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()

    collected_facts = {
        # Uptime facts
        'uptime_seconds': 30,
        'uptime_days': 0,

        # Memory facts
        'MemAvailable': None,
        'MemFree': None,
        'MemTotal': None,
        'MemUsed': None,
        'SwapFree': None,
        'SwapTotal': None,

        # Mount facts
        'mounts': []
    }


# Generated at 2022-06-22 23:23:31.979865
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert HurdHardware.platform == 'GNU'
    assert not hurd_hardware.init_timeout
    assert hurd_hardware.resource_monitor is None

# Generated at 2022-06-22 23:23:38.543879
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime']['seconds'] > 0
    assert facts['uptime']['days'] > 0
    assert facts['uptime']['time']
    assert facts['virtualization_type'] == 'native'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-22 23:23:45.110880
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hwc = HurdHardwareCollector()
    hw = hwc.collect()

    assert hw['uptime'] == hwc._fact_class.get_uptime_facts()['uptime']
    assert hw['kernelversion'] == hwc._fact_class.get_kernelversion_facts()['kernelversion']
    assert hw['memtotal_mb'] >= hwc._fact_class.get_memory_facts()['memtotal_mb']

# Generated at 2022-06-22 23:23:48.859670
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_h = HurdHardware()
    # Check for the platform
    assert hurd_h.platform == 'GNU'

# Test for the primary functionality of HurdHardware
# get_memory_facts is called and the same is verified.

# Generated at 2022-06-22 23:23:52.081672
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Test the constructor of class HurdHardwareCollector"""
    result = HurdHardwareCollector()
    assert isinstance(result, HardwareCollector)
    assert result._platform == 'GNU'

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 23:23:54.526230
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)
    assert hurd_hw._platform == 'GNU'

# Unit test: get_uptime_facts

# Generated at 2022-06-22 23:23:57.234847
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h
    assert HurdHardware.platform == 'GNU'

# Generated at 2022-06-22 23:24:00.264023
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardwareCollector(None, None)
    assert h._fact_class.platform == 'GNU'
    assert HurdHardware.platform == 'GNU'

# Generated at 2022-06-22 23:24:09.307823
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Checks if the populate method of class HurdHardware is able to fetch the
    correct memory and mount facts in the form of a dictionary.
    """

    import filecmp
    import json
    import os
    import pytest
    import stat
    import tempfile
    import time

    import ansible.module_utils.facts.hardware.linux as linux_hw

    # Create a temporary directory and populate it with a procfs image
    # containing some memory and mount facts.
    procfs_dir = tempfile.mkdtemp()

    procfs_dir_stat = os.stat(procfs_dir)
    os.chmod(procfs_dir, procfs_dir_stat.st_mode | stat.S_IWUSR)

    os.mkdir(os.path.join(procfs_dir, 'proc'))


# Generated at 2022-06-22 23:24:10.563369
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc
    assert hwc._fact_class == HurdHardware
    assert hwc._platform == 'GNU'

# Generated at 2022-06-22 23:24:14.634496
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Create a new object of class HurdHardwareCollector
    hardware_collector = HurdHardwareCollector()
    hardware_collector.collect()

    assert hardware_collector.hardware_instance is not None


# Generated at 2022-06-22 23:24:16.258517
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    result = HurdHardware()
    assert isinstance(result._collector_platform, str)

# Generated at 2022-06-22 23:24:18.160143
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_instance = HurdHardware()
# Test for populate method of class HurdHardware

# Generated at 2022-06-22 23:24:26.103572
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        from ansible.module_utils.facts.hardware.linux import LinuxHardware
    except ImportError:
        pass
    else:
        monkeypatch.setattr(LinuxHardware, 'get_mount_facts', lambda self: {})
        monkeypatch.setattr(HurdHardware, '_get_uptime_facts', lambda self: {})
        monkeypatch.setattr(HurdHardware, '_get_memory_facts', lambda self: {})
        hardware = HurdHardware()
        assert hardware.populate() == {}

# Generated at 2022-06-22 23:24:28.133709
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()._platform == 'GNU'
    assert HurdHardwareCollector()._fact_class == HurdHardware


# Generated at 2022-06-22 23:24:30.128997
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector_class = HurdHardwareCollector()
    hardware_collector_class.collect()

# Generated at 2022-06-22 23:24:32.794547
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._fact_class == HurdHardware
    assert hw._platform == 'GNU'

# Generated at 2022-06-22 23:24:34.829302
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()

    assert hhc.platform == 'GNU'


# Generated at 2022-06-22 23:24:37.033754
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdHardware