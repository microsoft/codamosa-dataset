

# Generated at 2022-06-22 23:14:36.510635
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hc = HurdHardwareCollector([])
    ret = hc.populate()
    assert isinstance(ret, dict)
    assert ret.get('uptime_seconds', 0) > 0
    assert ret.get('memory_mb', 0.0) > 0.0

# Generated at 2022-06-22 23:14:39.327859
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    hurd = HurdHardware()
    hurd.populate(facts)


# Generated at 2022-06-22 23:14:41.660571
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_obj = HurdHardware()
    assert isinstance(hurd_hardware_obj, dict)

# Generated at 2022-06-22 23:14:43.998043
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:14:46.702183
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw = HurdHardwareCollector()

    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'


# Generated at 2022-06-22 23:14:48.046214
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    module = HurdHardware()
    assert module.platform == 'GNU'

# Generated at 2022-06-22 23:14:50.072991
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test_class = HurdHardware()
    assert test_class.platform == 'linux'


# Generated at 2022-06-22 23:14:51.457204
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()

    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:14:53.365049
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(), HardwareCollector)


# Generated at 2022-06-22 23:14:56.161851
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Test - Instantiate an object of HurdHardware
    """
    hurd_hardware = HurdHardware()

    assert hurd_hardware is not None


# Generated at 2022-06-22 23:14:58.509374
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    shr = HurdHardwareCollector()
    assert shr.platform == 'GNU'
    assert shr._fact_class == HurdHardware


# Generated at 2022-06-22 23:15:00.083429
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:15:10.122806
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    import numbers
    import statvfs

    fs = HurdHardware(module=None)

    # Test for uptime facts
    uptime_facts = fs.get_uptime_facts()
    assert isinstance(uptime_facts['uptime_seconds'], numbers.Number)
    assert isinstance(uptime_facts['uptime_days'], numbers.Number)

    # Test for memory facts
    memory_facts = fs.get_memory_facts()
    assert isinstance(memory_facts['memtotal_mb'], numbers.Number)
    assert isinstance(memory_facts['memfree_mb'], numbers.Number)

    # Test for mount facts
    # (raise Time

# Generated at 2022-06-22 23:15:12.810924
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert isinstance(hardware, HardwareCollector)
    assert isinstance(hardware, HurdHardware)


# Generated at 2022-06-22 23:15:14.484819
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    c = HurdHardwareCollector()
    assert isinstance(c._fact_class, HurdHardware)

# Generated at 2022-06-22 23:15:17.559422
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class.__name__ == 'HurdHardware'



# Generated at 2022-06-22 23:15:19.558064
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Create an instance of HurdHardware.
    """
    hardware = HurdHardware()


# Generated at 2022-06-22 23:15:22.130920
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert isinstance(h, HardwareCollector)
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:15:23.507172
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware(None)
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:15:27.699856
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    collected_facts = {'ansible_system': 'GNU'}
    hardware_facts.populate(collected_facts)
    assert hardware_facts.facts['memory']['memtotal_mb'] > 0


# Generated at 2022-06-22 23:15:30.141830
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:15:33.049896
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert 'uptime_seconds' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts

# Generated at 2022-06-22 23:15:34.199685
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware().populate()

# Generated at 2022-06-22 23:15:36.319371
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(), HurdHardwareCollector)

# Generated at 2022-06-22 23:15:39.500006
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert hasattr(HurdHardwareCollector, '_platform')
    assert isinstance(HurdHardwareCollector._platform, str)
    assert HurdHardwareCollector._platform == 'GNU'


# Generated at 2022-06-22 23:15:43.197189
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()

    assert isinstance(facts, dict)
    assert 'uptime' in facts
    assert 'uptime_seconds' in facts
    assert 'memory' in facts
    assert 'swap' in facts
    assert 'mounts' in facts

# Generated at 2022-06-22 23:15:47.847602
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardware()
    uptime_obj = hardware_obj.get_uptime_facts()
    memory_obj = hardware_obj.get_memory_facts()
    mount_obj = hardware_obj.get_mount_facts()

    hardware_obj.populate()

# Generated at 2022-06-22 23:15:52.088852
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    expected_attributes = {
        'platform': 'GNU',
        'uuid': None,
        }

    hh = HurdHardware()

    for attribute, value in expected_attributes.items():
        assert getattr(hh, attribute) == value

# Generated at 2022-06-22 23:15:54.961185
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    facts = hardware.populate()

    assert facts.get('kernel') == 'GNU'
    assert 'mounts' in facts

# Generated at 2022-06-22 23:16:01.904800
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test for method populate of class HurdHardware."""
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware_collector._platform = 'GNU'
    hurd_hardware_data = hurd_hardware_collector.collect()
    assert type(hurd_hardware_data) is dict
    assert 'uptime_seconds' in hurd_hardware_data
    assert 'uptime_hours' in hurd_hardware_data

# Generated at 2022-06-22 23:16:09.299561
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    This function unit tests method populate of class HurdHardware.
    """

    test_class = HurdHardware()

    # Test exception TimeoutError raised by method get_mount_facts
    def raise_timeout_error():
        raise TimeoutError
    test_class.get_mount_facts = raise_timeout_error
    if test_class.populate()['mounts']:
        raise AssertionError("Method get_mount_facts did not raise TimeoutError")

# Generated at 2022-06-22 23:16:19.535111
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test that GNU Hurd method populate correctly constructs facts dictionary.
    """

    def mock_open_context_manager(open_path, open_mode):
        class open_return:
            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

            def read(self):
                return "sample text"

        return open_return()

    class SubHurdHardware(HurdHardware):
        def __init__(self):
            pass

        def get_uptime_facts(self):
            return {'uptime_seconds': 'argle'}

        def get_memory_facts(self):
            return {'memory': 'bargle'}

        def get_mount_facts(self):
            raise TimeoutError('Oh noes!')


# Generated at 2022-06-22 23:16:23.145855
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert isinstance(HurdHardwareCollector._fact_class, type(HurdHardware)) is True


# Generated at 2022-06-22 23:16:25.325701
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # test class is instantiated
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:16:27.544837
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:16:29.515855
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    x = HurdHardwareCollector()
    assert isinstance(x, HardwareCollector)


# Generated at 2022-06-22 23:16:30.682563
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector


# Generated at 2022-06-22 23:16:36.552908
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardware()
    collected_facts = hardware_obj.populate()
    expected_keys = [
        'mounts',
        'uptime',
        'uptime_days',
        'uptime_hours',
        'uptime_seconds',
        'memtotal_mb'
    ]
    for key in expected_keys:
        assert key in collected_facts


# Generated at 2022-06-22 23:16:43.711274
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector
    assert hw_collector._platform == 'GNU', \
        "platform is not GNU, instead %s" % (hw_collector._platform)
    assert hw_collector._fact_class == HurdHardware, \
        "fact_class is not HurdHardware, instead %s" \
        % (hw_collector._fact_class)


# Generated at 2022-06-22 23:16:47.057979
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test if method populate of class HurdHardware correctly works
    """
    hurdhw = HurdHardware() # create object of class HurdHardware
    assert isinstance(hurdhw, HurdHardware) # assert if hurdhw is of type HurdHardware
    assert isinstance(hurdhw.populate(), dict) # assert if return type is dict

# Generated at 2022-06-22 23:16:50.614683
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts.get('uptime', "") != ""
    assert hardware_facts.get('uptime_seconds', "") != ""
    assert hardware_facts.get('memtotal_mb', "") != ""
    assert hardware_facts.get('swaptotal_mb', "") != ""

# Generated at 2022-06-22 23:16:51.939831
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass


# Generated at 2022-06-22 23:16:55.296800
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Try to access HurdHardware class if running on GNU Hurd
    if HardwareCollector._platform == 'GNU':
        # Set up a HurdHardware instance
        hardware_obj = HurdHardware()
        # Call method populate
        hardware_obj.populate()

# Generated at 2022-06-22 23:16:58.314226
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_facts = HurdHardware()

    # Check if the platform is GNU
    assert hurd_hardware_facts.platform == 'GNU'


# Generated at 2022-06-22 23:17:05.360363
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware('/dev/sda1', '/home', '/sbin/init')
    assert hurd_hardware.root is '/dev/sda1'
    assert hurd_hardware.home is '/home'
    assert hurd_hardware.init is '/sbin/init'
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:17:07.419775
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    # do not crash when calling populate()
    hw.populate()

# Generated at 2022-06-22 23:17:10.033056
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    # Test with no memory
    assert h.populate({'memory_mb': {}}) == {}
    # Test with memory
    assert h.populate({'memory_mb': {'hwcapacity': None}}) == {}

# Generated at 2022-06-22 23:17:12.396330
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'

# Generated at 2022-06-22 23:17:19.175241
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._platform == 'GNU'
    assert hc._fact_class._platform == 'GNU'
    assert hc._fact_class.platform == 'GNU'
    assert hc._fact_class.get_file_content.__name__ == LinuxHardware.get_file_content.__name__
    assert hc._fact_class.get_file_lines.__name__ == LinuxHardware.get_file_lines.__name__

# Generated at 2022-06-22 23:17:22.621715
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    my_test = HurdHardware()
    assert isinstance(my_test, HurdHardware)


# Generated at 2022-06-22 23:17:24.496417
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware.get_fact_class() == HurdHardware

# Generated at 2022-06-22 23:17:27.231995
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_collector = HurdHardwareCollector()
    assert hurd_collector._platform == 'GNU'
    assert isinstance(hurd_collector._fact_class(), HurdHardware)

# Generated at 2022-06-22 23:17:31.561703
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware()
    res = fact_class.populate()
    assert 'uptime' in res
    assert 'proc_uptime' in res
    assert 'timezone' in res
    assert 'system' in res
    assert 'hostname' in res
    assert 'domain' in res
    assert 'fqdn' in res
    assert 'memory' in res
    assert 'swap' in res

# Generated at 2022-06-22 23:17:34.166707
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    lh = HurdHardware()


# Generated at 2022-06-22 23:17:43.849583
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    obj = HurdHardware()
    facts = obj.populate()

    assert isinstance(facts, dict)
    assert ('uptime_seconds' in facts) is True
    assert ('uptime_days' in facts) is True
    assert ('memfree_mb' in facts) is True
    assert ('memtotal_mb' in facts) is True
    assert ('swaptotal_mb' in facts) is True
    assert ('swapfree_mb' in facts) is True
    assert ('mounts' in facts) is True

    assert isinstance(obj, HurdHardware)
    assert isinstance(obj, LinuxHardware)

# Generated at 2022-06-22 23:17:46.314307
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwcol = HurdHardwareCollector()
    assert hwcol._fact_class == HurdHardware
    assert hwcol._platform == 'GNU'

# Generated at 2022-06-22 23:17:48.241359
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_h = HurdHardware()
    assert hurd_h.platform == 'GNU'


# Generated at 2022-06-22 23:17:49.959128
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hd = HurdHardware()
    assert hd.platform == 'GNU'


# Generated at 2022-06-22 23:17:58.976785
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware(dict())
    hardware_facts = hardware.populate()

    assert hardware_facts is not None
    assert 'uptime' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'virtualization' in hardware_facts
    assert 'kernel_version' in hardware_facts
    assert 'kernel_release' in hardware_facts
    assert 'kernel_name' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'fqdn' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts

# Generated at 2022-06-22 23:18:02.512385
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'
    assert h.get_memory_facts()
    assert h.get_uptime_facts()
    assert h.get_mount_facts()

# Generated at 2022-06-22 23:18:03.714263
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Unit test class HurdHardwareCollector

# Generated at 2022-06-22 23:18:13.480461
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Stub class to check if the right calls have been made.
    class Stub_HurdHardware(HurdHardware):
        def __init__(self, collected_facts=None):
            self.collected_facts = collected_facts
            self.was_get_uptime_facts_called = False
            self.was_get_memory_facts_called = False
            self.was_get_mount_facts_called = False

        def get_uptime_facts(self):
            self.was_get_uptime_facts_called = True
            return {'uptime_seconds': 42}

        def get_memory_facts(self):
            self.was_get_memory_facts_called = True
            return {'memtotal_mb': 256}

        def get_mount_facts(self):
            self.was_get_mount_

# Generated at 2022-06-22 23:18:15.596449
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.collect() == h.get_all()

# Generated at 2022-06-22 23:18:18.273596
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd = HurdHardwareCollector()
    assert hurd._fact_class == HurdHardware

# Generated at 2022-06-22 23:18:20.148267
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware(HurdHardwareCollector())
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:18:21.842069
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'


# Generated at 2022-06-22 23:18:28.259390
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Unit test for module tests/module_utils/facts/hardware/hurd.py"""

    # create test class object
    linux_hardware = HurdHardware()

    # check for expected instances
    assert isinstance(linux_hardware, HurdHardware)
    assert isinstance(linux_hardware, LinuxHardware)
    assert isinstance(linux_hardware, HardwareCollector)

    # check for expected attributes
    assert linux_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:18:30.125817
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector.platfo

# Generated at 2022-06-22 23:18:34.719374
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw_collector = HurdHardware()
    result = hw_collector.populate()
    keys = ['mounts', 'memory', 'uptime']
    assert result.keys() >= set(keys),\
           "result keys %s should be a superset of %s" % (result.keys(), keys)


if __name__ == '__main__':
    hw_collector = HurdHardware()
    print(hw_collector.populate())

# Generated at 2022-06-22 23:18:45.477677
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys
    import pytest
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.timeout import Timeout
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    # Set timeout fact to prevent end of test with timeout
    HardwareCollector.__timeout = Timeout(1)

    hurd_hw = HurdHardware()
    sys.modules['resource'] = pytest.Mock()
    sys.modules['fcntl'] = pytest.Mock()

    #######################
    # Test get_uptime_facts
    sys.modules['os'] = pytest.Mock()

# Generated at 2022-06-22 23:18:47.721671
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    result = HurdHardware()
    assert isinstance(result, HurdHardware)


# Generated at 2022-06-22 23:18:48.728912
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw is not None

# Generated at 2022-06-22 23:18:58.802310
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda: True
            self.fail_json = lambda: True

    class MockHurdHardware(HurdHardware):
        def __init__(self):
            self.module = MockModule()

        def get_uptime_facts(self):
            uptime_facts = {'uptime_seconds': 1234}
            return uptime_facts

        def get_memory_facts(self):
            memory_facts = {'memtotal_mb': 1234,
                            'memfree_mb': 1234,
                            'swaptotal_mb': 1234,
                            'swapfree_mb': 1234}
            return memory_facts

    mockhurdhardware = MockHurdHardware()

# Generated at 2022-06-22 23:19:01.516039
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    collected_facts = collector.collect()
    assert isinstance(collected_facts, dict), "a dictionary is returned"

# Generated at 2022-06-22 23:19:03.506431
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    actual_HurdHardware = HurdHardware()
    assert actual_HurdHardware.platform == 'GNU'

# Generated at 2022-06-22 23:19:04.887314
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:19:07.000016
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()

    collected_facts = {}
    result = hardware_facts.populate(collected_facts)
    assert isinstance(result, dict)

# Generated at 2022-06-22 23:19:08.855776
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class is HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:19:11.939997
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector('GNU')
    assert hw_collector._fact_class == HurdHardware
    assert hw_collector._platform == 'GNU'

# Generated at 2022-06-22 23:19:15.439496
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:19:19.113593
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test the method populate of the class HurdHardware
    """

    # Create a new instance of HurdHardware
    hardware_obj = HurdHardware()

    # Test using an empty dict as argument
    hardware_obj.populate({})

# Generated at 2022-06-22 23:19:26.697770
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {}
    hardware = HurdHardware()
    hardware_facts = hardware.populate(collected_facts=collected_facts)
    assert 'uptime' in hardware_facts
    assert isinstance(hardware_facts['uptime'], int)
    assert 'memtotal' in hardware_facts
    assert isinstance(hardware_facts['memtotal'], str)
    assert 'memfree' in hardware_facts
    assert isinstance(hardware_facts['memfree'], str)
    assert 'swaptotal' in hardware_facts
    assert 'swapfree' in hardware_facts
    assert 'mounts' in hardware_facts

# Generated at 2022-06-22 23:19:28.999941
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-22 23:19:36.330000
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    uptime_facts = {
        'uptime': '14 days, 20 hours, 21 minutes, ',
        'uptime_seconds': 1271720
    }

    memory_facts = {
        'memfree_mb': 3723,
        'memtotal_mb': 4025,
        'swapfree_mb': 3358,
        'swaptotal_mb': 4095
    }


# Generated at 2022-06-22 23:19:39.921029
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    _fact_class = HurdHardware
    _platform = 'GNU'
    assert HurdHardwareCollector._fact_class == _fact_class
    assert HurdHardwareCollector._platform == _platform

# Generated at 2022-06-22 23:19:40.824261
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:19:42.731583
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    class_inst = HurdHardware()
    assert class_inst.populate() == {}


# Generated at 2022-06-22 23:19:44.228843
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_obj = HurdHardware()
    assert hurd_hardware_obj.platform == 'GNU'
    assert hurd_hardware_obj.memory_unit_fact == 'kB'


# Generated at 2022-06-22 23:19:46.563345
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:49.460129
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._fact_class._platform == HurdHardware._platform
    assert issubclass(hw._fact_class, LinuxHardware)

# Generated at 2022-06-22 23:19:51.174984
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:19:58.558334
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardwareCollector().collect()
    assert isinstance(hw, dict)
    assert 'uptime' in hw
    assert 'uptime_seconds' in hw
    assert 'uptime_hours' in hw
    assert 'uptime_days' in hw
    assert 'memfree_mb' in hw
    assert 'memtotal_mb' in hw
    assert 'swapfree_mb' in hw
    assert 'swaptotal_mb' in hw

# Generated at 2022-06-22 23:20:01.168509
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert issubclass(hurd_hardware_collector._fact_class, HurdHardware)

# Generated at 2022-06-22 23:20:04.928048
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    #pylint: disable=protected-access
    collector = HurdHardwareCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware
    assert collector._cache_location == '/var/cache'
    assert collector._cache_files == ['ansible_facts.yml']

# Generated at 2022-06-22 23:20:06.788305
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware('hurd')

# Generated at 2022-06-22 23:20:08.917577
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj is not None

# Generated at 2022-06-22 23:20:12.284908
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware
    assert h._platform == 'GNU'

# Generated at 2022-06-22 23:20:23.624014
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        file_module = __import__('__builtin__', globals(), locals(), ['open'], 0)
    except ImportError:
        file_module = __import__('builtins', globals(), locals(), ['open'], 0)

# Generated at 2022-06-22 23:20:25.309071
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'


# Generated at 2022-06-22 23:20:34.711785
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardware as TestHardware

    class TestHurdHardware(TestHardware):
        def get_mount_facts(self):
            raise TimeoutError('Test for TimeoutError')

    facts = {}
    test_hardware = TestHurdHardware(facts)
    uptime_facts = test_hardware.get_uptime_facts()
    memory_facts = test_hardware.get_memory_facts()

    test_hardware.populate(facts)
    assert uptime_facts == facts
    assert memory_facts == facts



# Generated at 2022-06-22 23:20:37.693906
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test for constructor of class HurdHardwareCollector
    """
    hurd_collector = HurdHardwareCollector()
    assert hurd_collector._fact_class is HurdHardware
    assert hurd_collector._platform == 'GNU'

# Generated at 2022-06-22 23:20:40.281135
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hhw = HurdHardware()
    assert hhw.collect() == {'uptime': 317, 'uptime_days': 3, 'uptime_hours': 9, 'uptime_seconds': 319097, 'uptime_minutes': 1832}

# Generated at 2022-06-22 23:20:44.727915
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.uptime_facts == {}
    assert hurd_hardware.memory_facts == {}
    assert hurd_hardware.mount_facts == {}
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:20:46.476766
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['mounts'] is not None


# Generated at 2022-06-22 23:20:49.126374
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_collector = HurdHardwareCollector()
    assert hurd_collector._fact_class == HurdHardware
    assert hurd_collector._platform == 'GNU'

# Generated at 2022-06-22 23:20:49.664861
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h is not None

# Generated at 2022-06-22 23:20:51.608167
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:20:53.905689
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert 'uptime_seconds' in facts

# Generated at 2022-06-22 23:20:56.563137
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)

# Generated at 2022-06-22 23:21:00.738644
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector, HardwareCollector)
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:21:10.352815
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    def get_facts(fact_class, platform, collected_facts=None):
        return fact_class(platform=platform).get_facts(collected_facts=collected_facts)['ansible_facts']

    assert isinstance(HurdHardwareCollector(platform='GNU')._fact_class, HurdHardware)
    assert HurdHardwareCollector(platform='GNU')._platform == 'GNU'


# Generated at 2022-06-22 23:21:12.269822
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdHardware = HurdHardware()
    hurdHardware.populate()


# Generated at 2022-06-22 23:21:14.089033
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert(isinstance(HurdHardwareCollector(), HardwareCollector))


# Generated at 2022-06-22 23:21:18.464796
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    class Mock_HurdHardwareCollector(HurdHardwareCollector):
        def collect(self, module=None, collected_facts=None):
            return None

    Mock_HurdHardwareCollector()

# Generated at 2022-06-22 23:21:24.738930
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert (facts['uptime_seconds'] > 0)
    assert (facts['uptime_hours'] > 0)
    assert (facts['uptime_days'] > 0)
    assert (facts['memtotal_mb'] > 0)
    assert (facts['memfree_mb'] > 0)
    assert (facts['memavail_mb'] > 0)
    assert (facts['swaptotal_mb'] > 0)
    assert (facts['swapfree_mb'] > 0)
    assert (facts['mounts'] != [])


# Generated at 2022-06-22 23:21:31.786028
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardwareCollector()
    hardware = collector.collect()
    assert hardware['uptime_seconds'] >= 0
    assert hardware['uptime_hours'] >= 0
    assert hardware['memory']['total'] >= 0
    assert 'system' in hardware['mounts']
    assert 'procfs' in hardware['mounts']

if __name__ == '__main__':
    test_HurdHardware_populate()
    print('Tests completed successfully')

# Generated at 2022-06-22 23:21:33.509340
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardwareCollector = HurdHardwareCollector()
    assert hardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:21:40.283280
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import pytest
    hw = HurdHardware()
    facts = hw.populate()
    assert facts is not None
    # assert mount facts
    mount_facts = hw.get_mount_facts()
    assert 'mounts' in mount_facts
    assert isinstance(mount_facts['mounts'], list)
    assert len(mount_facts['mounts']) > 0
    assert mount_facts['mounts'][0]['device'] == '/'
    # assert memory fact
    memory_facts = hw.get_memory_facts()
    assert 'memfree_mb' in memory_facts
    assert 'memtotal_mb' in memory_facts
    assert isinstance(memory_facts['memfree_mb'], (int, float))

# Generated at 2022-06-22 23:21:43.226113
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_system': 'GNU'}
    lh = HurdHardware()
    lh.populate(collected_facts)

# Generated at 2022-06-22 23:21:45.428514
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc.fact_class._platform == 'GNU'

# Generated at 2022-06-22 23:21:47.189334
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:21:50.375247
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hd = HurdHardware()
    # ensure uptime and memory facts are not empty
    assert hd.populate()
    assert hd.uptime_facts()

# Generated at 2022-06-22 23:21:52.459773
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    result = hurd_hw.populate()
    assert 'uptime_seconds' in result

# Generated at 2022-06-22 23:21:55.169442
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hd_collector = HurdHardware()

    assert hd_collector.platform == 'GNU'
    assert isinstance(hd_collector, LinuxHardware)


# Generated at 2022-06-22 23:21:56.986482
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-22 23:21:58.034572
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:22:00.585873
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    _hwc = HurdHardwareCollector()
    assert isinstance(_hwc._fact_class(), HurdHardware)


# Generated at 2022-06-22 23:22:11.186397
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    c = HurdHardware()
    c.populate()

    # Test if init work correctly
    assert c.uptime['hours'] == 0
    assert c.uptime['seconds'] == 0
    assert c.uptime['days'] == 0
    assert c.uptime['minutes'] == 0
    assert c.uptime['days'] == 0

    # Test if memory was initialized correctly
    assert c.memfacts['MemTotal'] == 0
    assert c.memfacts['MemFree'] == 0
    assert c.memfacts['SwapTotal'] == 0
    assert c.memfacts['SwapFree'] == 0
    assert c.memfacts['Cached'] == 0
    assert c.memfacts['Active'] == 0
    assert c.memfacts['Dirty'] == 0

    # Test if swap was initialized correctly
    assert c.sw

# Generated at 2022-06-22 23:22:23.009069
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import tempfile
    import pytest

    facts = {}
    filetemp = tempfile.NamedTemporaryFile()
    filetemp.write(b"""MemTotal:        200 kB
MemFree:         100 kB
MemAvailable:    50 kB
SwapTotal:       1000 kB
SwapFree:        500 kB
""")
    filetemp.seek(0)

    filetemp2 = tempfile.NamedTemporaryFile()

# Generated at 2022-06-22 23:22:34.326195
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # instantiate the object and call populate
    hh = HurdHardware()
    hardware_facts = hh.populate()

    # check correctness of the results
    assert 'uptime' in hardware_facts
    assert 'ansible_uptime_seconds' in hardware_facts
    assert 'ansible_uptime_seconds' in hardware_facts
    assert 'system_mounts' in hardware_facts
    assert 'procfs' in hardware_facts['system_mounts']

    # test for a memory fact
    assert 'ansible_memfree_mb' in hardware_facts
    assert type(hardware_facts['ansible_memfree_mb']) is int
    assert 'ansible_swaptotal_mb' in hardware_facts
    assert type(hardware_facts['ansible_swaptotal_mb']) is int

# Generated at 2022-06-22 23:22:35.165732
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector('HurdHardwareCollector')

# Generated at 2022-06-22 23:22:37.439385
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector._fact_class(), HurdHardware)
    assert collector._platform == "GNU"

# Generated at 2022-06-22 23:22:40.431562
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    # In case of Hurd, we expect that the class 'LinuxHardware'
    # is being called.
    assert(isinstance(hurd_hardware, LinuxHardware))

# Generated at 2022-06-22 23:22:42.141744
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:22:46.732811
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardwareCollector(None)
    hardware = HurdHardware(None, collector)

    # __init__ calls get_mount_facts()
    collector.get_mount_facts = lambda: {'mounts': None}
    facts = hardware.populate()

    # get_mount_facts() returns the empty dict {'mounts': None},
    # get_memory_facts() and get_uptime_facts() are mocked with
    # the empty dict {}, so facts is the empty dict.
    assert facts == {}

# Generated at 2022-06-22 23:22:50.664229
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware(None)
    assert isinstance(hurd_hardware, HurdHardware)
    assert hurd_hardware.platform == 'GNU'



# Generated at 2022-06-22 23:22:53.546485
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHw = HurdHardware({})
    assert hurdHw.platform == 'GNU'

# Generated at 2022-06-22 23:22:56.443317
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)



# Generated at 2022-06-22 23:22:56.764203
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-22 23:23:04.573913
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import time
    import subprocess

    hurdhw = HurdHardware()

    # Call populate()
    now = time.time()
    output = subprocess.check_output(
            'uptime', stderr=subprocess.STDOUT, universal_newlines=True)
    after = time.time()

    assert hurdhw.populate().has_key('ansible_uptime_seconds')
    assert hurdhw.populate()['ansible_uptime_seconds'] <= (after - now)
    assert hurdhw.populate()['ansible_uptime_seconds'] > 0

# Generated at 2022-06-22 23:23:06.397913
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert isinstance(collector._fact_class(), HurdHardware)

# Generated at 2022-06-22 23:23:09.348251
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts = HurdHardwareCollector()
    assert isinstance(facts, HardwareCollector)
    assert facts.platform == 'GNU'


# Generated at 2022-06-22 23:23:13.739310
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    assert facts.uptime is not None
    assert facts.memtotal is not None
    assert facts.memfree is not None
    assert facts.disks is not None
    assert facts.distribution is not None
    assert facts.distribution_version is not None
    assert facts.mounts is not None

# Generated at 2022-06-22 23:23:18.137543
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    '''Unit test constructor of class HurdHardware'''
    hardware_obj = HurdHardware()
    assert isinstance(hardware_obj, HurdHardware)

if __name__ == '__main__':
    test_HurdHardware()

# Generated at 2022-06-22 23:23:19.923385
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HW = HurdHardware()
    assert HW.platform == "GNU"

# Generated at 2022-06-22 23:23:21.915744
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware()._platform == 'GNU'


# Generated at 2022-06-22 23:23:29.261882
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """

    # Arrange
    # Create an instance of the HurdHardware class
    facts = HurdHardware()

    # Act
    result = facts.populate()

    # Assert
    assert result['uptime_seconds'] > 0
    assert result['uptime_hours'] > 0
    assert result['uptime_days'] > 0
    assert result['uptime_seconds'] == result['uptime_hours']*3600 + result['uptime_days']*86400

# Generated at 2022-06-22 23:23:30.569722
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware({})
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:23:33.255869
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Testing constructor of class HurdHardware
    # should return an object of class HurdHardware
    assert isinstance(HurdHardware(), HurdHardware)

# Generated at 2022-06-22 23:23:37.025206
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # test default constructor
    hhw = HurdHardware()
    assert hhw
    # test specific constructor
    hhw = HurdHardware(module_name='foo')
    assert hhw

# Generated at 2022-06-22 23:23:40.249296
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhardware = HurdHardware()
    assert not hurdhardware.uptime

    hurdhardware.determine_uptime()
    assert hurdhardware.uptime

    assert not hurdhardware.memory
    hurdhardware.meminfo_facts()
    assert hurdhardware.memory

    mount_facts = {}
    try:
        mount_facts = hurdhardware.mount_facts()
    except TimeoutError:
        pass

    assert mount_facts

# Generated at 2022-06-22 23:23:43.281499
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector(None)
    assert isinstance(collector._fact_class, HurdHardware)

# Generated at 2022-06-22 23:23:53.660459
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create array of test memory information read from the Linux procfs
    test_memory_info_array = []
    test_memory_info_array.append('MemTotal:       4194304 kB')
    test_memory_info_array.append('MemFree:        3159336 kB')
    test_memory_info_array.append('Buffers:           7344 kB')
    test_memory_info_array.append('Cached:          151480 kB')
    test_memory_info_array.append('SwapCached:            0 kB')
    test_memory_info_array.append('Active:          151352 kB')
    test_memory_info_array.append('Inactive:         88052 kB')
    test_memory_info_array.append('Active(anon):      6400 kB')

# Generated at 2022-06-22 23:23:57.668616
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    with pytest.raises(AttributeError):
        HurdHardwareCollector(_platform='Linux')
    assert HurdHardwareCollector(_platform='GNU').__str__()[-5:] == 'facts'

# Generated at 2022-06-22 23:24:07.077435
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import psutil

    def get_swap_memory():
        return psutil.swap_memory()

    def get_virtual_memory():
        return psutil.virtual_memory()

    def get_disk_partitions():
        return psutil.disk_partitions(all=False)

    module = type('module', (), {'run_command': get_swap_memory})
    setattr(module, 'get_swap_memory', get_swap_memory)
    setattr(module, 'get_virtual_memory', get_virtual_memory)
    setattr(module, 'get_disk_partitions', get_disk_partitions)

    hd = HurdHardware(module)

    hd.populate()

# Generated at 2022-06-22 23:24:11.019591
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h is not None
    assert isinstance(h.platform, str)
    assert isinstance(h._fact_class, HurdHardware)


# Generated at 2022-06-22 23:24:13.431243
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts['mounts']

# Generated at 2022-06-22 23:24:20.514727
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test when only uptime facts are available and to avoid
    # TimeoutError in get_mount_facts
    hurd = HurdHardware()
    collected_facts = { 'system_uptime_secs': 42 }
    assert hurd.populate(collected_facts=collected_facts) == {
        'uptime': 42,
        'uptime_days': 0,
        'uptime_hours': 0,
        'uptime_minutes': 0,
        'uptime_seconds': 42,
        'mounts': [],
        'swapfree_mb': None,
        'swaptotal_mb': None,
        'memfree_mb': None,
        'memtotal_mb': None,
    }

# Generated at 2022-06-22 23:24:27.410357
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] is not None
    assert hardware_facts['uptime_seconds'] > 0

    assert hardware_facts['memtotal_mb'] is not None
    assert hardware_facts['memtotal_mb'] > 0

    assert hardware_facts['swaptotal_mb'] is not None
    assert hardware_facts['swaptotal_mb'] > 0

    assert hardware_facts['mounts'] is not None
    assert hardware_facts['mounts'] != []

# Generated at 2022-06-22 23:24:32.165713
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import ansible.module_utils.facts.hardware.hurd
    host_facts = ansible.module_utils.facts.hardware.hurd.HurdHardware()
    retrieved_facts = host_facts.populate()
    assert isinstance(
        retrieved_facts,
        dict
    )

# Generated at 2022-06-22 23:24:35.649269
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    hurd_hw = HurdHardware()
    # TODO: HurdHardware.populate should be tested
    # by using mocked results to mimic the Linux
    # method, corresponding to the Hurd compatibility
    # translator.
