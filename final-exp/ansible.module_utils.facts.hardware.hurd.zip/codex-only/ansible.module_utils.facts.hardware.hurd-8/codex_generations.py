

# Generated at 2022-06-22 23:14:36.738942
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts_class = HurdHardware()

    # Verify that the facts_class is an instance of HurdHardware
    assert isinstance(facts_class, HurdHardware)

    # Test the platform property
    assert facts_class.platform == 'GNU'

# Generated at 2022-06-22 23:14:40.312403
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class is HurdHardware
    assert hhc._platform is 'GNU'

# Generated at 2022-06-22 23:14:42.246821
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h1 = HurdHardwareCollector()
    assert h1.platform == 'GNU'


# Generated at 2022-06-22 23:14:43.457828
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware



# Generated at 2022-06-22 23:14:45.225343
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:14:47.000527
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HardwareCollector()
    print(hc)


# Generated at 2022-06-22 23:14:54.414394
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware({}, {}, {}, [])
    hw_facts = hw.populate()
    require_facts = ['uptime', 'uptime_seconds', 'memory']
    for fact in require_facts:
        assert fact in hw_facts, 'Failed to collect %s fact' % fact
    # No prlimit facts on GNU/Hurd
    if 'prlimit' in hw_facts:
        raise AssertionError('Should not collect prlimit facts on Hurd')

# Generated at 2022-06-22 23:14:55.506682
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)
    assert h.populate() is not False

# Generated at 2022-06-22 23:14:57.492260
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert isinstance(h._fact_class, HurdHardware)
    assert isinstance(h._platform, str)
    assert isinstance(h._collectors, dict)


# Generated at 2022-06-22 23:15:00.445144
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
  test = HurdHardware()
  assert test
  assert test.get_mount_facts()
  assert test.get_memory_facts()
  assert test.get_uptime_facts()

# Generated at 2022-06-22 23:15:05.598271
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initializing a linux hardware object for testing
    eut = HurdHardware(None)
    # Calling the populate method of class HurdHardware
    facts = eut.populate()
    # Verifying if facts is a dictionary
    assert isinstance(facts, dict)
    # Verifying if facts is empty or not
    assert facts != {}

# Generated at 2022-06-22 23:15:15.968889
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()

    # facts is a dict as returned by function populate of
    # HurdHardware instance
    facts = h.populate()

    # check values of typical Linux facts
    assert facts['uptime_seconds'] == 3601
    assert facts['uptime_hours'] == 1
    assert facts['uptime_days'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['fqdn'] == 'localhost'
    assert facts['cpu_model'] == 'Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz'
    assert facts['memtotal_mb'] == 3004
    assert facts['memfree_mb'] == 2551
    assert facts['processor_cores'] == 2

# Generated at 2022-06-22 23:15:20.202631
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert isinstance(hwc, HardwareCollector)
    assert hwc._fact_class == HurdHardware
    assert hwc._platform == 'GNU'


# Generated at 2022-06-22 23:15:26.266910
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts['uptime_seconds'] is not None
    assert facts['uptime_days'] is not None
    assert facts['memtotal_mb'] is not None
    assert facts['memfree_mb'] is not None
    assert facts['swaptotal_mb'] is not None
    assert facts['swapfree_mb'] is not None

# Generated at 2022-06-22 23:15:29.235412
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:15:34.978810
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] >= 0

    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0

    assert facts['mounts'] != []

# Generated at 2022-06-22 23:15:38.421649
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    module = 'facts.hardware.hurd'
    obj = HurdHardwareCollector()
    assert obj is not None
    assert obj._fact_class._platform == 'GNU'


# Generated at 2022-06-22 23:15:39.845514
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:15:43.531762
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.uptime is None
    assert hurd.memtotal is None
    assert hurd.memfree is None
    assert hurd.memavail is None
    assert hurd.swaptotal is None
    assert hurd.swapfree is None


# Generated at 2022-06-22 23:15:45.478653
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform=='GNU'


# Generated at 2022-06-22 23:15:49.102963
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert isinstance(hw, HardwareCollector)
    assert hw.platform == 'GNU'


# Generated at 2022-06-22 23:15:51.849428
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()

    assert(hwc._fact_class == HurdHardware)
    assert(hwc._platform == 'GNU')


# Generated at 2022-06-22 23:15:59.104835
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    uptime_facts = {'uptime': 1000}
    memory_facts = {'memtotal': 1000}
    mount_facts = {'mounts': 'mounts'}

    class MockHurdHardware(HurdHardware):
        def get_uptime_facts(self):
            return uptime_facts

        def get_memory_facts(self):
            return memory_facts

        def get_mount_facts(self):
            return mount_facts

    hardware = MockHurdHardware()

    assert(hardware.populate() == {'uptime': 1000, 'memtotal': 1000, 'mounts': 'mounts'})

# Generated at 2022-06-22 23:16:02.319112
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware.populate()
    assert 'memory' in facts
    assert isinstance(facts['memory']['swapfree_mb'], int)
    assert 'mounts' in facts

# Generated at 2022-06-22 23:16:12.952069
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    assert isinstance(facts, dict)
    assert 'uptime' in facts
    assert isinstance(facts['uptime'], int)
    assert 'uptime_seconds' in facts
    assert isinstance(facts['uptime_seconds'], int)
    assert 'uptime_days' in facts
    assert isinstance(facts['uptime_days'], int)
    assert 'memory_mb' in facts
    assert isinstance(facts['memory_mb'], int)
    assert 'memfree_mb' in facts
    assert isinstance(facts['memfree_mb'], int)
    assert 'swapfree_mb' in facts
    assert isinstance(facts['swapfree_mb'], int)
    assert 'mounts' in facts

# Generated at 2022-06-22 23:16:15.388046
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector

if __name__ == "__main__":
    test_HurdHardwareCollector()

# Generated at 2022-06-22 23:16:16.724208
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
  result = HurdHardware()
  assert result != None

# Generated at 2022-06-22 23:16:18.414227
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware._platform == 'GNU'

# Generated at 2022-06-22 23:16:19.769976
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw


# Generated at 2022-06-22 23:16:29.597748
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # create instance of HurdHardware class
    hardware_facts = HurdHardware()
    # call function populate of HurdHardware class, with empty dict
    hardware_facts.populate({})
    assert hardware_facts.populate({}) == {
        'memfree_mb': 1679,
        'memtotal_mb': 1754,
        'uptime_seconds': 68623,
        'uptime_days': 0,
        'uptime_hours': 19,
        'uptime_minutes': 7,
        'system_mounts': [
            {'mount': '/', 'device': '/dev/hd0s1', 'fstype': 'ufs'},
        ],
    }

# Generated at 2022-06-22 23:16:33.324859
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw_test = HurdHardware({})
    assert isinstance(hurd_hw_test, HurdHardware)
    assert isinstance(hurd_hw_test, LinuxHardware)
    assert isinstance(hurd_hw_test, HardwareCollector)

# Generated at 2022-06-22 23:16:34.217098
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() is not None

# Generated at 2022-06-22 23:16:39.066234
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['fqdn']
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] >= 0
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['mounts'][0]['mount'] == '/'
    assert hardware_facts['memtotal_mb'] > 0

# Generated at 2022-06-22 23:16:43.916460
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    assert(hurdhw)

    # Method populate returns a dict with key 'uptime'
    result = hurdhw.populate()
    assert isinstance(result, dict) and 'uptime' in result.keys()

# Generated at 2022-06-22 23:16:44.895878
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

# Generated at 2022-06-22 23:16:46.894619
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class == HurdHardware
    assert hhc._platform == 'GNU'

# Generated at 2022-06-22 23:16:48.189119
# Unit test for constructor of class HurdHardware

# Generated at 2022-06-22 23:16:50.418486
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'


# Generated at 2022-06-22 23:17:00.574376
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    hardware.populate()
    hardware_facts = hardware.get_facts()

    assert hardware_facts["uptime_seconds"] > 0
    assert hardware_facts["uptime_hours"] > 0
    assert hardware_facts["uptime_days"] > 0

    assert hardware_facts["memtotal_mb"] > 0

    assert hardware_facts["mounts"][0]["fstype"] == "exofs"
    assert hardware_facts["mounts"][0]["uuid"] == "00000000-0000-0000-0000-000000000000"
    assert hardware_facts["mounts"][0]["device"] == "/exofs"
    assert hardware_facts["mounts"][0]["mount"] == "/"
    assert hardware_facts["mounts"][0]["size_total"] == 0

# Generated at 2022-06-22 23:17:10.949807
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Given a GNU Linux system
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/bin/cat'

    open_mock = mock.mock_open(read_data='Hurd/i386')

# Generated at 2022-06-22 23:17:14.354969
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    if 'Hurd' in hardware.populate()['ansible_facts']['ansible_processor'][0]:
        return True
    return False

# Generated at 2022-06-22 23:17:23.616466
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {
        'ansible_sysname': 'GNU',
        'ansible_machine': 'i386',
        'ansible_memtotal_mb': '1576.0',
    }

    expected_facts = {
        'uptime_seconds': 157600,
        'uptime_days': 1,
        'uptime_hours': 4,
        'uptime_minutes': 24,
    }

    hardware = HurdHardware()

    facts = hardware.populate(collected_facts)

    assert facts == {
        'uptime_seconds': 157600,
        'uptime_days': 1,
        'uptime_hours': 4,
        'uptime_minutes': 24,
        'memtotal_mb': 1576.0,
        'mounts': [],
    }

# Generated at 2022-06-22 23:17:27.567255
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    e = HurdHardwareCollector()
    assert e.__class__.__name__ == 'HurdHardwareCollector'
    assert e._fact_class.__name__ == 'HurdHardware'
    assert e._platform == 'GNU'


# Generated at 2022-06-22 23:17:31.068539
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'
    assert h.uptime is None
    assert h.swapfree is None
    assert h.mounts is None

# Generated at 2022-06-22 23:17:42.361664
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    klass = HurdHardware
    method = 'populate'

    hw = klass()
    hw.populate()

    # Test uptime fact
    assert 'uptime' in hw.uptime_facts
    assert 'seconds' in hw.uptime_facts['uptime']
    assert 'minutes' in hw.uptime_facts['uptime']
    assert 'hours' in hw.uptime_facts['uptime']
    assert 'days' in hw.uptime_facts['uptime']

    # Test memory fact
    assert 'memtotal_mb' in hw.memory_facts
    assert 'memfree_mb' in hw.memory_facts
    assert 'swaptotal_mb' in hw.memory_facts
    assert 'swapfree_mb' in hw.memory_facts



# Generated at 2022-06-22 23:17:44.560483
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'

# Generated at 2022-06-22 23:17:46.267961
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:17:47.776425
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    mytest = HurdHardware({}, None)
    assert mytest.platform == 'GNU'


# Generated at 2022-06-22 23:17:50.266094
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Default unit test for construction of HurdHardware class
    """

    hurddata = HurdHardware()
    assert hurddata is not None



# Generated at 2022-06-22 23:17:52.351877
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    my_HurdHardwareCollector = HurdHardwareCollector()
    assert my_HurdHardwareCollector._fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:17:59.087186
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    '''
    Test HurdHardware class constructor and its call
    '''
    hurd = HurdHardware({})
    if not isinstance(hurd, HurdHardware):
        raise AssertionError('Failed to test HurdHardware()')
    if not isinstance(hurd.get_memory_facts(), dict):
        raise AssertionError('Failed to test HurdHardware().get_memory_facts()')
    if not isinstance(hurd.get_mount_facts(), dict):
        raise AssertionError('Failed to test HurdHardware().get_mount_facts()')


# Generated at 2022-06-22 23:18:02.268204
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    ura = HurdHardware()
    assert ura.mount_facts is None
    assert ura.uptime_facts is None
    assert ura.memory_facts is None

# Generated at 2022-06-22 23:18:05.567176
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector_object = HurdHardwareCollector()
    assert hurd_hardware_collector_object._fact_class == HurdHardware
    assert hurd_hardware_collector_object._platform == 'GNU'

# Generated at 2022-06-22 23:18:11.487847
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware(None)
    collected_facts = {'ansible_architecture': 'unknown'}
    hw.populate(collected_facts)
    for fact in (
        'uptime',
        'swapfree_mb',
        'uptime_seconds',
        'memfree_mb',
        'memtotal_mb',
        'swaptotal_mb',
        'mounts',
    ):
        assert fact in collected_facts

# Generated at 2022-06-22 23:18:13.263751
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    assert facts.platform == 'GNU'


# Generated at 2022-06-22 23:18:15.756956
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HardwareCollector)
    assert isinstance(hurd_hardware, HurdHardware)
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:18:16.936818
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:18:20.101490
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._fact_class is HurdHardware
    assert hurd_hardware_collector._platform is 'GNU'

# Generated at 2022-06-22 23:18:22.678253
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result.platform == 'GNU'
    assert result.fact_class == HurdHardware

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 23:18:29.506503
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup test object
    hw = HurdHardware()

    # Populate object with facts
    hw.populate()

    # List of required fact keys
    factlist = ['uptime', 'uptime_days', 'uptime_hours', 'uptime_seconds',
                'memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb']

    for fact in factlist:
        assert fact in hw.data, "Could not find fact %s" % fact

# Generated at 2022-06-22 23:18:32.380819
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    class TestHurdHardwareCollector(HurdHardwareCollector):
        pass

    assert TestHurdHardwareCollector._fact_class is HurdHardware
    assert TestHurdHardwareCollector._platform == 'GNU'


# Generated at 2022-06-22 23:18:36.651190
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    lhc = HurdHardwareCollector()
    assert lhc.platform == 'GNU'
    assert lhc._fact_class == HurdHardware

# Generated at 2022-06-22 23:18:47.303181
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test = HurdHardware()

# Generated at 2022-06-22 23:18:49.973703
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert 'ansible_facts' in facts
    assert 'memory_mb' in facts['ansible_facts']

# Generated at 2022-06-22 23:18:51.648926
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == "GNU"

# Generated at 2022-06-22 23:18:52.825574
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw

# Generated at 2022-06-22 23:18:55.698024
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    cls = HurdHardwareCollector()
    assert cls._platform == 'GNU'
    assert cls._fact_class == HurdHardware


# Generated at 2022-06-22 23:18:58.087229
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    assert isinstance(facts, dict)
    assert facts is not {}

# Generated at 2022-06-22 23:18:58.747705
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    pass

# Generated at 2022-06-22 23:19:07.394181
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    ansible_host_vars = {
        'ansible_product_name': 'GNU/Hurd',
        'ansible_machine': 'i386',
        'ansible_lsb': {
            'id': 'GNU/Hurd',
            'description': 'GNU Hurd 1.11',
            'release': '1.11',
            'codename': 'Hurd',
            'major_release': '1.11',
            'short_description': 'GNU Hurd'
        }
    }
    _obj = HurdHardware(ansible_host_vars)
    _facts = _obj.populate()
    assert 'ansible_architecture' in _facts

# Generated at 2022-06-22 23:19:09.704644
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector_object = HurdHardwareCollector()
    assert isinstance(hardware_collector_object, HurdHardwareCollector)


# Generated at 2022-06-22 23:19:12.469678
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_facts = HurdHardware()
    assert isinstance(hurd_facts.platform, str)
    assert isinstance(hurd_facts.populate(), dict)

# Generated at 2022-06-22 23:19:23.670456
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    m = HurdHardware()
    result = m.populate()

    assert result['uptime_seconds'] >= 0
    assert set(result['memfree_mb']) >= set(['real', 'swap'])
    assert set(result['memtotal_mb']) >= set(['real', 'swap'])
    assert set(result['swapfree_mb']) >= set(['real', 'swap'])
    assert set(result['swaptotal_mb']) >= set(['real', 'swap'])

    assert result['mounts'] is not None
    assert result['fstype'] is not None
    assert result['device'] is not None
    assert result['mount'] is not None
    assert result['options'] is not None
    assert result['size_total'] is not None

# Generated at 2022-06-22 23:19:26.049330
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-22 23:19:28.322217
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware({})
    assert isinstance(hurd_hardware, HurdHardware)

# Generated at 2022-06-22 23:19:30.506982
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # This test is only here because pylint complains without one.
    hw = HurdHardware()
    assert hw.populate() is None

# Generated at 2022-06-22 23:19:31.772506
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware('/')
    hh.populate()

# Generated at 2022-06-22 23:19:33.221642
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:36.523273
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'


# Generated at 2022-06-22 23:19:38.729554
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert type(h) == HurdHardware


# Generated at 2022-06-22 23:19:40.717961
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw._facts == {'arista_eos': False}

# Generated at 2022-06-22 23:19:42.209767
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert(HurdHardware.platform == 'GNU')
    HurdHardwareCollector()

# Generated at 2022-06-22 23:19:45.709934
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert isinstance(hurd_hardware_collector._fact_class, HurdHardware)
    assert hurd_hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:19:50.255958
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    asserts = {
        'platform': hh.platform,
        'memory': hh.memory,
        'mount': hh.mount
    }
    for k, v in asserts.items():
        assert k in hh
        assert v == hh[k]

# Generated at 2022-06-22 23:19:52.422773
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert(HurdHardware().collect()['uptime_seconds'] > 0)

# Generated at 2022-06-22 23:19:56.805342
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] >= 0
    assert hardware_facts['memtotal_mb'] >= 0
    assert hardware_facts['memfree_mb'] < hardware_facts['memtotal_mb']

# Generated at 2022-06-22 23:19:57.967002
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()

# Generated at 2022-06-22 23:20:00.167270
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'

# Generated at 2022-06-22 23:20:03.209293
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Create an instance of HurdHardwareCollector.
    """
    hw = HurdHardwareCollector()
    assert isinstance(hw, HurdHardwareCollector)

# Generated at 2022-06-22 23:20:08.669128
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import json
    import tempfile
    test_facts = {}

# Generated at 2022-06-22 23:20:10.362939
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:20:13.181357
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware('/')
    assert(type(hurdhw.populate()) == dict)


# Generated at 2022-06-22 23:20:24.368018
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from ansible.module_utils.facts.hardware.linux import _SYS_CLASS_NET_FILE_NAME
    from ansible.module_utils.facts.hardware.linux import _SYS_CLASS_NET_PATH_NAME
    import os
    import tempfile
    path = tempfile.mkdtemp()
    os.mkdir(os.path.join(path, _SYS_CLASS_NET_PATH_NAME))
    os.mkdir(os.path.join(path, _SYS_CLASS_NET_PATH_NAME, 'lo'))
    os.mkdir(os.path.join(path, _SYS_CLASS_NET_PATH_NAME, 'eth0'))

# Generated at 2022-06-22 23:20:28.039967
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    hardware_collector.collect()
    collected_facts = hardware_collector.get_facts()

    # verify that HurdHardwareCollector instantiates GNU Hurd
    assert collected_facts['ansible_facts']['hardware']['platform'] == 'GNU'

# Generated at 2022-06-22 23:20:32.447421
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.__class__.__name__ == 'HurdHardwareCollector'
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdHardware


# Generated at 2022-06-22 23:20:35.324202
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.uptime is None
    assert hurd_hardware.vendor is None
    return True


# Generated at 2022-06-22 23:20:38.887167
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Test without collectiing facts
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

    # Test with collected facts
    hurd_hw = HurdHardware(facts={'kernel': 'GNU'})
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-22 23:20:49.600723
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test to check method populate of class HurdHardware

    """

    h = HurdHardware()

# Generated at 2022-06-22 23:20:51.866849
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:21:01.144184
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    with open('test/unit/module_utils/facts/test_hardware_linux_uptime.json') as linux_uptime_json, \
            open('test/unit/module_utils/facts/test_hardware_linux_memory.json') as linux_memory_json, \
            open('test/unit/module_utils/facts/test_hardware_linux_mounts.json') as linux_mounts_json:
        linux_uptime_fact = json.load(linux_uptime_json)
        linux_memory_fact = json.load(linux_memory_json)
        linux_mounts_fact = json.load(linux_mounts_json)
        
        obj = HurdHardwareCollector()
        obj.collect()

# Generated at 2022-06-22 23:21:02.711427
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:21:04.383291
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'


# Generated at 2022-06-22 23:21:07.901085
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.collect()['ansible_facts']['ansible_mounts'] is not None
    assert hhc.collect()['ansible_facts']['ansible_uptime_seconds'] is not None

# Generated at 2022-06-22 23:21:10.469293
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    with HurdHardwareCollector() as facter:
        assert facter._platform == 'GNU'
        assert facter._fact_class is HurdHardware
        assert isinstance(facter._facts, HurdHardware)

# Generated at 2022-06-22 23:21:15.268937
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Create an instance of class HurdHardware with no arguments and check that
    the result is an object with the correct name.
    """
    hardware = HurdHardware()
    assert hardware.__class__.__name__ == 'HurdHardware'

# Generated at 2022-06-22 23:21:17.848750
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhardware = HurdHardware()
    assert hurdhardware.platform == "GNU"


# Generated at 2022-06-22 23:21:20.093450
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    uptime_facts = hardware_facts.get_uptime_facts()
    memory_facts = hardware_facts.get_memory_facts()

    mount_facts = {}
    try:
        mount_facts = hardware_facts.get_mount_facts()
    except TimeoutError:
        pass

    hardware_facts.populate(hardware_facts)

# Generated at 2022-06-22 23:21:21.649030
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    '''
    Instantiate a HurdHardware() object to test its constructor
    '''
    hurdhw = HurdHardware()

# Generated at 2022-06-22 23:21:23.593620
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'

# Generated at 2022-06-22 23:21:26.306425
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwcol = HurdHardwareCollector()
    assert hwcol.platform == 'GNU'

# Generated at 2022-06-22 23:21:34.097132
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_collector = HurdHardwareCollector()
    hardware_facts = hardware_collector.collect()
    assert hardware_facts['uptime']['days'] > 0
    assert hardware_facts['uptime']['hours'] >= 0
    assert hardware_facts['uptime']['minutes'] >= 0
    assert hardware_facts['uptime']['seconds'] >= 0
    assert hardware_facts['memory']['total'] > 0
    assert hardware_facts['memory']['swap']['total'] > 0
    assert hardware_facts['mounts'][0]['mount'] == '/'

# Generated at 2022-06-22 23:21:35.610712
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    assert(hurdhw.populate() is not None)

# Generated at 2022-06-22 23:21:37.491210
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test_obj = HurdHardware()
    assert isinstance(test_obj, HurdHardware)


# Generated at 2022-06-22 23:21:42.647908
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from collections import namedtuple

    mock_facts = {'kernel_name': 'GNU', 'distribution': 'GNU'}
    HurdHardware.distribution = mock_facts['distribution']
    HurdHardware.kernel = mock_facts['kernel_name']

    # Test with empty facts dictionary
    hardware_facts = HurdHardware().populate({})
    assert hardware_facts['memory_mb'] > 0
    assert hardware_facts['memory_mb'] != 'unknown'
    assert hardware_facts['uptime_seconds'] != 'unknown'
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_seconds'] > hardware_facts['uptime_days']*60*60*24

    # Test with non-empty facts dictionary

# Generated at 2022-06-22 23:21:46.852129
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    mod = HurdHardwareCollector()
    assert isinstance(mod, HardwareCollector)
    assert mod._fact_class == HurdHardware
    assert mod._platform == 'GNU'
    assert mod._fallback_fact_class == LinuxHardware


# Generated at 2022-06-22 23:21:49.186754
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    turtle_facts = HurdHardware().populate()
    assert 'uptime_seconds' in turtle_facts

# Generated at 2022-06-22 23:21:50.574544
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_instance = HurdHardware()
    assert hardware_instance.populate()

# Generated at 2022-06-22 23:21:52.285121
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_obj = HurdHardware()
    assert hurd_obj.platform == 'GNU'


# Generated at 2022-06-22 23:21:54.404228
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw_collector = HurdHardwareCollector()
    assert(hurd_hw_collector._platform == 'GNU')

# Generated at 2022-06-22 23:22:05.911631
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import json, sys
    if sys.version_info[0] < 3:
        # Python 2
        import mock
    else:
        # Python 3
        from unittest import mock
    with open("test/unit/module_utils/facts/hardware/test_hurd_hardware.json") as f:
        test_data = json.load(f)

    def mock_get_path_content(path):
        with open("test/unit/module_utils/facts/hardware/test_hurd_hardware_procfs.json") as f:
            procfs_content = json.load(f)
            return procfs_content[path]

    module = mock.MagicMock()
    module.params = {}
    module.params['gather_mounts'] = False
    hurd_hardware = HurdHardware

# Generated at 2022-06-22 23:22:09.992036
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_fact_module = HurdHardware()
    result = test_fact_module.populate()
    assert(result['memory_mb']['real']['total'] > 0)
    assert(result['uptime_seconds'] > 0)
    assert(result['mounts'] != None)

# Generated at 2022-06-22 23:22:12.036132
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert facts.get('uptime', 0) > 0
    assert facts.get('uptime_format', '') != ''

# Generated at 2022-06-22 23:22:20.999729
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.get_file_content.__module__ == 'ansible.module_utils.facts.hardware.linux'
    assert hurd.get_file_lines.__module__ == 'ansible.module_utils.facts.hardware.linux'
    assert hurd.get_mount_facts.__module__ == 'ansible.module_utils.facts.hardware.linux'
    assert hurd.get_uptime_facts.__module__ == 'ansible.module_utils.facts.hardware.linux'

# Generated at 2022-06-22 23:22:22.541113
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == HurdHardwareCollector._fact_class.platform

# Generated at 2022-06-22 23:22:34.285342
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import LegacyFactCollector
    from ansible.module_utils.facts.hardware import HurdHardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    # path to the procfs compatibility translator
    procfs_path = '/hurd/procfs'

    # Sample VmallocChunk value

# Generated at 2022-06-22 23:22:36.630115
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_collector = HurdHardwareCollector()
    assert fact_collector._platform == 'GNU'
    assert fact_collector._fact_class.__name__ == 'HurdHardware'

# Generated at 2022-06-22 23:22:41.956910
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():

    assert issubclass(HurdHardwareCollector, HardwareCollector) is True
    assert issubclass(HurdHardwareCollector, object) is True
    assert HurdHardwareCollector._fact_class is HurdHardware
    assert HurdHardwareCollector._platform == 'GNU'
    assert str("<class 'ansible.module_utils.facts.hardware.hurd.HurdHardwareCollector'>") in str(HurdHardwareCollector.__repr__(HurdHardwareCollector))

# Generated at 2022-06-22 23:22:44.059019
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:22:46.194027
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhardware = HurdHardware()
    assert isinstance(hurdhardware, HurdHardware)


# Generated at 2022-06-22 23:22:51.845053
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test1 = HurdHardware()
    assert test1.platform == 'GNU'
    assert test1._Uptime == ['/proc/uptime', 0, 2]
    assert test1._MEMORY == ['/proc/meminfo', 0, 8]
    assert test1._MOUNTS == ['/proc/mounts', 0, 11]



# Generated at 2022-06-22 23:22:55.962822
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._platform == 'GNU'
    assert isinstance(hw_collector._fact_class(None), HurdHardware)


# Generated at 2022-06-22 23:22:59.611178
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Creating a HurdHardware object for testing
    hurd_hw = HurdHardware()

    # Testing the return value of the empty method _get_mount_facts
    assert len(hurd_hw._get_mount_facts()) == 0

# Generated at 2022-06-22 23:23:01.673386
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw.collect(), dict)


# Generated at 2022-06-22 23:23:12.755351
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import platform
    import sys
    import os

    sys.modules['platform'] = platform
    path = os.path.dirname(os.path.realpath(__file__)) + "/sample_data"

    hw = HurdHardware()
    hw.module_args = {
        "gather_subset": ["all"],
        "filter": ['mounts', 'meminfo'],
        "path": {
            "uptime": path + "/uptime",
            "meminfo": path + "/meminfo",
            "mounts": path + "/mounts",
        },
    }

    sut = hw.populate()

    assert sut["uptime_seconds"] == 141030
    assert sut["uptime_seconds_raw"] == "141030"

# Generated at 2022-06-22 23:23:16.532868
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockModule:
        def __init__(self, *args, **kwargs):
            return

        def fail_json(self, *args, **kwargs):
            return

    import ansible.module_utils.facts.system.hurd.hardware.HurdHardware

# Generated at 2022-06-22 23:23:24.258298
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()

    assert facts['uptime_seconds'] == 1
    assert facts['uptime_hours'] == 1
    assert facts['uptime_days'] == 1
    assert facts['memtotal_mb'] == 1
    assert facts['memfree_mb'] == 1
    assert facts['swaptotal_mb'] == 1
    assert facts['swapfree_mb'] == 1
    assert facts['mounts'] == 1

# Generated at 2022-06-22 23:23:26.218672
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector
    assert fact_class._fact_class == HurdHardware
    assert fact_class._platform == 'GNU'

# Generated at 2022-06-22 23:23:29.590742
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware = HurdHardware()
    hardware_facts = HurdHardware.populate()
    assert hardware_facts['uptime'] > 0
    assert hardware_facts['uptime_seconds'] > 0

# Generated at 2022-06-22 23:23:33.419714
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()

    assert isinstance(hw, HardwareCollector)
    assert isinstance(hw._fact_class, HurdHardware)
    assert hw._platform == 'GNU'



# Generated at 2022-06-22 23:23:35.293811
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    assert h.populate()

# Generated at 2022-06-22 23:23:37.710048
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    result = hurd.populate()
    assert result['uptime_seconds'] > 0

# Generated at 2022-06-22 23:23:43.188408
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts_collector = HurdHardwareCollector()
    assert facts_collector
    assert isinstance(facts_collector, HurdHardwareCollector)

    # test for platform contructor
    assert facts_collector._platform == 'GNU'

    # test for _fact_class contructor
    assert facts_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:23:53.542518
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware, Uptime
    from ansible.module_utils.facts.hardware.base import Mount, Swap
    import pytest

    class MockProcFS(LinuxHardware):
        def get_meminfo_facts(self):
            meminfo = {
                'MemTotal': 419430400,
                'MemFree': 0,
                'SwapTotal': 838860800,
                'SwapFree': 838860800
            }
            return meminfo


# Generated at 2022-06-22 23:24:05.632484
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()

    # test case: /proc/uptime is readable
    with open('/proc/uptime', 'r') as f:
        hurd_hw.read_file = Mock(return_value=f.read())
        hurd_hw.read_file.side_effect = None
        result = hurd_hw.populate()
        assert result

    # test case: /proc/uptime is not readable
    hurd_hw.read_file = Mock(return_value=False)
    result = hurd_hw.populate()
    assert result

    # test case: /proc/mounts is readable
    with open('/proc/mounts', 'r') as f:
        hurd_hw.read_file = Mock(return_value=f.read())
        hurd_hw.read_file.side_effect

# Generated at 2022-06-22 23:24:06.971980
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:24:08.610727
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware(None).populate() is not None

# Generated at 2022-06-22 23:24:10.365146
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:24:14.062886
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert(isinstance(h, HurdHardware))
    assert(isinstance(h, LinuxHardware))
    assert(isinstance(h, HardwareCollector))


# Generated at 2022-06-22 23:24:16.379271
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert isinstance(result, HardwareCollector)
    assert isinstance(result.get_facts(), HurdHardware)


# Generated at 2022-06-22 23:24:17.860449
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'


# Generated at 2022-06-22 23:24:20.919532
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None
    assert hurd_hardware.get_memory_facts() is not None
    assert hurd_hardware.get_uptime_facts() is not None
    assert hurd_hardware.get_mount_facts() is not None
    assert hurd_hardware.populate() is not None

# Generated at 2022-06-22 23:24:21.495672
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

# Generated at 2022-06-22 23:24:22.972902
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'
    assert hurdhw.FACT_SUBSETS == HardwareCollector.FACT_SUBSETS


# Generated at 2022-06-22 23:24:25.171600
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'


# Generated at 2022-06-22 23:24:28.239252
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Unit test for constructor of class LinuxHardware"""
    hurdhw = HurdHardware()
    assert hurdhw.facts == {}
    assert hurdhw.platform == 'GNU'
    assert not hurdhw._warnings
    assert not hurdhw._failures


# Generated at 2022-06-22 23:24:30.255875
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class is HurdHardware


# Generated at 2022-06-22 23:24:32.881240
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware

# Generated at 2022-06-22 23:24:34.873492
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'
