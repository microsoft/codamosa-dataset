

# Generated at 2022-06-22 23:14:34.777453
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:14:36.477983
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert isinstance(hw, HurdHardware)
    assert isinstance(hw, LinuxHardware)

# Generated at 2022-06-22 23:14:47.640053
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    from ansible.module_utils.facts.collector import BaseFactCollector

    collected_facts = {}

    my_object = HurdHardware()
    uptime_facts = my_object.get_uptime_facts()
    memory_facts = my_object.get_memory_facts()
    mount_facts = {}
    try:
        mount_facts = my_object.get_mount_facts()
    except TimeoutError:
        pass

    assert isinstance(uptime_facts['ansible_uptime_seconds'], int)
    assert isinstance(uptime_facts['ansible_uptime_days'], int)
    assert isinstance(uptime_facts['ansible_uptime_hours'], int)

# Generated at 2022-06-22 23:14:49.308802
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'

# Generated at 2022-06-22 23:14:50.701140
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:14:51.994381
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware({})


# Generated at 2022-06-22 23:14:54.015315
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact = HurdHardwareCollector()
    assert fact.data["platform"] == "GNU"


# Generated at 2022-06-22 23:15:02.394053
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print("Executing test_HurdHardware_populate")
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()

    assert facts['uptime'] >= 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_days'] >= 0
    assert facts['uptime_seconds'] >= 0

    assert facts['memtotal_mb'] >= 0
    assert facts['memtotal'] >= 0

    assert 'swapfree' in facts
    assert 'swaptotal' in facts

    assert isinstance(facts['mounts'], list)
    assert len(facts['mounts']) > 0

# Generated at 2022-06-22 23:15:08.729878
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    import pytest
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    linux_hw = LinuxHardware()
    hurd_hw = HurdHardware()

    # we don't have any member variables yet.
    assert len(vars(hurd_hw)) == len(vars(LinuxHardware()))
    assert hurd_hw.platform == 'GNU'

    # we have the same methods as LinuxHardware
    assert hurd_hw.populate == LinuxHardware.populate

# Generated at 2022-06-22 23:15:09.578070
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    m = HurdHardware()
    m.populate()

# Generated at 2022-06-22 23:15:15.629427
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from os.path import join
    from mock import Mock
    from module_utils.facts.hardware.linux import LinuxHardware as Parent
    from ansible.module_utils.facts.hardware.hurd import HurdHardware

    # Configure the mock
    mock_module = Mock()
    mock_module.get_bin_path = Mock(return_value='/usr/bin/hurd-uptime')
    mock_module.params = {'gather_timeout': 42, 'filter': '.*'}
    mock_module.config = {'timeout': 15}
    mock_module.get_file_content = Mock(return_value='42.42')
    mock_module.get_mount_size = Mock(return_value={'size_total': 42, 'size_available': 42, 'size_used': 42})
    mock_

# Generated at 2022-06-22 23:15:17.559046
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware({})
    assert hh.platform == 'GNU'

# Generated at 2022-06-22 23:15:21.479563
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert isinstance(hw_collector._platform, str)
    assert hw_collector._platform == 'GNU'
    assert isinstance(hw_collector._fact_class, HurdHardware)

# Generated at 2022-06-22 23:15:32.623038
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = {'uptime': 123, 'uptime_seconds': 123, 'uptime_days': 123}


# Generated at 2022-06-22 23:15:34.978730
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._platform == 'GNU'

# Generated at 2022-06-22 23:15:38.027901
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    linux_hardware = HurdHardware()
    facts = linux_hardware.populate()
    assert facts['uptime_seconds'] == 0.0



# Generated at 2022-06-22 23:15:39.453848
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc.platform == 'GNU'

# Generated at 2022-06-22 23:15:41.248483
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.collect() == HurdHardwareCollector._fact_class.populate()

# Generated at 2022-06-22 23:15:42.290649
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardware, LinuxHardware)

# Generated at 2022-06-22 23:15:48.391107
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

    assert hardware.uptime_seconds
    assert hardware.uptime_seconds > 0

    assert hardware.swap['used']
    assert hardware.swap['used'] >= 0

    assert hardware.swap['total']
    assert hardware.swap['total'] >= 0

    assert hardware.swap['free']
    assert hardware.swap['free'] >= 0

    assert hardware.mem_total
    assert hardware.mem_total > 0

    assert hardware.mem_free
    assert hardware.mem_free >= 0

    assert hardware.mem_used
    assert hardware.mem_used >= 0

# Generated at 2022-06-22 23:15:54.321639
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_system': 'GNU'}
    hw = HurdHardware()

    # Call populate. Returned dictionary is empty if the system isn't supported
    hw.populate(collected_facts)

    assert hw.collector.platform == 'GNU'
    assert hw.fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:16:04.781688
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import TimeoutError
    import pytest

    hurd_hardware = HurdHardware()
    hurd_hardware.module = pytest.Mock()

    # Up time facts
    hurd_hardware.get_uptime_facts = pytest.Mock(return_value={'uptime_seconds': '42'})
    hurd_hardware.get_memory_facts = pytest.Mock(return_value={'swapfree_mb': '42'})
    hurd_hardware.get_mount_facts = pytest.Mock(return_value={'mounts': [{'mount': '/dev/sda', 'device': 'this'}]})
    hardware_facts = hurd_hardware.populate()

# Generated at 2022-06-22 23:16:08.168377
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {}
    hw = HurdHardware()
    result = hw.populate(collected_facts)

    assert result is not None
    assert 'kernel' in result
    assert 'uptime' in result

# Generated at 2022-06-22 23:16:09.910484
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:16:12.528894
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    # Call the method _populate with a mocked object to test its behavior
    h._populate(collected_facts={'kernel': 'GNU'})



# Generated at 2022-06-22 23:16:21.921072
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    facts = {'ansible_system': 'GNU', 'ansible_distribution': 'GNU'}
    collected_facts = {'ansible_facts': {'ansible_system': 'GNU',
                                         'ansible_distribution': 'GNU',
                                         'ansible_processor': ['x86_64']}}

    result = hurd_hardware.populate(collected_facts=collected_facts)


# Generated at 2022-06-22 23:16:24.512584
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:16:28.199790
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.get_mount_facts() is None


# Generated at 2022-06-22 23:16:36.022178
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    module_mock = 'ansible.module_utils.facts.hardware.linux.LinuxHardware'
    hardware = HurdHardware()
    assert hardware._mount_facts_class == module_mock
    assert hardware._memory_facts_class == module_mock
    assert hardware._uptime_facts_class == module_mock
    assert hardware.platform == 'GNU'
    assert hardware.distribution == ''
    assert hardware.distribution_version == ''
    assert hardware.distribution_major_version == ''
    assert hardware.distribution_release == ''

# Generated at 2022-06-22 23:16:36.862573
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:16:48.455838
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_mount_facts = {'mounts': [{"device": "/dev/vda",
                                    "mount": "/",
                                    "fstype": "ext2fs",
                                    "options": "rw"}]}
    hurd_hw.get_mount_facts = lambda: hurd_mount_facts
    hurd_uptime_facts = {'uptime_seconds': 3600}
    hurd_hw.get_uptime_facts = lambda: hurd_uptime_facts
    hurd_memory_facts = {'memfree_mb': 20}
    hurd_hw.get_memory_facts = lambda: hurd_memory_facts

# Generated at 2022-06-22 23:16:51.890085
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    instance = HurdHardwareCollector()
    assert isinstance(instance, HardwareCollector)
    assert instance.platform == 'GNU'
    assert instance._fact_class == HurdHardware

# Generated at 2022-06-22 23:16:54.314533
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Use constructor of class HurdHardware without argument and create a
    test instance.
    """
    test_obj = HurdHardware()


# Generated at 2022-06-22 23:16:56.037273
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == "GNU"

# Generated at 2022-06-22 23:16:57.563606
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector

# Generated at 2022-06-22 23:17:09.636058
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import tempfile
    from ansible.module_utils.facts.timeout import TimeoutError

    # Create empty test file
    tmpdir = tempfile.gettempdir()
    test_file = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    test_file.close()


# Generated at 2022-06-22 23:17:21.091857
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import timeout

    module_utils = 'ansible.module_utils.'
    a = module_utils + 'facts.hardware.'
    b = module_utils + 'facts.hardware.linux.LinuxHardware'
    c = module_utils + 'facts.hardware.hurd.HurdHardware'
    d = module_utils + 'facts.timeout.Timeout'

    timeout_original = timeout

    timeout.Timeout = timeout_original.Timeout
    Facts.collectors = [HurdHardwareCollector]
    Facts.collectors[0]._timed_out = False

    #

# Generated at 2022-06-22 23:17:26.195820
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    cpu_facts = HurdHardware().populate()

    assert 'uptime_seconds' in cpu_facts
    assert 'swapfree_mb' in cpu_facts
    assert 'swaptotal_mb' in cpu_facts
    assert 'memfree_mb' in cpu_facts
    assert 'memtotal_mb' in cpu_facts



# Generated at 2022-06-22 23:17:27.108860
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h is not None


# Generated at 2022-06-22 23:17:29.089715
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.get_platform() == 'GNU'
    assert HurdHardwareCollector._fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:17:33.600640
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert(hurd_hardware.platform == 'GNU')
    assert(hurd_hardware.get('uptime'))
    assert(hurd_hardware.get('virtualization'))

# Generated at 2022-06-22 23:17:34.709353
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector() # just instantiate

# Generated at 2022-06-22 23:17:37.563099
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    def test_args(self):
        pass
    hurd_hardware = HurdHardware(test_args)
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:17:42.948709
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == "GNU"
    assert obj.pldist == ""
    assert obj.meminfo == {}
    assert obj.virtual_mem == []
    assert obj.swaps == []
    assert obj.is_bdisk == False
    assert obj.is_block == False
    assert obj.is_ram == False
    assert obj.is_nfs == False

# Generated at 2022-06-22 23:17:47.515903
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    name = 'GNU'
    hwc = HurdHardwareCollector(name)
    assert isinstance(hwc, HardwareCollector)
    assert isinstance(hwc._fact_class, HurdHardware)
    assert hwc._platform == name

# Generated at 2022-06-22 23:17:49.277759
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fc = HurdHardwareCollector()
    output = fc._collect(None)
    assert output # Check if the output is not empty

# Generated at 2022-06-22 23:17:50.467753
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc

# Generated at 2022-06-22 23:17:52.583552
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector is not None


# Generated at 2022-06-22 23:17:55.382514
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h_h_c = HurdHardwareCollector()
    assert isinstance(h_h_c, HardwareCollector)
    assert h_h_c._platform == 'GNU'

# Generated at 2022-06-22 23:17:58.020720
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()

    assert hardware_collector._fact_class is HurdHardware
    assert hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:18:05.996208
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test the populate method of class HurdHardware."""

    from ansible.module_utils.facts.collector import TestCollector
    result = TestCollector(HurdHardwareCollector).collect()
    assert result['mounts']["/"] == {'size_total': 393881, 'options': 'rw,relatime',
                             'size_available': 63384, 'device': 'hurd',
                             'fstype': 'hurd'}
    assert result['uptime_seconds'] == 0
    assert 'MemTotal' in result['memfree_mb']

# Generated at 2022-06-22 23:18:08.999736
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:18:11.596164
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    GNUHurd = HurdHardware()
    assert GNUHurd.memory_facts()
    assert GNUHurd.mount_facts()

# Generated at 2022-06-22 23:18:16.442737
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_facts = hurd_hardware.populate()
    assert 'uptime' in hurd_facts
    assert 'memfree_mb' in hurd_facts
    assert 'memtotal_mb' in hurd_facts
    assert 'mounts' in hurd_facts

# Generated at 2022-06-22 23:18:23.844184
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hurd_hardware = HurdHardware()
    collect_set = set(['uptime',
                       'uptime_days',
                       'uptime_hours'])

    collect_set = collect_set.union(set(['memoryfree_mb',
                                         'memtotal_mb',
                                         'swapfree_mb',
                                         'swaptotal_mb']))

    collect_set = collect_set.union(set(['filesystems']))

    assert set(hurd_hardware.populate().keys()) == collect_set

# Generated at 2022-06-22 23:18:26.838567
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {}, \
        'Empty dictionary is returned by default when calling populate()'

# Generated at 2022-06-22 23:18:29.362016
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # create an instance of HurdHardware
    hardware = HurdHardware()
    # check correctness of method populate
    assert isinstance(hardware.populate(), dict)

# Generated at 2022-06-22 23:18:36.328311
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import mock
    import tempfile

    def _tempfile(content, mode):
        f = tempfile.NamedTemporaryFile(delete=False)
        f.write(content)
        f.close()
        return f

    def _fake_get_mount_facts():
        return {'mounts': [{'device': '/dev/fakeroot',
                            'mount': '/',
                            'fstype': 'ext4'}]}

    def _fake_get_uptime_facts():
        return {'uptime_seconds': 60}

    def _fake_get_memory_facts():
        return {'memfree_mb': 1024}

    # Testing for Linux-like Translator for Hurd
    # Uptime

# Generated at 2022-06-22 23:18:38.067506
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # test constructor
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:18:40.938277
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector()
    assert fact_class.fact_class == HurdHardware
    assert fact_class.platform == 'GNU'

HurdHardwareCollector.add_host_facts()

# Generated at 2022-06-22 23:18:41.922847
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:18:46.575167
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Testing of method populate of class HurdHardware.
    """
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    import time

    class MemInfoMock(object):
        def __init__(self, test_case):
            self.test_case = test_case
            self.content = "MemTotal:       514904 kB\nMemFree:        384628 kB\nBuffers:          7920 kB\nCached:          55628 kB\nSwapCached:            0 kB\n"
            self.readline_pos = 0


# Generated at 2022-06-22 23:18:49.207038
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test_dict = {}
    test_object = HurdHardware(module=test_dict)
    assert test_object.module is test_dict



# Generated at 2022-06-22 23:18:51.534777
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:18:52.986780
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    cls = HurdHardwareCollector()
    assert cls._platform == 'GNU'


# Generated at 2022-06-22 23:18:55.882188
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class.platform == 'GNU'


# Generated at 2022-06-22 23:18:56.820477
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-22 23:19:07.121191
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Ensure that calling the method populate of class HurdHardware
    return an object with the required values.
    """
    os_release = """
NAME="GNU/Linux"
ID=gnu
VERSION="0.9"
ID_LIKE=gnu
PRETTY_NAME="Debian GNU/Hurd"
"""
    fs_info_out = """
Filesystem     1024-blocks       Used Available Capacity  Mounted on
/dev/hd0s1       14136140  24750924       0     100% /
"""
    proc_uptime_out = "4769.35 2048.41"
    proc_meminfo_out = """
MemTotal:         3794564 kB
SwapTotal:         524288 kB
"""


# Generated at 2022-06-22 23:19:09.705987
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware(None)

    assert hurd_hardware._platform == 'GNU'
    assert hurd_hardware._fact_class == HurdHardware
    assert hurd_hardware._is_linux

# Generated at 2022-06-22 23:19:11.768509
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.collect() == h._fact_class(h._platform).populate()

# Generated at 2022-06-22 23:19:13.712072
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    f = HurdHardwareCollector()
    assert f.platform == 'GNU'
# test_HurdHardwareCollector()

# Generated at 2022-06-22 23:19:15.805312
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h

# Generated at 2022-06-22 23:19:17.302956
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert isinstance(obj, HurdHardware)

# Generated at 2022-06-22 23:19:21.024663
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert issubclass(HurdHardware, LinuxHardware)
    assert isinstance(hurd_hw, LinuxHardware)
    assert isinstance(hurd_hw, HardwareCollector)


# Generated at 2022-06-22 23:19:25.881456
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_os_family': 'GNU/Hurd'}
    fact_module = HurdHardware(collected_facts=collected_facts)
    fact_module.populate()
    assert fact_module.facts['ansible_os_family'] == 'GNU/Hurd'

# Generated at 2022-06-22 23:19:27.756737
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw is not None

# Generated at 2022-06-22 23:19:35.538753
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware(None)

    # Create a child process that raises a TimeoutError
    @hw.collector._timed_subprocess(1)
    def subprocess():
        raise TimeoutError("expected error")

    # Suppress results of subprocess from stdout and stderr
    import sys
    sys.stdout = open("/dev/null", "w")
    sys.stderr = open("/dev/null", "w")

    hardware_facts = hw.populate()

    # Make sure the two basic facts are present
    assert 'uptime' in hardware_facts
    assert 'uptime_seconds' in hardware_facts

    # Make sure the memory fact is present
    assert 'memory' in hardware_facts
    assert 'total_mb' in hardware_facts['memory']

    # Make sure the method

# Generated at 2022-06-22 23:19:40.723928
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_hours'] == 0
    assert hardware_facts['uptime_seconds'] == 0
    assert hardware_facts['uptime_days'] == 0

# Generated at 2022-06-22 23:19:44.661503
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test for method populate of class HurdHardware"""
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware_collector.populate()

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-22 23:19:46.902674
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh._platform == 'GNU'


# Generated at 2022-06-22 23:19:48.352563
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert hw.populate()

# Generated at 2022-06-22 23:19:51.121140
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    x=HurdHardwareCollector()
    assert x._platform == "GNU"
    assert x._fact_class == HurdHardware
    assert x._fact_class._platform == "GNU"


# Generated at 2022-06-22 23:19:55.049811
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    linux_hardware_collector = HurdHardwareCollector()
    linux_hardware_collector._populate()
    facts = linux_hardware_collector.get_facts()
    assert isinstance(facts, dict)

# Generated at 2022-06-22 23:19:59.513552
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._fact_class == HurdHardware
    assert hc._platform == 'GNU'

# Generated at 2022-06-22 23:20:02.583634
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'
    assert h.uptime_file == '/proc/uptime'
    assert h.memory_file == '/proc/meminfo'
    assert h.mount_facts_command == '/bin/mount'
    assert h.mount_facts_timeout == 3

# Generated at 2022-06-22 23:20:04.385225
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:20:05.226343
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware


# Generated at 2022-06-22 23:20:08.753775
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()

    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:20:12.110957
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:20:23.493052
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facter_hardware = HurdHardware()
    facter_hardware.populate()

# Generated at 2022-06-22 23:20:25.917917
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware.populate()
    assert 'uptime_seconds' in facts
    assert 'memory_mb' in facts
    assert 'mounts' in facts

# Generated at 2022-06-22 23:20:27.142207
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-22 23:20:33.689302
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Construct a HurdHardwareCollector object
    hhc = HurdHardwareCollector()

    # check if it is an instance of HurdHardwareCollector
    assert isinstance(hhc, HurdHardwareCollector)

    # check _fact_class is HurdHardware
    assert hhc._fact_class == HurdHardware

    # check _platform is GNU
    assert hhc._platform == 'GNU'

# Generated at 2022-06-22 23:20:35.074847
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert HurdHardware is not None

# Generated at 2022-06-22 23:20:36.101062
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_clt = HurdHardwareCollector()
    assert hw_clt.platform == 'GNU'

# Generated at 2022-06-22 23:20:38.588496
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware


# Generated at 2022-06-22 23:20:47.377172
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    
    assert hardware_facts['uptime_seconds'] == 123
    assert hardware_facts['uptime_hours'] == 3
    assert hardware_facts['uptime_days'] == 1
    assert hardware_facts['memtotal_mb'] == 1
    assert hardware_facts['memfree_mb'] == 1
    assert hardware_facts['swaptotal_mb'] == 16
    assert hardware_facts['swapfree_mb'] == 15
    assert hardware_facts['mounts'] == [{'mount': '/', 'device': '/dev/hd0s1'}]

# Generated at 2022-06-22 23:20:50.727707
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_obj = HurdHardware()
    result = test_obj.populate()
    assert result['uptime_seconds'] == 8410
    assert result['uptime_days'] == 0
    assert result['uptime_hours'] == 2
    assert result['uptime_minutes'] == 23
    assert result['uptime_seconds'] == 36
    assert result['memory_mb']['real']['total'] == 1546
    assert result['mounts'][0]['size_total'] == '/'
    assert result['mounts'][0]['size_available'] == '/'

# Generated at 2022-06-22 23:21:00.094688
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.facts import Facts
    facts = Facts(module=None)
    HurdHardware.populate(facts)
    assert len(facts.hardware) == 4
    assert facts.hardware['uptime']['hours'] == 791
    assert facts.hardware['memory'] == {'real': {'total': 45473824768},
                                        'swap': {'total': 0},
                                        'virtual': {'total': 71458435072}}
    assert len(facts.hardware['mounts']) == 3
    assert facts.hardware['mounts'][0]['options'] == 'rw,nosuid,nodev,bind'
    assert fa

# Generated at 2022-06-22 23:21:01.877754
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj
    assert obj._fact_class._platform == 'GNU'

# Generated at 2022-06-22 23:21:04.345278
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    con = HurdHardwareCollector()
    assert con.platform == "GNU"
    assert con.fact_class == HurdHardware

# Generated at 2022-06-22 23:21:12.258689
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    data = {
        'ansible_facts': {
            'mounts': [
                {
                    'device': '/dev/sdb1',
                    'mount': '/home',
                    'fstype': 'ext3',
                    'opts': 'rw,seclabel,relatime,data=ordered',
                    'size_total': 1073741824,
                    'size_available': 709371904,
                    'uuid': '2accab6e-3dcd-49ae-9ae2-f79031567127'
                }
            ]
        }
    }
    hardware = HurdHardware()
    hardware.populate()
    assert hardware.memory == data['ansible_facts']['mounts']

# Generated at 2022-06-22 23:21:14.088849
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert isinstance(obj, HurdHardware)

# Generated at 2022-06-22 23:21:24.355129
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # We need to create a temporary instance of class HurdHardware
    # for testing purpose
    hurd_hardware = HurdHardware()

    # We need to create some fictive data
    data = '''
             Key: Value
             Key2: Value2
    '''
    lines = iter(data.splitlines())
    # We need to create a fictive function that will return lines
    # in order to test the method populate of class HurdHardware
    def parse_text(text, key_value_separator):
        line = next(lines)
        while line:
            yield line.split(key_value_separator, 1)
            line = next(lines)

    # We need to create a fictive object for testing purpose
    # that will be returned by method read_file of class HurdHardware

# Generated at 2022-06-22 23:21:26.743586
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)

# Generated at 2022-06-22 23:21:28.946053
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'
    assert h._mount_facts == {}

# Generated at 2022-06-22 23:21:30.957965
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    mine = HurdHardwareCollector()
    assert mine._platform == 'GNU'
    assert issubclass(mine._fact_class, HurdHardware)

# Generated at 2022-06-22 23:21:32.212604
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:21:33.513545
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-22 23:21:35.797570
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_obj = HurdHardware()
    assert isinstance(hurd_obj, HurdHardware)
    assert hurd_obj.platform == 'GNU'

# Generated at 2022-06-22 23:21:39.937921
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    myHurdHardware = HurdHardware()
    assert myHurdHardware.platform == 'GNU'
    assert myHurdHardware.get_mount_facts()
    assert myHurdHardware.get_memory_facts()
    assert myHurdHardware.get_uptime_facts()

# Generated at 2022-06-22 23:21:42.914255
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc.platform == 'GNU'
    assert hc._fact_class == HurdHardware


# Generated at 2022-06-22 23:21:46.309774
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        collector = HurdHardwareCollector()
        assert collector._fact_class == HurdHardware
        assert collector._platform == "GNU"
    except Exception:
        assert False


# Generated at 2022-06-22 23:21:49.439747
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    fact_obj = HurdHardware()
    result = fact_obj.populate()
    assert result['uptime_seconds'] > 1.0


# Generated at 2022-06-22 23:21:52.727705
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # check the name of the platform
    hw_c = HurdHardwareCollector()
    assert hw_c.platform == 'GNU'

    # check the reference to the super class
    assert issubclass(HurdHardwareCollector, HardwareCollector)

# Generated at 2022-06-22 23:21:54.453611
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HardwareCollector)

# Generated at 2022-06-22 23:22:01.167823
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    m = HurdHardwareCollector()
    assert m._platform == 'GNU'
    case1 = ('/proc/meminfo', 'Linux', '/proc/meminfo')
    case2 = ('/proc/meminfo', 'GNU', '/proc/meminfo')
    assert m.get_file_path(case1[0], case1[1]) == case1[2]
    assert m.get_file_path(case2[0], case2[1]) == case2[2]

# Generated at 2022-06-22 23:22:09.781069
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdf = HurdHardware()
    hardware_facts = hurdf.populate()

    # test if class attributes were filled correctly
    assert hardware_facts['uptime_seconds'] == 173073
    assert hardware_facts['uptime_hours'] == 48
    assert hardware_facts['uptime_days'] == 0
    assert hardware_facts['mounts'] is not None
    assert hardware_facts['memtotal_mb'] == 2621
    assert hardware_facts['memfree_mb'] == 2355
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0

# Generated at 2022-06-22 23:22:11.333776
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware(None)
    assert hurd_hardware is not None

# Generated at 2022-06-22 23:22:16.908203
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()

    assert facts['uptime_seconds'] > 0
    assert facts['vendor'] == 'GNU'
    assert facts['memory_mb']['real']['total'] > 0
    assert isinstance(facts['mounts'], list)

# Generated at 2022-06-22 23:22:26.489870
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()

    from ansible.module_utils.facts.hardware.linux import _read_from_file as rff
    from ansible.module_utils.facts.hardware.linux import _read_from_procfs as rfp
    with patch.object(LinuxHardware, '_read_from_file', rff), \
         patch.object(LinuxHardware, '_read_from_procfs', rfp):
        facts = obj.populate()
        assert facts['uptime_seconds'] == 100
        assert facts['uptime_seconds_pretty'] == '1 day, 3:46:40'

        assert facts['memfree_mb'] == 2
        assert facts['memtotal_mb'] == 4
        assert facts['memtotal_bytes'] == 4194304
        assert facts['memfree_bytes'] == 2097152

# Generated at 2022-06-22 23:22:30.821231
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    collected_facts = {'ansible_system': 'GNU', 'ansible_distribution': 'GNU'}
    facts = h.populate(collected_facts=collected_facts)
    assert facts['uptime_seconds'] > 0
    assert facts['memtotal_mb'] > 0

# Generated at 2022-06-22 23:22:32.616722
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-22 23:22:41.879832
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Init
    hurd_hardware = HurdHardware()

    # Call
    hurd_hardware.populate()

    # Assertions
    assert type(hurd_hardware.uptime) is float
    assert len(hurd_hardware.mounts) > 0

    assert len(hurd_hardware.memtotal_mb) > 0
    assert type(hurd_hardware.memtotal_mb) is int

    assert len(hurd_hardware.memfree_mb) > 0
    assert type(hurd_hardware.memfree_mb) is int

    assert len(hurd_hardware.swaptotal_mb) > 0
    assert type(hurd_hardware.swaptotal_mb) is int

    assert len(hurd_hardware.swapfree_mb) > 0
    assert type

# Generated at 2022-06-22 23:22:44.004228
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    o = HurdHardwareCollector()
    assert o._fact_class._platform == 'GNU'
    assert isinstance(o._fact_class, HurdHardware)

# Generated at 2022-06-22 23:22:54.080530
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    # Test if method populate of class HurdHardware returns a dict
    facts = hurd_hardware.populate()
    assert isinstance(facts, dict) is True

    # Test keys of the return dictionary
    expected_keys = ['uptime', 'uptime_seconds', 'memtotal_mb', 'memfree_mb', 'swapfree_mb', 'mounts']
    for key in expected_keys:
        assert key in facts

    # Test values of the return dictionary
    assert facts['uptime'] is not None
    uptime_seconds = int(facts['uptime_seconds'])
    assert uptime_seconds > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swapfree_mb'] is not None

# Generated at 2022-06-22 23:22:57.011221
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:23:00.618550
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()

    assert len(facts) == 3
    assert facts['uptime_seconds'] >= 0
    assert facts['memtotal_mb'] >= -1
    assert 'mounts' in facts

# Generated at 2022-06-22 23:23:02.218214
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    a = HurdHardware({})
    assert a.populate() is not None

# Generated at 2022-06-22 23:23:04.013113
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-22 23:23:05.681708
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hd = HurdHardware()
    hd.populate()
    assert hd.data

# Generated at 2022-06-22 23:23:06.792902
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj


# Generated at 2022-06-22 23:23:09.348677
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector._fact_class
    assert fact_class == HurdHardware


# Generated at 2022-06-22 23:23:10.945055
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
	hardware_collector = HurdHardwareCollector()
	assert hardware_collector._platform == 'GNU'
	assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:23:13.652804
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    populate_result = hw.populate()

    assert populate_result['uptime_seconds'] > 0
    assert populate_result['uptime_hours'] > 0

# Generated at 2022-06-22 23:23:15.199033
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:23:27.169799
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    import json
    import string
    import unittest
    import unittest.mock as mock

    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    # We run the class tests only on GNU/Hurd
    if os.uname()[0] != 'GNU':
        return

    # Load and parse the output of the commands
    sysctl_stats_text = read_file(os.path.join(CURR_DIR, 'sysctl_stats.out'))
    sysctl_stats = json.loads(sysctl_stats_text)

    meminfo_text = read_file(os.path.join(CURR_DIR, 'meminfo.out'))

# Generated at 2022-06-22 23:23:31.381093
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # create a HurdHardware object
    hurd_hardware = HurdHardware()
    # call method populate of the HurdHardware object
    result = hurd_hardware.populate()
    # check the result
    # wait to create test_facts.py to check the result
    print (result)

# Generated at 2022-06-22 23:23:32.377138
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector is not None

# Generated at 2022-06-22 23:23:34.414501
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    assert len(hurd.populate()) > 0

# Generated at 2022-06-22 23:23:37.552661
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.get_mount_facts()

# Generated at 2022-06-22 23:23:40.619124
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:23:45.712623
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0

# Generated at 2022-06-22 23:23:47.592193
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware != None



# Generated at 2022-06-22 23:23:50.856204
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Make sure we have a instance of class HurdHardware
    hardware = HurdHardware()
    assert isinstance(hardware, HurdHardware)

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 23:23:54.449812
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert 'uptime' in hurd_hardware.ansible_facts
    assert 'memtotal_mb' in hurd_hardware.ansible_facts
    assert 'mounts' in hurd_hardware.ansible_facts

# Generated at 2022-06-22 23:23:58.102266
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware
    assert obj.collect() == {}


# Generated at 2022-06-22 23:23:59.206099
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:24:01.268365
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware = HurdHardwareCollector()
    assert hardware._platform == 'GNU'


# Generated at 2022-06-22 23:24:04.208918
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj

if __name__ == '__main__':
    test_HurdHardware()

# Generated at 2022-06-22 23:24:06.812237
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware


# Generated at 2022-06-22 23:24:13.525899
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {
        'distribution': 'GNU',
    }

    tested_class = HurdHardware(facts)
    results = tested_class.populate()
    assert results
    assert results['uptime']['seconds']
    assert results['memory']['swap']['total_mb']
    assert results['mounts'][0]['options']

# Generated at 2022-06-22 23:24:14.890793
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:24:17.114095
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'
    assert isinstance(h._fact_class, HurdHardware)


# Generated at 2022-06-22 23:24:19.419609
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardware, LinuxHardware)
    assert issubclass(HurdHardwareCollector, HardwareCollector)


# Generated at 2022-06-22 23:24:21.641827
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    hardware_collector.collect()

# Generated at 2022-06-22 23:24:29.956857
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collected_facts = None
    collector = HurdHardwareCollector()
    hardware_facts = {}
    hardware_facts = collector.collect(collected_facts)

    assert hardware_facts['hardware']['uptime']['total_seconds'] > 0
    assert hardware_facts['hardware']['uptime']['days'] >= 0
    assert hardware_facts['hardware']['uptime']['hours'] >= 0
    assert hardware_facts['hardware']['uptime']['minutes'] >= 0
    assert hardware_facts['hardware']['uptime']['seconds'] >= 0
    assert hardware_facts['hardware']['uptime']['uptime'] > 0

    assert hardware_facts['hardware']['mem_total'] > 0

# Generated at 2022-06-22 23:24:31.879184
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:24:33.258482
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h
