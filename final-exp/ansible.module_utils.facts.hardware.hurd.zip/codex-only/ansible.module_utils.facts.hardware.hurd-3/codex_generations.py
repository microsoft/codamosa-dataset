

# Generated at 2022-06-22 23:14:39.164266
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj_hhc = HurdHardwareCollector()
    assert obj_hhc._platform == 'GNU'

    obj_hhc._fact_class = LinuxHardware
    assert obj_hhc._fact_class == LinuxHardware

# Generated at 2022-06-22 23:14:43.656352
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import TimeoutError
    from ansible.module_utils.facts.timeout import Timeout

    with Timeout(seconds=1, error_message='timeout'):
        raise TimeoutError()

    HurdHardware().populate()

# Generated at 2022-06-22 23:14:45.412165
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()

    assert hh._platform == 'GNU'


# Generated at 2022-06-22 23:14:47.143932
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'

# Generated at 2022-06-22 23:14:48.142386
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj

# Generated at 2022-06-22 23:14:49.785691
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)

# Generated at 2022-06-22 23:14:52.944974
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:15:03.716953
# Unit test for constructor of class HurdHardware

# Generated at 2022-06-22 23:15:05.928958
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:15:08.474548
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhw = HurdHardwareCollector()
    assert hhw.platform == HurdHardware._platform
    assert hhw._fact_class == HurdHardware

# Generated at 2022-06-22 23:15:09.764451
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert(isinstance(hurd, HurdHardware))

# Generated at 2022-06-22 23:15:13.099281
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
  collector = HurdHardwareCollector()
  assert collector.platform == 'GNU'
  assert collector.fact_class == HurdHardware

# Unit test to test populate method of class HurdHardware

# Generated at 2022-06-22 23:15:14.818153
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'


# Generated at 2022-06-22 23:15:17.912290
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert isinstance(obj._fact_class, HurdHardware)
    assert obj._fact_class.platform == 'GNU'


# Generated at 2022-06-22 23:15:19.514153
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()

    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:15:24.325847
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_facts = HurdHardwareCollector(None)
    assert hasattr(hardware_facts, '_fact_class')
    assert hardware_facts._fact_class == HurdHardware
    assert hasattr(hardware_facts, '_platform')
    assert hardware_facts._platform == 'GNU'
    

# Generated at 2022-06-22 23:15:36.089459
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    generated_facts = {'uptime_seconds': 0, 'uptime_hours': 0,
                       'uptime_days': 0, 'uptime': '00:00:00',
                       'memtotal_mb': 0, 'memfree_mb': 0, 'memused_mb': 0,
                       'swaptotal_mb': 0, 'swapfree_mb': 0, 'swapused_mb': 0,
                       'mounts': [{'device': '', 'mount': '/'}]}
    fake_files = {"/proc/uptime": "0 0",
                  "/proc/meminfo":
                     "MemTotal: 0 kB\nMemFree: 0 kB\nSwapTotal: 0 kB\nSwapFree: 0 kB",
                  "/proc/mounts": "none / nullfs rw 0 0"}
   

# Generated at 2022-06-22 23:15:38.421496
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'
    assert h._fact_class == HurdHardware


# Generated at 2022-06-22 23:15:40.240871
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:15:51.570051
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import test_facts

    hardware = HurdHardware(module=None)
    hardware_facts = hardware.populate()

# Generated at 2022-06-22 23:15:52.930476
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'


# Generated at 2022-06-22 23:15:55.352156
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    _col = HurdHardwareCollector()
    assert _col._fact_class == HurdHardware
    assert _col._platform == 'GNU'

# Generated at 2022-06-22 23:15:56.966621
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert type(hwc) == HurdHardwareCollector

# Generated at 2022-06-22 23:16:00.288106
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()

    assert obj._fact_class is HurdHardware
    assert obj._platform is 'GNU'

# Generated at 2022-06-22 23:16:11.337617
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-22 23:16:12.876179
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.collect() == {}

# Generated at 2022-06-22 23:16:16.014994
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)
    # Asserting the default value of mount_facts
    assert hurd_hw.mount_facts['devices'] == {}



# Generated at 2022-06-22 23:16:16.790022
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-22 23:16:19.959352
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Test class constructor"""

    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:16:21.660469
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'


# Generated at 2022-06-22 23:16:29.712789
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test that the HurdHardware class populates the facts
    """

    def test_run_command(*args, **kwargs):
        """
        Mocked run_command
        """
        assert 'mount' in args[0]
        assert 'proc' in args[0]

        if 'mount' in args[0]:
            raise TimeoutError("test timeout")

        return b'File System           1024-blocks     Used Available Capacity Mounted on\n\
/hurd/ext2fs             10485760    4748180   4737580    47% /', b'', 0

    collect = HurdHardwareCollector()
    facts = HurdHardware()
    facts.load_all_facts = True
    facts.run_command = test_run_command
    facts.populate()

# Generated at 2022-06-22 23:16:32.345263
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    a = HurdHardwareCollector()
    assert a._fact_class == HurdHardware
    assert a._platform == 'GNU'


# Generated at 2022-06-22 23:16:34.623162
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'



# Generated at 2022-06-22 23:16:35.069909
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result

# Generated at 2022-06-22 23:16:37.278359
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector(None, None)._platform == 'GNU'
    assert HurdHardwareCollector(None, None)._fact_class == HurdHardware


# Generated at 2022-06-22 23:16:48.883563
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Define the expected output
    expected_output = {
        'memfree_mb': 4,
        'memtotal_mb': 6,
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
        'uptime_seconds': 23
    }

    # Define a file system mount point
    mount_point = '/'

    # Define the get_mount_facts method mock
    def get_mount_facts_mock(self, mount_point):
        return {mount_point: {'uuid': '1', 'mount': '/'}}

    # Define a hard disk device
    device = '/dev/sda'

    # Define the get_disk_facts method mock

# Generated at 2022-06-22 23:16:49.933436
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()

# Generated at 2022-06-22 23:16:53.721634
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_coll = HurdHardwareCollector()
    assert HurdHardwareCollector._platform == 'GNU'
    assert hw_coll._fact_class == HurdHardware
    assert hw_coll._platform == 'GNU'

# Generated at 2022-06-22 23:16:55.220449
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()

    # assert that all the hardware class attributes are initialized
    assert hurd_hw.memory

# Generated at 2022-06-22 23:16:56.308953
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()

# Generated at 2022-06-22 23:16:58.400547
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    Hurd = HurdHardware()
    assert Hurd.platform == 'GNU'


# Generated at 2022-06-22 23:17:01.382007
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._fact_class.platform == 'GNU'
    assert hw._platform == 'GNU'

# Generated at 2022-06-22 23:17:04.805801
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    fact_class = HurdHardware()
    assert fact_class.__class__.__name__ == 'HurdHardware'


# Generated at 2022-06-22 23:17:11.550513
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert facts is not None
    assert 'uptime' in facts
    assert 'uptime_seconds' in facts
    assert 'memory_mb' in facts
    assert 'mounts' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'architecture' in facts
    assert 'distribution' in facts
    assert 'distribution_version' in facts
    assert 'distribution_release' in facts

# Generated at 2022-06-22 23:17:13.767665
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert 'mounts' in hardware_facts

# Generated at 2022-06-22 23:17:16.934635
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'
    assert hw.fact_class == HurdHardware


# Generated at 2022-06-22 23:17:19.588141
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector(None, None, None, None)
    assert fact_class._fact_class == HurdHardware
    assert fact_class._platform == 'GNU'


# Generated at 2022-06-22 23:17:22.568570
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_obj = HurdHardware()
    assert hardware_obj


# Generated at 2022-06-22 23:17:25.381289
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
  hwobj = HurdHardwareCollector()
  assert hwobj._fact_class == HurdHardware
  assert hwobj._platform == 'GNU'


# Generated at 2022-06-22 23:17:28.672650
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Create an instance of HurdHardware class.
    """
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

if __name__ == '__main__':
    test_HurdHardware()

# Generated at 2022-06-22 23:17:34.709207
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_string'].startswith('up')
    assert hardware_facts['connection'] == 'smart'
    assert hardware_facts['vendor'] == 'Free Software Foundation, Inc'

# Generated at 2022-06-22 23:17:36.766650
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert hh.platform == 'GNU'


# Generated at 2022-06-22 23:17:39.909336
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class is HurdHardware
    assert hhc._platform is 'GNU'
    assert hhc._collector is None

# Generated at 2022-06-22 23:17:43.060600
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {
        "ansible_os_family": "GNU",
        "ansible_distribution": "Hurd"
    }

    h = HurdHardware(collected_facts)
    h.populate()

# Generated at 2022-06-22 23:17:45.144140
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'


# Generated at 2022-06-22 23:17:49.296577
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test_obj = HurdHardware()
    assert test_obj.platform == 'GNU'
    assert isinstance(test_obj.mount_facts_command, list)
    assert isinstance(test_obj.uptime_facts_command, list)


# Generated at 2022-06-22 23:17:58.992413
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = dict()

    mock_module = MagicMock()
    mock_module.params = dict()
    mock_module.params['gather_mount_facts'] = True

    Hurd_unit_test = HurdHardware(mock_module)

    Hurd_unit_test.get_uptime_facts = MagicMock()
    Hurd_unit_test.get_memory_facts = MagicMock()
    Hurd_unit_test.get_mount_facts = MagicMock()

    expected_result = dict()
    expected_result.update(Hurd_unit_test.get_uptime_facts.return_value)
    expected_result.update(Hurd_unit_test.get_memory_facts.return_value)

# Generated at 2022-06-22 23:18:08.032054
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test get_uptime_facts(), get_memory_facts() and get_mount_facts()
    are called
    """
    m_uptime_facts = {}
    m_memory_facts = {}
    m_mount_facts = {}

    class TestHurdHardware(HurdHardware):

        def get_uptime_facts(self):
            return m_uptime_facts

        def get_memory_facts(self):
            return m_memory_facts

        def get_mount_facts(self):
            return m_mount_facts

    f = TestHurdHardware()
    result = f.populate()

    assert m_uptime_facts == result
    assert m_memory_facts == result
    assert m_mount_facts == result

# Generated at 2022-06-22 23:18:16.273170
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create a HurdHardware object
    hardware_facts = HurdHardware()

    # Make sure we have at least the following facts
    expected_facts = [
        'uptime_seconds',
        'uptime_hours',
        'uptime_days',
        'memtotal_mb',
        'memavailable_mb',
        'mounts'
    ]

    # Populate our HurdHardware object with gathered facts
    hardware_facts.populate()
    # Get a dict of facts from the HurdHardware object
    gathered_facts = hardware_facts.populate_dict()

    # Assert that all expected facts are in the gathered facts
    for fact in expected_facts:
        assert fact in gathered_facts

# Generated at 2022-06-22 23:18:23.093024
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hrddict = HurdHardware().populate()
    assert hrddict['uptime_seconds'].__class__ is int
    assert hrddict['uptime_seconds'] > 0
    assert hrddict['uptime_days'].__class__ is int
    assert hrddict['uptime_days'] > 0
    assert hrddict['uptime_hours'].__class__ is int
    assert hrddict['uptime_hours'] >= 0 and hrddict['uptime_hours'] < 24
    assert hrddict['uptime_minutes'].__class__ is int
    assert hrddict['uptime_minutes'] >= 0 and hrddict['uptime_minutes'] < 60
    assert hrddict['uptime_seconds'].__class__ is int
    assert hrddict['uptime_seconds'] >= 0

# Generated at 2022-06-22 23:18:30.990917
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_collector = HurdHardwareCollector(None)

    expected_hardware_facts = {
        'boot_time': 1534103008.0,
        'memfree_mb': 590,
        'memtotal_mb': 789,
        'mounts': '/dev/mapper/root-root on / type ext2fs (rw,noatime)',
        'swapfree_mb': 1992,
        'swaptotal_mb': 1992
    }

    actual_hardware_facts = hardware_collector.populate()

    assert actual_hardware_facts == expected_hardware_facts

# Generated at 2022-06-22 23:18:33.042860
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hhw = HurdHardware()
    assert hhw._platform == 'GNU'
    assert hhw.platform == 'GNU'
    assert isinstance(hhw.facts, dict)

# Generated at 2022-06-22 23:18:35.634550
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.collect()

# Generated at 2022-06-22 23:18:37.117506
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:18:38.500142
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw_test = HurdHardware()
    assert hurdhw_test is not None

# Generated at 2022-06-22 23:18:40.225051
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts_obj = HurdHardware()
    assert hardware_facts_obj


# Generated at 2022-06-22 23:18:41.922764
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hd = HurdHardware()

    assert hd.platform == 'GNU'



# Generated at 2022-06-22 23:18:44.267221
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Create an object of HurdHardwareCollector
    """
    hurd_hardware_obj = HurdHardwareCollector()
    assert isinstance(hurd_hardware_obj, HurdHardwareCollector)


# Generated at 2022-06-22 23:18:53.316669
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardwareCollector()

# Generated at 2022-06-22 23:18:58.481573
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.get_memory_facts() == {}
    assert hurd_hardware.get_uptime_facts() == {}

# Generated at 2022-06-22 23:19:06.647027
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    facts = hh.populate()
    # uname
    assert facts['distribution'] == 'GNU'
    # uptime
    assert 'uptime_seconds' in facts
    assert 'uptime_hours' in facts
    assert 'uptime_days' in facts
    assert 'uptime_long' in facts
    # memory
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    # mounts
    assert len(facts['mounts']) >= 1

# Generated at 2022-06-22 23:19:08.127856
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._platform == 'GNU'
    assert hhc._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:11.207018
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardware()
    populated_hardware_facts = hardware_obj.populate()

    assert populated_hardware_facts['uptime_seconds'] >= 0


# Generated at 2022-06-22 23:19:15.388889
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Call the constructor for HurdHardwareCollector
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'
    assert hw._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:18.571840
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    assert type(hurd_hw) == HurdHardware
    assert hurd_hw.platform == 'GNU'
    assert type(hurd_hw.populate()) == dict

# Generated at 2022-06-22 23:19:20.646233
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:22.177065
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:19:22.629151
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware()

# Generated at 2022-06-22 23:19:24.490337
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw is not None

# Generated at 2022-06-22 23:19:34.439295
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_os_family': 'GNU/Hurd'}
    base_facts = {'ansible_os_family': 'GNU/Hurd', 'ansible_architecture': 'x86_64'}

# Generated at 2022-06-22 23:19:36.164237
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_fact_collector = HurdHardwareCollector()
    assert hw_fact_collector._platform == 'GNU'
    assert isinstance(hw_fact_collector._fact_class(), HurdHardware)

# Generated at 2022-06-22 23:19:38.507923
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    ret = HurdHardware().populate()
    assert isinstance(ret, dict)


# Generated at 2022-06-22 23:19:41.363363
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector(None)
    assert isinstance(hw._fact_class, HurdHardware)
    assert hw._platform == 'GNU'


# Generated at 2022-06-22 23:19:42.830483
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd = HurdHardwareCollector()
    assert(hurd._platform == "GNU")

# Generated at 2022-06-22 23:19:45.027751
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h_facts = HurdHardware()
    assert isinstance(h_facts, HurdHardware)
    assert h_facts.platform == 'GNU'

# Generated at 2022-06-22 23:19:47.226646
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test_hardware = HurdHardware()
    assert test_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:19:49.505725
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class == HurdHardware
    assert hhc._platform == 'GNU'

# Generated at 2022-06-22 23:19:53.048041
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhd = HurdHardwareCollector()
    assert type(hhd).__name__ == 'HurdHardwareCollector'

# Unit tests for constructor of class HurdHardware

# Generated at 2022-06-22 23:20:03.671552
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-22 23:20:04.496753
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    a = HurdHardware()

# Generated at 2022-06-22 23:20:08.644813
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()

    assert obj._fact_class is HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:20:14.281789
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    assert isinstance(HurdHardware().populate(), dict)
    # override the default platform string
    LinuxHardware._platform = 'Hurd'
    assert isinstance(HurdHardware().populate(), dict)


# Generated at 2022-06-22 23:20:16.533512
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware(None)
    assert hardware.platform == 'GNU'


# Generated at 2022-06-22 23:20:22.402998
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Basic unit test for method populate of class HurdHardware
    """
    HurdHardware = HurdHardwareCollector._fact_class
    hardware = HurdHardware()

    systems = ['GNU/Hurd', 'GNU/kFreeBSD']

    for system in systems:
        if system in hardware.distribution:
            return True

    raise AssertionError("System is not GNU based")

# Generated at 2022-06-22 23:20:25.221088
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhcobj = HurdHardwareCollector()
    assert hhcobj._platform == 'GNU'
    assert hhcobj._fact_class.__name__ == 'HurdHardware'

# Generated at 2022-06-22 23:20:28.940609
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    result = hurd_hw.populate()

    assert isinstance(result, dict)
    assert 'uptime' in result
    assert 'uptime_seconds' in result
    assert 'memtotal_mb' in result
    assert 'mounts' in result

# Generated at 2022-06-22 23:20:32.172908
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()

    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'



# Generated at 2022-06-22 23:20:34.322953
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    if not HurdHardwareCollector.detect():
        return

    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-22 23:20:40.370485
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] is not None
    assert hardware_facts['uptime_hours'] is not None
    assert hardware_facts['uptime_days'] is not None
    assert hardware_facts['mounts'] is not None
    assert hardware_facts['memtotal_mb'] is not None
    assert hardware_facts['memfree_mb'] is not None
    assert hardware_facts['swaptotal_mb'] is not None
    assert hardware_facts['swapfree_mb'] is not None

# Generated at 2022-06-22 23:20:50.897877
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-22 23:20:56.484478
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate()['uptime_seconds'] != None
    assert hurd_hardware.populate()['uptime_days'] != None

# Test if class HurdHardwareCollector is a subclass of HardwareCollector

# Generated at 2022-06-22 23:21:03.147507
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Testing report of bug #35057
    # https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=35057
    hardware = HurdHardware()
    hardware_facts = hardware.populate()['local']['hardware']
    assert hardware_facts['ram'] == 0
    assert hardware_facts['swap'] == 0
    assert hardware_facts['uptime']['seconds'] == 0

# Generated at 2022-06-22 23:21:06.630540
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hasattr(hurd, '_platform')
    assert hasattr(hurd, 'file_cache')
    assert hasattr(hurd, 'platform')
    assert hasattr(hurd, 'facts')


# Generated at 2022-06-22 23:21:09.914366
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Testing method populate of class HurdHardware
    """
    #Testing with non-Linux OS
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'
    #Testing with Linux OS
    assert HurdHardware('Linux').platform != 'GNU'

# Generated at 2022-06-22 23:21:14.227905
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware(None)
    # Test with valid input
    hardware.get_mount_facts = lambda: {'mounts': []}
    hardware.get_memory_facts = lambda: {'memtotal_mb': 16384}
    hardware.get_uptime_facts = lambda: {'uptime_seconds': 15}
    hardware_facts = hardware.populate()
    assert hardware_facts == {'mounts': [], 'memtotal_mb': 16384, 'uptime_seconds': 15}

# Generated at 2022-06-22 23:21:15.738374
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HurdHardware()


# Generated at 2022-06-22 23:21:24.969233
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-22 23:21:26.456560
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware


# Generated at 2022-06-22 23:21:36.050742
# Unit test for method populate of class HurdHardware

# Generated at 2022-06-22 23:21:38.148651
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collect_obj = HurdHardwareCollector()
    assert collect_obj._fact_class == HurdHardware
    assert collect_obj._platform == 'GNU'

# Generated at 2022-06-22 23:21:50.080223
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Method test_HurdHardware_populate tests the populate()-method
    of class HurdHardware. The method tests whether a dictionary listing
    facts about a GNU Hurd system is returned.
    """

    def mock_get_mount_facts(self):
        """
        Mock method for get_mount_facts()-method of class HurdHardware.
        The method returns the expected dictionary mount_facts.
        """

# Generated at 2022-06-22 23:21:51.469568
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert isinstance(obj, HurdHardware)

# Generated at 2022-06-22 23:21:52.768128
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.uptime


# Generated at 2022-06-22 23:21:54.097871
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc is not None

# Generated at 2022-06-22 23:21:57.691816
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'
    assert hurdhw.plugin == 'HurdHardware'
    assert hurdhw.req_platform == 'GNU'
    assert hurdhw.req_version is None

# Generated at 2022-06-22 23:22:09.055661
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_mock = HurdHardware()
    MockedHurdHardware = type('MockedHurdHardware', (HurdHardware, ), {'get_uptime_facts': lambda x: {'uptime_seconds': 60},
                                                                       'get_memory_facts': lambda x: {'ansible_memtotal_mb': 100},
                                                                       'get_mount_facts': lambda x: {'mounts': [{'size_total': 50}]}})
    mocked_hurd_facts = MockedHurdHardware()
    collected_facts = mocked_hurd_facts.populate()
    assert collected_facts['ansible_memtotal_mb'] == 100
    assert collected_facts['uptime_seconds'] == 60
    assert collected_facts['mounts'][0]['size_total'] == 50

# Unit test

# Generated at 2022-06-22 23:22:10.607501
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Method populate needs to be unit tested.
    :return:
    """
    pass

# Generated at 2022-06-22 23:22:11.967162
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == "GNU"

# Generated at 2022-06-22 23:22:16.249885
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert issubclass(HurdHardwareCollector._fact_class, LinuxHardware)
    assert HurdHardwareCollector._fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:22:21.512108
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h._platform == 'Linux'
    assert h._mount_info_file == '/proc/mounts'
    assert h._uptime_file == '/proc/uptime'
    assert h._sysctl_mib == ['kernel', 'ostype', 'osrelease', 'version', 'hostname', 'domainname', 'machine']

# Generated at 2022-06-22 23:22:24.246602
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Constructor of class HurdHardware should create
    an object of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)

# Generated at 2022-06-22 23:22:27.342694
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

    assert hw.uptime['seconds'] > 0

    assert hw.memory['MemTotal'] > 0
    assert hw.memory['SwapTotal'] >= 0

    assert hw.mounts
    assert hw.mounts[0]['device'] != ""

# Generated at 2022-06-22 23:22:34.242524
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    m_open_reader = m_HurdHardware.get_uptime_facts.return_value = {}
    m_HurdHardware.get_memory_facts.return_value = {}
    m_HurdHardware.get_mount_facts.return_value = {}
    _HurdHardware = HurdHardware()
    _HurdHardware.populate()
    assert m_HurdHardware.get_uptime_facts.called
    assert m_HurdHardware.get_memory_facts.called
    assert m_HurdHardware.get_mount_facts.called

# Generated at 2022-06-22 23:22:38.088199
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] > 0

# Generated at 2022-06-22 23:22:39.664466
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj is not None

# Generated at 2022-06-22 23:22:41.748701
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw_facts = HurdHardware()
    assert(hurd_hw_facts.platform == 'GNU')


# Generated at 2022-06-22 23:22:43.606405
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert isinstance(hurd, HurdHardware)
    assert isinstance(hurd, LinuxHardware)



# Generated at 2022-06-22 23:22:45.700890
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert isinstance(obj, HardwareCollector)


# Generated at 2022-06-22 23:22:49.206431
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_class = HurdHardwareCollector._fact_class
    m = fact_class()
    assert(m.platform == 'GNU')


# Generated at 2022-06-22 23:22:51.003496
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hd_collector = HurdHardwareCollector()
    assert hd_collector is not None


# Generated at 2022-06-22 23:22:52.784754
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc is not None

# Generated at 2022-06-22 23:23:04.466857
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Create a HurdHardware object
    #
    file_content = {}
    mountinfo = """/dev/sda on / type ext2 (rw,relatime)
    /dev/sda on /var type ext2 (rw,relatime)
    """
    file_content['mountinfo'] = mountinfo
    file_content['uptime'] = '12345678\n'
    file_content['meminfo'] = """MemTotal:        3878276 kB
    MemFree:          988016 kB
    Buffers:          590160 kB
    Cached:           130668 kB
    """


# Generated at 2022-06-22 23:23:06.649891
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert isinstance(hw, HurdHardware)
    assert isinstance(hw, LinuxHardware)
    assert isinstance(hw, HardwareCollector)

# Generated at 2022-06-22 23:23:08.968668
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)


# Generated at 2022-06-22 23:23:17.382677
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from mock import MagicMock
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    hurdhw = HurdHardware()
    hurdhw.get_uptime_facts = MagicMock(return_value={'uptime_seconds': '42'})
    hurdhw.get_memory_facts = MagicMock(return_value={'memtotal_mb': '42'})
    hurdhw.get_mount_facts = MagicMock(side_effect=TimeoutError)
    assert hurdhw.populate() == {'uptime_seconds': '42', 'memtotal_mb': '42'}


# Generated at 2022-06-22 23:23:20.025213
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    ## Not sure how to unit test populate without possibly breaking user's machine
    assert True

# Generated at 2022-06-22 23:23:22.410237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdHardware = HurdHardware()
    assert isinstance(hurdHardware.populate(), dict)

# Generated at 2022-06-22 23:23:24.925518
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HardwareCollector)
    assert isinstance(h, HurdHardware)


# Generated at 2022-06-22 23:23:25.968697
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)

# Generated at 2022-06-22 23:23:38.071753
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class HurdHardwareCollectorMock(HurdHardwareCollector):
        def __init__(self, *args, **kwargs):
            self.uptime_facts = { 'uptime_seconds': 100 }
            self.memory_facts = { 'memtotal_mb': 100 }

        def get_uptime_facts(self):
            return self.uptime_facts

        def get_memory_facts(self):
            return self.memory_facts

        def get_mount_facts(self):
            return { 'devices': {}, 'mounts': [] }

    # Test when get_mount_facts is available
    hurd_facts = HurdHardwareCollectorMock().populate()
    assert hurd_facts['uptime_seconds'] == 100
    assert hurd_facts['memtotal_mb'] == 100

    # Test when get_mount_

# Generated at 2022-06-22 23:23:43.139025
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    oHurdHardware = HurdHardware()
    oHurdHardware.populate()
    assert oHurdHardware.uptime == {'days': 0, 'hours': 0, 'seconds': 0, 'minutes': 0}, "Hurd uptime facts should be 0"


test_HurdHardware()

# Generated at 2022-06-22 23:23:43.960565
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()


# Generated at 2022-06-22 23:23:47.591841
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an instance of HurdHardware class
    hardware_object = HurdHardware()

    # Assert that the populate method returns a dictionary
    assert isinstance(hardware_object.populate(), dict)

# Generated at 2022-06-22 23:23:50.491832
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw = HurdHardwareCollector()
    assert hurd_hw.fact_class is HurdHardware
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-22 23:23:57.806225
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    # create fake procfs directories and files
    monkeypatch.setattr(
        hardware, '_mount_info_path',
        '/proc/mounts',
    )

    # mock /proc/uptime
    monkeypatch.setattr(
        hardware, '_uptime_path',
        '/proc/uptime',
    )

    monkeypatch.setattr(
        hardware, '_uptime_path',
        '/proc/uptime',
    )

    # mock /proc/meminfo
    monkeypatch.setattr(
        hardware, '_meminfo_path',
        '/proc/meminfo',
    )

    # mock Popen

# Generated at 2022-06-22 23:24:00.416146
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHW = HurdHardware()
    hw_facts = HurdHW.populate()
    assert hw_facts is not None

# Generated at 2022-06-22 23:24:02.907471
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._platform == 'GNU'
    assert hw._fact_class == HurdHardware

# Generated at 2022-06-22 23:24:05.715279
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None
    assert hurd_hardware.populate() is not None


# Generated at 2022-06-22 23:24:08.404431
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:24:11.020540
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result.hardware._fact_class == HurdHardware
    assert result.hardware._platform == 'GNU'

# Generated at 2022-06-22 23:24:13.816177
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware({'device_paths': '/dev', 'device_mount': '/dev'})
    assert hurd



# Generated at 2022-06-22 23:24:14.760858
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:24:16.665607
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'
    assert h.fact_class == HurdHardware

# Generated at 2022-06-22 23:24:18.593333
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    result = hurd.populate()
    assert isinstance(result, dict)

# Generated at 2022-06-22 23:24:27.448594
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Python2.7 API compat
    try:
        assertRaisesRegex = getattr(TestCase, 'assertRaisesRegex')
    except AttributeError:
        assertRaisesRegex = getattr(TestCase, 'assertRaisesRegexp')

    # Test unsupported platform
    with assertRaisesRegex(UnsupportedPlatform, "^GNU/Hurd not supported yet$"):
        hardware = HurdHardware("GNU/Hurd")
        del hardware

    # Test unsupported platform
    with assertRaisesRegex(UnsupportedPlatform, "^darwin not supported yet$"):
        hardware = HurdHardware("darwin")
        del hardware

# Generated at 2022-06-22 23:24:30.837402
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class._platform == 'GNU'


if __name__ == '__main__':
    test_HurdHardwareCollector()

# Generated at 2022-06-22 23:24:40.366120
# Unit test for method populate of class HurdHardware