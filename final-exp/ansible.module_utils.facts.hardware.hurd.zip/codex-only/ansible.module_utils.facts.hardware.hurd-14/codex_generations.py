

# Generated at 2022-06-22 23:14:35.662516
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result._fact_class == HurdHardware
    assert result._platform == 'GNU'

# Generated at 2022-06-22 23:14:36.444090
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()

# Generated at 2022-06-22 23:14:39.659384
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'
    assert hardware.collector is None


# Generated at 2022-06-22 23:14:42.738908
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'


# Generated at 2022-06-22 23:14:50.073013
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw._platform == 'GNU'
    assert hurd_hw._fact_class == HurdHardware
    assert hurd_hw._fact_methods == {
        'uptime': hurd_hw.get_uptime_facts,
        'memory': hurd_hw.get_memory_facts,
        'mounts': hurd_hw.get_mount_facts,
    }

    assert hurd_hw.get_mount_facts()['mounts']['none']['device'] == 'none'
    assert hurd_hw.get_mount_facts()['mounts']['none']['filesystem'] == 'none'

# Generated at 2022-06-22 23:14:52.155164
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    result = HurdHardwareCollector()
    assert result.platform == 'GNU'

# Generated at 2022-06-22 23:14:52.730122
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-22 23:14:55.869990
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector._platform = 'GNU'
    hardware = HurdHardwareCollector()
    assert hardware._fact_class._platform == 'GNU'
    assert hardware._platform == 'GNU'


# Generated at 2022-06-22 23:14:56.954776
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == "GNU"


# Generated at 2022-06-22 23:14:58.937086
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'


# Generated at 2022-06-22 23:15:02.591776
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'
    assert not hurd_hw.uptime_facts
    assert not hurd_hw.memory_facts
    assert not hurd_hw.mount_facts


# Generated at 2022-06-22 23:15:07.948528
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    facts = hurdhw.populate()

    assert set(facts.keys()) == {'system_uptime', 'system_memory', 'mounts'}
    assert facts['system_uptime']['seconds'] > 0
    assert facts['system_memory']['total_mb'] > 0
    assert len(facts['mounts']) > 0

# Generated at 2022-06-22 23:15:09.776773
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_obj = HurdHardware()
    assert hurd_hardware_obj.platform == 'GNU'
    assert hurd_hardware_obj

# Generated at 2022-06-22 23:15:20.953901
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {}
    collected_facts['virtualization_type'] = 'Hurd'
    hardware_fact = HurdHardware(collected_facts)
    hardware_facts = hardware_fact.populate()


# Generated at 2022-06-22 23:15:26.512409
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert isinstance(hurd, HurdHardware)
    assert isinstance(hurd.uptime_facts, dict)
    assert isinstance(hurd.memory_facts, dict)
    assert isinstance(hurd.mount_facts, dict)
    hurd.uptime_facts = {}
    hurd.memory_facts = {}
    hurd.mount_facts = {}

# Generated at 2022-06-22 23:15:30.192619
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    hw = HurdHardware(facts, None)

    hw.populate()

    # The mock_fact_retriever object does not support fact retrieval
    # and therefore returns an empty dict.

    assert facts == {}

# Generated at 2022-06-22 23:15:31.558526
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()


# Generated at 2022-06-22 23:15:37.401752
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    assert isinstance(facts, HardwareCollector)
    assert isinstance(facts, HurdHardware)
    assert hasattr(facts, "get_uptime_facts")
    assert hasattr(facts, "get_memory_facts")
    assert hasattr(facts, "get_mount_facts")
    assert hasattr(facts, "populate")

# Generated at 2022-06-22 23:15:38.961971
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)

# Generated at 2022-06-22 23:15:40.734820
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdhw = HurdHardwareCollector()
    assert isinstance (hurdhw, HardwareCollector)

# Generated at 2022-06-22 23:15:42.242159
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:15:44.566338
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc._platform == 'GNU'
    assert hwc._fact_class == HurdHardware

# Generated at 2022-06-22 23:15:50.166435
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    hurd_fact_collector = HurdHardware()


# Unit test of class HurdHardwareCollector

# Generated at 2022-06-22 23:15:55.093704
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_1 = HurdHardwareCollector()
    assert hw_1
    assert hw_1._fact_class == HurdHardware
    assert hw_1._platform == 'GNU'
    assert hw_1._config_file == '/etc/ansible/facts.d/hardware.fact'


# Generated at 2022-06-22 23:15:58.355044
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Test constructor of class HurdHardwareCollector.
    """
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._fact_class == HurdHardware
    assert hurd_hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:16:01.097840
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert isinstance(hurd, HurdHardware)
    assert hurd.platform == 'GNU'

# Generated at 2022-06-22 23:16:06.699992
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert 'uptime' in hurd_hw.hw_facts
    assert 'memfree_mb' in hurd_hw.hw_facts
    assert 'swapfree_mb' in hurd_hw.hw_facts
    assert 'mounts' in hurd_hw.hw_facts

# Generated at 2022-06-22 23:16:13.720924
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()

    collected_facts = {'kernel': 'GNU'}
    populated_facts = hh.populate(collected_facts)

    assert 'uptime' in populated_facts
    assert 'uptime_seconds' in populated_facts
    assert 'uptime_hours' in populated_facts
    assert 'uptime_days' in populated_facts
    assert 'memfree_mb' in populated_facts
    assert 'memtotal_mb' in populated_facts
    assert 'swapfree_mb' in populated_facts
    assert 'swaptotal_mb' in populated_facts

# Generated at 2022-06-22 23:16:16.788568
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'


# Generated at 2022-06-22 23:16:18.088079
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hf = HurdHardware()
    assert hf._platform == 'GNU'

# Generated at 2022-06-22 23:16:20.192651
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._fact_class == HurdHardware
    assert hw._platform == 'GNU'


# Generated at 2022-06-22 23:16:22.486493
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    c = HurdHardwareCollector()
    assert c.platform == 'GNU'

# Generated at 2022-06-22 23:16:23.968029
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()
    assert hurdHardware.platform == 'GNU'

# Generated at 2022-06-22 23:16:28.522143
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    fact_class = HurdHardware()
    assert fact_class.platform == 'GNU'
    # TODO: extend test case


# Generated at 2022-06-22 23:16:30.683822
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    collected_facts = {}
    assert type(hurdhw.populate()) is dict

# Generated at 2022-06-22 23:16:32.340628
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert isinstance(HurdHardware(None, None), HurdHardware)

# Generated at 2022-06-22 23:16:33.910794
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
   hurd_hardware = HurdHardware()
   hurd_hardware.populate()

# Generated at 2022-06-22 23:16:35.579490
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == "GNU"

# Generated at 2022-06-22 23:16:36.785591
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector

# Generated at 2022-06-22 23:16:43.617320
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware_facts = hurd_hardware.populate()
    assert hurd_hardware_facts['uptime_seconds'] > 0
    assert isinstance(hurd_hardware_facts['memfree_mb'], int)
    assert isinstance(hurd_hardware_facts['memtotal_mb'], int)

# Generated at 2022-06-22 23:16:48.193539
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    method_to_test = 'ansible.module_utils.facts.hardware.hurd.HurdHardware.populate'
    hurd_hw_instance = HurdHardware()
    assert(method_to_test == hurd_hw_instance.__module__ + '.' + hurd_hw_instance.__class__.__name__ + '.' + 'populate')


# Generated at 2022-06-22 23:16:50.927024
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdHardwareCollector = HurdHardwareCollector()
    assert(hurdHardwareCollector._fact_class == HurdHardware)
    assert(hurdHardwareCollector._platform == 'GNU')

# Generated at 2022-06-22 23:16:59.736358
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] >= 0
    assert hardware_facts['uptime_hours'] >= 0 and hardware_facts['uptime_hours'] <= 24
    assert hardware_facts['uptime_minutes'] >= 0 and hardware_facts['uptime_minutes'] <= 59
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['swap']['total'] >= 0
    assert hardware_facts['humandate'] is not None

# Generated at 2022-06-22 23:17:09.292717
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import os
    import json

    path = os.path.dirname(os.path.realpath(__file__)) + '\test_data\Hurd'
    with open(path + '\test_HurdHardware_populate_output.json', 'r') as file:
        output = json.load(file)

    hardware = HurdHardware()
    hardware._get_uptime = lambda: output['_get_uptime']
    hardware._procmeminfo = lambda: output['_procmeminfo']
    hardware._get_mount_facts = lambda: output['_get_mount_facts']

    assert hardware.populate() == output['_facts']


# Generated at 2022-06-22 23:17:17.300015
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    hw = h.populate()
    assert hw['uptime_seconds'] is not None
    assert hw['uptime_seconds'] > 0
    assert hw['memory_mb']['real']['total'] > 0
    assert hw['memory_mb']['real']['available'] > 0
    assert hw['memory_mb']['real']['used'] > 0
    assert hw['mounts'] is not None

# Generated at 2022-06-22 23:17:19.044529
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:17:27.518587
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    fact = {}
    fact = hurd.populate(fact)

    assert 'uptime' in fact
    assert 'uptime_seconds' in fact
    assert 'memory_mb' in fact
    assert 'memory_mb_raw' in fact
    assert 'swapfree_mb' in fact
    assert 'swapfree_mb_raw' in fact
    assert 'swaptotal_mb' in fact
    assert 'swaptotal_mb_raw' in fact
    assert 'mounts' in fact

# Generated at 2022-06-22 23:17:29.449867
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class == HurdHardware
    assert obj._platform == "GNU"

# Generated at 2022-06-22 23:17:34.814148
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts.get('mounts', None) is not None
    assert hardware_facts.get('memory', None) is not None
    assert hardware_facts.get('uptime', None) is not None

# Generated at 2022-06-22 23:17:37.649693
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    ip = HurdHardware()
    assert isinstance(ip, HurdHardware)
    assert isinstance(ip, LinuxHardware)
    assert isinstance(ip, HardwareCollector)

# Generated at 2022-06-22 23:17:39.411869
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    instance = collector._get_instance()
    assert isinstance(instance, HurdHardware)

# Generated at 2022-06-22 23:17:42.320362
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw_collector = HurdHardwareCollector()
    assert hurd_hw_collector._platform == 'GNU'
    assert hurd_hw_collector._fact_class is HurdHardware

# Generated at 2022-06-22 23:17:45.291428
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware


# Generated at 2022-06-22 23:17:47.515681
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:17:50.216736
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector('GNU')
    assert not hhc.has_current
    assert 'GNU' == hhc._platform
    assert not hhc.has_previous
    assert hhc._fact_class

# Generated at 2022-06-22 23:17:51.930706
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-22 23:17:52.964753
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

# Generated at 2022-06-22 23:18:00.746921
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module = AnsibleModule(dict(ANSIBLE_MODULE_ARGS={}))

    hurd_hw = HurdHardware()
    hurd_hw.get_uptime_facts = MagicMock(name="get_uptime_facts")
    hurd_hw.get_memory_facts = MagicMock(name="get_memory_facts")
    hurd_hw.get_mount_facts = MagicMock(name="get_mount_facts")

    hurd_hw.populate()

    hurd_hw.get_uptime_facts.assert_called_once_with()
    hurd_hw.get_memory_facts.assert_called_once_with()
    hurd_hw.get_mount_facts.assert_called_once_with()

if __name__ == '__main__':
    from ansible.module_utils.facts import ans

# Generated at 2022-06-22 23:18:02.494918
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    x = HurdHardware()
    # assert x.__class__ is HurdHardware
    # assert x.platform is 'GNU'
    assert x.facts == {}


# Generated at 2022-06-22 23:18:11.038767
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()

    # Verify kernel_name
    assert facts["kernel_name"] == HurdHardware().platform

    # Verify uptime_*
    assert isinstance(facts["uptime_seconds"], int) and facts["uptime_seconds"] >= 0
    assert facts["uptime_hours"] >= 0
    assert facts["uptime_days"] >= 0

    # Verify memory_mb == meminfo_*['MemTotal'] == meminfo_*['SwapTotal']
    assert facts["memory_mb"] == facts["meminfo_MemTotal"]
    assert facts["memory_mb"] == facts["meminfo_SwapTotal"]



# Generated at 2022-06-22 23:18:12.489587
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhardware = HurdHardware()
    assert hurdhardware.platform == 'GNU'

# Generated at 2022-06-22 23:18:14.628177
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware(module=None)
    assert isinstance(hw, HurdHardware)
    assert isinstance(hw, LinuxHardware)


# Generated at 2022-06-22 23:18:17.701108
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdhardwarecollector = HurdHardwareCollector()
    assert hurdhardwarecollector is not None

# Generated at 2022-06-22 23:18:19.507436
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware('*')
    d = h.populate()
    assert isinstance(d, dict)

# Generated at 2022-06-22 23:18:21.563251
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._fact_class == HurdHardware
    assert hc._platform == 'GNU'

# Generated at 2022-06-22 23:18:22.989956
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:18:24.423261
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert hurd_hardware

# Generated at 2022-06-22 23:18:33.766454
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from pprint import pprint

    # unittest/case.py doesn't support patching class attributes, so we
    # patch the module atribute instead.
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    original_get_mount_facts = HurdHardware.get_mount_facts
    HurdHardware.get_mount_facts = lambda _: {'mounts': 'abcdef'}

    h = HurdHardware()

    try:
        facts = h.populate()
    finally:
        HurdHardware.get_mount_facts = original_get_mount_facts

    pprint(facts)

    assert facts['memory_mb']['real']['total'] > 0
    assert facts['uptime_seconds'] > 0
    assert facts['mounts'] == 'abcdef'

# Generated at 2022-06-22 23:18:35.023582
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware().populate()

# Generated at 2022-06-22 23:18:38.500079
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdHardware = HurdHardware()
    collected_facts = {}

    # check that collected_facts is not modified when an error occurs
    hurdHardware.populate(collected_facts)
    assert collected_facts == {}

# Generated at 2022-06-22 23:18:39.152185
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw_ins = HurdHardware()
    assert hw_ins.populate()

# Generated at 2022-06-22 23:18:48.335455
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    collected_facts = { HardwareCollector.COLLECTED_KEY: {}}
    facts_dict = h.populate(collected_facts=collected_facts)

    assert 'uptime_seconds' in facts_dict.keys()
    assert 'uptime_hours' in facts_dict.keys()
    assert 'uptime_days' in facts_dict.keys()
    assert 'memfree_mb' in facts_dict.keys()
    assert 'memtotal_mb' in facts_dict.keys()
    assert 'swapfree_mb' in facts_dict.keys()
    assert 'swaptotal_mb' in facts_dict.keys()

# Generated at 2022-06-22 23:18:52.039113
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert isinstance(hc, HardwareCollector)
    assert issubclass(HurdHardwareCollector._fact_class, HardwareCollector)
    assert HurdHardwareCollector._fact_class.platform == 'GNU'
    assert HurdHardwareCollector._platform == 'GNU'


# Generated at 2022-06-22 23:18:55.136089
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.uptime, dict)
    assert isinstance(hurd_hardware.memory, dict)
    assert isinstance(hurd_hardware.mount, dict)

# Generated at 2022-06-22 23:18:58.211036
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-22 23:19:07.325838
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    facts = hh.populate()

    assert 'uptime' in facts
    assert 'kernel' in facts
    assert 'uptime_seconds' in facts
    assert 'users' in facts
    assert 'memfacts' in facts

    assert 'swapfree_mb' in facts['memfacts']
    assert 'memfree_mb' in facts['memfacts']
    assert 'memtotal_mb' in facts['memfacts']
    assert 'swaptotal_mb' in facts['memfacts']
    assert 'swapfree' in facts['memfacts']
    assert 'memfree' in facts['memfacts']
    assert 'memtotal' in facts['memfacts']
    assert 'swaptotal' in facts['memfacts']

# Generated at 2022-06-22 23:19:18.764865
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {'ansible_processor_cores': 4,
                        'ansible_processor_vcpus': 4,
                        'ansible_processor_threads_per_core': 1,
                        'ansible_memtotal_mb': 1,
                        'ansible_mounts': [{'mount': '/foo', 'device': '/dev'}],
                        'ansible_proc_uptime': 54,
                        'ansible_uptime_seconds': 60}
    result = hurd_hardware.populate()
    assert collected_facts['ansible_processor_cores'] == result['ansible_processor_cores']
    assert collected_facts['ansible_processor_vcpus'] == result['ansible_processor_vcpus']

# Generated at 2022-06-22 23:19:24.206311
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    path = os.path.dirname(os.path.realpath(__file__))
    procfs_root = path + '/proc'
    sysfs_root = path + '/sys'
    os.environ['HURD_TEST_PROCFS_ROOT'] = procfs_root
    os.environ['HURD_TEST_SYSFS_ROOT'] = sysfs_root
    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-22 23:19:29.478197
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.uptime == 0
    assert hardware.mounts == []
    assert hardware.memory == {'MemTotal': 0, 'MemFree': 0}
    assert hardware.swap == {'SwapTotal': 0, 'SwapFree': 0}


# Generated at 2022-06-22 23:19:30.903390
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert isinstance(hardware, LinuxHardware)

# Generated at 2022-06-22 23:19:44.278096
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Mock get_uptime_facts to return test values
    def mock_get_uptime_facts():
        test_uptime_facts = {'uptime_seconds': 12345678, 'uptime_hours': 3429, 'uptime_days': 143}
        return test_uptime_facts

    # Mock get_memory_facts to return test values
    def mock_get_memory_facts():
        test_memory_facts = {'memfree_mb': 2264, 'memtotal_mb': 16384}
        return test_memory_facts

    # Mock get_mount_facts to return test values
    def mock_get_mount_facts():
        test_mount_facts = {'/': {'device': '/dev/hd0s1', 'filesystem': 'ext2'}}
        return test_mount_facts

    # Mock upt

# Generated at 2022-06-22 23:19:47.335173
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    import os
    os.environ['PATH'] = ''
    h = HurdHardwareCollector()
    assert h._platform == 'GNU'


# Generated at 2022-06-22 23:19:49.199921
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()

    assert h.platform == 'GNU'


# Generated at 2022-06-22 23:19:51.224288
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:54.644097
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert HurdHardwareCollector._fact_class is HurdHardware
    assert HurdHardwareCollector._platform is 'GNU'


# Generated at 2022-06-22 23:20:00.292970
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    result = hardware_facts.populate()

    expected_keys = set(['uptime_seconds', 'uptime_hours', 'uptime_days',
                         'memfree_mb', 'memtotal_mb', 'swapfree_mb',
                         'swaptotal_mb'])
    assert set(result.keys()).issuperset(expected_keys), "Failed to collect expected keys"

# Generated at 2022-06-22 23:20:03.253846
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # this is more a test for the test than for HurdHardware
    hurd = HurdHardware()
    assert isinstance(hurd.populate(), dict)

# Generated at 2022-06-22 23:20:05.342077
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._platform == 'GNU'
    assert hw_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:20:10.637115
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Create class instance.
    module = HurdHardwareCollector()

    # Check type of instance.
    assert isinstance(module, HurdHardwareCollector)

    # Check inherited functions.
    assert callable(module.collect)



# Generated at 2022-06-22 23:20:14.065676
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from collections import namedtuple
    collected_facts = namedtuple('collected_facts', 'default')({
        'ansible_facts': {
            'distribution': 'GNU',
            'distribution_version': '0.2',
        },
    })
    collector = HurdHardwareCollector(collected_facts)
    hardware = collector.collect()

    expected_mount_facts = {'mounts': []}
    assert hardware['ansible_mounts'] == expected_mount_facts
    assert hardware['ansible_uptime_seconds'] > 0
    assert hardware['ansible_total_mem'] > 0

# Generated at 2022-06-22 23:20:18.522376
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_facts': {'os_family': 'GNU'}}
    hw = HurdHardware(collected_facts)
    hw.populate()
    assert isinstance(hw.memory, dict)
    assert isinstance(hw.mount, dict)

# Generated at 2022-06-22 23:20:20.884852
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert isinstance(facts, dict)
    assert 'memory' in facts
    assert 'mounts' in facts

# Generated at 2022-06-22 23:20:23.577418
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-22 23:20:25.656089
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware

# Generated at 2022-06-22 23:20:36.515571
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    # Mock function get_mount_facts
    def get_mount_facts():
        return {'mounts': []}
    hw.get_mount_facts = get_mount_facts
    # Mock function get_uptime_facts
    def get_uptime_facts():
        return {'uptime_seconds': 0, 'uptime_hours': 0, 'uptime_days': 0}
    hw.get_uptime_facts = get_uptime_facts
    # Mock function get_memory_facts
    def get_memory_facts():
        return {'memtotal': 0}
    hw.get_memory_facts = get_memory_facts
    # Execute function populate
    hw.populate()
    assert hw.facts['uptime_seconds'] == 0
    assert h

# Generated at 2022-06-22 23:20:40.010686
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()

    # Verify _fact_class is properly set
    assert hc._fact_class == HurdHardware
    # Verify _platform is properly set
    assert hc._platform == 'GNU'

# Generated at 2022-06-22 23:20:42.195469
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class is HurdHardware
    assert hw_collector._platform is 'GNU'

# Generated at 2022-06-22 23:20:49.136680
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_collector = HurdHardwareCollector()
    fact_collector._platform = 'GNU'
    collected_facts = {}
    fact_collector.populate(collected_facts)
    assert collected_facts['uptime_seconds'] >= 0
    assert collected_facts['uptime_days'] >= 0
    assert collected_facts['uptime_hours'] >= 0
    assert collected_facts['uptime_minutes'] >= 0

# Generated at 2022-06-22 23:20:51.484361
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    returned_facts_dict = hurd_hw.populate()
    assert returned_facts_dict.has_key('mounts'), "Facts should contain 'mounts'"


# Generated at 2022-06-22 23:21:00.321362
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.get_uptime_facts = lambda: {'uptime_seconds': 0}
    hurd_hw.get_memory_facts = lambda: {'memfree_mb': 0, 'memtotal_mb': 0}
    hurd_hw.get_mount_facts = lambda: {'mounts': [{'mount': 'tmpfs', 'device': 'tmpfs'}]}
    expected_result = {'uptime_seconds': 0, 'memfree_mb': 0, 'memtotal_mb': 0, 'mounts': [{'mount': 'tmpfs', 'device': 'tmpfs'}]}
    assert expected_result == hurd_hw.populate()

# Generated at 2022-06-22 23:21:03.975711
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware(None)

    assert isinstance(hurd, HurdHardware)
    assert isinstance(hurd, LinuxHardware)
    assert isinstance(hurd, HardwareCollector)
    assert hurd.sysctl_path == '/dev/pts/2'

# Generated at 2022-06-22 23:21:06.464570
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._fact_class == HurdHardware
    assert hardware_collector._platform == 'GNU'


# Generated at 2022-06-22 23:21:08.027779
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:21:09.628164
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:21:11.385343
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert (facts['ansible_processor_arch'])

# Generated at 2022-06-22 23:21:13.550165
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware_obj = HurdHardware()
    HurdHardware_obj.populate()


# Generated at 2022-06-22 23:21:16.030421
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc.platform == 'GNU'


# Generated at 2022-06-22 23:21:18.995801
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardware().populate()
    assert 'uptime' in hurd_facts
    assert 'memfree_mb' in hurd_facts

# Generated at 2022-06-22 23:21:22.955194
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardwareCollector = HurdHardwareCollector()

    # Check instance of class HardwareCollector
    assert isinstance(hardwareCollector, HardwareCollector)

    # Check fact class
    assert hardwareCollector.get_fact_class() == HurdHardware

    # Check platform
    assert hardwareCollector.get_platform() == 'GNU'


# Generated at 2022-06-22 23:21:24.800526
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h is not None

# Generated at 2022-06-22 23:21:26.853178
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:21:28.472053
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)



# Generated at 2022-06-22 23:21:30.927485
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()

    assert(hardware_collector.platform == 'GNU')
    assert(hardware_collector.fact_class == HurdHardware)

# Generated at 2022-06-22 23:21:32.170751
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert isinstance(HurdHardware(), HurdHardware)


# Generated at 2022-06-22 23:21:34.871395
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'
    assert hurd.uptime is 0
    assert hurd.memory is None
    assert hurd.mounts is None


# Generated at 2022-06-22 23:21:37.682281
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector.platform == 'GNU'
    assert HurdHardwareCollector.fact_class == HurdHardware


# Generated at 2022-06-22 23:21:40.734273
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhwc = HurdHardwareCollector()
    assert hhwc._fact_class == HurdHardware
    assert hhwc._platform == 'GNU'


# Generated at 2022-06-22 23:21:43.222986
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    res = hurd_hardware.populate()
    # Check that the res is not empty
    assert res

# Generated at 2022-06-22 23:21:45.424425
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test HurdHardware.populate"""
    hurd_hw = HurdHardware()
    hurd_hw.populate()

# Generated at 2022-06-22 23:21:46.799830
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw._platform == 'GNU'

# Generated at 2022-06-22 23:21:57.481178
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector
    from ansible.module_utils.facts.hardware.linux import procfs
    from ansible.module_utils.facts.timeout import TimeoutError
    import os
    import sys

    h = HurdHardware()
    l = LinuxHardware()
    p = procfs.ProcFS()

    # Skip these tests if GNU Hurd is not the current platform
    if sys.platform != "gnu0":
        return

    # A test case with facts collected from the current system
    uptime_facts = h.get_uptime_facts()
    memory_facts = h.get_memory_facts()

    # Skip these tests if /proc/uptime is missing or empty
   

# Generated at 2022-06-22 23:22:00.073334
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._platform is 'GNU'
    assert obj._fact_class is HurdHardware


# Generated at 2022-06-22 23:22:02.998240
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """Test the constructor of HurdHardware."""
    hurd_facts = HurdHardware()
    assert hurd_facts.platform == 'GNU'


# Generated at 2022-06-22 23:22:07.804294
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    collected_facts = {'ansible_system': 'GNU', 'ansible_distribution': 'Hurd'}
    hurdHardwareObj = HurdHardware(collected_facts=collected_facts)
    assert(hurdHardwareObj.platform == "GNU")
    hurdHardwareObj.populate()


# Generated at 2022-06-22 23:22:14.780117
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup arguments for the get_mount_facts function
    proc_mounts_content = """
    nodev /proc procfs rw 0 0
    /dev/disk0s3 on / (hfs, local, journaled)
    /dev/disk0s1 on /mach (hfs, local, nodev, nosuid, journaled)
    /dev/disk0s2 on /hurd (hfs, local, nodev, nosuid, journaled, nobrowse)
    nodev /dev/pts devpts rw,nosuid,noexec,relatime 0 0
    nodev /dev/shm tmpfs rw,nosuid,nodev 0 0
    """
    proc_mounts_path = "fake_proc_mounts"

    facts = HurdHardware()

# Generated at 2022-06-22 23:22:20.869458
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    hh.populate()

# Generated at 2022-06-22 23:22:24.958082
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Unit test for constructor of class HurdHardwareCollector"""
    instance = HurdHardwareCollector()
    assert isinstance(instance, HardwareCollector)
    assert hasattr(instance, '_fact_class')
    assert instance._fact_class == HurdHardware
    assert hasattr(instance, '_platform')
    assert instance._platform == 'GNU'

# Generated at 2022-06-22 23:22:28.800116
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware().populate()
    assert type(h) is dict
    assert h['uptime_seconds'] != 0
    assert h['uptime_hours'] != 0
    assert h['uptime_days'] != 0
    assert h['memory']
    assert h['mounts']

# Generated at 2022-06-22 23:22:38.235956
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Need to mocked method get_mount_facts to raise TimeoutError
    # as this method fails with timeout exception in GNU/Hurd without procfs
    # translator
    mock_get_mount_facts = "/module_utils/facts/hardware/linux.py"
    import_module = 'from ansible.module_utils.facts.hardware.linux '+\
                    'import LinuxHardware'

    import_mock = 'from ansible.module_utils.facts.hardware.linux '+ \
                  'import LinuxHardware, TimeoutError'

    class_mock = 'class HurdHardware(LinuxHardware):'
    class_mock_end = 'class Foo(LinuxHardware):'


# Generated at 2022-06-22 23:22:46.564687
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.timeout import TimeoutError
    clock = Clock()
    timeout = 1
    def get_uptime():
        return {
            'unix_time': clock.time() - timeout
        }

    def get_swap():
        raise Exception('Swap is not supported on GNU/Hurd')

    def get_mounts():
        if clock.time() - timeout < 0:
            raise TimeoutError()
        return {
            'test_fact_1': 'test_value_1',
            'test_fact_2': 'test_value_2'
        }


# Generated at 2022-06-22 23:22:55.531076
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module = MockModule()
    hurdhw = HurdHardware(module)

    # populate
    hurdhw.populate()

    # check module.exit_json call
    assert module.exit_json.called
    (args, kwargs) = module.exit_json.call_args
    assert 'ansible_facts' in kwargs
    assert 'hardware' in kwargs['ansible_facts']
    assert kwargs['ansible_facts']['hardware']['uptime_seconds'] == 31415926
    assert kwargs['ansible_facts']['hardware']['memtotal_mb'] == 314159

# Generated at 2022-06-22 23:22:57.988390
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    assert isinstance(facts, HurdHardware)
    assert facts.platform == "GNU"


# Generated at 2022-06-22 23:23:03.228739
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Creates an instance of HurdHardwareCollector and verifies
    if the instace has _fact_class and _platform as HurdHardware
    and GNU respectively.
    """

    hurd_hw_collector = HurdHardwareCollector()
    assert hurd_hw_collector._fact_class == HurdHardware
    assert hurd_hw_collector._platform == 'GNU'

# Generated at 2022-06-22 23:23:04.625358
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:23:06.792816
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # This test depends on get_memory_facts() and get_mount_facts()
    # returning non-empty dictionaries
    assert HurdHardware().populate()


# Generated at 2022-06-22 23:23:09.810957
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds']


# Generated at 2022-06-22 23:23:12.405133
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class == HurdHardware
    assert hw_collector._platform == 'GNU'

# Generated at 2022-06-22 23:23:16.532512
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts.get('uptime_seconds') is not None
    assert hardware_facts.get('uptime_days') is not None
    assert isinstance(hardware_facts.get('uptime_seconds'), int)
    assert isinstance(hardware_facts.get('uptime_days'), int)

# Generated at 2022-06-22 23:23:27.858934
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware({})
    hurd_hardware._get_mount_facts = lambda: {'mounts': [{'device': '/dev/vda1', 'mount': '/', 'options': 'rw,seclabel,relatime,data=ordered'}]}
    hurd_hardware._get_uptime_facts = lambda: {'uptime_seconds': 473}
    hurd_hardware._get_memory_facts = lambda: {'memtotal_mb': 1048575, 'memfree_mb': 553, 'swaptotal_mb': 0, 'swapfree_mb': 0}
    collected_facts = hurd_hardware.populate()

# Generated at 2022-06-22 23:23:30.840915
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert isinstance(hw, HardwareCollector)
    assert isinstance(hw._fact_class, HurdHardware)


# Generated at 2022-06-22 23:23:33.153846
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()


# Generated at 2022-06-22 23:23:45.001414
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts import timeout
    class MockLinuxHardware(LinuxHardware):
        def __init__(self):
            super(MockLinuxHardware, self).__init__()

        def get_uptime_facts(self):
            return {
                'uptime_seconds': 23,
                'uptime_hours': 0,
                'uptime_days': 0
            }

        def get_memory_facts(self):
            return {
                'ansible_memtotal_mb': 23,
                'ansible_swaptotal_mb': 10
            }


# Generated at 2022-06-22 23:23:47.227178
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    harware = HurdHardware()
    assert harware.platform == 'GNU'
    assert harware._platform == 'GNU'



# Generated at 2022-06-22 23:23:49.720298
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class == HurdHardware
    assert collector._platform == 'GNU'

# Generated at 2022-06-22 23:23:50.968095
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'


# Generated at 2022-06-22 23:23:58.050479
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}


# Generated at 2022-06-22 23:24:08.304016
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware import Hardware
    from ansible.module_utils.facts.timeout import set_default_timeout
    from ansible.module_utils.facts.timeout import get_default_timeout

    old_timeout = get_default_timeout()
    set_default_timeout(1)
    t = HurdHardware()
    try:
        facts = t.populate()
        assert facts['uptime']['hours']
        assert facts['uptime']['seconds']
        assert facts['uptime']['days']
        assert facts['uptime']['minutes']
        assert facts['memtotal_mb']
        assert facts['swaptotal_mb']
        assert facts['mounts']
    except Exception as e:
        raise e

# Generated at 2022-06-22 23:24:09.005207
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware()

# Generated at 2022-06-22 23:24:11.399283
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-22 23:24:13.253002
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.facts == {}



# Generated at 2022-06-22 23:24:17.939240
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test the method populate of class HurdHardware."""
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert isinstance(hurd_hw.uptime, float)
    assert isinstance(hurd_hw.swaptotal, int)
    assert isinstance(hurd_hw.swapfree, int)
    assert isinstance(hurd_hw.mounts, list)

# Generated at 2022-06-22 23:24:19.832470
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'
    assert hw._fact_class is HurdHardware


# Generated at 2022-06-22 23:24:20.919377
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts = HurdHardwareCollector()
    assert facts._fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:24:21.956910
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    s = HurdHardware()
    # TODO: migrate this test to unit test framework after merging patcher.
    assert s.populate()

# Generated at 2022-06-22 23:24:24.283935
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = HurdHardware().populate()

    # Assert that we got the right platform.
    assert result['platform'] == 'GNU'

# Generated at 2022-06-22 23:24:26.289139
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from sys import platform
    Hurd_hw_collector = HurdHardwareCollector()
    assert Hurd_hw_collector.sys_platform == platform

# Generated at 2022-06-22 23:24:27.791490
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw is not None

# Generated at 2022-06-22 23:24:38.411963
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_facts = {}
    uptime_facts = {}
    uptime_facts['uptime'] = '11:12:13'
    uptime_facts['uptime_days'] = '0'
    uptime_facts['uptime_hours'] = '11'
    uptime_facts['uptime_seconds'] = '40334'
    memory_facts = {}
    memory_facts['memfree_mb'] = 1135
    memory_facts['memtotal_mb'] = 1158
    memory_facts['swapfree_mb'] = 1591
    memory_facts['swaptotal_mb'] = 1591


    hurdhw = HurdHardwareCollector()
    hardware_facts = hurdhw.populate()

    assert hardware_facts['memfree_mb'] == memory_facts['memfree_mb']