

# Generated at 2022-06-22 23:14:33.948491
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'

# Generated at 2022-06-22 23:14:35.249573
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    try:
        HurdHardwareCollector()
    except Exception:
        assert False

# Generated at 2022-06-22 23:14:36.571245
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, LinuxHardware)
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:14:38.000599
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_obj = HurdHardware()

# Generated at 2022-06-22 23:14:42.100055
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw
    assert isinstance(hw,HurdHardware)
    assert isinstance(hw,LinuxHardware)
    assert isinstance(hw,HardwareCollector)


# Generated at 2022-06-22 23:14:43.656993
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h != None

# Generated at 2022-06-22 23:14:47.808372
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Arrange
    args = {
        'module':
            mock.Mock(),
        'params':
            {'gather_subset': 'all', 'filter': '*'}
    }
    hurd = HurdHardware(args)

    # Assert
    assert hurd.module == args['module'] and hurd.params == args['params']



# Generated at 2022-06-22 23:14:53.921097
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts
    assert hardware_facts['uptime_seconds'] == 0
    assert hardware_facts['uptime_hours'] == 0
    assert hardware_facts['uptime_days'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0

# Generated at 2022-06-22 23:14:55.399205
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    HardwareCollector.collectors['OS:GNU'] = HurdHardwareCollector

# Generated at 2022-06-22 23:15:06.174628
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.hurd import HurdHardware
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionCollector

    facts = HurdHardware(Distribution(DistributionCollector({})))
    facts_dict = facts.populate()

    assert facts_dict
    assert facts_dict['uptime']['seconds']
    assert facts_dict['memory']['swapfree_mb']
    assert facts_dict['memory']['memtotal_mb']
    assert facts_dict['memory']['swaptotal_mb']
    assert facts_dict['memory']['memfree_mb']
    assert facts_dict['mounts']

# Generated at 2022-06-22 23:15:08.618458
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.get('memory', {}).get('real', {}).get('total') != 0

# Generated at 2022-06-22 23:15:09.874873
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    assert not hw.populate()

# Generated at 2022-06-22 23:15:11.450728
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:15:13.099816
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:15:14.079363
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:15:20.603757
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_object = HurdHardware()
    expected_keys = ['uptime_seconds', 'uptime_hours', 'uptime_days',
                     'memtotal_mb', 'memfree_mb', 'swaptotal_mb', 'swapfree_mb',
                     'mounts']

    result = test_object.populate()
    assert isinstance(result, dict)
    assert not [key for key in expected_keys if key not in result]

# Generated at 2022-06-22 23:15:32.000192
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Test cases to check constructor
    testcase_constructor_list = [
                            # Input arguments - input_type, output_type, input_values, exception
                            # ["", "", str(), ""]
                            ]
    for testcase_constructor_item in testcase_constructor_list:
        test_hardware = HurdHardware(testcase_constructor_item[0], testcase_constructor_item[1], testcase_constructor_item[2])
        if testcase_constructor_item[3] == "":
            if test_hardware:
                print(True)
            else:
                print(False)

# Generated at 2022-06-22 23:15:33.714237
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.fact_class._platform == 'GNU'

# Generated at 2022-06-22 23:15:38.421273
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware
    assert hardware._platform == 'GNU'
    assert hardware._fact_class == HurdHardware
    assert hardware._file_contents == {}
    assert hardware._mount_points == None
    assert hardware._mount_points_list == []

# Generated at 2022-06-22 23:15:43.377339
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    info = HurdHardware()
    keys = ['uptime', 'uptime_days', 'uptime_hours', 'uptime_seconds',
            'memtotal_mb', 'memfree_mb', 'swaptotal_mb', 'swapfree_mb',
            'mounts']
    keys.sort()
    assert(info.populate().keys() == keys)

# Generated at 2022-06-22 23:15:45.378545
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:15:50.218653
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert(isinstance(hw_collector, HardwareCollector))
    assert(hw_collector._fact_class is not None)
    assert(hw_collector._platform is not None)


# Generated at 2022-06-22 23:15:54.791166
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert 'uptime_seconds' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'mounts' in facts

# Generated at 2022-06-22 23:15:56.068530
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert isinstance(hurd, HurdHardware)

# Generated at 2022-06-22 23:15:57.669377
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == "GNU"


# Generated at 2022-06-22 23:16:00.850843
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h._fact_class == HurdHardware
    assert h._platform == 'GNU'


# Generated at 2022-06-22 23:16:02.715003
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd = HurdHardwareCollector()
    assert hurd._fact_class == HurdHardware


# Generated at 2022-06-22 23:16:05.325987
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware._platform == 'GNU'


# Generated at 2022-06-22 23:16:07.362478
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_facts = HurdHardwareCollector()
    assert hardware_facts._fact_class == HurdHardware

# Generated at 2022-06-22 23:16:09.210129
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:16:10.504305
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:16:13.340524
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert isinstance(hurd_hardware, HurdHardware)
    assert isinstance(hurd_hardware, LinuxHardware)
    assert isinstance(hurd_hardware, HardwareCollector)

# Generated at 2022-06-22 23:16:22.544233
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.linux import mount_cache_path

    HurdHW = HurdHardware()
    LinuxHW = LinuxHardware()

    # Remove the memory fact
    for fact in BaseFactCollector.get_fact_names():
        if fact.startswith('memory_'):
            BaseFactCollector.remove_fact(fact)

    # Remove the mount fact
    for fact in BaseFactCollector.get_fact_names():
        if fact.startswith('mounts_'):
            BaseFactCollector.remove_fact(fact)

    # Remove the cache file


# Generated at 2022-06-22 23:16:25.550780
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    '''
    Creates an instance of HurdHardware class and check the value of platform property
    '''
    hurd_hardware_module_factory = HurdHardware()
    assert hurd_hardware_module_factory.platform == 'GNU'

# Generated at 2022-06-22 23:16:33.498702
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    memory_facts = hurd_hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    mount_facts = hurd_hardware.get_mount_facts()
    assert mount_facts['mounts'] is not None
    uptime_facts = hurd_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-22 23:16:37.031618
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert isinstance(hurd_hardware_collector._fact_class, HurdHardware)
    assert hurd_hardware_collector._fact_class._platform == 'GNU'

# Generated at 2022-06-22 23:16:47.249975
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.virtual_memory_facts == ("hw_memfree", "hw_swapfree", "hw_memory_total", "hw_swap_total")
    assert HurdHardwareCollector.uptime_fact == "uptime_seconds"
    assert HurdHardwareCollector.uptime_files == ['/proc/uptime']
    assert HurdHardwareCollector.memory_fact == "hw_memfree"
    assert HurdHardwareCollector.memory_paths == ['/proc/meminfo']
    assert HurdHardwareCollector.mount_fact == "mounts"
    assert HurdHardwareCollector.mount_files == ['/proc/mounts']

# Generated at 2022-06-22 23:16:48.767581
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == "GNU"


# Generated at 2022-06-22 23:16:58.074772
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware(None)

    # test when one output of free command is available
    output = '\n'.join(['             total       used       free     shared    buffers     cached',
                        'Mem:     48837376   37173836   11663540          0     145732    6832760',
                        '-/+ buffers/cache:   30444444   18392932',
                        'Swap:            0          0          0'])
    facts = hurd_hardware.get_memory_facts(output=output)
    assert facts['ansible_memtotal_mb'] == 47573
    assert facts['ansible_memfree_mb'] == 11343

    # test when more than one output of free command is available

# Generated at 2022-06-22 23:16:59.799552
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw.platform == 'GNU'
    assert HurdHardwareCollector._platform == 'GNU'

# Generated at 2022-06-22 23:17:03.619127
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()

    # Test the method populate() of the class HurdHardware
    res = hurdhw.populate()

    assert res['uptime_seconds'] > 0

# Generated at 2022-06-22 23:17:09.783696
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Create an instance of class HurdHardwareCollector
    # and test it for constructor
    hurd_hardware_col = HurdHardwareCollector()
    if not isinstance(hurd_hardware_col, HurdHardwareCollector):
        raise AssertionError("HurdHardwareCollector() object is not an instance of class HurdHardwareCollector")
    # Test the result when constructor has successfully completed
    assert isinstance(hurd_hardware_col, HurdHardwareCollector)


# Generated at 2022-06-22 23:17:13.822018
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class == HurdHardware
    assert hw_collector._platform == 'GNU'

# Generated at 2022-06-22 23:17:16.983666
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    cls = HurdHardwareCollector()
    assert issubclass(cls._fact_class, HurdHardware)
    assert cls._platform == 'GNU'

# Generated at 2022-06-22 23:17:19.405341
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    # check that Uptime instance is returned
    assert(h.populate() is not None)


# Generated at 2022-06-22 23:17:23.282164
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj._fact_class is HurdHardware
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:17:26.044255
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector.collect()
    assert hw['uptime_seconds'] > 0
    assert hw['uptime_seconds'] < 3600 * 24 * 365

# Generated at 2022-06-22 23:17:27.844166
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == "GNU"

# Generated at 2022-06-22 23:17:30.352731
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'



# Generated at 2022-06-22 23:17:33.170949
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    result = hurd_hardware.populate()

    assert result is not None

# Generated at 2022-06-22 23:17:35.130263
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == "GNU"


# Generated at 2022-06-22 23:17:39.223782
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    f = HurdHardwareCollector._fact_class()
    assert isinstance(f, HurdHardware)
    assert isinstance(f, LinuxHardware)
    assert isinstance(f, HardwareCollector)
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:17:41.074968
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class.platform == 'GNU'


# Generated at 2022-06-22 23:17:43.199966
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware({})

    assert h is not None

# Generated at 2022-06-22 23:17:44.852047
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'

# Generated at 2022-06-22 23:17:46.544219
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:17:48.045937
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-22 23:17:50.833998
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)
    x = HurdHardwareCollector()
    assert x._platform == 'GNU'
    assert x._fact_class == HurdHardware


# Generated at 2022-06-22 23:17:53.003928
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._fact_class._platform == 'GNU'

# Generated at 2022-06-22 23:17:56.498632
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h_hurd = HurdHardware()
    assert h_hurd._platform == 'GNU', 'h_hurd._platform should be GNU'
    assert h_hurd._fact_class == HurdHardware, 'h_hurd._fact_class should be HurdHardware'



# Generated at 2022-06-22 23:17:59.131772
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware,HurdHardware)


# Generated at 2022-06-22 23:18:00.948030
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc is not None

# Generated at 2022-06-22 23:18:05.916384
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Arrange
    # Act
    # Assert
    assert HurdHardwareCollector.platform == 'GNU'
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector.fact_class == HurdHardware
    assert HurdHardwareCollector._fact_class == HurdHardware
    assert HurdHardwareCollector.collector == HurdHardwareCollector._collect

# Generated at 2022-06-22 23:18:07.688295
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.supported

# Generated at 2022-06-22 23:18:10.189711
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert "mounts" in hw.populate()
    assert "memfree_mb" in hw.populate()
    assert "uptime_seconds" in hw.populate()

# Generated at 2022-06-22 23:18:13.222970
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Create an object of HurdHardware
    Make sure GNU is used as a platform
    """

    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'

# Generated at 2022-06-22 23:18:15.454572
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert isinstance(hwc, HardwareCollector)
    assert hwc.platform == 'GNU'
    assert hwc._fact_class == HurdHardware

# Generated at 2022-06-22 23:18:16.151446
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware() is not None

# Generated at 2022-06-22 23:18:22.961557
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    result = hurd_hw.populate()
    assert isinstance(result, dict), "HurdHardware.populate() returned an invalid type"
    assert 'uptime' in result, "HurdHardware.populate() did not return key uptime"
    assert 'uptime_seconds' in result, "HurdHardware.populate() did not return key uptime_seconds"
    assert 'memory' in result, "HurdHardware.populate() did not return key memory"
    assert 'swap' in result['memory'], "HurdHardware.populate() did not return key swap in memory"
    assert 'total' in result['memory']['swap'], "HurdHardware.populate() did not return key total in memory swap"

# Generated at 2022-06-22 23:18:28.163813
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)
    assert HurdHardwareCollector._fact_class is HurdHardware
    assert HurdHardwareCollector._platform is 'GNU'
    # TODO: make a test subclassing HurdHardware and run the test
    # of the parent class

if __name__ == '__main__':
    test_HurdHardwareCollector()

# Generated at 2022-06-22 23:18:29.180769
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector()

# Generated at 2022-06-22 23:18:30.513813
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'

# Generated at 2022-06-22 23:18:33.219732
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    a = HurdHardwareCollector()
    assert a._fact_class == HurdHardware, "Constructor of class HurdHardwareCollector fails!"
    assert a._platform == 'GNU', "Constructor of class HurdHardwareCollector fails!"

# Generated at 2022-06-22 23:18:36.322523
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._platform == 'GNU'

# Generated at 2022-06-22 23:18:46.820881
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create instance
    hurd_hardware = HurdHardware()

    # Create test data
    raw_fact_uptime = dict()
    raw_fact_uptime['uptime_seconds'] = 1506019
    raw_fact_memory = dict()
    raw_fact_memory['MemTotal'] = 1048576
    raw_fact_memory['MemFree'] = 520192
    raw_fact_memory['MemAvailable'] = 520192
    raw_fact_memory['SwapTotal'] = 0
    raw_fact_memory['SwapFree'] = 0

# Generated at 2022-06-22 23:18:48.992676
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector(None)
    assert hw.__class__.__name__ == 'HurdHardwareCollector'

# Generated at 2022-06-22 23:18:50.392582
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert isinstance(hc._fact_class(), HurdHardware)

# Generated at 2022-06-22 23:18:52.665250
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """HurdHardwareCollector class constructor test stub"""
    collector = HurdHardwareCollector()
    assert isinstance(collector, HurdHardwareCollector)


# Generated at 2022-06-22 23:18:53.856366
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)

# Generated at 2022-06-22 23:18:56.145214
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:19:00.347235
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    h = HurdHardwareCollector()
    assert issubclass(h._fact_class, LinuxHardware)


# Generated at 2022-06-22 23:19:02.895451
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    facts = hh.populate()
    assert facts['uptime_seconds'] == 0
    assert facts['mounts'] == []

# Generated at 2022-06-22 23:19:05.158296
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Ensure that the method HurdHardware.populate can be called
    h = HurdHardware()
    result = h.populate()

    # Check that the function HurdHardware.populate returns a dictionary
    assert isinstance(result, dict)

# Generated at 2022-06-22 23:19:07.638422
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdHardware
    assert collector.fact_class._platform == 'GNU'


# Generated at 2022-06-22 23:19:09.990648
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    arg_spec = HurdHardware.parse_params(None)
    hp = HurdHardware(argument_spec=arg_spec)
    assert hp.platform == 'GNU'

# Generated at 2022-06-22 23:19:11.984166
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-22 23:19:16.790916
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Call HurdHardware.populate() with a dummy object and check whether
    it returns a dictionary.
    """
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.populate(), dict)

# Generated at 2022-06-22 23:19:18.666637
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._platform == 'GNU'

# Generated at 2022-06-22 23:19:19.648376
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
	HurdHardware()

# Generated at 2022-06-22 23:19:21.951518
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware_object = HurdHardware()
    assert isinstance(hurd_hardware_object, HurdHardware)


# Generated at 2022-06-22 23:19:25.389977
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """Create an instance of HurdHardwareCollector"""
    hw_collector = HurdHardwareCollector()
    assert hw_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:28.558646
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector_data = HurdHardwareCollector()
    assert collector_data._platform == 'GNU'
    assert collector_data._fact_class == HurdHardware


# Generated at 2022-06-22 23:19:31.438437
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert isinstance(hurd_hardware.platform, str)
    assert isinstance(hurd_hardware.distribution, str)


# Generated at 2022-06-22 23:19:33.486807
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:19:37.026873
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test_HurdHardwareCollector = HurdHardwareCollector()

    assert test_HurdHardwareCollector is not None


# Generated at 2022-06-22 23:19:38.343958
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

# Generated at 2022-06-22 23:19:39.920490
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector().fact_class == HurdHardware

# Generated at 2022-06-22 23:19:41.403694
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h is not None



# Generated at 2022-06-22 23:19:43.730508
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert isinstance(h, HurdHardware)
    assert isinstance(h, HardwareCollector)

# Generated at 2022-06-22 23:19:50.846123
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test to check that class HurdHardware has properly returned a dictionary
    with information about uptime, memory and mount points.
    """
    hurd_hardware = HurdHardware()
    hurd_hardware_facts = hurd_hardware.populate()

    assert isinstance(hurd_hardware_facts, dict)
    assert 'uptime' in hurd_hardware_facts
    assert 'mem_total' in hurd_hardware_facts
    assert isinstance(hurd_hardware_facts.get('uptime'), dict)
    assert isinstance(hurd_hardware_facts.get('mem_total'), int)

# Generated at 2022-06-22 23:20:00.917578
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware().populate() == {
        'memfree_mb': 4,
        'memtotal_mb': 5,
        'mounts': [
            {'device': '/dev/hd0s1',
             'mount': '/',
             'fstype': 'ext2',
             'options': 'rw'},
            {'device': 'proc',
             'mount': '/proc',
             'fstype': 'proc',
             'options': 'rw'},
            {'device': '/dev/hd0s2',
             'mount': '/home',
             'fstype': 'ext2',
             'options': 'rw'}
        ],
        'uptime_seconds': 10800
    }

# Generated at 2022-06-22 23:20:02.844020
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    print("constructor test")
    hhc1=HurdHardwareCollector()


# Generated at 2022-06-22 23:20:09.320873
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    import re

    # Create a empty HurdHardware class
    hurd_hardware = HurdHardware()

    # Create a test dictionary
    test_dict = {
        "uptime": {
            'seconds': 10,
            'uptime_string': '10 seconds'
        },
        "memfree_mb": 0,
        "swapfree_mb": 0,
        "mounts": [
            {
                "device": "/dev/sda",
                "free_mb": 1523,
                "mount": "/",
                "size_mb": 1523,
                "type": "ext4"
            }
        ]
    }

    # Call method populate of class HurdHardware
    result = hurd_hardware.populate()

    #

# Generated at 2022-06-22 23:20:14.164706
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()

    assert 'memory' in hardware_facts
    assert 'swap' in hardware_facts
    assert 'system' in hardware_facts
    assert 'cpu' in hardware_facts
    assert 'mounts' in hardware_facts

# Generated at 2022-06-22 23:20:17.831122
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert isinstance(hwc, HurdHardwareCollector)
    assert hwc._fact_class == HurdHardware
    assert hwc._platform == 'GNU'

# Generated at 2022-06-22 23:20:19.266760
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    assert isinstance(hw.populate(), dict)

# Generated at 2022-06-22 23:20:25.221503
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert len(hardware_facts['mounts']) > 0

# Generated at 2022-06-22 23:20:28.941005
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate(None)
    assert facts['uptime_seconds'] >= 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_days'] >= 0
    assert facts['memtotal_mb'] >= 0
    assert facts['mounts']

# Generated at 2022-06-22 23:20:31.394969
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:20:40.458427
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test HurdHardware.populate"""

    class MockUptime:
        def get_uptime(self):
            return {
                'uptime': 0,
                'uptime_format': '',
            }

    class MockMemory:
        def get_memory_facts(self):
            return {
                'memtotal_mb': 1,
                'memfree_mb': 2,
                'swaptotal_mb': 3,
                'swapfree_mb': 4,
            }


# Generated at 2022-06-22 23:20:41.632973
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector == type(HurdHardwareCollector())


# Generated at 2022-06-22 23:20:51.900277
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_class = HurdHardware()

# Generated at 2022-06-22 23:20:53.359423
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().populate()

# Generated at 2022-06-22 23:20:55.798239
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()

    print(hardware_facts.populate())

# Generated at 2022-06-22 23:21:07.607996
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    ansible_facts = hw.populate()
    assert ansible_facts['uptime']['uptime'] == '23 days'
    assert ansible_facts['uptime']['idletime'] == '0'
    assert ansible_facts['mounts']['/']['device'] == '/dev/vda'
    assert ansible_facts['mounts']['/']['fstype'] == 'ext4'
    assert ansible_facts['mounts']['/']['mount'] == '/'
    assert ansible_facts['mounts']['/']['options'] == 'rw'
    assert ansible_facts['mounts']['/']['size_available'] == 1044791296

# Generated at 2022-06-22 23:21:12.040194
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware.populate()
    assert hw['uptime'] > 0
    assert hw['memfree_mb'] == 0
    assert hw['swapfree_mb'] == 0
    assert 'mounts' in hw
    assert len(hw['mounts']) > 0


# Generated at 2022-06-22 23:21:17.848275
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_obj = HurdHardware()
    assert hardware_obj._platform == 'GNU'
    assert type(hardware_obj._uptime_facts) is dict
    assert type(hardware_obj._memory_facts) is dict
    assert type(hardware_obj._mount_facts) is dict

# Generated at 2022-06-22 23:21:21.124328
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    # Raise exception in case of unsupported platform
    assert hurd_hw.get_platform() == 'GNU'
    # In case of supported platform, return nothing
    assert hurd_hw.populate() == {}

# Generated at 2022-06-22 23:21:31.135367
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    translator_path = '/path/to/translator-procs'
    _meminfo_path = translator_path + '/meminfo'
    _mounts_path = translator_path + '/mounts'
    _proc_path = translator_path + '/proc'
    _uptime_path = translator_path + '/uptime'
    hw = HurdHardware(_meminfo_path=_meminfo_path,
                      _mounts_path=_mounts_path,
                      _proc_path=_proc_path,
                      _uptime_path=_uptime_path)
    hw_facts = hw.populate()

# Generated at 2022-06-22 23:21:33.888713
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_collector = HurdHardwareCollector()
    assert hurd_collector
    assert hurd_collector._fact_class is HurdHardware
    assert hurd_collector._platform == 'GNU'


# Generated at 2022-06-22 23:21:40.735838
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class_hurd_hardware = HurdHardware()
    result = class_hurd_hardware.populate()
    expected = {'memory': {'swap': {'available': u'2129996',
                                    'total': u'2129996'},
                           'real': {'available': u'2129996',
                                    'total': u'2129996'}},
                'uptime_seconds': -1.0}
    assert result == expected

# Generated at 2022-06-22 23:21:42.391708
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware({})
    assert hw.platform == 'GNU'

# Generated at 2022-06-22 23:21:43.819022
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert(hurd is not None)

# Generated at 2022-06-22 23:21:46.014916
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    unit_test_HurdHardware = HurdHardware()
    assert unit_test_HurdHardware is not None

# Generated at 2022-06-22 23:21:48.729810
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw_collector = HurdHardwareCollector()

    assert hw_collector._platform == 'GNU'


# Generated at 2022-06-22 23:21:52.052898
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc._fact_class == HurdHardware
    assert hwc._platform == 'GNU'
    assert hwc._system_profiler == ['system_profiler']


# Generated at 2022-06-22 23:21:55.502340
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    HurdHardwareCollector.__init__(collector)
    assert(HurdHardwareCollector._platform == 'GNU')
    assert(HurdHardwareCollector._fact_class == HurdHardware)

# Generated at 2022-06-22 23:22:03.239171
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Check getting GNU Hurd hardware facts"""
    hardware_facts = HurdHardware().populate()

    assert type(hardware_facts) is dict
    assert 'uptime' in hardware_facts
    assert 'mounts' in hardware_facts
    assert hardware_facts['uptime'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] >= 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0

# Generated at 2022-06-22 23:22:05.477678
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    # Instantiating HurdHardware()
    h = HurdHardware()
    assert isinstance(h, HurdHardware)

# Generated at 2022-06-22 23:22:06.694673
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
	assert HurdHardware().platform == 'GNU'

# Generated at 2022-06-22 23:22:09.140452
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector(None)
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:22:10.874842
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    x = HurdHardwareCollector()
    assert x._fact_class == HurdHardware
    assert x._platform == 'GNU'

# Generated at 2022-06-22 23:22:14.577996
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_Hardware = HurdHardware()
    assert hurd_Hardware._platform == 'GNU'
    assert type(hurd_Hardware._fact_class) == HurdHardware
    assert not hurd_Hardware.get_all_facts()

# Generated at 2022-06-22 23:22:16.593858
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    assert hardware_facts.populate()

# Generated at 2022-06-22 23:22:19.257023
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_obj = HardwareCollector.factory()
    assert isinstance(hardware_obj, HurdHardware)


# Generated at 2022-06-22 23:22:22.251391
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact_collector = HurdHardwareCollector()
    assert fact_collector._platform == 'GNU'
    assert fact_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:22:25.015117
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware()


# Generated at 2022-06-22 23:22:26.037454
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'


# Generated at 2022-06-22 23:22:28.343049
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw_os_generic = HurdHardware()
    assert hw_os_generic.platform == 'GNU'


# Generated at 2022-06-22 23:22:37.490344
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardware()
    collected_facts = {}
    ret = hurd_facts.populate(collected_facts)
    assert ret['uptime']['seconds'] == 1
    assert ret['uptime']['hours'] == 1
    assert ret['uptime']['days'] == 1
    assert ret['memory']['swap']['available'] == 1
    assert ret['memory']['swap']['total'] == 1
    assert ret['memory']['physical']['available'] == 1
    assert ret['memory']['physical']['total'] == 1
    assert ret['mounts'][0]['size_total'] == 1
    assert ret['mounts'][0]['size_available'] == 1
    assert ret['mounts'][0]['fstype'] == 1


# Generated at 2022-06-22 23:22:42.357234
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwc = HurdHardwareCollector()
    assert hwc.platform == 'GNU', \
        'HurdHardwareCollector did not set the platform attribute correctly'
    assert hwc._fact_class == HurdHardware, \
        'HurdHardwareCollector did not set the _fact_class attribute correctly'



# Generated at 2022-06-22 23:22:43.531036
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()
    assert hw._platform == 'GNU'

# Generated at 2022-06-22 23:22:44.509280
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    print(obj)

# Generated at 2022-06-22 23:22:47.358092
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc._fact_class == HurdHardware
    assert hc._platform == 'GNU'

# Generated at 2022-06-22 23:22:50.489379
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()

    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware


# Generated at 2022-06-22 23:22:52.372549
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()

# Generated at 2022-06-22 23:23:01.220643
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    hardware_facts = hardware.populate()
    assert hardware_facts.get('uptime') is not None
    assert hardware_facts.get('uptime_seconds') is not None
    assert hardware_facts.get('memfree_mb') is not None
    assert hardware_facts.get('memtotal_mb') is not None
    assert hardware_facts.get('swaptotal_mb') is not None
    assert hardware_facts.get('swapfree_mb') is not None
    assert hardware_facts.get('mounts') is not None


# Generated at 2022-06-22 23:23:04.519633
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

collectors = [HurdHardwareCollector]

if __name__ == '__main__':
    for collector in collectors:
        print(collector)

# Generated at 2022-06-22 23:23:06.087969
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == HurdHardware._platform

# Generated at 2022-06-22 23:23:08.348047
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    fact_ins = HurdHardware()
    assert fact_ins.platform == 'GNU'


# Generated at 2022-06-22 23:23:13.438906
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_pretty'].startswith('up ')

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] >= 0

    assert hardware_facts['mounts'] is not None

# Generated at 2022-06-22 23:23:21.965152
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    # assert class variables for class HurdHardware
    assert hurd_hardware.platform == 'GNU'
    assert hurd_hardware.FILE_LOADAVG == '/proc/uptime'
    assert hurd_hardware.FILE_MEMORY_PHYSICAL_MB == '/proc/meminfo'
    assert hurd_hardware.FILE_MEMORY_SWAP_MB == '/proc/meminfo'
    assert hurd_hardware.CMD_MOUNTS == 'mount'

# Generated at 2022-06-22 23:23:28.042677
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test populate method.
    """
    hurd_hardware = HurdHardware()
    result = hurd_hardware.populate()

    assert 'memory' in result
    assert 'swap' in result
    assert 'uptime_seconds' in result
    assert 'uptime_hours' in result
    assert 'uptime_days' in result
    assert 'mounts' in result
    assert 'devices' in result
    assert 'fstypes' in result

# Generated at 2022-06-22 23:23:31.013102
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    This function is used to test the constructor of class HurdHardware.
    """
    h = HurdHardware()
    assert h.platform == 'GNU'

# Generated at 2022-06-22 23:23:33.906036
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware({'kernel': 'Linux', 'system': 'GNU'})
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:23:36.476559
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hw = HurdHardwareCollector()
    assert hurd_hw._fact_class == HurdHardware

# Generated at 2022-06-22 23:23:39.372078
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    HurdHardwareCollector constructor unit test
    """
    obj = HurdHardwareCollector()
    assert obj._platform == "GNU"


# Generated at 2022-06-22 23:23:47.718088
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware_collector.collect()
    collected_facts = hurd_hardware_collector.facts
    hardware_facts = collected_facts['ansible_facts']['ansible_hardware']

    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0

    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

    assert '_mounts' in hardware_facts

# Generated at 2022-06-22 23:23:49.100376
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:23:51.224242
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.platform == 'GNU'
    assert HurdHardware.platform == 'GNU'

# Generated at 2022-06-22 23:23:52.850648
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    my_object = HurdHardwareCollector()
    assert my_object._platform == 'GNU'

# Generated at 2022-06-22 23:23:55.323976
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwcollector = HurdHardwareCollector(None)
    assert hwcollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:24:04.748147
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    hardware = HurdHardware()
    hardware.sysctl = LinuxHardware.sysctl

    hardware.get_uptime_facts = lambda: {'uptime': 0}
    hardware.get_memory_facts = lambda: {'memtotal': 0}
    hardware.get_mount_facts = lambda: {'mounts': []}

    facts = hardware.populate()

    assert len(facts) == 3
    assert facts['uptime'] == 0
    assert facts['memtotal'] == 0
    assert facts['mounts'] == []

# Generated at 2022-06-22 23:24:06.567980
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:24:16.502807
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hw = HurdHardwareCollector()

    # Assert expected values of non-dynamic attributes
    assert(hw._platform == 'GNU')
    assert('GNU' in hw._platforms)
    assert(HurdHardware in hw._fact_class_map.values())
    assert(HardwareCollector not in hw._fact_class_map.values())

    hw1 = HurdHardwareCollector()
    assert(hw == hw1)
    assert(not hw != hw1)

    hw1._platform = 'Linux'
    assert(hw != hw1)
    assert(not hw == hw1)


# Generated at 2022-06-22 23:24:27.775118
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test for method HurdHardware.populate.
    """
    hurd_hardware = HurdHardware()

# Generated at 2022-06-22 23:24:33.026138
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    keys = ['uptime_hours', 'uptime_seconds', 'uptime_days',
            'memfree_mb', 'memtotal_mb']
    for key in keys:
        assert key in facts.data.keys(), \
            "Key '%s' is missing in dictionary returned by HurdHardware" % key