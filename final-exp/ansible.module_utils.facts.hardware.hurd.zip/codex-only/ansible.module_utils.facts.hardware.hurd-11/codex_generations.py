

# Generated at 2022-06-22 23:14:39.014572
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module_utils = 'ansible.module_utils.facts.hardware.linux'
    uptime_facts = dict(
        uptime_seconds=217743,
        uptime_days=2,
        uptime_hours=8,
        boot_time='2017-11-21T18:36:00Z')
    memory_facts = dict(
        MemTotal=2097152,
        MemFree=1822720,
        MemAvailable=1891328
        )
    mount_facts = dict(NonTimeoutError=False)

    module_mock = '%s.LinuxHardware.get_uptime_facts' % (module_utils)
    uptime_facts_mock = dict(
        side_effect = lambda self: uptime_facts,
        __name__ = module_mock
    )
    module_m

# Generated at 2022-06-22 23:14:40.866402
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert issubclass(HurdHardwareCollector, HardwareCollector)


# Generated at 2022-06-22 23:14:46.019448
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test facts population.
    :return: True if facts are populated, False otherwise.
    """

    facts = dict()
    facts['distribution'] = 'GNU'
    facts['distribution_version'] = '0.3'

    hardware = HurdHardware(facts)

    if hardware.populate() is not None:
        return False

    return True

# Generated at 2022-06-22 23:14:47.775797
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_hw = HurdHardware()
    assert(test_hw.populate())

# Generated at 2022-06-22 23:14:51.368067
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware = hurd_hardware_collector.collect()
    # Just check if the class collect something
    assert(hurd_hardware)


# Generated at 2022-06-22 23:14:53.736315
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert hurd_hw.platform == 'GNU'


# Generated at 2022-06-22 23:15:05.022154
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # mock object for GNU/Hurd translator
    class MockTranslator(object):
        def __init__(self, name, path=None):
            self.name = name
            self.path = path

        def read_proc_file(self, filename, decoding=None):
            if self.name == "meminfo":
                if filename == "meminfo":
                    return "MemTotal:        1624544 kB\n" \
                           "MemFree:           20696 kB\n" \
                           "Buffers:            1228 kB\n" \
                           "Cached:             2772 kB\n" \
                           "SwapCached:            0 kB\n" \
                           "Active:            85864 kB\n" \
                           "Inactive:          72336 kB\n"

# Generated at 2022-06-22 23:15:07.521306
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class HurdHardware:
        platform = 'GNU'

    hardware = HurdHardware()
    hardware.collect()
    assert hardware.populate()

# Generated at 2022-06-22 23:15:11.149545
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware().populate()
    keys = ["uptime", "uptime_seconds", "uptime_days",
            "memfree_mb", "memtotal_mb", "swapfree_mb", "swaptotal_mb",
            "mounts"]
    assert all(key in hardware_facts.keys() for key in keys)

# Generated at 2022-06-22 23:15:13.500156
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert not hurd_hw.package_facts['packages']
    assert not hurd_hw.sysconfig_facts

# Generated at 2022-06-22 23:15:17.661780
# Unit test for constructor of class HurdHardware
def test_HurdHardware():

    test_hw = HurdHardware()
    assert test_hw.platform == 'GNU'
    assert isinstance(test_hw, HurdHardware)
    assert isinstance(test_hw, LinuxHardware)
    assert isinstance(test_hw, HardwareCollector)

# Generated at 2022-06-22 23:15:20.551839
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.uptime_facts is None
    assert hardware.memory_facts is None
    assert hardware.mount_facts is None


# Generated at 2022-06-22 23:15:29.764575
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_minutes'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['memavailable_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['tmpfs'] is not None

# Generated at 2022-06-22 23:15:41.487218
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    collected_facts = {}
    facts = hurd_hw.populate(collected_facts)
    assert ('uptime' in facts)
    assert ('uptime_seconds' in facts)
    assert ('uptime_hours' in facts)
    assert ('memfree_mb' in facts)
    assert ('memtotal_mb' in facts)
    assert ('swapfree_mb' in facts)
    assert ('swaptotal_mb' in facts)
    assert ('fstype' in facts)
    assert ('device' in facts)
    assert ('filesystem' in facts)
    assert ('mount' in facts)
    assert ('size_total' in facts)
    assert ('size_available' in facts)
    assert ('size_used' in facts)



# Generated at 2022-06-22 23:15:42.929323
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    my_obj = HurdHardwareCollector()
    assert my_obj.platform == 'GNU'


# Generated at 2022-06-22 23:15:44.519553
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert isinstance(obj, HurdHardware)

# Generated at 2022-06-22 23:15:49.752594
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    hh.files = {}
    facts = hh.populate()

    assert 'uptime' in facts
    assert 'uptime_seconds' in facts
    assert 'memfree_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'mounts' in facts

# Generated at 2022-06-22 23:15:54.055058
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # initialize the object
    hurd_hardware_collector = HurdHardwareCollector()
    # check if object is initialized properly
    assert hurd_hardware_collector._fact_class == HurdHardware
    assert hurd_hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:15:56.355577
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert 'uptime' in hurd_hardware.populate()
    assert 'ram' in hurd_hardware.populate()
    assert 'mounts' in hurd_hardware.populate()


# Generated at 2022-06-22 23:16:07.142494
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    collected_facts = {'ansible_architecture': 'x86_64',
                       'ansible_distribution': 'GNU',
                       'ansible_distribution_version': '0.6'}

    proc_structure = {}
    proc_structure['uptime'] = [23670.57, 17305.99]

# Generated at 2022-06-22 23:16:08.573099
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hd = HurdHardware()
    assert hd is not None

# Generated at 2022-06-22 23:16:10.949319
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware


# Generated at 2022-06-22 23:16:12.526846
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    cls = HurdHardware()
    assert cls.platform == 'GNU'


# Generated at 2022-06-22 23:16:14.376593
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardware()
    assert len(hurd_facts.populate()) > 0

# Generated at 2022-06-22 23:16:17.141311
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class == HurdHardware

# Generated at 2022-06-22 23:16:18.841342
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector.platform == 'GNU'

# Generated at 2022-06-22 23:16:20.514682
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw=HurdHardware()
    assert isinstance(hw, HurdHardware)


# Generated at 2022-06-22 23:16:23.189262
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:16:24.749443
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'

# Generated at 2022-06-22 23:16:28.611798
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact = HurdHardwareCollector()
    actual = fact._fact_class
    expected = HurdHardware
    assert actual is expected


# Generated at 2022-06-22 23:16:29.789106
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:16:32.065543
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj
    assert issubclass(obj._fact_class, LinuxHardware)

# Generated at 2022-06-22 23:16:37.964439
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Create a HurdHardware instance
    hardware = HurdHardware()

    # We expect the fact 'mounts' to be in the output of method
    # get_mount_facts.
    hardware.get_mount_facts = MagicMock(return_value={'mounts': 'test'})

    collected_facts = {'kernel': 'GNU'}
    hardware_facts = hardware.populate(collected_facts)
    assert hardware_facts.get('mounts') is not None

# Generated at 2022-06-22 23:16:39.271493
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hardware = HurdHardware()
    hardware.populate()

# Generated at 2022-06-22 23:16:44.895838
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Test GNU Hurd specific subclass of Hardware. Define memory and mount facts
    based on procfs compatibility translator mimicking the interface of
    the Linux kernel.
    """
    hurdhw = HurdHardware()
    # check whether we return a dictionary
    assert isinstance(hurdhw.populate(), dict)

# Generated at 2022-06-22 23:16:46.161213
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)

# Generated at 2022-06-22 23:16:47.797916
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # Test a successful creation of class HurdHardwareCollector
    HurdHardwareCollector()


# Generated at 2022-06-22 23:16:49.410648
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:16:54.722338
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()
    keys = hardware.data.keys()
    assert "uptime" in keys
    assert "uptime_seconds" in keys
    assert "swapfree_mb" in keys
    assert "memfree_mb" in keys
    assert "memtotal_mb" in keys
    assert "mounts" in keys

# Generated at 2022-06-22 23:16:56.091146
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector


# Generated at 2022-06-22 23:16:57.604381
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()

# Generated at 2022-06-22 23:17:00.878995
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector._fact_class is HurdHardware
    assert collector._platform is 'GNU'

# Generated at 2022-06-22 23:17:07.130624
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardwareCollector().collect()
    assert hardware['uptime_seconds'] == 0
    assert hardware['uptime_days'] == 0
    assert hardware['uptime_hours'] == 0
    assert hardware['uptime_minutes'] == 0
    assert hardware['memtotal_mb'] == 0
    assert hardware['swaptotal_mb'] == 0
    assert hardware['mounts'] == []

# Generated at 2022-06-22 23:17:10.842094
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facter_module_mock = 'ansible.module_utils.facts.hardware.linux.LinuxHardware.populate'
    setattr(HurdHardware, 'populate', lambda x: {'a': 1})
    h = HurdHardware()
    assert h.populate() == {'a': 1, 'distribution': 'GNU/Hurd'}

# Generated at 2022-06-22 23:17:18.327374
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    ins = HurdHardware()
    expected = {
        'uptime_seconds': 2056907,
        'uptime_hours': 570,
        'uptime_days': 23,
        'memtotal_mb': 2048,
        'memavailable_mb': 1420,
        'swaptotal_mb': 2473337,
        'swapavailable_mb': 2474200
    }
    collected_facts = {}
    assert ins.populate(collected_facts) == expected

# Generated at 2022-06-22 23:17:22.086944
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)
    assert hurd_hw.platform == 'GNU'

# Generated at 2022-06-22 23:17:24.067482
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    h = HurdHardwareCollector()
    assert h.platform == 'GNU'


# Generated at 2022-06-22 23:17:28.330684
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create class object
    hardware_facts = HurdHardware()
    # Create a dictionary containing all the parameters that
    # will be sent to the method populate.
    facts_dict = {}
    # Call method populate
    result = hardware_facts.populate(facts_dict)
    assert result is not None

# Generated at 2022-06-22 23:17:30.777033
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hw = HurdHardware()
    assert isinstance(hurd_hw, HurdHardware)


# Generated at 2022-06-22 23:17:34.057542
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test for method HurdHardware.populate
    """
    test_obj = HurdHardware()
    result = test_obj.populate()
    assert result

# Generated at 2022-06-22 23:17:37.354317
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == "GNU"
    assert obj._fact_class == HurdHardware

# Unit tests for functions and methods of class HurdHardware

# Generated at 2022-06-22 23:17:39.222728
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    obj = HurdHardware()
    assert(obj.platform == 'GNU')



# Generated at 2022-06-22 23:17:50.230619
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    expected = {'ansible_facts': {
                'uptime_seconds': 300.0,
                'uptime_hours': 5,
                'uptime_days': 0,
                'uptime': "5 hours, 0 minutes, 0 seconds",
                'memtotal_mb': 10240,
                'memfree_mb': 512,
                'memavailable_mb': 1024,
                'swaptotal_mb': 0,
                'swapfree_mb': 0,
                'ansible_mounts': []
                }
            }

    cpu_info = {'processor': ['0', '1', '2', '3']}
    uptime_file = "\n".join(["300.0", "1797.90"])

# Generated at 2022-06-22 23:17:55.764515
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardwareClass = HurdHardware()
    uptime_facts = hardwareClass.get_uptime_facts()
    memory_facts = hardwareClass.get_memory_facts()

    hardware_facts = {}
    hardware_facts.update(uptime_facts)
    hardware_facts.update(memory_facts)
    hardware_facts.update(hardwareClass.get_mount_facts())

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0

# Generated at 2022-06-22 23:17:58.110634
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    args=dict
    facts=dict
    obj=HurdHardwareCollector(args,facts)
    assert obj._platform == 'GNU'

# Generated at 2022-06-22 23:18:08.141811
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    # Case 1:
    # If return facts is a proper dict, test pass
    hurd_hardware = HurdHardware()
    facts = {}
    # Method get_uptime_facts return a dict
    hurd_hardware.get_uptime_facts = lambda : {
        'seconds': 3,
        'days': 3,
        'hours': 5,
        'minutes': 5
    }
    # Method get_memory_facts return a dict
    hurd_hardware.get_memory_facts = lambda : {
        'memory_mb': {
            'real': {
                'total': 9999
            }
        }
    }
    # Method get_mount_facts raise TimeoutError

# Generated at 2022-06-22 23:18:10.836566
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'
    assert 'ansible_devices' not in h.facts


# Generated at 2022-06-22 23:18:12.292866
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:18:14.190011
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert [True for i in obj.collect() if i == 'ansible_system']



# Generated at 2022-06-22 23:18:14.937308
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    pass

# Generated at 2022-06-22 23:18:17.220033
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:18:19.463730
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Create an object of HurdHardwareCollector
    """
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:18:20.838395
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware.platform == 'GNU'



# Generated at 2022-06-22 23:18:22.623406
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert(hurd_hardware.platform == "GNU")

# Generated at 2022-06-22 23:18:23.590863
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
  HurdHardwareCollector()

# Generated at 2022-06-22 23:18:26.174511
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Test the class HurdHardware
    """
    hardware = HurdHardware()

    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:18:27.534588
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()
    assert hardware.platform == 'GNU'

# Generated at 2022-06-22 23:18:30.469631
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._fact_class is HurdHardware
    assert hurd_hardware_collector._platform == 'GNU'

# Generated at 2022-06-22 23:18:32.901217
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts_dict = HurdHardwareCollector()
    assert facts_dict._platform == 'GNU'
    assert isinstance(facts_dict._fact_class, HurdHardware)


# Generated at 2022-06-22 23:18:39.320809
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.populate() == {'uptime_seconds': 0, 'uptime_hours': 0, 'uptime_days': 0, 'uptime_minutes': 0,
                                        'uptime_precision': 0, 'memory_mb': 0, 'memory_swap': 0, 'mounts': []}

# Generated at 2022-06-22 23:18:40.710428
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector(None, None)._platform == 'GNU'

# Generated at 2022-06-22 23:18:43.076630
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    test_obj = HurdHardwareCollector()
    assert test_obj._fact_class == HurdHardware
    assert test_obj._platform == 'GNU'

# Generated at 2022-06-22 23:18:45.733619
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc.platform == 'GNU'
    assert hc._fact_class == HurdHardware


# Generated at 2022-06-22 23:18:51.850106
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = HurdHardwareCollector()
    hardware = hardware_collector.collect(module=module, collected_facts=dict())
    assert hardware is not None
    assert hardware.get("uptime") is not None
    assert hardware.get("mounts") is not None
    assert hardware.get("swap") is not None
    assert hardware.get("memtotal_mb") is not None
    assert hardware.get("memfree_mb") is not None

# Generated at 2022-06-22 23:18:52.986225
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware_facts = HurdHardware()
    assert hardware_facts.platform == 'GNU'

# Generated at 2022-06-22 23:18:54.536075
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware(None, None)

    assert hurdHardware.platform == 'GNU'

# Generated at 2022-06-22 23:18:56.817730
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(), HardwareCollector)

# Generated at 2022-06-22 23:19:01.468731
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_procfs_hardware = HurdHardware()
    assert isinstance(hurd_procfs_hardware, HurdHardware)
    assert isinstance(hurd_procfs_hardware, LinuxHardware)
    assert isinstance(hurd_procfs_hardware, HardwareCollector)

# Generated at 2022-06-22 23:19:08.456600
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.interface.path_exists('/proc/uptime')
    assert hw.interface.is_file('/proc/uptime')
    assert hw.interface.path_exists('/proc/meminfo')
    assert hw.interface.is_file('/proc/meminfo')
    assert hw.interface.path_exists('/proc/mounts')
    assert hw.interface.is_file('/proc/mounts')
    assert hw.interface.path_exists('/proc/swaps')
    assert hw.interface.is_file('/proc/swaps')


# Generated at 2022-06-22 23:19:13.222869
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    """
    Constructor of class HurdHardwareCollector must throw AssertionError
    if platform != GNU
    """

    import pytest

    with pytest.raises(AssertionError) as excinfo:
        HurdHardwareCollector('FOOBAR')
    assert "The platform must be 'GNU'" in str(excinfo.value)

# Generated at 2022-06-22 23:19:16.631773
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Test HurdHardware constructor.
    """
    hurdfacts = HurdHardware()
    assert hurdfacts.platform == 'GNU'

# Generated at 2022-06-22 23:19:26.540593
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw_obj = HurdHardware()
    collected_facts = {'ansible_hostname':'foo'}
    expected_hardware_facts = {'ansible_hostname':'foo', 'uptime':42.24,
                               'uptime_seconds':42.24, 'memtotal_mb':12345}

    hurd_hw_obj.get_uptime_facts = lambda: {'uptime': 42.24,
                                            'uptime_seconds': 42.24}
    hurd_hw_obj.get_memory_facts = lambda: {'memtotal_mb': 12345}
    hurd_hw_obj.get_mount_facts = lambda: {'mounts':
                                           [{'mount':'/foo/bar'}]}
    assert expected_hardware_facts == hurd_hw_obj.pop

# Generated at 2022-06-22 23:19:28.843793
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdhw = HurdHardware()
    assert hurdhw.platform == 'GNU'


# Generated at 2022-06-22 23:19:32.144633
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    results = h.populate()
    assert results is not None
    assert 'uptime' in results
    assert 'uptime_seconds' in results
    assert 'swaptotal_mb' in results

# Generated at 2022-06-22 23:19:37.348684
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHW = HurdHardware()
    assert hurdHW.platform == 'GNU'
    assert type(hurdHW) == HurdHardware


# Generated at 2022-06-22 23:19:38.215733
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hh = HurdHardware()
    assert type(hh) == HurdHardware


# Generated at 2022-06-22 23:19:40.236176
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:19:41.735305
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert isinstance(HurdHardwareCollector(None), HurdHardwareCollector)

# Generated at 2022-06-22 23:19:46.190465
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    collected_facts = {
      'ansible_processor_count': 4,
      'ansible_processor_vcpus': 4,
      'ansible_processor': [
        'Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz',
        'Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz',
        'Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz',
        'Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz'
      ]
    }

    facts = hw.populate(collected_facts)

    assert facts['system_vendor'] == 'LENOVO'

# Generated at 2022-06-22 23:19:54.378644
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    collected_facts = hardware.populate()
    assert collected_facts == {'uptime_seconds': 0,
                               'uptime_hours': 0,
                               'uptime_days': 0,
                               'uptime': 0,
                               'memtotal_mb': 0,
                               'memfree_mb': 0,
                               'memcached_mb': 0,
                               'membuffer_mb': 0,
                               'swaptotal_mb': 0,
                               'swapfree_mb': 0,
                               'mounts': [],
                               'fstype': [],
                               'filesystem': [],
                               'device': [],
                               'uuid': []}

# Generated at 2022-06-22 23:19:58.227137
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector.collect() == HurdHardwareCollector.collect()
    assert HurdHardwareCollector.collect()['uptime_seconds'] > 0
    assert HurdHardwareCollector.collect()['uptime_seconds'] <= 1000000000

# Generated at 2022-06-22 23:20:00.690135
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector_object = HurdHardwareCollector()
    assert hardware_collector_object.platform == 'GNU'


# Generated at 2022-06-22 23:20:02.223018
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    hh.populate()

# Generated at 2022-06-22 23:20:03.165098
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:20:05.886169
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hw = HurdHardware()
    assert hw.__class__.__name__ == 'HurdHardware'
    assert hw.platform == 'GNU'
    assert hw.distribution == 'GNU/Hurd'


# Generated at 2022-06-22 23:20:19.224176
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test HurdHardware.populate method
    """
    hardware = HurdHardware()

    uptime_facts = {'uptime_seconds': 1}
    memory_facts = {'memtotal_mb': 2}
    mount_facts = {'filesystems': ['filesystem1']}


    HurdHardware.get_uptime_facts = lambda self: uptime_facts
    HurdHardware.get_memory_facts = lambda self: memory_facts
    HurdHardware.get_mount_facts = lambda self: mount_facts

    assert hardware.populate() == {
        'uptime_seconds': uptime_facts['uptime_seconds'],
        'memtotal_mb': memory_facts['memtotal_mb'],
        'filesystems': mount_facts['filesystems']
    }

# Unit test

# Generated at 2022-06-22 23:20:20.797653
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hwCollector = HurdHardwareCollector()
    assert hwCollector.platform == 'GNU'

# Generated at 2022-06-22 23:20:23.259681
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    facts = HurdHardware()
    assert facts._platform == 'GNU'


# Generated at 2022-06-22 23:20:25.303368
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    # test that facts was successfully populated
    facts = hurd_hardware.populate()
    assert facts is not None

# Generated at 2022-06-22 23:20:26.554957
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    _fact_class = HurdHardware()
    assert _fact_class.populate()

# Generated at 2022-06-22 23:20:29.779097
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj_hardware_collector = HurdHardwareCollector()
    assert obj_hardware_collector._fact_class
    assert obj_hardware_collector._platform

    assert type(obj_hardware_collector._fact_class) == HurdHardware
    assert obj_hardware_collector._platform == 'GNU'


# Generated at 2022-06-22 23:20:32.795569
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdHardware


# Generated at 2022-06-22 23:20:34.030987
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    HurdHardwareCollector()

# Generated at 2022-06-22 23:20:41.624142
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # mock the module
    module = Mock()
    # init HurdHardware
    hardware = HurdHardware(module)
    # populate hardware facts
    hardware.populate()
    hardware_facts = hardware.get_facts()

# Generated at 2022-06-22 23:20:44.782636
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-22 23:20:52.931507
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockFactClass(HurdHardware):

        def __init__(self):
            self.memory_facts = {'memory_mb': {
                'real': {
                    'total': 800,
                    'free': 400,
                }
            }}

# Generated at 2022-06-22 23:20:55.844407
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h_facts = HurdHardware('repo_url', 'timeout')
    h_facts.populate({})

# Generated at 2022-06-22 23:21:04.596336
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import pytest

    from ansible.module_utils.facts.hardware.linux import HurdHardware

    test_HurdHardware = HurdHardware()
    test_pop = test_HurdHardware.populate()

    assert type(test_pop) is dict

    assert 'memory_mb' in test_pop
    assert 'memfree_mb' in test_pop
    assert 'swapfree_mb' in test_pop
    assert 'uptime_seconds' in test_pop
    assert 'mounts' in test_pop



# Generated at 2022-06-22 23:21:06.762452
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj1 = HurdHardwareCollector()
    assert obj1._platform == 'GNU'
    assert obj1._fact_class == HurdHardware

# Generated at 2022-06-22 23:21:14.177810
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    collected_facts = {}
    collected_facts['virtual'] = 'physical'


# Generated at 2022-06-22 23:21:16.196164
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hg = HurdHardware()
    assert hg.platform == 'GNU'

# Generated at 2022-06-22 23:21:20.661737
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_collector = HurdHardwareCollector()
    collected_facts = fact_collector.collect(None, None)
    assert collected_facts['uptime_seconds'] > 0
    assert collected_facts['memfree_mb'] > 0
    assert 'mounts' in collected_facts

# Generated at 2022-06-22 23:21:26.155068
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    '''Unit test for constructor of class HurdHardwareCollector.'''
    hurd_hw_collector_object = HurdHardwareCollector()
    assert type(hurd_hw_collector_object).__name__ == 'HurdHardwareCollector'


# Generated at 2022-06-22 23:21:31.046137
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    facts = HurdHardwareCollector.collect()
    assert type(facts) is dict
    assert 'hardware' in facts
    assert type(facts['hardware']) is dict
    assert 'uptime' in facts['hardware']
    assert 'memory' in facts['hardware']
    assert 'mounts' in facts['hardware']

# Generated at 2022-06-22 23:21:38.905320
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockHurdHardware():
        def __init__(self):
            self.uptime_facts = {'uptime_seconds': 42}
            self.memory_facts = {'memory': {'swapfree_mb': 0}}
            self.mount_facts = {'mounts': []}
        def get_uptime_facts(self):
            return self.uptime_facts
        def get_memory_facts(self):
            return self.memory_facts
        def get_mount_facts(self):
            return self.mount_facts

    uptime_facts = {'uptime_seconds': 42}
    memory_facts = {'memory': {'swapfree_mb': 0}}
    mount_facts = {'mounts': []}

    mock_HurdHardware = MockHurdHardware()
    facts = mock_H

# Generated at 2022-06-22 23:21:40.786865
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()


# Generated at 2022-06-22 23:21:42.449045
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().platform == 'GNU'

# Generated at 2022-06-22 23:21:43.871166
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurdHardware = HurdHardware()
    assert hurdHardware.platform == 'GNU'

# Generated at 2022-06-22 23:21:45.620811
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hd = HurdHardware()
    assert hd is not None

# Generated at 2022-06-22 23:21:47.415052
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware_populate_obj = HurdHardware()
    HurdHardware_populate_obj.populate()

# Generated at 2022-06-22 23:21:52.881718
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector
    hardware_collector = HurdHardwareCollector()
    assert hardware_collector._platform == 'GNU'
    assert hardware_collector._fact_class == HurdHardware
    assert issubclass(hardware_collector._fact_class, LinuxHardware)


# Generated at 2022-06-22 23:22:04.237885
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU', \
        "Expected platform to be 'GNU', but got '%s'" \
        % hurd_hardware_collector._platform

    assert isinstance(hurd_hardware_collector._fact_class(), HurdHardware), \
        "Expected _fact_class to be of type HurdHardware, but got '%s'" \
        % hurd_hardware_collector._fact_class()


# Generated at 2022-06-22 23:22:05.720921
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_info = HurdHardware()
    hardware_info.populate()

# Generated at 2022-06-22 23:22:06.988999
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    assert HurdHardwareCollector

# Generated at 2022-06-22 23:22:08.352329
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware is not None

# Generated at 2022-06-22 23:22:10.607844
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc.get_fact_class() == HurdHardware
    assert hc.get_platform() == 'GNU'


# Generated at 2022-06-22 23:22:12.254852
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()

    assert hurd.platform == "GNU"



# Generated at 2022-06-22 23:22:14.428953
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector.platform == 'GNU'

# Generated at 2022-06-22 23:22:25.156153
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hostname = 'foo'
    hurd_hw = HurdHardware({'ansible_hostname': hostname}, timeout=1)

    ret = hurd_hw.populate()
    assert type(ret) is dict
    assert 'ansible_virtualization_role' in ret
    assert 'ansible_virtualization_type' in ret
    assert 'ansible_mounts' in ret
    assert 'swap' in ret
    assert 'ansible_machine' in ret
    assert 'ansible_product_name' in ret
    assert 'ansible_processor_count' in ret
    assert 'ansible_memtotal_mb' in ret
    assert 'ansible_uptime_seconds' in ret
    assert 'ansible_processor' in ret
    assert 'ansible_date_time' in ret

# Generated at 2022-06-22 23:22:34.526263
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware()
    facts_dict = facts.populate()
    assert facts_dict['uptime_seconds'] == 1586
    assert facts_dict['memory_mb']['real']['total'] == 3004
    assert facts_dict['memory_mb']['real']['free'] == 2236
    assert facts_dict['memory_mb']['real']['used'] == 768
    assert facts_dict['memory_mb']['swap']['total'] == 1020
    assert facts_dict['memory_mb']['swap']['free'] == 1020
    assert facts_dict['memory_mb']['swap']['used'] == 0
    assert len(facts_dict['mounts']) == 1

# Generated at 2022-06-22 23:22:38.700414
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    hardware_facts = hh.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['mounts']

# Generated at 2022-06-22 23:22:40.467509
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert hurd_hardware.platform == 'GNU'


# Generated at 2022-06-22 23:22:42.184070
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd = HurdHardware()
    assert hurd.platform == 'GNU'


# Generated at 2022-06-22 23:22:46.294597
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()

    facts = h.populate()

    assert 'uptime_seconds' in facts
    assert 'uptime_hours' in facts
    assert 'uptime_days' in facts

    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

    assert 'mounts' in facts

# Generated at 2022-06-22 23:22:55.334808
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()

    assert facts['uptime_seconds'] >= 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_days'] >= 0

    assert 'MemTotal' in facts['ansible_meminfo']
    assert 'MemFree' in facts['ansible_meminfo']
    assert 'SwapTotal' in facts['ansible_meminfo']
    assert 'SwapFree' in facts['ansible_meminfo']

    assert 'Mounted on' in facts['ansible_mounts'][0]
    assert 'Mounted on' in facts['ansible_mounts'][-1]
    assert 'Device' in facts['ansible_mounts'][0]

# Generated at 2022-06-22 23:23:02.168951
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    # test_HurdHardwareCollector
    # Testing constructor of class HurdHardwareCollector
    #
    # Input parameters:
    #    None
    #
    # Expected result:
    #    object of class HurdHardwareCollector should be created
    #
    # Observed result:
    #    object of class HurdHardwareCollector is created
    #
    # Comments:
    #

    hurd_hw_col = HurdHardwareCollector()



# Generated at 2022-06-22 23:23:03.549818
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    import pytest
    # Just instantiate to verify the constructor
    HurdHardwareCollector()

# Generated at 2022-06-22 23:23:06.284585
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurd_hardware_collector = HurdHardwareCollector()
    assert hurd_hardware_collector._platform == 'GNU'
    assert hurd_hardware_collector._fact_class == HurdHardware

# Generated at 2022-06-22 23:23:16.376951
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    fact_gather = HurdHardwareCollector()
    collected_facts = {}
    collected_facts['ansible_system'] = 'GNU'
    fact_gather.populate(collected_facts)
    ## ansible_mounts
    assert 'ansible_mounts' in collected_facts
    # assert isinstance(collected_facts['ansible_mounts'], list)
    # assert len(collected_facts['ansible_mounts']) > 0
    # for entry in collected_facts['ansible_mounts']:
    #     assert isinstance(entry, dict)
    #     assert len(entry) == 5
    #     assert entry['mount']
    #     assert entry['device']
    #     assert entry['fstype']
    #     assert entry['options']
    #     assert isinstance(

# Generated at 2022-06-22 23:23:18.137354
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    collector = HurdHardwareCollector()
    assert collector is not None

# Generated at 2022-06-22 23:23:21.307208
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hhc = HurdHardwareCollector()
    assert hhc._fact_class == HurdHardware
    assert hhc._platform == 'GNU'

# Generated at 2022-06-22 23:23:21.916374
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    pass

# Generated at 2022-06-22 23:23:24.407738
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    obj = HurdHardwareCollector()
    assert obj.platform == 'GNU'
    assert obj._fact_class == HurdHardware

# Generated at 2022-06-22 23:23:26.302529
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts['uptime'] == 0

# Generated at 2022-06-22 23:23:27.672812
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    fact = HurdHardwareCollector()
    assert fact._platform == 'GNU'

# Generated at 2022-06-22 23:23:31.013917
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hc = HurdHardwareCollector()
    assert hc.platform == 'GNU'
    assert hc.fact_class == HurdHardware
    assert hc.fact_class._platform == 'GNU'

# Generated at 2022-06-22 23:23:34.717543
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hardware_collector_object = HurdHardwareCollector()
    assert hardware_collector_object._fact_class is HurdHardware
    assert hardware_collector_object._platform == 'GNU'

# Generated at 2022-06-22 23:23:38.737423
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """ Unit test for method Hardware.populate of class HurdHardware """
    hurd_hardware = HurdHardware()
    result = hurd_hardware.populate()
    assert isinstance(result, dict)

# Generated at 2022-06-22 23:23:47.804343
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().populate() == {
        'uptime_seconds': 100.0,
        'mounts': [{
            'device': '/dev/sda1',
            'fstype': 'ext4',
            'mount': '/'
        }],
        'fstab': [{
            'file': '/',
            'file_system_type': 'ext4',
            'mount': '/',
            'mount_options': 'rw',
            'vfstype': 'ext4'
        }],
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
        'total_memor_kb': 0,
        'vendor': 'Hurd',
        'memfree_mb': 0,
        'memtotal_mb': 0
    }

# Generated at 2022-06-22 23:23:50.393683
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    h = HurdHardware()
    assert h.platform == 'GNU'
    assert issubclass(HurdHardware, LinuxHardware)


# Generated at 2022-06-22 23:23:58.429227
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    """
    Create an instance of HurdHardware Class.
    """
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, LinuxHardware)
    assert hurd_hardware.platform == "GNU"
    assert hurd_hardware.get_uptime_facts.__doc__ == LinuxHardware.get_uptime_facts.__doc__
    assert hurd_hardware.get_memory_facts.__doc__ == LinuxHardware.get_memory_facts.__doc__
    assert hurd_hardware.get_mount_facts.__doc__ == LinuxHardware.get_mount_facts.__doc__

# Generated at 2022-06-22 23:24:01.367690
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_Hw = HurdHardware()
    upt_hw = HurdHardware.get_uptime_facts()
    mem_hw = HurdHardware.get_memory_facts()

# Generated at 2022-06-22 23:24:02.314352
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    pass

# Generated at 2022-06-22 23:24:05.881284
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware.uptime, dict)
    assert isinstance(hurd_hardware.memory, dict)
    assert isinstance(hurd_hardware.mounts, list)

# Generated at 2022-06-22 23:24:09.361682
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts_to_set = {}
    facts = HurdHardware(facts_to_set, None)
    facts.populate()
    assert facts_to_set['uptime_seconds'] == 0


# Generated at 2022-06-22 23:24:16.624556
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hardware = HurdHardware()

    assert hardware.platform == 'GNU'
    assert hardware.get_file_content('/proc/meminfo') == hardware._get_file_content('/proc/meminfo')
    assert hardware.path_exists('/proc') is True
    assert hardware.get_mount_facts() == hardware.get_mount_facts(filesystems=['proc'])
    assert hardware.get_uptime_facts() == hardware.get_uptime_facts(require_uptime=True)

# Generated at 2022-06-22 23:24:17.784083
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    assert HurdHardware().platform == 'GNU'


# Generated at 2022-06-22 23:24:21.348586
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    data = HurdHardwareCollector()
    assert data is not None
    assert data._platform == 'GNU'
    assert data._fact_class == HurdHardware

# Generated at 2022-06-22 23:24:22.813227
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    hurd_h = HurdHardware()
    assert hurd_h is not None

# Generated at 2022-06-22 23:24:30.514020
# Unit test for constructor of class HurdHardware
def test_HurdHardware():
    test_hardware = HurdHardware()

    assert test_hardware.platform == "GNU"
    assert test_hardware._host_sys_devices_path == "/host/sys/devices"
    assert test_hardware._host_proc_path == "/host/proc"
    assert test_hardware._host_sys_path == "/host/sys"
    assert test_hardware._host_sys_fs_host_mem_path == "/host/sys/fs/host/mem"
    assert test_hardware._proc_mounts_path == "/proc/mounts"
    assert test_hardware._proc_filesystems_path == "/proc/filesystems"
    assert test_hardware._proc_meminfo_path == "/proc/meminfo"

# Generated at 2022-06-22 23:24:32.882370
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    
    assert HurdHardwareCollector._platform == 'GNU'
    assert HurdHardwareCollector._fact_class == HurdHardware

# Generated at 2022-06-22 23:24:34.873680
# Unit test for constructor of class HurdHardwareCollector
def test_HurdHardwareCollector():
    hurdhwCollector = HurdHardwareCollector()
    assert HurdHardwareCollector() == hurdhwCollector