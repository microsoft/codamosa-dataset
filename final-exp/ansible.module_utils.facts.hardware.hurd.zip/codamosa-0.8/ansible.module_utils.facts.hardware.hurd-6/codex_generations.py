

# Generated at 2022-06-11 02:43:10.284470
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-11 02:43:14.353315
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Initialize a HurdHardware instance.
    hurd_hardware = HurdHardware()
    # Invoke method populate
    hurd_hardware.populate()
    # Check that memory and mount facts are present in the output
    # of the method.
    assert 'memory' in hurd_hardware.data
    assert 'mounts' in hurd_hardware.data

# Generated at 2022-06-11 02:43:20.556959
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    '''Test the method populate of class HurdHardware'''
    # Build the class to test within a try except block to catch
    # unexpected exceptions and on failure print the local variables
    # for inspection
    try:
        hw = HurdHardware()
        result = hw.populate()
        assert result is not None
    except Exception as e:
        print(e)
        for key, value in locals().items():
            print('%s=%s' % (key, value))


# Generated at 2022-06-11 02:43:29.761974
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class TestHurdHardware(HurdHardware):
        def __init__(self):
            self.uptime_facts = {'uptime': '100'}
            self.memory_facts = {'memory': 'hal-9000'}
            self.mount_facts = {'mount': 'Traveler'}
        
        def get_uptime_facts(self):
            return self.uptime_facts

        def get_memory_facts(self):
            return self.memory_facts

        def get_mount_facts(self):
            return self.mount_facts
    
    hurd_hw_collector = TestHurdHardware()
    hardware_facts = hurd_hw_collector.populate()

    assert hardware_facts != None
    assert hardware_facts['uptime'] == '100'

# Generated at 2022-06-11 02:43:33.385544
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = HurdHardware().populate()
    assert result['uptime_seconds'] == 0
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swapavail_mb' in result

# Generated at 2022-06-11 02:43:37.800001
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MockHurdCollectorModule:
        def __init__(self):
            self.params = {'gather_timeout': 30}

    class MockHurdHardwareModule:
        def __init__(self):
            self.params = {'gather_mount_timeout': 30}

    module = MockHurdCollectorModule()
    hurdhw = HurdHardware(module=module)
    #Test if mount_facts are added to the dictionary
    assert 'mounts' in hurdhw.populate().keys()

# Generated at 2022-06-11 02:43:40.691858
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware_collector._module_lock = False  # disable module lock
    hurd_hardware_collector.collect()

# Generated at 2022-06-11 02:43:42.217550
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test if the populate method of the class HurdHardware works.
    """
    pass

# Generated at 2022-06-11 02:43:51.272457
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts_obj = HurdHardware()
    hurd_facts = hurd_facts_obj.populate()

    assert type(hurd_facts['uptime']) == int
    assert type(hurd_facts['uptime_seconds']) == int
    assert 'swapfree_mb' in hurd_facts
    assert type(hurd_facts['swapfree_mb']) == int
    assert 'swaptotal_mb' in hurd_facts
    assert type(hurd_facts['swaptotal_mb']) == int
    assert type(hurd_facts['memfree_mb']) == int
    assert type(hurd_facts['memtotal_mb']) == int
    assert type(hurd_facts['mounts']) == list

# Generated at 2022-06-11 02:43:55.911783
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    # This test is somewhat difficult to write, because the translator
    # may not be installed and the translator may not be booted.
    # We could chroot or use a special Hurd in QEMU to avoid this,
    # but for now we simply check a single fact that is hard to get wrong,
    # as this is sufficient to make sure we exercise the tested code.
    assert 'uptime' in hurd_hw.populate()

# Generated at 2022-06-11 02:44:08.135877
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """See if this works at all!
    """

# Generated at 2022-06-11 02:44:16.248307
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    coll_facts = {}
    coll_facts['ansible_uptime_seconds'] = 45
    coll_facts['ansible_memfree_mb'] = 45
    coll_facts['ansible_mounts'] = [{'mount': '/', 'device': '/dev/sda'}]
    retrieved_facts = hurd_hardware.populate(coll_facts)

    assert coll_facts['ansible_uptime_seconds'] == retrieved_facts['ansible_uptime_seconds']
    assert coll_facts['ansible_memfree_mb'] == retrieved_facts['ansible_memfree_mb']
    assert coll_facts['ansible_mounts'][0]['mount'] == retrieved_facts['ansible_mounts'][0]['mount']

# Generated at 2022-06-11 02:44:24.213625
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import GetData
    test_data = {
        'uptime_seconds' : 1234,
        'memtotal_mb' : 1,
        'memfree_mb' : 2,
        'swaptotal_mb' : 3,
        'swapfree_mb' : 4,
        'mounts': [
            {
                'mount': '/',
                'device': '/dev/device_id',
                'fstype': 'fstype',
                'options': 'options',
            },
        ],
    }

    class Module:
        def get_bin_path(self, arg):
            return None

    module = Module()
    facts = HurdHardware()

    def get_data(name, default=None):
        assert 'uptime' == name

# Generated at 2022-06-11 02:44:26.507906
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware()
    hh.populate()
    assert hh.facts['memory_mb']


# vim: set filetype=python :

# Generated at 2022-06-11 02:44:31.875121
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Test the method populate of class HurdHardware"""
    # init class HurdHardware
    hurd_hardware = HurdHardware({})
    # run populate
    hurd_hardware.populate(collected_facts={})
    # check that it returns a dictionary
    assert isinstance(hurd_hardware.populate(collected_facts={}), dict)


# Generated at 2022-06-11 02:44:34.656809
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw_fact = HurdHardware()
    hurd_hw_fact.get_mount_facts = lambda: {}
    hurd_hw_fact.get_uptime_facts = lambda: {}
    hurd_hw_fact.get_memory_facts = lambda: {}
    data = hurd_hw_fact.populate()
    assert data  # Not empty
    assert 'mem_facts' in data
    assert 'mount_facts' in data
    assert 'uptime_facts' in data

# Generated at 2022-06-11 02:44:42.236086
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts['uptime_hours'] == 0.0
    assert facts['uptime_seconds'] == 0
    assert facts['uptime_days'] == 0.0
    assert facts['mounts'][0]['device'] == 'rootfs'
    assert facts['mounts'][0]['size_total'] == 0
    assert facts['mounts'][0]['size_available'] == 0
    assert facts['mounts'][0]['size_used'] == 0
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['devicememory_mb'] == 0

# Generated at 2022-06-11 02:44:47.154236
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()

    # Test for GNU/Hurd
    result = obj.populate()

    assert result['uptime_seconds'] == 100
    assert result['uptime_hours'] == 2
    assert result['uptime_days'] == 0
    assert result['uptime'] == '2 hours'
    assert result['memtotal_mb'] == 1024
    assert result['memfree_mb'] == 512
    assert result['swaptotal_mb'] == 2048
    assert result['swapfree_mb'] == 2048

# Generated at 2022-06-11 02:44:58.445957
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from collections import namedtuple

    from ansible.module_utils.facts.hardware.gnu import HurdHardware

    # Test HurdHardware.populate with values resulting from a successful
    # collection of hardware facts
    hardware_facts = HurdHardware()


# Generated at 2022-06-11 02:45:09.746667
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for the method HurdHardware.populate.
    """

    # Setup
    module = type('module', (object,), {'params': {'gather_timeout': 1}})
    hw = HurdHardware(module)
    hw.module.exit_json = lambda x: x
    uptime_facts = {
        'uptime': {
            'days': 0,
            'hours': 0,
            'minutes': 0,
            'seconds': 0
        },
        'uptime_format': '0 hours, 0 minutes'
    }
    hw.get_uptime_facts = lambda: uptime_facts

# Generated at 2022-06-11 02:45:15.960707
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    result = HurdHardware().populate()
    assert 'uptime' in result
    assert 'uptime_seconds' in result
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result


# Generated at 2022-06-11 02:45:19.705309
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_facts = HurdHardware().populate()
    assert 'uptime' in hurd_facts
    assert 'uptime_seconds' in hurd_facts
    assert 'memory' in hurd_facts
    assert 'swap' in hurd_facts
    assert 'mounts' in hurd_facts

# Generated at 2022-06-11 02:45:28.097813
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class myLinuxHardware(HurdHardware):
        def __init__(self):
            super(myLinuxHardware, self).__init__()
            self.uptime_facts = dict(uptime=10)
            self.memory_facts = dict(memtotal=100)
            self.mount_facts = dict(mounts=12)

        def get_uptime_facts(self):
            return self.uptime_facts

        def get_memory_facts(self):
            return self.memory_facts

        def get_mount_facts(self):
            return self.mount_facts

    class myHurdHardwareCollector(HurdHardwareCollector):
        def __init__(self):
            super(myHurdHardwareCollector, self).__init__()
            self.hardware = myLinuxHardware()

    hurdHardwareCollector = my

# Generated at 2022-06-11 02:45:33.068460
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate(None)
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] >= 0

    assert facts['memory_mb']['real']['total'] > 0
    assert facts['memory_mb']['swap']['total'] > 0

    assert facts['mounts'] is not None

# Generated at 2022-06-11 02:45:33.998593
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    print(HurdHardware().populate())

# Generated at 2022-06-11 02:45:38.758808
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    collected_facts = hw.populate()

    assert 'uptime_seconds' in collected_facts
    assert 'uptime_days' in collected_facts

    assert 'memory_mb' in collected_facts
    assert 'memory_mb_used' in collected_facts
    assert 'memory_mb_free' in collected_facts
    assert 'swap_mb' in collected_facts
    assert 'swap_mb_used' in collected_facts
    assert 'swap_mb_free' in collected_facts

    assert 'mounts' in collected_facts

# Generated at 2022-06-11 02:45:46.702511
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create an object of the class HurdHardware
    hardware = HurdHardware(module=None)

    # Create dictionary of facts and parameters
    collected_facts = {
        'kernel': 'GNU/Hurd',
        'os_family': 'GNU/Hurd'
    }

    # Test the populate method and check the result
    hardware_facts = hardware.populate(collected_facts)
    assert 'uptime_seconds' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'mounts' in hardware_facts


# Generated at 2022-06-11 02:45:48.369973
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware_ = HurdHardware()
    assert type(HurdHardware_.populate()) is dict

# Generated at 2022-06-11 02:45:54.525467
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware.populate()

    assert hardware.disks['sda']['vendor'] == 'ATA'
    assert hardware.disks['sda']['model'] == 'QEMU HARDDISK'
    assert hardware.disks['sda']['size'] == 10737418240
    assert hardware.disks['sda']['rotational'] == '1'
    assert hardware.disks['sda']['serial'] == 'QM00001'
    assert hardware.disks['sda']['host'] == 'ide0'
    assert hardware.disks['sda']['bus'] == 'ide'

# Generated at 2022-06-11 02:45:56.021511
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    facts = hardware_facts.populate()
    assert 'uptime' in facts

# Generated at 2022-06-11 02:46:00.344441
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Instantiate
    hw = HurdHardware()
    # Call populate method
    facts = hw.populate()

    # Assert
    assert facts == {}

# Generated at 2022-06-11 02:46:09.875949
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

    collected_facts = {'ansible_distribution_release': '8.2',
                       'ansible_distribution_version': '8.2',
                       'ansible_distribution': 'Debian'}

    hurd_hardware_facts = hurd_hardware.populate(collected_facts)
    assert 'uptime_seconds' in hurd_hardware_facts
    assert 'uptime_days' in hurd_hardware_facts
    assert 'memory_mb' in hurd_hardware_facts
    assert 'mounts' in hurd_hardware_facts
    assert 'swapfree_mb' in hurd_hardware_facts
    assert 'swaptotal_mb' in hurd_hardware_facts

# Generated at 2022-06-11 02:46:19.278328
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def mock_getuptime_facts(self):
        return {'uptime_seconds': 1,
                'uptime_hours': 0,
                'uptime_days': 1}

    def mock_getmemory_facts(self):
        return {'memfree_mb': 1,
                'memtotal_mb': 1,
                'swapfree_mb': 0,
                'swaptotal_mb': 0}

    def mock_getmount_facts(self):
        return {'mounts': [
            {'mount': "/", 'device': "foo/bar", 'filesystem': "bar/baz"},
            {'mount': "/boot", 'device': "boot", 'filesystem': "boot"}
        ]}

    HardwareCollector._collectors['GNU'] = HurdHardwareCollector
    h = HurdHardware()

# Generated at 2022-06-11 02:46:29.050232
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

# Generated at 2022-06-11 02:46:38.532734
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.timeout import TimeoutError

    # Mock load_file and load_file_to_str
    import sys
    import fakefs
    fakefs.install()
    sys.modules['ansible.module_utils.facts.timeout'] = fakefs.fakefsenv.fs
    real_timeout = __import__('ansible.module_utils.facts.timeout', globals(), locals(), ['TimeoutError'], -1)
    real_timeout.TimeoutError = TimeoutError
    sys.modules['ansible.module_utils.facts.timeout'] = real_timeout
    collector = Collector()
    hurd_hardware_collector = HurdHardwareCollector(collector)

# Generated at 2022-06-11 02:46:48.018290
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test to ensure that the facts dictionary is as expected
    """
    hurd_hw = HurdHardware()

    data = {'machine': 'i386', 'nodename': 'hurd'}
    hurd_hw.data = data

    # Collect facts
    facts = hurd_hw.populate()

    # Assert facts
    assert 'uptime_seconds' in facts
    assert 'uptime_seconds_pretty' in facts
    assert 'uptime_ssh_readable' in facts

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

    assert 'memory_mb' in facts
    assert 'swapfile_present' in facts
    assert 'swapfile_mb' in facts

    assert 'mounts' in facts

# Generated at 2022-06-11 02:46:55.050567
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()

# Generated at 2022-06-11 02:47:00.382160
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert 'swapfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['memavailable_mb'] > 0
    assert facts['swapfree_mb'] >= 0
    assert len(facts['mounts']) >= 0


# Generated at 2022-06-11 02:47:09.614124
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test for method populate of class HurdHardware.
    """
    hurd_collector = HurdHardwareCollector()

    # Mock the uptime_facts method
    def mock_uptime_facts(self):
        return {'uptime': '2 hours'}

    hurd_collector.fact_class.get_uptime_facts = mock_uptime_facts
    uptime_facts = hurd_collector.fact_class.get_uptime_facts()

    # Mock the memory_facts method
    def mock_memory_facts(self):
        memory_facts = {'swapfree_mb': 3,
                        'memfree_mb': 5,
                        'memtotal_mb': 10}
        return memory_facts

    hurd_collector.fact_class.get_memory_facts = mock_memory_facts
    memory

# Generated at 2022-06-11 02:47:13.901271
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class HurdHardware(LinuxHardware):
        platform = 'GNU'

    class HurdHardwareCollector(HardwareCollector):
        _fact_class = HurdHardware
        _platform = 'GNU'

    i = HurdHardwareCollector()
    i.populate()
    assert HurdHardware().populate() == i.get_all_facts()

# Generated at 2022-06-11 02:47:24.368909
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    m = HurdHardware()
    gathered_facts = m.populate()

    # Asserts
    keys = [
        'processor_count',
        'uptime',
        'uptime_days',
    ]

    for key in keys:
        assert(key in gathered_facts)

    assert(type(gathered_facts['processor_count']) == int)
    assert(gathered_facts['processor_count'] > 0)
    assert(type(gathered_facts['uptime']) == int)
    assert(gathered_facts['uptime'] > 0)
    assert(type(gathered_facts['uptime_days']) == int)
    assert(gathered_facts['uptime_days'] >= 0)

# Generated at 2022-06-11 02:47:30.671174
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class MsgModule:
        def __init__(self):
            self.params = {}
    class FactsCollector:
        def __init__(self):
            self._collectors = []
            self.ansible_facts = {}

    msg = MsgModule()
    facts = FactsCollector()
    hw = HurdHardware(msg, facts)

    facts = hw.populate()
    for k, v in facts.items():
        print("%s:%s" % (k, v))

if __name__ == '__main__':
    test_HurdHardware_populate()

# Generated at 2022-06-11 02:47:37.404946
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # initialize
    hw = HurdHardware()

    # populate
    facts = hw.populate()

    # test
    assert facts['uptime'] > 0
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert 'mounts' in facts
    assert len(facts['mounts']) >= 0

# Generated at 2022-06-11 02:47:41.851058
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()

    assert 'uptime' in facts
    assert 'uptime_seconds' in facts

    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

    assert 'mounts' in facts

# Generated at 2022-06-11 02:47:43.691300
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_dict = hardware.populate()
    assert hardware_dict

# Generated at 2022-06-11 02:47:45.816315
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    f = h.populate()
    assert f['uptime_seconds'] > 0

# vim: set et sts=4 sw=4 :

# Generated at 2022-06-11 02:47:51.050747
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    facts = hw.populate()
    assert facts['uptime_seconds'] == 135599
    assert facts['memory_mb']['real']['total'] == 1023
    assert facts['mounts'][0]['mount'] == '/'
    assert facts['mounts'][0]['device'] == '/dev/hd0s1'
    assert facts['mounts'][0]['fstype'] == 'ufs'

# Generated at 2022-06-11 02:47:54.243456
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    htt = HurdHardware()
    result = htt.populate()
    assert ('ansible_uptime_seconds' in result)
    assert ('ansible_memfree_mb' in result)
    assert ('ansible_mounts' in result)

# Generated at 2022-06-11 02:47:59.825190
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert facts["uptime"] > 0
    assert facts["uptime_seconds"] > 0
    assert facts["uptime_format"] != ''

    assert facts["memfree_mb"] >= 0
    assert facts["memtotal_mb"] >= 0

    assert facts["swaptotal_mb"] >= 0
    assert facts["swapfree_mb"] >= 0

    assert facts["mounts"] != []

# Generated at 2022-06-11 02:48:02.644841
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw_obj = HurdHardware(None)
    hurdhw_obj.collect()
    assert(hurdhw_obj.facts['mounts'] != None)
    assert(len(hurdhw_obj.facts['mounts']) > 0)

# Generated at 2022-06-11 02:48:08.405869
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()
    actual = obj.populate()
    import sys
    assert sys.platform == 'gnu0'
    assert len(actual) > 0
    assert 'memory' in actual
    assert 'swaptotal_mb' in actual['memory']
    assert 'mounts' in actual
    assert 'virtual_subsystem' in actual

# Generated at 2022-06-11 02:48:15.708696
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    hurd_hw.populate()
    assert hurd_hw.uptime['seconds'] >= 0
    assert hurd_hw.uptime['hour'] >= 0
    assert hurd_hw.uptime['minute'] >= 0
    assert hurd_hw.memory['swapfree'] >= 0
    assert hurd_hw.memory['swaptotal'] >= 0
    assert hurd_hw.get_mounts() != None

# Generated at 2022-06-11 02:48:19.675749
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware.populate()
    assert type(hardware_facts) is dict
    assert type(hardware_facts['memfree_mb']) is int
    assert type(hardware_facts['memtotal_mb']) is int
    assert type(hardware_facts['mounts']) is list
    assert type(hardware_facts['uptime_seconds']) is int

# Generated at 2022-06-11 02:48:29.741618
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Intialize an instance of HurdHardware.
    Hurd_Hardware = HurdHardware()
    # Create data from get_memory_facts.
    Hurd_Hardware._meminfo = Hurd_Hardware.read_file('/proc/meminfo')
    # Create data from get_mount_facts.
    Hurd_Hardware._mountinfo = Hurd_Hardware.read_file('/proc/mounts')
    # Call the populate method and save the result.
    Hurd_Hardware_populate = Hurd_Hardware.populate()
    # Create the expected result.

# Generated at 2022-06-11 02:48:37.200935
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    output_uptime = ' 00:00:00 up 17:45, 0 users, load average: 0.00, 0.00, 0.00'

# Generated at 2022-06-11 02:48:47.742354
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    # Replace methods get_uptime_facts, get_memory_facts, get_mount_facts
    # with a function returning a dummy dictionary.
    hw.get_uptime_facts = lambda: {'uptime_servertime': 'servertime',
                                   'uptime_since_iso_8601': 'since_iso_8601',
                                   'uptime': 'uptime',
                                   'uptime_hours': 'uptime_hours',
                                   'uptime_days': 'uptime_days',
                                   'users': 'users'}

# Generated at 2022-06-11 02:48:51.608994
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
     Unit test for method populate of class HurdHardware
    """
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert isinstance(hurd_hardware, HurdHardware)


# Generated at 2022-06-11 02:48:57.284437
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware({'ansible_system': 'GNU'})
    assert isinstance(hurd, HurdHardware)
    assert sorted(hurd.populate().keys()) == ['ansible_devices', 'ansible_memfree_mb', 'ansible_memory_mb', 'ansible_mounts', 'ansible_uptime_seconds', 'ansible_virtualization_role', 'ansible_virtualization_type']

# Generated at 2022-06-11 02:48:58.537698
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hh = HurdHardware({})
    hh.populate()

# Generated at 2022-06-11 02:49:01.812030
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    res = h.populate()
    assert 'uptime' in res
    assert 'uptime_seconds' in res
    assert 'memtotal_mb' in res
    assert 'memfree_mb' in res
    assert 'swaptotal_mb' in res
    assert 'swapfree_mb' in res

# Generated at 2022-06-11 02:49:09.320136
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    obj = HurdHardware()
    collected_facts = {'ansible_system':'GNU/Hurd'}
    obj.populate(collected_facts)
    gathered_facts = {'ansible_mounts': [], 'ansible_uptime_seconds': [], 'ansible_memtotal_mb': []}
    assert gathered_facts == obj.get_facts()


# Generated at 2022-06-11 02:49:12.308173
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    obj = HurdHardware()
    result = obj.populate()
    assert 'memory_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result

    assert 'mounts' in result

# Generated at 2022-06-11 02:49:13.144905
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    assert hurd != None

# Generated at 2022-06-11 02:49:19.708296
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class TestArgs(object):
        def __init__(self, uptime="23197.33 4264.34"):
            self.uptime = uptime
        def get(self, _):
            return self.uptime

    hardware = HurdHardware(args=TestArgs())
    assert hardware.populate() == {'uptime': 23197.33, 'uptime_seconds': 23197.33,
        'uptime_hours': 6.4493, 'uptime_days': 0.27072, 'boottime': '1970-01-01 00:37:22 +0000'}

# Generated at 2022-06-11 02:49:21.581009
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_object = HurdHardware()

    expected_return = {'uptime': 0,}

    assert not test_object.populate()

# Generated at 2022-06-11 02:49:31.261220
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    _platform = 'GNU'
    hw = HurdHardware()
    collected_facts = {}
    _facts_uptime = {'uptime_seconds': 321587.87, 'uptime_hours': '89',
                     'uptime_days': '3'}
    _facts_mem = {'memtotal_mb': 676, 'memfree_mb': 277, 'memavail_mb': 277,
                  'swaptotal_mb': 1585, 'swapfree_mb': 1585,
                  'swapcached_mb': 0,
                  'avail_mb': 1013, 'used_mb': 663}

# Generated at 2022-06-11 02:49:32.608302
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()
    assert isinstance(hurd.populate(), dict)

# Generated at 2022-06-11 02:49:42.054627
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.timeout import TimeoutError
    hard_obj = HurdHardware()
    hard_obj.uptime_cmd = 'command_uptime'
    hard_obj.meminfo_cmd = 'command_meminfo'
    hard_obj.mount_cmd = 'command_mount'
    hard_obj.uptime_pattern = 'time_pattern'
    hard_obj.uptime_divisor = 'divisor'
    hard_obj.meminfo_pattern = 'time_pattern'

    uptime_facts = {
        'uptime_seconds': '10'
    }
    memory_facts = {
        'MemTotal': '1000',
        'MemFree': '500',
        'SwapTotal': '2000',
        'SwapFree': '1000'
    }


# Generated at 2022-06-11 02:49:43.820892
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware('linux')
    assert 'uptime' in hurdhw.populate()
    assert 'swapfree_mb' in hurdhw.populate()


# Generated at 2022-06-11 02:49:52.768430
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    uptime_facts = {
        'uptime': '12:00:00',
        'uptime_seconds': 43200,
        'uptime_days': 0,
        'uptime_hours': 12,
        'uptime_minutes': 0,
    }
    memory_facts = {
        'memfree_mb': 1,
        'memtotal_mb': 2,
        'swapfree_mb': 3,
        'swaptotal_mb': 4,
    }

# Generated at 2022-06-11 02:49:56.652752
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardwareCollector()
    fact = collector.collect()
    assert fact['version'] == 'GNU'

# Generated at 2022-06-11 02:49:58.002768
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    factory = HurdHardwareCollector()
    assert "HurdHardware" == factory.collect(None, {})["ansible_facts"]["ansible_machine"]



# Generated at 2022-06-11 02:50:01.458638
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    f = h.populate()
    assert f['uptime']['seconds'] > 0
    assert f['memtotal_mb'] > 0
    assert f['mounts']
    assert f['filesystems']

# Generated at 2022-06-11 02:50:02.376668
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] <= 3600, 'Wrong uptime'

# Generated at 2022-06-11 02:50:05.769290
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class collectFacts:
        sysctl = '/gnu/store/pw6cjcm6wdcbx9hc2l1fypm4h2c4jfz4-procfs-compat/libexec/procfs-compat'

    test_obj = HurdHardware(collectFacts())
    result = test_obj.populate()
    assert result.get('uptime')

# Generated at 2022-06-11 02:50:07.946250
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = {}
    m = HurdHardware()

    m.populate()
    assert isinstance(facts, dict)

# Generated at 2022-06-11 02:50:10.040020
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
   _HurdHardware = HurdHardware()
   hardware_facts = _HurdHardware.populate()

   assert hardware_facts

# Generated at 2022-06-11 02:50:12.566805
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    result_dict = hurd_hardware.populate()
    assert result_dict
    assert len(result_dict) > 0


# Generated at 2022-06-11 02:50:22.205722
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def get_uptime_facts():
        return {'ansible_uptime_seconds': 10}
    def get_memory_facts():
        return {'ansible_memtotal_mb': 10}
    def get_mount_facts():
        return {'ansible_mounts': []}

    hurd_hardware = HurdHardware()
    hurd_hardware.get_uptime_facts = get_uptime_facts
    hurd_hardware.get_memory_facts = get_memory_facts
    hurd_hardware.get_mount_facts = get_mount_facts
    assert hurd_hardware.populate() == {'ansible_uptime_seconds': 10,
                                        'ansible_memtotal_mb': 10,
                                        'ansible_mounts': []}

# Generated at 2022-06-11 02:50:31.149491
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw_facts = hw.populate()

    assert hw_facts['uptime_seconds'] > 0
    assert hw_facts['uptime_hours'] > 0
    assert hw_facts['uptime_days'] > 0
    assert hw_facts['memfree_mb'] > 0
    assert hw_facts['memtotal_mb'] > 0
    assert hw_facts['swapfree_mb'] > 0
    assert hw_facts['swaptotal_mb'] > 0

    assert hw_facts['mounts'][0]['device'] != ''



# Generated at 2022-06-11 02:50:35.720250
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # 'populate' should be able to get the hardware information
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()
    assert True

# Generated at 2022-06-11 02:50:42.377776
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    class MockHurdHardware(HurdHardware):

        def get_uptime_facts(self):
            return {}

        def get_memory_facts(self):
            return {}

        def get_mount_facts(self):
            raise TimeoutError("timeout")

    facts = MockHurdHardware().populate()

    assert facts["uptime_seconds"] is None
    assert facts["ansible_memtotal_mb"] is None
    assert facts["ansible_mounts"] is None

# Generated at 2022-06-11 02:50:50.167077
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils._text import to_bytes

    hw = HurdHardware()
    hw.populate()

    # check that the uptime field has been filled with 3 fields
    assert(len(hw.uptime) == 3)

    # check that the memory field has been filled with 9 fields
    assert(len(hw.memory) == 9)

    # check that the swap field has been filled with 3 fields
    assert(len(hw.swap) == 3)

    # check that the devices field has been filled with the right values
    assert(len(hw.devices) == 2)
    assert(to_bytes('/dev/sda1') in hw.devices)
    assert(to_bytes('/dev/sda2') in hw.devices)

# Generated at 2022-06-11 02:50:55.137987
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    collected_facts = {}

    # timeout test
    hw.get_mount_facts = lambda: {'timeout': 'test'}
    hardware_facts = hw.populate(collected_facts)
    assert not hardware_facts

    hw.get_mount_facts = lambda: {}
    hardware_facts = hw.populate(collected_facts)
    assert hardware_facts

# Generated at 2022-06-11 02:51:02.530909
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    f = HurdHardware()
    facts = f.populate()
    assert 'uptime_seconds' in facts.keys()
    assert 'uptime_hours' in facts.keys()
    assert 'uptime_days' in facts.keys()
    assert 'uptime_timestamp' in facts.keys()
    assert 'memfree_mb' in facts.keys()
    assert 'memfree_gb' in facts.keys()
    assert 'memtotal_mb' in facts.keys()
    assert 'memtotal_gb' in facts.keys()
    assert 'swaptotal_mb' in facts.keys()
    assert 'swaptotal_gb' in facts.keys()
    assert 'swapfree_mb' in facts.keys()
    assert 'swapfree_gb' in facts.keys()


# Generated at 2022-06-11 02:51:05.730246
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    try:
        test_obj = HurdHardware()
        test_obj.gather()
        facts = test_obj.populate()
    except Exception:
        assert False

    assert 'memory_mb' in facts
    assert 'virtual_memory_mb' in facts
    assert 'swap_mb' in facts


# Generated at 2022-06-11 02:51:13.783186
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class HurdHardwareTest(HurdHardware):
        def _load_parser(self):
            pass

        def _get_meminfo_facts(self):
            meminfo_facts = {}

            # Fixme: Find a way to retrieve the size of physical memory
            meminfo_facts['memtotal_mb'] = -1

            # Fixme: Find a way to retrieve the amount of free memory
            meminfo_facts['memfree_mb'] = -1

            # Fixme: Find a way to retrieve the amount of memory in active use
            meminfo_facts['active_mb'] = -1

            # Fixme: Find a way to retrieve the amount of inactive memory
            meminfo_facts['inactive_mb'] = -1

            # Fixme: Find a way to retrieve the amount of cached memory

# Generated at 2022-06-11 02:51:17.615490
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    We do not want to run the tests for this platform on any other platform than the Hurd.
    """
    current_platform = HurdHardware().get_platform()
    test_platform = "GNU"
    if current_platform == test_platform:
        hw = HurdHardware()
        hw.populate()

# Generated at 2022-06-11 02:51:27.101034
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class HurdHardwareMock(HurdHardware):
        def __init__(self, *args):
            self.value_per_fact = {
                'uptime_seconds': args[0],
                'uptime_days': args[1],
                'memtotal_mb': args[2],
                'memfree_mb': args[3],
                'swaptotal_mb': args[4],
                'swapfree_mb': args[5],
                'mounts': args[6],
            }
        def get_uptime_facts(self):
            return {
                'uptime_seconds': self.value_per_fact['uptime_seconds'],
                'uptime_days': self.value_per_fact['uptime_days'],
            }
        def get_memory_facts(self):
            return

# Generated at 2022-06-11 02:51:36.045387
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    class CollectedFacts():
        pass

    hardware_facts = CollectedFacts()

    # Set fact values of the tested method
    hardware_facts.uptime_seconds = 100
    hardware_facts.uptime_days = 0
    hardware_facts.uptime_hours = 0
    hardware_facts.uptime_days = 0
    hardware_facts.memoryfree_mb = 10
    hardware_facts.memtotal_mb = 20
    hardware_facts.swaptotal_mb = 30
    hardware_facts.swapfree_mb =  40

    class TestHurdHardware():
        def __init__(self):
            self.populate_called = False
            self.populate_return = hardware_facts

        def populate(self, collected_facts=None):
            self.populate_called = True
            return self.populate

# Generated at 2022-06-11 02:51:39.746940
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware({})
    hardware.populate()

# Generated at 2022-06-11 02:51:40.530403
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    HurdHardware.populate()

# Generated at 2022-06-11 02:51:43.059553
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    assert facts["uptime_seconds"] == 0
    assert facts["uptime_days"] == 0
    assert facts["uptime_hours"] == 0

    assert facts["memory_mb"] > 0

# Generated at 2022-06-11 02:51:44.630062
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    if HurdHardware().populate() == {}:
        raise AssertionError("method populate of class HurdHardware does not work")



# Generated at 2022-06-11 02:51:47.095706
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    hurd_hardware = HurdHardware()
    assert isinstance(hurd_hardware, LinuxHardware)

# Generated at 2022-06-11 02:51:54.187781
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import pytest
    from mock import Mock
    from ansible.module_utils.facts.timeout import TimeoutError

    try:
        import psutil
    except ImportError:
        pytest.skip('psutil unavailable', allow_module_level=True)
    import platform

    # Failure case 1: TimeoutError is raised when getting mount facts
    platform_return = Mock(return_value='GNU')
    psutil_version = Mock(return_value=tuple([4,1,0]))
    psutil_virtual_memory_return = Mock(return_value=Mock(total=50, available=40))
    psutil_swap_memory_return = Mock(return_value=Mock(total=60))
    psutil_boot_time_return = Mock(return_value=123456.78)

    psutil_

# Generated at 2022-06-11 02:52:04.064325
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    module_mock = mock.Mock()
    module_mock.get_bin_path.side_effect = lambda x: '/usr/bin/' + x

    h = HurdHardware(module=module_mock)

    # TODO: test with an invalid procfs translator
    h.get_uptime_facts = mock.Mock(return_value={'uptime_seconds': 1})
    h.get_memory_facts = mock.Mock(return_value={'ansible_memtotal_mb': 1})
    h.get_mount_facts = mock.Mock(return_value={'mounts': []})

    facts = h.populate()


# Generated at 2022-06-11 02:52:05.429655
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    assert hurdhw.populate

# Generated at 2022-06-11 02:52:07.239309
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    output = hurd_hw.populate()
    assert 'uptime_seconds' in output

# Generated at 2022-06-11 02:52:10.363255
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    test_class = HurdHardware()
    result = test_class.populate()

    assert result.get("uptime_seconds")
    assert result.get("uptime_hours")
    assert result.get("memory_mb")
    assert result.get("mounts")

# Generated at 2022-06-11 02:52:25.300551
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw_collector = HurdHardwareCollector()
    hurd_hw_collector._populate()

    hurd_hw_facts = hurd_hw_collector.get_facts()
    assert isinstance(hurd_hw_facts['uptime_seconds'], int)
    assert isinstance(hurd_hw_facts['uptime_hours'], int)

    assert isinstance(hurd_hw_facts['hw_memtotal_mb'], int)
    assert isinstance(hurd_hw_facts['hw_memfree_mb'], int)
    assert isinstance(hurd_hw_facts['hw_swaptotal_mb'], int)
    assert isinstance(hurd_hw_facts['hw_swapfree_mb'], int)


# Generated at 2022-06-11 02:52:33.786257
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collections import HurdFactsCollector
    import os
    import sys

    def setup_module(module):
        module.facts = Facts(
            HurdFactsCollector,
            HurdHardwareCollector,
            {},
            os.path.dirname(os.path.realpath(__file__)) + '/../../tests/files/',
            None
        )

    if sys.version_info.major == 2:
        import __builtin__
        builtins = __builtin__
    else:
        import builtins


# Generated at 2022-06-11 02:52:42.294365
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    hardware.get_mount_facts = lambda: {
        'mounts': [
            {
                'device': '/dev/disk/by-label/Ansible',
                'options': 'rw,relatime,data=ordered',
                'mount': '/tmp',
                'fstype': 'fuse'
            }
        ],
        'fstype': {
            'fuse': 1
        }
    }

# Generated at 2022-06-11 02:52:44.140061
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()

    hardware.populate()

    assert hardware.uptime is not None
    assert hardware.total_mem is not None

# Generated at 2022-06-11 02:52:52.686984
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import mock
    import ansible.module_utils.facts.hardware.linux
    # Mocking the module_utils methods
    ansible.module_utils.facts.hardware.linux.get_memory_facts = mock.Mock()
    ansible.module_utils.facts.hardware.linux.get_mount_facts = mock.Mock()
    ansible.module_utils.facts.hardware.linux.get_uptime_facts = mock.Mock()
    # Create the object
    obj = HurdHardware()
    # Mock the methods we use to retrieve facts
    obj.get_uptime_facts = mock.Mock()
    obj.get_memory_facts = mock.Mock()
    obj.get_mount_facts = mock.Mock()
    # Test
    obj.populate()
    # Verify that we

# Generated at 2022-06-11 02:52:53.270255
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-11 02:52:55.034909
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # set up test
    test_obj = HurdHardware()
    test_obj.populate()

# Generated at 2022-06-11 02:53:03.885273
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.Hurd import HurdHardware, HurdHardwareCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    # instantiate two classes, one for Linux and one for GNU.
    # prepare the base class to return values that the calling class
    # method is expecting.
    #
    # these classes might be better moved to an external test file but
    # testing code is not a high priority right now.


# Generated at 2022-06-11 02:53:11.409139
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Method populate of class HurdHardware should get GNU Hurd specific facts:
    uptime, memory, mount and all facts of class LinuxHardware.
    """
    hw = HurdHardware()
    collected_facts = hw.populate()
    assert type(collected_facts) is dict
    assert len(collected_facts) > 0
    assert type(collected_facts['uptime']) is str
    assert type(collected_facts['memory']) is dict
    assert type(collected_facts['mounts']) is list
    assert 'devices' in collected_facts
    assert 'uniqueid' in collected_facts
    assert 'fips_enabled' in collected_facts