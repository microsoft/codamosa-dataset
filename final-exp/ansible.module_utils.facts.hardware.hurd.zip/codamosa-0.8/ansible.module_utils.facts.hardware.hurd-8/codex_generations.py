

# Generated at 2022-06-11 02:43:17.713239
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    def mock_get_uptime_facts(self):
        return {'uptime_seconds': '42'}

    def mock_get_memory_facts(self):
        return {'memtotal_mb': '42'}

    def mock_get_mount_facts(self):
        return {'mounts': ['rootfs', '/']}

    ha = HurdHardware()
    ha.get_uptime_facts = mock_get_uptime_facts.__get__(ha, HurdHardware)
    ha.get_memory_facts = mock_get_memory_facts.__get__(ha, HurdHardware)
    ha.get_mount_facts = mock_get_mount_facts.__get__(ha, HurdHardware)

# Generated at 2022-06-11 02:43:26.388722
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test correctness of the populate method of the HurdHardware class
    """
    hurdHardware = HurdHardware()
    collected_facts = {}
    returned_facts = hurdHardware.populate(collected_facts)
    assert 'uptime_seconds' in returned_facts.keys()
    assert 'uptime_days' in returned_facts.keys()
    assert 'uptime_hours' in returned_facts.keys()
    assert 'uptime_minutes' in returned_facts.keys()
    assert 'swapfree_mb' in returned_facts.keys()
    assert 'swaptotal_mb' in returned_facts.keys()
    assert 'memfree_mb' in returned_facts.keys()
    assert 'memtotal_mb' in returned_facts.keys()
    assert 'ansible_mounts' in returned_facts.keys

# Generated at 2022-06-11 02:43:30.458433
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert isinstance(hardware_facts, dict)
    assert 'uptime' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'ram' in hardware_facts
    assert 'mounts' in hardware_facts

# Generated at 2022-06-11 02:43:33.987291
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    facts = HurdHardware().populate()
    uptime = facts.get('uptime')
    assert type(uptime) == int
    memory = facts.get('ansible_memtotal_mb')
    assert type(memory) == int and memory > 0
    mount = facts.get('mounts')
    assert type(mount) == list

# Generated at 2022-06-11 02:43:39.827339
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.generic import GenericHardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    import pytest
    import sys

    if sys.version_info >= (3, 0):
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    # Class under test
    hhw = HurdHardware()

    # Create a mocked LinuxHardware and GenericHardware class,
    # populate() method returns are used by the tested populate of HurdHardware
    mocked_lhw = LinuxHardware()
    mocked_lhw.populate = MagicMock(return_value = {"lhw_fact_key":"lhw_fact_val"})
    mocked_gh

# Generated at 2022-06-11 02:43:46.971716
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    # expected values taken from GNU/Hurd VM test system
    assert hardware.uptime['seconds'] == 1753169
    assert isinstance(hardware.uptime['file'], str)
    assert hardware.memtotal_mb == 3146
    assert hardware.memfree_mb == 2226
    assert hardware.swaptotal_mb == 10
    assert hardware.swapfree_mb == 0
    assert isinstance(hardware.mounts, list)
    assert isinstance(hardware.mounts[0], dict)
    assert isinstance(hardware.mounts[0]['mount'], str)

# Generated at 2022-06-11 02:43:52.752048
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware({})
    hw.populate()

    assert hw.uptime is not None
    assert hw.uptime['seconds'] is not None
    assert hw.uptime['hours'] is not None
    assert hw.uptime['minutes'] is not None

    assert hw.memtotal_mb is not None
    assert hw.memfree_mb is not None

    assert hw.mounts is not None

# Generated at 2022-06-11 02:43:57.398994
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.collector import TestCollector

    hhw = HurdHardware(TestCollector())
    collected_facts = {'kernel': 'GNU', 'kernel_version': '42'}
    # Test with timeout
    hhw.mount_timeout = 0.01
    result = hhw.populate(collected_facts)
    # Test without timeout
    hhw.get_mount_facts = lambda: {'facts': 'facts'}
    hhw.mount_timeout = 0.1
    result = hhw.populate(collected_facts)

# Generated at 2022-06-11 02:44:05.222362
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test for HurdHardware class
    hurdHardware = HurdHardware()
    collected_facts = {
        'kernel': 'GNU',
        'kernel_version': '0.3'
    }
    facts = hurdHardware.populate(collected_facts)

    assert facts['uptime_seconds'] >= 0
    assert facts['uptime_hours'] >= 0
    assert facts['uptime_days'] >= 0
    assert facts['memtotal_mb'] >= 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0

# Generated at 2022-06-11 02:44:06.874390
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_obj = HurdHardware()
    assert hardware_obj.populate()

# Generated at 2022-06-11 02:44:08.949284
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    pass

# Generated at 2022-06-11 02:44:11.093756
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardwareCollector()
    hardware_instance = collector.collect()
    assert hardware_instance is not None

# Generated at 2022-06-11 02:44:17.488345
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test with no timeout
    hurd_hardware = HurdHardware()
    hurd_hardware.get_uptime_facts = lambda: {'uptime_seconds': 1}
    hurd_hardware.get_memory_facts = lambda: {'memtotal_mb': 2}
    hurd_hardware.get_mount_facts = lambda: {'mounts': [{'mount': '/'}]}
    facts = hurd_hardware.populate()

    assert facts == {'uptime_seconds': 1, 'memtotal_mb': 2, 'mounts': [{'mount': '/'}]}

    # Test with timeout
    hurd_hardware = HurdHardware()
    hurd_hardware.get_uptime_facts = lambda: {'uptime_seconds': 1}

# Generated at 2022-06-11 02:44:21.571999
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Collects facts using the method populate
    facts = HurdHardware().populate()
    # Asserts that the uptime variable isn't empty
    assert facts['uptime']
    # Asserts that the available_memory variable isn't empty
    assert facts['available_memory']
    # Asserts that the mounted variable isn't empty
    assert facts['mounted']

# Generated at 2022-06-11 02:44:25.235867
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    gathered_facts = hurd_hardware.populate()
    assert gathered_facts['uptime_seconds'] > 0
    assert gathered_facts['virtual_memory']['total'] > 0
    assert len(gathered_facts['mounts']) >= 0

# Generated at 2022-06-11 02:44:35.321155
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts import _get_file_lines
    from ansible.module_utils.facts.timeout import wait_for
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.linux.__init__ import LINUX_HARDWARE_CLASS_MAP
    LINUX_HARDWARE_CLASS_MAP = {}
    lh = LinuxHardware()
    lh._get_file_lines = _get_file_lines
    lh.get_uptime_facts = lambda: {'uptime_seconds': 0.0}
    lh.get_memory_facts = lambda: {'memory_mb': {'real': {'total': 0}} }
    lh.get_mount_facts = lambda: {'mounts': []}


# Generated at 2022-06-11 02:44:43.559970
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    collected_facts = {
        'uname': {
            'machine': 'i386',
            'system': 'GNU',
            'release': '0.9',
            'nodename': 'hurd',
            'kernel': 'GNU-Mach',
            'version': '1.7.1',
            'os': 'GNU',
            'processor': 'i386',
            'hardware': 'i386'
        },
        'virtual': 'physical',
    }
    collected_facts = hardware_facts.populate(collected_facts)
    assert 'memfree_mb' in collected_facts['ansible_memfree_mb']
    assert 'swapfree_mb' in collected_facts['ansible_swapfree_mb']

# Generated at 2022-06-11 02:44:44.662826
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()
    hw.populate()

# Generated at 2022-06-11 02:44:51.232068
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import json
    import os
    import sys
    import io

    # Create a HurdHardware object for testing
    hurdhwcol = HurdHardwareCollector()
    hurdhw = hurdhwcol.collect(None, None)
    hurdhw_dict = hurdhw.populate()

    # Load the corresponding reference data
    dirname, filename = os.path.split(os.path.abspath(sys.argv[0]))
    reference_file_fp = os.path.join(dirname, 'reference/hurd.json')
    with io.open(reference_file_fp, 'r') as f:
        reference_data = json.load(f)

    # Compare obtained data with reference data
    assert reference_data == hurdhw_dict

# Generated at 2022-06-11 02:44:58.683937
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    h.get_memory_facts = lambda x: {'memory': 'memory_facts'}
    h.get_mount_facts = lambda: {'mount': 'mount_facts'}
    h.get_uptime_facts = lambda: {'uptime': 'uptime_facts'}
    assert h.populate() == {'memory': 'memory_facts',
                            'mount': 'mount_facts',
                            'uptime': 'uptime_facts'}


# Generated at 2022-06-11 02:45:11.105681
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    timeout = 0.1
    hardware = HurdHardware({}, {}, timeout)
    uptime_facts = hardware.get_uptime_facts()
    memory_facts = hardware.get_memory_facts()
    mount_facts = {}
    try:
        mount_facts = hardware.get_mount_facts()
    except TimeoutError:
        pass

    hardware_facts = {}
    hardware_facts.update(uptime_facts)
    hardware_facts.update(memory_facts)
    hardware_facts.update(mount_facts)

    assert hardware_facts['uptime_seconds'] != ''
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] != ''
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] != ''


# Generated at 2022-06-11 02:45:17.180842
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hadd = HurdHardware()
    hardware_facts = hadd.populate()

    assert hardware_facts.get('uptime_seconds') == 0
    assert hardware_facts.get('uptime_days') == 0
    assert hardware_facts.get('uptime_hours') == 0
    assert hardware_facts.get('uptime_minutes') == 0

    assert hardware_facts.get('memory_mb') == 0
    assert hardware_facts.get('swapfree_mb') == 0

# Generated at 2022-06-11 02:45:26.452907
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys
    import os
    import py

    sys.path.insert(0, os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.realpath(__file__)))))
    from units.compat import unittest
    from ansible.module_utils.facts import FactCollector

    class TestHurdHardwarePopulate(unittest.TestCase):
        """
        Test class for testing populate method of class
        HurdHardware without mocking the memory and
        mount facts
        """

        def setUp(self):
            self.hardware = HurdHardware(None)
            self.collector = FactCollector()

        def test_populate(self):
            self.hardware.populate(self.collector)
            uptime_facts = self.hardware.get

# Generated at 2022-06-11 02:45:28.025298
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert False


# Generated at 2022-06-11 02:45:30.753985
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_collector = HurdHardwareCollector()
    hurd_hardware_collector._collect_platform_facts = lambda: {}
    hurd_hardware_collector.collect()
    exit(0)

# Generated at 2022-06-11 02:45:39.803721
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import sys
    import os
    import mock
    import pytest
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.linux import _get_mount_info
    from ansible.module_utils.facts import timeout

    up_seconds = 250000000
    up_days = up_seconds / 86400
    up_hours = (up_seconds - (up_days * 86400)) / 3600
    up_minutes = (up_seconds - (up_days * 86400) - (up_hours * 3600)) // 60

# Generated at 2022-06-11 02:45:47.771829
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Check if facts returned by the method populate of class
    HurdHardware are correct
    """
    collected_facts = {'ansible_os_family': 'GNU/Hurd'}
    hardware = HurdHardware()
    hardware_facts = hardware.populate(collected_facts)

    assert isinstance(hardware_facts['memory_mb'], (int, float))
    assert 'swapfree_mb' in hardware_facts
    assert 'mounts' in hardware_facts
    assert isinstance(hardware_facts['uptime_seconds'], (int, float))
    assert hardware_facts['uptime_seconds'] >= 0

# Generated at 2022-06-11 02:45:53.963376
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd = HurdHardware()

    # invert truth values of return values
    def mock_get_uptime_facts():
        return {'uptime_seconds': 0}
    hurd.get_uptime_facts = mock_get_uptime_facts

    def mock_get_memory_facts():
        return {'memtotal_mb': 0}
    hurd.get_memory_facts = mock_get_memory_facts

    def mock_get_mount_facts():
        return {'mounts': []}
    hurd.get_mount_facts = mock_get_mount_facts

    assert not hurd.populate()['uptime_seconds']
    assert not hurd.populate()['memtotal_mb']
    assert not hurd.populate()['mounts']

# Generated at 2022-06-11 02:45:55.550110
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    assert(hw.populate() is not None)

# Generated at 2022-06-11 02:46:01.162494
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()

    expected_facts = {
        'uptime': 0,
        'uptime_seconds': 0,
        'uptime_days': 0,
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
        'mounts': [],
    }

    assert facts == expected_facts

# Generated at 2022-06-11 02:46:05.479002
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware("")
    hurd_hardware.populate()

# Generated at 2022-06-11 02:46:08.377655
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    facts = hurd_hw.populate()
    assert type(facts) is dict
    assert 'os_family' in facts
    assert facts['os_family'] == 'GNU/Hurd'

# Generated at 2022-06-11 02:46:17.923057
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    # testing without collected_facts

# Generated at 2022-06-11 02:46:21.500895
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # test that it returns a dict
    hurd_facts = HurdHardware().populate()
    assert isinstance(hurd_facts, dict)
    # test that it returns at least some keys
    assert 'uptime' in hurd_facts
    assert 'swapfree_mb' in hurd_facts

# Generated at 2022-06-11 02:46:25.729145
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    collected_facts = {}
    collected_facts['ansible_system'] = 'GNU'
    facts = hurd_hardware.populate(collected_facts)
    assert 'mounts' in facts
    assert 'ram' in facts

# Generated at 2022-06-11 02:46:31.426005
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    class mocked_object(object):
        pass

    setattr(mocked_object, 'virtual', '',)
    setattr(mocked_object, 'kernel', '',)

    h = HurdHardware()

    # Test the method _linux_uptime
    assert isinstance(h._linux_uptime(), dict)

    # Test the method _linux_memory
    assert isinstance(h._linux_memory(), dict)

    # Test the method _linux_mount
    assert isinstance(h._linux_mount(mocked_object), dict)

    # Test when all are ok
    assert isinstance(h.populate(), dict)

# Generated at 2022-06-11 02:46:40.419442
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    HurdHardware_instance = HurdHardware()
    collected_facts = CollectedFacts().get_collected_facts()
    collected_facts['ansible_kernel'] = 'GNU' # test only GNU, not Hurd
    HurdFacts = HurdHardware_instance.populate(collected_facts)
    assert isinstance(HurdFacts, dict)
    assert HurdFacts['ansible_processor_cores'] == LinuxHardware().populate()['ansible_processor_cores']


# Generated at 2022-06-11 02:46:49.749077
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Create instance of class HurdHardware
    hurd_hardware = HurdHardware()
    hurd_hardware.uptime = {
        "seconds": 383249,
        "hostname": "host",
    }

# Generated at 2022-06-11 02:46:54.697645
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    populator = HurdHardware()
    hardware_facts = populator.populate()
    assert hardware_facts['uptime_seconds'] == 514
    assert hardware_facts['uptime_minutes'] == 8
    assert hardware_facts['memory_mb']['real']['total'] == 3864
    assert hardware_facts['memory_mb']['virtual']['free'] == 2547

# Generated at 2022-06-11 02:47:03.941761
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {'ansible_distribution': 'GNU',
                       'ansible_distribution_version': '0.3',
                       'ansible_distribution_major_version': '0',
                       'ansible_distribution_release': '-current',
                       'ansible_distribution_file_parsed': True}
    hurdhw = HurdHardware(collected_facts)

# Generated at 2022-06-11 02:47:14.363820
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurdhw = HurdHardware()
    facts = hurdhw.populate()
    # Test populates returns a dict
    assert isinstance(facts, dict)
    # Test that all facts are present
    assert facts['uptime_seconds'] == 0
    assert facts['uptime_days'] == 0
    assert facts['memory_mb'] > 0
    assert len(facts['mounts']) == 0

# Generated at 2022-06-11 02:47:19.313825
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware = HurdHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['hw_memory_total'] > 0
    assert hardware_facts['hw_memory_free'] > 0
    assert hardware_facts['hw_memory_free_percent'] >= 0
    assert hardware_facts['hw_memory_used'] > 0
    assert hardware_facts['hw_memory_used_percent'] >= 0
    assert hardware_facts['hw_memory_buffers'] > 0
    assert hardware_facts['hw_memory_cached'] > 0
    assert hardware_facts['hw_memory_available'] > 0
    assert hardware_facts['hw_memory_available_percent'] >= 0

# Generated at 2022-06-11 02:47:21.034423
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    class HurdHardwareFactory:
        def create(self):
            return HurdHardware()

    return HurdHardwareFactory()

# Generated at 2022-06-11 02:47:30.173867
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware()

    # for the sake of performance, define minimal amount of mock data
    # to be returned by the methods from LinuxHardware superclass.
    hw._uptime_content = '\n'.join([
        '982383.75 2355.90',
        ])

    hw._mount_content = '\n'.join([
        'proc on /proc type proc (rw)',
        ])

    # define expected data

# Generated at 2022-06-11 02:47:38.374877
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Setup of test case
    hurd_hw = HurdHardware({})

    # Run 'populate' method of hurd_hw
    hurd_hw.populate()

    # Assert
    assert(hurd_hw.facts == {'uptime_seconds': 27595,
                             'uptime_days': 0,
                             'uptime': '00:00:27',
                             'memtotal_mb': 1024,
                             'memfree_mb': 845,
                             'mounts': [{'uuid': None,
                                         'device': '/dev/sda1',
                                         'mount': '/',
                                         'fstype': 'ext2fs',
                                         'options': ['errors=remount-ro']}]})

# Generated at 2022-06-11 02:47:46.631932
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collected_facts = {
        'os_family': 'Debian',
        'distribution': 'GNU',
        'distribution_release': 'Hurd',
        'distribution_version': '0.8'
    }
    hw_facts_inst = HurdHardware(collected_facts, False)
    hardware_facts = hw_facts_inst.populate()

    uptime_facts = {
        'uptime': 3350,
        'uptime_days': 0,
        'uptime_hours': 0,
        'uptime_seconds': 3350
    }

    total_memory_mb = 16384

# Generated at 2022-06-11 02:47:53.289301
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """
    hw_facts = HurdHardware()
    result = hw_facts.populate()
    assert 'uptime' in result
    assert 'uptime_days' in result
    assert 'uptime_hours' in result
    assert 'uptime_seconds' in result
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'mounts' in result

# Generated at 2022-06-11 02:47:54.771788
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hardware_facts = HurdHardware()
    hardware_facts.populate()
    hardware_facts.get_mount_facts()

# Generated at 2022-06-11 02:48:01.710171
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()

    # Initialize LinuxHardware with mocked data in special file
    hurd_hw.uptime = {'time': 1633.0}
    hurd_hw.disks = {'/dev/sda': {'size': '42'}}
    hurd_hw._read_meminfo_file = lambda: 'MemTotal:         40960 KB\n'

    # Test the forced linux behavior
    hurd_hw.populate()
    assert hurd_hw.uptime['time'] == 1633.0
    assert hurd_hw.disks['/dev/sda']['size'] == '42'

# Generated at 2022-06-11 02:48:06.830572
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    uptime_facts = hurd_hardware.get_uptime_facts()
    memory_facts = hurd_hardware.get_memory_facts()

    mount_facts = {}
    try:
        mount_facts = hurd_hardware.get_mount_facts()
    except TimeoutError:
        pass

    assert len(uptime_facts.keys()) > 0
    assert len(memory_facts.keys()) > 0
    assert len(mount_facts.keys()) > 0

# Generated at 2022-06-11 02:48:23.864264
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    # Test if call to method populate returns proper facts
    hurd_hardware = HurdHardware()

    # Return the result of method populate
    return hurd_hardware.populate()

if __name__ == '__main__':
    # Test if call to method populate returns proper facts
    test_HurdHardware_populate()

# Generated at 2022-06-11 02:48:26.677282
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    hardware = HurdHardware()
    hardware.populate(LinuxHardware())

# Generated at 2022-06-11 02:48:34.922213
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Standalone method test for HurdHardware.populate
    """
    # Create a dummy fact instance
    fact_inst = HurdHardware()

    # Populate the fact inst
    fact_inst.populate()

    # Assert that the fact inst has populated both uptime, memory, and mount
    # facts.
    assert fact_inst._collected_facts['uptime_system'] is not None
    assert fact_inst._collected_facts['uptime_system'] != 0
    assert fact_inst._collected_facts['uptime_system'] > 0
    assert fact_inst._collected_facts['uptime_seconds'] is not None
    assert fact_inst._collected_facts['uptime_seconds'] != 0
    assert fact_inst._collected_facts['uptime_seconds'] > 0
    assert fact_inst

# Generated at 2022-06-11 02:48:42.992385
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hrdd = HurdHardware()
    facts = hrdd.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_seconds'] == 86400 * facts['uptime_days']
    assert facts['uptime_seconds'] == 3600 * facts['uptime_hours']
    assert facts['uptime_seconds'] == 60 * facts['uptime_minutes']
    assert facts['uptime'] == '{0} days'.format(facts['uptime_days'])
    assert facts['memory_mb']['real']['total'] > 0
    assert facts['mounts'] is not None


# Unit test class as a whole

# Generated at 2022-06-11 02:48:44.826237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    hurd_hardware.populate()

# Generated at 2022-06-11 02:48:50.551086
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    import types

    hurdhw = HurdHardware()
    assert isinstance(hurdhw, LinuxHardware)
    assert not isinstance(hurdhw, types.ModuleType)

    hurdhw.populate()
    assert not isinstance(hurdhw.memory, TimeoutError)

# Generated at 2022-06-11 02:49:00.351999
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """HurdHardware - populate()
    """

    c = HurdHardware()
    c.populate()
    assert c.uptime['seconds'] > 0
    assert c.uptime['days'] > 0
    assert c.memory['MemTotal'] > 0
    assert c.memory['MemAvailable'] > 0
    assert c.memory['SwapTotal'] == 0
    assert c.memory['SwapFree'] == 0
    assert '/' in c.mounts
    assert '/dev' in c.mounts
    assert '/proc' in c.mounts
    assert '/sys' in c.mounts
    assert '/run' in c.mounts
    assert '/tmp' in c.mounts
    assert '/dev/pts' in c.mounts
    assert '/mnt' in c.mounts

# Generated at 2022-06-11 02:49:03.176622
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Tests of the method populate of class HurdHardware.
    """
    hurdhw = HurdHardware()

    facts = hurdhw.populate()

    assert facts['uptime_seconds'] > 1

# Generated at 2022-06-11 02:49:12.879920
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.timeout import TimeoutError

    def raise_TimeoutError():
        raise TimeoutError(None, None, None)

    def do_nothing():
        pass

    h = HurdHardware()
    assert 'uptime_seconds' in h.populate()
    assert 'uptime_seconds' in h.populate(collected_facts={'uptime_seconds': 12345})

    assert 'swapfree_mb' in h.populate()
    assert 'memfree_mb' in h.populate()

    assert '/' in h.populate()['mounts']

    h.get_mount_facts = do_nothing
    assert 'mounts' not in h.populate()

# Generated at 2022-06-11 02:49:16.724131
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hw = HurdHardware()
    mounts = hurd_hw.get_mount_facts()
    assert 'mounts' in mounts
    assert mounts['mounts'][0]['device'] == '/dev/disk/ide/hdb'
    assert mounts['mounts'][0]['mount'] == '/'

# Generated at 2022-06-11 02:49:48.087910
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    h = HurdHardware()
    facts = h.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['uptime_hours'] > 0
    assert facts['uptime_days'] > 0
    assert facts['memory_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['mounts'] >= 0

# Generated at 2022-06-11 02:49:57.889715
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    hurd_hardware = HurdHardware()

    hardware_facts = hurd_hardware.populate()

    # Test uptime fact
    assert 'uptime' in hardware_facts
    assert isinstance(hardware_facts['uptime'], int)

    # Test memory facts
    assert 'memtotal_mb' in hardware_facts
    assert isinstance(hardware_facts['memtotal_mb'], int)

    assert 'memfree_mb' in hardware_facts
    assert isinstance(hardware_facts['memfree_mb'], int)

    assert 'swaptotal_mb' in hardware_facts
    assert isinstance(hardware_facts['swaptotal_mb'], int)

    assert 'swapfree_mb' in hardware_facts
    assert isinstance(hardware_facts['swapfree_mb'], int)

   

# Generated at 2022-06-11 02:50:06.108507
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Make sure the method populate of class HurdHardware works as expected.
    """

    class FakeTimeoutError(TimeoutError):
        """
        Fake class for Mocking TimeoutErrors and to avoid their
        original implementation.
        """

        def __init__(self, *args, **kwargs):
            self.message = 'TimeoutError'


    hurd_hw = HurdHardware()
    hurd_hw.hurd = True
    hurd_hw.get_mount_facts = MagicMock(return_value={'mounts':
                                                      ['/dev/sda1']})
    hurd_hw.get_uptime_facts = MagicMock(return_value={'uptime':
                                                       'uptime'})

# Generated at 2022-06-11 02:50:09.364941
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hHurdware = HurdHardware()
    res = hHurdware.populate()
    assert 'uptime_seconds' in res
    assert 'memtotal_mb' in res
    assert 'mounts' in res

# Generated at 2022-06-11 02:50:19.964065
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Unit test for method populate of class HurdHardware
    """

    # Patch LinuxHardware.get_memory_facts, since the method
    # calls a translator which is not included in the test environment
    def mock_get_memory_facts(self):
        return {'memtotal_mb': '12345', 'memfree_mb': '12345'}
    HurdHardware.get_memory_facts = mock_get_memory_facts

    # Patch LinuxHardware.get_uptime_facts, since the method
    # calls a translator which is not included in the test environment
    def mock_get_uptime_facts(self):
        return {'uptime_seconds': '12345'}
    HurdHardware.get_uptime_facts = mock_get_uptime_facts

    # Patch LinuxHardware.get_mount_facts, since

# Generated at 2022-06-11 02:50:26.070783
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    har = HurdHardware()
    collected_facts = {'ansible_processor_cores': 1,
                       'ansible_processor_count': 1,
                       'ansible_processor_threads_per_core': 1,
                       'ansible_processor_vcpus': 1}
    hardware_facts = har.populate(collected_facts)

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_hours'] > 0
    assert hardware_facts['uptime_days'] > 0
    assert hardware_facts['uptime_years'] > 0
    assert hardware_facts['memory_mb']['real']['total'] > 0
    assert hardware_facts['memory_mb']['swap']['total'] == 0
    assert hardware_facts['boottime_seconds'] > 0
   

# Generated at 2022-06-11 02:50:27.963996
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hd = HurdHardware()
    print(hd.populate())


# Generated at 2022-06-11 02:50:33.753143
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import pytest
    try:
        hurd_fac = HurdHardware()
    except ImportError:
        pytest.skip('Hurd is not supported')

    fac = hurd_fac.populate()
    assert fac['uptime_seconds'] >= 0
    assert fac['uptime_hours'] >= 0
    assert fac['uptime_days'] >= 0
    assert fac['memfree_mb'] >= 0
    assert fac['memtotal_mb'] >= 0

# Generated at 2022-06-11 02:50:36.659990
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    assert 'uptime' in hurd_hardware.populate()
    assert 'memfree_mb' in hurd_hardware.populate()

# Generated at 2022-06-11 02:50:37.191869
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():

    pass

# Generated at 2022-06-11 02:51:44.718512
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    class FakeLinuxHardware(LinuxHardware):
        def __init__(self):
            super(FakeLinuxHardware, self).__init__()
        def get_mount_facts(self):
            return {'/': {'uuid': 'x', 'mount': '/', 'file_system': 'ext4', 'options': 'rw,relatime,errors=remount-ro', 'device': '/dev/disk/by-uuid/x', 'size_available': '1234 KBytes', 'size_total': '5678 KBytes'}}
        def get_uptime_facts(self):
            return {'uptime_seconds': '1234'}
        def get_memory_facts(self):
            return {'memtotal_mb': '123'}

   

# Generated at 2022-06-11 02:51:46.468471
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    collector = HurdHardwareCollector()
    collected_facts = collector.collect()
    assert 'hardware' in collected_facts

# Generated at 2022-06-11 02:51:53.919377
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """
    Test that HurdHardware._populate() gives expected results given /proc/meminfo
    and /proc/mounts formatted as their equivalents in a Linux system.
    """

# Generated at 2022-06-11 02:52:03.788574
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware

    def mock_get_memory_facts(self):
        return {'swapfree_mb': 1, 'memfree_mb': 2, 'swaptotal_mb': 3, 'memtotal_mb': 4}

    def mock_get_mount_facts(self):
        return {'mounts': [{'device': '/dev/dsp', 'mount': '/', 'fstype': 'hurd', 'options': '', 'size_available': 2147450880, 'size_total': 2985457664}]}


# Generated at 2022-06-11 02:52:10.442386
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware_facts = HurdHardware()
    test_facts = {"uptime": {}, "memory": {}, "mounts": []}

    def get_uptime_facts():
        return {"uptime": {}}

    def get_memory_facts():
        return {"memory": {}}

    def get_mount_facts():
        return {"mounts": []}

    hurd_hardware_facts.get_uptime_facts = get_uptime_facts
    hurd_hardware_facts.get_memory_facts = get_memory_facts
    hurd_hardware_facts.get_mount_facts = get_mount_facts

    assert hurd_hardware_facts.populate() == test_facts

# Generated at 2022-06-11 02:52:11.786045
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    assert HurdHardware.populate({'ansible_system_vendor': 'GNU'})

# Generated at 2022-06-11 02:52:14.094287
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hurd_hardware = HurdHardware()
    facts = hurd_hardware.populate()
    assert isinstance(facts, dict) is True

# Generated at 2022-06-11 02:52:15.495357
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    hw = HurdHardware(lambda a: 1, lambda a: b"")
    hw.populate()
    pass

# Generated at 2022-06-11 02:52:18.888205
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    import platform

    HurdHardware_instance = HurdHardware()
    result = HurdHardware_instance.populate(collected_facts={'kernel': platform.system()})
    assert isinstance(result, dict)

# Generated at 2022-06-11 02:52:20.529237
# Unit test for method populate of class HurdHardware
def test_HurdHardware_populate():
    """Unit test class GNU_HurdHardware_populate"""
    hurd = HurdHardware()
    hurd.populate()