

# Generated at 2022-06-12 01:24:53.419985
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None

# Generated at 2022-06-12 01:24:54.933450
# Unit test for method address of class Address
def test_Address_address():
    name = 'address'
    assert Command(name).address() != None

# Generated at 2022-06-12 01:25:04.129019
# Unit test for method address of class Address
def test_Address_address():
    # Check :meth:`~Address.address()`

    address = Address()
    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()

    # Expanded format of address
    assert address.address() == ('{} {} {}'.format(st_num, st_name, st_sfx))

    # Shortened format of address
    for fmt in SHORTENED_ADDRESS_FMT:
        address._locale = fmt
        assert address.address() == ('{} {}'.format(st_num, st_name))


# Generated at 2022-06-12 01:25:05.931400
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result



# Generated at 2022-06-12 01:25:17.712615
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.street_number(), str)
    assert isinstance(address.street_name(), str)
    assert isinstance(address.street_suffix(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.state(), str)
    assert isinstance(address.state(abbr=True), str)
    assert isinstance(address.postal_code(), str)
    assert isinstance(address.zip_code(), str)
    assert isinstance(address.country_code(), str)
    assert isinstance(address.country_code(CountryCode.A2), str)
    assert isinstance(address.country(), str)
    assert isinstance(address.country(allow_random=True), str)
    assert isinstance(address.city(), str)
    assert isinstance

# Generated at 2022-06-12 01:25:19.436506
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert len(result) > 0

# Generated at 2022-06-12 01:25:21.928451
# Unit test for method address of class Address
def test_Address_address():
    """Test for function address

    Testing for function address of class Address
    """
    # Arrange
    address_generator = Address()
    # Action
    address = address_generator.address()
    # Assert
    assert address

# Generated at 2022-06-12 01:25:24.604518
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address
    of class Address
    """
    adr = Address()
    assert isinstance(adr.address(), str)



# Generated at 2022-06-12 01:25:26.031604
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    print(address.address())



# Generated at 2022-06-12 01:25:34.991676
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    address = Address('en')
    street_number = address.street_number(500)
    
    if address.country() == 'United States':
        assert address.address() == street_number + ' ' + address.street_name() + ' ' + address.street_suffix()
    elif address.country() == 'Canada':
        assert address.address() == street_number + ' ' + address.street_name()
    else:
        assert address.address() == address.street_name() + ' ' + street_number + ' ' + address.street_suffix()

test_Address_address()


# Generated at 2022-06-12 01:25:44.384326
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    assert isinstance(adr.address(),str)


# Generated at 2022-06-12 01:25:57.156034
# Unit test for method address of class Address
def test_Address_address():
    import pytest
    from mimesis.enums import Locale

    addr = Address()
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.helpers.is_string(addr.address())
    assert pytest.help

# Generated at 2022-06-12 01:25:58.125216
# Unit test for method address of class Address
def test_Address_address():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 01:26:03.380302
# Unit test for method address of class Address
def test_Address_address():
    # Test for English
    address = Address(locale='en')
    print(address.address())
    # Test for Russian
    address = Address(locale='ru')
    print(address.address())
    # Test for Japanese
    address = Address(locale='ja')
    print(address.address())


# Generated at 2022-06-12 01:26:07.324125
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.name import Name

    address = Address()
    name = Name(address.locale)

    assert address.street_number(maximum=1300)
    assert address.street_name()
    assert address.street_suffix()
    assert address.address()
    assert address.state()
    assert address.region()
    assert address.province()
    assert address.federal_subject()
    assert address.prefecture()
    assert address.postal_code()
    assert address.zip_code()
    assert address.country()
    assert address.city()
    assert address.latitude()
    assert address.longitude()
    assert address.coordinates()
    assert address.continent()


# Generated at 2022-06-12 01:26:09.072643
# Unit test for method address of class Address
def test_Address_address():
    address_zh = Address('zh')
    address_jp = Address('jp')
    assert address_zh != address_jp

# Generated at 2022-06-12 01:26:15.981504
# Unit test for method address of class Address
def test_Address_address():
    ADDRESS = '{st_num} {st_name} {st_sfx}'

    address = Address('en')
    result = address.address()
    assert isinstance(result, str)

    # Remove trailing spaces
    assert result.strip()

    # Test if result is like `st_num st_name st_sfx`
    assert address.random.parse_pattern(ADDRESS, result)

# Generated at 2022-06-12 01:26:20.324348
# Unit test for method address of class Address
def test_Address_address():

    from mimesis.utils import with_underscore

    InstanceOfAddress = Address('en')  # Creating an instance of Address
    num = InstanceOfAddress.street_number()
    street_address = InstanceOfAddress.address()
    if street_address != '':
        # print(street_num)
        assert num != ''
        assert type(num) == str
        assert type(street_address) == str

# Generated at 2022-06-12 01:26:21.641519
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()

# Generated at 2022-06-12 01:26:23.019285
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '16489 Sycamore Road'

# Generated at 2022-06-12 01:26:34.068367
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() in [
        '24 Houston St.',
        '26 Woodward St.',
        '24 Main St.',
        '26 Main St.',
        '24 Old St.',
        '26 Old Rd.',
        '24 Old Rd.',
        '26 Old Rd.',
        '24 Old St.',
        '26 Old Rd.',
        '24 Old Rd.',
        '26 Old Rd.',
    ]

# Generated at 2022-06-12 01:26:35.937439
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    print(a.address())

# Generated at 2022-06-12 01:26:37.312294
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='ja')
    print(a.address())

# Generated at 2022-06-12 01:26:38.845637
# Unit test for method address of class Address
def test_Address_address():
    Address().address()


# Generated at 2022-06-12 01:26:40.514055
# Unit test for method address of class Address
def test_Address_address():
    ad = Address(locale='en')
    assert isinstance(ad.address(), str)


# Generated at 2022-06-12 01:26:43.701663
# Unit test for method address of class Address
def test_Address_address():
    import re
    address_obj = Address('it')
    address = address_obj.address()
    assert isinstance(address, str)
    assert re.match('^\d+ [a-z]+\d*', address) is not None


# Generated at 2022-06-12 01:26:47.333007
# Unit test for method address of class Address
def test_Address_address():

    gen = Address()

    result = gen.address()

    assert result is not None
    assert gen.address() != gen.address()
    assert len(result) > 2


# Generated at 2022-06-12 01:26:49.027068
# Unit test for method address of class Address
def test_Address_address():
    for i in range(30):
        address = Address()
        print(address.address())


# Generated at 2022-06-12 01:26:50.576404
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    adress = provider.address()
    assert adress



# Generated at 2022-06-12 01:26:51.764905
# Unit test for method address of class Address
def test_Address_address():
    generator = Address()
    assert type(generator.address()) == str

# Generated at 2022-06-12 01:27:09.127225
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.localization import AddressFormats

    address = Address(locale=AddressFormats.EN)
    try:
        address.address(Gender.FEMALE)
    except TypeError as e:
        assert str(e) == 'address() takes 0 positional arguments but 1 was given'
    except NonEnumerableError:
        pass
    else:
        raise TypeError

    assert isinstance(address.address(), str)



# Generated at 2022-06-12 01:27:10.531941
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    print(address.address())


# Generated at 2022-06-12 01:27:18.341154
# Unit test for method address of class Address
def test_Address_address():
    # Complete test coverage for a method.
    test_addr = Address('pt')
    out = test_addr.address()
    assert isinstance(out, str)
    assert out

    # Test for locale ja
    test_addr = Address('ja')
    out = test_addr.address()
    assert isinstance(out, str)
    assert out

    # Test for shortened address format.
    test_addr = Address('en')
    out = test_addr.address()
    assert isinstance(out, str)
    assert out



# Generated at 2022-06-12 01:27:19.873581
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    assert type(address) == str


# Generated at 2022-06-12 01:27:22.530683
# Unit test for method address of class Address
def test_Address_address():
    a = Address()

    for x in range(10):
        print(a.address())



# Generated at 2022-06-12 01:27:31.325155
# Unit test for method address of class Address
def test_Address_address():
    obj = Address(seed=1)
    arg = obj.random.randint(1, 1000)
    print ("Testing Address with seed = {0}".format(arg))
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address with seed = 920
    print (obj.address())
    # Testing Address

# Generated at 2022-06-12 01:27:33.731066
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)



# Generated at 2022-06-12 01:27:34.935430
# Unit test for method address of class Address
def test_Address_address():
    test_obj = Address('en')
    test_obj.address()

# Generated at 2022-06-12 01:27:36.131901
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert len(a.address()) > 0


# Generated at 2022-06-12 01:27:42.818715
# Unit test for method address of class Address
def test_Address_address():
    # Because Address(locale='test') not exists,
    # it should use the same data as that of 'en'.
    assert Address(locale='test').address() == \
        '{st_num} {st_name} {st_sfx}'.format(
            st_num=Address(locale='en').street_number(),
            st_name=Address(locale='en').street_name(),
            st_sfx=Address(locale='en').street_suffix(),
        )


# Generated at 2022-06-12 01:28:04.508347
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    print(address)



# Generated at 2022-06-12 01:28:08.216845
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert re.match(r'(\d,\s)?[a-zA-Z0-9,\.\s-]+', a.address()) is not None



# Generated at 2022-06-12 01:28:15.487544
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    import random
    import string
    from collections import Counter

    # Set seed value
    random.seed(0)
    address = Address(random)

    postal_codes = set()
    for i in range(0, 200):
        postal_codes.add(address.postal_code())
    assert len(postal_codes) == 200

    street_numbers = set()
    street_names = set()
    street_suffixes = set()
    for i in range(0, 200):
        street_numbers.add(address.street_number())
        street_names.add(address.street_name())
        street_suffixes.add(address.street_suffix())
    assert len(street_numbers) == 200
    assert len(street_names)

# Generated at 2022-06-12 01:28:17.676894
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)

# Generated at 2022-06-12 01:28:20.370476
# Unit test for method address of class Address
def test_Address_address():
    provider = Address(locale="zh_CN")
    for _ in range(100):
        assert isinstance(provider.address(), str) == True


# Generated at 2022-06-12 01:28:27.916499
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    for _ in range(10):
        assert address.address().startswith('#')
        assert address.address().count('#') == 2

    address = Address('zh')
    for _ in range(10):
        assert address.address()[:2] in ('大道', '街道', '路', '路')

    address = Address('pt')
    for _ in range(10):
        assert address.address().count('#') == 2
        assert address.address().endswith('##')


# Generated at 2022-06-12 01:28:29.110021
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('en')
    assert not addr.address()



# Generated at 2022-06-12 01:28:31.732544
# Unit test for method address of class Address
def test_Address_address():
    """Test Address class and attribute address."""
    a = Address().address()
    assert str(a) == 'str'


# Generated at 2022-06-12 01:28:34.061516
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='it')
    assert address.address() == 'Via 81 di via dei della'


# Generated at 2022-06-12 01:28:41.747890
# Unit test for method address of class Address
def test_Address_address():
    """Test function address of class Address.

    This function tests the functionality using the
    example given in the documentation of the class Address
    """

    #Init the object
    address = Address()

    #Expected result
    exp_result = '1090 Queen Street West'

    #Result
    result = address.address()

    print('-------------------')
    print('Test Address:')
    print('-------------------')
    # Print the result
    print(result)
    # Compare the result with expected result
    if(exp_result!=result):
        print('ERROR')
    else:
        print('SUCCESS')
    print('-------------------')


# Generated at 2022-06-12 01:29:08.545090
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender
    address = Address()
    address.seed(1)
    a = address.address()
    assert a == '4312 Waldecker Straße'
    a = address.address(gender=Gender.FEMALE)
    assert a == '1940 Elly-Beinhorn-Straße'
    a = address.address(alphabet='ru')
    assert a == 'Ленина, 0'
    a = address.address(alphabet='ja')
    assert a == '東京都葛飾区亀有六丁目25番地99号'



# Generated at 2022-06-12 01:29:18.820377
# Unit test for method address of class Address
def test_Address_address():
    import os
    import sys
    import unittest

    sys.path.append(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    )

    from mimesis.builtins import RussiaSpecProvider


    class TestAddress(unittest.TestCase):

        def setUp(self) -> None:
            self.address = Address()

        def test_address(self):
            result = self.address.address()
            self.assertTrue(result)

        def test_street_number(self):
            result = self.address.street_number()
            self.assertTrue(result)

        def test_street_name(self):
            result = self.address.street_name()
            self.assertTrue(result)

       

# Generated at 2022-06-12 01:29:19.720727
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr = address.address()
    assert len(addr) > 3



# Generated at 2022-06-12 01:29:21.394090
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address(['en'])
    assert 'Street number' in address.address()
    assert 'Street name' in address.address()
    assert 'Street suffix' in address.address()

# Generated at 2022-06-12 01:29:23.482441
# Unit test for method address of class Address
def test_Address_address():
    """Test the method address of class Address."""
    print("start test_Address_address")
    test = Address("en")
    print(test.address())



# Generated at 2022-06-12 01:29:24.504400
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    add.address()



# Generated at 2022-06-12 01:29:27.645776
# Unit test for method address of class Address
def test_Address_address():
    from IPython import embed; embed()
    from mimesis import Address
    address = Address('zh')
    print(address.address())


# Generated at 2022-06-12 01:29:37.674739
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert addr.address() == '91225 Lilac Terrace Suite 977' or \
        addr.address() == '91225 Lilac Terrace Suite 977' or \
        addr.address() == '91225 Lilac Terrace Suite 977' or \
        addr.address() == '91225 Lilac Terrace Suite 977' or \
        addr.address() == '91225 Lilac Terrace Suite 977' or \
        addr.address() == '91225 Lilac Terrace Suite 977'

    addr = Address(locale='en-US')

# Generated at 2022-06-12 01:29:42.521393
# Unit test for method address of class Address
def test_Address_address():
    method_name = 'address'
    a = Address(seed=12345)
    print('method %s' % method_name)
    print(a.address())
    print(a.address())
    print(a.address())
    print(a.address())
    print(a.address())
    print(a.address())



# Generated at 2022-06-12 01:29:43.615307
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    assert address.address() is not None

# Generated at 2022-06-12 01:30:06.339910
# Unit test for method address of class Address
def test_Address_address():
    a = Address().address()
    assert isinstance(a, str)

if __name__ == '__main__':
    print(Address().address())

# Generated at 2022-06-12 01:30:08.359469
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    assert adr.address() == '12345 rue de la libération Paris'


# Generated at 2022-06-12 01:30:10.261223
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())

test_Address_address()

# Generated at 2022-06-12 01:30:14.212125
# Unit test for method address of class Address
def test_Address_address():
    class Test():
        def __init__(self, address, street_number, street_name, street_suffix):
            self.address = address
            self.street_number = street_number
            self.street_name = street_name
            self.street_suffix = street_suffix

    def get_street_number_street_name_street_suffix(addr):
        return addr.split(' ')

    def _test_provider_address(provider, Test, test_data):
        default_addr = provider.address()
        default_street_number, default_street_name, default_street_suffix = \
            get_street_number_street_name_street_suffix(default_addr)

# Generated at 2022-06-12 01:30:15.622711
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert type(address.address()) == str


# Generated at 2022-06-12 01:30:17.542823
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert address.address() == '14 Stone Oak Glen'

# Generated at 2022-06-12 01:30:20.783077
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()

    for i in range(0, 10):
        adr.address()
        adr.address(language='zh')

# Generated at 2022-06-12 01:30:23.674670
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = Address()
    assert a.address()


# Generated at 2022-06-12 01:30:25.607731
# Unit test for method address of class Address
def test_Address_address():

    assert Address("es").address() != ''
    assert Address("en").address() != ''
    assert Address("fr").address() != ''

# Generated at 2022-06-12 01:30:26.786436
# Unit test for method address of class Address
def test_Address_address():
    address = Address.address()
    assert address.isdigit()



# Generated at 2022-06-12 01:30:55.022205
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    a = Address(Locale.EN)
    assert a.address() in (
        '563 Juliano Tunnel, East Lila, NJ 34303-5174',
        '5804 Lindgren Shoal, Port Alaina, VT 89899-9259',
        '851 Schamberger Vista, Port Josiah, UT 89698-9787',
        '2582 Marvin Meadows, West Aronfurt, MT 82847-4261',
        '4183 Daugherty Mount, Andersonfort, MI 42071-2030',
        '5016 Haley Lodge, Lake Adalynn, CT 93359-8440',
    )

# Generated at 2022-06-12 01:30:57.093064
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
# test_Address_address()



# Generated at 2022-06-12 01:30:58.250094
# Unit test for method address of class Address
def test_Address_address():
    address = Address('ja')
    assert address.address() is not None


# Generated at 2022-06-12 01:30:59.447730
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    a.address()


# Generated at 2022-06-12 01:31:00.926205
# Unit test for method address of class Address
def test_Address_address():
    s = Address(locale='zh')
    print(s.address())

# Generated at 2022-06-12 01:31:03.054929
# Unit test for method address of class Address
def test_Address_address():
    print('Address.address')
    x = Address()
    for _ in range(10):
        addr = x.address()
        print(addr)
        assert addr
        

# Generated at 2022-06-12 01:31:07.069774
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = Address(locale='en')
    assert a.address()


# Generated at 2022-06-12 01:31:10.053629
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    b = Address()
    print(a.address())
    print(b.address())


if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:31:12.790562
# Unit test for method address of class Address
def test_Address_address():
    provider = Address(locale = 'en')
    address = provider.address()
    print(address)
    # TODO: 测试更多的locale情况


# Generated at 2022-06-12 01:31:15.041564
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    result = ad.address()
    assert isinstance(result, str)

# Generated at 2022-06-12 01:32:10.098899
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != Address().address()

# Generated at 2022-06-12 01:32:11.266765
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ""


# Generated at 2022-06-12 01:32:12.720036
# Unit test for method address of class Address
def test_Address_address():
    print(Address('en').address())
    return Address('en').address()


# Generated at 2022-06-12 01:32:13.788304
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    t = a.address()
    assert t


# Generated at 2022-06-12 01:32:14.831977
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    assert a.address() != a.address()

# Generated at 2022-06-12 01:32:17.110011
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-12 01:32:20.631915
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    result = address.address()
    assert result
    assert isinstance(result, str)


# Generated at 2022-06-12 01:32:26.905953
# Unit test for method address of class Address
def test_Address_address():
    """Test for address method."""
    from mimesis.enums import Gender
    mimesis = Address('ru')
    name = mimesis.person.full_name(gender=Gender.MALE)
    street_name = mimesis.address()
    assert street_name == '{}, {} {}'.format(
        name,
        mimesis.random.randint(1, 1400),
        mimesis.street_name())



# Generated at 2022-06-12 01:32:28.965357
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for Address.address()."""
    addr = Address()
    print(addr.address())
    print(addr.address())

# Generated at 2022-06-12 01:32:30.328974
# Unit test for method address of class Address
def test_Address_address():
    s = '6022 Old York Road'
    assert Address().address() == s

