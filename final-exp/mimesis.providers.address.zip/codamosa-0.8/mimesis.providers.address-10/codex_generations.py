

# Generated at 2022-06-12 01:24:50.971727
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    addr = adr.address()


# Generated at 2022-06-12 01:24:52.835633
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert len(address.address()) > 0


# Generated at 2022-06-12 01:24:55.702264
# Unit test for method address of class Address
def test_Address_address():
    address = Address(random_state = 42)
    assert address.address() == '1 rue des Hauts-de-Chênes, Lyon'


# Generated at 2022-06-12 01:24:57.835180
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    text = address.address()
    assert type(text) == str
    assert len(text) > 0


# Generated at 2022-06-12 01:24:59.205888
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    assert obj.address() not in (None, "")

# Generated at 2022-06-12 01:25:01.840814
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    address = add.address()
    assert address



# Generated at 2022-06-12 01:25:03.710135
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    print(result)
    assert result


# Generated at 2022-06-12 01:25:07.257966
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address

    a = Address()
    for i in range(10):
        assert isinstance(a.address(), str)
        print(a.address())


# Generated at 2022-06-12 01:25:17.755058
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address"""
    locale = 'ko'
    address = Address(locale=locale)

    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()
    postal_code = address.postal_code()
    city = address.city()

    result = '{} {} {} {} {}'.format(
        postal_code,
        city,
        st_num,
        st_name,
        st_sfx,
    )

    assert isinstance(result, str)
    assert address.address() == result


if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:25:18.669439
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    assert a.address()

# Generated at 2022-06-12 01:25:24.653253
# Unit test for method address of class Address
def test_Address_address():
    address = Address("en")
    print(address.address())

# Generated at 2022-06-12 01:25:26.676861
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    name = address.address()
    print('address: %s' % name)


# Generated at 2022-06-12 01:25:28.413266
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    assert isinstance(address_obj.address(), str)


# Generated at 2022-06-12 01:25:32.350742
# Unit test for method address of class Address
def test_Address_address():
    import json
    Address().address()
    with open('address.json', 'r') as f:
        data = json.load(f)
    assert 'fmt' in data
    assert isinstance(data['fmt'], str)

# Generated at 2022-06-12 01:25:34.206789
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    a = Address()
    assert a.street_name() in a.address()

# Generated at 2022-06-12 01:25:35.944371
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()


# Generated at 2022-06-12 01:25:40.032151
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    # Create object Address with locale 'en'
    addr = Address(locale=Locale.EN)
    # Print random address in format '302 W. Maple Ave.'
    print(addr.address())


# Generated at 2022-06-12 01:25:42.049882
# Unit test for method address of class Address
def test_Address_address():
    value = Address().address()
    assert value != ""
    assert value is str


# Generated at 2022-06-12 01:25:43.438063
# Unit test for method address of class Address
def test_Address_address():
    print('Testing Address.address')
    address = Address(use_cache=True)
    # print(address.address())
    print('passing')
    return address.address()


# Generated at 2022-06-12 01:25:49.864254
# Unit test for method address of class Address
def test_Address_address():
    address1 = Address(locale='en')
    address2 = Address(locale='ja')
    address3 = Address(locale='zh')
    print(address1.address())
    print(address2.address())
    print(address3.address())
    print(address1.province())
    print(address2.province())
    print(address3.province())


# Generated at 2022-06-12 01:25:56.605465
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    addr = Address()
    assert isinstance(addr.address(), str)

# Generated at 2022-06-12 01:25:58.628978
# Unit test for method address of class Address
def test_Address_address():
    # address = Address()
    # result = address.address()
    # print(result)
    assert True
    # pass

# Generated at 2022-06-12 01:26:04.794348
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.exceptions import NonEnumerableError
    a = Address('en')
    assert a.address() is not None
    assert a.address(locale='ru') is not None
    a.validate_locale()
    try:
        a.address(locale='foo')
    except NonEnumerableError:
        print('test_Address_address success')
        return True
    assert False

# Generated at 2022-06-12 01:26:08.183518
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    st_num = add.street_number()
    st_name = add.street_name()

    result = add.address()

    assert result == st_num + ' ' + st_name + ' Street'

# Generated at 2022-06-12 01:26:09.529944
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-12 01:26:11.493643
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())

# Generated at 2022-06-12 01:26:15.251200
# Unit test for method address of class Address
def test_Address_address():
    a0 = Address(seed=0)
    assert a0.address() == '402 Hazelcrest Mews'

    a1 = Address(seed=1)
    assert a1.address() == '16-1 Farragut Drive'

# Generated at 2022-06-12 01:26:17.150853
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address() #=> '43835 Larkin Road'


# Generated at 2022-06-12 01:26:18.039324
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())

# Generated at 2022-06-12 01:26:29.104599
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import CountryCode

    adr = Address('pt-br')

    # Ensure that the data used is correct
    assert adr.address() == 'Rua 905, Q 20, Lourdes'
    assert adr.address() == 'Rua 468, Jardim Guanabara, Morumbi'

    # Ensure the different formats
    assert adr.address(CountryCode.A2) == 'Rua 838, Jd. das Nações, São Joaquim'
    assert adr.address(CountryCode.A3) == 'Rua 938, Chácara Alvorada, Vila Altamiro'

# Generated at 2022-06-12 01:26:36.143814
# Unit test for method address of class Address
def test_Address_address():
    data_provider_address = Address()
    result = data_provider_address.address()
    print(result)


# Generated at 2022-06-12 01:26:41.916206
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    full_address = a.address()
    short_address = a.address()

    # Test condition
    # @full_address: Right
    # @short_address: Wrong
    assert(len(full_address) != len(short_address))

    # Test condition
    # @address: Random length
    assert(len(full_address) > 0 and len(short_address) > 0)

# Generated at 2022-06-12 01:26:43.273588
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str


# Generated at 2022-06-12 01:26:46.352916
# Unit test for method address of class Address
def test_Address_address():
    #TODO: write unit test for method address of class Address
    assert False


# Generated at 2022-06-12 01:26:48.089107
# Unit test for method address of class Address
def test_Address_address():
    myobj = Address(locale='en')
    result = myobj.address()
    assert result != None

# Generated at 2022-06-12 01:26:49.355912
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-12 01:26:53.603276
# Unit test for method address of class Address
def test_Address_address():
    """Unit test of method address of class Address."""
    locale = 'en-US'
    seed = 123
    a = Address(locale=locale, seed=seed)

    assert a.address() == '935 Ecker Drive'
    assert a.address() == '87749 O\'Connell Centers'
    assert a.address() == '91343 8th Extension'

# Generated at 2022-06-12 01:26:54.970689
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    assert isinstance(provider.address(), str)


# Generated at 2022-06-12 01:26:56.100018
# Unit test for method address of class Address
def test_Address_address():
    address_object = Address()
    assert address_object.address() == '4103 SW Cerro St'


# Generated at 2022-06-12 01:27:02.497617
# Unit test for method address of class Address
def test_Address_address():
    from .address import Address
    adrs = Address()
    print(adrs.street_number())
    print(adrs.street_name())
    print(adrs.address())
    print(adrs.street_suffix())
    print(adrs.state(abbr=True))
    print(adrs.region(abbr=True))
    print(adrs.province(abbr=True))
    print(adrs.federal_subject(abbr=True))
    print(adrs.prefecture(abbr=True))
    print(adrs.postal_code())
    print(adrs.zip_code())
    print(adrs.country_code(fmt='A4'))
    print(adrs.country(allow_random=True))
    print(adrs.city())
    print

# Generated at 2022-06-12 01:27:13.423567
# Unit test for method address of class Address
def test_Address_address():

    for _ in range(100):
        assert Address().address() != Address().address()

# Generated at 2022-06-12 01:27:15.720732
# Unit test for method address of class Address
def test_Address_address():
    d = Address()
    s = d.address()
    assert s
    assert isinstance(s, str) == True

# Generated at 2022-06-12 01:27:18.567366
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address = address.address()
    assert isinstance(address, str)
    assert address


# Generated at 2022-06-12 01:27:21.037748
# Unit test for method address of class Address
def test_Address_address():
    p = Address()

    # to make sure that this method returns a non-empty string
    assert p.address()


# Generated at 2022-06-12 01:27:24.087908
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    # Run a simple test and check that the result is not None
    assert result is not None
    assert isinstance(result, str)


# Generated at 2022-06-12 01:27:25.535797
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    assert ad.address() != None


# Generated at 2022-06-12 01:27:27.321396
# Unit test for method address of class Address
def test_Address_address():
    addr = Address("ru")
    print(addr.address())

if __name__ == "__main__":
    test_Address_address()

# Generated at 2022-06-12 01:27:29.475521
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    assert isinstance(adr.address(), str)
    assert adr.address() != adr.address()



# Generated at 2022-06-12 01:27:32.359782
# Unit test for method address of class Address
def test_Address_address():
    """Test output from method Address.address()"""
    locale = 'en'
    a = Address(locale)
    assert 0 < len(a.address()) <= 200

# Generated at 2022-06-12 01:27:32.899504
# Unit test for method address of class Address
def test_Address_address():
    # Tests
    assert Address().address()

# Generated at 2022-06-12 01:27:57.993115
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street_number = int(address.street_number())
    street_name = str(address.street_name())
    street_suffix = str(address.street_suffix())
    full_address = str(address.address())
    assert full_address == "s " + str(street_number) + " " + \
        str(street_name) + " " + str(street_suffix)


# Generated at 2022-06-12 01:28:09.677424
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    def test_with_locale(locale: str, result: str) -> None:
        """Test with locale.

        :param locale: Locale.
        :param result: Result.
        """
        address = Address(locale)
        assert address.address() == result

    test_with_locale(Locale.EN, '35 Nelson Street')
    test_with_locale(Locale.DE, '11478 Berliner Allee, 518')
    test_with_locale(Locale.RU, 'Москва, ул. Казанская, д. 13/2')

# Generated at 2022-06-12 01:28:14.254852
# Unit test for method address of class Address
def test_Address_address():
    '''
    function_name:  test_Address_address
    function_detail: 
        A function for unit testing for method address of class Address
    parameter: 
        none
    return: 
        none
    '''
    # Get the value of address from Address class
    str_address = Address().address()
    # Check if the value of address is null
    if str_address == None:
        print("Fail test_Address_address")


# Generated at 2022-06-12 01:28:15.770659
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) > 0

# Generated at 2022-06-12 01:28:18.907432
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert address.startswith("No ")
    assert len(address.split()) == 3


# Generated at 2022-06-12 01:28:21.920299
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    l = [addr.address() for i in range(100)]
    assert l.count('1 Main St') != 0


# Generated at 2022-06-12 01:28:24.001299
# Unit test for method address of class Address
def test_Address_address():
    address = Address('ar')
    result = address.address()
    assert result is not None
    assert len(result) > 0


# Generated at 2022-06-12 01:28:27.644527
# Unit test for method address of class Address
def test_Address_address():
    print('address:', Address(locale='en').address())
    print('full:', Address(locale='en').address(full=True))
    print('address_with_country:', Address(locale='en').address_with_country())


# Generated at 2022-06-12 01:28:29.466976
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert type(address.address()) == str
    assert len(address.address()) != 0


# Generated at 2022-06-12 01:28:40.292507
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode

    l = 'en'
    x = Address(l)

    assert x.address()
    assert x.street_number()
    assert x.street_name()
    assert x.street_suffix()
    assert x.state()
    assert x.region()
    assert x.province()
    assert x.federal_subject()
    assert x.prefecture()
    assert x.postal_code()
    assert x.zip_code()
    assert x.country()
    assert x.city()
    assert x.latitude()
    assert x.longitude()
    assert x.coordinates()
    assert x.continent()
    assert x.calling_code()

    x.set_locale('de')
    # Repeat all methods for German locale

    assert x

# Generated at 2022-06-12 01:29:29.295061
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = Address()
    result = a.address()
    assert isinstance(result, str)
    assert result != ""


# Generated at 2022-06-12 01:29:33.854806
# Unit test for method address of class Address
def test_Address_address():
    # Arrange
    my_address = Address(locale='en')
    exception = False

    # Act
    try:
        addr = my_address.address()
    except AttributeError:
        exception = True

    # Assert
    assert not exception
    assert isinstance(addr, str) and len(addr) > 3

# Generated at 2022-06-12 01:29:35.228593
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) >= 0
    assert len(Address('en-US').address()) >= 0


# Generated at 2022-06-12 01:29:46.192070
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Country
    from mimesis.providers.address import Address
    from mimesis.providers.utils import Provider

    address = Address('ru')
    ru_address = RussiaSpecProvider(Address('ru'))
    assert address.address() != ru_address.address()
    assert isinstance(address._data, dict)

    address = Address(locale='en')
    assert len(address.address()) > 0

    class A(Address, Provider):
        """Combination of Address and Provider."""

        class Meta:
            """Class for metadata."""

            name = 'test'

        def __init__(self, *args, **kwargs) -> None:
            """Initialize attributes."""

# Generated at 2022-06-12 01:29:58.977532
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address as AP
    en_address = AP(locale='en-US')
    assert en_address.address() != ''
    assert en_address.address().count(' ') >= 3
    assert 'Street' in en_address.address()

    ar_address = AP(locale='ar-SA')
    assert ar_address.address() != ''
    assert ar_address.address().count(' ') >= 3
    assert en_address.address().count(' ') >= 3
    assert 'حي' in ar_address.address()

    assert en_address.calling_code() != ''
    assert AP.Meta.name == 'address'
    assert len(AP.country_code(fmt=CountryCode.A3)) == 3


# Generated at 2022-06-12 01:30:03.248068
# Unit test for method address of class Address
def test_Address_address():
    print("\nTesting method address of class Address")
    print(Address().address())
    print(Address().address())
    print(Address().address())
    print(Address().address())
    print(Address().address())


# Generated at 2022-06-12 01:30:09.968630
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == Address().address()
    assert Address().address(locale='en') == Address(locale='en').address()
    assert Address().address(locale='en') == Address(locale='en').address()
    assert Address().address(locale='es') == Address(locale='es').address()
    assert Address().address(locale='en') != Address(locale='es').address()

# Generated at 2022-06-12 01:30:14.437454
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    fmt = '{self.address()}'
    result = eval(fmt)

    assert isinstance(result, str)
    assert result
    assert len(result.split()) >= 2
    assert len(result.split()) <= 5


# Generated at 2022-06-12 01:30:15.598771
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-12 01:30:27.259385
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import en
    from mimesis.enums import CountryCode
    from mimesis.enums import Gender

    addr = Address(locale='en', seed=4242)
    addr.add_provider('address', Address(locale='en', seed=4242))
    addr.add_provider('personal', en.Personal(locale='en', seed=4242))

    addr.address()
    # '837 Langosh Loaf
    #  Apt. 953'

    addr.address(capitalize=True)
    # '837 Langosh Loaf
    #  Apt. 953'

    addr.address(capitalize=True, abbreviate=True)
    # '837 Langosh Ln
    #  Apt. 953'
