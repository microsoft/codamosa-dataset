

# Generated at 2022-06-12 01:24:54.385427
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    Address(Locale.JA).address()
    Address(Locale.EN).address()
    Address(Locale.RU).address()


# Generated at 2022-06-12 01:25:05.924090
# Unit test for method address of class Address
def test_Address_address():
    '''
    Test method address of class Address
    :return:
    '''
    address = Address(locale='en-US')
    print('address is:', address.address())
    address = Address(locale='zh_CN')
    print('address is:', address.address())
    address = Address(locale='ja')
    print('address is:', address.address())
    address = Address(locale='ru')
    print('address is:', address.address())
    address = Address(locale='ro')
    print('address is:', address.address())
    address = Address(locale='it')
    print('address is:', address.address())
    address = Address(locale='en-PH')
    print('address is:', address.address())
    address = Address(locale='uk')


# Generated at 2022-06-12 01:25:07.769636
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr = address.address()
    assert isinstance(addr, str)


# Generated at 2022-06-12 01:25:08.980268
# Unit test for method address of class Address
def test_Address_address():
    x = Address()
    assert x.address()


# Generated at 2022-06-12 01:25:11.511315
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('zh')
    assert type(addr.address()) == str
    print('address test passed')


# Generated at 2022-06-12 01:25:16.041064
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == 'Владислава Кузнецова улица, 827-30'

test_Address_address()

# Generated at 2022-06-12 01:25:18.190574
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None
    assert type(result) is str


# Generated at 2022-06-12 01:25:20.567888
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result

    address2 = Address()
    result2 = address2.address()
    assert result2 != result



# Generated at 2022-06-12 01:25:25.994924
# Unit test for method address of class Address
def test_Address_address():
    from pprint import pprint
    import os,sys
    sys.path.append(os.path.abspath('../'))
    from mimesis import Address
    import pdb;pdb.set_trace()
    ad = Address('zh')
    print(ad.address())

if __name__ == "__main__":
    test_Address_address()

# Generated at 2022-06-12 01:25:27.931253
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    assert type(Address().address()) != type(None)


# Generated at 2022-06-12 01:25:33.336993
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    Address(locale=Locale.SPANISH).address()


if __name__ == "__main__":
    test_Address_address()

# Generated at 2022-06-12 01:25:36.589556
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    result = address.address()
    assert len(result) > 0


# Generated at 2022-06-12 01:25:39.561995
# Unit test for method address of class Address
def test_Address_address():
    address = Address('zh')
    test_address = address.address()
    assert test_address != None
    print("Address.address is: " + test_address)


# Generated at 2022-06-12 01:25:41.928116
# Unit test for method address of class Address
def test_Address_address():
    x = Address.address()
    assert isinstance(x, str)
    assert len(x) > 2


# Generated at 2022-06-12 01:25:48.838107
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

# Generated at 2022-06-12 01:25:50.568642
# Unit test for method address of class Address
def test_Address_address():
    """Test Address().address()."""
    assert Address().address() == '100 Main Street'


# Generated at 2022-06-12 01:25:53.583169
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    check_values = "308 Fadel Stravenue\n669 Hills Trace"
    value = Address().address()
    assert value in check_values

# Generated at 2022-06-12 01:25:55.595615
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    assert ad.address()

# Generated at 2022-06-12 01:25:57.386882
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    result = addr.address()
    assert result


# Generated at 2022-06-12 01:26:00.493650
# Unit test for method address of class Address
def test_Address_address():
    address = Address('fr')
    tmp = address.address()
    try:
        assert isinstance(tmp, str)
    except AssertionError:
        assert False


# Generated at 2022-06-12 01:26:15.694607
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    from mimesis.enums import Locale
    from mimesis.exc import NonEnumerableError
    from mimesis.exceptions import NonEnumerableError

    # Test for default locale
    address = Address()
    result = address.address()
    assert result == '3341 Good Street'

    # Test for ru locale
    address = Address(locale=Locale.RU)
    result = address.address()
    assert result == 'Улица Героев, д. 6, кв. 43'

    # Test for locale which doesn't support in address_fmt
    address = Address(locale='fake_locale')
    result = address.address()
    assert result == '3341 Good Street'

    # Test for ru

# Generated at 2022-06-12 01:26:17.457339
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    data = address.address()
    assert data is not None
    assert data != ''

# Generated at 2022-06-12 01:26:19.800624
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = Address()
    assert a.address() != a.address()
    assert isinstance(a.address(), str) == True


# Generated at 2022-06-12 01:26:21.891589
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
# Result:
# 153 Oxford Street


# Generated at 2022-06-12 01:26:23.248232
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='zh-CN')
    print(address.address())

# Generated at 2022-06-12 01:26:24.654823
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '2285 Janelle Viaduct'

# Generated at 2022-06-12 01:26:26.963257
# Unit test for method address of class Address
def test_Address_address():
    address = Address("zh")
    assert address.address() != ""


# Generated at 2022-06-12 01:26:34.253834
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    st_num = addr.street_number()
    st_name = addr.street_name()
    st_sfx = addr.street_suffix()

    fmt = addr._data['address_fmt']

    if addr.locale in SHORTENED_ADDRESS_FMT:
        assert addr.address() == fmt.format(
            st_num=st_num,
            st_name=st_name,
        )
    elif addr.locale == 'ja':
        assert addr.address() == fmt.format(
            addr.random.choice(addr._data['city']),
            # Generate list of random integers
            # in amount of 3, from 1 to 100.
            *addr.random.randints(amount=3, a=1, b=100),
        )
   

# Generated at 2022-06-12 01:26:36.877641
# Unit test for method address of class Address
def test_Address_address():
    print("Inside test_Address_address()")
 
    address = Address()
    return address.address()


# Generated at 2022-06-12 01:26:45.844424
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    adr = Address('en')
    assert (adr.address()) == '2363 Hintze Place'
    assert (adr.address()) == '89715 Center Point'
    assert (adr.address()) == '78154 Hintze Parkway'
    assert (adr.address()) == '536 Mayview Terrace'
    assert (adr.street_number()) == '1062'
    assert (adr.street_name()) == 'Tanglewood'
    assert (adr.street_name()) == 'Brucker'
    assert (adr.street_suffix()) == 'Path'
    assert (adr.street_suffix()) == 'Place'
    assert (adr.address()) == '1062 Tanglewood Path'
    assert (adr.address()) == '1062 Brucker Place'

#

# Generated at 2022-06-12 01:26:52.810123
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street = address.street_name() + ' ' + address.street_number() + ' ' + address.street_suffix()
    assert address.address() == street
    assert address.street_name().lower() in address.address().lower()

# Generated at 2022-06-12 01:26:53.939815
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str


# Generated at 2022-06-12 01:26:55.995333
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    data = address.address()
    assert isinstance(data, str)
    assert 'No.' in data or '#' in data
    assert data.endswith('Street') or data.endswith('Ave.')

# Generated at 2022-06-12 01:26:56.989908
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert type(a.address()) == str

# Generated at 2022-06-12 01:26:58.855381
# Unit test for method address of class Address
def test_Address_address():
    # GIVEN
    address = Address('en')
    # WHEN
    result = address.address()
    # THEN
    assert result.isalpha()


# Generated at 2022-06-12 01:27:00.375335
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(Local.en)
    assert address.address()


# Generated at 2022-06-12 01:27:03.695126
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    global address
    address = Address('en') # Start the class
    assert address.address() == '921 Argelia Hills'


# Generated at 2022-06-12 01:27:09.076350
# Unit test for method address of class Address
def test_Address_address():
    data = set()
    class A:
        ad = Address('en')
        def address(self):
            data.add(self.ad.address())
        def all(self):
            for i in range(5000):
                self.address()
    A().all()
    assert len(data) == 5000

# Generated at 2022-06-12 01:27:10.089602
# Unit test for method address of class Address
def test_Address_address():
    pass


# Generated at 2022-06-12 01:27:12.213414
# Unit test for method address of class Address
def test_Address_address():
    address1 = Address()
    address2 = Address(seed=123456)

    assert address1.address() != address2.address()

# Generated at 2022-06-12 01:27:18.608218
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result
    assert isinstance(result, str)

# Generated at 2022-06-12 01:27:20.112751
# Unit test for method address of class Address
def test_Address_address(): 
    import pytest
    address = Address('en')
    assert type(address.address()) == str


# Generated at 2022-06-12 01:27:23.122193
# Unit test for method address of class Address
def test_Address_address():
    address_ = Address(locale='en')
    format_ = address_.address()
    assert format_ == '1400 W.Grove St.'


# Generated at 2022-06-12 01:27:28.302890
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.localization import Localization

    Localization.set_current_locale(Locale.EN)
    ad = Address(Localization.EN)
    address = ad.address()
    assert isinstance(address, str)



# Generated at 2022-06-12 01:27:30.863068
# Unit test for method address of class Address
def test_Address_address():
    '''
    Test for method address of class Address
    '''
    from mimesis.providers.address import Address
    address = Address('ru')
    assert isinstance(address.address(), str)


# Generated at 2022-06-12 01:27:33.524957
# Unit test for method address of class Address
def test_Address_address():
    for i in range(10):
        assert len(Address().address()) > 2


# Generated at 2022-06-12 01:27:35.702960
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.provider = 'ru'
    print(address.address())
    print(address.address())
    print(address.address())
    return


# Generated at 2022-06-12 01:27:38.034103
# Unit test for method address of class Address
def test_Address_address():
    """Test for address() method."""
    address = Address()

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:27:39.453331
# Unit test for method address of class Address
def test_Address_address():
    import random
    Address().address()
    Address(random.randint(0, 100)).address()



# Generated at 2022-06-12 01:27:42.308962
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    value = address.address()
    print(value)
    assert len(value) > 0


# Generated at 2022-06-12 01:27:53.846336
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    # init object address with current locale
    address = Address(locale=Locale.RUSSIAN)
    # generate address
    address.address()
    # output data
    # >> 'Пирогова, 129/1'

# Generated at 2022-06-12 01:27:55.124043
# Unit test for method address of class Address
def test_Address_address():
    from pprint import pprint
    a = Address(locale='ja')
    pprint(a.address())

# Generated at 2022-06-12 01:27:56.031367
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()
    assert a.address()

# Generated at 2022-06-12 01:28:08.483274
# Unit test for method address of class Address
def test_Address_address():
    # Test case 1:
    #
    # INPUT
    #   None
    # OUTPUT
    #   full address
    addr = Address()
    print(addr.address())
    address = addr.address()

    # Test case 2:
    #
    # INPUT
    #   address
    # OUTPUT
    #   full address
    address_list = address.split(' ')
    street_num = address_list[0]
    street_name = address_list[1]
    street_suffix = address_list[2]
    assert street_num.isdigit()
    assert street_suffix in addr._data['street']['suffix']
    assert street_name in addr._data['street']['name']

    # Test case 3:
    #
    # INPUT
    #   address

# Generated at 2022-06-12 01:28:09.313487
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    address = Address("es_ES")
    print(address.address())

# Generated at 2022-06-12 01:28:15.987727
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.data import ADDRESS_FMT
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.utils import get_digits
    street_name_fmt = ADDRESS_FMT[Locale.RU]['street_name_fmt']
    street_suffix_fmt = ADDRESS_FMT[Locale.RU]['street_suffix_fmt']
    s = Address(Locale.RU)
    s.random = lambda: 0.1
    # ex: 292-44 Ленина
    address = s.address()
    assert get_digits(address) == '292-44'

# Generated at 2022-06-12 01:28:20.320493
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for Address.address()."""
    country = 'ru'
    result = set()

    for i in range(10):
        a = Address(country)
        result.add(a.address())
    assert len(result) == 10

# Generated at 2022-06-12 01:28:22.143766
# Unit test for method address of class Address
def test_Address_address():
    address = Address('zh')
    print(address.address())

# Generated at 2022-06-12 01:28:23.872573
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    a = address.address()
    assert a is not None


# Generated at 2022-06-12 01:28:25.598492
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert type(a.address()) == str


# Generated at 2022-06-12 01:28:45.405277
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='ko')
    print(adr.address())
    print(adr.address())
    print(adr.address())


# Generated at 2022-06-12 01:28:49.723179
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.exceptions import NonEnumerableError

    # Start of test
    addr = Address()

    for i in range(100):
        addr.address()

    try:
        addr.address(None)
    except NonEnumerableError:
        pass  # This is the correct behavior.


# Generated at 2022-06-12 01:28:52.630474
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '221B Baker St.'
    assert address.address() == '221B Baker St.'
    assert address.address() == '221B Baker St.'


# Generated at 2022-06-12 01:29:00.979718
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    # '{st_num} {st_name} {st_sfx}'
    assert address.address() in [
        '384 Summerview Ter',
        '254 Arrowood Terrace',
        '91 Hanover Street',
        '7218 Maple Street',
    ]
    # '{st_num} {st_name}'
    assert address.address() in [
        '53 Cosmo Drive',
        '9288 Sun Valley Court',
        '846 Marsh Road',
        '2284 Fordham Court',
    ]
    # '{st_num} {st_name}-{st_sfx}'

# Generated at 2022-06-12 01:29:02.379059
# Unit test for method address of class Address
def test_Address_address():
    a = Address(seed=123)
    print(a.address())


# Generated at 2022-06-12 01:29:04.282498
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address"""
    address = Address()
    assert address.address()


# Generated at 2022-06-12 01:29:06.130675
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    x = a.address()
    assert type(x) == str

# Generated at 2022-06-12 01:29:15.900155
# Unit test for method address of class Address
def test_Address_address():
    import random
    import doctest
    from mimesis.providers.address import Address
    random.seed(0)
    address = Address('en')
    assert address.address() == '461 Adams Place'
    assert address.address() == '454 Mayer Mall'
    assert address.address() == '628 Woodruff Center'
    assert address.address() == '111291 Susan Terrace'
    assert address.address() == '35710 Hayes Trail'
    assert address.address() == '6826 Ronald Regan Alley'
    assert address.address() == '0640 Henry Place'
    assert address.address() == '7442 Rosella Road'
    assert address.address() == '76934 Veda Park'
    assert address.address() == '6338 Lakewood Gardens Alley'

# Generated at 2022-06-12 01:29:17.052748
# Unit test for method address of class Address
def test_Address_address():
    pass


# Generated at 2022-06-12 01:29:20.496677
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(locale= 'en')
    assert addr.address() == '25742 South Vorderer Place'
    assert addr.address() == '68934 South Eastman Plaza'
    assert addr.address() == '1 Eastman Circle'


# Generated at 2022-06-12 01:30:06.216688
# Unit test for method address of class Address
def test_Address_address():
    # Test default locale
    assert Address().address()
    # Test ja locale
    assert Address('ja').address()
    # Test ru locale
    assert Address('ru').address()

# Generated at 2022-06-12 01:30:16.512654
# Unit test for method address of class Address
def test_Address_address():
    from random import random
    from mimesis.enums import Gender
    from mimesis.builtins import Person

    fmt = [
        '{st_num} {st_name} {st_sfx}',
        '{st_num} {st_sfx} {st_name}',
    ]
    gender = [Gender.MALE, Gender.FEMALE]
    data = {}

    for i in range(1000):
        pers = Person(('en', 'ru', 'ru_RU', 'vi'), random() < 0.5)
        st_num = pers.address.street_number()
        st_name = pers.address.street_name()
        st_sfx = pers.address.street_suffix()
        gender = gender[i % 2]


# Generated at 2022-06-12 01:30:19.197971
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)
test_Address_address()


# Generated at 2022-06-12 01:30:23.713904
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    provider = Address('en')
    result = provider.address()
    assert result
    assert not result.isspace()
    assert len(result) <= 255


# Generated at 2022-06-12 01:30:30.342891
# Unit test for method address of class Address
def test_Address_address():
    """Test address method of class Address."""
    address = Address(seed=1234)
    assert address.address() == '094 Eileen Stream'
    assert address.address() == '179 Eileen Stream\n' \
                                'St. Theresa, AZ 37231-2676'
    assert address.address() == '051 Eileen Stream ' \
                                '(McKenziefield, AZ 37231-2676)'
    assert address.address() == '094 伊莉莎白壩浜01本町 03-18-33\n' \
                                'St. Theresa, AZ 37231-2676'

# Generated at 2022-06-12 01:30:39.781287
# Unit test for method address of class Address
def test_Address_address():
    import re

    # The pattern will extract:
    #   - street number,
    #   - street name,
    #   - street suffix.
    pattern = re.compile(r'^(\d+) (.*?)( ([a-zA-Z]+))?$')
    a = Address()

    address = a.address()
    assert re.search(pattern, address) is not None, (
        'the address generated must include',
        'the street number, the street name and the suffix')

    # If locale is "ja"
    a = Address('ja')
    address = a.address()
    assert re.search(pattern, address) is None, (
        'the address generated in Japan shall not',
        'have a street number, street name and suffix')

# Generated at 2022-06-12 01:30:46.126521
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert next(address) == '2659 West Street'
    assert next(address) == '1284 Wisson Street'
    assert next(address) == '1158 Hill Street'
    assert next(address) == '1254 Mill Road'
    assert address() == '2162 Nye Street'


# Generated at 2022-06-12 01:30:49.133603
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == 'Реки нетании, 23'
    assert Address(locale='ru').address() == 'Реки нетании, 23'

# Generated at 2022-06-12 01:30:51.593714
# Unit test for method address of class Address
def test_Address_address():
    a=Address()
    address=a.address()
    print(address)
    address=a.address()
    print(address)

test_Address_address()

# Generated at 2022-06-12 01:30:52.413407
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())

# Generated at 2022-06-12 01:32:42.713780
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    a = Address(use_cache=False)
    address_rus = a.address()
    print(address_rus)
    assert isinstance(address_rus,str) == True
    # print(len(address_rus))
    # assert len(address_rus) > 1
    # assert len(address_rus) < 300

test_Address_address()

# Generated at 2022-06-12 01:32:46.452265
# Unit test for method address of class Address
def test_Address_address():
    class Address_test:
        def __init__(self, locale):
            self.locale = locale

    import re
    address = Address(Address_test("en"))
    assert re.match("\d+ [A-Za-z]+", address.address()) is not None



# Generated at 2022-06-12 01:32:47.852041
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())



# Generated at 2022-06-12 01:32:53.303766
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.localization import EN
    from mimesis.builtins import Address
    from mimesis.providers.address import Address as BaseAddress

    EN.set_language('en')
    address = Address(EN)
    base_address = BaseAddress(EN)

    for _ in range(10):
        assert address.address() == base_address.address()

# Generated at 2022-06-12 01:32:55.442005
# Unit test for method address of class Address
def test_Address_address():
    i = 0
    while i < 10:
        print(Address('en').address())
        i += 1

# Generated at 2022-06-12 01:32:57.889173
# Unit test for method address of class Address
def test_Address_address():
    data = Address('ru').address
    print(data)
    assert data is not None


# Generated at 2022-06-12 01:33:03.259898
# Unit test for method address of class Address
def test_Address_address():
    from . import address
    from . import random

    address.random = random.Random()
    result = address.address()
    assert isinstance(result, str)

    result = address.address(locale='ko')
    assert isinstance(result, str)

    result = address.address(locale='ja')
    assert isinstance(result, str)


# Generated at 2022-06-12 01:33:04.457132
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != None


# Generated at 2022-06-12 01:33:05.156293
# Unit test for method address of class Address
def test_Address_address():
    address = Address('zh')
    print("Address:" + address.address())

# Generated at 2022-06-12 01:33:12.354110
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed = 123)
    assert address.address() == "19083 Stracke Burgs"
    assert address.address() == "568 Richardson Parks"
    assert address.address() == "025 Strosin Union"
    assert address.address() == "86939 Marks Ramp"
    assert address.address() == "1314 Ruecker Summit"
    assert address.address() == "2634 Nitzsche Knolls"
