

# Generated at 2022-06-12 01:25:02.463072
# Unit test for method address of class Address
def test_Address_address():

    class AddressMock(Address):

        class Meta:
            seed = 1

        def street_number(self, maximum: int = 1400) -> str:
            return '1'

        def street_name(self) -> str:
            return 'Street'

        def street_suffix(self) -> str:
            return 'Avenue'

    add = AddressMock()
    print('EN:', add.address())

    add.locale = 'ru'
    print('RU:', add.address())

    add.locale = 'de'
    print('DE:', add.address())

    add.locale = 'pl'
    print('PL:', add.address())

    add.locale = 'es'
    print('ES:', add.address())

    add.locale = 'fr'

# Generated at 2022-06-12 01:25:07.981475
# Unit test for method address of class Address
def test_Address_address():
    address_gen = Address()
    street_num = address_gen.street_number()
    street_name = address_gen.street_name()
    street_suffix = address_gen.street_suffix()
    assert address_gen.address() == \
        '{} {} {}'.format(
            street_num, street_name, street_suffix
        )

# Generated at 2022-06-12 01:25:09.537028
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    address = obj.address()
    assert address.__len__() > 0

# Generated at 2022-06-12 01:25:11.637071
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None
    print(result)

# Generated at 2022-06-12 01:25:14.837605
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    address_ts = address.address()
    assert type(address_ts) == str


# Generated at 2022-06-12 01:25:16.440216
# Unit test for method address of class Address
def test_Address_address():
    # Address().address()
    pass


# Generated at 2022-06-12 01:25:17.058780
# Unit test for method address of class Address
def test_Address_address():
    pass

# Generated at 2022-06-12 01:25:18.144923
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != a.address()


# Generated at 2022-06-12 01:25:19.520860
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()
    print("Test pass")

test_Address_address()

# Generated at 2022-06-12 01:25:21.607776
# Unit test for method address of class Address
def test_Address_address():
    """Test code of method address."""
    addr = Address()
    assert isinstance(addr.address(), str)


# Generated at 2022-06-12 01:25:29.687682
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    ru = RussiaSpecProvider(Gender.FEMALE)
    ru.address()
    ru.address()


# Generated at 2022-06-12 01:25:31.075994
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None

# Generated at 2022-06-12 01:25:35.771331
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.localization import DEFAULT_LOCALES
    a = Address(locale=Locale.EN)
    lst = []
    for i in range(50):
        lst.append(a.address())
    assert all(item in DEFAULT_LOCALES['en']['address'] for item in lst)
    assert type(a.address()) == str


# Generated at 2022-06-12 01:25:36.772695
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()

# Generated at 2022-06-12 01:25:39.737943
# Unit test for method address of class Address
def test_Address_address():
    for _ in range(100):
        ad = Address()
        assert len(ad.address()) == 8
        assert type(ad.address()) == str


# Generated at 2022-06-12 01:25:47.744149
# Unit test for method address of class Address

# Generated at 2022-06-12 01:25:49.573512
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    addr = adr.address()
    print("Address: ", addr )



# Generated at 2022-06-12 01:25:50.525318
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) == 6

# Generated at 2022-06-12 01:25:59.980643
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert Address.Meta.name == 'address'

# Generated at 2022-06-12 01:26:00.949340
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())
    print(a.address())
    print(a.address())



# Generated at 2022-06-12 01:26:13.140595
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    assert isinstance(provider.address(), str)
    for i in range(10):
        assert isinstance(provider.address(), str)

# Generated at 2022-06-12 01:26:14.211815
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()

# Generated at 2022-06-12 01:26:16.173260
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert len(a.address()) > 0;


# Generated at 2022-06-12 01:26:17.544510
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''

# Generated at 2022-06-12 01:26:19.592657
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    address = Address(seed=4321)
    result = address.address()
    assert result == '7417 Rätoromanisch Spur'

# Generated at 2022-06-12 01:26:21.171529
# Unit test for method address of class Address
def test_Address_address():
    address = Address().address()
    print("address=",address)

# Generated at 2022-06-12 01:26:22.975873
# Unit test for method address of class Address
def test_Address_address():
    """Sample test."""
    actual = Address().address()
    assert isinstance(actual, str)



# Generated at 2022-06-12 01:26:26.439856
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='ja')
    adr_add = adr.address()
    print(adr_add)
    assert adr_add


# Generated at 2022-06-12 01:26:27.776801
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('ru')
    print(addr.address())


# Generated at 2022-06-12 01:26:29.339793
# Unit test for method address of class Address
def test_Address_address():
	assert isinstance(Address().address(), str)
	assert len(Address().address()) > 3


# Generated at 2022-06-12 01:26:39.762130
# Unit test for method address of class Address
def test_Address_address():
    for _ in range(1):
        a = Address('en')
        print(a.address())


# Generated at 2022-06-12 01:26:43.109840
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    # TODO FIX
    # a = Address('en')
    # print(a.address())
    # print(a.address())
    # assert a.address() == '123 Maple Street'
    pass


# Generated at 2022-06-12 01:26:46.505914
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address('en')
    assert address.address() != address.address()


# Generated at 2022-06-12 01:26:55.096768
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.city())
    print(a.address())
    print(a.state())
    print(a.region())
    print(a.province())
    print(a.federal_subject())
    print(a.prefecture())
    print(a.country())
    print(a.country(True))
    print(a.postal_code())
    print(a.zip_code())
    print(a.country_code())
    print(a.country_code(CountryCode.A3))
    print(a.country_code(CountryCode.NUMERIC))
    print(a.country_code(CountryCode.A2))
    print(a.country_code(CountryCode.A2))
    print(a.country_code(CountryCode.N))

# Generated at 2022-06-12 01:26:56.638265
# Unit test for method address of class Address
def test_Address_address():
    def foo():
        address = Address()
        return address.address()

    x = foo()
    assert len(x) > 0

# Generated at 2022-06-12 01:26:58.284033
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Localization

    a = Address(localization=Localization.EN)
    print(a.address())

# Generated at 2022-06-12 01:26:59.519439
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    value = a.address()
    assert value is not None


# Generated at 2022-06-12 01:27:11.411185
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import AddressFormats

    address = Address(locale='en-US')

    assert address.address()
    assert address.address_fmt(AddressFormats.SHORT_ADDRESS)
    assert address.country_code(CountryCode.A2)
    assert address.country_code(CountryCode.A3)
    assert address.country_code(CountryCode.NUMERIC)

    address.set_locale('ru')
    assert address.country() == 'Россия'

    address.set_locale('en')
    assert address.country() != 'Россия'


# Generated at 2022-06-12 01:27:23.014523
# Unit test for method address of class Address
def test_Address_address():
    from collections import Counter
    from mimesis.enums import SubdivisionType

    _en = Address('en')
    _ru = Address('ru')
    _uk = Address('uk')

    # Get a list of 100 full addresses
    en_addrs = [_en.address() for _ in range(100)]
    ru_addrs = [_ru.address() for _ in range(100)]
    uk_addrs = [_uk.address() for _ in range(100)]

    assert all(
        (
            # Check that the length of each address is
            # not less than 5 symbols
            len(i) >= 5
            for i in (
                en_addrs +
                ru_addrs +
                uk_addrs
            )
        )
    )

# Generated at 2022-06-12 01:27:24.524268
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())


# Generated at 2022-06-12 01:27:49.198620
# Unit test for method address of class Address
def test_Address_address():
    """Test case for the method address of class Address."""
    from mimesis.builtins import BrazilSpecProvider

    addresses = []
    address = Address('en')
    address_jp = Address('ja')
    address_br = Address(BrazilSpecProvider)

    for _ in range(10):
        addresses.append(address.address())

    assert '\n' in address_jp.address()
    assert 'Rua ' in address_br.address()

    for address in addresses:
        assert address != ''

# Generated at 2022-06-12 01:27:52.647814
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import AddressFormats
    from mimesis.builtins import address

    a = address.Address()
    assert isinstance(a.address(AddressFormats.FULL), str)
    assert isinstance(a.address(AddressFormats.SHORT), str)

# Generated at 2022-06-12 01:27:53.971819
# Unit test for method address of class Address
def test_Address_address():
    print("test_Address_address")
    assert Address().address() is not None


# Generated at 2022-06-12 01:28:04.618014
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    from pprint import PrettyPrinter
    pp = PrettyPrinter(indent=4)

    # Create a instance of Address
    addr = Address('en')

    # Get a full address
    addr.address()
    # generate : '67566 Ashley Station'

    addr = Address('fr')
    addr.address()
    # generate : '27 Rue Sauvage'

    # Get a full address with Japanese locale with random city
    addr = Address('ja', seed=1234)
    addr.address()
    # generate : '東京都北区上長尾１丁目１５−１６'

    # Get a full address with Japanese locale with setting

# Generated at 2022-06-12 01:28:09.831317
# Unit test for method address of class Address
def test_Address_address():
    # Language = en
    adr = Address()
    assert adr.address() != ''
    # Language = de
    adr = Address(locale='de')
    assert adr.address() != ''
    # Language = ja
    adr = Address(locale='ja')
    assert adr.address() != ''

# Generated at 2022-06-12 01:28:13.650716
# Unit test for method address of class Address
def test_Address_address():
    c = Address()
    for _ in range(10):
        print(c.address())
    for _ in range(10):
        print(c.address('ru'))
    for _ in range(10):
        print(c.address('zh'))
    for _ in range(10):
        print(c.address('ja'))


# Generated at 2022-06-12 01:28:18.015286
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    from mimesis.enums import Locale
    
    address = Address(Locale.EN)
    assert address.address()


# Generated at 2022-06-12 01:28:19.781155
# Unit test for method address of class Address
def test_Address_address():
    obj = Address(random.Random())
    addr = obj.address()
    assert type(addr) is str

# Generated at 2022-06-12 01:28:22.016926
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en')
    assert a.address() == '2247 Orange Street'



# Generated at 2022-06-12 01:28:25.935756
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode

    A = Address(CountryCode.RU)
    print(A.address())
    print(A.address())
    print(A.address())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:29:17.011113
# Unit test for method address of class Address
def test_Address_address():
    from . import mimesis
    a = Address(mimesis.Mimesis().locale)
    assert a.locale == 'en'
    assert a.address() == '75957 Gay Gardens, New Bobview, TN 03050'
    assert a.address() == '6939 Maryville, West Nettie, MO 24147'
    assert a.address() == '94651 Green Fork, North Aubrey, MA 15878'
    assert a.address() == '57066 Ramona Circles, South Kalebtown, VT 05643'
    assert a.address() == '5984 Herman Isle, Marianside, NE 62367'
    assert a.address() == '96317 Diannaberg, Lake Gennie, SC 81843'

# Generated at 2022-06-12 01:29:18.817344
# Unit test for method address of class Address
def test_Address_address():
    
    # Create Address object
    adr = Address()
    # Get address
    adr.address()

# Generated at 2022-06-12 01:29:20.917945
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()

    # Testing method
    result = obj.address()

    # Save result for unit test
    assert isinstance(result, str)



# Generated at 2022-06-12 01:29:22.863073
# Unit test for method address of class Address
def test_Address_address():
    # unit test for address of class Address
    global_p = Address('fake')
    address = global_p.address()
    assert isinstance(address, str)

# Generated at 2022-06-12 01:29:24.348969
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-12 01:29:25.707183
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    res = addr.address()
    assert res is not None
    assert res != ''


# Generated at 2022-06-12 01:29:27.492330
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-12 01:29:29.589100
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert_valid_string(result)
# End unit test for method address of class Address


# Generated at 2022-06-12 01:29:39.451785
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == 'Россия, Санкт-Петербург, ул. Конная, 32/4'
    assert address.address() == 'Россия, Санкт-Петербург, ул. Конная, 32/4'
    assert address.address() == 'Россия, Санкт-Петербург, ул. Конная, 32/4'

# Generated at 2022-06-12 01:29:43.213685
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('ru')
    address = provider.address()
    assert type(address) == str
    assert len(address) > 0
    assert address != provider.address()
