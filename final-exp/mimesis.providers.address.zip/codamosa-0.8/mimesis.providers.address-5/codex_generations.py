

# Generated at 2022-06-12 01:24:50.924751
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert len(address.address()) > 1


# Generated at 2022-06-12 01:25:02.839202
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    from mimesis.enums import Country

    en_address = Address(locale=Country.ENGLISH)
    ja_address = Address(locale=Country.JAPANESE)


# Generated at 2022-06-12 01:25:04.674699
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en')
    assert a.address() != ''


# Generated at 2022-06-12 01:25:06.656945
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en').address()
    assert a


# Generated at 2022-06-12 01:25:16.820711
# Unit test for method address of class Address
def test_Address_address():
    """Test method address."""
    d = Address(random_state=42)
    assert d.address() == '12342 Maywald Meadow'

    d = Address(random_state=42, locale='sv')
    assert d.address() == 'Barnvägen 165'

    d = Address(random_state=42, locale='ru')
    assert d.address() == 'Кутузовский Бульвар, 9'

    d = Address(random_state=42, locale='ja')
    assert d.address() == '北海道新得町 19-17'



# Generated at 2022-06-12 01:25:19.607389
# Unit test for method address of class Address
def test_Address_address():
    """
    Testing address method of class Address
    """
    random_address = Address()
    result = random_address.address()
    assert len(str(result)) > 0


# Generated at 2022-06-12 01:25:24.473393
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    """Testing Address.address()."""
    address = Address(Locale.EN)
    assert isinstance(address.address(), str)
    assert address.address() != ''
    assert address.address() != None
    assert address.address() != False
    assert address.address() != True


# Generated at 2022-06-12 01:25:25.401340
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    ad.address()
    a = Address('ja')
    a.address()

# Generated at 2022-06-12 01:25:27.715281
# Unit test for method address of class Address
def test_Address_address():
    d = Address()
    # print(d.address())
    assert(len(d.address()) > 0)



# Generated at 2022-06-12 01:25:30.086765
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('en')
    a = addr.address()
    print(a)


test_Address_address()

# Generated at 2022-06-12 01:25:36.668455
# Unit test for method address of class Address
def test_Address_address():
    # Initialize object address
    address = Address()
    result = address.address()

    # Check is result not empty
    assert len(result) > 0

# Generated at 2022-06-12 01:25:41.077669
# Unit test for method address of class Address
def test_Address_address():
    # TODO move this test to a generic tests class and execute on all
    #  methods that generate a string
    # GIVEN
    address = Address()
    # WHEN
    result = address.address()
    # THEN
    assert result is not None


# Generated at 2022-06-12 01:25:48.325192
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for Address.address."""
    a = Address(seed=42)
    assert a.address() == '2093 Via Verde, Apt. 006'
    assert a.address() == '10991 Garden Alley, Apt. 005'
    assert a.address() == '06631 Cascade Pass, Suite 841'
    assert a.address() == '9654 Cherry Road, Apt. 998'
    assert a.address() == '4826 Green Hill, Apt. 543'
    assert a.address() == '86735 Main Way, Suite 082'
    assert a.address() == '0638 Windy Terrace, Suite 154'
    assert a.address() == '6319 Dell Valley, Apt. 944'
    assert a.address() == '59984 Rolling Circle, Apt. 006'

# Generated at 2022-06-12 01:25:50.895031
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    str_addr = address.address()
    assert isinstance(str_addr, str)


# Generated at 2022-06-12 01:25:52.343025
# Unit test for method address of class Address
def test_Address_address():
    import pytest
    address = Address(locale='en')
    assert address.address() not in ('', None)
    with pytest.raises(AttributeError):
        address.address(True)


# Generated at 2022-06-12 01:25:55.893500
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '313791 Noreen Track'
    assert address.address() == '63118 Mayert Stravenue'


# Generated at 2022-06-12 01:26:02.005600
# Unit test for method address of class Address
def test_Address_address():
    import jieba,re
    a = Address('zh')
    for i in range(2):
        address = a.address()
        print(address)
        address = list(jieba.cut(address))
        print(address)
        l = re.findall(r'.*省.*',address)
        if l:
            print(l)
        else:
            print('NULL')


# Generated at 2022-06-12 01:26:05.267078
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import AddressFormat

    address = Address('ru')
    assert isinstance(address.address(), str)
    assert address.address(address_format=AddressFormat.SHORT)

# Generated at 2022-06-12 01:26:08.279604
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    assert not obj.provider('address.state.abbr')
    assert  obj.provider('address.state.name')
    assert not obj.provider('address.city')

# Generated at 2022-06-12 01:26:10.955188
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    result = address.address()
    assert result is not None


# Generated at 2022-06-12 01:26:15.888721
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    result = address.address()
    assert len(result) > 3


# Generated at 2022-06-12 01:26:18.275733
# Unit test for method address of class Address
def test_Address_address():
    test1 = Address(locale='en')
    print(test1.address())
    test2 = Address(locale='ja')
    print(test2.address())


# Generated at 2022-06-12 01:26:19.965196
# Unit test for method address of class Address
def test_Address_address():
    location = Address(locale='zh')
    addr = location.address()
    assert isinstance(addr, str)


# Generated at 2022-06-12 01:26:22.091831
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None
    assert len(result) > 0

# Generated at 2022-06-12 01:26:23.470265
# Unit test for method address of class Address
def test_Address_address():
    address = Address.address()
    assert address != Address.address()

# Generated at 2022-06-12 01:26:28.733737
# Unit test for method address of class Address
def test_Address_address():
    file_name = "address_test_result.txt"
    result = ""
    address = Address()
    for x in range(100):
        result += address.address()+"\n"
    file_to_write_in = open(file_name,'w')
    file_to_write_in.write(result)


# Generated at 2022-06-12 01:26:31.889507
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address1 = Address(Locale.EN)
    for i in range(10):
        print(address1.address())

    address2 = Address(Locale.RU)
    for i in range(10):
        print(address2.address())



# Generated at 2022-06-12 01:26:42.684644
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    num = Address('en').street_number()
    assert isinstance(num, str)
    assert num.isdigit()

    st_name = Address('en').street_name()
    assert isinstance(st_name, str)
    assert st_name.istitle()

    st_sfx = Address('en').street_suffix()
    assert isinstance(st_sfx, str)
    assert st_sfx.istitle()

    address = Address('en').address()
    assert isinstance(address, str)

    address = Address('it').address()
    assert isinstance(address, str)
    assert address.count(',') == 1



# Generated at 2022-06-12 01:26:45.904549
# Unit test for method address of class Address
def test_Address_address():
    # TODO: add test for ja locale
    for _ in range(10):
        address = Address().address()
        assert address is not None

# Generated at 2022-06-12 01:26:48.089881
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)

# Add unit test for method address_components of class Address

# Generated at 2022-06-12 01:26:54.504115
# Unit test for method address of class Address
def test_Address_address():
    import codecs
    with codecs.open('data.txt', 'w', 'utf-8') as f:
        for i in range(100):
            f.write(Address('ja').address() + '\n')

# Generated at 2022-06-12 01:26:59.049171
# Unit test for method address of class Address
def test_Address_address():
    from nose.tools import assert_equal
    from mimesis.exceptions import NonEnumerableError

    address = Address('en')
    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()
    fmt = address._data['address_fmt']

    assert_equal(address.address(), fmt.format(
        st_num=st_num,
        st_name=st_name,
        st_sfx=st_sfx,
    )
    )


# Generated at 2022-06-12 01:27:00.397348
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert len(a.address()) > 0

# Generated at 2022-06-12 01:27:01.228942
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())

# Generated at 2022-06-12 01:27:12.924389
# Unit test for method address of class Address
def test_Address_address():
    tester = Address()
    for i in range(10):
        print(tester.address())
        print()

# Generated at 2022-06-12 01:27:24.812338
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    mask = '{st_num} {st_name} {st_sfx}'

    locale = 'en-us'
    a = Address(locale)
    result = a.address()

    assert a.random.choice(a._data['address_fmt']) != mask
    assert len(result.split()) == 3
    assert result.split()[0].isdigit()

    locale = 'cs-cz'
    a = Address(locale)
    result = a.address()

    assert mask in a._data['address_fmt']
    assert len(result.split()) == 3
    assert result.split()[0].isdigit()

    locale = 'ja-jp'
    a = Address(locale)
    result = a.address()


# Generated at 2022-06-12 01:27:28.640711
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for address() method of Address."""
    a = Address('ar')
    assert a.address() == 'شارع حقيبة القمار (1203), حي الشعران'



# Generated at 2022-06-12 01:27:30.373355
# Unit test for method address of class Address
def test_Address_address():
    address = Address("en")
    assert address.address() == '187 Fritsch Locks Suite 438'


# Generated at 2022-06-12 01:27:30.870737
# Unit test for method address of class Address
def test_Address_address():
    Address().address()

# Generated at 2022-06-12 01:27:34.526415
# Unit test for method address of class Address
def test_Address_address():
    """Test address method."""
    data = []
    address = Address('en')
    for i in range(10):
        data.append(address.address())

    print(data)

# Generated at 2022-06-12 01:27:42.657255
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for _ in range(10):
        # print(address.address())
        assert isinstance(address.address(), str)


# Generated at 2022-06-12 01:27:52.251776
# Unit test for method address of class Address
def test_Address_address():
    a = Address(seed='abc')
    assert a.address() == '120500, Западный бульвар, 26с6'
    assert a.address() == '13000, Boulevard du Dauphiné, 6'
    assert a.address() == '261, 小田切通, 新宿区'
    assert a.address() == '47, 小田切通, 港区'
    assert a.address() == '1600, Чехова улица'
    assert a.address() == '25, Малаховский переулок'

# Generated at 2022-06-12 01:27:54.140589
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    street = a.address()
    print(street)
    assert street is not None
    assert type(street) == str


# Generated at 2022-06-12 01:27:55.974093
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    import mimesis
    address = mimesis.Address()
    assert address.address() != address.address()


# Generated at 2022-06-12 01:28:06.951909
# Unit test for method address of class Address
def test_Address_address():
    import unittest
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    class AddressTestCase(unittest.TestCase):
        def setUp(self):
            self.address = Address(locale=Locale.EN)

        def test_address(self):
            result = self.address.address()
            self.assertTrue(
                isinstance(result, str),
                msg='Should be an instance of str.',
            )
            self.assertTrue(
                len(result) > 0,
                msg='Length of the string should be greater than zero.',
            )

    unittest.main()

# Generated at 2022-06-12 01:28:10.137683
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    input_value = address.address()
    if input_value in address._data['address_fmt']:
        print(input_value)
        raise Exception("The Address address method returns null value!")


# Generated at 2022-06-12 01:28:12.830715
# Unit test for method address of class Address
def test_Address_address():
    for i in range(10):
        adr = Address(i)
        print(adr.address())
        print(adr.address())
        print(adr.address())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:28:14.160726
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    assert ad()


# Generated at 2022-06-12 01:28:18.309674
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('pt')

    for _ in range(20):
        c = provider.address()
        print(c)
        #assert c


# Generated at 2022-06-12 01:28:21.168607
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address

    assert Address().address() != ''

if __name__ == "__main__":
    test_Address_address()

# Generated at 2022-06-12 01:28:31.347423
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) > 2
    assert len(Address().address()) == 8


# Generated at 2022-06-12 01:28:34.021088
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    addr = address.address()
    assert isinstance(addr, str)
    assert len(addr) > 0


# Generated at 2022-06-12 01:28:36.320526
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    x = a.address()
    print(x)


# Generated at 2022-06-12 01:28:39.253294
# Unit test for method address of class Address
def test_Address_address():
    """test_Address_address"""
    from mimesis.providers.address import Address
    from mimesis.enums import Locale
    address = Address(Locale.CHINESE)
    assert address.address()

# Generated at 2022-06-12 01:28:40.338304
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-12 01:28:50.604907
# Unit test for method address of class Address
def test_Address_address():
    class FakeAddress:
        def __init__(self):
            self.street_number = lambda: False
            self.street_name = lambda: False
            self.street_suffix = lambda: False

    address = Address(FakeAddress())
    # Use the format string to get the correct method name
    fmt = address._data['address_fmt']
    # This regex should match all method names
    regex = r'\b(\w*?)\b'
    # Get a list of method names
    methods = re.findall(regex, fmt)
    # [street_name, street_number]
    # [street_name, street_number, street_suffix]
    for method in methods:
        assert hasattr(address, method)

# Generated at 2022-06-12 01:28:52.680884
# Unit test for method address of class Address
def test_Address_address():
    # [area code]-[exchange code]-[line number]
    print(Address().address())
    print(Address().address())


# Generated at 2022-06-12 01:28:53.806122
# Unit test for method address of class Address
def test_Address_address():
    for i in range(0,5):
        print(Address.address())

# Generated at 2022-06-12 01:28:56.323818
# Unit test for method address of class Address
def test_Address_address():
    """Test method address() of class Address."""
    addr = Address()
    # this assertion is known to be wrong
    assert addr.address() == "595 West 15th Street"


# Generated at 2022-06-12 01:28:59.410509
# Unit test for method address of class Address
def test_Address_address():
    """Address().address() should return a full address string as an address
    (e.g. 1600 Pennsylvania Avenue, Washington, DC)

    """
    check_length = lambda x: len(x.split(',')) == 3

    if __debug__:
        assert check_length(Address().address())

# Generated at 2022-06-12 01:29:08.861082
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-12 01:29:10.949823
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('en')
    addr = provider.address()
    assert type(addr) == str


# Generated at 2022-06-12 01:29:12.584261
# Unit test for method address of class Address
def test_Address_address():
    address = Address("ru_RU")
    assert isinstance(address.address(), str)



# Generated at 2022-06-12 01:29:15.341151
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    assert type(address) is str
    assert address
    print('address = ' + address)


# Generated at 2022-06-12 01:29:18.410199
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    full_address = address.address()
    assert full_address is not None
    assert isinstance(full_address, str)
    assert len(full_address) > 0

test_Address_address()


# Generated at 2022-06-12 01:29:21.335251
# Unit test for method address of class Address
def test_Address_address():
    locale = 'en-US'
    provider = Address(locale)
    address = provider.address()
    assert address is not None
    assert address is not []
    assert address is not ()
    assert address is not {}


# Generated at 2022-06-12 01:29:25.043389
# Unit test for method address of class Address
def test_Address_address():
    """Test routine for Address.address"""

    # if sys.version_info.major == 2:
    #     return

    from mimesis.providers.address import Address
    from mimesis.enums import Country

    a = Address()
    a.set_locale(Country.RUSSIA)

    for i in range(100):
        assert a.address()


# Generated at 2022-06-12 01:29:35.018190
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import CanadaSpecProvider
    adr = Address()
    # Germany
    assert adr.address() == 'Gartenstr. 65'
    assert adr.street_name() == 'Gartenstr.'
    assert adr.street_suffix() == 'Gasse'
    assert adr.street_number() == '65'
    assert adr.state() == 'BY'
    assert adr.region() == 'BY'
    assert adr.province() == 'BY'
    assert adr.federal_subject() == 'BY'
    assert adr.prefecture() == 'BY'
    assert adr.postal_code() == '02763'
    assert adr.zip_code() == '02763'
    assert adr.country() == 'Germany'

    # Czechia


# Generated at 2022-06-12 01:29:37.060037
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    print(adr.address())

# Generated at 2022-06-12 01:29:46.765497
# Unit test for method address of class Address
def test_Address_address():
    from .abstract import BaseTest
    from .address import Address
    from .enums import CountryCode

    class TestAddress(BaseTest):

        def setUp(self, *args, **kwargs) -> None:
            super().setUp(*args, **kwargs)
            self.data = Address('en')

        def test_address(self):
            addr = self.data.address()
            self.assertTrue(len(addr.split()) > 2)

        def test_address_with_shortened_fmt(self):
            a = Address('ja')
            addr = a.address()
            self.assertTrue(len(addr.split()) > 1)

    class TestEffectiveAddress(BaseTest):
        def setUp(self) -> None:
            self.data = Address(locale='en')


# Generated at 2022-06-12 01:30:04.840172
# Unit test for method address of class Address
def test_Address_address():
    """Tests the functionality of the address method."""
    address_1 = Address()
    result_1 = address_1.address()
    result_2 = address_1.address()
    result_3 = address_1.address()
    assert result_1 != result_2 != result_3


# Generated at 2022-06-12 01:30:07.683761
# Unit test for method address of class Address
def test_Address_address():
    # setup
    a = Address(locale='en')
    output = a.address()
    # verify
    assert isinstance(output, str)

# Generated at 2022-06-12 01:30:10.715664
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    res1 = address_obj.address()
    assert any([True for e in res1 if e == ' '])


# Generated at 2022-06-12 01:30:13.035683
# Unit test for method address of class Address
def test_Address_address():
    """Test for Address address"""
    address = Address('cs')
    print(address.address())


# Generated at 2022-06-12 01:30:16.094248
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr1 = address.address()
    assert isinstance(addr1, str)
    addr2 = address.address()
    assert isinstance(addr2, str)
    assert addr1 != addr2


# Generated at 2022-06-12 01:30:17.993736
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) != 0


# Generated at 2022-06-12 01:30:21.313432
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='nl')
    assert len(adr.address()) >= 1
    assert len(adr.address().split(' ')) >= 3


# Generated at 2022-06-12 01:30:28.428759
# Unit test for method address of class Address
def test_Address_address():
    obj = Address('en')
    address_1 = obj.address()
    assert address_1 == '1038 S. Feltner Dr.'
    address_2 = obj.address()
    assert address_2 == '2731 Luciano Bridge'
    address_3 = obj.address()
    assert address_3 == '91317 Brett Dale'
    address_4 = obj.address()
    assert address_4 == '7731 Schumm Spur'
    address_5 = obj.address()
    assert address_5 == '1704 Green Harbors'


# Generated at 2022-06-12 01:30:29.683162
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != "" and Address().address() is not None


# Generated at 2022-06-12 01:30:30.914021
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    result = addr.address()
    assert result is not None

# Generated at 2022-06-12 01:30:48.419872
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import AddressFormats

    a1 = Address()
    address = a1.address()
    expect_address_formats = [
        AddressFormats.SIMPLE,
        AddressFormats.SIMPLE_EXTENDED,
        AddressFormats.EXTENDED
    ]

    assert address is not None
    assert address != ''
    assert a1.address_formats.value in expect_address_formats

# Generated at 2022-06-12 01:30:50.215853
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    result = addr.address()
    assert type(result) == str
    assert len(result.split()) > 0

# Generated at 2022-06-12 01:30:58.527881
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    print(addr.address())  # 16984 Rue des Tanneurs

    addr = Address('de')
    print(addr.address())  # Wimmerstraße 46, 01984 Mainz

    addr = Address('ru')
    print(addr.address())  # Переулок Советский, 58, Комсомольск на Амуре, Хабаровский край, 677000



# Generated at 2022-06-12 01:31:09.832862
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    start_characters = ['ул.', 'вул.', 'просп.', 'бульв.']
    street_name_rus = ''
    street_name_ukr = ''
    address_rus = ''
    address_ukr = ''
    
    if 'ru' in a.locale:
        start_character = a.random.choice(start_characters)
        address_rus = ''.join([start_character, ' ', a.street_name(), ' ', a.street_number()])
        print(address_rus)
    elif 'uk' in a.locale:
        start_character = a.random.choice(start_characters)

# Generated at 2022-06-12 01:31:13.149645
# Unit test for method address of class Address
def test_Address_address():
    # Arrange
    a = Address()
    b = Address()
    # Act
    resultA = a.address()
    resultB = b.address()
    # Assert
    assert resultA != resultB
    print(resultA)
    print(resultB)


# Generated at 2022-06-12 01:31:16.288482
# Unit test for method address of class Address
def test_Address_address():
    f = Address()
    data = f.address()
    assert not isinstance(data, int)
    assert data is not None
    assert data is not ''
    assert isinstance(data, str)


# Generated at 2022-06-12 01:31:18.953654
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    str1 = address.address()
    result = len(str1)
    print(str1)
    assert result > 10


# Generated at 2022-06-12 01:31:20.484890
# Unit test for method address of class Address
def test_Address_address():
    # Arrange
    adr = Address()

    # Assert
    assert isinstance(adr.address(), str)


# Generated at 2022-06-12 01:31:25.927265
# Unit test for method address of class Address
def test_Address_address():
    ap = Address()
    assert int(ap.street_number()[0]) in range(1, 14)
    assert ap.street_name() in ap._data['street']['name']
    assert ap.street_suffix() in ap._data['street']['suffix']
    assert len(ap.address().split()) >= 3


# Generated at 2022-06-12 01:31:29.983517
# Unit test for method address of class Address
def test_Address_address():
    # Use the class Address
    obj = Address()
    # Calling the method address of class Address
    address = obj.address()
    assert address == "541 Rue des Chartreux"
        

# Generated at 2022-06-12 01:31:47.060177
# Unit test for method address of class Address
def test_Address_address():
    """Test Address Address function."""
    address = Address(locale='en')
    assert address.address() in [
        '{st_num} {st_name} {st_sfx}',
        '{st_num} {st_sfx} {st_name}',
        '{st_num} {st_name}',
        '{st_num} {st_sfx}',
    ]

# Test for method country of class Address

# Generated at 2022-06-12 01:31:49.805780
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    obj = Address('en')
    response = obj.address()
    assert type(response) == str
    assert len(response) >= 1


# Generated at 2022-06-12 01:31:59.990156
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    lst = (
        provider.address(),
        provider.address(),
        provider.address(),
        provider.address(),
    )
    valid = all(lst)
    assert valid == True



# Generated at 2022-06-12 01:32:01.203248
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    assert ad.address() == '6408 E Amethyst Circle'


# Generated at 2022-06-12 01:32:05.549747
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == 'N 1st St #95950' or a.address() == 'Calle de la Mancha, 11' or a.address() == '42709 Calle de la Mancha, 11'



# Generated at 2022-06-12 01:32:06.655049
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    print(obj.address())


# Generated at 2022-06-12 01:32:12.026586
# Unit test for method address of class Address
def test_Address_address():
    """Method for testing method address of class Address.

    Parameters:
        None
    Returns:
        None
    """
    # Getting an object of the class
    address = Address("en")
    # Getting an address by calling the method address()
    result = address.address()
    print("Generated address = ", result)
    # Checking the type of the result
    assert isinstance(result, str)


# Generated at 2022-06-12 01:32:13.684290
# Unit test for method address of class Address
def test_Address_address():
    # GIVEN
    a = Address()
    # WHEN
    print(a.address())
    # THEN no exceptions


# Generated at 2022-06-12 01:32:17.228812
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import DataPart
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode

    a = Address()
    b = Address(country_code=CountryCode.A2, data_part=DataPart.FULL)

    assert a.address() != b.address()
    assert a.address() != a.address()
    assert b.address() != b.address()

# Generated at 2022-06-12 01:32:19.636498
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert (len(address.address()) > 5)
    assert (address.address() != None)


# Generated at 2022-06-12 01:32:41.586522
# Unit test for method address of class Address
def test_Address_address():
    bp = Address()
    assert bp.address()


# Generated at 2022-06-12 01:32:44.004453
# Unit test for method address of class Address
def test_Address_address():
    # Method address test 
    for i in range(10):
        print(Address().address())

# Generated at 2022-06-12 01:32:45.079155
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-12 01:32:49.768453
# Unit test for method address of class Address
def test_Address_address():
    address = Address('ru')
    assert address.address() in [
        '44, 43-я линия В.О.',
        'г. Москва, м. Речной вокзал, парковая улица, д. 12',
        'Гари Политэ',
        'Вастон Стрит 22',
    ]


# Generated at 2022-06-12 01:32:51.112575
# Unit test for method address of class Address
def test_Address_address():
    m = Address()
    assert isinstance(m.address(), str)

# Generated at 2022-06-12 01:32:52.190406
# Unit test for method address of class Address
def test_Address_address():
    t = Address()
    print(t.address())


# Generated at 2022-06-12 01:32:53.220324
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    print(adr())

# Generated at 2022-06-12 01:32:56.698237
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != Address().address()
    assert Address().address() != ''
    assert Address().address() != ' '
    assert Address().address() != None
    return

# Generated at 2022-06-12 01:32:58.506196
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    print(Address(Locale.RU).address())


# Generated at 2022-06-12 01:33:09.611753
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.localization import get_territory_by_code
    from mimesis.generators.address import Address

    en = Address('en')
    assert en.address() != ''
    assert isinstance(en.address(), str)

    de = Address('de')
    assert de.address() != ''
    assert isinstance(de.address(), str)

    ru = Address('ru')
    assert ru.address() != ''
    assert isinstance(ru.address(), str)

    # Test is country within the territory
    mk = Address('mk')
    territory = get_territory_by_code('mk')
    assert mk.country() in territory.countries
    assert isinstance(mk.country(), str)

    # Test is code of country belongs to territory


# Generated at 2022-06-12 01:33:35.146683
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    l = Locale.from_str("en-us")
    a = Address(l)
    print(a.address())


# Generated at 2022-06-12 01:33:36.902914
# Unit test for method address of class Address
def test_Address_address():
    # Given
    provider = Address()

    # When
    result = provider.address()

    # Then
    assert result == "13 Jubilee Avenue"



# Generated at 2022-06-12 01:33:39.485377
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    street_name = a.street_name()
    street_suffix = a.street_suffix()
    street_number = a.street_number()
    assert a.address() == f'{street_number} {street_name}{street_suffix}'

# Generated at 2022-06-12 01:33:47.248233
# Unit test for method address of class Address
def test_Address_address():
    """Test Address() method address().
    """
    from mimesis.enums import Locale
    provider = Address(locale=Locale.EN)

    expected_result = '{st_num} {st_name} {st_sfx}'
    result = provider.address()
    assert isinstance(result, str)
    assert result != expected_result
    assert result != provider.address()

    expected_result = '{st_num} {st_name}'
    result = provider.address()
    assert isinstance(result, str)
    assert result != expected_result
    assert result != provider.address()


# Generated at 2022-06-12 01:33:49.916238
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    from mimesis.enums import Country
    addr = Address(Country.VIETNAM)
    print(addr.address())

# Generated at 2022-06-12 01:33:50.731734
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address().startswith('6U')

# Generated at 2022-06-12 01:33:52.565537
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    d = a.address()
    assert d is not None

# Generated at 2022-06-12 01:33:54.207699
# Unit test for method address of class Address
def test_Address_address():
    cls = Address()
    result = cls.address()
    assert result is not None
    

# Generated at 2022-06-12 01:33:55.201710
# Unit test for method address of class Address
def test_Address_address():
    address = Address
    result = address.address
    assert result is not None

# Generated at 2022-06-12 01:34:00.709617
# Unit test for method address of class Address
def test_Address_address():
    """Case 1: Test used function."""
    try:
        addr = Address(seed=123)
        state = addr.address()
        expected = "1512 W. John St."
        assert state == expected
    except:
        print ('Fail')
        print ('expected:', expected)
        print ('state:', state)


# Generated at 2022-06-12 01:34:26.666016
# Unit test for method address of class Address
def test_Address_address():
    # Unit test for method address of class Address
    address = Address()
    assert isinstance(address.address(), str)

# Generated at 2022-06-12 01:34:35.945552
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import DataField

    provider = Address('en')
    result = provider.address()
    assert result

    provider = Address('en')
    result = provider.address(data_fields=[DataField.STREET_ADDRESS])
    assert result

    provider = Address('en')
    result = provider.address(data_fields=[DataField.STREET_ADDRESS],
                              hide_fields=['street_name'])
    assert result

    provider = Address('zh')
    result = provider.address()
    assert result

    provider = Address('zh')
    result = provider.address(data_fields=[DataField.STREET_ADDRESS])
    assert result

    provider = Address('zh')

# Generated at 2022-06-12 01:34:37.105987
# Unit test for method address of class Address
def test_Address_address():
    address = Address("zh")
    print (address.address())



# Generated at 2022-06-12 01:34:46.653903
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.address import Address
    from mimesis.types import AnyIterator
    ad = Address(Locale.RU)

    assert(isinstance(ad.address(), str))

    # the current locale is not supported by the format
    try:
        Address(Locale.RO).address()
    except NonEnumerableError:
        pass

    # the current locale is not supported by the format
    try:
        Address(Locale.UK).address()
    except NonEnumerableError:
        pass

    # generator of address
    gen = AnyIterator(ad.address)
    assert(isinstance(next(gen), str))

