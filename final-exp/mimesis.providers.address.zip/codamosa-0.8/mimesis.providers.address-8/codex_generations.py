

# Generated at 2022-06-12 01:24:58.899775
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    a = Address('zh')
    assert a.address() == '钟楼街, 中华人民共和国, 北京市, 东城区, 1, 100739'
    assert a.address() == '地安门外大街, 中华人民共和国, 北京市, 东城区, 1, 100006'
    assert a.address() == '三里屯街, 中华人民共和国, 北京市, 朝阳区, 1, 100007'

# Generated at 2022-06-12 01:25:00.611071
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())


# Generated at 2022-06-12 01:25:12.900665
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.localization import DEFAULT_LOCALE

    adr = Address()

    result1 = adr.address()
    result2 = adr.address()

    assert len(result1) > 0
    assert type(result1) is str

    assert result1 != result2

    assert adr._data['address_fmt'] == adr._data['address_fmt']

    adr._locale = Locale.TEST
    adr._datafile = 'address_test.json'
    adr._pull(adr._datafile)

    result3 = adr.address()

    assert result1 != result3

    adr._locale = DEFAULT_LOCALE
    adr._pull(adr._datafile)



# Generated at 2022-06-12 01:25:14.554746
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()
    

# Generated at 2022-06-12 01:25:17.003916
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    s = address.address()
    print(s)


# Generated at 2022-06-12 01:25:18.625586
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    address = adr.address()
    print("address: ", address)


# Generated at 2022-06-12 01:25:28.316897
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    ad = Address(Locale.EN)
    ad.address() == '4 N. Charles St.'
    ad.address() == '1813 Albert Track Suite 579'
    ad.address() == '4150 Clement Throughway Suite 671'
    ad.address() == '73594 Susan Walks Suite 654A'
    ad.address() == '66391 Sarah Key'
    ad.address() == '16152 Walters Courts'
    ad.address() == '65587 Ola Circles Suite 432'
    ad.address() == '31467 Sarah Plazas'
    ad.address() == '88818 Weldon Burgs Suite 830'
    ad.address() == '2262 Kenneth Mission'


# Generated at 2022-06-12 01:25:31.594358
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    assert ad.address() == 'проспект Ильченко, 21'


# Generated at 2022-06-12 01:25:32.850746
# Unit test for method address of class Address
def test_Address_address():
    _c = Address()
    assert _c.address() != None


# Generated at 2022-06-12 01:25:34.919612
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(Locale.RU)
    address.address()
    address.address()
    address.address()



# Generated at 2022-06-12 01:25:41.634621
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-12 01:25:47.568770
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address, testing all possible locales.
    """
    fake = Address(locale='en')
    a = fake.address()
    assert a is not None
    assert isinstance(a, str)
    assert len(a) >= 5

    fake = Address(locale='ru')
    a = fake.address()
    assert a is not None
    assert isinstance(a, str)
    assert len(a) >= 5

    fake = Address(locale='ja')
    a = fake.address()
    assert a is not None
    assert isinstance(a, str)
    assert len(a) >= 5


# Generated at 2022-06-12 01:25:48.680581
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())

# Generated at 2022-06-12 01:25:51.512679
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    import pdb;pdb.set_trace()
    assert a.address()
    assert a.address()
    assert a.address()

# Generated at 2022-06-12 01:25:53.333503
# Unit test for method address of class Address
def test_Address_address():
    print("************ address ************")
    a = Address()
    print("address:", a.address())


# Generated at 2022-06-12 01:25:58.076298
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()

    # a = obj.address()
    # print(a)

    # Default fmt
    # '{st_num} {st_name} {st_sfx}'

    # fmt = '{st_num} {st_name} {st_sfx}, {city}, {state} {postal_code}'

    # obj.set_locale('ja')
    # fmt = '{city}-{0:02d}-{1:03d}'

    # a = obj.address(fmt=fmt)
    # print(a)

    # '{st_num} {st_name} {st_sfx}'
    # obj.set_locale('en')

    # obj.set_locale('fr')
    # obj.set_locale('de')
   

# Generated at 2022-06-12 01:26:08.896491
# Unit test for method address of class Address
def test_Address_address():
    """Test address function."""
    a = Address()
    addr = a.address()

# Generated at 2022-06-12 01:26:11.592721
# Unit test for method address of class Address
def test_Address_address():
    a = Address(seed=100)
    assert (a.address() == '346 Rippin Parkway')



# Generated at 2022-06-12 01:26:13.350548
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-12 01:26:20.794549
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='en')
    assert adr.address() == "4660 Ridgeview Drive"
    adr = Address(locale='fr')
    assert adr.address() == "37 rue Jean-Baptiste-Puvis de Chavannes"
    adr = Address(locale='ru')
    assert adr.address() == "Ул. Валовая, д. 160"
    adr = Address(locale='ja')
    assert adr.address() == "森博司郎５２-４-４"


# Generated at 2022-06-12 01:26:29.218978
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()


# Generated at 2022-06-12 01:26:40.516339
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode

    address = Address(locale='de')
    country = address.country_code(fmt=CountryCode.A2)
    assert country == 'DE'

    assert address.address() == 'Unter den Linden 6b'
    assert address.postal_code() == '10437'
    assert address.region() == 'SH'
    assert address.region(abbr=True) == 'SH'
    assert address.state() == 'Saarland'
    assert address.state(abbr=True) == 'SL'
    assert address.province() == 'Saarland'
    assert address.province(abbr=True) == 'SL'
    assert address.federal_subject() == 'Saarland'
    assert address.federal_subject(abbr=True)

# Generated at 2022-06-12 01:26:46.683372
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale en
    address_en = Address(locale='en')
    assert_method = 'address'
    assert_result = '212 E. Broadway'
    assert_result_alt = '122 E. Broadway'
    assert getattr(address_en, assert_method)() in [assert_result, assert_result_alt]
    assert "$" not in getattr(address_en, assert_method)()
    assert len(getattr(address_en, assert_method)()) > 3
    assert len(getattr(address_en, assert_method)()) < 30
    assert isinstance(getattr(address_en, assert_method)(), str)


# Generated at 2022-06-12 01:26:48.427965
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    ad = Address()
    assert isinstance(ad.address(), str)


# Generated at 2022-06-12 01:26:49.974704
# Unit test for method address of class Address
def test_Address_address():
    instance1 = Address()
    result = instance1.address()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:26:52.210959
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for the Address.address method."""
    address_gen = Address()
    res = address_gen.address()
    assert type(res) is str


# Generated at 2022-06-12 01:26:58.122678
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import DataPartition
    from mimesis.builtins import USABuiltins

    a = Address()
    assert a.address() == '35 Buhl Plaza, Apt. 932, Glendale, CA 93272'
    assert a.address(locale='ru') == 'пер. Ковалевского, д. 20/2, кв/оф 103'

    a = Address(partition=DataPartition.BUILTINS, builtins=USABuiltins())
    assert a.address() == '23539 Wida Terrace, Suite 066, New Haven, MN 51284'



# Generated at 2022-06-12 01:27:01.526359
# Unit test for method address of class Address
def test_Address_address():
    """Test for method :meth:`Address.address()`."""
    adr = Address(locale='en')
    result = adr.address()
    # Simple check
    assert ' ' in result
    # Test with different locale
    assert len(Address(locale='fr').address()) > 0



# Generated at 2022-06-12 01:27:02.863217
# Unit test for method address of class Address
def test_Address_address():
    Address().address()

# Generated at 2022-06-12 01:27:12.229176
# Unit test for method address of class Address
def test_Address_address():
    '''
        Unit test for method address of class Address
    '''
    addr = Address(seed=4545)
    print(addr.address())
    print(addr.address())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())
    print(addr.city())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:27:31.577271
# Unit test for method address of class Address
def test_Address_address():
    """Test random address()."""
    import random
    import string


# Generated at 2022-06-12 01:27:33.109476
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    print(provider.address())

# Generated at 2022-06-12 01:27:34.978239
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)
    assert len(a.address().split()) > 1


# Generated at 2022-06-12 01:27:37.713068
# Unit test for method address of class Address
def test_Address_address():
    assert Address('ru').address() == 'Светлая, 14'
    assert Address('en').address() == '3384 Green Street'
    assert Address('de').address() == 'Heilige Lilie, 64'

# Generated at 2022-06-12 01:27:39.452592
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    address = ad.address()
    assert isinstance(address, str)
    assert len(address) > 5


# Generated at 2022-06-12 01:27:43.499206
# Unit test for method address of class Address
def test_Address_address():
    for i in range(100):
        x = Address(seed=i).address()
        assert x is not None
        assert type(x) == str


# Generated at 2022-06-12 01:27:52.903434
# Unit test for method address of class Address
def test_Address_address():
    syn_data = ['Mainstreet Nr. 13']
    syn_data += ['Block 45, Mainstreet']
    syn_data += ['Block 45, Mainstreet']
    syn_data += ['Mainstreet, Block 45']
    syn_data += ['Mainstreet, Block 45']
    syn_data += ['Mainstreet Nr. 13']
    syn_data += ['Mainstreet Nr. 13']
    syn_data += ['Mainstreet Nr. 13']
    syn_data += ['Mainstreet Nr. 13']
    syn_data += ['Mainstreet Nr. 13']
    syn_data += ['Mainstreet Nr. 13']
    syn_data += ['Mainstreet Nr. 13']
    syn_data += ['Mainstreet 13']
    syn_data += ['Mainstreet 13']
    syn_data += ['Mainstreet 13']
    syn

# Generated at 2022-06-12 01:27:54.622071
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    arr = address.address() # arr为str类型
    print(arr)
    print(type(arr))


# Generated at 2022-06-12 01:27:58.592557
# Unit test for method address of class Address
def test_Address_address():
    """Test of Address.address().

    Verify if the method address of class Address return the value is
    str or not.
    """
    addr = Address('en')
    val = addr.address()
    t_type = isinstance(val, str)
    assert t_type



# Generated at 2022-06-12 01:28:00.887924
# Unit test for method address of class Address
def test_Address_address():
    address = Address(language='en')
    assert address.address() == address.address() #check




# Generated at 2022-06-12 01:28:17.341804
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale = 'hu')
    address_data = address.address()
    assert address_data is not None


# Generated at 2022-06-12 01:28:20.517409
# Unit test for method address of class Address
def test_Address_address():
    """
    Unit test for method address of class Address
    """
    item = Address(seed=1234567890)
    result = item.address()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:28:22.398574
# Unit test for method address of class Address
def test_Address_address():
    """Check method address."""
    result = Address().address()
    assert result

# Generated at 2022-06-12 01:28:24.319970
# Unit test for method address of class Address
def test_Address_address():
    ad = Address(locale='en')
    assert ad.address() != ''


# Generated at 2022-06-12 01:28:25.811734
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    assert a.address()


# Generated at 2022-06-12 01:28:26.602302
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-12 01:28:28.969190
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    a = Address()
    assert isinstance(a.address(), str), "address() should return a string"


# Generated at 2022-06-12 01:28:30.608595
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    print(address.address())



# Generated at 2022-06-12 01:28:34.181811
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()
    print(address.address())

# Generated at 2022-06-12 01:28:42.647170
# Unit test for method address of class Address
def test_Address_address():
    from pattern.pattern import Pattern
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    pattern = Pattern(locale='ru')
    address = Address(locale='ru')

    st_num = pattern('<n:[0-9]{1,4}>')
    st_name = pattern('<[A-Z][a-z]+>')
    st_sfx = pattern('<[A-Z][a-z]+>')
    pc = pattern('<n:[0-9]{6}>')

    assert address.address() == f'{st_num} {st_name} {st_sfx} {pc}'
    assert address.address() != f'{st_name} {st_sfx} {pc}'
    assert address.address() != f

# Generated at 2022-06-12 01:28:58.356889
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    address_value = address.address()
    assert (isinstance(address_value, str))


# Generated at 2022-06-12 01:29:08.376507
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Locale

    ad = Address(locale=Locale.RU)
    print(ad.address())

    print(ad.address())

    print(ad.address())

    print(ad.address())

    ad = Address(locale=Locale.EN)
    print(ad.address())

    print(ad.address())

    print(ad.address())

    print(ad.address())

    print(ad.address())

    print(ad.address())

    print(ad.address())

    print(ad.address())

    print(ad.address())

    ad = Address(locale=Locale.KO)
    print(ad.address())

    print(ad.address())

    print(ad.address())


# Generated at 2022-06-12 01:29:10.180714
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    print(address.address())


# Generated at 2022-06-12 01:29:12.172317
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Location
    a = Address(Location.RUSSIA)
    print(a.address())


# Generated at 2022-06-12 01:29:13.888215
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-12 01:29:16.145671
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    a = Address(Locale.CH)
    assert a.address() in a._data['address_fmt']

# Generated at 2022-06-12 01:29:17.243200
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())

# Generated at 2022-06-12 01:29:20.670906
# Unit test for method address of class Address
def test_Address_address():
    # This is for test function address
    address = Address()
    result = address.address()
    # This is for test the type of result
    assert isinstance(result, str) is True
    # This is for test the length of result
    assert len(result) >= 5


# Generated at 2022-06-12 01:29:22.307561
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""

    assert Address().address() != Address().address()


test_Address_address()

# Generated at 2022-06-12 01:29:24.221829
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import Address
    adr=Address()
    #print(adr.address())
    assert bool(adr.address())


# Generated at 2022-06-12 01:29:58.977121
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    a = address.address()
    assert a.find(' ') > 0
    assert '.' not in a
    assert ',' not in a
    assert '-' not in a


# Generated at 2022-06-12 01:30:10.965297
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    # Country: Japan
    assert adr.address() == '神奈川県横浜市旭区下小田原１８７－３３'
    # Country: China
    adr.locale = 'zh_cn'
    assert adr.address() == '北京市海淀区清华大学玉泉路以北、花园路以西'
    # Country: Germany
    adr.locale = 'de'
    assert adr.address() == 'Fischstrasse 167'
    # Country: Russia
    adr.locale = 'ru'
    assert adr.address

# Generated at 2022-06-12 01:30:12.913644
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-12 01:30:14.923785
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address('ru')
    assert isinstance(address.address(), str)


# Generated at 2022-06-12 01:30:16.244750
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    print(address)

# Generated at 2022-06-12 01:30:19.597280
# Unit test for method address of class Address
def test_Address_address():
    """Test generating address."""
    address = Address('en')
    generated_address = address.address()
    assert generated_address == '14 Umerov Stream'


# Generated at 2022-06-12 01:30:29.193467
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    class TestAddress:

        def test_address_en(self):
            address = Address(Locale.EN)
            result = address.address()
            assert result

        def test_address_ru(self):
            address = Address(Locale.RU)
            result = address.address()
            assert result

        def test_address_jp(self):
            address = Address(Locale.JA)
            result = address.address()
            assert result

        def test_address_zh(self):
            address = Address(Locale.ZH)
            result = address.address()
            assert result

    # Run class tests
    test_addr = TestAddress()
    test_addr.test_address_en()
    test_

# Generated at 2022-06-12 01:30:36.694068
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address.

    This method is tested by using pytest.
    """
    from mimesis.enums import Locale
    from mimesis.localization import Localization
    from mimesis.providers.address import Address
    from pytest import fixture

    @fixture
    def a():
        return Address(Localization(Locale.EN))

    def test_address(a):
        assert a.address()
        assert isinstance(a.address(), str)

# Generated at 2022-06-12 01:30:39.095373
# Unit test for method address of class Address
def test_Address_address():
    # GIVEN
    provider = Address()

    # WHEN
    result = provider.address()

    # THEN
    assert len(result) >= 7
    assert result.count(' ') >= 2


# Generated at 2022-06-12 01:30:44.999286
# Unit test for method address of class Address
def test_Address_address():
    test_faker = Address()
    assert isinstance(test_faker.address(), str)
    assert len(test_faker.address()) > 5
    #test_faker = Address('ru')
    #print(test_faker.address_en())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:32:07.065469
# Unit test for method address of class Address
def test_Address_address():
    import hypothesis
    import hypothesis.strategies
    import mimesis

    @hypothesis.given(value=hypothesis.strategies.text())
    def test_func(value):
        provider = mimesis.Address(value)
        address = provider.address()
        assert provider._data['address_fmt'] in address

    test_func()


# Generated at 2022-06-12 01:32:10.888952
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    adr = Address(Locale.ROOT)
    res = adr.address()
    assert isinstance(res, str)
    assert 0 < len(res) <= 100


# Generated at 2022-06-12 01:32:17.540394
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    nl_address = Address(locale='nl')
    en_address = Address(locale='en')
    ru_address = Address(locale='ru')

    # Dutch street suffixes
    suffixes = [
        'straat',
        'laan',
        'weg',
        'gedeelte',
        'boulevard',
        'singel',
        'brug',
        'wal',
    ]

    person = Person('nl')
    person.seed(1)


# Generated at 2022-06-12 01:32:21.370399
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    addr = Address(locale='zh')
    print(addr.address())

# Unit test
if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:32:24.556774
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert isinstance(address.address(), str)

# Generated at 2022-06-12 01:32:26.489946
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert len(result) != 0


# Generated at 2022-06-12 01:32:29.159466
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis import Address
    address = Address()
    add1 = address.address()
    add2 = address.address()
    assert ((add1 != add2) and (len(add1) >= 5) and (len(add2) >= 5))



# Generated at 2022-06-12 01:32:29.974350
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())


# Generated at 2022-06-12 01:32:34.528132
# Unit test for method address of class Address
def test_Address_address():
    address = Address(Mock())

    for i in range(10):
        st_num = address.street_number()
        st_name = address.street_name()
        st_sfx = address.street_suffix()
        result = address.address()
        full_address = f"{st_num} {st_name} {st_sfx}"
        assert result == full_address



# Generated at 2022-06-12 01:32:46.576743
# Unit test for method address of class Address
def test_Address_address():

    from mimesis import Address
    from mimesis.enums import CountryCode

    # Create a instance of class Address with german locale
    addr = Address('de')

    postal_code = addr.postal_code()
    city = addr.city()
    state = addr.state(True)

    print("Address 1")
    print("\tPostal Code: " + postal_code)
    print("\tCity: " + city)
    print("\tState: " + state)
    print("\tCountry: " + addr.country())

    print("\t---------------------------------")

    # Create a instance of class Address with russian locale
    addr = Address('ru')

    postal_code = addr.postal_code()
    city = addr.city()

    print("Address 2")