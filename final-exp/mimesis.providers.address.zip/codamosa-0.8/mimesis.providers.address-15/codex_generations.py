

# Generated at 2022-06-12 01:24:54.708700
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    assert isinstance(obj.address(), str)
    assert isinstance(obj.address(locale='ja'), str)


# Generated at 2022-06-12 01:24:58.366530
# Unit test for method address of class Address
def test_Address_address():
    # correct pattern
    assert re.match(r'([a-zA-Z]\s?\d{1,4}(\s|),\s(\w+\s?){1,7}?[a-zA-Z]+$)', Address().address())

# Generated at 2022-06-12 01:25:04.964562
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert len(list(set(address.street_number() for _ in range(100))))==10
    assert len(list(set(address.street_name() for _ in range(100))))==55
    assert len(list(set(address.street_suffix() for _ in range(100))))==13
    assert len(list(set(address.address() for _ in range(100))))==100

# Generated at 2022-06-12 01:25:06.559011
# Unit test for method address of class Address
def test_Address_address():
    assert ('-') not in Address().address()

# Generated at 2022-06-12 01:25:08.189220
# Unit test for method address of class Address
def test_Address_address():    
    address = Address('en')
    assert len(address.address().split()) == 5

# Generated at 2022-06-12 01:25:11.383593
# Unit test for method address of class Address
def test_Address_address():
    test_item = "address"
    for i in range(0,10):
        assert Address().address() != None
    print("Unit test for {} is successful.".format(test_item))


# Generated at 2022-06-12 01:25:14.505580
# Unit test for method address of class Address
def test_Address_address():
    """Test address."""
    a = Address()
    result = a.address()
    assert len(result.split())


# Generated at 2022-06-12 01:25:17.315096
# Unit test for method address of class Address
def test_Address_address():
    import mimesis.builtins
    a = mimesis.builtins.Address()
    print(a.address())



# Generated at 2022-06-12 01:25:18.951598
# Unit test for method address of class Address
def test_Address_address():
    a = Address("en")
    # Return random address
    assert(a.address())


# Generated at 2022-06-12 01:25:22.597686
# Unit test for method address of class Address
def test_Address_address():
    # test data
    region = 'en'
    print("Test method address of class Address for region:{}\n".format(
        region))

    obj = Address(region)
    result = obj.address()
    assert result
    print(result)



# Generated at 2022-06-12 01:25:27.407379
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-12 01:25:30.533785
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    actual = a.address()
    expected = '2200 W Elliott Rd, Tempe, AZ 85284'
    assert actual == expected


# Generated at 2022-06-12 01:25:32.350661
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='zh')
    address.address()
    assert address.address()


# Generated at 2022-06-12 01:25:43.397511
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.exceptions import NonEnumerableError

    A = Address().address()
    assert A is not None

    A = Address().address()
    assert isinstance(A, str)

    # Check exception in method _validate_enum()
    try:
        A = Address().country_code(fmt=1)
    except NonEnumerableError:
        pass
    assert A == CountryCode.A2

    A = Address().country_code(fmt=CountryCode.A3)
    assert A is not None

    A = Address().country_code(fmt=CountryCode.A2)
    assert A is not None

    A = Address().country_code(fmt=CountryCode.A3)
    assert A is not None


# Generated at 2022-06-12 01:25:44.059329
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ''

# Generated at 2022-06-12 01:25:46.814091
# Unit test for method address of class Address
def test_Address_address():
    result = Address('en').address()
    print(result)



# Generated at 2022-06-12 01:25:58.015621
# Unit test for method address of class Address

# Generated at 2022-06-12 01:26:00.343083
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('en')
    assert addr.address() == '123 Washington St'


# Generated at 2022-06-12 01:26:01.720969
# Unit test for method address of class Address
def test_Address_address():
    assert Address('en').address() != ''


# Generated at 2022-06-12 01:26:04.178965
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    address = addr.address()

    assert isinstance(address, str)
    assert address



# Generated at 2022-06-12 01:26:08.759496
# Unit test for method address of class Address
def test_Address_address():
    address = Address.address()
    assert isinstance(address, str) and len(address) > 0


# Generated at 2022-06-12 01:26:11.043926
# Unit test for method address of class Address
def test_Address_address():
    for _ in range(100):
        print(Address('ru').address())

# Generated at 2022-06-12 01:26:12.042960
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != None


# Generated at 2022-06-12 01:26:15.057012
# Unit test for method address of class Address
def test_Address_address():
    #t = Address('zh')
    t = Address('en')
    print(t.address())
    print(len(t.address()))


# Generated at 2022-06-12 01:26:18.118438
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    data = address.address()
    for name in data.split(" "):
        assert name.isalpha()
    assert address.address() is not None



# Generated at 2022-06-12 01:26:19.340240
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    assert (obj.address())

# Generated at 2022-06-12 01:26:21.281579
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import Address
    assert isinstance(Address.address(), str)


# Generated at 2022-06-12 01:26:22.286077
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    add.address()

# Generated at 2022-06-12 01:26:24.460400
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    result = a.address()
    assert result is not None
    assert isinstance(result,str)


# Generated at 2022-06-12 01:26:33.434298
# Unit test for method address of class Address
def test_Address_address():
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
    assert Address(seed=12).address() == '56720 Mccormick Branch'
   

# Generated at 2022-06-12 01:26:45.980180
# Unit test for method address of class Address
def test_Address_address():
    assert Address(seed=0).address() == '目黒区新宿7-1-99'
    assert Address(seed=1).address() == '297, New Hill Street'
    assert Address(seed=2).address() == 'Bethany, 5550 Lakewood Gardens'
    assert Address(seed=3).address() == 'Rue du Saint-Esprit, 44'
    assert Address(seed=4).address() == '新宿区上尾張3-4-5'
    assert Address(seed=5).address() == 'Avenida de Andalucía, 154'
    assert Address(seed=6).address() == 'Flat 3, Priory Gardens, DE23 4GA, Derby'

# Generated at 2022-06-12 01:26:51.209394
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    address = Address()
    assert isinstance(address.address(), str)
    assert isinstance(address.address(with_country=True), str)
    assert isinstance(address.address(with_locales=['nl', 'en']), str)
    assert isinstance(address.address(with_country=True, with_locales=['nl', 'en']), str)


# Generated at 2022-06-12 01:26:55.440049
# Unit test for method address of class Address
def test_Address_address():
    provider = Address(locale='zh')

    address = provider.address()
    assert address

    address = provider.address()
    assert address

    provider = Address(locale='en')

    address = provider.address()
    assert address

    address = provider.address()
    assert address

    provider = Address(locale='zh')
    address = provider.address()

    assert address

test_Address_address()

# Generated at 2022-06-12 01:26:56.580272
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert addr.address() is not None
    assert addr.address() != ''


# Generated at 2022-06-12 01:26:57.665174
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())


# Generated at 2022-06-12 01:26:58.968913
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address."""
    a = Address()
    assert isinstance(a.address(), str)


# Generated at 2022-06-12 01:27:00.225686
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr = address.address()
    assert isinstance(addr, str)



# Generated at 2022-06-12 01:27:02.087424
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='ru')
    x = a.address()
    assert isinstance(x, str)



# Generated at 2022-06-12 01:27:04.171317
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    add.address()

# Generated at 2022-06-12 01:27:15.220787
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = ('' +
         '3711 Hope Springs Drive\n' +
         '3711 Hope Springs Drive\n' +
         '3711 Hope Springs Drive\n')

# Generated at 2022-06-12 01:27:23.449154
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())

# test_Address_address()

# Generated at 2022-06-12 01:27:25.002634
# Unit test for method address of class Address
def test_Address_address():
    address = Address().address()
    assert isinstance(address, str)

# Generated at 2022-06-12 01:27:32.045443
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='zh')
    assert address.address() in [
        '1508 4th Ave # 5, New York, NY 10019',
        '895 6th Ave # 7, New York, NY 10001',
        '276 5th Ave, Brooklyn, NY 11215',
        '500 E 81st St, New York, NY 10075',
        '38 E 57th St, New York, NY 10022',
        '522 West 42nd Street, New York, NY 10036',
        '1828 Broadway, New York, NY 10023',
        '469 7th Ave # 2, New York, NY 10018',
        '300 E 42nd St, New York, NY 10017',
        '125 S 4th St, Brooklyn, NY 11211',
    ]

# Generated at 2022-06-12 01:27:34.323169
# Unit test for method address of class Address
def test_Address_address():
    """Test the functionality of the method address of class Address."""
    assert Address().address() == '49 rue Lamartine'


# Generated at 2022-06-12 01:27:41.288847
# Unit test for method address of class Address
def test_Address_address():
    # Ensure that locale-specific number formatting works
    address = Address(locale='de')
    assert address.address() == "15, Scheidpl.\n10115 Berlin"

    # Ensure that full address formats work
    address = Address(locale='en')
    assert address.address() == "1097 Jones Cir\nCumming, IA 50061-8484"

    # Ensure that shortened formats work
    address = Address(locale='ca')
    assert address.address() == "636, Prat de la Creu"

    # Ensure that locale-specific formatting works
    address = Address(locale='ja')
    assert address.address() == "静岡県沼津市宮前１丁目２−４０"

    # Ensure that

# Generated at 2022-06-12 01:27:44.189218
# Unit test for method address of class Address
def test_Address_address():
    address = Address("pt-BR")
    assert address.address() == "Rua Pedro Augusto, 310"


# Generated at 2022-06-12 01:27:46.123037
# Unit test for method address of class Address
def test_Address_address():
    survey = Address()
    result = survey.address()
    assert isinstance(result, str)
    assert result
    assert result.isalpha()

# Generated at 2022-06-12 01:27:49.476697
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for Address.address method."""
    address_obj = Address('es')
    data = address_obj.address()

    assert isinstance(data, str)
    assert len(data) >= 5


# Generated at 2022-06-12 01:27:50.233016
# Unit test for method address of class Address
def test_Address_address():
    a = Address("zh")
    print(a.address())

# Generated at 2022-06-12 01:27:52.140384
# Unit test for method address of class Address
def test_Address_address():
    dp = Address(locale='ru')
    address = dp.address()
    assert isinstance(address, str)


# Generated at 2022-06-12 01:28:02.866408
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('en')
    result = provider.address()

    assert any(result)


# Generated at 2022-06-12 01:28:03.972042
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print("address address: ", address.address())

# Generated at 2022-06-12 01:28:06.271131
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    result = provider.address()

    assert result is not None


# Generated at 2022-06-12 01:28:09.561910
# Unit test for method address of class Address
def test_Address_address():
    import pytest

    a = Address(locale='ja')
    assert type(a.address()) == str
    with pytest.raises(NotImplementedError):
        a.address()

# Generated at 2022-06-12 01:28:11.059107
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(locale='zh')
    print(addr.address())


# Generated at 2022-06-12 01:28:13.618942
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address(locale='zh_CN')
    x = address_obj.address()
    print(x)


if __name__ == '__main__':
    # Unit test
    test_Address_address()

# Generated at 2022-06-12 01:28:15.455968
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    result = provider.address()
    assert result is not None

# Generated at 2022-06-12 01:28:17.628089
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)

# Generated at 2022-06-12 01:28:19.966091
# Unit test for method address of class Address
def test_Address_address():
    """Test the address method of the Address class."""
    a = Address("en")
    assert isinstance(a.address(), str)


# Generated at 2022-06-12 01:28:25.936287
# Unit test for method address of class Address
def test_Address_address():
    '''
    Ensures that the address() method of the Address class works correctly.
    '''
    # Creates an instance of the Address class
    address = Address(seed=9238)

    # Execute the method address() of the Address class and save the result
    result = address.address()

    # Check whether the method address() works correctly
    assert result == '1348 W. St. Marys'

# Generated at 2022-06-12 01:28:41.629490
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

# Generated at 2022-06-12 01:28:45.906133
# Unit test for method address of class Address
def test_Address_address():
    """Test for the method address of class Address."""
    add = Address()
    addr = add.address()
    if not isinstance(addr, str):
        raise TypeError('Method must return a str.')

    if not addr:
        raise ValueError('Method should return a not empty str.')

# Generated at 2022-06-12 01:28:48.660507
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    x = ad.address()
    print(x)

if __name__ == "__main__":
    test_Address_address()

# Generated at 2022-06-12 01:28:57.456790
# Unit test for method address of class Address
def test_Address_address():
    """test_Address_address"""
    from mimesis.enums import Locale

    address = Address(Locale.RU)

    assert (address.street_number() >= 0 and address.street_number() <= 1400)

    assert isinstance(address.street_name(), str)
    assert isinstance(address.street_suffix(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.state(), str)
    assert isinstance(address.region(), str)
    assert isinstance(address.province(), str)
    assert isinstance(address.federal_subject(), str)
    assert isinstance(address.prefecture(), str)
    assert isinstance(address.postal_code(), str)
    assert isinstance(address.zip_code(), str)

# Generated at 2022-06-12 01:29:00.705154
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='zh')
    for _ in range(10):
        print(address.address())
    print(address.street_suffix())
    print(address.street_name())
    print(address.street_number())


# Generated at 2022-06-12 01:29:03.939193
# Unit test for method address of class Address
def test_Address_address():
    assert Address('en').address() != Address('ru').address()
    # assert Address('pl').address()
    # assert Address('ja').address()
    # assert Address('zh-CN').address()



# Generated at 2022-06-12 01:29:05.628345
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert ' ' not in result


# Generated at 2022-06-12 01:29:10.259886
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    sz = address.address()
    print(sz)
    sz = address.street_number()
    print(sz)
    sz = address.street_name()
    print(sz)
    sz = address.street_suffix()
    print(sz)


# Generated at 2022-06-12 01:29:11.870420
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-12 01:29:13.940969
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    address = provider.address()
    assert address != None


# Generated at 2022-06-12 01:29:38.890283
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    import pytest

    from mimesis.enums import Locale


# Generated at 2022-06-12 01:29:41.915449
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    assert address_1.address() != address_2.address()

# Generated at 2022-06-12 01:29:51.194336
# Unit test for method address of class Address
def test_Address_address():
    """Testing Address.address() method."""
    from mimesis.enums import CountryCode

    # address_fmt for country US
    us_fmt = '{st_num} {st_name} {st_sfx}'

    # address_fmt for country UA
    ua_fmt = '{st_name} {st_num}'

    # address_fmt for country JP
    jp_fmt = '{city} {st_name} {st_sfx} {st_num}'

    # address_fmt for country CL
    cl_fmt = '{st_num} {st_name}'

    # address_fmt for country KZ
    kz_fmt = '{city} {st_name} {st_num}'

    # address_fmt for country FR

# Generated at 2022-06-12 01:29:52.587749
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    assert isinstance(add.address(), str)
    

# Generated at 2022-06-12 01:29:58.976653
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address.

    Address.address()
    """
    address = Address('en')
    print(address.address())
    print(address.address())


# Generated at 2022-06-12 01:30:07.430657
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender

    ad=Address('en')
    print(ad.street_number())
    print(ad.street_name())
    print(ad.street_suffix())

    # print(ad.address_by_pattern("{building_number}/{street_name} {street_suffix}"))

    print(ad.city())
    print(ad.state())
    print(ad.county())
    print(ad.postal_code())
    print(ad.country_code())
    print(ad.country())

# Generated at 2022-06-12 01:30:12.806050
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    list_result = result.split()
    list_result.sort()
    assert (list_result == [address.street_number(), address.street_name(), address.street_suffix()] or
            list_result == [address.street_number(), address.street_name()])


# Generated at 2022-06-12 01:30:24.712847
# Unit test for method address of class Address
def test_Address_address():
    locale_list = ['ca-ES', 'de', 'en', 'fi-FI', 'fr', 'it', 'ja', 'pl', 'ru', 'uk', 'zh']

    for locale in locale_list:
        address = Address(locale=locale)
        # Main
        assert type(address.address()) is str, "assertEquals is error"
        # Street number
        assert type(address.street_number()) is str, "assertEquals is error"
        # Street name
        assert type(address.street_name()) is str, "assertEquals is error"
        # Street suffix
        assert type(address.street_suffix()) is str, "assertEquals is error"
        # State
        assert type(address.state()) is str, "assertEquals is error"
        # Federal subject

# Generated at 2022-06-12 01:30:25.608402
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())

# Generated at 2022-06-12 01:30:26.402027
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    addr = Address()
    assert 'bolshaya' in addr.address()

# Generated at 2022-06-12 01:30:47.702304
# Unit test for method address of class Address
def test_Address_address():

    def test_Address_address_param(mimesis_addres):
        Address.address()

    # test_Address_address_param(mimesis_addres=Address(locale='zh'))
    # test_Address_address_param(mimesis_addres=Address(locale='zh'))
    # test_Address_address_param(mimesis_addres=Address(locale='zh'))
    # test_Address_address_param(mimesis_addres=Address(locale='zh'))
    test_Address_address_param(mimesis_addres=Address(locale='zh'))



# Generated at 2022-06-12 01:30:49.324839
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()

    assert address is not None


# Generated at 2022-06-12 01:30:50.441250
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    print(add.address())


# Generated at 2022-06-12 01:30:52.737985
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert address.address()
    assert address.address()


# Generated at 2022-06-12 01:30:59.586809
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    a1 = Address(seed=1)
    assert a1.address() == '307 Schiller Park'

    a2 = Address(seed=2)
    assert a2.address() == '9202 Kutch Island'

    a3 = Address(seed=3)
    assert a3.address() == '846 Anzinger Brook'

    a4 = Address(seed=4)
    assert a4.address() == '513 Jacqueline Underpass'


# Generated at 2022-06-12 01:31:01.823304
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    ret = obj.address()
    assert ret != None
    ret = obj.address()
    assert ret != None


# Generated at 2022-06-12 01:31:03.201785
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    result = provider.address()
    assert isinstance(result, str)



# Generated at 2022-06-12 01:31:15.190297
# Unit test for method address of class Address
def test_Address_address():
    """Test for Address.address()."""
    a = ['3271 Larkin Street', '3321 W. Larkin Street',
       '1015 W. Larkin Street', '1447 N. Larkin Street',
       '1758 N. Larkin Street', '1166 W. Larkin Street',
       '3386 Larkin Street', '3546 N. Larkin Street',
       '1824 N. Larkin Street', '3723 W. Larkin Street']
    b = ['1491 Larkin Street', '1562 Larkin Street',
       '3173 W. Larkin Street', '2656 W. Larkin Street',
       '1153 W. Larkin Street', '3495 N. Larkin Street']

    address = Address('ru')
    assert address.address() in a
    assert address.address() in b
    assert address.address()

# Generated at 2022-06-12 01:31:17.665269
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert type(address.address()) == str



# Generated at 2022-06-12 01:31:22.479076
# Unit test for method address of class Address
def test_Address_address():
    address = Address('cs')
    results = [address.address(True) for i in range(1, 10)]
    assert results[0] == 'Stará Hlubočepská 1536'
    assert results[1] == 'Stará Hlubočepská 1536'
    assert results[2] == 'Stará Hlubočepská 1536'


# Generated at 2022-06-12 01:32:13.440304
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(locale=Locale.EN)
    assert address.address() != None


# Generated at 2022-06-12 01:32:19.017340
# Unit test for method address of class Address
def test_Address_address():
    import random
    import re
    import string
    import sys

    RAND_COUNT = 100
    NOT_FOUND_COUNT = 0
    LOCALE = 'en-US'

    def check_fmt(locale, adr_fmt, adr_str):
        if locale in ['de']:
            if not re.match(r'^[0-9]+$', adr_str):
                print(f'\n{locale}: AssertionError: invalid address format: '
                      f'{adr_str}')
                sys.exit()

# Generated at 2022-06-12 01:32:24.985505
# Unit test for method address of class Address
def test_Address_address():
    from .address import Address
    from . import address

    a_address = Address()
    r1 = a_address.address()
    print(r1)

    a_address = Address()
    r2 = a_address.address()
    print(r2)
    print(r1 == r2)

    compare(r1, r2)


# Generated at 2022-06-12 01:32:26.100174
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en')
    assert a.address() != a.address() # Return a different address string

# Generated at 2022-06-12 01:32:27.188533
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for _ in range(100):
        assert type(address.address()) == str


# Generated at 2022-06-12 01:32:29.364672
# Unit test for method address of class Address
def test_Address_address():
    expected_output= "Calle José Luis Trueba, 24"
    result = Address("es").address()
    assert result == expected_output



# Generated at 2022-06-12 01:32:31.733585
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    for i in range(10):
        assert isinstance(a.address(), str)
        print(a.address())


# Generated at 2022-06-12 01:32:32.888602
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result

# Generated at 2022-06-12 01:32:36.903530
# Unit test for method address of class Address
def test_Address_address():
    """Method address of class Address."""
    from mimesis.enums import Locale

    ad = Address(Locale.EN)
    assert isinstance(ad.address(), str) and len(ad.address()) > 0


# Generated at 2022-06-12 01:32:41.881450
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale="en")
    full_address = address.address()
    assert full_address
    assert isinstance(full_address,str)
    print(f"address.address() produced: {full_address}")


# Generated at 2022-06-12 01:33:19.154272
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    a = Address()
    assert a.address().__class__ == str
    assert a.address().__len__() > 0


# Generated at 2022-06-12 01:33:21.452859
# Unit test for method address of class Address
def test_Address_address():
    a = Address(seed=1337)
    assert a.address() == "1188 Suesh Sq."

# Generated at 2022-06-12 01:33:24.049941
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert result != ""
    assert type(result) == str
    assert len(result) > 0


# Generated at 2022-06-12 01:33:30.538622
# Unit test for method address of class Address
def test_Address_address():
    import unittest
    import re

    # True
    address = Address()
    pattern = re.compile(r'\d{1,4}\s[A-Za-z]+\s([A-Za-z]+)?\s?(St\.|Ave\.)?')
    assert pattern.match(address.address()) is not None

    # False
    assert pattern.match(address.address()) is None

    # Unit test
    class TestRandom(unittest.TestCase):
        """Test Address class."""

        def test_dd_to_dms(self):
            assert Address._dd_to_dms(45.876, 'lt') == '45º52\'33.760"N'

# Generated at 2022-06-12 01:33:33.281814
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    addr = Address()
    a = addr.address()
    print(a)
    assert isinstance(a, str)
    assert addr.address() != ''


# Generated at 2022-06-12 01:33:38.467416
# Unit test for method address of class Address
def test_Address_address():
    # Set up
    address = Address(locale="en")
    # Exercise
    result = address.address()
    result2 = address.address()
    result3 = address.street_name()
    result4 = address.street_suffix()
    result5 = address.street_number()
    # Verify
    assert type(result) == str and ' ' in result and type(result2) == str and ' ' in result2 and type(result3) == str and type(result4) == str and type(result5) == str


# Generated at 2022-06-12 01:33:41.795904
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
    print(address.address())
    print(address.address())
    print(address.address())
    print(address.address())


# Generated at 2022-06-12 01:33:44.862912
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(True)
    assert isinstance(address_1.address(), str)
    assert address_1.address() != address_1.address()


# Generated at 2022-06-12 01:33:46.678468
# Unit test for method address of class Address
def test_Address_address():
    # test 1
    ad = Address(locale='es')
    assert ad.address() != ad.address()


# Generated at 2022-06-12 01:33:49.054867
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    for i in range(100):
        assert isinstance(a.address(), str)



# Generated at 2022-06-12 01:34:33.356841
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert "Abbeyview" in a.address()

# Generated at 2022-06-12 01:34:35.207198
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

# Generated at 2022-06-12 01:34:37.978829
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    a = Address(Locale.EN)

    res = a.address()
    print(a.address())
    print(res)



# Generated at 2022-06-12 01:34:40.388175
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address_it = Address(Locale.ITALIAN)
    assert isinstance(address_it.address(), str)


# Generated at 2022-06-12 01:34:42.610859
# Unit test for method address of class Address
def test_Address_address():
    pass



# Generated at 2022-06-12 01:34:46.850351
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    # Test for ru locale
    addr = add.address()
    assert isinstance(addr, str)
    assert len(addr) > 0
    # Test for en locale
    addr = add.address(locale='en')
    assert isinstance(addr, str)
    assert len(addr) > 0
