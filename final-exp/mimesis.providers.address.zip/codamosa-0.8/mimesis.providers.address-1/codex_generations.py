

# Generated at 2022-06-12 01:24:55.481330
# Unit test for method address of class Address
def test_Address_address():
    import mimesis.builtins
    a = Address()
    a._random = mimesis.builtins.Random()
    a._random.choice = lambda x: '/'
    assert a.address() == '/'

# Generated at 2022-06-12 01:25:00.049887
# Unit test for method address of class Address
def test_Address_address():
    address = Address().address()
    exp = '{} {} {} {}'
    assert isinstance(address, str) and \
        exp.format(exp.format('', '', '', ''), exp.format('', '', '', ''), exp.format('', '', '', ''), '', '') == address



# Generated at 2022-06-12 01:25:03.558387
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    a = Address(Locale.EN)
    assert a.address() != a.address()

# Generated at 2022-06-12 01:25:05.009884
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)


# Generated at 2022-06-12 01:25:09.408265
# Unit test for method address of class Address
def test_Address_address():
    from test import samples
    from mimesis.enums import CountryCode
    address = Address()

    for i in samples:
        assert address.address() == i
    assert address.address(
        code=CountryCode.A2,
    ) == 'W-151 W Ruppert York, MD 21872'

# Generated at 2022-06-12 01:25:14.106818
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    result = address.address()
    assert isinstance(result, str), 'result must be string'
    assert len(result) > 0, 'result must not be empty'


# Generated at 2022-06-12 01:25:17.050076
# Unit test for method address of class Address
def test_Address_address():
    address = Address("zh")
    print(address.address())
    print(address.address())
    print(address.address())


# Generated at 2022-06-12 01:25:24.462719
# Unit test for method address of class Address
def test_Address_address():
    print("***********************************Testing method address of class Address*****************************")
    from mimesis.enums import Country
    from mimesis.enums import Locale
    address1 = Address(Locale.ENGLISH, Country.UNITED_STATES)
    address2 = Address(Locale.CHINESE, Country.CHINA)
    address3 = Address(Locale.JAPANESE, Country.JAPAN)
    print(address1.address())
    print(address2.address())
    print(address3.address())
    print()


# Generated at 2022-06-12 01:25:26.857687
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    addr = Address('pl')
    address = addr.address()
    assert address



# Generated at 2022-06-12 01:25:29.544865
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert len(result) >= 2


# Generated at 2022-06-12 01:25:44.126352
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.exceptions import NonEnumerableError

    # BaseDataProvider uses random.SystemRandom as default generator
    class Test(BaseDataProvider):
        def __init__(self, seed=None, generators=None):
            if generators is None:
                generators = []
            BaseDataProvider.__init__(self, seed, generators)

    provider = Address(seed=1)
    address = provider.address()
    assert address.startswith('895')

    provider = Address(seed=1)
    address = provider.address()
    assert address.startswith('895')

    provider = Address(seed=1)
    address = provider.address()

# Generated at 2022-06-12 01:25:47.029496
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    assert ad.address() != ''


# Generated at 2022-06-12 01:25:58.113835
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.builtins import JapanSpecProvider

    # test for ru
    ru_address = Address('ru')
    assert ru_address.address() == 'улица Кузнечная, 25/2'
    assert ru_address.address() == 'улица Полевая, дом 35'

    # test for en
    en_address = Address('en')
    assert en_address.address() == '793 Creek Street'

    # test for es
    es_address = Address('es')
    assert es_address.address() == 'Isabel Rivera #975, San Pedro'

    # test for it
    it_address = Address('it')

# Generated at 2022-06-12 01:26:03.367481
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    result_address = address.address()
    result_address_list = result_address.split()
    assert len(result_address_list) > 0
    assert len(result_address_list[0]) > 0
    assert result_address_list[0].isdigit()


# Generated at 2022-06-12 01:26:04.413506
# Unit test for method address of class Address
def test_Address_address():
    address = Address
    assert address()



# Generated at 2022-06-12 01:26:08.938133
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en')
    expected = ['{st_num} {st_name} {st_sfx}', '{st_num} {st_sfx} {st_name}', '{st_sfx} {st_num} {st_name}'] # noqa
    assert a.address() in expected

# Generated at 2022-06-12 01:26:11.641215
# Unit test for method address of class Address
def test_Address_address():
    p = Address(locale='en')
    assert p.address() == '113 E. Stienstra Parkway'

# Generated at 2022-06-12 01:26:12.991822
# Unit test for method address of class Address
def test_Address_address():
   ad = Address()
   result = ad.address()
   print(result)

# Generated at 2022-06-12 01:26:18.974479
# Unit test for method address of class Address
def test_Address_address():
    '''
    地址地址测试方法
    :return:
    '''
    # 测试地址方法
    address_p = Address()
    address = address_p.address()
    print('生成的随机地址为：%s' % address)
    assert address
    assert isinstance(address, str)

# Generated at 2022-06-12 01:26:20.725966
# Unit test for method address of class Address
def test_Address_address():
    print (Address().address())
    print (Address().address())
    print (Address().address())


# Generated at 2022-06-12 01:26:31.597947
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='ja')
    result = address.address()
    assert type(result) == str
    assert len(result) > 0


# Generated at 2022-06-12 01:26:43.186912
# Unit test for method address of class Address
def test_Address_address():
    from pprint import pprint
    a = Address(locale='es')
    for i in range(1):
        result = a.address()
        pprint(result)
    # pprint(a.address())  # "Casa en #3999, Calle Camino, Cuidad de Mexico"
    # pprint(a.address())  # "Calle San Marcos #2869, Cuidad de Mexico"
    # pprint(a.address())  # "Calle 5 de Mayo #3330, Cuidad de Mexico"
    # pprint(a.address())  # "Calle Camino #255, Cuidad de Mexico"
    # pprint(a.address())  # "#3612, Calle del Sol, Cuidad de Mexico"
    # pprint(a.address())  # "#1579, Calle Camino, Cuidad

# Generated at 2022-06-12 01:26:45.816746
# Unit test for method address of class Address
def test_Address_address():
    ad = Address('da')
    assert(ad.address() != '')

# Generated at 2022-06-12 01:26:52.450216
# Unit test for method address of class Address
def test_Address_address():
    """
    Test for Address.address()
    """
    street_num_list = []
    for i in range(5):
        addr = Address()
        street_num_list.append(addr.street_number())
    assert street_num_list[0] != street_num_list[1]
    assert street_num_list[1] != street_num_list[2]
    assert street_num_list[2] != street_num_list[3]
    assert street_num_list[3] != street_num_list[4]


# Generated at 2022-06-12 01:26:53.395864
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert type(a.address()) is str

# Generated at 2022-06-12 01:26:54.777579
# Unit test for method address of class Address
def test_Address_address():
    """Test method address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-12 01:26:55.773492
# Unit test for method address of class Address
def test_Address_address():
    testdata = Address().address()
    assert bool(testdata)


# Generated at 2022-06-12 01:26:59.369966
# Unit test for method address of class Address
def test_Address_address():
    # test for locale en-US
    a = Address(locale='en-US')
    assert a.address() != None
    assert isinstance(a.address(), str)
    assert len(a.address()) > 0
    # test for locale de-DE
    b = Address(locale='de-DE')
    assert b.address() != None
    assert isinstance(b.address(), str)
    assert len(b.address()) > 0


# Generated at 2022-06-12 01:27:00.286600
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()



# Generated at 2022-06-12 01:27:01.478311
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    result = obj.address()
    assert result


# Generated at 2022-06-12 01:27:11.815513
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = {address.address() for i in range(0, 10)}
    assert len(result) >= 3



# Generated at 2022-06-12 01:27:13.089335
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    assert ad.address() == '14 Rampart Street'

# Generated at 2022-06-12 01:27:17.122835
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    all(
        [
            address.address().startswith('No.')
            for _ in range(100)
        ]
    )


test_Address_address()

# Generated at 2022-06-12 01:27:26.664513
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender
    a = Address('en')
    assert a.address() != None
    a = Address('zh')
    assert a.address() != None
    a = Address('de')
    assert a.address() != None
    a = Address('es')
    assert a.address() != None
    a = Address('fr')
    assert a.address() != None
    a = Address('it')
    assert a.address() != None
    a = Address('ja')
    assert a.address() != None
    a = Address('ko')
    assert a.address() != None
    a = Address('ru')
    assert a.address() != None


# Generated at 2022-06-12 01:27:29.289076
# Unit test for method address of class Address
def test_Address_address():
    '''
    Test for method address of class Address
    '''
    a=Address()
    assert isinstance(a.address(),str)

# Generated at 2022-06-12 01:27:30.749983
# Unit test for method address of class Address
def test_Address_address():
    # test
    address = Address()
    # test
    assert isinstance(address.address(), str)

# Generated at 2022-06-12 01:27:33.410913
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    result = Address().address()
    assert len(result) > 0

# Generated at 2022-06-12 01:27:35.581863
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en_GB')
    address.address()
    d = address.address()
    assert isinstance(d, str)


# Generated at 2022-06-12 01:27:36.748586
# Unit test for method address of class Address
def test_Address_address():
    dp = Address()
    assert len(dp.address()) == 0

# Generated at 2022-06-12 01:27:46.880347
# Unit test for method address of class Address
def test_Address_address():
    print('\nFunction "test_Address_address"')
    print('Version: 1')
    print()

    address = Address(seed=12345)

    address_1 = address.address()
    print('address_1 = ', address_1)
    address_2 = address.address()
    print('address_2 = ', address_2)
    address_3 = address.address()
    print('address_3 = ', address_3)
    address_4 = address.address()
    print('address_4 = ', address_4)
    address_5 = address.address()
    print('address_5 = ', address_5)
    address_6 = address.address()
    print('address_6 = ', address_6)
    address_7 = address.address()
    print('address_7 = ', address_7)


# Generated at 2022-06-12 01:27:59.081941
# Unit test for method state of class Address
def test_Address_state():
    """Unit test for method state of class Address."""
    address = Address()
    state = address.state()
    assert state in address._data['state']['name']

# Generated at 2022-06-12 01:28:04.944906
# Unit test for method country of class Address
def test_Address_country():
    assert Address('en').country() == 'Great Britain'
    assert Address('en').country(allow_random=True) == 'Great Britain'
    assert Address('ru').country() == 'Россия'
    assert Address('ru').country(allow_random=True) == 'Россия'


# Generated at 2022-06-12 01:28:10.486119
# Unit test for method country of class Address
def test_Address_country():
    addr = Address()
    countries = ['United States', 'South Africa', 'Italy', 'Spain', 'Germany', 'France', 'United Kingdom', 'Australia', 'China', 'Japan', 'India', 'Indonesia', 'Nigeria', 'Brazil', 'Mexico', 'Egypt', 'Philippines', 'Argentina', 'Iran', 'Turkey']
    assert addr.country() in countries


# Generated at 2022-06-12 01:28:15.585146
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()

    assert type(address.federal_subject(abbr=True)) is str
    assert any(address.federal_subject(abbr=True) in i for i in address._data['state']['abbr'])
    assert len(address.federal_subject(abbr=True)) == 2

    assert type(address.federal_subject(abbr=False)) is str
    assert address.federal_subject(abbr=False) in address._data['state']['name']
    assert len(address.federal_subject(abbr=False)) > 3


# Generated at 2022-06-12 01:28:18.015916
# Unit test for method region of class Address
def test_Address_region():
    for _ in range(10):
        print(Address().region())



# Generated at 2022-06-12 01:28:20.152027
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    suffix = address.street_suffix()
    assert isinstance(suffix, str)


# Generated at 2022-06-12 01:28:22.388736
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    provider = Address()
    value = provider.zip_code()
    assert value is not None


# Generated at 2022-06-12 01:28:24.771885
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    s = a.street_suffix()

    assert len(s) > 0, 'Street suffix is empty'


# Generated at 2022-06-12 01:28:29.340838
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    random_continent_code = a.continent(code=True)
    print(random_continent_code)
    assert (random_continent_code in CONTINENT_CODES), "random_continent_code not in CONTINENT_CODES"
    assert (type(random_continent_code) is str), "random_continent_code is not a string"

# Generated at 2022-06-12 01:28:31.985958
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.locales import Locale

    address = Address(Locale.EN)
    assert address.province() == address.state()

# Generated at 2022-06-12 01:28:55.544103
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from random import random
    from mimesis.enums import CountryCode

    from mimesis.builtins import address

    country_codes = CountryCode.__values__

    for _ in range(50):
        seed = random()
        x = address.Address(seed=seed)
        y = address.Address(seed=seed)

        assert x.postal_code() == y.postal_code() \
            == x.postal_code()

    postal_1 = address.Address(seed=0.9644534869241914).postal_code()
    assert postal_1 == '57-000'

    postal_2 = address.Address(
        seed=0.6184387775573673,
        locale=country_codes[0]).postal_code()
    assert postal_2 == '01001'

# Generated at 2022-06-12 01:29:04.554336
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address
    assert address.street_name()
    assert address.address()
    assert address.state()
    assert address.postal_code()
    assert address.country()
    assert address.city()
    assert address.latitude()
    assert address.longitude()
    assert address.latitude(dms=True)
    assert address.longitude(dms=True)
    assert address.coordinates()
    assert address.coordinates(dms=True)
    assert address.continent()
    assert address.continent(code=True)
    assert address.calling_code()
    assert address.country_code(CountryCode.A2)
    assert address.country_code(CountryCode.A3)
    assert address.street_number()
    assert address.province()
    assert address

# Generated at 2022-06-12 01:29:06.583312
# Unit test for method city of class Address
def test_Address_city():
    address_object = Address()
    print(address_object.city())

# Generated at 2022-06-12 01:29:10.989868
# Unit test for method latitude of class Address
def test_Address_latitude():
    adr = Address()
    print(adr.latitude())
    print(adr.latitude())
    print(adr.latitude())
    print(adr.latitude(dms=True))
    print(adr.latitude(dms=True))
    print(adr.latitude(dms=True))


# Generated at 2022-06-12 01:29:13.815824
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    assert isinstance(address.street_name, str)
    assert len(address.street_name) > 0


# Generated at 2022-06-12 01:29:18.253195
# Unit test for method country of class Address
def test_Address_country():
    # call country() method
    # it returns a country
    result = Address().country()
    # assert that returned country is not empty
    # and is a string
    assert result is not None
    assert isinstance(result, str)
    # assert that returned country is not made up of only spaces
    # and is not an empty string
    assert result.strip() != ""


# Generated at 2022-06-12 01:29:20.140743
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    b = a.region()
    assert type(b) == str


# Generated at 2022-06-12 01:29:24.565149
# Unit test for constructor of class Address
def test_Address():
    """Unit test for constructor of class Address."""
    assert Address('en')
    assert Address('ru')
    assert Address('ja')
    assert Address('zh')
    assert Address('es')
    assert Address('fr')
    assert Address('de')
    assert Address('it')
    assert Address('pt')
    assert Address('be')
    assert Address('pl')
    assert Address('uk')
    assert Address('tr')
    assert Address('nl')
    assert Address('id')

# Generated at 2022-06-12 01:29:27.683266
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    print('Test method `postal_code()`')
    print(Address().postal_code())
    print('="==========')

# Generated at 2022-06-12 01:29:30.816784
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address(seed=0).latitude() == -88.163799
    assert Address(seed=0).latitude(dms=True) == \
        '88º9\'49.5200"S'


# Generated at 2022-06-12 01:30:06.658764
# Unit test for method street_number of class Address
def test_Address_street_number():
    addr = Address(locale='en')
    assert addr.street_number(maximum=1400) is not None
    assert addr.street_number(maximum=1400) not in ('', ' ')
    assert addr.street_number(maximum=1400) is str


# Generated at 2022-06-12 01:30:08.317084
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    result = address.prefecture()
    assert result != None


# Generated at 2022-06-12 01:30:17.023669
# Unit test for method country of class Address
def test_Address_country():
    country_1 = Address().country()
    country_2 = Address(locale='en').country()
    country_3 = Address(locale='ja').country()
    country_4 = Address(locale='en').country(allow_random=True)
    country_5 = Address(locale='ja').country(allow_random=True)
    assert country_1 == country_2
    assert country_1 != country_3
    assert country_1 == 'Japan'
    assert country_2 == 'United Kingdom'
    assert country_3 == '日本'
    assert country_4 != country_2
    assert country_5 != country_3


# Generated at 2022-06-12 01:30:23.905233
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    b = a.street_name()

    # Check not empty
    assert len(b) != 0
    assert b.isalpha() == True
    assert len(b.split()) == 2


# Generated at 2022-06-12 01:30:25.812986
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address('en')
    for i in range(10):
        assert -90 <= float(a.latitude()) <= 90

# Generated at 2022-06-12 01:30:27.008352
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    assert address.country() == 'Россия'

# Generated at 2022-06-12 01:30:29.281923
# Unit test for method latitude of class Address
def test_Address_latitude():
    for _ in range(10):
        print(Address().latitude())


# Generated at 2022-06-12 01:30:30.753546
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert type(address.address()) == str


# Generated at 2022-06-12 01:30:33.623160
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert calling_code in CALLING_CODES
    


# Generated at 2022-06-12 01:30:37.118861
# Unit test for method address of class Address
def test_Address_address():
    """Test method address() of class Address."""
    address = Address()
    s = address.address()
    assert s != ''
    assert isinstance(s, str)


# Generated at 2022-06-12 01:31:46.532905
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address("en")
    b = a.calling_code()
    assert b in CALLING_CODES


# Generated at 2022-06-12 01:31:47.006669
# Unit test for method address of class Address
def test_Address_address():
    pass

# Generated at 2022-06-12 01:31:49.740977
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis import Address
    from mimesis.enums import CountryCode

    a = Address('ru')
    assert a.federal_subject(abbr=True) == a.state(abbr=True)