

# Generated at 2022-06-12 01:24:55.526669
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    assert(a.address() != '')

test_Address_address()


# Generated at 2022-06-12 01:24:56.861078
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:24:58.669019
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''
    assert address.address() is not None


# Generated at 2022-06-12 01:25:03.706384
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='en')
    print(adr.address())
    adr = Address(locale='zh')
    print(adr.address())
    adr = Address(locale='ja')
    print(adr.address())


# Generated at 2022-06-12 01:25:08.980068
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale = 'en')
    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()
    address = address.address()

    assert address == '{} {} {}'.format(st_num, st_name, st_sfx)


# Generated at 2022-06-12 01:25:12.996450
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    ans = address.address()
    assert ans
    assert isinstance(ans, str)
    assert ans != ' '
    assert len(ans) > 1


# Generated at 2022-06-12 01:25:15.967418
# Unit test for method address of class Address
def test_Address_address():
    assert Address(random_seed=0).address() == '66 rue des Lilas, 94410 Saint-Maurice'


# Generated at 2022-06-12 01:25:17.446477
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)

# Generated at 2022-06-12 01:25:19.087861
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    print(address.address())
    print(address.state())

# Generated at 2022-06-12 01:25:21.607776
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='ru')
    assert a.address() == 'улица Вампира, 2099'


# Generated at 2022-06-12 01:25:37.450922
# Unit test for method address of class Address

# Generated at 2022-06-12 01:25:38.474611
# Unit test for method address of class Address
def test_Address_address():
    pass


# Generated at 2022-06-12 01:25:39.821318
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-12 01:25:42.828767
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()

    address_1.address()
    address_2.address()

    assert type(address_1.address()) == type(address_2.address())

# Generated at 2022-06-12 01:25:45.944516
# Unit test for method address of class Address
def test_Address_address():
    # Given
    address_generator = Address()
    address_generator.locale = 'ja'

    # When
    actual = address_generator.address()

    # Then
    assert actual == "東京都千代田区一番町1−100−100"

# Generated at 2022-06-12 01:25:57.720380
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from itertools import repeat
    from random import choice
    from mimesis.builtins import Address
    from mimesis.providers import Address as Address2
    def test():
        for _ in repeat(None, 100):
            for locale in Locale:
                addr = Address(locale)
                full_address = addr.address()
                street_name = addr.street_name()
                street_suffix = addr.street_suffix()
                street_number = addr.street_number()
                data = {
                    'address': full_address,
                    'street_name': street_name,
                    'street_suffix': street_suffix,
                    'street_number': street_number,
                }

# Generated at 2022-06-12 01:25:59.065386
# Unit test for method address of class Address
def test_Address_address():
    _address = Address('en')
    assert _address.address() == _address.address()

# Generated at 2022-06-12 01:26:01.034417
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    print(a.address())


# Generated at 2022-06-12 01:26:08.572019
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    a = Address()
    num = a.street_number()
    st_name = a.street_name()
    st_suffix = a.street_suffix()

    assert a.address() == a._data['address_fmt'].format(
        st_num=num,
        st_name=st_name,
        st_sfx=st_suffix
    ) or a._data['address_fmt'].format(
        st_num=num,
        st_name=st_name,
    )

# Generated at 2022-06-12 01:26:12.444939
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)
    assert isinstance(a.address('en'), str)
    assert isinstance(a.address(locale='en'), str)


# Generated at 2022-06-12 01:26:22.089853
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    assert isinstance(address, str)


# Generated at 2022-06-12 01:26:24.654849
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='en')
    actual = adr.address()
    expected = '278 John Wall Drive'
    assert actual == expected


# Generated at 2022-06-12 01:26:28.033973
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-12 01:26:28.855460
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result

# Generated at 2022-06-12 01:26:33.767366
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender
    from mimesis.providers import Address, Automotive, Blockchain, DateTime
    from mimesis.providers.person import Person

    add = Address('pt-BR')
    auto = Automotive('pt-BR')
    block = Blockchain('pt-BR')
    date = DateTime('pt-BR')
    person = Person('pt-BR')

    print(add.address())
    print(add.address())
    print(add.address())
    print(add.address())
    print(add.address())

# Generated at 2022-06-12 01:26:38.993114
# Unit test for method address of class Address
def test_Address_address():
    address_provider = Address()
    country_code = address_provider.country_code()

    address_provider._locale = country_code
    address = address_provider.address()
    print('Address')
    print('\t', address, end='\n\n\n')


# Generated at 2022-06-12 01:26:41.454272
# Unit test for method address of class Address
def test_Address_address():
    """ unit testing
    """
    provider = Address(__file__)
    results = provider.address()
    assert isinstance(results, str)
    assert len(results) > 0

# Generated at 2022-06-12 01:26:43.378076
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    print(address.address())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:26:53.796327
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en')

# Generated at 2022-06-12 01:26:56.368971
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.localization import RU

    addr = Address(locale=RU.code)
    assert addr.address() == '38-е литературное общество'


# Generated at 2022-06-12 01:27:12.963237
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


if __name__ == '__main__':
    pass

# Generated at 2022-06-12 01:27:15.311411
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for address() method."""
    assert Address('ru').address() == 'Лермонтова, 18'
    assert Address('ru').address() == 'Толстого, 31'
    assert Address('ru').address() == 'Гусева, 12'



# Generated at 2022-06-12 01:27:18.256070
# Unit test for method address of class Address
def test_Address_address(): 
    address = Address()
    r = address.address() # 随机地址
    print(r)


# Generated at 2022-06-12 01:27:19.473304
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() is not None



# Generated at 2022-06-12 01:27:23.735704
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address_fmt = '{street_number} {street_name}, {postal_code} {city}, {state}'
    assert a.address() == a.address_fmt(address_fmt)

# Generated at 2022-06-12 01:27:27.451564
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street = address.street_name()
    street_number = address.street_number()
    street_suffix = address.street_suffix()
    print('Address: {} {} {}, {}'.format(street_number, street, street_suffix, address.city()))
test_Address_address()

# Generated at 2022-06-12 01:27:33.814576
# Unit test for method address of class Address
def test_Address_address():
    p = Address(seed=59)
    assert p.address() == '1549 W. Roscoe'
    p = Address(seed=76)
    assert p.address() == '668 Spyglass Rd.'
    p = Address(seed=92)
    assert p.address() == '906 Regal Parkway'
    p = Address(seed=32)
    assert p.address() == '86883 Vinita Terrace'
    p = Address(seed=11)
    assert p.address() == '9722 Corrine Trail'
    p = Address(seed=69)
    assert p.address() == '334-6005 Eget Rd.'
    p = Address(seed=57)
    assert p.address() == '849-6807 Donec Rd.'
    p = Address(seed=17)

# Generated at 2022-06-12 01:27:35.338243
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == "1600 Pennsylvania Ave NW"

# Generated at 2022-06-12 01:27:37.417190
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    retval = address.address()
    print(retval)
    print(type(retval))
    assert type(retval) == str


# Generated at 2022-06-12 01:27:40.630821
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    list = []
    count = 0
    while(count != 100):
        addr = a.address()
        if addr not in list:
            list.append(addr)
            count = count+1
        else:
            continue

    print(list)


# Generated at 2022-06-12 01:28:13.800074
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('ru')
    test_addr = addr.address()
    assert(isinstance(test_addr, str))

# Generated at 2022-06-12 01:28:15.279400
# Unit test for method address of class Address
def test_Address_address():

    print(Address().address())

# Generated at 2022-06-12 01:28:26.766260
# Unit test for method address of class Address
def test_Address_address():
    # when locale is 'en'
    a_en = Address(locale='en')
    assert a_en.address() == '{num} {name} {suffix}'.format(
        num=a_en.street_number(),
        name=a_en.street_name(),
        suffix=a_en.street_suffix(),
    )

    # when locale is 'zh'
    a_zh = Address(locale='zh')
    assert a_zh.address() == '{num} {name}'.format(
        num=a_zh.street_number(),
        name=a_zh.street_name(),
    )

    # when locale is 'ja'
    a_ja = Address(locale='ja')

# Generated at 2022-06-12 01:28:28.936652
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    s = a.address()
    assert isinstance(s, str)
    assert (len(s) > 0)

# Generated at 2022-06-12 01:28:30.196668
# Unit test for method address of class Address
def test_Address_address():
    test = Address()
    assert isinstance(test.address(), str)


# Generated at 2022-06-12 01:28:32.818834
# Unit test for method address of class Address
def test_Address_address():
    adr = Address('en')
    print(adr.address())
    print("---------------------------------")


# Generated at 2022-06-12 01:28:34.744464
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    assert type(adr.address()) == str
    print("Unit test is successful")


# Generated at 2022-06-12 01:28:42.919560
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    rus = RussiaSpecProvider(locale=Locale.RU)
    address = Address(locale=Locale.RU)
    assert address.country() == 'Россия'
    assert address.state() == 'Московская обл'
    assert address.city() == 'Москва'
    assert address.address() == 'Ул. Мичурина, д. 27, кв. 33'

# Generated at 2022-06-12 01:28:47.022148
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    address = Address('en')

    for _ in range(10):
        res = address.address()
        assert isinstance(res, str)
        assert isinstance(res, str)
        assert len(res.split()) == 6


# Generated at 2022-06-12 01:28:49.722574
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
    print(address.address())
    print(address.address())
    print(address.address())
    print(address.address())
