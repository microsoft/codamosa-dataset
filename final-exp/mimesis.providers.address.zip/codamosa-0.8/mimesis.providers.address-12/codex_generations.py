

# Generated at 2022-06-12 01:24:54.801596
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    actual = address.address()
    expect = '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )
    assert actual == expect



# Generated at 2022-06-12 01:24:56.508534
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    x = address.address()
    print(x)



# Generated at 2022-06-12 01:24:57.150820
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()

# Generated at 2022-06-12 01:24:58.573463
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str


# Generated at 2022-06-12 01:25:10.618744
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    a = Address()
    str = a.address()
    str1 = a.address()
    str2 = a.address()
    str3 = a.address()
    str4 = a.address()
    str5 = a.address()
    str6 = a.address()
    str7 = a.address()
    str8 = a.address()
    str9 = a.address()
    str10 = a.address()
    str11 = a.address()
    str12 = a.address()
    str13 = a.address()
    str14 = a.address()
    str15 = a.address()
    str16 = a.address()
    str17 = a.address()
    str18 = a.address

# Generated at 2022-06-12 01:25:13.045333
# Unit test for method address of class Address
def test_Address_address():
    address = Address('zh')
    result = address.address()
    assert result is not None


# Generated at 2022-06-12 01:25:19.562823
# Unit test for method address of class Address
def test_Address_address():
    assert Address("en").address() == "1961 Heather Vista Suite 757"
    assert Address("ru").address() == "ул. Теплая, д. 99, кв. 238"
    assert Address("es").address() == "Calle de la Rosa, 563"
    assert Address("ja").address() == "〒114-8110 小滝市2-58-36-66"


# Generated at 2022-06-12 01:25:20.777998
# Unit test for method address of class Address
def test_Address_address():
    a_obj = Address()
    assert a_obj.address() is not None

# Generated at 2022-06-12 01:25:22.190141
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-12 01:25:29.446223
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    full_address = address.address()

    assert full_address is not None
    assert full_address is not ""

    if full_address.__contains__(" "):
        assert full_address.count(" ") >= 4
        assert address.street_number() in full_address
        assert address.street_name() in full_address
        assert address.street_suffix() in full_address



# Generated at 2022-06-12 01:25:38.516986
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()

    assert address.address() == '123 Anywhere St.'
    # Test of Chinese locale
    assert address.address() == '北京市 朝阳区 朝外大街 351 号'

# Generated at 2022-06-12 01:25:39.863988
# Unit test for method address of class Address
def test_Address_address():
    x = Address(locale='vi')
    print(x.address())


# Generated at 2022-06-12 01:25:44.421142
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert addr.address() is not None
    addr = Address('en')
    assert addr.address() is not None
    addr = Address('ru')
    assert addr.address() is not None
    addr = Address('es')
    assert addr.address() is not None
    addr = Address('zh')
    assert addr.address() is not None
  

# Generated at 2022-06-12 01:25:47.656600
# Unit test for method address of class Address
def test_Address_address():
    d = Address()
    result = d.address()
    assert result is not None


# Generated at 2022-06-12 01:25:49.125364
# Unit test for method address of class Address
def test_Address_address():
    import Address
    print(Address.Address().address())


# Generated at 2022-06-12 01:25:53.333539
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address

    add = Address('zh')
    print(add.address())
    print(add.address())
    print(add.address())
    print(add.address())
    print(add.address())
    print(add.address())

# Generated at 2022-06-12 01:25:54.314313
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == 'Karen Pheil'


# Generated at 2022-06-12 01:25:55.654868
# Unit test for method address of class Address
def test_Address_address():
    address_provider = Address()
    assert isinstance(address_provider.address(), str)
    assert address_provider.address() != ""


# Generated at 2022-06-12 01:26:05.889874
# Unit test for method address of class Address
def test_Address_address():
    print("\n# Unit test for method address of class Address:")
    adr = Address(locale="en")
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())
    print("Address: " + adr.address())


# Generated at 2022-06-12 01:26:17.500981
# Unit test for method address of class Address
def test_Address_address():
    fmt = '{st_num} {st_name} {st_sfx}'
    fmt1 = '{0} {1}'
    fmt2 = '{0} {1} {2}号'
    assert Address(locale='en').address() != Address(locale='en').address()
    assert Address(locale='en').address() == fmt.format(
        st_num=Address(locale='en').street_number(),
        st_name=Address(locale='en').street_name(),
        st_sfx=Address(locale='en').street_suffix(),
    )
    assert Address(locale='fr').address() == fmt1.format(
        Address(locale='fr').street_number(),
        Address(locale='fr').street_name(),
    )

# Generated at 2022-06-12 01:26:23.337677
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import Address
    address = Address()
    result = address.address()
    assert result != None


# Generated at 2022-06-12 01:26:28.941054
# Unit test for method address of class Address
def test_Address_address():
    print('Test method address of class Address')
    print('EN: ', Address('en').address())
    print('RU: ', Address('ru').address())
    print('ES: ', Address('es').address())
    print('DE: ', Address('de').address())
    print('UK: ', Address('uk').address())
    print('JA: ', Address('ja').address())

# Generated at 2022-06-12 01:26:29.477714
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert result

# Generated at 2022-06-12 01:26:36.632493
# Unit test for method address of class Address
def test_Address_address():
    """Test method address()."""
    import os
    import sys
    dir_name = os.path.dirname(__file__)
    sys.path.insert(0, dir_name + '/../../../')

    from mimesis.enums import Language

    locale = 'ru'
    a = Address(locale=locale)

    data = a.address()
    assert isinstance(data, str) or isinstance(data, int) or data == None
    assert data != None

# Generated at 2022-06-12 01:26:40.470905
# Unit test for method address of class Address
def test_Address_address():
    with open('./tests/address.txt', 'r') as f:
        file = f.readlines()
    obj = Address()
    for _ in range(200):
        add = obj.address()
        assert add in file


# Generated at 2022-06-12 01:26:43.411174
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    # Initialize provider
    pr = Address(locale=Locale.EN)
    # Get a random address
    for _ in range(10):
        print(pr.address())

# Generated at 2022-06-12 01:26:45.648803
# Unit test for method address of class Address
def test_Address_address():
	pass


# Generated at 2022-06-12 01:26:47.844951
# Unit test for method address of class Address
def test_Address_address():
    import mimesis.builtins
    provider = mimesis.builtins.Address()
    assert provider.address() != None


# Generated at 2022-06-12 01:26:50.801465
# Unit test for method address of class Address
def test_Address_address():
    a = Address(seed='test')
    # print(a.address())
    assert a.address() == '1120 Rue Valcourt'

if __name__ == '__main__':
    # test_Address_address()
    pass

# Generated at 2022-06-12 01:26:52.019378
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    r = address.address()
    return r

# Generated at 2022-06-12 01:26:57.315964
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    ad = Address()
    assert ad.address(country=None, state=None)

# Generated at 2022-06-12 01:26:58.621723
# Unit test for method address of class Address
def test_Address_address():
    address =  Address(from_file=True)
    print (address.address())


# Generated at 2022-06-12 01:27:00.508723
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    provider = Address()
    result = provider.address()
    assert result is not None


# Generated at 2022-06-12 01:27:10.667320
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == "206 Compte de la Liberté"
    assert Address(locale='pt-br').address() == "Rua Alvaro Fernandes Barros, 278"
    assert Address(locale='ru').address() == "ул. Братьев Радченко, 26"
    assert Address(locale='ja').address() == "福岡市中央区紙屋町6‐7"
    assert Address(locale='zh').address() == "中山镇白城东路150号"


# Generated at 2022-06-12 01:27:12.000281
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-12 01:27:16.127966
# Unit test for method address of class Address
def test_Address_address():
    # instance of class Address
    address = Address()

    # get a random full address
    full_address = address.address()

    print('street number: ', address.street_number())
    # print an random full address
    print(full_address)


# Generated at 2022-06-12 01:27:18.211793
# Unit test for method address of class Address
def test_Address_address():
    import mimesis
    a = mimesis.Address()
    a.address()

# Generated at 2022-06-12 01:27:22.080918
# Unit test for method address of class Address
def test_Address_address():
    from collections import Counter
    from mimesis import Address

    adr = Address('en')
    c = Counter([adr.address() for _ in range(100)])
    print(sorted(c.items()))


# Generated at 2022-06-12 01:27:25.300457
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '9482 Brittany Neck'
    assert Address(seed=0).address() == '3306 Luster Green'
    assert Address(seed=1).address() == '171 Kevin Forge'

# Generated at 2022-06-12 01:27:26.501247
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    print(address_obj.address())

# Generated at 2022-06-12 01:27:37.207390
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert isinstance(addr.street_name(), str)
    assert isinstance(addr.street_suffix(), str)
    assert isinstance(addr.street_number(), str)
    assert isinstance(addr.address(), str)


# Generated at 2022-06-12 01:27:43.001987
# Unit test for method address of class Address
def test_Address_address():
    # test
    address = Address()
    street_number = address._choices(address._data['street']['number'])
    street_name = address._choices(address._data['street']['name'])
    street_suffix = address._choices(address._data['street']['suffix'])
    assert address.address() == f"{street_number} {street_name} {street_suffix}"


# Generated at 2022-06-12 01:27:43.990807
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ''

# Generated at 2022-06-12 01:27:51.131996
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed=8, locale='en')
    assert address.address() == '13, North Cade'

    address = Address(seed=8, locale='ko')
    assert address.address() == '아터너어티 1-2-3'

    address = Address(seed=8, locale='ja')
    assert address.address() == '小出町区17-18-19'

    address = Address(seed=8, locale='pl')
    assert address.address() == 'Sokole 5'

# Generated at 2022-06-12 01:27:53.699047
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    address = Address()
    add_ = address.address()
    assert isinstance(add_, str)
    assert len(add_) > 0
    assert add_ == address.address()


# Generated at 2022-06-12 01:27:56.342835
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    a = Address.Factory().create(locale='en')
    a.country_code(CountryCode.A3)
    a.address()


# Generated at 2022-06-12 01:28:01.451568
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert (
        a.address().lower()
        in ['{0} {1}'.format(a.street_number(), a.street_name()),
            '{0} {1}'.format(a.street_number(),
                             a.street_name() + a.street_suffix())])


# Generated at 2022-06-12 01:28:05.124037
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    address = Address()
    address_ = address.address()
    assert isinstance(address_, str)
    assert len(address_) > 0



# Generated at 2022-06-12 01:28:07.600833
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    address = Address()
    assert address.address()


# Generated at 2022-06-12 01:28:10.178177
# Unit test for method address of class Address
def test_Address_address():
    """Test the results of method address of class Address."""
    assert Address('en').address()
    assert Address('ja').address()
    assert Address('es').address()


# Generated at 2022-06-12 01:28:27.355578
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()  # Should return address


# Generated at 2022-06-12 01:28:31.548403
# Unit test for method address of class Address
def test_Address_address():
    address1 = Address()
    address2 = Address(locale='ru')
    address3 = Address(locale='ja')

    assert address1.address() != None
    assert address2.address() == '{}, {}'
    assert address3.address() == '{}{}{}-{}-{} {}{}'

# Generated at 2022-06-12 01:28:33.172219
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert result is not None



# Generated at 2022-06-12 01:28:35.178064
# Unit test for method address of class Address
def test_Address_address():
    result = Address(locale='en').address()
    assert result == Address(locale='en').address()



# Generated at 2022-06-12 01:28:38.880943
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    #print(addr.address())
    assert addr.address() == '1, 蜂巣北郵便番号：238-0012'


# Generated at 2022-06-12 01:28:49.595964
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import AddressFormats

    a = Address(locale='en')
    fmt = a._data['address_fmt']

    # fmt: off
    addresses = [
        AddressFormats.DEFAULT,
        AddressFormats.FANCY,
        AddressFormats.FULL,
        AddressFormats.SHORT,
    ]
    # fmt: on

    for fmt in addresses:
        if fmt is AddressFormats.DEFAULT:
            expected = a.address()
        elif fmt is AddressFormats.FANCY:
            expected = a.address(fmt=AddressFormats.FANCY)
        elif fmt is AddressFormats.FULL:
            expected = a.address(fmt=AddressFormats.FULL)

# Generated at 2022-06-12 01:28:51.522393
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() == '10 Kimberly Plains Suite 538'


# Generated at 2022-06-12 01:28:53.649960
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    street_name = a.street_name()
    # we must verify the address include the street_name
    assert street_name in a.address()

# Generated at 2022-06-12 01:28:57.406487
# Unit test for method address of class Address
def test_Address_address():
    class A(Address):
        def __init__(self, loc: str) -> None:
            super().__init__(loc)

    a = A('en')
    assert a.address() is not None
    assert a.address() != ''
    assert a.address() != a.address()
    assert isinstance(a.address(), str)

# Generated at 2022-06-12 01:29:07.079798
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    # Testing
    address = Address('ja')
    data = address.address()

    assert isinstance(data, str)
    assert data.count('-') == 3
    assert data[-3].isdigit()

    address = Address('ru')
    data = address.address()

    assert isinstance(data, str)
    assert data[-1].isdigit()

    address = Address('en')
    data = address.address()

    assert isinstance(data, str)
    assert data[0].isdigit()
    assert data[2].isalpha()

    address = Address('ko')
    data = address.address()

    assert isinstance(data, str)
    assert data[0].isdigit()

# Generated at 2022-06-12 01:29:47.528664
# Unit test for method address of class Address
def test_Address_address():
    import pytest
    a = Address()
    assert a.address() is not None
    assert type(a.address()) == str
    with pytest.raises(Exception):
        assert a.address() is not 'abc'
        assert a.address() is not 123
        assert a.address() is not 123.456

# Generated at 2022-06-12 01:29:48.837733
# Unit test for method address of class Address
def test_Address_address():
    _ = Address()
    assert len(_.address()) > 0

# Generated at 2022-06-12 01:29:50.380022
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())


# Generated at 2022-06-12 01:29:53.549937
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address"""
    import re
    p = Address()
    result = p.address()
    assert isinstance(result, str)
    assert re.match(r"^\d{1,3}\s\w+\s\w+$", result) == None


# Generated at 2022-06-12 01:29:58.979489
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')

    # print(address.address())
    assert isinstance(address.address(), str)



# Generated at 2022-06-12 01:30:03.935998
# Unit test for method address of class Address
def test_Address_address():
    ad = Address('en')
    print('Random Address: ' + ad.address())
    print('Street number: ' + ad.street_number())
    print('Street name: ' + ad.street_name())
    print('Street suffix: ' + ad.street_suffix())


# Generated at 2022-06-12 01:30:06.174068
# Unit test for method address of class Address
def test_Address_address():
    # init Address
    addr = Address()
    # generate address
    addr.address()

# Generated at 2022-06-12 01:30:09.535929
# Unit test for method address of class Address
def test_Address_address():
    assert (80 < int(Address().street_number()) < 1400)
    assert Address().street_name()
    assert Address().street_suffix()
    assert Address().address()


# Generated at 2022-06-12 01:30:10.782577
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-12 01:30:15.181266
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    print(ad.address())  # "4752 Oxford Road"
    print(ad.address())  # "4908 Oxford Road"
    print(ad.address())  # "1487 Oxford Road"
    print(ad.address())  # "4817 Oxford Road"


# Generated at 2022-06-12 01:31:45.812593
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    result = address.address()
    assert type(result) == str


# Generated at 2022-06-12 01:31:48.043848
# Unit test for method address of class Address
def test_Address_address():
    name = "address"
    a = Address()
    result = a.address()
    assert len(result) >= 10
    assert type(result) is str
    print(name, ": ", result)


# Generated at 2022-06-12 01:31:59.990152
# Unit test for method address of class Address
def test_Address_address():
    import random  # 用于生成随机数
    seed = random.randint(1, 999)  # 随机数种子
    random.seed(seed)
    address = Address('zh')  # 实例化
    print(
        '随机数种子：', seed, '\n',
        '随机地址：', address.address(),
    )



# Generated at 2022-06-12 01:32:01.472100
# Unit test for method address of class Address
def test_Address_address():
    #Set the seed
    s = Address().seed(1)
    # Generate a random full address.
    s.address()


# Generated at 2022-06-12 01:32:02.578886
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())



# Generated at 2022-06-12 01:32:05.440219
# Unit test for method address of class Address
def test_Address_address():
    s = 'address'
    assert len(s) > 0

# Generated at 2022-06-12 01:32:07.137356
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    l = len(result)
    assert l > 1
    assert isinstance(result, str)

# Generated at 2022-06-12 01:32:09.437843
# Unit test for method address of class Address
def test_Address_address():
    # address
    add = Address()
    add.address()


# Generated at 2022-06-12 01:32:12.431218
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import Address
    instance = Address('zh')
    print(instance.address())
    print(instance.address())
    print(instance.address())
    print(instance.address())
    print(instance.address())


# Generated at 2022-06-12 01:32:13.223676
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())