

# Generated at 2022-06-12 01:24:58.942086
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers import Address

    # default
    address = Address('en')
    assert address.address() == "622 Sullivan Orchard"

    address = Address('pt-br')
    assert address.address() == "7872 Rua Zaire"

    address = Address('de')
    assert address.address() == "Friedrichstr. 807"

    address = Address('ru')
    assert address.address() == 'г. Москва, ул. Котовского, д. 7, кв. 474'

    address = Address('fr')
    assert address.address() == "9, place de la Liberation"

    address = Address('tr')

# Generated at 2022-06-12 01:25:00.661639
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address().split()[-1] == 'St.'

# Generated at 2022-06-12 01:25:03.703128
# Unit test for method address of class Address
def test_Address_address():
    n = 5
    addr = Address()
    for i in range(n):
        print(addr.address())


# Generated at 2022-06-12 01:25:07.983356
# Unit test for method address of class Address
def test_Address_address():
    """Check Address.address() function."""
    address = Address()

    full_address = address.address()
    assert full_address is not None

    # Check address format
    assert '{' not in full_address
    assert '}' not in full_address


# Generated at 2022-06-12 01:25:19.649260
# Unit test for method address of class Address
def test_Address_address():
	# name of method
	method_name = "address"
	# test for method address() of class Address
	# inputs for the method
	# address_fmt = '{st_num} {st_name} {st_sfx}'
	# street_number(maximum=1400)
	# street_name()
	# street_suffix()
	# output = {st_num} {st_name} {st_sfx}
	a = Address()
	addr = a.address() # {st_num} {st_name} {st_sfx}
	assert isinstance(addr, str) == True
	# test for method address() of class Address
	# inputs for the method
	# address_fmt = '{st_num} {st_name} {st_sfx}'
	# street_number

# Generated at 2022-06-12 01:25:21.288838
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    address = add.address()
    if address == "":
        assert False
    else:
        assert True


# Generated at 2022-06-12 01:25:32.568024
# Unit test for method address of class Address
def test_Address_address():
    # Test for method address of class Address
    for _ in range(100):
        # Test for address (without street)
        a = Address()
        address = ' '.join([a.street_number(), a.street_name()])
        assert a.address() in address
        # Test for address (with street)
        if a.locale not in SHORTENED_ADDRESS_FMT:
            assert a.address() in ' '.join([a.street_number(), a.street_name(), a.street_suffix()])
        # Test for russian address
        if a.locale == 'ru':
            assert len(a.address()) in [15,16,17,18]
        # Test for address for locale in SHORTENED_ADDRESS_FMT

# Generated at 2022-06-12 01:25:33.427189
# Unit test for method address of class Address
def test_Address_address():
    assert Address.address()


# Generated at 2022-06-12 01:25:39.704861
# Unit test for method address of class Address
def test_Address_address():
    from random import shuffle
    from mimesis.enums import Locale
    from mimesis.builtins import Address
    from mimesis.exceptions import NonEnumerableError
    from collections import Counter
    import os
    loc = os.environ.get('TZ', 'America/New_York')
    os.environ['TZ'] = 'UTC'

    a = Address(Locale.EN)
    addresses = []
    for i in range(100):
        addresses.append(a.address())

    shuffle(addresses)
    print(Counter(addresses))

    addresses = []
    for i in range(100):
        addresses.append(a.address())

    shuffle(addresses)
    print(Counter(addresses))
    countries = []

# Generated at 2022-06-12 01:25:42.749453
# Unit test for method address of class Address
def test_Address_address():
    address = Address("zh")
    print(address.address())
    print(address.address())
    print(address.address())
    print(address.address())
    print(address.address())


# Generated at 2022-06-12 01:25:48.984170
# Unit test for method address of class Address
def test_Address_address():
    add = Address(locale='en')
    for i in range(100):
        assert type(add.address()) == str


# Generated at 2022-06-12 01:25:59.185996
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert '19554' == address.street_number(19554)
    assert 'Moore Route' == address.street_name()
    assert 'Keller Knoll' == address.street_name()
    assert 'freeway' == address.street_name()
    assert 'Glen' == address.street_name()
    assert 'Park' == address.street_name()
    assert 'Mall' == address.street_name()
    assert 'Grove' == address.street_name()
    assert 'Turnpike' == address.street_name()
    assert 'Way' == address.street_name()
    assert 'Drive' == address.street_name()
    assert 'Lane' == address.street_name()
    assert 'Road' == address.street_name()

# Generated at 2022-06-12 01:26:01.134778
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(f"address(): {address.address()}")

# Generated at 2022-06-12 01:26:03.998716
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    a = address.address()
    assert isinstance(a, str)
    assert len(a) > 0
    print("Address:", a)


# Generated at 2022-06-12 01:26:08.135114
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    pin = address.postal_code()
    result = address.address()
    if result[0] == pin[0]:
        print("test_Address_address of Address is passed!")
    else:
        print("test_Address_address of Address is failed!")


# Generated at 2022-06-12 01:26:09.118376
# Unit test for method address of class Address
def test_Address_address():
    assert Address('en').address() == '122 Green Street'

# Generated at 2022-06-12 01:26:19.134175
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Locale

    a = Address(Locale.EN)
    assert isinstance(a, BaseDataProvider) is True
    assert a._validate_locale() is None
    assert isinstance(a.address(), str)
    assert isinstance(a.address(allow_random=True), str)

    a = Address(Locale.RU, RussiaSpecProvider)
    assert isinstance(a, BaseDataProvider) is True
    assert isinstance(a.address(), str)
    assert a._validate_locale() is None
    assert isinstance(a.address(allow_random=True), str)


# Generated at 2022-06-12 01:26:21.063156
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    addr = a.address()
    assert isinstance(addr, str)


# Generated at 2022-06-12 01:26:23.248087
# Unit test for method address of class Address
def test_Address_address():
    a = Address('de')
    # assert a.address()
    assert type(a.address(allow_random=True)) == str


# Generated at 2022-06-12 01:26:32.655907
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address"""
    from mimesis import Address
    # Create an instance of class Address with seed value = 1
    address = Address()
    # Create an instance of class Address with seed value = 2
    address_ = Address(seed = 2)
    # This method will always return the same value for the same seed
    assert address.address() == address_.address()
    assert address.address() == '2436 Euclid Ave'
    # Change the seed value
    address.seed(3)
    # Check that the address result is now different to the first one
    assert address.address() != '2436 Euclid Ave'
    # The result of the method will depend on the current locale
    address.seed(3)
    assert address.address() == '2436 Euclid Ave'
    address = Address('ru')

# Generated at 2022-06-12 01:26:39.494415
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(locale=Locale.EN)
    assert callable(address.address) == True
    assert address.address() != ""

# Generated at 2022-06-12 01:26:41.241860
# Unit test for method address of class Address
def test_Address_address():
    result = Address(locale="ua").address()
    assert result is not None


# Generated at 2022-06-12 01:26:45.740779
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.utils.decorators import seed
    from mimesis.providers import Address
    a = Address('en')
    # The value was randomly generated with a certain seed.
    assert a.address() == '1218 Blanche Street'

# Generated at 2022-06-12 01:26:49.034033
# Unit test for method address of class Address
def test_Address_address():
    fix_adrs = '2 Rue de la Gare, 78140, Vélizy-Villacoublay, France'
    assert [Address().address() for _ in range(1000)].count(fix_adrs) > 0

# Generated at 2022-06-12 01:26:53.333824
# Unit test for method address of class Address

# Generated at 2022-06-12 01:26:54.682288
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed=12345)
    expected = '5924 Pine Street'
    assert address.address() == expected

# Generated at 2022-06-12 01:26:57.894121
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    street = a.street_name() + ' ' + a.street_number() + ' ' + a.street_suffix()
    assert a.address() == f'{street}\n' + a.city() + ', ' + a.state()
    assert a.address() != f'{street}\n{street}'


# Generated at 2022-06-12 01:27:01.526305
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    from mimesis.exceptions import NoMatchFoundError

    try:
        assert address.address()
    except NoMatchFoundError:
        assert False

    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

# Generated at 2022-06-12 01:27:02.061652
# Unit test for method address of class Address
def test_Address_address():
    pass

# Generated at 2022-06-12 01:27:05.717112
# Unit test for method address of class Address
def test_Address_address():
    """Check Address.address method."""
    address = Address(locale='en')
    result = address.address()
    assert result  # is not None


# Generated at 2022-06-12 01:27:11.497296
# Unit test for method address of class Address
def test_Address_address():
    a=Address()
    # print(dir(a))
    print(a.address())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-12 01:27:12.795342
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()        
    

# Generated at 2022-06-12 01:27:15.297609
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address("th")
    result = address_obj.address()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:27:26.653322
# Unit test for method address of class Address

# Generated at 2022-06-12 01:27:28.983668
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    addr = a.address()
    assert isinstance(addr, str)


# Generated at 2022-06-12 01:27:30.076405
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert "{" in address.address()

# Generated at 2022-06-12 01:27:39.119515
# Unit test for method address of class Address
def test_Address_address():
    assert Address(random_state=0).address() == '6956 Rue Du Bono\nNoumea, 98800'
    assert Address(random_state=5).address() == '521 Rue De La Deniere\nNoumea, 98807'
    assert Address(random_state=10).address() == '9063 Chemin Du Beaupre\nNoumea, 98802'
    assert Address(random_state=15).address() == '9284 Rue De L\'Eglantine\nNoumea, 98801'
    assert Address(random_state=20).address() == '8606 Chemin De La Charite\nNoumea, 98808'
    assert Address(random_state=25).address() == '8236 Rue De La Bruyere\nNoumea, 98804'
   

# Generated at 2022-06-12 01:27:42.346132
# Unit test for method address of class Address
def test_Address_address():
    a1 = Address()
    l = a1.address()
    assert l, 'Failed Address.address()'
    print('Passed Address.address()')

# Generated at 2022-06-12 01:27:49.397966
# Unit test for method address of class Address
def test_Address_address():
    # TODO: write test for method address of class Address
    print('Test address_fmt:')

    # de:
    # st_num = 1
    # st_name = "Musterstraße"
    # st_sfx = "Straße"
    # city = "Musterstadt"
    # postal_code = "01234"
    # country = "Deutschland"
    # result = "Musterstraße 1, 01234 Musterstadt, Deutschland"

    addr = Address(locale='it')
    print(addr.address())


# Generated at 2022-06-12 01:27:57.081311
# Unit test for method address of class Address
def test_Address_address():
    obj = Address('en')
    # print(obj.address())
    # print(obj.address())
    # print(obj.city())
    # print(obj.address())
    # print(obj.street_name())
    # print(obj.street_suffix())
    # print(obj.address())
    # print(Address.address())
    # print(obj.coordinates())
    # print(obj.coordinates())
    # print(obj.continent())
    # print(obj.calling_code())
    # print(obj.calling_code())
    # print(obj.calling_code())
    # print(obj.calling_code())
    # print(obj.calling_code())
    # print(obj.calling_code())
    # print(obj.calling_code())
    # print(obj.calling

# Generated at 2022-06-12 01:28:08.132031
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    test_address =address.address()
    print('test_Address_address:', test_address)



# Generated at 2022-06-12 01:28:09.830977
# Unit test for method address of class Address
def test_Address_address():
    test_object = Address('tr')
    assert len(test_object.address()) >= 7


# Generated at 2022-06-12 01:28:11.355931
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address)
    print(address.address())


# Generated at 2022-06-12 01:28:12.480189
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result



# Generated at 2022-06-12 01:28:14.124206
# Unit test for method address of class Address
def test_Address_address():
    instance = Address()
    results = instance.address()
    assert results is not None


# Generated at 2022-06-12 01:28:18.563941
# Unit test for method address of class Address
def test_Address_address():
    # test Address().address()
    assert Address().address() != ''
    assert Address().address()[-1] in '0123456789'
    assert len(Address().address().split()) >= 2


# Generated at 2022-06-12 01:28:19.965725
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-12 01:28:23.741706
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = Address(locale='en')
    assert a.address() != ''
    a.seed(1)
    assert a.address() == '3 Howard Center'



# Generated at 2022-06-12 01:28:33.934825
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.street_number())
    print(address.street_name())
    print(address.street_suffix())
    print(address.address())
    print(address.state())
    print(address.region())
    print(address.province())
    print(address.federal_subject())
    print(address.prefecture())
    print(address.postal_code())
    print(address.zip_code())
    print(address.country_code())
    print(address.country())
    print(address.city())
    print(address.latitude())
    print(address.longitude())
    print(address.coordinates())
    print(address.continent())
    print(address.calling_code())


if __name__ == '__main__':
    test_Address

# Generated at 2022-06-12 01:28:35.249197
# Unit test for method address of class Address
def test_Address_address():
    addressProvider = Address()
    assert addressProvider.address() != ""

# Generated at 2022-06-12 01:28:52.340537
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    addr = a.address()
    assert isinstance(addr, str)

# Generated at 2022-06-12 01:28:52.886143
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()

# Generated at 2022-06-12 01:28:55.157469
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import Random

    if Random().address() :
        print("Get a random full address.")
    else:
        print("Empty field")


# Generated at 2022-06-12 01:29:04.167365
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.localization import DEFAULT_ADDRESS_FORMAT, DEFAULT_LOCALE
    from mimesis.localization import DEFAULT_SHORT_ADDRESS_FORMAT
    from mimesis.localization import NAMES_LOCALES, STREET_LOCALES
    from mimesis.typing import AddressType, LocaleType

    address = Address(DEFAULT_LOCALE)
    assert isinstance(address.address(), AddressType)
    assert isinstance(address.address(), str)


# Generated at 2022-06-12 01:29:07.215631
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    for i in range(100):
        a.address()
    # Test for method: address of class: Address
    assert len(a.address()) > 0

# Generated at 2022-06-12 01:29:10.261746
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address import Address
    a = Address(RussiaSpecProvider())
    result = a.address()
    assert result != None

# Generated at 2022-06-12 01:29:11.871214
# Unit test for method address of class Address
def test_Address_address():
    for _ in range(5):
        a = Address()
        assert a.address()


# Generated at 2022-06-12 01:29:13.940425
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for i in range(1,50):
        print(address.address())

# Generated at 2022-06-12 01:29:16.178256
# Unit test for method address of class Address
def test_Address_address():
    adr = Address('en')
    print(adr.address())
    print(adr.address())
    print(adr.address())
    print(adr.address())


# Generated at 2022-06-12 01:29:24.476711
# Unit test for method address of class Address
def test_Address_address():
    a = Address('ru')

# Generated at 2022-06-12 01:30:04.927547
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis import Address
    address = Address(Locale.EN)
    result = address.address()
    assert result == "1418 W. Chive Web"

# Generated at 2022-06-12 01:30:08.584770
# Unit test for method address of class Address
def test_Address_address():
    ua_address = Address('uk')
    address = ua_address.address()
    assert address is not None
    assert isinstance(address, str)
    assert address != ''
    assert ' ' in address
    assert ',' in address


# Generated at 2022-06-12 01:30:09.223313
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address()


# Generated at 2022-06-12 01:30:10.510147
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert 'address' in a.address()


# Generated at 2022-06-12 01:30:12.758185
# Unit test for method address of class Address
def test_Address_address():
    """Testing the address method of the Address class."""
    a = Address()
    assert isinstance(a.address(), str)

# Generated at 2022-06-12 01:30:14.847962
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import Address
    a = Address('en')
    assert a.address() != a.address()


# Generated at 2022-06-12 01:30:16.687063
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for address() method

    :return: None
    """
    address = Address('en')
    print(address.address())


# Generated at 2022-06-12 01:30:20.694693
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    results = set()
    for i in range(0, 5):
        results.add(address.address())
    assert len(results) == 5

# Generated at 2022-06-12 01:30:23.553961
# Unit test for method address of class Address
def test_Address_address():
    Address().address()
    Address().address()
    Address().address()
    Address().address()


# Generated at 2022-06-12 01:30:25.811428
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en')
    res = a.address()
    assert isinstance(res, str) is True
    assert len(res) > 0



# Generated at 2022-06-12 01:31:59.990109
# Unit test for method address of class Address
def test_Address_address():
    from master.data.address import Address
    from mimesis.enums import Gender

    address = Address(gender=Gender.FEMALE)

    streetName = address.street_name()
    streetNumber = address.street_number()
    
    finalAddress = address.address()

    assert finalAddress.find(streetName) > 0
    assert finalAddress.find(streetNumber) > 0

# Generated at 2022-06-12 01:32:01.203779
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    result = address.address()
    assert result != ''
    assert len(result) > 0

# Generated at 2022-06-12 01:32:05.845531
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    ad = Address(locale=Locale.EN)
    res = ad.address()
    print('Address:{}'.format(res))
    assert len(res)>0
    assert isinstance(res,str)


# Generated at 2022-06-12 01:32:08.453094
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address().split()[0] in map(str, range(1401))


# Generated at 2022-06-12 01:32:15.990995
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import AddressFormats

    adr = Address()

    # Check if this street name has letters only.
    assert adr.street_name().replace(' ', '').isalpha() is True

    # Check if this street name is not empty.
    assert adr.street_name()  # noqa: S001

    # Check if this street suffix has letters only.
    assert adr.street_suffix().replace(' ', '').isalpha() is True

    # Check if this street suffix is not empty.
    assert adr.street_suffix()  # noqa: S001

    # Check if this street number has digits only.
    assert adr.street_number().replace(' ', '').isdigit() is True

    # Check if this street number is not empty.
    assert adr.street_number() 

# Generated at 2022-06-12 01:32:19.571078
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    addr = address.address()

    assert len(addr.split(' ')) == 4


# Generated at 2022-06-12 01:32:26.610143
# Unit test for method address of class Address
def test_Address_address():
  from mimesis.enums import Gender
  from mimesis.providers.address import Address
  from mimesis.providers.person import Person
  from mimesis.providers.phone import Phone

  p = Person('en')
  address = Address('en')
  phone = Phone('en')
  print(address.address())
  print(p.full_name(gender=Gender.FEMALE))
  print(phone.phone_number())


# Generated at 2022-06-12 01:32:27.728668
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)


# Generated at 2022-06-12 01:32:28.928050
# Unit test for method address of class Address
def test_Address_address():
    pass


# Generated at 2022-06-12 01:32:40.488957
# Unit test for method address of class Address
def test_Address_address():
    # Initialize the object Address
    a = Address('zh')

    # Return the street number
    result = a.street_number()
    assert result is not None

    # Return the street name
    result = a.street_name()
    assert result is not None

    # Return the street suffix
    result = a.street_suffix()
    assert result is not None

    # Return the full address
    result = a.address()
    assert result is not None

    # Return the state
    result = a.state()
    assert result is not None

    # Return the postal code
    result = a.postal_code()
    assert result is not None

    # Return the country code
    result = a.country_code(CountryCode.A2)
    assert result is not None

    # Return the country
    result = a.country