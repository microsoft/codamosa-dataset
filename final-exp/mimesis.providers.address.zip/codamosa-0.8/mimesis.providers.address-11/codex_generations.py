

# Generated at 2022-06-12 01:24:53.301973
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)
    assert len(a.address()) > 0


# Generated at 2022-06-12 01:24:55.297031
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr = address.address()
    assert isinstance(addr, str)


# Generated at 2022-06-12 01:25:07.086606
# Unit test for method address of class Address
def test_Address_address():
    import pytest
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    _a = Address(locale=Locale.EN)
    st_num = _a.street_number()
    st_name = _a.street_name()
    st_sfx = _a.street_suffix()


# Generated at 2022-06-12 01:25:08.792484
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())



# Generated at 2022-06-12 01:25:14.205983
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix()
    )

# Generated at 2022-06-12 01:25:16.704481
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('en')
    assert provider.address() == '561 Wadsworth Street Suite 566'



# Generated at 2022-06-12 01:25:25.324276
# Unit test for method address of class Address
def test_Address_address():
    # Arrange
    address = Address()

    # Act
    street_name = address.street_name()
    suffix = address.street_suffix()
    street_num = address.street_number()
    full_address = address.address()

    # Assert
    street_name_value = len(address._data['street']['name']) > 0
    street_suffix_value = len(address._data['street']['suffix']) > 0
    assert street_name_value
    assert street_suffix_value
    assert street_name in full_address
    assert suffix in full_address
    assert street_num in full_address



# Generated at 2022-06-12 01:25:26.259549
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()

# Generated at 2022-06-12 01:25:27.735978
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '100 Sycamore Ave'

# Generated at 2022-06-12 01:25:36.814630
# Unit test for method address of class Address
def test_Address_address():
    # Generate street_number
    # '713'
    print(Address().street_number())
    # '433'
    print(Address().street_number(maximum=500))

    # Generate street_name
    # 'Berkley'
    print(Address().street_name())

    # Generate street_suffix
    # 'Throughway'
    print(Address().street_suffix())

    # Generate address
    # '713 Corbin Avenue'
    print(Address().address())

    # Generate state
    # 'Missouri'
    print(Address().state())
    # 'MO'
    print(Address().state(abbr=True))

    # Generate region
    # 'Minnesota'
    print(Address().region())
    # 'MN'
    print(Address().region(abbr=True))



# Generated at 2022-06-12 01:25:45.224790
# Unit test for method address of class Address
def test_Address_address():
    try:
        a = Address()
        assert type(a.address()) == str
    except AssertionError:
        raise AssertionError



# Generated at 2022-06-12 01:25:57.347901
# Unit test for method address of class Address
def test_Address_address():
    """Test for Address.address().

    Checks if the method works correctly
    and returns the type str.
    """
    from mimesis.schema import Field
    from mimesis.enums import Gender

    provider = Address('en')

# Generated at 2022-06-12 01:25:58.676537
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str

# Generated at 2022-06-12 01:26:00.689415
# Unit test for method address of class Address
def test_Address_address():
    var = Address()
    assert var.address() is not None



# Generated at 2022-06-12 01:26:02.050256
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) > 0
    assert Address().address() != Address().address()

# Generated at 2022-06-12 01:26:05.266969
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()

    address = addr.address()

    result = addr.format(SHORTENED_ADDRESS_FMT, addr._data['address_fmt'])

    assert address in result


# Generated at 2022-06-12 01:26:07.503577
# Unit test for method address of class Address
def test_Address_address():
    # Positive testing
    a = Address()
    assert a.address() is not None
    assert a.address() is not ""
    assert a.address().count(' ') > 1

    # Negative testing
    a = Address(locale="wrong")
    assert a.address() is not None
    assert a.address() is not ""
    assert a.address().count(' ') == 0


# Generated at 2022-06-12 01:26:08.520526
# Unit test for method address of class Address
def test_Address_address():
    # Address().address()
    pass


# Generated at 2022-06-12 01:26:12.397414
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    result = address.address()
    assert isinstance(result, str)
    assert not result.endswith(tuple(['.']))


# Generated at 2022-06-12 01:26:13.830058
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    print(address)

# Generated at 2022-06-12 01:26:23.383302
# Unit test for method address of class Address
def test_Address_address():
    address = Address("zh")
    result = address.address()
    assert result == "396 高地口道" or result == "1130 拉米克街"


# Generated at 2022-06-12 01:26:25.771183
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    for _ in range(100):
        print(adr.address())



# Generated at 2022-06-12 01:26:33.793871
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address('ru')
    assert address.address() == "улица Комсомольская, дом 42"
    assert address.address() == "улица Авиационная, дом 35"
    assert address.address() == "улица Богдана Хмельницкого, дом 4"
    assert address.address() == "улица Павлика Морозова, дом 71"

# Generated at 2022-06-12 01:26:36.091380
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""    
    address = Address('en')
    print(address.address())

# Generated at 2022-06-12 01:26:38.052795
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())



# Generated at 2022-06-12 01:26:39.444565
# Unit test for method address of class Address
def test_Address_address():
    l = Address()
    assert type(l.address()) is str

# Generated at 2022-06-12 01:26:40.382406
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != Address().address()

# Generated at 2022-06-12 01:26:47.367933
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import address as addr
    import re
    a = addr.Address()
    s = a.address()
    assert(s!=u'')
    assert(s!=u' ')
    assert(s!=u'  ')
    assert(s!=u'   ')
    assert(s!=None)
    assert(s!='')
    assert(s!=' ')
    assert(s!='  ')
    assert(s!='   ')
    assert(s!=None)
    assert(s!=0)
    assert(s!=1)
    assert(s!=-1)
    assert(s!=-2)
    assert(s!=-3)
    assert(s!=-4)
    assert(s!=-5)

# Generated at 2022-06-12 01:26:48.746763
# Unit test for method address of class Address
def test_Address_address():
    assert Address('en').address() != Address('es').address()
    assert Address('en').address() != ''
    assert Address('ru').address() != ''
    assert Address('jp').address() != ''


# Generated at 2022-06-12 01:26:51.326799
# Unit test for method address of class Address
def test_Address_address():
    obj = Address('en')

    assert obj.address().startswith('{} {} {}'.format(obj.street_number(), obj.street_name(), obj.street_suffix()))


# Generated at 2022-06-12 01:26:59.604710
# Unit test for method address of class Address
def test_Address_address():
    assert type(Address().address()) == str



# Generated at 2022-06-12 01:27:11.456384
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis import Address
    from mimesis.builtins import RussiaSpecProvider

    address = Address(RussiaSpecProvider)
    result1 = address.address()
    result2 = address.address()
    result3 = address.address()
    result4 = address.address()
    result5 = address.address()
    result6 = address.address()
    result7 = address.address()
    result8 = address.address()
    result9 = address.address()
    result10 = address.address()
    result11 = address.address()
    result12 = address.address()
    result13 = address.address()

# Generated at 2022-06-12 01:27:13.090219
# Unit test for method address of class Address
def test_Address_address():
    # Test return an address with default locale
    assert Address.address() != ''


# Generated at 2022-06-12 01:27:14.182963
# Unit test for method address of class Address
def test_Address_address():
    # todo: add unit test for method address of class Address
    assert True==True

# Generated at 2022-06-12 01:27:17.893959
# Unit test for method address of class Address
def test_Address_address():
    i = 1
    while i<3:
        i += 1
        a = Address()
        #print(a.address())
        assert a.address() is not None


# Generated at 2022-06-12 01:27:19.474043
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('en')
    address = provider.address()
    assert isinstance(address, str)



# Generated at 2022-06-12 01:27:22.416891
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address()
    assert address.address()
    assert address.address()


# Generated at 2022-06-12 01:27:27.453612
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert address.address() != ''
    assert address.address() != None
    assert address.street_name() != ''
    assert address.street_name() != None
    assert address.street_number() != ''
    assert address.street_number() != None
    assert address.street_suffix() != ''
    assert address.street_suffix() != None


# Generated at 2022-06-12 01:27:33.814985
# Unit test for method address of class Address
def test_Address_address():
    import random
    from Address import Address
    from mimesis.enums import CountryCode
    a = Address(random.randrange(1, 100), 'zh')
    print(a.street_name())
    print(a.street_suffix())
    print(a.street_number())
    print(a.postal_code())
    print(a.zip_code())
    print(a.address())
    print(a.province())
    print(a.province(True))
    print(a.federal_subject())
    print(a.federal_subject(True))
    print(a.prefecture())
    print(a.prefecture(True))
    print(a.region())
    print(a.region(True))
    print(a.state())
    print(a.state(True))

# Generated at 2022-06-12 01:27:35.042364
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    res = address.address()
    assert isinstance(res, str)
    assert ' ' in res
    assert len(res) >= 5
    assert len(res) <= 50


# Generated at 2022-06-12 01:27:49.633597
# Unit test for method address of class Address
def test_Address_address():
    assert type(Address().address()) == str
    assert Address().address() == '977 Walton Neck'

# Generated at 2022-06-12 01:27:51.772900
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    addr = Address()
    assert type(addr.address()) == str


# Generated at 2022-06-12 01:27:58.296761
# Unit test for method address of class Address
def test_Address_address():
    from pytest import raises
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.exceptions import NonEnumerableError
    from mimesis.utils import get_locale

    ad = Address(locale=get_locale())

    pattern = r'^(\d+\s)?\w+\s?\w*\.?$'
    result = ad.address()

    assert result != ''
    assert result is not None
    assert result != ' '
    assert type(result) is str
    assert isinstance(result, str)
    assert result != []
    assert result != ()
    assert result != {}

    assert ad.address(pattern=pattern)
    assert ad.address(pattern=pattern)
    assert ad.address(pattern=pattern)

    #

# Generated at 2022-06-12 01:28:00.843735
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result == '1020 rue Pecq'


# Generated at 2022-06-12 01:28:06.116233
# Unit test for method address of class Address
def test_Address_address():
    """ Unit test for method address of class Address """
    from mimesis.providers.address import Address
    # Init the class Address
    address = Address('en')
    # Call the method address
    result = address.address()
    assert isinstance(result, str)
    assert len(result) > 1



# Generated at 2022-06-12 01:28:07.443460
# Unit test for method address of class Address
def test_Address_address():
    pass


# Generated at 2022-06-12 01:28:10.599542
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()                                  # [Out]: "123 Easy St"
    address.address()                                  # [Out]: "6538 Brickson Park"
    address.address()                                  # [Out]: "982 Elka St"

# Generated at 2022-06-12 01:28:13.776456
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import JapanSpecProvider
    adr = Address()
    assert isinstance(adr.address(), str)
    jp = JapanSpecProvider()
    assert isinstance(jp.address(), str)


if __name__ == "__main__":
    print(Address().address())

# Generated at 2022-06-12 01:28:25.852692
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.data import (
        STATES,
        USA_POSTAL_CODE_FORMAT,
    )
    from mimesis.enums import CountryCode

    city = 'Philadelphia'
    street_num = '12'
    street_name = 'Main'
    street_sfx = 'Street'
    state = 'NY'
    country = 'United States of America'
    postal_code_fmt = USA_POSTAL_CODE_FORMAT
    country_code = CountryCode.A2.value

    a = Address('en')
    assert a.street_number() in {str(i) for i in range(1, 1400)}
    assert a.street_name() in a.street_name.__annotations__['return']
    assert a.street_suffix() in a.street_suffix.__

# Generated at 2022-06-12 01:28:30.006246
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    a = Address('fr')
    assert "Rue de la Gare" in a.address()
    assert "Beschornerstraße" in a.address('de')
    assert "Main St" in a.address('ru')
    assert "Beschornerstraße" in a.address()


# Generated at 2022-06-12 01:29:06.620459
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '448 Sherwood Groves'
    assert Address().address() == '3556 Jardine Trail'
    assert Address().address() == '73303 Hoff Ridge'
    assert Address().address() == '9855 Karolann Circle'
    assert Address().address() == '446 Leland Terrace'
    assert Address().address() == '70434 Malinda Causeway'
    assert Address().address() == '05442 Rosenbaum Lane'
    assert Address().address() == '5010 Bernhard Road'
    assert Address().address() == '2373 Lehner Way'
    assert Address().address() == '7374 Janet Extension'


# Generated at 2022-06-12 01:29:08.820276
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address()."""
    a = Address()
    res = a.address()
    assert len(res) >= 10



# Generated at 2022-06-12 01:29:10.910013
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '567 Montauk Court, Apt. 431'

# Generated at 2022-06-12 01:29:20.566974
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())
    print(a.street_name())
    print(a.postal_code())
    print(a.country_code())
    print(a.city())
    print(a.state())
    print(a.region())
    print(a.province())
    print(a.federal_subject())
    print(a.prefecture())
    print(a.zip_code())
    print(a.country())
    print(a.country(True))
    print(a.coordinates())
    print(a.continent())
    print(a.continent(code=True))
    print(a.calling_code())
    print(a.latitude())
    print(a.longitude())

if __name__ == "__main__":
    test

# Generated at 2022-06-12 01:29:21.899017
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    address = provider.address()

    assert address is not None


# Generated at 2022-06-12 01:29:23.499960
# Unit test for method address of class Address
def test_Address_address():
    provider = Address("en")
    address = provider.address()
    assert type(address) == str and len(address) > 0



# Generated at 2022-06-12 01:29:28.091807
# Unit test for method address of class Address
def test_Address_address():
    # Make sure we're using the default locale.
    from mimesis.enums import Locale
    from mimesis.localization import set_locale
    set_locale(Locale.EN)
    from mimesis.address import Address
    myAddress = Address()
    stNum = myAddress.street_number()
    stName = myAddress.street_name()
    stSfx = myAddress.street_suffix()
    address = myAddress.address()
    fmt = r'{}, {}, {}, {}'
    assert address == fmt.format(stNum, stName, stSfx, myAddress.city())

# unit test for method state of class Address

# Generated at 2022-06-12 01:29:31.908193
# Unit test for method address of class Address
def test_Address_address():
    address = Address("en")
    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()
    assert address.address() == f"{st_num} {st_name} {st_sfx}"


# Generated at 2022-06-12 01:29:34.247157
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(locale=Locale.EU)
    result = address.address()
    assert result is not None

# Generated at 2022-06-12 01:29:41.775456
# Unit test for method address of class Address
def test_Address_address():                                                  
    from mimesis.enums import Gender                                          
    # 下記のようにインスタンスを生成               
    ad = Address('ja')                                                        
    # 下記のように使用                                                        
    ad.address()                                                              
                                                                             

# Generated at 2022-06-12 01:30:48.858538
# Unit test for method address of class Address
def test_Address_address():
    assert Address('en').address()  == '931 Main St'

if __name__ == "__main__":
    # Unit test
    test_Address_address()

# Generated at 2022-06-12 01:30:50.615063
# Unit test for method address of class Address
def test_Address_address():
    lol = Address('ru')
    assert LOL.address() == 'Западная Ulitsa, 7'


# Generated at 2022-06-12 01:30:53.596222
# Unit test for method address of class Address
def test_Address_address():
    # Generate 100000 random addresses
    for _ in range(100000):
        try:
            Address().address()
        except Exception as e:
            raise AssertionError(e) from e

# Generated at 2022-06-12 01:31:02.086622
# Unit test for method address of class Address
def test_Address_address():
    print("Running test for method address of class Address")

    # test locale 'ko'
    locale = "ko"
    ad = Address(locale=locale)
    result = ad.address()
    address_ko = result

    # test other locale
    locale = "en"
    ad = Address(locale=locale)
    result = ad.address()
    address_en = result


    # check if the address from locale 'ko' is different from the address from locale 'en'
    assert address_ko != address_en, "The address from locale 'ko' should be different from the address from locale 'en'"


# Generated at 2022-06-12 01:31:07.442146
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address"""
    obj = Address()
    a1 = obj.address()
    a2 = obj.address()
    assert a1 != a2

    a1 = obj.address()
    a2 = obj.address()
    assert a1 != a2


# Generated at 2022-06-12 01:31:10.876405
# Unit test for method address of class Address
def test_Address_address():
    provider = Address(local='ru')
    # TODO: Add negative test cases

    address = provider.address()
    assert address == 'пер, 11, Ленинский проспект'


# Generated at 2022-06-12 01:31:15.904818
# Unit test for method address of class Address
def test_Address_address():
    locale = 'zh'
    address = Address(locale)

    # 北京市朝阳区太平桥东里3号
    test_result = address.address()
    assert test_result == '北京市朝阳区太平桥东里3号'

# Generated at 2022-06-12 01:31:19.160740
# Unit test for method address of class Address
def test_Address_address():
    # Initialize instance of class Address
    address = Address('en')
    # Get the result of address method
    result = address.address()
    # Check returned value of method address
    assert result == '11004 Burgoyne Street'

# Generated at 2022-06-12 01:31:20.178393
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) > 0


# Generated at 2022-06-12 01:31:30.213986
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Country
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.address import Address

    address = Address('ru')
    _address = address.address()
    assert _address is not None
    assert isinstance(_address, str)

    with address.override_locale(Country.UNITED_STATES):
        assert address.address() != _address

    address = Address('en')
    _address = address.address()
    assert _address is not None
    assert isinstance(_address, str)

    with address.override_locale('unknown'):
        with pytest.raises(NonEnumerableError):
            address.address()
