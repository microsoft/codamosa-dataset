

# Generated at 2022-06-21 15:45:41.425558
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test method calling_code of class Address."""
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode

    address = Address()
    for i in range(100):
        code = address.calling_code()
        assert code and isinstance(code, str)
        assert code[0] == '+'



# Generated at 2022-06-21 15:45:42.533048
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None

# Generated at 2022-06-21 15:45:48.979565
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert Address().country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert Address().country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]

# Generated at 2022-06-21 15:45:50.348425
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address('en')
    assert address.continent() in CONTINENT_CODES

# Generated at 2022-06-21 15:45:53.458900
# Unit test for method country of class Address
def test_Address_country():
    # Check if the country of the current locale is equal to the country which
    # is in the dictionary of the locale.
    print(Address().country())


# Generated at 2022-06-21 15:45:55.581259
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    for i in range(10):
        ad = Address()
        assert not ad.prefecture() == ad._data['state']['name']


# Generated at 2022-06-21 15:45:57.694428
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Test Address.street_number()"""
    addr = Address()
    assert isinstance(addr.street_number(), str)


# Generated at 2022-06-21 15:46:03.653532
# Unit test for method region of class Address
def test_Address_region(): #TODO test retourne string bien type;
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(locale=Locale.FRANCE)
    # Valeur à tester
    region_str = address.region()

    # Valeurs attendus
    str_type = str
    # Assertions
    assert type(region_str) == str_type


# Generated at 2022-06-21 15:46:06.090247
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country() == 'France'
    assert a.country(allow_random=True) in a._data['country']['name']


# Generated at 2022-06-21 15:46:09.415666
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.builtins import EN
    from mimesis import Address

    address = Address(EN)
    assert (len(address.state(abbr=True)) == 2)
    assert (len(address.state()) > 2)


# Generated at 2022-06-21 15:46:17.322949
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr = Address.street_name()
    assert isinstance(addr, str)

# Generated at 2022-06-21 15:46:19.832805
# Unit test for method state of class Address
def test_Address_state():
    # Create a instance of Address object
    address = Address()
    # Call method state
    result = address.state()

    # Unit test assert
    assert(result)


# Generated at 2022-06-21 15:46:21.272369
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() >= -90
    assert Address().latitude() <= 90


# Generated at 2022-06-21 15:46:23.612518
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    assert Address().coordinates() == {
        'latitude': 33.39619,
        'longitude': 156.01172
    }

# Generated at 2022-06-21 15:46:25.326583
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert address.street_name()



# Generated at 2022-06-21 15:46:31.599664
# Unit test for method latitude of class Address
def test_Address_latitude():
    address= Address()
    a=address.latitude()
    assert a == (0.0,90.0)
    a=address.latitude(dms=True)

# Generated at 2022-06-21 15:46:33.140511
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    s=Address()
    print(s.street_suffix())



# Generated at 2022-06-21 15:46:36.070937
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    list = []
    i = 0
    while(i < 1000):
        address = Address()
        list.append(address.postal_code())
        i += 1
    print(list)



# Generated at 2022-06-21 15:46:38.257035
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert a.continent() in a._data['continent']

# Unit tests for method calling_code of class Address

# Generated at 2022-06-21 15:46:40.757772
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region(abbr=True)
    print(region)


# Generated at 2022-06-21 15:46:55.313954
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address.
    """

    code = Address(seed=1111).country_code()
    assert code == 'AT'
    assert len(code) == 2

    code = Address().country_code(fmt=CountryCode.A3)
    assert code == 'AFG'
    assert len(code) == 3

    code = Address().country_code(fmt=CountryCode.NUM)
    assert code == '004'
    assert len(code) == 3

    code = Address().country_code(fmt=CountryCode.CODE3_LIGHT)
    assert len(code) == 3
    assert code in CONTINENT_CODES

    code = Address().country_code(fmt=CountryCode.CODE3_DARK)
    assert len(code) == 3

# Generated at 2022-06-21 15:46:56.489000
# Unit test for constructor of class Address
def test_Address():
    obj = Address()
    assert(obj)

# Generated at 2022-06-21 15:47:00.369747
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Unit test for method longitude of class Address."""
    address = Address()
    assert address.longitude() <= 180
    assert address.longitude() >= -180


# Generated at 2022-06-21 15:47:09.789002
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import CountryCode
    addressGenerator = Address()
    assert all([type(addressGenerator.province(abbr=True)) is str, len(addressGenerator.province(abbr=True)) == 2])
    assert all([type(addressGenerator.province(abbr=False)) is str, len(addressGenerator.province(abbr=False)) > 0])
    assert all([type(addressGenerator.province(abbr=True, country=CountryCode.IT)) is str, len(addressGenerator.province(abbr=True, country=CountryCode.IT)) == 2])

# Generated at 2022-06-21 15:47:11.978793
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()

    country_code = a.calling_code()

    assert isinstance(country_code, str)
    assert len(country_code) == 3


# Generated at 2022-06-21 15:47:18.679777
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.providers.address import Address
    from mimesis.enums import Country
    from collections import Counter
    from itertools import islice

    # Create a object for class Address
    address = Address(Country.IRAN)

    def take(n, iterable):
        return list(islice(iterable, n))

    stats = Counter(take(1000000, address.street_number()))
    assert stats[address.street_number()] > 0
    assert isinstance(address.street_number(), str)


# Generated at 2022-06-21 15:47:21.000892
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address(locale='de')
    print(address.country_code())

# Generated at 2022-06-21 15:47:24.963789
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    address = Address('en')
    # address.zip_code() == address.postal_code()
    assert address.zip_code() == address.postal_code()


# Generated at 2022-06-21 15:47:29.855367
# Unit test for method country of class Address
def test_Address_country():
    """Class for test country() of class Address."""
    address = Address('en')
    result = address.country()
    assert result == 'United States'

    address = Address('ar')
    result = address.country()
    assert result == 'الصين'



# Generated at 2022-06-21 15:47:32.423916
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    assert address.federal_subject() in \
        address._data['state']['name']

# Generated at 2022-06-21 15:47:44.824009
# Unit test for method continent of class Address
def test_Address_continent():
    """Test method continent of class Address"""
    # Test instance of Address
    from mimesis.builtins import Address as Ad
    address = Ad('en')
    assert address.continent(code=True) in CONTI_CODE
    assert address.continent() in CONTI_NAME


# Generated at 2022-06-21 15:47:50.529816
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import DMSDirections
    for dms in (True, False):
        lat = Address().latitude(dms)
        lon = Address().longitude(dms)
        print(lat, lon, dms)
        if dms:
            assert lat.endswith(DMSDirections.NORTH)
            assert lon.endswith(DMSDirections.EAST)


# Generated at 2022-06-21 15:47:51.767353
# Unit test for method province of class Address
def test_Address_province():
    print(Address().province())


# Generated at 2022-06-21 15:47:53.148194
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    _Address = Address()
    _Address.street_suffix()

# Generated at 2022-06-21 15:47:55.946754
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import Regions
    
    a = Address(locale='en')
    result = a.state(abbr=True)
    assert result in QA_ZIPCODE_STATES


# Generated at 2022-06-21 15:47:57.660142
# Unit test for method province of class Address
def test_Address_province():
    address = Address(seed = 123456)
    assert address.province() == 'KY'


# Generated at 2022-06-21 15:47:58.931332
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-21 15:48:04.812584
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import Locale, CountryCode
    from mimesis.providers.address import Address

    russian_address = Address(Locale.RU)
    english_address = Address(Locale.EN)
    print(russian_address.federal_subject())
    print(english_address.federal_subject())
    print(russian_address.federal_subject(True))
    print(english_address.federal_subject(True))


# Generated at 2022-06-21 15:48:07.368285
# Unit test for method street_name of class Address
def test_Address_street_name():
    adr = Address('en')
    assert len(adr.street_name()) > 0


# Generated at 2022-06-21 15:48:09.095171
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert(type(address.street_number())==str)


# Generated at 2022-06-21 15:48:19.974942
# Unit test for method continent of class Address
def test_Address_continent():
    pass


# Generated at 2022-06-21 15:48:24.061192
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    prefecture = a.prefecture()
    assert prefecture
    assert isinstance(prefecture, str)
    assert prefecture in a._data['state']['name']


# Generated at 2022-06-21 15:48:27.304279
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Unit test for Address.zip_code()"""
    zip_code = Address().zip_code()
    assert type(zip_code) is str and len(zip_code) > 0

# Generated at 2022-06-21 15:48:30.956595
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Given
    a = Address()
    # When
    r = a.zip_code()
    # Then
    assert isinstance(r, str)
    assert r
    assert len(r) > 0


# Generated at 2022-06-21 15:48:32.584080
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    tester = Address()

    result = tester.street_suffix()
    assert result == 'Avenue'

# Generated at 2022-06-21 15:48:36.538768
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    from pytest import raises

    instance = Address('ru')
    assert instance.country_code(CountryCode.A2) == 'RU'
    assert instance.country_code(CountryCode.A3) == 'RUS'
    assert instance.country_code(CountryCode.NUM) == '643'

    with raises(KeyError):
        instance.country_code(0xDEAD)

# Generated at 2022-06-21 15:48:39.250236
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address('de').postal_code() != None
    assert Address('ja').postal_code() != None


# Generated at 2022-06-21 15:48:46.159132
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import CountryCode
    from mimesis.enums import Locale

    a = Address(Locale.EN, CountryCode.A2)
    # Should return a string
    assert isinstance(a.zip_code(), str)
    # Should be the same length as the format
    assert len(a.zip_code()) == len(a._data['postal_code_fmt'])



# Generated at 2022-06-21 15:48:49.760274
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Generate a random street suffix.
    :return: Street suffix.
    """
    add = Address()
    res = add.street_suffix()
    assert isinstance(res, str)


# Generated at 2022-06-21 15:48:51.694581
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert len(address.street_name()) > 0


# Generated at 2022-06-21 15:49:00.615301
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from random import choice
    l = ["+"+choice(CALLING_CODES), "+1"]
    a = Address()
    for i in range(100):
        assert a.calling_code() in l

# Generated at 2022-06-21 15:49:03.187458
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert len(a.region()) == 2 #check if length is 2 or not
    assert len(a.region(abbr=True)) == 2 #check if length is 2 or not


# Generated at 2022-06-21 15:49:05.276153
# Unit test for method street_name of class Address
def test_Address_street_name():
    # Initialize the Address class
    addr = Address()

    # Get street name
    street_name = addr.street_name()

    # Check the result
    assert isinstance(street_name, str)

# Generated at 2022-06-21 15:49:06.681486
# Unit test for method street_number of class Address
def test_Address_street_number():
    addr=Address()
    for i in range(100):
        a = addr.street_number()
        print(a)


# Generated at 2022-06-21 15:49:09.151860
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    result = address.street_suffix()
    print(result)



# Generated at 2022-06-21 15:49:16.594681
# Unit test for method country of class Address
def test_Address_country():
    address1 = Address()
    address2 = Address(locale='es')
    address3 = Address(locale='en')
    address4 = Address(locale='ja')
    address5 = Address(locale='zh')

    expect = '中國'
    actual = address1.country(allow_random=True)

    assert len(expect) == len(actual)
    assert actual in ('中國', '日本')

    assert address2.country() == 'España'
    assert address3.country() == 'USA'
    assert address4.country() == '日本'
    assert address5.country() == '中国'

# Generated at 2022-06-21 15:49:17.962805
# Unit test for method street_number of class Address
def test_Address_street_number():
    street_number = Address().street_number()
    assert isinstance(street_number, str)

# Generated at 2022-06-21 15:49:19.248874
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    latitude = address.latitude()
    assert isinstance(latitude, float)


# Generated at 2022-06-21 15:49:20.301607
# Unit test for method city of class Address
def test_Address_city():
    pass

if __name__ == '__main__':
    print(Address())

# Generated at 2022-06-21 15:49:24.619348
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address(locale = "en")
    postal_code = a.postal_code()
    assert isinstance(postal_code, str)
    f = postal_code.split('-')
    assert len(f) == 2
    assert isinstance(f[0], str)
    assert isinstance(f[1], str)


# Generated at 2022-06-21 15:49:43.787251
# Unit test for method country of class Address
def test_Address_country():
    assert True

# Generated at 2022-06-21 15:49:55.424249
# Unit test for method region of class Address
def test_Address_region():
    address = Address()

# Generated at 2022-06-21 15:49:58.412087
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.builtins import Address
    a = Address()
    # This is not a consistent test.  Sometimes there are
    # no postal codes for a given locale.
    assert a.postal_code() != ''

# Generated at 2022-06-21 15:50:04.377353
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    seed(10)

# Generated at 2022-06-21 15:50:15.886141
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address."""
    from mimesis.enums import DataFields
    from mimesis.builtins import Address as Address_

    for _ in range(100):
        tmp = Address_('ru')
        # latitude or longitude not between -90 and 90
        assert -90 <= tmp.latitude() <= 90 and \
               -90 <= tmp.longitude() <= 90

        # Value of latitude or longitude not between 0 and 1
        assert 0 <= tmp.coordinates(dms=False)['latitude'] <= 1 and \
               0 <= tmp.coordinates(dms=False)['longitude'] <= 1

        # check returned values
        assert isinstance(tmp.latitude(), (str, float)) and \
               isinstance(tmp.latitude(), (str, float))

        # check returned values

# Generated at 2022-06-21 15:50:16.690906
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-21 15:50:18.709688
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    assert a.latitude(dms=False) in [-90.00, 90.00]


# Generated at 2022-06-21 15:50:19.642535
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    pass

# Generated at 2022-06-21 15:50:22.929917
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test method longitude of class Address"""
    address = Address()
    result = address.longitude(dms=False)
    assert -180 <= result <= 80


# Generated at 2022-06-21 15:50:27.685231
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    s = Address()
    for i in range(10):
        print(s.federal_subject())
        print(s.federal_subject(True))
    print(s.federal_subject())
    print(s.federal_subject(True))


# Generated at 2022-06-21 15:51:11.046015
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    lon = a.longitude()
    result = lon
    assert result is not None


# Generated at 2022-06-21 15:51:12.421313
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    print(Address.federal_subject())
print('####################################')


# Generated at 2022-06-21 15:51:14.070897
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    provider = Address('en')
    calling_code = provider.calling_code()
    assert calling_code != ''



# Generated at 2022-06-21 15:51:16.006019
# Unit test for method province of class Address
def test_Address_province():
    address = Address(locale='en')
    print('province is : ', address.province())


# Generated at 2022-06-21 15:51:18.061217
# Unit test for method longitude of class Address
def test_Address_longitude():
    addr = Address()
    assert isinstance(addr.longitude(), float)
    assert isinstance(addr.longitude(dms=True), str)


# Generated at 2022-06-21 15:51:20.156791
# Unit test for method country of class Address
def test_Address_country():
    """Display country of specified locale"""
    print(Address(locale='en').country())


# Generated at 2022-06-21 15:51:21.630709
# Unit test for method province of class Address
def test_Address_province():
    """
    Unit test for method province of class Address
    """
    addr = Address()
    assert addr.province()

# Generated at 2022-06-21 15:51:23.441820
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    result = Address.calling_code()
    if not isinstance(result, str):
        raise TypeError("The result should be of type string")


# Generated at 2022-06-21 15:51:24.911322
# Unit test for method calling_code of class Address
def test_Address_calling_code():

    assert Address('en').calling_code() in CALLING_CODES

# Generated at 2022-06-21 15:51:26.586704
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    import mimesis
    a=Address()
    assert "Avenue" in a.street_suffix()


# Generated at 2022-06-21 15:53:04.858535
# Unit test for method address of class Address
def test_Address_address():
    assert Address('en').address() == '058 Springfield Way'
    assert Address('de').address() == '32 Breslin Lane'
    assert Address('ru').address() == '6 Пархоменко Максима улица, кв.8'
    assert Address('ja').address() == '中部市南大和町甲-88-8'

# Generated at 2022-06-21 15:53:08.246454
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import Locale

    region = 'Самарская область'
    assert Address(Locale.RU).region() == region


# Generated at 2022-06-21 15:53:09.504921
# Unit test for constructor of class Address
def test_Address():
    pass


# Generated at 2022-06-21 15:53:12.628713
# Unit test for method region of class Address
def test_Address_region():
    adr = Address(locale='en')
    assert adr.region() in ('TX', 'CA', 'NY', 'MA')


# Generated at 2022-06-21 15:53:14.503085
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address(local='en')
    assert re.match(r'-\d{2}.\d{6}', address.longitude()) is not None

# Generated at 2022-06-21 15:53:16.218496
# Unit test for method city of class Address
def test_Address_city():
    ad = Address('en')
    print(ad.city())

# Generated at 2022-06-21 15:53:21.885861
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    province = address.province()
    assert province in address._data['state']['name']

    address_with_abbr = Address()
    province_with_abbr = address_with_abbr.province(abbr=True)
    assert province_with_abbr in address_with_abbr._data['state']['abbr']


# Generated at 2022-06-21 15:53:23.015215
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    pass


# Generated at 2022-06-21 15:53:27.471019
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
  from mimesis.enums import Locale
  from mimesis.providers import Address
  assert Address(Locale.RU).federal_subject() == 'Алтайский край'
  assert Address(Locale.RU).federal_subject(True) == 'АК'


# Generated at 2022-06-21 15:53:30.299562
# Unit test for method street_name of class Address
def test_Address_street_name():
    method_name="street_name"
    address = Address()
    method=getattr(address, method_name)
    print("Testing method: "+method_name)
    for i in range(5):
        print(method())

if __name__ == "__main__":
    test_Address_street_name()