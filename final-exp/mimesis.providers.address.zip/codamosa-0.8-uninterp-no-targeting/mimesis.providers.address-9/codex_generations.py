

# Generated at 2022-06-21 15:45:42.148778
# Unit test for method longitude of class Address
def test_Address_longitude():
    l = Address()
    print(l.longitude(True))
    print(l.longitude(False))


# Generated at 2022-06-21 15:45:45.985896
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    ad = Address()
    ad2 = Address(locale='en-US')
    assert len(ad.address()) == 0
    assert len(ad2.address()) == 0

# Generated at 2022-06-21 15:45:47.841763
# Unit test for method longitude of class Address
def test_Address_longitude():
    import numpy as np
    assert -180 <= Address().longitude() <= 180

# Generated at 2022-06-21 15:45:51.418264
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address('en')
    print(a.street_suffix())

if __name__ == "__main__":
    # execute only if run as a script
    test_Address_street_suffix()

# Generated at 2022-06-21 15:45:53.739536
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    for i in range(10):
        print(address.coordinates(), end='\n')

# test_Address_coordinates()

# Generated at 2022-06-21 15:45:55.788384
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    obj = Address()
    obj.locale = 'ru'
    oneOf = obj.federal_subject()
    assert oneOf in obj._data['state']['name']

# Generated at 2022-06-21 15:46:00.297108
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Arrange
    post_code_fmt = '[0-9]{5}'
    # Act
    post_code = Address('en').postal_code()
    # Assert
    assert (post_code[3:].isdigit() and post_code[:3].isdigit())

# Generated at 2022-06-21 15:46:05.195729
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    na = Address(locale = 'en')
    addr_str = na.federal_subject()
    print(addr_str)
    assert len(addr_str) == 2
    addr_str = na.federal_subject(abbr=False)
    print(addr_str)
    assert len(addr_str) > 2


# Generated at 2022-06-21 15:46:10.323800
# Unit test for method continent of class Address
def test_Address_continent():
    # Create Address() object
    address = Address()

    # Try to get a random continent name
    result = address.continent()
    # Check is it string
    assert isinstance(result, str)

    # Try to get a random continent code
    result = address.continent(code=True)
    # Check is it string
    assert isinstance(result, str)



# Generated at 2022-06-21 15:46:15.469037
# Unit test for method province of class Address
def test_Address_province():
    address1 = Address(locale='nl')
    address2 = Address(locale='fr')

    assert 'Zuid-Holland' in address1.province(False)
    assert 'FR' in address2.province(True)


# Generated at 2022-06-21 15:46:24.344168
# Unit test for method state of class Address
def test_Address_state():
    dict_ = Address('en').state(True)
    assert isinstance(dict_, str)


# Generated at 2022-06-21 15:46:25.508214
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    code = Address().federal_subject()
    assert code in Address()._data['state']['name']

# Generated at 2022-06-21 15:46:36.899043
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis import Address
    """
    def state(self, abbr: bool = False) -> str:
        Get a random administrative district of country.

        :param abbr: Return ISO 3166-2 code.
        :return: Administrative district.
    """

    # case 1: default region is name
    region = Address(seed=12345).region()
    assert isinstance(region, str)
    assert len(region) != 0
    # case 2: region is abbreviation
    region = Address(seed=12345).region(abbr=True)
    assert isinstance(region, str)
    assert len(region) != 0



# Generated at 2022-06-21 15:46:47.937260
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import CountryCode
    from mimesis.utils import defer_and_mock
    from mimesis.utils.datetime import set_locale_now_datetime
    from mimesis.utils.random import set_random_state

    def _defer_and_mock(data):
        _ = set_locale_now_datetime('en')
        _ = set_random_state(3)
        addr = Address('en', seed=3)
        _ = addr._data.update(data)
        prefecture = addr.prefecture()
        return prefecture

    data = {
        'state': {
            'name': ['Alabama', 'Alaska', 'Arizona', 'Arkansas'],
        }
    }

# Generated at 2022-06-21 15:46:49.108820
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    result = address.latitude()
    assert isinstance(result, float)


# Generated at 2022-06-21 15:46:51.180678
# Unit test for method city of class Address
def test_Address_city():
    address = Address(locale = 'en-us')
    assert address.city()
    # Expected type str
    assert isinstance(address.city(), str)
    # Expected length is 2 or more
    assert len(address.city()) >= 2


# Generated at 2022-06-21 15:46:53.034264
# Unit test for method prefecture of class Address
def test_Address_prefecture():
	assert Address().prefecture() in Address()._data['state']['name'] or Address().prefecture() in Address()._data['state']['abbr']


# Generated at 2022-06-21 15:46:55.462305
# Unit test for method continent of class Address
def test_Address_continent():
    """Test for Address.continent."""
    address = Address()

    assert isinstance(address.continent(), str)

# Generated at 2022-06-21 15:47:00.409225
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    provider = Address()
    postal_code = provider.postal_code()
    assert isinstance(postal_code, str)
    assert postal_code.isnumeric() and len(postal_code) > 0


# Generated at 2022-06-21 15:47:01.748178
# Unit test for method address of class Address
def test_Address_address():
    address = Address('hu')
    assert address.address() != None


# Generated at 2022-06-21 15:47:11.527130
# Unit test for method province of class Address
def test_Address_province():
    address_province_result = Address().province()
    assert type(address_province_result) is str


# Generated at 2022-06-21 15:47:15.941988
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code_1 = address.calling_code()
    calling_code_2 = address.calling_code()
    
    assert calling_code_1 != calling_code_2
    print("Unit test for method calling_code of class Address - Successful")

# Generated at 2022-06-21 15:47:19.908140
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from . import __name__ as package_name

    provider = Address(__name__.split('.')[0])
    res1 = provider.street_suffix()
    res2 = provider.street_suffix()
    assert isinstance(res1, str)
    assert isinstance(res2, str)
    assert res1 != res2



# Generated at 2022-06-21 15:47:27.861811
# Unit test for method country_code of class Address
def test_Address_country_code():
    addr = Address()
    country_code_1 = addr.country_code()
    country_code_2 = addr.country_code(CountryCode.A3)
    country_code_3 = addr.country_code(CountryCode.NUMERIC)
    country_code_4 = addr.country_code(CountryCode.ALL)
    assert len(country_code_1) == 2
    assert country_code_1 in COUNTRY_CODES[CountryCode.A2]
    assert len(country_code_2) == 3
    assert country_code_2 in COUNTRY_CODES[CountryCode.A3]
    assert len(country_code_3) == 3
    assert country_code_3 in COUNTRY_CODES[CountryCode.NUMERIC]
    assert country_code_4 in COUNTRY_COD

# Generated at 2022-06-21 15:47:29.759300
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    print(address.calling_code())


# Generated at 2022-06-21 15:47:31.262742
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code()

# Generated at 2022-06-21 15:47:36.023118
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    province_name = address.province()
    print("province_name:" + province_name)
    province_abbr = address.state(abbr=True)
    print("province_abbr:" + province_abbr)


# Generated at 2022-06-21 15:47:48.118242
# Unit test for constructor of class Address
def test_Address():
    ad = Address()
    assert hasattr(ad, 'state')
    assert hasattr(ad, 'street_name')
    assert hasattr(ad, 'postal_code')
    assert hasattr(ad, 'country_code')
    assert hasattr(ad, 'calling_code')
    assert hasattr(ad, 'city')
    assert hasattr(ad, 'province')
    assert hasattr(ad, 'prefecture')
    assert hasattr(ad, 'longitude')
    assert hasattr(ad, 'latitude')
    assert hasattr(ad, 'federal_subject')
    assert hasattr(ad, 'region')
    assert hasattr(ad, 'street_number')
    assert hasattr(ad, 'street_suffix')
    assert hasattr(ad, 'continent')

# Generated at 2022-06-21 15:47:49.405297
# Unit test for method latitude of class Address
def test_Address_latitude():
    pass
#Unit test for method longitude of class 

# Generated at 2022-06-21 15:47:59.062805
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address(locale= 'en')
    street = address.street_name()

# Generated at 2022-06-21 15:48:13.771796
# Unit test for method country_code of class Address
def test_Address_country_code():
    prefix_expected = [
        CountryCode.A2,
        CountryCode.A3,
        CountryCode.NUMERIC,
        CountryCode.A2,
        CountryCode.A3,
        CountryCode.NUMERIC,
    ]

    prefix_test = [
        CountryCode.A2,
        CountryCode.A3,
        CountryCode.NUMERIC,
        'A2',
        'A3',
        'NUMERIC',
    ]

    for test, expected in zip(prefix_test, prefix_expected):
        assert Address().country_code(test) == Address().country_code(expected)

# Generated at 2022-06-21 15:48:14.453760
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    print(adr.address())

# Generated at 2022-06-21 15:48:15.924467
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    assert address.federal_subject() in address._data['state']['name']

# Generated at 2022-06-21 15:48:18.668416
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    res = a.state()
    assert res in a._data['state']['name']



# Generated at 2022-06-21 15:48:20.746674
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    obj = Address()
    assert type(obj.street_suffix()) == str
    assert len(obj.street_suffix()) > 0


# Generated at 2022-06-21 15:48:24.129210
# Unit test for method country of class Address
def test_Address_country():
    adr = Address()
    assert adr.country(allow_random=True) in adr._data['country']['name']

# Generated at 2022-06-21 15:48:28.171577
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    provider = Address(locale="en")
    result = provider.coordinates()
    assert result is not None
    assert result != {}
    assert(result["latitude"])
    assert(result["longitude"])


# Generated at 2022-06-21 15:48:30.957368
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address('en')
    assert len(address.continent()) >= 3
    assert address.continent(code=True) in CONTINENT_CODES


# Generated at 2022-06-21 15:48:31.943366
# Unit test for method city of class Address
def test_Address_city():
    city = Address.city()
    assert city


# Generated at 2022-06-21 15:48:38.448812
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import Locale
    a = Address(Locale.CHINA)

# Generated at 2022-06-21 15:48:56.405045
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert address.street_name() is not None


# Generated at 2022-06-21 15:49:01.123015
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    assert len(a.country_code()) == 2
    assert len(a.country_code(fmt=CountryCode.A3)) == 3
    assert len(a.country_code(fmt=CountryCode.NUMERIC)) == 3
    assert len(a.country_code(fmt=CountryCode.FULL)) > 3
    return True

# Generated at 2022-06-21 15:49:03.844091
# Unit test for method country of class Address
def test_Address_country():
    """Test method country of class Address."""
    address = Address()
    country = address.country(allow_random=False)

    assert type(country) == str
    assert address.country() == 'Belarus'



# Generated at 2022-06-21 15:49:05.860590
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis import Address

    obj = Address('en')
    longitude = obj.longitude()
    assert longitude == 'N141.564998ºE21.922864º'


# Generated at 2022-06-21 15:49:06.768821
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    assert isinstance(a.street_suffix(), str)

# Generated at 2022-06-21 15:49:16.111209
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() in ['AK', 'AL', 'AR', 'AS', 'AZ', 'CA', 'CO', 'CT', 'DC', 'DE', 'FL', 'GA', 'GU', 'HI', 'IA', 'ID', 'IL', 'IN', 'KS', 'KY', 'LA', 'MA', 'MD', 'ME', 'MI', 'MN', 'MO', 'MP', 'MS', 'MT', 'NC', 'ND', 'NE', 'NH', 'NJ', 'NM', 'NV', 'NY', 'OH', 'OK', 'OR', 'PA', 'PR', 'RI', 'SC', 'SD', 'TN', 'TX', 'UM', 'UT', 'VA', 'VI', 'VT', 'WA', 'WI', 'WV', 'WY']


# Generated at 2022-06-21 15:49:26.298821
# Unit test for method calling_code of class Address
def test_Address_calling_code():
  import mimesis
  address = mimesis.Address()

# Generated at 2022-06-21 15:49:31.692715
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() in (
        'ST', 'STREET', 'AVE', 'AVENUE', 'HWY', 'HIGHWAY', 'LN', 'LANE',
        'DR', 'DRIVE', 'RD', 'ROAD', 'CIR', 'CIRCLE', 'TRL', 'TRAIL',
        'COURT', 'CT', 'PL', 'PLACE', 'SQUARE', 'SQ', 'WAY', 'WY'
    )

# Generated at 2022-06-21 15:49:35.979024
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    assert isinstance(a.street_number(), str)
    assert a.street_number() in ["1", "1400"]

# Unit Test for method street_name of class Address

# Generated at 2022-06-21 15:49:44.993660
# Unit test for method region of class Address

# Generated at 2022-06-21 15:50:35.452886
# Unit test for method longitude of class Address
def test_Address_longitude():
    # if Address().longitude() in [-180,180]:
    #     flag = True
    # else:
    #     flag = False
    flag = Address().longitude() in [-180,180]
    return flag


# Generated at 2022-06-21 15:50:39.299570
# Unit test for method city of class Address
def test_Address_city():
    ad = Address()
    assert ad.city() in [
        "Москва",
        "Санкт-Петербург",
        "Новосибирск",
    ]

# Generated at 2022-06-21 15:50:43.032920
# Unit test for method province of class Address
def test_Address_province():
    a = Address(locale='fr')
    print('a.province():', a.province())
    print('a.province(abbr=True):', a.province(abbr=True))


# Generated at 2022-06-21 15:50:44.820861
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    for i in range(50):
        print(address.country_code())

# Generated at 2022-06-21 15:50:47.939190
# Unit test for method state of class Address
def test_Address_state():
    adress = Address()
    state1 = adress.state()
    state2 = adress.state(abbr=True)
    assert state1 != state2

# Generated at 2022-06-21 15:50:53.669679
# Unit test for method province of class Address
def test_Address_province():
    addr = Address(seed=5)

# Generated at 2022-06-21 15:50:56.672862
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    obj = Address()
    assert obj.federal_subject() == obj.state()
    return True


# Generated at 2022-06-21 15:50:57.962063
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    assert type(a.longitude()) == float


# Generated at 2022-06-21 15:50:59.551792
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region()
    assert region == 'Lagos'


# Generated at 2022-06-21 15:51:02.460905
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    c = a.continent()
    assert c == 'Asia' or c == 'Europe' or c == 'North America' or c == 'South America' or c == 'Africa' or c == 'Oceania' or c == 'Antarctica'



# Generated at 2022-06-21 15:52:37.860267
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address"""
    address = Address()
    assert address.country_code() in COUNTRY_CODES['a2']
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES['a3']
    assert address.country_code(CountryCode.NUMERIC) in COUNTRY_CODES['numeric']

# Generated at 2022-06-21 15:52:42.551313
# Unit test for method city of class Address
def test_Address_city():
    assert Address().city in [
        'Helsinki',
        'Stockholm',
        'Berlin',
        'Paris',
        'London',
        'Moscow',
        'Rome',
        'Madrid',
        'Warsaw',
        'Kyiv',
        'New York',
        'Washington',
    ]


# Generated at 2022-06-21 15:52:45.187233
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    # ensure that method prefecture is an alias for method state
    assert a.prefecture == a.state


# Generated at 2022-06-21 15:52:46.848878
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    obj = Address()
    print(obj.street_suffix())


# Generated at 2022-06-21 15:52:47.371272
# Unit test for method region of class Address
def test_Address_region():
    pass

# Generated at 2022-06-21 15:52:48.770645
# Unit test for method country of class Address
def test_Address_country():
    a = Address('ru')
    assert a.country() == 'Россия'
    assert a.country(allow_random=True) in a._data['country']['name']
    

# Generated at 2022-06-21 15:52:52.072278
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address('en')
    assert '1' == a.street_number(maximum=1)

    for _ in range(10):
        assert 1 <= int(a.street_number(maximum=10)) <= 10


# Generated at 2022-06-21 15:52:52.831415
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() == '街'

# Generated at 2022-06-21 15:53:03.290262
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.exceptions import NonEnumerableError
    from random import choice

    addr = Address('ru')
    latitude = addr.latitude()
    lenght = len(str(latitude))
    assert lenght > 0


    lat = addr.latitude(dms=True)
    assert isinstance(lat, str)
    assert lat.isdigit()

    latitude = addr.latitude()
    lenght = len(str(latitude))
    assert lenght > 0

    lat = addr.latitude(dms=True)
    assert isinstance(lat, str)
    assert lat.isdigit()


    # print(addr.latitude(dms=True))
    # print

# Generated at 2022-06-21 15:53:07.033901
# Unit test for method country of class Address
def test_Address_country():
    class TestAddress(Address):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    a = TestAddress(locale='en')
    assert a.country() == 'United States'
