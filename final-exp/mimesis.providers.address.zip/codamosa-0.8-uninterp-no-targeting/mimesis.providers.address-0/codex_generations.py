

# Generated at 2022-06-21 15:45:38.207678
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    adress = Address()
    print(adress.zip_code())


# Generated at 2022-06-21 15:45:39.166034
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())


# Generated at 2022-06-21 15:45:40.767998
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.builtins import Address
    assert Address().postal_code() == '331255'

# Generated at 2022-06-21 15:45:44.819372
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    a = Address('de')

    assert a.region()
    assert a.region(abbr=True)
    assert a.country_code() == 'DE'
    assert a.country_code(CountryCode.A2) == 'DE'
    assert a.country_code(fmt=CountryCode.A2) == 'DE'
    assert a.country(allow_random=True)



# Generated at 2022-06-21 15:45:48.979740
# Unit test for method state of class Address
def test_Address_state():
    print('start!')
    d = Address('ko')
    state_list = []
    for i in range(10):
        state_list.append(d.state())

    print(state_list)


# Generated at 2022-06-21 15:45:51.465496
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address('en')
    assert a.zp_code() != None
    assert a.zp_code() != ''
    assert a.zp_code() != ' '

# Generated at 2022-06-21 15:45:53.414978
# Unit test for method state of class Address
def test_Address_state():
    print(Address().state())
    print(Address().state(abbr=True))


# Generated at 2022-06-21 15:45:58.806663
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    locale = 'en'
    seed = 1
    address = Address('en',seed)
    assert address.federal_subject() == 'MT'
    assert address.federal_subject(True) == 'AB'
    assert address.prefecture() == 'MN'
    assert address.prefecture(True) == 'AB'
    assert address.province() == 'CO'
    assert address.province(True) == 'AB'
    assert address.region() == 'AR'
    assert address.region(True) == 'AB'
    assert address.state() == 'AK'
    assert address.state(True) == 'AK'

# Generated at 2022-06-21 15:46:00.995731
# Unit test for method province of class Address
def test_Address_province():
    for i in range(0, 20):
        print("FEDERAL SUBJECT: {}".format(Address("ru").federal_subject()))



# Generated at 2022-06-21 15:46:03.021949
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    coord = a.coordinates()
    assert all([type(c) is float for c in coord.values()])

# Generated at 2022-06-21 15:46:14.665524
# Unit test for method latitude of class Address
def test_Address_latitude():
    lat = Address().latitude()
    assert isinstance(lat, float)
    assert lat >= -90.0 and lat <= 90.0
    print('test_Address_latitude() PASSED!')


# Generated at 2022-06-21 15:46:17.080922
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    actual = Address().zip_code()
    expected = True
    assert actual == expected


# Generated at 2022-06-21 15:46:18.992698
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    street_name = a.street_name()
    assert street_name.isalpha()

# Generated at 2022-06-21 15:46:25.158102
# Unit test for method province of class Address
def test_Address_province():
    print(Address.province.__doc__)

    address = Address(locale='zh')
    result = address.province()
    print(result)

    address = Address(locale='ja')
    result = address.province()
    print(result)

    address = Address(locale='en')
    result = address.province()
    print(result)

    address = Address(locale='en')
    result = address.province(abbr=True)
    print(result)


# Generated at 2022-06-21 15:46:29.621120
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    region = address.federal_subject()
    assert region in address._data['state']['name'] or region in address._data['state']['abbr']

# Generated at 2022-06-21 15:46:34.397172
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    a.country_code()
    a.country_code(CountryCode.A3)
    a.country_code(CountryCode.NUMERIC)
    a.country_code(CountryCode.UN_LOCODE)
    a.country_code(CountryCode.NAME)


# Generated at 2022-06-21 15:46:36.594993
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    province = address.province()
    assert province != None
    assert type(province) == str


# Generated at 2022-06-21 15:46:38.208159
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    x = a.random.randint(0,100)
    for i in range(x):
        z = a.zip_code()
        print(z)


# Generated at 2022-06-21 15:46:42.117926
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test output of longitude method of class Address."""
    address_provider = Address("en")
    output = address_provider.latitude()
    assert isinstance(output, float)

# Generated at 2022-06-21 15:46:44.482014
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert calling_code in CALLING_CODES


# Generated at 2022-06-21 15:47:04.322706
# Unit test for constructor of class Address
def test_Address():
    from mimesis.generators.address import Address

    address = Address()
    assert address() is not None


# Generated at 2022-06-21 15:47:09.658166
# Unit test for method country_code of class Address
def test_Address_country_code():
    """
    Code of following unit test is generated with the help of a special tool.
    Please write your unit tests according to the guidelines.
    You can find more information about testing in Mimesis on the link:
    https://mimesis.readthedocs.io/en/latest/testing.html

    :return: None
    """
    assert 'PE' == Address().country_code()



# Generated at 2022-06-21 15:47:10.591063
# Unit test for method latitude of class Address
def test_Address_latitude():
    Address.latitude()


# Generated at 2022-06-21 15:47:20.379904
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """This is a unit test for calling_code funcation of class Address"""
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    test_obj=Address()
    # test 1: call funcation randomly
    print(test_obj.calling_code())
    # test 2: specified country Germany
    print(test_obj.calling_code(country_code=CountryCode.A2.Germany))
    # test 3: specified country Canada
    print(test_obj.calling_code(country_code=CountryCode.A2.Canada))
    # test 4: specified country Japan
    print(test_obj.calling_code(country_code=CountryCode.A2.Japan))
    # test 5: specified country Russia

# Generated at 2022-06-21 15:47:21.113215
# Unit test for method street_number of class Address
def test_Address_street_number():
    print(Address().street_number())


# Generated at 2022-06-21 15:47:21.691195
# Unit test for method region of class Address
def test_Address_region():
    pass

# Generated at 2022-06-21 15:47:22.572985
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    assert address.coordinates()
    print(address.coordinates())

# Generated at 2022-06-21 15:47:25.835200
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address('en')
    coordinates = address.coordinates(dms=True)
    if (coordinates.get('latitude') == None) or (coordinates.get('longitude') == None) :
        return False
    return True


# Generated at 2022-06-21 15:47:29.273854
# Unit test for method country of class Address
def test_Address_country():
    var=Address()
    country=var.country()
    assert country=='Andorra'
    assert var.country(allow_random=True)


# Generated at 2022-06-21 15:47:33.283910
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    data = address.country_code()
    print(data)
    assert len(data) == 2

    data = address.country_code(CountryCode.A3)
    print(data)
    assert len(data) == 3

# Generated at 2022-06-21 15:47:53.993727
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Test for module Address, method street_number."""
    addr = Address()
    result = addr.street_number(maximum=1)
    if result != "1":
        return False
    return True


# Generated at 2022-06-21 15:47:57.513361
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    address = Address()
    region = address.region(abbr=False)
    region_abbr = address.region(abbr=True)
    country_code = address.country_code(CountryCode.A2)
    country_code_abbr = address.country_code(CountryCode.A3)

    assert isinstance(region, str)
    assert isinstance(region_abbr, str)
    assert isinstance(country_code, str)
    assert isinstance(country_code_abbr, str)


# Generated at 2022-06-21 15:47:58.589621
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    assert a.city() in a._data['city']

# Generated at 2022-06-21 15:48:00.242519
# Unit test for method state of class Address
def test_Address_state():
    actual = Address.state()
    expected = 'state'
    assert actual == expected


# Generated at 2022-06-21 15:48:02.603901
# Unit test for method province of class Address
def test_Address_province():
    province = Address()
    assert province.province() is not None
    assert province.province() == province.region()


# Generated at 2022-06-21 15:48:05.068510
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    addr = Address()
    assert 2 == len(addr.calling_code())

    addr.calling_code().isdigit() == True


# Generated at 2022-06-21 15:48:12.581241
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    p = Address()
    lat = p.latitude()
    assert 80 > lat > -80
    lng = p.longitude()
    assert 180 > lng > -180
    coord = p.coordinates()
    assert isinstance(coord, dict)
    assert coord['longitude'] == lng
    assert coord['latitude'] == lat
    coord = p.coordinates(dms=True)
    assert isinstance(coord, dict)
    assert isinstance(coord['longitude'], str)
    assert isinstance(coord['latitude'], str)

# Generated at 2022-06-21 15:48:19.311061
# Unit test for method province of class Address
def test_Address_province():
    locale = 'en'
    random_province = Address(locale).province()

# Generated at 2022-06-21 15:48:20.538437
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address=Address()
    assert address.federal_subject()

# Generated at 2022-06-21 15:48:24.347945
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    assert address.latitude() >= -90.0 and address.latitude() <= 90.0
    assert address.latitude() >= 0.0


# Generated at 2022-06-21 15:49:24.046831
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Unit test for method longitude of class Address."""
    assert type(Address().longitude(dms=False)) is float



# Generated at 2022-06-21 15:49:27.118754
# Unit test for method city of class Address
def test_Address_city():
    """Test Address.city method."""
    address = Address()
    city = address.city()

    assert city is not None



# Generated at 2022-06-21 15:49:28.927491
# Unit test for method city of class Address
def test_Address_city():
    print("\ntest_Address_city")
    a = Address()
    print(a.city())


# Generated at 2022-06-21 15:49:31.851856
# Unit test for method country of class Address
def test_Address_country():
    provider = Address()
    result = provider.country()
    assert result in ['India', 'Japan', 'Russia', 'United States']


# Generated at 2022-06-21 15:49:33.703920
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert isinstance(Address().prefecture(), str)

# Generated at 2022-06-21 15:49:35.980014
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    for i in range(1, 10):
        print(address.region())

# Generated at 2022-06-21 15:49:37.659789
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    print('Address', a.latitude())



# Generated at 2022-06-21 15:49:39.572688
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state(abbr=True)
    assert address.state()


# Generated at 2022-06-21 15:49:41.336911
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    assert 'prefecture' in dir(a)
    print(a.prefecture())

# Generated at 2022-06-21 15:49:42.565898
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    assert -90 < a.latitude() < 90