

# Generated at 2022-06-21 15:45:50.086368
# Unit test for method country_code of class Address
def test_Address_country_code():
    adr = Address(seed=123456)

    assert adr.country_code(CountryCode.A2) == "DK"
    assert adr.country_code(CountryCode.A3) == "DNK"
    assert adr.country_code(CountryCode.NUM) == "208"
    assert adr.country_code() == "DK"
    assert adr.country_code('A2') == "DK"
    assert adr.country_code('A3') == "DNK"
    assert adr.country_code('NUM') == "208"
    assert adr.country_code('_') == "Denmark"

    # In case of invalid format should return empty string
    invalid = ['12', '123', '1234']

# Generated at 2022-06-21 15:45:54.272187
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # Create an instance of Address
    add = Address()
    # Run method street_suffix
    name = add.street_suffix()
    # Verifying data
    assert isinstance(name, str)
    assert len(name) > 0


# Generated at 2022-06-21 15:45:55.237455
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province()

# Generated at 2022-06-21 15:45:57.695552
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test that country_code method returns a country code."""
    addr = Address('en')
    assert len(addr.country_code()) == 2


# Generated at 2022-06-21 15:46:03.260351
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    continent = a.continent(code=True)
    assert continent in ('AF', 'AN', 'AS', 'EU', 'NA', 'OC', 'SA')
    assert continent == 'EU' or continent == 'AS' \
        or continent == 'OC' or continent == 'AF'\
        or continent == 'NA' or continent == 'AN'\
        or continent == 'SA'


# Generated at 2022-06-21 15:46:03.904596
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    pass

# Generated at 2022-06-21 15:46:06.320566
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    first_result = Address("es").postal_code()
    second_result = Address("es").postal_code()

    assert len(first_result) is len(second_result)

# Generated at 2022-06-21 15:46:09.233871
# Unit test for method street_name of class Address
def test_Address_street_name():
    # Initialize provider
    address = Address()

    # street_name() method
    random_street_name = address.street_name()

    assert random_street_name is not None


# Generated at 2022-06-21 15:46:13.612640
# Unit test for method state of class Address
def test_Address_state():
    """Unit test for Address.state()"""
    # Run a small test
    addr = Address(locale='en-us')
    assert addr.state() in ['Alabama', 'Wyoming']


# Generated at 2022-06-21 15:46:17.466921
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    print(Address('en').calling_code())
    print(Address('fr').calling_code())
    print(Address('it').calling_code())
    assert True
    return True


# Generated at 2022-06-21 15:46:28.385762
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address('en')
    street_number1 = address.street_number()
    street_number2 = address.street_number()
    assert street_number1 != street_number2


# Generated at 2022-06-21 15:46:32.551320
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import CountryCode
    from pprint import pprint as print

    a = Address()
    arg1 = CountryCode.A2
    arg2 = CountryCode.A3
    arg3 = CountryCode.NUMERIC
    print('a.country_code(arg1) =', a.country_code(arg1))
    print('a.country_code(arg2) =', a.country_code(arg2))
    print('a.country_code(arg3) =', a.country_code(arg3))

# Generated at 2022-06-21 15:46:37.115304
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    import json
    adr = Address()
    calling_code = adr.calling_code()
    with open('address.json', mode='r', encoding='utf-8') as fp:
        json_data = json.load(fp)
    country_codes = json_data['phone']['calling_codes']
    assert calling_code in country_codes

# Generated at 2022-06-21 15:46:43.840971
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode

    assert len(Address().country_code(CountryCode.A2)) == 2
    assert len(Address().country_code(CountryCode.A3)) == 3
    assert len(Address().country_code(CountryCode.NUMERIC)) == 3
    assert len(Address().country_code(CountryCode.FULL)) > 2

    assert len(Address().country_code(CountryCode.A2)) == 2

# Generated at 2022-06-21 15:46:45.497783
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    assert address.country() == address._data['country']['current_locale']

# Generated at 2022-06-21 15:46:50.599432
# Unit test for method address of class Address
def test_Address_address():
    """Testing method address of class Address."""
    address = Address()
    _streets = ['{st_num} {st_name} {st_sfx}', '{st_num} {st_name}']
    assert address.street_number() in range(1, 1400)
    assert address.street_name() in address._data['street']['name']
    assert address.address() in _streets


# Generated at 2022-06-21 15:46:52.404774
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    # print(address.zip_code())
    # print(address.zip_code())
    # print(address.zip_code())



# Generated at 2022-06-21 15:46:53.556240
# Unit test for method country of class Address
def test_Address_country():
    from mimesis import Address
    a = Address()
    print(a.country())


# Generated at 2022-06-21 15:46:59.587358
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Test method zip_code."""
    from mimesis.enums import Locale

    a = Address(Locale.EN)
    assert isinstance(a.zip_code(), str)
    assert len(a.zip_code()) > 0
    assert a.zip_code() != a.zip_code()

# Generated at 2022-06-21 15:47:02.859341
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Test Address().street_number()"""
    # Given
    address = Address()
    # When
    street_number = address.street_number()
    # Then
    assert str(street_number).isnumeric()


# Generated at 2022-06-21 15:47:18.266834
# Unit test for method region of class Address
def test_Address_region():
    address = Address('en')
    result = set()
    for _ in range(100):
        result.add(address.region())
    assert len(result)==1



# Generated at 2022-06-21 15:47:24.483718
# Unit test for method continent of class Address
def test_Address_continent():

    # Instantiate class Address
    address = Address()

    # Generate continent
    continent = address.continent()
    print(continent)
    assert continent in address.continent()
    # Generate continent code
    continent_code = address.continent(True)
    print(continent_code)
    assert continent_code in CONTINENT_CODES



# Generated at 2022-06-21 15:47:26.088662
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address_provider = Address()

    result = address_provider.federal_subject()

    print(result)
    assert result


# Generated at 2022-06-21 15:47:33.337134
# Unit test for method country of class Address
def test_Address_country():
    # Check for a specific locale
    assert Address('ru').country() == 'Россия'
    # Check for a specific locale with a random country
    assert Address('ru').country(allow_random=True) == 'Россия'
    # Check for a random locale and a random country
    assert Address().country(allow_random=True) == 'Россия'


# Generated at 2022-06-21 15:47:35.002688
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code() in CALLING_CODES


# Generated at 2022-06-21 15:47:39.485357
# Unit test for method city of class Address
def test_Address_city():
    ad = Address(locale='ru')
    assert ad.city() != ''
#     assert ad.city(locale='ru') in _cache_['city']['ru']
#     assert len(ad.city(locale='ru')) > 0


# Generated at 2022-06-21 15:47:50.565873
# Unit test for method country_code of class Address
def test_Address_country_code():
    # A2 country code ~> 'AU'
    assert Address().country_code() == 'AU'
    # A3 country code ~> 'AUS'
    assert Address().country_code(CountryCode.A3) == 'AUS'
    # Numeric code ~> '036'
    assert Address().country_code(CountryCode.N) == '036'



import requests
from lxml import html

#headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36'}

# Generated at 2022-06-21 15:47:54.279487
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import ContinentCode

    tmp0 = Address().continent(code=True)
    tmp1 = Address().continent(code=False)
    assert tmp0 in CONTINENT_CODES
    assert tmp1 in tmp1._data['continent']


# Generated at 2022-06-21 15:47:56.134941
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    provider = Address('en')
    assert provider.coordinates() == {'longitude': '-6º58\'10.603"W', 'latitude': '24º14\'10.079"N'}


# Generated at 2022-06-21 15:48:01.879984
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('en')
    street_suffix = address.street_suffix()
    assert street_suffix.startswith('#')

if __name__ == "__main__":
    address = Address('en')
    street_suffix = address.street_suffix()
    print(street_suffix)
    street_suffix = address.street_suffix()
    print(street_suffix)
    street_suffix = address.street_suffix()
    print(street_suffix)


# Generated at 2022-06-21 15:48:32.811395
# Unit test for method continent of class Address
def test_Address_continent():
    for i in range(100):
        assert isinstance(Address().continent(), str)
        assert isinstance(Address().continent(code=True), str)



# Generated at 2022-06-21 15:48:38.921864
# Unit test for method federal_subject of class Address

# Generated at 2022-06-21 15:48:40.139127
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province()



# Generated at 2022-06-21 15:48:41.277130
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert isinstance(address.state(), str)
    assert isinstance(address.state(abbr=True), str)


# Generated at 2022-06-21 15:48:43.666041
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    assert isinstance(a.longitude(), (float, int))


# Generated at 2022-06-21 15:48:49.153376
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    seed = 1
    a = Address(seed=seed)
    
    b = "260"
    c = a.calling_code()
    # Assertion:
    assert(c == b)

    b = "98"
    c = a.calling_code()
    # Assertion:
    assert(c == b)

    b = "93"
    c = a.calling_code()
    # Assertion:
    assert(c == b)


# Generated at 2022-06-21 15:48:53.249239
# Unit test for method country_code of class Address
def test_Address_country_code():
    # Arrange
    address = Address(locale='en')
    expected = 'RU'

    # Act
    actual = address.country_code(CountryCode.A2)

    # Assert
    assert actual == expected



# Generated at 2022-06-21 15:48:56.359520
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    loc = 'ja'
    obj = Address(loc)
    r = obj.prefecture
    print(r)


# Generated at 2022-06-21 15:48:58.157030
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    assert isinstance(a.federal_subject(), str)



# Generated at 2022-06-21 15:49:03.258605
# Unit test for method country of class Address
def test_Address_country():
    """Ensure that Address.country() returns the name of the country
    of the current locale, and returns a random country name when allow_random
    is True.
    """
    import mimesis.enums as enums
    addr = Address(locale=enums.Locale.RU)
    assert addr.country() == 'Россия'
    assert type(addr.country(allow_random=True)) == str


# Generated at 2022-06-21 15:50:14.365378
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() == 'Australian Capital Territory'
    assert Address().region(abbr=True) == 'ACT'


# Generated at 2022-06-21 15:50:16.881846
# Unit test for method latitude of class Address
def test_Address_latitude():
    addr = Address("en")
    latitude = addr.latitude()
    assert abs(latitude) <= 90


# Generated at 2022-06-21 15:50:17.855316
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country() == "中国"

# Generated at 2022-06-21 15:50:18.708651
# Unit test for method province of class Address
def test_Address_province():
    assert Address.province()

# Generated at 2022-06-21 15:50:25.403081
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address."""
    from mimesis.enums import Locale
    address = Address(Locale.JAPANESE)
    result = address.prefecture()

# Generated at 2022-06-21 15:50:31.079273
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from hypothesis import given
    from hypothesis import strategies as st

    @given(st.integers(), st.integers())
    def test_Address_coordinates(lt, lg):
        addr = Address()
        assert abs(addr.latitude() - lt) < 1.0
        assert abs(addr.longitude() - lg) < 1.0

# Generated at 2022-06-21 15:50:32.351066
# Unit test for method country of class Address
def test_Address_country():
    country = Address().country()
    return country == 'Aruba'
