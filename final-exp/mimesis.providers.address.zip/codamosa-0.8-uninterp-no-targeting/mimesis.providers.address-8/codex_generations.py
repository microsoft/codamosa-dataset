

# Generated at 2022-06-21 15:45:36.224883
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    assert a.prefecture() in a._data['state']['name']


# Generated at 2022-06-21 15:45:44.053134
# Unit test for method longitude of class Address
def test_Address_longitude():
    address_zh_cn = Address(locale='zh_CN')
    Coordinate_cn = address_zh_cn.coordinates()
    Longitude_cn = Coordinate_cn['longitude']
    Longitude_cn = float(Longitude_cn)
    Address_cn = Longitude_cn 
    Is_return = isinstance(Address_cn, float)
    assert Is_return == True, 'Address.longitude() (zh_CN) returns not float'

    address_ru = Address(locale='ru')
    Coordinate = address_ru.coordinates()
    Longitude = Coordinate['longitude']
    Longitude = float(Longitude)
    Address = Longitude 
    Is_return = isinstance(Address, float)
    assert Is_return == True, 'Address.longitude() (ru) returns not float'

# Generated at 2022-06-21 15:45:47.007851
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address(seed=123456789)
    result = a.street_name()
    assert result == "Monumental"

# Generated at 2022-06-21 15:45:48.288441
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address().prefecture()



# Generated at 2022-06-21 15:45:50.665965
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    street_suffixes = Address.street_suffix()
    print(f"Street suffixes: {street_suffixes}")


# Generated at 2022-06-21 15:45:53.042878
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    provider = Address()
    result = provider.street_suffix()
    assert len(result) > 0



# Generated at 2022-06-21 15:45:54.353403
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    addr = Address()
    assert addr.federal_subject() == addr.state()

# Generated at 2022-06-21 15:45:55.989462
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    prov = a.province()
    assert prov


# Generated at 2022-06-21 15:45:59.776990
# Unit test for method continent of class Address
def test_Address_continent():
    addr = Address(locale='en')
    for i in range(20):
        assert addr.continent(code=True) in CONTINENT_CODES
        assert addr.continent() in addr._data['continent']



# Generated at 2022-06-21 15:46:01.562990
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adr = Address()
    assert adr.federal_subject() in adr._data['state']['name']

# Generated at 2022-06-21 15:46:11.854955
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    print(a.latitude(False))


# Generated at 2022-06-21 15:46:18.429441
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Locale is de
    a = Address(locale='de')
    # Generate postal code
    postal_code = a.postal_code()
    # 'postal_code' must be string
    assert isinstance(postal_code, str)
    # 'postal_code' must be in format '#####'
    assert len(postal_code) == 5


# Generated at 2022-06-21 15:46:20.470132
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    addr = Address()
    for fmt in CountryCode:
        code = addr.country_code(fmt)
        assert isinstance(code, str)


# Generated at 2022-06-21 15:46:21.584443
# Unit test for method country of class Address
def test_Address_country():
    print(Address().country())
    print(Address().country(True))



# Generated at 2022-06-21 15:46:24.270463
# Unit test for method country_code of class Address
def test_Address_country_code():
    adr = Address()

    for c in CountryCode:
        res = adr.country_code(fmt=c)
        print(res)
        assert c.value in COUNTRY_CODES
        assert res in COUNTRY_CODES[c.value]


# Generated at 2022-06-21 15:46:36.982984
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('ru')

# Generated at 2022-06-21 15:46:37.963737
# Unit test for method street_name of class Address
def test_Address_street_name():
    import pdb; pdb.set_trace()

# Generated at 2022-06-21 15:46:39.189310
# Unit test for method province of class Address
def test_Address_province():
    assert type(Address().province()) == str

# Generated at 2022-06-21 15:46:42.469073
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Unit test for Address().street_number().
    """
    address = Address(random_state=10)
    assert address.street_number() == '1398'


# Generated at 2022-06-21 15:46:51.360337
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Test method prefecture of class Address.

    This test generates a random prefecture name according
    to the current locale. The result is compared with
    the result of the original method prefecture of class
    Address.

    :return: Result of test.
    """
    test_obj = Address()
    test_result = test_obj.prefecture(True)
    curr_locale = test_obj.locale
    curr_cont = test_obj.continent()
    if curr_locale == 'ru' and curr_cont == 'Europe':
        test_result = test_obj.federal_subject(True)
    test_method_result = test_obj._data['state']['abbr']
    return test_result in test_method_result


# Generated at 2022-06-21 15:47:02.495334
# Unit test for method region of class Address
def test_Address_region():
    """Test method region of class Address."""
    a = Address()
    assert a.region().isalpha()
    assert a.region(abbr=True).isalnum()


# Generated at 2022-06-21 15:47:11.773259
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Country
    country = Address(Country.FRANCE).country()
    assert country == 'France'
    assert country != 'Russia'

    country = Address(Country.ARGENTINA).country()
    assert country == 'Argentina'
    assert country != 'France'

    country = Address(Country.RUSSIA).country()
    assert country == 'Russia'
    assert country != 'France'

    country = Address(Country.UKRAINE).country()
    assert country == 'Ukraine'
    assert country != 'France'

    country = Address(Country.AUSTRALIA).country()
    assert country == 'Australia'
    assert country != 'France'

    country = Address(Country.BRAZIL).country()
    assert country == 'Brazil'
    assert country != 'France'

    country = Address

# Generated at 2022-06-21 15:47:15.815126
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert calling_code in CALLING_CODES


if __name__ == '__main__':
    address = Address()
    print(address)
    print(address.calling_code())

# Generated at 2022-06-21 15:47:20.324156
# Unit test for method region of class Address
def test_Address_region():
    test_for_locale = "ru" # Допустимая строка, нужна для инициализации
    address = Address(test_for_locale)
    region = address.region(abbr = True)
    assert region in address._data["state"]["name"]

# Generated at 2022-06-21 15:47:21.542655
# Unit test for method street_name of class Address
def test_Address_street_name():
	x = Address()
	assert type(x.street_name()) == str, 'Data must be a str.'

# Generated at 2022-06-21 15:47:23.074029
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None


# Generated at 2022-06-21 15:47:25.323950
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    # This is actually a code of country, but it's fine
    continent = address.continent()
    assert continent in address._data['continent']


# Generated at 2022-06-21 15:47:26.625464
# Unit test for method country of class Address
def test_Address_country():
    pass


# Generated at 2022-06-21 15:47:28.625635
# Unit test for method state of class Address
def test_Address_state():
    addr = Address()
    assert addr.state() == 'Victoria'


# Generated at 2022-06-21 15:47:30.385779
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    for i in range(100):
        assert len(Address().calling_code()) == 3


# Generated at 2022-06-21 15:47:43.685710
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address."""
    addr = Address()
    result = addr.country_code()
    print(result)

test_Address_country_code()

# Generated at 2022-06-21 15:47:46.996220
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address."""
    address = Address()
    i = 0
    while i < 10:
        state = address.region()
        print(state)
        i += 1


# Generated at 2022-06-21 15:47:50.234860
# Unit test for method city of class Address
def test_Address_city():
    """Unit test for method city of class Address."""
    addr = Address('en')
    city = addr.city()

    assert isinstance(city, str)
    assert city
    assert len(city) <= 20


# Generated at 2022-06-21 15:47:52.305558
# Unit test for method province of class Address
def test_Address_province():
    address = Address("ja")
    assert isinstance(address.province(), str)


# Generated at 2022-06-21 15:47:56.837402
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a1 = Address(locale='en')
    a2 = Address(locale='ru')
    a3 = Address(locale='ja')
    assert a1.zip_code() == a1.postal_code()
    assert a2.zip_code() == a2.postal_code()
    assert a3.zip_code() == a3.postal_code()


# Generated at 2022-06-21 15:47:58.290150
# Unit test for method city of class Address
def test_Address_city():
    provider = Address()
    assert isinstance(provider.city(), str)



# Generated at 2022-06-21 15:47:59.441187
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    print(address.city())


# Generated at 2022-06-21 15:48:01.019534
# Unit test for method street_name of class Address
def test_Address_street_name():
    A = Address(locale='en')
    assert A.street_name() in A._data['street']['name']

# Generated at 2022-06-21 15:48:03.785911
# Unit test for method city of class Address
def test_Address_city():
    class_instance = Address()
    result = class_instance.city()
    assert result != None
    assert isinstance(result, str)


# Generated at 2022-06-21 15:48:05.773184
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    addr = Address()
    assert len(addr.postal_code()) == 7



# Generated at 2022-06-21 15:48:29.399439
# Unit test for method street_number of class Address
def test_Address_street_number():
    addr = Address()
    snum = addr.street_number()
    assert int(snum) > 0
    assert isinstance(snum, str)


# Generated at 2022-06-21 15:48:32.247217
# Unit test for method city of class Address
def test_Address_city():
    a = Address()

    for _ in range(0, 100):
        city = a.city()
        assert type(city) is str
        assert len(city) > 0


# Generated at 2022-06-21 15:48:34.033951
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Test method latitude of class Address."""
    print(Address().latitude())
    print(Address().latitude(True))


# Generated at 2022-06-21 15:48:36.781019
# Unit test for method address of class Address
def test_Address_address():
    """Test class method address."""
    address = Address()
    address.address()
    response = address.address()
    assert response is not None

# Generated at 2022-06-21 15:48:39.484632
# Unit test for method street_suffix of class Address
def test_Address_street_suffix(): 
    addr = Address()
    print("Street suffix:", addr.street_suffix())


# Generated at 2022-06-21 15:48:42.942040
# Unit test for method country of class Address
def test_Address_country():
    """Test method country of Address class."""
    address = Address(locale='en')
    country = address.country()
    assert country == 'United States'



# Generated at 2022-06-21 15:48:44.139264
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address().prefecture() != None
    assert Address().prefecture() != ''


# Generated at 2022-06-21 15:48:51.714219
# Unit test for method region of class Address
def test_Address_region():
    addr = Address(locale="es_MX")

# Generated at 2022-06-21 15:48:55.189666
# Unit test for method city of class Address
def test_Address_city():
    print('测试Address类的city方法')
    print(Address('zh').city())


# Generated at 2022-06-21 15:48:57.344223
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    province = a.prefecture()
    assert isinstance(province, str)


# Generated at 2022-06-21 15:49:43.659610
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    for i in range(0, 5):
        assert len(Address().postal_code()) == 5


# Generated at 2022-06-21 15:49:55.296214
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis import Address
    from mimesis.enums import Locale
    from mimesis.exceptions import NonEnumerableError

    # You should get all locales.
    all_locales = [v for v in Locale.__dict__.keys() if v.isupper()]

    # Create object Address with all know locales.
    for locale in all_locales:
        address_obj = Address(locale)

        # Check len of postal code.
        zip_code = address_obj.postal_code()
        assert locale == Locale.EN and \
            len(zip_code) == 5, \
            'Postal code {} is wrong.' \
            ''.format(zip_code)

        # Check letters in postal code.
        letters = address_obj._data['letters']

# Generated at 2022-06-21 15:49:56.942906
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    print('Street name: ' + address.street_name())



# Generated at 2022-06-21 15:50:00.152825
# Unit test for method continent of class Address
def test_Address_continent():
    locale = 'fr'
    a = Address(locale)
    result = a.continent()
    assert result in ['Afrique', 'Europe', 'Asie', 'Amère du Nord', 'Océanie', 'Amère du Sud', 'Antarctique']

# Generated at 2022-06-21 15:50:01.894166
# Unit test for method country_code of class Address
def test_Address_country_code():
    addresses = Address(locale='en')
    country_code = addresses.country_code()
    assert country_code in COUNTRY_CODES.values()


# Generated at 2022-06-21 15:50:13.991971
# Unit test for method region of class Address
def test_Address_region():
    # Проверка на составляющие адреса
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    address = Address(locale='ru')

    # Проверка на составляющие адреса
    assert address.street_name() != None
    assert address.street_suffix() != None
    assert address.street_number() != None
    assert address.state() != None
    assert address.region() != None
    assert address.federal_subject() != None
    assert address.prefecture() != None
    assert address.country_code() != None

# Generated at 2022-06-21 15:50:14.940303
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    addr = Address()
    print(addr.prefecture(abbr=True))
    # NT


# Generated at 2022-06-21 15:50:15.353277
# Unit test for constructor of class Address
def test_Address():
    Address()

# Generated at 2022-06-21 15:50:17.858415
# Unit test for method state of class Address
def test_Address_state():
    """ Test for method state of class Address.
    It is expected that the function returns a string."""

    assert isinstance(Address().state(), str)



# Generated at 2022-06-21 15:50:20.924697
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # Initialize an object Address
    addr = Address()
    # Get prefecture of Address object
    data = addr.prefecture()
    # Assertion
    assert data['prefecture'] in addr._data['state']['name']
