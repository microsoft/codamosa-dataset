

# Generated at 2022-06-21 15:45:37.738777
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Check method longitude of class Address"""
    address = Address()
    test_longitude = address.longitude()
    assert len(str(test_longitude)) < 10



# Generated at 2022-06-21 15:45:39.801421
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    for i in range(1,10):
        print(a.longitude(True))
    

# Generated at 2022-06-21 15:45:41.640800
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    result = address.federal_subject()
    assert result in address._data['state']['name']
    result = address.federal_subject(True)
    assert result in address._data['state']['abbr']


# Generated at 2022-06-21 15:45:43.578078
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address(locale='en').street_name()  # any_string

# Generated at 2022-06-21 15:45:45.678516
# Unit test for method city of class Address
def test_Address_city():
    assert Address().city() == '뉴욕'

# Generated at 2022-06-21 15:45:52.667110
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    address = Address('en')
    a = address.longitude()
    print(a)
    b = address.country_code(CountryCode.A2)
    print(b)
    c = address.federal_subject('USA')
    print(c)
    d = address.city()
    print(d)



# Generated at 2022-06-21 15:45:59.369638
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider

    address = Address(seed=123)
    usa = USASpecProvider(seed=123)
    ru = RussiaSpecProvider(seed=123)

    assert address.address() \
        == '2506 Thomas Place Suite 223'
    assert address.address() \
        == '2805 Wheeler Street Apt. 843'

    assert address.address(locale='ru') \
        == 'Приморская, 24а'
    assert address.street_name(locale='ru') == 'Приморская'
    assert address.street_suffix(locale='ru') == 'улица'

# Generated at 2022-06-21 15:46:01.135116
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    result = a.street_name()
    print(result)


# Generated at 2022-06-21 15:46:02.119747
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name()

# Generated at 2022-06-21 15:46:03.783616
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert isinstance(Address().longitude(), float)


# Generated at 2022-06-21 15:46:13.813808
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    print(Address().street_suffix())


# Generated at 2022-06-21 15:46:15.866245
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address(seed=0)
    assert a.street_number(10) == '6'


# Generated at 2022-06-21 15:46:20.109563
# Unit test for method street_number of class Address
def test_Address_street_number():
    print("Testing Address class method street_number")
    my_address = Address()
    my_street_number = my_address.street_number(maximum=1000)

    assert isinstance(my_street_number, str)
    assert my_street_number != ""


# Generated at 2022-06-21 15:46:21.271721
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    assert address.city().isalnum()


# Generated at 2022-06-21 15:46:24.261585
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    region = a.region()
    assert isinstance(region, str)
    assert len(region) in (2, 3, 4)


# Generated at 2022-06-21 15:46:29.773710
# Unit test for method province of class Address
def test_Address_province():
    a = Address(locale='zh-tw')
    assert a.province() in ('CZ', 'TA', 'TP', 'TC')
    assert a.province(abbr=True) in ('臺北市', '臺中市', '臺南市', '高雄市')
    a = Address(locale='ja')
    assert a.province() in ('北海道', '青森県', '岩手県', '宮城県', '秋田県')
    assert a.province(abbr=True) in ('01', '02', '03', '04', '05')
    a = Address(locale='en')

# Generated at 2022-06-21 15:46:31.423089
# Unit test for method latitude of class Address
def test_Address_latitude():
    test_obj = Address()
    latitude = test_obj.latitude()
    assert latitude ==-54.497329
test_Address_latitude()

# Generated at 2022-06-21 15:46:38.759876
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode

    country_choice = {"BG", "CH", "CZ", "DE", "DK", "EE", "ES", "FR", "GB", "GR", "HR", "HU", "IE",
                      "IT", "LT", "LV", "NL", "NO", "PL", "RO", "SE", "SK", "UA"}
    object_adress = Address()
    assert object_adress.state() in country_choice
    assert object_adress.state(abbr = True) in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-21 15:46:42.620971
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    result = address.state()
    correct = True if result in address._data['state']['abbr'] or result in address._data['state']['name'] else False
    assert correct

# Generated at 2022-06-21 15:46:46.566129
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address"""
    assert Address().region() in ['CA', 'SM', 'QC', 'BA', 'AB', 'YT', 'SK', 'PE', 'MB', 'NB', 'NS', 'NL', 'ON', 'NT', 'NU']

# Generated at 2022-06-21 15:47:10.318557
# Unit test for method country of class Address
def test_Address_country():

    # test case 1
    # ARGUMENTS:
    #
    # RETURN:
    #   random country name
    #

    a = Address()
    assert isinstance(a.country(True), str)
    assert isinstance(a.country(False), str)


# Generated at 2022-06-21 15:47:11.516096
# Unit test for method province of class Address
def test_Address_province():
    assert len(Address().province()) == len('Wyoming')

# Generated at 2022-06-21 15:47:14.377796
# Unit test for method street_number of class Address
def test_Address_street_number():
    addresses = Address()
    for _ in range(20):
        assert (addresses.street_number() >= 1 and
                addresses.street_number() <= 1400)


# Generated at 2022-06-21 15:47:18.187526
# Unit test for method longitude of class Address
def test_Address_longitude():
    # without dms
    longitude = Address().longitude()
    assert  longitude <= 180 and longitude >= -180

    # with dms
    longitude = Address().longitude(True)
    assert len(longitude) == 8 and longitude[-1] in ['W', 'E']


# Generated at 2022-06-21 15:47:22.582726
# Unit test for constructor of class Address
def test_Address():
    assert Address().seed == '42'
    assert Address(seed=7).seed == '7'
    assert Address().locale == 'en'
    assert Address(locale='ru').locale == 'ru'

# Generated at 2022-06-21 15:47:28.097670
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    random_continent = address.random.choice(address._data['continent'])
    random_continent_code = address.random.choice(CONTINENT_CODES)
    assert address.continent() == random_continent
    assert address.continent(code=True) == random_continent_code


# Generated at 2022-06-21 15:47:35.335827
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address(locale='zh-CN')
    # 只有一个参数
    country_code = address.country_code()
    assert country_code in COUNTRY_CODES['A2']
    # 有两个参数
    country_code = address.country_code(CountryCode.A3)
    assert country_code in COUNTRY_CODES['A3']

# Generated at 2022-06-21 15:47:47.235940
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.providers import Address
    from mimesis.enums import CountryCode

    a = Address('it')
    assert len(a.postal_code()) == 5
    assert a.postal_code().isdigit() is True

    a = Address('ru')
    assert len(a.postal_code()) == 6
    assert a.postal_code().isdigit() is True

    a = Address('jp')
    assert len(a.postal_code()) == 7
    assert a.postal_code().isdigit() is True

    a = Address('us')
    assert a.postal_code().isalpha() is True
    assert len(a.postal_code()) == 5

    a = Address('br')
    assert a.postal_code() == '00000-000'

   

# Generated at 2022-06-21 15:47:48.806691
# Unit test for method province of class Address
def test_Address_province():
    from mimesis import Address
    addr = Address()
    print(addr.province())

# Generated at 2022-06-21 15:47:52.689392
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test method street_suffix of class Address.

    :return: Nothing.
    """
    a = Address(seed=123456)
    assert a.street_suffix() == 'Street'


# Generated at 2022-06-21 15:48:41.777818
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    latitude = address.latitude()
    print('----------test_Address_latitude----------')
    print('latitude = ' + str(latitude))
    print('----------test_Address_latitude----------')


# Generated at 2022-06-21 15:48:44.321556
# Unit test for method state of class Address
def test_Address_state():
    """Unit test address_state."""
    address = Address(locale='en')
    assert len(address.state()) == 2


# Generated at 2022-06-21 15:48:47.948746
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # We create a context manager for class Address
    with Address() as cls_address:
        # We create an assert for the returned result
        assert cls_address.street_suffix() in cls_address._data['street']['suffix']


# Generated at 2022-06-21 15:48:50.349675
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert isinstance(address.postal_code(), str)
    assert not address.postal_code().endswith('-')

# Generated at 2022-06-21 15:48:54.611351
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    result = a.longitude()
    assert isinstance(result, float) or isinstance(result, str)
    assert not isinstance(result, int)


# Generated at 2022-06-21 15:48:55.693931
# Unit test for method street_number of class Address
def test_Address_street_number():
    pass


# Generated at 2022-06-21 15:48:57.785073
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    zip_code = a.zip_code()
    assert zip_code is not None

# Generated at 2022-06-21 15:49:05.622538
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address.country_code() in COUNTRY_CODES['A2']
    assert Address.country_code(fmt=CountryCode.A3) in COUNTRY_CODES['A3']
    assert Address.country_code(fmt=CountryCode.NUMERIC) in COUNTRY_CODES['NUMERIC']

    assert Address.country_code(fmt=CountryCode.A2) not in COUNTRY_CODES['A3']
    assert Address.country_code(fmt=CountryCode.A3) not in COUNTRY_CODES['NUMERIC']
    assert Address.country_code(fmt=CountryCode.NUMERIC) not in COUNTRY_CODES['A2']

    assert Address.country_code(fmt='sd') == ''


# Generated at 2022-06-21 15:49:07.784649
# Unit test for method city of class Address
def test_Address_city():
    assert type(Address.city()) is str


# Generated at 2022-06-21 15:49:09.236087
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None


# Generated at 2022-06-21 15:51:00.664166
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.localization import get_locale
    from mimesis.data import LOCALES
    LANGUAGES = LOCALES['language'].keys()

    for language in LANGUAGES:
        provider = Address(language)
        assert provider.region() != ''
        assert isinstance(provider.region(), str)
        assert isinstance(provider.region(abbr=True), str)
        assert isinstance(provider.province(), str)
        assert isinstance(provider.province(abbr=True), str)
        assert isinstance(provider.federal_subject(), str)
        assert isinstance(provider.federal_subject(abbr=True), str)
        assert isinstance(provider.prefecture(), str)

# Generated at 2022-06-21 15:51:03.099421
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test method coordinates of class Address."""
    address = Address()

    lat = address.latitude()
    lon = address.longitude()

    assert lat is not None
    assert lon is not None


# Generated at 2022-06-21 15:51:04.432420
# Unit test for constructor of class Address
def test_Address():
    # Testing the constructor of Address class
    address = Address()

    assert isinstance(address, Address)


# Generated at 2022-06-21 15:51:05.621566
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    _address = Address()
    x = _address.street_suffix()
    pass


# Generated at 2022-06-21 15:51:06.547683
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    a.city()


# Generated at 2022-06-21 15:51:09.775451
# Unit test for method street_name of class Address
def test_Address_street_name():
    import pandas as pd
    dic = {  'method': [],
             'result': []}
    for i in range(0, 3):
        address = Address()
        dic['method'].append(address.street_name)
        dic['result'].append('')
    df = pd.DataFrame(dic)
    print(df)
    

# Generated at 2022-06-21 15:51:18.711014
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    import random
    import re

    pattern = re.compile(r'\d+')

    addr = Address('en')
    postal_code = addr.postal_code()
    assert pattern.search(postal_code) is not None
    m = pattern.search(postal_code)
    res = m.group()
    num = int(res)
    assert num <= 99999 and num > 0
    if addr.locale == 'en':
        assert len(postal_code) == 5
    if addr.locale == 'ru':
        assert len(postal_code) == 6

    # Postal code is not None
    postal_code = addr.postal_code()
    assert isinstance(postal_code, str)

    # Postal code is integer
    postal_code = addr.postal_code()


# Generated at 2022-06-21 15:51:21.553276
# Unit test for method longitude of class Address
def test_Address_longitude():
    AD = Address(locale='zh')
    print(AD.longitude(dms=True))
    print(AD.longitude(dms=False))

# Generated at 2022-06-21 15:51:29.993584
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address."""
    addr = Address(locale='en')
    result = addr.coordinates(dms=True)

# Generated at 2022-06-21 15:51:31.457149
# Unit test for method state of class Address
def test_Address_state():
    new_address = Address()
    assert new_address.state() in new_address._data['state']['name']


# Generated at 2022-06-21 15:53:24.317380
# Unit test for method province of class Address
def test_Address_province():
    test_address = Address('en')
    assert test_address.province() in test_address._data['state']['name']

# Generated at 2022-06-21 15:53:26.534989
# Unit test for method city of class Address
def test_Address_city():
    """Unit test for Address.city()."""
    address = Address()
    assert isinstance(address.city(), str)



# Generated at 2022-06-21 15:53:28.433069
# Unit test for method state of class Address
def test_Address_state():
    gen = Address()
    x = gen.state(abbr=False)
    y = gen.state(abbr=True)
    return x, y


# Generated at 2022-06-21 15:53:30.418387
# Unit test for method country_code of class Address
def test_Address_country_code():
    gen = Address()
    for t,i in CountryCode.__members__.items():
        assert gen.country_code(i) in COUNTRY_CODES[t]


# Generated at 2022-06-21 15:53:32.050863
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('ru')
    address.street_name()

# Unit  test for method address of class Address

# Generated at 2022-06-21 15:53:34.178033
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    res = addr.address()
    assert res

# Generated at 2022-06-21 15:53:35.745046
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    expected = "Rue"
    assert address.street_suffix() == expected


# Generated at 2022-06-21 15:53:41.742294
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    import pytest
    from hypothesis import given, settings, strategies as st
    from mimesis.data import CITY_NAME

    seed = 0
    test_data = [
        ('en', 'Russian Federation', 'ru', 'Moscow'),
        ('de', 'South Africa', 'de', 'Moskau'),
        ('en', 'Russian Federation', 'en', 'Moscow'),
        ('uk', 'United Kingdom', 'en', 'Moscow'),
        ('fr', 'France', 'fr', 'Moscou'),
        ('ja', 'Japan', 'ja', 'モスクワ'),
        ('es', 'Spain', 'es', 'Moscú'),
        ('it', 'Italy', 'it', 'Mosca'),
    ]


# Generated at 2022-06-21 15:53:42.914988
# Unit test for constructor of class Address
def test_Address():
    """Test for constructor of class Address."""
    addr = Address()
    assert addr.__class__.__name__ == 'Address'

# Generated at 2022-06-21 15:53:47.614895
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    # Run 100 times
    for value in range(100):
        # Save value in string
        value = str(value)
        # Create zip code by calling method address()
        zip_code = address.zip_code()
        assert zip_code[0:4] == value[0]
        assert zip_code[4] == value[1]