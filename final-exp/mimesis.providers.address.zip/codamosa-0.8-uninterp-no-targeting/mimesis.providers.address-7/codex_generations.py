

# Generated at 2022-06-21 15:45:36.511457
# Unit test for method region of class Address
def test_Address_region():
    pass

# Generated at 2022-06-21 15:45:37.311214
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())

# Generated at 2022-06-21 15:45:38.641103
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    provider = Address()
    print(provider.calling_code())

# Generated at 2022-06-21 15:45:40.605453
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.enums import Locale
    a = Address(Locale.JA)
    print(a.street_name())


# Generated at 2022-06-21 15:45:42.472904
# Unit test for method country of class Address
def test_Address_country():
    address = Address(locale='nld')
    assert address.country() != address.country(allow_random=True)

# Generated at 2022-06-21 15:45:47.288663
# Unit test for method province of class Address
def test_Address_province():
    locale = "en"
    seed = 999

    expected_value = 'NJ'

    obj = Address(locale, seed)
    actual_value = obj.province(True)

    assert actual_value == expected_value, \
        "Unexpected returned value"


# Generated at 2022-06-21 15:45:49.085706
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    country = a.country()
    assert country != ''

# Generated at 2022-06-21 15:45:57.081602
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import CountryCode
    from mimesis.locales import Locale

    a = Address(Locale.RU)

    assert a.country() == 'Россия'
    assert a.country(allow_random=True) in a._data['country']['name']

    assert a.country_code() in COUNTRY_CODES[CountryCode.A2]
    assert a.country_code(fmt=CountryCode.A3) \
        in COUNTRY_CODES[CountryCode.A3]
    assert a.country_code(fmt=CountryCode.NUMERIC) \
        in COUNTRY_CODES[CountryCode.NUMERIC]

# Generated at 2022-06-21 15:45:58.585495
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    address.address()

# Generated at 2022-06-21 15:46:01.183529
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import Country
    address = Address()
    code = address.calling_code(Country.RUSSIA)
    assert code == '7'


# Generated at 2022-06-21 15:46:11.459433
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import CountryCode

    a = Address('en')
    assert a.state() in a._data['state']['name']
    assert a.state(abbr=True) in a._data['state']['abbr']
    assert a.region() in a._data['state']['name']
    assert a.province() in a._data['state']['name']
    assert a.federal_subject() in a._data['state']['name']
    assert a.prefecture() in a._data['state']['name']

    assert a.country_code() in COUNTRY_CODES['a2']
    assert a.country_code(CountryCode.A2) in COUNTRY_CODES['a2']


# Generated at 2022-06-21 15:46:18.024839
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    from mimesis.providers.address import Address
    import colander
    continents = ['Europe', 'Asia', 'South America', 'Africa', 'North America', 'Oceania', 'Antarctica']
    for _ in range(200):
        assert address.continent() in continents or address.continent(code=True) in continents


# Generated at 2022-06-21 15:46:19.330124
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    code = address.country_code()

    assert code in COUNTRY_CODES[CountryCode.A2.name]

# Generated at 2022-06-21 15:46:27.377853
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # Initalizing new object of class Address
    address_1 = Address()
    # Getting federal subject and verifying it type
    address_1_federal_subject = address_1.federal_subject()
    assert isinstance(address_1_federal_subject, str)
    # Comparing federal subject with federal subject of Address
    address_2 = Address('ru')
    address_2_federal_subject = address_2.federal_subject()
    assert address_1_federal_subject != address_2_federal_subject


# Generated at 2022-06-21 15:46:30.249731
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address_ = Address()
    calling_code = address_.calling_code()
    print(calling_code)


# Generated at 2022-06-21 15:46:34.989164
# Unit test for method state of class Address
def test_Address_state():
    # Create instance of class Address
    address = Address()

    # Get the state
    state = address.state(abbr=True)

    # Check the type of the state
    assert isinstance(state, str)

    # Check length of the state
    assert len(state) == 2


# Generated at 2022-06-21 15:46:38.308087
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    print(address.latitude())
    print(address.longitude())
    print(address.coordinates())


    print(address.continent())
    print(address.city())


# Generated at 2022-06-21 15:46:39.569704
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address != None
    return

# Generated at 2022-06-21 15:46:44.479890
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # функция генерирует случайный код
    adr = Address()
    assert adr.calling_code() in CALLING_CODES
    
    

# Generated at 2022-06-21 15:46:52.923332
# Unit test for method province of class Address
def test_Address_province():
    # Initialize global variables
    global address
    # Create a global local object that contains address
    address = Address()
    # Get a random province of country
    # Note: The country is the address locale,
    #       in this case is 'en'
    province = address.province()
    # Assert that province is a string
    assert province, isinstance(province, str)

a = Address()
print(a.address())
print(a.address())
print(a.coordinates())
print(a.coordinates())
print(a.coordinates(True))
print(a.city())
print(a.city())
print(a.country())
print(a.country())
print(a.country(True))
print(a.country(True))
print(a.country_code())

# Generated at 2022-06-21 15:47:05.918139
# Unit test for method latitude of class Address
def test_Address_latitude():
    temp = Address()
    temp.latitude()


# Generated at 2022-06-21 15:47:14.474830
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import CountryCode
    address = Address()
    assert address.province() in address._data['state']['abbr']
    assert address.country_code(CountryCode.FULL) in COUNTRY_CODES[CountryCode.FULL]
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert address.street_name() in address._data['street']['name']
    assert address.calling_code() in CALLING_CODES
    assert address.region() in address._data['state']['name']
    assert address.prefecture() in address._data['state']['name']
    assert address.federal_subject() in address._data['state']['name']
    assert address.province() in address

# Generated at 2022-06-21 15:47:15.369067
# Unit test for constructor of class Address
def test_Address():
    addr = Address()
    assert addr

# Generated at 2022-06-21 15:47:16.757496
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert a.continent() in a._data["continent"]

# Generated at 2022-06-21 15:47:20.260118
# Unit test for constructor of class Address
def test_Address():
    # Params
    args = []
    kwargs = {
        'locale': 'en',
    }

    # Run
    address = Address(*args, **kwargs)

    # Assert
    assert address is not None
    assert address._datafile == 'address.json'
    assert address._data is not None

# Generated at 2022-06-21 15:47:30.258777
# Unit test for method state of class Address
def test_Address_state():
    """Test class Address.

    test_Address_state is a method to test Address.state

    :return: return a string
    :rtype: str
    """

    address = Address('en')
    test_case = {
        'state': 'VIC',
        'state_abbr': 'Hawaii',
        'region': 'UT',
        'region_abbr': 'Minnesota',
        'province': 'NSW',
        'province_abbr': 'Washington',
        'federal_subject': 'SA',
        'federal_subject_abbr': 'South Carolina',
        'prefecture': 'WA',
        'prefecture_abbr': 'Texas',
    }


# Generated at 2022-06-21 15:47:34.016325
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import Country
    a = Address(Country.AUSTRALIA)
    for i in range(0, 1000):
        s = a.calling_code()
    return

# Generated at 2022-06-21 15:47:39.981736
# Unit test for method city of class Address
def test_Address_city():
    # see the output
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(locale=Locale.EN)
    #print(type(address.city()))
    f=address.city()
    return f

a=test_Address_city()
print(a)
print(type(a))

# Generated at 2022-06-21 15:47:42.513168
# Unit test for method region of class Address
def test_Address_region():
    test_address = Address('ru')
    assert isinstance(test_address.region(), str)


# Generated at 2022-06-21 15:47:45.474432
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address.longitude(True)
    assert isinstance(a, str), 'Should be str'
    assert a != '0.000000'



# Generated at 2022-06-21 15:48:13.310447
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Create an object of class Address
    Address = Address()
    # Run method
    result = Address.calling_code()
    # Check result
    assert len(result) == 3
    assert result.startswith('+')

# Generated at 2022-06-21 15:48:15.292209
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # Create an instance of class Address
    addr = Address()
    # Test prefecture method
    assert addr.prefecture(abbr=True) in addr._data['state']['abbr']

# Generated at 2022-06-21 15:48:18.326200
# Unit test for method city of class Address
def test_Address_city():
    # Create a Address object
    testObject = Address('es')
    # Generate city
    res = testObject.city()
    # Assert if result is in city list
    assert res in testObject._data['city']


# Generated at 2022-06-21 15:48:20.923268
# Unit test for method latitude of class Address
def test_Address_latitude():
    latitude = Address.latitude()
    assert latitude
    assert isinstance(latitude, float)
    assert latitude >= -90
    assert latitude <= 90


# Generated at 2022-06-21 15:48:22.904110
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject()


# Generated at 2022-06-21 15:48:25.250387
# Unit test for method longitude of class Address
def test_Address_longitude():
  a = Address(locale='en')
  assert -180 <= a.longitude() <= 180


# Generated at 2022-06-21 15:48:26.758051
# Unit test for method latitude of class Address
def test_Address_latitude():
    """


    """
    test_Address = Address()
    print(test_Address.latitude())


if __name__ == '__main__':
    test_Address_latitude()

# Generated at 2022-06-21 15:48:28.639094
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address("en")
    print('Random prefecture: ' + address.prefecture())


# Generated at 2022-06-21 15:48:33.736851
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # prepare test objects
    address_provider = Address()
    country_codes = set()
    # call calling_code method and collect result
    for i in range(200):
        country_codes.add(address_provider.calling_code())
    # check if there are duplicated country codes
    assert len(country_codes) == len(CALLING_CODES)


# Generated at 2022-06-21 15:48:35.436661
# Unit test for method longitude of class Address
def test_Address_longitude():
    address=Address()
    assert type(address.longitude()) == float

# Generated at 2022-06-21 15:49:36.466250
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    assert a.province() in ['AB', 'AK', 'BC']

# Generated at 2022-06-21 15:49:38.117003
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    a.province()


# Generated at 2022-06-21 15:49:40.137464
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address('fi')
    result = address.longitude()
    assert type(result) == float



# Generated at 2022-06-21 15:49:41.080066
# Unit test for method province of class Address
def test_Address_province():
    pass


# Generated at 2022-06-21 15:49:44.142130
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    import os
    import sys
    code = Address().calling_code()
    # print("Calling code: ", code)
    print("{id}: {msg}".format(id=sys._getframe().f_code.co_name, msg=""))
    assert code


# Generated at 2022-06-21 15:49:49.300980
# Unit test for method continent of class Address
def test_Address_continent():
    test_address = Address('es')
    result1 = test_address.continent()
    result2 = test_address.continent(code=True)
    assert result1 in ['América', 'Asia', 'África', 'Europa', 'Oceanía']
    assert result2 in ['AF', 'AS', 'EU', 'OC', 'NA', 'SA']

# Generated at 2022-06-21 15:49:56.412633
# Unit test for method street_name of class Address
def test_Address_street_name():
    print("\nTesting Address_street_name()")
    street = Address(locale='en')
    for _ in range(1, 11):
        assert street.street_name() in ['Sinton Trail', 'Pankratz Alley', 'Lillian Alley', 'Kessler Highway', 'Kingsford Court', 'Crista Point', 'Columbus Circle', 'Namekagon Lane', 'Pankratz Center', 'Green Ridge Gateway']


# Generated at 2022-06-21 15:49:57.954246
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address('en')
    assert type(a.coordinates()) == dict


# Generated at 2022-06-21 15:50:02.375313
# Unit test for method state of class Address
def test_Address_state():
    class _Address(Address):
        class Meta:
            locales = ['en']
    addr = _Address()
    assert addr.state(abbr=True) in addr._data['state']['abbr']
    assert addr.state() in addr._data['state']['name']

# Generated at 2022-06-21 15:50:05.171824
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address(locale='ko')
    postal_code = address.postal_code()
    assert len(postal_code) == 6


# Generated at 2022-06-21 15:51:10.691152
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    # test
    assert len( a.calling_code() ) == 3

# Generated at 2022-06-21 15:51:12.493086
# Unit test for method region of class Address
def test_Address_region():
    address = Address(locale='es')
    state = address.region()
    assert state != None

# Generated at 2022-06-21 15:51:14.147056
# Unit test for method longitude of class Address
def test_Address_longitude():
    test = Address()
    assert type(test.longitude()) is float
    assert test.longitude(dms=True)

# Generated at 2022-06-21 15:51:17.349988
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import Country
    ad = Address('ru')
    a = ad.street_number()
    assert (a <= 1400)
    # Also, this method supports only integer arguments
    ad.street_number(2)


# Generated at 2022-06-21 15:51:19.012704
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.builtins.address import Address
    zipcode = Address('en')
    print(zipcode.zip_code())


# Generated at 2022-06-21 15:51:20.701515
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert len(Address().latitude()) == 7


# Generated at 2022-06-21 15:51:22.819212
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    loc = 'en'
    a = Address(locale=loc)
    res = a.postal_code()
    assert res[0:3] == loc.upper()

# Generated at 2022-06-21 15:51:24.222492
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country() == "Germany"

# Generated at 2022-06-21 15:51:31.835241
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import Country
    from mimesis.locales import Locale

    a = Address(locale='en')
    #print(a.region())
    #print(a.province())
    #print(a.federal_subject())
    #print(a.prefecture())

    a = Address(locale='ru')
    #print(a.region())
    #print(a.province())
    #print(a.federal_subject())
    #print(a.prefecture())

    a = Address(locale='jp')
    #print(a.region())
    #print(a.province())
    #print(a.federal_subject())
    #print(a.prefecture())

    #print(locale_provider.territory)
    #print(Loc

# Generated at 2022-06-21 15:51:40.774573
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province(abbr = True) in [
        'AZ',
        'DE',
        'WY',
        'SD',
        'RI',
        'WV',
        'WA',
        'OR',
        'ME',
        'VT',
        'NY',
        'NH',
        'ND',
        'DC',
        'RI',
        'NV',
        'NE',
        'MT',
        'KY'
    ]

# Generated at 2022-06-21 15:54:05.701502
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('en')
    assert isinstance(address.postal_code(), str) 


# Generated at 2022-06-21 15:54:06.777721
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a is not None


# Generated at 2022-06-21 15:54:08.428499
# Unit test for method street_name of class Address
def test_Address_street_name():
    expected = "Ленина улица"
    actual = Address('ru').street_name()
    assert actual == expected


# Generated at 2022-06-21 15:54:09.524397
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code() in CALLING_CODES

# Generated at 2022-06-21 15:54:10.525363
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='en')
    print(adr.address())

# Generated at 2022-06-21 15:54:11.922572
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    assert len(a.zip_code()) > 0

# Generated at 2022-06-21 15:54:14.802867
# Unit test for method latitude of class Address
def test_Address_latitude():

    address = Address('en')
    latitude = address.latitude()

    assert isinstance(latitude, float) or isinstance(latitude, str)


# Generated at 2022-06-21 15:54:19.194873
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for method federal_subject of class Address"""
    from mimesis.enums import Locale
    address = Address(Locale.RU)
    adr_reg = address.federal_subject()
    assert adr_reg in address._data['state']['name']


# Generated at 2022-06-21 15:54:21.285342
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    result = address.continent(code=False)

    assert isinstance(result, str) and len(result) != 0

# Generated at 2022-06-21 15:54:25.242560
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    import random
    loc = 'en'
    Address_street_suffix = Address(loc)
    Street_suffix_value = Address_street_suffix.street_suffix()
    Street_suffix_list = ['Street', 'Avenue', 'Boulevard', 'Drive', 'Court', 'Place', 'Square', 'Lane']
    random.seed(1)   
    assert Street_suffix_value in Street_suffix_list
