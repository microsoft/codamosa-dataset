

# Generated at 2022-06-21 15:45:36.609981
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address(locale='ja').zip_code() == '356-0005'



# Generated at 2022-06-21 15:45:38.130494
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    assert a.postal_code() == a.postal_code()

# Generated at 2022-06-21 15:45:40.469865
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country(allow_random=True) in Address()._data['country']['name']
    assert Address().country() == 'Indonesia'


# Generated at 2022-06-21 15:45:42.071048
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    result = address.zip_code()
    assert result
    assert result >= 1


# Generated at 2022-06-21 15:45:54.232078
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    address = Address('zh')
    add1 = address.street_name()
    assert type(add1) == str


# Generated at 2022-06-21 15:46:02.120659
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # 测试随机街道后缀
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    
    russian = RussiaSpecProvider(locale=Locale.RU)
    russian.address.street_suffix()
    russian.address.street_suffix()
    russian.address.street_suffix()
    russian.address.street_suffix()
    russian.address.street_suffix()
    russian.address.street_suffix()
    russian.address.street_suffix()

# Generated at 2022-06-21 15:46:03.784162
# Unit test for method region of class Address
def test_Address_region():
    Address().region().should.be.a('str')



# Generated at 2022-06-21 15:46:05.403703
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert address.prefecture() in address._data['state']['abbr']


# Generated at 2022-06-21 15:46:12.913024
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """unit test for method federal_subject of class Address."""
    from mimesis.enums import CountryCode
    from mimesis.enums import Locale
    address = Address(Locale.ENGLISH)
    for _ in range(100):
        assert address.federal_subject() in address._data['state']['name']
        assert address.federal_subject(abbr=True) in address._data['state']['abbr']


# Generated at 2022-06-21 15:46:16.585127
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test Address.country_code()."""
    address = Address('ru')
    country_code = address.country_code()
    assert country_code in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-21 15:46:22.516360
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    longitude_value = address.longitude()
    assert longitude_value <= 180
    assert longitude_value >= -180

# Generated at 2022-06-21 15:46:24.353863
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country(allow_random=True) == 'Bosnia and Herzegovina'

# Generated at 2022-06-21 15:46:28.830084
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = Address()
    assert isinstance(a, Address)
    assert isinstance(a.address(), str)


# Generated at 2022-06-21 15:46:29.483227
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() == 'Africa'

# Generated at 2022-06-21 15:46:31.500506
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address)


# Generated at 2022-06-21 15:46:34.176032
# Unit test for method latitude of class Address
def test_Address_latitude():
    provider = Address()
    lat = provider.latitude()
    print("latitude : ", lat)
    assert isinstance(lat, float)


# Generated at 2022-06-21 15:46:36.378716
# Unit test for constructor of class Address
def test_Address():
    """Test Address() class."""
    data = Address('en')
    assert data.locale == 'en'
    assert data.provider == 'address'

# Generated at 2022-06-21 15:46:39.089543
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address("en")
    latitude = a.latitude(dms=False)
    assert latitude is not None
    assert isinstance(latitude, float)


# Generated at 2022-06-21 15:46:42.003766
# Unit test for method latitude of class Address
def test_Address_latitude():
    # address = Address(locale='en')
    address = Address()
    print(address.latitude())


# Generated at 2022-06-21 15:46:45.551917
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    print("Country code (Alpha 2): ", a.country_code(fmt=CountryCode.A2))
    print("Country code (Alpha 3): ", a.country_code(fmt=CountryCode.A3))

# Generated at 2022-06-21 15:46:58.332020
# Unit test for method country of class Address
def test_Address_country():
    """Unit test Address.country() method."""
    addr = Address(locale='en')
    assert addr.country() == 'United States of America'


# Generated at 2022-06-21 15:46:59.893035
# Unit test for constructor of class Address
def test_Address():
    Addresses = Address(locale='en')
    assert Addresses

# Generated at 2022-06-21 15:47:04.819310
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.enums import Gender
    from mimesis.providers.person import Person
    a = Address("en")
    print(a.longitude())
    print(a.longitude(dms=True))
    a.random.seed(12345)
    print(a.longitude())
    print(a.longitude(dms=True))

# Generated at 2022-06-21 15:47:06.408736
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert Address(seed=0).street_number() == '1228'


# Generated at 2022-06-21 15:47:14.794930
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address."""
    address = Address(locale='en', seed=1234)
    assert (
        address.country_code(CountryCode.A2)
        == 'ST'
    ), 'Wrong country code.'

    assert (
        address.country_code(CountryCode.A3)
        == 'STP'
    ), 'Wrong country code.'

    assert (
        address.country_code(CountryCode.NUMERIC)
        == '678'
    ), 'Wrong country code.'

    assert (
        address.country_code(CountryCode.FULL_NAME_EN)
        == 'Sao Tome and Principe'
    ), 'Wrong country code.'


# Generated at 2022-06-21 15:47:16.250520
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    print("Address: ", a.country())



# Generated at 2022-06-21 15:47:18.461060
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    postal_code = address.postal_code()
    assert isinstance(postal_code, str)
    print(postal_code)


# Generated at 2022-06-21 15:47:27.586970
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    address = Address()
    assert address.calling_code() in CALLING_CODES
    assert address.country(allow_random=True) in address._data['country']['name']
    assert address.country_code(fmt=CountryCode.A3) in COUNTRY_CODES['a3']
    assert address.state(True) in address._data['state']['abbr']
    assert address.postal_code() in address._data['postal_code_fmt']
    assert address.zip_code() in address._data['postal_code_fmt']
    assert address.address() in address._data['address_fmt']
    assert address.city() in address._data['city']

# Generated at 2022-06-21 15:47:29.897849
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    assert address.country() in ['China', 'Macau', 'Taiwan']


# Generated at 2022-06-21 15:47:31.641299
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert type(a) is not None

# Generated at 2022-06-21 15:47:55.585266
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Precondition:
    #   Calling code should be between 1 and 3 digits
    #   Calling code should be an integer

    # Test 1: Calling code should be between 1 and 3 digits
    assert len(Address().calling_code()) <= 3

    # Test 2: Calling code should be an integer
    assert Address().calling_code().isdigit()

# Generated at 2022-06-21 15:47:57.384667
# Unit test for method street_number of class Address
def test_Address_street_number():
    addr = Address()
    res = addr.street_number()
    assert type(res) == str
    assert int(res) > 0


# Generated at 2022-06-21 15:48:01.704276
# Unit test for method region of class Address
def test_Address_region():
    # Initialize class Address with locale ru_RU
    generate_region = Address('ru')
    
    # Call method region with arguments abbr=False
    region = generate_region.region(abbr=False)

    # Check result
    assert isinstance(region, str), \
        f'Method region returned {type(region)}, not str'
    
test_Address_region()


# Generated at 2022-06-21 15:48:04.684601
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    if a.country() == 'China':
        print('Test success!')
    else:
        print('Test fail!')


# Generated at 2022-06-21 15:48:07.957780
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test country_code method of class Address."""
    gen = Address()
    assert len(gen.country_code()) == 2, "method country_code is wrong"



# Generated at 2022-06-21 15:48:09.824575
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    assert 1 <= int(a.street_number()) <= 1400


# Generated at 2022-06-21 15:48:11.688367
# Unit test for method city of class Address
def test_Address_city():
    """Unit test for method city of class Address."""
    a = Address()
    assert len(a.city()) > 0



# Generated at 2022-06-21 15:48:18.766699
# Unit test for method city of class Address
def test_Address_city():
    _instance = Address()
    data_set = {
        'en': 'Addison',
        'fr': 'Cordova',
        'de': 'Aachen',
        'es': 'Pueblo',
        'it': 'Milan',
        'ru': 'Агейск',
        'nl': 'Groningen',
        'pt': 'Porto',
        'ja': 'Matsusaka Shi',
        'ar': 'أنطاليا',
        'zh': 'Yulinshi',
        'ko': '서울',
        'id': 'Depok',
        'tr': 'İstanbul',
    }
    for key, value in data_set.items():
        _instance = Address(key)
        assert _instance.city()

# Generated at 2022-06-21 15:48:27.859807
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    b = a.coordinates(dms=False)
    c = a.coordinates(dms=True)

    assert isinstance(b, dict)
    assert isinstance(c, dict)
    assert b['longitude'] != c['longitude']
    assert b['latitude'] != c['latitude']
    assert isinstance(b['longitude'], float)
    assert isinstance(b['latitude'], float)
    assert isinstance(c['longitude'], str)
    assert isinstance(c['latitude'], str)

# Generated at 2022-06-21 15:48:32.157982
# Unit test for method country of class Address
def test_Address_country():
    """Test for the Address.country() method."""
    provider = Address()

    country = provider.country()
    country1 = provider.country(allow_random=True)
    assert country
    assert country1
    assert isinstance(country, str)
    assert isinstance(country1, str)



# Generated at 2022-06-21 15:49:15.253413
# Unit test for method continent of class Address
def test_Address_continent():
    pass

# Generated at 2022-06-21 15:49:21.647111
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    address = Address('ru')
    result = address.province()
    assert result in address._data['state']['name']
    address_province_abbr = address.province(abbr=True)
    assert address_province_abbr in address._data['state']['abbr']
    assert len(address_province_abbr) == 2
    assert address.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert address.country_code(CountryCode.NUM) in COUNTRY_CODES[CountryCode.NUM]

# Generated at 2022-06-21 15:49:23.285816
# Unit test for method city of class Address
def test_Address_city():
    assert Address().city() == "Красноярск"


# Generated at 2022-06-21 15:49:24.429371
# Unit test for method longitude of class Address
def test_Address_longitude():
    ad = Address()
    print(ad.longitude())


# Generated at 2022-06-21 15:49:28.869364
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address(locale='ru')
    assert address.federal_subject() in ['Алтайский край', 'Сахалинская обл']

# Generated at 2022-06-21 15:49:31.363540
# Unit test for method state of class Address
def test_Address_state():
    """Test state method of Address class"""
    assert len(Address().state()) == 2


# Generated at 2022-06-21 15:49:34.018686
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(locale="zh")
    a = addr.address()
    print(a)

# Generated at 2022-06-21 15:49:44.172987
# Unit test for constructor of class Address
def test_Address():
    '''
    Función para probar la clase Address
    '''
    from mimesis.enums import CountryCode
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    address = Address('es')

    assert isinstance(address.country_code(CountryCode.A2), str)
    assert isinstance(address.region(), str)
    assert address.country() == 'España'
    assert isinstance(address.region(), str)
    assert isinstance(address.continent(), str)
    assert isinstance(address.calling_code(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.street_name(), str)
    assert isinstance(address.street_suffix(), str)

# Generated at 2022-06-21 15:49:52.524063
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    ad=Address()
    # Test1
    if len(ad.federal_subject())==2:
        print('test_Address_federal_subject1 passed')
    else:
        print('test_Address_federal_subject1 failed')
    # Test2
    if ad.federal_subject(abbr=True) in ad._data['state']['abbr']:
        print('test_Address_federal_subject2 passed')
    else:
        print('test_Address_federal_subject2 failed')


# Generated at 2022-06-21 15:50:01.377282
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()

    # Default result for coordinates
    c1 = address.coordinates()
    assert isinstance(c1, dict)
    assert isinstance(c1['longitude'], float)
    assert isinstance(c1['latitude'], float)

    # Default result for longitude
    long = address.longitude()
    assert isinstance(long, float)

    # Default result for latitude
    lat = address.latitude()
    assert isinstance(lat, float)

    # Result for coordinates with True dms param
    c2 = address.coordinates(dms=True)
    assert isinstance(c2, dict)
    assert isinstance(c2['longitude'], str)
    assert isinstance(c2['latitude'], str)

    # Result for longitude with True dms param
    long_

# Generated at 2022-06-21 15:50:55.638428
# Unit test for method street_number of class Address
def test_Address_street_number():
    x = Address()
    street_num = x.street_number()
    assert '.' not in street_num and "-" not in street_num


# Generated at 2022-06-21 15:51:00.866393
# Unit test for method street_number of class Address
def test_Address_street_number():
    
    from mimesis import Address
    from mimesis import Seed
    #print(Seed.generate(source=Seed.MACHINE, length=10))
    address = Address('en', Seed.generate(source=Seed.MACHINE, length=10))
    #print(address.street_number(),Address.street_number.__name__)
    # Returns '636'
    return address.street_number()

# Generated at 2022-06-21 15:51:02.187305
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    res = a.coordinates()
    assert len(res) == 2


# Generated at 2022-06-21 15:51:06.086297
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Test federal_subject function returns a string that contains the name of the region of Brazil,
    a string that contains the ISO code 8601 of a region of Brazil,
    or another string that is a two-letter code of a region of Brazil."""
    # Normal Case
    import random
    random.seed(1) # Seed for repeatability
    for i in range(100):
        assert isinstance(Address().federal_subject(),str)


# Generated at 2022-06-21 15:51:07.438683
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    check_code = "RU"
    address = Address()
    assert address.federal_subject() == check_code


# Generated at 2022-06-21 15:51:09.306812
# Unit test for method country of class Address
def test_Address_country():
    address = Address('uk')
    assert address.country(allow_random=False) == 'Great Britain'
    assert address.country(allow_random=True) in address._data['country']['name']

# Generated at 2022-06-21 15:51:11.070148
# Unit test for method longitude of class Address
def test_Address_longitude():
    try:
        address = Address()
        print(address.longitude(True))
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_Address_longitude()

# Generated at 2022-06-21 15:51:12.457374
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    assert a.federal_subject() != None

# Generated at 2022-06-21 15:51:21.372093
# Unit test for constructor of class Address
def test_Address():
    address = Address("en")
    assert address.__class__.__name__ == 'Address'
    assert address._data['street']['name'] == ["Adams", "Jefferson", "Madison", "Main", "Washington"]
    assert address._data['street']['suffix'] == ["Avenue", "Boulevard", "Commons", "Court", "Drive", "Lane", "Parkway", "Plaza", "Road", "Square", "Street", "Trail", "Way"]
    assert address._data['address_fmt'] == "{st_num} {st_name}"

# Generated at 2022-06-21 15:51:23.190036
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    country = a.country()
    assert isinstance(country, str)
    assert len(country) > 0