

# Generated at 2022-06-21 15:45:36.126934
# Unit test for constructor of class Address
def test_Address():
    from mimesis.builtins import Address
    a = Address('en')
    assert a._data

# Generated at 2022-06-21 15:45:39.364657
# Unit test for method latitude of class Address
def test_Address_latitude():
    import timeit

    address = Address()
    # print(timeit.timeit(lambda: address.latitude(),number=20))
    print(address.latitude())
    print(address.longitude())
    print(address.coordinates())


# Generated at 2022-06-21 15:45:41.277965
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    w = Address('en')
    assert w.zip_code() is not None 
    assert w.zip_code() is not None

# Generated at 2022-06-21 15:45:42.739949
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    assert address.street_name() in address._data['street']['name']

# Generated at 2022-06-21 15:45:54.630702
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.locale == 'en'
    assert address.random.choice(address._data['city']) == 'New York City'
    assert address.state() == 'New York'
    assert address.random.choice(COUNTRY_CODES[CountryCode.A2]) == 'US'
    assert address.random.choice(address._data['street']['name']) == 'Norman'
    assert address.random.choice(address._data['street']['suffix']) == 'Circle'
    assert address.random.choice(address._data['street']['name']) == 'Racquet'
    assert address.locale == 'en'
    assert address.random.choice(address._data['street']['name']) == 'Lake Park Drive'
    assert address.random.choice

# Generated at 2022-06-21 15:45:57.398006
# Unit test for method continent of class Address
def test_Address_continent():
    ad = Address()
    continent_name = ad.continent()
    continent_code = ad.continent(code=True)
    print(continent_name)
    print(continent_code)


# Generated at 2022-06-21 15:45:59.631924
# Unit test for method prefecture of class Address
def test_Address_prefecture():

    adr = Address()
    assert adr.prefecture() == '天津市'

# Generated at 2022-06-21 15:46:08.687128
# Unit test for method state of class Address
def test_Address_state():
    address = Address('en')
    state = address.state()
    assert state in (
        'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA', 'HI', 'ID',
        'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS',
        'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'OH', 'OK',
        'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV',
        'WI', 'WY')


# Generated at 2022-06-21 15:46:12.640478
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    # str
    assert isinstance(a.longitude(), str)
    # float
    assert isinstance(a.longitude(dms=False), float)

# Generated at 2022-06-21 15:46:14.258651
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert isinstance(result, str)


# Generated at 2022-06-21 15:46:20.549602
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert address.prefecture() in [
        'Miyagi',
        'Fukushima',
        'Ibaraki',
        'Chiba',
        'Tokyo',
        'Kanagawa',
    ]

# Generated at 2022-06-21 15:46:22.595065
# Unit test for method country of class Address
def test_Address_country():
    adr = Address()
    assert adr.country in adr._data['country']['name']


# Generated at 2022-06-21 15:46:23.876935
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    print(Address().coordinates())

if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-21 15:46:29.311009
# Unit test for method latitude of class Address
def test_Address_latitude():
    x = Address()
    # The result is float
    assert isinstance(x.latitude(), float)
    # The value is in range(-90,90)
    assert -90 <= x.latitude() <= 90


# Generated at 2022-06-21 15:46:31.350866
# Unit test for constructor of class Address
def test_Address():
    address = Address('es')
    assert address.city() == "M\'hamid"

# Generated at 2022-06-21 15:46:32.880278
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country() == a.country()


# Generated at 2022-06-21 15:46:39.522426
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address.country_code() in COUNTRY_CODES[CountryCode.A2]
    assert Address.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert Address.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]  # noqa
    assert Address.country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]  # noqa


# Generated at 2022-06-21 15:46:40.553950
# Unit test for method city of class Address
def test_Address_city():
    pass

# Generated at 2022-06-21 15:46:46.337719
# Unit test for method address of class Address
def test_Address_address():
    # Some locales are not supported
    locales = [
        'en',
        'pt-br',
        'ja',
        'ru',
    ]
    for i in range(len(locales)):
        # init Address class
        addr = Address(locales[i])
        # Generate address
        x = addr.address()
        # check its address
        assert x is not None

# Generated at 2022-06-21 15:46:48.182561
# Unit test for method country of class Address
def test_Address_country():
    """Test method country of class Address."""
    address_obj = Address(locale='ja')
    assert address_obj.country() == '日本'

# Generated at 2022-06-21 15:46:56.863128
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import DMSCoordinate

    a = Address()
    for i in range(100):
        assert (a.coordinates(i) == a.coordinates(i))
        assert (a.coordinates(DMSCoordinate.LATITUDE) == a.coordinates(DMSCoordinate.LATITUDE))
        assert (a.coordinates(DMSCoordinate.LONGITUDE) == a.coordinates(DMSCoordinate.LONGITUDE))
        assert (a.coordinates(DMSCoordinate.LATITUDE_AND_LONGITUDE) == a.coordinates(DMSCoordinate.LATITUDE_AND_LONGITUDE))

# Generated at 2022-06-21 15:47:01.003920
# Unit test for method address of class Address
def test_Address_address():
    # Initialization
    address_object = Address('en')
    # Execution
    address_method = address_object.address()
    # Assertion
    assert len(address_method) > 0


# Generated at 2022-06-21 15:47:02.634564
# Unit test for method region of class Address
def test_Address_region():
    address=Address('en')
    assert address.region() in address._data['state']['abbr']


# Generated at 2022-06-21 15:47:04.845104
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis import Address

    a = Address()
    print(a.latitude())
    print(a.latitude(dms=True))


# Generated at 2022-06-21 15:47:07.174504
# Unit test for constructor of class Address
def test_Address():
    addr = Address('en')
    assert isinstance(addr, Address)
    assert addr.locale == 'en'


# Generated at 2022-06-21 15:47:15.202685
# Unit test for method continent of class Address
def test_Address_continent():
    metadata = {'continent': ['Europe', 'Asia', 'Africa', 'North America', 'South America', 'Antarctica', 'Oceania']}
    temp = Address(metadata=metadata)
    current_key = list(metadata.keys())[0]
    temp.random.set_random_choices(metadata[current_key])
    test_data = [i for i in range(30)]
    result = [temp.continent(code=True) for _ in test_data]

# Generated at 2022-06-21 15:47:16.476015
# Unit test for method continent of class Address
def test_Address_continent():
    while True:
        print("continent: ", Address().continent())
        print("code: ", Address().continent(code=True))


# Generated at 2022-06-21 15:47:17.749754
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    s = Address()
    print(s.zip_code())

# Generated at 2022-06-21 15:47:22.947417
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    code_0 = address.continent()
    code_1 = address.continent(code=True)
    assert isinstance(code_0, str)
    assert isinstance(code_1, str)


# Generated at 2022-06-21 15:47:24.601710
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert address.street_number(maximum=1) == '1'


# Generated at 2022-06-21 15:47:33.186641
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert isinstance(address.zip_code(), str)


# Generated at 2022-06-21 15:47:35.397351
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    ad = Address('en')
    assert ad.zip_code() == ad.postal_code()


# Generated at 2022-06-21 15:47:41.053855
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.locale == Locale.EN

    address = Address(Locale.RU, seed=1)
    assert address.locale == Locale.RU

    address = Address(Locale.ES)
    assert address.locale == Locale.ES


# Generated at 2022-06-21 15:47:43.686020
# Unit test for method continent of class Address
def test_Address_continent():
    test_obj = Address()
    print(test_obj.continent())



# Generated at 2022-06-21 15:47:45.166949
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    result = address.street_name()
    assert result != None

# Generated at 2022-06-21 15:47:46.698362
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
	print(Address().federal_subject())


# Generated at 2022-06-21 15:47:48.300574
# Unit test for method street_name of class Address
def test_Address_street_name():
	assert Address().street_name() != None


# Generated at 2022-06-21 15:47:50.776043
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.builtins import Address
    adr = Address()
    postal_code = adr.postal_code()
    assert isinstance(postal_code, str)



# Generated at 2022-06-21 15:47:53.707457
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Generator of random values
    gen_random = Address()
    # Generate address
    postal_code = gen_random.postal_code()
    print('Postal code:', postal_code)


# Generated at 2022-06-21 15:47:55.190760
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    for i in range(10):
        print(a.street_name())


# Generated at 2022-06-21 15:48:12.693817
# Unit test for method city of class Address
def test_Address_city():
    assert Address(locale='ko').city() == '서울'

    assert Address(locale='ja').city() == '大阪'

    assert Address(locale='vi').city() == 'Hà Nội'



# Generated at 2022-06-21 15:48:14.151925
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('zh')
    assert address.prefecture() in address._data['state']['name']

# Generated at 2022-06-21 15:48:23.904368
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for country_code method of class Address."""
    from mimesis.enums import CountryCode

    a = Address('en')
    assert a.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    # TODO:
    # assert a.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert a.country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]
    assert a.country_code(CountryCode.FIFA) in COUNTRY_CODES[CountryCode.FIFA]
    assert a.country_code(CountryCode.IOC) in COUNTRY_CODES[CountryCode.IOC]

# Generated at 2022-06-21 15:48:26.791313
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    reg = Address(locale='ru')
    assert reg.federal_subject() in reg._data['state']['name']

# Generated at 2022-06-21 15:48:29.704033
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    lg = a.longitude()
    assert(type(lg) == float)
    assert(lg <= 180)
    assert(lg >= -180)

# Generated at 2022-06-21 15:48:35.128163
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Subject 1: postal_code with default locale
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.enums import Locale
    import re
    a = Address(random_data_provider=BaseSpecProvider(locale=Locale.EN))
    postal_code = a.postal_code() # Subject 1
    is_postal_code = re.match(r'[0-9]+', postal_code) is not None
    assert(is_postal_code)

# Generated at 2022-06-21 15:48:38.863482
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address('en')
    sn = a.street_number()
    assert isinstance(sn, str)
    assert len(sn) > 0


# Generated at 2022-06-21 15:48:40.978814
# Unit test for constructor of class Address
def test_Address():
    address = Address(seed=1234567)
    assert address.province() == 'E1'

# Generated at 2022-06-21 15:48:44.665804
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert a.continent() in CONTINENT_CODES
    assert a.continent(code=True) in [c.upper() for c in CONTINENT_CODES]


# Generated at 2022-06-21 15:48:46.576166
# Unit test for method province of class Address
def test_Address_province():
    adr = Address()
    assert hasattr(adr, 'province')


# Generated at 2022-06-21 15:49:19.416479
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import ContinentCode
    a = Address()
    code = a.continent(code=True)
    name = a.continent(code=False)
    assert isinstance(code, str)
    assert code in ContinentCode.__members__.keys()
    assert isinstance(name, str)
    assert name in a._data['continent']
test_Address_continent()



# Generated at 2022-06-21 15:49:21.939798
# Unit test for method postal_code of class Address
def test_Address_postal_code():
	
	ad = Address('en')
	pCode = ad.postal_code()
	print(pCode)
	assert len(pCode) == 5
	
	

# Generated at 2022-06-21 15:49:29.166263
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() in Address(Address)._data['street']['name']
    assert Address().street_name() in Address(Address)._data['street']['name']
    assert Address().street_name() in Address(Address)._data['street']['name']
    assert Address().street_name() in Address(Address)._data['street']['name']
    assert Address().street_name() in Address(Address)._data['street']['name']


# Generated at 2022-06-21 15:49:30.652793
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    result = address.street_number()
    print(result)
    assert result



# Generated at 2022-06-21 15:49:33.869504
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject() in Address()._data['state']['abbr']


# Generated at 2022-06-21 15:49:34.604824
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    pass

# Generated at 2022-06-21 15:49:39.523729
# Unit test for method street_number of class Address
def test_Address_street_number():
    inst = Address()
    assert inst.street_number(maximum=800)
    assert inst.street_number(maximum=1100)
    assert inst.street_number(maximum=800)
    assert inst.street_number(maximum=800)
    assert inst.street_number(maximum=800)


# Generated at 2022-06-21 15:49:41.288692
# Unit test for method country of class Address
def test_Address_country():
    provider = Address()

    for i in range(100):
        provider.country()


# Generated at 2022-06-21 15:49:43.475130
# Unit test for method continent of class Address
def test_Address_continent():
    """Test continent method of class Address."""
    provider = Address()
    continent = provider.continent()
    assert continent in provider._data['continent']


# Generated at 2022-06-21 15:49:45.357895
# Unit test for method country_code of class Address
def test_Address_country_code():
    for i in range(10):
        result = Address().country_code(CountryCode.A3)
        assert len(result) == 3


# Generated at 2022-06-21 15:50:56.625637
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert isinstance(street_name, str) == True


# Generated at 2022-06-21 15:50:58.518156
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    ad = Address("en")
    zip_code = ad.zip_code()
    assert len(zip_code) > 0


# Generated at 2022-06-21 15:51:00.322172
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    assert a.prefecture() in a._data['state']['abbr']

# Generated at 2022-06-21 15:51:01.382019
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    print(a.street_suffix())


# Generated at 2022-06-21 15:51:02.426056
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    ad = Address('en')
    ad.street_suffix()


# Generated at 2022-06-21 15:51:04.284905
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.builtins import RussiaSpecProvider
    provider = Address(RussiaSpecProvider)
    result = provider.city()
    assert result in provider._data['city']

# Generated at 2022-06-21 15:51:05.976027
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address(lang="en")
    for _ in range(10):
        result = a.zip_code()
        assert type(result) == str
        assert len(result) == 5

# Generated at 2022-06-21 15:51:07.830108
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state() in address._data['state']['name']
    assert address.state(abbr=True) in address._data['state']['abbr']


# Generated at 2022-06-21 15:51:08.552614
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    Address().zip_code()


# Generated at 2022-06-21 15:51:10.339878
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country() == 'Canada'
    assert Address(locale='en').country() == 'Canada'
    assert Address(locale='en-ca').country() == 'Canada'
