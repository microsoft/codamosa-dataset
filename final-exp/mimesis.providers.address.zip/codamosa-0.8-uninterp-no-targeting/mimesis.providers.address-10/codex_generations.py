

# Generated at 2022-06-21 15:45:37.135618
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    rnd = random.Random(0)
    address = Address(random=rnd)
    result = address.coordinates()
    assert result['latitude'] == -60.023096
    assert result['longitude'] == -123.186638

# Generated at 2022-06-21 15:45:43.169901
# Unit test for method country_code of class Address
def test_Address_country_code():
    try:
        address = Address('en')
        country = address.country_code(CountryCode.A2)
        assert isinstance(country, str)
        assert len(country) == 2
    except (KeyError, AssertionError):
        assert False
    
    try:
        address = Address('en')
        country = address.country_code(CountryCode.A3)
        assert isinstance(country, str)
        assert len(country) == 3
    except (KeyError, AssertionError):
        assert False

test_Address_country_code()

# Generated at 2022-06-21 15:45:54.934442
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    provider = Address(locale='pl')
    pattern = r'[0-9]{2}-[0-9]{3}'
    assert provider.postal_code() in pattern
    assert provider.zip_code() in pattern
    provider = Address(locale='en')
    assert provider.postal_code() in pattern
    assert provider.zip_code() in pattern
    provider = Address(locale='ja')
    assert provider.postal_code() == '200-4355'
    assert provider.zip_code() == '200-4355'
    provider = Address(locale='ru')
    assert provider.postal_code() == '117556'
    assert provider.zip_code() == '117556'
    provider = Address(locale='de')

# Generated at 2022-06-21 15:45:56.978360
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address(locale='es')
    for i in range(100):
        assert type(a.street_number()) == str


# Generated at 2022-06-21 15:46:02.737438
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address('de')
    for _ in range(30):
        street_name = address_obj.street_name()
        street_number = address_obj.street_number()
        street_suffix = address_obj.street_suffix()
        address = address_obj.address()
        assert street_name in address
        assert street_number in address
        assert street_suffix in address


# Generated at 2022-06-21 15:46:03.691902
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude()


# Generated at 2022-06-21 15:46:15.163500
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.builtins import Address

    a = Address(locale='ja')
    print(a.region(abbr=False))
    print(a.region(abbr=False))
    print(a.region(abbr=False))
    print(a.region(abbr=False))
    print(a.region(abbr=False))

    a1 = Address(locale='ko')
    print(a1.region(abbr=False))
    print(a1.region(abbr=False))
    print(a1.region(abbr=False))
    print(a1.region(abbr=False))
    print(a1.region(abbr=False))

    a2 = Address(locale='zh')

# Generated at 2022-06-21 15:46:19.204815
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address(use_local_data=False)
    res = a.coordinates()
    assert isinstance(res, dict)
    assert 'longitude' in res
    assert 'latitude' in res


# Generated at 2022-06-21 15:46:20.392610
# Unit test for method calling_code of class Address
def test_Address_calling_code():
	assert Address().calling_code() in CALLING_CODES


# Generated at 2022-06-21 15:46:23.095036
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    testAddress = Address()
    random_calling_code = testAddress.calling_code()
    assert random_calling_code in CALLING_CODES


# Generated at 2022-06-21 15:46:28.385083
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code() == '02069'

# Generated at 2022-06-21 15:46:32.381917
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    lat = a.latitude()
    print(lat)
    lg = a.longitude()
    print(lg)
    print(a.coordinates())


# Generated at 2022-06-21 15:46:33.097806
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() == "Africa"


# Generated at 2022-06-21 15:46:35.667230
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address(seed=123)
    actual = a.latitude()
    expected = -31.788223
    assert actual == expected


# Generated at 2022-06-21 15:46:37.066678
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    obj = Address()
    assert isinstance(obj.calling_code(), str)


# Generated at 2022-06-21 15:46:38.456334
# Unit test for method address of class Address
def test_Address_address():
    for i in range(100):
        print(Address('en').address())

# Generated at 2022-06-21 15:46:42.319902
# Unit test for method region of class Address
def test_Address_region():
    A = Address()
    assert A.region() in A._data['state']['name']
    assert A.region(abbr=True) in A._data['state']['abbr']


# Generated at 2022-06-21 15:46:48.859339
# Unit test for method state of class Address
def test_Address_state():
    # Тестирование метода state класса Address для нескольких языков
    address = Address('ru')
    state = address.state(abbr=True)
    eng = address.state(abbr=True)
    assert eng != None
    assert state != None
    assert type(eng) == str
    assert type(state) == str


# Generated at 2022-06-21 15:46:50.963048
# Unit test for method region of class Address
def test_Address_region():
    obj1=Address()
    assert obj1.region() in obj1._data['state']['name'], 'Failed to get region'
    assert obj1.region(abbr=True) in obj1._data['state']['abbr'], 'Failed to get region'

# Generated at 2022-06-21 15:46:53.483444
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Locale
    
    address = Address(Locale.EN)
    assert address.country() == 'Romania'

    address.set_locale(Locale.RU)
    assert address.country() == 'Тува'

# Generated at 2022-06-21 15:46:59.056945
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert 'Address' in str(address)

# Generated at 2022-06-21 15:47:01.004620
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    obj = Address()
    assert type(obj.zip_code()) is str


# Generated at 2022-06-21 15:47:02.217565
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    # return value is random
    assert isinstance(address.prefecture(), str)


# Generated at 2022-06-21 15:47:11.518047
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    def test_result_of_postal_code_in_locale_is_correct(
        locale: str,
        postal_code: str,
    ):
        address = Address(locale=locale)
        first_result = address.postal_code()
        assert first_result == postal_code
        second_result = address.postal_code()
        assert second_result == postal_code

    test_result_of_postal_code_in_locale_is_correct(
        locale='be', postal_code='1000',
    )
    test_result_of_postal_code_in_locale_is_correct(
        locale='br', postal_code='00000-000',
    )

# Generated at 2022-06-21 15:47:13.168867
# Unit test for constructor of class Address
def test_Address():
    result = Address.__init__('test')
    assert result is None, "Constructor of Address returned a value, but shouldn't."

# Generated at 2022-06-21 15:47:17.703432
# Unit test for method address of class Address
def test_Address_address():
    for i in range(0, 100):
        addr = Address(locale='de')
        city = addr.random.choice(addr._data['city'])
        assert addr.address() == '{0} {1}, {2} {3}'.format(addr.street_number(), addr.street_name(), addr.street_suffix(), city)


# Generated at 2022-06-21 15:47:27.610593
# Unit test for method country_code of class Address
def test_Address_country_code():
    addr = Address(locale='en')
    country_code = addr.country_code()
    if country_code not in COUNTRY_CODES['a2']:
        raise AssertionError('Country code {} not in country codes {}'.format(country_code, COUNTRY_CODES['a3']))
    #test for country_code(enum.a2)
    country_code = addr.country_code(CountryCode.A2)
    if country_code not in COUNTRY_CODES['a2']:
        raise AssertionError('Country code {} not in country codes {}'.format(country_code, COUNTRY_CODES['a3']))
    #test for country_code(enum.a3)
    country_code = addr.country_code(CountryCode.A3)

# Generated at 2022-06-21 15:47:30.257237
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    calling_code = a.calling_code()
    print("Calling code:", calling_code)


# Generated at 2022-06-21 15:47:33.587901
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    result = address.calling_code()
    assert isinstance(result, str) == True
    assert isinstance(int(result), int) == True


# Generated at 2022-06-21 15:47:35.814743
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject() == "徳島県"


# Generated at 2022-06-21 15:47:39.981684
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    Address('en').zip_code()

# Generated at 2022-06-21 15:47:44.363489
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for Address()."""
    from mimesis import Address
    res = Address('en').coordinates(True)
    assert len(res['longitude']) == 15
    assert len(res['latitude']) == 15

# Generated at 2022-06-21 15:47:46.746586
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    result=Address.postal_code()
    print(result)
    assert result
    assert not ' ' in result


# Generated at 2022-06-21 15:47:49.068617
# Unit test for method street_name of class Address
def test_Address_street_name():
    a=Address('en')
    assert a.street_name() in a._data['street']['name']


# Generated at 2022-06-21 15:47:51.225009
# Unit test for method city of class Address
def test_Address_city():
    Address('en').city()


# Generated at 2022-06-21 15:47:52.562131
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    f = Address()
    print(f.zip_code())


# Generated at 2022-06-21 15:47:57.037530
# Unit test for method continent of class Address
def test_Address_continent():
    """Test method continent of class Address"""
    import pytest
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Continent
    from mimesis.providers.address import Address

    address = Address('en')
    with pytest.raises(NonEnumerableError):
        address.continent(code=Continent.AFRICA)
    assert address.continent(code=True) in Continent.list_values()
    assert (address.continent(code=True)
            in address.list_continent_codes())
    assert address.continent(code=False) in address.list_continents()
    assert (address.continent(code=False)
            in address._data['continent'])


# Generated at 2022-06-21 15:47:58.975071
# Unit test for method street_name of class Address
def test_Address_street_name():
    street_name = Address(locale='en').street_name()
    assert street_name in Address._data['street']['name']


# Generated at 2022-06-21 15:48:00.614799
# Unit test for method country of class Address
def test_Address_country():
    # Default locale
    address = Address()
    result = address.country()
    assert result is not None


# Generated at 2022-06-21 15:48:11.765118
# Unit test for method state of class Address

# Generated at 2022-06-21 15:48:17.889166
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() == r'1335 W.\ Hellman St.'

# Generated at 2022-06-21 15:48:30.058493
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address(random_state=0)
    assert address.calling_code() == '+86'
    assert address.calling_code() == '+664'
    assert address.calling_code() == '+670'
    assert address.calling_code() == '+44'
    assert address.calling_code() == '+691'
    assert address.calling_code() == '+212'
    assert address.calling_code() == '+377'
    assert address.calling_code() == '+244'
    assert address.calling_code() == '+235'
    assert address.calling_code() == '+855'
    assert address.calling_code() == '+53'
    assert address.calling_code() == '+961'
    assert address.calling_code() == '+52'
    assert address

# Generated at 2022-06-21 15:48:40.249365
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    a = Address()
    for _ in range(10):
        c = a.country_code(CountryCode.A2)
        assert len(c) == 2
        assert c in COUNTRY_CODES[CountryCode.A2]

    for _ in range(10):
        c = a.country_code(CountryCode.A3)
        assert len(c) == 3
        assert c in COUNTRY_CODES[CountryCode.A3]

    for _ in range(10):
        c = a.country_code(CountryCode.N)
        assert c in COUNTRY_CODES[CountryCode.N]


if __name__ == '__main__':
    test_Address_country_code()

# Generated at 2022-06-21 15:48:44.850639
# Unit test for constructor of class Address
def test_Address():
    # Testing init method
    address = Address()
    # Testing class location
    assert address.locale == 'en'
    # Testing equal
    assert address == address
    # Testing not equal
    assert address != 123
    # Testing hash
    assert hash(address) != hash(123)

# Generated at 2022-06-21 15:48:47.402595
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    sn = a.street_number(a.random.randint(100,1000))
    assert isinstance(sn, str)


# Generated at 2022-06-21 15:48:55.495089
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    A = Address()
    geo = A.coordinates()
    lat = geo['latitude']
    lng = geo['longitude']
    lat_s = A.latitude(dms=True)
    lng_s = A.longitude(dms=True)
    assert(type(lat) == float and type(lng) == float)
    assert(type(lat_s) == str and type(lng_s) == str)


# Generated at 2022-06-21 15:49:01.927766
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state() in ['CA','AL','AK','AZ','AR','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY']


# Generated at 2022-06-21 15:49:05.306054
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
  from mimesis.enums import Locale
  from mimesis.providers.address import Address
  A = Address(Locale.EN)
  assert A.street_suffix() in ['Avenue', 'Blvd', 'Drive', 'Court']


# Generated at 2022-06-21 15:49:10.788567
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    streetNumber = address.street_number()
    assert streetNumber is not None
    assert isinstance(streetNumber, str)
    assert streetNumber != ''
    
    streetNumber = address.street_number(maximum = 100)
    assert streetNumber is not None
    assert isinstance(streetNumber, str)
    assert streetNumber != ''
    

# Generated at 2022-06-21 15:49:12.488410
# Unit test for method street_name of class Address
def test_Address_street_name():
    l = Address('ru')
    assert isinstance(l.street_name(), str)


# Generated at 2022-06-21 15:49:18.826640
# Unit test for method street_number of class Address
def test_Address_street_number():

    from mimesis.builtins import Address

    a = Address()
    street_number = a.street_number(maximum=100)

    assert a.random.randint(1, 100) == int(street_number)



# Generated at 2022-06-21 15:49:20.162150
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for region() method."""
    assert Address().region() == Address().province()


# Generated at 2022-06-21 15:49:22.146359
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a1 = Address()
    assert a1.zip_code() == a1.postal_code()


# Generated at 2022-06-21 15:49:23.081265
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() == Address().state()

# Generated at 2022-06-21 15:49:23.619947
# Unit test for method longitude of class Address
def test_Address_longitude():
    Address().longitude()

# Generated at 2022-06-21 15:49:25.034433
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state() == 'CA'


# Generated at 2022-06-21 15:49:27.117770
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address().longitude() == '-57.808457'

# Generated at 2022-06-21 15:49:30.955784
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    assert(address.country() == "France")

    list_countries = address.random.choice(address._data['country']['name'], amount=10)
    for country in list_countries:
        assert(country in address._data['country']['name'])

# Generated at 2022-06-21 15:49:36.368326
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.providers.address import Address
    from mimesis.enums import Continent
    obj = Address('en')
    assert obj.continent() in Continent.__members__
    assert obj.continent(True) in Continent.__members__


# Generated at 2022-06-21 15:49:38.033012
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    data = Address()
    assert data.federal_subject()



# Generated at 2022-06-21 15:49:48.139682
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    test_address = Address(seed=0)
    assert test_address.street_suffix() == 'Str.'


# Generated at 2022-06-21 15:49:59.000146
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    a = Address(locale='en')
    assert a.street_number() >= 1 and a.street_number() <= 1400
    assert a.street_number(1000) >= 1 and a.street_number(1000) <= 1000
    a = Address(locale='ja')
    assert a.street_number() >= 1 and a.street_number() <= 1400
    assert a.street_number(1000) >= 1 and a.street_number(1000) <= 1000
    a = Address(locale='en')
    assert a.street_number() is not None
    assert a.street_number() is not ''

# Generated at 2022-06-21 15:50:10.703187
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from .geo import Geo
    from .datetime import Datetime
    from .enums import CountryCode, Gender
    from .person import Person
    from .utils import get_locale

    geo = Geo(locale = get_locale())
    dt = Datetime(locale = get_locale())
    p = Person(locale = get_locale())

    fmt = '{} {}'.format(geo.coordinates(), dt.date_time())
    print(fmt)

    print(geo.coordinates(dms = True))

    fmt = '{} {}'.format(Person.get_full_name(p.full_name(gender=Gender.FEMALE)), geo.coordinates(dms = True))
    print(fmt)


# Generated at 2022-06-21 15:50:13.991310
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    answer = address.prefecture()
    assert answer!=None and isinstance(answer,str)


# Generated at 2022-06-21 15:50:16.364087
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    for i in range(100):
        assert address.street_suffix()



# Generated at 2022-06-21 15:50:24.046943
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
    print(Address().street_suffix())
   

# Generated at 2022-06-21 15:50:27.112507
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from .utils import validate_coordinates

    address = Address()
    result = address.coordinates(True)
    validate_coordinates(result)

# Generated at 2022-06-21 15:50:33.669615
# Unit test for method continent of class Address
def test_Address_continent():
    ad = Address()
    assert ad.continent() in (
        'Africa',
        'Antarctica',
        'Asia',
        'Europe',
        'North America',
        'South America',
        'Oceania')

    assert ad.continent(code=True) in (
        'AF',
        'AN',
        'AS',
        'EU',
        'NA',
        'SA',
        'OC')


# Generated at 2022-06-21 15:50:37.889829
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for class Address."""
    from mimesis.exceptions import NonEnumerableError

    try:
        addr = Address('en')
        addr.federal_subject()
    except NonEnumerableError:
        print('NonEnumerableError')
    else:
        print(addr.federal_subject())

# Generated at 2022-06-21 15:50:40.957972
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """
    Return a random prefecture.

    An alias for :meth:`~Address.state()`.
    """
    address = Address()
    str = address.prefecture()
    assert isinstance(str,str) == True


# Generated at 2022-06-21 15:51:05.802612
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    ad = Address('en')
    ad.seed(123)
    result = ad.city()
    assert result == 'Preston'
    assert result != 'Tangier'

    ad.seed()
    result = ad.city()
    assert result == 'San Francisco'

    alice = Address('en', seed=123)
    alice.generator.seed(123)
    bob = Address('en', seed=123)
    bob.generator.seed(123)
    assert alice.city() == bob.city()
    assert alice.city() != bob.city(seed=456)

    en = Address('en')
    assert en.city() != en.city(seed=456)

    fr = Address('fr')

# Generated at 2022-06-21 15:51:06.710004
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert len(a.calling_code()) == 3

# Generated at 2022-06-21 15:51:08.611366
# Unit test for method longitude of class Address
def test_Address_longitude():
    addr = Address()
    tmp = addr.longitude()
    assert len(tmp) == 9
    assert tmp[0] == '-' or tmp[0] == '+'


# Generated at 2022-06-21 15:51:13.713656
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address.Meta.name == 'address'
    assert type(Address.street_number()).__name__ == 'str'
    assert Address.street_number() in range(1,1400)
    assert type(Address.street_name()).__name__ == 'str'
    assert type(Address.street_suffix()).__name__ == 'str'
    assert type(Address.address()).__name__ == 'str'
    assert type(Address.state()).__name__ == 'str'
    assert type(Address.region()).__name__ == 'str'
    assert type(Address.province()).__name__ == 'str'
    assert type(Address.postal_code()).__name__ == 'str'
    assert type(Address.zip_code()).__name__ == 'str'

# Generated at 2022-06-21 15:51:17.200035
# Unit test for method street_number of class Address
def test_Address_street_number():
    for _ in range(1000):
        street_number = Address('en').street_number()
        assert isinstance(street_number, str)
        assert isinstance(int(street_number), int)
        assert 1 <= int(street_number) <= 1400


# Generated at 2022-06-21 15:51:20.817471
# Unit test for method longitude of class Address
def test_Address_longitude():
    print("Unit test for method longitude of class Address")
    from mimesis.enums import Country
    from mimesis.builtins import Address
    add = Address(Country.AUSTRALIA)
    assert add.longitude() == add.longitude()


# Generated at 2022-06-21 15:51:22.338828
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() == '1350 Woodrow Street'


# Generated at 2022-06-21 15:51:29.993003
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import Level
    from mimesis.providers.locale import Locale
    from mimesis.providers.address import Address
    provider = Address(locale=Locale.EN)
    result = provider.coordinates(dms=True)
    assert set(result.keys()) == {'longitude', 'latitude'}
    assert isinstance(result['longitude'], str)
    assert isinstance(result['latitude'], str)
    result = provider.coordinates()
    assert set(result.keys()) == {'longitude', 'latitude'}
    assert isinstance(result['longitude'], float)
    assert isinstance(result['latitude'], float)

# Generated at 2022-06-21 15:51:30.962157
# Unit test for method country of class Address
def test_Address_country():
    address = Address('en')
    print(address.country())


# Generated at 2022-06-21 15:51:36.247781
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import Country
    from mimesis.localization import Localization
    from mimesis.providers.address import Address
    from mimesis import Address as Address_s

    provider = Address(Localization(Country.RUSSIA))
    s_provider = Address_s()
    result = provider.latitude()
    s_result = s_provider.latitude()
    assert(result!=s_result)


# Generated at 2022-06-21 15:52:11.026792
# Unit test for method province of class Address
def test_Address_province():
    from random import choice
    from mimesis.builtins import RussiaSpecProvider

    addr = Address()
    regions = RussiaSpecProvider.regions()
    code = choice(regions).upper()

    assert addr.province(code=code) != addr.province(code=code)
    assert addr.province() == addr.province()

# Generated at 2022-06-21 15:52:12.651159
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    fmt = a.country_code(fmt=CountryCode.A2)
    print("a.country_code(): " + fmt)
    assert fmt in COUNTRY_CODES[CountryCode.A2]


# Generated at 2022-06-21 15:52:14.126733
# Unit test for constructor of class Address
def test_Address():
    _address = Address()

    assert _address
    assert isinstance(_address, BaseDataProvider)


# Generated at 2022-06-21 15:52:14.911217
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() != ''


# Generated at 2022-06-21 15:52:25.404569
# Unit test for constructor of class Address
def test_Address():
    """Test for class Address."""
    # Try to create instance of Address class.
    a = Address()
    assert a.street_number() == '1'
    assert a.street_name() == 'Amanda Trail'
    assert a.street_suffix() == 'Tr'
    assert a.address() == '1 Amanda Trail, Suite 750'
    assert a.state() == 'FL'
    assert a.province() == 'FL'
    assert a.federal_subject() == 'FL'
    assert a.prefecture() == 'FL'
    assert a.postal_code() == '02567'
    assert a.zip_code() == '02567'
    assert a.country() == 'United States'
    assert a.city() == 'Lake Dianaland'

# Generated at 2022-06-21 15:52:31.582551
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.providers.address import Address
    from mimesis.enums import DMSCoordinate
    a = Address('zh')
    for i in range(100):
        a.coordinates()
    for i in range(100):
        a.latitude()
    for i in range(100):
        a.longitude()
    for i in range(100):
        a.latitude(dms=DMSCoordinate.DM)
    for i in range(100):
        a.longitude(dms=DMSCoordinate.D)

# Generated at 2022-06-21 15:52:33.062898
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    addr = Address()
    ans = addr.federal_subject()
    assert len(ans) > 0


# Generated at 2022-06-21 15:52:34.738905
# Unit test for method calling_code of class Address
def test_Address_calling_code():
	address = Address('en')
	calling_code = address.calling_code()
	assert calling_code in CALLING_CODES

# Generated at 2022-06-21 15:52:38.352641
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    coordinates = address.coordinates()
    assert 'longitude' in coordinates.keys()
    assert 'latitude' in coordinates.keys()
    assert isinstance(coordinates['longitude'], (int, float))
    assert isinstance(coordinates['latitude'], (int, float))


# Generated at 2022-06-21 15:52:43.554556
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    from mimesis.builtins import datetime
    result = set()
    for i in range(20000):
        # Use English locale for reproducible test results
        a = Address(locale='en')
        result.add(a.coordinates())
    print(result)
    assert len(result) == 20000
    assert len(result) != 0

# Generated at 2022-06-21 15:53:03.589059
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Test Address.prefecture."""
    address = Address(seed=4)
    assert address.prefecture() == "Gyeonggi"


# Generated at 2022-06-21 15:53:06.048776
# Unit test for method continent of class Address
def test_Address_continent():
    t = Address()
    for _ in range(0,10):
        code = t.continent(code=True)
        if(code in CONTINENT_CODES):
            assert True
        else:
            assert False

# Generated at 2022-06-21 15:53:07.798197
# Unit test for constructor of class Address
def test_Address():
    address = Address('zh')
    address


# Generated at 2022-06-21 15:53:13.450887
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Test Address.latitude() method."""
    address = Address()
    lt = address.latitude()
    assert isinstance(lt, float)
    # Test latitude in DMS format
    lt = address.latitude(dms=True)
    assert isinstance(lt, str)
    assert len(lt) > 3



# Generated at 2022-06-21 15:53:23.593699
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Latitude of Address from Mimesis."""
    from mimesis.enums import Country
    from mimesis.providers.address import Address
    import pytest
    en = Address(Country.ENGLISH)
    zh = Address(Country.CHINESE)
    assert (-90 <= float(en.latitude()) <= 90)
    assert (-90 <= float(en.latitude(dms=True)) <= 90)
    assert en.latitude().endswith('N')
    assert en.latitude(dms=True).count('\'') == 1
    assert en.latitude(dms=True).count('"') == 1
    assert (-90 <= float(zh.latitude()) <= 90)
    assert (-90 <= float(zh.latitude(dms=True)) <= 90)

# Generated at 2022-06-21 15:53:28.296999
# Unit test for method longitude of class Address
def test_Address_longitude():
    a1 = Address(random=5)
    a1.longitude()
    a2 = Address(random=5)
    a2.longitude(dms=True)
    assert a1.longitude(dms=False) == a1.longitude(dms=False) and \
            a2.longitude(dms=True) == a2.longitude(dms=True)


# Generated at 2022-06-21 15:53:30.545205
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address.federal_subject(abbr = True) == 'US'
    assert Address.federal_subject(abbr = False) == 'New York'

if __name__ == '__main__':
    test_Address_federal_subject()

# Generated at 2022-06-21 15:53:32.150502
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    for i in range(10):
        print (Address().street_suffix())


# Generated at 2022-06-21 15:53:34.178217
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    city = a.city()
    assert city in a._data['city']


# Generated at 2022-06-21 15:53:37.403787
# Unit test for constructor of class Address
def test_Address():
    # Check that language is not specified
    address = Address()
    result = address.city()
    assert isinstance(result, str), 'City should be string'

    # Check if language is specified
    address = Address('es')
    result = address.city()
    assert isinstance(result, str), 'City should be string'

# Generated at 2022-06-21 15:53:57.326199
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Initialize object Address
    adress = Address()
    # Generate zip code
    zip_code = adress.zip_code()
    # print(zip_code)
    print(f'Address: {zip_code}')
    # Close object Address
    adress.close()


# Generated at 2022-06-21 15:54:04.615710
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert (a.address())
    assert (a.country())
    assert (a.city())
    assert (a.continent())
    assert (a.coordinates())
    assert (a.country_code())
    assert (a.province())
    assert (a.latitude())
    assert (a.longitude())
    assert (a.postal_code())
    assert (a.prefecture())
    assert (a.federal_subject())
    assert (a.region())
    assert (a.state())
    assert (a.street_name())
    assert (a.street_number())
    assert (a.street_suffix())
    assert (a.zip_code())

# Generated at 2022-06-21 15:54:06.261613
# Unit test for method latitude of class Address
def test_Address_latitude():
    latitude = Address(seed=42).latitude()
    assert latitude == '73º51\'30.868"N'

# Generated at 2022-06-21 15:54:08.610719
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    id_ = 0
    while True:
        test = Address(id_)
        print("Postal code:", test.postal_code())
        print("   Locale:", test.locale)
        print("   Region:", test.region())
        id_ += 1

# Generated at 2022-06-21 15:54:09.937970
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    ad = Address()
    print(ad.coordinates(dms=True))


# Generated at 2022-06-21 15:54:13.143974
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()
    # TODO: Fix this test
    # assert Address('ru').address() == 'Богдан Хмельницкого ул., 15, Москва'


# Generated at 2022-06-21 15:54:15.156795
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address().zip_code() == Address().postal_code()

# Generated at 2022-06-21 15:54:17.485611
# Unit test for method country_code of class Address
def test_Address_country_code():
    for i in range(1, 100):
        assert Address.country_code() in COUNTRY_CODES[CountryCode.A2.value]

# Generated at 2022-06-21 15:54:22.006483
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from pprint import pprint
    from mimesis.providers.address import Address

    # Create a new instance of Address class
    address_provider = Address()

    # Print out a random state name
    pprint(address_provider.federal_subject())

if __name__ == '__main__':
    test_Address_federal_subject()

# Generated at 2022-06-21 15:54:23.442867
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    actual = address.country()
    expected = 'Indonesia'
    assert actual == expected


# Generated at 2022-06-21 15:55:02.523045
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert calling_code in CALLING_CODES



# Generated at 2022-06-21 15:55:04.477902
# Unit test for method street_number of class Address
def test_Address_street_number():
    test_Address = Address('en')
    x = test_Address.street_number(5)
    assert x <= '5'


# Generated at 2022-06-21 15:55:05.972501
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    codes = Address().calling_code()
    assert type(codes) is str

# Generated at 2022-06-21 15:55:07.278916
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject()

# Generated at 2022-06-21 15:55:13.739063
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.providers.address import Address
    import pandas as pd
    a = Address("en")
    s = a.city()
    # 通过pandas读取csv文件
    cities = pd.read_csv("/Users/houliangliang/Documents/NLP/Final/data/cities.csv")
    city_name = list(cities['City'])
    assert s in city_name


# Generated at 2022-06-21 15:55:15.802540
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('en')
    # Get prefecture() method
    m = getattr(address, 'prefecture', None)
    # Test it
    assert m, "m is None"

# Generated at 2022-06-21 15:55:17.761539
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    country_list = address.country(allow_random=True)
    assert country_list in address._data['country']['name']


# Generated at 2022-06-21 15:55:18.843776
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    assert isinstance(a.zip_code(), str)

# Generated at 2022-06-21 15:55:25.938883
# Unit test for method region of class Address
def test_Address_region():
    address_1 = Address('en')

# Generated at 2022-06-21 15:55:29.059207
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.builtins import RussiaSpecProvider
    rus_address = RussiaSpecProvider()
    assert 'Хабаровский край' == rus_address.region(CountryCode.RU)