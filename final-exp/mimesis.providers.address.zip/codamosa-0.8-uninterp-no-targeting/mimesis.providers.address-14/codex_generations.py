

# Generated at 2022-06-21 15:45:40.686202
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    assert address.continent("code") in CONTINENT_CODES
    # print("test_Address_continent")
    # print(address.continent("code"))


# Generated at 2022-06-21 15:45:42.299459
# Unit test for method address of class Address
def test_Address_address():
    def test_address():
        return Address().address()

    assert test_address() is not None


# Generated at 2022-06-21 15:45:43.390089
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() is not None

# Generated at 2022-06-21 15:45:45.932649
# Unit test for method city of class Address
def test_Address_city():
    address = Address('ja')
    assert address.city() in '日本'


# Generated at 2022-06-21 15:45:50.031026
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.builtins import address
    a = address.Address()
    suffixes = a._data['street']['suffix']
    for i in range(10):
        assert a.street_suffix() in suffixes


# Generated at 2022-06-21 15:45:56.933019
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.builtins import RussianSpecProvider
    from mimesis.enums import CountryCode
    adr = Address(RussianSpecProvider)
    assert adr.country() == 'Российская Федерация'
    assert adr.country(True) in adr._data['country']['name']
    assert 'Russian Federation' in adr._data['country']['en']
    assert isinstance(adr.country_code(CountryCode.A2), str)
    assert isinstance(adr.country_code(CountryCode.A3), str)

# Generated at 2022-06-21 15:46:02.645876
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address(locale='en')
    print(a.coordinates())
    # {'longitude': '114.81169¢E', 'latitude': '22.53463¢N'}
    print(a.coordinates(dms=True))
    # {'longitude': '114.81169¢E', 'latitude': '22.53463¢N'}



# Generated at 2022-06-21 15:46:04.713403
# Unit test for method province of class Address
def test_Address_province():
    """Unit test for method province of class Address."""
    address = Address()
    assert isinstance(address.province(), str)

# Generated at 2022-06-21 15:46:06.090211
# Unit test for method country of class Address
def test_Address_country():
    # TODO: write unit test for method country of class Address
    pass

# Generated at 2022-06-21 15:46:08.631237
# Unit test for method street_number of class Address
def test_Address_street_number():
    generator = Address()
    number = generator.street_number()
    assert isinstance(number, str)

if __name__ == '__main__':
    test_Address_street_number()
    print('Done.')

# Generated at 2022-06-21 15:46:18.902068
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    s = a.continent(code=False)
    assert isinstance(s, str)


# Generated at 2022-06-21 15:46:20.431035
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert street_name != ''

# Generated at 2022-06-21 15:46:26.557025
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert a.continent() in ['Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America']
    assert a.continent(code=True) in ['AF', 'AN', 'AS', 'EU', 'NA', 'OC', 'SA']
    assert a.continent(code=False) in ['Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America']
    assert a.continent(code='123') in ['Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America']
    assert a.continent() in ['Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America']

# Generated at 2022-06-21 15:46:27.725697
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    result = a.country()
    assert a._data['country']['current_locale'] == result

# Generated at 2022-06-21 15:46:29.671851
# Unit test for method region of class Address
def test_Address_region():
    address = Address('en')
    assert address.region() == 'FL'

# Generated at 2022-06-21 15:46:37.208662
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continent
    from mimesis.enums import Region

    addr = Address()
    rng = [Continent.AFRICA, Continent.AMERICA, Continent.ASIA, Continent.EUROPE, Continent.OCEANIA]
    rng_reg = [Region.AMERICAS, Region.OECD, Region.WORLD, Region.APAC, Region.EMEA]

    result = addr.continent()
    assert result in rng or result in rng_reg


# Generated at 2022-06-21 15:46:48.203713
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    address = Address()
    assert address.state() in address._data['state']['name']
    assert address.state(abbr=True) in address._data['state']['abbr']
    assert address.state(None) in address._data['state']['name']
    assert address.country_code(CountryCode.A2) in COUNTRY_CODES['A2']
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES['A3']
    assert address.country_code(CountryCode.NUM) in COUNTRY_CODES['NUM']
    assert address.country_code(CountryCode.NAME) in COUNTRY_CODES['NAME']

# Generated at 2022-06-21 15:46:50.909950
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address().longitude() != None 
    
    assert type(Address().longitude()) == float
    
    assert (Address().longitude() <= 180 and Address().longitude() >= -180)
    
    return 


# Generated at 2022-06-21 15:46:51.685520
# Unit test for method country of class Address
def test_Address_country():
    print(Address().country())


# Generated at 2022-06-21 15:46:54.468533
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    print(Address.street_suffix())

# Generated at 2022-06-21 15:47:19.835404
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    import pytest
    from Address import Address

    from unittest.mock import patch
    ADDRESS_CALLING_CODES = [
        *CALLING_CODES,
        '+998',
        '+965',
    ]

    address = Address(random=False)
    address.random.choices = lambda x, k=1: x[:k]
    address.random.choice = lambda x: x[0]
    with patch('mimesis.providers.address.address.Address.random.choice', side_effect=ADDRESS_CODES):
        result = address.calling_code()
    assert result == '+998'

# Generated at 2022-06-21 15:47:26.369539
# Unit test for method country_code of class Address
def test_Address_country_code():
    addr = Address()
    address_list = []
    for i in COUNTRY_CODES:
        print(i, end=' ')
    for j in range(0, 10):
        print(addr.country_code(), end=' ')
        assert addr.country_code() in COUNTRY_CODES[addr._validate_enum(CountryCode.A2, CountryCode)]
        address_list.append(addr.country_code())
        if address_list.count(address_list[j]) > 1:
            print("duplicated")
            break



# Generated at 2022-06-21 15:47:33.086348
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import Country
    from mimesis.builtins import Person

    address = Address(Country.EUROPE.value)
    person = Person(Country.EUROPE.value)

    assert len(address.zip_code()) == 5
    assert address.zip_code() != person.username()
    assert isinstance(address.zip_code(), str)


# Generated at 2022-06-21 15:47:35.710322
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address().zip_code() in ('600-8165', '060-8344', '100-0001', '333-0106')


# Generated at 2022-06-21 15:47:37.880045
# Unit test for method state of class Address
def test_Address_state():
    a = Address(seed=12345)
    assert a.state(True) == "AA"


# Generated at 2022-06-21 15:47:40.337464
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    x = a.calling_code()
    y = a.calling_code()

    print(x, y)


# Generated at 2022-06-21 15:47:51.875688
# Unit test for constructor of class Address
def test_Address():
    off = Address(random=False)
    off.random.seed(0)
    off1 = Address()
    off2 = Address()
    off3 = Address(random=False)
    off4 = Address(random=False)
    assert off.state() == off1.state()
    assert off.city() == off1.city()
    assert off.country_code() == off1.country_code()
    assert off.address() == off1.address()
    assert off.zip_code() == off1.zip_code()
    assert off.postal_code() == off1.postal_code()
    assert off.continent() == off1.continent()
    assert off.street_number() == off1.street_number()
    assert off.street_suffix() == off1.street_suffix()


# Generated at 2022-06-21 15:47:52.760660
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address != None
    print("Unit test for constructor of class Address... OK!!!")

# Generated at 2022-06-21 15:47:54.062461
# Unit test for method country of class Address
def test_Address_country():
    test = Address(lang='en')
    country = test.country(True)
    assert isinstance(country, str)
    assert len(country) > 0


# Generated at 2022-06-21 15:47:56.309465
# Unit test for method longitude of class Address
def test_Address_longitude():
	# Create object of class Address
	address = Address()

	# Get longitude
	longitude = address.longitude()

	# Check if longitude is a float number
	assert type(longitude) == float
	# Check if longitude is between -180 and 180
	assert -180 <= longitude <= 180


# Generated at 2022-06-21 15:48:36.639926
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()
    assert type(result) == str


# Generated at 2022-06-21 15:48:40.351345
# Unit test for method prefecture of class Address
def test_Address_prefecture():
	# Prefecture Method of Address
	address = Address('zh')
	result = address.prefecture()
	assert result in address._data['state']['name']

# Generated at 2022-06-21 15:48:44.092742
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Arrange
    address=Address('en')
    zip_code=address.zip_code()
    # Action
    # Assert
    assert zip_code == address.postal_code()


# Generated at 2022-06-21 15:48:46.439612
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    x = address.federal_subject(abbr = True)
    assert len(x) == 3


# Generated at 2022-06-21 15:48:48.222756
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() == 'AL'



# Generated at 2022-06-21 15:48:52.227363
# Unit test for method latitude of class Address
def test_Address_latitude():
    # should return decimal value
    value = Address.latitude()
    assert isinstance(value, float)
    # should return value in DMS format
    value = Address.latitude(dms=True)
    assert isinstance(value, str)


# Generated at 2022-06-21 15:48:54.829265
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province() == Address().state()


# Generated at 2022-06-21 15:48:57.438328
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    assert address.continent() in ['Asia', 'Europe', 'Africa', 'Oceania', 'Americas']


# Generated at 2022-06-21 15:48:58.369704
# Unit test for constructor of class Address
def test_Address():
    Address().__init__()

# Generated at 2022-06-21 15:49:04.254128
# Unit test for method country of class Address
def test_Address_country():
    """Unit test for method country of class Address."""
    # Create a object of Address
    a = Address()
    # Get a country code of the current locale
    country = a.country()
    # Get a name of the current locale
    locale = a._data['country']['current_locale']
    # Get a country name of the current locale
    locale_country = a._data['country']['name'][locale]
    # Check that country and locale_country are equal
    assert country == locale_country, "The names of countries are different."