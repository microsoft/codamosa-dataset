

# Generated at 2022-06-21 15:45:38.597513
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address(seed=1)
    b = Address(seed=1)
    assert a.prefecture() == b.prefecture()


# Generated at 2022-06-21 15:45:41.203256
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.providers.address import Address
    address = Address('zh')
    region = address.region()
    assert isinstance(region, str)
    assert len(region) > 0


# Generated at 2022-06-21 15:45:49.138242
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale

    eng_address = Address(Locale.EN)
    ru_address = Address(Locale.RU)
    for x in range(0, 20):
        assert eng_address.street_suffix() in ['Ave', 'St', 'Rd']
        assert ru_address.street_suffix() in ['ул', 'пер', 'ш']


# Generated at 2022-06-21 15:45:51.896195
# Unit test for method country of class Address
def test_Address_country():
    adr = Address()
    assert isinstance(adr.country(), str) and adr.country() != ""
    assert isinstance(adr.country(True), str) and adr.country(True) != ""


# Generated at 2022-06-21 15:45:53.666777
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address("en")
    street_name = address.street_name()
    assert street_name in address._data['street']['name']

# Generated at 2022-06-21 15:45:55.153605
# Unit test for constructor of class Address
def test_Address():
    address = Address('en')
    assert address
    address = Address('en', seed=42)
    assert address

# Generated at 2022-06-21 15:45:57.143591
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    assert Address().calling_code() in CALLING_CODES

# Generated at 2022-06-21 15:45:59.050903
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address.latitude() == Address().latitude()


# Generated at 2022-06-21 15:46:01.609910
# Unit test for method street_number of class Address
def test_Address_street_number():
	locale = ""
	maximum = 1400
	a = Address(locale)
	number = a.street_number()
	assert int(number) < maximum


# Generated at 2022-06-21 15:46:03.222467
# Unit test for constructor of class Address
def test_Address():
    test_addr = Address()
    assert test_addr.locale in test_addr.locales


# Generated at 2022-06-21 15:46:12.531078
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert type(Address().street_name()) == str


# Generated at 2022-06-21 15:46:22.626962
# Unit test for method region of class Address
def test_Address_region():
    def test_Address_region(self):
        a = address.Address()
        self.assertIn(a.region(), self._data['state']['name'])

        self.assertIn(a.region(abbr=True),
                      self._data['state']['abbr'])

        self.assertIn(a.province(), self._data['state']['name'])

        self.assertIn(a.province(abbr=True),
                      self._data['state']['abbr'])

        self.assertIn(a.federal_subject(), self._data['state']['name'])

        self.assertIn(a.federal_subject(abbr=True),
                      self._data['state']['abbr'])


# Generated at 2022-06-21 15:46:24.423157
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name().isalnum() == True, "The function does not work"


# Generated at 2022-06-21 15:46:31.599517
# Unit test for method country of class Address
def test_Address_country():
    """Test for method country of class Address."""
    address_1 = Address()
    country_1 = address_1.country()
    country_2 = address_1.country()
    assert country_1 == country_2
    country_3 = address_1.country(allow_random=True)
    assert country_1 != country_3



# Generated at 2022-06-21 15:46:35.031806
# Unit test for method province of class Address
def test_Address_province():
    add = Address()
    add.locale = 'en-US'
    assert add.province() in add._data['state']['abbr']
    assert add.province(abbr=True) in add._data['state']['name']

# Generated at 2022-06-21 15:46:37.964182
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import Locale
    address = Address(Locale.JA.value)
    assert address.prefecture() in address._data['state']['name']



# Generated at 2022-06-21 15:46:42.269302
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    method = 'coordinates'
    # Check type of returned value by Address method coordinates
    assert isinstance(eval('Address().' + method), dict)
    # Check returned value
    assert len(eval('Address().' + method)) > 0

# Generated at 2022-06-21 15:46:44.632276
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    zip_code = Address().zip_code()
    assert len(zip_code) > 0
    assert len(zip_code) < 10



# Generated at 2022-06-21 15:46:52.198879
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address
    """
    # test a json that not exists
    adr = Address(data_dir='../wrong/dir/')
    assert adr.prefecture() == 'not exists'
    # test a json that exists but is empty
    adr = Address(locale='pt-br', data_dir='../unit-test/')
    assert adr.prefecture() == 'not exists'
    # test a json that exists and is not empty
    adr = Address(locale='en', data_dir='../unit-test/')
    assert adr.prefecture() in ['Alaska', 'Alabama', 'Arkansas', 'Arizona', 'California', 'Colorado']


# Generated at 2022-06-21 15:46:54.002401
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Country
    from mimesis.providers.address import Address
    provider = Address()

    assert type(provider.country(allow_random=True)) is str
    assert provider.country().lower() in Country.names()

# Generated at 2022-06-21 15:47:09.747106
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a.__class__.__name__ == 'Address'


# Generated at 2022-06-21 15:47:19.539254
# Unit test for method street_number of class Address

# Generated at 2022-06-21 15:47:23.112028
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    with open('testfile') as f:
        data = json.load(f)
    obj = Address()
    for element in data['street_suffix']:
        assert element == obj.street_suffix()


# Generated at 2022-06-21 15:47:25.368877
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    print('\nUnit test for method federal_subject of class Address')
    a1 = Address('en')
    print(a1.federal_subject())
    

# Generated at 2022-06-21 15:47:30.073948
# Unit test for method city of class Address
def test_Address_city():
    # simple tests for random cities
    for i in range(0,10):
        # we prefer not to print anything here
        # print(Address().city())
        Address().city()

if __name__ == "__main__":
    test_Address_city()

# Generated at 2022-06-21 15:47:33.385470
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    provider = Address()
    result = provider.federal_subject()
    assert type(result) is str
    assert len(result) > 0


# Generated at 2022-06-21 15:47:40.182517
# Unit test for method province of class Address
def test_Address_province():
    import numpy as np
    from tqdm import tqdm
    from collections import Counter
    counter = Counter()
    address = Address("en")
    for i in tqdm(range(1000000)):
        counter[address.province()] += 1
    import matplotlib.pyplot as plt
    plt.plot(np.arange(len(counter)),list(counter.values()))


# Generated at 2022-06-21 15:47:41.749549
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    print(a.street_name())


# Generated at 2022-06-21 15:47:42.274469
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    print(Address().zip_code())


# Generated at 2022-06-21 15:47:45.167479
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.street_number() in (1, 1400)


# Generated at 2022-06-21 15:48:20.790886
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # GIVEN: Instantiation of class Address
    addr = Address()

    # WHEN: We generate a federal subject of Russia
    result = addr.federal_subject()

    # THEN: It should be equal to one of the possible names
    assert result in addr._data['federal_subject']['name']

# Generated at 2022-06-21 15:48:25.250055
# Unit test for method city of class Address
def test_Address_city():
    address_class = Address()
    is_city = False
    if address_class.city() in address_class._data['city']:
        is_city = True
    assert is_city == True



# Generated at 2022-06-21 15:48:27.755804
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Check method `federal_subject` of class `Address`"""
    addr = Address()
    assert addr.federal_subject()



# Generated at 2022-06-21 15:48:36.281430
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.types import Number
    from mimesis.utils import random

    class Provider(BaseDataProvider):
        def random(self) -> Number:
            return random.Random()

    provider = Provider()
    address = Address(provider)

    # float, default range
    assert isinstance(address.longitude(), float)
    # float, custom range
    assert isinstance(address.longitude(dms=True), str)

    # Unit test for method latitude of class Address
    def test_Address_latitude():
        from mimesis.enums import CountryCode
        from mimesis.providers.address import Address

# Generated at 2022-06-21 15:48:45.097760
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    st_num = a.street_number()
    assert type(st_num) == str
    assert isinstance(st_num, str)
    assert len(st_num.strip()) != 0
    assert len(st_num) != 0
    assert len(st_num.strip()) is not None
    assert len(st_num) is not None
    assert st_num is not None
    assert len(st_num) > 0
    assert len(st_num.strip()) > 0


# Generated at 2022-06-21 15:48:46.918141
# Unit test for method latitude of class Address
def test_Address_latitude():
	address = Address("es")
	result = address.latitude()
	assert type(result) == float


# Generated at 2022-06-21 15:48:48.745980
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject() == 'Москва'

# Generated at 2022-06-21 15:48:49.816539
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address().zip_code() == '88137'

# Generated at 2022-06-21 15:48:54.460824
# Unit test for method continent of class Address
def test_Address_continent():
    """Unit test for Address.continent."""
    a = Address()
    assert a.continent() in a._data['continent']

    assert a.continent(code=True) in CONTINENT_CODES


# Generated at 2022-06-21 15:48:57.898846
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.builtins import Address

    x = Address()
    a = x.coordinates()
    assert a == {'latitude': a['latitude'], 'longitude': a['longitude']}

# Generated at 2022-06-21 15:49:31.852416
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    print(address.province())
    print(address.province(abbr=True))


# Generated at 2022-06-21 15:49:35.353991
# Unit test for method region of class Address
def test_Address_region():
    """Test for method region of class Address."""
    postal_code = Address().zip_code()
    assert '-' in postal_code

# Generated at 2022-06-21 15:49:37.800102
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    result = (len(a.postal_code()) > 1)
    assert result


# Generated at 2022-06-21 15:49:41.248518
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    zip = a.zip_code()
    assert len(zip) > 0
    assert(len(zip)) == 5
    for i in zip:
        i = int(i)
        assert 0 <= i <= 9


# Generated at 2022-06-21 15:49:42.846260
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address(locale='ja')
    print(a.prefecture())


# Generated at 2022-06-21 15:49:48.398428
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import CountryCode, ContinentCode
    adr = Address()
    # Test __init__
    assert isinstance(adr, Address)
    # Test street_number
    assert len(adr.street_number()) > 0
    # Test street_name
    assert len(adr.street_name()) > 0
    # Test street_suffix
    assert len(adr.street_suffix()) > 0
    # Test address
    assert len(adr.address()) > 0
    # Test state
    assert len(adr.state()) > 0
    # Test state
    assert len(adr.state(abbr=True)) > 0
    # Test region
    assert len(adr.region()) > 0
    # Test region
    assert len(adr.region(abbr=True)) > 0
    # Test province
    assert len

# Generated at 2022-06-21 15:49:49.300266
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    pass


# Generated at 2022-06-21 15:49:54.550713
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    for i in range(3):
        co = a.coordinates()
        assert -90.0 <= float(co['latitude']) <= 90.0
        assert -180.0 <= float(co['longitude']) <= 180.0


# Generated at 2022-06-21 15:49:56.940666
# Unit test for method city of class Address
def test_Address_city():
    """Test Address.city()
    """
    # Test that city name is not empty
    assert Address().city() != ""

# Unit tests for class Address

# Generated at 2022-06-21 15:49:58.490863
# Unit test for method city of class Address
def test_Address_city():
    add = Address()
    assert(add.city() in add._data['city'])