

# Generated at 2022-06-21 15:45:43.752374
# Unit test for method state of class Address
def test_Address_state():
    adr = Address()
    result1 = adr.state()
    assert isinstance(result1, str), 'should be a string'

    result2 = adr.state(abbr=True)
    assert isinstance(result2, str), 'should be a string'
    assert (result2.isalpha() or '-' in result2), 'should be an ISO 3166-2 code'


# Generated at 2022-06-21 15:45:52.077194
# Unit test for constructor of class Address
def test_Address():
    all_keys = [
        '_data',
        '_seed',
        '_random',
        '_validators',
        '_datafile',
        '_locale',
        '_receiver',
    ]

    assert Address.Meta.name == 'address'

    obj = Address()
    assert obj._datafile == 'address.json'

    addr_keys = obj._pull('address.json').keys()
    assert addr_keys == set(all_keys)


# Generated at 2022-06-21 15:45:56.963374
# Unit test for method country of class Address
def test_Address_country():
    adr = Address()
    # A country should be the same as the one provided in the address.json
    # file for a locale.
    assert adr.country() == adr._data['country']['current_locale']

    # All random countries should be in the address.json file for a locale.
    for _ in range(1000):
        assert adr.country(allow_random=True) in adr._data['country']['name']


# Generated at 2022-06-21 15:46:03.737125
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address."""
    addr1 = Address(random_locale=True)
    dms = addr1.coordinates()
    assert isinstance(dms, dict)

    addr2 = Address(random_locale=True)
    dms = addr2.coordinates(dms=True)
    assert isinstance(dms, dict)
    assert isinstance(dms.get('longitude'), str)
    assert isinstance(dms.get('latitude'), str)

# Generated at 2022-06-21 15:46:05.758509
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    assert address is not None
    assert isinstance(address, str)


# Generated at 2022-06-21 15:46:09.302777
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    assert(a.postal_code().isdigit())
    assert(len(a.postal_code()) == 5)

    a = Address('en')
    assert(a.postal_code()[0].isdigit())
    assert(len(a.postal_code()) == 5)


# Generated at 2022-06-21 15:46:11.190277
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    print(address.longitude())



# Generated at 2022-06-21 15:46:17.979608
# Unit test for method country_code of class Address
def test_Address_country_code():
    """
    This is a unit test method for `~Address.country_code()` of class `~Address`
    """
    Address_object = Address('en')
    code_format_enum = CountryCode.A2
    assert Address_object.country_code(code_format_enum) in COUNTRY_CODES[CountryCode.A2]


# Generated at 2022-06-21 15:46:25.450354
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.local import Local
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.local import Local
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.local import Local
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode


    eng = Local(lang='en', region='us')
    address = Address(locale=eng)

    assert address.state() == 'RI'
    assert address.state(abbr=True) == 'RI'
    assert address.region() == 'RI'

# Generated at 2022-06-21 15:46:37.965223
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.localization import DEFAULT_LOCALE
    from mimesis.enums import Locale

    locale = Locale('ru')

    a = Address(locale)
    assert a.federal_subject(abbr=False) == 'Архангельская область'
    assert a.federal_subject(abbr=True) == 'Архангельская обл'

    a = Address(DEFAULT_LOCALE, locale)
    assert a.federal_subject(abbr=False) == 'Архангельская область'

# Generated at 2022-06-21 15:46:46.716244
# Unit test for method country of class Address
def test_Address_country():
    addr = Address('en')
    for i in range(10):
        country = addr.country()
    assert country == 'United States of America'

# Generated at 2022-06-21 15:46:47.747095
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address( 'ja')
    result = address.prefecture()
    assert result

# Generated at 2022-06-21 15:46:48.908401
# Unit test for method address of class Address
def test_Address_address():
    address = Address('fr')
    assert address.address() == '5, rue du La Bassée'


# Generated at 2022-06-21 15:46:50.225226
# Unit test for method longitude of class Address
def test_Address_longitude():
    address=Address()
    longitude=address.longitude()
    print(longitude)
    assert longitude==str(longitude)


# Generated at 2022-06-21 15:46:52.078319
# Unit test for method state of class Address
def test_Address_state():
    address = Address(locale='en')
    state = address.state()
    assert len(state) == 2
    assert state == state.upper()



# Generated at 2022-06-21 15:46:58.752145
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    address = Address('it')
    print(address.state()) # Stampa una provincia italiana
    print(address.state(abbr=True)) # Stampa l'abbreviativo di una provincia italiana


# Generated at 2022-06-21 15:47:04.548568
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    longitude = address.longitude()
    latitude = address.latitude()
    coordinates = address.coordinates()
    assert type(longitude) is float and -180 <= longitude <= 180
    assert type(latitude) is float and -90 <= latitude <= 90
    assert type(coordinates) is dict and coordinates.keys() == {'longitude', 'latitude'}
    assert -180 <= coordinates['longitude'] <= 180 and -90 <= coordinates['latitude'] <= 90

# Generated at 2022-06-21 15:47:06.150974
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    ad = Address()

    assert ad.prefecture(True)

# Generated at 2022-06-21 15:47:09.075853
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    print("test_Address_street_suffix():")
    print("Expected: ","street_suffix")
    print("Actual  : ",Address().street_suffix())


# Generated at 2022-06-21 15:47:11.012822
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis import Address
    
    a = Address()
    
    print(a.postal_code())


# Generated at 2022-06-21 15:47:20.228935
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    assert a.zip_code() == a.postal_code()

# Generated at 2022-06-21 15:47:21.389753
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    assert address.city()

# Generated at 2022-06-21 15:47:22.948082
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address().longitude()

 # Unit test for method latitude of class Address

# Generated at 2022-06-21 15:47:31.358166
# Unit test for method country of class Address
def test_Address_country():
    """Test method country of class Address.
    """
    from mimesis.enums import CountryCode
    
    address = Address()
    value = address.country(allow_random=True)
    value_ = address.country()
    value__ = address.country_code(CountryCode.A3)

    assert value is not None
    assert value_ is not None
    assert value__ is not None
    assert isinstance(value, str)
    assert isinstance(value_, str)
    assert isinstance(value__, str)

# Generated at 2022-06-21 15:47:35.055756
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    longitude = address.longitude()
    assert type(longitude) == float
    assert -180 <= longitude <= 180
    assert len(str(longitude)) == 10



# Generated at 2022-06-21 15:47:47.094644
# Unit test for constructor of class Address
def test_Address():
    # create a obj
    tester = Address()

    # test public attributes
    assert tester.locale == "en-US"
    assert tester.seed is None
    assert tester.ctx is None

    # test if setted attributes are equal to the expected
    assert tester._datafile == 'address.json'

# Generated at 2022-06-21 15:47:49.698340
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # create object
    addr = Address()
    # return value
    zip_ = addr.zip_code()
    assert zip_ is not None


# Generated at 2022-06-21 15:47:52.156582
# Unit test for method longitude of class Address
def test_Address_longitude():
    adr = Address()
    result = adr.longitude()
    assert isinstance(result, (str, float))

# Generated at 2022-06-21 15:47:53.789685
# Unit test for method continent of class Address
def test_Address_continent():
    obj = Address()
    obj.seed(1)
    assert obj.continent() == 'Asia'


# Generated at 2022-06-21 15:48:01.855548
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()

# Generated at 2022-06-21 15:48:12.114302
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    c = a.country_code()
    assert len(c) > 0

# unit test for method country of class Address

# Generated at 2022-06-21 15:48:14.189200
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    import pytest

    with pytest.raises(AttributeError, match='is not an attribute of'):
        Address.federal_subject()


# Generated at 2022-06-21 15:48:15.334233
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Unit test for method calling_code of class Address."""
    a = Address()
    assert len(a.calling_code()) == 3

# Generated at 2022-06-21 15:48:16.245243
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code() != None

# Generated at 2022-06-21 15:48:17.927830
# Unit test for method province of class Address
def test_Address_province():
    assert Address.province() is not None


# Generated at 2022-06-21 15:48:19.810326
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address('es')
    result = address.latitude()
    assert type(result) is float


# Generated at 2022-06-21 15:48:21.106169
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert str(a.calling_code())



# Generated at 2022-06-21 15:48:23.694134
# Unit test for method city of class Address
def test_Address_city():
    for i in range(10):
        city = Address().city()

# Generated at 2022-06-21 15:48:34.106228
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Belgian postal codes
    postal_codes = ['8210', '4960', '3630', '8750',
                    '1570', '7782', '8554', '1367',
                    '3840', '8900', '4140', '2280',
                    '3700', '6700', '2690', '8000',
                    '1040', '3680', '1000', '4900',
                    '1090', '9800', '1640', '1790',
                    '9120', '8780', '4300', '3870',
                    '8600', '6987', '2930', '8972',
                    '8790', '9450', '4350', '1770']

    postal_codes = set(postal_codes)


# Generated at 2022-06-21 15:48:36.436730
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert address.street_number() != '1300'


# Generated at 2022-06-21 15:48:47.949022
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country() in a._data['country']['name']
    assert a.country(allow_random=True) in a._data['country']['name']


# Generated at 2022-06-21 15:48:51.646250
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    # Method longitude() of class Address must return value 
    # between -180 and 180
    assert a.longitude(dms=False) < 180 and a.longitude(dms=False) > -180


# Generated at 2022-06-21 15:49:02.439021
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode

    address_provider = Address()

    fmt = CountryCode.A2
    # Test with existing key in `COUNTRY_CODES`
    assert address_provider.country_code(fmt)

    fmt = CountryCode.A3
    # Test with existing key in `COUNTRY_CODES`
    assert address_provider.country_code(fmt)

    fmt = CountryCode.NUMERIC
    # Test with existing key in `COUNTRY_CODES`
    assert address_provider.country_code(fmt)

    fmt = 130
    # Test with not existing key in `COUNTRY_CODES`
    assert address_provider.country_code(fmt) is None

# Generated at 2022-06-21 15:49:05.587184
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    x = a.country_code(CountryCode.A2)
    assert len(x) == 2
    y = a.country_code(CountryCode.A3)
    assert len(y) == 3


# Generated at 2022-06-21 15:49:08.080266
# Unit test for method continent of class Address
def test_Address_continent():
    print(Address().continent(False))
    print(Address().continent(True))

test_Address_continent()

# Generated at 2022-06-21 15:49:13.113974
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    provider = Address(random=FakeRandom(1))
    assert provider.coordinates() == {'latitude': -22.946458,
                                      'longitude': 159.107052}
    assert provider.coordinates(dms=True) == {'latitude': '-22º56\'47.265"S',
                                              'longitude': '159º6\'25.382"E'}

# Generated at 2022-06-21 15:49:14.368703
# Unit test for method city of class Address
def test_Address_city(): 
    assert Address().city() is not None


# Generated at 2022-06-21 15:49:17.273405
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert address.region() == "город Новосибирск"
    assert address.region(abbr=True) == "НС"

# Unit tests for method city of class Address

# Generated at 2022-06-21 15:49:21.290481
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    test_address_1 = Address()
    assert test_address_1.federal_subject() in (
        'MEX', 'GTM', 'PRY', 'BRA', 'ARG', 'CHL', 'COL', 'PER',
        'VEN', 'ECU', 'GUY', 'SUR', 'BOL', 'URY', 'PRY', 'PAR',
        'FLK', 'BRA', 'ARG', 'URY', 'BOL', 'CHL', 'PER')


# Generated at 2022-06-21 15:49:22.957125
# Unit test for method province of class Address
def test_Address_province():
    s = Address()
    p = s.province()
    assert p == "TL"


# Generated at 2022-06-21 15:49:44.232802
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.builtins import RussiaSpecProvider

    address = Address(RussiaSpecProvider)
    assert address.country(allow_random=True) == 'Azerbaijan'
    assert address.country() == 'Russia'

# Generated at 2022-06-21 15:49:46.441215
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address(locale = 'zh')
    result = a.continent()
    assert result in a._data['continent']


# Generated at 2022-06-21 15:49:49.996344
# Unit test for method address of class Address
def test_Address_address():
    _a = Address()
    _s = set()
    for _ in range(100):
        _s.add(_a.address())
    assert len(_s) > 1



# Generated at 2022-06-21 15:49:51.921124
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    pass


# Generated at 2022-06-21 15:49:53.387687
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    print(a.street_suffix())

# Generated at 2022-06-21 15:49:55.842393
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    adr = Address()
    assert adr.calling_code() == '81-532-350-1437'


# Generated at 2022-06-21 15:49:57.200877
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    print(a.address())

# Generated at 2022-06-21 15:49:58.263503
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    print(a.street_suffix())


# Generated at 2022-06-21 15:50:00.228089
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis import Address
    address = Address('es')
    result = address.calling_code()
    print(result)



# Generated at 2022-06-21 15:50:04.821072
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """unit testing"""
    provider = Address()
    provider_Postal_Code = provider.postal_code()
    assert len(provider_Postal_Code) == len(provider._data['postal_code_fmt'])


# Generated at 2022-06-21 15:50:34.057613
# Unit test for method province of class Address
def test_Address_province():
    locale = 'en'
    seed = 0
    PROVINCE = {
        'en': [
            'Quebec', 'Prince Edward Island', 'Ontario',
            'Manitoba', 'New Brunswick', 'British Columbia',
            'Saskatchewan', 'Newfoundland and Labrador',
            'Alberta', 'Nova Scotia', 'Yukon', 'Northwest Territories',
            'Nunavut'
        ]
    }
    address = Address(locale, seed)
    result = address.province()
    assert result in PROVINCE.get(locale)

# Generated at 2022-06-21 15:50:36.247621
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    p = address.prefecture()
    assert isinstance(p, str)
    assert p == address.state()



# Generated at 2022-06-21 15:50:40.477695
# Unit test for method province of class Address
def test_Address_province():
    add = Address()

    ap = add.province()
    assert (type(ap) == str)
    assert (len(ap) > 0)

    ap = add.province(True)
    assert (type(ap) == str)
    assert (len(ap) > 0)



# Generated at 2022-06-21 15:50:42.089212
# Unit test for method city of class Address
def test_Address_city():
    addr = Address()
    assert isinstance(addr.city(), str)


# Generated at 2022-06-21 15:50:43.595666
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country() is "Canada"


# Generated at 2022-06-21 15:50:47.939247
# Unit test for method street_name of class Address
def test_Address_street_name():
    print(
        (
            "Testing Address.street_name\n"
            "==========================\n"
        )
    )

    a1 = Address()

    s = a1.street_name()

    print('Street Name:', s)


# Generated at 2022-06-21 15:50:49.109071
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Unit test for method calling_code of class Address."""

    addr = Address()
    result = addr.calling_code()
    assert result == "260"


# Generated at 2022-06-21 15:50:51.495983
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address('ru').prefecture.__name__ ==\
        Address('ru').federal_subject.__name__ ==\
        Address('ru').province.__name__ ==\
        Address('ru').region.__name__ == 'state'

# Generated at 2022-06-21 15:51:02.427687
# Unit test for constructor of class Address
def test_Address():
    address = Address(random_state="42")
    assert address.postal_code() == "43928"
    assert address.street_number() == "1400"
    assert address.street_name() == "Collins Avenue"
    assert address.street_suffix() == "Place"
    assert address.address() == "1400 Collins Avenue"
    assert address.state() == "LA"
    assert address.region() == "LA"
    assert address.province() == "LA"
    assert address.federal_subject() == "LA"
    assert address.prefecture() == "LA"
    assert address.country() == "United States of America"
    assert address.country_code() == "US"
    assert address.continent() == "North America"
    assert address.city() == "Northwood"

# Generated at 2022-06-21 15:51:03.753503
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert address.street_name() == 'Av. Santa Marina'


# Generated at 2022-06-21 15:51:47.809249
# Unit test for method city of class Address
def test_Address_city():
    assert Address().city() != ''


# Generated at 2022-06-21 15:51:50.983690
# Unit test for method longitude of class Address
def test_Address_longitude():
    m = Address(locale='en')
    ret_val1 = m.longitude()
    ret_val2 = m.longitude(dms=True)
    assert type(ret_val1) == type(ret_val2)
    assert ret_val1 < ret_val2


# Generated at 2022-06-21 15:51:52.654261
# Unit test for method city of class Address
def test_Address_city():
    """Unit test for the method city of class Address."""
    result = Address().city()
    assert result
    assert isinstance(result, str)



# Generated at 2022-06-21 15:51:54.264437
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    rus = RussiaSpecProvider()
    e = Address(locale='ru')
    rus.address() == e.address()

# Generated at 2022-06-21 15:51:58.517719
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis import Address
    address = Address('en')
    assert address.latitude() == address.latitude()

    assert address.latitude() == address.latitude()

    assert address.latitude() == address.latitude()

    assert address.latitude() == address.latitude()


# Generated at 2022-06-21 15:52:14.521915
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    assert Address().coordinates(dms=False) == {'longitude': -15.123436, 'latitude': 74.320375}
    assert Address().coordinates(dms=True) == {'longitude': '91º42\'42.879"W', 'latitude': '83º53\'13.313"N'}

# Generated at 2022-06-21 15:52:24.956592
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Test to validate if the postal code is being generated correctly.

    :return: Boolean value if the test was successful or not.
    """
    data_set = [
        ['BR', '\d{8}'],
        ['JP', '\d{3}-\d{4}'],
        ['CH', '\d{4}'],
        ['IT', '\d{5}'],
        ['ES', '\d{5}'],
        ['PT', '\d{4}-\d{3}'],
        ['US', '\d{5}(-\d{4})?'],
        ['DE', '\d{5}'],
        ['AU', '\d{4}'],
        ['FR', '\d{5}'],
    ]

    failed_tests = 0

   

# Generated at 2022-06-21 15:52:26.035765
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    Address.federal_subject()

# Generated at 2022-06-21 15:52:34.516973
# Unit test for method street_name of class Address
def test_Address_street_name():
    test = Address().street_name()

# Generated at 2022-06-21 15:52:35.244894
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    pass

# Generated at 2022-06-21 15:53:57.254020
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    result = address.postal_code()
    print(result)



# Generated at 2022-06-21 15:54:04.953886
# Unit test for method province of class Address
def test_Address_province():
    address = Address('ru')

# Generated at 2022-06-21 15:54:05.964494
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code().__eq__("1")


# Generated at 2022-06-21 15:54:07.008562
# Unit test for method region of class Address
def test_Address_region():
    assert type(Address().region()) == str


# Generated at 2022-06-21 15:54:09.951435
# Unit test for method street_number of class Address
def test_Address_street_number():
    address_1 = Address()
    assert len(address_1.street_number()) == 4
    assert len(address_1.street_number(maximum=1000)) == 4
    assert len(address_1.street_number(maximum=10)) == 2
    assert len(address_1.street_number(maximum=1)) == 1


# Generated at 2022-06-21 15:54:13.152210
# Unit test for method country of class Address
def test_Address_country():
    # the test should pass but it failed
    # base on the generated result
    data = ['Úniã' if x == 'Úniã' else 'Canada' for x in Address().country(allow_random=True) ] 
    assert Address().country() in data

# Generated at 2022-06-21 15:54:17.559463
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    country_code = a.country_code(CountryCode.NUMERIC)
    assert country_code in ['276', '531', '532', '533', '534', '535', '536', '537', '538', '539']

# Generated at 2022-06-21 15:54:19.736223
# Unit test for method province of class Address
def test_Address_province():
    generator = Address('ru')
    result = generator.province()
    print(result)


# Generated at 2022-06-21 15:54:21.802568
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    country = address.country()
    assert country != ''
    assert len(country) > 0


# Generated at 2022-06-21 15:54:27.844159
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import CountryCode
    a = Address(locale='en', seed=123)
    assert a.zip_code() == '9724'
    a.locale = 'us'
    assert a.zip_code() == '19005'
    a.locale = 'ja'
    assert a.zip_code() == '973-0104'
    a.country_code(CountryCode.A3) == 'JPN'
    assert a.zip_code() == '973-0104'
    a.country_code(CountryCode.A2) == 'JP'
    assert a.zip_code() == '973-0104'