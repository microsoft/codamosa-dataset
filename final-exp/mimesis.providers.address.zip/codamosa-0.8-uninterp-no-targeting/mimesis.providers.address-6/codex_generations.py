

# Generated at 2022-06-21 15:45:33.664765
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Test method latitude of class Address."""
    a = Address()
    lat = a.latitude()
    assert -90 <= lat <= 90


# Generated at 2022-06-21 15:45:38.769837
# Unit test for method country_code of class Address
def test_Address_country_code():
    print("\nUnit test for method country_code of class Address")
    address = Address()
    print(address.country_code(CountryCode.A2))
    print(address.country_code(CountryCode.A3))
    print(address.country_code(CountryCode.NUMERIC))
    print(address.country_code(CountryCode.NAME))


# Generated at 2022-06-21 15:45:44.167675
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    '''
    test_Address_prefecture(void) -> void
    
    check for prefecture() method in Address()
    
    '''
    print("\n")
    print("*********** # Unit test for method prefecture of class Address *********** ")
    print("\n")
    adress_test = Address(random.choice(['en','ru','zh']))
    prefecture = adress_test.prefecture()
    
    print("The following test the method prefecture():")
    print("\n")
    print("The result of the prefecture is: "+ prefecture)

# Generated at 2022-06-21 15:45:47.680869
# Unit test for method street_name of class Address
def test_Address_street_name():
    obj = Address('en')
    st_name = obj.street_name()
    assert st_name in obj._data['street']['name']


# Generated at 2022-06-21 15:45:49.792372
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    addr = Address()
    kanto = addr.prefecture()
    assert kanto == '千葉県'

# Generated at 2022-06-21 15:45:57.024321
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address().postal_code() == '90210'
    assert Address().postal_code() == '19-110'
    assert Address().postal_code() == '90210'
    assert Address().postal_code() == '90-210'
    assert Address().postal_code() == '90210'
    assert Address().postal_code() == '10085'
    assert Address().postal_code() == '00085'
    assert Address().postal_code() == '403-8076'
    assert Address().postal_code() == '403-8076'

# Generated at 2022-06-21 15:46:04.888059
# Unit test for method address of class Address
def test_Address_address():
    # Create an instance of Address
    address = Address(locale='de')
    # Get a random street name
    street_name = address.street_name()
    # Get a random street number
    street_number = address.street_number()
    # Get a random street suffix
    street_suffix = address.street_suffix()
    # Get a random full address
    full_address = address.address()

    # Check the result
    assert full_address == f'{street_number} {street_name} {street_suffix}'


# Generated at 2022-06-21 15:46:14.510897
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import random
    random_t = random.Random()
    random_t.seed(0)

    coordenadas = Address(random_t).coordinates(dms=False)
    print(coordenadas)
    assert coordenadas == {'longitude': -0.345826, 'latitude': -0.595156}

    coordenadas = Address(random_t).coordinates(dms=True)
    print(coordenadas)
    assert coordenadas == {'longitude': '0º20\'44.296"W', 'latitude': '0º35\'42.563"S'}



# Generated at 2022-06-21 15:46:17.371415
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    b = a.province()
    assert(callable(b) is False)


# Generated at 2022-06-21 15:46:18.166247
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    pr = Address(locale='jp')
    print(pr.postal_code())

# Generated at 2022-06-21 15:46:23.653854
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # Test prefecture
    a = Address(locale='ja')
    print(a.prefecture())
    # => 京都府


# Generated at 2022-06-21 15:46:27.866697
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address(locale='en')
    assert a.postal_code() in ('\d{5}', '\d{6}', '\d{9}')

# Generated at 2022-06-21 15:46:39.247786
# Unit test for method longitude of class Address
def test_Address_longitude():
    class returned_value_Address():
        def __init__(self):
            self.result = -135.582314

        def return_test_Address_longitude(self):
            return self.result

    class mock_uniform():
        def __init__(self, rng1, rng2, precision):
            self.rng1 = rng1
            self.rng2 = rng2
            self.precision = precision

        def return_test_random_uniform(self):
            returned_value_Address.result = -135.582314
            return returned_value_Address()

    mock_uniform = mock_uniform(-180, 180, 6)
    Address.random.uniform = mock_uniform.return_test_random_uniform
    actual_value = Address().longitude()
    expected

# Generated at 2022-06-21 15:46:45.840017
# Unit test for method city of class Address
def test_Address_city():
    # as we are aware that the city names are different in different regions, to check whether the function returns right city name or not we set the locale to a fixed value and call the function
    # we set the locale to 'en-US' and check if the city name returned is 'New York'
    assert Address(locale='en-US').city() == 'New York'
    # if the city name is returned as 'New York' then we assert true
    

# Generated at 2022-06-21 15:46:48.299919
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr = Address()
    for i in range(0, 15):
        st_name = addr.street_name()
        print(st_name)


# Generated at 2022-06-21 15:46:50.486926
# Unit test for method state of class Address
def test_Address_state():
    results = {'ja': '青森県', 'en_GB': 'Northamptonshire', 'zh_CN': '北京市'}
    for lang in results:
        addr = Address(lang)
        assert addr.state() == results[lang]

# Generated at 2022-06-21 15:46:52.923042
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # Create object of class Address
    address = Address()

    # Generate prefecture
    prefecture = address.prefecture()

    # Check if generated prefecture is present in the list of prefectures
    assert prefecture in address.state(abbr=True)

# Generated at 2022-06-21 15:46:55.031172
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    assert isinstance(a.street_name(), str)

# Generated at 2022-06-21 15:46:57.211301
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert isinstance(address.province(), str)


# Generated at 2022-06-21 15:46:58.238974
# Unit test for method city of class Address
def test_Address_city():
    testObjet = Address()
    testObserver = testObjet.city()
    assert isinstance(testObserver, str)


# Generated at 2022-06-21 15:47:09.477818
# Unit test for constructor of class Address
def test_Address():
    """Test Address class constructor."""
    a = Address()
    assert a.locale == 'en'
    a = Address(locale='ru')
    assert a.locale == 'ru'
    assert a.localizer.locale == 'ru'



# Generated at 2022-06-21 15:47:11.393297
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    latitude = address.latitude()
    assert type(latitude) in [float, str]


# Generated at 2022-06-21 15:47:14.607176
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adr = Address(random_state=1)
    sub = adr.federal_subject()
    assert sub == 'Ульяновская обл'


# Generated at 2022-06-21 15:47:16.028169
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    x = Address()
    x.address()

# Generated at 2022-06-21 15:47:17.018798
# Unit test for method country of class Address
def test_Address_country():
    a = Address(seed=1234567890)
    assert a.country(allow_random=True) == 'Niger'

# Generated at 2022-06-21 15:47:18.226277
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    print(address.longitude())


# Generated at 2022-06-21 15:47:22.583279
# Unit test for method latitude of class Address
def test_Address_latitude():
    ad = Address(seed=1337)
    # print(ad.latitude(dms=True))
    assert ad.latitude(dms=True) =='45º47\'37.94504"N'

# Generated at 2022-06-21 15:47:25.755877
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    fakes = [Address('zh').street_suffix() for _ in range(10)]
    assert fakes != []
    assert len(fakes) == 10


# Generated at 2022-06-21 15:47:29.227046
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    postal_code = address.postal_code()
    assert len(postal_code) == 5
    assert postal_code.isnumeric()


# Generated at 2022-06-21 15:47:31.680969
# Unit test for method province of class Address
def test_Address_province():
    ad = Address()
    assert(ad.province() in ad._data['state']['name'])


# Generated at 2022-06-21 15:47:49.321261
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    full_address = address.address()


# Generated at 2022-06-21 15:47:53.464443
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import CountryCode
    from mimesis.providers import Address
    a = Address
    a.__init__()
    assert isinstance(a.zip_code(), str)
    assert a.zip_code()

# Generated at 2022-06-21 15:47:54.633807
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() in ['Street', 'Avenue', 'Court']

# Generated at 2022-06-21 15:47:56.101009
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    provider = Address()
    assert provider.zip_code() == provider.postal_code()


# Generated at 2022-06-21 15:47:57.477337
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a is not None

# Generated at 2022-06-21 15:47:59.364117
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    result = address.latitude()
    assert result < 90
    assert result > -90


# Generated at 2022-06-21 15:48:01.938048
# Unit test for method latitude of class Address
def test_Address_latitude():
    """unit test for method latitude of class Address."""
    # initialization
    address = Address(locale='zh')
    # generate the result
    result = address.latitude()
    # test the result
    assert result != None


# Generated at 2022-06-21 15:48:04.937340
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.providers.address import Address
    addr = Address()
    print("street_name: {}".format(addr.street_name()))



# Generated at 2022-06-21 15:48:06.802137
# Unit test for method street_number of class Address
def test_Address_street_number():
    result=Address.street_number()


# Generated at 2022-06-21 15:48:11.024919
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Unit test for method longitude of class Address.

    Expected result is between -180.0 and 180.0.

    :return:
    """
    generator = Address('en')
    assert type(generator.longitude()) == float
    assert 180.0 >= generator.longitude() >= -180.0


# Generated at 2022-06-21 15:48:32.158605
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    coordinates = address.coordinates()
    assert isinstance(coordinates, dict)
    assert isinstance(coordinates.get('longitude'), float)
    assert isinstance(coordinates.get('latitude'), float)

# Generated at 2022-06-21 15:48:33.571354
# Unit test for method city of class Address
def test_Address_city():
    print('Address.city() \t\t\t= ', Address().city())


# Generated at 2022-06-21 15:48:35.098905
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    for x in range(10):
        Address().calling_code()

# Generated at 2022-06-21 15:48:39.711811
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    '''Test the method Address.street_suffix
    
    :return: None
    '''
    address = Address('ja')
    result = address.street_suffix()
    print(result)
    assert result != None


# Generated at 2022-06-21 15:48:42.377478
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.__class__.__name__ == 'Address'
    assert address.__dict__ != {}


# Generated at 2022-06-21 15:48:45.731343
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    st_num = a.street_number()
    st_name = a.street_name()
    st_sfx = a.street_suffix()
    address1 = a.address()
    address2 = st_num + st_name + st_sfx
    assert address1 == address2


# Generated at 2022-06-21 15:48:48.853383
# Unit test for method address of class Address
def test_Address_address():
    # Arrange
    address = Address(locale='en')
    # Act
    res = [ address.address() for _ in range(0,5) ]
    # Assert
    assert (res == address.address() for _ in range(0,5))

# Generated at 2022-06-21 15:48:50.742929
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert isinstance(address.region(True), str)


# Generated at 2022-06-21 15:48:53.249377
# Unit test for method region of class Address
def test_Address_region():
    """Test method region of class Address."""
    a = Address()
    assert a.region()



# Generated at 2022-06-21 15:49:00.556114
# Unit test for method country_code of class Address
def test_Address_country_code():
    t = Address()
    assert t.country_code(CountryCode.A2) in COUNTRY_CODES.get(CountryCode.A2)
    assert t.country_code(CountryCode.A3) in COUNTRY_CODES.get(CountryCode.A3)
    assert t.country_code(CountryCode.NA) in COUNTRY_CODES.get(CountryCode.NA)
    assert t.country_code(CountryCode.NUM) in COUNTRY_CODES.get(CountryCode.NUM)

# Generated at 2022-06-21 15:49:42.277199
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    print("\nTesting Address.prefecture()")
    addr = Address()
    print(addr.prefecture() + "\n")


# Generated at 2022-06-21 15:49:46.544601
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    # From 0.9 to 1.1 degrees
    lg = 0.9 + 0.2 * random()
    # From 0.9 to 1.1 degrees
    lt = 0.9 + 0.2 * random()

    a = Address(lg=lg, lt=lt)
    c = a.coordinates()
    assert (lg - 0.1) <= c['longitude'] <= (lg + 0.1)
    assert (lt - 0.1) <= c['latitude'] <= (lt + 0.1)



# Generated at 2022-06-21 15:49:58.033651
# Unit test for method state of class Address
def test_Address_state():
    ad = Address(locale='zh')
    assert ad.state() in ['广东省', '广西壮族自治区', '云南省']

    assert ad.state(abbr=False) in ['广东省', '广西壮族自治区', '云南省']

    assert ad.state(abbr=True) in ['广东省', '广西壮族自治区', '云南省']

    ad.set_locale('en')

    assert ad.state() in ['California', 'New York', 'Texas']


# Generated at 2022-06-21 15:50:03.299623
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed=1)
    assert address.address() == '73199 Teresa Vista'
    assert address.address() == '68592 Graham Cliffs'
    assert address.address() == '2159 Howard Avenue'
    assert address.address() == '9593 West Travis'
    assert address.address() == '1730 Browning Road'


# Generated at 2022-06-21 15:50:06.777172
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr = Address()
    assert re.fullmatch(r'^\d{5}(?:[-\s]\d{4})?$', addr.zip_code())


# Generated at 2022-06-21 15:50:17.652638
# Unit test for method country of class Address
def test_Address_country():
    address_zh_CN = Address('zh_CN')
    address_en_US = Address('en_US')
    address_de_AT = Address('de_AT')
    address_fr_FR = Address('fr_FR')
    address_ru_RU = Address('ru_RU')
    address_ja_JP = Address('ja_JP')
    address_uk_UA = Address('uk_UA')

    assert address_zh_CN.country() == '中国'
    assert address_en_US.country() == 'United States'
    assert address_de_AT.country() == 'Österreich'
    assert address_fr_FR.country() == 'France'
    assert address_ru_RU.country() == 'Россия'
    assert address_ja_JP.country()

# Generated at 2022-06-21 15:50:19.593485
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    x = Address()
    print(x.zip_code())
# test_Address_zip_code()

# Generated at 2022-06-21 15:50:20.958354
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('es')
    assert address.postal_code() == '28080'


# Generated at 2022-06-21 15:50:25.596689
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    a = Address(locale='en')
    print(a.province(abbr='true'))
    a.reset_locale('en')
    print(a.province(abbr='true'))

# Generated at 2022-06-21 15:50:36.933364
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    add = Address("zh")

# Generated at 2022-06-21 15:51:22.165385
# Unit test for constructor of class Address
def test_Address():
    geo = Address(locale='en')
    assert type(geo) == Address


# Generated at 2022-06-21 15:51:25.097570
# Unit test for method country of class Address
def test_Address_country():
    # The country of locale ru-RU is Russia
    addr = Address()
    addr_with_random = Address(allow_random=True)
    assert addr.country() == 'Russia'
    assert addr_with_random.country() != 'Russia'

# Generated at 2022-06-21 15:51:32.014181
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import CountryCode
    from mimesis.builtins import RussiaSpecProvider

    # Create object of class Address
    Address_obj = Address(RussiaSpecProvider)

    # Create object of class CountryCode
    CountryCode_obj = CountryCode

    # Call the method
    result = Address_obj.federal_subject(CountryCode_obj.A2)
    print(result)

    # Call method with russian country code
    result = Address_obj.federal_subject(CountryCode_obj.RU)
    print(result)

    # Call method with russian country code
    result = Address_obj.federal_subject(CountryCode_obj.RU.value)
    print(result)



# Generated at 2022-06-21 15:51:35.794486
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    from mimesis.providers.base import BaseDataProvider
    # Generate random city name
    print(Address().city())
    # Generate random city name of specific locale
    print(Address('ja').city())
    # Generate random city name of specific country
    a = Address(country='JP')
    print(a.city())
    # Generate random city name with ISO 3166-1-alpha-2 code
    print(Address(country=CountryCode.A2).city())
    # Generate random city name with ISO 3166-1-alpha-3 code
    print(Address(country=CountryCode.A3).city())
    # Generate random city name with ISO 3166-1-numeric code

# Generated at 2022-06-21 15:51:38.053453
# Unit test for method street_number of class Address
def test_Address_street_number():
    n = Address().street_number()
    assert isinstance(n, str)


# Generated at 2022-06-21 15:51:39.846699
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import CountryCode
    from mimesis.builtins import Address
    adr = Address()
    adr.federal_subject()

# Generated at 2022-06-21 15:51:42.350836
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address()
    assert addr.street_suffix() in ('cir', 'ct', 'ave')


# Generated at 2022-06-21 15:51:43.659847
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    pprint(address.calling_code())



# Generated at 2022-06-21 15:51:45.017669
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address('en')
    assert addr.street_suffix() == 'Pass'


# Generated at 2022-06-21 15:51:47.718881
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Unit test for method latitude of class Address"""
    # Initializing the object with parameters
    address = Address('en')
    # Calling function
    address.latitude(True)
    # Checking the output



# Generated at 2022-06-21 15:52:53.850107
# Unit test for method country of class Address
def test_Address_country():
    addresses = (
        Address(locale='en'),
        Address(locale='zh'),
        Address(locale='ja'),
        Address(locale='ru'),
        Address(locale='fr'),
        Address(locale='id'),
        Address(locale='es'),
        Address(locale='ar'),
        Address(locale='en', allow_random=True),
        Address(locale='zh', allow_random=True),
        Address(locale='ja', allow_random=True),
        Address(locale='ru', allow_random=True),
        Address(locale='fr', allow_random=True),
        Address(locale='id', allow_random=True),
        Address(locale='es', allow_random=True),
        Address(locale='ar', allow_random=True),
    )

# Generated at 2022-06-21 15:52:55.656235
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert isinstance(address.street_number(), str)


# Generated at 2022-06-21 15:52:59.656768
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    # test len street_name
    assert(len(address.street_name()) >= 3)
    # test address format
    assert(len(address.address()) > 10)
    # test street_number
    assert(address.street_number()[0] != "0")



# Generated at 2022-06-21 15:53:03.567742
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Coordinate unit test."""
    a = Address()
    b = a.coordinates()

    assert 'latitude' in b and 'longitude' in b
    assert '-' in b['latitude'] and '-' in b['longitude']

# Generated at 2022-06-21 15:53:05.301732
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    print(address.continent())
    print(address.continent(code=True))


# Generated at 2022-06-21 15:53:08.872605
# Unit test for method street_name of class Address
def test_Address_street_name():
    expected = ['1st Street', '1st Avenue', 'Main Street', 'Park Avenue']
    en = Address('en')
    got = []
    for _ in range(0, 4):
        got.append(en.street_name())
    assert got == expected


# Generated at 2022-06-21 15:53:13.007054
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address(locale='zh-CN')
    street_name = address.street_name()
    assert type(street_name) is str
    assert street_name in address._data['street']['name']
    

# Generated at 2022-06-21 15:53:14.572759
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state() in ('MI', 'OH', 'CA', 'TX', 'MN')



# Generated at 2022-06-21 15:53:17.801235
# Unit test for method state of class Address
def test_Address_state():
    address = Address(locale='en')
    result = address.state(abbr=True)
    assert result
    assert isinstance(result, str)
    assert len(result) == 2


# Generated at 2022-06-21 15:53:19.324824
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    returned = Address().calling_code()
    return returned in CALLING_CODES


# Generated at 2022-06-21 15:54:52.485723
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Test Address().latitude"""
    _assert_isinstance_str(Address().latitude(), is_dms=True)


# Generated at 2022-06-21 15:54:55.180128
# Unit test for method continent of class Address
def test_Address_continent():
    assert (Address().continent() in ('Europe', 'Asia', 'Africa', 
     'North America', 'South America', 'Oceania', 'Antarctica', 
     'Seven seas (open ocean)')) == True


# Generated at 2022-06-21 15:54:57.075482
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert 'Москва' == Address('ru').federal_subject()
    assert '石川県' == Address('ja').federal_subject()

# Generated at 2022-06-21 15:54:58.631122
# Unit test for method continent of class Address
def test_Address_continent():
    # generate
    a = Address("en")
    # unit test
    assert a.continent("it") in CONTINENT_CODES


# Generated at 2022-06-21 15:55:00.858452
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert isinstance(a, Address)
    assert isinstance(a.provider, BaseDataProvider)
    assert hasattr(a, 'latitude')
    assert hasattr(a, 'continent')


# Generated at 2022-06-21 15:55:01.947055
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert isinstance(address.street_number(), str)


# Generated at 2022-06-21 15:55:08.356684
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Unit test: Address.postal_code()."""
    address = Address()
    for fmt in address.get_locales():
        address.set_locale(fmt)
        postal_code = address.postal_code()
        print(postal_code)
        assert isinstance(postal_code, str)
        if address.locale == 'bg':
            assert len(postal_code) == 4
        else:
            assert len(postal_code) == 5


# Generated at 2022-06-21 15:55:10.115686
# Unit test for method longitude of class Address
def test_Address_longitude():
    faker = Address()
    assert isinstance(faker.longitude(), float)

# Generated at 2022-06-21 15:55:18.786964
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import Country

    country = 'jp'
    address = Address(country)
    result = address.prefecture(abbr=True)
    assert result
    assert result in address._data['state']['abbr']

    country = 'ru'
    address = Address(country)
    result = address.prefecture()
    assert result
    assert result in address._data['state']['name']

    country = 'de'
    address = Address(country)
    result = address.prefecture()
    assert result
    assert result in address._data['state']['name']

    country = Country.US
    address = Address(country)
    result = address.prefecture()
    assert result
    assert result in address._data['state']['name']

    country = 'uk'

# Generated at 2022-06-21 15:55:20.727259
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Unit testing for method street_number of class Address."""
    address = Address()
    result = address.street_number()

    assert result is not None
    assert isinstance(result, str)

