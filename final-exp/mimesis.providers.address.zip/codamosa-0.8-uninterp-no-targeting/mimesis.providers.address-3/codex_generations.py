

# Generated at 2022-06-21 15:45:39.194517
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    rez = address.coordinates()
    print(rez)
    rez = address.coordinates(dms=True)
    print(rez)


# Generated at 2022-06-21 15:45:41.165582
# Unit test for method street_number of class Address
def test_Address_street_number():
    address_provider = Address()
    result = address_provider.street_number()
    print(result)


# Generated at 2022-06-21 15:45:46.461298
# Unit test for constructor of class Address
def test_Address():
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address as BaseAddress

    base = BaseAddress()
    a = Address()
    assert base.seed == a.seed
    assert a._data == base._data
    assert a.address() != ''
    assert len(a.address()) > 5
    assert a.city() != ''
    assert len(a.city()) > 2
    assert a.postal_code() != ''
    assert len(a.postal_code()) > 3
    assert a.street_name() != ''
    assert len(a.street_name()) > 2
    assert a.street_suffix() != ''
    assert len(a.street_suffix()) > 2
    assert a.street_number() != ''


# Generated at 2022-06-21 15:45:49.395083
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address(seed=1)
    assert a.continent(code=True) == 'EU'
    assert a.continent() == 'Europe'

# Generated at 2022-06-21 15:45:51.884753
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address('en')
    latitude = a.latitude()
    assert (-90 < latitude < 90)


# Generated at 2022-06-21 15:45:53.831146
# Unit test for method country_code of class Address
def test_Address_country_code():
    country_code = Address().country_code()
    assert len(country_code) == 2


# Generated at 2022-06-21 15:45:56.223175
# Unit test for method street_number of class Address
def test_Address_street_number():
    adr = Address()
    print(type(adr.street_number()))
    assert isinstance(adr.street_number(), str)


# Generated at 2022-06-21 15:45:57.974744
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()
    print(result)


# Generated at 2022-06-21 15:46:08.199215
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    a = Address('en')
    a.country(allow_random=True)
    a.country_code(CountryCode.A2)
    a.country_code(CountryCode.A3)
    a.country_code(CountryCode.NUMERIC)
    a.continent(code=True)
    a.continent(code=False)
    a.coordinates(dms=True)
    a.coordinates(dms=False)
    a.latitude(dms=True)
    a.latitude(dms=False)
    a.longitude(dms=True)
    a.longitude(dms=False)
    a.region(abbr=True)

# Generated at 2022-06-21 15:46:15.244621
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import CountryCode
    a = Address()
    print(a.city())
    print(a.province())
    print(a.address())
    print(a.street_name())
    print(a.postal_code())
    print(a.country())
    print(a.country_code())
    print(a.coordinates(dms=True))

# Generated at 2022-06-21 15:46:21.384876
# Unit test for method longitude of class Address
def test_Address_longitude():
    adrs = Address()
    a = adrs.longitude()
    #print("test_Address_longitude(): a =", a)
    assert a is not None


# Generated at 2022-06-21 15:46:21.893618
# Unit test for method city of class Address
def test_Address_city():
    assert Address().city()

# Generated at 2022-06-21 15:46:23.256321
# Unit test for method city of class Address
def test_Address_city():
    city = Address().city()
    assert type(city) == str and len(city) > 0

# Generated at 2022-06-21 15:46:25.417822
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    addr = Address(locale='en')
    result = addr.calling_code()
    print(result)

if __name__ == '__main__':
    test_Address_calling_code()
    """
    +224
    """

# Generated at 2022-06-21 15:46:37.975062
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import CountryCode
    address = Address()
    fmt = address._data['address_fmt']
    st_num = address.street_number()
    st_name = address.street_name()

    if address.locale in SHORTENED_ADDRESS_FMT:
        address.address() == fmt.format(
            st_num=st_num,
            st_name=st_name,
        )

    if address.locale == 'ja':
        address.address() == fmt.format(
            address.random.choice(address._data['city']),
            # Generate list of random integers
            # in amount of 3, from 1 to 100.
            *address.random.randints(amount=3, a=1, b=100),
        )


# Generated at 2022-06-21 15:46:40.441199
# Unit test for method region of class Address
def test_Address_region():
    addr = Address()
    assert isinstance(addr.region(abbr=True), str)


# Generated at 2022-06-21 15:46:42.526162
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.region() in address._data['state']['name']

# Generated at 2022-06-21 15:46:45.007492
# Unit test for method country_code of class Address
def test_Address_country_code():
    address_obj = Address(locale="ro")
    country_code = address_obj.country_code(CountryCode.A2)
    assert country_code in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-21 15:46:46.031234
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.address() != ""

    return address

# Generated at 2022-06-21 15:46:49.201117
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    adr = Address()

    calling_code = adr.calling_code()
    calling_code2 = adr.calling_code()
    assert isinstance(calling_code, str)
    assert calling_code in CALLING_CODES
    assert calling_code == calling_code2


# Generated at 2022-06-21 15:47:00.504313
# Unit test for constructor of class Address
def test_Address():
    assert Address._meta.name == 'address'
    assert Address._meta.provider == 'mimesis'
    assert Address._meta.datasource == 'address.json'

    address = Address()
    assert address.seed is None

    address = Address('ru')
    assert address.seed == 'ru'


# Generated at 2022-06-21 15:47:02.859947
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender
    a = Address(Gender.MALE, 'en')
    assert "1234 Main Street" in a.address()


# Generated at 2022-06-21 15:47:04.353223
# Unit test for constructor of class Address
def test_Address():
    """Unit test for Address().

    :return: None.
    """
    addr = Address()
    assert addr is not None

# Generated at 2022-06-21 15:47:05.963581
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert (a.region() == 'CA')

# Generated at 2022-06-21 15:47:07.367579
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert type(a.calling_code()) is str

# Generated at 2022-06-21 15:47:09.120070
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    print(address.continent(code=True))



# Generated at 2022-06-21 15:47:10.006081
# Unit test for method region of class Address
def test_Address_region():
  assert isinstance(Address().region(), str)

# Generated at 2022-06-21 15:47:11.466231
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    ad = Address()
    assert ad.prefecture()


# Generated at 2022-06-21 15:47:14.970208
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    assert len(a.country_code()) == 2
    assert len(a.country_code(CountryCode.A3)) == 3
    assert len(a.country_code(CountryCode.NUMERIC)) == 4

# Generated at 2022-06-21 15:47:17.097558
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.providers.address import Address
    address = Address()
    assert len(address.state()) > 0


# Generated at 2022-06-21 15:47:24.963002
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    #Arrange
    import random
    random.seed(1)
    Ad=Address()
    #Act
    re=Ad.prefecture()
    #Assert
    assert re=='Saitama'


# Generated at 2022-06-21 15:47:26.798567
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert 1 <= Address().street_number() <= 1400


# Generated at 2022-06-21 15:47:27.592686
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    pass

# Generated at 2022-06-21 15:47:36.566378
# Unit test for method state of class Address
def test_Address_state():
    """Test for method state of class Address."""
    a = Address()
    for _ in range(10):
        assert len(a.state()) == 2
        assert type(a.state()) == str
        assert len(a.state(abbr=True)) == 2
        assert type(a.state(abbr=True)) == str
        assert a.state() or a.state(abbr=True) in a._data['state']['abbr']
        assert a.state(abbr=True) in a._data['state']['name']


# Generated at 2022-06-21 15:47:39.221722
# Unit test for method region of class Address
def test_Address_region():
    address = Address('en')
    assert type(address.region()) == str
    assert address.region() == address.state()


# Generated at 2022-06-21 15:47:41.636994
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for method federal_subject of class Address."""
    address = Address()
    assert address.federal_subject() is not None

# Generated at 2022-06-21 15:47:43.273370
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address


# Generated at 2022-06-21 15:47:46.139901
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Assertion for method latitude.

    :return: True if it is in range.
    """
    assert -90 <= Address().latitude() <= 90


# Generated at 2022-06-21 15:47:48.532556
# Unit test for method city of class Address
def test_Address_city():
    ad = Address("en")
    city = ad.city()
    #print("City: ", city)
    assert city


# Generated at 2022-06-21 15:47:55.722032
# Unit test for method address of class Address
def test_Address_address():
    # Test function address
    a = Address(locale='en')
    assert a.address() == '71 South Street\nSouth Robertville, NJ 78660'

    a = Address(locale='en')
    assert a.address() == '514 South Avenue\nPort Joanne, PE 59898'

    a = Address(locale='en')
    assert a.address() == '332 Hampton Court\nNorth Keithfurt, VA 00959'

    # Test function address for locale ja
    a = Address(locale='ja')
    assert a.address() == 'マヌキ市今井町1-23-4'

    a = Address(locale='ja')
    a.random.seed(728)

# Generated at 2022-06-21 15:48:03.924921
# Unit test for method street_name of class Address
def test_Address_street_name():
    provider = Address(locale='en')
    str_name = provider.street_name()
    assert type(str_name) == str and str_name



# Generated at 2022-06-21 15:48:07.155893
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    add = Address('en')
    f = add.federal_subject()
    assert isinstance(f, str)
    assert len(f) == 2
    

# Generated at 2022-06-21 15:48:08.573797
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    assert -180 <= address.longitude() <= 180

# Generated at 2022-06-21 15:48:09.444216
# Unit test for method continent of class Address
def test_Address_continent():
    Address(seed=1).continent()

# Generated at 2022-06-21 15:48:11.917675
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert type(a.continent()) is str
    assert len(a.continent()) > 0


# Generated at 2022-06-21 15:48:18.888878
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    address = Address('zh')
    longitude = address.longitude()
    assert longitude >= -180 and longitude <= 180
    longitude_dms = address.longitude(dms=True)
    assert longitude_dms.find(':') >= 0 and longitude_dms.find('.') >= 0
    assert address.calling_code() in CALLING_CODES
    assert address.country() in address._data['country']['name']
    assert address.country(allow_random=True) in address._data['country']['name']
    assert address.country_code() in COUNTRY_CODES[CountryCode.A2]
    assert address.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]


# Generated at 2022-06-21 15:48:21.016183
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Create Address object
    address = Address()

    # Print on console random longitude
    print("Longitude: " + address.longitude())

# Generated at 2022-06-21 15:48:24.905069
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address('')
    assert address.continent() in address._data['continent']
    assert address.continent(True) in CONTINENT_CODES

# Generated at 2022-06-21 15:48:28.432822
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    test_values = ['Avenue', 'Boulevard', 'Lane', 'Road', 'Street']
    assert (a.street_name() in test_values) is True

# Generated at 2022-06-21 15:48:29.705790
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject()


# Generated at 2022-06-21 15:48:46.007580
# Unit test for method street_number of class Address
def test_Address_street_number():
    seed(1)
    address = Address()
    street_number_list = []
    while len(street_number_list) < 10000:
        street_number = address.street_number()
        if street_number not in street_number_list:
            street_number_list.append(street_number)
    assert(len(street_number_list) == 1400)


# Generated at 2022-06-21 15:48:48.696021
# Unit test for method continent of class Address
def test_Address_continent():
    cc = Address()
    assert cc.continent() in ("Europe", "North America", "Africa", "Asia", "Oceania", "South America")

# Generated at 2022-06-21 15:48:52.315984
# Unit test for method state of class Address
def test_Address_state():
    """
    Test method state()
    """
    obj = Address("ru")
    assert obj.state() != None
    assert obj.state(abbr=True) != None
    assert obj.state(abbr=False) != None


# Generated at 2022-06-21 15:49:01.596289
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country() == '中国'

    from mimesis.enums import CountryCode

    assert a.country_code(fmt=CountryCode.A2) == 'CN'
    assert a.country_code(fmt=CountryCode.A3) == 'CHN'
    assert a.country_code(fmt=CountryCode.NUMERIC) == '156'
    assert a.country_code(fmt=CountryCode.NAME) == 'China'
    assert a.country_code(fmt=CountryCode.COUNTRY_CODE_TLD) == '.cn'


# Generated at 2022-06-21 15:49:11.911242
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.utils import Provider as Prov
    from mimesis.typing import Seed

    _str = str
    _fmt_str_generator = Prov.format_str_generator
    _normalize_string = Prov.normalize_string
    _seed = Prov.seed

    def _format_postal_code(self, seed: Seed, fmt: str) -> str:
        # TODO: Add tests
        return _fmt_str_generator(seed, fmt)


# Generated at 2022-06-21 15:49:13.541541
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    region = address.province()
    assert isinstance(region, str)


# Generated at 2022-06-21 15:49:15.399738
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.builtins import RussiaSpecProvider
    address = Address(RussiaSpecProvider)
    assert address.region() == address.federal_subject()
    assert address.province() == address.federal_subject()

# Generated at 2022-06-21 15:49:18.088934
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    province = address.province()
    assert isinstance(province, str)
    assert province in address._data['state']['name']


# Generated at 2022-06-21 15:49:19.116293
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    print(address.federal_subject(False))
    return

# Generated at 2022-06-21 15:49:22.624865
# Unit test for method continent of class Address
def test_Address_continent():
    var1 = Address()
    result = var1.continent()
    assert result in ('Europe', 'Asia', 'Africa', 'Antarctica', 'North America', 'South America', 'Oceania'), "Method has error"
    assert type(result) is str, "Method has error"

# Generated at 2022-06-21 15:49:52.200613
# Unit test for method latitude of class Address
def test_Address_latitude():
    test = Address()
    # Create test samples
    samples = set()
    while len(samples) < 100:
        samples.add(test.latitude())
    # Check that every sample is in range -90..90
    for sample in samples:
        assert -90 <= float(sample) <= 90



# Generated at 2022-06-21 15:49:55.521247
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address(seed=1234)
    assert a.federal_subject() == 'Оренбургская область'

# Generated at 2022-06-21 15:49:58.182046
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    a = Address(locale='en')
    assert len(a.latitude()) == len(a.latitude(dms=True))


# Generated at 2022-06-21 15:49:59.592614
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    region = a.region()
    assert isinstance(region, str)

# Generated at 2022-06-21 15:50:05.094834
# Unit test for method address of class Address
def test_Address_address():
    # Test for English
    en = Address(locale='en')
    assert isinstance(en.address(), str)
    assert all(map(lambda x: x.isalnum(), en.address().split()))

    # Test for Chinese
    zh = Address(locale='zh')
    assert isinstance(zh.address(), str)
    assert all(map(lambda x: x.isalnum(), zh.address().split()))

    # Test for French
    fr = Address(locale='fr')
    assert isinstance(fr.address(), str)
    assert all(map(lambda x: x.isalnum(), fr.address().split()))

    # Test for Japanese
    ja = Address(locale='ja')
    assert isinstance(ja.address(), str)

# Generated at 2022-06-21 15:50:07.202300
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address(locale="zh_CN")
    print(address.calling_code())


# Generated at 2022-06-21 15:50:08.946209
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    print(address.region())



# Generated at 2022-06-21 15:50:11.525562
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    b = a.coordinates()
    print(b)


if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-21 15:50:17.091057
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    assert address.country_code() in COUNTRY_CODES
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES
    assert address.country_code(CountryCode.NUMERIC) in COUNTRY_CODES
    assert address.country_code(CountryCode.UNM49) in COUNTRY_CODES


# Generated at 2022-06-21 15:50:20.071328
# Unit test for method longitude of class Address
def test_Address_longitude():
    provider = Address(locale='en')
    longitude = provider.longitude()
    assert '.' in str(longitude)
    assert (longitude >= -180) and (longitude <= 180)


# Generated at 2022-06-21 15:51:18.909482
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import Locale

    class TestAddress:
        """Unit test for Address."""

        @classmethod
        def setup_class(cls):
            """Set-up class."""
            cls.address = Address(Locale.RU)

        def test_province(self):
            """Test method province."""
            result = self.address.province()
            assert result in self.address._data['province'].values()

# Generated at 2022-06-21 15:51:21.631526
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    fake = Address()
    print(fake.postal_code())


if __name__ == '__main__':
    test_Address_postal_code()

# Generated at 2022-06-21 15:51:22.522687
# Unit test for method state of class Address
def test_Address_state():
    add = Address()
    print(add.state())
    print(add.state(True))


# Generated at 2022-06-21 15:51:24.520104
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address('en')
    code = address.country_code()
    assert code in COUNTRY_CODES['A2']


# Generated at 2022-06-21 15:51:28.211566
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert len(address.street_name()) > 0
    assert len(address.address()) > 0
    assert len(address.city()) > 0
    assert len(address.region()) > 0
    assert len(address.countryCode(CountryCode.A2)) > 0
    assert len(address.postal_code()) > 0

# Generated at 2022-06-21 15:51:32.814953
# Unit test for method country_code of class Address
def test_Address_country_code():
    adr = Address()

    assert adr.country_code() in ["KOR", "USA", "CAN"]
    assert adr.country_code(CountryCode.A2) in ["KOR", "USA", "CAN"]
    assert adr.country_code(CountryCode.A3) in ["KOR", "USA", "CAN"]
    assert adr.country_code(CountryCode.NUM) in ["KOR", "USA", "CAN"]

# Generated at 2022-06-21 15:51:33.523433
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    return 0


# Generated at 2022-06-21 15:51:39.786368
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.utils import get_locale
    from mimesis.enums import CountryCode

    for code in CountryCode:
        for loc in ('en', 'ru', 'ja'):
            results = []
            locale = get_locale(loc)
            address = Address(locale=locale)

            for item in range(100):
                res = address.country_code(fmt=code)
                if res not in results:
                    results.append(res)

            # Check that we've got different results
            assert len(results) > 0

# Generated at 2022-06-21 15:51:42.274016
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.data import REGIONS

    address = Address()
    region = address.region()
    assert region in REGIONS

# Generated at 2022-06-21 15:51:43.594875
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    print(address.country_code())


# Generated at 2022-06-21 15:53:46.022020
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    print(address.longitude(dms=True))



# Generated at 2022-06-21 15:53:51.090630
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.builtins.address import Address
    from mimesis.builtins.locales import AddressCode
    address = Address(AddressCode.DE)
    data = address.coordinates(dms=True)
    assert isinstance(data, dict)

# Generated at 2022-06-21 15:53:53.102367
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region()
    assert region.startswith('#') or \
        len(region) <= 2


# Generated at 2022-06-21 15:53:55.105881
# Unit test for constructor of class Address
def test_Address():
    adr = Address()
    assert isinstance(adr, Address)

# Unit tests for Address.address

# Generated at 2022-06-21 15:54:02.362723
# Unit test for constructor of class Address
def test_Address():
    class SubAddress(Address):
        class Meta:
            name = 'address'
    address = SubAddress()
    address.address()
    address.street_name()
    address.street_number()
    address.street_suffix()
    address.postal_code()
    address.zip_code()
    address.region()
    address.state()
    address.province()
    address.prefecture()
    address.federal_subject()
    address.country_code()
    address.country()
    address.city()
    address.latitude()
    address.longitude()
    address.coordinates()
    address.continent()
    address.calling_code()
    address.coordinates()

# Generated at 2022-06-21 15:54:03.049753
# Unit test for constructor of class Address
def test_Address():
    provider = Address()
    assert provider is not None


# Generated at 2022-06-21 15:54:04.505668
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street = address.street_name()
    assert street


# Generated at 2022-06-21 15:54:06.410714
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test value of method calling_code of class Address"""
    add = Address()
    assert add.calling_code() in CALLING_CODES


# Generated at 2022-06-21 15:54:08.513021
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address"""
    address = Address('en-US')
    assert(len(address.coordinates()) == 2)
    assert(len(address.coordinates(True)) == 2)

test_Address_coordinates()

# Generated at 2022-06-21 15:54:09.837778
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert address.prefecture() == "Otago"

