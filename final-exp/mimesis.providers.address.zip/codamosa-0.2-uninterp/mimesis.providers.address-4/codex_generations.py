

# Generated at 2022-06-17 22:05:19.969850
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:21.490523
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:22.692446
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:05:30.661538
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    adr = Address(Locale.EN)
    assert adr.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=adr.street_number(),
        st_name=adr.street_name(),
        st_sfx=adr.street_suffix(),
    )

    adr = Address(Locale.RU)

# Generated at 2022-06-17 22:05:31.871160
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:33.880118
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:35.643398
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:05:36.849747
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:38.926637
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:05:40.388899
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:49.760314
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:50.999582
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:53.513912
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:55.538841
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Street Name'

# Generated at 2022-06-17 22:05:57.599138
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:58.941492
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != None


# Generated at 2022-06-17 22:06:06.142534
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    address = Address('en')
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address()

# Generated at 2022-06-17 22:06:12.603765
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'


# Generated at 2022-06-17 22:06:13.905768
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:15.228262
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:24.693461
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:26.048315
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:06:27.413444
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:28.578776
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:06:30.255453
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:31.401599
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:32.880051
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:36.664445
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:06:46.681320
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
   

# Generated at 2022-06-17 22:06:47.987097
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:07:07.831638
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:09.926292
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-17 22:07:19.884153
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:07:29.631362
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address()

# Generated at 2022-06-17 22:07:31.183109
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:42.042242
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale en
    address = Address(locale='en')
    assert address.address() == '1234 Main St'
    # Test for locale ru
    address = Address(locale='ru')
    assert address.address() == 'Ул. Московская, д. 12'
    # Test for locale ja
    address = Address(locale='ja')
    assert address.address() == '東京都港区芝公園４丁目２−８'
    # Test for locale zh
    address = Address(locale='zh')
    assert address.address() == '上海市黄浦区南京东路'
    # Test for locale ar
    address

# Generated at 2022-06-17 22:07:48.013573
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'
    assert address.address() == '4th St'

# Generated at 2022-06-17 22:07:50.224204
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-17 22:07:52.325962
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:57.779453
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:08:43.919243
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1st Street'


# Generated at 2022-06-17 22:08:45.209990
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''

# Generated at 2022-06-17 22:08:48.100758
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

# Generated at 2022-06-17 22:09:01.104254
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.RU)
    assert address.address() == '{st_num} {st_name}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:09:09.582100
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    address = Address(Locale.EN)
    datetime = Datetime(Locale.EN)
    geo = Geo(Locale.EN)
    person = Person(Locale.EN)
    text = Text(Locale.EN)
    provider = Provider(Locale.EN)


# Generated at 2022-06-17 22:09:13.073589
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    assert a.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:09:14.140493
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:09:20.664003
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:09:22.281415
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:32.704257
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'