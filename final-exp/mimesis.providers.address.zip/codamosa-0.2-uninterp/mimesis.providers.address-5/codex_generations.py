

# Generated at 2022-06-17 22:05:23.085677
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_JA
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_ZH_CN
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_ZH_TW

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.RU)
    assert address.address() != ''

    address = Address(Locale.JA)
    assert address.address() != ''


# Generated at 2022-06-17 22:05:26.901453
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:05:28.073335
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:30.280245
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:31.945559
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:36.545535
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:05:38.029508
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()

# Generated at 2022-06-17 22:05:39.520211
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:40.659897
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:42.521859
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:48.477264
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:55.545870
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address()

# Generated at 2022-06-17 22:05:56.720702
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:58.417157
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:06:00.222498
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:06:02.041022
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:03.489754
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:04.731892
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)


# Generated at 2022-06-17 22:06:05.647960
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:06.894587
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:17.969750
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() != address.address()


# Generated at 2022-06-17 22:06:19.254489
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ""


# Generated at 2022-06-17 22:06:20.133966
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None

# Generated at 2022-06-17 22:06:21.336298
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:30.547506
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Provider

    class CustomAddress(Address):
        class Meta:
            name = 'address'

    class CustomPerson(Person):
        class Meta:
            name = 'person'

    class CustomProvider(Provider):
        class Meta:
            name = 'custom'

        address = CustomAddress
        person = CustomPerson

    custom = CustomProvider('ru')
    address = Address('ru')
    person = Person('ru')
    russia = RussiaSpecProvider('ru')


# Generated at 2022-06-17 22:06:38.428224
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.RU)
    assert address.address() != ''

    address = Address(Locale.JA)
    assert address.address() != ''

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.EN)

# Generated at 2022-06-17 22:06:40.436823
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:42.060906
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:45.562781
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    assert a.address() != a.address()


# Generated at 2022-06-17 22:06:46.896384
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:07:11.652141
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:07:13.628953
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:14.950695
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:15.839826
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:16.918328
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:17.958944
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:27.676851
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
   

# Generated at 2022-06-17 22:07:29.252765
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:30.702854
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:32.639254
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:08:12.839015
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:14.380091
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-17 22:08:15.641685
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:17.332200
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:18.500701
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:19.791482
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:20.938708
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:23.116238
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:08:32.894806
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'

# Generated at 2022-06-17 22:08:33.781294
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:05.624252
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:10:06.763903
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:07.866517
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:10:13.489209
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:10:15.202094
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:10:16.589912
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:10:17.824273
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:10:19.639586
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:10:20.940209
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:22.567820
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'
