

# Generated at 2022-06-17 22:05:20.906000
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'

# Generated at 2022-06-17 22:05:22.144566
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:28.259008
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'


# Generated at 2022-06-17 22:05:34.842801
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:05:36.534372
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Main St'


# Generated at 2022-06-17 22:05:38.533219
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:49.124535
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider
    from mimesis.providers.vehicle import Vehicle
    from mimesis.providers.web import Web
    from mimesis.providers.misc import Misc
    from mimesis.providers.science import Science
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.geography import Geography
    from mimesis.providers.internet import Internet


# Generated at 2022-06-17 22:05:50.340897
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:51.474944
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:53.438409
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:59.325630
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:06:09.276013
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.phone_number import PhoneNumber
    from mimesis.providers.text import Text

    address = Address()
    geography = Geography()
    person = Person()
    phone = PhoneNumber()
    text = Text()

    # Test for default locale
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    # Test for locale 'en'


# Generated at 2022-06-17 22:06:10.445895
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert addr.address() != ''


# Generated at 2022-06-17 22:06:11.666154
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:13.230527
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:14.918121
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)


# Generated at 2022-06-17 22:06:16.133291
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:24.511195
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:06:25.648710
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:06:27.031904
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:06:37.023556
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:39.107498
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:42.061146
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None
    assert isinstance(result, str)


# Generated at 2022-06-17 22:06:43.611594
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:46.531206
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:47.952255
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:48.945139
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:06:50.651158
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:06:52.641200
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:06:54.624524
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:15.807204
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:16.597869
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''

# Generated at 2022-06-17 22:07:17.634382
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:18.958163
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != ''


# Generated at 2022-06-17 22:07:28.649824
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
    assert address.address() == '1300 W. Main St.'
   

# Generated at 2022-06-17 22:07:30.245111
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:33.307493
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'

# Generated at 2022-06-17 22:07:34.017032
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:07:36.417863
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:37.798282
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:08:21.868187
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:23.226684
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:08:24.308715
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:08:25.396712
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:32.885765
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address

# Generated at 2022-06-17 22:08:34.146101
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:35.294498
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:37.308238
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:38.598575
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:39.945059
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:11:28.802242
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert address.address()

# Generated at 2022-06-17 22:11:29.889091
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:11:31.925237
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:11:33.343840
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:11:34.502781
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:11:35.680820
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:11:37.478649
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:11:38.766858
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:11:45.105093
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'

# Generated at 2022-06-17 22:11:46.916693
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''
