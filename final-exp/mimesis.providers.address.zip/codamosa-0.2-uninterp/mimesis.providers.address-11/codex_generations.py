

# Generated at 2022-06-17 22:05:23.789638
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:26.124037
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:30.603241
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:05:32.124841
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:37.176697
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'
    assert a.address() == '1234 Main St'


# Generated at 2022-06-17 22:05:38.761444
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:40.198992
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:41.724956
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:43.121020
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:44.475596
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:53.802625
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:54.952412
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:04.783052
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() != ''
    assert address.address() != ' '
    assert address.address() != '   '
    assert address.address() != '\n'
    assert address.address() != '\t'
    assert address.address() != '\r'
    assert address.address() != '\r\n'
    assert address.address() != '\n\r'
    assert address.address() != '\t\n'
    assert address.address() != '\t\r'
    assert address.address() != '\t\r\n'

# Generated at 2022-06-17 22:06:05.740340
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:14.005565
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.RU)
    assert address.address() == '{st_num} {st_name}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:06:15.303993
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:16.715547
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:18.283299
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '123 Main St'


# Generated at 2022-06-17 22:06:26.186054
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:06:34.230176
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
   

# Generated at 2022-06-17 22:06:50.334286
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:52.288031
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:54.246509
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:06:55.335665
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:57.316083
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:07:07.319490
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale en
    address = Address(locale='en')
    assert address.address() == '1400 W. Broadway'
    # Test for locale ru
    address = Address(locale='ru')
    assert address.address() == 'ул. Красная, д. 1, кв. 100'
    # Test for locale ja
    address = Address(locale='ja')
    assert address.address() == '東京都港区芝公園４丁目２−８'
    # Test for locale zh
    address = Address(locale='zh')

# Generated at 2022-06-17 22:07:10.249698
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:20.123303
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"
    assert address.address() == "123 Main St"

# Generated at 2022-06-17 22:07:23.377396
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:31.489131
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_JA

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.RU)
    assert address.address() != ''

    address = Address(Locale.JA)
    assert address.address() != ''

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:08:05.597213
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:11.268868
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    class TestAddress(Address):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.__text = Text(self.locale)
            self.__person = Person(self.locale)
            self.__datetime = Datetime(self.locale)

        def street_name(self):
            return self.__text.word()


# Generated at 2022-06-17 22:08:12.838376
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:13.743096
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'


# Generated at 2022-06-17 22:08:14.923451
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:24.828558
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:08:25.930055
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:35.377394
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
   

# Generated at 2022-06-17 22:08:37.434110
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:08:38.784918
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:09:19.350519
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:09:29.218471
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address() == '1346 Rue de la Paix'
    assert address.address()

# Generated at 2022-06-17 22:09:31.419068
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:09:32.815820
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
