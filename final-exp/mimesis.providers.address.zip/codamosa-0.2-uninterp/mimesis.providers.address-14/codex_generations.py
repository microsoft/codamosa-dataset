

# Generated at 2022-06-17 22:05:21.738190
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:22.947237
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:24.204608
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != None


# Generated at 2022-06-17 22:05:25.373220
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:32.811235
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:05:34.237800
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:35.989889
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:38.211441
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:39.680654
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:41.350815
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:53.903772
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.utils import ProviderType

    address = Address()
    person = Person()
    geo = Geography()

    # Test for method address of class Address
    assert address.address() != ''
    assert address.address() != ' '
    assert address.address() != '  '
    assert address.address() != '   '
    assert address.address() != '    '
    assert address.address() != '     '
    assert address.address() != '      '
    assert address.address() != '       '
    assert address.address() != '        '

# Generated at 2022-06-17 22:05:55.066668
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:04.655134
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:06:06.004622
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:14.207077
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address
    from mimesis.providers.address import Address as _Address

# Generated at 2022-06-17 22:06:23.145691
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:06:24.376958
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:26.090253
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:28.408989
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-17 22:06:29.644201
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:06:34.960297
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:36.069072
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:37.342796
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:06:47.114030
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address

# Generated at 2022-06-17 22:06:48.561686
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:50.656250
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:06:52.207505
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'


# Generated at 2022-06-17 22:06:54.103791
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:56.686168
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:57.779859
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:07:17.107157
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
    assert address.address() == '874 W. Wieck Street'
   

# Generated at 2022-06-17 22:07:26.789374
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address

# Generated at 2022-06-17 22:07:28.157117
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:07:39.670759
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address()

# Generated at 2022-06-17 22:07:47.493476
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:07:49.115178
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:49.873101
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:07:51.353932
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-17 22:07:53.188553
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:56.369394
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:08:14.692716
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:08:16.120122
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:17.669587
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:08:19.645067
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'

# Generated at 2022-06-17 22:08:21.452773
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:23.790820
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:08:25.190533
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:08:26.568472
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:32.884787
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:08:33.781080
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:21.442798
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:22.570063
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:24.484563
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:09:25.772593
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:27.072008
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:09:28.895196
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:29.829712
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:31.945029
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:09:33.840085
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:35.600432
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:11:49.612388
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:11:52.136206
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:11:54.245116
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:11:55.155001
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:11:57.166754
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:11:59.306760
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:01.675919
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:02.847441
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:12:09.251298
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'
    assert address.address() == '9078 W. Eastwood Ave.'

# Generated at 2022-06-17 22:12:12.800581
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() != ''
    assert address.address() != address.address()


# Generated at 2022-06-17 22:14:58.129345
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:15:07.954770
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'
    assert address.address() == '1 rue de la République'

# Generated at 2022-06-17 22:15:08.998088
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:15:09.939099
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:15:11.429999
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:15:12.394812
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:15:13.526943
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:15:15.027845
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:15:15.818689
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''
