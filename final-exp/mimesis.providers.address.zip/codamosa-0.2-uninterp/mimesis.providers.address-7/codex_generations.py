

# Generated at 2022-06-17 22:05:21.817779
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:23.032325
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:24.289222
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:26.124641
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:05:27.292372
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:30.729729
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-17 22:05:31.907173
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:33.358437
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-17 22:05:36.928694
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    result = address.address()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-17 22:05:37.642607
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:44.868898
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:53.840939
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.geo import Geo

    a = Address(locale=Locale.RU)
    assert a.address() == 'Москва, ул. Старокачаловская, д. 1'

    a = Address(locale=Locale.EN)
    assert a.address() == '1 North Ave, New York, NY 10018'

    a = Address(locale=Locale.JA)
    assert a.address() == '東京都千代田区丸の内1-1-1'


# Generated at 2022-06-17 22:05:55.287297
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:56.407277
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:57.656336
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:07.801294
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit
    from mimesis.providers.utils import Utils
    from mimesis.providers.web import Web

# Generated at 2022-06-17 22:06:09.854386
# Unit test for method address of class Address
def test_Address_address():
    # Create a instance of Address
    address = Address()
    # Generate a random full address
    result = address.address()
    # Check that result is not empty
    assert result != ''


# Generated at 2022-06-17 22:06:17.099172
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a

# Generated at 2022-06-17 22:06:21.046109
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

# Generated at 2022-06-17 22:06:30.218741
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.file import File
    from mimesis.providers.code import Code
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.identifier import Identifier

# Generated at 2022-06-17 22:06:38.075863
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:39.837662
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:06:41.397296
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:43.023198
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:45.255106
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:46.674803
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:48.102741
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:56.843144
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address() == '1 rue de la Paix'
    assert address.address()

# Generated at 2022-06-17 22:06:58.512411
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:59.700863
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:15.606288
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:07:16.664984
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:17.739720
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:19.113618
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:07:20.337865
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:21.505132
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:23.771958
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:25.028631
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:26.287530
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:27.510161
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:05.210065
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'

# Generated at 2022-06-17 22:08:06.272588
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:08:07.308345
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:11.157231
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime

    a = Address(Locale.EN)
    d = Datetime(Locale.EN)
    b = BaseProvider(Locale.EN)

    assert a.address() != ''
    assert a.address() != a.address()
    assert a.address() != d.date()
    assert a.address() != b.text()



# Generated at 2022-06-17 22:08:12.394485
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:13.109368
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:23.188813
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:08:26.865224
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:08:27.597227
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:08:37.382546
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:09:56.055948
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:58.147135
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:59.779721
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:01.078993
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:10:03.042562
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:10.668865
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'

# Generated at 2022-06-17 22:10:21.150884
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address(Locale.EN)
    person = Person(Locale.EN)
    geo = Geo(Locale.EN)
    text = Text(Locale.EN)
    datetime = Datetime(Locale.EN)

    assert isinstance(address.address(), str)

# Generated at 2022-06-17 22:10:22.748378
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:10:25.059181
# Unit test for method address of class Address
def test_Address_address():
    # Test for method address of class Address
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:10:26.615386
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None
