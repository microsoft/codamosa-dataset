

# Generated at 2022-06-17 22:05:20.686489
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:21.900269
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:23.451417
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:05:24.688283
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:32.284917
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address()

    address = Address(Locale.RU)
    assert address.address()

    address = Address(Locale.JA)
    assert address.address()

    address = Address(Locale.DE)
    assert address.address()

    address = Address(Locale.ES)
    assert address.address()

    address = Address(Locale.FR)
    assert address.address()

    address = Address(Locale.IT)
    assert address.address()

    address = Address(Locale.PT)
    assert address.address()


# Generated at 2022-06-17 22:05:42.539433
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:05:43.601515
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:44.954258
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:53.901851
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    class TestAddress(Address):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.datetime = Datetime(self.locale)
            self.person = Person(self.locale)
            self.text = Text(self.locale)

        def address(self):
            return self.text.text(max_symbols=20)


# Generated at 2022-06-17 22:05:55.436066
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None
    assert address.address() != ''


# Generated at 2022-06-17 22:06:00.321202
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:02.585287
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:04.392499
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:05.306281
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != a.address()


# Generated at 2022-06-17 22:06:06.249807
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:07.661224
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:06:08.919235
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:10.401748
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:06:11.625989
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:13.185520
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:21.884942
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:30.996418
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() != ''

    address = Address(Locale.RU)
    assert address.address() != ''

    address = Address(Locale.JA)
    assert address.address() != ''

    address = Address(Locale.FR)
    assert address.address() != ''

    address = Address(Locale.DE)
    assert address.address() != ''

    address = Address(Locale.ES)
    assert address.address() != ''

    address = Address(Locale.PT)
    assert address.address() != ''

    address = Address(Locale.IT)

# Generated at 2022-06-17 22:06:33.992264
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:06:35.209558
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:37.021243
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:40.864625
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-17 22:06:42.504596
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:44.027073
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:46.049618
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:47.829526
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:11.437001
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:07:20.927979
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address(Locale.EN)
    base = BaseProvider(Locale.EN)
    datetime = Datetime(Locale.EN)
    geo = Geo(Locale.EN)
    internet = Internet(Locale.EN)
    person = Person(Locale.EN)
    text = Text(Locale.EN)

# Generated at 2022-06-17 22:07:22.212279
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:31.285915
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'

# Generated at 2022-06-17 22:07:32.962228
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:07:43.314614
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'

# Generated at 2022-06-17 22:07:48.854430
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.payment import Payment
    from mimesis.providers.business import Business
    from mimesis.providers.file import File
    from mimesis.providers.misc import Misc
    from mimesis.providers.structures import Structures
    from mimesis.providers.science import Science

# Generated at 2022-06-17 22:07:58.048924
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    class CustomProvider(BaseProvider):
        """Custom provider."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self.address = Address(self.locale)
            self.datetime = Datetime(self.locale)

# Generated at 2022-06-17 22:08:06.935133
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:08:07.725208
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:27.729622
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:08:32.884971
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:08:34.070866
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:35.845333
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:08:45.866569
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address()

    address = Address(Locale.RU)
    assert address.address()

    address = Address(Locale.JA)
    assert address.address()

    address = Address(Locale.EN)
    assert address.address()

    address = Address(Locale.EN)
    assert address.address()

    address = Address(Locale.EN)
    assert address.address()

    address = Address(Locale.EN)
    assert address.address()

    address = Address(Locale.EN)
    assert address.address()


# Generated at 2022-06-17 22:08:47.988370
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None

# Generated at 2022-06-17 22:08:48.951703
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:49.851306
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:53.051346
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:03.075350
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.utils import get_locale

    locale = get_locale(Locale.EN)
    address = Address(locale)
    assert isinstance(address, BaseProvider)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)

# Generated at 2022-06-17 22:09:46.355601
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:09:47.427539
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:52.709721
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    p.seed(1)
    p.gender = Gender.MALE
    p.add_provider(RussiaSpecProvider)

    a = Address('ru')
    a.seed(1)
    assert a.address() == 'г. Калининград, ул. Советская, д. 13'

    a.seed(2)
    assert a.address() == 'г. Калининград, ул. Красная, д. 6'

    a.seed(3)
   

# Generated at 2022-06-17 22:10:03.624910
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:10:11.126216
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_JA

    a = Address(Locale.EN)
    assert a.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=a.street_number(),
        st_name=a.street_name(),
        st_sfx=a.street_suffix(),
    )

    a = Address(Locale.RU)

# Generated at 2022-06-17 22:10:14.751698
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:10:16.246445
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-17 22:10:17.642018
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:26.966347
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:10:28.105056
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:02.151110
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:12:08.913709
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'

# Generated at 2022-06-17 22:12:10.476208
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:12:19.664720
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
   

# Generated at 2022-06-17 22:12:21.890169
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    a = Address(Locale.EN)
    assert a.address() != a.address()


# Generated at 2022-06-17 22:12:23.309244
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:12:24.459483
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:25.564590
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:27.257100
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ""


# Generated at 2022-06-17 22:12:34.858880
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale en
    address = Address(locale='en')
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    # Test for locale ru
    address = Address(locale='ru')
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    # Test for locale ja
    address = Address(locale='ja')