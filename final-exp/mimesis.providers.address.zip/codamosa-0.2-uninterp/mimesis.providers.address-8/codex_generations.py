

# Generated at 2022-06-17 22:05:23.113819
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'

# Generated at 2022-06-17 22:05:24.010357
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:25.217984
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:26.379744
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:27.517110
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:28.331584
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:05:30.885637
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:32.054407
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:05:38.397554
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'
    assert address.address() == '1234 Fake St.'

# Generated at 2022-06-17 22:05:39.723826
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:05:48.954471
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:52.292465
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

# Generated at 2022-06-17 22:05:54.231115
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:56.872475
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:58.914324
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:03.913292
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:06:12.589971
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
   

# Generated at 2022-06-17 22:06:13.904713
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:06:21.737890
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'
    assert a.address() == '1 Rue de la Paix'


# Generated at 2022-06-17 22:06:22.881790
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:41.397621
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:42.980799
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:45.205128
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:54.664630
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.person import Person
    from mimesis.providers.utils import ProviderType

    address = Address(locale=Locale.EN)
    person = Person(locale=Locale.EN)
    assert isinstance(address, Address)
    assert isinstance(address, BaseDataProvider)
    assert isinstance(address, ProviderType)
    assert isinstance(person, Person)
    assert isinstance(person, BaseDataProvider)
    assert isinstance(person, ProviderType)
    assert isinstance(address.address(), str)
    assert isinstance(address.street_number(), str)

# Generated at 2022-06-17 22:06:57.177724
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:59.543427
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:00.689392
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:07:02.010261
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:04.142621
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:05.711600
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Fake St'


# Generated at 2022-06-17 22:07:43.822730
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:50.086263
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    class TestAddress(Address):
        """Test class for Address."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self.datetime = Datetime(self.locale)

# Generated at 2022-06-17 22:07:58.436583
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
   

# Generated at 2022-06-17 22:08:00.359567
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-17 22:08:08.263385
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.utils import ProviderType

    # Create a new instance of Address
    address = Address()
    # Create a new instance of Person
    person = Person()
    # Create a new instance of Geography
    geography = Geography()

    # Get a random full address
    address.address()

    # Get a random street number
    address.street_number()

    # Get a random street name
    address.street_name()

    # Get a random street suffix
    address.street_suffix()

    # Get a random administrative district of country
    address.state()

    # Get a random administrative

# Generated at 2022-06-17 22:08:09.890255
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == 'Малая Серпуховская улица, дом 1'

# Generated at 2022-06-17 22:08:11.455565
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:13.327324
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:23.382434
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '541-9084 中央区'
    assert address.address() == '541-9084 中央区'
    assert address.address() == '541-9084 中央区'
    assert address.address() == '541-9084 中央区'
    assert address.address() == '541-9084 中央区'
    assert address.address() == '541-9084 中央区'
    assert address.address() == '541-9084 中央区'
    assert address.address() == '541-9084 中央区'

# Generated at 2022-06-17 22:08:32.886120
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Provider

    provider = Provider(Address(Locale.EN))
    assert isinstance(provider, BaseProvider)
    assert isinstance(provider, Person)
    assert isinstance(provider, Address)

    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider.address()
    assert provider

# Generated at 2022-06-17 22:09:24.806674
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:09:35.776360
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider

    address = Address(locale=Locale.RU)
    assert address.address() == 'Красная улица, дом 1'

    address = Address(locale=Locale.EN)
    assert address.address() == '1 Red Street'

    address = Address(locale=Locale.JA)
    assert address.address() == '東京都中央区日本橋'

    address = Address(locale=Locale.RU)
    assert address.address() == 'Красная улица, дом 1'


# Generated at 2022-06-17 22:09:43.437079
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
    assert address.address() == "1 Rue de la Paix"
   

# Generated at 2022-06-17 22:09:44.271746
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:09:51.584184
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider

    address = Address(Locale.EN)
    assert isinstance(address, BaseDataProvider)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance

# Generated at 2022-06-17 22:09:53.750411
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:10:03.932461
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:10:10.437621
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address() == '1030 W. Addison St.'
    assert address.address()

# Generated at 2022-06-17 22:10:12.937100
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:22.182032
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    from mimesis.enums import CountryCode

    address = Address('en')
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

    address = Address('ru')
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

    address = Address('ja')
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

    address = Address('zh')
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
