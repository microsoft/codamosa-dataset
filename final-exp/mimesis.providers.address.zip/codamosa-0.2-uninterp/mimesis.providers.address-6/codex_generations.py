

# Generated at 2022-06-17 22:05:23.622972
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:05:27.098952
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

# Generated at 2022-06-17 22:05:28.848951
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)
    assert address.address() != ''


# Generated at 2022-06-17 22:05:30.838665
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:32.017745
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:33.469276
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:38.594360
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_JA

    address = Address(locale=Locale.EN)
    address_ja = Address(locale=Locale.JA)
    address_ru = Address(locale=Locale.RU)
    address_zh = Address(locale=Locale.ZH)

    assert address.address() != ''
    assert address_ja.address() != ''
    assert address_ru.address() != ''
    assert address_zh.address() != ''

    assert address.address() in SHORTENED_ADDRESS_FMT
   

# Generated at 2022-06-17 22:05:39.912643
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:41.544739
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:42.936825
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:05:50.589705
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address('en')
    assert address.address() == '1400 W. Campbell Ave.'


# Generated at 2022-06-17 22:05:59.414763
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'
    assert address.address() == '123 Fake St'

# Generated at 2022-06-17 22:06:01.216740
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:03.020255
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:06:04.730502
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:11.482900
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale en
    address = Address(locale='en')
    assert address.address() in [
        '{st_num} {st_name} {st_sfx}'.format(
            st_num=address.street_number(),
            st_name=address.street_name(),
            st_sfx=address.street_suffix(),
        ),
        '{st_num} {st_name}'.format(
            st_num=address.street_number(),
            st_name=address.street_name(),
        ),
    ]
    # Test for locale ru
    address = Address(locale='ru')

# Generated at 2022-06-17 22:06:13.414705
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:06:14.734606
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:15.974200
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:17.368254
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:29.607409
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:30.800210
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:31.967844
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:34.035767
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:06:35.244494
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:36.706086
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:38.756428
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:47.955427
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.RU)
    assert address.address() == '{st_num} {st_name}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:06:50.139744
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:06:52.148532
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:07:17.804904
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:19.743828
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-17 22:07:20.982842
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:30.483203
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.phone import Phone
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    # Create a provider
    provider = Provider(
        locale=Locale.EN,
        providers=[
            Address,
            BaseProvider,
            Datetime,
            Person,
            Phone,
            Text,
        ],
    )

    # Create a Address provider
    address = Address(locale=Locale.EN)

    # Get a random address
    address.address()

    #

# Generated at 2022-06-17 22:07:32.403359
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:34.753683
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:35.500794
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:07:42.376105
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:07:44.195427
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:07:45.101942
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-17 22:09:00.126840
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.utils import ProviderType

    address = Address('en')
    person = Person('en')
    geo = Geography('en')

    assert address.address() == '{} {} {}'.format(
        address.street_number(),
        address.street_name(),
        address.street_suffix(),
    )

    assert address.address() != '{} {} {}'.format(
        address.street_number(),
        address.street_name(),
        address.street_suffix(),
    )


# Generated at 2022-06-17 22:09:02.079437
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:03.266260
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:09:10.936829
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import _dd_to_dms
    from mimesis.providers.address import _get_fs
    from mimesis.providers.address import _validate_enum
    from mimesis.providers.address import calling_code
    from mimesis.providers.address import city
    from mimesis.providers.address import coordinates
    from mimesis.providers.address import country
    from mimesis.providers.address import country_code
    from mimesis.providers.address import continent
    from mimesis.providers.address import latitude

# Generated at 2022-06-17 22:09:12.186118
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:13.529303
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:15.022005
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ""


# Generated at 2022-06-17 22:09:16.648364
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:09:17.774123
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:27.592412
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
   

# Generated at 2022-06-17 22:10:25.141241
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:33.849474
# Unit test for method address of class Address
def test_Address_address():
    # Test for English locale
    address = Address(locale='en')
    assert address.address() == '1400 W. North Ave.'
    # Test for Russian locale
    address = Address(locale='ru')
    assert address.address() == 'г. Москва, ул. Академика Королева, д. 12, кв. 34'
    # Test for Japanese locale
    address = Address(locale='ja')
    assert address.address() == '東京都港区芝公園４丁目２−８'
    # Test for Chinese locale
    address = Address(locale='zh')

# Generated at 2022-06-17 22:10:34.861510
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:44.489187
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.RU)
    assert address.address() == '{st_num} {st_name}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:10:52.840844
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:10:54.839511
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:57.747260
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:59.493094
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:11:01.141018
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'

# Generated at 2022-06-17 22:11:10.787095
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
   

# Generated at 2022-06-17 22:13:19.396214
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:28.376156
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:13:29.365826
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:13:31.205153
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:32.397241
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:33.328790
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:35.229072
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:13:36.337782
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:39.338703
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:40.743576
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
