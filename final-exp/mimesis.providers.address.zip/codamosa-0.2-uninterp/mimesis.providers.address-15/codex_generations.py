

# Generated at 2022-06-17 22:05:13.800637
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:20.150245
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider

    class Provider(BaseProvider):
        address = Address(Locale.EN)

    p = Provider()
    assert p.address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=p.address.street_number(),
        st_name=p.address.street_name(),
        st_sfx=p.address.street_suffix(),
    )


# Generated at 2022-06-17 22:05:28.528048
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a

# Generated at 2022-06-17 22:05:30.596226
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:32.197606
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:42.509453
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:05:52.188826
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider

    a = Address(Locale.EN)
    b = Address(Locale.RU)
    c = Address(Locale.JA)

    assert isinstance(a, BaseProvider)
    assert isinstance(a, Address)

    assert a.address() != b.address()
    assert a.address() != c.address()
    assert b.address() != c.address()

    assert a.address() != a.address()
    assert b.address() != b.address()
    assert c.address() != c.address()

    assert a.address() != a.address()
    assert b.address() != b.address()

# Generated at 2022-06-17 22:05:54.157629
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:59.134935
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:06:02.139781
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address()


# Generated at 2022-06-17 22:06:06.026596
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:07.206457
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:08.526467
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:16.253896
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    address = Address(Locale.EN)
    assert isinstance(address, Provider)
    assert isinstance(address, BaseProvider)
    assert address.address() == '1400 W. Main St.'
    assert address.address() == '1400 W. Main St.'
    assert address.address() == '1400 W. Main St.'
    assert address.address() == '1400 W. Main St.'

# Generated at 2022-06-17 22:06:24.506770
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:06:25.919905
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:34.066539
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
   

# Generated at 2022-06-17 22:06:40.971853
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit
    from mimesis.providers.utils import Provider
    from mimesis.providers.business import Business

# Generated at 2022-06-17 22:06:42.984718
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:06:45.204722
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:06:50.409269
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:52.357676
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:58.862098
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:07:00.011473
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:01.338943
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:03.295900
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:05.053242
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:06.235802
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:07.594314
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:09.720006
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:26.161188
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:07:27.040302
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:07:28.690195
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:31.254525
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.address() != None


# Generated at 2022-06-17 22:07:32.828838
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:35.207917
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:36.994125
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:07:38.816292
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:46.911848
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:07:56.715915
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    address = Address(Locale.EN)
    assert isinstance(address, Address)
    assert isinstance(address, BaseProvider)

# Generated at 2022-06-17 22:08:12.358899
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:13.831550
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:14.999704
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:17.132057
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:18.340182
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:08:19.645226
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:22.756528
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert address.address() != address.address()


# Generated at 2022-06-17 22:08:25.049891
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() == '1234 Main St'


# Generated at 2022-06-17 22:08:25.881889
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St.'


# Generated at 2022-06-17 22:08:26.898371
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:09:12.186589
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:09:13.467300
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:14.536856
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:16.271066
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:09:17.623130
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:19.378698
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:09:21.134041
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:31.375963
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:09:32.741505
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:36.565130
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:10:46.743139
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:10:48.260628
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:50.082872
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:10:52.080764
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:10:54.804075
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St.'


# Generated at 2022-06-17 22:11:03.655732
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'
    assert address.address() == '1234 Main Street'

# Generated at 2022-06-17 22:11:05.591246
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:11:06.686333
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:11:07.917245
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:11:16.463251
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:13:45.199265
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:13:46.378746
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:51.426672
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import CONTINENT_CODES
    from mimesis.providers.address import COUNTRY_CODES
    from mimesis.providers.address import CALLING_CODES
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address

# Generated at 2022-06-17 22:13:53.864611
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:13:56.712079
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:13:58.652320
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:14:00.637905
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:14:01.738669
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:14:02.734890
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:14:04.948324
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''
