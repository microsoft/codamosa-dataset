

# Generated at 2022-06-17 22:05:14.901384
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:16.484165
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:05:17.640715
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:24.370690
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'
    assert address.address() == '1234 Main St'

# Generated at 2022-06-17 22:05:26.204452
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:36.673672
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:05:47.128621
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:05:49.122152
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:55.893701
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person
    from mimesis.providers.structures import Address as AddressStructure
    from mimesis.providers.utils import ProviderType

    a = Address()
    g = Geo()
    p = Person()
    s = AddressStructure()

    assert a.address()
    assert a.address(locale='ru')
    assert a.address(locale='en')
    assert a.address(locale='ja')
    assert a.address(locale='zh')
    assert a.address(locale='de')
    assert a.address(locale='es')

# Generated at 2022-06-17 22:06:00.455325
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:06:12.170854
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.RU)
    assert address.address() == '{st_num} {st_name}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:06:13.506501
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:17.692815
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:06:19.003800
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:26.757898
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:06:28.331219
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:29.561386
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:30.760256
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:35.083110
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:06:36.459383
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:48.218896
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:49.613843
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:52.497257
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:06:54.493327
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:07:02.450717
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Provider

    address = Address('en')
    person = Person('en')
    geo = Geography('en')

    assert address.address() == '{} {} {}'.format(
        address.street_number(),
        address.street_name(),
        address.street_suffix(),
    )

    assert address.address() == '{} {} {}'.format(
        address.street_number(),
        address.street_name(),
        address.street_suffix(),
    )


# Generated at 2022-06-17 22:07:04.374634
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:07:11.338341
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit
    from mimesis.providers.business import Business
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.file import File

# Generated at 2022-06-17 22:07:20.868865
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.phone_number import PhoneNumber
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    # Create a new instance of Address
    address = Address('en')
    # Create a new instance of Geography
    geography = Geography('en')
    # Create a new instance of Person
    person = Person('en')
    # Create a new instance of PhoneNumber
    phone_number = PhoneNumber('en')
    # Create a new instance of Text
    text = Text('en')

    # Create a new instance of Provider
    provider = Provider

# Generated at 2022-06-17 22:07:22.056011
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:24.942984
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-17 22:07:45.404777
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'

# Generated at 2022-06-17 22:07:55.201246
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
   

# Generated at 2022-06-17 22:07:55.952262
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:07:57.920244
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:06.794270
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address

# Generated at 2022-06-17 22:08:07.808652
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:08.931897
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:08:09.760772
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:11.709887
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:08:13.203070
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:49.281851
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:01.941811
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    # Create a new instance of Address
    address = Address(Locale.EN)

    # Check that the class is inherited from BaseProvider
    assert issubclass(Address, BaseProvider)
    # Check that the class is inherited from Provider
    assert issubclass(Address, Provider)

    # Check that the instance is an instance of Address
    assert isinstance(address, Address)
    # Check

# Generated at 2022-06-17 22:09:03.659718
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:05.114410
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:09:06.167681
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:07.249999
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:09:14.327044
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.utils import get_locale

    a = Address(get_locale(Locale.EN))
    assert isinstance(a, Address)
    assert isinstance(a, BaseProvider)
    assert isinstance(a.address(), str)
    assert isinstance(a.address(locale=Locale.RU), str)
    assert isinstance(a.address(locale=Locale.JA), str)
    assert isinstance(a.address(locale=Locale.ZH_CN), str)
    assert isinstance(a.address(locale=Locale.ZH_TW), str)

# Generated at 2022-06-17 22:09:19.876650
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:09:22.208516
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:23.648352
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:21.011428
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:10:22.048819
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:10:31.235700
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale 'en'
    address = Address(locale='en')
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    # Test for locale 'ru'
    address = Address(locale='ru')
    assert address.address() == '{st_num} {st_name}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
    )

    # Test for locale 'ja'
    address = Address(locale='ja')

# Generated at 2022-06-17 22:10:39.086181
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import CONTINENT_CODES
    from mimesis.providers.address import COUNTRY_CODES
    from mimesis.providers.address import CALLING_CODES
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import CONTINENT_CODES
    from mimesis.providers.address import COUNTRY_CODES
    from mimesis.providers.address import CALLING_CODES
    from mimesis.providers.address import SHORTENED_ADDRESS_

# Generated at 2022-06-17 22:10:41.482336
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:42.713489
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:10:44.191286
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:10:45.382356
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:47.015528
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:50.947169
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

# Generated at 2022-06-17 22:13:02.461138
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:03.686264
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Main St'


# Generated at 2022-06-17 22:13:04.677624
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:13:14.364681
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Provider

    address = Address('en')
    person = Person('en')
    geography = Geography('en')
    provider = Provider('en')

    assert address.address() == '{} {}'.format(
        address.street_number(),
        address.street_name(),
    )

    assert address.address() == '{} {}'.format(
        address.street_number(),
        address.street_name(),
    )


# Generated at 2022-06-17 22:13:15.969892
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:13:17.816653
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:13:19.145837
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Main St.'


# Generated at 2022-06-17 22:13:20.168591
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:13:22.277054
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)
    assert len(address.address()) > 0


# Generated at 2022-06-17 22:13:31.460064
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address