

# Generated at 2022-06-17 22:05:27.161510
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:05:28.246035
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Main St'


# Generated at 2022-06-17 22:05:30.347688
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:31.394757
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != None


# Generated at 2022-06-17 22:05:33.414827
# Unit test for method address of class Address
def test_Address_address():
    # Create a instance of Address
    address = Address()
    # Generate a random full address
    result = address.address()
    # Check if result is a string
    assert isinstance(result, str)


# Generated at 2022-06-17 22:05:35.648069
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:38.694901
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:05:40.573920
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:41.999846
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:43.355952
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:05:57.145516
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Main St'


# Generated at 2022-06-17 22:05:58.416197
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:59.838321
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:09.718862
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.RU)

# Generated at 2022-06-17 22:06:17.017550
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() is not None
    assert address.address() != ''
    assert address.address() != ' '
    assert address.address() != '  '
    assert address.address() != '   '
    assert address.address() != '    '
    assert address.address() != '     '
    assert address.address() != '      '
    assert address.address() != '       '
    assert address.address() != '        '
    assert address.address() != '         '
    assert address.address() != '          '
    assert address.address() != '           '
    assert address.address() != '            '


# Generated at 2022-06-17 22:06:18.286434
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:26.191685
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
   

# Generated at 2022-06-17 22:06:27.529043
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:29.062421
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:30.282967
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:46.049568
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:47.148799
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:48.609165
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:49.947827
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:52.079314
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != a.address()


# Generated at 2022-06-17 22:06:54.033697
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:56.035692
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:59.138426
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address.

    :return: None
    """
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:01.080438
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:07:09.819504
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_JA
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_RU
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_UK
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_ZH_CN
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT_ZH_TW
    from mimesis.providers.address import SHORTENED_ADDRESS

# Generated at 2022-06-17 22:07:24.430067
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:25.674264
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-17 22:07:32.888439
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:07:35.252220
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:07:37.429657
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:41.343132
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

# Generated at 2022-06-17 22:07:42.915623
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1st Street'


# Generated at 2022-06-17 22:07:44.081666
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:50.237367
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
    address.address()
   

# Generated at 2022-06-17 22:07:51.708315
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:22.445457
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:08:25.083473
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import RussiaSpecProvider

    address = Address(RussiaSpecProvider)
    assert address.address() == 'Москва, Ул. Ленина, д. 1'

# Generated at 2022-06-17 22:08:26.185407
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:27.665720
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:32.888683
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:37.786250
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:08:39.258771
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:40.597007
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-17 22:08:42.575475
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:08:43.681257
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
