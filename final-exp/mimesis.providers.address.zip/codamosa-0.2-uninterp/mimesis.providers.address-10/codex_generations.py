

# Generated at 2022-06-17 22:05:26.321337
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() is not None
    assert address.address() != ''


# Generated at 2022-06-17 22:05:30.073107
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:37.359831
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'
    assert address.address() == '1st Street'

# Generated at 2022-06-17 22:05:47.558379
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address

# Generated at 2022-06-17 22:05:49.546412
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:51.363400
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:05:54.231234
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1, Rue des Chartreux'


# Generated at 2022-06-17 22:06:03.914674
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
   

# Generated at 2022-06-17 22:06:04.830940
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:06.189682
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:19.254696
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:21.126816
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:06:22.275995
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-17 22:06:23.510187
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:25.156593
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:06:26.891528
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() is not None

# Generated at 2022-06-17 22:06:28.139761
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:29.720580
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:37.881385
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:06:47.388565
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

# Generated at 2022-06-17 22:07:16.193136
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:17.187656
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:07:18.546768
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:19.639205
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:20.842964
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:23.771818
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'


# Generated at 2022-06-17 22:07:25.028507
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:07:32.508686
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:07:34.854886
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:44.120522
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'
    assert address.address() == '1 Rue des Lilas'