

# Generated at 2022-06-17 22:05:14.781481
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:16.636182
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:17.790267
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:19.688595
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:20.842965
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:22.064056
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:23.285870
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:24.528337
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:05:32.157231
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import CONTINENT_CODES
    from mimesis.providers.address import COUNTRY_CODES
    from mimesis.providers.address import CALLING_CODES
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT
    from mimesis.providers.address import CONTINENT_CODES
    from mimesis.providers.address import COUNTRY_CODES
    from mimesis.providers.address import CALLING_CODES
    from mimesis.providers.address import SHORTENED_ADDRESS_

# Generated at 2022-06-17 22:05:34.157261
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:05:41.957142
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:43.371892
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:44.732218
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:05:53.749867
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider

    class TestAddress(Address):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.locale = Locale.EN
            self.seed(0)

    address = TestAddress()
    assert address.address() == '1400 W. Campbell Ave.'
    assert address.address() == '1400 W. Campbell Ave.'
    assert address.address() == '1400 W. Campbell Ave.'
    assert address.address() == '1400 W. Campbell Ave.'
    assert address.address() == '1400 W. Campbell Ave.'
    assert address.address() == '1400 W. Campbell Ave.'


# Generated at 2022-06-17 22:05:55.212521
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:05:59.577955
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() is not None


# Generated at 2022-06-17 22:06:00.975756
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:02.826990
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:06:04.586574
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ""


# Generated at 2022-06-17 22:06:05.957074
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:21.166312
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()

# Generated at 2022-06-17 22:06:22.351788
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:23.215065
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:06:24.464228
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:25.613190
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:26.939737
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:06:28.452568
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:06:29.722098
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:30.930677
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:38.655701
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
    assert a.address() == '1400 W. North Ave.'
   

# Generated at 2022-06-17 22:07:21.132478
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'
    assert address.address() == '1234 W. Street'

# Generated at 2022-06-17 22:07:23.377438
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:31.488927
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    address = Address(Locale.EN)
    assert isinstance(address, Address)
    assert isinstance(address, BaseDataProvider)

# Generated at 2022-06-17 22:07:42.122519
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address

# Generated at 2022-06-17 22:07:49.041669
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    address = Address(Locale.RU)
    assert address.address() == '{st_num} {st_name}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
    )

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:07:51.258061
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:53.551266
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:08:03.537624
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:08:08.652122
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'

# Generated at 2022-06-17 22:08:10.257354
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:09:32.432303
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address()

# Generated at 2022-06-17 22:09:35.394422
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:37.110442
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:09:38.322722
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-17 22:09:49.223935
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'

# Generated at 2022-06-17 22:09:51.706980
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:09:53.924212
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:09:57.047440
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:58.817910
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:10:08.084881
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.EN)
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address.address() == '1400 W. North Ave.'
    assert address