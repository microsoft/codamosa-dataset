

# Generated at 2022-06-17 22:05:20.416796
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:21.653175
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:24.249458
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:05:25.415694
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:05:26.901012
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:05:31.102272
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:32.275193
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:34.087222
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:05:38.968743
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

# Generated at 2022-06-17 22:05:49.505631
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.utils import Provider

    class TestAddress(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.address = Address(self.locale)
            self.datetime = Datetime(self.locale)
            self.internet = Internet(self.locale)
            self.person = Person(self.locale)


# Generated at 2022-06-17 22:05:58.643234
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:06:00.081271
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:01.522564
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:04.913224
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    print(a.address())


# Generated at 2022-06-17 22:06:05.836949
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:07.585996
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:15.480800
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    a = Address('en')
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address() == '1400 W. Campbell Ave.'
    assert a.address()

# Generated at 2022-06-17 22:06:16.921231
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:18.197526
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-17 22:06:19.420503
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:38.496227
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:40.479919
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:06:42.898124
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:45.908762
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-17 22:06:55.226097
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale en
    address = Address(locale='en')
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )

    # Test for locale ja
    address = Address(locale='ja')
    assert address.address() == '{city} {st_num}-{st_num}-{st_num}'.format(
        city=address.random.choice(address._data['city']),
        st_num=address.street_number(),
    )

    # Test for locale ru
    address = Address(locale='ru')

# Generated at 2022-06-17 22:06:56.360764
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:58.861865
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'


# Generated at 2022-06-17 22:07:00.009324
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:01.338694
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:03.294467
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:40.924332
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St.'


# Generated at 2022-06-17 22:07:42.209264
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:07:43.394155
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-17 22:07:44.293246
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:45.648431
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1400 Fake Street'


# Generated at 2022-06-17 22:07:46.738572
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:48.302407
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-17 22:07:57.646439
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'
    assert address.address() == '1234 Fake St'

# Generated at 2022-06-17 22:07:58.676227
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:08:04.674832
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.phone_number import PhoneNumber
    from mimesis.providers.text import Text

    address = Address()
    geography = Geography()
    person = Person()
    phone = PhoneNumber()
    text = Text()

    assert address.address() != ''
    assert address.address() != address.address()
    assert address.address() != address.address()
    assert address.address() != address.address()
    assert address.address() != address.address()
    assert address.address() != address.address()
    assert address.address() != address.address()