

# Generated at 2022-06-17 22:05:24.041565
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:05:25.846815
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:33.200118
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'
    assert Address().address() == '123 Main St.'

# Generated at 2022-06-17 22:05:35.057446
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:05:36.331471
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-17 22:05:38.297971
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:05:48.942604
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
    assert address.address() == '1 Rue de la Paix'
   

# Generated at 2022-06-17 22:05:55.806069
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:05:56.956455
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:06:07.153879
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"
    assert address.address() == "123 Main Street"

# Generated at 2022-06-17 22:06:13.506602
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:22.341410
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:06:23.592432
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:24.876276
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:33.429114
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address()."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.utils import Provider

    address = Address(Locale.EN)
    assert isinstance(address, Provider)
    assert isinstance(address, BaseProvider)
    assert isinstance(address, Address)
    assert isinstance(address.datetime, Datetime)
    assert isinstance(address.person, Person)

    assert address.address()
    assert address.street_name()
    assert address.street_number()
    assert address.street_suffix()
    assert address.state()

# Generated at 2022-06-17 22:06:40.783438
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:06:42.457383
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:06:43.907836
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:06:54.188869
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:06:56.498479
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    assert a.address() is not None


# Generated at 2022-06-17 22:07:03.566781
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:10.949071
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'
    assert address.address() == '123 Main St.'

# Generated at 2022-06-17 22:07:20.626162
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'

# Generated at 2022-06-17 22:07:30.216145
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.phone_number import PhoneNumber
    from mimesis.providers.structures import Address as AddressStructure
    from mimesis.providers.structures import Person as PersonStructure
    from mimesis.providers.structures import PhoneNumber as PhoneNumberStructure
    from mimesis.providers.structures import Street as StreetStructure
    from mimesis.providers.structures import StreetAddress as StreetAddressStructure
    from mimesis.providers.structures import StreetName as StreetNameStructure
    from mimesis.providers.structures import StreetNumber as Street

# Generated at 2022-06-17 22:07:32.877227
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:07:43.276692
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'
    assert address.address() == '123 Fake St.'

# Generated at 2022-06-17 22:07:44.417318
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:45.474797
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:46.557446
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:48.071725
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:07:56.725838
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'


# Generated at 2022-06-17 22:07:57.837644
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:07:58.876963
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:01.082865
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:02.261418
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:09.370155
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'
    assert address.address() == '123 Main St'

# Generated at 2022-06-17 22:08:13.722429
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'
    assert address.address() == '123 Fake Street'

# Generated at 2022-06-17 22:08:17.174509
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.EN)
    assert a.address() == '1400 W. North Ave.'


# Generated at 2022-06-17 22:08:18.338015
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:08:19.645198
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:08:37.949929
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:08:40.432366
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert address.address()


# Generated at 2022-06-17 22:08:44.689227
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-17 22:08:45.866393
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:08:58.767230
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    address = Address(Locale.RU)
    assert address.address() == 'Советская улица, д. 1'

    address = Address(Locale.RU, RussiaSpecProvider)
    assert address.address() == 'Советская улица, д. 1'

    address = Address(Locale.EN)
    assert address.address() == '1 Main Street'

    address = Address(Locale.JA)

# Generated at 2022-06-17 22:08:59.674573
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:02.043178
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Fake St.'


# Generated at 2022-06-17 22:09:02.932250
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:09:10.631732
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
    assert address.address() == "1400 W. North Ave."
   

# Generated at 2022-06-17 22:09:12.185871
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:09:40.152740
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:09:49.478243
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'
    assert address.address() == '123 Main Street'

# Generated at 2022-06-17 22:09:51.747336
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:10:03.367691
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.unit import Unit

    address = Address()
    assert isinstance(address, Address)
    assert isinstance(address, BaseProvider)
    assert isinstance(address, Datetime)


# Generated at 2022-06-17 22:10:10.931569
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
    assert address.address() == '10 Rue des Chartreux'
   

# Generated at 2022-06-17 22:10:13.861912
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-17 22:10:15.422060
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:10:24.600971
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'
    assert a.address() == '123 Main St.'

# Generated at 2022-06-17 22:10:25.778564
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1st Street'

# Generated at 2022-06-17 22:10:27.338953
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-17 22:11:54.734663
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:11:56.746573
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != None


# Generated at 2022-06-17 22:12:00.266545
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.address() != ''


# Generated at 2022-06-17 22:12:08.913962
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()

# Generated at 2022-06-17 22:12:10.477585
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:12.080013
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address."""
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:13.182750
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-17 22:12:22.520193
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'
    assert a.address() == '123 Main Street'

# Generated at 2022-06-17 22:12:23.751798
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-17 22:12:24.894505
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
