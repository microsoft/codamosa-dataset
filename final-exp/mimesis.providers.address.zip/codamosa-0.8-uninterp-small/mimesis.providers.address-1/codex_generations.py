

# Generated at 2022-06-25 20:18:37.410594
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    address = Address()
    address.address()



# Generated at 2022-06-25 20:18:39.270122
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()



# Generated at 2022-06-25 20:18:40.065379
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='ru')
    assert address.address() is not None


# Generated at 2022-06-25 20:18:44.004789
# Unit test for method address of class Address
def test_Address_address():
    fmt = Address()._data['address_fmt']

    # Check if it has a default format

# Generated at 2022-06-25 20:18:45.404112
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    assert isinstance(address_obj.address(), str)


# Generated at 2022-06-25 20:18:48.305263
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    ans = address_0.address()
    if ans is not None:
        pass
    else:
        print('Test Failed', 'test_Address_address()')


# Generated at 2022-06-25 20:18:49.560053
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-25 20:19:00.128455
# Unit test for method address of class Address
def test_Address_address():
    # Test for case 0
    address_0 = Address()
    address_0_result = address_0.address()
    assert isinstance(address_0_result, str)

    # Test for case 1
    address_1 = Address()
    address_1_result = address_1.address()
    assert isinstance(address_1_result, str)

    # Test for case 2
    address_2 = Address()
    address_2_result = address_2.address()
    assert isinstance(address_2_result, str)

    # Test for case 3
    address_3 = Address()
    address_3_result = address_3.address()
    assert isinstance(address_3_result, str)

    # Test for case 4
    address_4 = Address()
    address_4_result = address_4.address

# Generated at 2022-06-25 20:19:01.140645
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:07.495030
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    data = {
        'en': 'Snelgrove Vw',
        'es': 'Loptel Ln',
        'it': 'Sant\'Alessandro Dr',
        'ru': 'Марксистская ул',
    }
    for locale in data.keys():
        address.set_locale(locale)
        assert address.address().split('\n')[0] == data[locale]


# Generated at 2022-06-25 20:19:17.873423
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    address_0.address()


# Generated at 2022-06-25 20:19:22.676916
# Unit test for method address of class Address
def test_Address_address():
    try:
        address_0 = Address()
        address_0.address()
    except:
        # Test case failed
        return -1
    # Test case passed
    return 0


# Generated at 2022-06-25 20:19:25.986861
# Unit test for method address of class Address
def test_Address_address():
    print('Method address:')
    address_0 = Address()
    result = address_0.address()
    print('method address result:', result)


# Generated at 2022-06-25 20:19:33.967533
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(locale='en')

    # String
    assert isinstance(address_0.address(), str)
    assert isinstance(address_1.address(), str)
    # Non-empty string
    assert address_0.address()
    assert address_1.address()


# Generated at 2022-06-25 20:19:36.423433
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None



# Generated at 2022-06-25 20:19:38.933007
# Unit test for method address of class Address
def test_Address_address():
    address_01 = Address()
    address_01.address()


# Generated at 2022-06-25 20:19:42.716208
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    addrss = address_0.address()
    assert addrss != None and addrss != ''


# Generated at 2022-06-25 20:19:46.145736
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert (len(address.address())) >= 7
    assert (len(address.address())) <= 26


# Generated at 2022-06-25 20:19:47.709403
# Unit test for method address of class Address
def test_Address_address():
    for i in range(1):
        address_1 = Address()
        address_1.address()

# Generated at 2022-06-25 20:19:50.971489
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) > 0


# Generated at 2022-06-25 20:20:01.950218
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert len(address_0.address()) >= 8


# Generated at 2022-06-25 20:20:04.636444
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:20:05.651771
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:20:08.230203
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str1 = address_0.address()


# Generated at 2022-06-25 20:20:12.064152
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert type(result_0) is str


# Generated at 2022-06-25 20:20:14.873459
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result != ''



# Generated at 2022-06-25 20:20:17.659383
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:20:19.038679
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address = address_0.address()
    assert isinstance(address, str)


# Generated at 2022-06-25 20:20:23.874383
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    s = address_0.address()
    assert s is not None
    assert isinstance(s, str)


# Generated at 2022-06-25 20:20:31.043625
# Unit test for method address of class Address
def test_Address_address():
    print('### Start test method address ###')
    address_0 = Address()
    print('address_0.address() = ' + address_0.address())
    address_1 = Address()
    print('address_1.address() = ' + address_1.address())
    address_2 = Address()
    print('address_2.address() = ' + address_2.address())
    print('### Finish test method address ###')



# Generated at 2022-06-25 20:20:54.406801
# Unit test for method address of class Address
def test_Address_address():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 20:21:06.071671
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    address_5 = Address()
    address_6 = Address()
    address_7 = Address()
    address_8 = Address()
    address_9 = Address()
    address_10 = Address()
    address_11 = Address()
    address_12 = Address()
    address_13 = Address()
    address_14 = Address()
    address_15 = Address()
    address_16 = Address()
    address_17 = Address()
    address_18 = Address(locale='de')
    address_19 = Address(locale='de')
    address_20 = Address(locale='de')
    address_21 = Address(locale='de')
    address_

# Generated at 2022-06-25 20:21:08.936794
# Unit test for method address of class Address
def test_Address_address():
    for i in range(100):
        assert Address().address() == Address().address()


# Generated at 2022-06-25 20:21:15.217282
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()

    street_name = address_1.street_name()
    street_number = address_1.street_number()
    street_suffix = address_1.street_suffix()

    assert_0 = street_number + ' ' + street_name + ' ' + street_suffix
    assert_1 = address_1.address()

    assert assert_0 == assert_1


# Generated at 2022-06-25 20:21:18.360128
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 20:21:21.389517
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()


# Generated at 2022-06-25 20:21:25.328882
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    value_0 = address_0.address()
    assert value_0 == "1 Rue Poulletier"


# Generated at 2022-06-25 20:21:27.553609
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == "1759 Roger Cliffs"


# Generated at 2022-06-25 20:21:38.070537
# Unit test for method address of class Address
def test_Address_address():
    expected_output_ru = str
    assert(type(Address(provider='ru').address()) == expected_output_ru)
    expected_output_en = str
    assert(type(Address(provider='en').address()) == expected_output_en)
    expected_output_es = str
    assert(type(Address(provider='es').address()) == expected_output_es)
    expected_output_el = str
    assert(type(Address(provider='el').address()) == expected_output_el)
    expected_output_it = str
    assert(type(Address(provider='it').address()) == expected_output_it)
    expected_output_fr = str
    assert(type(Address(provider='fr').address()) == expected_output_fr)
    expected_output_pl = str

# Generated at 2022-06-25 20:21:41.628042
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert str(type(address_0.address())) == "<class 'str'>"


# Generated at 2022-06-25 20:22:30.622270
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())



# Generated at 2022-06-25 20:22:40.566297
# Unit test for method address of class Address
def test_Address_address():
    # Test 1
    # ---------
    ad0 = Address('en')
    assert isinstance(ad0.address(), str)
    assert ad0.address() in [
        '{st_num} {st_name} {st_sfx}'.format(st_num=ad0.street_number(),
                                             st_name=ad0.street_name(),
                                             st_sfx=ad0.street_suffix()),
        '{st_num} {st_name}'.format(st_num=ad0.street_number(),
                                    st_name=ad0.street_name())
    ]
    # Test 2
    # ---------
    ad0 = Address('uk')
    assert isinstance(ad0.address(), str)

# Generated at 2022-06-25 20:22:47.724785
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    # Pickup a value from method address of class Address and print
    print(str(address_0.address()))


# Generated at 2022-06-25 20:22:48.521177
# Unit test for method address of class Address
def test_Address_address():
    addr_0 = Address()
    assert not (addr_0.address() == addr_0.address())


# Generated at 2022-06-25 20:22:50.685743
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str


# Generated at 2022-06-25 20:22:51.706618
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != ''


# Generated at 2022-06-25 20:22:59.861817
# Unit test for method address of class Address
def test_Address_address():
    Add = Address('ru')
    assert "Трушина" in Add.address()
    assert "улица" in Add.address()
    assert "улица" in Add.address()
    assert "улица" in Add.address()
    assert "Магистральная" in Add.address()
    assert "улица" in Add.address()
    assert "улица" in Add.address()


# Generated at 2022-06-25 20:23:10.890426
# Unit test for method address of class Address
def test_Address_address():
    """
    Note:
        These tests are not exhaustive and should be expanded.
        Feel free to submit a PR to add additional test cases.

    Returns:
        None

    """
    # pattern = re.compile('^\d{1,4}\s[\w\s]{1,20}\n+[\w\s]{1,20}\n+[\w\s]{1,20}$')
    pattern = re.compile('^(\d+|\d{1,4}\w{1,4})\s[\w\s]{1,20}\n+[\w\s]{1,20}\n+[\w\s]{1,20}$')
    address = Address()
    addr = address.address()
    assert re.match(pattern, addr)


# Generated at 2022-06-25 20:23:13.825699
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:23:15.716054
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address_result = address.address()
    assert address_result is not None and address_result != ''
