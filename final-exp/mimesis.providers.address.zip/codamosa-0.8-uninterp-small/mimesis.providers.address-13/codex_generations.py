

# Generated at 2022-06-25 20:18:40.591607
# Unit test for method address of class Address
def test_Address_address():
    # Test 0
    addr_obj_0 = Address()
    var_0 = addr_obj_0.address()
    assert var_0 == '2 Aaker Lane'

    # Test 1
    addr_obj_1 = Address(locale='ru')
    var_0 = addr_obj_1.address()
    assert var_0 == 'Ул. Ленинградская, д. 1, кв. 62'

    # Test 2
    addr_obj_2 = Address(locale='de')
    var_0 = addr_obj_2.address()
    assert var_0 == '10 Береговой сл., Кв. 5'

    # Test 3
    addr_obj_3 = Address(locale='ja')


# Generated at 2022-06-25 20:18:47.973400
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'
    assert address_0.address() == '10, rue de la paix'

# Generated at 2022-06-25 20:18:55.801296
# Unit test for method address of class Address
def test_Address_address():
    for i in range(0, 1000):
        address_0 = Address()
        address_1 = Address()
        address_2 = Address()
        address_3 = Address()
        if address_0.state() != address_1.state():
            assert True
        else:
            assert False
        if address_0.address() != address_1.address():
            assert True
        else:
            assert False
        if address_0.street_name() != address_1.street_name():
            assert True
        else:
            assert False
        if address_1.calling_code() == address_0.calling_code():
            assert True
        else:
            assert False
        if address_0.continent() != address_1.continent():
            assert True
        else:
            assert False

# Generated at 2022-06-25 20:18:58.886077
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address_0 = Address()
    var_0 = address_0.address()
    assert var_0 == 'Оборонная, д. 98 кв. 81'
    assert address_0._random.get_state() is not None



# Generated at 2022-06-25 20:19:00.949247
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    var_0 = address_0.address()


# Generated at 2022-06-25 20:19:02.672461
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    var_0 = address_0.address()


# Generated at 2022-06-25 20:19:05.882737
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    # This is docstring of method __init__ of class Address
    """Class for generate fake address data.

    This object provides all the data related to
    geographical location.
    """


# Generated at 2022-06-25 20:19:07.493745
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()

    assert result is not None


# Generated at 2022-06-25 20:19:14.886764
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    var_1 = address_0.address()
    print(f'Address: {var_1}')
    print(f'Street Number: {var_1.split()[0]}')
    print(f'Street Name: {var_1.split()[1]}')
    print(f'Street Suffix: {var_1.split()[2]}')


# Generated at 2022-06-25 20:19:17.874634
# Unit test for method address of class Address
def test_Address_address():
    address_instance = Address()
    assert isinstance(address_instance.address(), str)


# Generated at 2022-06-25 20:19:25.511049
# Unit test for method address of class Address
def test_Address_address():
    target = Address()
    result = target.address()
    assert result != None


# Generated at 2022-06-25 20:19:38.441133
# Unit test for method address of class Address
def test_Address_address():
    tests = [
        {
            'args': [],
            'kwargs': {},
            'expect': {
                'st_name': str,
                'st_sfx': str,
                'st_num': str,
            }
        },
    ]

    # Loop tests and verify method
    for test in tests:
        address_0 = Address()
        expect = test.get('expect', None)

        method = address_0.address
        actual = method(*test.get('args', None),
                        **test.get('kwargs', None))

        assert actual is not None, 'Should not be None'


# Generated at 2022-06-25 20:19:41.589799
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:19:44.275627
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() not in [""]


# Generated at 2022-06-25 20:19:47.079250
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-25 20:19:48.432153
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert(address_0.address() is not None)


# Generated at 2022-06-25 20:19:53.081678
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert len(result) > 0
    assert isinstance(result, str)


# Generated at 2022-06-25 20:19:55.884752
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:57.723620
# Unit test for method address of class Address
def test_Address_address():
    for _ in range(10):
        with address_0.use_locale('en'):
            address_0.address()


# Generated at 2022-06-25 20:20:01.134468
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == 'Ленина-Черемушкина 37/27'


# Generated at 2022-06-25 20:20:24.128888
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    text_0 = address_0.address()
    assert isinstance(text_0, str)


# Generated at 2022-06-25 20:20:29.460259
# Unit test for method address of class Address
def test_Address_address():
    try:
        address_0 = Address()
        x = address_0.address()
        assert type(x) is str
    except Exception as e:
        print(f'Exception message: {e}')
        return False
    else:
        return True



# Generated at 2022-06-25 20:20:31.972699
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:20:34.700300
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:20:38.553082
# Unit test for method address of class Address
def test_Address_address():
    # Check if address_1 is a string
    address_1 = Address().address()
    
    assert type(address_1) == str


# Generated at 2022-06-25 20:20:42.422515
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address(locale='ru')
    address_3 = Address(locale='uk')
    address_4 = Address(locale='ja')
    test_case_0()
    assert(len(address_1.address()) > 0)
    assert(len(address_2.address()) > 0)
    assert(len(address_3.address()) > 0)
    assert(len(address_4.address()) > 0)


# Generated at 2022-06-25 20:20:45.862657
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert type(result) is str


# Generated at 2022-06-25 20:20:48.741374
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:20:50.213020
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()

# Generated at 2022-06-25 20:20:51.642896
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '140 Rink St'


# Generated at 2022-06-25 20:21:17.336398
# Unit test for method address of class Address
def test_Address_address():
    addr_0 = Address()
    assert isinstance(addr_0.address(), str)


# Generated at 2022-06-25 20:21:22.694153
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    correct_result = type(result) == str and len(result) > 0
    assert correct_result, "Address().address() returned {}".format(result)



# Generated at 2022-06-25 20:21:26.715004
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address(locale='de')
    assert address_0.address() == '241 E.E. Cummings Highway'
    assert address_1.address() == '12 E.E. Cummings Highway'
    assert address_2.address() == '23 Schulterblatt'


# Generated at 2022-06-25 20:21:37.760619
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == 'Домбышева, 10'
    assert address_0.address() == 'Учительская, 10'
    assert address_0.address() == 'Сосновая, 10'
    assert address_0.address() == 'Руднева, 10'
    assert address_0.address() == 'Пролетарская, 10'
    assert address_0.address() == 'Комсомольская, 10'
    assert address_0.address() == 'Краснознаменная, 10'
    assert address_0.address()

# Generated at 2022-06-25 20:21:40.095781
# Unit test for method address of class Address
def test_Address_address():
    address_2 = Address()
    address_2.address()


# Generated at 2022-06-25 20:21:43.913345
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    # loop 1000 times
    for i in range(1000):
        # Calls address()
        assert isinstance(address_0.address(), str)

# Generated at 2022-06-25 20:21:46.935963
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.utils import get_locale

    locale = get_locale()
    address = Address(locale)

    address_0 = address.address()
    assert bool(address_0)
    assert type(address_0) is str
    assert len(address_0) != 0


# Generated at 2022-06-25 20:21:53.772878
# Unit test for method address of class Address
def test_Address_address():
    # Which locale we want to use
    locales = ["ru", "it", "ja"]
    for locale in locales:
        address = Address(locale)
        address.address()
        print("[+] Locale:", locale, "/ address:", address.address())


# Generated at 2022-06-25 20:21:55.878554
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert 'street_number' in address_0.address()


# Generated at 2022-06-25 20:22:04.513214
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(random_seed=1)
    address_2 = Address(random_seed=2)

    assert address_0.address() == '1355 Nam street'
    assert address_1.address() == '43 Henny alley'
    assert address_2.address() == '9603 Nam lane'


# Generated at 2022-06-25 20:23:08.914075
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()

    assert address_0.address() != address_1.address()
    assert address_1.address() != address_2.address()
    assert address_0.address() != address_2.address()
    assert address_2.address() != address_3.address()
    assert address_3.address() != address_4.address()
    assert address_4.address() != address_0.address()


# Generated at 2022-06-25 20:23:09.647557
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:23:20.677298
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    # address_0
    result = address_0.address()
    assert len(result) > 0
    assert result == '{streetNumber} {streetName} {streetSuffix}'
    # address_1
    result = address_1.address()
    assert len(result) > 0
    assert result == '{streetNumber} {streetName} {streetSuffix}'
    # address_2
    result = address_2.address()
    assert len(result) > 0
    assert result == '{streetNumber} {streetName} {streetSuffix}'
    # address_3
    result = address_3.address()

# Generated at 2022-06-25 20:23:26.358591
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = address_0.address()
    assert type(address_1) is str
    assert len(address_1) > 0
    print("Address: ", address_1)


# Generated at 2022-06-25 20:23:28.023011
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:23:33.924770
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert address.address()


# Generated at 2022-06-25 20:23:35.047081
# Unit test for method address of class Address
def test_Address_address():
    address_2 = Address()
    assert isinstance(address_2.address(), str)


# Generated at 2022-06-25 20:23:40.117774
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '127.1.2.1.1'
    assert Address().address() == '92.2.2.2.2'
    assert Address().address() == '0.2.2.2.2'
    assert Address().address() == '5.5.5.5.5'
    assert Address().address() == '12.12.12.12.12'
    assert Address().address() == '3.3.3.3.3'


# Generated at 2022-06-25 20:23:43.145505
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() is not None


# Generated at 2022-06-25 20:23:44.767570
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()
