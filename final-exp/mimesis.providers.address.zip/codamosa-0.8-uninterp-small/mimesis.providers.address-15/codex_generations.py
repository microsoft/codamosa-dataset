

# Generated at 2022-06-25 20:18:36.447128
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('ru')
    str_1 = address_1.address()
    assert str_1 == '11 Белогорск, Тандырская 14'



# Generated at 2022-06-25 20:18:43.494920
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address("be")
    address_2 = Address("es")
    address_3 = Address("fr")
    address_4 = Address("it")
    address_5 = Address("jp")
    address_6 = Address("us")
    print(address_0.address())
    print(address_1.address())
    print(address_2.address())
    print(address_3.address())
    print(address_4.address())
    print(address_5.address())
    print(address_6.address())


# Generated at 2022-06-25 20:18:45.223665
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert str_0 is not None


# Generated at 2022-06-25 20:18:47.480052
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()

    assert str_0 is not None



# Generated at 2022-06-25 20:18:49.412015
# Unit test for method address of class Address
def test_Address_address():
    # Setup test
    address_1 = Address()
    # Exercise and Verify
    assert address_1.address() != None


# Generated at 2022-06-25 20:18:54.210986
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address_1 = a.address()


# Generated at 2022-06-25 20:19:01.936169
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('ja')
    str_0 = address_0.address()
    str_0 = address_0.address()
    str_0 = address_0.address()
    address_0.locale = 'ja'
    str_1 = address_0.address()
    str_1 = address_0.address()
    str_1 = address_0.address()
    address_0.locale = 'pt_BR'
    str_2 = address_0.address()
    str_2 = address_0.address()
    str_2 = address_0.address()
    address_0.locale = 'es_ES'
    str_3 = address_0.address()
    str_3 = address_0.address()
    str_3 = address_0.address()

# Generated at 2022-06-25 20:19:05.560136
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert (str_0 is not None)
    assert (type(str_0) is str)
    assert (len(str_0) > 0)


# Generated at 2022-06-25 20:19:07.202612
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:19:08.865921
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    expected = address.address()
    actual = address.address()
    assert actual != expected


# Generated at 2022-06-25 20:19:16.467329
# Unit test for method address of class Address
def test_Address_address():
    for i in range(100):
        result_1 = Address().address()
        assert type(result_1) == str
        assert len(result_1) > 0, "This result length() nil."

# Generated at 2022-06-25 20:19:25.242394
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(seed=1)
    assert address_1.address() == '606 Fritsch Hill'
    assert address_1.address() == '1090 Moen Villages'
    assert address_1.address() == '1037 Eichmann Mews'
    assert address_1.address() == '1275 Donnelly Burgs'

    # Change current locale
    address_1.localizer.set_locale('ru')
    address_1.random.seed(1)
    assert address_1.address() == 'Ул. Якушева, д. 55б'

    address_2 = Address(seed=2)
    assert address_2.address() == '1343 Wuckert Island'
    assert address_2.address() == '631 Kunze Vista'

# Generated at 2022-06-25 20:19:26.101891
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address().address()


# Generated at 2022-06-25 20:19:36.849703
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address('fr')
    address_2 = Address('he')
    address_3 = Address('es')
    # Test case with default locale
    assert isinstance(address_0.address(), str)
    # Test case with french locale
    assert isinstance(address_1.address(), str)
    # Test case with hebrew locale
    assert isinstance(address_2.address(), str)
    # Test case with spanish locale
    assert isinstance(address_3.address(), str)


# Generated at 2022-06-25 20:19:39.068483
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '601 Green Street'


# Generated at 2022-06-25 20:19:44.058808
# Unit test for method address of class Address
def test_Address_address():
    # given
    address = Address()
    # when
    result = address.address()
    # then
    result_type = type(result)
    assertresult_type == str



# Generated at 2022-06-25 20:19:46.868429
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:48.487496
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    string_0 = address_0.address()
    assert isinstance(string_0, str)


# Generated at 2022-06-25 20:19:54.206590
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0._validate_locale('en') == 'en'
    assert address_0.address() == 'Lane_15, Simpson_Meadow_63'

# Generated at 2022-06-25 20:19:56.278391
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address = address_0.address()


# Generated at 2022-06-25 20:20:11.171486
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address._data = {
        'address_fmt': '{st_num} {st_name} {st_sfx}',
        'street': {
            'name': ['foo'],
            'suffix': ['bar']
        },
    }
    address.generator = lambda: 1
    assert address.address() == '1 foo bar'


# Generated at 2022-06-25 20:20:13.964445
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert len(address_0.address()) > 0


# Generated at 2022-06-25 20:20:24.926510
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_0.address() != ""
    assert address_

# Generated at 2022-06-25 20:20:32.467282
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert isinstance(address_1.address(), str)
    assert isinstance(address_1.street_name(), str)
    assert isinstance(address_1.street_suffix(), str)
    assert isinstance(address_1.street_number(), str)
    assert isinstance(address_1.city(), str)
    assert isinstance(address_1.state(), str)
    assert isinstance(address_1.region(), str)
    assert isinstance(address_1.province(), str)
    assert isinstance(address_1.postal_code(), str)
    assert isinstance(address_1.zip_code(), str)
    assert isinstance(address_1.country(), str)
    assert isinstance(address_1.country_code(), str)

# Generated at 2022-06-25 20:20:35.176993
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address()


# Generated at 2022-06-25 20:20:43.519272
# Unit test for method address of class Address
def test_Address_address():
    """Test functionality of Address.address.

    Addresses generation may depend on locale, that's why I will
    test every locale which is supported by this method.
    """
    for locale in Address.__locales__:
        address_1 = Address(locale=locale)
        assert isinstance(address_1.address(), str)
        print(f'Tested {locale}')

        # Test pretty
        assert isinstance(
            address_1.address(pretty=True), str)
        return True



# Generated at 2022-06-25 20:20:45.779505
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:20:53.178813
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert result_0
    result_1 = address_0.address()
    assert result_1
    result_2 = address_0.address()
    assert result_2
    result_3 = address_0.address()
    assert result_3
    result_4 = address_0.address()
    assert result_4
    

# Generated at 2022-06-25 20:20:57.349750
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    actual_address = address_1.address()
    assert (isinstance(actual_address, str))


# Generated at 2022-06-25 20:21:01.655229
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0_address = address_0.address()
    assert isinstance(address_0_address, str)


# Generated at 2022-06-25 20:21:26.728357
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert type(address_1.address()) == str


# Generated at 2022-06-25 20:21:27.636288
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert (result is not None)


# Generated at 2022-06-25 20:21:31.322522
# Unit test for method address of class Address
def test_Address_address():
    """Test the result of method address."""
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:21:33.335552
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.address()

# Generated at 2022-06-25 20:21:33.952950
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert result



# Generated at 2022-06-25 20:21:35.813101
# Unit test for method address of class Address
def test_Address_address():
    f = Address()
    for i in range(0,100):
        assert(f.address())
    assert True


# Generated at 2022-06-25 20:21:43.655152
# Unit test for method address of class Address
def test_Address_address():
    # There are two cases:
    # 1. Locale that supported by the method
    # 2. Locale that not supported by the method

    address_1 = Address(locale="en")
    address_2 = Address(locale="zh")

    assert address_1.address()
    assert address_2.address()


# Generated at 2022-06-25 20:21:45.631289
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address = address_0.address()
    assert(isinstance(address, str))


# Generated at 2022-06-25 20:21:47.762370
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:21:56.639941
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('en')
    address_2 = Address('ru')
    address_3 = Address('es')
    address_4 = Address('pt')
    address_5 = Address('ja')
    for i in range(100):
        assert len(address_1.address()) > 0
        assert len(address_2.address()) > 0
        assert len(address_3.address()) > 0
        assert len(address_4.address()) > 0
        assert len(address_5.address()) > 0


# Generated at 2022-06-25 20:22:52.848134
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:22:55.011459
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:22:56.838782
# Unit test for method address of class Address
def test_Address_address():
    assert (Address().address() != "" and Address().address() != None)


# Generated at 2022-06-25 20:23:08.913688
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street_number = address.street_number()
    street_name = address.street_name()

    address_en = address.address()
    address_en_format = address.address_fmt
    assert address.address_fmt == SHORTENED_ADDRESS_FMT['en']
    assert address_en == '{} {}'.format(street_number, street_name)


# Generated at 2022-06-25 20:23:12.452302
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), (str, bytes))


# Generated at 2022-06-25 20:23:13.824287
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ''

# Generated at 2022-06-25 20:23:16.312870
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:23:18.274460
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() is not None


# Generated at 2022-06-25 20:23:21.132317
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:23:24.264920
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert(isinstance(a.address(), str))


# Generated at 2022-06-25 20:25:36.944614
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street = address.street_name()
    city = address.city()
    address = address.address()
    assert street.lower() in address.lower() and city.lower() in address.lower()



# Generated at 2022-06-25 20:25:38.488475
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result != ''


# Generated at 2022-06-25 20:25:39.834373
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    address_obj.address()


# Generated at 2022-06-25 20:25:42.235893
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) >= 1


# Generated at 2022-06-25 20:25:43.738213
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != '0'


# Generated at 2022-06-25 20:25:45.594299
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == "5278 Mistake Alley"


# Generated at 2022-06-25 20:25:46.933775
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()



# Generated at 2022-06-25 20:25:48.589397
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:25:50.595872
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    address = addr.address()
    assert isinstance(address, str)


# Generated at 2022-06-25 20:25:52.184710
# Unit test for method address of class Address
def test_Address_address():
    for _ in range(10):
        ad = Address()
    # print(ad.address())

