

# Generated at 2022-06-25 20:18:35.021701
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    var_0 = address_0.address()


# Generated at 2022-06-25 20:18:36.525275
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:18:37.280671
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    var_0 = address_0.address()


# Generated at 2022-06-25 20:18:42.125213
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    var_0 = address_0.address()
    # Expected Output: '2116 W. North St.'
    try:
        assert var_0 == '2116 W. North St.'
    except AssertionError:
        print('Expected Output: \'2116 W. North St.\'')


# Generated at 2022-06-25 20:18:43.571718
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)



# Generated at 2022-06-25 20:18:45.260934
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1_method_result = address_1.address()
    return address_1_method_result


# Generated at 2022-06-25 20:18:46.823853
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:18:48.433428
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:18:49.470136
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    S = address.address()
    assert isinstance(S, str)


# Generated at 2022-06-25 20:18:54.541118
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    var = address.address()
    assert var is not None


# Generated at 2022-06-25 20:19:00.360109
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:19:02.815184
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    for _ in range(100):
        print(address_0.address())


# Generated at 2022-06-25 20:19:04.149202
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-25 20:19:05.882195
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    # Call method address of class Address
    address.address()



# Generated at 2022-06-25 20:19:08.683500
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.address()
    assert address_1.address()


# Generated at 2022-06-25 20:19:10.642559
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:19:13.116771
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() != ""


# Generated at 2022-06-25 20:19:15.223120
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('en')
    assert type(address_1.address()) == str


# Generated at 2022-06-25 20:19:24.538272
# Unit test for method address of class Address
def test_Address_address():
    x = Address(seed=1)
    assert x.address() == '4109 West North Avenue'
    assert x.address() == '9171 Kathy Haven'
    assert x.address() == '6656 Williams Avenue'
    assert x.address() == '6432 Daystar Plaza'
    assert x.address() == '6255 Nancy Parkway'
    assert x.address() == '2810 Washington Crossing'
    assert x.address() == '6011 Jay Meadow'
    assert x.address() == '3498 Smetana Alley'
    assert x.address() == '6234 Huxley Pass'
    assert x.address() == '6407 New Castle Trail'
    x = Address(seed=2)
    assert x.address() == '2710 Redwing Road'
    assert x.address() == '6785 Basil Park'
    assert x

# Generated at 2022-06-25 20:19:26.626430
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1_result = address_1.address()
    assert address_1_result is not None


# Generated at 2022-06-25 20:19:36.780624
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    temp = address.address()
    assert isinstance(temp, str)


# Generated at 2022-06-25 20:19:49.368792
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    address_5 = Address()

    arr_1 = []
    arr_2 = []
    arr_3 = []
    arr_4 = []
    arr_5 = []
    for i in range(100):
        arr_1.append(address_1.address())
        arr_2.append(address_2.address())
        arr_3.append(address_3.address())
        arr_4.append(address_4.address())
        arr_5.append(address_5.address())

    print('address()')
    print('Address().address(): ', address_1.address())
    print('Address(locale=\'en\').address(): ', address_2.address())
   

# Generated at 2022-06-25 20:19:51.521868
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ''


# Generated at 2022-06-25 20:19:54.134531
# Unit test for method address of class Address
def test_Address_address():
    # Python version
    assert isinstance(Address().address(), str), 'Returned type is \'string\''

# Generated at 2022-06-25 20:19:57.593289
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-25 20:20:00.839807
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert re.match(r"\d+, \w+, \w+", address_0.address())


# Generated at 2022-06-25 20:20:11.758637
# Unit test for method address of class Address
def test_Address_address():
    
    from mimesis.enums import AddressFormats
    from mimesis.providers.address import Address
    
    # Create a instance of class Address
    address = Address()

    # Generated random address with separator, formated
    # in dot.
    assert address.address() != None
    
    # Generated random address with separator, formated
    # in slash.
    assert address.address(formatter=AddressFormats.SLASH) != None
    
    # Generated random address without separator, formated
    # in dot.
    assert address.address(separator=None) != None
    
    # Generated random address without separator, formated
    # in slash.
    assert address.address(separator=None, formatter=AddressFormats.SLASH) != None
    
    return True


# Generated at 2022-06-25 20:20:19.449530
# Unit test for method address of class Address
def test_Address_address():
    # Get the address of en_US
    address_0 = Address(locale='en_US')
    print(type(address_0.address()))
    print(address_0.address())

    # Get the address of ja
    address_1 = Address(locale='ja')
    print(type(address_1.address()))
    print(address_1.address())



# Generated at 2022-06-25 20:20:24.304814
# Unit test for method address of class Address
def test_Address_address():
    # Call the function
    address_0 = Address()
    result = address_0.address()

    # Check the result
    assert type(result) == str


# Generated at 2022-06-25 20:20:27.700140
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address = address_0.address()
    assert isinstance(address, str)

# Generated at 2022-06-25 20:20:56.782469
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) is str
    assert len(address_0.address()) > 0
    address_0.seed(1)
    assert (address_0.address() == '100 Kellerstraße')
    address_0.seed(1)
    assert (address_0.address() == '100 Kellerstraße')
    address_0.seed(2)
    assert (address_0.address() == '17 Sullivan Drive')
    address_0.seed(3)
    assert (address_0.address() == '488 Evans Pass')
    address_0.seed(4)
    assert (address_0.address() == '541 Anzinger Plaza')
    address_0.seed(5)
    assert (address_0.address() == '564 Alpine Pass')
   

# Generated at 2022-06-25 20:20:58.974252
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())

# Generated at 2022-06-25 20:21:02.952129
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address.address()
    address_2 = Address.address()
    assert address_1 != address_2


# Generated at 2022-06-25 20:21:05.188797
# Unit test for method address of class Address
def test_Address_address():
    f = Address()
    result = f.address()
    assert result is not None

# Generated at 2022-06-25 20:21:08.555723
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr = address.address()
    assert addr is not None
    assert addr.strip() != ""


# Generated at 2022-06-25 20:21:10.658679
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:21:14.057381
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    try:
        address = Address()
        address.address()
    except BaseException:
        raise IOError("Unit test failed.")



# Generated at 2022-06-25 20:21:22.329843
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address(locale='ja')
    address_4 = Address(locale='ja')
    address_0.address()
    address_1.address()
    address_2.address()
    address_3.address()
    address_4.address()


# Generated at 2022-06-25 20:21:24.876963
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)



# Generated at 2022-06-25 20:21:28.063062
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:22:14.251346
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print("The address of Address(" + address_0.address() + ") is: " + address_0.address())


# Generated at 2022-06-25 20:22:15.550174
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    adress = address_0.address()

    assert True


# Generated at 2022-06-25 20:22:17.818247
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:22:19.905154
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-25 20:22:21.609131
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert len(address.address()) > 0
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:22:26.529050
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for Address.address()"""
    address_1 = Address()
    result_1 = address_1.address()

    assert(result_1 != None)
    assert(isinstance(result_1, str))


# Generated at 2022-06-25 20:22:30.157579
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import address
    address_0 = address.Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:22:33.767286
# Unit test for method address of class Address
def test_Address_address():
    address = Address("en")
    result = address.address()
    # TODO: Assert the result is valid
    assert result is not None
    return result


# Generated at 2022-06-25 20:22:35.684367
# Unit test for method address of class Address
def test_Address_address():
    # Create object
    address = Address()

    # Check: should return address
    assert type(address.address()) == str



# Generated at 2022-06-25 20:22:42.258257
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address("pt_BR")
    result_0 = address_0.address()
    print("result_0", result_0)
    result_1 = address_0.address()
    print("result_1", result_1)


# Generated at 2022-06-25 20:23:37.831668
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()

# Generated at 2022-06-25 20:23:40.628819
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    myAddress = address.address()
    assert isinstance(myAddress, str)



# Generated at 2022-06-25 20:23:44.361267
# Unit test for method address of class Address
def test_Address_address():
    """Testing case for method address of class Address"""
    address = Address()
    assert bool(address.address())


# Generated at 2022-06-25 20:23:52.264361
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

# Generated at 2022-06-25 20:23:55.255956
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:24:07.124549
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address().__contains__(" ")

# Generated at 2022-06-25 20:24:13.037208
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    address_5 = Address()
    address_6 = Address()
    address_7 = Address()
    address_8 = Address()
    address_9 = Address()
    address_10 = Address()
    address_11 = Address()
    address_12 = Address()
    address_13 = Address()
    address_14 = Address()
    address_15 = Address()
    address_16 = Address()
    address_17 = Address()
    address_18 = Address()
    address_19 = Address()
    address_20 = Address()
    address_21 = Address()
    address_22 = Address()
    address_23 = Address()
    address_24 = Address()

# Generated at 2022-06-25 20:24:14.820326
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:24:16.106494
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('ru')
    print(address_1.address())


# Generated at 2022-06-25 20:24:28.051977
# Unit test for method address of class Address
def test_Address_address():
    from random import seed
    from mimesis.enums import Locale
    # Initialize Seed
    seed(1)
    # Initialize Class
    address_ = Address(locale=Locale.EN)
    result = address_.address()
    assert result == '948 Goodwin Lake'
    # 2
    seed(2)
    # Initialize Class
    address_ = Address(locale=Locale.EN)
    result = address_.address()
    assert result == '434 Nelson Hill'
    # 3
    seed(3)
    # Initialize Class
    address_ = Address(locale=Locale.EN)
    result = address_.address()
    assert result == '288 Louis Hill'
    # 4
    seed(4)
    # Initialize Class
    address_ = Address(locale=Locale.EN)


# Generated at 2022-06-25 20:25:21.959952
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert len(address_1.address()) > 0


# Generated at 2022-06-25 20:25:27.666422
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=0)
    result_0 = address_0.address()
    assert result_0 == '48 Dach Point'
    seed_0 = 0
    seed_1 = 0
    address_1 = Address(seed=seed_0)
    address_2 = Address(seed=seed_1)
    result_1 = address_1.address()
    result_2 = address_2.address()
    assert result_1 == result_2


# Generated at 2022-06-25 20:25:30.604159
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) is str


# Generated at 2022-06-25 20:25:33.832053
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    addr_0 = address_0.address()
    print(addr_0)


# Generated at 2022-06-25 20:25:36.825714
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print("Test Case: address: address_0 = Address()")
    print("address_0.address(()):")
    print(address_0.address())


# Generated at 2022-06-25 20:25:38.710781
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # Address
    assert address_0.address() == '3345 Smith St.'


# Generated at 2022-06-25 20:25:41.538450
# Unit test for method address of class Address
def test_Address_address():
    # TODO: Write unit test
    return None


# Generated at 2022-06-25 20:25:45.286462
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('en')
    address_1 = Address('en')
    for i in range(0, 100):
        if address_0.address() != address_1.address():
            break
    else:
        assert False, \
            'Address.address method not working correctly!'


# Generated at 2022-06-25 20:25:46.973170
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)
    print(address.address())

# Generated at 2022-06-25 20:25:48.263701
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:26:42.574189
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert(address_0.address() != '')
    # print('\naddress_0 address: ' + address_0.address())


# Generated at 2022-06-25 20:26:44.186106
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:26:46.343855
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for i in range(0, 5):
        address.address()


# Generated at 2022-06-25 20:26:48.859943
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() not in ("", 0, 1, None)


# Generated at 2022-06-25 20:26:56.699345
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() == "331 Elizabeth Place"
    assert address_1.address() == "4727 Crescent Drive"
    assert address_1.address() == "5446 Lincoln Drive"
    assert address_1.address() == "7450 Charles Drive"
    assert address_1.address() == "2156 Woodgate Drive"
    assert address_1.address() == "4562 Camden Court"
    assert address_1.address() == "6444 Walnut Road"
    assert address_1.address() == "7235 Charles Street"
    assert address_1.address() == "7331 Palmetto Avenue"
    assert address_1.address() == "8121 Price Street"
    assert address_1.address() == "3835 Oxford Drive"

# Generated at 2022-06-25 20:26:58.137703
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:27:02.409161
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()



# Generated at 2022-06-25 20:27:04.359415
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert(address_1.address() != None)


# Generated at 2022-06-25 20:27:05.358025
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert any(address.address())


# Generated at 2022-06-25 20:27:06.596829
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    str(address_0.address())
