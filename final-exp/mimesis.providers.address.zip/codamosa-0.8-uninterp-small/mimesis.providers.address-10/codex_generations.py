

# Generated at 2022-06-25 20:18:38.306581
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address().address()
    try:
        assert(type(address_0) != None)
    except:
        print('Function address() of class Address is broken')
    else:
        print('Function address() of class Address is not broken')


# Generated at 2022-06-25 20:18:40.858025
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(postal_code='200100')

    assert address_0.address() == '25 Harrison St.'


# Generated at 2022-06-25 20:18:42.711519
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    for i in range(100):
        assert isinstance(ad.address(), str)


# Generated at 2022-06-25 20:18:44.809417
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # Test case 1
    assert isinstance(address_0.address(), str)



# Generated at 2022-06-25 20:18:53.703335
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '720 Jaskolski Inlet'
    assert address_0.address() == '042 Barton Shoals'
    assert address_0.address() == '229 Eggers Wall'
    assert address_0.address() == '82314 Margie Shore'
    assert address_0.address() == '84724 Gislason Ranch'
    assert address_0.address() == '2820 Block Route'
    assert address_0.address() == '8546 Block Route'
    assert address_0.address() == '89674 Kiehn Stravenue'
    assert address_0.address() == '3154 Ebert Trace'
    assert address_0.address() == '82636 Beahan Trail'
    assert address_0.address() == '042 Stanton Lake'
   

# Generated at 2022-06-25 20:18:54.724341
# Unit test for method address of class Address
def test_Address_address():
    address = Address('En')
    address_address = address.address()
    assert isinstance(address_address, str)


# Generated at 2022-06-25 20:18:56.573454
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())
    assert address_0.address()


# Generated at 2022-06-25 20:19:00.936537
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.address import Address
    a = Address()
    result = a._address()
    assert result == 'No. 1723, Green Wind Trail'
    pass



# Generated at 2022-06-25 20:19:02.619337
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:19:03.980241
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:19:11.064128
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert len(result_0) == 28


# Generated at 2022-06-25 20:19:12.983583
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-25 20:19:17.339521
# Unit test for method address of class Address
def test_Address_address():
    mimesis_address = Address().address()
    print(mimesis_address)
    try:
        assert(mimesis_address is not None)
    except AssertionError as error:
        print(error)
    try:
        assert(len(mimesis_address) > 0)
    except AssertionError as error:
        print(error)


# Generated at 2022-06-25 20:19:21.262617
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(region='US')
    result = address_0.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:19:27.494424
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(locale='ru')
    address_2 = Address(locale='ja')

    assert isinstance(address_0.address(), str)
    assert len(address_0.address()) > 1
    assert address_1.address() != address_2.address()


# Generated at 2022-06-25 20:19:29.438008
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for i in range(100):
        assert len(address.address()) > 0


# Generated at 2022-06-25 20:19:32.145912
# Unit test for method address of class Address
def test_Address_address():
    ml = Address()
    address = ml.address()
    print("The address is: ", address)


# Generated at 2022-06-25 20:19:34.718982
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:36.963746
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:19:39.080142
# Unit test for method address of class Address
def test_Address_address():
    test_instance = Address()
    print(test_instance.address())


# Generated at 2022-06-25 20:19:46.807677
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None



# Generated at 2022-06-25 20:19:52.376870
# Unit test for method address of class Address

# Generated at 2022-06-25 20:19:54.412025
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()



# Generated at 2022-06-25 20:19:56.742119
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en')
    assert type(address_1.address()) == str


# Generated at 2022-06-25 20:19:58.476686
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:20:06.275942
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()
    address_1 = Address()
    address_1.address()
    address_2 = Address()
    address_2.address()
    address_3 = Address()
    address_3.address()
    address_4 = Address()
    address_4.address()
    address_5 = Address()
    address_5.address()
    address_6 = Address()
    address_6.address()
    address_7 = Address()
    address_7.address()
    address_8 = Address()
    address_8.address()
    address_9 = Address()
    address_9.address()
    address_10 = Address()
    address_10.address()
    address_11 = Address()
    address_11.address()
    address_12 = Address()

# Generated at 2022-06-25 20:20:13.478972
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address(locale='en')
    address_3 = Address(locale='ru')
    address_4 = Address(locale='zh')
    address_5 = Address(locale='ar')
    address_6 = Address(locale='be')
    address_7 = Address(locale='bg')
    address_8 = Address(locale='cs')
    address_9 = Address(locale='da')
    address_10 = Address(locale='de')
    address_11 = Address(locale='el')
    address_12 = Address(locale='es')
    address_13 = Address(locale='fi')
    address_14 = Address(locale='fr')
    address_15 = Address(locale='he')

# Generated at 2022-06-25 20:20:18.695608
# Unit test for method address of class Address
def test_Address_address():
    addr_0 = Address()
    assert addr_0.address().count('\n') == 0
    assert addr_0.address().count('\r') == 0
    assert addr_0.address().count(',') == 1


# Generated at 2022-06-25 20:20:19.996269
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != None
    return 0


# Generated at 2022-06-25 20:20:22.725801
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ''


# Generated at 2022-06-25 20:20:38.478045
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:20:47.080966
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != address_0.address()

# Generated at 2022-06-25 20:20:56.807047
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()
    address_1 = Address()
    address_1.address()
    address_2 = Address(seed=0)
    address_2.address()
    address_3 = Address(seed=0)
    address_3.address()
    assert address_0.address() == '青野島２７０−４'
    assert address_1.address() == 'Spalentorstrasse８７'
    assert address_2.address() == 'Софийская６０５'
    assert address_3.address() == 'Софийская６０５'

# Unit test

# Generated at 2022-06-25 20:20:58.559926
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    assert address_0.address() != address_1.address()


# Generated at 2022-06-25 20:21:02.655549
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed="seed")
    assert address_0.address() == '学院６２８１'


# Generated at 2022-06-25 20:21:07.564849
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert result.count(' ') == 1
    assert result.count(',') == 1


# Generated at 2022-06-25 20:21:17.863146
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

# Generated at 2022-06-25 20:21:24.351453
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() in ["Robert Hausmann-Straße 9", "4283, Rue des Prés", "서울특별시 용산구 원효로 1, 이태원동"]


# Generated at 2022-06-25 20:21:29.106086
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # Street address in format 'street-number street-name street-suffix'.
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:21:32.759097
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:22:03.252784
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    assert (address)


# Generated at 2022-06-25 20:22:05.851433
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    random = address.random
    assert random in address.address()


# Generated at 2022-06-25 20:22:11.598698
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    result = 0
    for i in range(1000):
        s = address_0.street_number()
        if (s[0] == '1'):
            result += 1

    for j in range(1000):
        s = address_0.street_number()
        if (s[0] == '2'):
            result += 1

    for k in range(1000):
        s = address_0.street_number()
        if (s[1] == '0'):
            result += 1

    assert 100 <= result <= 300

# Generated at 2022-06-25 20:22:12.910280
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:22:14.340341
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())

test_Address_address()

# Generated at 2022-06-25 20:22:15.920749
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert(result_0 == "123 Beaumarrage Drive")


# Generated at 2022-06-25 20:22:18.197211
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    print(address_1.address())



# Generated at 2022-06-25 20:22:23.516625
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    test_arg_0 = address_0.address()
    # The type of return value of method address of class Address
    assert(isinstance(test_arg_0, str))


# Generated at 2022-06-25 20:22:27.410039
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    assert address_0.address() == address_1.address()
    assert address_1.address() == address_2.address()


# Generated at 2022-06-25 20:22:29.820348
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None
