

# Generated at 2022-06-25 20:18:31.119007
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.street_number(maximum=100)


# Generated at 2022-06-25 20:18:34.031518
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    str_1 = address_0.address()
    assert str_0 is not str_1


# Generated at 2022-06-25 20:18:35.426741
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    result = ad.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:18:39.072137
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # str full_address_0 = address_0.address()
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())


# Generated at 2022-06-25 20:18:44.480019
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.providers.base import BaseProvider
    from tests.unit.testdata.address import ADDRESS_LIST_EN
    from tests.unit.testdata.address import ADDRESS_LIST_JA
    provider = Address(locale='en')
    address = provider.address()
    assert address in ADDRESS_LIST_EN
    provider = Address(locale='ja')
    address = provider.address()
    assert address in ADDRESS_LIST_JA



# Generated at 2022-06-25 20:18:45.596083
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ' '


# Generated at 2022-06-25 20:18:46.413719
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:18:47.537845
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address"""
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:48.989253
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    # Run function address of class Address
    result = address_0.address()

    # Check the address

    assert type(result) is str

# Generated at 2022-06-25 20:18:49.601467
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() is not None


# Generated at 2022-06-25 20:18:55.227184
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:18:56.941046
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    string_1 = address_0.address()
    print(string_1)


# Generated at 2022-06-25 20:18:58.137178
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert len(address_0.address()) > 0


# Generated at 2022-06-25 20:19:00.701749
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()

    assert address_0.address() != address_1.address()


# Generated at 2022-06-25 20:19:09.628246
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(random=4)
    str_0 = '4a Calle'
    assert str_0 == address_0.address(), 'Expected "4a Calle" from address_0.address(), but got: {}'.format(address_0.address())

    address_1 = Address(random=60)
    str_1 = '60 Calle'
    assert str_1 == address_1.address(), 'Expected "60 Calle" from address_1.address(), but got: {}'.format(address_1.address())

    address_2 = Address(random=123)
    str_2 = '123 Calle'
    assert str_2 == address_2.address(), 'Expected "123 Calle" from address_2.address(), but got: {}'.format(address_2.address())


# Generated at 2022-06-25 20:19:11.002300
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:19:18.597701
# Unit test for method address of class Address
def test_Address_address():
    # create instance Address
    address_0 = Address()
    # assign result of method address of class Address to address1
    address1 = address_0.address()
    # check if address1 is address
    assert isinstance(address1, str)
    # assign result of method address of class Address to address2
    address2 = address_0.address()
    # check if address2 is address
    assert isinstance(address2, str)
    # assign result of method address of class Address to address3
    address3 = address_0.address()
    # check if address3 is address
    assert isinstance(address3, str)


# Generated at 2022-06-25 20:19:22.299588
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address = address_1.address()
    print('address = ', address)


# Generated at 2022-06-25 20:19:24.439268
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:19:33.935083
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    st_num = address_0.street_number()
    st_name = address_0.street_name()
    st_sfx = address_0.street_suffix()
    address_0.address()
    assert address_0.address() == address_0.address_fmt.format(st_num=st_num, st_name=st_name, st_sfx=st_sfx)
    address_0.locale = 'ja'
    assert address_0.address() == address_0.address_fmt.format(address_0.random.choice(address_0._data['city']), *address_0.random.randints(amount=3, a=1, b=100))
    address_0.locale = 'zh_CN'

# Generated at 2022-06-25 20:19:50.979885
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address(locale='en')
    address_3 = Address(locale='ru')
    address_4 = Address(locale='ja')
    address_5 = Address(locale='pt')
    address_6 = Address(locale='vi')
    address_7 = Address(locale='zh')
    address_8 = Address(locale='es')
    address_9 = Address(locale='pl')
    address_10 = Address(locale='cs')
    address_11 = Address(locale='hu')
    address_12 = Address(locale='it')
    address_13 = Address(locale='sl')
    address_14 = Address(locale='de')
    address_15 = Address(locale='fr')

# Generated at 2022-06-25 20:19:53.717671
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)



# Generated at 2022-06-25 20:20:01.707027
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.random.seed(0)
    assert address_1.address() == '12/6 Rue de la Nuit'
    address_1.random.seed(1)
    assert address_1.address() == '42 Rue du froid'
    address_1.random.seed(2)
    assert address_1.address() == '8 Rue du CDZ de la touche'
    address_1.random.seed(3)
    assert address_1.address() == '21 Rue de Dijkstra'
    address_1.random.seed(4)
    assert address_1.address() == '75 Rue de la Démocratie du logiciel libre'
    address_1.random.seed(5)
    assert address_1.address() == '9 Rue de la Presse'

# Generated at 2022-06-25 20:20:06.339918
# Unit test for method address of class Address
def test_Address_address():
    print("\nTEST: Address -> method address")
    address_0 = Address()
    address_1 = Address()
    print(address_0.address())
    print(address_1.address())



# Generated at 2022-06-25 20:20:07.694989
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert isinstance(str_0, str) is True, 'Unexpected type'
    assert str_0, 'Unexpected empty string'



# Generated at 2022-06-25 20:20:08.420629
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address().address()


# Generated at 2022-06-25 20:20:11.531009
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str) == True


# Generated at 2022-06-25 20:20:15.570959
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    s = str(address_0.address())
    b = isinstance(s, (str,))
    assert(b)



# Generated at 2022-06-25 20:20:25.508387
# Unit test for method address of class Address
def test_Address_address():
    def test_case_1():
        assert Address().address() == "1234 Marlyn  Way"

    def test_case_2():
        assert Address().address() == "1234 Marlyn  Way"

    def test_case_3():
        assert Address().address() == "1234 Marlyn  Way"

    def test_case_4():
        assert Address().address() == "1234 Marlyn  Way"

    def test_case_5():
        assert Address().address() == "1234 Marlyn  Way"

    def test_case_6():
        assert Address().address() == "1234 Marlyn  Way"

    def test_case_7():
        assert Address().address() == "1234 Marlyn  Way"

    def test_case_8():
        assert Address().address() == "1234 Marlyn  Way"

# Generated at 2022-06-25 20:20:31.376266
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    address_3 = Address(seed=0)
    address_4 = Address(seed=0)
    address_5 = Address()
    assert address_1.address() == address_2.address(), 'BAD!'
    assert address_3.address() == address_4.address(), 'BAD!'
    assert address_1.address() != address_5.address(), 'BAD!'



# Generated at 2022-06-25 20:20:54.079764
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None


# Generated at 2022-06-25 20:20:56.100946
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='zh')
    assert address_0.address() == '0号-长沙街'



# Generated at 2022-06-25 20:20:57.640825
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:21:00.128065
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert len(address.address()) != 0


# Generated at 2022-06-25 20:21:07.455466
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address('de')
    address_2 = Address('ru')
    address_3 = Address('ru-ru')
    address_4 = Address('sr-RS')
    address_5 = Address('sr-rs')
    address_6 = Address('ja')
    address_7 = Address('en-gb')
    address_8 = Address('en-US')
    address_9 = Address('en-us')
    assert address_0.address() is not None
    assert address_1.address() is not None
    assert address_2.address() is not None
    assert address_3.address() is not None
    assert address_4.address() is not None
    assert address_5.address() is not None
    assert address_6.address() is not None
    assert address_7

# Generated at 2022-06-25 20:21:10.365319
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == "3rd Street"



# Generated at 2022-06-25 20:21:12.949453
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() in [Address().address() for _ in range(100)]


# Generated at 2022-06-25 20:21:16.197361
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('fr')
    assert address_1.address()


# Generated at 2022-06-25 20:21:19.361124
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    a0 = address_0.address()
    assert isinstance(a0, str)


# Generated at 2022-06-25 20:21:23.346217
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


if __name__ == '__main__':
    test_Address_address()
    test_case_0()

# Generated at 2022-06-25 20:22:10.363841
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None and address.address().find('\'') == -1


# Generated at 2022-06-25 20:22:12.361759
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)

# Generated at 2022-06-25 20:22:13.940393
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    print("The Street Address is ",result)


# Generated at 2022-06-25 20:22:15.457022
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # result
    res = address_0.address()
    assert isinstance(res, str)



# Generated at 2022-06-25 20:22:28.422113
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
   

# Generated at 2022-06-25 20:22:35.142529
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    try:
        address_0.address()
    except Exception as ex:
        assert "str object is not callable" in str(ex)
    assert address_0.address() is not None
    assert not isinstance(address_0.address(), bool)
    assert len(address_0.address()) > 0
    print(address_0.address())



# Generated at 2022-06-25 20:22:37.963510
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    add.address()


# Generated at 2022-06-25 20:22:40.568594
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:22:47.723429
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-25 20:22:49.138715
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result = address_1.street_name()
    assert result == "Fordham Road"
