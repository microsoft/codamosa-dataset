

# Generated at 2022-06-25 20:18:37.813851
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address(seed=88)

    assert address_1.address() != address_2.address()
    

# Generated at 2022-06-25 20:18:40.640253
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:18:41.883182
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:18:43.335120
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ""


# Generated at 2022-06-25 20:18:45.593543
# Unit test for method address of class Address
def test_Address_address():
    print('Test for method address of class Address')
    address_0 = Address()
    address_result = address_0.address()
    print(' address result = {}'.format(address_result))



# Generated at 2022-06-25 20:18:48.819551
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(['sk'])
    s = address_0.address()
    s1 = address_1.address()
    
if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-25 20:18:50.711486
# Unit test for method address of class Address
def test_Address_address():
    testObj = Address()
    print('Address_address : '+testObj.address()+'\n')


# Generated at 2022-06-25 20:18:53.939510
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street_num = address.street_number()
    street_name = address.street_name()
    street_suffix = address.street_suffix()
    assert street_num + ' ' + street_name + ' ' + street_suffix in \
        address.address()


# Generated at 2022-06-25 20:18:55.033097
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:19:02.350599
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str) is True
    assert address_0.address() == '1408 Mraz Fields' or \
        address_0.address() == '1408 Mraz Forges' or \
        address_0.address() == '1408 Mraz Meadows' or \
        address_0.address() == '1408 Mraz Rdg' or \
        address_0.address() == '1408 Mraz Radial' or \
        address_0.address() == '1408 Mraz Summit' or \
        address_0.address() == '1408 Mraz Turnpike' or \
        address_0.address() == '1408 Mraz Viaduct' or \
        address_0.address() == '1408 Mraz Villas' or \
        address_0

# Generated at 2022-06-25 20:19:10.547488
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ""


# Generated at 2022-06-25 20:19:13.010839
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    # To do
    # Get a random street address.
    # Arguments: none
    # Return: Random street address.
    address_1.address()


# Generated at 2022-06-25 20:19:15.156499
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '22 Нагорная'


# Generated at 2022-06-25 20:19:17.044049
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print('Address of the user is ' + address_0.address())

# Generated at 2022-06-25 20:19:18.680984
# Unit test for method address of class Address
def test_Address_address():
    data_0_0 = Address().address()
    assert type(data_0_0) == str


# Generated at 2022-06-25 20:19:21.186974
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) == 10


# Generated at 2022-06-25 20:19:29.086457
# Unit test for method address of class Address
def test_Address_address():
    # This is an automated test, please do not modify it
    # Iteration 1:
    address_0 = Address()
    assert address_0.address() == '286 Rue de la Charente'

    # Iteration 2:
    address_1 = Address()
    assert address_1.address() == '631 Cours Jules Lagrange'

    # Iteration 3:
    address_2 = Address()
    assert address_2.address() == '156 Rue du Faubourg du Temple'


# Generated at 2022-06-25 20:19:39.137785
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()
    assert Address.address(Address())
    assert Address('es').address()
    assert Address.address(Address('es'))
    assert Address('en-US').address()
    assert Address.address(Address('en-US'))
    assert Address('zh-Hans_SG').address()
    assert Address.address(Address('zh-Hans_SG'))
    assert Address('bn-BD').address()
    assert Address.address(Address('bn-BD'))
    assert Address('ar-EG').address()
    assert Address.address(Address('ar-EG'))
    assert Address('fa-IR').address()
    assert Address.address(Address('fa-IR'))
    assert Address('en-CA').address()
    assert Address.address(Address('en-CA'))

# Generated at 2022-06-25 20:19:42.937868
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for i in range(0, 100):
        result = address.address()
        assert result is not None


# Generated at 2022-06-25 20:19:45.058981
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())


# Generated at 2022-06-25 20:20:00.987013
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()

# Generated at 2022-06-25 20:20:06.183515
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # assert address_0.address() == '1293 Притыцкого проезд'
    assert address_0.address() is not None


# Generated at 2022-06-25 20:20:08.896612
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_arg_0 = address_0.address()
    assert str_arg_0


# Generated at 2022-06-25 20:20:11.677128
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('en')
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:20:14.479171
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() # The result is: 1084 Adams Street


# Generated at 2022-06-25 20:20:16.617241
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:20:22.935001
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address("ru")
    address_3 = Address("en_GB")

    assert address_1.address() == "200 中山西路"
    assert address_2.address() == "200 Принцессы Габриэллы"
    assert address_3.address() == "200 Princess Gabrielle"


# Generated at 2022-06-25 20:20:26.939108
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() is not None


# Generated at 2022-06-25 20:20:34.245729
# Unit test for method address of class Address
def test_Address_address():
    pt = Address(locale='pt')
    en = Address(locale='en')
    es = Address(locale='es')
    fr = Address(locale='fr')
    it = Address(locale='it')
    de = Address(locale='de')
    uk = Address(locale='uk')
    ja = Address(locale='ja')
    cn = Address(locale='cn')
    th = Address(locale='th')
    tw = Address(locale='tw')
    vn = Address(locale='vn')
    tr = Address(locale='tr')
    rus = Address(locale='ru_RU')
    ua = Address(locale='uk_UA')
    kz = Address(locale='kk_KZ')

# Generated at 2022-06-25 20:20:35.265593
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)



# Generated at 2022-06-25 20:20:53.664061
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.street_number() is not None
    assert address.street_name() is not None
    assert address.street_suffix() is not None

    assert address.address() is not None


# Generated at 2022-06-25 20:20:58.598641
# Unit test for method address of class Address
def test_Address_address():  # noqa
    address = Address()
    assert (len(address.address()) >= 10)
    assert (len(address.address()) <= 50)



# Generated at 2022-06-25 20:21:00.078548
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert len(address_0.address()) > 0
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:21:01.395362
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='en')
    assert a.address() is not None


# Generated at 2022-06-25 20:21:03.683886
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    # Test for Address address method
    assert a.address() != '3'


# Generated at 2022-06-25 20:21:08.633786
# Unit test for method address of class Address
def test_Address_address():

	# Arrange
	address_0 = Address()
	
	# Act
	result = address_0.address()
	
	# Assert
	assert isinstance(result, str)
	
test_Address_address()


# Generated at 2022-06-25 20:21:12.948397
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0_address = address_0.address()
    assert isinstance(address_0_address, str)
    assert address_0_address


# Generated at 2022-06-25 20:21:17.335389
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    # print(address_1.address())
    assert address_1.address() == '1067 Laverne Loop'


# Generated at 2022-06-25 20:21:27.082264
# Unit test for method address of class Address
def test_Address_address():
    # Test default locale
    address_0 = Address()
    address = address_0.address()
    assert isinstance(address, str)
    assert len(address.split(" ")) == 4

    # Test ru_RU
    address_0 = Address("ru_RU")
    address = address_0.address()
    assert isinstance(address, str)
    assert len(address.split(" ")) == 4

    # Test short address format
    address_0 = Address("fr_FR")
    address = address_0.address()
    assert isinstance(address, str)
    assert len(address.split(" ")) == 3

    # Test ja_JP
    address_0 = Address("ja_JP")
    address = address_0.address()
    assert isinstance(address, str)

# Generated at 2022-06-25 20:21:29.105719
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:21:52.945528
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale="en-Us")
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())


# Generated at 2022-06-25 20:21:55.419470
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address().address()
    print(f'address_1: {address_1}')


# Generated at 2022-06-25 20:22:00.424976
# Unit test for method address of class Address
def test_Address_address():

    def _check(data: str, stub: str) -> bool:
        return data == stub

    assert _check(Address().address(), "520 W. Ash St.")
    assert _check(Address('ru').address(), "Волгоград, ул. Василия Качалова, д. 3, кв. 43")
    assert _check(Address('ru', 'ru').address(), "Нижний Новгород, ул. Грибоедова, д. 7, кв. 60")

# Generated at 2022-06-25 20:22:03.729512
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)
    assert address_0.address() != ''


# Generated at 2022-06-25 20:22:06.301380
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert True == (isinstance(address_0.address(), str))


# Generated at 2022-06-25 20:22:09.218648
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='zh')
    assert address_1.address() != address_1.address()


# Generated at 2022-06-25 20:22:15.382462
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()
    address_1 = Address(seed=87076184235)
    address_1.address()
    address_2 = Address(seed=4511697037)
    address_2.address()
    address_3 = Address(seed=47646627141)
    address_3.address()
    address_4 = Address(seed=21973517973)
    address_4.address()
    address_5 = Address(seed=63322348280)
    address_5.address()


# Generated at 2022-06-25 20:22:18.963682
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert(address_1.address() != "")
    assert(address_1.address() != None)


# Generated at 2022-06-25 20:22:24.953436
# Unit test for method address of class Address
def test_Address_address():
    print("Running address test case...")
    address_0 = Address()
    my_address = address_0.address()
    print(my_address)
    assert "\n" not in my_address
    assert isinstance(my_address, str)



# Generated at 2022-06-25 20:22:27.234853
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert isinstance(result_0, str)
