

# Generated at 2022-06-25 20:18:43.301382
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()

# Generated at 2022-06-25 20:18:45.682662
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()
    assert address.address()


# Generated at 2022-06-25 20:18:47.176351
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:48.776582
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=None)
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:50.667479
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    str_1 = address_1.address()
    assert isinstance(str_1, str)
    

# Generated at 2022-06-25 20:18:52.187320
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:18:56.198600
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == "1869 John Crooks Avenue"
    assert address_0.address() == "372 Henderson Road"
    assert address_0.address() == "1314 Bulah Road"
    assert address_0.address() == "5056 Korner Drive"
    assert address_0.address() == "5251 Goyette Place"
    assert address_0.address() == "3174 Silver Street"
    assert address_0.address() == "9309 Tikhonov Terrace"
    assert address_0.address() == "4660 Cooper Circle"
    assert address_0.address() == "9448 Allard Road"
    assert address_0.address() == "6100 Cornell Avenue"
    assert address_0.address() == "4865 Richard Avenue"
    assert address_0

# Generated at 2022-06-25 20:19:00.454822
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert str_0 is not None
    assert type(str_0) is str



# Generated at 2022-06-25 20:19:02.914866
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    print(str_0)



# Generated at 2022-06-25 20:19:04.234870
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    str = address.address()


# Generated at 2022-06-25 20:19:13.254062
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('en')
    assert type(addr.address()) is str


# Generated at 2022-06-25 20:19:19.923601
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    arg_0 = address_0.address()
    arg_1 = address_0.address()
    arg_2 = address_0.address()
    arg_3 = address_0.address()
    arg_4 = address_0.address()
    arg_5 = address_0.address()
    arg_6 = address_0.address()
    arg_7 = address_0.address()
    arg_8 = address_0.address()
    arg_9 = address_0.address()
    arg_10 = address_0.address()
    arg_11 = address_0.address()
    arg_12 = address_0.address()
    arg_13 = address_0.address()
    arg_14 = address_0.address()
    arg_15 = address_0.address()

# Generated at 2022-06-25 20:19:21.559724
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    print(result)


# Generated at 2022-06-25 20:19:23.689475
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.address()


# Generated at 2022-06-25 20:19:25.869470
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() == "200 E. 6th Street"


# Generated at 2022-06-25 20:19:29.140217
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()



# Generated at 2022-06-25 20:19:36.615018
# Unit test for method address of class Address
def test_Address_address():
    # 0. Default locale is 'en'
    address = Address()
    assert ' ' not in address.address()

    # 1. Check result with 'de'
    address.set_locale('de')
    assert ' ' not in address.address()

    # 2. Check result with 'ja'
    address.set_locale('ja')
    assert ' ' not in address.address()


# Generated at 2022-06-25 20:19:42.565598
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address() # Create a object address_0 of class Address
    print("address_0.address():")
    print(address_0.address())
    assert  isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:47.379001
# Unit test for method address of class Address
def test_Address_address():
    print('Testing address')
    address_0 = Address()
    address_0.address()
    address_0.address()
    address_0.address()
    address_0.address()
    address_0.address()
    pass


# Generated at 2022-06-25 20:19:51.134627
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:20:10.881353
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(locale='en-US')
    address_2 = Address(locale='ru')
    address_3 = Address(locale='ja')
    address_4 = Address()
    address_5 = Address(locale='en-US')
    address_6 = Address(locale='ru')
    address_7 = Address(locale='ja')
    address_8 = Address()
    address_9 = Address(locale='en-US')
    address_10 = Address(locale='ru')
    address_11 = Address(locale='ja')
    address_12 = Address()
    address_13 = Address(locale='en-US')
    address_14 = Address(locale='ru')
    address_15 = Address(locale='ja')
    address_

# Generated at 2022-06-25 20:20:13.549812
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-25 20:20:14.918054
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    print("result: " + str(result))

# Generated at 2022-06-25 20:20:16.745139
# Unit test for method address of class Address
def test_Address_address():
    for i in range(10):
        # print("address: " + str(Address.address()))
        print("address: " + str(Address.address()))

# test_Address_address()


# Generated at 2022-06-25 20:20:19.708493
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=0)
    address_1 = Address(seed=1)
    address_2 = Address(seed=2)
    assert address_0.address() == "1288 S. Park Avenue"
    assert address_1.address() == "1370 Cityview Avenue"
    assert address_2.address() == "1323 Rainsford Avenue"


# Generated at 2022-06-25 20:20:22.527538
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:20:27.655933
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    a = address_0.address()
    assert a is not None



# Generated at 2022-06-25 20:20:29.952495
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en')
    assert re.search(r'\d{1,4} \w+ \w+', address_1.address())


# Generated at 2022-06-25 20:20:32.992000
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:20:38.553340
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    #_iterate_method(address_0, 'address', 100)
    for _iter in range(100):
        address_0.address()


# Generated at 2022-06-25 20:20:51.132913
# Unit test for method address of class Address
def test_Address_address():
    # Arrange
    address_0 = Address()

    # Act
    actual_0 = address_0.address()

    # Assert
    assert isinstance(actual_0, str)


# Generated at 2022-06-25 20:20:53.943412
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    address.address()
    


# Generated at 2022-06-25 20:20:59.489601
# Unit test for method address of class Address
def test_Address_address():
    try:
        N = int(input("Enter number of test case: "))
        for i in range(N):
            test_case_0()
    except Exception as err:
        print(err)

# Generated at 2022-06-25 20:21:01.798538
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:21:04.141202
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() in ['{st_num} {st_name}', '{st_num} {st_name} {st_sfx}']


# Generated at 2022-06-25 20:21:06.532748
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    assert isinstance(address, str)


# Generated at 2022-06-25 20:21:17.453562
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en')
    street_number_1 = address_1.street_number()
    street_name_1 = address_1.street_name()
    street_suffix_1 = address_1.street_suffix()
    address_1 = address_1.address()
    street_number_2 = address_1.street_number()
    street_name_2 = address_1.street_name()
    street_suffix_2 = address_1.street_suffix()
    address_2 = address_1.address()
    street_number_3 = address_1.street_number()
    street_name_3 = address_1.street_name()
    street_suffix_3 = address_1.street_suffix()
    address_3 = address_1.address()


# Generated at 2022-06-25 20:21:27.125416
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == "221B Baker Street"
    address_0 = Address(locale='en')
    assert address_0.address() == "1122 Main Road"
    address_0 = Address(locale='ru')
    assert address_0.address() == "проспект Мира, д. 99"
    address_0 = Address(locale='uk')
    assert address_0.address() == "вул. Васильківська, буд. 11"
    address_0 = Address(locale='ja')
    assert address_0.address() == "東京都江東区江東1-11-11"

#

# Generated at 2022-06-25 20:21:31.960367
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result_1 = address_1.address()
    assert isinstance(result_1, str)
    assert len(result_1) > 0


# Generated at 2022-06-25 20:21:33.615506
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != None
    assert address_0.address() != address_0.address()


# Generated at 2022-06-25 20:21:45.328793
# Unit test for method address of class Address
def test_Address_address():
    # Instance of Address.
    address_0 = Address()

    # Generate 100 random address.
    assert all([type(address_0.address()) is str for _ in range(100)])



# Generated at 2022-06-25 20:21:49.769531
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(seed=None)
    print(address_1.address())
    print(type(address_1.address()))


# Generated at 2022-06-25 20:21:52.807558
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:21:54.177214
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '1658 Ferguson Road'

# Generated at 2022-06-25 20:21:55.521156
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:22:00.490889
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    fmt = address_0.address()
    assert len(fmt) == len('123 Street Name Street Suffix')


# Generated at 2022-06-25 20:22:02.172553
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    print(Address().address())
    print(Address(CountryCode.A2).address())

# Generated at 2022-06-25 20:22:04.168788
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.address()


# Generated at 2022-06-25 20:22:06.496911
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('en')
    result = provider.address()
    assert type(result) == str


# Generated at 2022-06-25 20:22:08.966074
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='zh')
    address_1.address()


# Generated at 2022-06-25 20:22:19.348385
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    val = address_0.address()


# Generated at 2022-06-25 20:22:24.109673
# Unit test for method address of class Address
def test_Address_address():
    country_0 = Address()
    abbr = country_0.country_code(CountryCode.A2)
    full = country_0.country_code(CountryCode.A3)
    print(abbr, full)

# Generated at 2022-06-25 20:22:26.662309
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed=0)
    assert address.address() == '383515 262 Rue Donnellyville'


# Generated at 2022-06-25 20:22:28.608871
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:22:30.486960
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()

# Generated at 2022-06-25 20:22:34.654285
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    assert len(address_0.address()) > 0



# Generated at 2022-06-25 20:22:41.280557
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '1184 Muehlenkamp Vista'
    assert Address(locale='ru').address() == 'Песчаная улица, 78'
    assert Address(locale='de').address() == 'Viktoriastr. 37'
    assert Address(locale='en-CA').address() == 'Suite 582 485 Langley Station'
    assert Address(locale='en-GB').address() == 'Suite 582 485 Langley Station'
    assert Address(locale='en-US').address() == 'Suite 582 485 Langley Station'
    assert Address(locale='es').address() == 'Suite 582 485 Langley Station'
    assert Address(locale='pt').address() == 'Suite 603 757 George Junction'

# Generated at 2022-06-25 20:22:47.723796
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert(result_0 == '2041 St. Wendy Ramp, New Scottshire, Arizona, 58574')
    

# Generated at 2022-06-25 20:22:52.441703
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(seed=0)
    assert address_1.address() == "770 Rue de Montréal"
    address_2 = Address(seed=0)
    assert address_2.address() == "770 Rue de Montréal"
    address_3 = Address(seed=1590953372)
    assert address_3.address() == "471 Rue des Ardennes"
    # test data of japanese version
    address_4 = Address(seed=0, locale='ja')
    assert address_4.address() == "宮城県仙台市青葉区神宮町４６−７７"


# Generated at 2022-06-25 20:22:54.641114
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())



# Generated at 2022-06-25 20:23:18.274562
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    value_address_0 = address_0.address()
    assert type(value_address_0) == str


# Generated at 2022-06-25 20:23:33.924547
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    
    def method_0(address_0: Address):
        assert address_0.address()
    address_0.address = method_0
    address_0.address()
    
    def method_1(address_0: Address):
        assert address_0.address()
    address_0.address = method_1
    address_0.address()
    
    def method_2(address_0: Address):
        assert address_0.address()
    address_0.address = method_2
    address_0.address()
    
    def method_3(address_0: Address):
        assert address_0.address()
    address_0.address = method_3
    address_0.address()
    
    def method_4(address_0: Address):
        assert address_

# Generated at 2022-06-25 20:23:34.831259
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())

# Generated at 2022-06-25 20:23:38.235997
# Unit test for method address of class Address
def test_Address_address():
    for i in range(0, 100):
        address_0 = Address()
        assert len(address_0.address()) > 0
        # print(address_0.address())



# Generated at 2022-06-25 20:23:40.556391
# Unit test for method address of class Address
def test_Address_address():
    assert (len(Address().address()) > 0)


# Generated at 2022-06-25 20:23:44.291761
# Unit test for method address of class Address
def test_Address_address():
    unit_test = Address(locale='en')
    result = unit_test.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:23:47.123432
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:23:48.421225
# Unit test for method address of class Address
def test_Address_address():
    assert Address.address('en') != None, "Address.address() fails"


# Generated at 2022-06-25 20:23:52.444382
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='pt')
    # address() # should returns a string
    assert isinstance(address_1.address(), str)


# Generated at 2022-06-25 20:23:54.906080
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:24:20.251049
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:24:25.409152
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    if Address.address not in Address.__dict__:
        raise NotImplementedError(
            "Class Address has no attribute 'address'"
        )


# Generated at 2022-06-25 20:24:28.944538
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0 = Address(locale='en')
    address_0 = Address(locale='ru')
    address_0 = Address(locale='zh')
    address_0 = Address(locale='ja')
    address_0 = Address(locale='es')
    address_0 = Address(locale='de')


# Generated at 2022-06-25 20:24:39.603394
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0_expected = '983 Cierra Course'
    address_0_actual = address_0.address()
    assert address_0_actual == address_0_expected
    address_1 = Address()
    address_1_expected = '3 二本松町'
    address_1_actual = address_1.address()
    assert address_1_actual == address_1_expected
    address_2 = Address()
    address_2_expected = '5300 Ленинградская улица'
    address_2_actual = address_2.address()
    assert address_2_actual == address_2_expected
    address_3 = Address()

# Generated at 2022-06-25 20:24:44.126634
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    try:
        address_0.address()
    except:
        raise AssertionError("Unexpected error!")


# Generated at 2022-06-25 20:24:45.073060
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != None


# Generated at 2022-06-25 20:24:48.857990
# Unit test for method address of class Address
def test_Address_address():
    address_address = Address().address()
    assert type(address_address) is str, "address should return a string"


# Generated at 2022-06-25 20:24:52.315001
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address_str = address.address()
    assert isinstance(address_str, str)
    return address_str 



# Generated at 2022-06-25 20:24:54.793680
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result = address_1.address()
    assert len(result) <= 65


# Generated at 2022-06-25 20:24:58.640345
# Unit test for method address of class Address
def test_Address_address():
    address = Address("en")
    for i in range(0, 100):
        assert(type(address.address()) == str)


# Generated at 2022-06-25 20:25:31.544919
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address_0 = address.address()
    assert address_0 is not None


# Generated at 2022-06-25 20:25:35.158826
# Unit test for method address of class Address
def test_Address_address():
    address = Address('ru')
    addresses = [address.address() for _ in range(0, 1000)]
    assert len(addresses) == 1000


# Generated at 2022-06-25 20:25:36.374983
# Unit test for method address of class Address
def test_Address_address():
    assert isinstance(Address().address(), str)

# Generated at 2022-06-25 20:25:38.300800
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    value_0 = address_0.address()
    assert(isinstance(value_0, str))


# Generated at 2022-06-25 20:25:39.644774
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:25:42.463481
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:25:52.137118
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=0)
    s_0 = address_0.address()
    assert s_0 == '4754 Aspen Court'
    s_1 = address_0.address()
    assert s_1 == '2445 West Irving Park Road'
    s_2 = address_0.address()
    assert s_2 == '850 South Oakley Boulevard'
    s_3 = address_0.address()
    assert s_3 == '6176 Diversey Avenue'
    s_4 = address_0.address()
    assert s_4 == '4139 North Mobile Avenue'
    s_5 = address_0.address()
    assert s_5 == '6967 North Seeley Avenue'
    s_6 = address_0.address()
    assert s_6 == '8146 South Whipple Street'
   

# Generated at 2022-06-25 20:25:54.866694
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    addr = address_1.address()
    print('Addr: %s' % addr)


# Generated at 2022-06-25 20:25:56.757662
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address('ru')
    assert address_0.address() != address_1.address()


# Generated at 2022-06-25 20:26:05.957061
# Unit test for method address of class Address
def test_Address_address():
    expected_result = 'Каштановая Площадь, 14'
    assert expected_result == Address().address()


# Generated at 2022-06-25 20:27:12.318317
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-25 20:27:13.149517
# Unit test for method address of class Address
def test_Address_address():
    address_addr = Address()
    address_addr.address()



# Generated at 2022-06-25 20:27:14.992874
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('en')
    address_2 = Address('en')
    assert address_1.address() == address_2.address()


# Generated at 2022-06-25 20:27:19.187074
# Unit test for method address of class Address
def test_Address_address():
    # Global variables
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    # Invoking address() method
    address_0.address()
    address_1.address()
    address_2.address()
    address_3.address()
    address_4.address()


# Generated at 2022-06-25 20:27:20.047678
# Unit test for method address of class Address
def test_Address_address():
    Address().address()


# Generated at 2022-06-25 20:27:22.186639
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:27:24.581692
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    assert callable(address_0.address)
    assert address_0.address() != address_1.address()


# Generated at 2022-06-25 20:27:30.780477
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    # cn, de, ja, ru
    assert address.address() in [
        'Caijingtongguan, Room 804, Building A, No. 18, South Street, Shinan District, Qingdao',
        '18/09/15, 1st floor, Hosharafa Lane, Nizamuddin West, New Delhi, 110013',
        '3-6-1, Kyobashi, Chuo, Tokyo',
        'ул. Котляковская, д. 12, стр. 1, кв. 5, Москва, Россия, 115035',
    ]


# Generated at 2022-06-25 20:27:38.626008
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    exp = r'\d{1,3}'
    assert address.street_number() is not None
    assert re.match(exp, address.street_number())
    exp = '\D{0,30}'
    assert address.street_name() is not None
    assert re.match(exp, address.street_name())
    exp = '\D{0,20}'
    assert address.street_suffix() is not None
    assert re.match(exp, address.street_suffix())

# Generated at 2022-06-25 20:27:40.889434
# Unit test for method address of class Address
def test_Address_address():
    address_val = '1000 仙台市青葉区国分町'
    address_1 = Address('ja')
    assert (address_1.address() == address_val)

