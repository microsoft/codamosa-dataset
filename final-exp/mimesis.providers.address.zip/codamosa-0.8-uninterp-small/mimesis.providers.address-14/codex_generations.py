

# Generated at 2022-06-25 20:18:32.114838
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str), 'Address.address() is not string'



# Generated at 2022-06-25 20:18:33.456839
# Unit test for method address of class Address
def test_Address_address():
    address = Address.address()
    assert address is not None


# Generated at 2022-06-25 20:18:34.984406
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:18:36.795183
# Unit test for method address of class Address
def test_Address_address():
    _address = Address()
    for _ in range(50):
        _address.address()


# Generated at 2022-06-25 20:18:37.966913
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()



# Generated at 2022-06-25 20:18:39.853212
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:18:41.680602
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    for _ in range(10):
        print(address.address())


# Generated at 2022-06-25 20:18:45.262136
# Unit test for method address of class Address
def test_Address_address():
    address1 = Address('ru')
    assert address1.address().find('ул') > -1
    address2 = Address('be')
    assert address2.address().find('вул') > -1
    address3 = Address('ua')
    assert address3.address().find('вул') > -1


# Generated at 2022-06-25 20:18:46.880506
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == "126 Park Street"

# Generated at 2022-06-25 20:18:47.760852
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())

# Generated at 2022-06-25 20:18:51.985160
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:18:52.757227
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''


# Generated at 2022-06-25 20:18:57.195870
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address(seed=10)
    address_1 = Address(seed=10)

    # Test the function address with arguments: None
    result = address_0.address()
    control = '13-й ноябрьский проезд'
    assert result == control

    # Test the function address with arguments: None
    result = address_1.address()
    control = '6 Советская улица'
    assert result == control

    # Test the function address with arguments: None
    result = address_0.address()
    control = 'Набережная улица'
    assert result == control

    # Test the function address with arguments: None
    result

# Generated at 2022-06-25 20:18:58.856567
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result_1 = address_1.address()
    length_1 = len(result_1)

    assert(length_1 < 100)


# Generated at 2022-06-25 20:19:00.948391
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert(isinstance(address_0.address(), str))


# Generated at 2022-06-25 20:19:01.904685
# Unit test for method address of class Address
def test_Address_address():
    assert isinstance(Address().address(), str)

# Generated at 2022-06-25 20:19:10.356144
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(locale='ru')
    address_2 = Address(locale='zh_CN')
    address_3 = Address(locale='ja')
    assert address_0.address() in [
        '{st_num} {st_name}',
        '{st_num} {st_name} {st_sfx}',
        '91830 {st_name}',
        '91830 {st_name} {st_sfx}',
        '954 {st_name}',
        '954 {st_name} {st_sfx}',
    ]

# Generated at 2022-06-25 20:19:15.274710
# Unit test for method address of class Address
def test_Address_address():
    import re
    address1 = Address()
    address2 = Address()
    for i, address in enumerate(re.finditer(r"[,]+", address1.address())):
        if i == 2 or i == 3:
            assert address
    for i, address in enumerate(re.finditer(r"[,]+", address2.address())):
        if i == 2 or i == 3:
            assert address



# Generated at 2022-06-25 20:19:18.538278
# Unit test for method address of class Address
def test_Address_address():
    address_ = Address()
    address = address_.address()
    assert isinstance(address, str)
    pass


# Generated at 2022-06-25 20:19:23.461555
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert '\n' not in address_0.address()
    assert ' ' in address_0.address()
    assert len(address_0.address()) > 0



# Generated at 2022-06-25 20:19:32.194767
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:19:34.401157
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result = address_1.address()
    print(result)


# Generated at 2022-06-25 20:19:36.849617
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    expected = "12 Main Street"
    actual = address_0.address()
    assert actual == expected


# Generated at 2022-06-25 20:19:39.067443
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:19:42.863820
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for _ in range(1000):
        address.address()
        assert address.address()  # is not None


# Generated at 2022-06-25 20:19:44.008948
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='en')
    address_0.address()


# Generated at 2022-06-25 20:19:46.230840
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:19:47.490281
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:19:54.280576
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.utils import lazy_test_runner
    from threading import Thread

    th_0 = Thread(target=test_case_0)
    th_0.start()


if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-25 20:19:57.779834
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert len(result) > 0, "Address.address() returned a wrong result: " + result


# Generated at 2022-06-25 20:20:16.094745
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == "120 W Oak St"


# Generated at 2022-06-25 20:20:17.654597
# Unit test for method address of class Address
def test_Address_address():
    pass


# Generated at 2022-06-25 20:20:19.662901
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('en')

    assert address_0.address() is not None


# Generated at 2022-06-25 20:20:24.486355
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # Assert method address of class Address is defined
    assert(hasattr(address_0, 'address'))


# Generated at 2022-06-25 20:20:26.723757
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-25 20:20:28.416159
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert len(address_1.address()) == 11


# Generated at 2022-06-25 20:20:32.192273
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    street_number = adr.street_number()
    street_name = adr.street_name()
    street_suffix = adr.street_suffix()
    address = adr.address()
    assert isinstance(address, str)
    print(address)
    assert address.endswith(street_suffix)


# Generated at 2022-06-25 20:20:36.917383
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    assert isinstance(address_0.address(), str) == True
    assert len(address_0.address()) > 0


# Generated at 2022-06-25 20:20:39.262264
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '1400 Rue Bugeaud'


# Generated at 2022-06-25 20:20:42.618813
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert re.match(r"[0-9]+ [a-zA-Z]+ [a-zA-Z]+", address_1.address())


# Generated at 2022-06-25 20:21:25.811509
# Unit test for method address of class Address
def test_Address_address():
    # Case 0: Locale = DE, allow_random = False
    address_0 = Address('DE')
    # print('address_0:', address_0.address())

    # Case 1: Locale = ZH_CN, allow_random = False
    address_1 = Address('ZH_CN')
    # print('address_1:', address_1.address())

    # Case 2: Locale = ZH, allow_random = False
    address_2 = Address('ZH')
    # print('address_2:', address_2.address())

    # Case 3: Locale = RU, allow_random = False
    address_3 = Address('RU')
    # print('address_3:', address_3.address())

    # Case 4: Locale = ES, allow_random = False
    address_4 = Address

# Generated at 2022-06-25 20:21:32.469426
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert 0 == len(address_0.address())
    assert 0 == len(address_0.address())
    assert 0 == len(address_0.address())
    assert 0 == len(address_0.address())
    assert 0 == len(address_0.address())


# Generated at 2022-06-25 20:21:35.279950
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0_address = address_0.address()
    assert isinstance(address_0_address, str)


# Generated at 2022-06-25 20:21:40.622831
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    try:
        address_0.address()
    except Exception as e:
        assert False, 'Exception thrown in method address: ' + str(e)



# Generated at 2022-06-25 20:21:43.294204
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:21:45.468177
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address().address()
    assert isinstance(address_1, str)
    print(address_1)


# Generated at 2022-06-25 20:21:47.105860
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:21:49.545995
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:21:51.165949
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != Address().address()



# Generated at 2022-06-25 20:21:54.541425
# Unit test for method address of class Address
def test_Address_address():
    extent = 100
    address_0 = Address()
    for i in range(extent):
        address_0.address()


# Generated at 2022-06-25 20:22:42.110570
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result_0 = address.address()
    assert isinstance(result_0, str)
    result_1 = address.address()
    assert isinstance(result_1, str)
    result_2 = address.address()
    assert isinstance(result_2, str)


# Generated at 2022-06-25 20:22:47.723529
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    test_Address_address_var_0 = address_0.address()
    print(test_Address_address_var_0)



# Generated at 2022-06-25 20:22:50.617290
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()
    address_0.address()


# Generated at 2022-06-25 20:22:54.491230
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    assert(
        isinstance(address_0.address(), str)
    )


# Generated at 2022-06-25 20:22:57.908913
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != address_0.address()
    assert address_0.address() != None
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:23:02.143331
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    out = address_0.address()
    assert isinstance(out, str)
    assert len(out) > 0


# Generated at 2022-06-25 20:23:03.578793
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    string_0 = address_0.address()
    assert (len(string_0) > 0)

# Generated at 2022-06-25 20:23:08.913858
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:23:11.062215
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    # Test for method address of class Address
    assert_value = '932 W. Page Blvd'
    actual_value = address.address()
    assert assert_value == actual_value, 'Not expected value'


# Generated at 2022-06-25 20:23:12.820288
# Unit test for method address of class Address
def test_Address_address():
    a1 = Address('ru')
    a2 = Address('en')
    a3 = Address('tk')
    assert a1.address()
    assert a2.address()
    assert a3.address()


# Generated at 2022-06-25 20:24:52.455058
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    func_name = 'address'
    result = provider.address()
    assert result is not None


# Generated at 2022-06-25 20:24:55.516157
# Unit test for method address of class Address
def test_Address_address():
    locale_0 = 'uk'
    address_0 = Address(locale=locale_0)
    result_0 = address_0.address()
    print(result_0)


# Generated at 2022-06-25 20:24:59.939397
# Unit test for method address of class Address
def test_Address_address():
    '''
    Runs test for the method address of class Address
    '''

    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:25:04.945177
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en')
    address_2 = Address(locale='en')
    address_3 = Address(locale='en')
    assert address_1.address()
    assert address_2.address()
    assert address_3.address()


# Generated at 2022-06-25 20:25:08.537668
# Unit test for method address of class Address
def test_Address_address():
    print("\n\nTesting Address: Address")
    address_1 = Address(locale=None)
    print(address_1.address())


# Generated at 2022-06-25 20:25:13.864862
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert result_0 != None
    assert result_0 != ''
    assert result_0 != ' '


# Generated at 2022-06-25 20:25:15.780171
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    full_address = ad.address()
    assert isinstance(full_address, str)
    assert full_address != ''


# Generated at 2022-06-25 20:25:20.237587
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0_address_0 = address_0.address()
    assert len(address_0_address_0) > 10



# Generated at 2022-06-25 20:25:24.898757
# Unit test for method address of class Address
def test_Address_address():
    # This is the method's body
    address_0 = Address()
    assert address_0.street_number() >= 1
    assert address_0.street_number(maximum=0) < 1400


# Generated at 2022-06-25 20:25:26.327083
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()
    address_0.address()

