

# Generated at 2022-06-25 20:18:30.502244
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:31.821485
# Unit test for method address of class Address
def test_Address_address():
    random = Address()
    address = random.address()


# Generated at 2022-06-25 20:18:33.616032
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:35.427293
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert(type(str_0) == str)


# Generated at 2022-06-25 20:18:37.563517
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    print(str_0)


# Generated at 2022-06-25 20:18:38.886333
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None

# Generated at 2022-06-25 20:18:39.702547
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '123 Test Street'


# Generated at 2022-06-25 20:18:41.883294
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    str_1 = address_1.address()
    assert str_1 != None



# Generated at 2022-06-25 20:18:51.508680
# Unit test for method address of class Address
def test_Address_address():
    import unittest
    from unittest import mock
    from . import Address

    # Mock data for Address.random.choice
    mock_address_choice = mock.MagicMock(return_value='a')
    Address.random.choice = mock_address_choice

    # Mock data for Address.street_number
    mock_address_street_number = mock.MagicMock(return_value='a')
    Address.street_number = mock_address_street_number

    # Mock data for Address.street_suffix
    mock_address_street_suffix = mock.MagicMock(return_value='a')
    Address.street_suffix = mock_address_street_suffix

    address_0 = Address()
    # Asserting that the value of address_0 is equal to a

# Generated at 2022-06-25 20:18:52.653169
# Unit test for method address of class Address
def test_Address_address():
    # Test case 0
    address_0 = Address()
    str_0 = address_0.address()
    assert str_0 == "095 Ritter Creek"

# Generated at 2022-06-25 20:18:56.868002
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() is not None
    assert Address().address() is str


# Generated at 2022-06-25 20:18:59.465114
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address."""
    provider = Address()
    assert provider.address()


# Generated at 2022-06-25 20:19:01.899483
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()

test_case_0(test_Address_address)



# Generated at 2022-06-25 20:19:03.980774
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:07.113948
# Unit test for method address of class Address
def test_Address_address():
    gen = Address('en')
    # Test case for en locale
    for _ in range(10):
        result = gen.address()
        assert type(result) == str
        assert len(result) != 0


# Generated at 2022-06-25 20:19:10.225388
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '419-118 Cutler Ridge Suite 424'


# Generated at 2022-06-25 20:19:16.055553
# Unit test for method address of class Address
def test_Address_address():
    """Test Address() address()."""
    address_0 = Address()

    assert len(address_0.address()) > 0
    assert len(address_0.address()) > 0
    assert len(address_0.address()) > 0
    assert len(address_0.address()) > 0
    assert len(address_0.address()) > 0



# Generated at 2022-06-25 20:19:17.723509
# Unit test for method address of class Address
def test_Address_address():
    for i in range(100, 120):
        print(Address().address())


# Generated at 2022-06-25 20:19:19.598760
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address_d = address.address()
    assert type(address_d) == str


# Generated at 2022-06-25 20:19:23.000259
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0_address = address_0.address()
    print(address_0_address)



# Generated at 2022-06-25 20:19:30.998012
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('zh')
    for _ in range(10):
        result = address_0.address()
        assert '中国' in result


# Generated at 2022-06-25 20:19:33.744088
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.seed(0)
    assert address_0.address() == "3118 Rue Leon-Papin"


# Generated at 2022-06-25 20:19:34.983530
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(),str)


# Generated at 2022-06-25 20:19:36.779945
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)

# Generated at 2022-06-25 20:19:39.079635
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()



# Generated at 2022-06-25 20:19:42.865893
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert callable(address.address)
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:19:45.142045
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) > 0


# Generated at 2022-06-25 20:19:47.157210
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    assert address_0.address() != None
    assert address_0.address() != ' '


# Generated at 2022-06-25 20:19:59.862544
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='ar-sa')

# Generated at 2022-06-25 20:20:01.988131
# Unit test for method address of class Address
def test_Address_address():
    for i in range(10):
        assert address.address()


# Generated at 2022-06-25 20:20:13.146981
# Unit test for method address of class Address
def test_Address_address():
    """ Unit test for method address of class Address """
    address_0 = Address('zh')
    assert type(address_0.address()) == str
    address_1 = Address('zh', seed=1337)
    assert address_1.address() == '吉林省龙潭区国际大道1542号'
    assert address_0.address() == address_1.address()
    address_2 = Address('zh', seed=1337)
    assert address_2.address() == address_0.address()
    address_2.set_seed(1337)
    assert address_0.address() == address_2.address()
    address_0.set_seed(1338)
    assert address_0.address() != address_2.address()


# Generated at 2022-06-25 20:20:17.148878
# Unit test for method address of class Address
def test_Address_address():
    # Initializing Address object
    address_0 = Address()
    # Getting address
    address = address_0.address()
    assert address is not None


# Generated at 2022-06-25 20:20:19.017329
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)


# Generated at 2022-06-25 20:20:22.789563
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert result


# Generated at 2022-06-25 20:20:27.300470
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:20:28.959550
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())
    pass


# Generated at 2022-06-25 20:20:33.045042
# Unit test for method address of class Address
def test_Address_address():

    address_1 = Address()
    address_2 = Address(locale="ru")
    address_3 = Address(locale="ja")

    print("Address_address_1")
    assert isinstance(address_1.address(), str)
    print("Address_address_2")
    assert isinstance(address_2.address(), str)
    print("Address_address_3")
    assert isinstance(address_3.address(), str)


# Generated at 2022-06-25 20:20:37.073522
# Unit test for method address of class Address
def test_Address_address():
    name = "Address().address()"
    address = Address()
    result = address.address()
    assert(result!=None)


# Generated at 2022-06-25 20:20:40.197585
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:20:45.823866
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(
        'en'
    )
    address_1.address() # STREET_NUMBER STREET_NAME STREET_SFX APT CITY STATE

    address_2 = Address(
        'de'
    )
    address_2.address() # STREET_NUMBER STREET_NAME CITY POSTAL_CODE

    address_3 = Address(
        'ru'
    )
    address_3.address() # STREET_NUMBER STREET_NAME CITY POSTAL_CODE


# Generated at 2022-06-25 20:20:56.979433
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() == "7795 Bahnstraße"
    print(address_1.address())


# Generated at 2022-06-25 20:21:01.873731
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address() is not None
    address_2 = Address()
    assert address_1.address() is not address_2.address()


# Generated at 2022-06-25 20:21:03.934617
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    x = address_0.address()
    print(x)
    assert type(x) is str


# Generated at 2022-06-25 20:21:05.782230
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:21:07.770064
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()



# Generated at 2022-06-25 20:21:11.328913
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    res_0 = address_0.address()
    print(res_0)


# Generated at 2022-06-25 20:21:13.156461
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:21:15.681975
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:21:18.235999
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert len(address_0.address()) == 5


# Generated at 2022-06-25 20:21:25.051043
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    st_name = address_0.street_name()
    st_num = address_0.street_number()
    st_suffix = address_0.street_suffix()
    address_str = address_0.address()
    assert (st_name in address_str) and (st_num in address_str) and (st_suffix in address_str), "failed test_address"


# Generated at 2022-06-25 20:21:43.454151
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('en')
    result_1 = address_1.address()
    assert(isinstance(result_1, str))
    assert(len(result_1.splitlines()) == 1)


# Generated at 2022-06-25 20:21:44.958237
# Unit test for method address of class Address
def test_Address_address():
    assert type(Address.address(Address())) == str


# Generated at 2022-06-25 20:21:47.369094
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:21:56.697785
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    st_num = address_0.street_number()
    st_name = address_0.street_name()
    st_sfx = address_0.street_suffix()
    address = address_0.address()
    if address_0.locale in SHORTENED_ADDRESS_FMT:
        assert f'{st_num} {st_name}' in address
    else:
        assert f'{st_sfx} {st_name}' in address


# Generated at 2022-06-25 20:21:59.333929
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:22:02.023558
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:22:07.392532
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='en')
    result = address_0.address()
    # Assert address_0 is a valid address
    assert type(result) == str
    assert 'str' in str(type(result))
    assert 'Street' in result
    assert result[0].isdigit()


# Generated at 2022-06-25 20:22:16.358481
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    address_5 = Address()

    assert address_1.address() == 'آزادی، 38-27'
    assert address_2.address() == 'Calle del Prado, 12'
    assert address_3.address() == 'пр-кт Независимости, 56'
    assert address_4.address() == 'Rua Joaquim Silvério dos Santos Filho, 453'
    assert address_5.address() == 'Av. Santa Júlia, 113'



# Generated at 2022-06-25 20:22:19.837456
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()

    address_0.address()
    address_1.address()


# Generated at 2022-06-25 20:22:22.731828
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr = address.address()
    assert len(addr) > 0


# Generated at 2022-06-25 20:22:40.287493
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str) == True


# Generated at 2022-06-25 20:22:47.859957
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('uk')
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())

# test_case_0()
# test_Address_address()

# Generated at 2022-06-25 20:22:49.395294
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1_add = address_1.address()
    assert type(address_1_add) is str


# Generated at 2022-06-25 20:22:57.232894
# Unit test for method address of class Address
def test_Address_address():
    # locale = en
    address_en = Address(locale='en')
    assert(bool(address_en.address()))
    # locale = pl
    address_pl = Address(locale='pl')
    assert(bool(address_pl.address()))
    # locale = ja
    address_ja = Address(locale='ja')
    assert(bool(address_ja.address()))


# Generated at 2022-06-25 20:23:01.447094
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert type(result) == str


# Generated at 2022-06-25 20:23:11.391604
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    address_5 = Address()
    address_6 = Address()
    address_7 = Address()
    address_8 = Address()
    address_9 = Address()
    address_10 = Address()
    address_11 = Address()
    address_12 = Address()
    address_13 = Address()
    address_14 = Address()
    address_15 = Address()
    address_16 = Address()
    address_17 = Address()
    address_18 = Address()
    address_19 = Address()
    # print(address_0.address())
    # print(address_1.address())
    # print(address_2.address())
    # print(address_

# Generated at 2022-06-25 20:23:12.964839
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_str_0 = address_0.address()
    print(address_str_0)
    assert(isinstance(address_str_0, str))


# Generated at 2022-06-25 20:23:17.647903
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='en')
    assert type(address_0.address()) == str
    assert len(address_0.address()) >= 5
    assert len(address_0.address()) <= 35


# Generated at 2022-06-25 20:23:18.848300
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:23:22.466994
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != ""



# Generated at 2022-06-25 20:23:46.425925
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.address()


# Generated at 2022-06-25 20:23:47.706655
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() is not None


# Generated at 2022-06-25 20:24:07.126087
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    street_name = add.street_name()
    street_suffix = add.street_suffix()
    street_number = add.street_number()
    city = add.city()
    state = add.state()
    address = add.address()
    postal_code = add.postal_code()

    assert len(street_number) > 0
    assert len(street_name) > 0
    assert len(street_suffix) > 0
    assert len(city) > 0
    assert len(state) > 0
    assert len(address) > 0
    assert len(postal_code) > 0


# Generated at 2022-06-25 20:24:08.265475
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != address.address()


# Generated at 2022-06-25 20:24:11.682337
# Unit test for method address of class Address
def test_Address_address():
    # Create a new instance of Address class
    address_0 = Address()

    # Invoke a method of created instance
    address_0.address()


# Generated at 2022-06-25 20:24:13.486259
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()  # doesn't crash


# Generated at 2022-06-25 20:24:15.076066
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:24:16.476340
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:24:21.938408
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    try:
        print(address_0.address())
        print(address_0.address())
    except Exception as e:
        print(e)
        print(address_0.address())
        print(address_0.address())



# Generated at 2022-06-25 20:24:25.758172
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    result = address_obj.address()
    assert type(result) == str
    assert len(result) > 0


# Generated at 2022-06-25 20:25:04.672343
# Unit test for method address of class Address
def test_Address_address():
    get_address = Address()
    assert get_address.address() != '0'
    assert isinstance(get_address.address(), str)


# Generated at 2022-06-25 20:25:08.213068
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0 = Address()
    address_0 = Address()

    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:25:11.093701
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()
    assert address.address() is not None

# Generated at 2022-06-25 20:25:15.978475
# Unit test for method address of class Address
def test_Address_address():
    from _mimesis_testdata import AddressTestData
    from mimesis._utils import is_str

    address_0 = Address()
    for x in AddressTestData.address:
        assert is_str(address_0.address())
    assert is_str(address_0.address())
    address_1 = Address(locale='de')

    assert is_str(address_1.address())
    assert is_str(address_1.street_name())
    address_2 = Address(locale='uk')
    assert is_str(address_2.address())
    assert is_str(address_2.street_name())
    address_3 = Address(locale='es')
    assert is_str(address_3.address())
    assert is_str(address_3.street_name())

# Generated at 2022-06-25 20:25:28.043688
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('ru')

# Generated at 2022-06-25 20:25:35.768881
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()
    fmt = address._data['address_fmt']

    assert fmt.format(st_num=st_num, st_name=st_name, st_sfx=st_sfx)\
        in address.address()


# Generated at 2022-06-25 20:25:37.753246
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address.address()
    assert address_1 is not None


# Generated at 2022-06-25 20:25:38.854151
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()
    pass

# Generated at 2022-06-25 20:25:43.852985
# Unit test for method address of class Address
def test_Address_address():
    # Get 1000 random addresses
    for i in range(100):
        address = Address()
        rnd = address.address()
        assert address.street_number() in rnd
        assert address.street_name() in rnd
        assert address.street_suffix() in rnd


# Generated at 2022-06-25 20:25:45.734453
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address().__class__ is str


# Generated at 2022-06-25 20:26:28.647568
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert (len(address_0.address())>0)


# Generated at 2022-06-25 20:26:34.949116
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address(locale="ru")
    address_3 = Address(locale="ru")
    address_4 = Address(locale="ru")
    address_5 = Address(locale="ru")
    address_6 = Address(locale="ru")
    address_7 = Address(locale="ru")
    address_8 = Address(locale="ru")
    address_9 = Address(locale="ru")
    address_10 = Address(locale="ru")
    address_11 = Address(locale="ru")
    address_12 = Address(locale="ru")
    address_13 = Address(locale="ru")
    address_14 = Address(locale="ru")
    address_15 = Address(locale="ru")
   

# Generated at 2022-06-25 20:26:36.010486
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == '9007 Big Creek Crossing'


# Generated at 2022-06-25 20:26:37.176368
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-25 20:26:39.809466
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    if not isinstance(result, str):
        raise AssertionError("Expected {}, but got {}".format(str, type(result)))


# Generated at 2022-06-25 20:26:40.620636
# Unit test for method address of class Address
def test_Address_address():
    addr=Address()
    assert type(addr.address()) == str


# Generated at 2022-06-25 20:26:51.037595
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == "1827 George Mews"
    assert Address().address(locale='ar') == "شارع علي الوكيل شقة ضد مدرية المسابقة جدة"
    assert Address().address(locale='bg') == "ул. България № 15"
    assert Address().address(locale='ca') == "Avinguda de l'Estació, 15, 3"
    assert Address().address(locale='cs') == "Vinohradská, 31/22"
    assert Address().address(locale='en') == "1827 George Mews"

# Generated at 2022-06-25 20:26:54.699663
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    pattern = "^[0-9]{1,4} (.*) (Street|St|Ave|Avenue|Rd|Road|Dr|Drive|Blvd|Way|Crescent|Court)$"
    assert re.match(pattern, address.address()) is not None


# Generated at 2022-06-25 20:27:04.142640
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.tests.common import make_result_test

    with make_result_test(Address().address) as test:
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')
        test('#44-63 Strada Mare')


# Generated at 2022-06-25 20:27:05.655629
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    assert address_1.address() != address_2.address()


# Generated at 2022-06-25 20:27:45.418357
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address
    """
    assert Address().address() != ''


# Generated at 2022-06-25 20:27:46.316708
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:27:49.864125
# Unit test for method address of class Address
def test_Address_address():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    # Test case 0
    test_case_0()
    # Test method address of class Address
    test_Address_address()

# Generated at 2022-06-25 20:27:50.671410
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:27:52.161657
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    assert address_1 != address_2



# Generated at 2022-06-25 20:27:53.669094
# Unit test for method address of class Address
def test_Address_address():
    x=Address()
    r = x.address()
    #print(r)


# Generated at 2022-06-25 20:27:54.946559
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en')
    assert type(address_1.address()) == str


# Generated at 2022-06-25 20:27:55.730079
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != ""

# Generated at 2022-06-25 20:27:56.848719
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str) is True


# Generated at 2022-06-25 20:27:58.104396
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    final_value = address_0.address()
    assert isinstance(final_value, str)
