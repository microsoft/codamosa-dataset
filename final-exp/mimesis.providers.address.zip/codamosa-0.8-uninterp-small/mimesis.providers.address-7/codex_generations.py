

# Generated at 2022-06-25 20:18:32.596500
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    str_1 = address_1.address()
    assert isinstance(str_1, str)


# Generated at 2022-06-25 20:18:39.554557
# Unit test for method address of class Address
def test_Address_address():
    # 1st unit test
    address_0 = Address()
    str_0 = address_0.address()

    # 2nd unit test
    address_1 = Address()
    str_1 = address_1.address()

    # 3rd unit test
    address_2 = Address()
    str_2 = address_2.address()

    # 4th unit test
    address_3 = Address()
    str_3 = address_3.address()

    # 5th unit test
    address_4 = Address()
    str_4 = address_4.address()



# Generated at 2022-06-25 20:18:41.433095
# Unit test for method address of class Address
def test_Address_address():
    obj_0 = Address()
    str_0 = obj_0.address()


# Generated at 2022-06-25 20:18:42.906736
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != ""


# Generated at 2022-06-25 20:18:43.740515
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()



# Generated at 2022-06-25 20:18:46.266689
# Unit test for method address of class Address
def test_Address_address():
    """Test case for method address of class Address."""
    address_0 = Address()
    address_0.address()
    address_0.address()
    address_1 = Address(locale='ru')
    address_1.address()
    address_2 = Address(locale='zh')
    address_2.address()
    address_3 = Address(locale='pl')
    address_3.address()
    address_4 = Address(locale='ja')
    address_4.address()



# Generated at 2022-06-25 20:18:47.423251
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:50.382183
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for address() method of Address."""

    address_0 = Address()
    str_0 = address_0.address()
    assert len(str_0) > 0
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:18:51.586179
# Unit test for method address of class Address
def test_Address_address():
    address = Address().address()
    assert isinstance(address, str)



# Generated at 2022-06-25 20:18:52.266186
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-25 20:18:56.904315
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:18:58.593271
# Unit test for method address of class Address
def test_Address_address():
    # print(Address().address())

    address_1 = Address()
    print(address_1.address())

if __name__ == '__main__':

    test_Address_address()

# Generated at 2022-06-25 20:19:00.708425
# Unit test for method address of class Address
def test_Address_address():
    address_test = Address()
    assert address_test.address() is not None


# Generated at 2022-06-25 20:19:02.031225
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address.address()
    print(address_1)


# Generated at 2022-06-25 20:19:04.720708
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())


# Generated at 2022-06-25 20:19:08.165448
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address('en')
    assert address_1.address()


# Generated at 2022-06-25 20:19:10.711975
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:19.878796
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='en')
    assert address_0.address() == '927 E. James Mounds'
    address_1 = Address(locale='nl')
    assert address_1.address() == '927 E. James Mounds'
    address_2 = Address(locale='ja')
    assert address_2.address() == '927 E. James Mounds'

    address_3 = Address(locale='ja')
    assert len(address_3.address()) == 9

    address_4 = Address(locale='ru')
    assert address_4.address() == '927 E. James Mounds'

    address_5 = Address(locale='es')
    assert address_5.address() == '927 E. James Mounds'

    address_6 = Address(locale='it')


# Generated at 2022-06-25 20:19:21.004659
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:19:23.079516
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert type(addr.address()) == str


# Generated at 2022-06-25 20:19:31.800901
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_result_0 = address_0.address()
    # assert address_result_0 == 'Torremanzanas 641'


# Generated at 2022-06-25 20:19:35.486692
# Unit test for method address of class Address
def test_Address_address():
    print("Test Address address")
    address = Address() # address is the instance of class Address
    print(address.address())

test_Address_address()

# Generated at 2022-06-25 20:19:37.245249
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address("en")
    assert isinstance(address_1.address(), str)


# Generated at 2022-06-25 20:19:39.669860
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:47.908392
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    #print(f"Address.address(self) = {address_1.address()}")
    assert address_1.address() == "83 Maple St" or address_1.address() == "Ленина str. 7" or address_1.address() == "99, Rue des Coutures" or address_1.address() == "Ленина ул. 7"


# Generated at 2022-06-25 20:19:51.906348
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:19:54.692550
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    a = address.address()
    
    assert ' ' in a or '.' in a



# Generated at 2022-06-25 20:20:00.432687
# Unit test for method address of class Address
def test_Address_address():
    addr1 = Address('en')
    addr2 = Address('ru')
    addr3 = Address('ja')
    assert addr1.address() == 'k6y8U6cz (BZ) cHJpT9vY'
    assert addr2.address() == 'm3q3N8s3 (RW) 5g1nE1v2, S6h8U6xo'
    assert addr3.address() == '8U1nE1v2C1v2T9vY'


# Generated at 2022-06-25 20:20:03.196988
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) is str


# Generated at 2022-06-25 20:20:12.573609
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=0)
    data_0 = address_0.address()
    assert data_0 == "63 Blackbird Place"
    assert type(data_0) is str
    address_1 = Address(seed=1)
    data_1 = address_1.address()
    assert data_1 == "64 Clove Street"
    assert type(data_1) is str
    address_2 = Address(seed=2)
    data_2 = address_2.address()
    assert data_2 == "5 Miller Road"
    assert type(data_2) is str
    address_3 = Address(seed=3)
    data_3 = address_3.address()
    assert data_3 == "38 Franklin Avenue"
    assert type(data_3) is str

# Generated at 2022-06-25 20:20:22.918307
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) is str


# Generated at 2022-06-25 20:20:27.657166
# Unit test for method address of class Address
def test_Address_address():
    address_01 = Address()
    assert address_01.address().__class__ == str


# Generated at 2022-06-25 20:20:29.295221
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != ''


# Generated at 2022-06-25 20:20:43.828483
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(seed=116102)
    address_2 = Address(seed=122854)
    address_3 = Address(seed=131290)
    address_4 = Address(seed=129834)
    address_5 = Address(seed=124589)
    address_6 = Address(seed=108392)
    address_7 = Address(seed=110344)
    address_8 = Address(seed=111058)
    address_9 = Address(seed=102048)
    address_10 = Address(seed=121317)
    address_11 = Address(seed=107140)
    address_12 = Address(seed=130497)
    address_13 = Address(seed=109976)
    address_14 = Address(seed=121545)


# Generated at 2022-06-25 20:20:46.720877
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())




# Generated at 2022-06-25 20:20:50.812331
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address_example = address.address()

    assert(isinstance(address_example, str))
    assert(len(address_example) > 1)



# Generated at 2022-06-25 20:20:57.790620
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '3078 Jervis Street'
    assert address_0.address() == '2144 Nelson Avenue'
    assert address_0.address() == '4707 Makayla Center'
    assert address_0.address() == '52713 Hilll Pike'
    assert address_0.address() == '4482 Melissa Center'
    assert address_0.address() == '3289 Hansen Park'
    assert address_0.address() == '0032 Preston Park'
    assert address_0.address() == '4040 Deborah Lights'
    assert address_0.address() == '8261 Rebecca Route'
    assert address_0.address() == '47 Green Terrace'
    assert address_0.address() == '61051 Raul Locks Apt. 817'

# Generated at 2022-06-25 20:21:05.506891
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='pt-BR')
    expected = 'Rua José Silva, 567'
    actual = address_0.address()
    assert expected == actual

    address_1 = Address(locale='zh')
    expected = '广东省深圳市深南大道1003号'
    actual = address_1.address()
    assert expected == actual

    expected = 'Rua José Silva, 567'
    actual = address_0.address()
    assert expected == actual


# Generated at 2022-06-25 20:21:10.732664
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=0)
    address_1 = Address(seed=1)

    assert address_0.address() == "647 Russett Trails"
    assert address_1.address() == "72428 King Parkway"



# Generated at 2022-06-25 20:21:13.790895
# Unit test for method address of class Address
def test_Address_address():  # type: ignore
    address_0 = Address()
    assert isinstance(address_0.address(), str)
assert len(address_0.address()) >= 1


# Generated at 2022-06-25 20:21:32.540020
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert len(address_1.address()) > 0


# Generated at 2022-06-25 20:21:38.602109
# Unit test for method address of class Address
def test_Address_address():
    for _ in range(10):
        address_1 = Address()
        street_num_1 = address_1.street_number()
        street_name_1 = address_1.street_name()
        assert type(street_num_1).__name__ == 'str'
        assert type(street_name_1).__name__ == 'str'
        address_1_str = address_1.address()
        assert type(address_1_str).__name__ == 'str'
        assert str(street_num_1) in address_1_str
        assert str(street_name_1) in address_1_str


# Generated at 2022-06-25 20:21:42.814464
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address_0 = address.address()
    print(address_0)
    print(address_0.__len__())

# Generated at 2022-06-25 20:21:44.166746
# Unit test for method address of class Address
def test_Address_address():
    assert type(Address().address()) == str

# Generated at 2022-06-25 20:21:45.074049
# Unit test for method address of class Address
def test_Address_address():
    assert address_0.address() is not None


# Generated at 2022-06-25 20:21:47.434676
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:21:50.668149
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address = address_0.address()
    assert address



# Generated at 2022-06-25 20:21:51.917602
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print("\n===================\nTesting Address.address()")
    print("Your address is: " + address_0.address())


# Generated at 2022-06-25 20:21:54.473199
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert isinstance(address_1.address(), str)


# Generated at 2022-06-25 20:21:57.545383
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en')
    address_1._data['address_fmt'] = '{{street_number}} {{street_name}} {{street_suffix}}'
    for _ in range(3):
        assert len(address_1.address()) == (3 + 3 + 3)


# Generated at 2022-06-25 20:22:43.410523
# Unit test for method address of class Address
def test_Address_address():
    list_ = [Address() for x in range(0, 10)]
    list_address = [] #Create list with each element is the result of function address().
    for x in list_:
        list_address.append(x.address())
    assert len(list_address) == 10
    assert len(list_address) != 9


# Generated at 2022-06-25 20:22:47.723031
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(st_num = address.street_number(), st_name = address.street_name(), st_sfx = address.street_suffix())


# Generated at 2022-06-25 20:22:49.333760
# Unit test for method address of class Address
def test_Address_address():
    # Create an instance of a class Address
    address_1 = Address()
    # Get a random address
    address_1 = address_1.address()


# Generated at 2022-06-25 20:22:50.685087
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:22:54.565377
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), (str)),'The address() method of class Address has failed.'


# Generated at 2022-06-25 20:22:56.615097
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:22:59.134356
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:23:01.586539
# Unit test for method address of class Address
def test_Address_address():
    address = Address().address()
    print(address)


# Generated at 2022-06-25 20:23:03.566374
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert len(address.address()) > 0


# Generated at 2022-06-25 20:23:08.913666
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() == Address().address()
    assert type(Address().address()) is str


# Generated at 2022-06-25 20:24:48.140325
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()



# Generated at 2022-06-25 20:24:50.501199
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:24:53.482983
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()  # Instantiate of class Address
    address_0.address()  # Random address


# Generated at 2022-06-25 20:24:54.781730
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
test_case_0()

# Generated at 2022-06-25 20:24:58.087934
# Unit test for method address of class Address
def test_Address_address():
    address_obj=Address()

    assert address_obj.address() is not None



# Generated at 2022-06-25 20:25:01.885909
# Unit test for method address of class Address
def test_Address_address():
    # Find a way to check, if the output is valid address
    # or not.
    output = Address().address()
    print(output)


# Generated at 2022-06-25 20:25:03.214589
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()


# Generated at 2022-06-25 20:25:08.228689
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0._data['street']['name'][0] in address_0.address()
    assert address_0._data['street']['suffix'][0] in address_0.address()
    assert address_0.street_number() in address_0.address()


# Generated at 2022-06-25 20:25:11.093388
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:25:13.199013
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-25 20:28:15.714557
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    print("Test Address_address: ")
    print(result)
    assert type(result) == str
    assert len(result) > 0


# Generated at 2022-06-25 20:28:16.671666
# Unit test for method address of class Address
def test_Address_address():
    assert type(Address().address()) == str


# Generated at 2022-06-25 20:28:18.387368
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    assert(len(address_0.address()) > 0)

# Generated at 2022-06-25 20:28:20.533879
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:28:21.783548
# Unit test for method address of class Address
def test_Address_address():

    adr = Address()

    assert adr.address()


# Generated at 2022-06-25 20:28:23.265806
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert result


# Generated at 2022-06-25 20:28:26.551972
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(random_state=1)
    expected_result_0 = '6349 Monte Vista'
    actual_result_0 = address_0.address()
    assert actual_result_0 == expected_result_0
