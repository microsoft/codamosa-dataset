

# Generated at 2022-06-25 20:18:41.175226
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    str_1 = address_1.address()
    assert str_1 != ""



# Generated at 2022-06-25 20:18:42.671926
# Unit test for method address of class Address
def test_Address_address():
    add = Address('en')
    assert add.street_name() != add.street_name()



# Generated at 2022-06-25 20:18:44.706261
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert re.search(r'[\D]', str_0)


# Generated at 2022-06-25 20:18:46.778621
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:48.048744
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:18:49.708567
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='en')
    str_0 = adr.address()
    str_1 = adr.address()
    assert str_0 != str_1


# Generated at 2022-06-25 20:18:56.999319
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(seed = 1234)
    assert address_1.address() == '600 S Portage Path\nBolingbroke, OH 43105'
    address_2 = Address(seed = 56)
    assert address_2.address() == '3147 E Gable Lane\nWyandotte, OH 44270'
    address_3 = Address(seed = 13)
    assert address_3.address() == '1705 W Ronald Regan Drive\nLos Angeles, CA 90027'
    address_4 = Address(seed = 9)
    assert address_4.address() == '1104 N Shady Lane\nNorth Arlington, OH 44016'
    address_5 = Address(seed = 23)
    assert address_5.address() == '8242 W Chase Street\nOrland, FL 32825'

# Generated at 2022-06-25 20:18:59.092884
# Unit test for method address of class Address
def test_Address_address():
    for x in range(0, 5):
        Address().address()


# Generated at 2022-06-25 20:19:00.798062
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-25 20:19:03.630470
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en')
    result_1 = isinstance(address_1.address(), str)
    assert result_1 is True


# Generated at 2022-06-25 20:19:11.185241
# Unit test for method address of class Address
def test_Address_address():
    random_0 = Address(str_0)
    str_1 = random_0.address()



# Generated at 2022-06-25 20:19:15.118674
# Unit test for method address of class Address
def test_Address_address():
    # Init
    obj_0 = Address(str_0)
    
    # Invoke method
    test_0 = obj_0.address()
    ans_0 = obj_0.address()

    # Test results
    assert_equal(test_0, ans_0)


# Generated at 2022-06-25 20:19:17.942711
# Unit test for method address of class Address
def test_Address_address():
    adr_0 = Address()
    str_0 = adr_0.address()


# Generated at 2022-06-25 20:19:21.557693
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(str_0)
    result_str_0 = addr.address()
    print(result_str_0)


# Generated at 2022-06-25 20:19:30.616816
# Unit test for method address of class Address
def test_Address_address():
    import json
    import random
    import string
    import os
    import tempfile
    import pytest
    from random import choice
    from collections import Counter
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.utils import seed, NUMERALS

    seed(0)
    address = Address(str_0)

    def test_us():
        assert address.country(True) == "Brunei"
        assert address.postal_code() == "14339"
        assert address.country_code() == "BN"

    def test_ru():
        assert address.country_code(True) == "BR"
        assert address.country_code() == "BY"
        assert address.country_code(False) == "BZ"
        assert address.country

# Generated at 2022-06-25 20:19:33.676389
# Unit test for method address of class Address
def test_Address_address():
    import random
    cls_0 = Address(random.Random())
    str_0 = cls_0.address()
    print(str_0)
    print(str_0)


# Generated at 2022-06-25 20:19:40.460682
# Unit test for method address of class Address
def test_Address_address():
    str_0 = '0'
    float_0 = float('0.0')
    float_1 = float('0.1')
    float_2 = float('0.2')
    float_3 = float('0.3')
    float_4 = float('0.4')
    float_5 = float('0.5')
    float_6 = float('0.6')
    float_7 = float('0.7')
    float_8 = float('0.8')
    float_9 = float('0.9')
    int_0 = int(float_0)
    int_1 = int(float_1)
    int_2 = int(float_2)
    int_3 = int(float_3)
    int_4 = int(float_4)

# Generated at 2022-06-25 20:19:50.314076
# Unit test for method address of class Address
def test_Address_address():
    print('-- test_Address_address')
    addr = Address()
    address1 = addr.address()
    assert type(address1) == str
    print('address: {0}'.format(address1))

test_case_enum = [
    ('en', 'Address'), ('en', 'city'), ('en', 'postal_code'),
    ('en', 'region'), ('en', 'state'), ('en', 'street'),
    ('en', 'street_name'), ('en', 'street_number'), ('en', 'street_suffix'),
    ('en', 'zip_code'),
]

# Test cases for __init__ method of class Address
test_cases_init = [
    ('en'), ('en-US'), ('es-419'), ('es'), ('ja'), ('zh'), ('zh-CN'), ('zh-TW'),
]


# Generated at 2022-06-25 20:19:53.541713
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(str_0)
    assert re.match('^[0-9]+[ ](?:[A-Z][a-z]*[\. ]){1,2}$', adr.address())


# Generated at 2022-06-25 20:19:56.141438
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(seed=0)
    assert addr.address() == '9740 Kipp Streets'



# Generated at 2022-06-25 20:20:05.092388
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:20:09.672440
# Unit test for method address of class Address
def test_Address_address():
    """Test for method address of class Address"""
    # Create an instance of class Address with parameter 'en'
    address = Address('en')
    # Call method address of address
    str_0 = address.address()
    assert str_0 is not None


# Generated at 2022-06-25 20:20:14.721079
# Unit test for method address of class Address
def test_Address_address():
    format_string_0 = '480 {}'
    address_0 = Address(str_0)
    str_1 = address_0.address()
    assert str_1 == format_string_0.format('E. Morris Place')


# Generated at 2022-06-25 20:20:25.214376
# Unit test for method address of class Address
def test_Address_address():
    import random
    import copy

    locales = ['en', 'es', 'pt', 'ru', 'uk', 'fr', 'ja']

    locales_copy = copy.deepcopy(locales)
    for i in range(len(locales_copy)):
        locales_copy[i] = 'en'
    locales_copy[random.randint(0, len(locales_copy) - 1)] = ''

    locales_copy_0 = copy.deepcopy(locales)
    for i in range(len(locales_copy_0)):
        locales_copy_0[i] = 'es'
    locales_copy_0[random.randint(0, len(locales_copy_0) - 1)] = ''

    locales_copy_1 = copy.deepcopy(locales)


# Generated at 2022-06-25 20:20:28.164614
# Unit test for method address of class Address
def test_Address_address():
    address = Address(str)
    assert isinstance(address.address(), str)
    assert len(address.address()) > 0


# Generated at 2022-06-25 20:20:29.709040
# Unit test for method address of class Address
def test_Address_address():
    address_instance = Address(str_0)
    str_1 = address_instance.address()


# Generated at 2022-06-25 20:20:44.067493
# Unit test for method address of class Address
def test_Address_address():
    assert 'Address' == Address.Meta.name
    assert 'Address' == Address._meta.name
    assert 'Address' == Address.Meta._meta.name
    assert 'Address' == Address._meta._meta.name
    assert 'address' == Address.Meta.name.lower()
    assert 'address' == Address._meta.name.lower()
    assert 'address' == Address.Meta._meta.name.lower()
    assert 'address' == Address._meta._meta.name.lower()
    assert 'address' == Address.Meta.__class__.__name__.lower()
    assert 'address' == Address._meta.__class__.__name__.lower()
    assert 'address' == Address.Meta._meta.__class__.__name__.lower()
    assert 'address' == Address._meta._meta.__class__.__name

# Generated at 2022-06-25 20:20:45.254498
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    str_0 = address_1.address()
    return str_0

# Generated at 2022-06-25 20:20:47.929798
# Unit test for method address of class Address
def test_Address_address():
    # Providing arguments for class Address
    arg_0 = 'en'
    obj_0 = Address(arg_0)

    # Calling method address of class Address with argument obj_0
    result_0 = Address.address(obj_0)

    # Printing result_0
    print(result_0)

# Generated at 2022-06-25 20:20:51.133723
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    r = a.address()
    assert r is not False
    assert r is not None


# Generated at 2022-06-25 20:21:00.688136
# Unit test for method address of class Address
def test_Address_address():
    import random
    random.seed(0)

    data_provider = Address(str_0)
    assert data_provider.address() == 'Независимости пр. 26/1'


# Generated at 2022-06-25 20:21:04.872362
# Unit test for method address of class Address
def test_Address_address():
    try:
        str_0 = Address(str_0).address()
        str_1 = Address(str_1).address()
        str_2 = Address(str_2).address()
        str_3 = Address(str_3).address()
    except Exception as raisedException:
        print(raisedException)


# Generated at 2022-06-25 20:21:07.339855
# Unit test for method address of class Address
def test_Address_address():
    str_0 = 'en'
    address = Address(str_0)


# Generated at 2022-06-25 20:21:10.288539
# Unit test for method address of class Address
def test_Address_address():
    sut = Address(str_0)
    assert sut.address() is not None


# Generated at 2022-06-25 20:21:13.747139
# Unit test for method address of class Address
def test_Address_address():
    from random import randint
    from mimesis.builtins import address
    from random import randint
    from mimesis.builtins import address
    from mimesis.enums import CountryCode

    # Address().address()
    assert isinstance(address.address(), str)

    # Address(str_0).address()
    assert isinstance(address.address(), str)

    # Address(str_0).address(int_0)
    assert isinstance(address.address(), str)



# Generated at 2022-06-25 20:21:16.344706
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    addr.address()


# Generated at 2022-06-25 20:21:21.583723
# Unit test for method address of class Address
def test_Address_address():

    address = Address('en')
    print("Testing address() method with locale en")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

    for i in range(0, 10):
        print("Got result:", address.address())


# Generated at 2022-06-25 20:21:26.106487
# Unit test for method address of class Address
def test_Address_address():
    str_0 = 'en'
    str_1 = 'sp'
    str_2 = 'de'
    str_3 = 'ru'
    str_4 = 'pt'
    str_5 = 'it'
    str_6 = 'no'
    str_7 = 'es'
    str_8 = 'zxx'
    str_9 = 'ja'
    str_10 = 'fr'
    obj_0 = Address(str_0)
    obj_1 = Address(str_1)
    obj_2 = Address(str_2)
    obj_3 = Address(str_3)
    obj_4 = Address(str_4)
    obj_5 = Address(str_5)
    obj_6 = Address(str_6)
    obj_7 = Address(str_7)
    obj_

# Generated at 2022-06-25 20:21:33.334563
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(locale = 'en')
    test_case_1(addr)
    test_case_2(addr)
    test_case_3(addr)
    test_case_4(addr)
    test_case_5(addr)

# Tests calling code with n number of calls, printing the result and the list of different values

# Generated at 2022-06-25 20:21:35.739693
# Unit test for method address of class Address
def test_Address_address():
    args_0 = {}
    ret_0 = Address.address(args_0)
    str_0 = 'en'
    assert(ret_0 == str_0)


# Generated at 2022-06-25 20:21:43.780113
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en').address()
    assert type(address) == str


# Generated at 2022-06-25 20:21:45.696065
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale = 'en')
    str_0 = address.address()
    print(str_0)
    
    

# Generated at 2022-06-25 20:21:57.861526
# Unit test for method address of class Address
def test_Address_address():
    str_0 = 'en'
    str_1 = 'uk'
    str_2 = 'zh'
    str_3 = 'en'
    str_4 = 'el'
    str_5 = 'pl'
    str_6 = 'es'
    str_7 = 'ru'
    str_8 = 'fr'
    str_9 = 'ja'
    str_10 = 'de'
    str_11 = 'it'
    str_12 = 'vi'
    str_13 = 'nl'
    str_14 = 'pt'
    str_15 = 'id'
    str_16 = 'ko'
    str_17 = 'et'
    str_18 = 'lt'
    str_19 = 'cs'
    str_20 = 'hu'
    str_21 = 'sv'
   

# Generated at 2022-06-25 20:22:00.700773
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(str_0)
    assert type(addr.address()) == str


# Generated at 2022-06-25 20:22:04.602594
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(str_0)
    print(addr.address())

if __name__ == "__main__":
    test_case_0()
    test_Address_address()

# Generated at 2022-06-25 20:22:07.168291
# Unit test for method address of class Address
def test_Address_address():
    str_0 = 'en'
    obj_0 = Address(str_0)
    str_1 = obj_0.address()
    print(str_1)
    str_2 = obj_0.address()
    print(str_2)
    str_3 = obj_0.address()
    print(str_3)


# Generated at 2022-06-25 20:22:10.674501
# Unit test for method address of class Address
def test_Address_address():
    cls = Address()
    str_0 = cls.address()
    str_1 = cls.address()
    assert str_0 == str_1


# Generated at 2022-06-25 20:22:13.029848
# Unit test for method address of class Address
def test_Address_address():
    address_gen = Address(seed=0)
    address_gen.address()


# Generated at 2022-06-25 20:22:15.110450
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(str_0)
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:22:21.488769
# Unit test for method address of class Address
def test_Address_address():
    address = Address('zh')
    str_0 = address._data['address_fmt']
    str_1 = address.address()
    str_2 = address.address()
    str_3 = address.address()
    str_4 = address.address()


# Generated at 2022-06-25 20:22:39.869877
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    val = address.address()
    assert isinstance(val, str)


# Generated at 2022-06-25 20:22:42.653072
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('fr')
    addr_addr = addr.address()
    print(addr_addr)


# Generated at 2022-06-25 20:22:47.723119
# Unit test for method address of class Address
def test_Address_address():
    adr_0 = Address()
    str_0 = adr_0.address()
    assert (len(str_0) > 0)


# Generated at 2022-06-25 20:22:49.708774
# Unit test for method address of class Address
def test_Address_address():
    address_obj_0 = Address('en')
    class_0 = address_obj_0
    address_obj_0 = class_0.address()

    assert address_obj_0 == '#554 Buell Street'


# Generated at 2022-06-25 20:22:52.776645
# Unit test for method address of class Address
def test_Address_address():
    z0 = Address()
    z1 = z0.address()
    return z1


# Generated at 2022-06-25 20:23:01.035935
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address

    a = Address('en')
    res_0 = address()
    assert res_0 == '522 Fowler Squares Apt. 343'

    res_1 = address()
    assert res_1 == '423 Alvarado Centers Apt. 903'

    res_2 = address()
    assert res_2 == '473 Watson Divide Apt. 649'

    res_3 = address()
    assert res_3 == '134 Turner Glen Apt. 553'

    res_4 = address()
    assert res_4 == '732 Watson Path'

    res_5 = address()
    assert res_5 == '684 Mccormick Locks Apt. 858'



# Generated at 2022-06-25 20:23:11.225226
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.enums import Locale

    address = Address(locale=Locale.EN)
    address_0 = Address(locale=Locale.EN)
    address_1 = Address(locale=Locale.EN)
    address_2 = Address(locale=Locale.EN)
    address_3 = Address(locale=Locale.EN)
    address_4 = Address(locale=Locale.EN)
    address_5 = Address(locale=Locale.EN)
    address_6 = Address(locale=Locale.EN)
    address_7 = Address(locale=Locale.EN)

    assert len(address.address()) > 0
    assert len(address_0.address()) > 0

# Generated at 2022-06-25 20:23:19.312100
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(str_0)
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'c'
    str_4 = 'd'
    str_5 = 'e'
    str_6 = 'f'
    str_7 = 'g'
    str_8 = 'h'
    str_9 = 'i'
    str_10 = 'j'
    str_11 = 'k'
    str_12 = 'l'
    str_13 = 'm'
    str_14 = 'n'
    str_15 = 'o'
    str_16 = 'p'
    str_17 = 'q'
    str_18 = 'r'
    str_19 = 's'
    str_20 = 't'

# Generated at 2022-06-25 20:23:24.813319
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('en')
    assert type(addr.address()) == str
    assert len(addr.address().split(" ")) == 3
    assert len(addr.address().split(" ")) <= 4


# Generated at 2022-06-25 20:23:28.371155
# Unit test for method address of class Address
def test_Address_address():
    str_0 = 'en'
    obj_0 = Address(locale=str_0)
    str_1 = obj_0.address()
    print(str_1)


# Generated at 2022-06-25 20:23:54.626266
# Unit test for method address of class Address
def test_Address_address():
    str_1 = 'en'
    address_0 = Address(str_1)
    str_2 = address_0.address()
    print(str_2)


# Generated at 2022-06-25 20:24:07.125114
# Unit test for method address of class Address
def test_Address_address():
    import pytest, random
    random.seed(0)
    address = Address(str_0, 0)
    assert address.address() == '1203, New St.'


# Generated at 2022-06-25 20:24:17.842141
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode

    # See: https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2
    # See: https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3
    # See: https://en.wikipedia.org/wiki/ISO_3166-1_numeric

    # Locale does not affect the result
    address = Address(locale='pt-BR')
    result_0 = address.address()
    result_1 = address.address()
    assert type(result_0) == type(result_1)
    assert len(result_0) > 10
    assert len(result_1) > 10

    # Argument `allow_random` does not affect the result
    result_0 = address.country(allow_random=True)
    result

# Generated at 2022-06-25 20:24:20.316420
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    # str_0 = address.address()


# Generated at 2022-06-25 20:24:29.856037
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import RussiaSpecProvider

# Generated at 2022-06-25 20:24:32.350510
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None
    pass


# Generated at 2022-06-25 20:24:35.681256
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    ret = address_0.address()
    assert str_0 in address_0.address()


# Generated at 2022-06-25 20:24:37.479841
# Unit test for method address of class Address
def test_Address_address():
    obj_0 = Address()
    str_0 = obj_0.address()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:24:41.771750
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()


# Generated at 2022-06-25 20:24:44.269495
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    str_0 = addr.address()
    print("TEST case 0 (address):", str_0)
    assert(True)


# Generated at 2022-06-25 20:25:06.469473
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())


# Generated at 2022-06-25 20:25:13.929764
# Unit test for method address of class Address
def test_Address_address():
    # Create instance of Address
    address = Address(locale="zh")
    # Get data
    if address.address() == '':
        raise AssertionError("No address")
    else:
        print("Test case 0 for address function in Address class passed")
        print("address: " + address.address())


# Generated at 2022-06-25 20:25:15.599818
# Unit test for method address of class Address
def test_Address_address():
    print("address")
    address_0 = Address()
    ret = address_0.address()
    print(ret)


# Generated at 2022-06-25 20:25:18.660477
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)

# Generated at 2022-06-25 20:25:28.733557
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street = address.street_name()
    street_number = address.street_number()
    fmt = address._data['address_fmt']
    state = address.state()
    country = address.country()
    city = address.city()
    address_ = fmt.format(st_name = street, st_num = street_number, state = state, country = country, city = city)

    print("Street: " + street)
    print("Street number: " + street_number)
    print("State: " + state)
    print("Country: " + country)
    print("City: " + city)
    print("Address: " + address_)


if __name__ == '__main__':
    test_case_0()
    test_Address_address()

# Generated at 2022-06-25 20:25:30.962283
# Unit test for method address of class Address
def test_Address_address():
	address_0 = Address()
	address_0.address()


# Generated at 2022-06-25 20:25:33.070972
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:25:39.552877
# Unit test for method address of class Address
def test_Address_address():
    import json
    import re
    from os import path

    patterns = None
    with open(path.abspath(path.join(__file__, '..', 'data', 'address.json')),
              'r', encoding='utf-8') as file:
        patterns = json.load(file)

    for i in range(1000):
        address = Address()
        address_pattern = address._data['address_fmt']
        assert re.match(patterns['address_fmt'][address.locale], address.address())



# Generated at 2022-06-25 20:25:42.140825
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert(address_0.address() != None)

# Generated at 2022-06-25 20:25:43.614002
# Unit test for method address of class Address
def test_Address_address():
    addresses = Address()
    assert isinstance(addresses.address(), str)


# Generated at 2022-06-25 20:26:25.114118
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert (result != None)


# Generated at 2022-06-25 20:26:26.367542
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-25 20:26:28.055883
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert 'address' in address_0.provider.keys()
    assert isinstance(address_0.provider['address'], Address)


# Generated at 2022-06-25 20:26:29.366633
# Unit test for method address of class Address
def test_Address_address():
    # Test without argument
    address_1 = Address()
    address_1.address()


# Generated at 2022-06-25 20:26:35.484471
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()

# Generated at 2022-06-25 20:26:37.377845
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.address()
    address_1.address()
    address_1.address()
    address_1.address()


# Generated at 2022-06-25 20:26:38.892965
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = address_0.address()
    assert isinstance(address_1, str)


# Generated at 2022-06-25 20:26:40.495198
# Unit test for method address of class Address
def test_Address_address():
    address = Address().address()
    assert type(address) is str
    

# Generated at 2022-06-25 20:26:41.981276
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address()


# Generated at 2022-06-25 20:26:43.406013
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result


# Generated at 2022-06-25 20:28:06.275356
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender, Title
    from mimesis.providers.base import BaseProvider
    gender = Gender.MALE
    title = Title.MALE
    base_provider = BaseProvider('en', gender, title)
    address = Address('en', base_provider)
    full_address = address.address()
    expected_output = '{street_num} {street_name} {street_sfx}'.format(street_num=address.street_number(), street_name=address.street_name(), street_sfx=address.street_suffix())
    assert full_address==expected_output


# Generated at 2022-06-25 20:28:07.200075
# Unit test for method address of class Address
def test_Address_address():
    pass


# Generated at 2022-06-25 20:28:08.641961
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    var_1 = address_0.address()
    assert type(var_1) == str


# Generated at 2022-06-25 20:28:09.842415
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address()
    return True


# Generated at 2022-06-25 20:28:12.496523
# Unit test for method address of class Address
def test_Address_address():
    # Test-1
    address_0 = Address()
    string_0 = address_0.address()
    # Test-2
    address_1 = Address()
    string_1 = address_1.address()
    # Test-3
    address_2 = Address()
    string_2 = address_2.address()


# Generated at 2022-06-25 20:28:14.388356
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert isinstance(result, str)
    assert result is not None


# Generated at 2022-06-25 20:28:15.913968
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != ""


# Generated at 2022-06-25 20:28:22.654221
# Unit test for method address of class Address
def test_Address_address():

    # test case: no locale
    address_0 = Address()
    result_0 = address_0.address()
    assert result_0

    # test case: cn
    address_cn = Address('cn')
    result_1 = address_cn.address()
    assert result_1

    # test case: en
    address_en = Address('en')
    result_2 = address_en.address()
    assert result_2

    # test case: ja
    address_ja = Address('ja')
    result_3 = address_ja.address()
    assert result_3


# Generated at 2022-06-25 20:28:27.603424
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    r = Address(locale=Locale.AMERICAN_ENGLISH)
    s = r.address()
    assert isinstance(s, str)
    assert len(s) > 0
    r = Address(locale=Locale.GERMAN)
    s = r.address()
    assert isinstance(s, str)
    assert len(s) > 0
