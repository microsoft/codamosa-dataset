

# Generated at 2022-06-25 20:18:41.721513
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) is str


# Generated at 2022-06-25 20:18:51.465718
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='id_ID')
    assert address_0.address() == 'Jl. 2, Sg. Karangdowo'
    address_0 = Address(locale='pt_BR')
    assert address_0.address() == 'Rua 1045, Rua Ano Bom'
    address_0 = Address(locale='es_ES')
    assert address_0.address() == 'Calle 1132, Calle Torredembarra'
    address_0 = Address(locale='es_PE')
    assert address_0.address() == 'Av. 834, Calle Tito'
    address_0 = Address(locale='pl_PL')
    assert address_0.address() == 'ul. 843, Aleja Trzydziestolatka'

# Generated at 2022-06-25 20:18:53.402551
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address('ru')
    address_2 = Address('en-US')
    print(address_0.address())
    print(address_1.address())
    print(address_2.address())


# Generated at 2022-06-25 20:18:54.526097
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    output_0 = address_0.address()
    print(output_0)


# Generated at 2022-06-25 20:18:55.860058
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address()


# Generated at 2022-06-25 20:18:58.713355
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    # 1
    assert address.address() != address.address()
    # 2
    address = Address()
    assert address.address() != address.address()
    # 3
    address = Address('fr')
    assert address.address() != address.address()



# Generated at 2022-06-25 20:19:00.796145
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    for _ in range(20):
        print(a.address())


# Generated at 2022-06-25 20:19:02.866148
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert(address_0.address() != '')


# Generated at 2022-06-25 20:19:04.518803
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str



# Generated at 2022-06-25 20:19:06.275029
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert type(address_0.address()) == str


# Generated at 2022-06-25 20:19:22.802761
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale="en")
    addr1 = address.address()
    assert addr1 == "868 W. Crawford St."
    addr2 = address.address()
    addr3 = address.address()
    addr4 = address.address()
    available_addr = {'868 W. Crawford St.', '967 E. Roosevelt Ave.',
                      '871 E. Jefferson St.', '467 S. Tyler St.'}
    assert addr2 in available_addr
    assert addr3 in available_addr
    assert addr4 in available_addr

# Generated at 2022-06-25 20:19:24.292435
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()


# Generated at 2022-06-25 20:19:26.217181
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:19:33.125477
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(seed=7224)
    address_2 = Address(seed=7224)
    assert address_0.address() == address_2.address()
    assert address_0.address() != address_1.address()


# Generated at 2022-06-25 20:19:35.698672
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address.address()
    assert len(address_0)


# Generated at 2022-06-25 20:19:37.966466
# Unit test for method address of class Address
def test_Address_address():
    # Get data from Address.address()
    Address_address = Address().address()
    # Check type
    assert isinstance(Address_address, str)


# Generated at 2022-06-25 20:19:39.266303
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:19:44.277074
# Unit test for method address of class Address
def test_Address_address():
    """
    :return: testing address
    """
    address = Address(locale='en')
    assert address.address() is not None
    assert type(address.address()) is str


# Generated at 2022-06-25 20:19:47.341810
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = address_0.address()
    assert isinstance(address_1, str)


# Generated at 2022-06-25 20:19:51.678789
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    assert bool(address_obj.address() not in address_obj.address())


# Generated at 2022-06-25 20:20:17.073184
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert(isinstance(address_0.address(), str))


# Generated at 2022-06-25 20:20:19.707506
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    case = address.address()
    assert case
    assert isinstance(case, str)



# Generated at 2022-06-25 20:20:31.311773
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(locale='en')
    address_2 = Address(locale='en')
    address_3 = Address(locale='en')
    address_4 = Address(locale='en')
    address_5 = Address(locale='fr')
    address_6 = Address(locale='fr')
    address_7 = Address(locale='fr')
    address_8 = Address(locale='fr')
    address_9 = Address(locale='ja')
    address_10 = Address(locale='ja')
    address_11 = Address(locale='ja')
    address_12 = Address(locale='ja')

    assert address_0.address() == address_0.address()
    assert address_1.address() != address_2.address()
    assert 12

# Generated at 2022-06-25 20:20:33.801587
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    add.address()


# Generated at 2022-06-25 20:20:39.104879
# Unit test for method address of class Address
def test_Address_address():
    _pass = False
    try:
        address_0 = Address()
        address_0.address()
        _pass = True
    except Exception:
        pass
    assert _pass == True


# Generated at 2022-06-25 20:20:41.145845
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert type(addr.address()) == str


# Generated at 2022-06-25 20:20:54.178018
# Unit test for method address of class Address
def test_Address_address():
    # 1
    address_1 = Address()
    assert address_1.address().__class__ == str
    assert len(address_1.address()) > 0
    # 2
    address_2 = Address()
    assert address_2.address().__class__ == str
    assert len(address_2.address()) > 0
    # 3
    address_3 = Address()
    assert address_3.address().__class__ == str
    assert len(address_3.address()) > 0
    # 4
    address_4 = Address()
    assert address_4.address().__class__ == str
    assert len(address_4.address()) > 0
    # 5
    address_5 = Address()
    assert address_5.address().__class__ == str
    assert len(address_5.address()) > 0
    # 6


# Generated at 2022-06-25 20:21:06.000258
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='ru')
    address_2 = Address(locale='en')
    address_3 = Address(locale='ja')
    ru_fmt_values = {'st_num': '1', 'st_name': 'Ленина'}
    en_fmt_values = {'st_num': '1', 'st_name': 'Nelson Street'}
    ja_fmt_values = {'city': 'Москва', 'randints': '51,73,86'}
    ru_fmt = u"{st_num} {st_name} проспект"
    en_fmt = u"{st_num} {st_name} Street"

# Generated at 2022-06-25 20:21:13.279862
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    flag_0 = all(address_1.address() for _ in range (0, 100))
    flag_1 = all(address_1.address() != address_2.address() for _ in range (0, 100))
    assert flag_0 == True
    assert flag_1 == True


# Generated at 2022-06-25 20:21:15.826378
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:22:06.890562
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=3930297948)
    expected = '3949 Rogers Road'
    actual = address_0.address()
    assert expected == actual



# Generated at 2022-06-25 20:22:09.402663
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None



# Generated at 2022-06-25 20:22:15.109782
# Unit test for method address of class Address
def test_Address_address():
    # address_0 = Address()
    # result_0 = address_0.address()
    # assert result_0 == 'пер. Дружный, 48'
    # assert result_0 != 'пер. Федоровский, 2'
    return


# Generated at 2022-06-25 20:22:18.341118
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1048 West Tyrell Villages'


# Generated at 2022-06-25 20:22:23.664333
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    str_1 = str_0.upper()
    print("Address: ", str_0)
    print("Address: ", str_1)


# Generated at 2022-06-25 20:22:26.920805
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()
    address = Address()
    assert address.address()
    str(address)
    bool(address)
    address + ''
    address * 3


# Generated at 2022-06-25 20:22:30.114734
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # It should generate a string.
    assert isinstance(address_0.address(), str)
    # It works.
    assert address_0.address() in ('51 rue Poulletier, Paris', '3 Rue Pierre Landais, Brest')


# Generated at 2022-06-25 20:22:33.175755
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()

    assert result is not None
    assert len(result) > 1


# Generated at 2022-06-25 20:22:35.989942
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print("\n", address_0.address(), end='')
    assert_0 = '4006 Avenue Matteotti'
    assert assert_0 in address_0.address()


# Generated at 2022-06-25 20:22:39.497703
# Unit test for method address of class Address
def test_Address_address():
    address_test = Address()
    assert type(address_test.address()) is str
