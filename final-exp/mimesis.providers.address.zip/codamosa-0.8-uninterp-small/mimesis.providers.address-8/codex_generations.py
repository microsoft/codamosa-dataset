

# Generated at 2022-06-25 20:18:32.955194
# Unit test for method address of class Address
def test_Address_address():
    data = Address().address()
    assert type(data) is str


# Generated at 2022-06-25 20:18:35.095060
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_str = address_0.address()
    try:
        assert(address_str)
    except:
        assert False


# Generated at 2022-06-25 20:18:37.528357
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address() == '3350 Karis Course\nSchimmelbury, MT 93081'


# Generated at 2022-06-25 20:18:40.244810
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address"""
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:47.846314
# Unit test for method address of class Address
def test_Address_address():
    # Variable init
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    address_5 = Address()
    address_6 = Address()
    address_7 = Address()
    address_8 = Address()
    address_9 = Address()

    # Test str.
    assert address_0.address() is not None
    assert address_1.address() is not None
    assert address_2.address() is not None
    assert address_3.address() is not None
    assert address_4.address() is not None
    assert address_5.address() is not None
    assert address_6.address() is not None
    assert address_7.address() is not None
    assert address_8.address() is not None


# Generated at 2022-06-25 20:18:49.719457
# Unit test for method address of class Address
def test_Address_address():
    global result
    address_0 = Address()

    str_0 = ''
    result = address_0.address()

    assert result is not None
    assert type(result) is str
    assert len(result) > 0


# Generated at 2022-06-25 20:18:54.549961
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    print(str_0)
    str_1 = address_0.address()
    print(str_1)
    str_2 = address_0.address()
    print(str_2)
    str_3 = address_0.address()
    print(str_3)
    str_4 = address_0.address()
    print(str_4)
    str_5 = address_0.address()
    print(str_5)
    str_6 = address_0.address()
    print(str_6)
    str_7 = address_0.address()
    print(str_7)
    str_8 = address_0.address()
    print(str_8)
    str_9 = address_0.address()

# Generated at 2022-06-25 20:18:55.395841
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:57.071184
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert str_0 is not None


# Generated at 2022-06-25 20:19:03.155847
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    print(str_0)

    str_1 = address_0.address()
    print(str_1)

    str_2 = address_0.address()
    print(str_2)

    str_3 = address_0.address()
    print(str_3)


# Generated at 2022-06-25 20:19:08.622150
# Unit test for method address of class Address
def test_Address_address():
    expected = 'Av. Independência 23'
    actual = Address('pt').address()
    assert actual == expected, 'Wrong address'


# Generated at 2022-06-25 20:19:12.245092
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    addr = address.address()
    assert isinstance(addr, str)
    assert len(addr) > 0
    print(addr)


# Generated at 2022-06-25 20:19:15.633470
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    output_0 = 'No.{st_num}, {st_name} {st_sfx}'
    assert address_0.address() == output_0


# Generated at 2022-06-25 20:19:18.227001
# Unit test for method address of class Address
def test_Address_address():
    address_method = Address()

    # Assert
    assert isinstance(address_method.address(), str)
    assert len(address_method.address()) > 0


# Generated at 2022-06-25 20:19:30.438745
# Unit test for method address of class Address

# Generated at 2022-06-25 20:19:33.554629
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    value = address_0.address()
    assert isinstance(value, str)


# Generated at 2022-06-25 20:19:36.114902
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    for i in range(0,10):
        print(obj.address())


# Generated at 2022-06-25 20:19:37.584446
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:19:39.411407
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()


# Generated at 2022-06-25 20:19:43.839511
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    res = address_0.address()
    assert isinstance(res, str)
    assert len(res) > 0


# Generated at 2022-06-25 20:19:54.346457
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert(type(address_0.address()) is str)


# Generated at 2022-06-25 20:19:56.743066
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() == '1 Random Street'


# Generated at 2022-06-25 20:20:09.852535
# Unit test for method address of class Address
def test_Address_address():
    # test case 0
    address_0 = Address()
    streetNum = address_0.street_name()
    streetName = address_0.street_name()
    streetSuffix = address_0.street_suffix()
    address_0_ = "201 "+streetName+" "+streetSuffix
    assert address_0.address() == address_0_
    # test case 1
    address_1 = Address(locale='fr')
    streetNum = address_1.street_number()
    streetName = address_1.street_name()
    streetSuffix = address_1.street_suffix()
    address_1_ = streetNum+" "+streetName+" "+streetSuffix
    assert address_1.address() == address_1_
    # test case 2

# Generated at 2022-06-25 20:20:12.431682
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:20:19.871502
# Unit test for method address of class Address
def test_Address_address():
    # Generate address on English locale
    address_1 = Address(locale='en')
    result_address_1 = address_1.address()
    assert result_address_1 != None

    # Generate address on Russian locale
    address_2 = Address(locale='ru')
    result_address_2 = address_2.address()
    assert result_address_2 != None


# Generated at 2022-06-25 20:20:23.687877
# Unit test for method address of class Address
def test_Address_address():
    address1 = Address().address()
    assert isinstance(address1, str)


# Generated at 2022-06-25 20:20:29.086409
# Unit test for method address of class Address
def test_Address_address():
    address_address_0 = Address()
    str_0 = address_address_0.address()
    str_1 = address_address_0.address()
    str_2 = address_address_0.address()


# Generated at 2022-06-25 20:20:34.246687
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(locale='en')
    address_2 = Address(locale='es')
    address_3 = Address(locale='ru')
    address_4 = Address(locale='zh')
    address_5 = Address(locale='ja')
    print("Test Address address")
    print(address_0.address())
    print(address_1.address())
    print(address_2.address())
    print(address_3.address())
    print(address_4.address())
    print(address_5.address())


# Generated at 2022-06-25 20:20:38.219211
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    output = address.address()
    assert isinstance(output, str)
    assert output != ""


# Generated at 2022-06-25 20:20:40.460031
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() is not None


# Generated at 2022-06-25 20:21:01.873890
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:21:10.921421
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=5)
    case_0 = address_0.address()
    print(case_0)
    assert case_0 == '1437 микрорайон Пять Дорог-VI Улица Мягкая'
    assert type(case_0) == str

    address_1 = Address(seed=454)
    case_1 = address_1.address()
    print(case_1)
    assert case_1 == '14625 поселок Следы-IV Крепостная'
    assert type(case_1) == str



# Generated at 2022-06-25 20:21:13.556449
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:21:16.705590
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:21:26.462065
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('en')
    assert address_0.address() != '1484 Grace Courts\n\
    Lake Ashley, WA 73923-0248'
    assert address_0.address() != '63891 Ryleigh Freeway\n\
    South Mason, IA 01948'
    assert address_0.address() != '651 Michael Isle\n\
        North Jillianstad, VT 99300-9255'
    assert address_0.address() != '8275 Hernandez Shores\n\
        East Eric, GA 92371-3912'
    assert address_0.address() != '82562 Bogan Creek Suite 954\n\
        Andersonstad, WA 00932-4718'



# Generated at 2022-06-25 20:21:30.155706
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert result_0 is not None


# Generated at 2022-06-25 20:21:32.178418
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:21:34.801969
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(seed=1)
    assert address_1.address() == '825 Heidenreich Gardens'


# Generated at 2022-06-25 20:21:35.944270
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:21:44.680152
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())


if __name__ == '__main__':
    test_case_0()
    # test_Address_address()

# Generated at 2022-06-25 20:22:07.520779
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    #print(address_0.address())
    pass


# Generated at 2022-06-25 20:22:11.221207
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()
    address_5 = Address()
    address_6 = Address()
    address_7 = Address()
    address_8 = Address()
    address_9 = Address()
    addresses_list = [address_1, address_2, address_3, address_4, address_5, address_6, address_7, address_8, address_9]
    
    for i in addresses_list:
        assert isinstance(i.address(), str) is True


# Generated at 2022-06-25 20:22:13.827433
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='ru')
    assert address.address() == 'Олександра Матросова, 29/1'


# Generated at 2022-06-25 20:22:16.528925
# Unit test for method address of class Address
def test_Address_address():
    address_ = Address()

    assert len(address_.address()) > 0
    assert len(address_.address()) > 0
    assert len(address_.address()) > 0
    assert len(address_.address()) > 0
    assert len(address_.address()) > 0


# Generated at 2022-06-25 20:22:19.904304
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en-Gb')
    result = address.address()
    assert result != None
    assert type(result) == str


# Generated at 2022-06-25 20:22:22.097223
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != None


# Generated at 2022-06-25 20:22:24.391697
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()

# Unit tests for method city of class Address

# Generated at 2022-06-25 20:22:26.341031
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str

# Generated at 2022-06-25 20:22:35.925555
# Unit test for method address of class Address
def test_Address_address():
    address = Address("en")
    assert address.address() in ["Flat 648, Melody Hill, 805 Duke Avenue, "
                                 "Toller Porcorum, Dorset, DT2 0SX",
                                 "Flat 984, Dower Park, 733 Lloyd Avenue, "
                                 "Rotherham, South Yorkshire, S66 3QR"]
    assert address.address() in ["No. 228 Wulin West Road, Binjiang District, "
                                 "Hangzhou, Zhejiang",
                                 "No. 518, Hanzhong Road, Xuhui District, "
                                 "Shanghai, Shanghai"]



# Generated at 2022-06-25 20:22:38.261770
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ''


# Generated at 2022-06-25 20:23:08.913867
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # Invoke method address of class Address
    result_0 = address_0.address()
    assert result_0 is not None


# Generated at 2022-06-25 20:23:13.552219
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    result = add.address()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-25 20:23:15.493782
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:23:17.423166
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address()


# Generated at 2022-06-25 20:23:23.418293
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    # The first element in the following tuple is the address’s locale,
    # the second element is the street name and the third element is the street’s suffix.

# Generated at 2022-06-25 20:23:25.347388
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address.address()) > 0


# Generated at 2022-06-25 20:23:33.924429
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    print('result is: ' + str(result))

    assert all([
        isinstance(result, str),
        len(result) > 0,
        result.isalpha() is False,
    ])


# Generated at 2022-06-25 20:23:34.580516
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() is not None


# Generated at 2022-06-25 20:23:38.134257
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    address_0 = Address()

    for _ in range(10):
        assert type(address_0.address()) is str


# Generated at 2022-06-25 20:23:40.317421
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address()


# Generated at 2022-06-25 20:24:16.290260
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for _ in range(100):
        assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:24:28.187834
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.street_number() != str()
    assert address_0.street_name() != str()
    assert address_0.street_suffix() != str()
    assert address_0.state() != str()
    assert address_0.region() != str()
    assert address_0.province() != str()
    assert address_0.federal_subject() != str()
    assert address_0.prefecture() != str()
    assert address_0.postal_code() != str()
    assert address_0.zip_code() != str()
    assert address_0.country_code() != str()
    assert address_0.country() != str()
    assert address_0.city() != str()
    assert address_0.latitude() != str()
    assert address

# Generated at 2022-06-25 20:24:31.802689
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    expected_0 = '103 Hamilton Way'
    assert result_0 == expected_0


# Generated at 2022-06-25 20:24:44.726168
# Unit test for method address of class Address
def test_Address_address():
    # Test for locale 'ar'
    address_0 = Address(locale='ar')
    assert address_0.address() == "سهيري، عبد القادر بن عبد الله, 1233"

    # Test for locale 'cs'
    address_1 = Address(locale='cs')
    assert address_1.address() == "Pernická 1230/1"

    # Test for locale 'de'
    address_2 = Address(locale='de')
    assert address_2.address() == "Altenberger Weg 21"

    # Test for locale 'en'
    address_3 = Address(locale='en')
    assert address_3.address() == "Needham Road 1160"

    # Test for locale 'es'

# Generated at 2022-06-25 20:24:52.954376
# Unit test for method address of class Address
def test_Address_address():
    address0 = Address()
    address1 = Address()
    address2 = Address()
    address3 = Address()
    address4 = Address()
    address5 = Address()
    print(address0.address())
    print(address1.address())
    print(address2.address())
    print(address3.address())
    print(address4.address())
    print(address5.address())


# Generated at 2022-06-25 20:24:55.423466
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != '', 'AssertionError'
    assert len(address_0.address()) > 0, 'AssertionError'


# Generated at 2022-06-25 20:24:58.294096
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:25:00.275963
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:25:03.633687
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert isinstance(result_0, str)


# Generated at 2022-06-25 20:25:05.844572
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:25:55.653927
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    st_num = address_0.street_number()
    st_name = address_0.street_name()
    st_sfx = address_0.street_suffix()
    result  = address_0.address()
    assert result == st_num + st_name + st_sfx


# Generated at 2022-06-25 20:26:05.956843
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    for _ in range(0, 10): # 10: number of tests
        assert type(address_1.address()) == type('')
        assert address_1.address().find(' ') != -1
        assert address_1.address().find(',') != -1


# Generated at 2022-06-25 20:26:15.511493
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address()
    address_3 = Address(locale='ru')
    address_4 = Address(locale='pt-BR')
    address_5 = Address(locale='ja')
    address_6 = Address(locale='af')
    address_7 = Address(locale='ar')
    address_8 = Address(locale='ar-AE')
    address_9 = Address(locale='ar-BH')
    address_10 = Address(locale='ar-DZ')
    address_11 = Address(locale='ar-EG')
    address_12 = Address(locale='ar-IQ')
    address_13 = Address(locale='ar-JO')
    address_14 = Address(locale='ar-KW')

# Generated at 2022-06-25 20:26:16.428892
# Unit test for method address of class Address
def test_Address_address():
    mimesis.address.address()


# Generated at 2022-06-25 20:26:18.411047
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() in address.street_number() + " " + address.street_name()



# Generated at 2022-06-25 20:26:19.953090
# Unit test for method address of class Address
def test_Address_address():
    provider_address = Address()
    res = provider_address.address()
    assert len(res) != 0


# Generated at 2022-06-25 20:26:20.942618
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address()


# Generated at 2022-06-25 20:26:22.228058
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:26:23.239082
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:26:28.241684
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    address_2 = Address(locale='en')
    address_3 = Address(locale='en')
    address_4 = Address(locale='en')
    address_5 = Address(locale='en')
    address_6 = Address(locale='en')
    address_7 = Address(locale='en')
    address_8 = Address(locale='en')
    address_9 = Address(locale='en')
    address_10 = Address(locale='en')



# Generated at 2022-06-25 20:28:07.507694
# Unit test for method address of class Address
def test_Address_address():
    """Method address of class Address"""
    address_1 = Address()

    output_1 = address_1.address()
    assert not (output_1 is None)
    assert not (output_1 == '')


# Generated at 2022-06-25 20:28:08.706618
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() != 0


# Generated at 2022-06-25 20:28:09.929631
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert type(address_1.address()) is str


# Generated at 2022-06-25 20:28:12.302051
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert len(address_0.address()) > 0


# Generated at 2022-06-25 20:28:12.908634
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() is not None


# Generated at 2022-06-25 20:28:21.692372
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    test_address_1 = address_0.address()
    assert type(test_address_1) is str
    test_address_2 = address_0.address()
    assert type(test_address_2) is str
    test_address_3 = address_0.address()
    assert type(test_address_3) is str
    test_address_4 = address_0.address()
    assert type(test_address_4) is str
    test_address_5 = address_0.address()
    assert type(test_address_5) is str
    test_address_6 = address_0.address()
    assert type(test_address_6) is str
    test_address_7 = address_0.address()
    assert type(test_address_7) is str
    test

# Generated at 2022-06-25 20:28:23.737240
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=123)
    result_0 = address_0.address()
    assert result_0 == '1323 W. Montana Ave.'


# Generated at 2022-06-25 20:28:32.403183
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address(locale='en-US')
    address_2 = Address(locale='zh-CN')
    address_3 = Address(locale='ja')
    street_name_0 = address_0.street_name()
    street_name_1 = address_1.street_name()
    street_name_2 = address_2.street_name()
    street_name_3 = address_3.street_name()
    street_number_0 = address_0.street_number()
    street_number_1 = address_1.street_number()
    street_number_2 = address_2.street_number()
    street_number_3 = address_3.street_number()
    street_suxfix_1 = address_1.street_suffix()
   