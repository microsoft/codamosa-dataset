

# Generated at 2022-06-25 20:18:35.568407
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale = 'el')
    result_0 = address_0.address()
    print(result_0)
    assert result_0 == 'Ι. Περίκλειου 373'


# Generated at 2022-06-25 20:18:37.412337
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for i in range(5):
        print(address.address())


# Generated at 2022-06-25 20:18:41.306245
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    str_1 = address_0.address()
    str_2 = address_0.address()

    assert str_0 == str_1, str_2


# Generated at 2022-06-25 20:18:42.270771
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)
    assert len(address.address()) > 0


# Generated at 2022-06-25 20:18:45.223957
# Unit test for method address of class Address
def test_Address_address():

    import unittest
    class Test_Address(unittest.TestCase):
        def test_address(self):
            address = Address()
            result = address.address()
            self.assertEqual(str(type(result)), "<class 'str'>")

    unittest.main()

# Generated at 2022-06-25 20:18:47.131798
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.country()


# Generated at 2022-06-25 20:18:48.732747
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert str_0



# Generated at 2022-06-25 20:18:50.297140
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()



# Generated at 2022-06-25 20:18:51.507970
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    string = address_1.address()


# Generated at 2022-06-25 20:18:53.219672
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert str_0 == '1800 Schwarz Place'



# Generated at 2022-06-25 20:18:59.092363
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert ' ' not in addr.address()


# Generated at 2022-06-25 20:19:01.158748
# Unit test for method address of class Address
def test_Address_address():
    # Get an instance of address
    address = Address()

    # Call address()
    address()


# Generated at 2022-06-25 20:19:03.630840
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    result = a.address()
    assert result == "1003 rue des Forges"


# Generated at 2022-06-25 20:19:05.070548
# Unit test for method address of class Address
def test_Address_address():
    assert Address().street_number() != Address().street_number()


# Generated at 2022-06-25 20:19:17.338221
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address('ru')
    # address_2 = Address('hy')
    # address_3 = Address('lv')
    # address_4 = Address('ja')
    address_5 = Address('en')

    assert address_0.locale == 'en'
    assert address_1.locale == 'ru'
    # assert address_2.locale == 'hy'
    # assert address_3.locale == 'lv'
    # assert address_4.locale == 'ja'
    assert address_5.locale == 'en'

    # address = '{st_num} {st_name} {st_sfx}'
    # address = '{st_num} {st_name}'
    address_0.address()



# Generated at 2022-06-25 20:19:20.286947
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '1078 Campos Street'



# Generated at 2022-06-25 20:19:29.236614
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(seed=0)
    ans = '338 Range Springs, South Monique, FL 82566'
    assert address_0.street_number() == '338'
    assert address_0.street_name() == 'Range Springs'
    assert address_0.street_suffix() == 'Street'
    assert address_0.state(abbr=True) == 'FL'
    assert address_0.city() == 'South Monique'
    assert address_0.postal_code() == '82566'
    assert address_0.address() == ans


# Generated at 2022-06-25 20:19:39.182870
# Unit test for method address of class Address
def test_Address_address():
    # First test
    address_1 = Address()
    st_num_1 = address_1.street_number()
    st_name_1 = address_1.street_name()
    st_sfx_1 = address_1.street_suffix()
    address_fmt_1 = address_1._data['address_fmt']
    actual_1 = address_fmt_1.format(st_num = st_num_1, st_name = st_name_1, st_sfx = st_sfx_1)
    expected_1 = '124 Brasil'

    assert actual_1 == expected_1

    # Second test
    address_2 = Address()
    st_num_2 = address_2.street_number()
    st_name_2 = address_2.street_name()
    actual_

# Generated at 2022-06-25 20:19:41.813441
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()

# Generated at 2022-06-25 20:19:43.926500
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert isinstance(addr.address(), str)


# Generated at 2022-06-25 20:19:54.064000
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert callable(Address.address)
    assert isinstance(address_0.address(), str)



# Generated at 2022-06-25 20:19:57.846349
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address('vi')
    result = address_0.address()
    assert result != None


# Generated at 2022-06-25 20:20:00.558759
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # Assertions
    print(address_0.address())


# Generated at 2022-06-25 20:20:02.264772
# Unit test for method address of class Address
def test_Address_address():
    # Test case 0
    address_0 = Address()
    assert_equal(isinstance(address_0.address(), str), True)



# Generated at 2022-06-25 20:20:05.017727
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('en')
    result = address_0.address()
    print(result)


# Generated at 2022-06-25 20:20:07.901130
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    assert address_0.address() != address_0.address()


# Generated at 2022-06-25 20:20:12.504548
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result_address_1 = address_1.address()
    assert isinstance(result_address_1, str)


# Generated at 2022-06-25 20:20:14.636830
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address()


# Generated at 2022-06-25 20:20:15.753847
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert len(address.address()) > 0


# Generated at 2022-06-25 20:20:17.922923
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address()


# Generated at 2022-06-25 20:20:27.436939
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-25 20:20:29.089073
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for _ in range(10):
        print(address.address())



# Generated at 2022-06-25 20:20:35.478680
# Unit test for method address of class Address
def test_Address_address():
    # Unit test for English locale
    address_0 = Address(locale="en")
    address_1 = address_0.address()
    assert isinstance(address_1, str)
    assert address_1

    address_0 = Address("en")
    address_1 = address_0.address()
    assert isinstance(address_1, str)
    assert address_1

    # Unit test for Chinese locale
    address_0 = Address(locale="zh")
    address_1 = address_0.address()
    assert isinstance(address_1, str)
    assert address_1

    address_0 = Address("zh")
    address_1 = address_0.address()
    assert isinstance(address_1, str)
    assert address_1

    # Unit test for Japanese locale

# Generated at 2022-06-25 20:20:43.968220
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street = address.street_name()
    number = address.street_number()
    suffix = address.street_suffix()
    zip_code = address.zip_code()
    city = address.city()
    address_composed = str(number) + " " + street + " " + str(suffix) + ", " + str(zip_code) + ", " + city
    address_generated = address.address()
    assert address_generated == address_composed, "The generated address value don't match with the composed value"

# Generated at 2022-06-25 20:20:48.883575
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)
    address_1 = Address()
    assert address_0.address() == address_1.address()


# Generated at 2022-06-25 20:20:57.269740
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address().address()
    has_not_digits_0 = False
    for char in address_0:
        if char.isdigit():
            has_not_digits_0 = True
            break
    assert has_not_digits_0

    address_1 = Address().address()
    has_not_digits_1 = False
    for char in address_1:
        if char.isdigit():
            has_not_digits_1 = True
            break
    assert has_not_digits_1

    address_2 = Address().address()
    has_not_digits_2 = False
    for char in address_2:
        if char.isdigit():
            has_not_digits_2 = True
            break
    assert has_not_digits_2

   

# Generated at 2022-06-25 20:21:01.592992
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert isinstance(address_1.address(), str), f'{address_1.address()} is not a string'


# Generated at 2022-06-25 20:21:03.218848
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None

# Generated at 2022-06-25 20:21:05.514687
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    val1 = address_1.address()


# Generated at 2022-06-25 20:21:08.063577
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:21:26.727992
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    for counter in range(10000):
        address_0.address()


# Generated at 2022-06-25 20:21:28.739095
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    print(address.address())


# Generated at 2022-06-25 20:21:31.817006
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:21:37.542872
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address('en')
    address_2 = Address('de')
    address_3 = Address('ru')
    address_4 = Address('ja')

    print (address_0.address())
    print (address_1.address())
    print (address_2.address())
    print (address_3.address())
    print (address_4.address())

if __name__ == '__main__':
    test_case_0()
    #test_Address_address()

# Generated at 2022-06-25 20:21:41.129933
# Unit test for method address of class Address
def test_Address_address():
    _address = Address()
    _address_result = _address.address()
    assert isinstance(_address_result, str)


# Generated at 2022-06-25 20:21:44.290168
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:21:50.165241
# Unit test for method address of class Address
def test_Address_address():
    print("----- Case 0 -----")
    test_case_0()
    print("----- Case 1 -----")
    address_1 = Address("en-us")
    r = address_1.address()
    print(r)
    print("----- Case 2 -----")
    address_2 = Address("zh")
    r = address_2.address()
    print(r)
    print("----- Case 3 -----")
    address_3 = Address("zh")
    r = address_3.address()
    print(r)


# Generated at 2022-06-25 20:21:53.564859
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() in ['1st St', '7th St', '25th St']



# Generated at 2022-06-25 20:21:56.042073
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    f_result = address_0.address()
    assert isinstance(f_result, str)


# Generated at 2022-06-25 20:22:00.353270
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # result_0 is a str type
    result_0 = address_0.address()



# Generated at 2022-06-25 20:22:24.256955
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert_0 = address_1.address()
    assert_1 = address_1.address()
    try:
        assert_0 == assert_1
    except ValueError:
        assert_0 != assert_1


# Generated at 2022-06-25 20:22:27.952482
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    # Tests that all address formats are valid
    address_format = address.address()
    assert address_format is not None
    assert address_format is not ""
    assert address_format is not False
    assert address_format is not []

# Generated at 2022-06-25 20:22:29.050997
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str


# Generated at 2022-06-25 20:22:30.886087
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:22:35.024302
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    actual = address_1.address()
    assert isinstance(actual, str)


# Generated at 2022-06-25 20:22:39.052057
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    # Check if address has a length that is not zero
    assert len(address.address()) > 0


# Generated at 2022-06-25 20:22:41.057596
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-25 20:22:43.338842
# Unit test for method address of class Address
def test_Address_address():
    for i in range(3):
        print(Address().address())


# Generated at 2022-06-25 20:22:47.723058
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:22:49.464517
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:23:33.924660
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address().address()


# Generated at 2022-06-25 20:23:36.896461
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
    print(address.country())


# Generated at 2022-06-25 20:23:42.721379
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

# Generated at 2022-06-25 20:23:46.359411
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    print(address.address())
    print(address.city())
    print(address.city())


# Generated at 2022-06-25 20:23:52.830934
# Unit test for method address of class Address
def test_Address_address():
    lower_bound = 1 # The lowest possible street number
    upper_bound = 1400 # The highest possible street number
    address_1 = Address()
    address_1.address()
    # Check if the street number is within the given range
    assert(int(address_1.street_number()) >= lower_bound and int(address_1.street_number()) <= upper_bound)
    # Check if street name is not empty
    assert(address_1.street_name() != "")
    address_2 = Address(locale='en')
    # address_2.address()
    assert(address_2.address() == str(address_1.street_number()) + ' ' + address_1.street_name() + ' ' + address_1.street_suffix())
    # Check if the street number is within the given range

# Generated at 2022-06-25 20:23:55.186473
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:23:57.190675
# Unit test for method address of class Address
def test_Address_address():
    assert(Address().address() is not None)


# Generated at 2022-06-25 20:24:07.124545
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    assert(adr.address())


# Generated at 2022-06-25 20:24:17.842141
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.set_locale("en")
    assert address_0.address() == "Col. 5a. Calle Miguel Hidalgo, Mexico, Mexico"
    assert address_0.address() == "240 Vista de la Montana, Manzanillo, Mexico"
    assert address_0.address() == "Calzada de la Esperanza, Ensenada, Mexico"
    assert address_0.address() == "Col. 11a. Calle Cuauhtemoc, Acajete, Mexico"
    assert address_0.address() == "Col. 5a. Calle Miguel Hidalgo, Mexico, Mexico"
    assert address_0.address() == "163 Jose Maria Mora, San Luis Potosi, Mexico"

# Generated at 2022-06-25 20:24:21.008156
# Unit test for method address of class Address
def test_Address_address():
    ad = Address(seed=143)
    assert ad.address() == '166 Park Lodge Apt. 574'


# Generated at 2022-06-25 20:25:41.759232
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    returned_value_1 = address_0.address()
    print(returned_value_1)


# Generated at 2022-06-25 20:25:43.210814
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert len(address.address()) > 10


# Generated at 2022-06-25 20:25:44.085397
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() is not None

# Generated at 2022-06-25 20:25:46.449531
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_result = address_0.address()
    assert isinstance(address_result, str)


# Generated at 2022-06-25 20:25:48.025169
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert str is type(address_0.address())


# Generated at 2022-06-25 20:26:05.957662
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address('ru')
    address_2 = Address('ja')

    # Ensure that the method address generates at least 6 unique values
    # and no one is empty.
    assert [address_0.address() for _ in range(6)] != ['' for _ in range(6)], "Method address of class Address \
        is expected to generate at least 6 unique values, but instead, it generated a list of values with \
        length 6 and all of them are empty."
    assert [address_0.address() for _ in range(6)] != [address_0.address() for _ in range(6)], "Method address \
        of class Address is expected to generate at least 6 unique values, but instead, it generated a list \
        of values with length 6, and all of them are equal."

# Generated at 2022-06-25 20:26:07.667346
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = str(address_0.address())
    assert result != ''
    assert ' ' in result


# Generated at 2022-06-25 20:26:08.882230
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:26:11.191722
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address = address_0.address()
    print(address)


# Generated at 2022-06-25 20:26:19.828504
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()
    assert Address().address() in Address().address()