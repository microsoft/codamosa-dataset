

# Generated at 2022-06-25 20:18:33.764461
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert type(str_0) == str


# Generated at 2022-06-25 20:18:35.500758
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:18:37.334281
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:39.503346
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    actual = address.address()
    assert actual is not None


# Generated at 2022-06-25 20:18:43.610992
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    str_1 = address_0.address()
    str_2 = address_0.address()
    str_3 = address_0.address()
    str_4 = address_0.address()
    str_5 = address_0.address()


# Generated at 2022-06-25 20:18:44.280719
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert len(result) > 0

# Generated at 2022-06-25 20:18:48.390320
# Unit test for method address of class Address
def test_Address_address():
    # Test 1
    provider = Address()
    str_0 = provider.address()
    assert len(str_0) > 0

    # Test 2
    provider = Address(locale='ja')
    str_0 = provider.address()
    assert len(str_0) > 0



# Generated at 2022-06-25 20:18:49.959736
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:18:54.539420
# Unit test for method address of class Address
def test_Address_address():
    test_Address = Address()

    Address.address(test_Address)


# Generated at 2022-06-25 20:18:55.800163
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()


# Generated at 2022-06-25 20:19:02.866453
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    a = address.address()
    assert not a is None, "Error: Getting Address address failed"


# Generated at 2022-06-25 20:19:04.136528
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None



# Generated at 2022-06-25 20:19:06.140259
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_1.address()


# Generated at 2022-06-25 20:19:08.373427
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) == str


# Generated at 2022-06-25 20:19:13.116345
# Unit test for method address of class Address
def test_Address_address():
    random_locale = "af"
    address_0 = Address(random_locale)
    # str
    result = address_0.address()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-25 20:19:16.629085
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()

    # Test an assertion of unit test
    assert address_0.address() != address_1.address() == address_2.address()


# Generated at 2022-06-25 20:19:18.538201
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:19:20.433313
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != ''


# Generated at 2022-06-25 20:19:21.851613
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address() != None


# Generated at 2022-06-25 20:19:24.588077
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result = address_1.address()
    print(result)


# Generated at 2022-06-25 20:19:36.045836
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_1 = Address()
    address_2 = Address()
    print(address_0.address())
    print(address_1.address())
    print(address_2.address())
    return address_0.address(),address_1.address(),address_2.address()


# Generated at 2022-06-25 20:19:41.453333
# Unit test for method address of class Address
def test_Address_address():
    debug = True
    address_0 = Address()
    result_0 = address_0.address()

# Generated at 2022-06-25 20:19:45.503549
# Unit test for method address of class Address
def test_Address_address():
    # case 0
    address_0 = Address()
    # get address
    res_0 = address_0.address()
    assert type(res_0) is str


# Generated at 2022-06-25 20:19:47.266879
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    print(address_1.address())

# Generated at 2022-06-25 20:19:49.691279
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:19:53.152328
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    assert address_1.address()
    # TODO: more test case


# Generated at 2022-06-25 20:19:56.913360
# Unit test for method address of class Address
def test_Address_address():
    assert isinstance(Address().address(), str)


# Generated at 2022-06-25 20:19:59.511373
# Unit test for method address of class Address
def test_Address_address():
    result = Address().address()
    assert isinstance(result, str), "Address().address() returns type %s" % type(result)


# Generated at 2022-06-25 20:20:02.201138
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:20:06.257494
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # AssertionError: 'None' != '1400'
    assert address_0.street_number() != '1400'


# Generated at 2022-06-25 20:20:21.111236
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    str_0 = address_0.address()
    str_1 = address_0.address()
    str_2 = address_0.address()
    assert str_0
    assert str_1
    assert str_2


# Generated at 2022-06-25 20:20:24.666730
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    result = provider.address()
    assert result
    assert type(result) == str


# Generated at 2022-06-25 20:20:28.165476
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '1930 12th St. SW'


# Generated at 2022-06-25 20:20:29.881374
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(randomize=False)
    assert(address_0.address() == "1072 Rue de la Paix")

# Generated at 2022-06-25 20:20:32.314467
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) >= 5


# Generated at 2022-06-25 20:20:35.579107
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    value = address_0.address()
    print(value)


# Generated at 2022-06-25 20:20:39.337109
# Unit test for method address of class Address
def test_Address_address():
    address = Address().address()
    assert isinstance(address, str)
    assert len(address) > 0


# Generated at 2022-06-25 20:20:40.955602
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:20:44.043569
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    out_0 = address_0.address()
    logger.info(out_0)


# Generated at 2022-06-25 20:20:55.725325
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    assert isinstance(address_0.address(), str)
    assert isinstance(address_0.city(), str)
    assert isinstance(address_0.street_number(), str)
    assert isinstance(address_0.street_name(), str)
    assert isinstance(address_0.street_suffix(), str)
    assert isinstance(address_0.address(), str)
    assert isinstance(address_0.region(), str)
    assert isinstance(address_0.province(), str)
    assert isinstance(address_0.postal_code(), str)
    assert isinstance(address_0.zip_code(), str)
    assert isinstance(address_0.country_code(), str)
    assert isinstance(address_0.country_code(CountryCode.A2), str)


# Generated at 2022-06-25 20:21:24.971987
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('zh-CN')
    str_0 = address_0.address()
    str_1 = address_0.address()
    str_2 = address_0.address()
    print(str_0, str_1, str_2)


# Test
if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-25 20:21:28.675992
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    ret_1 = address_0.address()
    assert isinstance(ret_1, str)


# Generated at 2022-06-25 20:21:31.747265
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    result = address_1.address()
    assert result != ""


# Generated at 2022-06-25 20:21:33.759243
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())


# Generated at 2022-06-25 20:21:36.917050
# Unit test for method address of class Address
def test_Address_address():
    """Tests method address of class Address

    :return: None
    """
    address_0 = Address()
    count = 0
    while True:
        if count > 10000:
            break
        address = address_0.address()
        assert isinstance(address, str)

        count = count + 1



# Generated at 2022-06-25 20:21:41.056948
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address(locale='en')  # English

    address_1 = Address(locale='ja')  # Japanese



# Generated at 2022-06-25 20:21:43.721032
# Unit test for method address of class Address
def test_Address_address():
    provider = Address(locale="en")
    assert provider.address() is not None


# Generated at 2022-06-25 20:21:47.894493
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()

    assert address_0.address() == '45 Southend Lane'

    address_1 = Address('uk')

    assert address_1.address() == '1A Southend Lane'

    address_2 = Address('en')

    assert address_2.address() == '1A Southend Lane'

    address_3 = Address('en_GB')

    assert address_3.address() == '1A Southend Lane'



# Generated at 2022-06-25 20:21:49.273755
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print(address_0.address())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-25 20:21:50.517717
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address = address_1.address()
    assert type(address) == str


# Generated at 2022-06-25 20:22:18.876626
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0, Address)
    assert address_0.address()


# Generated at 2022-06-25 20:22:23.663880
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # address_0.address
    assert len(address_0.address()) == 17
    # address_0.address
    assert len(address_0.address()) == 17


# Generated at 2022-06-25 20:22:25.451007
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert(address.address())



# Generated at 2022-06-25 20:22:26.598276
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address."""


# Generated at 2022-06-25 20:22:37.020565
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street_number = address.street_number()
    street_name = address.street_name()
    street_name_full = street_number + ' ' + street_name
    street_suffix = address.street_suffix()
    street_name_full_with_suffix = street_number + ' ' + street_name + ' ' + street_suffix
    address_fmt_list = address._data['address_fmt'].replace(' ', '').replace('\n', '').split('{')
    assert street_name_full in address.address()
    for address_fmt in address_fmt_list:
        if 'st_num' in address_fmt:
            assert street_number in address.address()
        elif 'st_name' in address_fmt:
            assert street

# Generated at 2022-06-25 20:22:40.079027
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:22:42.183345
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    result = address.address()
    assert result



# Generated at 2022-06-25 20:22:43.514114
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    _address = address_1.address()
    assert type(_address) == str
    assert len(_address) != 0


# Generated at 2022-06-25 20:22:48.559861
# Unit test for method address of class Address
def test_Address_address():
    # Using default locale
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)
    address_1 = Address(locale='ru')
    result = address_1.address()
    assert isinstance(result, str)
    address_2 = Address(locale='ru')
    result = address_2.address()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:22:53.066621
# Unit test for method address of class Address
def test_Address_address():
    # Case 0:
    address_0 = Address()
    for i in range(1,4):
        assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:23:24.501099
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:23:26.954132
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() == '1 rue des lilas'


# Generated at 2022-06-25 20:23:33.924691
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed=0)
    expected = '94 rue du Faubourg Saint-Honoré'
    actual = address.address()
    assert expected == actual
    assert isinstance(actual, str)


# Generated at 2022-06-25 20:23:35.835912
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert(isinstance(address, Address))
    address_0 = address.address()
    assert(isinstance(address_0, str))
    assert(isinstance(address_0.rsplit(), list))


# Generated at 2022-06-25 20:23:38.100021
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    _result = address_0.address()
    print("address: %s" % _result)


# Generated at 2022-06-25 20:23:40.317730
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert len(address.address()) > 0



# Generated at 2022-06-25 20:23:44.698845
# Unit test for method address of class Address
def test_Address_address():
    # Parameters
    address = Address('en')
    # result should be a string
    result = isinstance(address.address(), str)
    assert result is True


# Generated at 2022-06-25 20:23:47.867001
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result = address_0.address()
    assert isinstance(result, str)



# Generated at 2022-06-25 20:23:50.431035
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert address_0.address() is not None


# Generated at 2022-06-25 20:23:54.181352
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    print('address_0.address() = ' + address_0.address())


# Generated at 2022-06-25 20:24:36.013581
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0_result = address_0.address()
    assert isinstance(address_0_result, str)



# Generated at 2022-06-25 20:24:36.846520
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()


# Generated at 2022-06-25 20:24:46.326861
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    #
    # print(address_0.address())
    # print(address_0.address())
    # print(address_0.address())
    # print(address_0.address())
    # print(address_0.address())
    # print(address_0.address())
    # print(address_0.address()),
    #
    # print('=======================================')
    #
    # address_0.set_locale('en-GB')
    # print(address_0.address()),
    # print(address_0.address()),
    # print(address_0.address()),
    # print(address_0.address()),
    # print(address_0.address()),
    # print(address_0.address()),
    #
    # print('

# Generated at 2022-06-25 20:24:56.639832
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('en')
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    print(address_0.address())
    address_1 = Address('ru')
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    print(address_1.address())
    address_2 = Address('ja')
    print(address_2.address())

# Generated at 2022-06-25 20:24:59.871265
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert isinstance(address_0.address(), str)


# Generated at 2022-06-25 20:25:08.029969
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    r = address.street_suffix()
    assert isinstance(r, str)
    r = address.region()
    assert isinstance(r, str)
    r = address.region(abbr=True)
    assert isinstance(r, str)
    r = address.state()
    assert isinstance(r, str)
    r = address.state(abbr=True)
    assert isinstance(r, str)
    r = address.province()
    assert isinstance(r, str)
    r = address.province(abbr=True)
    assert isinstance(r, str)
    r = address.federal_subject()
    assert isinstance(r, str)
    r = address.federal_subject(abbr=True)
    assert isinstance(r, str)


# Generated at 2022-06-25 20:25:12.686729
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('en')
    address_1 = Address('en')
    address_0.address() == address_1.address()


# Generated at 2022-06-25 20:25:15.349422
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    actual_address = address_0.address()
    expected_address = actual_address
    assert actual_address == expected_address


# Generated at 2022-06-25 20:25:27.751902
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address()
    address_2 = Address(locale='de')
    address_3 = Address(locale='en')
    address_4 = Address(locale='es')
    address_5 = Address(locale='fr')
    address_6 = Address(locale='it')
    address_7 = Address(locale='nl')
    address_8 = Address(locale='pl')
    address_9 = Address(locale='ru')
    address_10 = Address(locale='hu')
    address_11 = Address(locale='ja')
    print('address_1.address() = ', address_1.address())
    print('address_2.address() = ', address_2.address())
    print('address_3.address() = ', address_3.address())

# Generated at 2022-06-25 20:25:31.406041
# Unit test for method address of class Address
def test_Address_address():
    for i in range(20):
        address = Address()
        fullAddress = address.address()
        assert fullAddress is not None


# Generated at 2022-06-25 20:26:41.981425
# Unit test for method address of class Address
def test_Address_address():

    address_0 = Address()
    address_1 = Address(locale='en')
    address_2 = Address(locale='ja')
    address_3 = Address(locale='ru')
    address_4 = Address(locale='de')

    assert isinstance(address_0.address(), str)
    assert isinstance(address_1.address(), str)
    assert isinstance(address_2.address(), str)
    assert isinstance(address_3.address(), str)
    assert isinstance(address_4.address(), str)

    print(address_0.address())
    print(address_1.address())
    print(address_2.address())
    print(address_3.address())
    print(address_4.address())


# Generated at 2022-06-25 20:26:44.221971
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address(locale='en-US')
    res_0 = address_1.address()
    assert res_0


# Generated at 2022-06-25 20:26:45.365855
# Unit test for method address of class Address
def test_Address_address():
    address_1 = Address().address()


# Generated at 2022-06-25 20:26:47.661062
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    assert len(address_0.address()) > 0


# Generated at 2022-06-25 20:26:48.819949
# Unit test for method address of class Address
def test_Address_address():
    yield test_case_0

# Generated at 2022-06-25 20:26:56.678122
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address('ru')

    # 1st step - test True case
    assert 'улица' in address_0.address()

    # 2nd step - test False case
    address_1 = Address('ru')

    assert 'улица' not in address_1.address()

    # 3nd step - test True case
    address_2 = Address('en')

    assert 'Street' in address_2.address()

    # 4th step - test False case
    address_3 = Address('en')

    assert 'Street' not in address_3.address()

    # 5th step - test True case
    address_4 = Address('ru')

    st0 = address_4.street_number()
    st1 = address_4.street_name()

# Generated at 2022-06-25 20:26:58.139090
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    address.address();


# Generated at 2022-06-25 20:27:00.006671
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    # used for testing
    assert address_0.address()


# Generated at 2022-06-25 20:27:09.246152
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    street_number = address.street_number()
    street_name = address.street_name()

    if address.locale in SHORTENED_ADDRESS_FMT:
        assert address.address() == f"{street_number} {street_name}"

    if address.locale == 'ja':
        city = address.random.choice(address._data['city'])
        assert address.address() == "{0} {1} {2} - {3}".format(city, *address.random.randints(amount=3, a=1, b=100))

    street_suffix = address.street_suffix()
    assert address.address() == f"{street_number} {street_name} {street_suffix}"



# Generated at 2022-06-25 20:27:10.073671
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())


# Generated at 2022-06-25 20:28:17.084536
# Unit test for method address of class Address
def test_Address_address():
    assert type(Address().address()) == str


# Generated at 2022-06-25 20:28:18.824043
# Unit test for method address of class Address
def test_Address_address():
    address = Address(locale='en')
    assert len(address.address()) > 0


# Generated at 2022-06-25 20:28:20.597038
# Unit test for method address of class Address
def test_Address_address():
    for i in range(10000):
        assert(len(Address().address()) == 15)


# Generated at 2022-06-25 20:28:21.784552
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    address_0.address()


# Generated at 2022-06-25 20:28:23.573208
# Unit test for method address of class Address
def test_Address_address():
    address_0 = Address()
    result_0 = address_0.address()
    assert isinstance(result_0, str)
