

# Generated at 2022-06-23 20:58:23.350852
# Unit test for method province of class Address
def test_Address_province():
    address = Address('en')
    assert address.province() in [
        'AB', 'AL', 'AZ', 'BC', 'CA', 'DC', 'FL', 'IA', 'KS', 'KY',
        'LA', 'ME', 'MO', 'MS', 'NC', 'NH', 'NV', 'PA', 'PE', 'PR',
        'SC', 'SD', 'TX', 'UT', 'VT', 'WA', 'WI',
    ]

# Generated at 2022-06-23 20:58:28.637223
# Unit test for method country_code of class Address
def test_Address_country_code():
  from mimesis.enums import CountryCode
  from mimesis.providers.address import Address
  address = Address()
  assert address.country_code() in CountryCode.A2.value


# Generated at 2022-06-23 20:58:30.384343
# Unit test for method zip_code of class Address
def test_Address_zip_code():
  address = Address('en')
  assert address.zip_code() != None, "The method returned None"
  

# Generated at 2022-06-23 20:58:32.654687
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) is str
    assert type(address.address(allow_random=True)) is str


# Generated at 2022-06-23 20:58:37.026196
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale

    generator = Address(Locale.RU)
    city = generator.city()

    assert city in generator._data['city']


# Generated at 2022-06-23 20:58:38.475088
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address().prefecture() in Address()._data['state']['name']

# Generated at 2022-06-23 20:58:42.691914
# Unit test for method country_code of class Address
def test_Address_country_code():
    import random
    country = Address(random.randint(0,1000000))
    if country.country_code():
        assert 1
    else:
        assert 0


# Generated at 2022-06-23 20:58:47.782602
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adr = Address()
    # Get a random
    assert adr.federal_subject() in adr._data['state']['abbr']
    # Get a random federal subject in a abbreviation
    assert adr.federal_subject(abbr=True) in adr._data['state']['abbr']


# Generated at 2022-06-23 20:58:48.576716
# Unit test for method province of class Address
def test_Address_province():
    assert type(Address().province()) is str

# Generated at 2022-06-23 20:58:51.229356
# Unit test for method state of class Address
def test_Address_state():

    address = Address()
    assert address.state() in address.province()
    

# Generated at 2022-06-23 20:58:52.397400
# Unit test for method state of class Address
def test_Address_state():
    provider = Address()
    assert provider.state() != None


# Generated at 2022-06-23 20:59:03.394284
# Unit test for method latitude of class Address
def test_Address_latitude():
    import decimal
    import math
    from decimal import Decimal
    from mimesis.enums import CountryCode

    a = Address(locale="en")

    tmp = a.latitude(dms=True)

    assert isinstance(tmp, str)
    assert tmp is not None

    tmp = tmp.replace("º", "")
    tmp = tmp.replace("'", "")
    tmp = tmp.replace("\"", "")
    tmp = tmp.replace("N", "")
    tmp = tmp.replace("S", "")

    lt = tmp.split(".")

    if len(lt) == 1:
        lt.append("0")
    
    deg = int(lt[0])
    min = int(lt[1][0:2])
    sec = int(lt[1][2:4]) + int

# Generated at 2022-06-23 20:59:08.669750
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    a = Address()

    # test_default_value
    assert a.state() in a._data['state']['name'] # noqa

    # test_abbr
    assert a.state(abbr=True) in a._data['state']['abbr']

    # test_region
    assert a.region() in a._data['state']['name'] # noqa

    # test_province
    assert a.province() in a._data['state']['name'] # noqa

    # test_federal_subject
    assert a.federal_subject() in a._data['state']['name'] # noqa

    # test_prefecture
    assert a.prefecture() in a._data['state']['name'] # noqa

    # test

# Generated at 2022-06-23 20:59:10.725888
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state(abbr=True)!= None


# Generated at 2022-06-23 20:59:14.688438
# Unit test for constructor of class Address
def test_Address():
    address = Address('ru')
    assert address.address() is not None
    assert address.continent() is not None
    assert address.region() is not None
    assert address.province() is not None
    assert address.postal_code() is not None

# Generated at 2022-06-23 20:59:15.991893
# Unit test for method city of class Address
def test_Address_city():
    ad = Address()
    assert ad.city()


# Generated at 2022-06-23 20:59:17.918895
# Unit test for method city of class Address
def test_Address_city():
    # Object of class Address
    address = Address()

    # City in format of string
    assert type(address.city()) == str


# Generated at 2022-06-23 20:59:24.432929
# Unit test for method state of class Address
def test_Address_state():
    a = Address(random_state=3)
    assert a.state() == 'BK'
    assert a.state() == 'BR'
    assert a.state() == 'CG'
    assert a.state() == 'ES'
    assert a.state() == 'GC'
    assert a.state() == 'GR'
    assert a.state() == 'HU'
    assert a.state() == 'MD'
    assert a.state() == 'PR'
    assert a.state() == 'SL'

# Generated at 2022-06-23 20:59:26.025773
# Unit test for method street_number of class Address
def test_Address_street_number():
    print(Address.street_number(maximum=20))
    print(Address.street_number())


# Generated at 2022-06-23 20:59:29.059731
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address()
    result = addr.street_suffix()
    assert isinstance(result, str)
    assert result != 'None'


# Generated at 2022-06-23 20:59:33.486701
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Testing Address zip_code."""
    adr = Address()

    zc = adr.zip_code()
    assert zc

    zc = adr.zip_code(locale='ru')
    assert zc

# Generated at 2022-06-23 20:59:42.624603
# Unit test for method state of class Address
def test_Address_state():
    address = Address('en')
    for i in range(10):
        assert address.state() in address._data['state']['name']
        assert address.region() in address._data['state']['name']
        assert address.province() in address._data['state']['name']
        assert address.federal_subject() in address._data['state']['name']
        assert address.prefecture() in address._data['state']['name']
        assert address.state(abbr=True) in address._data['state']['abbr']
        assert address.region(abbr=True) in address._data['state']['abbr']
        assert address.province(abbr=True) in address._data['state']['abbr']
        assert address.federal_subject(abbr=True)

# Generated at 2022-06-23 20:59:45.557315
# Unit test for method address of class Address
def test_Address_address():
    """ Test the address method in Address class"""
    # assert Address().address() == '1761 Marvin Garden Apt. 711'
    assert Address().address() == '1761 Oxford Street'



# Generated at 2022-06-23 20:59:47.729851
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    assert (len(a.postal_code())) == (len(a._data['postal_code_fmt']))

# Generated at 2022-06-23 20:59:48.814911
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country() == 'China'

# Generated at 2022-06-23 20:59:50.252153
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    mock = Address('en')
    return mock.prefecture()


# Generated at 2022-06-23 20:59:52.720994
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    addr = Address(seed=1)
    for i in range(5):
        # '57' is the calling code for Colombia
        assert addr.calling_code() == '57'

# Generated at 2022-06-23 20:59:55.713208
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    zip_code = Address._zip_code()
    # Validate whether the zip code is generated as expected
    assert type(zip_code) == str
    assert len(zip_code) == 9


# Generated at 2022-06-23 20:59:59.009168
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    result = a.street_suffix()
    assert result not in ("", [])

# Generated at 2022-06-23 20:59:59.432373
# Unit test for method region of class Address
def test_Address_region():
    pass

# Generated at 2022-06-23 21:00:02.320236
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert a.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:00:04.585275
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('en')
    print(f'Street suffix = {address.street_suffix()}')


# Generated at 2022-06-23 21:00:07.179066
# Unit test for method address of class Address
def test_Address_address():
    add=Address("en")
    results = []
    for i in range(100):
        results.append(add.address())
    assert results != []


# Generated at 2022-06-23 21:00:11.500603
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a.address()
    assert a.postal_code()
    assert a.zip_code()
    assert a.state()
    assert a.region()
    assert a.province()
    assert a.federal_subject()
    assert a.prefecture()
    assert a.city()
    assert a.latitude()
    assert a.longitude()
    assert a.coordinates()
    assert a.continent()
    assert a.calling_code()
    assert a.country_code()
    assert a.street_number()
    assert a.street_name()
    assert a.street_suffix()


# Generated at 2022-06-23 21:00:13.084966
# Unit test for method street_number of class Address
def test_Address_street_number():
    addr = Address()
    print (addr.street_number())
#print(Address().street_number())


# Generated at 2022-06-23 21:00:14.805872
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:00:26.706827
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address

    ad = Address(locale='ar')
    region = ad.province()
    print(region)
    country_code = ad.country_code(fmt=CountryCode.A2)
    print(country_code)
    country = ad.country()
    print(country)
    city = ad.city()
    print(city)
    postal_code = ad.postal_code()
    print(postal_code)
    state = ad.state()
    print(state)
    street_name = ad.street_name()
    print(street_name)
    street_number = ad.street_number()
    print(street_number)
    street

# Generated at 2022-06-23 21:00:30.260659
# Unit test for method street_name of class Address
def test_Address_street_name():
    """Test street_name() from Address class."""
    from mimesis.providers.address import Address
    from mimesis.enums import Language

    address = Address(Language.EN)
    for _ in range(5):
        assert address.street_name() in address._data['street']['name']


# Generated at 2022-06-23 21:00:32.397608
# Unit test for method country of class Address
def test_Address_country():
    a = Address('zh')
    print(a.country())

if __name__ == "__main__":
    test_Address_country()

# Generated at 2022-06-23 21:00:40.119163
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()

# Generated at 2022-06-23 21:00:41.345469
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address(locale='ja')
    address.prefecture()

# Generated at 2022-06-23 21:00:43.990593
# Unit test for method city of class Address
def test_Address_city():
    provider=Address()
    print(provider.city())

if __name__=='__main__':
    test_Address_city()

# Generated at 2022-06-23 21:00:47.216357
# Unit test for method latitude of class Address
def test_Address_latitude():

    a = Address(seed=42)
    print(a.latitude()) # -58.013947
    print(a.latitude()) # -71.985962


# Generated at 2022-06-23 21:00:48.304526
# Unit test for method country of class Address
def test_Address_country():
    print(Address(current_locale='zh').country())

# Generated at 2022-06-23 21:00:49.903977
# Unit test for method province of class Address
def test_Address_province():
    """Test to check if method province returns
    an administrative district of current locale.
    """
    address = Address('ru')
    assert address.province() in address._data['state']['name']

# Generated at 2022-06-23 21:00:50.741883
# Unit test for method city of class Address
def test_Address_city():

    result = Address(seed=10).city()
    print(result)


# Generated at 2022-06-23 21:00:53.712300
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    postal_code = address.postal_code()
    assert(len(postal_code) == 5)
    assert(postal_code.isdigit() == True)


# Generated at 2022-06-23 21:00:54.638305
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adrs = Address()
    assert type(adrs.federal_subject()) == str


# Generated at 2022-06-23 21:00:56.356469
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    address_test = address.federal_subject()
    assert address_test is not None

# Generated at 2022-06-23 21:00:58.120185
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr = Address()
    assert len(addr.street_name()) > 0


# Generated at 2022-06-23 21:01:00.944317
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    import mimesis
    a = mimesis.Address('zh')
    b = a.prefecture()
    assert type(b) == str


# Generated at 2022-06-23 21:01:10.553915
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """
    日本の県名をランダムに返すことを確認する
    """
    address = Address()
    prefecture = address.prefecture()


# Generated at 2022-06-23 21:01:11.049958
# Unit test for method country of class Address
def test_Address_country():
    pass

# Generated at 2022-06-23 21:01:23.404125
# Unit test for method country_code of class Address
def test_Address_country_code():
    ad = Address()
    # Test for ISO 3166-1-alpha2 (default):
    from mimesis.enums import CountryCode
    c = CountryCode.A2
    _cc = ad.country_code()
    assert _cc in COUNTRY_CODES[c.value]
    # Test for ISO 3166-1-alpha3:
    c = CountryCode.A3
    _cc = ad.country_code(fmt=c)
    assert _cc in COUNTRY_CODES[c.value]
    # Test for ISO 3166-1-numeric:
    c = CountryCode.NUMERIC
    _cc = ad.country_code(fmt=c)
    assert _cc in COUNTRY_CODES[c.value]
    # Test for unsupported fmt:

# Generated at 2022-06-23 21:01:26.475395
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address(random.seed(0))
    assert a.country_code(CountryCode.A2) == "CL"
    assert a.country_code(CountryCode.A3) == "CHL"

# Generated at 2022-06-23 21:01:32.559093
# Unit test for method city of class Address
def test_Address_city():
    print()
    print("-------------------Start Test Address class city-------------------")
    # set default locale is "en"
    address = Address()
    print("Default Address:",address)
    #get a random city
    print("Address city:",address.city())

    # set locale is "ja"
    address = Address('ja')
    print("-------------------Set locale is ja-------------------")
    print("Address ja city:",address.city())
    print("-------------------End Test Address class city-------------------")
    print("\n")


# Generated at 2022-06-23 21:01:34.635355
# Unit test for method province of class Address
def test_Address_province():
    instance = Address()
    result = instance.province()
    print(result)
    assert result is not None


# Generated at 2022-06-23 21:01:35.564241
# Unit test for method address of class Address
def test_Address_address():
    print()
    addr = Address()
    print(addr.address())


# Generated at 2022-06-23 21:01:37.036225
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    # print(a.street_number())
    assert a.street_number().isdigit()


# Generated at 2022-06-23 21:01:38.193656
# Unit test for method latitude of class Address
def test_Address_latitude():
    instance = Address()
    assert -90 <= float(instance.latitude()) <= 90


# Generated at 2022-06-23 21:01:40.944996
# Unit test for method country of class Address
def test_Address_country():
    @addresses.register('en')
    class AddressEN(Address):
        class Meta:
            name = 'address'
            locales = ['en']
    address = AddressEN()
    assert address.country(allow_random=True) in address._data['country']['name']
    assert address.country() in address._data['country']['name']

# Generated at 2022-06-23 21:01:44.776557
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test for method Address.coordinates()."""
    assert(Address().latitude() in range(-90, 90))
    assert(Address().longitude() in range(-180, 180))

# Generated at 2022-06-23 21:01:48.422191
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from pdb import set_trace; set_trace()
    address = Address(locale='ru')
    print(address.federal_subject())

if __name__ == '__main__':
    test_Address_federal_subject()

# Generated at 2022-06-23 21:01:57.593666
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    a = Address(locale='en')
    n1 = a.latitude() # Test case 1: Return value should be a float number in [-90, 90] 
    n2 = a.latitude(dms=True) # Test case 2: Return value should be a string
    n3 = a.street_number() # Test case 3: Return value should be a string
    n4 = a.street_

# Generated at 2022-06-23 21:01:59.975225
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    coordinates = address.coordinates()
    assert isinstance(coordinates, dict)
    assert 'longitude' in coordinates.keys()
    assert 'latitude' in coordinates.keys()

# Generated at 2022-06-23 21:02:01.080444
# Unit test for method state of class Address
def test_Address_state():
    assert 'office' in Address().state()
    assert Address().state() == 'KY'


# Generated at 2022-06-23 21:02:03.182317
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    continent = address.continent(code=True)
    assert continent in CONTINENT_CODES
    assert isinstance(continent, str)
    assert continent == "EW"

# Generated at 2022-06-23 21:02:11.032120
# Unit test for method country_code of class Address
def test_Address_country_code():
    obj = Address()
    obj.seed(0)
    assert 'US' == obj.country_code(CountryCode.A2)

    obj.seed(1)
    assert 'US' == obj.country_code(CountryCode.A2)

    obj.seed(2)
    assert 'US' == obj.country_code(CountryCode.A2)

    obj.seed(0)
    assert 'USA' == obj.country_code(CountryCode.A3)

    obj.seed(1)
    assert 'USA' == obj.country_code(CountryCode.A3)

    obj.seed(2)
    assert 'USA' == obj.country_code(CountryCode.A3)

    obj.seed(0)
    assert '840' == obj.country_code(CountryCode.NUMERIC)


# Generated at 2022-06-23 21:02:12.629480
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address().continent()
    assert address in 'Europe'


# Generated at 2022-06-23 21:02:14.368998
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert isinstance(address, Address)


# Generated at 2022-06-23 21:02:24.391712
# Unit test for method state of class Address
def test_Address_state():
    addr = Address()
    res = addr.state()
    assert 5 == len(res)
    res = addr.state(abbr=True)
    if addr.locale == 'be':
        assert 2 == len(res)
        assert res in ['БН', 'ВН', 'ГН', 'ГРН', 'МН', 'МНМ', 'АН', 'БРН', 'ГРН',
                       'ДРН', 'МН', 'МНГ', 'МНД', 'МНР', 'СНГ', 'ТН', 'ВИН',
                       'БРН']

# Generated at 2022-06-23 21:02:26.988166
# Unit test for method country of class Address
def test_Address_country():
    data = Address().country()
    assert isinstance(data, str) and bool(data)


# Generated at 2022-06-23 21:02:27.996770
# Unit test for method address of class Address
def test_Address_address():
  address = Address()
  assert address.address()


# Generated at 2022-06-23 21:02:30.759237
# Unit test for constructor of class Address
def test_Address():

    a = Address()
    assert a is not None

# Generated at 2022-06-23 21:02:40.431833
# Unit test for method state of class Address
def test_Address_state():
    import unittest
    # call method and get result
    state_result = Address(locale='en').state()
    # check result
    assert isinstance(state_result, str)
    assert state_result in ['WI', 'AZ', 'CA', 'NH', 'MT', 'RI', 'VT', 'NJ', 'IA', 'IN', 'OK', 'ME', 'KY', 'OR', 'KS', 'SC', 'MS', 'MN', 'NV', 'VA', 'MD', 'HI', 'GA', 'DE', 'FL', 'UT', 'AK', 'WY', 'CT', 'TN', 'LA', 'AL', 'NE', 'CO', 'ND', 'MO', 'AR', 'MI', 'WA', 'PA', 'ID', 'MA', 'DC', 'TX', 'NY', 'IL']


# Generated at 2022-06-23 21:02:41.734817
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    addr = Address()
    assert isinstance(addr.prefecture(), str)

# Generated at 2022-06-23 21:02:45.356694
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for method federal_subject of class Address."""
    addr = Address(locale='ru')
    res = addr.federal_subject()
    assert res in addr._data['state']['name']

    res = addr.federal_subject(abbr=True)
    assert res in addr._data['state']['abbr']

# Generated at 2022-06-23 21:02:52.395702
# Unit test for method country of class Address
def test_Address_country():
    '''
    Testing country method for three locales (US, RU, JP)
    '''
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.US)
    assert a.country() == 'United States'
    a = Address(Locale.RU)
    assert a.country() == 'Россия'
    a = Address(Locale.JP)
    assert a.country() == '日本'


# Generated at 2022-06-23 21:02:57.030970
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    import pytest
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    address = Address()
    zip_code = address.zip_code()
    assert zip_code

    address = Address(locale='ru')
    zip_code = address.zip_code()
    assert zip_code == '123456'


# Generated at 2022-06-23 21:03:00.319270
# Unit test for method country of class Address
def test_Address_country():
    """Test the functionality of class method country.
    """
    address = Address(locale="es-ES")
    assert address.country() == "España"


# Generated at 2022-06-23 21:03:02.639630
# Unit test for method city of class Address
def test_Address_city():
    a = Address('en')
    assert isinstance(a.city(), str)


# Generated at 2022-06-23 21:03:04.014484
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    print(Address.prefecture(Address))


# Generated at 2022-06-23 21:03:06.451272
# Unit test for method continent of class Address
def test_Address_continent():
    """Test method continent of class Address."""
    adr = Address()
    assert adr.continent() in adr._data['continent']

# Generated at 2022-06-23 21:03:08.262888
# Unit test for method country of class Address
def test_Address_country():
    add = Address()
    result = add.country()
    assert type(result) == str
    assert result == 'China'

# Generated at 2022-06-23 21:03:09.652716
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert isinstance(address.prefecture(), str)

# Generated at 2022-06-23 21:03:11.659941
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() < 90
    assert Address().latitude() > -90


# Generated at 2022-06-23 21:03:20.276534
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers import Generic
    import re

    p = Address('en')
    g = Generic('en')
    assert p.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert p.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert p.country_code(CountryCode.M49) in COUNTRY_CODES[CountryCode.M49]
    assert p.country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]

# Generated at 2022-06-23 21:03:25.851078
# Unit test for method country_code of class Address
def test_Address_country_code():
    addresses = [Address(i) for i in Address.Meta.locales]

    assert len(addresses)
    assert len(addresses) == len(Address.Meta.locales)

    assert all(isinstance(i.country_code(), str) for i in addresses)
    assert all(len(i.country_code()) == 2 for i in addresses)

    for i in addresses:
        assert i.country_code(CountryCode.A2)
        assert i.country_code(CountryCode.A3)
        assert i.country_code(CountryCode.NUMERIC)

test_Address_country_code()

# Generated at 2022-06-23 21:03:27.917487
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    print(a.calling_code())


# Generated at 2022-06-23 21:03:29.831273
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    c = a.prefecture()
    assert c != None
    assert c != ''
    assert len(c) < 20

# Generated at 2022-06-23 21:03:33.307549
# Unit test for method coordinates of class Address
def test_Address_coordinates():

    for x in range(1, 100):
        #Generating a dictionary with latitude and longitude 
        coord = dict()
        coord['latitude'] = Address('en').latitude()
        coord['longitude'] = Address('en').longitude()
        print(coord)


# Generated at 2022-06-23 21:03:34.516823
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    # print(address.address())


# Generated at 2022-06-23 21:03:37.270959
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    assert isinstance(a.coordinates(), dict)
    assert isinstance(a.coordinates(True), dict)

# Generated at 2022-06-23 21:03:41.403033
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    assert len(adr.address()) > 0
    assert len(adr.address()) > 0
    assert len(adr.address()) > 0
    assert len(adr.address()) > 0
    assert len(adr.address()) > 0


# Generated at 2022-06-23 21:03:43.313348
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address().postal_code() != ''

# Generated at 2022-06-23 21:03:47.890084
# Unit test for method state of class Address
def test_Address_state():
    """Test state."""
    address = Address()
    result = address.state()
    assert result == 'Амурская область'
    result = address.state(True)
    assert result == 'Амурская область'


# Generated at 2022-06-23 21:03:50.762314
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    street_name = address.street_name()
    print(street_name)
    assert isinstance(street_name, str)


# Generated at 2022-06-23 21:03:52.072324
# Unit test for method country of class Address
def test_Address_country():
    result = Address().country()
    assert result



# Generated at 2022-06-23 21:03:53.717632
# Unit test for method address of class Address
def test_Address_address():
  x = Address().address()
  print(str(x))


# Generated at 2022-06-23 21:03:54.640138
# Unit test for method continent of class Address
def test_Address_continent():
    pass


# Generated at 2022-06-23 21:03:56.919520
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import Locale

    address = Address(Locale.ENGLISH)
    print(address.province(False))
    print(address.province(True))

# Generated at 2022-06-23 21:03:57.881767
# Unit test for method continent of class Address
def test_Address_continent():
    addr = Address()

    print(addr.continent())

# Generated at 2022-06-23 21:04:00.537898
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.builtins import address
    ad = address.Address(locale='zh')
    calling_code = ad.calling_code()
    # print(calling_code)


# Generated at 2022-06-23 21:04:03.905680
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    prefecture = address.prefecture()
    print("Prefecture: ", prefecture)

# Test for method street_name of class Address

# Generated at 2022-06-23 21:04:06.846805
# Unit test for method province of class Address
def test_Address_province():
    ad = Address(locale='ru')
    print(ad.province())


# Generated at 2022-06-23 21:04:08.095749
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    assert address.street_suffix() in address._data['street']['suffix']


# Generated at 2022-06-23 21:04:10.838801
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    test_address = "Svetozara Markovića 51, Beograd"

    actual_address = address.address()
    assert actual_address == test_address

# Generated at 2022-06-23 21:04:14.006968
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    unit = Address('ru')
    code = unit.postal_code()
    assert len(code) == 6
    assert '999999' not in code

# Generated at 2022-06-23 21:04:15.594564
# Unit test for method state of class Address
def test_Address_state():
    ''' test the method "state" of class Address '''
    from mimesis import Address
    a = Address()
    state = a.state()
    assert(type(state) == str)


# Generated at 2022-06-23 21:04:19.371901
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert address.federal_subject().__class__ == str
    assert address.federal_subject(abbr=False).__class__ == str
    assert address.federal_subject(abbr=True).__class__ == str

# Generated at 2022-06-23 21:04:29.341494
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale

    a = Address(Locale.RU)
    print(a.street_suffix())  # п
    print(a.street_suffix())  # ул
    print(a.street_suffix())  # пр-кт
    print(a.street_suffix())  # ш

    a = Address(Locale.EN)
    print(a.street_suffix())  # Drive
    print(a.street_suffix())  # Street
    print(a.street_suffix())  # Road
    print(a.street_suffix())  # Pass


# Generated at 2022-06-23 21:04:33.211606
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test Address class method calling_code."""
    # Case 1: Calling code of random country.
    calling_code_case_1 = Address().calling_code()
    assert calling_code_case_1 in CALLING_CODES


# Generated at 2022-06-23 21:04:42.677287
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import Locale
    from mimesis.exceptions import FieldError

    i = 0
    l = 0
    for e in CALLING_CODES:
        assert Address(Locale.EN).calling_code() == e
        i += 1
    for e in CALLING_CODES:
        assert Address(Locale.RU).calling_code() == e
        l += 1
    
    assert Address('zz').calling_code() == ''

    try:
        API(Locale.ZZ).calling_code()
    except FieldError:
        pass

    assert i == l


# Generated at 2022-06-23 21:04:45.340543
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(Locale.RU)
    print(address.address())

    print(address.address())


# Generated at 2022-06-23 21:04:46.635521
# Unit test for constructor of class Address
def test_Address():
    """Unit test for constructor of class Address"""
    locality1 = Address()
    assert isinstance(locality1, Address)


# Generated at 2022-06-23 21:04:48.615030
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    addr = a.street_name()
    print(addr)


# Generated at 2022-06-23 21:04:52.835068
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    street_number = address.street_number(maximum=1400)
    # assert 1 <= int(street_number) <= 1400
    assert len(street_number) == 1 or len(street_number) == 2


# Generated at 2022-06-23 21:04:54.511309
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != None


# Generated at 2022-06-23 21:04:56.783417
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    provider = Address()
    assert provider.calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:04:57.893091
# Unit test for method longitude of class Address
def test_Address_longitude():
    Address().longitude()
    assert True

# Generated at 2022-06-23 21:05:01.138837
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    a.continent() == 'North America' # True
    a.continent(code=True) == 'NA' # True

test_Address_continent()

# Generated at 2022-06-23 21:05:02.896636
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Unit test for calling_code method."""
    assert int(Address().calling_code()) > 0


# Generated at 2022-06-23 21:05:05.181934
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    provider = Address()
    postal_code = provider.postal_code()
    assert len(postal_code) == 5
    assert postal_code.isdigit()


# Generated at 2022-06-23 21:05:07.186540
# Unit test for method street_number of class Address
def test_Address_street_number():
    street_number= Address().street_number()
    print("Test Address_street_number:")
    print("Street number:",street_number)
    return street_number


# Generated at 2022-06-23 21:05:09.021066
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    code = address.calling_code()
    assert isinstance(code, str)



# Generated at 2022-06-23 21:05:12.521489
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address('zh')
    dict = address.coordinates()
    assert dict['latitude'] >= -90 and dict['latitude'] <= 90
    assert dict['longitude'] >= -180 and dict['longitude'] <= 180

# Generated at 2022-06-23 21:05:16.778509
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method "address" of class Address"""
    # Fixture
    LOCALE = 'en-US'
    expected = '14 Letty Park Suite 508'
    address = Address(LOCALE)
    # Exercise
    result = address.address()
    # Verify
    assert result == expected


# Generated at 2022-06-23 21:05:19.033375
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() == '973 Joy Street Suite 664'


# Generated at 2022-06-23 21:05:22.322156
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import CountryCode
    from pprint import pformat

    a = Address()
    for loc in CountryCode.all():
        obj = Address(loc.name)
        print(pformat(obj.country()))

# Generated at 2022-06-23 21:05:23.354973
# Unit test for method country of class Address
def test_Address_country():
    
    assert type(Address().country()) == str

# Generated at 2022-06-23 21:05:25.446127
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import Country
    from mimesis.builtins import Address
    a = Address(Country.RUSSIA)
    assert isinstance(a.latitude(), float)

# Generated at 2022-06-23 21:05:29.296022
# Unit test for method city of class Address
def test_Address_city():
    print('[+] Executing method Address_city()')
    prov = Address()
    for i in range(0,100):
        print(prov.city())

# Generated at 2022-06-23 21:05:31.992014
# Unit test for method latitude of class Address
def test_Address_latitude():
    add = Address()
    lat = add.latitude()
    print(lat)


# Generated at 2022-06-23 21:05:37.056635
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.builtins import Address
    address = Address()
    postal_code = address.postal_code()
    assert postal_code is not None, "The result of a postal code is invalid."
    print(postal_code)


# Generated at 2022-06-23 21:05:40.845504
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    # Should return a dict with coordinates
    a = Address()
    assert isinstance(a.coordinates(), dict)
    a = Address()
    assert isinstance(a.coordinates(dms=True), dict)



# Generated at 2022-06-23 21:05:42.909420
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert isinstance(address.street_name(), str)


# Generated at 2022-06-23 21:05:48.672855
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    import json
    test_cases = json.loads(r'''
[
    {
        "locale": "en",
        "number": 10
    },
    {
        "locale": "es",
        "number": 10
    },
    {
        "locale": "ru",
        "number": 10
    },
    {
        "locale": "ja",
        "number": 10
    }
]
    ''')
    from mimesis.enums import Locale
    for test_case in test_cases:
        for i in range(test_case["number"]):
            print(Address(Locale(test_case["locale"])).prefecture())


# Generated at 2022-06-23 21:05:54.850164
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import Country
    from mimesis.builtins import JapanSpecProvider
    from random import choice
    from re import match
    
    # Fake a value for country.
    country = choice(JapanSpecProvider._data['country']['name'])
    # Create instance of JapanSpecProvider.
    jsp = JapanSpecProvider(Country.JAPAN)
    # Generate prefecture.
    prefecture = jsp.prefecture()
    # Check if it's correctly generated.
    assert match(r'^[\w\(\)\-]+$', prefecture)

# Generated at 2022-06-23 21:05:56.608853
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address().zip_code() == Address().postal_code()



# Generated at 2022-06-23 21:05:58.038666
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    x = a.street_name()
    assert x in a._data['street']['name']


# Generated at 2022-06-23 21:05:59.885998
# Unit test for constructor of class Address
def test_Address():
    a = Address().create_address_provider(locale='en')

    assert len(a.address()) > 0

# Generated at 2022-06-23 21:06:06.643185
# Unit test for method prefecture of class Address

# Generated at 2022-06-23 21:06:09.196260
# Unit test for constructor of class Address
def test_Address():
    print("Method test_Address")
    address = Address()
    assert address is not None
    assert address._datafile == 'address.json'
    assert address.locale == 'en'



# Generated at 2022-06-23 21:06:12.703693
# Unit test for method country of class Address
def test_Address_country():
    obj = Address(locale='ru')
    result = obj.country()
    expected = "Российская Федерация"
    assert result == expected


# Generated at 2022-06-23 21:06:17.779250
# Unit test for method street_number of class Address
def test_Address_street_number():
    street_number_list = []
    street_number_amount = 100
    for i in range(0, street_number_amount):
        street_number = Address('en').street_number(maximum = 1400)
        street_number = int(street_number)
        street_number_list.append(street_number)
    assert min(street_number_list) >= 1
    assert max(street_number_list) <= 1400
    print("Test method 'street_number' of class Address: OK")


# Generated at 2022-06-23 21:06:20.752518
# Unit test for method city of class Address
def test_Address_city():
    address = Address(locale="en")
    result = address.city()
    assert type(result) == str
    assert len(result) >= 2
    assert result[0].isupper()


# Generated at 2022-06-23 21:06:23.136799
# Unit test for method country of class Address
def test_Address_country():
    adr = Address()
    result = adr.country(allow_random=False)
    assert result in adr._data['country']['name']


# Generated at 2022-06-23 21:06:24.503666
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address(locale='en')
    b = a.coordinates()
    assert abs(b['longitude']) <= 180
    assert abs(b['latitude']) <= 90

# Generated at 2022-06-23 21:06:27.716765
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale
    address1 = Address(Locale.EN)
    assert address1.city()
    address2 = Address(Locale.RU)
    assert address2.city()
    address3 = Address(Locale.UK)
    assert address3.city()


# Generated at 2022-06-23 21:06:30.780641
# Unit test for method state of class Address
def test_Address_state():
    # Initialize Address class
    address = Address()
    # Get state name
    state = address.state()
    # Check if state is type str 
    assert isinstance(state, str)

# Generated at 2022-06-23 21:06:32.428986
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert len(Address().longitude()) == len(str(Address().longitude()))

# Generated at 2022-06-23 21:06:37.119579
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    result = a.province()
    assert isinstance(result, str)
    # Test if len of result of function Address.province is less than 5
    # assert isinstance(len(result),bool)
    # assert len(result) == 2
    # assert isinstance(result,list)


# Generated at 2022-06-23 21:06:39.996401
# Unit test for method continent of class Address
def test_Address_continent():
    adr = Address()
    print(adr.continent())
    print(adr.continent(True))


# Generated at 2022-06-23 21:06:43.695297
# Unit test for constructor of class Address
def test_Address():
    ad = Address('en-US')
    print(ad.address())
    print(ad.city())
    print(ad.calling_code())


if __name__ == '__main__':
    test_Address()

# Generated at 2022-06-23 21:06:46.202815
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()

    for i in range(1, 6):
        assert address.longitude() >= -180 and address.longitude() <= 180


# Generated at 2022-06-23 21:06:49.147777
# Unit test for method longitude of class Address
def test_Address_longitude():
    addr = Address()
    assert isinstance(addr.longitude(), float)
    assert len(str(addr.longitude())) > 0


# Generated at 2022-06-23 21:06:52.304914
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province() in address._data['state']['name']
    assert address.province(True) in address._data['state']['abbr']


# Generated at 2022-06-23 21:06:55.263347
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    assert callable(a.latitude)
    assert isinstance(a.latitude(), (float, str))


# Generated at 2022-06-23 21:06:57.514572
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address('en').federal_subject() in open("address_federal_subject_expected.txt", "r")

# Generated at 2022-06-23 21:06:59.818657
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address."""
    assert Address().region()


# Generated at 2022-06-23 21:07:08.638872
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert len(a.street_number()) > 0
    assert len(a.street_name()) > 0
    assert len(a.street_suffix()) > 0
    assert len(a.address()) > 0
    assert len(a.state()) > 0
    assert len(a.province()) > 0
    assert len(a.region()) > 0
    assert len(a.federal_subject()) > 0
    assert len(a.prefecture()) > 0
    assert len(a.postal_code()) > 0
    assert len(a.zip_code()) > 0
    assert len(a.country_code()) > 0
    assert len(a.country()) > 0
    assert len(a.city()) > 0
    assert len(a.latitude()) > 0

# Generated at 2022-06-23 21:07:10.020076
# Unit test for constructor of class Address
def test_Address():
    a = Address()
#
#     TODO: Write unit tests
#
    return None

# Generated at 2022-06-23 21:07:11.356973
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    city = a.city()


# Generated at 2022-06-23 21:07:15.628639
# Unit test for method continent of class Address
def test_Address_continent():
    a1 = Address()
    assert a1.continent() in ["Africa", "Asia", "Europe", "North America", "Oceania", "South America"]
    assert a1.continent(code=True) in ["AF", "AS", "EU", "NA", "OC", "SA"]


# Generated at 2022-06-23 21:07:18.031506
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    streetname = address.street_name()
    print(streetname)


# Generated at 2022-06-23 21:07:19.933930
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    for i in range(100):
        result = a.latitude(dms=False)
        print(result)
        assert result <= 90 and result >= -90



# Generated at 2022-06-23 21:07:24.052123
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Unit test address mimesis"""
    address = Address('ru')
    assert address.longitude() != address.latitude()
    assert address.longitude() in [-180, 180]
    assert address.latitude() in [-90, 90]


# Generated at 2022-06-23 21:07:26.694947
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    street_number = a.street_number()
    assert type(street_number) == str
    assert street_number.isdigit()


# Generated at 2022-06-23 21:07:34.729430
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from ast import literal_eval
    from mimesis.enums import CountryCode
    from mimesis.data import COUNTRIES as COUNTRIES_DATA

    addr = Address('en')

    assert 'longitude' in addr.coordinates()
    assert 'latitude' in addr.coordinates()

    assert isinstance(addr.latitude(), float)
    assert isinstance(addr.longitude(), float)

    assert addr.latitude() in range(-90, 90)
    assert addr.longitude() in range(-180, 180)
    
    # Relevant to issue #29
    assert isinstance(addr.latitude(dms=True), str)
    assert isinstance(addr.longitude(dms=True), str)

# Generated at 2022-06-23 21:07:36.989930
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    ad = Address()
    res = ad.coordinates()
    for k in res:
        assert isinstance(res[k], float)



# Generated at 2022-06-23 21:07:38.707046
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert isinstance(address.federal_subject(), str)


# Generated at 2022-06-23 21:07:40.488792
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    print(address.calling_code())
    exit(0)


# Generated at 2022-06-23 21:07:49.788317
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender, Locale
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    adr = Address(locale=Locale.EN)
    ru_adr = Address(locale=Locale.RU)
    ru_sp = RussiaSpecProvider(locale=Locale.RU)
    ru_sp.phone()
    ru_sp.mobile_phone()
    ru_sp.passport_number()
    ru_sp.postal_code()
    ru_sp.kladr_id()
    ru_sp.fms_unit()
    ru_sp.snils()
    ru_sp.inn()

    ru

# Generated at 2022-06-23 21:07:51.749905
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    test = Address()
    assert test.calling_code()


# Generated at 2022-06-23 21:07:52.844950
# Unit test for method continent of class Address
def test_Address_continent():
    assert isinstance(Address.continent(), str)

# Generated at 2022-06-23 21:07:56.934294
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.utils import is_string
    assert is_string(Address(Locale.EN).address())
    assert is_string(Address(Locale.RU).address())


# Generated at 2022-06-23 21:08:00.729848
# Unit test for method state of class Address
def test_Address_state():
    language = 'zh'
    a = Address(language)
    assert type(a.state()) == str
    a = Address()
    assert type(a.state(True)) == str
    assert a.state() != a.state(True)


# Generated at 2022-06-23 21:08:05.910275
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    adr = Address()

    # Generate the first coordinate and compare with the second one
    coord = adr.coordinates()
    coord_DMS = adr.coordinates(dms=True)

    assert coord.get('latitude') != coord_DMS.get('latitude')
    assert coord.get('longitude') != coord_DMS.get('longitude')

# Generated at 2022-06-23 21:08:07.659799
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert isinstance(street_name, str)

# Generated at 2022-06-23 21:08:12.318513
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    latitude = address.latitude(dms=True)
    assert latitude == '21º34\'49.717"N'


# Generated at 2022-06-23 21:08:15.382596
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    street_suffix = address.street_suffix()
    print(street_suffix)


# Generated at 2022-06-23 21:08:17.920189
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address('en')
    lat = a.latitude()
    assert lat > -90 and lat < 90


# Generated at 2022-06-23 21:08:19.536894
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    assert len(address.calling_code()) == 3