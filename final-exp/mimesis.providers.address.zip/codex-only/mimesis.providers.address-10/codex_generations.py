

# Generated at 2022-06-23 20:58:23.042876
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address("en-en")
    c = a.calling_code()
    assert c in CALLING_CODES

# Generated at 2022-06-23 20:58:28.245661
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address(locale='ru')
    federal_subject = address.federal_subject(abbr=True)
    assert len(federal_subject) == 2

# Generated at 2022-06-23 20:58:31.579832
# Unit test for method latitude of class Address
def test_Address_latitude():
    import random
    
    assert lat == 0 or abs(lat) < 90
    assert isinstance(lat, int)
    assert isinstance(lat, float)


# Generated at 2022-06-23 20:58:37.023869
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    assert address.continent(True) in CONTINENT_CODES
    assert address.continent(False) in address._data['continent']
    assert address.continent() in address._data['continent']


# Generated at 2022-06-23 20:58:38.925709
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    actual = a.prefecture()
    assert type(actual) == str


# Generated at 2022-06-23 20:58:43.514187
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    for _ in range(0,10):
        print(a.province())
        print(a.federal_subject())
        print(a.prefecture())



# Generated at 2022-06-23 20:58:52.437210
# Unit test for constructor of class Address
def test_Address():
    ad = Address()
    print("City: ", ad.city())
    print("State: ", ad.state())
    print("Country: ", ad.country())
    print("Address: ", ad.address())
    print("Coordinates: ", ad.coordinates())
    print("Latitude: ", ad.latitude(dms=True))
    print("Longitude: ", ad.longitude(dms=True))
    print("Postal code: ", ad.postal_code())
    print("Country code: ", ad.country_code())
    print("Street name: ", ad.street_name())
    print("Street number: ", ad.street_number())
    print("Street suffix: ", ad.street_suffix())


# Generated at 2022-06-23 20:58:55.093093
# Unit test for constructor of class Address
def test_Address():
    address_pro = Address()
    assert address_pro is not None


# Generated at 2022-06-23 20:58:57.850274
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr = Address()
    name = addr.street_name()
    assert isinstance(name, str)
    assert name
    assert len(name) > 0


# Generated at 2022-06-23 20:59:00.342196
# Unit test for method street_number of class Address
def test_Address_street_number():
	from mimesis.enums import Locale
	address = Address(Locale.JAPANESE)
	result = address.street_number()
	assert result


# Generated at 2022-06-23 20:59:07.811296
# Unit test for method continent of class Address
def test_Address_continent():
    import pytest
    from mimesis.providers.address import Address
    from textwrap import dedent

    # integer is not callable
    with pytest.raises(TypeError):
        Address().continent(0)

    # string is not callable
    with pytest.raises(TypeError):
        Address().continent('ITSANAME')

    # boolean is not callable
    with pytest.raises(TypeError):
        Address().continent(True)

    # assert true
    assert callable(Address().continent(True))



# Generated at 2022-06-23 20:59:10.375283
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    z=a.zip_code()
    assert z

# Generated at 2022-06-23 20:59:12.904396
# Unit test for method longitude of class Address
def test_Address_longitude():
    result = Address().longitude()
    assert(result != None)
    assert(type(result) == float)


# Generated at 2022-06-23 20:59:22.965881
# Unit test for method province of class Address
def test_Address_province():
    """Test method province of class Address."""
    from mimesis.enums import CountryCode

    a = Address()

    assert isinstance(a.province(abbr=True), str)
    assert isinstance(a.province(), str)

    a._data = {'state': {
        'name': ['Кемеровская область', 'Санкт-Петербург'],
        'abbr': ['КО', 'ЛО'],
    }}

    assert a.province() == 'Кемеровская область'
    assert a.province(abbr=True) == 'КО'

# Unit test

# Generated at 2022-06-23 20:59:24.812376
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province() in Address()._data['state']['name']


# Generated at 2022-06-23 20:59:26.427723
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert re.match(r'\b\d{5}(-\d{4})?\b', Address("en").zip_code())


# Generated at 2022-06-23 20:59:31.279249
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('fr')
    suffix = address.street_suffix()
    assert suffix in address._data['street']['suffix'], \
        f'Suffix: {suffix} is not in street suffixes'

# Generated at 2022-06-23 20:59:33.649331
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state() == 'Ain'
    assert Address().state(abbr=True) == '01'


# Generated at 2022-06-23 20:59:37.311958
# Unit test for method street_name of class Address
def test_Address_street_name():
    msg = 'Method `street_name` of class `Address` should return random street\
 name'
    address = Address(seed=4085)
    assert address.street_name() == '명륜로'


# Generated at 2022-06-23 20:59:42.689649
# Unit test for method province of class Address
def test_Address_province():
    from mimesis import __main__ as mimesis
    print("-----------------------")
    
    address = mimesis.Address()
    result = address.province()
    if result:
        print("result is : ",result)
    else:
        print("result is none")


# Generated at 2022-06-23 20:59:45.228649
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert isinstance(street_name, str)
    assert street_name


# Generated at 2022-06-23 20:59:51.389162
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    address = Address('ru')

    assert address.street_number() in range(1, 1400)

    assert address.street_number(maximum=1400) in range(1, 1400)

    assert address.street_number(maximum=1) in range(1, 2)

    assert address.street_number(maximum=2) in range(1, 3)


# Generated at 2022-06-23 20:59:53.859249
# Unit test for method country of class Address
def test_Address_country():

    """Unit test for method country of class Address"""

    provider = Address(locale='ru')

    country = provider.country()

    assert country == 'Россия'

# Generated at 2022-06-23 20:59:54.735788
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    assert address.city() == 'Paris'

# Generated at 2022-06-23 20:59:57.299027
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Locale, Country
    from mimesis.providers.address import Address
    addr = Address()
    print(addr.country(allow_random=True))

# Generated at 2022-06-23 21:00:04.155600
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import Format

    a = Address(Format.RU)
    codes = []
    for i in range(10000):
        code = a.zip_code()
        if not codes.count(code):
            codes.append(code)

    assert len(codes) >= len(a._data['postal_code_fmt'])


# Generated at 2022-06-23 21:00:05.929226
# Unit test for method address of class Address
def test_Address_address():
	address = Address("ru")
	assert address.address() != address.address()


# Generated at 2022-06-23 21:00:08.356464
# Unit test for method city of class Address
def test_Address_city():
    # Assert that city generates only city with the locale "en-US"
    Address(locale="en-US").city() == 'Providence'

if __name__ == '__main__':
    test_Address_city()

# Generated at 2022-06-23 21:00:10.100318
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    result = address.continent()
    assert result in address._data['continent']

# Generated at 2022-06-23 21:00:11.804300
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    #street = address.street_name()
    street = address.address()
    print(street)


# Generated at 2022-06-23 21:00:17.890972
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.data import POSTAL_CODE_FMT
    for i in range(16):
        print(Address().postal_code())
    for i in range(16):
        print(Address().postal_code(POSTAL_CODE_FMT['nl']))
    for i in range(16):
        print(Address().postal_code(POSTAL_CODE_FMT['ru']))

# Generated at 2022-06-23 21:00:21.657188
# Unit test for method continent of class Address
def test_Address_continent():
    """Testing method continent of class Address."""
    assert Address().continent() == 'Asia'
    assert Address().continent(code=True) == 'AS'



# Generated at 2022-06-23 21:00:24.414874
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    longitude = address.longitude(dms=False)
    result = isinstance(longitude, float)
    assert result == True


# Generated at 2022-06-23 21:00:29.768018
# Unit test for method region of class Address
def test_Address_region():
    """Test method region of class Address.

    This unit test is used to test method region of class Address.

    :param Address: mimesis.providers.address.Address
    :return: None
    """
    import re
    from mimesis.enums import CountryCode
    from re import Match

    address = Address(locale='ja')
    region = address.region()
    pattern = re.compile(r'[a-zA-Z]+')
    pattern.fullmatch(region)

    country_code = address.country_code(fmt=CountryCode.A2)
    country = address.country(allow_random=True)
    postal_code = address.postal_code()
    dms_longitude = address._dd_to_dms(-180.00, 'lg')

# Generated at 2022-06-23 21:00:34.426371
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    sn = a.street_number()
    assert sn
    # Test for maximum value
    sn_max = a.street_number(maximum=100)
    assert sn_max
    # Test for return type
    assert isinstance(sn_max, str)



# Generated at 2022-06-23 21:00:42.350540
# Unit test for method longitude of class Address
def test_Address_longitude():
    print("\n============= begin test_Address_longitude =============")
    data = {
        'coordinates': [],
        'longitude': []
    }
    del data['coordinates']
    print("\ndata={}".format(data))
   
    address = Address() # 实例化一个Address类的对象
    latitude = address.latitude()
    logitude = address.longitude()
    res = address.coordinates()
    print("\nres={}".format(res))

    print("\n=============== end test_Address_longitude ===============")


# Generated at 2022-06-23 21:00:47.109388
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Unit test for method zip_code of class Address."""
    address = Address('en')
    code = address.zip_code()
    valid_format = False
    if code.isnumeric():
        valid_format = True
    assert valid_format

# Generated at 2022-06-23 21:00:51.589847
# Unit test for method continent of class Address
def test_Address_continent():
    """Test for Address class
    """
    s = Address(language='en-US')
    assert s.continent() != ""
    assert s.continent(code=True) != ""
    assert type(s.continent(code=True)) == str
    assert type(s.continent()) == str


# Generated at 2022-06-23 21:00:55.282607
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    data = Address(Locale.EN)
    for i in range(100):
        assert data.street_suffix() in data._data['street']['suffix']

# Generated at 2022-06-23 21:01:05.934369
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import address
    from mimesis.enums import DataField
    from mimesis.providers.address import Address
    from mimesis.providers.address import SHORTENED_ADDRESS_FMT

    _add = Address()
    _add.add_provider(address)

    fmt = _add.address_format
    if _add.locale in SHORTENED_ADDRESS_FMT:
        # Test for address formats with street name only
        assert _add.get_field(DataField.STREET_NAME) in fmt
        # Test for address formats without street suffix
        assert _add.get_field(DataField.STREET_SUFFIX) not in fmt
        # Test for address formats without city name

# Generated at 2022-06-23 21:01:07.639605
# Unit test for method latitude of class Address
def test_Address_latitude():
    #assert Address().latitude() == 1.000000
    assert Address().latitude() == 1.0


# Generated at 2022-06-23 21:01:09.539980
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    prefecture = Address().prefecture()
    assert (prefecture in
            Address.province(allow_random=True))


# Generated at 2022-06-23 21:01:11.402765
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    zipcode = address.zip_code()
    assert type(zipcode) == str



# Generated at 2022-06-23 21:01:23.708160
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    print(a.address())
    print(a.country())
    print(a.country(allow_random=True))
    print(a.continent())
    print(a.continent(code=True))
    print(a.country_code())
    print(a.country_code(CountryCode.A3))
    print(a.country_code(CountryCode.NUMERIC))
    print(a.city())
    print(a.calling_code())
    print(a.coordinates())
    print(a.coordinates(dms=True))
    print(a.longitude())
    print(a.longitude(dms=True))
    print(a.latitude())
    print(a.latitude(dms=True))
    print(a.postal_code())


# Generated at 2022-06-23 21:01:25.430898
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    test = Address()
    assert(test.federal_subject() != test.state())


# Generated at 2022-06-23 21:01:29.087929
# Unit test for method country of class Address
def test_Address_country():
    import pytest
    from mimesis.providers.address import Address

    """Testing Address.country()"""
    address = Address(locale="ja")
    result = address.country()
    expected = "日本"
    assert result == expected


# Generated at 2022-06-23 21:01:32.335407
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.builtins import RussiaSpecProvider
    address = Address(RussiaSpecProvider)
    prefecture = address.prefecture()
    assert prefecture in address._data['state']['name']

# Generated at 2022-06-23 21:01:33.612660
# Unit test for method country of class Address
def test_Address_country():
    addr = Address("en")
    assert(len(addr.country()) == 2)

# Generated at 2022-06-23 21:01:42.420942
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.typing import Seed

    ad = Address(seed=Seed(1))
    assert isinstance(ad, Address)

    st_abbr = ad.state(abbr=True)
    assert isinstance(st_abbr, str)
    assert len(st_abbr) == 2

    st = ad.state()
    assert isinstance(st, str)

    # Check different locales
    locales = ['ru', 'de', 'nl', 'fr', 'es', 'it', 'tr', 'uk', 'ja']
    for locale in locales:
        ad.set_locale(locale)
        assert isinstance(ad.state(), str)

    # Check error
    ad.set_

# Generated at 2022-06-23 21:01:45.327834
# Unit test for method city of class Address
def test_Address_city():
    add = Address(seed=543738)
    city = add.city()
    assert city=='Тамбов'

# Generated at 2022-06-23 21:01:47.475810
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    address = Address()
    result = address.address()
    assert len(result.split(' ')) >= 2

# Generated at 2022-06-23 21:01:50.830660
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Test the method prefecture of the class Address"""
    address=Address(locale='pt')
    result_p=address.prefecture()
    assert result_p in address._data['state']['name']


# Generated at 2022-06-23 21:01:53.650197
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print("address.address()=", address.address())
    print("address.address()=", address.address())
    print("address.address()=", address.address())



# Generated at 2022-06-23 21:01:55.488540
# Unit test for method province of class Address
def test_Address_province():
    provider = Address()
    result = provider.province()
    print(result)
    assert result is not None
    assert result is not ""

# Generated at 2022-06-23 21:01:56.640436
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() in [-90, 90]


# Generated at 2022-06-23 21:01:58.440328
# Unit test for constructor of class Address
def test_Address():
    provider = Address('en')
    assert str(provider) == '<Address>'
    assert provider.seed == 42


# Generated at 2022-06-23 21:02:03.963227
# Unit test for method country_code of class Address
def test_Address_country_code():
    expected = ('AR', 'AT', 'AU', 'BE', 'CA', 'CH', 'CN', 'DE', 'DK', 'ES', 'FI', 'FR', 'GB', 'HU', 'IE', 'IS', 'IT', 'JP', 'KR', 'MX', 'NL', 'NO', 'NZ', 'PL', 'PT', 'RU', 'SE', 'TH', 'TR', 'UA', 'US', 'ZA')
    handler = Address(locale='en')
    for _ in range(100):
        code = handler.country_code(CountryCode.A2)
        assert code in expected


# Generated at 2022-06-23 21:02:08.250650
# Unit test for method region of class Address
def test_Address_region():
    # Assert Address().region(abbr=True) is equal 'VA'
    assert Address().region(abbr=True) == 'VA'
    # Assert Address().region() is equal 'Virginia'
    assert Address().region() == 'Virginia'


# Generated at 2022-06-23 21:02:11.081470
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    s = Address(local="en-US")
    x = s.prefecture(abbr=True)
    assert(x in s._data['state']['abbr'])

# Generated at 2022-06-23 21:02:13.794948
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address"""
    address = Address('en')
    assert address.prefecture()


# Generated at 2022-06-23 21:02:16.531767
# Unit test for method province of class Address
def test_Address_province():
    my_Address = Address()
    my_Address.province()
    return my_Address.province()


# Generated at 2022-06-23 21:02:23.109718
# Unit test for method province of class Address
def test_Address_province():
    """Test Address.province().

    Calling method with default parameter returns a string
    from default locale.

    :return: True if Address.province() works correctly.
    """
    from mimesis.builtins import en, ru

    for _ in range(1000):
        pr = ru.address.province(abbr=True)
        assert isinstance(pr, str)
        assert len(pr) == 3

        pr = en.address.province(abbr=True)
        assert isinstance(pr, str)
        assert len(pr) == 2

# Generated at 2022-06-23 21:02:28.581877
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import CountryCode
    address = Address("en")
    with address.use_locale("lv"):
        assert address.zip_code() == address.postal_code()
    assert address.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-23 21:02:30.211683
# Unit test for method province of class Address
def test_Address_province():
    adr = Address()
    result = adr.province()
    assert result == 'CA'


# Generated at 2022-06-23 21:02:32.450015
# Unit test for method street_number of class Address
def test_Address_street_number():
    # Check that the number generated by function street_number is a string
    assert isinstance(Address.street_number, str)


# Generated at 2022-06-23 21:02:37.128304
# Unit test for method city of class Address
def test_Address_city():
    a = Address(seed=100)
    assert a.city() == 'Birmingham'
    assert a.city() == 'Riverside'
    assert a.city() == 'Los Angeles'
    assert a.city() == 'Boston'
    assert a.city() == 'Bridgeport'


# Generated at 2022-06-23 21:02:45.208556
# Unit test for constructor of class Address
def test_Address():
    # Return a random calling code
    assert Address().calling_code() in CALLING_CODES
    # Get a random continent
    assert Address().continent() in Address()._data['continent']
    # Get a random continent code
    assert Address().continent(code=True) in CONTINENT_CODES
    # Return a random country name
    assert Address().country() in Address()._data['country']['name']
    # Return a random country code
    assert Address().country_code(fmt=CountryCode.A2) in COUNTRY_CODES['A2']
    assert Address().country_code(fmt=CountryCode.A3) in COUNTRY_CODES['A3']
    assert Address().country_code(fmt=CountryCode.FIPS) in COUNTRY_CODES['FIPS']

# Generated at 2022-06-23 21:02:49.711058
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    a = Address('en')
    assert len(a.zip_code())>=5
    a = Address('en', CountryCode.A3)
    assert len(a.zip_code())==3

# Generated at 2022-06-23 21:02:51.718207
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    add = Address(random=True)
    print(add.coordinates(True))
    print(add.coordinates(False))


# Generated at 2022-06-23 21:02:54.058267
# Unit test for method street_number of class Address
def test_Address_street_number():
    # Arrange
    # Act
    street_number = Address().street_number()
    # Assert
    assert street_number



# Generated at 2022-06-23 21:02:59.472169
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Locale
    from mimesis.localization import Localization
    from mimesis.providers.datetime import Datetime

    # Create provider with only Spanish locale
    add = Address(Localization([Locale.ES]))
    assert add.country() == 'España'
    assert add.country(allow_random=True) != add.country()

    add = Address(Datetime)
    assert add.country() == add.country()
    assert add.country(allow_random=True) != add.country()


# Generated at 2022-06-23 21:03:01.279423
# Unit test for method latitude of class Address
def test_Address_latitude():
    print("Testing Address class, method latitude...")
    assert Address().latitude() == -2.110104
    print("Success! Address class, method latitude")


# Generated at 2022-06-23 21:03:03.595334
# Unit test for method continent of class Address
def test_Address_continent():
    instance = Address()
    expected = 'Europe'
    actual = instance.continent()
    assert actual in expected


# Generated at 2022-06-23 21:03:05.391340
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    data = address.prefecture()
    assert (data)


# Generated at 2022-06-23 21:03:11.919389
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    correct_postal_code = True

    while correct_postal_code:
        postal_code = Address(locale='nl').postal_code()
        if postal_code.isnumeric() and len(postal_code) == 4:
            correct_postal_code = False
            print(f'The postal code of Netherlands is {postal_code}')
            return postal_code
        else:
            continue

test_Address_postal_code()


# Generated at 2022-06-23 21:03:13.740266
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    city = address.city()
    print("City : " + city)


# Generated at 2022-06-23 21:03:21.266466
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    #test for first format
    assert address.address() in ["{st_num} {st_name}", "{st_num} {st_name} {st_sfx}"]

    #test for second format
    address.locale = 'ja'
    assert address.address().startswith("{0}-{1}{2}")

    #test for third format
    address.locale = 'km'
    assert address.address() in ["លេខ {st_num} ផ្លូវ {st_name}", "លេខ {st_num} ផ្លូវ {st_name} {st_sfx}"]

# Generated at 2022-06-23 21:03:23.663440
# Unit test for method city of class Address
def test_Address_city():
    
    address = Address(locale="en")
    assert address.city() in address._data["city"]

# Generated at 2022-06-23 21:03:27.457371
# Unit test for method address of class Address
def test_Address_address():
    # Create Address
    addr_obj = Address()
    # Call method address of class Address
    addr = addr_obj.address()
    assert isinstance(addr, str)
    assert len(addr) == 8
    assert addr.find(' ') != -1


# Generated at 2022-06-23 21:03:28.296774
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    print(a.city())

# Generated at 2022-06-23 21:03:30.513945
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis import Address
    a=Address('zh')
    print(a.latitude())
    assert 1<2, 'test_Address_latitude failed!'


# Generated at 2022-06-23 21:03:32.380497
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    provider = Address('en')
    result = provider.federal_subject()
    assert result == provider.state()

# Generated at 2022-06-23 21:03:39.046988
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address"""
    print("test_Address_country_code")

    assert Address.country_code() in COUNTRY_CODES[CountryCode.A2], "code is not in country code"

    assert Address.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3], "code is not in country code"

    assert Address.country_code(CountryCode.A3M) in COUNTRY_CODES[CountryCode.A3M], "code is not in country code"

    assert Address.country_code(CountryCode.NUM) in COUNTRY_CODES[CountryCode.NUM], "code is not in country code"


# Generated at 2022-06-23 21:03:40.194986
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None

# Generated at 2022-06-23 21:03:42.370712
# Unit test for method street_number of class Address
def test_Address_street_number():
    print("Testing street_number")
    addr = Address()

    assert True


# Generated at 2022-06-23 21:03:43.842893
# Unit test for method region of class Address
def test_Address_region():
    a = Address().region()


# Generated at 2022-06-23 21:03:45.909106
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address(random_state=0).zip_code() == '60177-8013'

# Generated at 2022-06-23 21:03:55.932260
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    global postal_code_au, postal_code_bd, postal_code_be, postal_code_cn, postal_code_de, postal_code_dk, postal_code_es, postal_code_fr, postal_code_id, postal_code_in, postal_code_it, postal_code_jp, postal_code_my, postal_code_nl, postal_code_ph, postal_code_ru, postal_code_tr, postal_code_ua, postal_code_us, postal_code_uk, postal_code_vn, postal_code_other
    postal_code_au = 0
    postal_code_bd = 0
    postal_code_be = 0
    postal_code_cn = 0
    postal_

# Generated at 2022-06-23 21:03:58.136650
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    instance = Address(random_state=0)
    instance.calling_code()  # => '359'


# Generated at 2022-06-23 21:04:05.773434
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test for method street_suffix of class Address."""
    address = Address()

# Generated at 2022-06-23 21:04:07.805560
# Unit test for method address of class Address
def test_Address_address():
    tmp = Address()

    # If locale does not match,
    # we take a default address format
    assert tmp.address()

# Generated at 2022-06-23 21:04:10.606321
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    result = address.coordinates()
    assert result['longitude'] in range(-180, 180)
    assert result['latitude'] in range(-90, 90)


# Generated at 2022-06-23 21:04:15.605198
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    result = a.coordinates(dms=True)
    assert type(result['latitude']) == str
    assert a.longitude(dms=True) == result['longitude']
    assert a.latitude(dms=True) == result['latitude']

# Generated at 2022-06-23 21:04:27.525276
# Unit test for method country_code of class Address
def test_Address_country_code():
    print("test Address.country_code()")

# Generated at 2022-06-23 21:04:29.385791
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test for calling_code() of class Address."""
    print(Address().calling_code())


# Generated at 2022-06-23 21:04:32.426559
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    street_suffix = address.street_suffix()
    # test case
    assert street_suffix in address._data['street']['suffix']

# Generated at 2022-06-23 21:04:33.954169
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    assert address.longitude() 


# Generated at 2022-06-23 21:04:45.417245
# Unit test for constructor of class Address
def test_Address():
    # Create Address object,
    address = Address(locale='en')
    # check its attributes,
    assert address.country() == 'United States'
    assert address.city() in ['Anchorage', 'Raleigh', 'Bismarck', 'Tallahassee']
    assert address.region() in ['AK', 'NC', 'ND', 'FL']
    assert address.latitude()
    assert address.longitude()
    assert address.street_name() in ['Alfred', 'Wendell', 'Tinker', 'Schoolhouse']
    assert address.street_number()
    assert address.street_suffix() in ['St', 'Rd', 'Ave', 'Blvd']
    assert address.postal_code()
    assert address.address()

# Generated at 2022-06-23 21:04:47.411253
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    obj = Address()

    assert len(obj.postal_code()) >= 5
    assert len(obj.postal_code()) <= 6


# Generated at 2022-06-23 21:04:48.267901
# Unit test for constructor of class Address
def test_Address():
    Address()

# Generated at 2022-06-23 21:04:54.354527
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CoordinateType
    from mimesis.builtins import Address
    
    a = Address()
    gps = a.coordinates()
    lat = gps['latitude']
    lon = gps['longitude']
    assert (lat >= -90 and lat <= 90)
    assert (lon >= -180 and lon <= 180)

# Generated at 2022-06-23 21:05:00.545359
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continents, ContinentsCode
    from mimesis.typing import Enum

    address = Address('en')
    print(address.continent())
    print(address.continent(code=True))
    print(address.continent(code=Enum(Continents)))
    print(address.continent(code=Enum(ContinentsCode)))

# Generated at 2022-06-23 21:05:01.966193
# Unit test for method city of class Address
def test_Address_city():
    address_obj = Address()
    assert address_obj.city() != ''

# Generated at 2022-06-23 21:05:03.824275
# Unit test for method province of class Address
def test_Address_province():
    #c = Address()
    #assert c.province() in c._data['state']['name']
    assert True
    return True


# Generated at 2022-06-23 21:05:09.297214
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    ad = Address('en')
    # print(ad.prefecture())
    # print(ad.prefecture(abbr=True))
    ad = Address('ja')
    # print(ad.prefecture())
    # print(ad.prefecture(abbr=True))


# Generated at 2022-06-23 21:05:15.301204
# Unit test for method state of class Address
def test_Address_state():
    """Unit test for method state of class Address."""
    addr = Address(seed=12345)

    # On non-Russian locale this method should return
    # random state name.
    assert addr.state() in addr._data['state']['name']

    addr = Address(locale='ru')
    # On Russian locale this method should return
    # random state code.
    assert addr.state(abbr=True) in addr._data['state']['abbr']

# Generated at 2022-06-23 21:05:19.081388
# Unit test for constructor of class Address
def test_Address():
    add = Address('ru')
    # print(add.street_number())
    # print(add.address())
    # print(add.address(locale="en"))
    print(add.country_code(locale="ru"))
    pass

# Generated at 2022-06-23 21:05:27.393877
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    data = [
        address.region(),
        address.address(),
        address.city(),
        address.country(),
        address.street_name(),
        address.street_number(),
        address.street_suffix(),
        address.state(abbr=True),
        address.province(abbr=True),
        address.federal_subject(abbr=True),
        address.postal_code(),
        address.zip_code(),
        address.prefecture(abbr=True),
        address.latitude(),
        address.longitude(),
        address.continent(),
        address.calling_code(),
        address.country_code(CountryCode.A2),
        address.country_code(CountryCode.A3),
        address.country_code(CountryCode.NUM3),
    ]

# Generated at 2022-06-23 21:05:31.078349
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('en')
    region = address.federal_subject()
    assert(region in address._get_data('address.json')['state']['name'])


# Generated at 2022-06-23 21:05:32.214990
# Unit test for method address of class Address
def test_Address_address():
    for locale in ['en-US', 'de', 'ru', 'ja']:
        address = Address(locale=locale)
        address.address()

# Generated at 2022-06-23 21:05:36.314929
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    calling_code = Address().calling_code()
    calling_code_list = [country[0] for country in CALLING_CODES]
    assert calling_code in calling_code_list


# Generated at 2022-06-23 21:05:37.937767
# Unit test for method region of class Address
def test_Address_region():
    assert Address.region(allow_random=True)

# Generated at 2022-06-23 21:05:39.382313
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = 'Address()'
    code = eval(a).calling_code()
    assert code in CALLING_CODES


# Generated at 2022-06-23 21:05:42.997345
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Test method zip_code() of class Address."""
    addr = Address()
    result = addr.zip_code()
    assert isinstance(result, str)
    assert result != ""


# Generated at 2022-06-23 21:05:49.492799
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Gender

    dp = Address()
    assert 0 < len(dp.address()) < 3000

    dp = Address(gender=Gender.FEMALE)
    assert 0 < len(dp.address()) < 3000

    dp = Address(gender=Gender.MALE)
    assert 0 < len(dp.address()) < 3000

    dp = Address(locale='en')
    assert 0 < len(dp.address()) < 3000


# Generated at 2022-06-23 21:06:01.362521
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.continent() not in ","
    assert address.calling_code() not in ","
    assert address.city() not in ","
    assert address.continent('code', False) not in ","
    assert address.province() not in ","
    assert address.state() not in ","
    assert address.region() not in ","
    assert address.prefecture() not in ","
    assert address.postal_code() not in ","
    assert address.country_code('code') not in ","
    assert address.country_code() not in ","
    assert address.street_name() not in ","
    assert address.street_suffix() not in ","
    assert address.street_number() not in ","
    assert address.country() not in ","

# Generated at 2022-06-23 21:06:02.497797
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    print(a.longitude())


# Generated at 2022-06-23 21:06:04.214409
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    value = a.city()
    assert value in a._data['city']


# Generated at 2022-06-23 21:06:11.364403
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    new_address = Address()
    # Generate a postal_code
    postal_code = new_address.postal_code()
    # Check if the postal_code is valid
    info = []

    for char in postal_code:
        # Check if the postal_code is only capital letters
        if (char < 'A' or char > 'Z') and (char < '0' or char > '9'):
            info.append(char)
    if len(postal_code) != 5:
        info.append("Invalid Length")

    print("Postal Code: ",postal_code,"\nInfo: ",info)


# Generated at 2022-06-23 21:06:15.356324
# Unit test for method latitude of class Address
def test_Address_latitude():

    a = Address()
    assert '0' in a.latitude(dms=True)
    assert '0' in a.latitude()
    assert '0' in a.latitude()
    assert '0' in a.latitude()
    assert '0' in a.latitude()
    assert '0' in a.latitude()



# Generated at 2022-06-23 21:06:17.313138
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert address.federal_subject() in address.federal_subjects()

# Generated at 2022-06-23 21:06:20.123926
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    province = address.province()

    assert isinstance(province, str)
    assert len(province) > 0


# Generated at 2022-06-23 21:06:20.504610
# Unit test for constructor of class Address
def test_Address():
    Address()

# Generated at 2022-06-23 21:06:24.076082
# Unit test for method street_number of class Address
def test_Address_street_number():
    ad = Address()
    res = ad.street_number()
    assert 'int' in str(type(int(res)))
    assert len(res) > 0


# Generated at 2022-06-23 21:06:25.472706
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    assert isinstance(address.continent(), str)

# Generated at 2022-06-23 21:06:27.861863
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    a = Address()
    print(a.address())

# Generated at 2022-06-23 21:06:33.567677
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import CountryCode
    test_values = [(CountryCode.A2.name, "CZ"), (CountryCode.A3.name, "CZE"), (CountryCode.NUMERIC.name, CZ)]
    for t in test_values:
        assert Address().country_code(t[0]) == t[1]
        pass
    return

# Generated at 2022-06-23 21:06:39.123258
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.locale == 'en'
    assert address.seed is None
    _locale = 'en'
    _seed = '1'
    _provider = Address(locale=_locale, seed=_seed)
    assert _provider.locale == 'en'
    assert _provider.seed == _seed


# Generated at 2022-06-23 21:06:42.936969
# Unit test for method country of class Address
def test_Address_country():
    adr = Address('pt_BR')
    assert adr.country() == 'Brasil'
    assert adr.country(allow_random=True) in adr._data['country']['name']

# Generated at 2022-06-23 21:06:44.406926
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    assert len(address.calling_code()) == 3

# Generated at 2022-06-23 21:06:51.302695
# Unit test for method country of class Address
def test_Address_country():
    """Test for the method country of class Address"""
    print("Testing Address.country")
    a = Address()
    assert a.country(allow_random = True) in a._data['country']['name']
    assert a.country(allow_random = False) in a._data['country']['name']


# Generated at 2022-06-23 21:06:52.654551
# Unit test for method address of class Address
def test_Address_address():
    a = Address('ru')
    assert a.address() is not None


# Generated at 2022-06-23 21:06:55.209821
# Unit test for method region of class Address
def test_Address_region():
    address = Address(locale='ko')
    print(address.region())


# Generated at 2022-06-23 21:06:58.019817
# Unit test for method region of class Address
def test_Address_region():
    fake =  Address()
    print(fake.region())
    print(fake.region(abbr=True))


# Generated at 2022-06-23 21:07:06.866283
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    from mimesis.data import COUNTRY_CODES
    from mimesis.providers.address import Address
    from mimesis.localization import Localization

    a = Address(Localization('en'))
    a.country_code(CountryCode.A3)
    a.country_code(CountryCode.A2)
    a.country_code(CountryCode.NUMERIC)
    a.country_code(CountryCode.FIFA)
    a.country_code(CountryCode.IOC)
    a.country_code(CountryCode.GS1)

    # Get latitude
    a.latitude()
    # Get lattitude in degree-minute-second format
    a.latitude(dms=True)
    # Get longitude
    a.longitude()


# Generated at 2022-06-23 21:07:08.557515
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region."""
    a = Address()
    assert a.region()



# Generated at 2022-06-23 21:07:11.041398
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    c = a.continent()
    assert isinstance(c, str) is True
    assert c in a._data['continent'] is True


# Generated at 2022-06-23 21:07:12.278037
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Unit test for Address.calling_code method"""
    assert Address().calling_code() in [str(i) for i in CALLING_CODES]

# Generated at 2022-06-23 21:07:13.942935
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    # Do 10 iterations.
    for i in range(10):
        a.postal_code()

# Generated at 2022-06-23 21:07:20.824422
# Unit test for method region of class Address
def test_Address_region():
    address = Address('en')
    assert address.region() in address._data['state']['name']
    assert address.region(abbr=True) in address._data['state']['abbr']
    assert address.province().endswith('province')
    assert address.federal_subject().endswith('region')
    assert address.prefecture().endswith('prefecture')

# Generated at 2022-06-23 21:07:21.811581
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a.state() == 'LA'
    assert a.state(abbr=True) == 'LA'


# Generated at 2022-06-23 21:07:30.659219
# Unit test for constructor of class Address
def test_Address():
    a = Address(locale='en')
    print(a.city())
    print(a.address())
    print(a.country())
    print(a.continent())
    print(a.continent(True))
    print(a.state())
    print(a.state(True))
    print(a.longitude())
    print(a.longitude(True))
    print(a.latitude())
    print(a.latitude(True))
    print(a.calling_code())

    a = Address(locale='ja')
    print(a.city())
    print(a.address())
    print(a.country())
    print(a.state())
    print(a.longitude())
    print(a.longitude(True))
    print(a.latitude())

# Generated at 2022-06-23 21:07:34.245999
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address(seed=0)
    assert address.federal_subject() == 'Алтайский край'

# Generated at 2022-06-23 21:07:38.844841
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    # default fmt = CountryCode.A2
    assert address.country_code() in COUNTRY_CODES[CountryCode.A2]
    # fmt = CountryCode.A3
    assert address.country_code(fmt=CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    # fmt = CountryCode.NUM
    assert address.country_code(fmt=CountryCode.NUM) in COUNTRY_CODES[CountryCode.NUM]


# Generated at 2022-06-23 21:07:41.848136
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Arrange
    e = Address()

    # Act
    postal_code = e.postal_code()

    # Assert
    assert postal_code != e.postal_code()


# Generated at 2022-06-23 21:07:42.797604
# Unit test for constructor of class Address
def test_Address():
    assert isinstance(Address(), Address)

# Generated at 2022-06-23 21:07:46.418369
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.providers.address import Address
    address_obj = Address()
    test_value = address_obj.street_name()
    print(test_value)
    assert isinstance(test_value, str) is True


# Generated at 2022-06-23 21:07:49.269555
# Unit test for method province of class Address
def test_Address_province():
    from mimesis import Address

    address = Address('zh-TW')
    result = address.province()

    assert result in address._data['state']['name']
    assert isinstance(result, str)

# Generated at 2022-06-23 21:07:51.836548
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    Address = Address(random = Random(0))
    assert Address.street_suffix() == 'street'


# Generated at 2022-06-23 21:07:54.383024
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert 'Ульяновская область' == Address().federal_subject()

# Generated at 2022-06-23 21:07:56.075021
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    b = a.postal_code()
    return(b)

# Generated at 2022-06-23 21:07:56.776265
# Unit test for method region of class Address
def test_Address_region():
    print(Address().region())

# Generated at 2022-06-23 21:07:58.488204
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Unit test for method street_number of class Address
    """
    addr = Address()
    assert 0 < int(addr.street_number()) < 1400


# Generated at 2022-06-23 21:08:00.469529
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # assert isinstance(Address().zip_code(), str) # TODO: test
    pass

# Generated at 2022-06-23 21:08:02.984839
# Unit test for method country_code of class Address
def test_Address_country_code():
    # default: A2
    adr = Address(locale='zh')
    res = adr.country_code()
    assert len(res) == 2


# Generated at 2022-06-23 21:08:05.499527
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address().federal_subject()
    assert(isinstance(a, str))
    assert(len(a) < 70)


# Generated at 2022-06-23 21:08:07.283481
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    aa = Address('en')
    assert aa.postal_code() == '90220'


# Generated at 2022-06-23 21:08:12.121116
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert street_name is not None
    assert len(street_name) > 0
    print(street_name)


# Generated at 2022-06-23 21:08:17.920049
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    import pytest
    from mimesis.exceptions import NonEnumerableError
    address = Address('ru')
    addr = address.zip_code()
    assert isinstance(addr, str)
    assert len(addr) == 6
    with pytest.raises(NonEnumerableError):
        address.zip_code(test='test')


# Generated at 2022-06-23 21:08:20.022580
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr = Address()
    street_name = addr.street_name()
    print(street_name)


# Generated at 2022-06-23 21:08:25.223492
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.mimesis import Mimesis

    address = Address()
    answer = address.prefecture()

    m = Mimesis()
    question = m.address.prefecture()

    print(answer)
    print(question)
    if (answer == question):
        print("PASSED")
    else:
        print("FAILED")
