

# Generated at 2022-06-23 20:58:22.540128
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    # print(adr.address())

# Generated at 2022-06-23 20:58:23.515878
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province() in Address()._data['state']['name']

# Generated at 2022-06-23 20:58:28.637076
# Unit test for method region of class Address
def test_Address_region():
    """Class test object."""
    a = Address('en')
    print('region:', a.region())
    print('region:', a.region(abbr=True))



# Generated at 2022-06-23 20:58:31.637889
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    street_name = address.street_name()
    print(street_name)
    assert len(street_name) > 4


# Generated at 2022-06-23 20:58:36.325092
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    result = a.federal_subject()
    print(result)
    assert result in a._data['state']['name']

# Generated at 2022-06-23 20:58:41.169532
# Unit test for method street_name of class Address
def test_Address_street_name():
    """Test method street_name of class Address
    :return:
    """
    assert Address().street_name() != Address().street_name()
    assert Address().street_name() != Address().street_name()
    assert Address().street_name() != Address().street_name()
    assert Address().street_name() != Address().street_name()
    assert Address().street_name() != Address().street_name()
    assert Address().street_name() != Address().street_name()
    assert Address().street_name() != Address().street_name()


# Generated at 2022-06-23 20:58:42.655693
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address('ru')
    assert address.coordinates() == \
           {'longitude': '87º34\'20.7428"E', 'latitude': '33º21\'52.1917"N'}

# Generated at 2022-06-23 20:58:45.514092
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # CALL
    address = Address()
    result = address.prefecture()
    # ASSERT
    assert isinstance(result, str) == True

# Generated at 2022-06-23 20:58:50.470407
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    '''
    Test case for the method prefecture of class Address
    '''
    a = Address(locale = 'ru')
    assert a.prefecture() in a._data['state']['abbr'], 'Data is not correct'

# Generated at 2022-06-23 20:58:51.802163
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    print(a.address())


# Generated at 2022-06-23 20:58:55.150379
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    test_string = Address().street_suffix()

    assert (test_string is not None)
    assert (type(test_string) is str)

# Generated at 2022-06-23 20:59:04.871156
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    assert Address('en').coordinates() == {'longitude': -118.8599, 'latitude': -16.735}
    assert Address('ru').coordinates() == {'longitude': -56.6156, 'latitude': -24.0305}
    assert Address('zh').coordinates() == {'longitude': -119.2261, 'latitude': 29.3518}
    assert Address('tr').coordinates() == {'longitude': -80.872, 'latitude': -13.2519}
    assert Address('es').coordinates() == {'longitude': 73.879, 'latitude': -13.1996}
    assert Address('fr').coordinates() == {'longitude': 85.4859, 'latitude': 27.5633}

# Generated at 2022-06-23 20:59:06.488305
# Unit test for method continent of class Address
def test_Address_continent():
   assert (isinstance(Address().continent(), str))


# Generated at 2022-06-23 20:59:10.622138
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # Arrange
    address: Address = Address()
    # Act
    result: str = address.prefecture()
    # Assert
    assert isinstance(result, str)


# Generated at 2022-06-23 20:59:16.730994
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import DMS, DDecimal
    a = Address()
    assert a.longitude() != a.longitude()
    assert a.longitude() < 180
    assert a.longitude() > -180
    assert a.longitude(dms=DMS) != a.longitude(dms=DMS)
    assert a.longitude(dms=DDecimal) != a.longitude(dms=DDecimal)

# Generated at 2022-06-23 20:59:19.858145
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address("ja")
    prefecture = address.prefecture()
    assert isinstance(prefecture, str)
    assert prefecture in address._data['state']['name']


# Generated at 2022-06-23 20:59:28.326848
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates() of class Address."""
    addr = Address()
    coords = addr.coordinates()
    lat = coords['latitude']
    lng = coords['longitude']

    lat_range = (-90, 90)
    lng_range = (-180, 180)

    assert isinstance(lat, float)
    assert isinstance(lng, float)
    assert lat_range[0] <= lat <= lat_range[1]
    assert lng_range[0] <= lng <= lng_range[1]

    coords = addr.coordinates(dms=True)
    lat = coords['latitude']
    lng = coords['longitude']

    assert isinstance(lat, str)
    assert isinstance(lng, str)

# Generated at 2022-06-23 20:59:31.708464
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    assert a.street_number() in list(
        range(1,1401))


# Generated at 2022-06-23 20:59:33.649537
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    assert len(a.street_suffix()) > 0


# Generated at 2022-06-23 20:59:34.555608
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert type(address.street_number()) == str


# Generated at 2022-06-23 20:59:35.642521
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country() == "Switzerland"

# Generated at 2022-06-23 20:59:37.548313
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    country_code = Address.calling_code()
    assert country_code in CALLING_CODES

# Generated at 2022-06-23 20:59:39.451769
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert isinstance(address.prefecture(), str)

# Generated at 2022-06-23 20:59:45.499836
# Unit test for method region of class Address
def test_Address_region():

    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    a = Address('en')

    # default argument
    assert isinstance(a.region(), str)

    # argument = True
    assert isinstance(a.region(abbr=True), str)

    # argument = False
    assert isinstance(a.region(abbr=False), str)



# Generated at 2022-06-23 20:59:46.936301
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code() == '255'


# Generated at 2022-06-23 20:59:54.970754
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    ad = Address(locale='zh')
    # Check with default format (CountryCode.A2)
    assert ad.country_code() in COUNTRY_CODES[CountryCode.A2]
    assert ad.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert ad.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert ad.country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]


# Generated at 2022-06-23 20:59:59.812709
# Unit test for constructor of class Address
def test_Address():
    # Create a instance of address provider
    address = Address(locale='zh')
    assert address._data['country']['current_locale'] == '中华人民共和国'
    assert len(address._data['street']['name']) > 0
    assert len(address._data['country']['name']) > 0
    assert len(address._data['state']['name']) > 0
    assert re.match(
        r'\d{6}', address.postal_code()) is not None

# Generated at 2022-06-23 21:00:00.783549
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    a = address.address()
    assert type(a) == str



# Generated at 2022-06-23 21:00:01.382405
# Unit test for method province of class Address
def test_Address_province():
    return Address().province()

# Generated at 2022-06-23 21:00:03.361957
# Unit test for method longitude of class Address
def test_Address_longitude():
    adr = Address()
    assert -180 <= float(adr.longitude()) <= 180


# Generated at 2022-06-23 21:00:04.205904
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address(random_state=42)
    assert address.zip_code() == '69118'


# Generated at 2022-06-23 21:00:05.739122
# Unit test for method address of class Address
def test_Address_address():
    import random
    a = Address(random.choice(['en','zh','fr','ja','ru','de','es','it']))
    print(a.address())

# Generated at 2022-06-23 21:00:06.563708
# Unit test for method longitude of class Address
def test_Address_longitude():
    pass


# Generated at 2022-06-23 21:00:07.788150
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test method prefecture of class Address."""
    addr = Address()
    assert addr.prefecture() in addr._data['state']['name']

# Generated at 2022-06-23 21:00:11.735168
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    coordinates = address.coordinates(dms=False)
    assert coordinates['longitude'] >= -180 and coordinates['longitude'] <= 180
    assert coordinates['latitude'] >= -90 and coordinates['latitude'] <= 90


# Generated at 2022-06-23 21:00:17.785499
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address."""
    prefecture_list = []
    a = Address()
    for i in range(0,1000):
        prefecture_list.append(a.prefecture())
    assert len(prefecture_list) == len(set(prefecture_list))
    for i in prefecture_list:
        assert isinstance(a.prefecture(),str)


# Generated at 2022-06-23 21:00:22.842810
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    lis = list()
    a = Address(locale='ja')
    for i in range(0,15):
        lis.append(a.prefecture())
    print(lis)


if __name__ == "__main__":
    test_Address_prefecture()

# Generated at 2022-06-23 21:00:26.707880
# Unit test for method state of class Address
def test_Address_state():
    """Test for Address.state()."""
    # Obtain Address object.
    address = Address(locale='en')
    assert isinstance(address.state(), str)
    assert len(address.state().strip()) > 0
test_Address_state()


# Generated at 2022-06-23 21:00:27.542699
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    result = address.prefecture()
    print(result)


# Generated at 2022-06-23 21:00:30.076896
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    for i in range(10):
        # Assume the result is between (-180, 180)
        assert -180 <= a.longitude() <= 180

# Generated at 2022-06-23 21:00:31.813979
# Unit test for method longitude of class Address
def test_Address_longitude():
    lat = Address().longitude()
    assert isinstance(lat, float)


# Generated at 2022-06-23 21:00:34.951225
# Unit test for method street_number of class Address
def test_Address_street_number():
    adr = Address()
    result = adr.street_number(20)
    assert 0 < int(result) <= 20


# Generated at 2022-06-23 21:00:40.905820
# Unit test for method city of class Address
def test_Address_city():
    a = Address(locale='ru')
    print(a.city())
    print(a.random.choice(a._data['city']))
    print('^')
    print(a.address())
    print(a.state(abbr=True))
    print(a.state())
    print(a.country())
    print(a.coordinates())
    print(a.street_number())
    print(a.postal_code())
    print(a.zip_code())

# Generated at 2022-06-23 21:00:46.521871
# Unit test for method postal_code of class Address
def test_Address_postal_code():
	from time import time
	a = Address()
	b = 1
	while(True):
		b += 1
		a.seed(int(time()))
		print(b, a.postal_code())
		if(b > 1000):
			break

if __name__ == "__main__":
	test_Address_postal_code()

# Generated at 2022-06-23 21:00:57.074307
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address("en")

# Generated at 2022-06-23 21:01:03.730497
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.enums import Locale
    A = Address(Locale.JAPANESE)
    street_name = A.street_name()
    assert street_name in A._data['street']['name']
    assert isinstance(street_name, str)
    # Test value with length
    street_name = A.street_name()
    length = len(street_name)
    assert length >= 7 and length <= 11
    assert isinstance(street_name, str)


# Generated at 2022-06-23 21:01:07.242455
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    ad = Address(locale='en')
    print(ad.street_suffix())
    print(ad.street_suffix())
    print(ad.street_suffix())
    # print(ad.street_suffix())


# Generated at 2022-06-23 21:01:11.938732
# Unit test for constructor of class Address
def test_Address():
    assert Address(locale='en').country() == 'United States'
    assert Address(locale='en').city() == 'Miami'
    assert Address(locale='en').street_suffix() == 'Street'
    assert Address(locale='fr').country() == 'Canada'
    assert Address(locale='fr').city() == 'Saint-Carthélemy'
    assert Address(locale='fr').street_suffix() == 'Rue'

# Generated at 2022-06-23 21:01:18.801883
# Unit test for method region of class Address
def test_Address_region():
    addr = Address(locale='en')
    assert addr.region(abbr=False) in addr._data['state']['name']
    assert addr.region(abbr=True) in addr._data['state']['abbr']
    assert addr.region() in addr._data['state']['abbr']


# Generated at 2022-06-23 21:01:20.969195
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    x = Address('en')
    for i in range(10):
        assert x.postal_code() == '{{#####}}'


# Generated at 2022-06-23 21:01:23.356117
# Unit test for method latitude of class Address
def test_Address_latitude():
    provider = Address()
    a = provider.latitude()
    b = provider.latitude()
    print(a, b)
    assert a == b


# Generated at 2022-06-23 21:01:26.890092
# Unit test for method country of class Address
def test_Address_country():
    locale = 'en'
    ad = Address(locale)
    assert isinstance(ad.country(), str)
    assert ad.country() == 'United States'
    assert len(ad.country()) > 1
    assert ad.country() != ad.country()


# Generated at 2022-06-23 21:01:28.567956
# Unit test for constructor of class Address
def test_Address():
    assert Address('ru').address() == 'Земляной вал, 30'

# Generated at 2022-06-23 21:01:32.989299
# Unit test for method region of class Address
def test_Address_region():
    addr = Address(locale='en')
    # tests that the type of the output is a string
    assert isinstance(addr.region(), str)
    # tests that the type of the output is a string
    assert isinstance(addr.region(abbr=True), str)

# Generated at 2022-06-23 21:01:37.621127
# Unit test for method street_name of class Address
def test_Address_street_name():
    locales = ['eo', 'sk', 'de', 'tr', 'nl']
    for locale in locales:
        address = Address(locale=locale)
        street_name = address.street_name()
        assert street_name is not None
        assert isinstance(street_name, str)
        assert street_name != ''


# Generated at 2022-06-23 21:01:41.127699
# Unit test for method region of class Address
def test_Address_region():
    region = Address().region()
    assert region == 'Оренбургская область'
    assert region == 'Оренбургская область'



# Generated at 2022-06-23 21:01:48.302750
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() in [
        'Europe',
        'Asia',
        'Africa',
        'North America',
        'South America',
        'Oceania',
        'Antarctica',
    ]

    assert Address().continent(code=True) in [
        'EU',
        'AS',
        'AF',
        'NA',
        'SA',
        'OC',
        'AN',
    ]


# Generated at 2022-06-23 21:01:51.521131
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    print("\nInside test_Address_prefecture ...")
    address = Address()
    print(f"Prefecture: {address.prefecture()}")
    assert type(address.prefecture()) == str

# Generated at 2022-06-23 21:01:53.422626
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())
    print(address.postal_code())
    print(address.coordinates())

# Generated at 2022-06-23 21:01:55.994035
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address("en")
    for _ in range(10):
        continent = address.continent()
        print(continent)
        assert isinstance(continent, str)



# Generated at 2022-06-23 21:01:57.510832
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    tmp = Address()
    assert len(tmp.street_suffix()) > 0


# Generated at 2022-06-23 21:01:59.298660
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis import Address
    a = Address()
    assert -180 <= a.longitude() <= 180


# Generated at 2022-06-23 21:02:00.647104
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province()
    assert address.province(abbr=True)


# Generated at 2022-06-23 21:02:02.477303
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address."""
    addr = Address()

    # TODO: Implement a way of testing this method with parameterise
    assert len(addr.region()) == 2



# Generated at 2022-06-23 21:02:10.796503
# Unit test for method address of class Address
def test_Address_address():
    from random import random
    from pymimesis.enums import CountryCode
    from pymimesis.providers.address import Address
    obj = Address()
    for _ in range(0, 100):
        assert isinstance(obj.address(), str) is True
        assert isinstance(
            obj.address(locale="ja"), str) is True
        assert isinstance(
            obj.address(locale = "en-US"), str) is True
        assert isinstance(
            obj.address(locale = "en-CA"), str) is True
        assert isinstance(
            obj.address(locale = "fr-FR"), str) is True
        assert isinstance(
            obj.address(locale = "de-DE"), str) is True

# Generated at 2022-06-23 21:02:21.674549
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    class_Address = Address(locale='ru')
    subj = class_Address.federal_subject()

# Generated at 2022-06-23 21:02:23.357934
# Unit test for method state of class Address
def test_Address_state():
    """Unit test for Address_state."""
    assert (Address().state())


# Generated at 2022-06-23 21:02:25.197891
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    x=Address()
    print(x.coordinates())


if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-23 21:02:27.530223
# Unit test for method city of class Address
def test_Address_city():
    h = Address()
    x = h.city()
    assert type(x) is str

# Generated at 2022-06-23 21:02:33.109667
# Unit test for method address of class Address
def test_Address_address():
    the_object = Address()
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
    print(the_object.address())
   

# Generated at 2022-06-23 21:02:35.092684
# Unit test for method continent of class Address
def test_Address_continent():
    temp = Address().continent()
    assert temp != None


# Generated at 2022-06-23 21:02:38.015229
# Unit test for method country of class Address
def test_Address_country():
    # Test country
    assert Address('en').country() == 'United States'
    assert Address('en').country(allow_random=True) == 'United States'
    assert isinstance(Address().country(), str)


# Generated at 2022-06-23 21:02:42.765111
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    street_suffix = address.street_suffix()
    print(street_suffix)
    assert street_suffix == 'St' or street_suffix == 'Ave' or street_suffix == 'Blvd'


# Generated at 2022-06-23 21:02:45.345362
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    result = Address().zip_code()
    expected = Address().postal_code()
    assert result == expected


# Generated at 2022-06-23 21:02:49.843080
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Locale
    a = Address(Locale.EN)
    assert len(a.country()) > 5
    assert a.country() != a.country()
    assert a.country() != a.country()
    assert a.country() != a.country()



# Generated at 2022-06-23 21:02:51.851788
# Unit test for method province of class Address
def test_Address_province():
    a = Address(locale="ru")
    assert a.province() in a._data["state"]["name"]
    

# Generated at 2022-06-23 21:02:54.883356
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    _addr = Address(random=False)
    _coord = _addr.coordinates()
    for _key in ('longitude', 'latitude'):
        assert isinstance(_coord[_key], float)


# Generated at 2022-06-23 21:02:57.408549
# Unit test for method country_code of class Address
def test_Address_country_code():
    _a = Address()
    _a.country_code(CountryCode.A3)
    _a.country_code(CountryCode.A2)
    _a.country_code(CountryCode.N3)


# Generated at 2022-06-23 21:03:00.321358
# Unit test for constructor of class Address
def test_Address():
    '''test_Address
    '''
    assert Address('en')._data['street']['name'][0] == "Almond Street"

# Generated at 2022-06-23 21:03:02.639240
# Unit test for method region of class Address
def test_Address_region():
    a = Address(NAME)
    b = a.region()
    print(b)
    assert len(b) > 0

# Generated at 2022-06-23 21:03:04.070459
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.builtins.address import Address



# Generated at 2022-06-23 21:03:08.840961
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import ContinentCode

    address = Address('tr')
    continent_name = address.continent()
    continent_code = address.continent(code=True)

    assert continent_name in address._data['continent']
    assert continent_code in CONTINENT_CODES
    assert isinstance(continent_code, ContinentCode)

# Generated at 2022-06-23 21:03:09.845503
# Unit test for method street_name of class Address
def test_Address_street_name():
    pass


# Generated at 2022-06-23 21:03:11.403539
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    print(address.street_number())


# Generated at 2022-06-23 21:03:13.696307
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    long = a.latitude()
    short = a.latitude(True)
    print(long, short)


# Generated at 2022-06-23 21:03:14.674017
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    city = address.city()
    assert isinstance(city, str)

# Generated at 2022-06-23 21:03:17.102443
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis import Address
    prefect = Address('en')
    for i in range(1,10):
        print(prefect.prefecture())


# Generated at 2022-06-23 21:03:19.437251
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    result = address.street_name()
    print(result)


# Generated at 2022-06-23 21:03:26.832409
# Unit test for method country_code of class Address
def test_Address_country_code():
    countries = {"A2": "IT", "A3": "ITA", "FIFA": "ITA", "NOC": "ITA", "Numeric": "380", "WMO": "I"}
    for fmt in countries.keys():
        if fmt == "FIFA":
            assert countries[fmt] == Address(fmt=CountryCode(fmt)).country_code(
                fmt=CountryCode(fmt))
        else:
            assert countries[fmt] == Address(fmt=fmt).country_code(
                fmt=fmt)

# Generated at 2022-06-23 21:03:29.320064
# Unit test for method street_name of class Address
def test_Address_street_name():
    r = Address()
    result = r.street_name()
    assert isinstance(result, str)
    assert (len(result) > 0) is True


# Generated at 2022-06-23 21:03:33.343959
# Unit test for method region of class Address
def test_Address_region():
    obj = Address()
    assert isinstance(obj.region(), str)
    assert obj.region() != ''
    assert isinstance(obj.region(abbr=True), str)
    assert obj.region(abbr=True) != ''
    _ = obj.region()  # noqa: WPS421
    _ = obj.region(abbr=True)  # noqa: WPS421



# Generated at 2022-06-23 21:03:39.594257
# Unit test for method region of class Address
def test_Address_region():
    class TestAddress:
        def test_it_returns_random_region(self):
            address = Address('en')
            region = address.region()
            assert type(region) is str
            assert region in address._data['state']['name']

        def test_it_returns_random_region_if_abbr_is_true(self):
            address = Address('en')
            region = address.region(abbr=True)
            assert type(region) is str
            assert region in address._data['state']['abbr']

    # Run tests
    ta = TestAddress()
    ta.test_it_returns_random_region()
    ta.test_it_returns_random_region_if_abbr_is_true()

# Generated at 2022-06-23 21:03:41.057256
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    assert isinstance(address.federal_subject(), str)

# Generated at 2022-06-23 21:03:42.763315
# Unit test for method street_name of class Address
def test_Address_street_name():
    print(Address().street_name())


# Generated at 2022-06-23 21:03:43.881163
# Unit test for constructor of class Address
def test_Address():
    """Test the Address class."""
    try:
        Address()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-23 21:03:48.228553
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code() in COUNTRY_CODES[CountryCode.A2]
    assert Address().country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert Address().country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]

# Generated at 2022-06-23 21:03:49.965171
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state() == 'territory'


# Generated at 2022-06-23 21:03:51.549024
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    result = address.city()

    assert result



# Generated at 2022-06-23 21:04:02.562428
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # This is unit test for method zip_code of class Address
    from mimesis.enums import CountryCode
    from mimesis.providers.date import Datetime
    from mimesis.providers.address import Address

    address = Address(language='ru', country=CountryCode.RU)
    datetime = Datetime()

    print()
    print('#'*80)
    print('Method Address.zip_code():')
    print()

    print('address.zip_code() ->', address.zip_code())
    print('address.zip_code() ->', address.zip_code())
    print('address.zip_code() ->', address.zip_code())
    print('address.zip_code() ->', address.zip_code())

    print()
    print('#'*80)

# Generated at 2022-06-23 21:04:12.866365
# Unit test for method address of class Address
def test_Address_address():
    from textwrap import dedent
    from pprint import pprint
    from mimesis.enums import Locale
    from mimesis.localization import Locales, localize
    locale = Locale.from_str('zh')

    # 取得為現時語系支持之語系.
    supported_locales = Locales.get_supported_locales()
    assert locale in supported_locales, 'Locale {} is not supported.'.format(locale)
    # 重設語系
    old_locale = localize(locale)


# Generated at 2022-06-23 21:04:16.113384
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address(locale = 'zh_CN')
    postal_code = address.postal_code()
    assert len(postal_code) == 6


# Generated at 2022-06-23 21:04:18.289116
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    var = Address().federal_subject()
    print(var)
    assert var != "" 


# Generated at 2022-06-23 21:04:20.525090
# Unit test for method city of class Address
def test_Address_city():
    ad = Address()
    assert type(str()) == type(ad.city())


# Generated at 2022-06-23 21:04:24.195255
# Unit test for method country of class Address
def test_Address_country():
    """
    Unit test for method country of class Address
    """
    instance = Address()
    result = instance.country()
    assert result in instance._data['country']['name']


# Generated at 2022-06-23 21:04:27.876156
# Unit test for method state of class Address
def test_Address_state():
    # Create a Address object
    ad = Address()

    # Call method state with value True
    result = ad.state(abbr=True)

    # Check that result
    assert result == 'AB'



# Generated at 2022-06-23 21:04:31.391164
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test for Address.country_code()"""
    result = Address("test")
    cc = result.country_code()
    assert cc in COUNTRY_CODES[CountryCode.A2]
    assert len(cc) == 2
    

# Generated at 2022-06-23 21:04:38.671332
# Unit test for method country_code of class Address
def test_Address_country_code():
    print("\nFrom test_Address_country_code()")
    address = Address()
    a = address.country_code(CountryCode.A2)
    b = address.country_code(CountryCode.A3)
    c = address.country_code(CountryCode.NUMERIC)
    print("CountryCode.A2:", a)
    print("CountryCode.A3:", b)
    print("CountryCode.NUMERIC:", c)


# Generated at 2022-06-23 21:04:44.176822
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import RegionCode
    from mimesis.locales import Locale
    address = Address(locale=Locale.TURKEY)

    assert address.region(abbr=False)
    assert address.region(abbr=True)
    assert address.region(fmt=RegionCode.A2)
    assert address.region() is not None



# Generated at 2022-06-23 21:04:46.061039
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    assert len(a.prefecture()) > 0


# Generated at 2022-06-23 21:04:49.689463
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    import random
    import re
    a = Address()
    r = a.zip_code()

    assert re.match(r'[\d]{5}', r)



# Generated at 2022-06-23 21:04:51.416538
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    print(address.state())


# Generated at 2022-06-23 21:04:54.243437
# Unit test for method province of class Address
def test_Address_province():
    test_address = Address(locale='ru_RU')
    assert test_address.province() in test_address._data['state']['abbr']


# Generated at 2022-06-23 21:05:05.142803
# Unit test for method province of class Address

# Generated at 2022-06-23 21:05:08.235408
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.builtins import Address, en
    a = Address(en)
    x = a.street_name()
    assert type(x) == str


# Generated at 2022-06-23 21:05:11.248918
# Unit test for method street_number of class Address
def test_Address_street_number():
    for _ in range(10):
        num = Address().street_number()
        assert isinstance(num, str)
        assert int(num) <= 1400



# Generated at 2022-06-23 21:05:12.467469
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert 'New Brunswick' in address.region()


# Generated at 2022-06-23 21:05:15.990845
# Unit test for method state of class Address
def test_Address_state():
    a = Address(locale='en')
    assert a.state() in a._data['state']['name']
    assert a.state(abbr=True) in a._data['state']['abbr']


# Generated at 2022-06-23 21:05:24.268343
# Unit test for method latitude of class Address
def test_Address_latitude():
    import datetime
    import random
    random.seed(datetime.datetime.now())
    inst = Address('en')
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90
    assert -90 <= inst.latitude() <= 90


# Generated at 2022-06-23 21:05:26.462876
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address("tr")
    print("Türkiye kıtalarının ismi:", address.continent())
    print("Avrupa kıtalarının kodları:", address.continent(code=True))

# Generated at 2022-06-23 21:05:29.040347
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert a.calling_code() == "+86"


# Generated at 2022-06-23 21:05:33.962285
# Unit test for method country of class Address
def test_Address_country():
    """Some tests for Address.country() method."""
    addr = Address()
    a = addr.country()
    print(type(a))
    print(a)

    b = addr.country(True)
    print(type(b))
    print(b)


if __name__ == '__main__':
    test_Address_country()

# Generated at 2022-06-23 21:05:45.047095
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a.state(abbr=True) in ['MH', 'AL', 'CA', 'NY', 'WV', 'ND', 'VA', 'ID', 'OR', 'MA', 'TX', 'MN', 'SD', 'MS', 'KY', 'PA', 'MI', 'TN', 'NJ', 'OH', 'AR', 'FL', 'WA', 'WI', 'CO', 'KS', 'NE', 'MT', 'AZ', 'HI', 'WY', 'LA', 'MD']

# Generated at 2022-06-23 21:05:47.347476
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address1 = Address()
    suffix = address1.street_suffix()
    assert isinstance(suffix, str) and suffix != ''


# Generated at 2022-06-23 21:05:55.288953
# Unit test for method continent of class Address
def test_Address_continent():
    locale = 'en'
    seeds = [9812, 9732, 8712, 7921, 7192, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912, 7912]
    for seed in seeds:
        Address._seed(seed)
        assert Address(locale).continent() in ['Asia', 'North America', 'Europe', 'Africa', 'Oceania', 'Antarctica', 'South America', 'Seven seas (open ocean)']
        assert Address(locale).continent(code=True) in ['AS', 'NA', 'EU', 'AF', 'OC', 'AN', 'SA', 'OC', 'EU']

# Generated at 2022-06-23 21:05:57.127005
# Unit test for method region of class Address
def test_Address_region():
    region = Address._Address().region()
    print(region)

# Generated at 2022-06-23 21:06:04.170684
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test Address class calling_code method."""
    add = Address()
    ccode = add.calling_code()
    assert ccode in CALLING_CODES
    assert ccode == add.calling_code()
    assert isinstance(ccode, str)
    assert len(ccode) >= 1 and len(ccode) <= 4
    assert ccode == add.calling_code()  # Test randomness



# Generated at 2022-06-23 21:06:05.865708
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('ru')
    print(address.postal_code())


# Generated at 2022-06-23 21:06:08.122545
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    address = Address('ko')
    assert address.longitude() == -180 or address.longitude() == 180


# Generated at 2022-06-23 21:06:10.458609
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Tests the postal_code method of the Address class"""
    for i in range(10):
        assert len(Address('en').postal_code()) == 5

# Generated at 2022-06-23 21:06:13.382455
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    print(a.street_suffix())
    print(a.street_suffix())
    #Expected output: "St" or "St"


# Generated at 2022-06-23 21:06:20.113567
# Unit test for method latitude of class Address
def test_Address_latitude():
    import pytest
    from mimesis.enums import DataField
    from mimesis.typing import Seed

    # Create Address object.
    address_obj = Address('zh_CN')
    # Use seed '1'
    seed = Seed(1)

    # Using Python's built-in function zip().
    # zip() return an iterator of tuples.
    # We also use Python's built-in function list() to get list of tuples.
    # It's hard to create unit test
    # with checking of number after comma.
    # So we just compare first 10 numbers
    # (first number after comma)
    # and first 10 numbers after comma.

# Generated at 2022-06-23 21:06:23.558433
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    # Continent name
    test_1 = address.continent()
    assert isinstance(test_1, str)
    # Continent code
    test_2 = address.continent(True)
    assert isinstance(test_2, str)


# Generated at 2022-06-23 21:06:26.637295
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address("en")
    list = []
    for i in range(1, 1000):
        list.append(a.street_number())

    assert len(list) == 999
    assert list[i] > 0
    assert list[i] < 1400


# Generated at 2022-06-23 21:06:27.953672
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address("en")
    res = a.street_number()
    assert res == "14"


# Generated at 2022-06-23 21:06:29.095976
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    for _ in range(10):
        print(address.street_suffix())


# Generated at 2022-06-23 21:06:32.268046
# Unit test for method province of class Address
def test_Address_province():
    address = Address("en")
    assert address.province('en') == 'province'
    assert address.province(False) == 'province'


# Generated at 2022-06-23 21:06:34.667223
# Unit test for method state of class Address
def test_Address_state():
    address = Address('es')
    assert address.state(abbr=False) in address._data['state']['name']


# Generated at 2022-06-23 21:06:36.752275
# Unit test for method region of class Address
def test_Address_region():
    a = Address(locale = 'ja')
    assert a.region() == '北海道'


# Generated at 2022-06-23 21:06:39.068641
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert a.region() in a._data['state']['name']


# Generated at 2022-06-23 21:06:41.090865
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    add = Address('zh-cn')
    a = add.calling_code()
    print(a)


# Generated at 2022-06-23 21:06:43.091909
# Unit test for method province of class Address
def test_Address_province():
    _engine = Address()
    # print(_engine.province())


# Generated at 2022-06-23 21:06:50.426791
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address.

    Test if method coordinates of class Address return expected value.
    """
    from mimesis.enums import DMS

    latitude = 15.0
    longitude = 30.0

    b = Address(seed=1010)
    c = Address(seed=1010)

    latitud_dms = b.latitude(dms=True)
    longitud_dms = b.longitude(dms=True)

    dict_c = b.coordinates(dms=True)
    dict_dms = b.coordinates(dms=DMS.DMS)

    assert latitud_dms == '15º0\'0.000"N'
    assert longitud_dms == '30º0\'0.000"E'

    assert dict_c['latitude']

# Generated at 2022-06-23 21:06:52.323060
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    gen = Address()
    zip_code = gen.zip_code()
    assert isinstance(zip_code, str)


# Generated at 2022-06-23 21:06:55.263541
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    assert address.country(allow_random=True) in address._data['country']['name']


# Generated at 2022-06-23 21:06:59.121997
# Unit test for method city of class Address
def test_Address_city():
    """Unit test for method city()."""
    from mimesis.enums import Locale

    address = Address(Locale.EN)
    assert address.city() in address._data['city']

# Generated at 2022-06-23 21:07:01.299778
# Unit test for method country of class Address
def test_Address_country():
    addr = Address()
    assert addr.country(allow_random=True) in addr._data['country']['name']

# Generated at 2022-06-23 21:07:05.053630
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    print("Test the function Address.coordinates")
    a = Address()
    cood = a.coordinates()
    keys = cood.keys()
    assert "latitude" in keys
    assert "longitude" in keys
    print("Passed")


# Generated at 2022-06-23 21:07:06.209088
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert type(address.state()) == str

# Generated at 2022-06-23 21:07:08.944563
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    ad = Address()
    res = ad.coordinates()
    print(res)
    assert isinstance(res.get('longitude'), float)
    assert isinstance(res.get('latitude'), float)


# Generated at 2022-06-23 21:07:11.043237
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    adr = Address(locale='en')
    result = adr.street_suffix()
    assert type(result) == str


# Generated at 2022-06-23 21:07:16.241394
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    from mimesis.builtins import Address
    # Create Address object with default locale
    Address('pt_BR')
    # Create Address object with specific locale
    Address('ja')
    # Create Address object with specific locale
    Address(CountryCode.AFGHANISTAN)
    # Create Address object with current locale
    Address()
    # Create Address object with current locale and mimesis seed
    Address(seed=1234567890)

# Generated at 2022-06-23 21:07:18.502099
# Unit test for method province of class Address
def test_Address_province():
    address = Address(locale='en')
    assert address.province() == address.state()

# Generated at 2022-06-23 21:07:22.657641
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert isinstance(a, Address)
    assert isinstance(a, BaseDataProvider)
    assert a.seed == a.random.seed
    assert isinstance(a.seed, int)
    assert isinstance(a.random, BaseDataProvider)


# Generated at 2022-06-23 21:07:23.796965
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    postal_code = address.postal_code()
    assert len(postal_code) == 5
    assert postal_code.isdigit()


# Generated at 2022-06-23 21:07:24.473836
# Unit test for method city of class Address
def test_Address_city():
    addr = Address()
    assert addr.city() in addr._data['city']

# Generated at 2022-06-23 21:07:26.067852
# Unit test for method latitude of class Address
def test_Address_latitude():
  address = Address()
  assert address.latitude >= -90
  assert address.latitude <= 90


# Generated at 2022-06-23 21:07:30.629443
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    addr = Address()
    assert len(addr.country_code(CountryCode.A2)) == 2
    assert len(addr.country_code(CountryCode.A3)) == 3
    assert len(addr.country_code(CountryCode.alpha_2)) == 2
    assert len(addr.country_code(CountryCode.alpha_3)) == 3

# Generated at 2022-06-23 21:07:37.423412
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    result_1 = a.province()
    assert result_1 != '' and len(result_1) >= 4
    result_2 = a.province(abbr=False)
    assert result_2 != '' and len(result_2) >= 4
    result_3 = a.province(abbr=True)
    assert result_3 != '' and len(result_3) >= 2


# Generated at 2022-06-23 21:07:45.309350
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import CountryCode
    from mimesis.enums import RegionCode
    from mimesis.providers.address import CityProviders
    from mimesis.providers.address import Address
    from mimesis.providers.address import CityProviders
    from mimesis.providers.address import Address
    from mimesis.providers.address import CityProviders
    from mimesis.providers.address import Address
    from mimesis.providers.address import CityProviders
    from mimesis.providers.address import Address
    from mimesis.providers.address import CityProviders
    from mimesis.providers.address import Address
    # CityProviders.provider = Address(local='en')
    # assert issubclass(CityProviders, Address)
    # assert CityProv

# Generated at 2022-06-23 21:07:49.877472
# Unit test for method country_code of class Address
def test_Address_country_code():
    print("\n----- test_Address_country_code() -----")

    a = Address('en')
    print(a.country_code())
    print(a.country_code(CountryCode.A3))
    print(a.country_code(CountryCode.NUMERIC))
    print(a.country_code(CountryCode.NAME))



# Generated at 2022-06-23 21:07:52.693626
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    for i in range(10):
        assert len(Address().zip_code()) == 5
        assert type(Address().zip_code()) == str

# Generated at 2022-06-23 21:07:56.752253
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None
    assert address._data is not None
    assert address._data['address_fmt'] is not None
    assert address._data['address_fmt']['default'] is not None


# Generated at 2022-06-23 21:08:00.555556
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    a = Address()
    a.country_code()
    a.country_code(CountryCode.A3)
    a.country_code(CountryCode.NUMERIC)
    a.country_code(CountryCode.A2)

# Generated at 2022-06-23 21:08:02.649406
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country() == 'United States of America'


# Generated at 2022-06-23 21:08:08.110017
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    print("Unit test for method street_suffix of class Address")
    a = Address()
    street_suffix = a.street_suffix()
    print("Street suffix: " + street_suffix)
    # Test result
    assert street_suffix is not None, "The street suffix is null"
    assert type(street_suffix) is str, "The street suffix is not type of string"


# Generated at 2022-06-23 21:08:12.416976
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    l = []
    for i in range(100):
        l.append(a.province())
    print(l)
    return l


# Generated at 2022-06-23 21:08:14.466478
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address(locale='JA')
    assert isinstance(address.prefecture(), str)


# Generated at 2022-06-23 21:08:16.533214
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert type(Address().latitude()) == float


# Generated at 2022-06-23 21:08:19.020234
# Unit test for method province of class Address
def test_Address_province():
    address = Address('en')
    assert type(address.province()) == str


# Generated at 2022-06-23 21:08:20.953045
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address(locale='en')
    print(a.continent(), a.continent(code=True))


# Generated at 2022-06-23 21:08:25.415773
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()

    assert isinstance(result, str)
    assert result in address._data['state']['name']
    assert result in address._data['state']['abbr']

if __name__ == '__main__':
    test_Address_federal_subject()