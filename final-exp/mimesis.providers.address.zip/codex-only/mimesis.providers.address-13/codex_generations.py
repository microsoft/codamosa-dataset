

# Generated at 2022-06-23 20:58:22.592992
# Unit test for method country of class Address
def test_Address_country():
	addr = Address()
	country = addr.country()
	print(country)
	assert isinstance(country,str) == True

# Generated at 2022-06-23 20:58:28.090266
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    a = Address(Locale.EN)
    for i in range(10):
        print(a.street_suffix())

# Generated at 2022-06-23 20:58:30.073016
# Unit test for method country of class Address
def test_Address_country():
    ad = Address()
    res = ad.country()
    assert res == 'South Korea'

    res = ad.country(allow_random=True)
    if res not in  ad._data['country']['name']:
        raise AssertionError


# Generated at 2022-06-23 20:58:31.589636
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a != None


# Generated at 2022-06-23 20:58:41.485876
# Unit test for method longitude of class Address

# Generated at 2022-06-23 20:58:51.602711
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    for i in range(10):
        assert isinstance(address.street_name(),str)
        assert isinstance(address.street_suffix(),str)
        assert isinstance(address.street_number(),str)
        assert isinstance(address.address(),str)  
        assert isinstance(address.state(True),str)
        assert isinstance(address.province(True),str)
        assert isinstance(address.region(True),str)
        assert isinstance(address.federal_subject(True),str)
        assert isinstance(address.prefecture(True),str)
        assert isinstance(address.zip_code(),str)
        assert isinstance(address.country_code(),str)
        assert isinstance(address.country(True),str)
        assert isinstance(address.city(),str)

# Generated at 2022-06-23 20:58:56.882617
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Test on random using English locale
    ad = Address()
    res = ad.calling_code()
    assert res in CALLING_CODES
    print(res)

    # Test on random using Czech locale
    ad = Address(locale='cs')
    res = ad.calling_code()
    assert res in CALLING_CODES
    print(res)

    ad = Address(locale='cs')
    res = ad.calling_code()
    assert res in CALLING_CODES
    print(res)


# Generated at 2022-06-23 20:59:00.169542
# Unit test for method longitude of class Address
def test_Address_longitude():
    # get a handle to the class
    provider = Address()
    # test the longitude function
    # Any longitude should be in range -180 to +180
    data = provider.longitude()
    assert -180 <= data <= 180

# Generated at 2022-06-23 20:59:03.214430
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert isinstance(address.federal_subject(), str)
    # An alias for state
    assert address.federal_subject() == address.state()

# Generated at 2022-06-23 20:59:05.840660
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address().prefecture() in Address()._data['state']['abbr']
assert test_Address_prefecture() == None


# Generated at 2022-06-23 20:59:17.626390
# Unit test for method continent of class Address
def test_Address_continent():
    """Test for method continent of class Address"""
    from mimesis.enums import Continent
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    from mimesis.providers.address import CONTINENT_CODES
    from mimesis.providers.address import CONTINENT_NAMES

    Address = Address('en', Language.ENGLISH)
    assert Address.continent() in CONTINENT_NAMES
    assert Address.continent(code=True) in CONTINENT_CODES
    assert Continent.ANTARCTICA.value not in CONTINENT_NAMES
    assert Continent.ANTARCTICA.value in CONTINENT_CODES
    assert Continent.ANTARCTICA.value not in Address.continent()

# Generated at 2022-06-23 20:59:19.286699
# Unit test for method address of class Address
def test_Address_address():
    print(Address().address())
    print(Address('hi').address())


# Generated at 2022-06-23 20:59:21.046468
# Unit test for method street_name of class Address
def test_Address_street_name():
    """Test Address.street_name().
    """
    print(Address.street_name())


# Generated at 2022-06-23 20:59:25.628328
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    assert isinstance(address.latitude(), float)
    address = Address()
    assert address.locale == 'en-US'
    assert isinstance(address.latitude(True), str)
    address.set_locale('de')
    assert address.locale == 'de'
    assert isinstance(address.latitude(True), str)



# Generated at 2022-06-23 20:59:36.733262
# Unit test for method address of class Address
def test_Address_address():
    addr = Address()
    assert addr.address()
    assert addr.address(locale='es')
    assert addr.address(locale='ru')
    assert addr.address(locale='it')
    assert addr.address(locale='de')
    assert addr.address(locale='pt')
    assert addr.address(locale='nl')
    assert addr.address(locale='ja')
    assert addr.address(locale='fr')
    assert addr.address(locale='en')
    assert addr.address(locale='zh')
    assert addr.address(locale='pl')
    assert addr.address(locale='gt')
    assert addr.address(locale='en')
    assert addr.address(locale='en')

# Generated at 2022-06-23 20:59:41.013689
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    zip_code = a.zip_code()
    expected_length = len(a._data['postal_code_fmt'])
    assert len(zip_code) == expected_length


# Generated at 2022-06-23 20:59:47.400804
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()

    assert "prefecture" in dir(a)
    assert "province" in dir(a)
    assert a.prefecture() == a.province()

    assert "region" in dir(a)
    assert "state" in dir(a)
    assert a.region(abbr=True) == a.state(abbr=True)

    assert "federal_subject" in dir(a)
    assert a.federal_subject() == a.state()

# Generated at 2022-06-23 20:59:50.035332
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import ContinentCode
    address = Address()
    assert address.continent(code = True) in [i.name for i in ContinentCode]


# Generated at 2022-06-23 20:59:51.435335
# Unit test for method longitude of class Address
def test_Address_longitude(): 
    a = Address()
    a.longitude()


# Generated at 2022-06-23 20:59:52.645217
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    print(Address().federal_subject())


# Generated at 2022-06-23 20:59:55.622660
# Unit test for method state of class Address
def test_Address_state():
    """Testing method state of class Address"""

    test = Address()
    result = test.state()

    assert type(result) == str
    assert len(result) in range(0, 2)

    result = test.state(abbr=True)

    assert type(result) == str
    assert len(result) in range(0, 2)

# Generated at 2022-06-23 21:00:00.551897
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method Address.region()."""
    addr = Address()
    assert addr.region() in addr.random.choice(
        addr._data['state']['name'])

# Generated at 2022-06-23 21:00:01.865238
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    state = Address.federal_subject(abbr=True)
    assert(len(state) == 2)


# Generated at 2022-06-23 21:00:03.811469
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    country = Address('en')
    code = country.calling_code()
    assert code != ""


# Generated at 2022-06-23 21:00:08.739263
# Unit test for method longitude of class Address
def test_Address_longitude():
    test_data = [
        {
            "function": "longitude(dms = False)",
            "expected": "float"
        }
    ]
    test = Address(seed=15)
    for case in test_data:
        assert type(eval("test.{}".format(case["function"]))) == eval(case["expected"])


# Generated at 2022-06-23 21:00:15.794561
# Unit test for method address of class Address
def test_Address_address():
  from mimesis.enums import Gender
  sample = Address
  sample.random.seed(0)
  assert sample.address() == '967 Wunba Viaduct'
  sample.random.seed(0)
  assert sample.address(gender=Gender.FEMALE) == '967 Wunba Viaduct'
  sample.random.seed(0)
  assert sample.address(gender=Gender.MALE) == '967 Wunba Viaduct'
  sample.random.seed(0)
  assert sample.address(locale='es') == '967 Av. Wunba'
  sample.random.seed(0)
  assert sample.address(locale='ru') == '967 Вунба'
  sample.random.seed(0)

# Generated at 2022-06-23 21:00:18.595003
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from pprint import pprint
    ad = Address('ja')
    pprint (ad.calling_code())


# Generated at 2022-06-23 21:00:20.558887
# Unit test for constructor of class Address
def test_Address():
    ad = Address()
    assert ad.locale == 'en'

# Generated at 2022-06-23 21:00:30.116392
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    import mimesis
    address = mimesis.Address()

# Generated at 2022-06-23 21:00:31.867811
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    continent = address.continent()
    assert continent in address._data['continent']


# Generated at 2022-06-23 21:00:42.387673
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    addr = Address()
    c = addr.coordinates()
    assert type(c) is dict
    assert len(c) == 2
    assert 'longitude' in c
    assert 'latitude' in c
    c = addr.coordinates(dms=True)
    assert type(c) is dict
    assert len(c) == 2
    assert 'longitude' in c
    assert 'latitude' in c
    assert len(c['longitude'].split('º')) == 3
    assert len(c['latitude'].split('º')) == 3
    assert c['longitude'][-1] in ['e', 'E', 'w', 'W']
    assert c['latitude'][-1] in ['n', 'N', 's', 'S']


# Generated at 2022-06-23 21:00:47.604229
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('en')
    for i in range(0, 10):
        suffix = address.street_suffix()
        print(suffix)
        # TODO:
        # Assert.assertIn(suffix, self._data['street']['suffix'])


# Generated at 2022-06-23 21:00:49.870940
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    sn = a.street_number()
    print(sn)
    assert sn != None


# Generated at 2022-06-23 21:00:51.137636
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en')
    assert a.address()

# Generated at 2022-06-23 21:00:52.156238
# Unit test for method country of class Address
def test_Address_country():
    assert Address.country() in "Japan", Address.country()

# Generated at 2022-06-23 21:01:01.196983
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address

    address = Address()

# Generated at 2022-06-23 21:01:03.501252
# Unit test for method city of class Address
def test_Address_city():


    a = Address(locale='es')
    city = a.city()
    assert city in a._data['city']


# Generated at 2022-06-23 21:01:12.411970
# Unit test for method country_code of class Address
def test_Address_country_code():
    import pytest
    from mimesis.enums import CountryCode
    from mimesis.exceptions import NonEnumerableError
    from mimesis.exceptions import UnsupportedCountryCodeError
    address = Address()
    assert address.country_code('de') in COUNTRY_CODES['A2']
    assert address.country_code(CountryCode.A2) in COUNTRY_CODES['A2']
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES['A3']
    assert address.country_code(CountryCode.NUM) in COUNTRY_CODES['NUM']
    assert address.country_code(CountryCode.WIKIPEDIA) in \
        COUNTRY_CODES['WIKIPEDIA']


# Generated at 2022-06-23 21:01:17.350820
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Test Address class - street_number()."""
    address = Address()

    street_number = address.street_number()
    
    assert (street_number == "1") or (street_number == "2")

# Generated at 2022-06-23 21:01:20.315411
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    result = a.country_code(CountryCode.A3)
    assert result in COUNTRY_CODES[CountryCode.A3.value]

# Generated at 2022-06-23 21:01:22.776472
# Unit test for method continent of class Address
def test_Address_continent():
    """Unit test for method continent of class Address."""
    address = Address()
    address.continent()
    address.continent(code=True)


# Generated at 2022-06-23 21:01:25.909789
# Unit test for method longitude of class Address
def test_Address_longitude():
    provider = Address()
    longitude = provider.longitude()
    assert isinstance(longitude, float)
    assert longitude <= 180.0
    assert longitude >= -180.0


# Generated at 2022-06-23 21:01:28.662509
# Unit test for method region of class Address
def test_Address_region():
    # first create a instance of address class
    address = Address()
    # get a random region
    region = address.region()
    assert isinstance(region, str)
    assert region != ''


# Generated at 2022-06-23 21:01:33.032462
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # Create object of class Address
    address = Address()
    # Run method street_suffix
    result = address.street_suffix()
    # Check that this value is in the list of street suffixes
    assert result in address._data['street']['suffix']


# Generated at 2022-06-23 21:01:39.431741
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    eng = Address(locale='en')
    ja = Address(locale='ja')
    rus = Address(locale="ru")
    cn = Address(locale="cn")
    assert eng.prefecture() in eng._data['state']['name']
    assert ja.prefecture() in ja._data['state']['abbr']
    assert rus.prefecture() in rus._data['state']['name']
    assert cn.prefecture() in cn._data['state']['name']

# Generated at 2022-06-23 21:01:44.272713
# Unit test for method city of class Address
def test_Address_city():
    instance = Address()
    result = instance.city()
    assert result is not None
    assert result.__class__.__name__ == 'str'
    assert ' ' not in result


# Generated at 2022-06-23 21:01:45.473266
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province()

# Generated at 2022-06-23 21:01:47.168294
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject()


# Generated at 2022-06-23 21:01:48.826186
# Unit test for method prefecture of class Address
def test_Address_prefecture():
	assert Address("en").prefecture() != Address("en").prefecture()

# Generated at 2022-06-23 21:01:49.862047
# Unit test for constructor of class Address
def test_Address():
    adr = Address()


# Generated at 2022-06-23 21:01:58.441701
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import json
    import unittest
    from mimesis.providers.geo.address import Address

    class TestAddress(unittest.TestCase):

        def setUp(self) -> None:
            """Set up test data.

            :return: None
            """
            self.countries = Address()._data['country']['name']
            self.a = Address(seed=123)

        def test_coordinates(self):
            # Original seed is 123
            self.assertEqual(
                self.a.coordinates(dms=True),
                {
                    'latitude': '50º33\'39.9720"S',
                    'longitude': '29º12\'28.6154"W',
                }
            )

# class Address


# Generated at 2022-06-23 21:01:59.691089
# Unit test for method province of class Address
def test_Address_province():
    for _ in range(100):
        assert isinstance(Address.province(), str)


# Generated at 2022-06-23 21:02:01.286780
# Unit test for method address of class Address
def test_Address_address():
    a = Address(locale='vi')
    assert a.address() == "số 824 đường Tân Phước"

# Generated at 2022-06-23 21:02:05.234518
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode

    assert Address().state() == 'Abruzzo'
    assert Address().state(abbr=True) == 'AB'
    assert Address().region() == 'Abruzzo'
    assert Address().province() == 'Abruzzo'
    assert Address().prefecture() == 'Abruzzo'
    assert Address().federal_subject() == 'Abruzzo'
    assert Address().state(CountryCode.A2) == 'Abruzzo'

# Generated at 2022-06-23 21:02:08.581150
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    pc = a.postal_code() # pc = postal_code
    assert len(pc) > 0
    print(pc)


# Generated at 2022-06-23 21:02:13.066390
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Expected outcome: -76.685656, 39.346177"""

    addr = Address('en')
    result = addr.coordinates(dms=True)
    assert result == '76º41\'8.34"W, 39º20\'46.24"N'

# Generated at 2022-06-23 21:02:16.355442
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address('cs')
    assert address.continent(True) in ('EU', 'OC',  'AF', 'AS', 'NA')


# Generated at 2022-06-23 21:02:17.384770
# Unit test for method latitude of class Address
def test_Address_latitude():
    pass


# Generated at 2022-06-23 21:02:20.964990
# Unit test for method country of class Address
def test_Address_country():
    a = Address(seed=123)
    assert a.country() == 'Algérie'
    assert a.country(allow_random=True) in a._data['country']['name']
    assert a.country() == 'Algérie'



# Generated at 2022-06-23 21:02:24.140365
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('es')
    postal_code = address.postal_code()
    assert len(postal_code) in (5, 6)



# Generated at 2022-06-23 21:02:34.899154
# Unit test for method continent of class Address
def test_Address_continent():
    # Possible values when code is False
    continents = ["Europe", "Asia", "Africa", "North America", "South America",
                "Oceania", "Antarctica"]
    # Possible values when code is True
    codes = ["AF", "AN", "AS", "EU", "NA", "OC", "SA"]
    # Initializing Address object with 'en' locale
    addr_obj = Address("en")
    # For loop that tests the method continent() when code is True
    for i in codes:
        # Calling the method continent() and passing True to the parameter code
        obj_code = addr_obj.continent(True)
        # Print the value returned by the method
        print(obj_code)
        # If the returned value is in the list CONTINENT_CODES, the code is
        # working properly and the test is passed

# Generated at 2022-06-23 21:02:39.649644
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    addr = Address('ru-RU')
    a = addr.calling_code()
    b = addr.country_code(CountryCode.A2)
    # assert a == CALLING_CODES[b]



# Generated at 2022-06-23 21:02:45.475477
# Unit test for method country of class Address
def test_Address_country():
    address = Address()

    # Test current locale.
    assert address.country() in address._data['country']['name']

    # Test random country.
    assert address.country(allow_random=True) in address._data['country']['name']

    # Test error if locale is not supported.
    address.locale = 'tt-RU'
    assert address.country() is None

    # Test error if locale is not supported.
    address.locale = 'ru'
    assert address.country() not in address._data['country']['name']

# Generated at 2022-06-23 21:02:46.414258
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent(True) == 'AF'

# Generated at 2022-06-23 21:02:49.106050
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert address.region() == "ภาคกลาง"


# Generated at 2022-06-23 21:02:58.183957
# Unit test for method province of class Address
def test_Address_province():
    assert 'Республика Адыгея' in Address('ru').province(abbr=False)
    assert 'Калининградская обл.' in Address('ru').province(abbr=False)
    assert 'Москва' in Address('ru').province(abbr=False)
    assert 'Севастополь' in Address('ru').province(abbr=False)
    assert 'Санкт-Петербург' in Address('ru').province(abbr=False)

# Generated at 2022-06-23 21:03:01.030063
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    try:
        provider = Address()
        assert provider.prefecture() != provider.prefecture()
    except Exception:
        raise


# Generated at 2022-06-23 21:03:04.879796
# Unit test for method longitude of class Address
def test_Address_longitude():
    a=Address()
    if a.longitude()==a.longitude():
        print("test_Address_longitude is passed!")
    else:
        print("test_Address_longitude is failed!")


# Generated at 2022-06-23 21:03:08.115620
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Initialize Address object.
    address = Address('ru')
    
    # Give random longitude
    longitude = address.longitude()
    print('longitude:', longitude)


# Generated at 2022-06-23 21:03:09.508881
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address().longitude() == -23.959445



# Generated at 2022-06-23 21:03:11.035752
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    print(address.state())


# Generated at 2022-06-23 21:03:12.121771
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
	a = Address()
	assert a.street_suffix() in ['Avenue', 'Boulevard', 'Drive', 'Road', 'Street']

# Generated at 2022-06-23 21:03:13.976276
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a.state() in a._data['state']['name']


# Generated at 2022-06-23 21:03:21.374613
# Unit test for method province of class Address
def test_Address_province():
    # 1
    ad = Address()
    assert ad.locale == 'en'
    assert ad.province() == 'BC'
    assert ad.province() == 'AB'
    # 2
    ad = Address(locale='ru')
    assert ad.locale == 'ru'
    assert ad.province() == 'КР'
    assert ad.province() == 'СТ'
    # 3
    ad = Address(locale='zh')
    assert ad.locale == 'zh'
    assert ad.province() == '河北'
    assert ad.province() == '新疆'
    # 4
    ad.set_locale('ja')
    assert ad.locale == 'ja'
    assert ad.province() == '東京'

# Generated at 2022-06-23 21:03:28.725139
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import CountryCode
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import Address
    x = Address('en')
    try:
        x.country_code(CountryCode.A3)
    except NonEnumerableError as e:
        print(e)
    finally:
        assert x.country_code(CountryCode.A3) == 'XXX'
        assert x.country_code() == 'XK'

# Generated at 2022-06-23 21:03:30.920663
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    postcode_fmt = Address()._data['postal_code_fmt']
    assert len(Address().postal_code()) == len(postcode_fmt)

# Generated at 2022-06-23 21:03:32.766993
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    print("Testing method coordinates of class Address")
    addr = Address(use_cache=False)
    print(addr.coordinates(dms=True))

# Generated at 2022-06-23 21:03:35.407553
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test the method calling_code() of class Address.

    :return: None.
    :rtype: None.
    """
    addr = Address("en")
    assert len(addr.calling_code()) == 3

# Generated at 2022-06-23 21:03:37.632100
# Unit test for method street_name of class Address
def test_Address_street_name():
	address = Address()
	name = address.street_name()

	assert name

	print(name)

# Generated at 2022-06-23 21:03:38.655235
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)


# Generated at 2022-06-23 21:03:44.546837
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address.country_code(fmt=CountryCode.A3) in COUNTRY_CODES['a3']
    assert Address.country_code(fmt=CountryCode.NUM) in COUNTRY_CODES['num']
    assert Address.country_code(fmt=CountryCode.A2) in COUNTRY_CODES['a2']

# Generated at 2022-06-23 21:03:47.383329
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('pt_BR')
    value = address.prefecture(True)
    assert len(value) == 2
    assert value in address._data['state']['abbr']



# Generated at 2022-06-23 21:03:51.904125
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    print('##########################')
    print('Test method street_suffix')
    print('##########################')
    # Declare object
    address = Address()
    # Set locale to japan
    address.set_locale('ja')
    # Print the result
    print(address.street_suffix())

# Generated at 2022-06-23 21:03:56.016554
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    for _ in range(20):
        a = address.street_number()
        b = address.street_number(maximum=1000)
        assert type(a) == str
        assert type(b) == str
        assert a.isdecimal()
        assert b.isdecimal()


# Generated at 2022-06-23 21:03:58.229642
# Unit test for method city of class Address
def test_Address_city():
    assert 'Cupertino' in Address().city()
    assert 'Cupertino' in Address().city()

# Generated at 2022-06-23 21:04:00.383127
# Unit test for constructor of class Address
def test_Address():
    address = Address(locale='en')
    return address


# Generated at 2022-06-23 21:04:03.346141
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert street_name == "Name"


# Generated at 2022-06-23 21:04:06.429434
# Unit test for method city of class Address
def test_Address_city():
   address=Address()
   address.city()
   assert address.city() not in ""


# Generated at 2022-06-23 21:04:07.664258
# Unit test for method continent of class Address
def test_Address_continent():
    A = Address()
    assert isinstance(A.continent(),str)
    assert isinstance(A.continent(True),str)


# Generated at 2022-06-23 21:04:12.434642
# Unit test for method latitude of class Address
def test_Address_latitude():
    adr = Address()
    assert adr.latitude(dms=True).count('°') == 1
    assert adr.latitude(dms=True).count('\'') == 1
    assert adr.latitude(dms=True).count('"') == 1
    assert '´' not in adr.latitude(dms=True)
    assert adr.latitude().__class__ == float


# Generated at 2022-06-23 21:04:15.329696
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address_class = Address()
    calling_code = address_class.calling_code()
    assert calling_code == '1'


# Generated at 2022-06-23 21:04:27.211635
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    tmp_address_1 = Address(locale='en')
    tmp_address_2 = Address(locale='en')
    t1 = tmp_address_1.zip_code()
    t2 = tmp_address_2.zip_code()
    print('\nEN zip code: ', t1)
    print('EN zip code: ', t2)

    tmp_address = Address(locale='ja')
    t = tmp_address.zip_code()
    print('\nJA zip code: ', t)

    tmp_address = Address(locale='es')
    t = tmp_address.zip_code()
    print('\nES zip code: ', t)

    tmp_address = Address(locale='fr')
    t = tmp_address.zip_code()
    print('\nFR zip code: ', t)

# Generated at 2022-06-23 21:04:33.532774
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # prefecture
    address = Address('en')
    print('Address.prefecture', address.prefecture())

    #province
    print('Address.province', address.province())

    #region
    print('Address.region', address.region())

    #federal_subject
    print('Address.federal_subject', address.federal_subject())


if __name__ == '__main__':
    test_Address_prefecture()

# Generated at 2022-06-23 21:04:34.207315
# Unit test for method city of class Address
def test_Address_city():
    assert Address.city()

# Generated at 2022-06-23 21:04:35.244929
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address('ru')
    a.coordinates()

# Generated at 2022-06-23 21:04:36.291914
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix()


# Generated at 2022-06-23 21:04:38.845105
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    g = Address()
    assert isinstance(g.coordinates(), dict)
    assert len(g.coordinates()) == 2

# Generated at 2022-06-23 21:04:40.673753
# Unit test for method city of class Address
def test_Address_city():
    addr=Address()
    print(addr.city())
    

# Generated at 2022-06-23 21:04:42.266770
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a.address(), str)

# Generated at 2022-06-23 21:04:46.713317
# Unit test for method country of class Address
def test_Address_country():
    object_1 = Address(locale='ru')
    object_2 = Address()

    assert object_1.country() == 'Россия'
    assert object_2.country() == 'Japan'
    assert object_2.country(allow_random=True) in object_2._data['country']['name']

# Generated at 2022-06-23 21:04:50.033157
# Unit test for method state of class Address
def test_Address_state():
    """Unit test for method state of class Address"""
    address = Address('en')
    assert address.state() in address._data['state']['name']


# Generated at 2022-06-23 21:04:53.298528
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address=Address("en")
    for i in range(100):
        coord = address.coordinates()
        assert -90 <= coord['latitude'] <= 90
        assert -180 <= coord['longitude'] <= 180

# Generated at 2022-06-23 21:04:56.570052
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr = Address()
    assert isinstance(addr.zip_code(), str)
    assert isinstance(addr.postal_code(), str)


# Generated at 2022-06-23 21:04:58.761618
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    ad = Address(locale='jp')
    assert ad.prefecture() in ["東京都", "北海道"]


# Generated at 2022-06-23 21:05:01.966467
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Test for method federal_subject of class Address."""
    address = Address()
    assert isinstance(address.federal_subject(), str)


# Generated at 2022-06-23 21:05:09.671939
# Unit test for method region of class Address
def test_Address_region():
    from . import TestCase
    from . import locale

    obj = Address(locale.EN)
    result = obj.region()
    assert isinstance(result, str)
    assert result in obj._data['state']['name']

    result = obj.region(abbr=True)
    assert isinstance(result, str)
    assert result in obj._data['state']['abbr']

    # Test for method state
    obj.locale = locale.RU
    result = obj.region()
    assert result in obj._data['state']['name']

    # Test for method region
    result = obj.region(abbr=True)
    assert result in obj._data['state']['abbr']

    # Test for method province
    result = obj.province()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:05:11.624735
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    _addres = Address()
    _addres.latitude()


# Generated at 2022-06-23 21:05:21.661637
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import Region
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import RussiaSpecProvider

    rus = Address('ru')
    en = Address('en')
    zh = Address('zh')
    ja = Address('ja')
    random_address = Address()

    assert rus.locale == 'ru'
    assert en.locale == 'en'
    assert zh.locale == 'zh'
    assert ja.locale == 'ja'
    assert isinstance(random_address.random, RussiaSpecProvider)

    en.set_locale('en')
    assert en.locale == 'en'

# Generated at 2022-06-23 21:05:22.721332
# Unit test for constructor of class Address
def test_Address():
    assert Address.__name__ == 'Address'


# Generated at 2022-06-23 21:05:25.337908
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    adr = Address()
    country = (adr.country_code().lower(), adr.country())
    assert country in adr.address()


# Generated at 2022-06-23 21:05:29.736711
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address("en")
    coordinates = a.coordinates()
    assert isinstance(coordinates,dict)
    assert "latitude" in coordinates
    assert "longitude" in coordinates


# Generated at 2022-06-23 21:05:30.841824
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    # a.country()

# Generated at 2022-06-23 21:05:33.056688
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    res = address.country()
    assert len(res) > 0


# Generated at 2022-06-23 21:05:40.416287
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from random import shuffle
    from itertools import combinations

    provider_address = Address()
    calling_codes = provider_address.random.choice(CALLING_CODES)
    shuffle(calling_codes)
    lis = list(combinations(calling_codes,3))

    if (provider_address.calling_code() in lis[0]):
        print("Calling code:"+provider_address.calling_code())
    else:
        print("Error")


# Generated at 2022-06-23 21:05:47.692250
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from random import seed
    address = Address('en')
    seed(1)
    for _ in range(0, 10):
        address.postal_code()
    assert address.postal_code() == '374749-0320'
    assert address.postal_code() == '790663-1030'
    assert address.postal_code() == '741599-3950'
    assert address.postal_code() == '690260-4660'
    assert address.postal_code() == '276373-3270'
    assert address.postal_code() == '2667-6395'
    assert address.postal_code() == '082850-5590'
    assert address.postal_code() == '937210-1920'

# Generated at 2022-06-23 21:05:48.481010
# Unit test for method city of class Address
def test_Address_city():
    adr = Address("en")
    assert 'Bergen' == adr.city()

# Generated at 2022-06-23 21:05:49.881932
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address().longitude() is not None 


# Generated at 2022-06-23 21:05:53.712628
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert(Address('en').street_suffix() in Address('en')._data['street']['suffix'])

# Integration tests

# Generated at 2022-06-23 21:06:03.124006
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    a = Address()

    state_name_brazil = a.state(CountryCode.A2, 'BR')

    assert a.state(CountryCode.A2, 'BR') == 'RJ'

# Generated at 2022-06-23 21:06:10.349022
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address."""
    address = Address()
    assert address.country_code() in COUNTRY_CODES['A2']
    assert address.country_code(CountryCode.A2) in COUNTRY_CODES['A2']
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES['A3']
    assert address.country_code(CountryCode.NUMERIC) in COUNTRY_CODES['NUMERIC']
    assert address.country_code(CountryCode.SHORTENED) in COUNTRY_CODES['SHORTENED']


# Generated at 2022-06-23 21:06:20.848504
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from pprint import pprint
    # import json
    from mimesis.enums import DataField
    from mimesis.providers.date import Date
    address = Address(DataField.LATIN)
    lst = []
    # s = {"datetime": str(datetime.datetime.now()), "longitude": 0, "latitude": 0}
    # pprint(s)
    date = Date()
    for i in range(1):
        lst.append(
            {"datetime": str(date.datetime(datetime_start='-1d')), "longitude": address._get_fs('lg',False), "latitude": address._get_fs('lt',False)})
    pprint(lst)

    # with open('GPS.json', 'w') as f:
    #

# Generated at 2022-06-23 21:06:21.820272
# Unit test for method continent of class Address
def test_Address_continent():
    print(Address().continent(True))

# Generated at 2022-06-23 21:06:24.100914
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('en')
    r = address.street_suffix()
    assert(r != None)
    assert(isinstance(r, str))


# Generated at 2022-06-23 21:06:26.464523
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address().prefecture() in Address()._data['state']['abbr']


# Generated at 2022-06-23 21:06:30.723804
# Unit test for method zip_code of class Address
def test_Address_zip_code(): ##
    a = Address()
    postcode = a.zip_code() # get a postal code
    assert postcode # check if it is not empty
    assert set(postcode) & set("0123456789") # check if it has digits only


# Generated at 2022-06-23 21:06:36.917843
# Unit test for method region of class Address

# Generated at 2022-06-23 21:06:42.287403
# Unit test for method street_number of class Address
def test_Address_street_number():
    street_number_list = []
    for i in range(100):
        address = Address()
        street_number_list.append(address.street_number())
    assert street_number_list.count('(-1)') <= 0
    assert street_number_list.count('0') <= 0


# Generated at 2022-06-23 21:06:45.280265
# Unit test for method street_name of class Address
def test_Address_street_name():
    print("\nTest for method street_name of class Address")
    for i in range(5):
        result = Address().street_name()
        print(result)
        assert result is not None


# Generated at 2022-06-23 21:06:48.599426
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.builtins import Address
    address = Address()
    output = address.zip_code()
    assert isinstance(output, str)

# Generated at 2022-06-23 21:06:53.426884
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import numpy as np
    expected_result = {'longitude': -179.276914, 'latitude': -52.532256}
    result = Address.coordinates()
    assert expected_result == result
    assert isinstance(result['latitude'],float)
    assert isinstance(result['longitude'],float)
    assert result['latitude'] <= 90
    assert result['latitude'] >= -90

# Generated at 2022-06-23 21:06:56.354095
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    for i in range(10):
        print(a.postal_code())

# Generated at 2022-06-23 21:06:58.503911
# Unit test for method continent of class Address
def test_Address_continent():
    newAddress = Address()
    assert newAddress.continent() == "Asia"


# Generated at 2022-06-23 21:07:03.359705
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert type(a.state(abbr=True)) == str
    assert len(a.state(abbr=True)) == 2
    assert type(a.state(abbr=False)) == str
    assert len(a.state(abbr=False)) >= 2

# Generated at 2022-06-23 21:07:06.556735
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """
    Unit test for method federal_subject of class Address.
    """
    address = Address()
    answer1 = address.federal_subject()
    address.reset_seed()
    answer2 = address.federal_subject()
    assert answer1 == answer2


# Generated at 2022-06-23 21:07:08.991167
# Unit test for method state of class Address
def test_Address_state():
    obj = Address()
    res = obj.state(abbr=True)
    assert type(res) == str
    assert len(res) == 2


# Generated at 2022-06-23 21:07:12.148251
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('zh')
    assert address.prefecture() in '最美丽的沙漠在西藏,极光在明日'


# Generated at 2022-06-23 21:07:19.248159
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis import Address
    from mimesis.enums import ContinentCode
    a = Address('de')
    assert a.continent(code=ContinentCode.NAME) in ['Europe', 'Africa', 'Asia', 'South America', 'North America',
                                                    'Australia', 'Antarctica']
    assert isinstance(a.continent(code=ContinentCode.NAME), str)
    assert a.continent(code=ContinentCode.ISO_3166_1_ALPHA_2) in ['EU', 'OC', 'AF', 'SA', 'AN',
                                                                  'AS', 'NA']
    assert isinstance(a.continent(code=ContinentCode.ISO_3166_1_ALPHA_2), str)

# Generated at 2022-06-23 21:07:23.927869
# Unit test for method latitude of class Address
def test_Address_latitude():
    test1 = Address()
    test2 = Address(locale="ko-KR")
    test3 = Address(locale="ja-JP")
    test4 = Address(locale="zh-CN")
    test5 = Address(locale="en-US")
    test6 = Address(locale="de-DE")

    assert type(test1.latitude()) == float
    assert -90 < test1.latitude() < 90
    assert len(str(test1.latitude())) <= 6

    assert len(test2.latitude()) == 9

    assert len(test3.latitude()) == 9

    assert len(test4.latitude()) == 9

    assert len(test5.latitude()) == 9

    assert len(test6.latitude()) == 9


# Generated at 2022-06-23 21:07:26.521065
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    region = address.federal_subject()
    assert type(region) is str
    assert len(region) == 2


# Generated at 2022-06-23 21:07:29.054665
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    assert isinstance(address.coordinates(), dict)


# Generated at 2022-06-23 21:07:35.993240
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    suffixes = {'Avenue', 'Boulevard', 'Court', 'Court', 'Drive', 'Lane', 'Parkway', 'Road', 'Street'}
    assert len(suffixes) == 9, "Lenght is not equal to 9."
    for i in range(1000):
        assert address.street_suffix() in suffixes, "Suffixes is not in the set."


# Generated at 2022-06-23 21:07:38.153029
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    longitude = address.longitude()
    assert isinstance(longitude, (str, float))



# Generated at 2022-06-23 21:07:43.982843
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis import Address
    address = Address('en')
    for i in range(0, 100):
        assert isinstance(address.coordinates()['latitude'], float)
        assert isinstance(address.coordinates()['longitude'], float)
        assert isinstance(address.coordinates(dms=True)['latitude'], str)
        assert isinstance(address.coordinates(dms=True)['longitude'], str)

test_Address_coordinates()

# Generated at 2022-06-23 21:07:45.515710
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    first = a.street_suffix()
    assert first is not None


# Generated at 2022-06-23 21:07:47.671616
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region()
    assert region in address._data['state']['name']

# Generated at 2022-06-23 21:07:49.937025
# Unit test for method country_code of class Address
def test_Address_country_code():
    unit = Address()
    country_code = unit.country_code()
    assert country_code
    assert isinstance(country_code, str)
    assert len(country_code) == 2


# Generated at 2022-06-23 21:07:54.644378
# Unit test for method state of class Address
def test_Address_state():
    """Test method state of class Address."""
    address = Address()
    state = address.state()
    assert isinstance(state, str)
    assert len(state) == 2
    assert state in address._data['state']['abbr']


# Generated at 2022-06-23 21:08:00.073308
# Unit test for method state of class Address
def test_Address_state():
    from random import choice
    from mimesis.enums import CountryCode
    from mimesis import Address

    result = Address('en').state(abbr=True)
    assert result  #len(result) == 2 # result is a two-letter string

    result = Address('en').state(abbr=False)
    assert result  # result is a state name
    

# Generated at 2022-06-23 21:08:02.940112
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state() in address._data['state']['name']
    assert address.state(abbr = True) in address._data['state']['abbr']


# Generated at 2022-06-23 21:08:04.994962
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    assert address.city() in address._data['city']


# Generated at 2022-06-23 21:08:07.196037
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test the method calling_code of Address class."""
    address = Address()
    assert address.calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:08:13.317723
# Unit test for method continent of class Address
def test_Address_continent():
    # Test for method continent of class Address
    address = Address()
    continents = [
        "Europe",
        "America",
        "Asia",
        "Africa",
        "Oceania",
        "Antarctica",
    ]
    assert address.continent() in continents



# Generated at 2022-06-23 21:08:18.130399
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """
    :return:
    """
    # Init the class
    addr = Address()

    # Get the values for state and federal_subject 
    state = addr.state()
    federal_subject = addr.federal_subject()
    
    # Test
    assert state == federal_subject

# Generated at 2022-06-23 21:08:20.553406
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    provider = Address()
    zip_code = provider.zip_code()
    assert (len(zip_code) == 3)
