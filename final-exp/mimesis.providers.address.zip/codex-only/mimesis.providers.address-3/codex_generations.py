

# Generated at 2022-06-23 20:58:27.051092
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address.continent(code=True) in CONTINENT_CODES


# Generated at 2022-06-23 20:58:29.158380
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    for _ in range(100):
        assert address.region()


# Generated at 2022-06-23 20:58:31.450065
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    for i in range(0, 10):
        print(Address().street_suffix())


# Generated at 2022-06-23 20:58:33.431405
# Unit test for method province of class Address
def test_Address_province():
    addr = Address()
    res = addr.province()
    print('\nres=', res)
    assert res != ''

# Generated at 2022-06-23 20:58:36.238662
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    output = a.region()
    assert isinstance(output, str)


# Generated at 2022-06-23 20:58:42.145187
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import CountryCode

    address = Address('ru')
    assert address.prefecture() in address._data['state']['name']

    us = Address('en')
    assert us.prefecture() in address._data['state']['name']

    assert type(Address('ja').prefecture()) == str
    assert type(Address('en').prefecture()) == str
    assert type(Address('ru').prefecture('abbr')) == str
    assert type(Address('en').prefecture('abbr')) == str
    assert type(Address('ja').prefecture('abbr')) == str
    assert type(Address('ja').prefecture(code=CountryCode.A2)) == str


# Generated at 2022-06-23 20:58:43.296813
# Unit test for method city of class Address
def test_Address_city():
    Address().city()


# Generated at 2022-06-23 20:58:46.822477
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # setup
    a = Address()

    # act
    calling_code = a.calling_code()

    # assert
    assert isinstance(calling_code, str)
    assert calling_code in CALLING_CODES


# Generated at 2022-06-23 20:58:50.520041
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address(locale='en')
    assert type({'longitude': -56.820024999999995, 'latitude': 41.313834}) == type(address.coordinates())

# Generated at 2022-06-23 20:58:53.030273
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    city_name = address.city()
    if city_name == None:
        print(False)
    else:
        print(True)


# Generated at 2022-06-23 20:58:56.428925
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address('en')
    result = address.latitude()
    if len(result) > 0:
        print(result)



# Generated at 2022-06-23 20:58:59.036879
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    obj = Address()
    assert len(obj.street_suffix()) > 0
    assert len(obj.street_suffix()) <= len('Avenue')


# Generated at 2022-06-23 20:59:01.199745
# Unit test for method longitude of class Address
def test_Address_longitude():
    adr = Address()
    assert adr.longitude() > -180 and adr.longitude() < 180


# Generated at 2022-06-23 20:59:04.646089
# Unit test for method latitude of class Address
def test_Address_latitude():
    latitude = Address().latitude()
    assert isinstance(latitude, float)

    latitude = Address().latitude(dms=True)
    assert isinstance(latitude, str)


# Generated at 2022-06-23 20:59:07.728390
# Unit test for method latitude of class Address
def test_Address_latitude():
    provider = Address('en')
    for _ in range(100):
        result = provider.latitude()
        if result > 90 and result < -90:
            print("Bad result: " + str(result))


# Generated at 2022-06-23 20:59:13.823698
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """
    GIVEN a Address class
    WHEN  instantiating a instance of the class
    THEN check if the method address is working properly
    """
    ad = Address("en")
    result = ad.coordinates()
    assert isinstance(result['longitude'], float)
    assert isinstance(result['latitude'], float)

# Generated at 2022-06-23 20:59:16.518775
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    for i in range(1):
        a = Address()
        p1 = a.postal_code()
        p2 = a.postal_code()
        assert p1 != p2

# Generated at 2022-06-23 20:59:17.903267
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() == "Kennedy"


# Generated at 2022-06-23 20:59:21.133004
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """
    Test function.
    """
    res = Address().federal_subject(True)
    assert (len(res) != 0)
    assert (res != '')


# Generated at 2022-06-23 20:59:22.827107
# Unit test for method region of class Address
def test_Address_region():
    addr = Address()
    # should return a random region
    addr.region()



# Generated at 2022-06-23 20:59:26.556033
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address(locale='ko')
    country_code = address.country_code(CountryCode.A3)
    country_code_list = [code for code in COUNTRY_CODES[CountryCode.A3]]
    assert country_code in country_code_list


# Generated at 2022-06-23 20:59:28.290422
# Unit test for method region of class Address
def test_Address_region():
    """Test for method region of class Address"""
    assert 'Pays de la Loire' == Address().region()


# Generated at 2022-06-23 20:59:33.431966
# Unit test for method street_name of class Address
def test_Address_street_name():
    locale = 'en'
    a = Address(locale)
    street_name = a.street_name()
    print('Street name:')
    print(street_name)
    print('Street name type:')
    print(type(street_name))


# Generated at 2022-06-23 20:59:35.803877
# Unit test for method continent of class Address
def test_Address_continent():
    ad = Address('en')
    print(ad.continent())
    print(ad.continent(True))


# Generated at 2022-06-23 20:59:47.361024
# Unit test for method street_number of class Address
def test_Address_street_number():
    import unittest

    from mimesis.enums import Gender
    from mimesis.person import Person

    class AddressTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.address = Address('es')
            self.person = Person('es')

        def test_street_number(self):
            st_num = self.address.street_number()
            self.assertTrue(isinstance(st_num, str))

            st_num = self.address.street_number(maximum=600)
            self.assertGreaterEqual(int(st_num), 0)
            self.assertLessEqual(int(st_num), 600)

        def test_street_name(self):
            st_name = self.address.street_name()

# Generated at 2022-06-23 20:59:49.220161
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address('en')
    print(address.address())
    print(address.zip_code())

# Generated at 2022-06-23 20:59:51.013107
# Unit test for method region of class Address
def test_Address_region():
    address = Address('ko') # create Address object with locale "ko"
    print(address.region())


# Generated at 2022-06-23 20:59:55.121673
# Unit test for constructor of class Address
def test_Address():
    """Constructor of class Address."""
    a = Address()
    assert a.random is not None
    assert a.seed == a.random.seed
    assert a.locale == a.random.locale
    assert a.random.locale == a.locale
    assert a.seed == a.locale.seed

# Generated at 2022-06-23 20:59:56.663264
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()
    return isinstance(result, str)

# Generated at 2022-06-23 21:00:08.395056
# Unit test for method state of class Address
def test_Address_state():
    # Create Address instance with current locale
    address = Address()
    # Create Address instance with uk locale
    address_uk = Address(locale='uk')
    # Check that current locale is equal to en
    assert address.locale == 'en'
    # Check that locale of Address instance is equal to uk
    assert address_uk.locale == 'uk'
    # Check that method state returned value is str
    assert isinstance(address.state(), str)
    # Check that method state returned value is not empty
    assert len(address.state()) > 0
    # Check that method state returned value is str
    assert isinstance(address_uk.state(), str)
    # Check that method state returned value is not empty
    assert len(address_uk.state()) > 0


# Generated at 2022-06-23 21:00:08.890452
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name()


# Generated at 2022-06-23 21:00:11.959856
# Unit test for method state of class Address
def test_Address_state():
    """This is a unit test for method state of class Address."""
    assert isinstance(Address().state(), str) is True
    print("The unit test for method state of class Address has passed successfully.")

# Generated at 2022-06-23 21:00:13.637662
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    result = address.city()
    print(result)


# Generated at 2022-06-23 21:00:19.859499
# Unit test for method state of class Address
def test_Address_state():
    for locale in ['uk-UA', 'en-US', 'de-DE', 'ru-RU']:
        address = Address(locale=locale)
        state = address.state(abbr=False)
        assert set(state.split()).issubset(('Alaska', 'Virginia', 'Ohio', 'California'))

# Generated at 2022-06-23 21:00:28.551190
# Unit test for method continent of class Address
def test_Address_continent():
    """
    test for method continent of class Address
    """
    address = Address()
    assert address.continent(code = False) in "Asia"
    assert address.continent(code = False) in "Europe"
    assert address.continent(code = False) in "Africa"
    assert address.continent(code = False) in "Antarctica"
    assert address.continent(code = False) in "South America"
    assert address.continent(code = False) in "North America"
    assert address.continent(code = False) in "Oceania"
    assert type(address.continent(code = False)) is str


# Generated at 2022-06-23 21:00:30.706941
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    state = address.region()
    print(state)
    assert type(state) == str


# Generated at 2022-06-23 21:00:33.852420
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region()
    assert region is not None
    assert len(region) > 0
    assert type(region) == str


# Generated at 2022-06-23 21:00:37.084209
# Unit test for method address of class Address
def test_Address_address():
    # Object Provider
    provider = Address(locale='en')
    print(provider.street_number())

if __name__ == "__main__":
    test_Address_address()

# Generated at 2022-06-23 21:00:39.862920
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    print(address.state())
    print(address.region())
    print(address.province())
    print(address.federal_subject())
    print(address.prefecture())


# Generated at 2022-06-23 21:00:49.678602
# Unit test for constructor of class Address
def test_Address():
    address = Address(locale="en")
    print(address.region())
    print(address.province())
    print(address.federal_subject())
    print(address.prefecture())
    print(address.postal_code())
    print(address.zip_code())
    print(address.country_code())
    print(address.country())
    print(address.city())
    print(address.latitude())
    print(address.longitude())
    print(address.coordinates())
    print(address.continent())
    print(address.calling_code())
    print(address.build_address())
    print(address.calling_code())

# Running the unit test
test_Address()

# Generated at 2022-06-23 21:00:51.732606
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    assert address.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:00:53.129452
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code() == 'BD'


# Generated at 2022-06-23 21:00:55.282993
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    assert address.country_code() in COUNTRY_CODES[CountryCode.A2]



# Generated at 2022-06-23 21:01:03.132712
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import Locale
    locale_list = [
        'ar', 'au', 'at', 'ba', 'be', 'br', 'bg', 'ca', 'cl', 'cn',
        'cz', 'de', 'eg', 'es', 'fr', 'gr', 'gb', 'hk', 'id', 'ie',
        'il', 'in', 'it', 'jp', 'ke', 'lt', 'mx', 'nl', 'nz', 'ng',
        'pl', 'pt', 'pr', 'ro', 'ru', 'se', 'tw', 'tz', 'ua', 'us'
    ]
    for locale in locale_list:
        address = Address(locale=locale)
        postal_code_fmt = address._data['postal_code_fmt']
        result = address.post

# Generated at 2022-06-23 21:01:05.745751
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    for _ in range(100):
        assert isinstance(a.zip_code(), str)

# Generated at 2022-06-23 21:01:09.498701
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test for method street_suffix of class Address."""
    from mimesis.enums import Locale
    address = Address(locale=Locale.EN)
    street_suffix = address.street_suffix()
    assert street_suffix in address._data['street']['suffix']


# Generated at 2022-06-23 21:01:11.355263
# Unit test for method province of class Address
def test_Address_province():
    addr = Address()
    assert 'province' in dir(addr)
    assert addr.province()
    assert addr.province(abbr=True)

# Generated at 2022-06-23 21:01:15.883636
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    for i in range(10):
        zip_code = Address().zip_code()
        print(zip_code)
        assert zip_code is not None


# Generated at 2022-06-23 21:01:19.840515
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() <= 90 or Address().latitude() >= -90
    assert Address().latitude(dms=True).isalpha() == False
    assert Address().latitude(dms=True) != None


# Generated at 2022-06-23 21:01:27.217343
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # Initialize address from class Address
    address = Address()
    # An arbitrary number of street suffixes
    arbitrary_number_of_street_suffixes = 20
    # Result list
    result_list = []
    # The loop is repeated arbitrary_number_of_street_suffixes times
    for i in range(arbitrary_number_of_street_suffixes):
        # Result of the method street_suffix is added to the result list
        result_list.append(address.street_suffix())
    # The most common element in result_list
    most_common_element_in_result_list = max(set(result_list), key=result_list.count)
    # The most common element in result_list appears at least one time
    assert most_common_element_in_result_list in result_list


# Generated at 2022-06-23 21:01:29.504576
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()

    for i in range(1,10):
        assert len(a.postal_code()) > 0



# Generated at 2022-06-23 21:01:31.027077
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    addr = Address()
    for _ in range(10):
        addr.federal_subject()



# Generated at 2022-06-23 21:01:32.702129
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    addr = Address()
    result = addr.address()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:01:33.968484
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() in ['street', 'road', 'avenue', 'court']


# Generated at 2022-06-23 21:01:37.936691
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """
    Test method coordinates of class Address,
    which contains attributes of random latitude and random longitude.
    """
    a = Address()
    result = a.coordinates()
    assert(isinstance(result, dict))
    assert('latitude' in result and 'longitude' in result)

# Generated at 2022-06-23 21:01:41.666743
# Unit test for method street_name of class Address
def test_Address_street_name():
    from random import uniform
    from math import ceil

    a = Address()
    for i in range(int(ceil(uniform(1, 40)))):
        st_name = a.street_name()
        print(st_name)

# Generated at 2022-06-23 21:01:44.885901
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a=Address('en')
    k=a.street_suffix()
    print("street_suffix is:",k)


# Generated at 2022-06-23 21:01:50.095058
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    assert a.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert a.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert a.country_code() in COUNTRY_CODES[CountryCode.A2]


# Generated at 2022-06-23 21:01:58.662447
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.builtins import RussiaSpecProvider
    ru = RussiaSpecProvider()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru.address.city()
    ru

# Generated at 2022-06-23 21:02:00.427592
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    assert a.street_number() == '1060'
    assert a.street_number(1000) == '380'

# Generated at 2022-06-23 21:02:03.516809
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address("en")
    latitude = address._dd_to_dms(address.latitude(True), 'lt')
    longitude = address._dd_to_dms(address.longitude(True), 'lg')

    assert latitude == address.coordinates(True)['latitude']
    assert longitude == address.coordinates(True)['longitude']

# Generated at 2022-06-23 21:02:06.538296
# Unit test for method latitude of class Address
def test_Address_latitude():
	test_address = Address()
	test_latitude = test_address.latitude()
	print(test_latitude)
	assert isinstance(test_latitude , float)
	assert -90 <= test_latitude <= 90



# Generated at 2022-06-23 21:02:10.508794
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address("en-US")
    s = 0
    while s < 10:
        print("{} : {}".format(s, a.street_name()))
        s += 1


# Generated at 2022-06-23 21:02:13.839515
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    address = Address()
    result = address.coordinates()
    assert longitude in result
    assert latitude in result


# Generated at 2022-06-23 21:02:17.014670
# Unit test for method address of class Address
def test_Address_address():
    # Initialize
    address = Address("en")

    # Get address
    addr = address.address()

    # Check result
    assert addr == 'Albrecht Pl'



# Generated at 2022-06-23 21:02:22.862875
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address

    :return: True if unit test successful.
    :rtype: bool
    """
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    provider = Address()

    if provider.country_code() != 'RU' or \
            provider.country_code(CountryCode.A3) != 'RUS':
        return False

    return True


# Generated at 2022-06-23 21:02:24.718264
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    state = address.province()
    assert state in address._data["state"]["abbr"]


# Generated at 2022-06-23 21:02:26.370322
# Unit test for method street_name of class Address
def test_Address_street_name():
    for _ in range(20):
        street_name = Address().street_name()
        print(street_name)


# Generated at 2022-06-23 21:02:27.803173
# Unit test for method address of class Address
def test_Address_address():
    provider = Address(locale='en')
    provider.address.assert_length(5)

# Generated at 2022-06-23 21:02:32.825964
# Unit test for method address of class Address
def test_Address_address():
    add = Address()
    '''
        def address(self) -> str:
        # Generate a random full address.
    
        :return: Full address.
    '''
    full_address = add.address()
    print(full_address)


# Generated at 2022-06-23 21:02:35.137115
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert address.prefecture(abbr=True) == 'JP-27'


# Generated at 2022-06-23 21:02:38.056468
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert street_name
    assert isinstance(street_name, str)
    assert len(street_name) > 0


# Generated at 2022-06-23 21:02:45.722737
# Unit test for method country_code of class Address

# Generated at 2022-06-23 21:02:46.508122
# Unit test for method region of class Address
def test_Address_region():
    addr = Address()
    assert isinstance(addr.region(), str)



# Generated at 2022-06-23 21:02:49.151378
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    x = address.street_name()
    print(x)
    pass


# Generated at 2022-06-23 21:02:50.476516
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    assert isinstance(latitude, str)

# Generated at 2022-06-23 21:02:51.762999
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address().prefecture() == '广东省'

# Generated at 2022-06-23 21:02:58.272915
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    try:
        street_suffix_list = ["Avenue", "Boulevard", "Commons", "Court", "Drive", "Lane", "Parkway", "Place", "Road", "Square", "Street", "Terrace"]
        street_suffix = address.street_suffix()
        assert street_suffix in street_suffix_list
        assert type(street_suffix) == str
    except:
        print("Did not return a random street suffix.")

# Generated at 2022-06-23 21:03:01.140362
# Unit test for method country of class Address
def test_Address_country():
    a = Address()

# Generated at 2022-06-23 21:03:06.175019
# Unit test for method country of class Address
def test_Address_country():
    """Unit test for method country of class Address.

    This method is used to test country method of Address by passing parameter
    allow_random=True or allow_random=False, in both, cases it returns a
    random country name.
    """
    from mimesis.builtins import Address
    address = Address('en')
    assert address.country(allow_random=True) == address.country(allow_random=False)


# Generated at 2022-06-23 21:03:10.772943
# Unit test for method country_code of class Address
def test_Address_country_code():
    address_A2 = Address().country_code(CountryCode.A2)
    address_A3 = Address().country_code(CountryCode.A3)
    assert address_A2 in (COUNTRY_CODES[CountryCode.A2])
    assert address_A3 in (COUNTRY_CODES[CountryCode.A3])

# Generated at 2022-06-23 21:03:14.590082
# Unit test for method city of class Address
def test_Address_city():
    """Test for method city of class Address."""
    ad = Address()
    city = ad.city()
    # print(type(city))
    assert isinstance(city, str)


if __name__ == "__main__":
    test_Address_city()

# Generated at 2022-06-23 21:03:15.636896
# Unit test for method region of class Address
def test_Address_region():
    pass



# Generated at 2022-06-23 21:03:18.191115
# Unit test for method state of class Address
def test_Address_state():
    prov = Address(locale='en')
    print(prov.state())


# Generated at 2022-06-23 21:03:23.104361
# Unit test for method state of class Address
def test_Address_state():
    # Найти полное название региона
    adress = Address("ru")
    x = adress.state()
    print("Полное название региона: ", x)

    # Найти код страны в формате ISO 3166-1-alpha2
    x = adress.country_code(CountryCode.A2)
    print("Код страны в формате ISO 3166-1-alpha2: ", x)

    # Найти код ст

# Generated at 2022-06-23 21:03:27.979052
# Unit test for method state of class Address
def test_Address_state():
    obj = Address('fr')
    result = obj.state()
    assert len(result) > 1
    assert result == obj.region()
    assert result == obj.province()
    assert result == obj.federal_subject()
    assert result == obj.prefecture()
    assert result != obj.city()
    assert result != obj.country()
    assert result != obj.calling_code()

# Generated at 2022-06-23 21:03:30.815366
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address(locale = 'zh_Hans_CN')
    calling_code = address.calling_code()
    print(calling_code)

if __name__ == '__main__':
    test_Address_calling_code()

# Generated at 2022-06-23 21:03:32.016031
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    print(address.country())


# Generated at 2022-06-23 21:03:36.484328
# Unit test for constructor of class Address
def test_Address():
    """Unit test for constructor of class Address."""
    def test_object_creation():
        """Object creation test."""
        address = Address(seed=42)
        assert address is not None

    def test_attributes():
        """Test attributes of object."""
        address = Address(locale='ru')
        assert address.field is not None
        assert address.field.random is not None
        assert address.locale == 'ru'

    test_object_creation()
    test_attributes()


# Generated at 2022-06-23 21:03:37.581928
# Unit test for method country_code of class Address
def test_Address_country_code():
    print(Address().country_code())



# Generated at 2022-06-23 21:03:39.669006
# Unit test for method country of class Address
def test_Address_country():

    address = Address(None)
    country = address.country()
    assert country == 'Argentina'


# Generated at 2022-06-23 21:03:44.651078
# Unit test for method state of class Address
def test_Address_state():
    """Test Address.state()."""
    a = Address()
    st = a.state()
    assert st in a._data['state']['name']

    st = a.state(abbr=True)
    assert st in a._data['state']['abbr']

# Generated at 2022-06-23 21:03:46.734015
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address('de').longitude() >= -180 and Address('de').longitude() <= 180


# Generated at 2022-06-23 21:03:48.957499
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis import Address
    assert(Address().street_suffix() in Address._data['street']['suffix'])

# Generated at 2022-06-23 21:03:52.515200
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address(random=False)
    a.random.seed(0)
    assert a.longitude() == -177.991506
    assert a.longitude(dms=True) == '177º59\'29.522"W'

# Generated at 2022-06-23 21:03:59.068215
# Unit test for method prefecture of class Address
def test_Address_prefecture():

    # Initialize the instance of class Address
    address = Address('zh')

    # Get a random prefecture of China
    prefecture = address.prefecture()
    # Check the type of attribute prefecture: str
    assert type(prefecture) == str
    # Unit test passed.
    print('test passed.')



# Generated at 2022-06-23 21:04:06.313442
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.enums import Gender
    address = Address(locale='en')
    street_name = address.street_name()
    address.locale = 'ru-RU'
    # Test method street_name
    assert callable(address.street_name)
    assert isinstance(address.street_name(),str)
    assert address.street_name() != street_name
    # Test method city
    assert callable(address.city)
    assert isinstance(address.city(),str)
    assert address.city() != address.city()
    # Test method country
    assert callable(address.country)
    assert isinstance(address.country(),str)
    assert address.country(allow_random=True) != address.country(allow_random=True)
   

# Generated at 2022-06-23 21:04:08.711018
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale
    x = Address(locale = Locale.JAPANESE)
    print(x.city())

# Generated at 2022-06-23 21:04:10.955202
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    latitude = address.latitude()
    assert latitude >= -90 and latitude <= 90, "Latitude is not in range [-90; 90] !"


# Generated at 2022-06-23 21:04:13.647615
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('ru')
    assert address.prefecture() in address._data['state']['name']

# Generated at 2022-06-23 21:04:25.681524
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis import Address, __version__

    # Helper to check values in range [-180; 180]
    def check_value_in_range(value):
        if value < -180 or value > 180:
            raise AssertionError('value is not in range [-180; 180]')

    gen1 = Address()
    gen2 = Address('ru')
    gen3 = Address('ru')

    # Check value gen1
    value1 = gen1.longitude()
    check_value_in_range(value1)

    # Check value gen2
    value2 = gen2.longitude()
    check_value_in_range(value2)

    # Check value gen3
    value3 = gen3.longitude()
    check_value_in_range(value3)

    # Check that values are not equal
   

# Generated at 2022-06-23 21:04:30.972175
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import Country
    from mimesis.providers.address import Address
    address_ = Address(locale=Country.UNITED_STATES)
    result = address_.calling_code()
    assert (result is not None)
    assert (isinstance(result, str))
    assert (result in CALLING_CODES)


# Generated at 2022-06-23 21:04:33.955425
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert street_name in address._data['street']['name']



# Generated at 2022-06-23 21:04:39.431116
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.localization import get_locale
    from mimesis.enums import CountryCode
    adr = Address(get_locale('en'))
    assert adr.coordinates(dms=True) == adr.latitude(dms=True) and adr.longitude(dms=True)


# Generated at 2022-06-23 21:04:44.599797
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a1 = Address()
    c = a1.coordinates()
    if (c['latitude'] < -90) or (c['latitude'] > 90) or (c['longitude'] < -180) or (c['longitude'] > 180):
        return False
    if isinstance(c['latitude'], float) and isinstance(c['longitude'], float):
        return True
    else:
        return False


# Generated at 2022-06-23 21:04:47.050835
# Unit test for method country of class Address
def test_Address_country():
    """Unit test for method country of class Address."""
    address = Address()
    assert address.country() in address._data['country']['name']

# Generated at 2022-06-23 21:04:49.419390
# Unit test for method street_number of class Address
def test_Address_street_number():
    f = Address()
    assert len(f.street_number()) == 4


# Generated at 2022-06-23 21:04:52.057860
# Unit test for method longitude of class Address
def test_Address_longitude():
    adr = Address(random_seed=1)
    print('longitude: ' + str(adr.longitude()))


# Generated at 2022-06-23 21:04:54.084113
# Unit test for method province of class Address
def test_Address_province():
    assert Address('es').province() in Address('es')._data['state']['name']


# Generated at 2022-06-23 21:04:56.416042
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test method calling_code of class Address."""
    assert Address().calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:04:57.535003
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    print(address.country())

# Generated at 2022-06-23 21:05:01.519002
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Test for type of value
    test_result = type(Address().calling_code())
    assert type(test_result) == str
    # Test for callable of method
    assert callable(Address().calling_code)


# Generated at 2022-06-23 21:05:07.089214
# Unit test for method longitude of class Address
def test_Address_longitude():
    
    # Create the Address object
    A = Address()

    # Create a list of 100 elements composed by the values returned by the Address().longitude method
    l = [A.longitude() for _ in range(100)]

    # Assertions
    assert l != None
    assert len(l) == 100
    assert isinstance(l, list)
    assert all(isinstance(x, float) for x in l)
    assert all(x>=-90 and x<=90 for x in l)


# Generated at 2022-06-23 21:05:08.529550
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address('en')
    street_name = a.street_name()
    print(street_name)
    

# Generated at 2022-06-23 21:05:13.426711
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    test = Address()
    longitude = test._get_fs('lg')
    latitude = test._get_fs('lt')
    result = {'longitude': longitude, 'latitude': latitude}
    coordinates = test.coordinates()
    assert coordinates['longitude'] == longitude and \
           coordinates['latitude'] == latitude


# Generated at 2022-06-23 21:05:24.017365
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    expected_value = [
        "st",
        "ave",
        "pl",
        "ln",
        "ave",
        "al",
        "ave",
        "blvd",
        "way",
        "ln",
        "lk",
        "ct",
        "rd",
        "st",
        "rd",
        "ave",
        "rd",
        "cres",
        "ave",
        "rd",
        "pl",
        "st",
        "ave",
        "ln",
        "cres",
    ]
    street_suffix = Address()
    results = []
    for i in range(30):
        result = street_suffix.street_suffix()
        results.append(result)

    assert results == expected_value


# test for method region of

# Generated at 2022-06-23 21:05:25.082034
# Unit test for constructor of class Address
def test_Address():
    provider = Address()
    assert isinstance(provider, Address)


# Generated at 2022-06-23 21:05:35.824303
# Unit test for method latitude of class Address
def test_Address_latitude():
    # Case 1: longitude = 50
    a = Address()
    if a.latitude(dms=True) == "50º0'0.000" + 'N':
        return True
    # Case 2: longitude = -90
    a = Address()
    if a.latitude(dms=True) == "90º0'0.000" + 'S':
        return True
    # Case 3: longitude = 0
    a = Address()
    if a.latitude(dms=True) == "0º0'0.000" + 'N':
        return True
    # Case 4: random longitude
    a = Address()
    if -90 <= float(a.latitude(dms=True).split('º')[0]) <= 90:
        return True
    else:
        return False
# Unit

# Generated at 2022-06-23 21:05:39.461232
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address("uk")
    longitude = address.longitude()

    # Check that the generated value is a number
    assert type(longitude) == float

    # Check that the generated value falls into the range from -180 to 180
    assert longitude >= -180 and longitude <= 180


# Generated at 2022-06-23 21:05:41.261812
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert address.street_number()


# Generated at 2022-06-23 21:05:46.207179
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test Address longitude."""
    # Check longitude, latitude and format.
    # Initialize address object.
    address = Address(seed=42)
    # Generate coordinate in DMS format.
    _c = address.coordinates(dms=True)
    # Expected result (data from seed 42).
    _r = {'longitude': '121º7\'58.45862"E', 'latitude': '-12º46\'11.92287"S'}
    assert _c == _r  # Compare result.
    # Check that longitude is an integer.
    assert isinstance(_c['longitude'], str)  # Check type.
    assert 'º' in _c['longitude'] and '\'' in _c['longitude']  # Check format.

# Generated at 2022-06-23 21:05:48.379232
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()
    assert address.federal_subject() == result


# Generated at 2022-06-23 21:05:50.206892
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert address.zip_code() != address.zip_code()


# Generated at 2022-06-23 21:05:53.502290
# Unit test for method city of class Address
def test_Address_city():
    for i in range(1):
        a = Address('en')
        print(a.city())


# Generated at 2022-06-23 21:05:55.151132
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    print("Test zip_code")
    address = Address()
    print(address.zip_code())


# Generated at 2022-06-23 21:05:57.564465
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    assert address.street_suffix() in address._data['street']['suffix']


# Generated at 2022-06-23 21:06:00.865522
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert a.continent(code = True) in CONTINENT_CODES # continent is one of the values in CONTINENT_CODES
    assert a.continent(code = False) in a._data['continent'] # continent is one of the values in address.json

# Generated at 2022-06-23 21:06:05.218448
# Unit test for method latitude of class Address
def test_Address_latitude():
    """
    https://github.com/lk-geimfari/mimesis/blob/master/test/test_address.py
    """
    from mimesis.enums import Locale
    x = Address(Locale.EN)
    lat = x.latitude()
    assert len(lat) != 0

    lat_dms = x.latitude(dms=True)
    assert len(lat_dms) != 0


# Generated at 2022-06-23 21:06:09.020990
# Unit test for method longitude of class Address
def test_Address_longitude():
    geo = Address()
    lng = geo.longitude()
    assert -180.0 <= lng <= 180.0

# Generated at 2022-06-23 21:06:10.709619
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert Address().street_number() in [str(i) for i in range(1, 1401)]



# Generated at 2022-06-23 21:06:12.940993
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
	address = Address()
	print(address.street_suffix())
	print(address.street_suffix())
	print(address.street_suffix())



# Generated at 2022-06-23 21:06:14.185841
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert a.region() != a.region()


# Generated at 2022-06-23 21:06:20.565366
# Unit test for constructor of class Address
def test_Address():
    a = Address()

    a.address()
    a.calling_code()
    a.city()
    a.country()
    a.country_code()
    a.continent()
    a.coordinates()
    a.latitude()
    a.longitude()
    a.postal_code()
    a.state()
    a.street_name()
    a.street_number()
    a.street_suffix()
    a.zip_code()

# Generated at 2022-06-23 21:06:27.391738
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis import Address
    import pprint
    pp = pprint.PrettyPrinter(indent=4)
    # For ru locale
    ru_zip_code = Address(locale='ru').zip_code()
    pp.pprint(ru_zip_code)
    # Return russian zip code
    assert ru_zip_code == "644002"
    # For us locale
    us_zip_code = Address(locale='us').zip_code()
    pp.pprint(us_zip_code)
    # Return us zip code
    assert ru_zip_code == "44145"


# Generated at 2022-06-23 21:06:35.300416
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Test 1
    addr = Address(lang='es')
    longitude_1 = addr.longitude()
    longitude_2 = addr.longitude()
    assert longitude_1 == longitude_2, 'Test #1: Failed'
    
    # Test 2
    addr = Address(lang='es')
    longitude_1 = addr.longitude(dms = True)
    longitude_2 = addr.longitude(dms = True)
    assert longitude_1 == longitude_2, 'Test #2: Failed'


# Generated at 2022-06-23 21:06:42.736853
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.localization import DEFAULT_LOCALE
    from mimesis.providers import Address

    a = Address(DEFAULT_LOCALE)

    for _ in range(0, 10):
        assert a.federal_subject() in ("Московская область", "Адыгея", "Калужская область")


# Generated at 2022-06-23 21:06:45.022895
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address."""
    coordinates = Address('ru').coordinates()
    assert len(coordinates) == 2
    assert isinstance(coordinates, dict)
    assert isinstance(coordinates['longitude'], float)
    assert isinstance(coordinates['latitude'], float)

# Generated at 2022-06-23 21:06:46.647331
# Unit test for method city of class Address
def test_Address_city():
    print(Address().city())


# Generated at 2022-06-23 21:06:50.473251
# Unit test for method latitude of class Address
def test_Address_latitude():
    t = Address()
    c = 0
    for i in range(0,1):
        c += float(t.latitude())
    return c


# Generated at 2022-06-23 21:06:59.230867
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.builtins import address
    from ddt import ddt, data

    @ddt
    class TestAddressLongitude(unittest.TestCase):
        def setUp(self):
            self.add = address.Address('zh')

        @data(
            (180, True),
            (180, False)
        )
        def test_longitude(self, test_input, expected):
            test_output = self.add.longitude(test_input)
            self.assertEqual(test_output, expected)

    unittest.main()


# Generated at 2022-06-23 21:07:01.822403
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    assert street_name is not None



# Generated at 2022-06-23 21:07:03.258053
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert address.zip_code() == '228030'

# Generated at 2022-06-23 21:07:04.963355
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address(random_state=4)
    assert a.continent() == 'Africa'


# Generated at 2022-06-23 21:07:06.872872
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert any([address.postal_code(), address.zip_code()])

# Generated at 2022-06-23 21:07:15.937673
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale
    #ar
    Address.set_locale(Locale.AR)
    assert len(Address().city()) > 0
    #bg
    Address.set_locale(Locale.BG)
    assert len(Address().city()) > 0
    #cs
    Address.set_locale(Locale.CS)
    assert len(Address().city()) > 0
    #de
    Address.set_locale(Locale.DE)
    assert len(Address().city()) > 0
    #en
    Address.set_locale(Locale.EN)
    assert len(Address().city()) > 0
    #es
    Address.set_locale(Locale.ES)
    assert len(Address().city()) > 0
    #fa

# Generated at 2022-06-23 21:07:19.463923
# Unit test for method latitude of class Address
def test_Address_latitude():
    #Generate random float number between -90 and 90
    #It represents latitude
    location = Address().latitude()
    assert -90.0 <= float(location) <= 90.0


# Generated at 2022-06-23 21:07:21.606203
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    print ("3. continento: ", address.continent())

# Generated at 2022-06-23 21:07:23.765143
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    result = address.calling_code()
    assert result in CALLING_CODES


# Generated at 2022-06-23 21:07:26.408245
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """test case for calling_code()"""
    address = Address('en')
    result = address.calling_code()
    assert result in CALLING_CODES
    assert isinstance(result, str)


# Generated at 2022-06-23 21:07:30.107843
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    # federal_subject is an alias for state method
    # so we don't need to test them separately
    assert address.federal_subject() in address._data['state']['name']

# Generated at 2022-06-23 21:07:31.703347
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address().longitude() == -70.438923


# Generated at 2022-06-23 21:07:36.392842
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    print(a.province())
    print(a.province())
    print(a.province())
    print(a.province())
    print(a.province())
    print(a.province())
    print(a.province())

# Generated at 2022-06-23 21:07:46.459488
# Unit test for constructor of class Address
def test_Address():
    print("Test Address:")
    print("-"*10)

    print("Create object of class")
    address = Address("ru")
    print("Passed")

    print("Test method `street_number`")
    assert isinstance(address.street_number(), str)
    print("Passed")

    print("Test method `street_name`")
    assert isinstance(address.street_name(), str)
    print("Passed")

    print("Test method `street_suffix`")
    assert isinstance(address.street_suffix(), str)
    print("Passed")

    print("Test method `address`")
    assert isinstance(address.address(), str)
    print("Passed")

    print("Test method `state`")
    assert isinstance(address.state(), str)
    print("Passed")



# Generated at 2022-06-23 21:07:52.616498
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)
    assert(a.state() != None)

# Generated at 2022-06-23 21:07:55.760164
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import Locale
    _tmp = Address(Locale.FRENCH)
    assert _tmp.prefecture() in _tmp._data['state']['name']

# Generated at 2022-06-23 21:08:06.185873
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import DataField

    lati = Address('en').latitude()

    assert isinstance(lati, float)
    assert -90.0 <= lati <= 90.0
    assert len(str(lati).split('.')[1]) == 6

    dms = Address('en').latitude(dms=True)

    assert isinstance(dms, str)
    assert len(dms.split('º')) == 3

    en = Address('en')
    assert en.latitude() == en.latitude(dms=False)
    assert en.latitude(dms=True)[-1] == 'N'

    de = Address('de')
    assert de.latitude() == de.latitude(dms=False)
    assert de.latitude(dms=True)[-1]

# Generated at 2022-06-23 21:08:10.594998
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode

    addr = Address(locale='en')

    # Test for Address.address().
    address = addr.address()

    assert isinstance(address, str)
    assert address.count(' ') >= 2

    # Test for Address.address() with ``country.code``.
    address = addr.address(code=CountryCode.A2)

    assert isinstance(address, str)
    assert address.count(' ') >= 2
    assert address[len(address) - 2:].isupper()



# Generated at 2022-06-23 21:08:13.317490
# Unit test for method province of class Address
def test_Address_province():
    state_address=Address(locale='en')
    assert state_address.province(abbr=False) == 'California'

# Generated at 2022-06-23 21:08:14.389405
# Unit test for method region of class Address
def test_Address_region():
    ad = Address()
    region = ad.region()
    assert type(region) is str
    assert 1 <= len(region) <= 2

# Generated at 2022-06-23 21:08:20.474286
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    random_a_prefecture = address.prefecture()
    random_a_prefecture_abbr = address.prefecture(abbr=True)
    assert random_a_prefecture in address._data['state']['name']
    assert random_a_prefecture_abbr in address._data['state']['abbr']


# Generated at 2022-06-23 21:08:25.480847
# Unit test for method address of class Address
def test_Address_address():
    """
    Test method Address.address()
    """
    import sys
    sys.path.append('../')

    from providers.address import Address

    addr = Address('fr')
    address = addr.address()
    assert address is not None
    assert address != ''
    assert isinstance(address, str)
    print(f'Address: {address}')

