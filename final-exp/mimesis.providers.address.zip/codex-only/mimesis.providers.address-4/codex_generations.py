

# Generated at 2022-06-23 20:58:30.156565
# Unit test for method continent of class Address
def test_Address_continent():
    random_address = Address()
    assert random_address.continent() in ["Asia", "Europe", "South America", "Africa", "Oceania", "Antarctica", "North America"]
    assert random_address.continent(True) in ["AS", "EU", "SA", "AF", "OC", "AN", "NA"]



# Generated at 2022-06-23 20:58:32.433062
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    street_suffix = address.street_suffix()
    assert street_suffix in address._data['street']['suffix']

# Generated at 2022-06-23 20:58:35.868602
# Unit test for method street_name of class Address
def test_Address_street_name():
    temp = Address()
    assert isinstance(temp.street_name(), str)


# Generated at 2022-06-23 20:58:38.036310
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    lat = a.latitude()
    assert lat > -90 and lat < 90


# Generated at 2022-06-23 20:58:44.418256
# Unit test for method country of class Address
def test_Address_country():
    locale = 'ru'
    # verify country
    inst = Address(locale=locale)
    assert inst.country(allow_random=True) in inst._data['country']['name']
    assert inst.country(allow_random=False) == \
            inst._data['country']['current_locale']


# Generated at 2022-06-23 20:58:48.694507
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address(locale='en')
    assert a.street_name() in \
        ['Acacia Court', 'Hazel Court', 'Raspberry Drive', 'Tamarisk Drive']
    print('\ntest_Address_street_name: OK!')



# Generated at 2022-06-23 20:58:51.317330
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code() == '123456'

# Generated at 2022-06-23 20:58:53.914058
# Unit test for method latitude of class Address
def test_Address_latitude():
    instance = Address(locale='en')
    result = instance.latitude()
    assert result is not float


# Generated at 2022-06-23 20:59:01.198559
# Unit test for method country_code of class Address
def test_Address_country_code():
    adr = Address(locale='en')
    # set the random seed so that we always get the same result
    adr.random.seed(0xDEADBEEF)
    assert adr.country_code() == 'CA'
    assert adr.country_code(CountryCode.A3) == 'CAN'
    assert adr.country_code(CountryCode.NUMERIC) == '124'
    assert adr.country_code(CountryCode.A2) == 'CA'


# Generated at 2022-06-23 20:59:09.870924
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.builtins import address
    from mimesis.utils import get_locales
    import os

    path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'data'))
    locales = get_locales(path)
    for locale in locales:
        if locale not in address.supported_locales:
            continue
        adr = address.Address(locale)
        adr.country_code(CountryCode.A2)
        adr.postal_code()
        adr.zip_code()
        adr.calling_code()
        adr.latitude()
        adr.longitude()
        adr.province()
        adr.state

# Generated at 2022-06-23 20:59:11.050263
# Unit test for method city of class Address
def test_Address_city():
    ad = Address()
    assert ad.city()

# Generated at 2022-06-23 20:59:15.312234
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import Region
    import re
    a = Address(region=Region.RU)
    pc = a.postal_code()
    r = re.compile('[0-9]+')
    assert r.match(pc)


# Generated at 2022-06-23 20:59:17.626029
# Unit test for method region of class Address
def test_Address_region():
    # Arrange
    address = Address('en')

    # Act
    result = address.region()

    # Assert
    assert isinstance(result, str)

# Generated at 2022-06-23 20:59:20.494774
# Unit test for method street_number of class Address
def test_Address_street_number():
    data = Address()
    data_street_number = data.street_number(maximum=1400)
    print("Street number is: " + data_street_number)


# Generated at 2022-06-23 20:59:21.678917
# Unit test for method street_name of class Address
def test_Address_street_name():
    address=Address('fr')
    assert type(address.street_name()).__name__=='str'

# Generated at 2022-06-23 20:59:24.861431
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() in \
        [
        'Africa',
        'Antarctica',
        'Asia',
        'Europe',
        'North America',
        'Oceania',
        'South America',
        ]


# Generated at 2022-06-23 20:59:26.161413
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    result = provider.address()
    assert isinstance(result, str)


# Generated at 2022-06-23 20:59:27.030561
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject() != ''

# Generated at 2022-06-23 20:59:29.712757
# Unit test for method latitude of class Address
def test_Address_latitude():
    # Input variables
    dms = True

    # Expected result
    result = '-13.910'

    # Check
    assert Address.latitude() == result, 'Wrong result!'
to_do_test("test_Address_latitude")


# Generated at 2022-06-23 20:59:30.539605
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address('en')
    assert address.street_number() is not None


# Generated at 2022-06-23 20:59:32.946087
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    # print(a.region())
    assert isinstance(a.region(), str)


# Generated at 2022-06-23 20:59:40.528714
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    assert len(address.country_code()) == 2
    assert len(address.country_code('a')) == 2
    assert len(address.country_code(fmt='a2')) == 2
    assert len(address.country_code('alpha2')) == 2
    assert len(address.country_code('a3')) == 3
    assert len(address.country_code(fmt='alpha3')) == 3
    assert len(address.country_code('n')) == 3
    assert len(address.country_code('numeric')) == 3


# Generated at 2022-06-23 20:59:42.756799
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Unit test for method street_number of class Address."""
    address = Address()
    result = address.street_number()
    assert result.isdigit()
    assert int(result) > 0


# Generated at 2022-06-23 20:59:43.690490
# Unit test for method country of class Address
def test_Address_country():
    """."""
    pass

# Generated at 2022-06-23 20:59:44.186084
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    pass

# Generated at 2022-06-23 20:59:46.221089
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()

    assert isinstance(address.prefecture(), str)
    assert len(address.prefecture()) > 0


# Generated at 2022-06-23 20:59:48.519190
# Unit test for method street_number of class Address
def test_Address_street_number():
    try:
        a = Address('en')
        assert isinstance(a.street_number(), str)
    except:
        assert False


# Generated at 2022-06-23 20:59:51.102163
# Unit test for method province of class Address
def test_Address_province():
    x = Address(locale='en-US')
    expected = 'AP'
    actual = x.province(abbr=True)
    assert actual == expected


# Generated at 2022-06-23 20:59:54.298687
# Unit test for method state of class Address
def test_Address_state():
    address = Address("en")
    assert address.state(True) in ("WA", "WV", "WI", "WY")
    assert address.state() in ("Washington", "West Virginia", "Wisconsin", "Wyoming")


# Generated at 2022-06-23 20:59:57.335211
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    res = a.coordinates()
    print(res)
    assert res["longitude"] > -180 and res["longitude"] < 180
    assert res["latitude"] > -90 and res["latitude"] < 90

# Generated at 2022-06-23 20:59:58.867513
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # Проверка возвращаемого типа
    assert isinstance(Address().federal_subject(), str)


# Generated at 2022-06-23 21:00:04.056857
# Unit test for method latitude of class Address
def test_Address_latitude():
    adr = Address()
    lat = adr.latitude()
    assert -90 <= float(lat) <= 90
    lat = adr.latitude(dms=True)
    assert lat.endswith('S")') or lat.endswith('N")')


# Generated at 2022-06-23 21:00:05.840345
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    street_name = address.street_name()
    assert street_name



# Generated at 2022-06-23 21:00:07.733124
# Unit test for method state of class Address
def test_Address_state():
    address = Address('en')
    random_state = address.state()
    assert random_state in address._data['state']['name']


# Generated at 2022-06-23 21:00:09.572071
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state() in address._data['state']['name']


# Generated at 2022-06-23 21:00:11.535407
# Unit test for method city of class Address
def test_Address_city():
    assert (Address().city() in Address()._data['city'])


# Generated at 2022-06-23 21:00:12.796190
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert 'St' == Address().street_suffix()


# Generated at 2022-06-23 21:00:25.073230
# Unit test for method country_code of class Address
def test_Address_country_code():
    provider = Address('en')
    for i in range(10):
        code = provider.country_code()
        assert code.lower() in COUNTRY_CODES[CountryCode.A2]
        code = provider.country_code(fmt=CountryCode.A3)
        assert code.lower() in COUNTRY_CODES[CountryCode.A3]
        code = provider.country_code(fmt=CountryCode.Name)
        assert code.lower() in COUNTRY_CODES[CountryCode.Name]
        code = provider.country_code(fmt=CountryCode.Numeric)
        assert code.lower() in COUNTRY_CODES[CountryCode.Numeric]
        code = provider.country_code(fmt=CountryCode.OfficialName)

# Generated at 2022-06-23 21:00:26.470469
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    test = Address()
    print(test.street_suffix())

# Generated at 2022-06-23 21:00:28.381027
# Unit test for method city of class Address
def test_Address_city():
    address = Address('fr')
    result = address.city()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:00:31.864800
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Initialize an address object
    address_obj=Address("en")
    # Get calling code
    calling_code=address_obj.calling_code()
    # Check that calling code is not empty
    assert bool(calling_code)

# Generated at 2022-06-23 21:00:33.853030
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
  test_site = Address()
  test_site.federal_subject()

# Generated at 2022-06-23 21:00:36.564016
# Unit test for method street_number of class Address
def test_Address_street_number():
    instance = Address()
    print(instance.street_number())
    assert isinstance(instance.street_number(), str)


# Generated at 2022-06-23 21:00:37.335416
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)

# Generated at 2022-06-23 21:00:38.345868
# Unit test for constructor of class Address
def test_Address():
    print(Address().region())

# Generated at 2022-06-23 21:00:40.582661
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address(locale='en')
    addr_num = address.street_number(maximum=100000)
    assert addr_num.isdigit()


# Generated at 2022-06-23 21:00:41.136441
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    Address().prefecture()

# Generated at 2022-06-23 21:00:44.894948
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.providers.address import Address 
    address_provider = Address('en') 
    assert isinstance(address_provider.longitude(),float) or isinstance(address_provider.longitude(),str)


# Generated at 2022-06-23 21:00:47.389147
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert isinstance(address.street_number(), str)


# Generated at 2022-06-23 21:00:48.848399
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.localization import Address

    print(Address.address())

# Generated at 2022-06-23 21:00:50.501295
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('zh')
    address.prefecture(True)


# Generated at 2022-06-23 21:00:52.688044
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    num = address.street_number()
    assert(isinstance(num, str))


# Generated at 2022-06-23 21:01:01.575396
# Unit test for constructor of class Address
def test_Address():
    test_size = 10
    addr = Address()

    # Test __init__
    # zone = addr.timezone
    # tz = TimeZone(zone)
    # assert tz.now()

    # Test address
    addr_fmt = addr.address()
    assert addr_fmt[0].isdigit()

    # Test calling_code
    calling_code = addr.calling_code()
    assert len(calling_code) == 3
    calling_code = int(calling_code)
    assert calling_code >= 1 and calling_code < 1000

    # Test city
    city = addr.city()
    assert city

    # Test country
    country = addr.country()
    assert country

    # Test country_code
    country_code = addr.country_code()
    assert country_code

    # Test coordinates


# Generated at 2022-06-23 21:01:06.552313
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # Declare Address class
    adr = Address()
    # Get random prefecture
    pf = adr.prefecture()
    # Declare list state abbr
    state_abbr = adr._data['state']['abbr']
    # Check prefecture in list state abbr or not
    assert (pf in state_abbr)

# Generated at 2022-06-23 21:01:10.448567
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    import unittest
    
    # 1. Test without passing locale.
    addr = Address()
    assert isinstance(addr.street_suffix(), str)
    
    # 2. Test passing locale.
    addr = Address(locale='ja')
    assert isinstance(addr.street_suffix(), str)


# Generated at 2022-06-23 21:01:12.151856
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    a = address.province()
    print(a)
    assert(len(a) == 2)


# Generated at 2022-06-23 21:01:17.657532
# Unit test for method country of class Address
def test_Address_country():
    addr = Address(locale='en')
    country = addr.country()
    assert country == 'United States of America'


if __name__ == "__main__":
    # Unit test for method country of class Address
    # test_Address_country()
    pass

# Generated at 2022-06-23 21:01:20.130119
# Unit test for method country_code of class Address
def test_Address_country_code():
    country_code = Address().country_code()
    assert country_code in COUNTRY_CODES[CountryCode.A2]


# Generated at 2022-06-23 21:01:27.338673
# Unit test for method federal_subject of class Address

# Generated at 2022-06-23 21:01:29.916501
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    i = 1
    while i <= 100:
        assert ((Address().zip_code() != '') and (len(Address().zip_code()) == 5))
        i = i + 1

# Generated at 2022-06-23 21:01:34.589999
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    os.chdir(r'E:\mimesis-master\mimesis\tests\stdlib')
    with open('Address_zip_code.txt', 'w+', encoding='utf8') as f:
        for i in range(100000000):
            f.write(Address('ru').zip_code() + '\n')
    assert i == 99999999

# Generated at 2022-06-23 21:01:36.600884
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address(seed=12345)\
    .country_code() == 'JP'


# Generated at 2022-06-23 21:01:38.648351
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    my_object = Address()
    assert my_object.prefecture() in my_object._data['state']['name']


# Generated at 2022-06-23 21:01:42.325875
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a.state() in a._data['state']['name']
    assert isinstance(a.state(), str)


# Generated at 2022-06-23 21:01:46.901378
# Unit test for method address of class Address
def test_Address_address():
    address = Address('ru')
    result = address.address()
    assert isinstance(result, str)
    assert result

    address = Address('en')
    result = address.address()
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-23 21:01:56.449731
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    list = [
        address.street_number(10),
        address.street_name(),
        address.street_suffix(),
        address.address(),
        address.state(),
        address.region(),
        address.province(),
        address.federal_subject(),
        address.prefecture(),
        address.postal_code(),
        address.zip_code(),
        address.country_code(),
        address.country(True),
        address.city(),
        address.latitude(),
        address.longitude(),
        address.coordinates(),
        address.continent(),
        address.calling_code(),
    ]

    assert len(list) > 0
    assert isinstance(list[0], str)
    assert isinstance(list[1], str)

# Generated at 2022-06-23 21:01:58.595223
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    c = a.coordinates()
    print("c:",c)
    assert type(c) is dict
    return c


# Generated at 2022-06-23 21:02:04.344483
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import Country
    from mimesis.utils import generate_code
    from cw_models.address import Address
    from cw_models.address import Address

    # random - 0.8 < random < 0.2
    # random >= 0.8
    a = Address(Country.RUSSIA)
    random = 0.96646
    result = a._get_fs('lt', 0.2, 0.8, random)
    assert result >= 90.0
    assert result <= -90.0
    assert type(result) == float

    # random < 0.8
    random = 0.64664
    result = a._get_fs('lt', 0.2, 0.8, random)
    assert result >= 90.0
    assert result <= -90.0
    assert type(result) == float

# Generated at 2022-06-23 21:02:07.334678
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    b = a.prefecture()
    assert a.prefecture() == b
    #assert b == '浙江省'

# Generated at 2022-06-23 21:02:09.641171
# Unit test for method state of class Address
def test_Address_state():
    a = Address("en")
    print(a.state())


# Generated at 2022-06-23 21:02:14.235429
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale

    a = Address(Locale.SPANISH)
    x = set()
    for i in range(100):
        x.add(a.city())
    print(sorted(x))


# Generated at 2022-06-23 21:02:18.567569
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    result_1 = a.province()
    assert result_1 in a._data['state']['name']
    result_2 = a.province(abbr=True)
    assert result_2 in a._data['state']['abbr']

# Generated at 2022-06-23 21:02:20.605390
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    number = address.street_number()
    assert int(number) <= 1400 and int(number) >= 1


# Generated at 2022-06-23 21:02:22.888474
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address('ru')
    assert address.country_code() in COUNTRY_CODES['a2']

# Generated at 2022-06-23 21:02:26.233623
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit tests for federal_subject method of Address class."""
    adr = Address('ru')
    assert isinstance(adr.federal_subject(), str)
    assert str(adr.federal_subject()).isupper()
    assert adr.federal_subject().isalpha()


# Generated at 2022-06-23 21:02:29.707849
# Unit test for method country_code of class Address
def test_Address_country_code():
    test_obj = Address()
    expected_output = str
    result = test_obj.country_code()
    assert isinstance(result, expected_output), "Error: result should be {}, but it is {}".format(expected_output, result)

# Generated at 2022-06-23 21:02:33.590195
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Country
    from mimesis.providers import Address
    for _ in range(10):
        t = Address('en', Country.UNITED_STATES)
        suffix = t.street_suffix()
        assert suffix in t._data['street']['suffix']


# Generated at 2022-06-23 21:02:35.817377
# Unit test for method country of class Address
def test_Address_country():
    a = Address("ag","Ag")
    assert a.country(True) == "Antigua e Barbuda"


# Generated at 2022-06-23 21:02:38.423926
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.localization import FRENCH
    fr = Address(locale=FRENCH)
    assert fr.postal_code() == '974-75'

# Generated at 2022-06-23 21:02:39.774665
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    print(Address.postal_code())


# Generated at 2022-06-23 21:02:41.819556
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test for method longitude() of class Address."""
    addr = Address('en')
    assert -90 <= addr.longitude() <= 90

# Generated at 2022-06-23 21:02:48.115740
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    import datetime
    
    print("test_Address_postal_code = ", Address('ru').postal_code())
    print("test_Address_postal_code = ", Address('ru').postal_code())
    print("test_Address_postal_code = ", Address('ru').postal_code())
    print("test_Address_postal_code = ", Address('ru').postal_code())
    print("test_Address_postal_code = ", Address('ru').postal_code())
    print("test_Address_postal_code = ", Address('ru').postal_code())
    print("test_Address_postal_code = ", Address('ru').postal_code())
    print("test_Address_postal_code = ", Address('ru').postal_code())

# Generated at 2022-06-23 21:02:49.522575
# Unit test for method continent of class Address
def test_Address_continent():
    pass


# Generated at 2022-06-23 21:02:51.897770
# Unit test for method city of class Address
def test_Address_city():
    city = Address('en').city()
    # print(city)
    assert city is not None

if __name__ == "__main__":
    test_Address_city()

# Generated at 2022-06-23 21:02:54.233951
# Unit test for method country_code of class Address
def test_Address_country_code():
    obj = Address()
    assert obj.country_code() in COUNTRY_CODES[obj._validate_enum(CountryCode.A2, CountryCode)]

# Generated at 2022-06-23 21:02:56.453457
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Testing method Address.federal_subject()."""
    address = Address('en')
    r = address.federal_subject()
    assert isinstance(r, str)

# Generated at 2022-06-23 21:02:58.423011
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.builtins import RussiaSpecProvider

    rus = Address(RussiaSpecProvider)
    assert isinstance(rus.city(),str)

# Generated at 2022-06-23 21:03:03.694903
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    st_sfx_list = ['St','N','Road','Ave','S','E','O']
    loc = 'en-US'
    addr = Address(loc)
    st_sfx = addr.street_suffix()
    assert st_sfx in st_sfx_list


# Generated at 2022-06-23 21:03:06.960457
# Unit test for method country of class Address
def test_Address_country():
    obj = Address()
    obj.locale = 'en'
    result = obj.country()
    print("result = ", result)
    assert result == 'Afghanistan'



# Generated at 2022-06-23 21:03:07.541189
# Unit test for method latitude of class Address
def test_Address_latitude():
    result = Address.latitude()
    assert result

# Generated at 2022-06-23 21:03:13.099995
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    a = Address(Locale.EN)
    result = a.street_suffix()
    assert result in ['Avenue', 'Lane', 'Boulevard', 'Drive', 'Court', 'Place', 'Road', 'Rd', 'Route', 'Highway', 'Broadway', 'Place']
    print("street_suffix: " + result)


# Generated at 2022-06-23 21:03:15.251077
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Unit test for method calling_code of class Address."""
    gen = Address()
    assert gen.calling_code() in CALLING_CODES



# Generated at 2022-06-23 21:03:16.768963
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address(seed=0)
    expected = "-75.835132"
    result = address.longitude(dms=False)
    assert result == expected


# Generated at 2022-06-23 21:03:21.309748
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    a = Address()
    assert isinstance(a.country_code(), str)
    assert a.country_code(CountryCode.A2) in COUNTRY_CODES.A2
    assert a.country_code(CountryCode.A3) in COUNTRY_CODES.A3
    assert a.country_code(CountryCode.Name) in COUNTRY_CODES.Name
    assert a.country_code(CountryCode.Numeric) in COUNTRY_CODES.Numeric


# Generated at 2022-06-23 21:03:30.021956
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Locale
    from unittest.mock import patch
    from .helpers import generate_provider

    for loc in Locale:
        a = Address(loc)
        result = a.country()
        assert result == a._data['country']['current_locale']

        # If a locale is not in list of locales, then
        # return a random country from the file address.json.
        with patch(
                'mimesis.enums.Locale.__contains__',
                return_value=False,
        ):
            result = a.country()
            assert result in a._data['country']['name']

# Generated at 2022-06-23 21:03:33.395474
# Unit test for method longitude of class Address
def test_Address_longitude():
    address_provider = Address()
    longitude = address_provider.longitude()
    if isinstance(longitude, str):
        longitude = float(address_provider.longitude())

    assert isinstance(longitude, float) and ((-180 <= longitude <= 180))


# Generated at 2022-06-23 21:03:34.596859
# Unit test for method country_code of class Address
def test_Address_country_code():
    country_code = Address.country_code()
    assert len(country_code) == 2

# Generated at 2022-06-23 21:03:46.342578
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for country code of class Address"""
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    addr = Address('en')
    
    # Test A2 CountryCode with locale of 'en'
    assert addr.country_code(CountryCode.A2) in ['GB', 'US', 'RU', 'CN', 'BR']
    # Test A3 CountryCode with locale of 'en'
    assert addr.country_code(CountryCode.A3) in ['GBR', 'USA', 'RUS', 'CHN', 'BRA']
    # Test numeric CountryCode with locale of 'en'
    assert addr.country_code(CountryCode.Numeric) in ['826', '840', '643', '156', '76']

# Generated at 2022-06-23 21:03:48.680877
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    assert address.city() == 'Алёнтовский'



# Generated at 2022-06-23 21:03:51.535143
# Unit test for method street_number of class Address
def test_Address_street_number():
    d = Address()
    # Check that street_number method returns a string
    assert type(d.street_number()).__name__ == 'str'


# Generated at 2022-06-23 21:03:54.942327
# Unit test for method city of class Address
def test_Address_city():
    l = ['city', 'country']
    for data in l:
        addr = Address()
        result = addr.city()

        assert result is not None
        assert type(result) is str
        assert len(result) > 1
        assert result[0].isupper()

# Generated at 2022-06-23 21:03:56.556911
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    n = address.street_number()
    assert n is not None


# Generated at 2022-06-23 21:03:58.242551
# Unit test for method continent of class Address
def test_Address_continent():
    print(Address().continent(code=True))
    print(Address().continent())



# Generated at 2022-06-23 21:04:01.664977
# Unit test for method country_code of class Address
def test_Address_country_code():
    # Arrange & Act
    a = Address()
    b = a.country_code()

    # Assert
    assert len(b) == 2
    assert b in COUNTRY_CODES[CountryCode.A2]


# Generated at 2022-06-23 21:04:06.220324
# Unit test for method address of class Address
def test_Address_address():
    """Test Address().address()."""
    adr = Address()
    fmt = '{st_num} {st_name}'

    assert re.match(fmt, adr.address())

# Generated at 2022-06-23 21:04:09.029153
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    name = a.street_name()
    assert isinstance(name, str)
    assert len(name) > 0
    return True

# Generated at 2022-06-23 21:04:10.805013
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() == -7.443344


# Generated at 2022-06-23 21:04:13.954773
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    x = Address(locale='en')
    expected_values = ['1']
    assert x.calling_code() in expected_values



# Generated at 2022-06-23 21:04:15.656079
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    country = Address()
    print(country.street_suffix())

# Generated at 2022-06-23 21:04:16.763667
# Unit test for method address of class Address
def test_Address_address():
    import random
    ad=Address(random.seed(1))
    #print(ad.address())

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-23 21:04:22.424906
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    lists = [
        'St',
        'Street',
        'Rd',
        'Road',
        'Lane',
        'Avenue',
        'Ave',
        'Alley',
        'Place',
    ]
    address = Address()
    for i in range(0, 100):
        assert address.street_suffix() in lists


# Generated at 2022-06-23 21:04:24.753502
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    result = type(address.continent()) == str
    assert result == True


# Generated at 2022-06-23 21:04:35.991966
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    code = CountryCode.A3

    a = Address()
    b = Address(locale='ru')
    c = Address(locale='fr')
    d = Address(locale='ja')
    e = Address(locale='cmn')

    assert a.region(abbr=code) in {'USA'}
    assert b.region(abbr=code) in {'RUS'}
    assert c.region(abbr=code) in {'FRA'}
    assert d.region() in {'東京都', '愛知県', '大阪府', '北海道'}

# Generated at 2022-06-23 21:04:38.948978
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.builtins import Address
    a = Address()
    b = a.street_name()

    assert b is not None


# Generated at 2022-06-23 21:04:40.382744
# Unit test for method city of class Address
def test_Address_city():
	f = Address()
	print(f.city())

# Generated at 2022-06-23 21:04:41.846958
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr = Address()
    print(addr.zip_code())


# Generated at 2022-06-23 21:04:43.746172
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.providers.address import Address
    address = Address()
    # print(address.city())


# Generated at 2022-06-23 21:04:46.112858
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    ad = Address()
    assert isinstance(ad.zip_code(), str) == True



# Generated at 2022-06-23 21:04:50.143729
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address()
    street_suffix = addr.street_suffix()
    assert len(street_suffix) > 0, \
        "The function street_suffix is broken. It returns an empty string."


# Generated at 2022-06-23 21:04:52.248610
# Unit test for method address of class Address
def test_Address_address():
    address = Address("zh")
    res = address.address()
    print(res)

# Generated at 2022-06-23 21:04:55.776036
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    ad = Address('zh')
    b = True
    for i in range(10):
        if len(ad.postal_code()) != 6:
            b = False
            break
    return b


# Generated at 2022-06-23 21:04:57.743261
# Unit test for method city of class Address
def test_Address_city():
    address = Address('en')
    assert (address.city() in address._data['city'])


# Generated at 2022-06-23 21:05:04.654985
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.providers.address import Address
    from mimesis.random import Generator
    import random
    ad = Address(random.Random(1))
    result = ad.coordinates()
    assert result['latitude'] == '-73.43875º5\'5.959"'
    assert result['longitude'] == '3.62512º17\'15.966"'
    ad2 = Address(Generator(1))
    assert ad2.coordinates() == result



# Generated at 2022-06-23 21:05:06.990743
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert type(address.address()) is str


# Generated at 2022-06-23 21:05:11.769431
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Unit test for method latitude of class Address."""
    result0 = Address().latitude()
    print(result0)
    assert type(result0) == float
    result1 = Address().latitude(dms=True)
    print(result1)
    assert type(result1) == str


# Generated at 2022-06-23 21:05:13.992881
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address(locale='ru').postal_code() == Address(locale='ru').zip_code()
    assert Address().postal_code() == Address().zip_code()

# Generated at 2022-06-23 21:05:16.041609
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert isinstance(address.prefecture(), str)


# Generated at 2022-06-23 21:05:18.688201
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('en')
    zip_code = address.postal_code()
    assert type(zip_code) is str



# Generated at 2022-06-23 21:05:21.660089
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address("zh")
    street_suffix = address.street_suffix()
    assert (street_suffix in address._data['street']['suffix']) is True


# Generated at 2022-06-23 21:05:23.846442
# Unit test for method address of class Address
def test_Address_address():
    # Initialize the class
    address = Address()
    # Generate a random full address
    result = address.address()
    # Check the data type of `result`
    assert isinstance(result, str)

# Generated at 2022-06-23 21:05:26.150930
# Unit test for method longitude of class Address
def test_Address_longitude():
    address_provider = Address("ru")
    longitude=address_provider.longitude()
    print("longitude:", longitude)
    assert -180<=longitude<=180 and type(longitude) is float


# Generated at 2022-06-23 21:05:30.043403
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    addr = Address()
    provinces = set()
    for i in range(200):
        provinces.add(addr.prefecture())

    assert len(provinces) >= 1
    assert len(provinces) <= 1

# Generated at 2022-06-23 21:05:32.408182
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    obj = Address(locale='en')
    assert isinstance(obj.street_suffix(), str)


# Generated at 2022-06-23 21:05:35.579665
# Unit test for method city of class Address
def test_Address_city():
    """Unit test for method city of class Address"""
    data = Address()
    assert data.city()  # Asserting not None


# Generated at 2022-06-23 21:05:46.578209
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    address = Address(locale='en')
    address.longitude()
    address.longitude(dms=True)
    address.latitude()
    address.latitude(dms=True)
    address.coordinates()
    address.coordinates(dms=True)
    address.street_number()
    address.street_number(maximum=8700)
    address.street_name()
    address.street_suffix()
    address.address()
    address.state()
    address.state(abbr=True)
    address.region()
    address.province()
    address.prefecture()
    address.federal_subject()
    address.postal_code()
    address.zip_code()
    address.country_code()
    address.country

# Generated at 2022-06-23 21:05:47.652783
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis import Address

    address = Address('ja')
    assert address.prefecture() in address._data['state']['name']

# Generated at 2022-06-23 21:05:50.250422
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.address
    assert address.province
    assert address.city
    assert address.country
    assert address.calling_code
    assert address.continent

# Generated at 2022-06-23 21:05:52.675334
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    a1 = Address()
    assert a1.longitude() is not None
    assert a1.longitude(dms=True) is not None
    a1 = Address(country_code=CountryCode.A3)
    a1.longitude() is not None
    assert a1.longitude(dms=True) is not None


# Generated at 2022-06-23 21:05:56.779287
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continent
    
    # Continent
    address = Address('zh')
    result = address.continent(code=True)
    result_name = address.continent()
    assert result_name == Continent.get_name(result)

# Generated at 2022-06-23 21:05:57.948739
# Unit test for method latitude of class Address
def test_Address_latitude():
  assert Address().latitude()


# Generated at 2022-06-23 21:06:03.469833
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.utils import get_locale
    from mimesis.builtins import Seedable

    seed = 0
    a = Address(seed=seed)
    a.set_locale(Locale.ES)

    expected = '28891'
    assert a.zip_code() == expected

    exp = '28891'
    assert a.zip_code() == exp

    a.random.seed(seed)
    assert a.zip_code() == exp

    a.reset_seed()
    expected = get_locale('es')
    # Test for unit test
    assert a.zip_code() == expected
    assert a._data['postal_code_fmt'] == '#####'


#

# Generated at 2022-06-23 21:06:06.647677
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address("en")
    assert a.postal_code() == "CO1 7YW" or a.postal_code() == "M13 7ZM" or a.postal_code() == "TR2 3XL"
    

# Generated at 2022-06-23 21:06:09.178040
# Unit test for method continent of class Address
def test_Address_continent():
    a=Address()
    result = a.continent()
    assert result in a._data['continent']


# Generated at 2022-06-23 21:06:19.438710
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis import Address
    a = Address(locale='pt-BR')
    assert a.region() == "RS"
    assert a.region(abbr=False) == "Rio Grande do Sul"
    assert a.country() == "Argelia"
    assert a.country(allow_random=True) == "Angola"
    assert list(CountryCode) == ['A2', 'A3', 'NUMERIC']
    assert a.country_code(CountryCode.NUMERIC) == '024'
    assert a.country_code() == 'DZ'
    assert a.country_code(CountryCode.A3) == 'DZA'
    assert a.calling_code() == '234'
    assert a.prefecture() == 'PE'
    assert a

# Generated at 2022-06-23 21:06:22.349332
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    # street_number() return list of string => cast to int for checking
    assert int(address.street_number()) <= 1400
    assert 1 <= int(address.street_number())


# Generated at 2022-06-23 21:06:23.936313
# Unit test for method country of class Address
def test_Address_country():
    ad = Address()
    res = ad.country()
    assert res == '中国'

# Generated at 2022-06-23 21:06:26.064464
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # test_Address = Address()
    # assert test_Address.street_suffix() in ['St', 'Dr', 'Ave', 'Dr']

    assert True

# Generated at 2022-06-23 21:06:26.903232
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    Address().calling_code()

# Generated at 2022-06-23 21:06:29.674739
# Unit test for method state of class Address
def test_Address_state():
    ad = Address()
    ls = []
    for i in range(10):
        ls.append(ad.state())
    print(ls)


# Generated at 2022-06-23 21:06:32.009059
# Unit test for method address of class Address
def test_Address_address():
    pass


if __name__ == '__main__':
    a = Address()
    print(a.address())

# Generated at 2022-06-23 21:06:37.649641
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    from mimesis.enums import CountryCode
    from mimesis.providers.en import Address as AddressEN
    from mimesis.providers.pt_BR import Address as AddressPT_BR

    # Get a Brazilian address
    address = AddressPT_BR().address()

    # Get a Brazilian postal code
    postal_code = AddressPT_BR().postal_code()

    # Get a United States zip code
    zip_code = AddressEN(CountryCode.US).zip_code()

    # Get an American state code
    state_abbr = AddressEN(CountryCode.US).state(True)

    # Get a Brazilian state code
    state_abbr = AddressPT_BR(CountryCode.BR).state(True)

# Generated at 2022-06-23 21:06:40.530947
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Unit test for class Address."""
    address = Address('en')
    assert type(address.postal_code()) is str

# Generated at 2022-06-23 21:06:44.960836
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    data = address.get_data()

    assert set(address.__dict__.keys()) == {'locale', '_data'}
    assert address.__dict__['locale'] == 'en'
    assert set(data.keys()) == {'Address'}

# Generated at 2022-06-23 21:06:51.385744
# Unit test for method city of class Address
def test_Address_city():
    address_city_method = 'city'
    Address_obj = Address()
    obj_address_city = getattr(Address_obj, address_city_method)

    assert type(obj_address_city()).__name__ == 'str'
    assert obj_address_city() != ' ' and obj_address_city() is not None


# Generated at 2022-06-23 21:07:02.334164
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    for locale in ['en', ]:
        a = Address(locale)
        _postal_code_fmt = a._data['postal_code_fmt'].replace('-', ' ')
        _postal_code_fmt = _postal_code_fmt.replace('X', r'\d')
        _postal_code_fmt = _postal_code_fmt.replace('A', r'[A-Z]')
        _postal_code_fmt = _postal_code_fmt.replace('N', r'\d{2}')
        assert re.fullmatch(_postal_code_fmt, a.postal_code())[1:]

# Generated at 2022-06-23 21:07:07.212620
# Unit test for method country of class Address
def test_Address_country():
    """Unit test for method country of class Address."""
    current_locale = 'en'
    # Get current location and set it to current_locale
    # if you want to add your current location, just add your current location in address.json
    # in the place of 'current_locale'
    current_locale = 'current_locale'
    assert Address(locale=current_locale).country() == current_locale

# Generated at 2022-06-23 21:07:10.443950
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    print(address.state())
    print(address.region())
    print(address.province())
    print(address.federal_subject())
    print(address.prefecture())


# Generated at 2022-06-23 21:07:18.285577
# Unit test for method region of class Address

# Generated at 2022-06-23 21:07:22.398861
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test for method street_suffix of class Address."""
    data1 = Address(lang='zh-CN')
    print(data1.street_suffix())
    data2 = Address(lang='de')
    print(data2.street_suffix())


# Generated at 2022-06-23 21:07:24.848228
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    addr = Address('ru')
    assert addr.prefecture(abbr=True) in addr._data['state']['abbr']

# Generated at 2022-06-23 21:07:27.831407
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    obj = Address()
    obj.coordinates() == {'longitude': '-33º42\'28.428"E', 'latitude': '-66º55\'55.933"S'}
    print('passed')


# Generated at 2022-06-23 21:07:31.268993
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    adr = Address("en")
    print("adress is:",adr.country_code(fmt=CountryCode.A2))
    print("location is:",adr.coordinates())
if __name__ == "__main__":
    test_Address_coordinates()

# Generated at 2022-06-23 21:07:34.032661
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None
    assert address.locale is not None


# Generated at 2022-06-23 21:07:36.291804
# Unit test for method street_name of class Address
def test_Address_street_name():
    address_provider = Address()
    res = address_provider.street_name()
    print(res)



# Generated at 2022-06-23 21:07:41.848881
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed=111111)
    assert address.address() == '1250 Shannon Way'
    assert address.address(seed=123456) == '1220 Shoal Creek Way'
    assert address.address(seed=12345) == '1501 Ivy Meadow Ball'
    assert address.address(seed=123456) == '1196 Silverhorn Drive'
    assert address.address(seed=12345) == '1314 Rocky River Plaza'

# Generated at 2022-06-23 21:07:42.929477
# Unit test for method continent of class Address
def test_Address_continent():
    # Initialize an object Address object
    ad = Address()



# Generated at 2022-06-23 21:07:51.170028
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import Locale
    eng = Address(locale=Locale.ENGLISH)
    # Postal code for France
    assert eng.postal_code() == '06000'
    assert eng.zip_code() == '06000'

    # Postal code for the Netherlands
    dut = Address(locale=Locale.DUTCH)
    assert dut.postal_code() == '1234AA'
    assert dut.zip_code() == '1234AA'

    # Postal code for Russian Federation
    rus = Address(locale=Locale.RUSSIAN)
    assert rus.postal_code() == '101000'
    assert rus.zip_code() == '101000'

    # Postal code for Brazil

# Generated at 2022-06-23 21:07:55.315571
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address("en")
    print("Test Address.latitude(): \t\t",address.latitude())     # Test Address.latitude():          43.919280
    assert (address.latitude() >= -90 and address.latitude() <= 90)


# Generated at 2022-06-23 21:07:58.126480
# Unit test for method province of class Address
def test_Address_province():
    address = Address('es')
    assert address.province() == 'A Coruña'
    assert address.province() == 'Zamora'


# Generated at 2022-06-23 21:08:03.483977
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    assert Address().coordinates() == {
        'longitude': '1.986966º29\'11.864"E',
        'latitude': '16.713867º28\'52.715"S',
    }

    assert Address().coordinates(dms=False) == {
        'longitude': -134.726578,
        'latitude': -93.457484,
    }

# Generated at 2022-06-23 21:08:09.322174
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    print("test_Address_city:", a.city())
    print("test_Address_city:", a.city())
    print("test_Address_city:", a.city())

"""
The above code will output:
test_Address_city: Santuario
test_Address_city: San Juan del Río
test_Address_city: San Miguel del Milagro
"""

if __name__ == '__main__':
    test_Address_city()

# Generated at 2022-06-23 21:08:21.408647
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test longitude function of Address class."""
    from mimesis.events import Event
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.address import Address
    import re

    address = Address()
    lng = address.longitude()
    assert isinstance(lng, (int, float))
    assert lng >= -180 and lng <= 180

    lng = address.longitude(dms=True)
    assert isinstance(lng, str)
    assert re.match(
        r'^\d+º\d+\'\d+\.\d+"\w{1}$', lng)

    lng = address._dd_to_dms(0, 'lg')
    assert isinstance(lng, str)

# Generated at 2022-06-23 21:08:23.463093
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    zc = Address()
    print(zc.zip_code())
