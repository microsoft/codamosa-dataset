

# Generated at 2022-06-23 20:58:22.748872
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.providers.address.ru import RussianAddress

    print(RussianAddress().region())

# Generated at 2022-06-23 20:58:33.777402
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.builtins import Address

    a = Address()
    assert a.region() in a.province()
    assert a.region(abbr=True) in a.province(abbr=True)
    assert a.region(abbr=True) in a.state(abbr=True)
    assert a.region() in a.state()
    assert a.region() in a.prefecture()
    assert a.region() in a.federal_subject()
    assert len(a.region(abbr=True)) == 2
    assert len(a.region()) != 2



# Generated at 2022-06-23 20:58:35.983708
# Unit test for method continent of class Address
def test_Address_continent():
    addr = Address()
    code = addr.continent(True)
    assert code in CONTINENT_CODES
    name = addr.continent(False)
    assert name in addr._data['continent']


# Generated at 2022-06-23 20:58:48.520323
# Unit test for method state of class Address
def test_Address_state():
    """Testing Address.state() method.
    """
    from mimesis.enums import CountryCode
    a = Address('ru')
    assert a.state(abbr=True) in a._data['state']['abbr']
    assert a.state(abbr=False) in a._data['state']['name']
    a = Address('en')
    assert a.state() in a._data['state']['name']
    assert a.country_code(fmt=CountryCode.A2) in COUNTRY_CODES['A2']
    assert a.country_code(fmt=CountryCode.A3) in COUNTRY_CODES['A3']
    assert a.country_code(fmt=CountryCode.NUMERIC) in COUNTRY_CODES['NUMERIC']

# Generated at 2022-06-23 20:59:00.505876
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import CountryCode
    from mimesis.builtins import RussiaSpecProvider
    import re
    import pytest
    postal_code_rus_pat = re.compile(r'\d{6}')
    postal_code_pat = re.compile(r'\D{2}\d{5}')

    ru_address = Address(
        locale='ru_RU',
        spec=RussiaSpecProvider()
    )

    assert ru_address.postal_code() == '330000'
    assert postal_code_rus_pat.match(ru_address.postal_code())
    assert ru_address.postal_code(fmt='ru') == '330000'

    ar_address = Address(
        locale='ar_EG',
    )
    assert postal_code_pat.match

# Generated at 2022-06-23 20:59:02.282946
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    result = address.province()
    assert isinstance(result, str)

# Generated at 2022-06-23 20:59:09.815014
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Test for Address.street_number() method."""
    address_1 = Address()
    address_2 = Address()
    address_3 = Address()
    address_4 = Address()

    assert address_1.street_number() != address_2.street_number()
    assert address_1.street_number() != address_3.street_number()
    assert address_1.street_number() != address_4.street_number()
    assert address_2.street_number() != address_3.street_number()
    assert address_2.street_number() != address_4.street_number()
    assert address_3.street_number() != address_4.street_number()


# Generated at 2022-06-23 20:59:11.986610
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    my_address = Address.federal_subject()
    assert my_address in Address.state()


# Generated at 2022-06-23 20:59:13.469390
# Unit test for method city of class Address
def test_Address_city():
    """."""
    assert isinstance(Address().city(), str)


# Generated at 2022-06-23 20:59:23.519909
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address(locale='ru')

# Generated at 2022-06-23 20:59:26.237622
# Unit test for method latitude of class Address
def test_Address_latitude():
    # parameter 1: instance of class Address
    # parameter 2: argument dms (boolean)
    # paramter 3: expected output (expect float number between -90 and 90)
    test = Address()
    assert -90 <= float(test.latitude(False)) < 90


# Generated at 2022-06-23 20:59:38.216785
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    a = Address(locale='en')
    test1 = a.region(abbr=True)
    assert test1 in ['GA', 'NE', 'NW', 'SW']
    a.locale = 'es'
    test2 = a.region(abbr=False)
    assert test2 in ['Aguascalientes', 'Baja California', 'Baja California Sur', 'Campeche']
    a.locale = 'ar'
    test3 = a.region()
    assert test3 in ['حضرموت', 'بابل', 'بصره', 'بغداد']
    a.locale = 'tr'
    test4 = a.region()
    assert test

# Generated at 2022-06-23 20:59:40.861556
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    result = a.federal_subject()
    assert result != ''
    assert result is not None

# Generated at 2022-06-23 20:59:43.733124
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address_inst = Address("en")
    result = address_inst.calling_code()
    assert len(result) == 3
    assert isinstance(result, str)


# Generated at 2022-06-23 20:59:45.702720
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert isinstance(address, Address)
    assert address._datafile == 'address.json'
    assert isinstance(address._data, dict)

# test for _dd_to_dms in class Address

# Generated at 2022-06-23 20:59:48.711402
# Unit test for method latitude of class Address
def test_Address_latitude():
    addr = Address()
    x = addr.latitude()
    print(x)
    assert isinstance(x, float)

if __name__ == "__main__":
    test_Address_latitude()

# Generated at 2022-06-23 20:59:50.921357
# Unit test for method address of class Address
def test_Address_address():
    """Test Address.address() method."""
    from mimesis.enums import Locale

    random = Address(locale=Locale.EN)

# Generated at 2022-06-23 20:59:54.126701
# Unit test for method street_number of class Address
def test_Address_street_number():
    print("\n------- test_Address_street_number --------\n")
    current_locale = "en-US"
    address = Address(current_locale)
    print(address.street_number())


# Generated at 2022-06-23 20:59:55.958121
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    c = Address(seed=123)
    x = c.calling_code()
    assert x == '1'

# Generated at 2022-06-23 21:00:01.956214
# Unit test for method city of class Address
def test_Address_city():

    from mimesis.providers.address import Address
    from mimesis.enums import Language
    pr = Address(Language.EN)

    # Get a random city.
    assert pr.city() is not None


# Generated at 2022-06-23 21:00:03.860834
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    print(a.prefecture())
    # 山口県


# Generated at 2022-06-23 21:00:12.988790
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject() in ('Нидерланды', 'Москва', 'Томская область', 'Краснодарский край', 'Самарская область', 'Санкт-Петербург', 'Тверская область', 'Республика Башкортостан')


# Generated at 2022-06-23 21:00:13.645311
# Unit test for method longitude of class Address
def test_Address_longitude():
    pass

# Generated at 2022-06-23 21:00:14.973202
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    postal_code = Address(locale='en').postal_code()
    assert isinstance(postal_code, str)

# Generated at 2022-06-23 21:00:16.723235
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert isinstance(address, Address)

# Generated at 2022-06-23 21:00:23.097792
# Unit test for method country of class Address
def test_Address_country():
    locale = 'en'
    address_gen = Address(locale)
    result1 = address_gen.country(allow_random=False)
    assert result1 == 'United States'

    result2 = address_gen.country(allow_random=True)
    country_list = address_gen._data['country']['name']
    assert result2 in country_list

# Generated at 2022-06-23 21:00:25.752140
# Unit test for method province of class Address
def test_Address_province():
    address = Address(seed = 1)
    province = address.province()
    # Test type
    assert(isinstance(province, str))


# Generated at 2022-06-23 21:00:27.442367
# Unit test for method province of class Address
def test_Address_province():
    ad = Address()
    result = ad.province()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:00:29.524561
# Unit test for constructor of class Address
def test_Address():
    from mimesis.utils import is_valid_locale

    address = Address('en')
    assert is_valid_locale('en')
    assert address



# Generated at 2022-06-23 21:00:31.962160
# Unit test for method longitude of class Address
def test_Address_longitude():
    # GIVEN
    provider = Address('en')

    # WHEN
    result = provider.longitude()

    # THEN
    assert result is not None


# Generated at 2022-06-23 21:00:39.921191
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    class DummyAddress(Address):
        @staticmethod
        def _get_fs(key: str, dms: bool = False) -> Union[str, float]:
            assert key in ('lt', 'lg')
            return 'dummy'

    dummy_data = {
        'longitude': 'dummy',
        'latitude': 'dummy',
    }

    address = DummyAddress('ru')
    assert address.coordinates() == dummy_data
    assert address.coordinates(dms=True) == dummy_data

# Generated at 2022-06-23 21:00:45.096266
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test method coordinates of class Address.

    This method checks if the values stored in the variable `coordinates` are valid.
    """

    long = -100.0
    lat = 50.0

    address = Address()
    coordinates = address.coordinates()

    assert coordinates['latitude'] == lat
    assert coordinates['longitude'] == long

    return True


# Generated at 2022-06-23 21:00:50.592828
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """
    This method test for the methods postal_code and city in the class Address.
    """
    from mimesis.exceptions import NonEnumerableError

    address = Address()
    # should be a string
    postal_code1 = address.postal_code()

    assert isinstance(postal_code1, str)



# Generated at 2022-06-23 21:00:52.392482
# Unit test for method longitude of class Address
def test_Address_longitude():
    longitude = Address().longitude()
    assert -180 <= longitude <= 180


# Generated at 2022-06-23 21:00:55.702546
# Unit test for method address of class Address
def test_Address_address():
    # Test Address.address_data from EN locale
    assert Address('en').address().startswith('Address:\n')
    # Test Address.address_data from RU locale
    assert Address('ru').address().startswith('Адрес:\n')

# Generated at 2022-06-23 21:00:58.769010
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """test_Address_street_suffix."""
    # Basically for testing
    a = Address()
    print(a._data)
    st = a.street_suffix()
    print("street suffix = ", st)
    pass


# Generated at 2022-06-23 21:01:04.693773
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address.

    :return: None.
    """
    c = Address()
    region_1 = c.region()
    region_2 = c.region(abbr=True)
    assert isinstance(region_1, str)
    assert isinstance(region_2, str)
    assert len(region_1) > 0
    assert len(region_2) > 0

    if c.locale != 'ru':
        for i in range(0, 100):
            region = c.region()
            assert region in c._data['state']['name']

    for i in range(0, 100):
        region = c.region(abbr=True)
        assert region in c._data['state']['abbr']



# Generated at 2022-06-23 21:01:07.916622
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continent

    address = Address()
    print(address.continent())
    print(address.continent(code=True))
    print(address.continent(code=Continent.CODE))


# Generated at 2022-06-23 21:01:09.834256
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    zip_code = address.zip_code()
    print(zip_code)
#output
# '785000'
# '956781'


# Generated at 2022-06-23 21:01:20.598995
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # 1. Create an object, by default called 'en'
    a = Address()

    # 2. Check that the object is Address class
    assert isinstance(a, Address), 'Object is not Address'

    # 3. Check that the object has method calling_code
    assert callable(a.calling_code), 'Method calling_code is not callable'

    # 3. Test calling_code
    # 3.1 Test returned value
    assert isinstance(a.calling_code(), str), 'Returned value is not str'

    # 3.2 Test that the returned value is a valid calling code
    assert a.calling_code() in CALLING_CODES



# Generated at 2022-06-23 21:01:23.355270
# Unit test for method prefecture of class Address
def test_Address_prefecture():
  adr = Address(locale='ja')
  a = adr.prefecture()
  print(a)

# Address
if __name__ == "__main__":
  test_Address_prefecture()

# Generated at 2022-06-23 21:01:25.814636
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for region."""
    address = Address()
    address.region()


# Generated at 2022-06-23 21:01:28.567069
# Unit test for method state of class Address
def test_Address_state():
    """Test method state of class Address."""
    adr = Address('en')
    assert type(adr.state()) is str
    assert type(adr.state(abbr=True)) is str


# Generated at 2022-06-23 21:01:31.026897
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    result = address.region(abbr=True)
    assert result in address._data['state']['abbr']


# Generated at 2022-06-23 21:01:34.724627
# Unit test for method coordinates of class Address
def test_Address_coordinates():

    addr_instance = Address(locale='en')
    coordinates = addr_instance.coordinates()
    lat = coordinates['latitude']
    lg = coordinates['longitude']

    assert -90 <= lat <= 90
    assert -180 <= lg <= 180


# Generated at 2022-06-23 21:01:40.895449
# Unit test for method city of class Address
def test_Address_city():
    address = Address('en')

# Generated at 2022-06-23 21:01:44.720934
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Unit test for method postal_code of class Address."""
    addr = Address()
    assert isinstance(addr.postal_code(), str)



# Generated at 2022-06-23 21:01:46.939014
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    address.street_number()
    assert address.street_number() in range(1, 1401)



# Generated at 2022-06-23 21:01:49.379758
# Unit test for constructor of class Address
def test_Address():
    """Testing constructor of class Address."""
    a = Address()
    assert isinstance(a, Address)

# Unit tests for Address.state

# Generated at 2022-06-23 21:01:58.286777
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import CountryCode
    from mimesis.enums import Language
    a = Address(Language.UKRAINIAN)
    assert isinstance(a.address(), str)
    assert isinstance(a.city(), str)
    assert isinstance(a.state(), str)
    assert isinstance(a.region(), str)
    assert isinstance(a.province(), str)
    assert isinstance(a.federal_subject(), str)
    assert isinstance(a.prefecture(), str)
    assert isinstance(a.calling_code(), str)
    assert isinstance(a.continent(), str)
    assert isinstance(a.continent(code=True), str)
    assert isinstance(a.country(), str)
    assert isinstance(a.country_code(), str)
    assert isinstance

# Generated at 2022-06-23 21:02:00.647828
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    c = Address()
    post_code = c.postal_code()
    if not isinstance(post_code, str):
        print('type error: return type should be str')


# Generated at 2022-06-23 21:02:01.748656
# Unit test for method street_number of class Address
def test_Address_street_number():
    addr = Address()
    assert isinstance(addr.street_number(), str)

# Generated at 2022-06-23 21:02:03.035568
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    add = Address()
    assert add.federal_subject(abbr=True) == 'NH'

# Generated at 2022-06-23 21:02:06.023836
# Unit test for method address of class Address
def test_Address_address():

    a = Address(locale='en')
    assert a.address() == '65-7826 8th St.'
    assert a.address() != '5-7826 8th St.'


# Generated at 2022-06-23 21:02:10.093244
# Unit test for method province of class Address
def test_Address_province():
    """Unit test for method province of class Address."""
    addr = Address('zh')
    province = addr.province()
    assert province in addr._data['state']['name']



# Generated at 2022-06-23 21:02:15.258358
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address(locale='es')
    assert isinstance(a.postal_code(), str)
    assert len(a.postal_code()) == 5
    assert isinstance(a.zip_code(), str)
    assert len(a.zip_code()) == 5


# Generated at 2022-06-23 21:02:24.982370
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test method coordinates."""
    address = Address('en')
    coordinates = address.coordinates()
    assert isinstance(coordinates, dict)
    assert 'latitude' in coordinates
    assert 'longitude' in coordinates
    assert isinstance(coordinates.get('latitude'), float)
    assert isinstance(coordinates.get('longitude'), float)
    assert coordinates.get('latitude') <= 90
    assert coordinates.get('longitude') <= 180
    coordinates = address.coordinates(dms=True)
    assert isinstance(coordinates.get('longitude'), str)
    assert isinstance(coordinates.get('latitude'), str)
    match = re.search(r'^(\d+)[º|\'|\`](\d+)[`\'|\"]', coordinates.get('longitude'))
    assert match

# Generated at 2022-06-23 21:02:27.386264
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # Call the method with no params
    assert isinstance(Address().street_suffix(), str)


# Generated at 2022-06-23 21:02:32.169483
# Unit test for method city of class Address
def test_Address_city():
    # Method city of class Address returns value
    # 'Cordoba' of current locale 'es'.
    assert Address('es').city() == 'Cordoba'
    assert Address('es', random_locale=True).city()

# Generated at 2022-06-23 21:02:33.155734
# Unit test for method longitude of class Address
def test_Address_longitude():

    a = Address()
    assert a.longitude() == -172.8760


# Generated at 2022-06-23 21:02:35.693169
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from pprint import pprint
    from random import randint

    for _ in range(10):
        address = Address(randint(1, 100))
        assert address.calling_code()

# Generated at 2022-06-23 21:02:39.160685
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for address method of Address class."""
    address = Address(locale='en')
    result = address.address()
    assert result is not None
    assert isinstance(result, str)
    assert len(result) > 0

# Generated at 2022-06-23 21:02:40.326731
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    coordinates = address.coordinates()
    assert coordinates == {
        'longitude': address.longitude(),
        'latitude': address.latitude(),
    }

# Generated at 2022-06-23 21:02:41.995099
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    result = address.country()
    assert result == 'Japan'


# Generated at 2022-06-23 21:02:44.601132
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    # Assert that returned value is string type
    assert isinstance(a.zip_code(), str)


# Generated at 2022-06-23 21:02:54.760961
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a.state(abbr= True) in a._data['state']['abbr']
    assert a.region(abbr= True) in a._data['state']['abbr']
    assert a.federal_subject(abbr= True) in a._data['state']['abbr']
    assert a.prefecture(abbr= True) in a._data['state']['abbr']
    assert a.province(abbr= True) in a._data['state']['abbr']

    assert a.state() in a._data['state']['name']
    assert a.region() in a._data['state']['name']
    assert a.federal_subject() in a._data['state']['name']
    assert a.prefecture() in a._data

# Generated at 2022-06-23 21:02:55.893101
# Unit test for method city of class Address
def test_Address_city():
    ad = Address()
    ad.city()

# Generated at 2022-06-23 21:02:57.734785
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    adr = Address(locale='ja')
    print(adr.prefecture())

if __name__ == '__main__':
    test_Address_prefecture()

# Generated at 2022-06-23 21:03:07.348123
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.builtins import address
    a = address.Address(locale='en')
    result = a.coordinates()
    assert isinstance(result, dict)
    assert 'latitude' in result
    assert 'longitude' in result
    assert isinstance(result['latitude'], float)
    assert isinstance(result['longitude'], float)

    result = a.coordinates(dms=True)
    assert isinstance(result, dict)
    assert 'latitude' in result
    assert 'longitude' in result
    assert isinstance(result['latitude'], str)
    assert isinstance(result['longitude'], str)

# Generated at 2022-06-23 21:03:17.321177
# Unit test for method country_code of class Address

# Generated at 2022-06-23 21:03:19.649442
# Unit test for method province of class Address
def test_Address_province():
    a = Address('en')
    assert a.province() == a.state()



# Generated at 2022-06-23 21:03:20.599710
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    print(a.zip_code())


# Generated at 2022-06-23 21:03:22.572014
# Unit test for method city of class Address
def test_Address_city():
    test = Address("en")
    assert test.city() in test._data['city']

# Generated at 2022-06-23 21:03:24.662354
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    # print(a.country())
    return a.country() == 'Bahrain'

# Generated at 2022-06-23 21:03:26.592049
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address(seed=12345)
    assert a.zip_code() == a.postal_code()


# Generated at 2022-06-23 21:03:27.893231
# Unit test for constructor of class Address
def test_Address():
    _address = Address()
    assert _address is not None



# Generated at 2022-06-23 21:03:29.157764
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert "ave" in Address().street_suffix().lower()

# Generated at 2022-06-23 21:03:30.668176
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state() in address._data['state']['name']


# Generated at 2022-06-23 21:03:32.173039
# Unit test for method address of class Address
def test_Address_address():
    addr = Address('en')
    assert isinstance(addr.address(), str)


# Generated at 2022-06-23 21:03:34.390213
# Unit test for method region of class Address
def test_Address_region():
    """Test whether function Address.region() is working properly.
    """

    addr = Address()
    for _ in range(10):
        assert addr.region() in addr._data['state']['name']


# Generated at 2022-06-23 21:03:37.630651
# Unit test for method longitude of class Address
def test_Address_longitude():
    try:
        for i in range(25):
            print(Address().longitude())

    except Exception as e:
        print(e)


# Generated at 2022-06-23 21:03:38.352855
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    print(address.street_name())


# Generated at 2022-06-23 21:03:45.483391
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.enums import Language
    from mimesis.providers.address import Address
    address = Address(Language.RUSSIAN)
    addr = Address(Language.ENGLISH, region=CountryCode.UK)
    assert type(address.longitude(dms=True)) == str
    assert type(addr.longitude(dms=True)) == str

# Generated at 2022-06-23 21:03:55.803074
# Unit test for method country of class Address

# Generated at 2022-06-23 21:03:59.350250
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """"""
    seed=1
    address=Address()
    postal_code=address.postal_code()
    assert postal_code == '50300'

# Generated at 2022-06-23 21:04:02.153777
# Unit test for method continent of class Address
def test_Address_continent():
    # Get a random continent name
    assert Address(_seed=0).continent() == 'Africa'

    # Get a random continent code
    assert Address(_seed=0).continent(code=True) == 'AF'

# Generated at 2022-06-23 21:04:09.954930
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    address = Address(Locale.EN.value)
    assert address.address() == '{st_num} {st_name} {st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix()
    )

if __name__ == '__main__':
    test_Address_address()

# Generated at 2022-06-23 21:04:12.206430
# Unit test for method city of class Address
def test_Address_city():
    address = Address(locale='en')
    print(address.city())


# Generated at 2022-06-23 21:04:16.315580
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() in [
        'AB', 'BC', 'MB', 'NB', 'NL', 'NS', 'NT', 'NU', 'ON', 'PE', 'QC', 'SK', 'YT']


# Generated at 2022-06-23 21:04:20.575750
# Unit test for method latitude of class Address
def test_Address_latitude():
    i = {"latitude": 48.866360, "longitude": 2.373250}
    test_object = Address()
    test_result = test_object.latitude()
    assert isinstance(test_result, float)
    assert test_result == i["latitude"]

# Generated at 2022-06-23 21:04:22.678434
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a.__class__.__name__ == "Address"

# Generated at 2022-06-23 21:04:26.544755
# Unit test for method province of class Address
def test_Address_province():
    import pprint
    pp = pprint.PrettyPrinter(indent=4)
    res = Address(locale='ru').province()
    print(res)
    pp.pprint(res)


# Generated at 2022-06-23 21:04:28.096358
# Unit test for method city of class Address
def test_Address_city():
	address = Address()
	print(address.city())
    


# Generated at 2022-06-23 21:04:31.251379
# Unit test for method continent of class Address
def test_Address_continent():
    try:
        tmp = Address()
        print ("Address().continent() ---------> " + tmp.continent())
    except Exception as e:
        print (e)
        assert False


# Generated at 2022-06-23 21:04:43.077892
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test method coordinates of class Address()."""
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    ad = Address('zh')
    longitude_data = [ad.longitude() for i in range(10)]
    latitude_data = [ad.latitude() for i in range(10)]
    coordinates_data = [ad.coordinates() for i in range(10)]
    longitude_dms_data = [ad.longitude(dms=True) for i in range(10)]
    latitude_dms_data = [ad.latitude(dms=True) for i in range(10)]
    coordinates_dms_data = [ad.coordinates(dms=True) for i in range(10)]
    assert isinstance(longitude_data[0], float)

# Generated at 2022-06-23 21:04:45.342445
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    for i in range(0,10):
        print(a.street_suffix())


# Generated at 2022-06-23 21:04:51.145721
# Unit test for method province of class Address
def test_Address_province():
    address = Address('en')
    # use english language
    assert address.province() in address._data['state']['name']
    assert address.region() in address._data['state']['name']
    assert address.prefecture() in address._data['state']['name']
    assert address.federal_subject() in address._data['state']['name']

# Generated at 2022-06-23 21:04:52.588612
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address != ""
    print(address.address())

# Generated at 2022-06-23 21:04:54.243260
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code() in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-23 21:04:58.614774
# Unit test for method latitude of class Address
def test_Address_latitude():
    print("\nUnit test for method latitude of class Address")
    print("*"*100)
    addr=Address('ru')
    print("Latitude value is : {}".format(addr.latitude()))
    print("*"*100)


# Generated at 2022-06-23 21:05:01.028620
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address()
    assert len(addr.street_suffix()) != 0


# Generated at 2022-06-23 21:05:01.435443
# Unit test for method state of class Address
def test_Address_state():
    pass

# Generated at 2022-06-23 21:05:04.900284
# Unit test for method country of class Address
def test_Address_country():
    """Test for method country"""
    address = Address()

    assert address.country() == 'Argentina'
    assert address.country() == address.country()
    assert address.country(allow_random=True) != address.country(allow_random=True)


# Generated at 2022-06-23 21:05:06.618848
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    assert address.continent(False) == "America"
    assert address.continent(True) == "NA"


# Generated at 2022-06-23 21:05:09.430227
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    coordinates = address.coordinates(dms=True)
    lg = coordinates['longitude']
    lt = coordinates['latitude']
    assert len(lg) >= 6 and len(lt) >= 6
    print(lg, lt)
    assert len(address.coordinates()) >= 6

# Generated at 2022-06-23 21:05:12.521709
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import Country
    provider = Address(Country.UNITED_KINGDOM)
    assert len(provider.street_number()) >= 1


# Generated at 2022-06-23 21:05:16.787296
# Unit test for method country_code of class Address
def test_Address_country_code():
    print("Testing Address class country_code method")
    assert Address().country_code(CountryCode.A2) == 'US'
    assert Address().country_code(CountryCode.A3) == 'USA'
    assert Address().country_code(CountryCode.NUM) == '840'


# Generated at 2022-06-23 21:05:19.815847
# Unit test for method street_name of class Address
def test_Address_street_name():
    obj = Address()
    street_name = obj.street_name
    assert type(street_name) is str
    assert len(street_name) > 0


# Generated at 2022-06-23 21:05:21.973755
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    res = address.street_suffix()
    assert res in address._data['street']['suffix']



# Generated at 2022-06-23 21:05:24.017094
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr = Address(seed=12345)
    zipcode = addr.zip_code()

    assert zipcode == "384800"


# Generated at 2022-06-23 21:05:25.445391
# Unit test for method state of class Address
def test_Address_state():
    provider = Address(locale='en')
    assert provider.state() != None


# Generated at 2022-06-23 21:05:35.773275
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    print("Test method prefecture of class Address")
    test = Address("ja")
    #get a random prefecture
    region = test.prefecture()
    #get a random prefecture
    state = test.state()
    # get a random prefecture
    province = test.province()
    # get a random prefecture
    federal_subject = test.federal_subject()
    # get a random prefecture
    region1 = test.region()
    print("random prefecture: " + str(region))
    print("random state: " + str(state))
    print("random province: " + str(province))
    print("random federal subject: " + str(federal_subject))
    print("random region: " + str(region1))


# Generated at 2022-06-23 21:05:37.938551
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('zh')
    assert len(address.prefecture()) > 0


# Generated at 2022-06-23 21:05:44.275113
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Gender

    a = Address('en')
    st_number = a.street_number()
    assert st_number
    assert st_number.isdigit()
    assert int(st_number) < 1400

    try:
        a = Address('en')
        st_number = a.street_number(maximum=Gender.MALE)
        assert False
    except NonEnumerableError:
        assert True

    try:
        a = Address('en')
        st_number = a.street_number(maximum=100)
        assert False
    except NonEnumerableError:
        assert True


# Generated at 2022-06-23 21:05:46.934733
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    print()
    print('------Get a random region------')
    print('region = {}'.format(Address.federal_subject()))

if __name__ == '__main__':
    test_Address_federal_subject()

# Generated at 2022-06-23 21:05:47.794355
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    ltt = address.latitude()
    assert 0 <= ltt <= 90


# Generated at 2022-06-23 21:05:49.253708
# Unit test for method state of class Address
def test_Address_state():
    ad = Address()
    assert isinstance(ad.state(), str)



# Generated at 2022-06-23 21:05:56.967211
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    address = Address()
    longitude = address.longitude()
    assert (longitude >= -180) and (longitude <= 180)
    longitude = address.longitude(dms=True)
    assert isinstance(longitude, str)
    longitude = address.longitude()
    assert (longitude >= -180) and (longitude <= 180)
    longitude = address.longitude(dms=True)
    assert isinstance(longitude, str)
    longitude = address.longitude()
    assert (longitude >= -180) and (longitude <= 180)
    longitude = address.longitude(dms=True)
    assert isinstance(longitude, str)
    longitude = address.longitude()

# Generated at 2022-06-23 21:05:58.846398
# Unit test for method city of class Address
def test_Address_city():
    ad = Address('ru')
    for i in range(0, 10):
        assert ad.city()


# Generated at 2022-06-23 21:06:03.788574
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('en')
    assert address.street_suffix() \
    in ['ave', 'blvd', 'cir', 'ct', 'dr', 'hwy', 'pkwy', 'pl', 'rd', 'st']



# Generated at 2022-06-23 21:06:07.349974
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Country

    a = Address(Country.SWEDEN)
    assert a.country() == "Sweden"

# Generated at 2022-06-23 21:06:10.999307
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    b = a.province()
    c = a.province(abbr=True)
    d = a.federal_subject()
    e = a.region()

    print(b)
    print(c)
    print(d)
    print(e)


# Generated at 2022-06-23 21:06:13.971690
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address('zh')
    house_number = address.street_number()
    re_number = r'\d{1,4}'
    assert re.match(re_number,house_number)



# Generated at 2022-06-23 21:06:17.360590
# Unit test for method state of class Address
def test_Address_state():
    # Test for method state of class Address
    a = Address()
    assert a.state() in a._data['state']['name']
    assert a.state(abbr=True) in a._data['state']['abbr']

# Generated at 2022-06-23 21:06:20.566293
# Unit test for method street_name of class Address
def test_Address_street_name():
   """
   A test method for unit testing of street name
   """
   result = Address().street_name()
   assert (type(result) == str)
   assert (result != '')


# Generated at 2022-06-23 21:06:22.894528
# Unit test for method province of class Address
def test_Address_province():
    assert type(Address.province(Address())) == str


# Generated at 2022-06-23 21:06:23.997778
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix()

# Generated at 2022-06-23 21:06:26.143569
# Unit test for method region of class Address
def test_Address_region():
    """Test region method."""
    address = Address('en')
    region_of_country = address.region()

    assert region_of_country != ''


# Generated at 2022-06-23 21:06:27.526166
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    assert len(a.postal_code()) > 0
    

# Generated at 2022-06-23 21:06:28.228023
# Unit test for constructor of class Address
def test_Address():
    pass


# Generated at 2022-06-23 21:06:29.260819
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject()


# Generated at 2022-06-23 21:06:32.007895
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    #assert len(a.federal_subject()) == 2
    print(a.federal_subject())


# Generated at 2022-06-23 21:06:34.443709
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    state = address.state()
    if state == None:
        return False
    else:
        return True


# Generated at 2022-06-23 21:06:36.125766
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for i in range(1, 100):
        print(address.address())


# Generated at 2022-06-23 21:06:39.226538
# Unit test for method longitude of class Address
def test_Address_longitude():
	# Test 1
	address = Address('en')
	print(address.longitude())

	# Test 2
	print(address.longitude(dms=True))


# Generated at 2022-06-23 21:06:40.222868
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert isinstance(address.region(), str)
    assert len(address.region()) > 0


# Generated at 2022-06-23 21:06:43.939176
# Unit test for method state of class Address
def test_Address_state():
    address = Address('en')
    res = address.state(abbr=False)
    # print("country = {}".format(country))
    assert len(res)>0



# Generated at 2022-06-23 21:06:45.957567
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address('en')
    zip_code = address.zip_code()
    print(zip_code)
    assert len(zip_code) == 5

# Generated at 2022-06-23 21:06:47.732332
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('en')
    assert address.federal_subject() in \
        ['Centre', 'North-West', 'South', 'Volga']

# Generated at 2022-06-23 21:06:51.302026
# Unit test for method province of class Address
def test_Address_province():
    """Unit test for method province of class Address."""
    addr = Address('ru')
    res = addr.province()
    assert type(res) == str


# Generated at 2022-06-23 21:06:52.654152
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() is not None

# Generated at 2022-06-23 21:06:55.987372
# Unit test for method address of class Address
def test_Address_address():
    # Create an object Address
    objAddress = Address()
    result = objAddress.address()

    assert result is not None, "The address can not be None"

# Generated at 2022-06-23 21:06:59.122315
# Unit test for method latitude of class Address
def test_Address_latitude():
    addr = Address()
    for _ in range(10):
        assert addr.latitude() >= -90.0 and addr.latitude() <= 90.0


# Generated at 2022-06-23 21:07:02.474439
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address(seed=12345)
    # method street_number()
    assert address.street_number() == '1362'
    # method street_number(maximum=99)
    assert address.street_number(maximum=99) == '77'


# Generated at 2022-06-23 21:07:05.916982
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    ad = Address()
    # 根据参数获取日本省份
    ad.prefecture()
    # 获取日本省份
    ad.prefecture(ad)

# Generated at 2022-06-23 21:07:08.168248
# Unit test for method country_code of class Address
def test_Address_country_code():
    country_code = Address(locale='en').country_code()
    assert isinstance(country_code, str)
    assert country_code.isalpha()
    assert len(country_code) == 2


# Unit tests for method country of class Address

# Generated at 2022-06-23 21:07:11.357720
# Unit test for method country_code of class Address
def test_Address_country_code():
    addr = Address()
    assert addr.country_code() == 'US'
    assert addr.country_code(fmt=CountryCode.A3) == 'USA'
    assert addr.country_code(fmt=CountryCode.NUM) == '840'

# Generated at 2022-06-23 21:07:12.636199
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert len(address.federal_subject()) == 2

# Generated at 2022-06-23 21:07:14.274871
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert address.street_number() != address.street_number()


# Generated at 2022-06-23 21:07:18.292807
# Unit test for method street_name of class Address
def test_Address_street_name():
    address_name = Address()
    for i in range(10):
        assert_true(len(address_name.street_name())>0)


# Generated at 2022-06-23 21:07:18.946191
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    print(address.country_code())


# Generated at 2022-06-23 21:07:24.152864
# Unit test for method address of class Address
def test_Address_address():

    # Locale setting
    locale = "vi_VN"

    # Instantiation
    address = Address(provider=locale)


    # Call method
    result = address.address()


    # Check
    assert isinstance(result, str)
    assert result.isalpha()
    assert result.isalnum()


# Generated at 2022-06-23 21:07:26.343767
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    result = address.prefecture()
    assert result in address._data['state']['name']


# Generated at 2022-06-23 21:07:29.258325
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    print(address.country())
    print(address.country(allow_random = True))


# Generated at 2022-06-23 21:07:30.861912
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address().zip_code() is not None


# Generated at 2022-06-23 21:07:32.655005
# Unit test for method province of class Address
def test_Address_province():
    assert len(Address().province()) <= 2

# Generated at 2022-06-23 21:07:37.894229
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    r_1 = a.federal_subject(abbr=False)
    r_2 = a.federal_subject(abbr=True)
    a_1 = a._data['state']['abbr']
    a_2 = a._data['state']['name']
    assert r_1 in a_2
    assert r_2 in a_1

# Generated at 2022-06-23 21:07:45.539200
# Unit test for method address of class Address
def test_Address_address():
    address = Address()

    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'
    assert address.address() == '{st_num} {st_name} {st_sfx}'

# Generated at 2022-06-23 21:07:47.296513
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address('en')
    result = address.coordinates()
    print(result)

if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-23 21:07:52.201591
# Unit test for method street_name of class Address
def test_Address_street_name():
	  # Create object address
	  address = Address()
	  # Get street name
	  res = address.street_name()
	  # Street name from default format
	  def_name = '{number} {street}'
	  # Get format of street name for current locale
	  fmt = address._data['address_fmt']
	  # Get street name from current locale with default format
	  res = address.format(def_name, number=address.street_number(), street=res)
	  # Check if street name from default format is the same as one from format of current locale
	  assert res.strip() == address.format(fmt).strip()


# Generated at 2022-06-23 21:07:54.319987
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    result = address.street_name()
    print(result)


# Generated at 2022-06-23 21:07:59.295286
# Unit test for method region of class Address
def test_Address_region():
    """Test Address class.

    The unit test for method region() of class Address.
    The method returns a random administrative district of country.
    """
    a = Address()
    assert a.region() in a._data['state']['name']
    assert a.region(True) in a._data['state']['abbr']

# Generated at 2022-06-23 21:08:02.041579
# Unit test for method latitude of class Address
def test_Address_latitude():
    latitude = Address('en').latitude()
    assert type(latitude) is float
    assert latitude <= 90.0
    assert latitude >= -90.0



# Generated at 2022-06-23 21:08:05.691302
# Unit test for method city of class Address
def test_Address_city():
    addr = Address()
    c1 = addr.city()
    c2 = addr.city()
    assert c1 != c2
    assert isinstance(c1, str)
    assert isinstance(c2, str)



# Generated at 2022-06-23 21:08:06.471989
# Unit test for method address of class Address
def test_Address_address():
    a1=Address()
    a1.address()

# Generated at 2022-06-23 21:08:12.462826
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address(locale='en')

    assert isinstance(address.coordinates(), dict)
    assert isinstance(address.coordinates(True), dict)
    assert isinstance(address.coordinates(False), dict)

    c = address.coordinates()

    assert isinstance(c['longitude'], float)
    assert isinstance(c['latitude'], float)

    assert isinstance(address.coordinates(True)['longitude'], str)
    assert isinstance(address.coordinates(True)['latitude'], str)

    assert isinstance(address.coordinates(False)['longitude'], float)
    assert isinstance(address.coordinates(False)['latitude'], float)



# Generated at 2022-06-23 21:08:22.738482
# Unit test for method country_code of class Address
def test_Address_country_code():
    print("\nAddress.country_code")

    a = Address()
    print(a.country_code())
    print(a.country_code(CountryCode.A3))
    print(a.country_code(CountryCode.NUMERIC))
    print(a.country_code(CountryCode.OFFICIAL_NAME))
    print(a.country_code(CountryCode.OFFICIAL_NAME_FR))
    print(a.country_code(CountryCode.OFFICIAL_NAME_ES))
    print(a.country_code(CountryCode.OFFICIAL_NAME_ZH))

    # Raises KeyError
    # print(a.country_code(CountryCode.OFFICIAL_NAME_RU))


if __name__ == "__main__":
    test_Address_country_code()