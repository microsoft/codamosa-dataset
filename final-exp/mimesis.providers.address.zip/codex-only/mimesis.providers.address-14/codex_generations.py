

# Generated at 2022-06-23 20:58:28.506285
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    a = Address()
    assert len(a.latitude()) == len(a.latitude(dms=True))
    assert len(a.latitude()) == len(a.latitude(dms=False))
    assert a.latitude(dms=True)
    assert a.latitude(dms=False)
    assert len(a.latitude(dms=True)) == len(a.latitude(dms=True))
    assert len(a.latitude(dms=True)) == len(a.latitude(dms=False))
    assert not (a.latitude(dms=True) == a.latitude(dms=False))
    assert not (a.latitude(dms=True) == a.latitude(dms=True))
   

# Generated at 2022-06-23 20:58:29.592993
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province()

# Generated at 2022-06-23 20:58:35.768034
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode

    address = Address()
    assert address.latitude() in range(0, 90)

    address = Address()
    assert address.latitude(dms=True)

    address = Address('pt')
    assert address.country_code() == 'BR'

    address = Address('pt')
    assert address.country_code(CountryCode.A2) == 'BR'

    address = Address('pt')
    assert address.country_code(CountryCode.A3) == 'BRA'

    address = Address('pt')
    assert address.country_code(CountryCode.NUMERIC) == '076'

    address = Address('pt')
    assert address.country_code(fmt='A2') == 'BR'

    address = Address('pt')
    assert address.country_code

# Generated at 2022-06-23 20:58:38.045662
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    name = a.country_code(CountryCode.A2)
    assert name in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-23 20:58:49.954033
# Unit test for method city of class Address
def test_Address_city():
    addr = Address()
    assert isinstance(addr.city(), str)


# Generated at 2022-06-23 20:58:51.186045
# Unit test for method latitude of class Address
def test_Address_latitude():
  pass


# Generated at 2022-06-23 20:58:54.728600
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    provider = Address('zh')
    if provider.prefecture() not in provider._data['state']['name']:
        assert False
    else:
        assert True


# Generated at 2022-06-23 20:58:59.165440
# Unit test for method city of class Address
def test_Address_city():
    '''
    GIVEN a initialized method
    WHEN a city is generated
    THEN check if the city is in the city set.
    '''
    addr = Address('zh')
    random_city = addr.city()
    assert random_city in addr._data['city']


# Generated at 2022-06-23 20:59:01.614278
# Unit test for method state of class Address
def test_Address_state():
    test_address = Address(locale='en')
    assert test_address.state(abbr=True) in test_address._data['state']['abbr']


# Generated at 2022-06-23 20:59:06.094816
# Unit test for method state of class Address
def test_Address_state():
    locale = 'en'
    provider = Address(locale=locale)
    assert provider.state() in provider._data['state']['name']
    assert provider.state(abbr=True) in provider._data['state']['abbr']

# Generated at 2022-06-23 20:59:13.822609
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from pprint import pprint
    from itertools import islice
    from .helpers.functions import Iterator
    import mimesis
    coodinates = []
    total_results = 0

    while total_results < 100:
        n = mimesis.Address()
        coodinates.append(n.coordinates(dms=True))
        total_results += 1
    pprint(coodinates)
    print(len(coodinates))



# Generated at 2022-06-23 20:59:17.346359
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    import unittest
    address = Address()
    for i in range(100):
        code = address.calling_code()
        assert code in CALLING_CODES
        for key, value in CountryCode.__members__.items():
            assert code != address.country_code(value)

# Generated at 2022-06-23 20:59:21.498961
# Unit test for method city of class Address
def test_Address_city():
    provider = Address('en')
    city = provider.city()
    provin = provider.province()
    stat = provider.state()
    country = provider.country()
    assert city != provin
    assert city != stat
    assert stat != provin
    assert country

# Generated at 2022-06-23 20:59:23.195197
# Unit test for method region of class Address
def test_Address_region():
    region = Address().region()
    assert region in Address._data['state']['name']


# Generated at 2022-06-23 20:59:27.478356
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('en')
    us_code = address.postal_code()
    assert len(us_code) == 5
    assert isinstance(us_code, str)

    address = Address('ru')
    ru_code = address.postal_code()
    assert len(ru_code) == 6
    assert isinstance(ru_code, str)



# Generated at 2022-06-23 20:59:28.880586
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    pass

# Generated at 2022-06-23 20:59:35.113897
# Unit test for method postal_code of class Address
def test_Address_postal_code():

    n = 2

    for i in range(0, n):
        postal_code = Address().postal_code()
        print(postal_code)

        if (type(postal_code) != str):
            print ("test_Address_postal_code: TypeError")
            return "test_Address_postal_code: TypeError"

    return "success"


# Generated at 2022-06-23 20:59:36.141371
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject()



# Generated at 2022-06-23 20:59:39.012123
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    val = Address().calling_code()
    print(val)

if __name__ == '__main__':
    test_Address_calling_code()

# Generated at 2022-06-23 20:59:44.782254
# Unit test for method continent of class Address
def test_Address_continent():
    # First test case
    # Code is not set
    addr = Address(seed=123)
    assert addr.continent() == 'Австралия'
    # Second test case
    # Code is set
    addr2 = Address(seed=123)
    assert addr2.continent(code=True) == 'OC'



# Generated at 2022-06-23 20:59:46.513498
# Unit test for method country of class Address
def test_Address_country():
    # Create Address object
    a = Address('zh')
    print(a.country())



# Generated at 2022-06-23 20:59:52.392393
# Unit test for method continent of class Address
def test_Address_continent():
    """Test method continent."""
    address = Address(locale='en')
    assert address.continent() == 'Africa'
    assert address.continent() == 'Antarctica'
    assert address.continent() == 'Antarctica'
    assert address.continent() == 'Asia'
    assert address.continent() == 'Europe'
    assert address.continent() == 'North America'
    assert address.continent() == 'North America'
    assert address.continent() == 'South America'
    assert address.continent() == 'South America'
    assert address.continent() == 'South America'
    assert address.continent() == 'Oceania'
    assert address.continent() == 'Oceania'
    assert address.continent() == 'Oceania'


# Generated at 2022-06-23 20:59:54.126310
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    data = ['Moscow', 'Saint Petersburg']
    assert (address.federal_subject() in data)

# Generated at 2022-06-23 20:59:56.889284
# Unit test for method calling_code of class Address
def test_Address_calling_code():
   address = Address()
   calling_codes = [address.calling_code() for i in range(0, 50)]
   for code in calling_codes:
       assert code.isdigit()


# Generated at 2022-06-23 21:00:01.795026
# Unit test for constructor of class Address
def test_Address():
    assert Address(seed=42).calling_code() == '227'
    assert Address(seed=42).continent() == 'Africa'
    assert Address(seed=42).continent(True) == 'AF'

# Generated at 2022-06-23 21:00:02.848782
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address().zip_code() == '71557'

# Generated at 2022-06-23 21:00:04.022400
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    for _ in range(0, 100):
        assert isinstance(address.longitude(), float)

# Generated at 2022-06-23 21:00:06.144268
# Unit test for method state of class Address
def test_Address_state():
    address = Address('en')
    state = address.state()
    assert not state.isspace()
    assert state


# Generated at 2022-06-23 21:00:07.732873
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test longitude.
    """
    a = Address()

    assert isinstance(a.longitude(), float)


# Generated at 2022-06-23 21:00:11.752596
# Unit test for method address of class Address
def test_Address_address():
    """Test method address of class Address."""
    print('Test Address.address()')
    addr = Address()
    print(addr.address())
    print(addr.address())
    print(addr.address())
    print(addr.address())
    print(addr.address())
    print(addr.address())
    print(addr.address())


# Generated at 2022-06-23 21:00:15.519484
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    suffix = address.street_suffix()
    print(suffix)
    assert suffix in address._data['street']['suffix']

if __name__ == "__main__":
    test_Address_street_suffix()

# Generated at 2022-06-23 21:00:20.164891
# Unit test for method continent of class Address
def test_Address_continent():
    """Test for returning dictionary."""
    import json
    from mimesis.providers.address import Address
    assert Address().continent() in json.load(open('mimesis/data/address.json'))['continent']


# Generated at 2022-06-23 21:00:22.734690
# Unit test for method street_number of class Address
def test_Address_street_number():
    obj = Address()
    for x in range(10):
        assert type(int(obj.street_number())) == int


# Generated at 2022-06-23 21:00:24.616683
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    result = address.street_name()
    assert type(result) == str



# Generated at 2022-06-23 21:00:31.060733
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address."""
    obj = Address(None)

    # Test return type of method coordinates of class Address
    assert isinstance(obj.coordinates(), dict)

    # Test if method coordinates of class Address return a dict of coord.
    assert isinstance(obj.coordinates()['longitude'], float)
    assert isinstance(obj.coordinates()['latitude'], float)

    # Test if method coordinates of class Address return a dict of DMS coord.
    assert 'º' in obj.coordinates(dms=True)['longitude']
    assert 'º' in obj.coordinates(dms=True)['latitude']

# Generated at 2022-06-23 21:00:32.759443
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adr = Address()
    assert adr.federal_subject()


# Generated at 2022-06-23 21:00:34.061083
# Unit test for constructor of class Address
def test_Address():
    assert isinstance(Address(), Address)

# Generated at 2022-06-23 21:00:36.838409
# Unit test for method continent of class Address
def test_Address_continent():
    a=Address()
    assert a.continent() in ('Europe', 'Africa', 'Asia', 'Oceania', 'Americas', 'Antarctica')

# Generated at 2022-06-23 21:00:39.332378
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    for x in range(1000):
        st = a.street_name()
        assert st in a._data['street']['name']

# Generated at 2022-06-23 21:00:45.656199
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.localization import Localization
    from mimesis.utils.decorators import keep_length

    address = Address(localization=Localization(Locale.EN, 'address'))

    @keep_length
    def get_test_method(test_string, replace_char='_'):
        """Get a test method."""
        return test_string.format(
            replace_char,
            replace_char,
            replace_char,
        ).split(',')

    tests = address._data['tests']['address']
    test_methods = get_test_method(tests)

    for test in test_methods:
        assert address.address() in test

# Generated at 2022-06-23 21:00:48.701674
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    prefecture = Address("ru").prefecture()
    assert isinstance(prefecture, str)
    assert prefecture in Address("ru")._data['state']['name']


# Generated at 2022-06-23 21:00:51.138579
# Unit test for method state of class Address
def test_Address_state():
    ad = Address(locale="en")
    assert ad.state() in ad._data['state']['name']


# Generated at 2022-06-23 21:00:53.712894
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address('en').continent() in ('South America', 'Asia', 'Africa', 'Europe', 'Oceania', 'North America', 'Antarctica')


# Generated at 2022-06-23 21:00:55.472940
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert type(Address.longitude()) is float
    assert -180 <= Address.longitude() <= 180

# Generated at 2022-06-23 21:00:57.547124
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Unit test for method zip_code of class Address."""
    a = Address()
    assert a.postal_code() == a.zip_code()

# Generated at 2022-06-23 21:00:58.768397
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    print(address.zip_code())


# Generated at 2022-06-23 21:01:01.109289
# Unit test for method region of class Address
def test_Address_region():
    address = Address(locale='en')

    assert address.region() in address._data['state']['name']

# Generated at 2022-06-23 21:01:10.693530
# Unit test for constructor of class Address
def test_Address():
  from mimesis.exceptions import LocaleNotFound

  address = Address(locale='ru')
  assert issubclass(type(address), Address)

  assert address.province() in address._data['state']['abbr']
  assert address.region() in address._data['state']['name']

  assert address.city() in address._data['city']

  assert address.address() is not None
  assert address.street_number() is not None
  assert address.street_name() is not None
  assert address.street_suffix() is not None

  lat = address.latitude()
  lon = address.longitude()
  assert lat <= 90 and lat >= -90
  assert lon <= 180 and lon >= -180

  assert address.coordinates() is not None


# Generated at 2022-06-23 21:01:12.122693
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    ad = Address(locale='en')
    assert len(ad.postal_code()) == 5

# Generated at 2022-06-23 21:01:17.247082
# Unit test for method continent of class Address
def test_Address_continent():
    # Russian language
    for i in range(1000):
        assert 'А' in Address('ru').continent()

    # English language
    for i in range(1000):
        assert 'O' in Address('en').continent()


# Generated at 2022-06-23 21:01:19.067700
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('zh')
    print(address.prefecture())


# Generated at 2022-06-23 21:01:22.344009
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from .. import config
    from .. import enums
    a = Address(config.LOCALE, enums.Gender.MALE)
    assert a.federal_subject() in a._data['state']['name']


# Generated at 2022-06-23 21:01:25.909966
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    data = address.street_name()
    assert isinstance(data, str)
    assert isinstance(data, str)
    assert len(data) > 1
    assert data != ''
    assert data is not None


# Generated at 2022-06-23 21:01:35.278113
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    ad = Address()
    assert ad.state() != ad.region() != ad.province() != ad.federal_subject() != ad.prefecture()
    assert ad.country() != ad.country(True)
    assert ad.country_code() == ad.country_code(CountryCode.A2) != ad.country_code(CountryCode.A3)
    assert ad.city() != ad.city()
    assert ad.street_name() != ad.street_name()
    assert ad.street_suffix() != ad.street_suffix()
    assert ad.street_number() != ad.street_number()
    assert ad.address() != ad.address()
    assert ad.zip_code() != ad.zip_code()

# Generated at 2022-06-23 21:01:36.693679
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    print(address.region())


# Generated at 2022-06-23 21:01:38.368235
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() in open('data/address.json', encoding='utf-8').read()


# Generated at 2022-06-23 21:01:41.893970
# Unit test for method country of class Address
def test_Address_country():
    print("Testing Address.country()")
    addr = Address('en')
    country_list = [addr.country() for i in range(10)]
    print(country_list)
    # Testing that all results are in the country list
    country_list.extend(addr._data['country']['name'])
    country_list = [x.lower() for x in country_list]
    assert(len(country_list) == len(set(country_list)))

# Generated at 2022-06-23 21:01:45.473074
# Unit test for method city of class Address
def test_Address_city():
    print(Address.city('en'))
    print(Address.city('zh'))

if __name__ == "__main__":
    test_Address_city()

# Generated at 2022-06-23 21:01:47.552772
# Unit test for method state of class Address
def test_Address_state():
    ad = Address()
    state = ad.state()
    assert isinstance(state, str)
    assert state.__len__() > 0


# Generated at 2022-06-23 21:01:48.825219
# Unit test for constructor of class Address
def test_Address():
    """Unit test for Address."""
    pass


# Generated at 2022-06-23 21:01:50.665027
# Unit test for method city of class Address
def test_Address_city():
    myObject = Address("en")
    assert (type(myObject.city()) == str)


# Generated at 2022-06-23 21:01:52.123786
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    result = a.zip_code()
    assert result != None

# Generated at 2022-06-23 21:01:53.698697
# Unit test for method longitude of class Address
def test_Address_longitude():
    test = Address()
    assert -180 <= float(test.longitude()) <= 180


# Generated at 2022-06-23 21:01:56.141852
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    country_code = address.country_code(CountryCode.Numeric)
    country_code = int(country_code)
    assert country_code in range(100, 999)

# Generated at 2022-06-23 21:01:57.669307
# Unit test for method province of class Address
def test_Address_province():
  address = Address()
  print(address.province())

test_Address_province()

# Generated at 2022-06-23 21:02:04.819199
# Unit test for method street_suffix of class Address

# Generated at 2022-06-23 21:02:08.023726
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    for _ in range(0,10000):
        address = Address()
        assert address.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:02:11.272512
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    for i in range(0, 100):
        assert isinstance(a.street_suffix(), str)
        assert a.street_suffix() in a._data['street']['suffix']

# Generated at 2022-06-23 21:02:13.541015
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    result = address.continent()
    assert result in address._data['continent']

# Generated at 2022-06-23 21:02:17.060436
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address_provider = Address()
    zip_code = address_provider.zip_code()
    assert isinstance(zip_code, str)
    assert int(zip_code) > 0


# Generated at 2022-06-23 21:02:24.803364
# Unit test for method city of class Address
def test_Address_city():
    '''
    This function is used to test the correctness of 
    metods city in class Address.
    '''
    prov = Address('he')
    res_dict = {}
    for i in range(1000):
        res = prov.city()
        if res in res_dict:
            res_dict[res] += 1
        else:
            res_dict[res] = 1
    for i in res_dict:
        if res_dict[i] >= 6:
            print(i)
    print(res_dict)
    sum_res = sum(res_dict.values())
    assert sum_res == 1000


# Generated at 2022-06-23 21:02:26.834768
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    addr = Address()
    assert isinstance(addr.prefecture(), str)

# Generated at 2022-06-23 21:02:36.813642
# Unit test for method province of class Address
def test_Address_province():
    # Assert that:
    # If a locale is not specified,
    # locale equals to 'en'.
    english_province = Address().province()
    # Check that `english_province` is a string.
    assert isinstance(english_province, str)

    # Assert that:
    # If a correct locale is specified,
    # locale equals to 'ru'.
    russian_province = Address('ru').province()
    # Check that `russian_province` is a string.
    assert isinstance(russian_province, str)

    # Assert that:
    # If an incorrect locale is specified,
    # locale equals to 'en'.
    arabic_province = Address('ar').province()
    # Check that `arabic_province` is a string.

# Generated at 2022-06-23 21:02:38.514329
# Unit test for method street_name of class Address
def test_Address_street_name():
    address_name = Address()
    result = address_name.street_name()
    print(result)


# Generated at 2022-06-23 21:02:41.281765
# Unit test for method region of class Address
def test_Address_region():
    address = Address('ru')
    assert address.region() in address._data['state']['name']


# Generated at 2022-06-23 21:02:44.053309
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    res = a.province(abbr=True)
    assert res != ""
    assert ' ' not in res
    assert len(res) < 5


# Generated at 2022-06-23 21:02:54.189804
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    country_code = address.country_code(CountryCode.A2)
    assert len(country_code) == 2
    assert country_code in COUNTRY_CODES[CountryCode.A2.value]

    country_code = address.country_code(CountryCode.A3)
    assert len(country_code) == 3
    assert country_code in COUNTRY_CODES[CountryCode.A3.value]

    country_code = address.country_code(CountryCode.NUM)
    assert len(country_code) == 3
    assert country_code in COUNTRY_CODES[CountryCode.NUM.value]

    country_code = address.country_code(CountryCode.FULLNAME)
    assert len(country_code) >= 3
    assert country_code in COUNTRY_CODES

# Generated at 2022-06-23 21:02:56.511973
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    for i in range(100):
        assert(isinstance(a.street_number(), str))
        assert(int(a.street_number()) < 1400)


# Generated at 2022-06-23 21:03:08.069372
# Unit test for constructor of class Address
def test_Address():
    def validate_street_number():
        assert Address().street_number() in range(1, 100)
    validate_street_number()

    def validate_street_name():
        street_name = Address().street_name()
        assert street_name in Address._data['street']['name']
    validate_street_name()

    def validate_street_suffix():
        street_suffix = Address().street_suffix()
        assert street_suffix in Address._data['street']['suffix']
    validate_street_suffix()

    def validate_address():
        address = Address().address()
        street_number = Address().street_number()
        street_name = Address().street_name()
        street_suffix = Address().street_suffix()

# Generated at 2022-06-23 21:03:10.303147
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address(locale='ja')
    result = address.prefecture()
    assert result is not None


# Generated at 2022-06-23 21:03:11.003265
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() in ['St', 'Rd', 'Ave']

# Generated at 2022-06-23 21:03:13.348174
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address()
    result = addr.street_suffix()
    assert result in addr._data['street']['suffix']


# Generated at 2022-06-23 21:03:15.855849
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.builtins import Address

    zip_code = Address('en').zip_code()
    assert isinstance(zip_code, str) and len(zip_code) == 9

# Generated at 2022-06-23 21:03:19.148188
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert isinstance(address.province(), str)
    assert isinstance(address.province(abbr=True), str)


# Generated at 2022-06-23 21:03:20.711121
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr = Address(seed=12345)
    assert addr.street_name() == 'Vandra Street'


# Generated at 2022-06-23 21:03:29.820368
# Unit test for method country of class Address
def test_Address_country():
    cls = Address('id')
    current_locale = cls._data['country']['current_locale']
    random_country = cls.country(allow_random=True)
    current_locale_country = cls.country(allow_random=False)
    assert isinstance(current_locale_country, str)
    assert isinstance(random_country, str)
    assert isinstance(current_locale, str)
    assert current_locale == current_locale_country
    assert current_locale_country in cls._data['country']['name']
    assert random_country in cls._data['country']['name']


# Generated at 2022-06-23 21:03:40.400659
# Unit test for method street_name of class Address

# Generated at 2022-06-23 21:03:50.135982
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import CountryCode
    address = Address()
    country_code = address.country_code(CountryCode.A2)
    province = address.province()
    assert province in address._data['state']['name']
    assert province in address._data['state']['abbr']
    assert province in address._data['state'][country_code]['name']
    assert province in address._data['state'][country_code]['abbr']
    assert address.random.choice(address._data['state']['name']) in address._data['state']['name']
    assert address.random.choice(address._data['state']['name']) in address._data['state']['abbr']

# Generated at 2022-06-23 21:03:53.241371
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Test method street_number of class Address"""
    address = Address()
    assert str(
        address.street_number()
    ) in [str(i) for i in range(1, 1400)]
    
    

# Generated at 2022-06-23 21:03:54.855158
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('tr')
    assert address.prefecture() in address._data['state']


# Generated at 2022-06-23 21:03:56.794404
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    given = 'RU'
    expected = 'Тыва'
    assert Address(given).federal_subject() == expected

# Generated at 2022-06-23 21:03:59.159079
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    assert address.federal_subject() in ['Москва', 'Самара']


# Generated at 2022-06-23 21:04:01.678978
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    prefecture = address.prefecture()
    if prefecture not in address._data['state']['name']:
        raise ValueError("Address.prefecture()")

# Generated at 2022-06-23 21:04:05.381302
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address(locale='ru')
    assert a.prefecture() in a._data['state']['name']


# Generated at 2022-06-23 21:04:07.376606
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address('en').longitude(True) is not None

# test for method latitude of class Address

# Generated at 2022-06-23 21:04:08.881625
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert type(a) == Address


# Generated at 2022-06-23 21:04:10.807976
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    print(a.prefecture())
    return


# Generated at 2022-06-23 21:04:12.710547
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    result = obj.address()
    assert result is not None

# Generated at 2022-06-23 21:04:15.656914
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test coordinates()."""
    adr = Address()
    assert isinstance(adr.coordinates(), dict)



# Generated at 2022-06-23 21:04:27.577225
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from random import choice
    from collections import namedtuple

    from mimesis.data import CONTINENT_CODES
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    def get_fmt(dms: bool) -> str:
        return '{}º{}\'{:.3f}"'

    def generate(continent: str, country: str, dms: bool, fmt: str) -> str:
        a: Address = Address(locale=country)
        return fmt.format(
            *a.coordinates(dms=dms).values(),
        )

    fmt = get_fmt(dms=True)
    args = ['Australia', 'en', True, fmt]

# Generated at 2022-06-23 21:04:29.432520
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    result = address.longitude()
    assert isinstance(result, float)

# Generated at 2022-06-23 21:04:40.437658
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test the method country_code of the class Address."""
    address = Address()
    country_code = address.country_code(CountryCode.A2)
    assert isinstance(country_code, str)
    assert len(country_code) == 2
    assert country_code.isalpha()

    country_code = address.country_code(CountryCode.A3)
    assert isinstance(country_code, str)
    assert len(country_code) == 3
    assert country_code.isalpha()

    country_code = address.country_code(CountryCode.NUMERIC)
    assert isinstance(country_code, str)
    assert len(country_code) == 3
    assert country_code.isdigit()

# Generated at 2022-06-23 21:04:41.891713
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    test = Address()
    assert len(test.prefecture()) == 2


# Generated at 2022-06-23 21:04:49.917121
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address."""
    tests = (
        (u'Архангельская область', u'Архангельская область'),
        (u'Чувашия', u'Чувашия')
    )
    for test in tests:
        assert Address(locale=test[0]).prefecture() == test[1]


# Generated at 2022-06-23 21:04:51.615896
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province() == 'MI'

# Generated at 2022-06-23 21:04:53.593220
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    result = a.street_number()
    assert result is not None


# Generated at 2022-06-23 21:04:57.137421
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert len(str(Address().street_number())) > 0
    assert len(str(Address().street_number(maximum=1500))) > 0
    assert int(Address().street_number()) <= 1400


# Generated at 2022-06-23 21:05:06.945934
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address('zh').street_name() == '金沙江路' # Result of Chinese
    assert Address('ja').street_name() == '千葉通り' # Result of Japanese
    assert Address('en').street_name() == 'Cantrell Brook' # Result of English
    assert Address('in').street_name() == 'Jawaharlal Nehru Marg' # Result of Indonesian
    assert Address('id').street_name() == 'Jl. Dr. Setiabudhi' # Result of Indonesian
    assert Address('th').street_name() == 'Ratchaphakdi Alley' # Result of Thai
    assert Address('ru').street_name() == 'ул. Вербовая' # Result of Russian

# Generated at 2022-06-23 21:05:11.153073
# Unit test for method address of class Address
def test_Address_address():
    import pytest
    adr = Address()
    assert isinstance(adr.address(), str)
    assert adr.address() != ''
    with pytest.raises(TypeError):
        assert isinstance(adr.address(1), str)


# Generated at 2022-06-23 21:05:13.392951
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    street_name = address.street_name()
    assert street_name in address._data['street']['name']
    

# Generated at 2022-06-23 21:05:15.112881
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country() == "Bangladesh"

# Generated at 2022-06-23 21:05:17.434555
# Unit test for method city of class Address
def test_Address_city():
    address = Address('ru')
    city = address.city()
    assert city == 'Норильск'


# Generated at 2022-06-23 21:05:19.128185
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address()
    print(addr.street_suffix())


# Generated at 2022-06-23 21:05:22.406650
# Unit test for method longitude of class Address
def test_Address_longitude():
    ad = Address()
    lg1 = ad.longitude()
    lg2 = ad.longitude(dms=True)
    assert isinstance(lg1, float)
    assert isinstance(lg2, str)


# Generated at 2022-06-23 21:05:24.904489
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert address.prefecture() in address._data['state']['abbr']
    assert address.prefecture(abbr=True) in address._data['state']['abbr']


# Generated at 2022-06-23 21:05:30.540059
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import ContinentCode
    addr = Address()
    # Should raise ValueError
    addr.continent(True)
    assert addr.continent() != addr.continent(code=True)
    assert isinstance(addr.continent(code=True), ContinentCode)



# Generated at 2022-06-23 21:05:39.270763
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.data import ISO_639_1_LOCALES_CODES
    from mimesis.enums import CountryCode
    from mimesis.providers.datetime import Datetime

    a = Address('ja')
    dt = Datetime(a.locale)
    dt.set_datetime_format("%A, %B %d, %Y")
    # print(dt.date(now=True))

    # print("\n")
    # print("qwertyuiop[]asdfghjkl;'zxcvbnm,./{}")
    # print("\n")

    # print("{}")
    # print(dt.date(now=True))
    # print("{}")
    # print(dt.date(now=True))

# Generated at 2022-06-23 21:05:41.920930
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.providers.address import Address
    provider = Address('en')

    assert provider.zip_code() == provider.postal_code()

# Generated at 2022-06-23 21:05:44.584253
# Unit test for method address of class Address
def test_Address_address():
    # Instance of Address
    address = Address()
    # Print the generated full address
    print(address.address())



# Generated at 2022-06-23 21:05:53.995937
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    from mimesis.providers.base import BaseEnum

    ge = Address('en')

    c_code = ge.country_code(CountryCode.A3)

    code = ge.calling_code()

    assert code in CALLING_CODES[c_code]

    assert hasattr(CountryCode, 'A2')

    assert isinstance(CountryCode.A2, BaseEnum)

    # Test incomplete name of calling code
    assert '+' in ge.calling_code(incomplete=True)

    # Test without spaces
    assert not ge.calling_code(spaces=False).isspace()

    # Test with invalid fmt
    assert callable(ge.calling_code)

    # Test max length

# Generated at 2022-06-23 21:05:57.481423
# Unit test for method latitude of class Address
def test_Address_latitude():
    adr = Address()
    print(adr.longitude(dms=True))
    print(adr.latitude(dms=True))
    print(adr.longitude())
    print(adr.latitude())

# Generated at 2022-06-23 21:06:02.315119
# Unit test for method country_code of class Address
def test_Address_country_code():
    def test(code):
        assert code in COUNTRY_CODES[CountryCode.A2]

    for i in range(100):
        test(Address('en').country_code())
        test(Address('en').country_code(CountryCode.A3))
        test(Address('en').country_code(CountryCode.NUMERIC))
        test(Address('en').country_code(CountryCode.FULL))



# Generated at 2022-06-23 21:06:03.767150
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address('en')
    continent = address.continent()
    assert continent != ""
    assert continent != None


# Generated at 2022-06-23 21:06:05.081057
# Unit test for method latitude of class Address
def test_Address_latitude():
    add = Address(locale='en')
    add.latitude()


# Generated at 2022-06-23 21:06:06.771766
# Unit test for method city of class Address
def test_Address_city():
    tmp = Address().city()
    assert tmp != None
    assert type(tmp) == str


# Generated at 2022-06-23 21:06:09.892081
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    res = a.street_name()
    assert res in a._data['street']['name']
    print(res)



# Generated at 2022-06-23 21:06:11.445952
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    for i in range(10):
        print(a.street_name())


# Generated at 2022-06-23 21:06:16.556034
# Unit test for method address of class Address
def test_Address_address():
    _A = Address()
    for _ in range(10):
        _address = _A.address()
        (assert_equal, assert_not_equal) = (
            _A.assertEqual, _A.assertNotEqual)
        assert_not_equal(_address, "")
        assert_not_equal(_address, None)
        assert_not_equal(_address, 0)
        assert_equal(type(_address), str)
        print(_address)

# Generated at 2022-06-23 21:06:20.221567
# Unit test for method country of class Address
def test_Address_country():
    country = Address().country()
    assert country in ("Austria", "Canada", "France", "Germany", "Italy", "Mexico", "Spain", "Sweden", "Switzerland", "United States", "United Kingdom")


# Generated at 2022-06-23 21:06:22.891622
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert len(Address().street_suffix())>0


# Generated at 2022-06-23 21:06:26.422507
# Unit test for method province of class Address
def test_Address_province():
    with Address(provider='address-MY') as a:
        assert a.province() == 'Kelantan'
        assert a.province(abbr=True) == '11'
        assert a.prefecture() == 'Kelantan'
        assert a.prefecture(abbr=True) == '11'
        assert a.federal_subject() == 'Kelantan'
        assert a.federal_subject(abbr=True) == '11'
        assert a.region() == 'Kelantan'
        assert a.region(abbr=True) == '11'


# Generated at 2022-06-23 21:06:28.379836
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    (Adr().zip_code())
    print("test_Address_zip_code Done")

# Generated at 2022-06-23 21:06:30.049274
# Unit test for method longitude of class Address
def test_Address_longitude():
    longitude = Address().longitude()
    assert longitude >= -180 and longitude <= 180

# Generated at 2022-06-23 21:06:32.975717
# Unit test for method continent of class Address
def test_Address_continent():
    print(Address().continent(code=True))
    print(Address().continent())


if __name__ == '__main__':
    test_Address_continent()

# Generated at 2022-06-23 21:06:35.680544
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    st_sfx = address.street_suffix()
    assert isinstance(st_sfx, str) and st_sfx != ''


# Generated at 2022-06-23 21:06:37.871324
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    result = address.street_name()
    print(result)
    assert isinstance(result, str)

# Generated at 2022-06-23 21:06:43.404234
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    adress = Address(locale='zw')
    zip_code1 = adress.postal_code()
    zip_code2 = adress.postal_code()
    print(zip_code1)
    print(zip_code2)
    assert zip_code1 != zip_code2


# Generated at 2022-06-23 21:06:48.723464
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adr = Address(locale='ru')
    adr.federal_subject(abbr=False)
    adr.federal_subject(abbr=True)
    

# Generated at 2022-06-23 21:06:52.305899
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    coor_keys = ['longitude','latitude']
    assert len(coor_keys) == len(a.coordinates())
    assert all([key in coor_keys for key in a.coordinates()])


# Generated at 2022-06-23 21:06:53.768647
# Unit test for method address of class Address
def test_Address_address():
    ad = Address(locale='en')
    ad.address()


# Generated at 2022-06-23 21:07:05.685338
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Unit test for method longitude of class Address
    from mimesis.enums import CountryCode
    from mimesis.typing import Float, Precision

    # Case 1: DMS format (default precision is 6)
    lg = Address().longitude(dms=True)
    assert isinstance(lg, str)
    assert lg.endswith('"E')

    # Case 2: DMS format (precision is 2)
    lg = Address().longitude(dms=True, precision=2)
    assert isinstance(lg, str)
    assert lg.endswith('"E')

    # Case 3: Decimal format (default precision is 6)
    lg = Address().longitude()
    assert isinstance(lg, float)

    # Case 4: Decimal format (precision is 2)

# Generated at 2022-06-23 21:07:07.218259
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adr = Address()
    res = adr.federal_subject()
    assert isinstance(res, str)

# Generated at 2022-06-23 21:07:08.358319
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() > -90 and Address().latitude() < 90


# Generated at 2022-06-23 21:07:10.860063
# Unit test for method latitude of class Address
def test_Address_latitude():
    addr = Address()
    a = ['N', 'S']
    assert addr.latitude() in a or addr.latitude(dms = True)[-1] in a


# Generated at 2022-06-23 21:07:13.203977
# Unit test for method country of class Address
def test_Address_country():
    import mimesis
    address = mimesis.Address('ru')

    assert address.country() == "Россия"


# Generated at 2022-06-23 21:07:16.823853
# Unit test for method continent of class Address
def test_Address_continent():
    ad = Address()
    for i in range(5):
        print(ad.continent())

# Generated at 2022-06-23 21:07:22.045724
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    address = Address()
    result = address.latitude(dms = True)
    assert type(result) == type(" ")
    result = address.latitude()
    assert result >= -90 and result <= 90



# Generated at 2022-06-23 21:07:24.891865
# Unit test for method province of class Address
def test_Address_province():
    province_list = []
    for _ in range(100):
        province_list.append(Address().province())
    assert province_list.count(province_list[0]) >= 20

# Generated at 2022-06-23 21:07:27.146731
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    d = {}
    for i in range(0, 20):
        d[address.country_code()] = 1
    assert len(d.keys()) == 20

# Generated at 2022-06-23 21:07:38.876295
# Unit test for method state of class Address
def test_Address_state():
    # Locale: Russian, address.json(address.py)
    a1 = Address(locale='ru')
    for i in range(0, 10):
        if type(a1.state(True)) is str:
            assert len(a1.state(True)) == 2
        # print(a1.state(True))
    for i in range(0, 10):
        if type(a1.state(False)) is str:
            assert len(a1.state(False)) > 2
        # print(a1.state(False))

    # Locale: Chinese, address.json(address.py)
    a2 = Address(locale='zh')
    for i in range(0, 10):
        if type(a2.state(True)) is str:
            assert len(a2.state(True)) == 2

# Generated at 2022-06-23 21:07:42.581289
# Unit test for method city of class Address
def test_Address_city():
    _test = Address()
    _cities = [_test.city() for _ in range(N)]

    assert len(_cities) == N
    assert isinstance(_cities[0], str)
    print("Address.city() passed succesfully")
    return True


# Generated at 2022-06-23 21:07:44.560184
# Unit test for method region of class Address
def test_Address_region():
    # @type: Address
    add = Address(locale='en')
    assert add.region() == 'CA' or add.region() == 'ON'

# Generated at 2022-06-23 21:07:47.472548
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    assert address.country() == 'США'
    assert address.country(True) in address._data['country']['name']

# Generated at 2022-06-23 21:07:52.994364
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    print('Test of method address in Address class')
    address = Address()
    print('Method address of class Address have a first variant in eng locale')
    print(address.address())
    print('Method address of class Address have a second variant in eng locale')
    print(address.address())
    print('Method address of class Address have a first variant in ru locale')
    address.locale = 'ru'
    print(address.address())
    print('Method address of class Address have a second variant in ru locale')
    print(address.address())
    print('Method address of class Address have a test variant in ru locale')
    print(address.address())
    print('Method address of class Address have a first variant in ja locale')
    address.loc

# Generated at 2022-06-23 21:07:54.694773
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state() is not None


# Generated at 2022-06-23 21:08:05.408501
# Unit test for method postal_code of class Address

# Generated at 2022-06-23 21:08:12.078626
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import CountryCode
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.phone import Phone
    from mimesis.providers.ru import RussiaSpecProvider
    from mimesis.providers.uk import UKSpecProvider

    person = Person('ru', gender=Gender.MALE)
    rsp = RussiaSpecProvider()
    ukp = UKSpecProvider()
    datetime = Datetime()
    address = Address('ru')
    phone = Phone('ru')

# Generated at 2022-06-23 21:08:14.260795
# Unit test for method country of class Address
def test_Address_country():
    a = Address('ru')
    assert(a.country() == 'Россия')

# Generated at 2022-06-23 21:08:18.128665
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Get a random calling code of random country
    # calling_code may change because it is random
    calling_code = Address().calling_code()
    assert calling_code== "+48"


# Generated at 2022-06-23 21:08:22.307689
# Unit test for method longitude of class Address
def test_Address_longitude():
    print("A green bar means that Address longitude() function is working.")
    x = Address()
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())
    print(x.longitude())