

# Generated at 2022-06-23 20:58:22.515765
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    add_test = Address()
    assert type(add_test.calling_code()) == str


# Generated at 2022-06-23 20:58:23.114054
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    Address().coordinates()

# Generated at 2022-06-23 20:58:24.654686
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    result = a.latitude(True)
    assert isinstance(result, str)



# Generated at 2022-06-23 20:58:29.912343
# Unit test for method city of class Address
def test_Address_city():
    """This is a test function for the function city."""
    expected_output = 'Boston'
    output = Address().city()

    assert expected_output!=output, "The output should be equal to the expected output"
    assert type(output)==str, "The output should be a string"


# Generated at 2022-06-23 20:58:35.806655
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import random
    from mimesis.enums import CountryCode

    # Declare seed for random generator
    seed = 3
    # Create a sequence of number, which is used in random generator.
    seq = range(0, 10)
    # Set seed
    random.seed(seed)
    # Set seed for random generator
    random.setstate(random.getstate())
    # Generate sequence which is used in random generator
    random.shuffle(seq)
    # Get input params
    class UnitaryInputParams:
        def __init__(self, dms):
            self.dms = dms

    # Set seed
    random.seed(seed)
    # Set seed for random generator
    random.setstate(random.getstate())
    # Generate sequence which is used in random generator
    random.shuffle(seq)

# Generated at 2022-06-23 20:58:37.987586
# Unit test for method calling_code of class Address
def test_Address_calling_code():
	address = Address()
	print('calling_code: ', address.calling_code())

# Generated at 2022-06-23 20:58:41.085443
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    data = Address('en')
    assert data.calling_code() in CALLING_CODES

# Generated at 2022-06-23 20:58:51.361126
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() in [
        '{st_num} {st_name} {st_sfx}'.format(st_num=address.street_number(), st_name=address.street_name(), st_sfx=address.street_suffix()),
        '{st_num} {st_name} {st_sfx}'.format(st_num=address.street_number(maximum=1000), st_name=address.street_name(), st_sfx=address.street_suffix()),
        '{st_num} {st_name} {st_sfx}'.format(st_num=address.street_number(maximum=900), st_name=address.street_name(), st_sfx=address.street_suffix()),
    ]


# Generated at 2022-06-23 20:58:52.627446
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    print(address.city())


# Generated at 2022-06-23 20:58:56.668961
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr = Address()
    # d = addr.zip_code()
    # print(d)
if __name__ == '__main__':
    test_Address_zip_code()

# Generated at 2022-06-23 20:59:00.342386
# Unit test for method longitude of class Address
def test_Address_longitude():
    class UnitTest(Address):
        pass
    u = UnitTest('en')
    a = u.longitude()
    print(u)
    assert isinstance(a, float)
    print(a)
    # AssertionError: True is not false



# Generated at 2022-06-23 20:59:02.257535
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    a = address.address()
    assert isinstance(a, str)
    assert a != ''



# Generated at 2022-06-23 20:59:04.909896
# Unit test for constructor of class Address
def test_Address():
    _address = Address()
    assert _address is not None
    assert _address.__class__.__name__ == 'Address'


# Generated at 2022-06-23 20:59:06.879039
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None
    assert address.locale == 'en'

# Generated at 2022-06-23 20:59:11.104336
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Country
    address = Address('en')

    assert address.country() == 'United States'
    assert address.country(allow_random=True) in Country.names()


# Generated at 2022-06-23 20:59:13.161570
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    state = address.state()
    assert state in address._data['state']['name']

# Generated at 2022-06-23 20:59:14.147814
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    print(address.federal_subject())

# Generated at 2022-06-23 20:59:15.363127
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    print(a.state())

# Generated at 2022-06-23 20:59:16.563017
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert isinstance(address, Address)


# Generated at 2022-06-23 20:59:17.940530
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    adr = Address('en')
    print(adr.coordinates())

# Generated at 2022-06-23 20:59:21.794288
# Unit test for constructor of class Address
def test_Address():
    """Test for Address class constructor."""
    from mimesis.enums import Locale

    address = Address(locale=Locale.EN)
    assert address.street_name()
    assert address.street_number()
    assert address.street_suffix()


# Generated at 2022-06-23 20:59:23.519518
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address()
    assert type(addr.street_suffix()) == str


# Generated at 2022-06-23 20:59:28.085108
# Unit test for method street_name of class Address
def test_Address_street_name():
    provider = Address()
    # Test method street_name of class Address with seed 123
    provider.seed(123)
    assert provider.street_name() == 'Пушкинская'
    # Test method street_name of class Address with seed 321
    provider.seed(321)
    assert provider.street_name() == 'Ул. Ленинградская'


# Generated at 2022-06-23 20:59:39.820319
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state() in ("Alaska", "Montana", "North Dakota", "South Dakota", "Maine", "Vermont", "New Hampshire", "Massachusetts", "Rhode Island", "Connecticut", "New Jersey", "Delaware", "Maryland", "Virginia", "West Virginia", "North Carolina", "South Carolina", "Georgia", "Florida", "Ohio", "Pennsylvania", "New York", "Wisconsin", "Illinois", "Michigan", "Indiana", "Kentucky", "Tennessee", "Alabama", "Mississippi", "Arkansas", "Louisiana", "Oklahoma", "Texas", "Minnesota", "Iowa", "Missouri", "Nebraska", "Kansas", "Colorado", "Wyoming", "Utah", "Arizona", "New Mexico", "Nevada", "California", "Oregon", "Washington", "Idaho", "Hawaii")


# Generated at 2022-06-23 20:59:41.676267
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
	address = Address()
	assert type(address.street_suffix()) == str

# Generated at 2022-06-23 20:59:43.914567
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    street_number = address.street_number()
    street_number_int = int(street_number)
    assert street_number_int >= 1 and street_number_int < 1400


# Generated at 2022-06-23 20:59:46.085536
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    provider = Address()
    assert provider.federal_subject() in provider._data['state']['name']


# Generated at 2022-06-23 20:59:48.367740
# Unit test for method province of class Address
def test_Address_province():
    address = Address('en')
    province = address.province()
    print(province)
    assert province
    assert isinstance(province, str)

# Generated at 2022-06-23 20:59:50.200957
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    res = a.street_suffix()
    assert isinstance(res, str)

# Generated at 2022-06-23 20:59:56.119872
# Unit test for method region of class Address
def test_Address_region():
    s = Address()
    assert s.random.choice(s._data["state"]["abbr"]) == s.region()
    assert s.random.choice(s._data["state"]["abbr"]) == s.province()
    assert s.random.choice(s._data["state"]["abbr"]) == s.federal_subject()
    assert s.random.choice(s._data["state"]["abbr"]) == s.prefecture()

# Generated at 2022-06-23 21:00:01.454214
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address.longitude()
    assert a <= 90 and a >= -90
    assert type(a) is float

if __name__ == '__main__':
    test_Address_longitude()

# Generated at 2022-06-23 21:00:02.597856
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() != Address().street_name()

test_Address_street_name()

# Generated at 2022-06-23 21:00:04.494978
# Unit test for method country of class Address
def test_Address_country():
    print("Test country")
    a = Address()
    print(a.country())


# Generated at 2022-06-23 21:00:05.885256
# Unit test for constructor of class Address
def test_Address():
    address = Address(locale="en")


# Generated at 2022-06-23 21:00:08.786387
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    assert a.province() == 'AS'
    assert a.province('state') == 'AS'
    assert a.province(abbr=True) == 'AS'
    assert a.province(False) == 'American Samoa'

# Generated at 2022-06-23 21:00:12.919100
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    for i in range(100):
        address_1 = provider.address()
        address_2 = provider._data['address_fmt'].format(
            st_num=provider.street_number(),
            st_name=provider.street_name(),
            st_sfx=provider.street_suffix()
        )
        assert address_1 == address_2

# Generated at 2022-06-23 21:00:15.076044
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address('en')
    assert address.calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:00:26.969692
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from enum import Enum
    from random import randint
    from re import match
    
    class Country(Enum):
        Algeria = 'dz'
        Bahamas = 'bs'
        Barbados = 'bb'
        Brazil = 'br'

# Generated at 2022-06-23 21:00:30.619336
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test for method coordinates of class Address."""
    a = Address('ru')
    assert -90 <= a.coordinates()["latitude"] <= 90
    assert -180 <= a.coordinates()["longitude"] <= 180


# Generated at 2022-06-23 21:00:32.397695
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address(random.Random())
    assert type(a.longitude()) is float


# Generated at 2022-06-23 21:00:37.666610
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.providers.address import Address
    from mimesis.enums import Country
    from mimesis.enums import Locale

    a = Address(Country.JAPAN, Locale.JAPANESE)
    city = a.city()
    assert city in a._data['city']

# Generated at 2022-06-23 21:00:39.712910
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    suffix = address.street_suffix()
    assert len(suffix)>0


# Generated at 2022-06-23 21:00:42.159882
# Unit test for constructor of class Address
def test_Address():
    print('test local constructor')
    address = Address('en')
    print('-' * 100)
    print('test global constructor')
    address = Address()
    print('-' * 100)

# Generated at 2022-06-23 21:00:53.464737
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.builtins import Address as Address_
    from mimesis.enums import Locale
    from mimesis.providers.address import Address as Address_klass

    street_suffix_db = Address_klass._data['street']['suffix']
    # print(street_suffix_db)
    # ['Avenue', 'Blvd', 'Boulevard', 'Cir', 'Circle', 'Close', 'Crescent', 'Court', 'Cove', 'Creek', 'Drive', 'Expressway', 'Freeway', 'Highway', 'Lane', 'Loop', 'Parkway', 'Place', 'Road', 'Square', 'Street', 'Terrace', 'Trail', 'Way']

    address_ = Address_(Locale.US)
    street_suffix = address_.street_suffix()
    #

# Generated at 2022-06-23 21:00:56.356498
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert a.region() in a._data['state']['abbr']
    assert a.region(abbr=True) in a._data['state']['name']


# Generated at 2022-06-23 21:00:59.036547
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address('es')
    assert address.calling_code() == '+54'
    assert '+54' in address.calling_code()
    assert '+' in address.calling_code()


# Generated at 2022-06-23 21:01:02.234764
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    import re
    addr = Address('zh')
    print(re.findall(r'\w', addr.prefecture()))


if __name__ == '__main__':
    test_Address_prefecture()

# Generated at 2022-06-23 21:01:07.198482
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for method federal_subject of class Address.

    The method returns federal subject of country.
    This test verifies the Russian federation.
    """
    ad = Address('ru')
    actual = ad.federal_subject()
    expected = 'Свердловская обл'
    assert actual == expected

# Generated at 2022-06-23 21:01:08.394177
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address('en')
    output = address.continent()
    assert output in ['Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America']


# Generated at 2022-06-23 21:01:10.119540
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province() == address.state()


# Generated at 2022-06-23 21:01:16.121633
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unittest for Address.country_code

    :return: None
    """
    import pytest
    from mimesis.exceptions import NonEnumerableError
    ADDRESS = Address('en')

    # check return type
    assert isinstance(ADDRESS.country_code(), str)



# Generated at 2022-06-23 21:01:25.488707
# Unit test for constructor of class Address
def test_Address():
    A = Address('en')
    assert A.street_number(10) != None
    assert A.street_suffix() != None
    assert A.address() != None
    assert A.street_name() != None
    assert A.state() != None
    assert A.region() != None
    assert A.province() != None
    assert A.prefecture() != None
    assert A.federal_subject() != None
    assert A.postal_code() != None
    assert A.zip_code() != None
    assert A.country_code() != None
    assert A.country() != None
    assert A.city() != None
    assert A.longitude() != None
    assert A.latitude() != None
    assert A.coordinates() != None
    assert A.continent() != None

# Generated at 2022-06-23 21:01:29.501611
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    result = address.longitude(dms=True)
    assert type(result) is str
    assert len(result) > 3
    assert result[-1] in ['W', 'E']
    assert 'º' in result and '\'' in result and '"' in result


# Generated at 2022-06-23 21:01:31.095304
# Unit test for method city of class Address
def test_Address_city():
    a = Address(locale='es')
    a.city() == 'Bilbao'

# Generated at 2022-06-23 21:01:33.036662
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    country = Address().country_code(CountryCode.A3)
    assert len(country) == 3



# Generated at 2022-06-23 21:01:37.723435
# Unit test for method city of class Address
def test_Address_city():  # 3
    """test city."""
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    fr = Address(Locale.FRANCE)
    assert fr.city()

    jp = Address(Locale.JAPAN)
    assert jp.city()

    ru = Address(Locale.RUSSIA)
    assert ru.city()

    uk = Address(Locale.UK)
    assert uk.city()

    us = Address(Locale.US)
    assert us.city()


# Generated at 2022-06-23 21:01:38.910636
# Unit test for method country of class Address
def test_Address_country():
    _address = Address(locale='en')
    assert _address.country() == 'Russian Federation'



# Generated at 2022-06-23 21:01:43.581405
# Unit test for method region of class Address
def test_Address_region():
    obj = Address(locale='en')
    assert obj.region() in obj._data['state']['abbr']
    assert obj.region(abbr=True) in obj._data['state']['abbr']
    assert obj.region(abbr=False) in obj._data['state']['name']
    assert obj.region() == obj.state()
    assert obj.region() == obj.province()
    assert obj.region() == obj.federal_subject()
    assert obj.region() == obj.prefecture()


# Generated at 2022-06-23 21:01:46.814372
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    # TODO: Improve Unit test
    addr = Address()

    assert addr.address() != None


# Generated at 2022-06-23 21:01:49.586870
# Unit test for method region of class Address
def test_Address_region():
    addr = Address()
    assert addr.region(abbr=False).strip()
    assert addr.region(abbr=True).strip()
    assert addr.region().strip()

# Generated at 2022-06-23 21:01:51.084255
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()

# Generated at 2022-06-23 21:01:52.761605
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    # 東京都
    print(address.prefecture())

# Generated at 2022-06-23 21:01:57.111877
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # US
    assert Address(locale='en').postal_code() == '12074-0694'
    assert Address(locale='en').zip_code() == '12074-0694'

    # TH
    assert Address(locale='th').postal_code() == '10270'
    assert Address(locale='th').zip_code() == '10270'


# Generated at 2022-06-23 21:02:02.133481
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address."""
    assert isinstance(Address().latitude(), float)
    assert isinstance(Address().longitude(), float)
    assert isinstance(Address().coordinates().get('latitude'), float)
    assert isinstance(Address().coordinates().get('longitude'), float)
    assert Address().latitude(True).endswith(('N', 'S'))
    assert Address().longitude(True).endswith(('E', 'W'))



# Generated at 2022-06-23 21:02:03.403283
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    obj = Address()
    assert len(obj.zip_code()) == 5 or len(obj.zip_code()) == 10

# Generated at 2022-06-23 21:02:11.097987
# Unit test for method country_code of class Address
def test_Address_country_code():
    # Create Address object
    # with pre-defined locale
    a = Address(locale='ru')

    # Check for method to return
    # code in ISO-3166-1-alpha-2 format
    assert isinstance(a.country_code(CountryCode.A2), str) == True

    # Check for method to return
    # code in ISO-3166-1-alpha-3 format
    assert isinstance(a.country_code(CountryCode.A3), str) == True

    # Check for method to return
    # code in UN M.49 format
    assert isinstance(a.country_code(CountryCode.UNM49), str) == True

    # Check for method to raise KeyError
    # if not supported code format is passed
    # as keyword argument

# Generated at 2022-06-23 21:02:21.890554
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.utils import ProviderType

    p = Person(ProviderType.RUSSIA)
    a = Address(ProviderType.RUSSIA)
    r = RussiaSpecProvider()

    name = p.name(gender=Gender.FEMALE)
    gender = p.gender(name)

    address = a.address()
    city = a.city()
    region = a.region()
    prefecture = a.prefecture()

# Generated at 2022-06-23 21:02:24.802382
# Unit test for method continent of class Address
def test_Address_continent():
    ad = Address()
    print(ad.continent(code = True))
    print(ad.continent())


# Generated at 2022-06-23 21:02:31.161715
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    from mimesis.mimesis import Mimesis
    from mimesis.providers.address import Address

    address_provider = Address(locale='en-US')

    assert len(address_provider.street_suffix()) > 0

# Generated at 2022-06-23 21:02:33.045112
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    postal_code = address.postal_code()
    assert len(postal_code) == 5


# Generated at 2022-06-23 21:02:35.003333
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state() == 'STATE'


# Generated at 2022-06-23 21:02:39.118893
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Create random object
    add = Address("en")
    # Get random longitude
    long = add.longitude()
    # Check if longitude is not empty
    if(long != ""):
        print("longitude:", long)
    else:
        print("longitude is empty\n")


# Generated at 2022-06-23 21:02:40.490748
# Unit test for method region of class Address
def test_Address_region():
    print(Address().region(abbr=True))
    print(Address().region())

# Generated at 2022-06-23 21:02:43.979173
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() != Address().region()
    assert len(Address().region()) > 0
    assert Address().region(abbr=True) != Address().region(abbr=True)
    assert len(Address().region(abbr=True)) == 2


# Generated at 2022-06-23 21:02:54.146372
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import CountryCode
    from mimesis.primitive import container
    from mimesis.providers.address import Address

    a = Address('en')
    prefecture_list = ['Gifu', 'Shizuoka', 'Mie', 'Kyoto', 'Osaka', 'Hyogo', 'Nara', 'Wakayama', 'Tottori', 'Shimane', 'Okayama', 'Hiroshima', 'Yamaguchi', 'Tokushima', 'Kagawa', 'Ehime', 'Kochi', 'Fukuoka', 'Saga', 'Nagasaki', 'Kumamoto', 'Oita', 'Miyazaki', 'Kagoshima', 'Okinawa']
    assert len(prefecture_list) == len(set(prefecture_list))


# Generated at 2022-06-23 21:02:58.709384
# Unit test for method country_code of class Address
def test_Address_country_code():
    obj = Address()
    a = obj.country_code()
    assert len(a) == 2
    b = obj.country_code(fmt='A3')
    assert len(b) == 3
    c = obj.country_code(fmt='numeric')
    assert len(c) == 3
    d = obj.country_code(fmt='alpha3')
    assert len(d) == 3

if __name__ == '__main__':
    test_Address_country_code()

# Generated at 2022-06-23 21:03:01.183462
# Unit test for method latitude of class Address
def test_Address_latitude():
    fa = Address()
    result = fa.latitude()
    assert result is not None



# Generated at 2022-06-23 21:03:03.046259
# Unit test for method city of class Address
def test_Address_city():
    for i in range(1):
        print(Address('en').city())


# Generated at 2022-06-23 21:03:13.151098
# Unit test for method province of class Address
def test_Address_province():
    # province() should return a value in list self._data['state']['name']
    # or self._data['state']['abbr']
    import locale
    locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
    print(locale.getlocale())
    adr = Address(locale='en_US')
    print(adr.province())
    result = adr.province() in adr._data['state']['name']
    print(result)
    print(adr._data['state']['name'])
    result = adr.province() in adr._data['state']['abbr']
    print(result)

if __name__ == "__main__":
    test_Address_province()

# Generated at 2022-06-23 21:03:15.255316
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address."""
    address = Address()
    result = address.region()
    assert ' ' not in result

# Generated at 2022-06-23 21:03:16.517784
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    city = a.city()
    b = Address()
    city2 = b.city()
    assert city != city2



# Generated at 2022-06-23 21:03:18.851477
# Unit test for method city of class Address
def test_Address_city():
    a = Address(en_US)
    assert len(a.city()) > 0

# Generated at 2022-06-23 21:03:22.091768
# Unit test for method country of class Address
def test_Address_country():
    # Test that the country of Address is the country of current locale
    address = Address()
    current_locale = address._data['country']['current_locale']
    test_data = address.country()
    assert test_data == current_locale


# Generated at 2022-06-23 21:03:25.970089
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    provider = Address()
    postal_code = provider.postal_code()
    print(type(postal_code))
    print(postal_code)
    assert isinstance(postal_code, str)


# Generated at 2022-06-23 21:03:27.605020
# Unit test for method state of class Address
def test_Address_state():
    assert len(Address(seed=217).state()) == 2

# Generated at 2022-06-23 21:03:35.404676
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Country
    from mimesis.providers.address import Address


# Generated at 2022-06-23 21:03:37.631753
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-23 21:03:39.853953
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    x = a.province()
    print('province: {}'.format(x))
    x = a.province(abbr=True)
    print('province abbr: {}'.format(x))
    return x


# Generated at 2022-06-23 21:03:42.704072
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address("en")
    result = address.country_code()
    assert result in COUNTRY_CODES['A2']

# Generated at 2022-06-23 21:03:45.427577
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address."""
    result = Address().region()
    assert result is not None


# Generated at 2022-06-23 21:03:47.247042
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert address.region() == address.state()


# Generated at 2022-06-23 21:03:50.332009
# Unit test for method street_number of class Address
def test_Address_street_number():
    for i in range(0,10):
        num = Address().street_number()
        assert (int(num)>0 and int(num)<1400)


# Generated at 2022-06-23 21:04:01.998631
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.geo import Geo

    a = Address()
    assert isinstance(a.longitude(), float)
    assert a.longitude() >= -180.0 and a.longitude() <= 180.0

    # Test DMS format
    lg_dms = a.longitude(dms=True)
    dms_parts = lg_dms.split()
    assert (len(dms_parts) == 2) and (dms_parts[1] in 'WE')

    # Test locale
    locale = 'en-GB'
    a = Address(locale)
    assert a.country_code() == CountryCode.A2.UK

    # Test random country
    g = Geo()

# Generated at 2022-06-23 21:04:06.535905
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Test method latitude() of class Address.
    """
    a = Address()
    assert round(a.latitude(dms=True), 10) == '28º42\'26.865"'

# Generated at 2022-06-23 21:04:08.511520
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    assert address.federal_subject() in address._data['state']['name']

# Generated at 2022-06-23 21:04:11.461542
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert isinstance(a.continent(), str)
    assert isinstance(a.continent(True), str)
    a.seed(1)
    assert a.continent() != a.continent()

# Generated at 2022-06-23 21:04:16.113318
# Unit test for method longitude of class Address
def test_Address_longitude():
    addr = Address()
    lg1 = addr.longitude(True)
    lg2 = addr.longitude(False)
    print(lg1, lg2)
    assert type(lg1) == type(lg2)


# Generated at 2022-06-23 21:04:17.811373
# Unit test for method country of class Address
def test_Address_country():
    from mimesis import Address
    from mimesis.enums import Locale
    addr = Address(Locale.EN)
    assert addr.country() in addr._data['country']['name']

# Generated at 2022-06-23 21:04:29.475197
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address as add
    from mimesis.providers.address import Address as Address
    
    a = Address('en')
    x = add('en')
    b = Address('en')
    c = Address('en')
    d = Address('en')
    e = Address('en')
    
    # Calling this method
    # should either return a string
    # or raise an error.
    assert isinstance(a.address(), str)
    assert isinstance(x.address(), str)
    assert isinstance(b.address(), str)
    assert isinstance(c.address(), str)
    assert isinstance(d.address(), str)

# Generated at 2022-06-23 21:04:30.686033
# Unit test for method city of class Address
def test_Address_city():
    Address().city()



# Generated at 2022-06-23 21:04:34.448142
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.builtins import Address
    address = Address('it')
    key=address.calling_code()
    print(key)
    assert int(key)>=1 and int(key)<=9999


# Generated at 2022-06-23 21:04:36.291923
# Unit test for method state of class Address
def test_Address_state():
    state = Address().state()
    assert isinstance(state, str)
    assert len(state) > 0

# Generated at 2022-06-23 21:04:47.457296
# Unit test for method country_code of class Address
def test_Address_country_code():
    # Address.country_code(fmt=CountryCode.A2)
    assert Address().country_code(fmt=CountryCode.A2) == "ES"
    assert Address().country_code(fmt=CountryCode.A2) == "ID"
    assert Address().country_code(fmt=CountryCode.A2) == "AR"

    # Address.country_code(fmt=CountryCode.A3)
    assert Address().country_code(fmt=CountryCode.A3) == "ESP"
    assert Address().country_code(fmt=CountryCode.A3) == "IDN"
    assert Address().country_code(fmt=CountryCode.A3) == "ARG"

    # Address.country_code(fmt=CountryCode.NUM)

# Generated at 2022-06-23 21:04:49.469121
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address().postal_code() != ""


# Generated at 2022-06-23 21:04:50.358098
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code()

# Generated at 2022-06-23 21:04:51.625883
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''

# Generated at 2022-06-23 21:04:53.085769
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() == -64.762942

# Generated at 2022-06-23 21:04:58.871750
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Check the coordinates of Address"""
    a = Address()
    cood = a.coordinates()
    assert cood.get('longitude') >= -180 and cood.get('longitude') <= 180, "Error in longitude"
    assert cood.get('latitude') >= -90 and cood.get('latitude') <= 90, "Error in latitude"


# Generated at 2022-06-23 21:05:08.050900
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    from pytest import approx
    import re

    locale = 'en'

    a = Address(locale=locale)

    res = a.coordinates()

    assert re.match(r'^-?\d+\.?\d*$', '{longitude}'.format(**res))
    assert re.match(r'^-?\d+\.?\d*$', '{latitude}'.format(**res))

    assert '{longitude}'.format(**res) == approx(-180)
    assert '{latitude}'.format(**res) == approx(-90)

    res = a.coordinates(dms=True)


# Generated at 2022-06-23 21:05:12.742419
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    output = address.province(abbr=True)
    assert isinstance(output, str)


test_Address_province.province_test = True

address = Address()
test_Address_province()
print(address.province(abbr=True))

# Generated at 2022-06-23 21:05:15.527357
# Unit test for method province of class Address
def test_Address_province():
    addr = Address(locale='fr')
    print(addr.province())


if __name__ == '__main__':
    test_Address_province()

# Generated at 2022-06-23 21:05:18.538221
# Unit test for method country_code of class Address
def test_Address_country_code():
    try:
        assert Address().country_code(CountryCode.RANDOM) != ''
    except KeyError:
        print("The format of country code you entered is not supported")

# Generated at 2022-06-23 21:05:24.695693
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Patching class Address
    with patch_locale(DEFAULT_LOCALE):
        # Instantiating object of class Address
        address = Address(DEFAULT_LOCALE)
        # Creating variable zip_code, which contains value of method zip_code of class Address
        zip_code = address.zip_code()
        # Creating variable postal_code of class Address
        postal_code = address.postal_code()
        # Testing zip_code is equal postal_code
        assert zip_code == postal_code


# Generated at 2022-06-23 21:05:25.917196
# Unit test for method state of class Address
def test_Address_state():
    prov = Address('en')
    result = prov.state()
    assert result in prov._data['state']['name']

# Generated at 2022-06-23 21:05:35.391816
# Unit test for method country of class Address
def test_Address_country():
    # Test for locale ch
    ad = Address(locale="ch")
    assert ad.country() == '中国'
    assert ad.country(allow_random=True) in ad._data['country']['name']

    # Test for locale en
    ad = Address(locale="en")
    assert ad.country() == 'United States'
    assert ad.country(allow_random=True) in ad._data['country']['name']

    # Test for locale ru
    ad = Address(locale="ru")
    assert ad.country() == 'Россия'
    assert ad.country(allow_random=True) in ad._data['country']['name']

# Generated at 2022-06-23 21:05:37.152140
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    result = address.continent()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:05:39.324938
# Unit test for method street_number of class Address
def test_Address_street_number():
    print("Street number: ")
    a = Address("zh")
    print(a.street_number(maximum=100))


# Generated at 2022-06-23 21:05:42.598411
# Unit test for method longitude of class Address
def test_Address_longitude():
    addr = Address(locale='en')
    assert type(addr.longitude()) == float
    assert type(addr.longitude(dms=True)) == str


# Generated at 2022-06-23 21:05:46.641356
# Unit test for method continent of class Address
def test_Address_continent():
    continent_name = ['Africa', 'Antarctica', 'Asia', 'Europe',
                      'North America', 'South America', 'Oceania']
    continent_code = ['AF', 'AN', 'AS', 'EU', 'NA', 'SA', 'OC']
    assert Address().continent() in continent_name
    assert Address().continent(True) in continent_code


# Generated at 2022-06-23 21:05:48.427482
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    result = address_obj.address()
    assert result

# Generated at 2022-06-23 21:05:50.672506
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert '+' in Address().calling_code()

# Generated at 2022-06-23 21:05:53.543198
# Unit test for method address of class Address
def test_Address_address():
    a = Address()

    assert isinstance(a.address(), str)
    assert a.address()

# Generated at 2022-06-23 21:05:57.122753
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() in ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']


# Generated at 2022-06-23 21:06:02.306748
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    adr = Address()
    assert isinstance(adr, Address)
    assert isinstance(adr.zip_code(), str)
    assert not isinstance(adr.zip_code(), list)
    assert len(adr.zip_code()) > 0


# Generated at 2022-06-23 21:06:04.234370
# Unit test for method state of class Address
def test_Address_state():
	address = Address()
	assert address.state() == 'Nordrhein-Westfalen'
	assert address.state(abbr=True) == 'NW'


# Generated at 2022-06-23 21:06:06.296627
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    print(a.province(True))
    print(a.province(False))


# Generated at 2022-06-23 21:06:08.541860
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address.__dict__['street_suffix'].__doc__ == \
        'Get a random street suffix.\n\n        :return: Street suffix.\n        '

# Generated at 2022-06-23 21:06:12.856445
# Unit test for method country_code of class Address
def test_Address_country_code():
    r = Address(seed=1)
    assert r.country_code() == 'RU'
    assert r.country_code(fmt=CountryCode.A3) == 'RUS'
    assert r.country_code(fmt=CountryCode.NUM) == '643'
    assert r.country_code(fmt=CountryCode.CALL) == '7'

# Generated at 2022-06-23 21:06:14.081398
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    provider = Address()
    assert provider.federal_subject()

# Generated at 2022-06-23 21:06:15.638178
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    result = Address(providers=['address']).coordinates()
    assert result['longitude']
    assert result['latitude']

# Generated at 2022-06-23 21:06:25.371717
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test method coordinates of class Address."""
    from random import randint

    from mimesis.builtins import Address as AddressBuiltins
    from mimesis.enums import DataFieldProvider
    from mimesis.providers.utils import get_provider_for
    from mimesis.providers.mimesis import Mimesis
    from mimesis.typing import DatetimeData, Locale

    locale: Locale = 'en'
    print(f'locale: {locale}')
    provider: AddressBuiltins = Address(ssn='Test')
    provider.set_locale(locale)

    # Assert Address
    assert isinstance(provider, Address)
    # Assert BaseDataProvider
    assert isinstance(provider, BaseDataProvider)
    # Assert Mimesis

# Generated at 2022-06-23 21:06:30.692027
# Unit test for constructor of class Address
def test_Address():
    """
    Test for constructor of class Address.
    """
    # Normal constructor
    address = Address()
    address.street_number()
    address.street_name()
    address.street_suffix()
    address.address()
    address.state()
    address.region()
    address.province()
    address.federal_subject()
    address.prefecture()
    address.postal_code()
    address.zip_code()
    address.country_code()
    address.country()
    address.city()
    address.latitude()
    address.longitude()
    address.coordinates()
    address.continent()
    address.calling_code()


    # Constructor with locale
    address = Address('fr')
    address.street_number()
    address.street_name()
    address

# Generated at 2022-06-23 21:06:33.235689
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    data = address.longitude()
    assert isinstance(data, str) or isinstance(data, float)

# Generated at 2022-06-23 21:06:37.180501
# Unit test for method province of class Address
def test_Address_province():
    assert len(Address().province()) > 0
    assert len(Address().region()) > 0
    assert len(Address().prefecture()) > 0
    assert len(Address().federal_subject()) > 0
    assert len(Address().province(abbr=True)) > 0
    assert len(Address().region(abbr=True)) > 0
    assert len(Address().prefecture(abbr=True)) > 0
    assert len(Address().federal_subject(abbr=True)) > 0



# Generated at 2022-06-23 21:06:40.476396
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    lat = address.latitude()
    assert type(lat) == float
    assert lat >= -90.0
    assert lat <= 90.0


# Generated at 2022-06-23 21:06:45.958191
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Unit tests for method longitude of class Address

    Returns
    -------
    bool
        True if all tests are passed, otherwise False.
    """
    a = Address()
    lon = a.longitude()
    dms = a.longitude(True)
    assert -180 < lon < 180
    assert len(dms) >= 6
    return True


# Generated at 2022-06-23 21:06:50.267092
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() != Address().continent()
    assert Address().continent(code=True) != Address().continent(code=True)
    assert Address().continent() != Address().continent(code=True)

# Generated at 2022-06-23 21:06:51.446484
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    print(a.street_name())

# Generated at 2022-06-23 21:06:55.591304
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    ad = Address()
    code = ad.country_code(fmt=CountryCode.A3)
    assert (code in COUNTRY_CODES[CountryCode.A3])


# Generated at 2022-06-23 21:06:58.344567
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    addr = Address('en')
    for i in range(10):
        print(addr.postal_code())


# Generated at 2022-06-23 21:07:01.508752
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address(locale='ja_JP')
    a1 = address.prefecture()
    assert isinstance(a1, str)
    assert a1

# Generated at 2022-06-23 21:07:03.407700
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    longitude = address.longitude()
    assert len(str(longitude)) != 0

# Generated at 2022-06-23 21:07:04.754890
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    print(a.street_name())



# Generated at 2022-06-23 21:07:08.805018
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import DataField
    from mimesis.builtins import Address
    a = Address()
    n = a.coordinates()
    print(n)
    assert isinstance(n[DataField.LATITUDE], float)
    assert isinstance(n[DataField.LONGITUDE], float)
    print('Test passed')
if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-23 21:07:09.785801
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() == 'Rd'

# Generated at 2022-06-23 21:07:17.895851
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    from mimesis.enums import Gender
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code

    a = Address(CountryCode.US, 'en')
    for _ in range(2):
        _ = a.coordinates()
        _ = a.coordinates(dms=True)

    p = Person(CountryCode.US, 'en')
    g = Geo(CountryCode.US, 'en')
    c = Code(CountryCode.US, 'en')


# Generated at 2022-06-23 21:07:26.026634
# Unit test for constructor of class Address
def test_Address():
    from mimesis.enums import CountryCode
    from mimesis.exceptions import NonEnumerableError

    address = Address()

    address.latitude()

    address.longitude()

    address.state()

    address.state(abbr=True)

    address.country_code()

    address.country_code(fmt=CountryCode.A2)

    code = address.country_code(fmt=CountryCode.LONG_NAME)

    address.country(allow_random=True)

    address.city()

    address.street_number()

    address.street_suffix()

# Generated at 2022-06-23 21:07:32.754574
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    addr = Address(Datetime())
    assert 'º' in addr.latitude(dms=True)
    assert 'º' in addr.latitude(False)
    assert 'º' in addr.latitude(True)
    assert len(addr.country_code(CountryCode.A2)) == 2
    assert len(addr.country_code(CountryCode.A3)) == 3
    assert len(addr.country_code(CountryCode.NUMERIC)) == 3
    assert len(addr.country_code(CountryCode.NAME)) > 2
    assert addr.calling_code()
    assert addr.country()
    assert addr.state()

# Generated at 2022-06-23 21:07:35.650307
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Test Address.zip_code()."""
    adr = Address()
    assert adr.zip_code() == adr.postal_code()


# Generated at 2022-06-23 21:07:38.194945
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('pt_BR')
    state = address.prefecture()
    # print(state)
    assert isinstance(state, str)
    assert state != ''


# Generated at 2022-06-23 21:07:39.780144
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    for _ in range(10):
        obj = Address()
        obj.calling_code()


# Generated at 2022-06-23 21:07:41.985793
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    b = a.prefecture(True)
    c = a.state(True)
    assert b == c


# Generated at 2022-06-23 21:07:44.028528
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture."""
    address = Address('en')
    assert address.prefecture(True)


# Generated at 2022-06-23 21:07:45.844636
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    str = address.street_name()
    assert str == 'test'
    assert address.street_name() != 'test'


# Generated at 2022-06-23 21:07:52.635027
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    # Выпадает число от 1 до 1400, если нет входных значений
    num = address.street_number()
    assert isinstance(num, str) and int(num) > 0 and int(num) < 1400
    # Выпадает число от 1 до maximum, если есть входное значение
    maximum = 652
    num = address.street_number(maximum)
    assert isinstance(num, str) and int(num) > 0 and int(num) < maximum


# Generated at 2022-06-23 21:07:55.540136
# Unit test for method latitude of class Address
def test_Address_latitude():
    # Create a Address object
    address = Address()
    # Get a random value of latitude
    result = address.latitude()
    # Check that result is in range between -90 and 90
    assert -90 <= result <= 90
    # Check that the length of result is 6
    assert len(str(result)) == 6



# Generated at 2022-06-23 21:07:57.443320
# Unit test for method country of class Address
def test_Address_country():
    addr = Address(locale="en")
    country = addr.country()
    assert country == 'France'

# Generated at 2022-06-23 21:07:59.801462
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address(locale='en')
    assert address.street_name() in address._data['street']['name']


# Generated at 2022-06-23 21:08:02.192743
# Unit test for method coordinates of class Address
def test_Address_coordinates():

    u = Address(seed=4242424242424242)
    for i in range(0, 10):
        print(u.coordinates())

# Generated at 2022-06-23 21:08:03.224219
# Unit test for method country of class Address
def test_Address_country():
    assert Address('en').country() == 'United States'

# Generated at 2022-06-23 21:08:08.273140
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address."""
    addr = Address()
    p = addr.prefecture(False)
    assert p in addr._data['state']['name']
    addr.locale = 'zh_CN'
    p = addr.prefecture(False)
    assert p in addr._data['state']['name']

# Generated at 2022-06-23 21:08:13.026624
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Test method zip_code."""
    address = Address(locale='zh-CN')
    zip_code = address.zip_code()
    assert zip_code.startswith('20')



# Generated at 2022-06-23 21:08:15.941133
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    zip_code = address.zip_code()
    assert zip_code == address.postal_code()

# Generated at 2022-06-23 21:08:19.980939
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('en')
    for _ in range(100):
        x = address.postal_code()
        assert isinstance(x, str)
        assert len(x) == 5
        assert x.isdigit()


# Generated at 2022-06-23 21:08:21.533314
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert address.region() == 'Ontario'
