

# Generated at 2022-06-23 20:58:21.670488
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address(locale="zh")
    assert address.calling_code() in CALLING_CODES

# Generated at 2022-06-23 20:58:24.338217
# Unit test for method country of class Address
def test_Address_country():
    test_Address = Address()
    # Check for current locale
    print(test_Address.country())
    # Check for random country
    print(test_Address.country(allow_random=True))


# Generated at 2022-06-23 20:58:27.051596
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.builtins import RussiaSpecProvider
    return Address(RussiaSpecProvider).state()


# Generated at 2022-06-23 20:58:28.042731
# Unit test for method state of class Address
def test_Address_state():
    provider = Address("en")
    assert(provider.state())



# Generated at 2022-06-23 20:58:33.227423
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    '''
    Проверяет возвращение региона России
    :return:
    '''
    from mimesis import address
    ad = address.Address('ru')
    assert ad.federal_subject() in ad._data['state']['name_ru']


# Generated at 2022-06-23 20:58:36.107839
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    ad = Address()
    assert len(ad.zip_code()) == 6



# Generated at 2022-06-23 20:58:48.522578
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Method for testing coordinates() method."""
    _address = Address()
    _coords = _address.coordinates()

    assert isinstance(_coords, dict), 'Invalid type'

    assert isinstance(_coords['longitude'], float), \
        'Invalid type of longitude'
    assert isinstance(_coords['latitude'], float), \
        'Invalid type of latitude'

    assert -90 <= _coords['latitude'] <= 90, \
        'Invalid value'
    assert -180 <= _coords['longitude'] <= 180, \
        'Invalid value'

    _coords = _address.coordinates(dms=True)
    assert isinstance(_coords, dict), \
        'Invalid type of coordinates'

    _lat = _coords['latitude']

# Generated at 2022-06-23 20:58:53.328895
# Unit test for method street_number of class Address
def test_Address_street_number():
    # We test the method with a maximum value and without it
    # We also test that it gives us a number from 1 to 1400
    from mimesis.enums import DatetimeUnit
    random = DatetimeUnit.MINUTE.name
    assert Address(random).street_number() >= 1 and Address(random).street_number() <= 1400
    assert Address(random).street_number() >= 1 and Address(random).street_number() <= 10


# Generated at 2022-06-23 20:59:04.189260
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Remove trailing zeroes, it will be ignored when comparing with test data.
    # Pattern is required, otherwise removed zeroes can brake next code by wrong
    # removal.
    pattern = '00'

# Generated at 2022-06-23 20:59:07.274047
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    province = address.province(abbr=True)
    assert isinstance(province, str)
    assert province in address._data['state']['abbr']
    return


# Generated at 2022-06-23 20:59:08.881435
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address().postal_code().isnumeric()

# Generated at 2022-06-23 20:59:19.550743
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    from mimesis.data import CONTINENT_CODES

    a = Address('en')
    b = Address('ru')
    c = Address('fr')
    
    assert a.state() in a._data['state']['name']
    assert b.state() in b._data['state']['name']
    assert c.state() in c._data['state']['name']

    assert a.state(abbr = True) in a._data['state']['abbr']
    assert b.state(abbr = True) in b._data['state']['abbr']
    assert c.state(abbr = True) in c._data['state']['abbr']
    pass


# Generated at 2022-06-23 20:59:21.308706
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert len(a.calling_code()) == 3


# Generated at 2022-06-23 20:59:23.378278
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() != "Address1\tAddress2"
    print("Test passed")


# Generated at 2022-06-23 20:59:29.291603
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """
    1. Create new Address()
    2. generate number of coordinates,
        coordinates = Address().coordinates()
    3. check, that every coordinate (longitude, latitude)
        has type ``float``
    """
    provider = Address()
    num = 100
    while num:
        coordinates = provider.coordinates()
        assert isinstance(coordinates['longitude'], float)
        assert isinstance(coordinates['latitude'], float)
        num -= 1


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-23 20:59:30.170940
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    print(a.region(True))

# Generated at 2022-06-23 20:59:32.579808
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    x = -75.32818099999999
    x1 = address.longitude()

    assert x == x1


# Generated at 2022-06-23 20:59:41.113909
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test the method coordinates of class Address."""
    from mimesis.builtins import Address as Address1
    from mimesis.enums import LatLong

    add=Address1()
    res=add.coordinates(dms=False)
    keys=res.keys()
    assert 'longitude' in keys
    assert 'latitude' in keys
    assert len(res.keys()) == 2
    res=add.coordinates(dms=True)
    keys=res.keys()
    assert 'longitude' in keys
    assert 'latitude' in keys
    assert len(res.keys()) == 2
    assert isinstance(res['latitude'],str)
    assert isinstance(res['longitude'],str)

# Generated at 2022-06-23 20:59:42.384758
# Unit test for constructor of class Address
def test_Address():
    address = Address('ru')


# Generated at 2022-06-23 20:59:46.936387
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address(
        'en').continent() in (
        'Africa', 'Americas', 'Asia', 'Europe', 'Oceania')
    assert Address(
        'en').continent(code=True) in ('AF', 'AS', 'EU', 'NA', 'OC', 'SA', 'AN')



# Generated at 2022-06-23 20:59:48.758445
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a1 = Address()
    result = a1.prefecture()
    assert isinstance(result, str)


# Generated at 2022-06-23 20:59:51.339228
# Unit test for method street_number of class Address
def test_Address_street_number():
    import random
    s = Address()
    maximum = random.randint(1, 1400)
    assert int(s.street_number(maximum)) <= maximum


# Generated at 2022-06-23 20:59:54.168580
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.builtins import RussiaSpecProvider

    a = Address('ru')
    b = RussiaSpecProvider('ru')
    assert a.province() in b.regions_list()


# Generated at 2022-06-23 20:59:56.624117
# Unit test for method region of class Address
def test_Address_region():
    address=Address('en')
    state=address.region(abbr=True)
    print(state)
    #Output: 'TN'



# Generated at 2022-06-23 21:00:01.794951
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for method federal_subject of class Address."""
    address_ru = Address('ru')

    assert address_ru.federal_subject() in address_ru._data['state']['name']

# Generated at 2022-06-23 21:00:07.237226
# Unit test for method city of class Address
def test_Address_city():
    a1 = Address('en')
    city_a1_0 = a1.city()
    city_a1_1 = a1.city()
    city_a1_0
    city_a1_1

    a2 = Address('es')
    city_a2_0 = a2.city()
    city_a2_1 = a2.city()
    city_a2_0
    city_a2_1

    a3 = Address('ru')
    city_a3_0 = a3.city()
    city_a3_1 = a3.city()
    city_a3_0
    city_a3_1

    a4 = Address('ja')
    city_a4_0 = a4.city()
    city_a4_1 = a4.city()
    city_

# Generated at 2022-06-23 21:00:09.402385
# Unit test for method continent of class Address
def test_Address_continent():
    """get result and print.

    :return: void
    """

    address = Address()
    print(address.continent(code=True))

# Generated at 2022-06-23 21:00:10.955685
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:00:12.392871
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    for i in CountryCode:
        print(address.country_code(i))

if __name__ == '__main__':
    test_Address_country_code()

# Generated at 2022-06-23 21:00:14.396142
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    assert type(a.street_suffix()) is str


# Generated at 2022-06-23 21:00:16.997427
# Unit test for method region of class Address
def test_Address_region():
    address = Address('en')
    print(address.region())
    print(address.region(abbr=True))

# Generated at 2022-06-23 21:00:28.262897
# Unit test for method country_code of class Address
def test_Address_country_code():
    a= Address(locale='ja')
    try:
        m= a.country_code(fmt=CountryCode.A3)
    except KeyError:
        print("Test for CountryCode.A3 Passed")

    try:
        m= a.country_code(fmt=CountryCode.A2)
        print("Test for CountryCode.A2 Passed")
    except KeyError:
        pass

    try:
        m= a.country_code(fmt=CountryCode.NUMERIC)
        print("Test for CountryCode.NUMERIC Passed")
    except KeyError:
        pass

    try:
        m= a.country_code(CountryCode.A2)
        print("Test for CountryCode.A2 Passed")
    except KeyError:
        pass


# Generated at 2022-06-23 21:00:29.700165
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address('ja').prefecture() in Address('ja')._data['state']['abbr']


# Generated at 2022-06-23 21:00:31.400911
# Unit test for method city of class Address
def test_Address_city():
    address = Address.create()
    assert address.city() == '西安'


# Generated at 2022-06-23 21:00:34.219313
# Unit test for method street_number of class Address
def test_Address_street_number():
    for _ in range(100):
        num = Address().street_number(maximum = 100)
        assert 0 < int(num) < 100


# Generated at 2022-06-23 21:00:39.332134
# Unit test for method country_code of class Address
def test_Address_country_code():
    a1 = Address(locale='zh')
    a2 = Address(locale='zh')
    print(a1.country_code(CountryCode.A2))
    print(a2.country_code(CountryCode.A3))

if __name__ == '__main__':
    test_Address_country_code()

# Generated at 2022-06-23 21:00:40.848669
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert address.federal_subject() in address._data['state']['name']

# Generated at 2022-06-23 21:00:44.966125
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.providers.address import Address
    address = Address()
    coord_list = []
    for i in range(1,1000):
        coord = address.coordinates()
        coord_list.append(coord)
    with open("C:/Users/kyleg/Desktop/coord_data.txt", 'a') as f:
        for coord in coord_list:
            f.write(str(coord))
            f.write("\n")
        f.close()

# Generated at 2022-06-23 21:00:47.878577
# Unit test for method country of class Address
def test_Address_country():
    address = Address("en")
    print("Country = " + address.country())
    print("Country = " + address.country(True))


# Generated at 2022-06-23 21:00:49.676001
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    print('address.coordinates() =', address.coordinates())
    print('address.coordinates() =', address.coordinates(True))


if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-23 21:00:51.336048
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent(code=True) == 'EU'

# Generated at 2022-06-23 21:00:56.852169
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for class method country_code(self, fmt=None)"""
    address = Address()
    assert address.country_code() in COUNTRY_CODES[CountryCode.A2]
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert address.country_code(CountryCode.Numeric) in COUNTRY_CODES[CountryCode.Numeric]


# Generated at 2022-06-23 21:01:07.466804
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    add = Address()
    assert isinstance(add.country_code(), str)
    assert add.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert add.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert add.country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]
    assert add.country_code(CountryCode.ALL) in COUNTRY_CODES[CountryCode.A2] + COUNTRY_CODES[CountryCode.A3] + COUNTRY_CODES[CountryCode.NUMERIC]

# Generated at 2022-06-23 21:01:12.148756
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Unit test for method longitude of class Address
    import unittest
    import re

    from mimesis.providers.address import Address

    class TestAddress(unittest.TestCase):

        def setUp(self):
            self.address = Address('en')

        def test_longitude(self):
            longitude = self.address.longitude()
            self.assertIsInstance(longitude, float)
            self.assertTrue(re.match(r'-\d*.\d{6}', str(longitude)))

    unittest.main()

# Unit Test for method longitude of class Address
test_Address_longitude()

# Generated at 2022-06-23 21:01:15.402466
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    code = address.calling_code()
    assert code in CALLING_CODES

# Generated at 2022-06-23 21:01:18.654028
# Unit test for method region of class Address
def test_Address_region():
    obj = Address('en')
    res = obj.region()
    assert res in obj._data['state']['name']

# end unit test


# Generated at 2022-06-23 21:01:26.645202
# Unit test for constructor of class Address
def test_Address():
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    c = Address()
    assert c is not None 
    assert c.__class__.__name__ == "Address"
    assert c.country("Spain") == "Spain"
    assert c.country("Spain", allow_random=True) in ["Spain", "Morocco"]
    assert c.country("Spain", code=CountryCode.A3) == "ESP"
    assert c.country("Spain", code=CountryCode.A2) == "ES"
    assert c.country("Spain", code=CountryCode.NUMERIC) == "724"

# Generated at 2022-06-23 21:01:28.710021
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    assert a.zip_code().isdigit()
    assert len(a.zip_code()) > 3


# Generated at 2022-06-23 21:01:37.442115
# Unit test for method continent of class Address
def test_Address_continent():
    c = {"ru": "Евразия", "pt": "África", "en": "Oceania", "de": "Europa", "fr": "Afrique", "es": "Asia", "id": "Asia", "it": "Oceania", "ar": "أفريقيا", "ja": "アジア", "ko": "아시아", "tr": "Avrupa", "uk": "Азія"}
    for k in c:
            assert Address(k).continent() == c[k]


# Generated at 2022-06-23 21:01:38.511750
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()

    assert address.longitude() < 180.0 and address.longitude() > -180.0

# Generated at 2022-06-23 21:01:39.489226
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() == '0'

# Generated at 2022-06-23 21:01:40.340731
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    print(Address().federal_subject())

# Generated at 2022-06-23 21:01:42.715029
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    assert [
        'longitude', 'latitude'
    ] == list((Address().coordinates()).keys())

# Generated at 2022-06-23 21:01:45.638943
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    zipcode = address.zip_code()
    assert zipcode
    assert isinstance(zipcode, str)


# Generated at 2022-06-23 21:01:47.987774
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.builtins import Address
    generate = Address()
    result = generate.zip_code()
    assert result == '86030'



# Generated at 2022-06-23 21:01:54.632660
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Test Address().latitude()"""
    from mimesis.enums import CountryCode
    from mimesis.localization import Localization
    for i in ['en', 'en']:
        for j in [CountryCode.A2, CountryCode.A3, CountryCode.NAME]:
            if j is CountryCode.NAME:
                assert len(CountryCode.A2.value) == len(Address(i).country(j))

            assert len(CountryCode.A2.value) == len(Address(i).country_code(j))

# Generated at 2022-06-23 21:01:58.324155
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address(seed=7)
    assert address.calling_code() == '966'

    # Second test
    address = Address(seed=15)
    assert address.calling_code() == '685'

    # Third test
    address = Address(seed=23)
    assert address.calling_code() == '993'


# Generated at 2022-06-23 21:01:59.308918
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    state = address.state()


# Generated at 2022-06-23 21:02:00.670425
# Unit test for method province of class Address
def test_Address_province():
    global province
    province = address.province()
    print("The province name is {}".format(province))


# Generated at 2022-06-23 21:02:02.471046
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address('en')
    for _ in range(100):
        result = address.continent()
        assert len(result) == 2
        assert result in CONTINENT_CODES

# Generated at 2022-06-23 21:02:04.991909
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    print("Test for Address_calling_code")
    for i in range(10):
        assert Address().calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:02:08.025640
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    b = a.street_name()
    assert type(b) == str
    print(b)


# Generated at 2022-06-23 21:02:11.798523
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates of class Address"""
    a = Address(locale='en')
    result = a.coordinates(True)
    assert type(result) == dict
    assert type(result['longitude']) == str
    assert type(result['latitude']) == str

# Generated at 2022-06-23 21:02:13.972799
# Unit test for method region of class Address
def test_Address_region():
    # Return a random administrative district of country.
    result = Address().region()
    assert len(result) > 0

# Generated at 2022-06-23 21:02:24.037837
# Unit test for constructor of class Address
def test_Address():
    address_obj = Address()
    street_number_obj = address_obj.street_number()
    street_name_obj = address_obj.street_name()
    street_suffix_obj = address_obj.street_suffix()
    address_obj = address_obj.address()
    state_obj = address_obj.state()
    country_code_obj = address_obj.country_code()
    city_obj = address_obj.city()
    postal_code_obj = address_obj.postal_code()
    country_obj = address_obj.country()
    continent_obj = address_obj.continent()
    calling_code_obj = address_obj.calling_code()
    latitude_obj = address_obj.latitude()
    longitude_obj = address_obj.longitude()

# Generated at 2022-06-23 21:02:26.686377
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    provider = Address()
    result = provider.calling_code()
    assert len(result) == 4
    print(result)

# Generated at 2022-06-23 21:02:28.282275
# Unit test for method city of class Address
def test_Address_city():
    """Test method city."""
    a = Address()
    print(a.city())

# Generated at 2022-06-23 21:02:30.809605
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert isinstance(address, Address)

# Generated at 2022-06-23 21:02:33.587970
# Unit test for method latitude of class Address
def test_Address_latitude():
    add = Address()
    lt_1 = add.latitude()
    lt_2 = add.latitude(dms=True)
    assert str(lt_2) != str(lt_1)



# Generated at 2022-06-23 21:02:37.070042
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address('en')
    b = a.coordinates()
    assert isinstance(b, dict)
    assert len(b) == 2
    assert isinstance(b['latitude'], float)
    assert isinstance(b['longitude'], float)


# Generated at 2022-06-23 21:02:37.974481
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    Address().zip_code()



# Generated at 2022-06-23 21:02:40.300133
# Unit test for constructor of class Address
def test_Address():  
    address = Address()
    print(address.address())
    print(address.calling_code())
 


# Generated at 2022-06-23 21:02:42.852849
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert type(address.region()) == str
    assert len(address.region()) > 0

test_Address_region()


# Generated at 2022-06-23 21:02:44.769345
# Unit test for method city of class Address
def test_Address_city():
    a = Address("zh")
    assert a.city()
    

# Generated at 2022-06-23 21:02:46.059912
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    print(address.calling_code())


# Generated at 2022-06-23 21:02:56.119593
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    locale = 'ru'
    a = Address(locale)
    assert a.state() == 'Санкт-Петербург'
    assert a.state(abbr=True) == 'СПб'

    assert a.province() == 'Санкт-Петербург'
    assert a.region() == 'Санкт-Петербург'
    assert a.federal_subject() == 'Санкт-Петербург'

    # Because Japan has a unique state system,
    # only this method will

# Generated at 2022-06-23 21:02:58.593505
# Unit test for method province of class Address
def test_Address_province():
    def count_repetitions(item):
        set_item = set(item)
        return any(item.count(x) > 1000 for x in set_item)
    assert count_repetitions([Address().province() for _ in range(10000)]) == True

# Generated at 2022-06-23 21:03:00.632525
# Unit test for method latitude of class Address
def test_Address_latitude():
    lat = Address().latitude()
    assert abs(lat) < 91


# Generated at 2022-06-23 21:03:03.328739
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address(['en'])
    assert a.federal_subject() in a._data['state']['abbr']

# Generated at 2022-06-23 21:03:04.823176
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    print(a.continent())

# Generated at 2022-06-23 21:03:06.908611
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert len(address.postal_code()) == 5


# Generated at 2022-06-23 21:03:10.299483
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    
    a = Address(seed=1)
    # test default format
    assert a.street_suffix() =="St"

    # test fixed format
    assert a.street_suffix("fixed") =="St"



# Generated at 2022-06-23 21:03:19.554700
# Unit test for method state of class Address
def test_Address_state():
    import re
    import pytest
    from mimesis.enums import Locale
    from mimesis.exceptions import NonEnumerableError

    en = Address(locale=Locale.EN)
    zh = Address(locale=Locale.ZH)
    ru = Address(locale=Locale.RU)
    ro = Address(locale=Locale.RO)
    fr = Address(locale=Locale.FR)
    ja = Address(locale=Locale.JA)
    it = Address(locale=Locale.IT)

    with pytest.raises(NonEnumerableError):
        Address(locale='xxx').state()

    assert re.match(r'^[A-Z]{2}$', en.state(abbr=True))

# Generated at 2022-06-23 21:03:21.545994
# Unit test for method street_number of class Address
def test_Address_street_number():
    provider = Address()
    result = provider.street_number()
    assert result
    assert isinstance(result, str)


# Generated at 2022-06-23 21:03:24.618488
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address(locale='zh')
    result = address.country_code()
    print(result)
    assert isinstance(result, str) is True


# Generated at 2022-06-23 21:03:26.617536
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert isinstance(address.street_name(), str)


# Generated at 2022-06-23 21:03:29.953764
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test longitude method of Address class."""
    a = Address()
    longitude = a.longitude()
    assert isinstance(longitude, float)
    assert longitude > -180 and longitude < 180


# Generated at 2022-06-23 21:03:32.264159
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address("ru")
    assert address.street_number(maximum=1400) == "56"


# Generated at 2022-06-23 21:03:34.317286
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() in ('Africa', 'Antarctica', 'Asia', 'Europe', 'North_America', 'South_America', 'Oceania')

# Generated at 2022-06-23 21:03:36.943448
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    address = Address(locale='en_GB')
    lon = address.longitude()
    assert (lon >= -180 and lon <= 180)
    
test_Address_longitude()

# Generated at 2022-06-23 21:03:42.460389
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import Country
    from mimesis.providers.address import Address

    region_values = [
        'US-WA', 'US-MN', 'US-PR', 'US-VI', 'US-VI', 'US-TX',
        'US-LA', 'US-TX', 'US-PR', 'US-PR', 'US-PR', 'US-NY',
        'US-HI', 'US-OH', 'US-OH', 'US-OH', 'US-VI', 'US-CT'
    ]

    address = Address(Country.UNITED_STATES)
    regions = [address.region() for _ in range(len(region_values))]
    assert regions == region_values

# Generated at 2022-06-23 21:03:43.748900
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # Create a Address object
    obj = Address()
    # Get a federal subject
    result = obj.federal_subject()
    # Check that result is a not null
    assert result != None

# Generated at 2022-06-23 21:03:47.850348
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('en')
    suffix = address.street_suffix()

    assert type(suffix) is str
    # Length of suffix is not grater then 4
    assert len(suffix) <= 4
    # Suffix is not empty
    assert len(suffix) != 0


# Generated at 2022-06-23 21:03:49.966164
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert type(address.street_name()) == str


# Generated at 2022-06-23 21:03:52.396942
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    print(a.coordinates())

if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-23 21:04:00.661323
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test for country code"""
    assert Address().country_code() in ['FR', 'GB', 'DE', 'RU', 'US', 'IT', 'JP']
    assert isinstance(Address().country_code(fmt=CountryCode.A3), str)
    assert Address().country_code(fmt=CountryCode.A3) in ['FRA', 'GBR', 'DEU', 'RUS', 'USA', 'ITA', 'JPN']
    assert isinstance(Address().country_code(fmt=CountryCode.Numeric), str)
    assert Address().country_code(fmt=CountryCode.Numeric) in ['250', '826', '276', '643', '840', '380', '392']


# Generated at 2022-06-23 21:04:02.265212
# Unit test for method city of class Address
def test_Address_city():
    address=Address()
    assert address.city() is not None


# Generated at 2022-06-23 21:04:07.317768
# Unit test for method country_code of class Address
def test_Address_country_code():
    for i in range(10):
        locale = get_random_locale()
        address = Address(locale)
        country_code_a2 = address.country_code()

        assert len(country_code_a2) == 2


# Generated at 2022-06-23 21:04:09.531216
# Unit test for method street_name of class Address
def test_Address_street_name():
    # Init object Address
    addr = Address()
    # Get street name
    street = addr.street_name()

    return street


# Generated at 2022-06-23 21:04:12.205887
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None
    # Check json file.

    assert 'address.json' in str(address)



# Generated at 2022-06-23 21:04:16.315680
# Unit test for method street_name of class Address
def test_Address_street_name():
    """Test for method street_name of class Address."""
    address = Address()
    result = address.street_name()
    assert type(result) is str
    assert len(result.split(" ")) > 1


# Generated at 2022-06-23 21:04:17.543101
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    lat = address.latitude()
    assert lat is not None
    assert isinstance(lat, float)


# Generated at 2022-06-23 21:04:20.474590
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr=Address('zh')
    street_name=addr.street_name()
    print(street_name)
    assert street_name==street_name


# Generated at 2022-06-23 21:04:24.140380
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a1 = Address(locale='it')
    result = a1.postal_code()
    print(result)


if __name__ == '__main__':
    test_Address_postal_code()

# Generated at 2022-06-23 21:04:26.136258
# Unit test for method street_name of class Address
def test_Address_street_name():
    street_name = Address().street_name()

# Generated at 2022-06-23 21:04:29.648701
# Unit test for method street_number of class Address
def test_Address_street_number():

    # Create an instance of Address class
    instance_of_Address = Address()

    assert len(instance_of_Address.street_number()) >= 1
    assert len(instance_of_Address.street_number()) <= 4



# Generated at 2022-06-23 21:04:36.785702
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.localization import en

    fr = en.Address(locale='fr')
    dms = fr.coordinates(dms=True)
    print(dms)

    expected_keys = {'longitude', 'latitude'}
    expected_type = dict
    assert all([i in expected_keys for i in dms])
    assert isinstance(dms, expected_type)

# Generated at 2022-06-23 21:04:39.488372
# Unit test for method state of class Address
def test_Address_state():
    """ Test method state of class Address."""
    a = Address()
    assert a.state() == "Hessen"

# Generated at 2022-06-23 21:04:43.613650
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    lat = a._get_fs('lt', dms=False)
    lg = a._get_fs('lg', dms=False)
    assert type(lat) == float
    assert type(lg) == float
    assert lat >= -90
    assert lat <= 90
    assert lg >= -180
    assert lg <= 180

# Generated at 2022-06-23 21:04:44.852920
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test function."""
    pass


# Generated at 2022-06-23 21:04:46.642924
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert address.address() is not None


# Generated at 2022-06-23 21:04:47.581245
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() != Address().latitude()

# Generated at 2022-06-23 21:04:57.220404
# Unit test for method street_name of class Address
def test_Address_street_name():
    import os
    path = os.path.dirname(os.path.abspath(__file__)) + '/address.json'
    with open(path) as file:
        street_names = file.read()
    
    street_name_list = street_names.split('\n')
    del street_name_list[-1]
    print(street_name_list)
    addr = Address()
    
    for i in range(0,1000):
        street_name = addr.street_name()
        error = street_name not in street_name_list
        assert error==False


# Generated at 2022-06-23 21:04:59.060423
# Unit test for method province of class Address
def test_Address_province():
    """Test a random province of a country."""
    assert 'province' in Address().province()


# Generated at 2022-06-23 21:05:05.062072
# Unit test for method address of class Address
def test_Address_address():
    addr = Address(locale='en')
    full_addr = addr.address()
    street_name = addr.street_name()
    street_number = addr.street_number()
    street_suffix = addr.street_suffix()
    assert full_addr.startswith(street_number)
    assert street_name in full_addr
    if addr.locale != 'ja':
        assert street_suffix in full_addr


# Generated at 2022-06-23 21:05:07.053156
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    # Return a random value of latitude
    a = address.latitude()
    assert (-90 <= a and a <= 90)


# Generated at 2022-06-23 21:05:10.121101
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address."""
    address = Address('en')
    country_code = address.country_code()
    assert len(country_code) in (2, 3)

# Generated at 2022-06-23 21:05:12.428415
# Unit test for method street_name of class Address
def test_Address_street_name():
    z = Address('en')
    address = z.street_name()
    assert address is not None


# Generated at 2022-06-23 21:05:15.113044
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address(locale='en')
    res = address.latitude()
    assert type(res) == float
    assert (res > -90 and res < 90) == True

# Generated at 2022-06-23 21:05:17.434912
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    print("Test of method coordinates of class Address")
    address = Address()
    print(address.coordinates())


# Generated at 2022-06-23 21:05:20.290189
# Unit test for method latitude of class Address
def test_Address_latitude():
    """
    Test method latitude of class Address
    """
    locale = 'en'
    a = Address(locale)
    assert a.latitude()


# Generated at 2022-06-23 21:05:22.059546
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Assert
    assert (Address().calling_code() in CALLING_CODES)


# Generated at 2022-06-23 21:05:29.252524
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
	from mimesis.enums import CountryCode
	addr = Address(locale='ru-RU')

# Generated at 2022-06-23 21:05:33.214881
# Unit test for constructor of class Address
def test_Address():
    """Test for Address class."""
    ad = Address()
    # Name of current locale
    assert 'United States' in ad.country()
    # Current locale
    assert 'ru' in ad.country(True)


# Generated at 2022-06-23 21:05:36.455610
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    adr = Address()
    x = adr.federal_subject()
    assert x in adr._data['state']['name']


# Generated at 2022-06-23 21:05:38.180824
# Unit test for method street_name of class Address
def test_Address_street_name():
  address = Address()
  address.street_name()


# Generated at 2022-06-23 21:05:39.354298
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    for _ in range(100):
        assert Address().calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:05:42.598181
# Unit test for method province of class Address
def test_Address_province():
    address = Address()

    from mimesis.enums import CountryCode

    assert address.province(abbr=True) in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-23 21:05:43.951321
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # FIXME: write some tests
    pass


# Generated at 2022-06-23 21:05:50.424911
# Unit test for method latitude of class Address
def test_Address_latitude():
    # given
    from mimesis.builtins import Address
    from mimesis.enums import Locale

    # when
    en_address = Address(Locale.EN)
    ru_address = Address(Locale.RU)

    latitude_en = en_address.latitude()
    latitude_ru = ru_address.latitude()

    # then
    assert type(latitude_en) is float
    assert type(latitude_ru) is float


# Generated at 2022-06-23 21:05:57.742340
# Unit test for method region of class Address
def test_Address_region():
    test = Address('en')
    result = test.region()

# Generated at 2022-06-23 21:05:59.923942
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() in ('Maple', 'Walnut', 'Elm', 'Main', 'Brick', 'Cornwall')
    return True


# Generated at 2022-06-23 21:06:01.381192
# Unit test for method country of class Address
def test_Address_country():
    """Test method country from class Address."""
    address = Address('ru')
    assert address.country() == 'Россия'

# Generated at 2022-06-23 21:06:02.610634
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    res = Address(Locale.EN).address()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:06:06.771944
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    assert a.street_number() == '1'
    assert a.street_number() == '1'
    assert a.street_number() == '1'
    assert a.street_number() == '1'
    assert a.street_number() == '1'
    assert a.street_number() == '1'

# Generated at 2022-06-23 21:06:08.333535
# Unit test for constructor of class Address
def test_Address():
    """Testing `Address` class."""
    address = Address('ru')
    assert address
    assert address.random

# Generated at 2022-06-23 21:06:09.195957
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert '+689' == Address().calling_code()

# Generated at 2022-06-23 21:06:11.216419
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Test Address().street_number()."""
    assert Address().street_number(maximum=10) == '5'


# Generated at 2022-06-23 21:06:18.773556
# Unit test for method street_name of class Address

# Generated at 2022-06-23 21:06:20.985574
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    code = a.calling_code()
    assert type(code) == str
    assert len(code) == 3

# Generated at 2022-06-23 21:06:21.961275
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    street_number = address.street_number()
    print(street_number)


# Generated at 2022-06-23 21:06:24.552514
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()
    print(result)
    assert type(result) == str
    assert result in address._data['state']['name']


# Generated at 2022-06-23 21:06:27.242094
# Unit test for method region of class Address
def test_Address_region():
    Address.region()
    Address.region(abbr=True)
    Address.region(abbr=False)


# Generated at 2022-06-23 21:06:29.668135
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture in class Address."""
    obj = Address()
    assert isinstance(obj.prefecture(), str)

# Generated at 2022-06-23 21:06:34.626250
# Unit test for method coordinates of class Address
def test_Address_coordinates():

    from pprint import pprint
    from mimesis.enums import CountryCode

    _address_=Address(locale='en')

    a = _address_.coordinates()
    print('Address():')
    pprint(a)
    assert a['latitude'] 
    assert a['longitude']

# Generated at 2022-06-23 21:06:35.947520
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    print(a.street_number())


# Generated at 2022-06-23 21:06:39.074391
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    country = a.country()
    # print("年龄:"+country)
    assert isinstance(country, str)


# Generated at 2022-06-23 21:06:39.831091
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.builtins import Address
    a = Address()
    assert len(a.street_suffix()) > 1

# Generated at 2022-06-23 21:06:45.754946
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    ex = ['84-239', '05-170', '73-215', '63-895', '48-352']
    print("\nunit test for method postal_code of class Address")

    for i in range(5):
        adr = Address("pl")
        print(i + 1, adr.postal_code())
        assert (adr.postal_code() in ex)


# Generated at 2022-06-23 21:06:53.883255
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    import pytest

    address_check = Address()
    address_check.seed(0)
    assert address_check.federal_subject() == 'Адыгея'
    assert address_check.federal_subject() == 'Алтай'

    address_check.seed(1)
    assert address_check.federal_subject() == 'Алтай'
    assert address_check.federal_subject() == 'Амурская'

    with pytest.raises(NotImplementedError):
        Address(locale='es').federal_subject()


# Generated at 2022-06-23 21:06:57.609672
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Create a instance of Address
    address = Address()
    # Test method calling_code of class Address
    assert len(address.calling_code()) == 3


# Generated at 2022-06-23 21:07:01.001297
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('en')
    assert address.prefecture() == 'ME'
    assert address.prefecture(abbr=False) == 'Maine'


# Generated at 2022-06-23 21:07:03.064569
# Unit test for method continent of class Address
def test_Address_continent():
    """Unit test for method continent of class Address."""
    address = Address()
    assert address.continent() in address._data['continent']


# Generated at 2022-06-23 21:07:04.443898
# Unit test for method country of class Address
def test_Address_country():
    addr = Address()
    assert len(addr.country()) in range(10)

# Generated at 2022-06-23 21:07:07.526721
# Unit test for constructor of class Address
def test_Address():
    """Test case for constructor of Address() class."""
    address = Address()
    assert address.__class__.__name__ == 'Address'


# Generated at 2022-06-23 21:07:09.600199
# Unit test for constructor of class Address
def test_Address():
    test_obj = Address("en")
    assert(test_obj.address() != test_obj.address())


# Generated at 2022-06-23 21:07:10.952497
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address(locale="en")
    address.street_name()

# Generated at 2022-06-23 21:07:11.537579
# Unit test for method province of class Address
def test_Address_province():
    pass

# Generated at 2022-06-23 21:07:14.559171
# Unit test for method province of class Address
def test_Address_province():
    provider = Address(locale='en')
    assert provider.province() == 'MT'
    assert provider.province(abbr=True) == 'MT'
    assert provider.province() == 'Mato Grosso'


# Generated at 2022-06-23 21:07:16.729308
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    street_suffix = address.street_suffix()
    assert street_suffix in ['Ave', 'Blvd', 'St', 'Rd', 'Ct', 'Pl']

# Generated at 2022-06-23 21:07:18.858895
# Unit test for method street_name of class Address
def test_Address_street_name():
    result = Address.Address().street_name()
    assert result in ['Alabama', 'Texas']


# Generated at 2022-06-23 21:07:21.412922
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.builtins import address
    addr = address.Address()
    assert addr.latitude() in [-90, 90]


# Generated at 2022-06-23 21:07:25.021958
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    assert isinstance(a.prefecture(), str)
    assert a.prefecture() == a.random.choice(a._data['state']['abbr'] or a._data['state']['name'])
    

# Generated at 2022-06-23 21:07:26.228221
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None


# Generated at 2022-06-23 21:07:30.241923
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Method will return random prefecture of random country
    """
    addr = Address()
    prefecture = addr.prefecture()
    assert len(prefecture) > 0

# Generated at 2022-06-23 21:07:41.238357
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode

    a = Address('ru')
    assert a.latitude()
    result = a.latitude(True)
    assert 'º' in result
    assert '\'' in result
    assert '"' in result
    assert type(a.latitude()) == float
    result = a.latitude(True)
    assert type(result) == str

    a = Address('ru')
    assert a.latitude()
    result = a.latitude(True)
    assert 'º' in result
    assert '\'' in result
    assert '"' in result
    assert type(a.latitude()) == float
    result = a.latitude(True)
    assert type(result) == str

    a = Address('ru')
    assert a.latitude()
    result = a.latitude

# Generated at 2022-06-23 21:07:42.579274
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    print(address.street_suffix())


# Generated at 2022-06-23 21:07:44.228576
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    assert address.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:07:45.742823
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address(locale = "en_US")
    isinstance(address.street_name(), str)


# Generated at 2022-06-23 21:07:47.974311
# Unit test for method state of class Address
def test_Address_state():
    obj = Address(locale='fr')
    lst = [obj.state() for i in range(10)]
    assert all(['Ile-de-France' in str(i) for i in lst])


# Generated at 2022-06-23 21:07:50.381476
# Unit test for method country of class Address
def test_Address_country():
    """Test country of class Address.
    """
    addr = Address()

    country = addr.country()
    assert isinstance(country, str)
    assert country is not None
    assert len(country) > 0


# Generated at 2022-06-23 21:07:51.809425
# Unit test for method continent of class Address
def test_Address_continent():
    obj = Address()
    assert len(obj.continent()) >= 2
    assert len(obj.continent(code=True)) >= 2



# Generated at 2022-06-23 21:08:02.616113
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.builtins import Address
    from mimesis.enums import Country
    from mimesis.providers.base import BaseDataProvider

    class CustomAddress(Address):
        def __init__(self, seed=None, *args, **kwargs):
            super().__init__(seed=seed, *args, **kwargs)
            self.random.choice = BaseDataProvider._custom_random_choice
            self.random.uniform = BaseDataProvider._custom_random_uniform

    a = CustomAddress(seed=42, locale=Country.MOLDOVA)
    assert a.coordinates() == {'longitude': -70.698219, 'latitude': -9.110911}

# Generated at 2022-06-23 21:08:05.030297
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    result = address.continent()
    assert type(result) is str
    assert result in address._data['continent']


# Generated at 2022-06-23 21:08:07.783290
# Unit test for method street_name of class Address
def test_Address_street_name():
    """The test case of Address.street_name()."""
    address = Address(locale='en')
    street_name = address.street_name()
    assert street_name in address._data['street']['name']



# Generated at 2022-06-23 21:08:19.894824
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Create one instance of class Address
    # to test its method longitude
    addr = Address()
    longitude = addr.longitude()
    assert str(longitude)[0] == '-' or str(longitude)[0] == '0' or str(longitude)[0] == '1' or str(longitude)[0] == '2' or str(longitude)[0] == '3'
    assert '.' in str(longitude)
    assert str(longitude)[-1] == '6' or str(longitude)[-1] == '7' or str(longitude)[-1] == '8' or str(longitude)[-1] == '9'
