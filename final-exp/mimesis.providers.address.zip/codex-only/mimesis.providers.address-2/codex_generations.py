

# Generated at 2022-06-23 20:58:21.925300
# Unit test for method city of class Address
def test_Address_city():
    ad = Address('zh')
    flag = 0
    for i in range(100):
        if ad.city() == '台北市':
            flag = 1
            break
    assert flag == 1

# Generated at 2022-06-23 20:58:24.642940
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address

    a = Address(Locale.EN)
    b = Address(Locale.EN)
    assert a.street_number() == a.street_number()
    assert a.street_number() != b.street_number()


# Generated at 2022-06-23 20:58:27.301826
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    print(a.calling_code())
# output: +62


# Generated at 2022-06-23 20:58:30.075077
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    l = Address(locale='ja')
    s = l.prefecture()
    print(s)
    assert s in l._data['state']['abbr']


# Generated at 2022-06-23 20:58:34.231685
# Unit test for method country of class Address
def test_Address_country():
    """Unit test for method country of class Address."""
    addr = Address()
    current_locale = addr.locale
    allowed_locales = addr._data['country']['name']

    assert (addr.country(allow_random=True) in allowed_locales)
    assert (addr.country(allow_random=False) == current_locale)

# Generated at 2022-06-23 20:58:38.650937
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    a = Address(Locale.SWEDISH)
    assert a.address() == 'Östervägen 180'

    a = Address(Locale.NORWEGIAN)
    assert a.address() == 'Torbjørn Rings Gate 3245'

    a = Address(Locale.SPANISH)
    assert a.address() == 'Calle de Santo Domingo 1119'

    a = Address(Locale.GERMAN)
    assert a.address() == 'Marktstraße 51'

    a = Address(Locale.FRENCH)
    assert a.address() == '60 Boulevard de la Marne'

    a = Address(Locale.PORTUGUESE_BRAZIL)
    assert a.address() == 'Rua da Sé 666'



# Generated at 2022-06-23 20:58:41.622687
# Unit test for method continent of class Address
def test_Address_continent():
    assert type(Address().continent()) == str


# Generated at 2022-06-23 20:58:51.802287
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import mimesis.builtins
    from mimesis.enums import CountryCode
    from mimesis.enums import CardinalDirection

    data = [Address('en').coordinates() for i in range(5)]
    data1 = [Address('en').coordinates(dms=True) for i in range(5)]
    data2 = [Address('ja').coordinates() for i in range(5)]

    data3 = [Address('en').state(abbr=True) for i in range(5)]
    data4 = [Address('en').country() for i in range(5)]
    data5 = [Address('en').country(allow_random=True) for i in range(5)]
    data6 = [Address('en').country_code() for i in range(5)]

# Generated at 2022-06-23 20:58:58.535035
# Unit test for method state of class Address
def test_Address_state():
    # Test european
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Country
    ru = RussiaSpecProvider()
    assert ru.address.state() in ru.address._data['state']['name']

    # Test american
    from mimesis.builtins import USASpecProvider
    from mimesis.enums import Country
    en_us = USASpecProvider()
    assert en_us.address.state() in en_us.address._data['state']['name']

    # Test japanese
    from mimesis.builtins import JapanSpecProvider
    from mimesis.enums import Country
    ja = JapanSpecProvider()
    assert ja.address.state() in ja.address._data['state']['name']



# Generated at 2022-06-23 20:59:06.533459
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Test: Generate postal code using postal code format
    # UK (GB) and US (US)
    a = Address(locale='uk')
    b = Address(locale='us')
    # Zip code (postal code) of UK can be in format:
    # DD DD, where D is a digit or
    # DD DD D, where D is a digit or
    # DD DDD, where D is a digit
    # and also can contain a space after the first
    # two digits.
    #
    # Examples of zip codes from UK:
    # BN11 1DN, BN11 1DZ, BN11 1EF
    #
    # Zip code (postal code) of US can be in format:
    # 5-digit code like 90210 or
    # 9-digit code like 64147-9998
   

# Generated at 2022-06-23 20:59:07.509613
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())

# Generated at 2022-06-23 20:59:09.482224
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert(
        Address.calling_code())

# Generated at 2022-06-23 20:59:14.162361
# Unit test for constructor of class Address
def test_Address():
    """Unit test for Address().

    test_Address()
    """
    addr = Address()
    assert addr.country() == '中国'
    assert addr.city() == '上海市'
    assert ',' in addr.address()
    assert addr.state() == '上海'

# Generated at 2022-06-23 20:59:15.777737
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 20:59:17.904935
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    # One test is enough
    a.random.seed(0)
    assert a.region() == 'CA'

# Generated at 2022-06-23 20:59:21.446665
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address(locale='en')
    street_name = address.street_name()

    assert isinstance(street_name, str)
    assert street_name in address._data['street']['name']



# Generated at 2022-06-23 20:59:22.093876
# Unit test for method province of class Address
def test_Address_province():
    print(Address().province())

# Generated at 2022-06-23 20:59:23.426980
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    print(a.street_number())

# Generated at 2022-06-23 20:59:24.761972
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    a.state()


# Generated at 2022-06-23 20:59:36.094440
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    from mimesis.builtins import en

    address = Address(locale=en)

    # Case: A2
    assert address.country_code(CountryCode.A2) in COUNTRY_CODES['A2']

    # Case: A3
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES['A3']

    # Case: Numeric
    numeric_code = address.country_code(CountryCode.Numeric)
    assert numeric_code in COUNTRY_CODES['Numeric']
    assert numeric_code.isdigit()

    # Case: Alpha2
    assert address.country_code(CountryCode.Alpha2) in COUNTRY_CODES['Alpha2']

    # Case: Alpha3
    assert address.country_

# Generated at 2022-06-23 20:59:37.594330
# Unit test for method city of class Address
def test_Address_city():
    x = Address()
    y = x.city()
    assert y

# Generated at 2022-06-23 20:59:46.524766
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a._validate_enum(CountryCode.A2, CountryCode) == 'alpha2'
    assert a.region() == a.state()
    assert a.state(abbr=True) in a._data['state']['abbr']
    assert a.province(abbr=True) in a._data['state']['abbr']
    assert a.federal_subject(abbr=True) in a._data['state']['abbr']
    assert a.prefecture(abbr=True) in a._data['state']['abbr']



# Generated at 2022-06-23 20:59:49.168317
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    import re
    address_instance = Address()
    test_result = re.search(r'\d+', address_instance.calling_code())
    assert test_result

# Generated at 2022-06-23 20:59:54.651749
# Unit test for method street_name of class Address
def test_Address_street_name():
    address_obj = Address(locale='en')
    all_list = []
    for i in range(100):
        all_list.append(address_obj.street_name())
    # print(all_list)
    assert (all(isinstance(item, str) for item in all_list)),  "unit test for method street_name of class Address has failed"
    print("unit test for method street_name of class Address has passed")


# Generated at 2022-06-23 20:59:55.544363
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    print(address.postal_code())

# Generated at 2022-06-23 21:00:08.231668
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    street_suffix = address.street_suffix()

# Generated at 2022-06-23 21:00:09.564679
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    assert type(a.longitude()) == float

# Generated at 2022-06-23 21:00:12.954265
# Unit test for method province of class Address
def test_Address_province():
    data = Address(locale='en').province()
    assert data
    assert isinstance(data, str) is True
    assert not isinstance(data, int) is True


# Generated at 2022-06-23 21:00:14.704755
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address("en").latitude() == "33.978939"


# Generated at 2022-06-23 21:00:17.732673
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    assert Address().country(allow_random=False) == 'Ukraine'


# Generated at 2022-06-23 21:00:21.552836
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    ad = Address()
    d = ad.coordinates(dms)
    assert d["longitude"] is not None
    assert d["latitude"] is not None

# Generated at 2022-06-23 21:00:22.601927
# Unit test for method continent of class Address
def test_Address_continent():
	a = Address()
	b = a.continent()
	print(b)


# Generated at 2022-06-23 21:00:25.705114
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    # The original value
    original = a.street_suffix()
    print(original)
    l = ["Avenue", "Aly.", "Way"]
    assert original in l


# Generated at 2022-06-23 21:00:29.017571
# Unit test for method city of class Address
def test_Address_city():
    """Unit test for method city of class Address.

    Test if method city of class Address and
    method __init__ of class Address return the same value.
    """
    address = Address()
    assert (address.city() == address._data['city'][0])



# Generated at 2022-06-23 21:00:30.293367
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert address.zip_code()



# Generated at 2022-06-23 21:00:32.050678
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    for i in range(10):
        print(address.address())

# Generated at 2022-06-23 21:00:36.145932
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    locale = 'ru'
    a = Address(locale)
    assert(isinstance(a.federal_subject(), str))
    assert(a.federal_subject() in a._data['state']['name'])

# Generated at 2022-06-23 21:00:38.042705
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:00:38.944157
# Unit test for method address of class Address
def test_Address_address():
    assert Address().address()

# Generated at 2022-06-23 21:00:40.175051
# Unit test for method street_name of class Address
def test_Address_street_name():
    a1 = Address()
    assert type(a1.street_name()) ==str

# Generated at 2022-06-23 21:00:42.574719
# Unit test for method address of class Address
def test_Address_address():

    a = Address('en')
    assert type(a.address()) == str
    assert a.address() == "37191 Wuckert Lake Suite 660"

    return


# Generated at 2022-06-23 21:00:44.691984
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    result = address.prefecture()
    assert result == 'ZH'


# Generated at 2022-06-23 21:00:47.158281
# Unit test for method continent of class Address
def test_Address_continent():
    adr = Address()
    print(adr.continent(code=False))


# Generated at 2022-06-23 21:00:51.241593
# Unit test for method street_number of class Address
def test_Address_street_number():
    provider = Address()
    max_val = 1400
    for i in range(100):
        street_number = provider.street_number(maximum=max_val)
        street_number = int(street_number)
        assert 0 < street_number < max_val + 1


# Generated at 2022-06-23 21:00:54.595903
# Unit test for method province of class Address
def test_Address_province():
    for i in range(0,1000):
        address_province = Address()
        if address_province.province() is None:
            print('test fail')
            exit()
    print('test success')


# Generated at 2022-06-23 21:00:55.709817
# Unit test for method latitude of class Address
def test_Address_latitude():
    ad = Address('en')
    lat = ad.latitude()
    assert -90 <= float(lat) <= 90


# Generated at 2022-06-23 21:00:57.941870
# Unit test for method state of class Address
def test_Address_state():
    ad = Address()
    assert ad.state() in [
        'Alabama',
        'Alaska',
        'Alberta',
        'Andhra Pradesh',
        'Arizona',
        'Arkansas',
        'British Columbia',
        'California',
        'Colorado',
        'Connecticut',
    ]


# Generated at 2022-06-23 21:01:00.114486
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address(locale='ru')
    assert a.postal_code() == '000000'+str(a.random.randint(1,10))


# Generated at 2022-06-23 21:01:02.372403
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.__class__.__name__ == 'Address'
    assert address.__doc__.startswith('Class for generate')


# Generated at 2022-06-23 21:01:05.449954
# Unit test for method country of class Address
def test_Address_country():
    address_pl = Address(locale='pl')
    assert isinstance(address_pl.country(), str)
    assert address_pl.country() == 'Polska'


# Generated at 2022-06-23 21:01:07.197009
# Unit test for method region of class Address
def test_Address_region():
    addr = Address('ja')
    assert isinstance(addr.region(), str)



# Generated at 2022-06-23 21:01:08.810493
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    assert isinstance(a.longitude(), float)


# Generated at 2022-06-23 21:01:17.194631
# Unit test for method address of class Address
def test_Address_address():
    results = []
    for _ in range(5):
        results.append(Address().address())
    assert results == [
        '66 Rue du Sentier',
        '3 7-chōme 5-1 Sotokanda',
        'Elmoore Lane 2163',
        '1/275 Commanda Viaduct',
        'Λεωφόρος Μεσογείων Μαραθώνας 93',
    ]



# Generated at 2022-06-23 21:01:19.417015
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    b = a.federal_subject()
    print (b)

# Generated at 2022-06-23 21:01:27.229851
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test Address.longitude()
    
    Returns a random value of longitude 
    (in DMS format if ``dms=True``).
    
    Arguments:
        dms {bool} -- DMS format 
        (default: {False})
    """
    address = Address()
    assert len(address.longitude(dms=True)) > 4 and type(address.longitude(dms=True)) == str
    assert len(address.longitude()) > 4 and type(address.longitude()) == float


# Generated at 2022-06-23 21:01:29.834791
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert isinstance(address.province(), str)
    print("\nAddress.province:")
    print("   ", address.province())


# Generated at 2022-06-23 21:01:31.340001
# Unit test for method address of class Address
def test_Address_address():
    # test it in real environment
    provider = Address()
    assert len(provider.address()) > 0

# Generated at 2022-06-23 21:01:33.306403
# Unit test for method state of class Address
def test_Address_state():
    locale = 'id_ID'
    address_obj = Address(locale)
    assert address_obj.state() != ''


# Generated at 2022-06-23 21:01:42.218006
# Unit test for constructor of class Address
def test_Address():
    """Test constructor of Address class.

    Address class should be initialized without any error.
    """
    address_obj = Address('en')
    assert address_obj._datafile == 'address.json'
    assert address_obj.locale == 'en'
    assert address_obj._data['address_fmt'] is not None
    assert address_obj._data['street']['name'] is not None
    assert address_obj._data['street']['suffix'] is not None
    assert address_obj._data['state']['abbr'] is not None
    assert address_obj._data['state']['name'] is not None
    assert address_obj._data['postal_code_fmt'] is not None
    assert address_obj._data['country']['name'] is not None

# Generated at 2022-06-23 21:01:45.588772
# Unit test for method address of class Address
def test_Address_address():
    address_obj = Address()
    result = address_obj.address()
    assert result.__class__ == str
    assert result
    assert len(result) > 0


# Generated at 2022-06-23 21:01:50.745202
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
 

    address_provider = Address()
    result = address_provider.calling_code()
    assert isinstance(result, str)
    assert result in CALLING_CODES


# Generated at 2022-06-23 21:01:53.224320
# Unit test for method address of class Address
def test_Address_address():
    print("Test for method address of class Address")
    a = Address()
    address = a.address()
    print("Address: " + address)


# Generated at 2022-06-23 21:01:54.019539
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    pass


# Generated at 2022-06-23 21:01:59.522810
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    from mimesis.builtins import Address
    from mimesis.enums import CountryCode
    from mimesis.providers import Person, CountryCodeProvider
    from mimesis.utils import numbers

    person = Person('en')
    address = Address('en')
    country_code = CountryCodeProvider('en')
    country = country_code.country('en')

    full_address = address.address()

    # Check if street number is in range [1, 1400]
    assert 1 <= int(numbers.extract_number(full_address.split()[0])) <= 1400

    # Check if street name is in list of street names
    assert full_address.split()[1] in address._data['street']['name']

    # Check if street suffix is in list of

# Generated at 2022-06-23 21:02:00.882323
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    print(address.continent())
    print(address.continent())
    print(address.continent())



# Generated at 2022-06-23 21:02:02.721521
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Test Address().postal_code()"""
    a = Address()
    assert len(a.postal_code()) == len(a._data['postal_code_fmt'])

# Generated at 2022-06-23 21:02:05.946278
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continent
    g = Address()
    for x in range(5):
        fmt = Continent.NAME
        print(g.continent(code=fmt.name))

# Generated at 2022-06-23 21:02:08.301480
# Unit test for method street_number of class Address
def test_Address_street_number():
    addr = Address()
    assert type(addr.street_number()) in str


# Generated at 2022-06-23 21:02:17.965251
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.address import Address as Address2
    address = Address()
    address2 = Address2(locale='ru')

    assert address.latitude() == address2.latitude()
    assert address.latitude(dms=True) == address2.latitude(dms=True)

    assert address.country_code() == address2.country_code()
    assert address.country_code(fmt=CountryCode.A3) == address2.country_code(fmt=CountryCode.A3)

# Generated at 2022-06-23 21:02:21.847848
# Unit test for method province of class Address
def test_Address_province():
    print("Start test")
    c = Address()
    assert c.province() != 'Vaud'
    assert c.province() != 'Wien'
    assert c.province() != 'Lembang'
    assert c.province() != 'Istanbul'
    print("End test")

# Generated at 2022-06-23 21:02:23.877449
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    adr = Address()
    res = adr.prefecture()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:02:26.146151
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert address.street_number()


# Generated at 2022-06-23 21:02:28.473914
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.enums import Locale
    address = Address(Locale.ENGLISH)
    street_names = set(address.street_name() for i in range(1000))
    assert len(street_names) == 1000


# Generated at 2022-06-23 21:02:31.580854
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    a.street_name()
    print("\n")
    
    # Unit test for method street_number of class Address

# Generated at 2022-06-23 21:02:32.669810
# Unit test for constructor of class Address
def test_Address():
    "Test Address constructor"
    address = Address()
    assert isinstance(address, Address)

# Generated at 2022-06-23 21:02:42.738271
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    address1 = Address()
    address2 = Address(locale='ru')
    address3 = Address(locale='ja')
    address4 = Address(locale='de')
    address5 = Address(locale='fr')
    assert isinstance(address1.region(), str) 
    assert isinstance(address2.region(), str)
    assert isinstance(address3.region(), str)
    assert isinstance(address4.region(), str)
    assert isinstance(address5.region(), str)
    assert isinstance(address1.region(True), str)
    assert isinstance(address2.region(True), str)
    assert isinstance(address3.region(True), str)
    assert isinstance(address4.region(True), str)

# Generated at 2022-06-23 21:02:45.697678
# Unit test for method address of class Address
def test_Address_address():
    address = Address(seed=5)
    result = address.address()
    expected = "3657 rue du Pont"
    assert result == expected



# Generated at 2022-06-23 21:02:46.941940
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('en')
    assert address.federal_subject() in address._data['state']['name']


# Generated at 2022-06-23 21:02:51.615588
# Unit test for method city of class Address
def test_Address_city():
    print("------------ test_Address_city() ------------")

    address = Address("en")
    print(address.city())
    # Test
    assert len(address.city()) > 1



# Generated at 2022-06-23 21:02:53.613035
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    assert a.continent() in a._data['continent']


# Generated at 2022-06-23 21:02:59.227033
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code() == '52558' # default locale is 'en_US'

    address = Address(locale="pt_BR")
    assert address.postal_code() == '94738-130'

    address = Address(locale="ja")
    assert address.postal_code() == '265-8452'

    address = Address(locale="ru")
    assert address.postal_code() == '187128'

    address = Address(locale="zh_CN")
    assert address.postal_code() == '350000'

# Generated at 2022-06-23 21:03:02.184731
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    res = address.street_number()
    assert type(res) is str


# Generated at 2022-06-23 21:03:12.223495
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis import enums
    from mimesis.enums import Gender

    address_pl = Address(enums.Language.POLISH)
    address_es = Address(enums.Language.SPANISH)

    street_name_pl = address_pl.street_name()
    street_name_es = address_es.street_name()
    assert street_name_pl != street_name_es

    personal_pl = Personal(enums.Language.POLISH, gender=Gender.FEMALE)
    street_name_pl = personal_pl.full_name(middle=True) + 'strasse'
    assert street_name_pl == street_name_es


if __name__ == '__main__':
    test_Address_street_name()

# Generated at 2022-06-23 21:03:15.167103
# Unit test for method street_name of class Address
def test_Address_street_name():
    address1 = Address(locale='en')
    print(address1.street_name())
    print(address1.street_name())
    print(address1.street_name())



# Generated at 2022-06-23 21:03:17.858670
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address
    """
    addr = Address()
    data = addr.country_code()
    print(data)
    assert len(data) == 2


# Generated at 2022-06-23 21:03:25.792533
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider

    address_provider = Address('en')
    assert isinstance(address_provider, BaseDataProvider)

    address_provider = Address('en')
    assert isinstance(address_provider, BaseDataProvider)
    assert (address_provider.state(abbr=False)).isalpha()
    assert (address_provider.state(abbr=True)).isalpha()
    assert isinstance(address_provider.country_code(CountryCode.A3), str)
    assert isinstance(address_provider.country_code(CountryCode.NUMERIC), str)
    assert isinstance(address_provider.country(), str)

# Generated at 2022-06-23 21:03:27.457135
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    address.street_name() == address.street_name()


# Generated at 2022-06-23 21:03:29.735234
# Unit test for method country of class Address
def test_Address_country():
    a = Address('en')
    print(a.country())
    print(a.country(True))


if __name__ == '__main__':
    test_Address_country()

# Generated at 2022-06-23 21:03:40.400458
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # Создаём экземпляр класса Address, под каждый тест новый, чтобы не было
    # случайных коллизий с содержанием переменных
    provider = Address()
    # Проверка региона

# Generated at 2022-06-23 21:03:44.599836
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    street_number = address.street_number()
    assert isinstance(street_number, str)
    assert street_number != ''
    assert street_number.isdigit()


# Generated at 2022-06-23 21:03:49.820967
# Unit test for method state of class Address
def test_Address_state():
    adr = Address(locale='en')
    en_state = adr.state()
    assert isinstance(en_state, str)
    assert len(en_state) <= 20
    assert len(en_state) > 0

    adr = Address(locale='jp')
    jp_state = adr.state()
    assert isinstance(jp_state, str)
    assert len(jp_state) <= 10
    assert len(jp_state) > 0


# Generated at 2022-06-23 21:03:52.256185
# Unit test for method latitude of class Address
def test_Address_latitude():
    # Test method latitude of class Address
    a = Address()
    latitude = a.latitude()
    assert latitude >= -90 and latitude <= 90


# Generated at 2022-06-23 21:03:53.554494
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    print(a.street_suffix())


# Generated at 2022-06-23 21:04:03.333872
# Unit test for constructor of class Address
def test_Address():
    from mimesis.builtins import Address
    address = Address()
    #street_number = address.street_number()
    #street_name = address.street_name()
    #street_suffix = address.street_suffix()
    address = address.address()
    #state = address.state()
    #region = address.region()
    #province = address.province()
    #federal_subject = address.federal_subject()
    #prefecture = address.prefecture()
    #postal_code = address.postal_code()
    #zip_code = address.zip_code()
    #country_code = address.country_code()
    #country = address.country()
    #city = address.city()
    #latitude = address.latitude()
    #longitude = address.long

# Generated at 2022-06-23 21:04:06.845987
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    assert address.longitude() is not None and address.longitude() > -180 and address.longitude() < 180


# Generated at 2022-06-23 21:04:10.918896
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    addr = Address(Locale.EN_US)
    add = addr.street_suffix()
    en_us_street_suffix = addr._data['street']['suffix']
    assert add in en_us_street_suffix


# Generated at 2022-06-23 21:04:15.050241
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for method federal_subject of class Address."""
    adr = Address(locale='en')
    result = adr.federal_subject()
    assert result


# Generated at 2022-06-23 21:04:26.895906
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test Address._coordinates(dms: bool = False)-> dict."""
    from random import choice
    from decimal import Decimal as D
    expected = {'latitude': '0º4\'43.45"N',
                'longitude': '0º4\'43.45"W'}
    result = Address._coordinates(dms=True)
    assert result == expected, \
        "Error in Address._coordinates(dms=True): expected {} but returned {}".\
        format(expected, result)

    expected = {"latitude": D('0'),
                "longitude": D('0')}
    result = Address._coordinates(dms=False)
    assert result == expected, \
        "Error in Address._coordinates(dms=False): expected {} but returned {}".\
        format(expected, result)

# Generated at 2022-06-23 21:04:30.169089
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address."""
    addr = Address()
    # print(addr.prefecture(abbr=True)) # For example 'VA'
    return addr.prefecture()

# Generated at 2022-06-23 21:04:31.156832
# Unit test for method province of class Address
def test_Address_province():
    a = Address().province()
    assert a != ''

# Generated at 2022-06-23 21:04:41.202714
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import CountryCode
    # Should return 'Москва'
    _address = Address(locale='ru')
    assert(_address.federal_subject() == 'Москва')

    # Should return 'Москва'
    _address = Address(locale='ru')
    assert(_address.federal_subject() == 'Москва')
   
    # Should return 'Москва'
    _address = Address(locale='ru')
    assert(_address.federal_subject() == 'Москва')


# Generated at 2022-06-23 21:04:45.939159
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country() == 'Brazil'
    assert Address().country(allow_random=True) in ['United States', 'South Korea', 'Canada', 'Germany', 'France', 'United Kingdom', 'Russia', 'Brazil', 'Australia', 'Argentina', 'China', 'Mexico']
    assert isinstance(Address().country(), str)


# Generated at 2022-06-23 21:04:57.795303
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test for method street_suffix of class Address.

    """
    from mimesis import Address
    from mimesis.enums import Locale

    ad = Address(Locale.EN)
    result1 = ad.street_suffix()
    print(result1)
    result2 = ad.street_suffix()
    print(result2)
    result3 = ad.street_suffix()
    print(result3)
    result4 = ad.street_suffix()
    print(result4)
    result5 = ad.street_suffix()
    print(result5)
    result6 = ad.street_suffix()
    print(result6)
    result7 = ad.street_suffix()
    print(result7)
    result8 = ad.street_suffix()
    print(result8)

# Generated at 2022-06-23 21:05:01.028485
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address('es')
    print(a.zip_code())
    print(a.zip_code())
    print(a.zip_code())


# Generated at 2022-06-23 21:05:03.172115
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():

    address = Address(locale='zh')
    suffix = address.street_suffix()
    assert isinstance(suffix, str)



# Generated at 2022-06-23 21:05:05.098587
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    for a in range(100):
        assert isinstance(address.coordinates(), dict)



# Generated at 2022-06-23 21:05:07.042331
# Unit test for method country of class Address
def test_Address_country():
    addr = Address(locale='en')
    assert addr.country() == 'Russia'

# Generated at 2022-06-23 21:05:08.020743
# Unit test for method country of class Address
def test_Address_country():
    assert Address().country() == 'China'


# Generated at 2022-06-23 21:05:11.571633
# Unit test for method latitude of class Address
def test_Address_latitude():
    # Arrange
    provider = Address()

    # Act
    result = provider.latitude()

    # Assert
    assert isinstance(result, float)
    assert -90 <= result <= 90


# Generated at 2022-06-23 21:05:13.845634
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    assert address.country() in  address._data['country']['name']

# Generated at 2022-06-23 21:05:16.681291
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address."""
    address = Address('es')
    assert len(address.country_code(CountryCode.A2)) == 2



# Generated at 2022-06-23 21:05:17.521455
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    print(address.address())

# Generated at 2022-06-23 21:05:25.008295
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continent

    def test_Address_continent_code():
        for _ in range(20):
            a = Address()
            c = a.continent(code=True)
            assert c in CONTINENT_CODES

    def test_Address_continent_name():
        for _ in range(20):
            a = Address()
            c = a.continent(code=False)
            assert c in a._data['continent']

    # With code
    yield test_Address_continent_code
    # Without code
    yield test_Address_continent_name

# Generated at 2022-06-23 21:05:26.791475
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Test for locale es
    a = Address(locale='es')
    print (a.zip_code())
    # A50000

test_Address_zip_code()

# Generated at 2022-06-23 21:05:29.882468
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() == 'Oceania'
    assert Address().continent(code=True) == 'OC'


# Generated at 2022-06-23 21:05:32.274247
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert address.federal_subject().isalnum()


# Generated at 2022-06-23 21:05:35.967850
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address(locale='en')
    for i in range(10):
        print(address.street_name() + '\n')


# Generated at 2022-06-23 21:05:36.963344
# Unit test for method city of class Address
def test_Address_city():
    assert Address().city()


# Generated at 2022-06-23 21:05:47.985756
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import CountryCode
    address = Address(locale="en-us")
    zip_code = address.zip_code()
    assert len(zip_code) == 5
    assert address.postal_code() == zip_code
    assert len(address.country_code(CountryCode.A2)) == 2
    assert len(address.country_code(CountryCode.A3)) == 3
    assert len(address.country_code(CountryCode.NUM)) == 3
    assert len(address.country_code(CountryCode.ALL)) > 2
    assert len(address.country_code(CountryCode.CURRENT)) == 2
    assert len(address.country_code(CountryCode.CURRENT_ALL)) > 2
    zip_code = Address(locale='ja').zip_code()

# Generated at 2022-06-23 21:05:54.229911
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    assert address.country_code(CountryCode.A3) != address.country_code(CountryCode.A2)
    assert address.country_code(CountryCode.NUMERIC) != address.country_code(CountryCode.A2)

test_Address_country_code()

# Generated at 2022-06-23 21:05:57.078752
# Unit test for method country of class Address
def test_Address_country():
    A = Address(seed=1)
    print(A.country())
    print(A.country(True))
    # en
    # Papua New Guinea


# Generated at 2022-06-23 21:06:07.958464
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode

    addr = Address()

    # Check that state returns the correct data for a given country
    assert addr.state(country_code=CountryCode.A2) \
        == addr.state(country_code=CountryCode.A2)

    # Check that state returns an ISO 3166-2 when abbr=True
    # and an ISO 3166-2 code has been provided
    assert len(addr.state(abbr=True, country_code=CountryCode.A2)) == 2

    # Check that state returns false if abbr=True
    # but no ISO 3166-2 code is provided
    assert not addr.state(abbr=True)

    # Check that state returns None if no country is provided
    # and no locale has been set

# Generated at 2022-06-23 21:06:09.894913
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject() in Address()._data["state"]["name"] # noqa: WPS517


# Generated at 2022-06-23 21:06:14.191081
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address as a
    ru = a(Locale.RU.value)
    ru_fs = ru.federal_subject()
    assert ru_fs in ru._data['state']['name']


# Generated at 2022-06-23 21:06:15.483470
# Unit test for method street_name of class Address
def test_Address_street_name():
	address = Address()
	res = address.street_name()
	print(res)


# Generated at 2022-06-23 21:06:17.626702
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    try:
        prov = Address(locale='tr-TR')
        print(prov.postal_code())
    except AttributeError:
        assert (1 == 1)

# Generated at 2022-06-23 21:06:20.189843
# Unit test for method province of class Address
def test_Address_province():
    print("\n\n     + Test method province of class Address +")
    test_num = 5
    result = {}
    addr = Address("es")
    while test_num != 0:
        result[addr.province()] = 1
        test_num -= 1
    print("     result:", result)


# Generated at 2022-06-23 21:06:23.650453
# Unit test for method country_code of class Address
def test_Address_country_code():
    country_code_A2 = Address().country_code(CountryCode.A2)
    country_code_A3 = Address().country_code(CountryCode.A3)
    assert len(country_code_A2) == 2
    assert len(country_code_A3) == 3

# Generated at 2022-06-23 21:06:26.103965
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    # Arrange
    instance = Address()

    # Act
    result = instance.street_suffix()

    # Assert
    assert isinstance(result, str)
    assert result



# Generated at 2022-06-23 21:06:32.526916
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Method test_Address_longitude() of the class Address."""
    from mimesis.enums import Degree
    from mimesis.exceptions import NonEnumerableError

    provider = Address('ru')
    # Test longitude()
    assert provider.longitude() != provider.longitude()

    # Test longitude() with DMS format
    # Test longitude() with DMS format and enum object
    assert provider.longitude() != provider.longitude(dms=True)

    provider.dms = Degree.DEGREES
    assert provider.longitude() != provider.longitude()

    provider.dms = Degree.MINUTES
    assert provider.longitude() != provider.longitude()

    provider.dms = Degree.SECONDS
    assert provider.longitude() != provider.longitude()


# Generated at 2022-06-23 21:06:36.794373
# Unit test for method province of class Address
def test_Address_province():
    address=Address(locale='en')
    assert address.province() in address._data['state']['abbr']
    assert address.province(True) in address._data['state']['abbr']
    assert address.province('') in address._data['state']['abbr']

# Generated at 2022-06-23 21:06:47.673524
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    province = Address(language_code='zh').federal_subject()

# Generated at 2022-06-23 21:06:49.059513
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    # Create a object Address
    address = Address('de')

    # Get a province (a random value)
    print(address.prefecture())

# Generated at 2022-06-23 21:06:51.344591
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address('en')
    assert address.longitude() == "92.491017"


# Generated at 2022-06-23 21:07:03.509575
# Unit test for method street_name of class Address

# Generated at 2022-06-23 21:07:05.809128
# Unit test for method province of class Address
def test_Address_province():
    print(Address().province())


# Generated at 2022-06-23 21:07:07.747480
# Unit test for method latitude of class Address
def test_Address_latitude():
    latitude = Address().latitude()
    print(latitude)
    assert isinstance(latitude,(float))
    return latitude


# Generated at 2022-06-23 21:07:09.460763
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert (Address().federal_subject() in Address()._data['state']['name']) == True


# Generated at 2022-06-23 21:07:10.347514
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr=Address()
    assert(addr.zip_code())

# Generated at 2022-06-23 21:07:10.775713
# Unit test for method latitude of class Address
def test_Address_latitude():
    pass

# Generated at 2022-06-23 21:07:12.864539
# Unit test for method country of class Address
def test_Address_country():
    provider = Address()
    assert provider.country() == 'Saint Kitts and Nevis'
    assert provider.country() == 'Saint Kitts and Nevis'
    assert provider.country(allow_random=True) in provider._data['country']['name']

# Generated at 2022-06-23 21:07:16.087594
# Unit test for constructor of class Address
def test_Address():
    Address(locale='en')
    Address(locale='ru')
    Address(locale='ja')

# Generated at 2022-06-23 21:07:19.563278
# Unit test for method state of class Address
def test_Address_state():
    """Generate administrative district name."""
    address = Address(seed=42)
    assert address.state(abbr=True) == 'IN-MH'
    assert address.state() == 'Karnataka'

# Generated at 2022-06-23 21:07:21.327297
# Unit test for method country of class Address
def test_Address_country():
    g = Address(use_json=True, locale='ru')
    result = g.country()
    assert result == 'Российская Федерация'


# Generated at 2022-06-23 21:07:24.233283
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    print(address.federal_subject())
    print(address.federal_subject('ru'))
    print(address.federal_subject())


# Generated at 2022-06-23 21:07:26.786184
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()

    # test_continent_name
    assert address.continent()

    # test_continent_code
    assert address.continent(code=True)

# Generated at 2022-06-23 21:07:30.772869
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    for i in range(100):
        code = a.country_code()
        assert code in COUNTRY_CODES['a2'], "Data should be in ISO 3166-1 A2 list"



# Generated at 2022-06-23 21:07:34.350927
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test for method street_suffix of class Address"""
    address = Address(random_seed=0)
    assert address.street_suffix() == 'Street'

# Generated at 2022-06-23 21:07:38.792723
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print('address:{}'.format(address.address()))
    print('street_number:{}'.format(address.street_number()))
    print('street_name:{}'.format(address.street_name()))
    print('street_suffix:{}'.format(address.street_suffix()))



# Generated at 2022-06-23 21:07:39.693783
# Unit test for method city of class Address
def test_Address_city():
    obj = Address()
    print(obj.city())

# Generated at 2022-06-23 21:07:41.986720
# Unit test for method longitude of class Address
def test_Address_longitude():
    ad = Address()
    assert ad.longitude() >= 0 and ad.longitude() <= 100
    assert True


# Generated at 2022-06-23 21:07:43.481408
# Unit test for method country_code of class Address
def test_Address_country_code():
    country_codes = Address(seed=42).country_code(CountryCode.A3)
    assert country_codes == 'CRI'

# Generated at 2022-06-23 21:07:44.956225
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert Address( ['en']).street_number(maximum=1400) == str(randint(1, 1400))


# Generated at 2022-06-23 21:07:48.130012
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Test method zip_code of class Address."""
    a = Address()
    assert len(a.zip_code()) == 5
    assert type(a.zip_code()) == str


# Generated at 2022-06-23 21:07:49.824249
# Unit test for method address of class Address
def test_Address_address():
    #Arrange
    address = Address()
    #Act
    result = address.address()
    #Assert
    assert len(result) > 0

# Generated at 2022-06-23 21:07:51.805821
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() in range(-90,90)


# Generated at 2022-06-23 21:07:53.437560
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert isinstance(a.calling_code(), str)

# Generated at 2022-06-23 21:07:55.056042
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a.state()


# Generated at 2022-06-23 21:07:58.669388
# Unit test for method latitude of class Address
def test_Address_latitude():
    # Test Data
    geo_cord = Address()
    # Test execution
    res = geo_cord.latitude()
    print(res)
    # Test assertion
    assert -90.0 <= res <= 90.0



# Generated at 2022-06-23 21:08:00.992777
# Unit test for method street_number of class Address
def test_Address_street_number():
    adr = Address()
    assert adr.street_number() == '1'
    assert len(adr.street_number()) == 1


# Generated at 2022-06-23 21:08:02.409507
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert address.zip_code() is not None

# Generated at 2022-06-23 21:08:05.270312
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address(locale='en')
    assert a.street_suffix() in [u'Avenue', u'Circle', u'Terrace']
    
    

# Generated at 2022-06-23 21:08:06.126791
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a is not None

# Generated at 2022-06-23 21:08:08.507487
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    latitude = Address().latitude()
    longitude = Address().longitude()

    assert isinstance(latitude, float)
    assert isinstance(longitude, float)

# Generated at 2022-06-23 21:08:13.532292
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert isinstance(a, Address)
    assert isinstance(a, BaseDataProvider)
    assert isinstance(a._data, dict)
    assert isinstance(a._datafile, str)


# Generated at 2022-06-23 21:08:14.612438
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()

    assert len(a.calling_code()) == 2 or len(a.calling_code()) == 3



# Generated at 2022-06-23 21:08:17.136279
# Unit test for method address of class Address
def test_Address_address():
    t = Address()
    addr = t.address()
    assert bool(addr)


# Generated at 2022-06-23 21:08:21.912830
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import numpy as np
    lat = []
    lon = []
    for i in range(0, 1000):
        lat.append(Address().latitude())
        lon.append(Address().longitude())
    print(np.mean(lat))
    print(np.mean(lon))  # should be 0
    # should be between -180 and 180

