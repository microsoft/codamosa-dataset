

# Generated at 2022-06-23 20:58:32.898065
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.builtins import Address
    a = Address('en')
    # 単位テスト
    # 地球の赤道に最も近い緯度は±2度。そろそろできるかな？
    ans = 0
    for i in range(0, 100):
        ans += abs(a.latitude())
    ans /= 100
    print(ans)
    assert ans < 2
    print('単位テスト成功。')

# Generated at 2022-06-23 20:58:37.109599
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    addr = Address(locale='es')
    assert addr.postal_code()
    assert len(addr.postal_code()) == 5
    assert addr.postal_code().isdigit()

# Generated at 2022-06-23 20:58:43.821951
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address('en')
    assert address.country_code(CountryCode.A3) == 'USA'
    assert address.country_code(CountryCode.A2) == 'US'
    assert address.country_code(CountryCode.NUMERIC) == '840'
    assert address.country_code(CountryCode.FULL) == 'United States'


# Generated at 2022-06-23 20:58:48.246133
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # The result of calling method calling_code of class Address should be a string
    assert isinstance(Address().calling_code(), str)

    # The result of calling method calling_code of class Address should be a string
    # that contain only digit characters
    assert Address().calling_code().isdigit()


# Generated at 2022-06-23 20:58:50.365395
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address("zh_CN")
    print(a.calling_code())

# Generated at 2022-06-23 20:58:51.493597
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    zip_code = Address(locale='en').zip_code()
    assert zip_code


# Generated at 2022-06-23 20:58:54.679744
# Unit test for method province of class Address
def test_Address_province():
    address = Address('zh')
    province = address.province()
    print("province：" + province)


# Generated at 2022-06-23 20:58:56.367439
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    type = Address()
    test = type.prefecture()
    assert test is not None

# Generated at 2022-06-23 20:59:01.238140
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import CountryCode as CC
    a = Address()
    expected = '999-99'
    actual = a.postal_code()
    assert expected == actual
    a = Address(locale='ru')
    expected = '799-99'
    actual = a.postal_code()
    assert expected == actual


# Generated at 2022-06-23 20:59:04.697275
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    test_coordinates = address.coordinates()
    print("test_coordinates: ", test_coordinates)
    assert isinstance(test_coordinates, dict)


# Generated at 2022-06-23 20:59:06.345295
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert address.region()


# Generated at 2022-06-23 20:59:15.312344
# Unit test for method country of class Address
def test_Address_country():
    print('Testing country...')
    a = Address()
    result = a.country()
    assert "Corée du Sud" == result
    result = a.country(allow_random=True)
    print('Country [', result,']')
    result = a.country(allow_random=True)
    print('Country [', result,']')
    result = a.country(allow_random=True)
    print('Country [', result,']')
    result = a.country(allow_random=True)
    print('Country [', result,']')


# Generated at 2022-06-23 20:59:16.845730
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() in ['Street', 'Road', 'Avenue', 'Boulevard']

# Generated at 2022-06-23 20:59:19.181934
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Test method postal_code of class Address."""
    addr = Address('en')
    assert type(addr.postal_code()) == str

# Generated at 2022-06-23 20:59:25.987082
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    # Expected format:
    # ['street_number', 'street_name', 'street_suffix']
    # This method may return None in the case of locale is
    # one of the following: 'ar', 'el', 'fa', 'fa-AF', 'ja', 'ko',
    # 'ms', 'my', 'ta', 'uz'.
    if a.locale not in ['ar', 'el', 'fa', 'fa-AF', 'ja', 'ko', 'ms', 'my', 'ta', 'uz']:
        assert a.address()


# Generated at 2022-06-23 20:59:33.704754
# Unit test for method state of class Address
def test_Address_state():
    address=Address()
    assert address.state()
    assert address.state(abbr=True)
    assert address.region()
    assert address.region(abbr=True)
    assert address.province()
    assert address.province(abbr=True)
    assert address.federal_subject()
    assert address.federal_subject(abbr=True)
    assert address.prefecture()
    assert address.prefecture(abbr=True)


# Generated at 2022-06-23 20:59:36.585836
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Test Address.federal_subject."""
    address = Address()
    result = address.federal_subject()
    assert result == "Москва"

# Generated at 2022-06-23 20:59:37.956221
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    print(address.latitude())


# Generated at 2022-06-23 20:59:49.221745
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import pytest
    from mimesis.enums import CountryCode, Field
    from mimesis.providers.address import Address
    from mimesis.providers.geo import Geo

    def test_method_coordinates(lat, long):
        # Code for testing method coordinates of class Address
        provider = Address()

        # Generating a random coordinate, expect data type as dict
        coordinate = provider.coordinates()
        assert isinstance(coordinate, dict)
        # Expecting latitude exist in coordinate
        assert coordinate['latitude']
        # Expecting longitude exist in coordinate
        assert coordinate['longitude']
        # Expecting data type of latitude as float
        assert isinstance(lat, float)
        # Expecting data type of longitude as float
        assert isinstance(long, float)

        # Generating a random coordinate in DMS

# Generated at 2022-06-23 20:59:50.832546
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    st = []
    for i in range(10):
        st.append(a.address())
    for i in st:
        assert len(i) > 0

# Generated at 2022-06-23 20:59:56.887622
# Unit test for method prefecture of class Address

# Generated at 2022-06-23 21:00:08.953966
# Unit test for constructor of class Address
def test_Address():
    address = Address(locale='en')
    print(address.street_number())
    print(address.street_name())
    print(address.street_suffix())
    print(address.address())
    print(address.state())
    print(address.region())
    print(address.province())
    print(address.federal_subject())
    print(address.prefecture())
    print(address.postal_code())
    print(address.zip_code())
    print(address.country_code())
    print(address.country())
    print(address.city())
    print(address.latitude(dms=True))
    print(address.longitude(dms=True))
    print(address.coordinates())
    print(address.continent())
    print(address.calling_code())
   

# Generated at 2022-06-23 21:00:10.856598
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    code = a.calling_code()
    assert code in CALLING_CODES

# Generated at 2022-06-23 21:00:13.845203
# Unit test for method state of class Address
def test_Address_state():
    """Test for method state of class Address."""
    address = Address()
    assert address.state() in address._data['state']['name']
    assert address.state(abbr=True) in address._data['state']['abbr']

# Generated at 2022-06-23 21:00:15.271350
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region()
    assert isinstance(region, str)
    assert region != ''


# Generated at 2022-06-23 21:00:27.101344
# Unit test for method address of class Address
def test_Address_address():
    a = Address(seed=1)
    print(a.address())#在中国海城市八岗路
    #
    # a = Address(seed=1, locale='en')
    # assert a.address() == '34 E Railroad St'
    #
    # a = Address(seed=1, locale='ru')
    # assert a.address() == 'Шоссе Андрея Тарковского, дом 9, корпус 1'
    #
    # a = Address(seed=1, locale='de')
    # assert a.address() == 'Kirchstraße, 1'
    #
    # a = Address(seed=1, locale='fr')
    #

# Generated at 2022-06-23 21:00:28.826248
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    assert a.federal_subject()


# Generated at 2022-06-23 21:00:33.787300
# Unit test for method country_code of class Address
def test_Address_country_code():
    Address().country_code()
    Address().country_code(CountryCode.A3)
    Address().country_code(CountryCode.NUMERIC)
    Address().country_code(CountryCode.CURRENT_LOCALE)
    try:
        Address().country_code(1)
    except KeyError:
        pass


# Generated at 2022-06-23 21:00:38.584658
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # Test the generated federal subject
    address = Address('en')
    assert address.federal_subject() in (
        'NSW',
        'Victoria',
        'Queensland',
        'Western Australia',
        'South Australia',
        'Tasmania'
    )


# Generated at 2022-06-23 21:00:49.199213
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import Country
    from mimesis.enums import Locale
    from mimesis.enums import Gender

    data = Address(Locale.EN)
    # print(data.random.choice(data._data['street']))
    # print(data.random.randint(1400))
    # print(data.street_number(maximum=1400))
    # print(data.street_name())
    # print(data.street_suffix())
    print(data.address())
    print(data.state())
    print(data.region())
    print(data.province())
    print(data.federal_subject())
    print(data.prefecture())
    print(data.postal_code())
    print(data.zip_code())

# Generated at 2022-06-23 21:00:52.751930
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    x = Address()
    print(x.federal_subject(abbr=True))
    print(x.federal_subject())
    print(x.region(abbr=True))
    print(x.region())
    print(x.province(abbr=True))
    print(x.province())
    print(x.prefecture(abbr=True))
    print(x.prefecture())

if __name__ == "__main__":
    test_Address_federal_subject()

# Generated at 2022-06-23 21:00:54.596579
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    assert address.street_name() in address._data['street']['name']


# Generated at 2022-06-23 21:00:57.072497
# Unit test for method province of class Address
def test_Address_province():
    address_province_test = Address().province
    assert len(address_province_test) > 0
    return "test_Address_province passed."


# Generated at 2022-06-23 21:01:07.467886
# Unit test for method city of class Address
def test_Address_city():
    # Using English locale
    address = Address(locale='en')
    result = address.city()
    expected = 'Jacinda'
    assert result == expected

    # Using Russian locale
    address = Address(locale='ru')
    result = address.city()
    expected = 'Маршал'
    assert result == expected

    # Using German locale
    address = Address(locale='de')
    result = address.city()
    expected = 'Русиново'
    assert result == expected

    # Using Spanish locale
    address = Address(locale='es')
    result = address.city()
    expected = 'Катин Бор'
    assert result == expected

    # Using Estonian locale
    address = Address(locale='et')
    result = address

# Generated at 2022-06-23 21:01:10.300241
# Unit test for constructor of class Address
def test_Address():
    """Testing the constructor of class Address
    """
    print("Constructor of class Address")
    _Address = Address()
    assert _Address._datafile == 'address.json'
    assert _Address._pull(_Address._datafile)


# Generated at 2022-06-23 21:01:12.517144
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code() in COUNTRY_CODES[CountryCode.A2]



# Generated at 2022-06-23 21:01:19.747442
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test method longitude of class Address."""
    a = Address('en')
    lon = a.longitude()
    assert isinstance(lon, float) and -180.0 <= lon <= 180.0

    lon = a.longitude(dms=True)
    assert isinstance(lon, str)
    assert lon.endswith('E') or lon.endswith('W')

# Generated at 2022-06-23 21:01:21.849119
# Unit test for method state of class Address
def test_Address_state():
	a = Address()
	
	assert len(a.state()) > 0
	assert len(a.state(abbr=True)) > 0

# Generated at 2022-06-23 21:01:24.104516
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    print(address.state())


# Generated at 2022-06-23 21:01:26.346258
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    result = address.latitude()
    assert isinstance(result, float)
    assert result >= -90 and result <= 90


# Generated at 2022-06-23 21:01:27.639838
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert isinstance( Address().calling_code(), str)


# Generated at 2022-06-23 21:01:35.456140
# Unit test for method prefecture of class Address

# Generated at 2022-06-23 21:01:36.665945
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    result = address.province()
    assert result not in ("", None)



# Generated at 2022-06-23 21:01:37.666488
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert len(Address().country_code()) == 2


# Generated at 2022-06-23 21:01:39.408481
# Unit test for method continent of class Address
def test_Address_continent():
    locale = 'en'
    addr = Address(locale)
    result = addr.continent(code=True)
    assert result in CONTINENT_CODES

# Generated at 2022-06-23 21:01:42.500772
# Unit test for method country of class Address
def test_Address_country():
    country_name = Address().country()
    assert len(country_name) >= 3

# Generated at 2022-06-23 21:01:46.302444
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert isinstance(calling_code, str)
    assert calling_code in CALLING_CODES



# Generated at 2022-06-23 21:01:48.000527
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    print (Address().calling_code())

# Generated at 2022-06-23 21:01:53.278886
# Unit test for method country of class Address
def test_Address_country():
    assert '中国' == Address().country()
    assert '中国' == Address().country()
    assert 'よみかん' == Address('ja').country()
    assert 'よみかん' == Address('ja').country()
    assert 'China' == Address('en-US').country()
    assert 'China' == Address('en-US').country()


# Generated at 2022-06-23 21:02:00.713266
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    from mimesis.enums import DMS
    from mimesis.enums import Key

    a = Address(locale='en')

    assert isinstance(a.coordinates(), dict)
    assert isinstance(a.coordinates(dms=True), dict)

    #: The type of longitude and latitude
    assert isinstance(a.coordinates()[Key.LONGITUDE.value], float)
    assert isinstance(a.coordinates()[Key.LATITUDE.value], float)
    assert isinstance(a.coordinates(dms=True)[Key.LATITUDE.value], str)
    assert isinstance(a.coordinates(dms=True)[Key.LONGITUDE.value], str)

    #: The format of long

# Generated at 2022-06-23 21:02:03.442678
# Unit test for constructor of class Address
def test_Address():
    """Unit test for class Address."""
    address = Address()
    street = address.street_name()
    address_fmt = address.address()
    assert isinstance(street, str)
    assert isinstance(address_fmt, str)


if __name__ == '__main__':
    test_Address()

# Generated at 2022-06-23 21:02:05.044141
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address('en')
    suffix = addr.street_suffix()
    assert '.' not in suffix
    assert suffix in addr._data['street']['suffix']

# Generated at 2022-06-23 21:02:08.525718
# Unit test for method city of class Address
def test_Address_city():
    print("Testing method Address.city of class Address")
    assert(
        isinstance(Address().city(), str)
    )
    print("Passed!")


# Generated at 2022-06-23 21:02:09.786316
# Unit test for method province of class Address
def test_Address_province():
    assert Address.province() == Address.state()

# Generated at 2022-06-23 21:02:13.928158
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    p = a.province()
    assert p in a._data['state']['name'], f'{p} not in {a._data["state"]["name"]}'


# Generated at 2022-06-23 21:02:15.164436
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude()


# Generated at 2022-06-23 21:02:18.877521
# Unit test for method province of class Address
def test_Address_province():
    address = Address('ja')
    assert address.province() in address._data['state']['name']
    assert len(address.province()) <= len(max(address._data['state']['name']))


# Generated at 2022-06-23 21:02:24.428149
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Unit test for method  calling_code of class Address."""
    method = 'Address().calling_code()'
    l = ['Address().calling_code()']
    l = list()
    while True:
        answer = str(Address().calling_code())
        if answer not in l:
            l.append(answer)
        if len(l) == len(CALLING_CODES):
            break
    assert l == CALLING_CODES


# Generated at 2022-06-23 21:02:26.989211
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    lat = a.longitude()
    assert lat > -90 and lat < 90

# Generated at 2022-06-23 21:02:28.988764
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address('en').zip_code()
    # assert raise_exception(Address, 'ru')


# Generated at 2022-06-23 21:02:30.967198
# Unit test for method country of class Address
def test_Address_country():
    assert Address.country() in Address.get_territories()

# Generated at 2022-06-23 21:02:38.123915
# Unit test for method state of class Address
def test_Address_state():
    print('#' * 52 + '\n')
    print(Address(locale='en').state(abbr=True))
    print('#' * 52 + '\n')
    print(Address(locale='ru').state(abbr=True))
    print('#' * 52 + '\n')
    print(Address(locale='zh').state(abbr=True))
    print('#' * 52 + '\n')
    print(Address(locale='ja').state(abbr=True))
    print('#' * 52 + '\n')
    print(Address(locale='es').state(abbr=True))


# Generated at 2022-06-23 21:02:40.150792
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    result = address.country()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:02:41.467354
# Unit test for method region of class Address

# Generated at 2022-06-23 21:02:42.937458
# Unit test for method region of class Address
def test_Address_region():
    address = Address(locale='en')
    assert address.region() != ''

# Generated at 2022-06-23 21:02:47.132761
# Unit test for method province of class Address
def test_Address_province():
    locale = 'en'
    provider = Address(locale)

    result = provider.province()
    assert isinstance(result, str) and result != ''

    result = provider.province(abbr=True)
    assert isinstance(result, str) and result != ''

# Generated at 2022-06-23 21:02:53.387539
# Unit test for method country_code of class Address
def test_Address_country_code():
    address_data = (
        ('A2', 'RU'),
        ('A3', 'RUS'),
        ('numeric', '643'),
    )

    for fmt, expected in address_data:
        fmt = CountryCode.str(fmt)
        country_code = Address().country_code(fmt)
        assert country_code == expected

# Generated at 2022-06-23 21:02:54.677996
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state() != Address().state()


# Generated at 2022-06-23 21:02:55.867167
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-23 21:02:56.743899
# Unit test for constructor of class Address
def test_Address():
    assert Address()


# Generated at 2022-06-23 21:02:59.275987
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    print([address.continent() for _ in range(10)])
    print([address.continent(code=True) for _ in range(10)])

# Unit test
if __name__ == "__main__":
    test_Address_continent()

# Generated at 2022-06-23 21:03:02.189975
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    instance = Address()
    assert type(instance.zip_code()) == str


# Generated at 2022-06-23 21:03:04.790223
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.providers.address import Address
    a = Address()
    res = a.latitude()
    assert isinstance(res, float)



# Generated at 2022-06-23 21:03:06.856706
# Unit test for method address of class Address
def test_Address_address():
    obj = Address()
    address = obj.address()
    assert isinstance(address, str)


# Generated at 2022-06-23 21:03:16.890286
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CoordinateFormat
    a = Address('en')

    test_coordinates1 = a.coordinates(dms=CoordinateFormat.DMS)
    test_coordinates2 = a.coordinates(dms=CoordinateFormat.DEGREES)
    
    assert isinstance(test_coordinates1, dict)
    assert isinstance(test_coordinates1['longitude'], str)
    assert isinstance(test_coordinates1['latitude'], str)
    assert isinstance(test_coordinates2, dict)
    assert isinstance(test_coordinates2['longitude'], float)
    assert isinstance(test_coordinates2['latitude'], float)
    
if __name__ == "__main__":
    test_Address_coordinates()

# Generated at 2022-06-23 21:03:18.744997
# Unit test for method city of class Address
def test_Address_city():
    ad = Address('en')
    for i in range(5):
        city = ad.city()
        if ' ' in city:
            print(city)

# Generated at 2022-06-23 21:03:20.372300
# Unit test for method street_number of class Address
def test_Address_street_number():
    ad = Address()
    assert isinstance(ad.street_number(), str)

# Generated at 2022-06-23 21:03:24.171997
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address('zh')
    assert a.continent() in a._data['continent']
    assert a.continent(code=True) in CONTINENT_CODES


# Generated at 2022-06-23 21:03:25.161342
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude()



# Generated at 2022-06-23 21:03:27.458117
# Unit test for method state of class Address
def test_Address_state():
    address_provider = Address()
    # Generate a full address
    get_address = address_provider.state()
    print(get_address)

# Generated at 2022-06-23 21:03:28.121524
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    print(a.coordinates())


# Generated at 2022-06-23 21:03:30.024028
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    result = address.city()
    assert result
    assert type(result) == str


# Generated at 2022-06-23 21:03:40.453607
# Unit test for method country_code of class Address
def test_Address_country_code():
    code = Address().country_code()
    assert code in COUNTRY_CODES['A2']

# Generated at 2022-06-23 21:03:41.964002
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() == -16.986504


# Generated at 2022-06-23 21:03:44.159181
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    print(address.longitude())


# Generated at 2022-06-23 21:03:47.141249
# Unit test for method state of class Address
def test_Address_state():
    addr = Address()
    # print(addr.state())
    # print(addr.state(True))
    return True if addr.state() in addr._data['state']['name'] else False


# Generated at 2022-06-23 21:03:49.052284
# Unit test for method latitude of class Address
def test_Address_latitude():
    result = Address().latitude(dms=False)
    assert(result != None)



# Generated at 2022-06-23 21:03:51.221130
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address(seed=42)
    assert a.latitude() == '47.203270'


# Generated at 2022-06-23 21:03:55.717262
# Unit test for method longitude of class Address
def test_Address_longitude():
    # Create
    import mimesis
    address = mimesis.Address()

    # Different
    lat = address.longitude()
    assert isinstance(lat, float)
    assert lat != address.longitude()
    assert isinstance(address.longitude(dms=True), str)
    assert address.longitude() != address.longitude(dms=True)


# Generated at 2022-06-23 21:03:59.075291
# Unit test for constructor of class Address
def test_Address():
    address = Address('en')
    # Test the class initialise
    assert isinstance(address, Address)
    # Test the class has all attributes
    assert hasattr(address, 'state') and hasattr(address, 'street_number')

#Test cases for address

# Generated at 2022-06-23 21:04:06.428266
# Unit test for method country of class Address
def test_Address_country():
    """Provide the data for unit test of Address class.

    This test provides the test data for unit test of the method country of
    class Address. The data are consist of fake random data from
    Address class and their expected value.

    :return: The actual value and expected value of method country of class Address.
    :rtype: tuple
    """
    addr = Address("en")
    expect = 'South Korea'
    actual = addr.country()
    
    return(actual,expect)


# Generated at 2022-06-23 21:04:09.573897
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    lat = address.latitude()
    lon = address.longitude()
    print ("latitude :", lat)
    print ("longitude :", lon)


# Generated at 2022-06-23 21:04:11.731483
# Unit test for constructor of class Address
def test_Address():
    ad = Address(random.Random())
    assert ad is not None
    assert isinstance(ad, Address)

# Generated at 2022-06-23 21:04:14.061398
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    result = address.city()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:04:26.135790
# Unit test for method address of class Address

# Generated at 2022-06-23 21:04:27.351128
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    # Check object is instance of Address
    assert isinstance(address, Address)


# Generated at 2022-06-23 21:04:30.546407
# Unit test for method street_name of class Address
def test_Address_street_name():
    for i in range(10):
        provider = Address()
        res = provider.street_name()
        assert type(res) == str
        assert len(res) > 0


# Generated at 2022-06-23 21:04:32.620244
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    object = Address('en')
    assert bool(object.postal_code())


# Generated at 2022-06-23 21:04:35.737973
# Unit test for method calling_code of class Address
def test_Address_calling_code():                                                                                         
    address = Address(None)

    calling_code = address.calling_code()

    print ("Calling code: ", calling_code)

    assert calling_code != None


# Generated at 2022-06-23 21:04:40.190440
# Unit test for method continent of class Address
def test_Address_continent():
    continents = ['Africa', 'Antarctica', 'Asia', 'Europe', 'North America', 'Oceania', 'South America']
    a = Address()
    c = a.continent()
    assert c in continents


# Generated at 2022-06-23 21:04:42.581401
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    provider = Address()
    result = provider.calling_code()
    assert result in CALLING_CODES



# Generated at 2022-06-23 21:04:44.341514
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('ru')
    assert isinstance(address.prefecture(), str)


# Generated at 2022-06-23 21:04:46.522205
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    assert address.latitude() < 90 and address.latitude() > -90


# Generated at 2022-06-23 21:04:56.367087
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test country code."""
    from mimesis.enums import CountryCode

    count = 5

    for i in range(count):
        c = Address(i)

        # Test A2
        code_a2 = c.country_code(CountryCode.A2)
        assert len(code_a2) == 2
        assert code_a2 in COUNTRY_CODES[CountryCode.A2]

        # Test A3
        code_a3 = c.country_code(CountryCode.A3)
        assert len(code_a3) == 3
        assert code_a3 in COUNTRY_CODES[CountryCode.A3]

# Generated at 2022-06-23 21:04:58.310193
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert type(address.zip_code()) == str


# Generated at 2022-06-23 21:05:01.138819
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    print(address.continent(code=True))
    print(address.continent())


# Generated at 2022-06-23 21:05:02.846983
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert calling_code in CALLING_CODES

# Generated at 2022-06-23 21:05:04.151079
# Unit test for method city of class Address
def test_Address_city():
    addr = Address()
    assert isinstance(addr.city(), str)


# Generated at 2022-06-23 21:05:15.421059
# Unit test for method federal_subject of class Address

# Generated at 2022-06-23 21:05:17.387671
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert isinstance(address.province(), str) and address.province().isalnum()

# Generated at 2022-06-23 21:05:21.385594
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture of class Address
    """
    addr = Address()

    prefecture = addr.prefecture()
    print(prefecture)
    assert len(prefecture) > 0
    assert isinstance(prefecture, str)


# Generated at 2022-06-23 21:05:23.429794
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # Instantiate an Address class
    a = Address()
    # Get a random federal subject
    assert a.federal_subject() in a._data['state']['name']

# Generated at 2022-06-23 21:05:24.932456
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Return a zip code."""
    assert Address().zip_code() == '95513'


# Generated at 2022-06-23 21:05:28.782664
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Test that country code is not empty."""
    a = Address()
    data = a.country_code()
    assert data != ''
    assert data != None
    assert data != []

# Generated at 2022-06-23 21:05:30.440176
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    assert len(a.postal_code()) == 5

# Generated at 2022-06-23 21:05:35.773905
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continents
    from mimesis.typing import Code
    from mimesis.enums import CodeFormat

# Generated at 2022-06-23 21:05:37.523416
# Unit test for method region of class Address
def test_Address_region():
  a = Address()
  res = a.region()
  assert type(res) is str


# Generated at 2022-06-23 21:05:48.608124
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    addr = Address()
    assert type(addr.region()) == str

    addr = Address(seed=1)
    assert addr.region(abbr=True) == 'AK'
    assert addr.region() == 'Alaska'

    addr = Address(seed=1, locale='ru')
    assert addr.region() == 'Красноярский край'

    addr = Address(locale='ja')
    assert addr.region() == ('県', '都', '府', '道')

    addr = Address(seed=1, locale='en_GB')
    assert addr.region(abbr=True) == 'ENG'

    addr = Address(locale='fr')

# Generated at 2022-06-23 21:05:54.282898
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address('en')
    address._get_fs('lt', dms=True)
    address._get_fs('lg', dms=True)
    address_result = address.coordinates(dms=True)
    for k, v in address_result.items():
        if k == 'longitude' or k == 'latitude':
            print(address_result)
            return address_result
    print('Unit test failed!')
    return None
# Unit test code
test_Address_coordinates()

# Generated at 2022-06-23 21:05:56.737145
# Unit test for method calling_code of class Address
def test_Address_calling_code():    
    address = Address()
    calling_code = address.calling_code()
    assert len(str(calling_code)) == 3

# Generated at 2022-06-23 21:06:02.832784
# Unit test for method state of class Address
def test_Address_state():
    adr = Address()
    state_adr = adr.state()
    state_abbr = adr.state(True)
    if not isinstance(state_adr, str):
        print(f"TypeError state_adr -> {state_adr}")
    if not isinstance(state_abbr, str):
        print(f"TypeError state_abbr -> {state_abbr}")
    #print(f"state_adr: {state_adr}\nstate_abbr: {state_abbr}")


# Generated at 2022-06-23 21:06:05.110074
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()

    longitude = address.longitude(True)

    assert ceil(float(longitude[:-1])) == -180

    assert longitude[-1] in ('W', 'E')


# Generated at 2022-06-23 21:06:13.971390
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import CountryCode
    from mimesis.localization import EN

    a = Address(EN)
    assert a.prefecture() in a.state(abbr=True)
    assert a.prefecture() in a.region(abbr=True)
    assert a.prefecture() in a.province(abbr=True)
    assert a.prefecture() in a.federal_subject(abbr=True)
    assert a.prefecture() in a.state(abbr=True)
    assert a.prefecture() in a.country_code(CountryCode.A2)
    assert a.prefecture() in a.country_code(CountryCode.A3)
    assert a.prefecture() in a.country_code(CountryCode.NUMERIC)

# Generated at 2022-06-23 21:06:16.404786
# Unit test for method region of class Address
def test_Address_region():
    provider = Address()
    region1 = provider.region()
    region2 = provider.region()
    region3 = provider.region()
    assert region1 != region2 != region3


# Generated at 2022-06-23 21:06:20.022881
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    def check_type(test_data):
        assert isinstance(test_data, str)

    addr = Address(Locale.RU)

    check_type(addr.address())


# Generated at 2022-06-23 21:06:26.713566
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import Region
    from mimesis.enums import CountryCode
    from mimesis.enums import Language

    rnd = random.Random()
    provider = Address(rnd)

    result = provider.province()
    assert isinstance(result, str)

    result = provider.province(
        region=Region.RUSSIA,
        country_code=CountryCode.FRANCE,
        language=Language.UKRAINIAN,
        region_fmt=None,
        abbr=True,
        region_code=True,
    )
    assert isinstance(result, str)

# Generated at 2022-06-23 21:06:28.646516
# Unit test for method region of class Address
def test_Address_region():
    import random
    random.seed(42)
    assert Address().region() == 'Mie'


# Generated at 2022-06-23 21:06:34.042241
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    test_list_1 = [{"x": "1"}, {"x": "2"}]
    test_list_2 = [{"x": "3"}, {"x": "4"}]
    test_list_3 = test_list_1 + test_list_2
    for i in test_list_3:
        print (i)


# Generated at 2022-06-23 21:06:37.722306
# Unit test for method country_code of class Address
def test_Address_country_code():
    """Unit test for method country_code of class Address."""
    a = Address()
    code_list = []
    for i in range(1, 9):
        code_list.append(a.country_code(fmt=CountryCode(i)))


# Generated at 2022-06-23 21:06:40.209649
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address('ja')
    assert a.longitude() is not None


# Generated at 2022-06-23 21:06:42.687420
# Unit test for method state of class Address
def test_Address_state():
    a1 = Address()
    s = a1.state()
    print(s)


# Generated at 2022-06-23 21:06:50.244244
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # 1
    actual = Address(
        'ru'
    ).federal_subject()
    expexted = 'Адыгея Республика'
    assert actual == expexted
    # 2
    actual = Address(
        'ru'
    ).federal_subject(True)
    expexted = 'АР'
    assert actual == expexted
    # 3
    actual = Address(
        'ru'
    ).region()
    expexted = 'Адыгея Республика'
    assert actual == expexted
    # 4
    actual = Address(
        'ru'
    ).region(True)

# Generated at 2022-06-23 21:07:00.849132
# Unit test for method address of class Address
def test_Address_address():
    import pytest
    from mimesis.enums import Locale

    locales = [
        'ar', 'cs', 'de', 'da', 'el', 'en', 'es',  # European
        'fi', 'fr', 'hu', 'id', 'it', 'ja', 'ko',  # Asian
        'nl', 'no', 'pl', 'pt', 'ro', 'ru', 'sv',  # Slavic
        'tr', 'uk', 'vi', 'zh',  # Asian
    ]

    for locale in locales:
        address = Address(Locale(locale))
        result = address.address()
        assert ' ' in result
        assert len(result) <= 100



# Generated at 2022-06-23 21:07:02.800951
# Unit test for method city of class Address
def test_Address_city():
    assert 'New York' in Address().city()
test_Address_city()


# Generated at 2022-06-23 21:07:05.250289
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.builtins import Address
    # Create an instance of class Address
    adr = Address('uk')
    print(adr.federal_subject())

# Generated at 2022-06-23 21:07:06.905844
# Unit test for method address of class Address
def test_Address_address():
    """Tests Address().address()."""
    a = Address()
    addr = a.address()

# Generated at 2022-06-23 21:07:08.602051
# Unit test for method state of class Address
def test_Address_state():
    addr=Address('zh')
    state=addr.state()
    assert isinstance(state,str)

# Generated at 2022-06-23 21:07:11.086709
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Unit test for method latitude of class Address."""
    addr = Address('es')
    lat = addr.latitude()
    assert lat >= -90 and lat <= 90


# Generated at 2022-06-23 21:07:12.365311
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:07:17.548692
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import Country
    from mimesis.providers.address import Address

    a = Address(Country.RUSSIA)
    st_name = a.state()
    assert isinstance(st_name, str)
    assert st_name in a._data['state']['name']

    st_abbr = a.state(abbr=True)
    assert isinstance(st_abbr, str)
    assert st_abbr in a._data['state']['abbr']


# Generated at 2022-06-23 21:07:18.398469
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    ad = Address('en')
    assert type(ad.federal_subject()) == str

# Generated at 2022-06-23 21:07:20.682368
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import Country
    from mimesis.providers.address import Address

    a = Address(Country.RUSSIA)
    assert a.latitude(dms=False)
    assert a.latitude(dms=True)


# Generated at 2022-06-23 21:07:24.367361
# Unit test for method region of class Address
def test_Address_region():
    # Create sample
    address = Address()
    # Get region
    region = address.region()
    # Check result (check for string)
    assert isinstance(region, str)


# Generated at 2022-06-23 21:07:26.270191
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    print(a.federal_subject())
    print(a.federal_subject(abbr=True))

# Generated at 2022-06-23 21:07:29.157254
# Unit test for method street_number of class Address
def test_Address_street_number():
    random = Address()
    
    res = random.street_number(maximum=100)
    assert isinstance(res, str)


# Generated at 2022-06-23 21:07:39.446587
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import CountryCode
    from mimesis.enums import Locale

    a = Address(Locale.EN)
    assert a.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert a.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert a.country_code(CountryCode.NUM) in COUNTRY_CODES[CountryCode.NUM]
    assert a.country_code(CountryCode.ALPHA3) in COUNTRY_CODES[CountryCode.ALPHA3]
    assert a.country_code(CountryCode.NUM) in COUNTRY_CODES[CountryCode.NUM]

# Generated at 2022-06-23 21:07:40.953859
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    r = Address().calling_code()
    assert r in CALLING_CODES

# Generated at 2022-06-23 21:07:47.433636
# Unit test for method state of class Address
def test_Address_state():
    """Test method state of class Address."""
    address = Address()
    assert address.state()
    assert address.state(abbr=True)
    assert address.region()
    assert address.region(abbr=True)
    assert address.province()
    assert address.province(abbr=True)
    assert address.federal_subject()
    assert address.federal_subject(abbr=True)
    assert address.prefecture()
    assert address.prefecture(abbr=True)


# Generated at 2022-06-23 21:07:52.480019
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    abbr = address.province(abbr=True)
    nbr = address.province(abbr=False)
    assert abbr in ['AB', 'BC', 'ON', 'QC', 'NS', 'NB', 'MB', 'SK', 'AB', 'BC', 'ON', 'QC', 'NS', 'NB', 'MB', 'SK']
    assert nbr in ['Alberta', 'British Columbia', 'Ontario', 'Quebec', 'Nova Scotia', 'New Brunswick', 'Manitoba', 'Saskatchewan', 'Alberta', 'British Columbia', 'Ontario', 'Quebec', 'Nova Scotia', 'New Brunswick', 'Manitoba', 'Saskatchewan']


# Generated at 2022-06-23 21:07:56.513109
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    a = Address(Locale.RU)
    assert a.city() in a._data['city']


# Generated at 2022-06-23 21:08:04.815236
# Unit test for method coordinates of class Address
def test_Address_coordinates():

    try:

        ad = Address()
        coordinates = ad.coordinates()
        assert type(coordinates) == dict, "coordinates() \
            method should return dict"
        assert len(coordinates) == 2, "coordinates() \
            method should return dict of lenght 2"
        assert 'longitude' in coordinates, "coordinates() \
            method should return dict with keys named 'longitude'"
        assert 'latitude' in coordinates, "coordinates() \
            method should return dict with keys named 'latitude'"

    except Exception:

        assert False, "Exception {}".format(Exception)

test_Address_coordinates()

# Generated at 2022-06-23 21:08:06.708969
# Unit test for method address of class Address
def test_Address_address():
    address = Address('en')
    assert isinstance(address.address(), str)


# Generated at 2022-06-23 21:08:08.272762
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert Address().street_number() in ['12', '76', '1156']

# Generated at 2022-06-23 21:08:11.590969
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address
    for i in range(10):
        print(a.zip_code)


# Generated at 2022-06-23 21:08:14.622183
# Unit test for method longitude of class Address
def test_Address_longitude():
    """Test longitude method of class Address."""
    address = Address()
    longitude = address.longitude()
    assert -90 <= longitude <= 90


# Generated at 2022-06-23 21:08:18.437501
# Unit test for method region of class Address
def test_Address_region():
    address_zh = Address('zh')
    address_it = Address('it')
    print(address_zh.region(abbr=False))
    print(address_it.region(abbr=False))


# Generated at 2022-06-23 21:08:25.416443
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    res = address.continent()  # str
    assert(type(res) == str)
    assert(res.__class__.__name__ == 'str')
    assert(res.__class__.__name__ == str.__name__)
    assert(isinstance(res, str))
    assert(isinstance(res, object))
    assert(issubclass(res.__class__, object))
    assert(len(res) <= 9)
