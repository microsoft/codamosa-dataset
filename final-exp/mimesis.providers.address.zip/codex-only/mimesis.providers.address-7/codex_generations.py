

# Generated at 2022-06-23 20:58:23.712548
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    province = address.province()

    assert isinstance(province, str)

# Generated at 2022-06-23 20:58:28.243940
# Unit test for method state of class Address
def test_Address_state():
    a = Address('zh', seed=0)
    assert a.state() == '上海市'
    assert a.state(abbr=True) == '32'

# Generated at 2022-06-23 20:58:30.030644
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    assert address.state() in address._data['state']['name']

# Generated at 2022-06-23 20:58:31.548417
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    result = provider.address()
    return result

# Generated at 2022-06-23 20:58:41.429798
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    
    from mimesis import Address
    from mimesis.schema import Field, Schema

    address = Address()
    '''
    print("\n", address.postal_code())

    schema = Schema(Address, postal_code=Field('postal_code'))
    print("\n", schema.create(postal_code=Field('postal_code')))
    '''
    import sys
    original_stdout = sys.stdout
    with open('data.txt', 'w') as f:
        sys.stdout = f
        schema = Schema(Address, postal_code=Field('postal_code'))
        print("\n", schema.create(postal_code=Field('postal_code')))
    sys.stdout = original_stdout

# Generated at 2022-06-23 20:58:48.112096
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import Country
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo

    address = Address(region_provider=Geo(Datetime()))
    address.set_locale(locale='ru-RU', region=Country.RUSSIAN_FEDERATION)
    assert address.calling_code() == '7'

# Generated at 2022-06-23 20:58:50.788061
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    addr = Address(locale='ru')
    assert addr.federal_subject() == 'Московская область'


# Generated at 2022-06-23 20:59:01.833974
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    street_suffix = Address().street_suffix()

# Generated at 2022-06-23 20:59:03.572165
# Unit test for method region of class Address
def test_Address_region():
    a = Address(locale='en')
    print(a.region())

# Generated at 2022-06-23 20:59:06.576900
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import LocaleEnum
    addr = Address(locale=LocaleEnum.RUSSIAN)
    assert len(addr.province()) > 0

# Generated at 2022-06-23 20:59:09.774991
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address"""
    a = Address('en')
    assert a.region() in a._data['state']['abbr']

# Generated at 2022-06-23 20:59:20.494860
# Unit test for method latitude of class Address
def test_Address_latitude():
    ########
    # NOTE #
    ########
    # Function `test_Address_latitude` is not run in travis environment.
    # It is run locally.
    # Reason is that travis use python 3.5 and method `isclose` is
    # not implemented in math module of python 3.5
    # https://stackoverflow.com/questions/45414089/is-there-an-equivalent-to-python-3-5s-math-isclose-for-python-3-4
    #
    # https://www.kaggle.com/loidrubio/random-geocoordinates-generator/
    from math import isclose
    from mimesis.enums import CountryCode

    # rule of thumb:
    # lat in range (-90, 90)
    # lon in range (-180,

# Generated at 2022-06-23 20:59:21.801911
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address("en")
    print(address.federal_subject())

# Generated at 2022-06-23 20:59:25.069162
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for coordinates() of class Address."""
    obj = Address()
    for _ in range(100):
        coords = obj.coordinates()
        longitude = coords['longitude']
        latitude = coords['latitude']
        assert -180 <= longitude <= 180
        assert -90 <= latitude <= 90

# Generated at 2022-06-23 20:59:27.815700
# Unit test for method country of class Address
def test_Address_country():
    """Unit test for method country of class Address."""
    a = Address()
    assert a.country() in a._data['country']['name']
    assert a.country(allow_random=True) in a._data['country']['name']

# Generated at 2022-06-23 20:59:30.355192
# Unit test for method street_number of class Address
def test_Address_street_number():
    Address().street_number()


# Generated at 2022-06-23 20:59:31.865312
# Unit test for method state of class Address
def test_Address_state():
    assert Address(random_state=1337).state() == 'gujarat'



# Generated at 2022-06-23 20:59:34.217480
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address(locale='sv')
    latitude = address.latitude()
    assert isinstance(latitude, float)


# Generated at 2022-06-23 20:59:36.734603
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    r = a.region()
    assert r in ('BRC', 'TUC')


# Generated at 2022-06-23 20:59:44.652373
# Unit test for method state of class Address
def test_Address_state():
    a1 = Address()
    s1 = a1.state()


# Generated at 2022-06-23 20:59:46.309960
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address('en')
    assert a.continent(True) in CONTINENT_CODES


# Generated at 2022-06-23 20:59:47.680733
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    address = a.address()
    assert address is not None
    print("address(): ", address)



# Generated at 2022-06-23 20:59:50.352413
# Unit test for method street_name of class Address
def test_Address_street_name():
    street_name = Address().street_name()
    assert isinstance(street_name, str)
    assert len(street_name) > 0


# Generated at 2022-06-23 20:59:58.172048
# Unit test for method country of class Address
def test_Address_country():
    """Test method country of class Address.
    This method use the variable 'current_locale' to return the country 
    of the current locale.
    """
    test = Address()
    if test.locale == 'en-US':
        assert test.country() == 'United States'
    elif test.locale == 'es-ES':
        assert test.country() == 'España'
    elif test.locale == 'fr-FR':
        assert test.country() == 'France'
    elif test.locale == 'de-DE':
        assert test.country() == 'Deutschland'
    elif test.locale == 'it-IT':
        assert test.country() == 'Italia'

# Generated at 2022-06-23 21:00:00.611206
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    print(address.country_code())

# Generated at 2022-06-23 21:00:02.797438
# Unit test for method city of class Address
def test_Address_city():
    # Test address
    address = Address()
    assert len(address.city()) > 0
    
    

# Generated at 2022-06-23 21:00:13.132547
# Unit test for method state of class Address
def test_Address_state():
    # Define test data
    test_data = [
            ('en', 'CA'),
            ('en', 'QC'),
            ('en', 'US'),
            ('fr', 'US'),
            ('it', 'QC'),
            ('it', 'CA'),
            ('it', 'US'),
            ('pt', 'CA'),
            ('pt', 'US'),
            ('pt', 'QC'),
            ('zh-hans', 'CA'),
            ('zh-hans', 'US'),
            ('zh-hans', 'QC'),
            ('zh-hant', 'QC'),
            ('zh-hant', 'US'),
            ('zh-hant', 'CA')
        ]
    print("Testing Address.state()")

# Generated at 2022-06-23 21:00:14.448331
# Unit test for constructor of class Address
def test_Address():
    """Test Address."""
    assert Address()

# Generated at 2022-06-23 21:00:17.497588
# Unit test for method latitude of class Address
def test_Address_latitude():
    for i in range(10):
        result = Address().latitude(dms=False)
        assert -90.0 <= result <= 90.0


# Generated at 2022-06-23 21:00:20.668877
# Unit test for method state of class Address
def test_Address_state():
    # Set up test case
    address = Address('en')
    state = address.state()
    print(state)


# Generated at 2022-06-23 21:00:23.208496
# Unit test for method city of class Address
def test_Address_city():
    addr = Address(locale='cs')
    assert addr.city() == 'Malé Svatoňovice'


# Generated at 2022-06-23 21:00:31.392634
# Unit test for method latitude of class Address
def test_Address_latitude():
    # First case
    address1 = Address()
    assert -90 < address1.latitude(False) < 90
    address1 = Address()
    assert -90 < address1.latitude(True) < 90

    # Second case
    address2 = Address()
    assert -90 < address2.latitude(False) < 90
    address2 = Address()
    assert -90 < address2.latitude(True) < 90

    # Third case
    address3 = Address()
    assert -90 < address3.latitude(False) < 90
    address3 = Address()
    assert -90 < address3.latitude(True) < 90

    # Forth case
    address4 = Address()
    assert -90 < address4.latitude(False) < 90
    address4 = Address()

# Generated at 2022-06-23 21:00:33.787208
# Unit test for method address of class Address
def test_Address_address():
    # Create object of class Address
    address = Address()

    assert isinstance(address.address(), str)

# Generated at 2022-06-23 21:00:37.808152
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    b = Address()
    c = Address()
    assert  a.region() == "NJ"
    assert  b.region() == "UT"
    assert  c.region() == "UT"


# Generated at 2022-06-23 21:00:39.792181
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert type(Address().longitude(dms=True)) == str
    assert type(Address().longitude(dms=False)) == float



# Generated at 2022-06-23 21:00:40.732063
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert True


# Generated at 2022-06-23 21:00:42.824613
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address('ru').longitude() == -172.245747
    assert Address('ru').longitude() == -172.245747

# Generated at 2022-06-23 21:00:46.521423
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() == 'Street'
    assert Address().street_suffix() == 'Avenue'
    assert Address().street_suffix() == 'Lane'


# Generated at 2022-06-23 21:00:48.748051
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    print(a.coordinates(dms=True))


# Generated at 2022-06-23 21:00:50.788349
# Unit test for method province of class Address
def test_Address_province():
    provider = Address('ru')
    assert isinstance(provider.province(), str)


# Generated at 2022-06-23 21:00:54.548641
# Unit test for method longitude of class Address
def test_Address_longitude():

    # Data provider
    ad = Address()

    # Check that longitude method returns a number in degree format
    assert type(ad.longitude()) == float
    # Check that longitude method returns a string in DMS format
    assert type(ad.longitude(dms=True)) == str

# Generated at 2022-06-23 21:01:02.719207
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # assert Address().zip_code() == "54330-54330"
    # assert Address(seed=1337).zip_code() == "54330-54330"
    assert Address(locale='zh').zip_code() == "367002"
    assert Address(locale='pt_BR').zip_code() == "36700-000"
    assert Address(locale='ja').zip_code() == "520-7087"
    # assert Address(locale='ar').zip_code() == "54330-54330"
    assert Address(locale='uk').zip_code() == "54330"
    assert Address(locale='de').zip_code() == "54330"
    assert Address(locale='ru').zip_code() == "54330"
    # assert Address(

# Generated at 2022-06-23 21:01:04.341043
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    print(address.address())

# Generated at 2022-06-23 21:01:06.509512
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address() of class Address."""
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-23 21:01:08.179948
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address(strict=True).zip_code() == '82800-000'



# Generated at 2022-06-23 21:01:12.148698
# Unit test for method city of class Address
def test_Address_city():
    # Define variable with value of test method
    variable_test_method = ('Agua Fria', 'Agua Linda', 'Agua Nueva', 'Ahuacatitlan', 'Ahuacatitlán', 'Ahuacatlán', 'Ahuacatlan', 'Ahuacatlán')

    instance = Address(seed = 8671) # Initialize an instance of Address with a fixed seed
    # Call test method
    result = instance.city()

    # Test method
    assert result in variable_test_method


# Generated at 2022-06-23 21:01:14.464877
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    print(provider.address())

# Generated at 2022-06-23 21:01:17.035903
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    postal_code = Address().postal_code()
    assert isinstance(postal_code, str)
    assert postal_code != ''

# Generated at 2022-06-23 21:01:20.031928
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis import Address
    address = Address()
    code = address.calling_code()
    print(code)
    assert code in CALLING_CODES


# Generated at 2022-06-23 21:01:24.675585
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis import Address
    from mimesis.enums import CountryCode
    address = Address()

    assert address.longitude(dms=True) == address._dd_to_dms(address.longitude(), 'lg')
    assert isinstance(address.longitude(dms=False), float)
    assert isinstance(address.longitude(dms=True), str)


# Generated at 2022-06-23 21:01:25.869623
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address()


# Generated at 2022-06-23 21:01:28.663084
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address"""
    address = Address("en")         # Create Address object
    full_address = address.address()
    assert full_address is not None


# Generated at 2022-06-23 21:01:30.430753
# Unit test for method street_name of class Address
def test_Address_street_name():
    Address.street_name()

# Generated at 2022-06-23 21:01:31.541641
# Unit test for method state of class Address
def test_Address_state():
    print(Address().state())


# Generated at 2022-06-23 21:01:33.878502
# Unit test for method province of class Address
def test_Address_province():
    '''Unit test for method province of class Address.
    '''
    p = Address()
    assert isinstance(p.province(), str)


# Generated at 2022-06-23 21:01:40.830238
# Unit test for method country of class Address
def test_Address_country():
    """Unit test for method country of class Address."""
    countries = ['it', 'ru', 'es', 'fr']
    for c in countries:
        locale = c
        addr = Address(locale=locale)
        country = addr.country()
        assert country == 'Италия' if c == 'it' else 'Россия' if c == 'ru' \
            else 'Испания' if c == 'es' else 'Франция' if c == 'fr' else ''

# Generated at 2022-06-23 21:01:52.158894
# Unit test for constructor of class Address
def test_Address():
    address = Address()

    assert address.street_number() != address.street_number()
    assert address.street_name() != address.street_name()
    assert address.street_suffix() != address.street_suffix()
    assert address.address() != address.address()
    assert address.state() != address.state()
    assert address.region() != address.region()
    assert address.province() != address.province()
    assert address.federal_subject() != address.federal_subject()
    assert address.prefecture() != address.prefecture()
    assert address.postal_code() != address.postal_code()
    assert address.zip_code() != address.zip_code()
    assert address.country_code() != address.country_code()

# Generated at 2022-06-23 21:01:57.274386
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')

    federal_subject = address.federal_subject()
    assert federal_subject in address._data['state']['name']
    assert len(federal_subject) == 3
    assert federal_subject == 'ЮФО'

    federal_subject = address.federal_subject(abbr=True)
    assert federal_subject in address._data['state']['abbr']
    assert federal_subject == 'KHA'




# Generated at 2022-06-23 21:02:00.240820
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    assert a.federal_subject(abbr=False) in a._data['state']['name']
    assert a.federal_subject(abbr=True) in a._data['state']['abbr']


# Generated at 2022-06-23 21:02:01.630904
# Unit test for method region of class Address
def test_Address_region():
  region = Address('en').region()
  print(region)

test_Address_region()

# Generated at 2022-06-23 21:02:05.490887
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import CountryCode
    from mimesis.enums import Locale
    address = Address(Locale.EN)
    country_code = CountryCode.A2
    countries = address.country_code(country_code)
    #print("The country code is:", countries)
    countries1 = address.country()
    #print("The country is:", countries1)


# Generated at 2022-06-23 21:02:08.302151
# Unit test for method street_name of class Address
def test_Address_street_name():
    print(Address(locale='en').street_name())
    assert Address(locale='en').street_name() != None



# Generated at 2022-06-23 21:02:13.859829
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    from mimesis.builtins import RussiaSpecProvider
    a = Address(locale=Locale.RU)
    r = RussiaSpecProvider(locale=Locale.RU)
    st_sfx_list = a.street_suffix()
    ru_st_sfx_list = r.street_suffix()

    assert type(st_sfx_list) == str
    assert st_sfx_list in ru_st_sfx_list


# Generated at 2022-06-23 21:02:20.368319
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address()
    r1 = a.continent()
    r2 = a.continent(code=True)
    assert r1 == 'America' or r1 == 'Europe' or r1 == 'Asia' or r1 == 'Africa'
    assert r2 == 'AS' or r2 == 'EU' or r2 == 'AF' or r2 == 'NA' or r2 == 'SA' or r2 == 'AN' or r2 == 'OC'


# Generated at 2022-06-23 21:02:22.386855
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address("en")
    result = a.street_number()
    print(result)


# Generated at 2022-06-23 21:02:26.200149
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    print("Test: Address.street_suffix")
    obj = Address()
    result = obj.street_suffix()
    print(result)


# Generated at 2022-06-23 21:02:27.289271
# Unit test for method country_code of class Address
def test_Address_country_code():
    return "hello"


# Generated at 2022-06-23 21:02:32.751238
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    a = Address()
    a.set_locale('en')
    b = a.coordinates()
    assert(-90 <= float(b['longitude']) < 90)

# Generated at 2022-06-23 21:02:35.415210
# Unit test for method region of class Address
def test_Address_region():
    address = Address('en')
    region = address.state()
    assert type(region) is str
    assert len(region) == 2


# Generated at 2022-06-23 21:02:37.674850
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    for i in range(10):
        city = address.city()
        assert city is not None


# Generated at 2022-06-23 21:02:41.743300
# Unit test for method street_name of class Address
def test_Address_street_name():
    print("Test of method street_name of class Address")
    address = Address("en")
    a = address.street_name()
    print("Expected type str, given", type(a))
    print("Expected length of a >= 1, given", len(a))
    print("\n")

# Generated at 2022-06-23 21:02:44.374650
# Unit test for method street_number of class Address
def test_Address_street_number():
    obj = Address()
    obj.street_number()
    # Statement coverage
    obj.street_number(maximum=3)
    # If statement coverage 
    obj.street_number(maximum=3)


# Generated at 2022-06-23 21:02:49.195869
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.enums import DataField
    from mimesis.enums import Locale

    address = Address(Locale.EN)

    for item in range(10):
        assert type(address.street_name()) == str
        assert address.field(DataField.STREET_NAME) == address.street_name()



# Generated at 2022-06-23 21:02:50.876876
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    result = address.continent()
    assert len(result) > 0


# Generated at 2022-06-23 21:02:56.328949
# Unit test for method state of class Address
def test_Address_state():
    address = Address(locale='en')
    current_province = address.state()
    assert current_province is not None
    assert isinstance(current_province, str)

    assert address.state(abbr=True) is not None
    assert address.region() is not None
    assert address.province() is not None
    assert address.federal_subject() is not None
    assert address.prefecture() is not None


# Generated at 2022-06-23 21:02:58.991891
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import Locale

    # Create instance of class Address
    address = Address(Locale.EN)

    # Call method postal_code of the class Address for test
    postal_code = address.postal_code()

    # Print the result
    print(postal_code)

# Generated at 2022-06-23 21:03:00.632525
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    return Address().calling_code()

# Generated at 2022-06-23 21:03:04.479909
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert len(address.zip_code()) == 5
    assert len(address.zip_code('ru')) == 6
    assert len(address.zip_code('us')) == 9


# Generated at 2022-06-23 21:03:07.347950
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state()
    assert Address().region()
    assert Address().province()
    assert Address().federal_subject()
    assert Address().prefecture()


# Generated at 2022-06-23 21:03:07.922723
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    Address().street_suffix()


# Generated at 2022-06-23 21:03:09.699213
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    result = a.longitude(True)
    assert result



# Generated at 2022-06-23 21:03:11.712019
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    latitude = address.latitude()
    assert latitude == '83.291798'

# Generated at 2022-06-23 21:03:15.031265
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Test for the method federal_subject of class Address."""
    addr = Address('ru')
    for _ in range(100):
        assert addr.federal_subject() in addr._data['state']['name']

# Generated at 2022-06-23 21:03:20.605634
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import RegionCode

    ad = Address()

    if ad.locale == 'ru':
        assert ad.federal_subject(abbr=True).isin(RegionCode.values())
    if ad.locale == 'zh':
        assert ad.federal_subject() == "貴州省"
    if ad.locale == 'en':
        assert ad.federal_subject() == "Alaska"
    if ad.locale == 'ja':
        assert ad.federal_subject() == "兵庫県"

# Generated at 2022-06-23 21:03:30.425408
# Unit test for method country of class Address
def test_Address_country():
    country_names = [
        'Mauritius',
        'India',
        'Hungary',
        'Japan',
        'China',
        'Canada',
        'United States',
        'Ukraine',
        'Lithuania',
        'Macedonia',
        'Belarus',
    ]
    country_from_list = [
        'Italy',
        'Ireland',
        'Indonesia',
        'Brazil',
        'Finland',
        'Estonia',
    ]
    for i in range(10):
        country = Address().country()
        assert country in country_names

    for i in range(10):
        country = Address().country(allow_random=True)
        assert country in country_from_list

# Generated at 2022-06-23 21:03:33.210828
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    locale_list = ['zh_CN','en','zh_TW','ja']
    for locale in locale_list:
        address = Address(locale)
        assert isinstance(address.postal_code(), str)


# Generated at 2022-06-23 21:03:35.291814
# Unit test for method state of class Address
def test_Address_state():
    from pprint import pprint
    address = Address()

    state = address.state()
    pprint(state)

    assert isinstance(state, str)
    assert len(state) > 0


# Generated at 2022-06-23 21:03:37.923563
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    a.country_code()
    a.country_code(CountryCode.A3)
    a.country_code(CountryCode.NUM)
    a.country_code(CountryCode.OFFICIAL)
    a.country_code(CountryCode.NAME)

# Generated at 2022-06-23 21:03:43.617601
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.utils import count_items
    from mimesis.typing import List

    a = Address()
    items: List[str] = []

    for _ in range(1000):
        items.append(a.address())

    result = count_items(items)
    unique_items = len(result)

    assert unique_items == 1000

# Generated at 2022-06-23 21:03:45.726417
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    result = Address().street_suffix()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:03:49.278160
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    for i in range(10):
        coord = a.coordinates()
        assert isinstance(coord, dict)
        assert isinstance(coord['longitude'], float)
        assert isinstance(coord['latitude'], float)

# Generated at 2022-06-23 21:03:51.266371
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    assert isinstance(a.latitude(False), float)



# Generated at 2022-06-23 21:03:52.927742
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert len(calling_code) == 3

# Generated at 2022-06-23 21:03:55.947577
# Unit test for method state of class Address
def test_Address_state():
    address = Address('en')
    state = address.state()
    assert state != ''

# Generated at 2022-06-23 21:03:58.535667
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert len(Address().street_number()) >= 1
    assert len(Address().street_number(maximum=1000))  == 3


# Generated at 2022-06-23 21:04:06.013372
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Test case for Address() class."""
    from mimesis.enums import CountryCode
    address = Address(seed=123)

    assert address.postal_code() == '426069'
    assert address.postal_code() == '407002'
    assert address.postal_code() == '435049'
    assert address.postal_code() == '410012'
    assert address.postal_code() == '608124'
    assert address.postal_code() == '820000'
    assert address.postal_code() == '820000'
    assert address.postal_code() == '820000'
    assert address.postal_code() == '820000'
    assert address.postal_code() == '820000'

    assert address.postal_

# Generated at 2022-06-23 21:04:08.065825
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    assert a.street_name() in a._data['street']['name']


# Generated at 2022-06-23 21:04:11.101344
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Arrange
    address = Address('ar')

    # Act
    result = address.zip_code()

    # Assert
    assert result is not None
    assert len(result) == 4
    assert result.isdigit()

# Generated at 2022-06-23 21:04:13.647147
# Unit test for method country of class Address
def test_Address_country():
    adr = Address()
    c = adr.country()
    assert isinstance(c, str)


# Generated at 2022-06-23 21:04:16.557907
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    c = Address()
    a = c.postal_code()
    if len(a) < 1:
        raise Exception('Value is too short')
    return


# Generated at 2022-06-23 21:04:18.764672
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    obj = Address()
    assert len(obj.street_suffix()) > 0



# Generated at 2022-06-23 21:04:19.768016
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    a.country(True)

# Generated at 2022-06-23 21:04:31.393236
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import pprint
    from mimesis.enums import DataField
    from mimesis.builtins import RussianSpecProvider
    from mimesis.providers.location import Address

    pprint.pprint(Address(DataField.LATITUDE).coordinates(True))
    pprint.pprint(Address('ru', 'ru').coordinates())
    pprint.pprint(Address(RussianSpecProvider).coordinates(True))
    pprint.pprint(Address(locale='ru', spec_set=RussianSpecProvider).coordinates())

    # Output:
    # {'latitude': -64.33188°49'6.601"S', 'longitude': -152.33133°58'21.948"E'}
    # {'latitude': -0.273522, 'longitude': -152.405

# Generated at 2022-06-23 21:04:34.832850
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test the Address class"""
    assert Address(local='en').coordinates() == {'latitude': -66.582799,
                                                 'longitude': -152.218078}



# Generated at 2022-06-23 21:04:38.173766
# Unit test for constructor of class Address
def test_Address():
    print("Address.__init__(): ", end="")
    obj = Address('de')
    assert obj.locale == 'de'
    print("OK")


# Generated at 2022-06-23 21:04:39.285057
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address().federal_subject()

# Generated at 2022-06-23 21:04:41.524215
# Unit test for method province of class Address
def test_Address_province():
    address = Address('en')
    result = address.province()
    assert result in address._data['state']['name']



# Generated at 2022-06-23 21:04:44.217272
# Unit test for method street_number of class Address
def test_Address_street_number():
    ad = Address('en')
    assert ad.street_number() == '898'
    assert ad.street_number(maximum=500) == '138'


# Generated at 2022-06-23 21:04:46.758979
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    test_Address_coordinates.a = a
    assert isinstance(a.coordinates(), dict)



# Generated at 2022-06-23 21:04:48.744857
# Unit test for method region of class Address
def test_Address_region():
    from mimesis import Address
    a = Address()
    assert len(a.region()) == 2


# Generated at 2022-06-23 21:04:50.246604
# Unit test for method country of class Address
def test_Address_country():
    ad = Address()
    print(ad.country())

# Generated at 2022-06-23 21:04:54.083144
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    calling_code = address.calling_code()
    assert len(calling_code) == 5 and calling_code[0] == '+'
    print("Test calling_code, ok")


# Generated at 2022-06-23 21:05:03.314420
# Unit test for method state of class Address
def test_Address_state():
    import random
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.utils import random_datetime
    seed = random_datetime(0, 0, 0, 0, 0, 0)
    random.seed(seed)

    cls = Address('en')
    key = random.choice(list(CountryCode))
    actual = cls.state(key == CountryCode.SUB_DIVISION_CODE)
    assert isinstance(actual, str)
    assert len(actual) > 0



# Generated at 2022-06-23 21:05:07.248790
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address."""
    obj = Address()
    result = obj.address()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:05:11.058064
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Test for method zip_code of class Address."""
    addr1 = Address(seed=1)
    addr2 = Address(seed=1)
    assert addr1.zip_code() == addr2.zip_code()


# Generated at 2022-06-23 21:05:13.883659
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address(locale='es_ES')
    postal_code = address.postal_code()
    assert isinstance(postal_code, str)
    assert len(postal_code) == 5


# Generated at 2022-06-23 21:05:14.794488
# Unit test for constructor of class Address
def test_Address():
    Address()

# Generated at 2022-06-23 21:05:16.580636
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    b = a.street_number()
    assert isinstance(b, str)


# Generated at 2022-06-23 21:05:19.224395
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    assert isinstance(address.calling_code(), str)
    assert address.calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:05:20.517519
# Unit test for method street_number of class Address
def test_Address_street_number():
    post_code = Address().street_number()
    assert type(post_code) == str
    assert len(post_code) > 0


# Generated at 2022-06-23 21:05:24.101281
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address(locale='en')
    address.continent() == 'North America'
    address.continent(True) == 'NA'
    address.continent() == 'South America'
    address.continent(True) == 'SA'
test_Address_continent()

# Generated at 2022-06-23 21:05:27.286173
# Unit test for method country_code of class Address
def test_Address_country_code():
    print('Testing Address.country_code')
    a = Address()
    print('Country code A2: ', a.country_code())
    print('Country code A3: ', a.country_code(CountryCode.A3))
    print('Country code N2: ', a.country_code(CountryCode.N2))

if __name__ == '__main__':
    test_Address_country_code()

# Generated at 2022-06-23 21:05:29.297084
# Unit test for method address of class Address
def test_Address_address():
    assert len(Address().address()) > 10


# Generated at 2022-06-23 21:05:32.615626
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    c = address.coordinates()
    assert c["latitude"] is c["longitude"]
    # Unit test for method address of class Address


# Generated at 2022-06-23 21:05:35.338293
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    a = Address()
    assert isinstance(a.prefecture(), str)


# Generated at 2022-06-23 21:05:37.108543
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address(random.SystemRandom()).calling_code() == '1268'


# Generated at 2022-06-23 21:05:45.672405
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Подготовка тестовых данных
    addr = Address('ru')
    # Получение почтового индекса
    postal_code = addr.postal_code()
    # Проверка на соответствие формату
    assert len(postal_code) == 6
    assert postal_code.isdigit()

# Generated at 2022-06-23 21:05:47.156124
# Unit test for constructor of class Address
def test_Address():
    assert Address().__class__.__name__ == 'BaseDataProvider'

# Generated at 2022-06-23 21:05:50.161645
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Test method postal_code"""
    testAddress = Address()
    zip = testAddress.postal_code()
    assert (len(zip) <= 10) and (len(zip) > 0)


# Generated at 2022-06-23 21:05:53.849119
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    assert hasattr(address, 'street_name')
    assert isinstance(address.street_name(), str)


# Generated at 2022-06-23 21:05:58.031973
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    assert address.longitude() is not None
    assert type(address.longitude(True)) is str
    assert type(address.longitude(False)) is float and address.longitude(False) > -180 and address.longitude(False) < 180


# Generated at 2022-06-23 21:06:02.824180
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # The calling code of country should be 3 digit number
    # The country code is an ISO 3166-1-alpha2
    calling_code = Address().calling_code()
    assert len(calling_code) <= 3 and isinstance(calling_code, str)

# Generated at 2022-06-23 21:06:04.141347
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert Address().latitude() < 90
    assert Address().latitude() > -90


# Generated at 2022-06-23 21:06:07.580396
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for method prefecture.
    :return: Nothing
    """
    address = Address()
    try:
        print(address.prefecture())
    except Exception as e:
        print(e)

test_Address_prefecture()

# Generated at 2022-06-23 21:06:10.330031
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    suffix = a.street_suffix()
    print("street_suffix:", suffix)
    assert len(suffix) > 0


# Generated at 2022-06-23 21:06:11.532423
# Unit test for method latitude of class Address
def test_Address_latitude():
    result = Address().latitude()
    assert result


# Generated at 2022-06-23 21:06:13.480044
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    federal_subject = Address().federal_subject()
    assert type(federal_subject) == str
    assert len(federal_subject) > 0

# Generated at 2022-06-23 21:06:15.474839
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    provider = Address()
    result = provider.prefecture()
    assert result in provider._data['state']['name']


# Generated at 2022-06-23 21:06:25.294660
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.enums import CurrencyCode
    from mimesis.enums import Localization
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.currency import Currency
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    address = Address(Localization.EN)
    currency = Currency(Localization.EN)
    datetime = Datetime(Localization.EN)
    internet = Internet(Localization.EN)

# Generated at 2022-06-23 21:06:32.789575
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # x = Address()
    # y = x.random.choice(CALLING_CODES)
    # assert y == x.calling_code()

    for i in range(4):
        assert Address().random.choice(CALLING_CODES) == Address().calling_code()

    for i in range(4):
        assert Address(seed=i).random.choice(CALLING_CODES) == Address(seed=i).calling_code()



# Generated at 2022-06-23 21:06:34.395562
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for method region of class Address"""
    Address.region()


# Generated at 2022-06-23 21:06:36.843257
# Unit test for method province of class Address
def test_Address_province():
    test_address = Address(language_code='en')
    result_test = test_address.province(abbr=True)
    assert result_test in "AB"



# Generated at 2022-06-23 21:06:47.701629
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    import json
    import os
    import unittest

    class AddressTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.a = Address('en')

        def test_postal_code(self) -> None:
            with open(os.path.join(os.path.dirname(__file__), 'data', 'address.json'), 'rb') as f:
                data = json.load(f)
            
            for locale, value in data['postal_code_fmt'].items():
                a = Address(locale)

                result = a.postal_code()

                self.assertEqual(len(result), len(value))
                for char in value:
                    self.assertIn(char, result)

    unittest.main()

# Generated at 2022-06-23 21:06:50.162379
# Unit test for method calling_code of class Address
def test_Address_calling_code():
	assert Address().calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:06:51.000013
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province() == "PV"

# Generated at 2022-06-23 21:06:53.427290
# Unit test for method state of class Address
def test_Address_state():
    adr = Address('en')
    st = adr.state()
    # print(st)
    assert isinstance(st, str)
    assert st != ''


# Generated at 2022-06-23 21:06:56.772321
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    # The number cannot be negative and greater than 1400
    assert 0 <= int(address.street_number()) <= 1400


# Generated at 2022-06-23 21:07:07.020970
# Unit test for method address of class Address
def test_Address_address():
    a = Address('en', seed=0)

# Generated at 2022-06-23 21:07:08.373906
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert a.address() == '1234 North 4th Street'

# Generated at 2022-06-23 21:07:10.232716
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Method for testing federal_subject of class Address"""
    
    address = Address(locale='en')
    address.federal_subject()
    address.federal_subject(abbr=True)


# Generated at 2022-06-23 21:07:11.307808
# Unit test for method region of class Address
def test_Address_region():
    add = Address()
    region = add.region()
    assert region is not None


# Generated at 2022-06-23 21:07:12.237528
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address().postal_code() == '87671'

# Generated at 2022-06-23 21:07:24.410556
# Unit test for method country_code of class Address
def test_Address_country_code():
    import pandas as pd

    addr = Address()

    df = pd.DataFrame()
    df['A2'] = [addr.country_code() for _ in range(10000)]
    df['A3'] = [addr.country_code(CountryCode.A3) for _ in range(10000)]
    df['NUM'] = [addr.country_code(CountryCode.NUM) for _ in range(10000)]

    df.to_csv('/tmp/country_code.csv')

    # Check uniqueness
    assert len(df['A2'].unique()) == len(COUNTRY_CODES[CountryCode.A2])
    assert len(df['A3'].unique()) == len(COUNTRY_CODES[CountryCode.A3])

# Generated at 2022-06-23 21:07:25.657039
# Unit test for constructor of class Address
def test_Address():
    addr = Address()
    assert isinstance(addr, Address)

# Generated at 2022-06-23 21:07:29.723226
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    obj = Address('en')
    postal_code = obj.postal_code()
    assert 5 == len(postal_code)
    assert postal_code.isdigit()


# Generated at 2022-06-23 21:07:31.363894
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    assert address.calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:07:41.517503
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.localization import DefaultLocale
    from mimesis.enums import CountryCode
    from mimesis.providers.person import Person
    address = Address(DefaultLocale('en'))

    assert address.region() in address.states()
    assert address.region(True) in address.states(True)

    assert address.province() in address.states()
    assert address.province(True) in address.states(True)

    assert address.federal_subject() in address.states()
    assert address.federal_subject(True) in address.states(True)

    assert address.prefecture() in address.states()
    assert address.prefecture(True) in address.states(True)


# Generated at 2022-06-23 21:07:43.150858
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    for i in range(20):
        print(Address().calling_code())


# Generated at 2022-06-23 21:07:44.631795
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert type(Address('en').zip_code()) == str
    assert len(Address('en').zip_code()) >= 5


# Generated at 2022-06-23 21:07:47.195682
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    calling_code = a.calling_code()
    assert calling_code in CALLING_CODES



# Generated at 2022-06-23 21:07:49.309071
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    country_code = address.country_code(fmt=CountryCode.A2)
    assert len(country_code) == 2


# Generated at 2022-06-23 21:07:52.338990
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    test = Address
    print("Address class street_suffix method test's result:")
    print(test.street_suffix())


# Generated at 2022-06-23 21:07:53.959250
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code() is not None

# Generated at 2022-06-23 21:07:58.127381
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    zip_code_1 = address.zip_code()

    # Test for return type of method zip_code
    assert isinstance(zip_code_1, str)
    # Test for different results
    assert zip_code_1 != address.zip_code()

# Generated at 2022-06-23 21:08:03.176329
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test if the street suffix is one of the 7 existing in Brazilian."""
    address = Address('pt')
    street_suffix = address.street_suffix()
    assert street_suffix in ['Avenida', 'Alameda', 'Travessa', 'Praça', 'Travessia', 'Rodovia', 'Estrada']


# Generated at 2022-06-23 21:08:07.238434
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region()
    if len(region) < 2:
        raise ValueError('Region name can not be less then 2 characters.')
    if not isinstance(region, str):
        raise TypeError('Result must be string.')

# Generated at 2022-06-23 21:08:10.862914
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address('en')
    result = address.longitude()
    assert isinstance(result, float)


# Generated at 2022-06-23 21:08:12.696926
# Unit test for method address of class Address
def test_Address_address():
    pa = Address()
    assert pa.address()


# Generated at 2022-06-23 21:08:14.258686
# Unit test for method city of class Address
def test_Address_city():
    for i in range(50):
        print(Address(i).city())

# Generated at 2022-06-23 21:08:16.743528
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr = Address('hi')
    assert re.match(r'\d{6}', addr.zip_code())

# Generated at 2022-06-23 21:08:20.149200
# Unit test for method street_number of class Address
def test_Address_street_number():
    obj = Address()
    streetNumber = obj.street_number()
    assert streetNumber.isdigit()
    assert len(streetNumber) > 0
    assert len(streetNumber) <= 4


# Generated at 2022-06-23 21:08:21.751085
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    assert address.prefecture() ==  address.state()

# Generated at 2022-06-23 21:08:24.352936
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    suffix = address.street_suffix()
    assert suffix in address._data['street']['suffix']
