

# Generated at 2022-06-23 20:58:22.396627
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    A = Address()
    L = [A.calling_code(),A.calling_code(),A.calling_code()]
    assert L != []


# Generated at 2022-06-23 20:58:24.855094
# Unit test for method country of class Address
def test_Address_country():
    country_name = "United States"
    address = Address(locale="en-us")
    assert address.country() == country_name
    assert address.country(allow_random=True) != country_name



# Generated at 2022-06-23 20:58:30.931941
# Unit test for method longitude of class Address
def test_Address_longitude():
    from time import time
    from sys import stderr
    from primes import is_prime
    t0 = time()
    # max_n = 10 ** 2
    # max_n = 2 * 10 ** 2
    max_n = 3 * 10 ** 2
    # max_n = 4 * 10 ** 2
    # max_n = 5 * 10 ** 2
    # max_n = 6 * 10 ** 2
    # max_n = 7 * 10 ** 2
    # max_n = 8 * 10 ** 2
    # max_n = 9 * 10 ** 2
    # max_n = 10 ** 3
    # max_n = 2 * (10 ** 3)
    # max_n = 3 * (10 ** 3)
    # max_n = 4 * (10 ** 3)
    # max_n = 5 * (10 ** 3

# Generated at 2022-06-23 20:58:33.592669
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    print("region:",address.region())
    print("country:",address.country())
    print("state:",address.state())
    print("continent:",address.continent())

# Generated at 2022-06-23 20:58:37.762018
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    result = address.zip_code()
    assert isinstance(result, str)
    assert len(result) == 5

if __name__ == '__main__':
    test_Address_zip_code()

# Generated at 2022-06-23 20:58:40.374215
# Unit test for method street_name of class Address
def test_Address_street_name():
    addr = Address()
    for i in range(10):
        addr.street_name()

# Generated at 2022-06-23 20:58:42.950851
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address('sk')
    assert a.street_name() in a._data['street']['name']
    

# Generated at 2022-06-23 20:58:45.142198
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    expected_result = 'Malibu, CA'
    result = address.region(is_abbr=False)
    assert result == expected_result

# Generated at 2022-06-23 20:58:47.602740
# Unit test for method street_number of class Address
def test_Address_street_number():
    provider = Address()
    st_num = provider.street_number()
    assert st_num is not None


# Generated at 2022-06-23 20:58:51.300539
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CardinalDirection

    a = Address()
    b = Address(CardinalDirection.NORTH)

    a.longitude()
    b.longitude()

    a.longitude(dms=True)
    b.longitude(dms=True)


# Generated at 2022-06-23 20:58:53.224130
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    try:
        assert Address().street_suffix()
    except:
        assert False


# Generated at 2022-06-23 20:58:58.098398
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    a = address.coordinates()
    print('Latitude: '+str(a['latitude']),'\nLongitude: '+str(a['longitude']))


if __name__ == "__main__":
    test_Address_coordinates()

# Generated at 2022-06-23 20:59:02.534577
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test method coordinates of class Address."""
    a = Address()
    result = a.coordinates()
    assert result.get('longitude') is not None
    assert result.get('latitude') is not None
    assert result.get('longitude') not in ('', ' ', None)
    assert result.get('latitude') not in ('', ' ', None)


# Generated at 2022-06-23 20:59:05.852826
# Unit test for method state of class Address
def test_Address_state():
    """Unit test for Address.state method of class Address."""
    assert type(Address().state()) == str
    assert type(Address().state(abbr=True)) == str


# Generated at 2022-06-23 20:59:06.832203
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert Address().postal_code()

# Generated at 2022-06-23 20:59:15.134977
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.types import Seed
    from mimesis.verifiers import verify_regex
    seed = Seed()
    address = Address(seed=seed, locale=Locale.EN)
    calling_code = address.calling_code()
    assert calling_code is not None
    assert verify_regex(r'^\+[0-9]{1,3}$', calling_code)


# Generated at 2022-06-23 20:59:16.773459
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    assert type(a.longitude()) == float
    return True

# Generated at 2022-06-23 20:59:19.441394
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis_core import Address
    test = Address()
    print(test.longitude())


# Generated at 2022-06-23 20:59:21.531632
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Test method zip_code."""
    a = Address(random_state=123)
    assert a.zip_code() == "194-0136"

# Generated at 2022-06-23 20:59:24.341527
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Test for Address.calling_code method."""
    address = Address()
    country_calling_code = address.calling_code()
    assert isinstance(country_calling_code, str)



# Generated at 2022-06-23 20:59:26.594012
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import Address
    from mimesis.enums import Gender

    addr = Address('en')

    print(addr.address())


# Generated at 2022-06-23 20:59:28.965651
# Unit test for method country of class Address
def test_Address_country():
    address=Address()
    country=address.country()
    assert isinstance(country,str)


# Generated at 2022-06-23 20:59:31.758944
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address.country_code() in COUNTRY_CODES[CountryCode.A2]


# Generated at 2022-06-23 20:59:33.633542
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address('ru')
    assert address.country_code() in COUNTRY_CODES[CountryCode.A2]
    assert address.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]



# Generated at 2022-06-23 20:59:36.535586
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Test Address street_suffix"""
    street_suffix = Address().street_suffix()
    assert street_suffix in Address.Meta.address_street_suffix


# Generated at 2022-06-23 20:59:47.729773
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address('ko')
    import re
    assert re.match(r'가 시', a.street_suffix())
    a = Address('ko')
    assert re.match(r'가 시', a.street_suffix())
    a = Address('ko')
    assert re.match(r'가 시', a.street_suffix())
    a = Address('ko')
    assert re.match(r'가 시', a.street_suffix())
    a = Address('ko')
    assert re.match(r'가 시', a.street_suffix())
    a = Address('ko')
    assert re.match(r'가 시', a.street_suffix())
    a = Address('ko')
   

# Generated at 2022-06-23 20:59:49.979267
# Unit test for method state of class Address
def test_Address_state():
    addr = Address()
    result = addr.state()
    # test length of result if it is not null
    assert len(result) > 0

# Generated at 2022-06-23 20:59:52.497239
# Unit test for method continent of class Address
def test_Address_continent():
    """
    Unit test for Address.continent
    """
    addr = Address()
    assert addr.continent() in addr._data['continent']


# Generated at 2022-06-23 20:59:55.115492
# Unit test for method state of class Address
def test_Address_state():
    #def state(self, abbr: bool = False) -> str:
    assert Address().state()
    assert Address().state(abbr=True)

# Generated at 2022-06-23 20:59:56.356773
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert isinstance(address, Address)



# Generated at 2022-06-23 21:00:03.313568
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test for method Address.coordinates"""
    from mimesis import Address
    address = Address()
    coordinates = address.coordinates()
    longitude = coordinates['longitude']
    latitude = coordinates['latitude']
    assert longitude >= -180
    assert longitude <= 180
    assert latitude >= -90
    assert latitude <= 90

# Generated at 2022-06-23 21:00:05.535164
# Unit test for method street_number of class Address
def test_Address_street_number():
    ad = Address()
    assert type(ad.street_number(maximum=10))
    assert ad.street_number(maximum=10)


# Generated at 2022-06-23 21:00:08.000249
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    result = address.longitude()
    print('Address -> longitude: ', result)
    assert isinstance(result, float)


# Generated at 2022-06-23 21:00:16.113515
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode

    a = Address()

    assert isinstance(a.address(), str)

    assert len(a.address()) > 0
    assert len(a.address().split('\n')) == 1

    assert a.street_number(maximum=200) == a.street_number(maximum=200)
    assert a.street_number() != a.street_number()
    assert a.street_number(maximum=200) != a.street_number(maximum=10000)

    assert a.street_name() != a.street_name()
    assert a.street_suffix() != a.street_suffix()

    assert a.address() != a.address()

    a = Address(locale='ru')
    assert len(a.address().split('\n')) == 1


# Generated at 2022-06-23 21:00:20.773732
# Unit test for method latitude of class Address
def test_Address_latitude():
    # Instantiate Address
    addr = Address()
    # Get a random latitude
    lat = addr.latitude()
    # Check if it is in range [-90, +90]
    assert -90 <= lat <= 90



# Generated at 2022-06-23 21:00:24.962937
# Unit test for method longitude of class Address
def test_Address_longitude():
    ad = Address(locale='en')
    r1 = ad.longitude(dms=True)
    assert r1 is not None
    r2 = ad.longitude(dms=True)
    assert r2 is not None
    assert r1 != r2


# Generated at 2022-06-23 21:00:27.730713
# Unit test for method continent of class Address
def test_Address_continent():
    """Unit test for method continent of class Address"""
    assert Address().continent() in ['Europe', 'Asia', 'Africa', 'North America', 'South America', 'Oceania', 'Antarctica']


# Generated at 2022-06-23 21:00:30.022244
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale

    a = Address(Locale.EN)
    suffix = a.street_suffix()
    assert suffix in a._data['street']['suffix']


# Generated at 2022-06-23 21:00:34.324302
# Unit test for method continent of class Address
def test_Address_continent():

    address = Address(locale="ru")

    # test it called continent
    #
    assert address.continent(code = False) == "Азия"

    # test it called calling_code
    #
    assert address.calling_code() == "47"

# Generated at 2022-06-23 21:00:43.595827
# Unit test for method country_code of class Address
def test_Address_country_code():
    # Testing countries codes
    lang = Address(locale='en')
    assert lang.country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]
    assert lang.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]
    assert lang.country_code(CountryCode.A3T) in COUNTRY_CODES[CountryCode.A3T]
    assert lang.country_code(CountryCode.NUM) in COUNTRY_CODES[CountryCode.NUM]
    assert lang.country_code(CountryCode.ITU) in COUNTRY_CODES[CountryCode.ITU]
    assert lang.country_code(CountryCode.FIFA) in COUNTRY_CODES[CountryCode.FIFA]

# Generated at 2022-06-23 21:00:45.050193
# Unit test for method state of class Address
def test_Address_state():
    print(Address(seed=123456789).state())


# Generated at 2022-06-23 21:00:55.974655
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime

    dt = Datetime()
    adr = Address(seed=dt.timestamp())
    assert adr.province() == 'AB'
    assert adr.province(abbr=True) == 'AB'
    assert isinstance(adr.province(abbr=True), str)
    assert adr.province(dt.timestamp()) == 'AB'
    assert adr.province(a=True) == 'AB'
    assert adr.province(dt.timestamp(), a=True) == 'AB'
    assert adr.province(True) == 'AB'

# Generated at 2022-06-23 21:01:01.993104
# Unit test for method street_number of class Address
def test_Address_street_number():
    """Tests for method street_number of class Address."""

    from mimesis.enums import CountryCode
    from mimesis.enums import Gender
    from mimesis.enums import PersonType
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.phone import Phone

    # Generate 10 random names, surnames and numbers
    a = Address('en')
    for i in range(10):
        print("street_number:", a.street_number())


# Generated at 2022-06-23 21:01:03.589890
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert Address.federal_subject(Address()) == Address.state(Address())



# Generated at 2022-06-23 21:01:07.195884
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Testing a method prefecture of class Address"""
    provider = Address('ru')
    prefecture = provider.prefecture()
    assert type(prefecture) is str
    assert prefecture in provider._data['state']['abbr']


# Generated at 2022-06-23 21:01:07.866630
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region()


# Generated at 2022-06-23 21:01:09.418122
# Unit test for method street_number of class Address
def test_Address_street_number():
    asser = Address()
    print("Street Number:", asser.street_number())


# Generated at 2022-06-23 21:01:10.622752
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    city = address.city()
    return city

# Generated at 2022-06-23 21:01:14.409536
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address().street_suffix() in ['St', 'St', 'Ave', 'Rd', 'Boulevard']


# Generated at 2022-06-23 21:01:19.419058
# Unit test for method latitude of class Address
def test_Address_latitude():
    adr = Address()
    try:
        assert -90 <= adr.latitude() <= 90
    except:
        print(adr.latitude())
        print('-90 <= adr.latitude() <= 90')
        raise
        
test_Address_latitude()


# Generated at 2022-06-23 21:01:27.020799
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import Country, Language
    from mimesis.providers.address import Address
    from mimesis.providers.info import Info
    from mimesis.providers.person import Person
    from mimesis.providers.phone import Phone

    class Dummy:
        pass

    dummy = Dummy()
    dummy.country_code = 'ua'
    
    address = Address(dummy)
    info = Info(Language.EN)
    person = Person(Language.EN)
    phone = Phone()

    country = address.country()
    code = address.calling_code()


    # Person
    person_fullname = person.full_name()
    person_sex = info.sex()
    person_occupation = info.occupation()
    person_username = person.username()
    person

# Generated at 2022-06-23 21:01:28.713862
# Unit test for constructor of class Address
def test_Address():
    assert Address()
    assert Address('ru')
    assert Address(locale='ru')


# Generated at 2022-06-23 21:01:31.628179
# Unit test for method city of class Address
def test_Address_city():
    """Tests the method city() of class Address."""
    addr = Address('zh')
    assert addr.city() in addr._data['city']

# Generated at 2022-06-23 21:01:35.420094
# Unit test for method country_code of class Address
def test_Address_country_code():
    print("Testing country_code")
    addr = Address("en")
    a = addr.country_code()
    print("The calling code of the country is:", a)
    assert len(a) == 2, "The length of the country code is not 2"


# Generated at 2022-06-23 21:01:37.207144
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    addr = Address(local='en')
    assert type(addr.street_suffix()) == str

# Generated at 2022-06-23 21:01:38.621294
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    suffix = address.street_suffix()
    assert suffix in address._data['street']['suffix']

# Generated at 2022-06-23 21:01:44.760262
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    from mimesis.builtins import RussiaSpecProvider

    locales = ['ru-RU', 'en-US', 'cs-CZ', 'pl-PL', 'pt-BR', 'es-ES', 'ja-JP']
    fmt = CountryCode.A2

    for loc in locales:
        address = Address(loc)
        state = address.state()
        code = address.country_code(fmt)
        locale_code = f'{code}{state}'

        if address.locale == 'ru-RU':
            assert locale_code in RussiaSpecProvider().__dict__.keys()
        else:
            assert len(state) == 2
            assert address.country_code(fmt) == code

# Generated at 2022-06-23 21:01:46.407241
# Unit test for method country of class Address
def test_Address_country():
    _address = Address()
    assert _address.country() == 'italy'

# Generated at 2022-06-23 21:01:48.421920
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    street_name = a.street_name()
    print(street_name)


# Generated at 2022-06-23 21:01:50.210365
# Unit test for method state of class Address
def test_Address_state():
    assert Address(get_locale_from_env=False).state() == '茨城県'

# Generated at 2022-06-23 21:01:51.496418
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    cities = ('Calgary', 'Montreal', 'Ottawa')
    assert a.city() in cities

# Generated at 2022-06-23 21:01:53.099549
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    suffix = address.street_suffix()
    assert suffix



# Generated at 2022-06-23 21:02:01.163409
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import DataProviderTuple, ProviderTuple
    from mimesis.typing import Seed
    from mimesis.types import AddressInfo, CustomProviderTuple

    address = Address(seed=Seed(1))
    print(address.calling_code())

    address = Address(seed=Seed(1), locale="en")
    print(address.calling_code())
    print(address.calling_code())

    address = Address(seed=Seed(1), locale="es")
    print(address.calling_code())

    address = Address(seed=Seed(1), locale="ja")
    print(address.calling_code())

    address = Address(seed=Seed(1), locale="nl")
    print(address.calling_code())


# Generated at 2022-06-23 21:02:06.532025
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Тест функции postal_code класса Address для мейджорных локалей
    test_flag_error = 0
    error = []
    keys = ['en', 'en-US', 'pt', 'en-GB', 'ja', 'en-AU', 'en-CA', 'en-IE', 'en-NZ',
            'en-ZA', 'de', 'ar', 'cs', 'el', 'it-IT', 'pl', 'ru', 'tr', 'uk', 'fr-FR']
    for key in keys:
        test_locale = Address(key)
        for i in range(10):
            code = test_locale.postal_code()

# Generated at 2022-06-23 21:02:09.832667
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    # print(address.prefecture(abbr=False))
    assert isinstance(address.prefecture(abbr=False), str)

# Generated at 2022-06-23 21:02:12.015234
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    assert address.longitude() in range(-90, 90)


# Generated at 2022-06-23 21:02:16.678831
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert Address.street_suffix(Address(), )
    assert Address.street_suffix(Address(), )
    assert Address.street_suffix(Address(), )
    assert Address.street_suffix(Address(), )
    assert Address.street_suffix(Address(), )

# Generated at 2022-06-23 21:02:27.088597
# Unit test for method country_code of class Address
def test_Address_country_code():
    
    import unittest

    class TestAddressCountryCode(unittest.TestCase):

        def test_valid_country_code(self):
            from mimesis.enums import CountryCode
            addr = Address()
            ccode = addr.country_code(CountryCode.A2)
            self.assertEqual(ccode, addr.country_code())
            self.assertEqual(len(ccode), 2)
            assert isinstance(ccode, str)

            ccode = addr.country_code(CountryCode.A2)
            self.assertEqual(len(ccode), 2)
            assert isinstance(ccode, str)

            ccode = addr.country_code(CountryCode.A3)
            self.assertEqual(len(ccode), 3)
            assert isinstance(ccode, str)

# Generated at 2022-06-23 21:02:30.331273
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    print(a.latitude())


# Generated at 2022-06-23 21:02:31.376608
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    result = address.address()
    assert result is not None


# Generated at 2022-06-23 21:02:32.601940
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    print(a.country_code())


# Generated at 2022-06-23 21:02:42.668193
# Unit test for method country of class Address
def test_Address_country():
    """unit test for method country of class Address"""
    from mimesis.enums import Locale
    from mimesis.builtins import country as country_enums
    from mimesis import address

    addr = address.Address(Locale.EN)

    country_dict = {
        'locale': 'en',
        'country': 'country',
    }

    assert addr.country(allow_random=True) in country_dict['country']  # noqa

    assert addr.country(allow_random=True) == "China" or addr.country(allow_random=True) == "Taiwan" or addr.country(allow_random=True) == "Hong Kong" or addr.country(allow_random=True) == "Macau" or addr.country(allow_random=True) == "Korea" 


# Generated at 2022-06-23 21:02:44.918996
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address().longitude() >= -180 and Address().longitude() <= 180


# Generated at 2022-06-23 21:02:45.834204
# Unit test for method street_name of class Address
def test_Address_street_name():
    pass


# Generated at 2022-06-23 21:02:51.053643
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address_A = Address('ru')
    postal_code_A = address_A.postal_code()
    assert len(postal_code_A) == 6
    assert postal_code_A[:2].isdigit()
    assert postal_code_A[2] == ' '
    assert postal_code_A[3:].isdigit()


# Generated at 2022-06-23 21:02:59.401814
# Unit test for method country_code of class Address
def test_Address_country_code():
    #Test_1: fmt = CountryCode.A2
    a = Address(locale = 'ca')
    result = a.country_code(fmt = CountryCode.A2)
    assert result in [x['alpha_2_code'] for x in COUNTRY_CODES['A2']]

    #Test_2: fmt = CountryCode.A3
    a = Address(locale = 'ca')
    result = a.country_code(fmt = CountryCode.A3)
    assert result in [x['alpha_3_code'] for x in COUNTRY_CODES['A3']]

    #Test_3: fmt = CountryCode.NUMERIC
    a = Address(locale = 'ca')
    result = a.country_code(fmt = CountryCode.NUMERIC)

# Generated at 2022-06-23 21:03:04.570026
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code(CountryCode.A1) == "PR"
    assert Address().country_code(CountryCode.A2) == "PR"
    assert Address().country_code(CountryCode.A3) == "PRI"
    assert Address().country_code(CountryCode.NUM) == "630"

# Generated at 2022-06-23 21:03:11.404749
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    from mimesis.providers import Address

    # A2
    assert Address.country_code() in COUNTRY_CODES[CountryCode.A2]

    # A3
    assert Address.country_code(CountryCode.A3) in COUNTRY_CODES[CountryCode.A3]

    # Numeric
    assert Address.country_code(CountryCode.NUMERIC) in COUNTRY_CODES[CountryCode.NUMERIC]



# Generated at 2022-06-23 21:03:14.674108
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    from mimesis.enums import CountryCode
    address = Address(random.choice(['en', 'ru']))
    assert address.federal_subject() != address.federal_subject()
    assert isinstance(address.federal_subject(True), str)
    addr = Address('en')
    assert addr.federal_subject(True) not in COUNTRY_CODES[CountryCode.A2]
    assert addr.federal_subject() not in addr._data['state']['abbr']
    assert '_' in address.federal_subject()


# Generated at 2022-06-23 21:03:17.043698
# Unit test for method region of class Address
def test_Address_region():
    a = Address(locale='cn')
    res = a.region()
    assert isinstance(res, str) and len(res) > 0

# Generated at 2022-06-23 21:03:20.028718
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address()
    res = address.longitude()
    assert type(res) == float
    print('method longitude of class Address done!')


# Generated at 2022-06-23 21:03:22.209299
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert (Address.federal_subject(abbr=True) != None)
    assert (Address.federal_subject(abbr=False) != None)


# Generated at 2022-06-23 21:03:24.708599
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() is not None
    assert type(address.address()) is str


# Generated at 2022-06-23 21:03:26.659748
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    zip_ = Address()
    assert zip_ == Address.__init__()


# Generated at 2022-06-23 21:03:28.291299
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address(locale='en')
    assert address.calling_code() in ['92', '508', '36']

# Generated at 2022-06-23 21:03:29.593386
# Unit test for constructor of class Address
def test_Address():
    """Unit test for constructor of class Address"""
    address = Address()
    assert address != None
    assert address.__class__.__name__ == "Address"

# Generated at 2022-06-23 21:03:31.610781
# Unit test for method latitude of class Address
def test_Address_latitude():
    addr = Address('zh')
    input_latitude = addr.latitude()
    assert isinstance(input_latitude, float), '_Address_latitude fail'


# Generated at 2022-06-23 21:03:33.546184
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    assert address.city()
    assert address.city()
    assert address.city()
    assert address.city()
    assert address.city()


# Generated at 2022-06-23 21:03:36.744522
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.data import US_POSTAL_CODES_REGEX

    pattern = US_POSTAL_CODES_REGEX
    address = Address(locale='en')
    zipcode = address.zip_code()
    assert isinstance(zipcode, str)
    assert re.match(pattern, zipcode)



# Generated at 2022-06-23 21:03:37.385033
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    pass

# Generated at 2022-06-23 21:03:38.984959
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    result = Address().postal_code()
    assert result


# Generated at 2022-06-23 21:03:43.414946
# Unit test for method street_name of class Address
def test_Address_street_name():
    # Init class
    addr = Address()

    # Get street name
    name = addr.street_name()

    # Test substrings
    assert all(part in name for part in ("street", "st."))



# Generated at 2022-06-23 21:03:51.098873
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    from mimesis.enums import Gender
    a = Address('en')
    assert isinstance(a.address(), str)
    assert len(a.address()) > 0
    assert isinstance(a.address('en'), str)
    assert len(a.address()) > 0
    assert isinstance(a.address('es'), str)
    assert len(a.address()) > 0
    assert isinstance(a.address('fr'), str)
    assert len(a.address()) > 0
    assert isinstance(a.address('it'), str)
    assert len(a.address()) > 0
    assert isinstance(a.address('pt'), str)
    assert len(a.address()) > 0
    assert isinstance(a.address('cn'), str)
    assert len(a.address()) > 0

# Generated at 2022-06-23 21:03:52.850693
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    addr = Address()
    result = addr.calling_code()
    assert result in CALLING_CODES

# Generated at 2022-06-23 21:03:58.229342
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    path_datafile = "C:\\Users\\Eric\\Desktop\\mimesis\\mimesis\\data\\address.json"
    a = Address(locale='zh-CN', file_path=path_datafile)
    print(a.coordinates())


# Generated at 2022-06-23 21:04:00.173104
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    region = address.region()
    assert region
    assert len(region) > 0


# Generated at 2022-06-23 21:04:02.517378
# Unit test for method country of class Address
def test_Address_country():
    address_provider = Address(locale='en')
    assert isinstance(address_provider.country(), str)
    assert isinstance(address_provider.country(allow_random=True), str)


# Generated at 2022-06-23 21:04:05.648289
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    code = address.country_code()
    assert len(code) == 2


# Generated at 2022-06-23 21:04:06.744125
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert a.region()

# Generated at 2022-06-23 21:04:12.464760
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.utils import get_locales
    from mimesis.verifiers import is_valid_prefecture

    address = Address('en')
    for locale in get_locales():
        address = Address(locale)
        prefecture = address.prefecture()
        is_valid_prefecture(prefecture, address.locale)

# Generated at 2022-06-23 21:04:14.814493
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    assert isinstance(a.street_suffix(), str)


# Generated at 2022-06-23 21:04:17.114626
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    x = Address(locale='en')
    s = x.street_suffix()
    assert(s)


# Generated at 2022-06-23 21:04:18.921976
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    print(address.prefecture())


# Generated at 2022-06-23 21:04:22.271158
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    long = address.longitude()
    lat = address.latitude()
    test = {'longitude': long, 'latitude': lat}
    assert test == address.coordinates()

# Generated at 2022-06-23 21:04:24.038661
# Unit test for method province of class Address
def test_Address_province():
    addr = Address()
    assert isinstance(addr.province(), str)

# Generated at 2022-06-23 21:04:25.978037
# Unit test for method city of class Address
def test_Address_city():
    address = Address()
    city = address.city()
    assert city

# Generated at 2022-06-23 21:04:27.472657
# Unit test for method latitude of class Address
def test_Address_latitude():
    for i in range(100):
        print(Address().latitude())


# Generated at 2022-06-23 21:04:29.340465
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert a.region() in a._data['state']['abbr']

# Generated at 2022-06-23 21:04:41.108267
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    print("Test Address.postal_code()...")
    adr = Address('en')
    postal_code1 = adr.postal_code()
    assert len(postal_code1) == 5
    assert postal_code1.isdigit() == True
    print(postal_code1)

    postal_code2 = adr.postal_code()
    assert len(postal_code2) == 5
    assert postal_code2.isdigit() == True
    print(postal_code2)

    adr.set_locale('ru')
    postal_code3 = adr.postal_code()
    assert len(postal_code3) == 6
    assert postal_code3.isdigit() == True
    print(postal_code3)


# Generated at 2022-06-23 21:04:41.805915
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    pass

# Generated at 2022-06-23 21:04:44.462242
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.builtins import RussiaSpecProvider
    address = Address(RussiaSpecProvider)
    assert address.region() in address._data['country']['region']

# Generated at 2022-06-23 21:04:52.742197
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    from mimesis import Address

    address = Address('en')
    assert address.state() in address._data['state']['name']

    assert address.region() == address.state()

    assert address.province() == address.state()

    assert address.federal_subject() == address.state()

    assert address.prefecture() == address.state()

    assert address.state(abbr=True) in address._data['state']['abbr']

    assert address.region(abbr=True) == address.state(abbr=True)

    assert address.province(abbr=True) == address.state(abbr=True)

    assert address.federal_subject(abbr=True) == address.state(abbr=True)

    assert address.prefecture

# Generated at 2022-06-23 21:04:57.330878
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address("zh")
    random_continent = address.continent()
    assert random_continent in ["亚洲", "非洲", "美洲", "欧洲", "大洋洲"]

# Generated at 2022-06-23 21:05:00.596415
# Unit test for method street_number of class Address
def test_Address_street_number():
    a = Address()
    assert isinstance(a.street_number(), str)
    assert 1 <= int(a.street_number()) <= 1400


# Generated at 2022-06-23 21:05:02.387040
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    assert address.street_name() in address._data['street']['name']

# Generated at 2022-06-23 21:05:03.515423
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    assert Address().province()
    assert Address().province(abbr=True)

# Generated at 2022-06-23 21:05:06.377143
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address is not None


# Generated at 2022-06-23 21:05:09.070300
# Unit test for method state of class Address
def test_Address_state():
    """Test method state of class Address.
    """
    address = Address()
    result = address.state()
    assert isinstance(result, str)


# Generated at 2022-06-23 21:05:12.566681
# Unit test for method country of class Address
def test_Address_country():
    a = Address(locale='en')
    assert a.country() == 'United Kingdom'
    assert a.country(allow_random=True) in ['United Kingdom', 'United States']


# Generated at 2022-06-23 21:05:14.207858
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address(locale='en')
    coord = address.coordinates()
    assert isinstance(coord, dict)

# Generated at 2022-06-23 21:05:16.679679
# Unit test for method city of class Address
def test_Address_city():
    address = Address("en")
    assert address.city() in ["Hull", "Birmingham", "Bristol"]


# Generated at 2022-06-23 21:05:25.693503
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    provider = Address(locale='en')
    assert provider.postal_code() == 'V5K5J5'
    assert provider.postal_code() == 'L2E2A9'
    assert provider.postal_code() == 'E1W3K8'
    assert provider.postal_code() == 'K8P2G2'
    assert provider.postal_code() == 'T6T1R6'
    assert provider.postal_code() == 'K1A1E1'
    assert provider.postal_code() == 'P2L2A2'
    assert provider.postal_code() == 'J1E5V8'
    assert provider.postal_code() == 'J1Z1L6'

# Generated at 2022-06-23 21:05:35.391387
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import CountryCode
    from mimesis.enums import Locale
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import Address
    from mimesis.builtins import Person
    address = Address(locale='ru')
    person = Person(locale='ru')
    tmp = Address('ru')
    address.longitude()
    """
    Unit test for method longitude of class Address
    Verifies the validity of the method by comparing the result with a known value
    :return:
    """
    assert address.longitude(dms=False) in range(-180, 180)


# Generated at 2022-06-23 21:05:36.446831
# Unit test for method region of class Address
def test_Address_region():
    address = Address()
    assert address.region() # Test first call
    assert address.region() # Test the next call


# Generated at 2022-06-23 21:05:39.014641
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    ad = Address()
    postal_code = ad.postal_code()
    print(postal_code)

# # Unit test for method zip_code of class Address

# Generated at 2022-06-23 21:05:42.073011
# Unit test for method state of class Address
def test_Address_state():
    assert Address().state(True) in Address()._data['state']['abbr']
    assert Address().state() in Address()._data['state']['name']


# Generated at 2022-06-23 21:05:47.029936
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Create data."""
    from mimesis.enums import DataField
    from random import uniform
    from mimesis.data import COUNTRY_CODES

    address = Address()
    data = {}
    for name in COUNTRY_CODES[DataField.NAME.value]:
        data[name] = {
            'longitude': uniform(-180, 180),
            'latitude': uniform(-90, 90)
        }
    print('data = {}'.format(str(data)))
    address.set_data(data)

    # Test with dummy countries
    for country in COUNTRY_CODES[DataField.NAME.value]:
        print('country = {}'.format(country))
        address.set_locale(country)
        coord = address.coordinates()
        assert isinstance(coord, dict)

# Generated at 2022-06-23 21:05:51.011739
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address("zh")
    for i in range(100):
        assert address.street_suffix() in [
            '内大街', '外大街', '中街', '西街', '南街', '北街', '北一道', '北二道', '南一道', '南二道', '西一道', '西二道', '东大街', '西大街', '南大街', '北大街'
        ]


# Generated at 2022-06-23 21:05:54.719230
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    result = address.latitude()
    assert isinstance(result, (int, float)), 'result is not a number'
    assert result >= -90, 'result is not less than -90'
    assert result <= 90, 'result is not bigger than 90'
    assert result != 0, 'result is equal to 0'


# Generated at 2022-06-23 21:05:56.470735
# Unit test for method street_number of class Address
def test_Address_street_number():
    data = Address().street_number()
    print(data)


# Generated at 2022-06-23 21:06:02.264162
# Unit test for method state of class Address

# Generated at 2022-06-23 21:06:05.037438
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    assert address.coordinates() == {
        'longitude': -9.927878,
        'latitude': -37.529782,
    }


# Generated at 2022-06-23 21:06:06.726700
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    assert address.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:06:08.623579
# Unit test for method state of class Address
def test_Address_state():
    a = Address()

    assert(a.state() == 'Maine')
    assert(a.state(True) == 'ME')


# Generated at 2022-06-23 21:06:11.338768
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    assert address.continent() in ['Europe', 'Africa', 'Antarctica', 'Oceania', 'Asia', 'North America', 'South America']


# Generated at 2022-06-23 21:06:13.971844
# Unit test for method country of class Address
def test_Address_country():
    assert 'Россия' == Address('ru').country()
    assert 'Russia' == Address('en').country()
    assert 'Росія' == Address('uk').country()

# Generated at 2022-06-23 21:06:14.765048
# Unit test for method country of class Address
def test_Address_country():
    Address.country()


# Generated at 2022-06-23 21:06:18.393590
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    r = a._get_random_obj()
    z = a.calling_code()
    print("Random number",r)
    print("Calling code",z, sep ="\n")


# Generated at 2022-06-23 21:06:21.357199
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()

    # Test
    assert len(a.coordinates(dms=False).keys()) == 2
    assert len(a.coordinates(dms=True).keys()) == 2


# Generated at 2022-06-23 21:06:24.679184
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    assert len(a.coordinates()) == 2
    assert type(a.coordinates()) == dict
    assert len(a.coordinates(dms=True)) == 2
    assert type(a.coordinates(dms=True)) == dict

# Generated at 2022-06-23 21:06:27.081651
# Unit test for method continent of class Address
def test_Address_continent():
    # Preparation
    addr = Address()
    # Action
    result = addr.continent()
    # Result
    assert isinstance(result, str)
    assert result in addr._data['continent']


# Generated at 2022-06-23 21:06:31.156240
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    test_base = Address()
    test_cc = test_base.calling_code()

    print(test_cc)
    assert len(test_cc) > 0
    assert 0 <= len(test_cc) <= 3


# Generated at 2022-06-23 21:06:42.787417
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # Test for method address of class Address
    # Test for address in Russian language
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    import re
    import unittest

    class TestAddress(unittest.TestCase):
        def setUp(self):
            self.rus = Address('ru')

        def test_address(self):
            result = self.rus.address()
            actual = re.match(r'\d{1,4}\s.+\s.+\s', result)
            self.assertIs(bool(actual), True)

        def test_state(self):
            result = self.rus.state()
            actual = re.match(r'\w{3}\.\s.+', result)

# Generated at 2022-06-23 21:06:46.666417
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    pr = Address(locale='en')
    suffixes = ['Avenue', 'Circle', 'Drive', 'Court', 'Lane', 'Parkway',
        'Place', 'Road', 'Square', 'Street']
    for i in range(10):
        assert pr.street_suffix() in suffixes


# Generated at 2022-06-23 21:06:47.553834
# Unit test for method city of class Address
def test_Address_city():
    return Address("es").city()


# Generated at 2022-06-23 21:06:50.795216
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    ad = Address()
    for i in range(5):
        assert len(ad.calling_code()) == 3


# Generated at 2022-06-23 21:06:57.556251
# Unit test for method country_code of class Address
def test_Address_country_code():
    result = Address().country_code()
    assert result in COUNTRY_CODES[CountryCode.A2]

    result = Address().country_code(fmt=CountryCode.A3)
    assert result in COUNTRY_CODES[CountryCode.A3]

    result = Address().country_code(fmt=CountryCode.NUMERIC)
    assert result in COUNTRY_CODES[CountryCode.NUMERIC]

# Generated at 2022-06-23 21:07:04.578406
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Unit test for method zip_code of
    class Address with the following steps:
        1. Create a Address object.
        2. Use method zip_code.
        3. Compare the result with a known result.
    """
    address_obj=Address()
    assert address_obj.zip_code()!=address_obj.zip_code()
    assert address_obj.zip_code()!=""
    assert type(address_obj.zip_code()) is str


# Generated at 2022-06-23 21:07:06.494601
# Unit test for method address of class Address
def test_Address_address():
    assert Address('en').address() == '2295 Miguel Centers'


# Generated at 2022-06-23 21:07:08.511501
# Unit test for constructor of class Address
def test_Address():
    a = Address(locale='uk')
    print(a.city(), a.address(), a.postal_code(), a.country(), sep=' | ')

# Generated at 2022-06-23 21:07:09.882808
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    add = Address('ru')
    assert isinstance(add.coordinates(), dict)

# Generated at 2022-06-23 21:07:11.585498
# Unit test for method address of class Address
def test_Address_address():
    ad = Address()
    result = ad.address()
    assert() is not None


# Generated at 2022-06-23 21:07:18.309640
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    ua = Address('uk')
    assert ua.postal_code() == '606XX'
    assert ua.zip_code() == ua.postal_code()

    ru = Address('ru')
    assert ru.postal_code() == '193460'

    br = Address('br')
    assert br.postal_code() == '18290-000'


# Generated at 2022-06-23 21:07:19.119792
# Unit test for method province of class Address
def test_Address_province():
    x = Address("fr").province()
    assert isinstance(x,str)

# Generated at 2022-06-23 21:07:24.323844
# Unit test for method continent of class Address
def test_Address_continent():
    """
    Unit test method continent of class Address
    This method test the correctness of function return
    value

    :return: None
    """
    # Initialize an Address
    address = Address(local="English", seed=1234)
    test_result = address.continent()
    assert test_result == "Africa"


# Generated at 2022-06-23 21:07:26.572356
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from random import Random

    randomInstance = Random()

    address = Address(randomInstance)
    address.coordinates()
    address.coordinates(dms=True)


# Generated at 2022-06-23 21:07:28.691621
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code() in ['241', '253', '242']

# Generated at 2022-06-23 21:07:31.381514
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.builtins import Address
    street_suffix = Address(locale='es').street_suffix()
    print(street_suffix)
    assert street_suffix != None


# Generated at 2022-06-23 21:07:34.138074
# Unit test for method country of class Address
def test_Address_country():
    address = Address()
    assert address.country(allow_random=True)


# Generated at 2022-06-23 21:07:37.560772
# Unit test for method continent of class Address
def test_Address_continent():
    """Test method continent of class Address."""
    addr = Address(locale='ru')
    assert isinstance(addr.continent(), str)
    assert len(addr.continent()) == len(addr.continent(code=True))


# Generated at 2022-06-23 21:07:40.020551
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.builtins import address
    print(address.Address().street_name())

if __name__ == "__main__":
    test_Address_street_name()

# Generated at 2022-06-23 21:07:42.537285
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address()
    name = address.continent()
    assert name

    code = address.continent(code=True)
    assert code



# Generated at 2022-06-23 21:07:48.596079
# Unit test for method country_code of class Address
def test_Address_country_code():
    a1 = Address()
    assert (a1.country_code(CountryCode.A3) in COUNTRY_CODES['A3'])
    assert (a1.country_code(CountryCode.N3) in COUNTRY_CODES['N3'])
    assert (a1.country_code(CountryCode.NA) not in CALLING_CODES)
    assert (a1.country_code(CountryCode.A2) in COUNTRY_CODES['A2'])
    assert (a1.country_code(CountryCode.A2) in COUNTRY_CODES['A2'])
    assert (a1.country_code(CountryCode.N2) in COUNTRY_CODES['N2'])


# Generated at 2022-06-23 21:07:50.164957
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    unit_test_Address_prefecture = Address()
    print(unit_test_Address_prefecture.prefecture())


# Generated at 2022-06-23 21:07:51.657570
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() != 'Region'

# Generated at 2022-06-23 21:07:53.225189
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    assert Address().zip_code() == '94211'


# Generated at 2022-06-23 21:07:55.209347
# Unit test for method street_name of class Address
def test_Address_street_name():
    instance = Address(local='en-US')
    assert isinstance(instance.street_name(), str)

# Generated at 2022-06-23 21:07:56.084911
# Unit test for constructor of class Address
def test_Address():
    return Address()

# Generated at 2022-06-23 21:07:59.751407
# Unit test for method province of class Address
def test_Address_province():
    provincia = Address('es')
    data = provincia.province()
    assert data in ['Misiones', 'Santa Fe', 'Mendoza', 'Buenos Aires', 'Tierra del Fuego, Antártida e Islas del Atlántico Sur']


# Generated at 2022-06-23 21:08:02.161179
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.builtins import Address as Addr
    assert isinstance(Addr().prefecture(), str)


# Generated at 2022-06-23 21:08:03.539300
# Unit test for method state of class Address
def test_Address_state():
    print(Address().state())
    print(Address().state(True))


# Generated at 2022-06-23 21:08:09.098004
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    provider = Address(locale='ru')
    assert provider.federal_subject() in provider._data['state']['name']

    provider = Address(locale='ru')
    assert provider.federal_subject(abbr=True) in provider._data['state']['abbr']

    provider = Address(locale='en')
    assert provider.federal_subject() in provider._data['state']['name']


# Generated at 2022-06-23 21:08:11.690993
# Unit test for method zip_code of class Address
def test_Address_zip_code():
	address = Address('en')
	assert isinstance(address.zip_code(), str)


# Generated at 2022-06-23 21:08:12.973504
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    print(address.prefecture())

# Generated at 2022-06-23 21:08:13.712377
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    assert address.postal_code() == '33842'

# Generated at 2022-06-23 21:08:15.778454
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    a.province()
    assert True




# Generated at 2022-06-23 21:08:17.445959
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert isinstance(a, Address)


# Generated at 2022-06-23 21:08:19.261682
# Unit test for method country of class Address
def test_Address_country():
    assert Address(use_cache=True).country() == 'Japan'
