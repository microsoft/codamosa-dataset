

# Generated at 2022-06-23 20:58:23.106657
# Unit test for constructor of class Address
def test_Address():
    n = Address()
    assert n.provider == 'address'

# Generated at 2022-06-23 20:58:26.608194
# Unit test for constructor of class Address
def test_Address():
    addr = Address()
    assert addr is not None


# Generated at 2022-06-23 20:58:35.745391
# Unit test for constructor of class Address
def test_Address():
    address = Address()
    assert address.address() is not None # test address()
    assert address.street_name() is not None # test street_name()
    assert address.street_number() is not None # test street_number()
    assert address.street_suffix() is not None # test street_suffix()
    assert address.state() is not None # test state()
    assert address.region() is not None # test region()
    assert address.province() is not None # test province()
    assert address.federal_subject() is not None # test federal_subject()
    assert address.prefecture() is not None # test prefecture()
    assert address.postal_code() is not None # test postal_code()
    assert address.zip_code() is not None # test zip_code()
    assert address.country_code()

# Generated at 2022-06-23 20:58:40.004361
# Unit test for method city of class Address
def test_Address_city(): # pragma: no cover
    from mimesis.enums import Locale

    a = Address(locale=Locale.RUSSIAN)
    print(a.city())



# Generated at 2022-06-23 20:58:42.794099
# Unit test for method continent of class Address
def test_Address_continent():
    assert Address().continent() in ('Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America')


# Generated at 2022-06-23 20:58:44.366325
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address(use_cache=False).street_name() != ' '


# Generated at 2022-06-23 20:58:53.515966
# Unit test for method street_name of class Address
def test_Address_street_name():
    from pathlib import Path
    from mimesis.enums import Locale

    # test for es_CL
    a = Address(locale=Locale.ES_CL)
    path_to_json = Path('mimesis/providers/address/es_CL.json')
    with open(path_to_json, 'r') as f:
        data = f.read()
    assert a.street_name() in data

    # test for es_MX
    a = Address(locale=Locale.ES_MX)
    path_to_json = Path('mimesis/providers/address/es_MX.json')
    with open(path_to_json, 'r') as f:
        data = f.read()
    assert a.street_name() in data

    # test for es_ES
    a

# Generated at 2022-06-23 20:58:57.345728
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from . import Address

    address = Address()
    assert type(address.state()) is str
    assert address.state() == "TN"


# Generated at 2022-06-23 20:59:05.963383
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address(seed=42)
    assert address.street_suffix() == 'Rd'
    #
    address = Address(seed=2)
    assert address.street_suffix() == 'St'
    #
    address = Address(seed=552532)
    assert address.street_suffix() == 'Ave'
    #
    address = Address(seed=666)
    assert address.street_suffix() == 'Lane'
    #
    address = Address(seed=38)
    assert address.street_suffix() == 'Way'
    #
    address = Address(seed=345)
    assert address.street_suffix() == 'Pl'
    #
    address = Address(seed=6543)
    assert address.street_suffix() == 'Dr'
    #
    address = Address

# Generated at 2022-06-23 20:59:07.953844
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province() in address._data['state']['name']

# Generated at 2022-06-23 20:59:10.896937
# Unit test for constructor of class Address
def test_Address():
    locale = 'en'
    add = Address(locale)

    assert add.locale == locale


# Generated at 2022-06-23 20:59:14.828094
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Unit test for method 'zip_code'."""
    address = Address()
    assert address.zip_code() == address.postal_code()
    # Just call method, but exclude functional test.
    address.zip_code()

# Generated at 2022-06-23 20:59:16.474885
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()

    assert address.postal_code() is not None


# Generated at 2022-06-23 20:59:18.107362
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert isinstance(address.federal_subject(), str)


# Generated at 2022-06-23 20:59:20.552498
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address('en')
    result = address.street_name()
    assert isinstance(result, str)


# Generated at 2022-06-23 20:59:29.075178
# Unit test for constructor of class Address
def test_Address():
    """Unit test."""
    a = Address()
    print(a.state())
    print(a.state(abbr=True))
    print(a.region())
    print(a.region(abbr=True))
    print(a.province())
    print(a.province(abbr=True))
    print(a.prefecture())
    print(a.prefecture(abbr=True))
    print(a.federal_subject())
    print(a.federal_subject(abbr=True))
    print(a.city())
    print(a.street_number())
    print(a.street_suffix())
    print(a.street_name())
    print(a.address())
    print(a.country())
    print(a.country_code())

# Generated at 2022-06-23 20:59:33.965546
# Unit test for method street_name of class Address
def test_Address_street_name():
    test_num = 20
    a = Address()
    expectation_list = ['Main', 'High', 'Park', 'Washington', 'Lake']
    assert(all([item in expectation_list for item in [a.street_name() for _ in range(test_num)]]))


# Generated at 2022-06-23 20:59:39.778540
# Unit test for method latitude of class Address
def test_Address_latitude():
    '''
    The test_Address_latitude function tests the latitude function

    1. Create an Address object
    2. Create a list of fake latitude
    3. Assert that the latitude function is valid
    '''
    city = Address(seed=1234)
    print(city.latitude(),city.latitude(dms=True))
    print(city.latitude(),city.latitude(dms=True))


# Generated at 2022-06-23 20:59:46.570742
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # PYTHONPATH=./:.. LOCALE=it python tests/test_address.py Address.postal_code
    from mimesis.builtins import address

    # Test Locale 'it'.
    address_it = address('it')
    result = address_it.postal_code()
    expected = 'NN111'

    assert isinstance(result, str)
    assert len(result) == len(expected)
    assert result.isdigit()


# Generated at 2022-06-23 20:59:51.897760
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    a = Address('es')
    a.country_code(CountryCode.A2)
    a.country_code(CountryCode.A3)
    a.country_code(CountryCode.NUMERIC)

    a.address()
    a.address()

    from mimesis.builtins import address

# Generated at 2022-06-23 20:59:55.626861
# Unit test for method province of class Address
def test_Address_province():
    from mimesis.enums import Locale

    ar = Address(Locale.ARABIC)
    assert ar.province() in ar._data['state']['name']
    assert ar.province(abbr=True) in ar._data['state']['abbr']

# Generated at 2022-06-23 21:00:00.551194
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    addr = Address()
    data = addr.calling_code()
    assert len(data) == 2 or len(data) == 3
    assert len(data) > 0

# Generated at 2022-06-23 21:00:02.142532
# Unit test for method continent of class Address
def test_Address_continent():
    provider=Address()
    result=provider.continent()
    assert result in ('Europe', 'North America', 'South America', 'Asia', 'Africa', 'Oceania')

# Generated at 2022-06-23 21:00:08.168175
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    path = '~/Desktop/zProjects/mimesis-project/mimesis/data/address.json'
    address = open(path, 'r')
    address_dict = ast.literal_eval(address.read())
    s = address_dict.get('street')
    name = s.get('name')
    x = a.street_name()
    print(x)
    assert x in name


# Generated at 2022-06-23 21:00:13.314511
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    addr = Address()
    print(addr.calling_code())  # +7
    print(addr.country_code())  # KZ
    print(addr.country_code(CountryCode.A3))  # KAZ
    print(addr.country_code(CountryCode.FULL_NAME))  # Kazakhstan
    print(addr.country_code())  # KZ
    print(addr.country_code(CountryCode.NUMERIC))  # 398

# Generated at 2022-06-23 21:00:15.959761
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    result = address.street_number()
    assert result.isdigit()
    print(result)



# Generated at 2022-06-23 21:00:26.611799
# Unit test for method country of class Address
def test_Address_country():
    # Test country method of class Address
    from mimesis.enums import Country, AddressField
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography

    g = Geography()
    c = Address(c=g.country(country=Country.POLAND))
    assert c.country() == g.country().split(' ')[0]
    assert c.country(allow_random=True) != g.country().split(' ')[0]
    assert Address.country(c) == g.country().split(' ')[0]
    assert Address.country(c, allow_random=True) != g.country().split()[0]


# Generated at 2022-06-23 21:00:28.180156
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    assert isinstance(a, Address)
    assert isinstance(a.address(), str)


# Generated at 2022-06-23 21:00:35.365457
# Unit test for constructor of class Address
def test_Address():
    from mimesis.providers.address import Address
    from mimesis.enums import CountryCode
    from mimesis.utils import DEFAULT_LOCALE

    address = Address(DEFAULT_LOCALE)

    assert address.province() is not None
    assert address.federal_subject() is not None
    assert address.region() is not None
    assert address.prefecture() is not None
    assert address._get_fs('lt') is not None
    assert address._get_fs('lt') is not None
    assert address._get_fs('lt', True) is not None
    assert address.city() is not None
    assert address.country() is not None
    assert address.country_code(CountryCode.NUMERIC) is not None
    assert address.country_code(CountryCode.A2) is not None

# Generated at 2022-06-23 21:00:38.138027
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address(random_state=1)
    actual = address.street_suffix()
    expected = 'Avenue'
    assert actual == expected


# Generated at 2022-06-23 21:00:39.115594
# Unit test for constructor of class Address
def test_Address():
    x = Address()
    assert x


# Generated at 2022-06-23 21:00:40.665828
# Unit test for method city of class Address
def test_Address_city():
    obj_address = Address('en')
    result = obj_address.city()
    assert result


# Generated at 2022-06-23 21:00:43.127502
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    assert isinstance(a.street_name(), str)
    assert a.street_name() in a._data['street']['name']


# Generated at 2022-06-23 21:00:48.035395
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name()
    assert Address(seed=1).street_name() == 'آرژانتین'
    assert Address(seed=1, locale='ru').street_name() == 'Бавария'

# Generated at 2022-06-23 21:00:49.870395
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a = Address()
    for _ in range(10):
        print(a.zip_code())

# Generated at 2022-06-23 21:00:57.948369
# Unit test for method country of class Address
def test_Address_country():
    expected = ['Brazil', 'Brasil', 'Brazil', 'Brésil', 'Brasilien', 'Bresil',
                'Brazílie', 'Brésil', 'Brasilia', 'Brazylia', 'Brazil',
                'Brazili', 'Brasilien', 'Brazil', '汉语', '한국어',
                'Brasil', 'Brasiilia', 'Brasília', 'Бразилия', 'Brasil',
                'Brasília']

    actual = [Address().country() for _ in range(21)]
    assert actual == expected

# Generated at 2022-06-23 21:01:06.123273
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    import mimesis.builtins
    class CustomRandom(mimesis.builtins.Mimesis):
        def __init__(self, seed=None):
            self.seed = seed
            self.random = random.Random(seed)
            self.special = mimesis.builtins.Special()
            self.address = Address(seed=seed)
        def choice(self, container):
            return random.choice(container)
    r = CustomRandom(seed=1)
    for i in range(50):
        v = r.address.calling_code()
        assert v == '7'


# Generated at 2022-06-23 21:01:09.810991
# Unit test for method continent of class Address
def test_Address_continent():
    a = Address( 'en' )
    assert a.continent() in [
        'Africa',
        'Antarctica',
        'Asia',
        'Europe',
        'North America',
        'Oceania',
        'South America',
        'Australia'
    ]

test_Address_continent()

# Generated at 2022-06-23 21:01:15.177736
# Unit test for constructor of class Address
def test_Address():
    provider = Address
    assert provider('en').country() == 'United States'
    assert provider('en').country_code() == 'US'
    assert provider('en').street_name() == 'Johnson'
    assert provider('en').city() == 'Birmingham'


test_Address()

# Generated at 2022-06-23 21:01:25.028265
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from mimesis.enums import Locale
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person
    for el in [Locale.EN, Locale.RU, Locale.UK, Locale.DE]:
        adr = Address(el)
        print('{} -> {}'.format(el, adr.street_suffix()))
    for el in [Locale.EN, Locale.RU, Locale.UK, Locale.DE]:
        adr = Address(el)
        print('{} -> {}'.format(el, adr.street_suffix()))
    for el in [Locale.EN, Locale.RU, Locale.UK, Locale.DE]:
        ad

# Generated at 2022-06-23 21:01:25.870226
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code() == 'US'

# Generated at 2022-06-23 21:01:33.466685
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Test postal_code() method."""
    address = Address()
    postal_code = address.postal_code()

    assert postal_code

    postal_code = address.postal_code()
    assert postal_code

    postal_code = address.postal_code()
    assert postal_code

    postal_code = address.postal_code()
    assert postal_code

    postal_code = address.postal_code()
    assert postal_code

    postal_code = address.postal_code()
    assert postal_code

    postal_code = address.postal_code()
    assert postal_code

    postal_code = address.postal_code()
    assert postal_code

# Generated at 2022-06-23 21:01:35.867020
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    my_address = Address()
    my_postal_code = my_address.postal_code()
    # Postcode can't be empty
    assert my_postal_code
    # Print the generated postal code
    print(my_postal_code)


# Generated at 2022-06-23 21:01:36.830403
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    print(a)

# Generated at 2022-06-23 21:01:42.560723
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    """Unit test for Address().prefecture()"""
    # default locale
    try:
        address = Address()
        assert address.prefecture() in ['Fukui', 'Kōchi', 'Shiga',\
            'Fukuoka', 'Niigata', 'Hiroshima', 'Kyoto', 'Gifu',\
            'Wakayama', 'Miyazaki', 'Fukushima', 'Kagoshima', 'Akita']
    except Exception as e:
        print(e)
        assert False

    # locale is ja

# Generated at 2022-06-23 21:01:45.951855
# Unit test for method street_name of class Address
def test_Address_street_name():
    adr = Address()
    street_name = adr.street_name()
    assert isinstance(street_name, str)
    assert street_name


# Generated at 2022-06-23 21:01:49.462926
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Coordinates."""
    address = Address('ja')
    coordinates = address.coordinates()
    assert coordinates != {}
    assert len(coordinates) == 2
    assert coordinates['longitude'] != ''
    assert coordinates['latitude'] != ''



# Generated at 2022-06-23 21:01:55.207634
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    
    while True:
        if a.coordinates() != {'longitude': a.longitude(), 'latitude': a.latitude()}:
            print("a.coordinates() != {'longitude': a.longitude(), 'latitude': a.latitude()}")
        else:
            print("a.coordinates() == {'longitude': a.longitude(), 'latitude': a.latitude()}")
            break
            

# Generated at 2022-06-23 21:01:56.533228
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Method tests calling_code of class Address."""
    assert isinstance(_Address().calling_code(), str)


# Generated at 2022-06-23 21:01:59.298486
# Unit test for method latitude of class Address
def test_Address_latitude():
    import random
    random.seed(12)
    assert Address().latitude() == 1.102332
    random.seed(12)
    assert Address().latitude() == '1º6\'8.399"N'


# Generated at 2022-06-23 21:02:01.595916
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """Unit test for method calling_code of class Address."""
    provider = Address(locale='en')
    result = provider.calling_code()

    assert result in CALLING_CODES


# Generated at 2022-06-23 21:02:03.403968
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.enums import Locale

    address = Address(Locale.FR)

    assert address.prefecture() in address._data['state']['name']

# Generated at 2022-06-23 21:02:09.845862
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    # Assert the type of return value of method Address.longitude() is float
    assert(type(a.longitude(False)) == float)
    # Assert the type of return value of method Address.longitude() is str
    assert(type(a.longitude(True)) == str)
    # Assert the return value of method Address.longitude() is >= -180
    assert(a.longitude(False) >= -180)
    # Assert the return value of method Address.longitude() is <= 180
    assert(a.longitude(False) <= 180)


# Generated at 2022-06-23 21:02:12.017145
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province(abbr=True) in ('NL', 'CT', 'CO')


# Generated at 2022-06-23 21:02:16.679574
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    tmp = a.street_name()
    assert tmp == 'Estrada Municipal' or tmp == 'Rua Dom João XXIII' or tmp == 'Avenida dos Anjos' or tmp == 'Avenida dos Aliados'


# Generated at 2022-06-23 21:02:19.940712
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    import sys
    import os
    sys.path.append(os.path.abspath('..'))
    from mimesis import Address
    a = Address()
    assert a.zip_code() != a.zip_code()


# Generated at 2022-06-23 21:02:22.415039
# Unit test for method state of class Address
def test_Address_state():
    test = Address()
    result = test.state()
    assert isinstance(result, str)
    assert result in test._data['state']['name']


# Generated at 2022-06-23 21:02:31.328701
# Unit test for method country_code of class Address
def test_Address_country_code():
    a1=Address()
    assert a1.country_code() in COUNTRY_CODES['alpha_2']
    assert a1.country_code(CountryCode.A2) in COUNTRY_CODES['alpha_2']
    assert a1.country_code(CountryCode.A3) in COUNTRY_CODES['alpha_3']
    assert a1.country_code(CountryCode.A3_ALT) in COUNTRY_CODES['alpha_3_alt']
    assert a1.country_code(CountryCode.NUMERIC) in COUNTRY_CODES['numeric']


# Generated at 2022-06-23 21:02:33.418208
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address('en')
    lat = a.latitude()
    assert isinstance(lat, float)
    assert lat >= -90 and lat <= 90
    

# Generated at 2022-06-23 21:02:34.942574
# Unit test for constructor of class Address
def test_Address():
    # 2
    addr = Address()
    assert isinstance(addr, Address)


# Generated at 2022-06-23 21:02:37.179174
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address(locale="pt_BR")
    assert abs(a.latitude()) >= -90
    assert abs(a.latitude()) <= 90

# Generated at 2022-06-23 21:02:41.888808
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.builtins import Address
    from mimesis.enums import Continent

    p = Address()
    assert isinstance(p.continent(), str)
    assert p.continent(code=True) in p.__class__.Meta.continent.choices
    for enum in list(Continent):
        assert p.continent(code=True) == enum

# Generated at 2022-06-23 21:02:47.831756
# Unit test for method longitude of class Address
def test_Address_longitude():
    result_dict = {}
    for i in range(10):
        add = Address()
        longitude = add.longitude()
        result_dict[longitude] = result_dict.get(longitude, 0) + 1
    print(result_dict)
    #Result: {'81.176601W': 1, '-56.206959W': 1, '-14.484991E': 1, '-12.792655E': 1, '-20.391811E': 1, '-58.418279W': 1, '-1.11722E': 1, '-20.905837W': 1, '-56.403276E': 1, '35.782655W': 1}


# Generated at 2022-06-23 21:02:50.166232
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province() in ['AS', 'DC', 'PR', 'VI', 'GU', 'MP', 'FM', 'MH', 'PW']

# Generated at 2022-06-23 21:02:52.173216
# Unit test for method latitude of class Address
def test_Address_latitude():
    address = Address()
    lt = address.latitude()
    assert lt >= -90 and lt <= 90

# Generated at 2022-06-23 21:02:54.145296
# Unit test for constructor of class Address
def test_Address():
    assert Address.Meta.name == 'address'
    assert Address.Meta.provider_name == 'mimesis'

# Generated at 2022-06-23 21:02:59.115732
# Unit test for method latitude of class Address
def test_Address_latitude():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.tools import suppress_warnings
    from re import compile

    with suppress_warnings():
        address = Address(Locale.EN)

    assert address.latitude().isdigit(), 'address.latitude() should be an integer.'
    assert address.latitude(dms=True).isalnum(), 'address.latitude(dms=True) should be alphanumeric.'


# Generated at 2022-06-23 21:03:02.031192
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    assert a.country().lower() == a.country(True).lower()


# Generated at 2022-06-23 21:03:06.071508
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    mimesis_address = Address()
    N = 100
    codes = [mimesis_address.calling_code() for _ in range(N)]
    assert len(codes) == N
    assert codes != np.unique(codes).tolist()



# Generated at 2022-06-23 21:03:09.033055
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    obj = Address()
    assert obj.locale == 'en'
    assert obj.federal_subject() == 'AK'
    assert obj.federal_subject(abbr=True) == 'KS'

# Generated at 2022-06-23 21:03:11.814466
# Unit test for constructor of class Address
def test_Address():
    try:
        addr = Address()
        assert addr is not None
    except:
        raise AssertionError("Constructor of class Address failed")


# Generated at 2022-06-23 21:03:13.697568
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    b = a.latitude()
    assert isinstance(b, float)


# Generated at 2022-06-23 21:03:15.175235
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    # print(f"Country: {a.country()}")
    pass

if __name__ == "__main__":
    test_Address_country()
    pass

# Generated at 2022-06-23 21:03:23.941434
# Unit test for constructor of class Address
def test_Address():
    a = Address()
    assert a.random
    assert a.seed
    assert a.locale
    assert a.provider

    assert a.street_number
    assert a.street_name
    assert a.street_suffix
    assert a.address

    assert a.state
    assert a.region
    assert a.province
    assert a.federal_subject
    assert a.prefecture

    assert a.postal_code
    assert a.zip_code

    assert a.country_code
    assert a.country

    assert a.city

    assert a.latitude
    assert a.longitude
    assert a.coordinates

    assert a.continent
    assert a.calling_code

# Generated at 2022-06-23 21:03:26.295678
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    tc = Address()
    print(tc.federal_subject())
    print(tc.federal_subject(abbr=True))



# Generated at 2022-06-23 21:03:29.745457
# Unit test for method continent of class Address
def test_Address_continent():
    locale = 'en'
    address = Address(locale=locale)
    assert address.continent() in address._data['continent']
    assert address.continent(code=True) in CONTINENT_CODES


# Generated at 2022-06-23 21:03:32.264295
# Unit test for method state of class Address
def test_Address_state():
    """Test Address state."""
    test_address = Address()
    test_address.state()


# Generated at 2022-06-23 21:03:33.241927
# Unit test for method address of class Address
def test_Address_address():
    provider = Address('en')
    assert provider.address() == '71 Riverwood Butte, Kansas City, MN 12743'



# Generated at 2022-06-23 21:03:34.754377
# Unit test for method region of class Address
def test_Address_region():
    ad = Address('en')
    assert ad.region() in ad._data['state']['name']

# Generated at 2022-06-23 21:03:37.582603
# Unit test for method country of class Address
def test_Address_country():
    """Test for method country of class Address."""
    provider = Address()
    result = provider.country()
    assert result == 'Russia'


# Generated at 2022-06-23 21:03:40.090426
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    print(address.province())


if __name__ == '__main__':
    test_Address_province()

# Generated at 2022-06-23 21:03:49.960092
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale
    from mimesis.typing import Seed
    from datetime import datetime

    en_address = Address(local='en')
    es_address = Address(local='es')
    it_address = Address(local='it')
    ja_address = Address(local='ja')
    # Result: '333 Alturas Terrace + Apt. 6'
    en_address.address()

    assert en_address.address() == '333 Alturas Terrace + Apt. 6'
    assert en_address.address() == '257 Roth Park'
    assert es_address.address() == u'Calle Goya, 66, 1ºC'
    assert it_address.address() == 'Via Angelo Garibaldi, 13'

# Generated at 2022-06-23 21:03:53.814965
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address.

    If method not exists, it will raise AttributeError.
    When called, method must return non-empty string.
    """
    address = Address()
    result = address.address()

    assert result
    assert isinstance(result, str)



# Generated at 2022-06-23 21:03:56.332369
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    postalCode = Address()
    print(postalCode.postal_code())


# Generated at 2022-06-23 21:03:58.408626
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    prov = a.province()
    assert prov is not None


# Generated at 2022-06-23 21:04:00.360456
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address()
    a = address.calling_code()
    b = address.calling_code()
    assert a == b or a != b

# Generated at 2022-06-23 21:04:02.214497
# Unit test for method address of class Address
def test_Address_address():
    data = Address().address()
    assert isinstance(data, str)

# Generated at 2022-06-23 21:04:06.744110
# Unit test for method street_name of class Address
def test_Address_street_name():
    adr=Address()
    street_name=adr.street_name()
    assert street_name !=" "
    assert street_name!=" "
    assert street_name!=''



# Generated at 2022-06-23 21:04:09.140241
# Unit test for method country_code of class Address
def test_Address_country_code():
    address_instance = Address()
    assert country_code(CountryCode.A2) in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-23 21:04:16.061717
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    # Initialization of class object
    addr = Address()
    zip_code = addr.zip_code()
    # Checking the type of result
    assert isinstance(zip_code, str) == True
    # Checking the length of result
    assert len(zip_code) in range(1,32) == True
    # Checking the format of result
    assert zip_code.isdigit() == True




# Generated at 2022-06-23 21:04:27.936211
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import CountryCode

    rus = RussiaSpecProvider()
    russia = rus.address
    assert russia.state() in rus._data['state']['name']
    assert russia.state(abbr=True) in rus._data['state']['abbr']

    eng = Address(locale='en')
    eng_us = eng.address
    assert eng_us.state() in eng._data['state']['name']
    assert eng_us.state(abbr=True) in eng._data['state']['abbr']

    assert eng.region() in eng._data['state']['name']
    assert eng.province() in eng._data['state']['name']
    assert eng.federal_

# Generated at 2022-06-23 21:04:29.747151
# Unit test for method country_code of class Address
def test_Address_country_code():
    add = Address('en')
    assert add.country_code() == 'US'


# Generated at 2022-06-23 21:04:41.453695
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Testing if the location is correct."""
    assert Address(locale='ca').postal_code() == 'Q2B 3A5'
    assert Address(locale='hu').postal_code() == '3512'
    assert Address(locale='it').postal_code() == '58100'
    assert Address(locale='jp').postal_code() == '100-0020'
    assert Address(locale='us').postal_code() == '13707'
    assert Address(locale='es').postal_code() == '48400'
    assert Address(locale='de').postal_code() == '10997'
    assert Address(locale='fr').postal_code() == '95500'
    assert Address(locale='ru').postal_code() == '148002'


# Generated at 2022-06-23 21:04:43.875055
# Unit test for method state of class Address
def test_Address_state():
    address = Address()
    print("State:", address.state())
    print("State:", address.state(abbr=True))


# Generated at 2022-06-23 21:04:47.587093
# Unit test for method country of class Address
def test_Address_country():
    """test_Address_country."""
    #test that method country return string value
    a = Address(seed=12345)
    assert (a.country()) == 'Китай'
    assert (type(a.country())) == str


# Generated at 2022-06-23 21:04:49.804498
# Unit test for method street_number of class Address
def test_Address_street_number():
    assert Address().street_number() != Address().street_number()


# Generated at 2022-06-23 21:05:01.614324
# Unit test for method region of class Address
def test_Address_region():
    # Make sure that region returns state or a random
    # code of country or a random region.
    #
    # @param enums.CountryCode.A2  ->  ISO 3166-1-alpha2
    # @param enums.CountryCode.A3  ->  ISO 3166-1-alpha3
    # @param enums.CountryCode.NUM ->  ISO 3166-1-numeric
    fmt_list = [CountryCode.A2, CountryCode.A3, CountryCode.NUM]
    for fmt in fmt_list:
        country_code = Address().country_code(fmt)
        assert Address().region() in Address().state()
        assert Address().region(abbr=True) in Address().state(abbr=True)
        assert Address().region(code=True) in country_code



# Generated at 2022-06-23 21:05:04.403044
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    assert a.federal_subject() == a.region()
    assert a.federal_subject() == a.province()
    assert a.federal_subject() == a.prefecture()

# Generated at 2022-06-23 21:05:07.758743
# Unit test for method country of class Address
def test_Address_country():
    myaddress = Address()

    res = myaddress.country()

    assert res in myaddress._data["country"]["name"]

# Generated at 2022-06-23 21:05:09.244668
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address()
    assert address.street_suffix() in address._data['street']['suffix']


# Generated at 2022-06-23 21:05:11.623935
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    import pytest
    address = Address('en')
    assert address.street_suffix() != None


# Generated at 2022-06-23 21:05:12.950138
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    assert a.calling_code() == '65'

# Generated at 2022-06-23 21:05:15.760030
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address('it')

    street_number = address.street_number()
    assert type(street_number) == str
    assert len(street_number) > 0



# Generated at 2022-06-23 21:05:18.122196
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    result = a.longitude()
    print(result)
    assert -180 <= result <= 180

# Generated at 2022-06-23 21:05:19.589579
# Unit test for constructor of class Address
def test_Address():
    """Test constructor of class Address."""
    assert Address()



# Generated at 2022-06-23 21:05:22.101010
# Unit test for method country of class Address
def test_Address_country():
    address = Address()

    assert len(address.country()) == 3
    assert 'United States' == address.country(allow_random=True)


# Generated at 2022-06-23 21:05:25.086203
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    addr = Address(locale='en')
    int_code = addr.calling_code()
    print(f"Calling code: {int_code}")
    assert type(int_code) == str
    assert int_code != None


# Generated at 2022-06-23 21:05:34.881010
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.data import COUNTRY_CODES

    # Test the count of locale
    locale_count = len(COUNTRY_CODES['alpha-2'])
    assert len(Locale) == locale_count, 'Error in locale count.'

    addr = Address()
    country_names = []
    for country_code in COUNTRY_CODES['alpha-2']:
        addr.set_locale(country_code)
        country_names.append(addr.country())
    assert len(country_names) == locale_count, 'Error in country name count.'

# Generated at 2022-06-23 21:05:42.414663
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    """Unit test for method federal_subject of class Address
    """
    addr = Address()
    assert isinstance(addr.federal_subject(abbr=True), str)
    assert isinstance(addr.federal_subject(), str)
    assert addr.federal_subject(abbr=True) in addr._data['state']['abbr']
    assert addr.federal_subject() in addr._data['state']['name']

if __name__ == '__main__':
    test_Address_federal_subject()

# Generated at 2022-06-23 21:05:44.818052
# Unit test for method province of class Address
def test_Address_province():
    """Testing method Address.province."""
    address = Address()
    region = address.province()
    assert isinstance(region, str)

# Generated at 2022-06-23 21:05:46.322204
# Unit test for method province of class Address
def test_Address_province():
    assert Address().province() == Address().province(False)

# Generated at 2022-06-23 21:05:48.518864
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    addr = Address('en')
    postal_code = addr.postal_code()
    assert (len(postal_code) == 5)

# Generated at 2022-06-23 21:05:50.963721
# Unit test for method state of class Address
def test_Address_state():
    """Unit test for method state of class Address"""
    address = Address()
    state = address.state()
    assert type(state) is str and len(state) > 0

# Generated at 2022-06-23 21:05:53.586706
# Unit test for constructor of class Address
def test_Address():
    result = Address('ru')
    assert result.__class__.__name__ == 'Address'


# Generated at 2022-06-23 21:05:55.891056
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    for i in range(10):
        b = a.longitude()
        assert b >= -180 and b <= 180

# Generated at 2022-06-23 21:05:58.631005
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address()
    state_name = address.prefecture()
    state_abbr = address.prefecture(abbr=True)

    assert state_name != state_abbr

# Generated at 2022-06-23 21:06:09.113359
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.localization import Localization
    from mimesis.localization import DEFAULT_LOCALE
    from mimesis.enums import Localization
    from mimesis.enums import CountryCode
    import pytest
    address = Address(localization=Localization.DEFAULT)
    assert address.postal_code() == '90210'
    address = Address(localization=Localization.RU)
    assert address.postal_code() == '98900'
    address = Address(localization=Localization.DEFAULT)
    assert address.postal_code() == '90210'
    address = Address(localization=Localization.DEFAULT)
    assert address.postal_code() == '90210'



# Generated at 2022-06-23 21:06:10.752565
# Unit test for method longitude of class Address
def test_Address_longitude():
    instance = Address()

    for i in range(0, 10):
        assert (isinstance(instance.longitude(), float))

# Generated at 2022-06-23 21:06:12.282840
# Unit test for method province of class Address
def test_Address_province():
    a = Address()
    assert a.province() == a.state()


# Generated at 2022-06-23 21:06:13.891006
# Unit test for method province of class Address
def test_Address_province():
    address = Address('en')
    code = address.province()
    assert code == 'AC'


# Generated at 2022-06-23 21:06:16.108569
# Unit test for method continent of class Address
def test_Address_continent():
    continent = Address()
    print(continent.continent())
    print(continent.continent(code=True))


# Generated at 2022-06-23 21:06:18.873810
# Unit test for method longitude of class Address
def test_Address_longitude():
    address = Address('en')
    longitude = address.longitude()
    assert isinstance(longitude, str)
    assert len(longitude) == 8


# Generated at 2022-06-23 21:06:19.985270
# Unit test for method city of class Address
def test_Address_city():
    a = Address()
    n = a.city()
    assert len(n) > 0


# Generated at 2022-06-23 21:06:24.139464
# Unit test for method country_code of class Address
def test_Address_country_code():
    import mimesis.enums as enums
    from mimesis.compat.typing import List
    address = Address()
    test_enum = enums.CountryCode.A3
    result = address.country_code(fmt=test_enum)
    assert result in COUNTRY_CODES[test_enum]


# Generated at 2022-06-23 21:06:26.507638
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    name = a.street_name()
    assert type(name) is str


# Generated at 2022-06-23 21:06:30.383593
# Unit test for method longitude of class Address
def test_Address_longitude():
    a = Address()
    assert len(a.longitude()) == len('-99.999')
    assert len(a.longitude(dms=True)) == len('-99º999\'000.000\"W')


# Generated at 2022-06-23 21:06:42.042748
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    import json
    import json
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address

    """
    Tests for method geo_coordinates of class Address
    """
    from mimesis.builtins import datetime as dt
    from mimesis.builtins import json as json
    from mimesis.builtins import math as math
    from mimesis.builtins import time as time
    from mimesis.enums import Gender
    from mimesis.enums import NumberSystem
    from mimesis.enums import PersonTitle
    from mimesis.providers.address import Address

    add = Address(locale='en')
    ret = add.coordinates(dms=True)

    assert len(ret) == 2
    assert ret['latitude'] is not None
   

# Generated at 2022-06-23 21:06:43.696679
# Unit test for method longitude of class Address
def test_Address_longitude():
    rnd = Address()
    assert type(rnd.longitude(True)) is str

# Generated at 2022-06-23 21:06:46.494884
# Unit test for method latitude of class Address
def test_Address_latitude():
    addr = Address()
    print(addr.latitude())


# Generated at 2022-06-23 21:06:54.914440
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    st_num = address.street_number()
    st_name = address.street_name()
    st_sfx = address.street_suffix()
    city = address.city()
    pc = address.postal_code()
    country = address.country()
    result = address.address()
    # Check that street number and street name is contained in the result
    assert st_num in result
    assert st_name in result
    # Check that street suffix is contained in the result
    assert st_sfx in result
    # Check that city is contained in the result
    assert city in result
    # Check that postal code is contained in the result
    assert pc in result
    # Check that country is contained in the result
    assert country in result


# Generated at 2022-06-23 21:06:58.194880
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address('pt_BR')
    st_num = address.street_number()
    assert st_num in str(list(range(1,1400)))


# Generated at 2022-06-23 21:07:03.462273
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from mimesis.enums import CountryCode
    address = Address(locale="en")
    zc = address.zip_code()
    assert len(zc) == 5
    zc = address.zip_code()
    zc = zc.replace("-", "")
    assert len(zc) == 5


# Generated at 2022-06-23 21:07:13.985991
# Unit test for method province of class Address
def test_Address_province():
    def test_Address_province_random():
        """Unit test for method province of class Address.

        Method province of class Address should return province of
        current locale.
        """
        locale = 'ru'
        address = Address(locale=locale)
        assert isinstance(address.province(), str)

        assert address.province() in \
            address._data['state']['name']

    def test_Address_province_random_abbr():
        """Unit test for method province of class Address.

        Method province of class Address should return province of
        current locale.
        """
        locale = 'ru'
        address = Address(locale=locale)
        assert isinstance(address.province(abbr=True), str)

        assert address.province(abbr=True) in \
            address._data

# Generated at 2022-06-23 21:07:18.963418
# Unit test for method state of class Address
def test_Address_state():
    addr = Address()
    result = addr.state()
    print(result)

    result = addr.state(abbr=True)
    print(result)

# Unit test
if __name__ == '__main__':
    test_Address_state()

# Generated at 2022-06-23 21:07:19.831073
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    assert type(Address().postal_code()) is str

# Generated at 2022-06-23 21:07:20.806838
# Unit test for method street_number of class Address
def test_Address_street_number():
    street_number = Address().street_number()
    assert isinstance(street_number,str)


# Generated at 2022-06-23 21:07:26.108914
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import Locale
    from mimesis.localization import Localization

    address = Address(Localization())

    res = address.postal_code()
    assert isinstance(res, str)
    assert len(res) != 0
    assert res[0].isdigit()
    assert res[1].isdigit()


# Generated at 2022-06-23 21:07:29.003748
# Unit test for method longitude of class Address
def test_Address_longitude():
    assert Address.Address().longitude() == '-36.1244513º14\'20.57053"W'


# Generated at 2022-06-23 21:07:38.581107
# Unit test for method address of class Address
def test_Address_address():
    """Unit test for method address of class Address.
    """
    import os
    import pandas as pd
    import random
    import tempfile
    import yaml

    random.seed(0)

    result = pd.read_csv('./data/address.csv', sep=';')
    result = result.loc[result.locale == 'en']

    address = Address('en')
    test = dict()

    # Test address()
    for i in range(10):
        test[i] = address.address()

    assert result[['address']].equals(pd.DataFrame.from_dict(test, orient='index'))


# Generated at 2022-06-23 21:07:43.764630
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Region
    from mimesis.providers.address import Address
    import pytest


    region = Region.RU
    a = Address(region)

    result = a.address()
    assert result == result.upper()
    assert result != result.lower()

    with pytest.raises(ValueError):
        a.address(1, 2)

    assert len(result.split(' ')) == 3


# Generated at 2022-06-23 21:07:47.282083
# Unit test for method latitude of class Address
def test_Address_latitude():
    addr = Address(seed=1)

    # Check value of latitude:
    assert addr.latitude() == -73.136734

    # Check value of latitude (DMS):
    assert addr.latitude(dms=True) == '-73º8\'12.246"'



# Generated at 2022-06-23 21:07:51.671563
# Unit test for method continent of class Address
def test_Address_continent():

    address = Address(locale='en')

    for _ in range(10):
        continent = address.continent()
        assert continent == 'Europe' or continent == 'Asia' or continent == 'North America' or continent == 'Africa' or continent == 'South America' or continent == 'Oceania' or continent == 'Antarctica' or continent == 'an unknown continent', "Expected: Europe or Asia or North America or Africa or South America or Oceania or Antarctica or an unknown continent; Actual: {continent}".format(continent=continent)


# Generated at 2022-06-23 21:07:54.269802
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    result = address.federal_subject()
    assert result  # TODO: validate result


# Generated at 2022-06-23 21:07:56.408975
# Unit test for method region of class Address
def test_Address_region():
    assert Address().region() in Address()._data['state']['name']


# Generated at 2022-06-23 21:08:00.140114
# Unit test for method street_number of class Address
def test_Address_street_number():
    x = Address()
    #print('\n>>> Unit test for method street_number of class Address:\n')
    #print('\nMethod street_number()\n')
    print('\n' + '@' * 40)
    print(50 * '-' + '\n')
    print(x.street_number())
    print(50 * '-' + '\n')
    print('@' * 40 + '\n')


# Generated at 2022-06-23 21:08:03.223966
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    Adress = Address()
    assert Adress.calling_code() in CALLING_CODES
    assert type(Adress.calling_code()) is str


# Generated at 2022-06-23 21:08:04.860686
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address(locale='en')
    a.latitude()


# Generated at 2022-06-23 21:08:06.540941
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    street_name = address.street_name()
    print(street_name)


# Generated at 2022-06-23 21:08:09.814738
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Test case for method latitude is class Address."""
    from mimesis.enums import CountryCode
    from mimesis.typing import CountryCodeEnum

    # Build Address instance
    ad = Address()

    # Test for method latitude
    assert isinstance(ad.latitude(), float)
    assert ad.latitude(dms=True) is not None



# Generated at 2022-06-23 21:08:11.742259
# Unit test for method address of class Address
def test_Address_address():
    adr = Address()
    print(adr.address())


# Generated at 2022-06-23 21:08:22.441566
# Unit test for method province of class Address
def test_Address_province():
    address_provider = Address(locale='zh-CN')
    province = address_provider.province()
    print(province)