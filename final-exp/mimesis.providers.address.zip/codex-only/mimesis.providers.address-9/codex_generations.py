

# Generated at 2022-06-23 20:58:22.754799
# Unit test for method street_name of class Address
def test_Address_street_name():
    """Test Address.street_name() method."""
    provider = Address('en')
    result = provider.street_name()
    assert isinstance(result, str)


# Generated at 2022-06-23 20:58:34.860932
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address()
    for i in range(1000):
        country_code = address.country_code(CountryCode.A2)

# Generated at 2022-06-23 20:58:37.661103
# Unit test for method street_name of class Address
def test_Address_street_name():
    A = Address()
    data = "street"
    if A.street_name() in A._data[data]['name']:
        return True
    else:
        return False


# Generated at 2022-06-23 20:58:40.700814
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    """Unit test for method zip_code of class Address"""
    assert Address().zip_code() is not None


# Generated at 2022-06-23 20:58:42.845203
# Unit test for method country_code of class Address
def test_Address_country_code():
    a = Address()
    assert a.country_code() in COUNTRY_CODES[CountryCode.A2]

# Generated at 2022-06-23 20:58:47.887134
# Unit test for method street_number of class Address
def test_Address_street_number():
    print('\nTest: street_number\n')

    # Test method with default values
    assert len(Address().street_number()) > 0
    print(Address().street_number())

    # Test method with specified values
    assert len(Address().street_number(5)) > 0
    print(Address().street_number(5))


# Generated at 2022-06-23 20:58:54.779699
# Unit test for method longitude of class Address
def test_Address_longitude():
    from mimesis.enums import Country
    en_address = Address(Country.UNITED_STATES)
    print(en_address.longitude())
    print(en_address.longitude(dms=True))
    de_address = Address(Country.GERMANY)
    print(de_address.longitude())
    print(de_address.longitude(dms=True))


# Generated at 2022-06-23 20:58:58.498769
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address('ru')
    assert len(a.postal_code()) == 6
    assert a.postal_code()[0] == '1'

if __name__ == '__main__':
    test_Address_postal_code()

# Generated at 2022-06-23 20:59:01.401973
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    a = Address()
    print(a.calling_code())


# Generated at 2022-06-23 20:59:05.523181
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import ContinentCode, Continents
    import mimesis.builtins
    continent = mimesis.builtins.Address().continent(code=True)
    assert continent in ContinentCode
    assert continent in Continents

# Generated at 2022-06-23 20:59:09.715692
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import CountryCode

    a = Address(locale=CountryCode.RU)
    print(a.postal_code())


# Generated at 2022-06-23 20:59:20.450566
# Unit test for method country_code of class Address
def test_Address_country_code():
    address = Address(lang='en')
    result = address.country_code()
    assert isinstance(result, str)
    assert result in COUNTRY_CODES[CountryCode.A2]
    assert result not in COUNTRY_CODES[CountryCode.A3]

    result = address.country_code(CountryCode.A3)
    assert isinstance(result, str)
    assert result in COUNTRY_CODES[CountryCode.A3]
    assert result not in COUNTRY_CODES[CountryCode.N3]

    result = address.country_code(CountryCode.N3)
    assert isinstance(result, str)
    assert result in COUNTRY_CODES[CountryCode.N3]
    assert result not in COUNTRY_CODES[CountryCode.A2]

    result = address.country

# Generated at 2022-06-23 20:59:21.759230
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    adr = Address()
    print(adr.calling_code())

# Generated at 2022-06-23 20:59:24.566260
# Unit test for method province of class Address
def test_Address_province():
    """Unit test for method province of class Address."""
    adr = Address('en')
    assert (adr.province() in adr._data['region']['name'])



# Generated at 2022-06-23 20:59:35.803406
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    from mimesis.localization import GermanSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.enums import Country
    # Assign the locale to Russia
    address = Address(locale='ru')
    # Germany
    r = Address(_locale='de')
    # Germany with GermanSpecProvider:
    c = Address(GermanSpecProvider())
    # Create a Address instance with a GermanSpecProvider
    # and gender Male:
    d = Address(gender=Gender.MALE)
    # Create a Address instance with a GermanSpecProvider
    # and gender Female:
    e = Address(gender=Gender.FEMALE)
    # Create a Address instance with a locale
    # and gender Male:

# Generated at 2022-06-23 20:59:41.537374
# Unit test for method continent of class Address
def test_Address_continent():
    from mimesis.enums import Continent
    from mimesis.enums import ContinentCode
    from mimesis.providers.address import Address
    print(Address().continent())
    print(Address().continent(code=True))
    print(Address(continent=Continent.NORTH_AMERICA).continent())
    print(Address(continent=ContinentCode.AS).continent(code=True))

if __name__ == "__main__":
    test_Address_continent()

# Generated at 2022-06-23 20:59:46.264510
# Unit test for method country_code of class Address
def test_Address_country_code():
    address_instance = Address()
    a2 = address_instance.country_code(CountryCode.A2)
    a3 = address_instance.country_code(CountryCode.A3)
    assert isinstance(a2, str) and len(a2) == 2
    assert isinstance(a3, str) and len(a3) == 3

# Generated at 2022-06-23 20:59:48.112840
# Unit test for method state of class Address
def test_Address_state():
    z = Address()
    assert z.state() == 'ویرغن'


# Generated at 2022-06-23 20:59:49.168429
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address().country_code() == 'RU'

# Generated at 2022-06-23 20:59:50.316329
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    address = Address()
    assert len(address.zip_code()) is 5


# Generated at 2022-06-23 20:59:51.291742
# Unit test for method province of class Address
def test_Address_province():
    print(Address().province())


# Generated at 2022-06-23 20:59:52.633779
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    p = Address
    assert p.postal_code() == '30-000'

# Generated at 2022-06-23 21:00:00.214772
# Unit test for method region of class Address
def test_Address_region():
    """Unit test for region() method of class Address."""
    addr = Address(locale='en')


# Generated at 2022-06-23 21:00:03.262781
# Unit test for method state of class Address
def test_Address_state():
    state = Address()
    assert isinstance(state.state(), str)
    assert isinstance(state.state(abbr=True), str)



# Generated at 2022-06-23 21:00:05.119840
# Unit test for method address of class Address
def test_Address_address():
    _address = Address('en')
    assert '#' in _address.address()



# Generated at 2022-06-23 21:00:07.633770
# Unit test for method street_name of class Address
def test_Address_street_name():
    provider = Address(random_state=0)
    assert provider.street_name() == "Rua Leopoldo D'Ávila"


# Generated at 2022-06-23 21:00:09.203630
# Unit test for method street_number of class Address
def test_Address_street_number():
    for i in range(10):
        assert type(Address('').street_number()) == str


# Generated at 2022-06-23 21:00:12.322886
# Unit test for method address of class Address
def test_Address_address():
    add = Address('en')
    assert type(add) is Address
    assert add.address() is not None
    print(add.address())



# Generated at 2022-06-23 21:00:14.758027
# Unit test for method city of class Address
def test_Address_city():
    city_set = set()
    city_set.add(Address().city())
    assert len(city_set) == 1



# Generated at 2022-06-23 21:00:16.420260
# Unit test for method street_number of class Address
def test_Address_street_number():
    a=Address()
    assert a.street_number() != None


# Generated at 2022-06-23 21:00:18.785511
# Unit test for method city of class Address
def test_Address_city():
    addresses = Address('en')
    city = addresses.city()
    assert city



# Generated at 2022-06-23 21:00:29.245925
# Unit test for method country_code of class Address
def test_Address_country_code():
    _address = Address()

# Generated at 2022-06-23 21:00:31.264548
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    result = Address().postal_code()
    assert len(result) == 5
    assert result.isnumeric()


# Generated at 2022-06-23 21:00:33.645577
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    print('street_name: ' + a.street_name())


# Generated at 2022-06-23 21:00:39.544107
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from itertools import chain

    lats = []
    longs = []

    for _ in range(1000):
        _dict = Address('en').coordinates()
        lats.append(_dict['latitude'])
        longs.append(_dict['longitude'])

    assert max(chain(lats, longs)) <= 90
    assert min(chain(lats, longs)) >= -90

# Generated at 2022-06-23 21:00:41.385213
# Unit test for method province of class Address
def test_Address_province():
    province = Address().province()
    print("province:"+province)
    assert isinstance(province, str)


# Generated at 2022-06-23 21:00:44.832314
# Unit test for method address of class Address
def test_Address_address():

    # create instance of class
    address = Address()

    # generate address
    full_address = address.address()

    # assert that the address is not empty
    assert full_address != ""


# Generated at 2022-06-23 21:00:48.144845
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Unit test for method postal_code of class Address."""
    addr = Address('en')
    assert addr.postal_code() != addr.postal_code()

# Generated at 2022-06-23 21:00:58.112171
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    # Создаём объект с локалью ru
    addr = Address('ru')
    # Получаем случайный код региона
    code = addr.federal_subject()
    # Проверяем наличие случайного кода региона
    # В списке кодов регионов
    assert code in addr._data['state']['abbr']
    # Получаем с

# Generated at 2022-06-23 21:01:08.479923
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ja')
    federal_subject = address.federal_subject()

# Generated at 2022-06-23 21:01:10.287757
# Unit test for method province of class Address
def test_Address_province():
    address = Address('en')
    assert address.province() in address._data['state']['abbr']

# Generated at 2022-06-23 21:01:12.459285
# Unit test for method street_number of class Address
def test_Address_street_number():
    _a = Address()
    assert _a.street_number() not in range(1401)



# Generated at 2022-06-23 21:01:15.515592
# Unit test for method region of class Address
def test_Address_region():
    a = Address()
    assert isinstance(a, Address)
    print(a.region)



# Generated at 2022-06-23 21:01:22.918658
# Unit test for method street_name of class Address
def test_Address_street_name():
    from mimesis.builtins import Address
    from mimesis.enums import Locale
    import os

    for lang in os.listdir('mimesis/data'):
        if os.path.isdir("mimesis/data/"+lang):
            address = Address(locale=lang)
            street_name = address.street_name()
            # Check for length
            assert len(street_name) <= 20
            # Check for non-numeric values
            assert street_name.isalpha()


# Generated at 2022-06-23 21:01:29.835590
# Unit test for method street_name of class Address
def test_Address_street_name():
    import random
    import string
    import mimesis.enums
    street = Address(mimesis.enums.Language.EN)
    data = street.street_name()
    assert type(data) == str
    if street.language.name == 'ja':
        assert len(data) > 0 and len(data) < 11
    elif street.language.name == 'ru':
        assert len(data) > 0 and len(data) < 7
    else:
        assert len(data) > 0 and len(data) < 13



# Generated at 2022-06-23 21:01:33.403720
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """."""
    # Initialization Address
    address = Address('en')
    # Get random postal code
    postal_code = address.postal_code()
    # Check equality of postal code
    assert len(postal_code)
    # Check type of postal code
    assert isinstance(postal_code, str)


# Generated at 2022-06-23 21:01:34.607237
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    s = Address()
    assert len(s.zip_code()) == 7


# Generated at 2022-06-23 21:01:35.535843
# Unit test for method state of class Address
def test_Address_state():
    address = Address()

    print(address.state())


# Generated at 2022-06-23 21:01:38.697803
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    provider = Address(provider='address', locales='es')
    zip_code = provider.zip_code()
    assert isinstance(zip_code, str)
    assert len(zip_code) == 5


# Generated at 2022-06-23 21:01:41.663984
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address("zh")
    street_name = address.street_name()
    print("street_name: ", street_name)



# Generated at 2022-06-23 21:01:44.886085
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    from demos.test import seed
    seed(0)
    a = Address()
    assert a.street_suffix() == 'Street'


# Generated at 2022-06-23 21:01:46.500574
# Unit test for method state of class Address
def test_Address_state():
    a = Address()
    assert a.state() != ''


# Generated at 2022-06-23 21:01:52.512376
# Unit test for method latitude of class Address
def test_Address_latitude():
    """Unit test for method latitude of class Address."""
    adr = Address()
    lat1 = adr.latitude()
    lat2 = adr.latitude()
    assert isinstance(lat1, float) or isinstance(lat1, str)
    assert isinstance(lat2, float) or isinstance(lat2, str)
    assert lat1 != lat2  # pylint: disable=unneeded-not


# Generated at 2022-06-23 21:01:57.701788
# Unit test for method city of class Address
def test_Address_city():
    random_address = Address(locale='en')
    print(random_address.city())
    assert random_address.city() in ['Dongsheng','Dongxiang','Dongyuan','Dongzhen','Donghai','Dacheng','Dachuan','Dafang','Daguan','Dahu','Dalang','Dama','Daming','Damingshan','Damo','Dangshan','Dangtu','Dangxiong','Dangzhai','Danyang']


# Generated at 2022-06-23 21:01:59.003623
# Unit test for method street_name of class Address
def test_Address_street_name():
    print(Address.street_name())
    print(Address.street_name())
    print(Address.street_name())


# Generated at 2022-06-23 21:02:00.217169
# Unit test for method city of class Address
def test_Address_city():
    city = Address(seed=123).city()

    assert city == "Cairo"


# Generated at 2022-06-23 21:02:01.858026
# Unit test for constructor of class Address
def test_Address():
    a = Address(54, 80)
    assert isinstance(a, Address)
    assert repr(a) == '<Address 54/80>'


# Generated at 2022-06-23 21:02:03.608825
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Test_address_postal_code."""
    a = Address(locale='ja')
    assert a.postal_code() == '900-0000'


# Generated at 2022-06-23 21:02:06.601613
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    # Testing function coordinates
    # Dict with coordinates
    from mimesis.builtins import Address
    address = Address()
    print(address.coordinates())
    print(address.coordinates(dms=True))
    print(address.latitude())
    print(address.latitude(dms=True))
    print(address.longitude())
    print(address.longitude(dms=True))


# Generated at 2022-06-23 21:02:09.491930
# Unit test for method street_number of class Address
def test_Address_street_number():
    address = Address()
    assert isinstance(address.street_number(), str)


# Generated at 2022-06-23 21:02:20.739280
# Unit test for method street_number of class Address
def test_Address_street_number():
    from mimesis.enums import Country
    from mimesis.localization import Localization
    from mimesis.providers.address import Address
    assert Address(localization=Localization(Country.RUSSIA)).street_number(maximum=1400) in '0123456789'
    assert Address(localization=Localization(Country.RUSSIA)).street_number(maximum=1400) in '0123456789'
    assert Address(localization=Localization(Country.RUSSIA)).street_number(maximum=1400) in '0123456789'
    assert Address(localization=Localization(Country.RUSSIA)).street_number(maximum=1400) in '0123456789'

# Generated at 2022-06-23 21:02:22.463054
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    provider = Address()
    res = provider.prefecture()
    assert(res)


# Generated at 2022-06-23 21:02:23.825551
# Unit test for method address of class Address
def test_Address_address():
    a = Address()
    a.address()

# Generated at 2022-06-23 21:02:27.298726
# Unit test for method continent of class Address
def test_Address_continent():
    Add = Address()
    assert Add.continent() in 'AfricaAsiaAntarcticaEuropeNorth America' \
                            'AustraliaSouth America'
    assert Add.continent(False) in 'AfricaAsiaAntarcticaEuropeNorth America' \
                                  'AustraliaSouth America'
    assert Add.continent(True) in 'AFASAEUNAUSSA'

# Generated at 2022-06-23 21:02:31.056787
# Unit test for constructor of class Address
def test_Address():
    assert Address().random.choice(Address()._data['street']['name']) is not None


# Generated at 2022-06-23 21:02:32.330955
# Unit test for method city of class Address
def test_Address_city():
    city = Address().city()
    assert isinstance(city, str)


# Generated at 2022-06-23 21:02:38.870059
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.utils import get_provider
    address = get_provider('address')
    assert address.address() == 'Комсомольская ул., 74'
    assert address.address() == 'Декабристов ул., 22'
    assert address.address() == 'Комсомольская ул., 74'


# Generated at 2022-06-23 21:02:44.186097
# Unit test for method address of class Address
def test_Address_address():
    from mimesis import Address
    address = Address(locale='en')
    assert address.address() in '{st_num}{st_name}{st_sfx}'.format(
        st_num=address.street_number(),
        st_name=address.street_name(),
        st_sfx=address.street_suffix(),
    )


# Generated at 2022-06-23 21:02:46.189715
# Unit test for method country of class Address
def test_Address_country():
    add = Address()
    # print(add.country(allow_random=True))
    # print(add.country())


# Generated at 2022-06-23 21:02:47.879587
# Unit test for method region of class Address
def test_Address_region():
    d = Address()
    assert len(d.region()) > 0



# Generated at 2022-06-23 21:02:53.016005
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address("zh")
    assert address.street_suffix() in list(address._data['street']['suffix'])
    assert address.street_suffix() in list(address._data['street']['suffix'])
    assert address.street_suffix() in list(address._data['street']['suffix'])


# Generated at 2022-06-23 21:02:54.340783
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert isinstance(address.address(), str)


# Generated at 2022-06-23 21:02:55.781085
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    a1 = Address()
    zip = a1.zip_code()
    assert isinstance(zip, str)

# Generated at 2022-06-23 21:02:59.845365
# Unit test for method region of class Address
def test_Address_region():
    from mimesis.enums import CountryCode
    from mimesis.builtins import address
    d = address.Address()
    for i in range(100):
        code_1 = d.region()
        code_2 = d.region(abbr=True)
        code_3 = d.region(CountryCode.A2)
        assert len(code_1) > 0
        assert len(code_2) > 0
        assert len(code_3) > 0

# Generated at 2022-06-23 21:03:01.879420
# Unit test for method country of class Address
def test_Address_country():
    addr = Address()
    print(addr.country())


# Generated at 2022-06-23 21:03:04.879292
# Unit test for method street_number of class Address
def test_Address_street_number():
    try:
        print("street_number(): ",end="")
        assert Address().street_number() == "764"
        print("Success")
    except:
        print("Fail")

# Generated at 2022-06-23 21:03:06.958445
# Unit test for method address of class Address
def test_Address_address():
    adr = Address(locale='en')
    assert adr.address()


# Generated at 2022-06-23 21:03:07.963665
# Unit test for method country of class Address
def test_Address_country():
    address = Address()

    assert address.country(allow_random=True) in address._data['country']['name']

# Generated at 2022-06-23 21:03:09.169161
# Unit test for method street_name of class Address
def test_Address_street_name():
    assert Address().street_name() != Address().street_name()


# Generated at 2022-06-23 21:03:12.789308
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    # Init class
    addr = Address('en')
    # Generate value
    val = addr.calling_code()
    # Check result
    assert val in CALLING_CODES
    assert isinstance(val, str)


# Generated at 2022-06-23 21:03:20.834376
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import CountryCode
    instance = Address(locale='en')
    assert instance.state()
    assert instance.state(abbr=False)
    assert instance.state(abbr=True)
    assert instance.region()
    assert instance.region(abbr=False)
    assert instance.region(abbr=True)
    assert instance.province()
    assert instance.province(abbr=False)
    assert instance.province(abbr=True)
    assert instance.federal_subject()
    assert instance.federal_subject(abbr=False)
    assert instance.federal_subject(abbr=True)
    assert instance.prefecture()
    assert instance.prefecture(abbr=False)
    assert instance.prefecture(abbr=True)
    assert instance.country_

# Generated at 2022-06-23 21:03:22.292776
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    assert isinstance(Address().federal_subject(), str)

# Generated at 2022-06-23 21:03:31.976527
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    from random import seed

# Generated at 2022-06-23 21:03:33.397058
# Unit test for method state of class Address
def test_Address_state():
    test = Address()
    assert test.state() in test._data['state']['name']


# Generated at 2022-06-23 21:03:35.728771
# Unit test for method prefecture of class Address
def test_Address_prefecture():
    address = Address('en')
    assert address.prefecture() in address._data['state']['name']


# Generated at 2022-06-23 21:03:38.930275
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    # "AD" should be Andorra
    assert a._data['country']['current_locale'] == "Andorra"


# Generated at 2022-06-23 21:03:40.494998
# Unit test for method street_name of class Address
def test_Address_street_name():
    a = Address()
    print(a.street_name())



# Generated at 2022-06-23 21:03:43.202602
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address('en')
    assert a.federal_subject() in a._data['state']['name']

# Generated at 2022-06-23 21:03:44.411687
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    """
    Check if calling_code() method of Address class returns a string.
    """
    assert isinstance(Address('be').calling_code(), str)


# Generated at 2022-06-23 21:03:49.973666
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address()
    assert isinstance(address.coordinates(), dict)
    assert isinstance(address.coordinates(True), dict)
#Test function to check if the method coordinates of class Address is returning a float or not.
#def test_Address_coordinates_returns_float():
#    address = Address()
#    assert isinstance(address.coordinates(), float)
#    assert isinstance(address.coordinates(True), float)
#test_Address_coordinates_returns_float()
# Tests for the method continent in class Address

# Generated at 2022-06-23 21:03:52.765465
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address()
    assert isinstance(a.street_suffix(), str)
    print('street_suffix -------->  ', a.street_suffix())


# Generated at 2022-06-23 21:03:55.388680
# Unit test for method latitude of class Address
def test_Address_latitude():
    assert(type(Address().latitude()) == float)


# Generated at 2022-06-23 21:03:57.173597
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address(seed=0)
    try:
        assert a.street_suffix() == "d'Amour"
    finally:
        a.reset_seed()


# Generated at 2022-06-23 21:03:59.588449
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address()
    name = address.street_name()
    assert name
    assert type(name) == str
    assert len(name) > 0


# Generated at 2022-06-23 21:04:02.321473
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    """Unit test for street_suffix."""
    locale = 'en'
    address_obj = Address(locale)
    # Assert function return suffix of street
    assert isinstance(address_obj.street_suffix(), str)



# Generated at 2022-06-23 21:04:03.571010
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ""

# Generated at 2022-06-23 21:04:07.478220
# Unit test for method city of class Address
def test_Address_city():
    addr = Address('en')
    city = addr.city()
    assert len(city) > 0
    assert city == "Hilder"


# Generated at 2022-06-23 21:04:11.602015
# Unit test for constructor of class Address
def test_Address():
    assert Address.Meta.name == 'address'
    assert Address('en').state(abbr=True) in ['AL', 'AB', 'AK', 'AZ', 'AR']
    assert Address('en').state(abbr=False) == 'Alabama'
    assert Address('en').city() in ['New York', 'Los Angeles', 'Chicago']


# Generated at 2022-06-23 21:04:14.987002
# Unit test for method street_number of class Address
def test_Address_street_number():
    random = FakeRandom()
    address = Address(random)
    address.street_number()
    assert address.street_number() == random.randint(1, 1400)



# Generated at 2022-06-23 21:04:18.816308
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    adr = Address()
    assert len(adr.calling_code()) == 4
    assert adr.calling_code().startswith('+')
    assert adr.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:04:28.000156
# Unit test for method country_code of class Address
def test_Address_country_code():
    # default value
    assert Address().country_code() in COUNTRY_CODES[
        CountryCode.A2.value]
    # a3
    assert Address().country_code(CountryCode.A3) in COUNTRY_CODES[
        CountryCode.A3.value]
    # numeric
    assert Address().country_code(CountryCode.NUMERIC) in COUNTRY_CODES[
        CountryCode.NUMERIC.value]
    # iana
    assert Address().country_code(CountryCode.IANA) in COUNTRY_CODES[
        CountryCode.IANA.value]

# Generated at 2022-06-23 21:04:30.697678
# Unit test for method country of class Address
def test_Address_country():
    a = Address('es')
    p1 = a.country(allow_random=False)
    p2 = a.country(allow_random=True)
    assert p1 == 'España'
    assert p2 in ['Estados Unidos', 'Tailandia', 'Turquía', 'España']


# Generated at 2022-06-23 21:04:31.981615
# Unit test for method street_number of class Address
def test_Address_street_number():
    number = Address().street_number()
    assert number

# Generated at 2022-06-23 21:04:33.049056
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    Address()
    assert True

# Generated at 2022-06-23 21:04:35.293989
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('en')
    pc = address.postal_code()
    assert (pc in address._data['postal_code']) is True

# Generated at 2022-06-23 21:04:39.802191
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis import Address
    address = Address()
    print("%s" % address.coordinates())
    print("%s" % address.coordinates())
    print("%s" % address.coordinates())


# Generated at 2022-06-23 21:04:42.082516
# Unit test for method continent of class Address
def test_Address_continent():
    prov = Address(
        'en'
    )
    result = prov.continent()

    assert result == 'Africa'

# Generated at 2022-06-23 21:04:44.305083
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.builtins import address

    a = address.Address()
    assert isinstance(a.address(), str)



# Generated at 2022-06-23 21:04:46.192368
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    assert len(Address('es').street_suffix()) == 2


# Generated at 2022-06-23 21:04:50.246458
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    for i in range(100):
        postal_code = address.postal_code()
        assert len(postal_code) > 0
        assert postal_code.isnumeric()



# Generated at 2022-06-23 21:04:51.910824
# Unit test for method longitude of class Address
def test_Address_longitude():
    add = Address()
    assert -180 <= add.longitude() <= 180

# Generated at 2022-06-23 21:04:53.350613
# Unit test for method country of class Address
def test_Address_country():
    Address(locale='ja').country() == "日本"

# Generated at 2022-06-23 21:04:56.570882
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.enums import Locale
    a =Address(Locale.RU)
    assert a.city() == 'Москва'

# Generated at 2022-06-23 21:04:58.460310
# Unit test for method country of class Address
def test_Address_country():
    a = Address()
    print(a.country())
    print(a.country())


# Generated at 2022-06-23 21:05:02.432354
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import Locale

    address = Address(locale=Locale.EN)
    result = address.address()
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 21:05:05.413187
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    address = Address('en')
    assert address.coordinates() == {
        'latitude': '9º2\'56.00"N',
        'longitude': '-58º59\'10.01"W'
    }

# Generated at 2022-06-23 21:05:11.630433
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert('ru' == Address().country_code())
#     Тестируем случай, когда метод не знает, что делать со значением, пришедшим в параметре, а именно со значением None
    assert(False, Address().country_code(None))
    assert(False, Address().country_code('none'))
#     Тестируем случай успешного те

# Generated at 2022-06-23 21:05:12.841129
# Unit test for method city of class Address
def test_Address_city():
    address=Address()
    assert address.city() in address._data['city']


# Generated at 2022-06-23 21:05:14.213173
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    objAddress = Address()
    print(objAddress.calling_code())


# Generated at 2022-06-23 21:05:21.000876
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    from mimesis.enums import DMSFormat
    addr = Address()
    for _ in range(10):
        res = addr.coordinates(dms=DMSFormat.DD)
        assert isinstance(res, dict)
        for key, value in res.items():
            assert isinstance(key, str)
            assert isinstance(value, float)
        assert -90 <= res['latitude'] <= 90
        assert -180 <= res['longitude'] <= 180

# Generated at 2022-06-23 21:05:23.041357
# Unit test for method city of class Address
def test_Address_city():
    from mimesis.builtins import RussiaSpecProvider
    a = Address(RussiaSpecProvider)
    print(a.city())


# Generated at 2022-06-23 21:05:26.007133
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    from mimesis.enums import Locale

    address = Address(locale=Locale.UK)
    postal_code = address.postal_code()
    assert len(postal_code) == 5
    assert postal_code.isalpha() or postal_code.isdigit()


# Generated at 2022-06-23 21:05:31.388644
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    mimesis = Address
    lat1, long1 = mimesis.coordinates().values()
    lat2, long2 = mimesis.coordinates().values()
    assert -90 < lat1 < 90 and -180 < long1 < 180
    assert lat1 != lat2 or long1 != long2

# Generated at 2022-06-23 21:05:37.196207
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    a = Address()
    fmt_list = [CountryCode.A2, CountryCode.A3, CountryCode.NUMERIC]
    for f in fmt_list:
        print(f, a.country_code(fmt=f))

if __name__ == '__main__':
    test_Address_country_code()

# Generated at 2022-06-23 21:05:39.421986
# Unit test for method continent of class Address
def test_Address_continent():
    address = Address(seed=0)
    assert address.continent(code=True) == 'AF'

test_Address_continent()

# Generated at 2022-06-23 21:05:46.526740
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address()
    assert address.federal_subject(abbr=True)
    assert address.federal_subject(abbr=False)
    assert address.province(abbr=True)
    assert address.province(abbr=False)
    assert address.region(abbr=True)
    assert address.region(abbr=False)
    assert address.prefecture(abbr=True)
    assert address.prefecture(abbr=False)

# Generated at 2022-06-23 21:05:48.761640
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    address = Address('ru')
    state = address.federal_subject()
    assert isinstance(state, str)
    print(state)

# Generated at 2022-06-23 21:05:52.783890
# Unit test for method city of class Address
def test_Address_city():
    output = Address().city()
    assert isinstance(output, str)

test_Address_city()



# Generated at 2022-06-23 21:05:54.631021
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    for i in range(100):
        assert repr(Address('en').calling_code()) == '43'

# Generated at 2022-06-23 21:05:57.126669
# Unit test for method state of class Address
def test_Address_state():
    country = Address.state()
    assert country.lower() in ['american samoa', 'guam', 'puerto rico']


# Generated at 2022-06-23 21:06:02.306731
# Unit test for method city of class Address
def test_Address_city():
    """Test Address.city() method."""
    def func():
        """Call Address.city() method and get result."""
        return Address().city()
    assert isinstance(func(), str)
    assert func() in ('São Paulo', 'New York', 'Paris')


# Generated at 2022-06-23 21:06:02.959444
# Unit test for method longitude of class Address
def test_Address_longitude():
    pass

# Generated at 2022-06-23 21:06:05.295058
# Unit test for method province of class Address
def test_Address_province():
    address = Address()
    assert address.province() in address._data['state']['name'], \
        'Address.province() should return name of province'


# Generated at 2022-06-23 21:06:09.380116
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    a = Address(random_state = 123)
    assert a.street_suffix() == 'Boulevard'



# Generated at 2022-06-23 21:06:13.356226
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    a = Address()
    assert isinstance(a.federal_subject(), str)
    assert isinstance(a.federal_subject(abbr=True), str)
    assert isinstance(a.federal_subject(abbr=False), str)
    assert isinstance(a.federal_subject(abbr=True), str)

# Generated at 2022-06-23 21:06:15.361550
# Unit test for method address of class Address
def test_Address_address():
    provider = Address()
    address = provider.address()
    assert len(address) > 0
    assert isinstance(address, str)



# Generated at 2022-06-23 21:06:17.922807
# Unit test for method street_suffix of class Address
def test_Address_street_suffix():
    address = Address('en')
    assert address.street_suffix() in ('Avenue', 'Road', 'Street')


# Generated at 2022-06-23 21:06:20.123937
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address('zh')
    postal_code = address.postal_code()
    assert isinstance(postal_code, str)


# Generated at 2022-06-23 21:06:22.216854
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    address = Address('fo')
    for _ in range(100):
        assert address.calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:06:24.819963
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address()
    msg = "Method latitude() failed."
    assert (a.latitude() >= -90 and a.latitude() <= 90), msg


# Generated at 2022-06-23 21:06:27.964507
# Unit test for method latitude of class Address
def test_Address_latitude():
    a = Address('ru')
    assert isinstance(a.latitude(), float)
    assert isinstance(a.latitude(dms=True), str)


# Generated at 2022-06-23 21:06:30.531378
# Unit test for method country of class Address
def test_Address_country():
    assert isinstance(Address().country(),str)
    assert isinstance(Address().country(allow_random=True),str)


# Generated at 2022-06-23 21:06:33.476081
# Unit test for method country of class Address
def test_Address_country():
    # Test locale en
    locale = 'en'
    country = 'United States'
    address = Address(locale)
    assert address.country() == country


# Generated at 2022-06-23 21:06:35.531580
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Unit test for method coordinates() of class Address."""
    a = Address()
    assert -90 <= a.coordinates()['longitude'] <= 90
    assert -180 <= a.coordinates()['latitude'] <= 180


# Generated at 2022-06-23 21:06:36.927292
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    test = Address()
    assert(len(test.federal_subject()) > 0)

# Generated at 2022-06-23 21:06:39.786266
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    ad = Address()
    code = ad.calling_code()
    assert code in CALLING_CODES


# Generated at 2022-06-23 21:06:40.832692
# Unit test for method address of class Address
def test_Address_address():
    address = Address()
    assert address.address() != ''

# Generated at 2022-06-23 21:06:42.887566
# Unit test for method province of class Address
def test_Address_province():
    test = Address()
    result = test.province()
    print(result)

# Generated at 2022-06-23 21:06:50.345964
# Unit test for method state of class Address
def test_Address_state():
    from mimesis.enums import Country

    assert Address._get_data('address')['state']['name']['RU'] == 'город'
    assert Address._get_data('address')['state']['name']['US'] == 'state'
    assert Address._get_data('address')['state']['abbr']['RU'] == 'г'
    assert Address._get_data('address')['state']['abbr']['US'] == 'st'
    # Check default locale
    assert Address().state() == Address._get_data('address')['state']['name']['US']
    # Check abbr
    assert Address().state(abbr=True) == Address._get_data('address')['state']['abbr']['US']
    #

# Generated at 2022-06-23 21:07:02.229042
# Unit test for method street_number of class Address
def test_Address_street_number():
    from pprint import pprint
    from random import seed
    from mimesis.providers.address import Address

    seed(4)

    # Create instance of Address object
    address = Address('pt')

    # Main testing
    pprint(address.street_number()) # Output: '832'
    pprint(address.street_number()) # Output: '1231'
    pprint(address.street_number()) # Output: '1304'
    pprint(address.street_number()) # Output: '903'
    pprint(address.street_number()) # Output: '1423'
    pprint(address.street_number()) # Output: '1025'
    pprint(address.street_number()) # Output: '1095'
    pprint(address.street_number()) # Output: '1033'
   

# Generated at 2022-06-23 21:07:07.883370
# Unit test for method region of class Address
def test_Address_region():
	print('\nUnit test for method region of class Address')
	print('---------------------------------------')
	ad = Address(locale='en')
	print('Call ad.region(abbr=True) 10 times')
	for _ in range(10):
		print(ad.region(abbr=True), end=', ')
	print('\nCall ad.region(abbr=False) 10 times')
	for _ in range(10):
		print(ad.region(abbr=False), end=', ')



# Generated at 2022-06-23 21:07:09.599481
# Unit test for method zip_code of class Address
def test_Address_zip_code():
    addr = Address()
    zc = addr.zip_code()
    assert isinstance(zc, str)

# Generated at 2022-06-23 21:07:11.149229
# Unit test for method street_name of class Address
def test_Address_street_name():
    address = Address("ru")
    street_name = address.street_name()
    assert isinstance(street_name, str)
    assert street_name


# Generated at 2022-06-23 21:07:12.375468
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address()
    answer = ['10000', '12345', '99999']
    assert address.postal_code() in answer

# Generated at 2022-06-23 21:07:18.502521
# Unit test for method address of class Address
def test_Address_address():
    from mimesis.enums import CountryCode
    from mimesis.builtins import EN

    a = Address(locale=EN)

    assert a.address() != ''
    print(a.address())

    a = Address(locale=CountryCode.UA)

    assert a.address() != ''
    print(a.address())

# Generated at 2022-06-23 21:07:20.310830
# Unit test for method street_name of class Address
def test_Address_street_name():
    t = Address(locale='en')
    result = t.street_name()
    assert result
    

# Generated at 2022-06-23 21:07:24.367565
# Unit test for method region of class Address
def test_Address_region():
   # Check region call
   address = Address()
   state = address.region()
   assert state in address.province()
   assert state in address.federal_subject()
   assert state in address.prefecture()


# Generated at 2022-06-23 21:07:27.315051
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    """Unit test for method postal_code of class Address."""

    addr1 = Address()
    postal_code = addr1.postal_code()
    assert isinstance(postal_code, str)
    assert postal_code

# Generated at 2022-06-23 21:07:33.581321
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    """Test method coordinates() of class Address."""
    assert len(Address().coordinates()) == 2
    assert type(Address().coordinates()['longitude']) is float
    assert type(Address().coordinates()['latitude']) is float
    assert len(Address().coordinates(dms=True)) == 2
    assert type(Address().coordinates(dms=True)['longitude']) is str
    assert type(Address().coordinates(dms=True)['latitude']) is str



# Generated at 2022-06-23 21:07:35.496335
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    a = Address()
    s = a.postal_code()
    print(s)


# Generated at 2022-06-23 21:07:39.402815
# Unit test for method state of class Address
def test_Address_state():
    geo = Address(locale='en')

    expected = ['Saint Martin', 'Sint Maarten', 'Saba']
    result = geo.state()
    assert result in expected
    result = geo.state(abbr=True)
    assert result in ['MF', 'SX', 'BQ']


# Generated at 2022-06-23 21:07:41.273872
# Unit test for method federal_subject of class Address
def test_Address_federal_subject():
    import random
    provider = Address('en')
    result = provider.federal_subject()
    assert result in provider.states


# Generated at 2022-06-23 21:07:42.623676
# Unit test for method continent of class Address
def test_Address_continent():
    Address().continent()
    Address().continent(code=True)


# Generated at 2022-06-23 21:07:47.275180
# Unit test for method country of class Address
def test_Address_country():
    from mimesis.localization import Localization

    # Test country without random
    test_provider = Address(Localization.EN)
    assert test_provider.country() == 'England'
    # Test country with random
    assert test_provider.country(True) in test_provider._data['country']['name']



# Generated at 2022-06-23 21:07:53.383351
# Unit test for method country_code of class Address
def test_Address_country_code():
    assert Address.country_code(fmt=CountryCode.A2) in COUNTRY_CODES['a2']
    assert Address.country_code(fmt=CountryCode.A3) in COUNTRY_CODES['a3']
    assert Address.country_code(fmt=CountryCode.Numeric) in COUNTRY_CODES['numeric']
    assert Address.country_code(fmt=CountryCode.Fifa) in COUNTRY_CODES['fifa']
    assert Address.country_code(fmt=CountryCode.Dial) in COUNTRY_CODES['dial']
    assert Address.country_code(fmt=CountryCode.Iso) in COUNTRY_CODES['iso']

# Generated at 2022-06-23 21:07:55.370169
# Unit test for method city of class Address
def test_Address_city():
    provider = Address()
    city = provider.city()
    assert isinstance(city, str)



# Generated at 2022-06-23 21:07:59.435936
# Unit test for method country_code of class Address
def test_Address_country_code():
    from mimesis.enums import CountryCode
    Address(seed=12345678912).country_code()
    Address(seed=12345678912).country_code(fmt=CountryCode.A3)
    Address(seed=12345678912).country_code(fmt=CountryCode.num)
    Address(seed=12345678912).country_code(fmt=CountryCode.name)


# Generated at 2022-06-23 21:08:00.731445
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    assert Address().calling_code() in CALLING_CODES

# Generated at 2022-06-23 21:08:03.622108
# Unit test for method coordinates of class Address
def test_Address_coordinates():
    a = Address()
    print(a.coordinates())
    print(a.coordinates(dms=True))

if __name__ == '__main__':
    test_Address_coordinates()

# Generated at 2022-06-23 21:08:08.618452
# Unit test for method calling_code of class Address
def test_Address_calling_code():
    from mimesis.enums import CountryCode
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    a = Address(locale='en')
    assert isinstance(a, Address)
    assert hasattr(a, 'calling_code')
    assert a.calling_code() in CALLING_CODES


# Generated at 2022-06-23 21:08:12.065230
# Unit test for method longitude of class Address
def test_Address_longitude():
    addr = Address()
    assert type(addr.longitude()) == float
    assert -180 <= addr.longitude() <= 180


# Generated at 2022-06-23 21:08:15.993127
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    address = Address("en")
    #address.seed(0)
    assert address.postal_code() == '662-035'
    assert address.zip_code() == '662-035'


# Generated at 2022-06-23 21:08:18.489841
# Unit test for method postal_code of class Address
def test_Address_postal_code():
    # TODO: remove print
    print(Address(locale='ru').postal_code())

# Generated at 2022-06-23 21:08:26.668246
# Unit test for method country_code of class Address
def test_Address_country_code():
    # Test for method country_code of class Address with fmt CountryCode.A2
    # Expected: AS
    r = Address().country_code(fmt=CountryCode.A2)
    assert(r == "AS")
    # Test for method country_code of class Address with fmt CountryCode.A3
    # Expected: ASM
    r = Address().country_code(fmt=CountryCode.A3)
    assert(r == "ASM")
    # Test for method country_code of class Address with fmt CountryCode.NUM
    # Expected: 16
    r = Address().country_code(fmt=CountryCode.NUM)
    assert(r == "16")