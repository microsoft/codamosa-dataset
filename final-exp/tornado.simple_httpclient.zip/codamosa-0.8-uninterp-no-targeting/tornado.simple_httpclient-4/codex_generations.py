

# Generated at 2022-06-22 04:17:33.902594
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    def test_on_connection_close_1(self):
        # This is not used anymore
        pass

# Generated at 2022-06-22 04:17:35.138536
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # _HTTPConnection.run needs to be tested in a fully functional
    # test.  (see test_client.py)
    pass


# Generated at 2022-06-22 04:17:40.510269
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    url = ""
    method = "GET"
    validate_cert = True
    client = HTTPClient()
    request = HTTPRequest(url, method, validate_cert)
    timeout = None
    auth_username = None
    auth_password = None
    follow_redirects = True
    allow_nonstandard_methods = False
    user_agent = None
    use_gzip = None
    network_interface = None
    streaming_callback = None
    header_callback = None
    prepare_curl_callback = None
    request_timeout = 20
    if_modified_since = None
    follow_redirects = True
    max_redirects = 5
    user_agent = None
    use_gzip = True
    network_interface = None
    streaming_callback = None
    header_callback = None
    prepare_

# Generated at 2022-06-22 04:17:41.284543
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    pass



# Generated at 2022-06-22 04:17:43.001465
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Create the object
    e = HTTPStreamClosedError('Testing')
    # Run the test
    assert e.__str__() == 'Testing'


# Generated at 2022-06-22 04:17:48.597503
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
  import json
  import os
  import tempfile
  import tornado.testing
  import tornado.web
  import tornado.websocket
  import unittest
  import urllib.parse
  from tornado import gen
  from tornado.httpclient import HTTPRequest, HTTPClient, AsyncHTTPClient
  from tornado.log import access_log, gen_log
  from tornado.testing import AsyncHTTPTestCase, AsyncTestCase, ExpectLog, gen_test
  # need str() to use repr() on python 2
  from tornado.testing import get_async_test_timeout
  from tornado.testing import main, skipOnTravis
  from tornado.testing import run_on_executor
  from tornado.testing import skipIfNonUnix
  from tornado.testing import unittest

# Generated at 2022-06-22 04:17:58.868288
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _io_loop = object()
    request = object()
    _max_buffer_size = object()
    streaming_callback = object()
    release_callback = object()
    final_callback = object()
    _connect_timeout = object()
    _connect_future = object()
    client = object()
    max_redirects = object()
    validate_cert = object()
    ca_certs = object()
    allow_ipv6 = object()
    _client_key = object()
    _client_cert = object()
    _server_hostname = object()
    _ssl_options = object()
    proxy_host = object()
    proxy_port = object()
    proxy_username = object()
    proxy_password = object()
    proxy_auth_mode = object()
    _proxy_auth_mode = object

# Generated at 2022-06-22 04:18:03.237112
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    request = HTTPRequest("http://www.google.com",method="GET")
    timeout = None
    release = None
    final = None
    io_loop = None
    connection = _HTTPConnection(
        request,
        timeout,
        release,
        final,
        io_loop
    )
    print("Success")


# Generated at 2022-06-22 04:18:06.356122
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError("error message").code == 599
    assert str(HTTPTimeoutError("error message")) == "error message"



# Generated at 2022-06-22 04:18:10.748801
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # type: () -> None
    """
    Make sure SimpleAsyncHTTPClient is closed correctly.
    """
    io_loop = IOLoop()
    io_loop.make_current()
    self = SimpleAsyncHTTPClient()
    self.close()



# Generated at 2022-06-22 04:23:27.184888
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    __tracebackhide__ = True
    # NotImplemented

# Generated at 2022-06-22 04:23:28.895473
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    temp = HTTPStreamClosedError('Error message')
    assert(temp)


# Generated at 2022-06-22 04:23:31.794669
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Constructor of _HTTPConnection should not raise any exception
    # and perform as expected
    _HTTPConnection(None, None, None)  # type: ignore


# Generated at 2022-06-22 04:23:42.964385
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # __init__() and close()
    _ = AsyncHTTPClient()
    _.close()
    _ = AsyncHTTPClient()
    _.close()
    # __init__() and initialize() and close()
    defaults = dict()  # type: Dict[str, Any]
    _ = AsyncHTTPClient()
    _.initialize(defaults=defaults)
    _.close()
    _ = AsyncHTTPClient()
    _.initialize(defaults=defaults)
    _.close()
    # __init__() and initialize() and close() and initialize()
    _ = AsyncHTTPClient()
    _.initialize(defaults=defaults)
    _.close()
    _.initialize(defaults=defaults)
    _.close()
    _ = AsyncHTTPClient()
   

# Generated at 2022-06-22 04:23:48.345141
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    self = _HTTPConnection(url_convert_arg) # type: ignore
    self.final_callback = _HTTPConnection_run_callback
    print('HTTPClient() is testing _HTTPConnection.run()')
    print('\n')
    print('_HTTPConnection.run() will return a response object')
    print('\n')
    return self.run()



# Generated at 2022-06-22 04:23:50.233784
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    assert HTTPStreamClosedError.__name__ == 'HTTPStreamClosedError'



# Generated at 2022-06-22 04:23:53.619200
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    objHTTPStreamClosedError = HTTPStreamClosedError(message="message test")
    print(objHTTPStreamClosedError.message)
    print(objHTTPStreamClosedError.code)

test_HTTPStreamClosedError()



# Generated at 2022-06-22 04:23:56.183883
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    instance = SimpleAsyncHTTPClient()

    # Unit test for method close of class SimpleAsyncHTTPClient
    assert isinstance(instance.close(), None)



# Generated at 2022-06-22 04:24:06.029411
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    with pytest.raises(HTTPStreamClosedError):
        HTTPClient()
        client._HTTPConnection(
            client,
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
            tornado.testing.mock_object(),
        )
        client.on_connection_close()

# Generated at 2022-06-22 04:24:07.577563
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    ...