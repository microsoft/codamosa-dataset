

# Generated at 2022-06-22 04:17:59.135018
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    error = HTTPTimeoutError("the timeout message")
    assert error.code == 599
    assert str(error) == "the timeout message"

# ssl.match_hostname was added in python 3.5 as a backport from
# python 3.2. This means we can use it in both python 2 and 3, but
# we need to import it differently for each python version.
if sys.version_info >= (3, 5):
    from ssl import match_hostname, CertificateError
else:
    from backports.ssl_match_hostname import match_hostname, CertificateError

# Default timeout for an HTTP request.  Can be overridden by using
# the `request_timeout` keyword argument to `HTTPClient.fetch`.
_DEFAULT_TIMEOUT = 20.0

# Non-chunk

# Generated at 2022-06-22 04:18:07.945900
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    client = _HTTPClient()
    request = HTTPRequest(url="http://google.com", method="GET")
    http_conn = _HTTPConnection(client, request)
    mock_stream = Mock()
    http_conn.stream = mock_stream
    http_conn.io_loop = IOLoop.current()
    http_conn._write_body = Mock(return_value=asyncio.sleep(0))
    http_conn.run()
    assert http_conn.headers is None
    assert http_conn.chunks == []
    assert http_conn.code == 0
    assert http_conn._timeout is None
    assert http_conn.final_callback is None
    assert http_conn.release_callback is None
    assert http_conn.start_time is None
    assert http_conn.start_wall_time is None


# Generated at 2022-06-22 04:18:11.119272
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    with pytest.raises(TypeError):
        HTTPClient.initialize(self, max_clients=10, max_buffer_size=104857600)

# Generated at 2022-06-22 04:18:12.748936
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # _HTTPConnection.data_received()
    #_HTTPConnection.data_received(chunk)
    return None



# Generated at 2022-06-22 04:18:15.755738
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    ioloop = IOLoop()
    ioloop.make_current()

    io_loop = IOLoop()
    io_loop.make_current()
    io_loop.run_sync(SimpleAsyncHTTPClient().initialize())


# Generated at 2022-06-22 04:18:21.045480
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    f = Future()
    def callback(response):
        assert response.body == b"testing..."
        f.set_result(None)
    hc = _HTTPConnection(
        SimpleAsyncHTTPClient(),
        None,
        HTTPRequest("http://localhost/"),
        callback,
        release_callback=None,
        final_callback=callback,
        io_loop=IOLoop.current(),
    )
    hc.code = 200
    hc.headers = httputil.HTTPHeaders({"Content-Length": "9"})
    hc.finish()
    hc.data_received(b"testing...")
    IOLoop.current().add_future(f, lambda f: f.result())

if __name__ == "__main__":
    test__HTTPConnection_finish()

# Generated at 2022-06-22 04:18:23.141886
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    exc = HTTPStreamClosedError("error")
    assert exc.__str__() == "Stream closed"



# Generated at 2022-06-22 04:18:28.036464
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("Timeout")
    assert error.code == 599
    assert error.message == "Timeout"
    assert str(error) == "Timeout"



# Generated at 2022-06-22 04:18:31.106086
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("foo")  # type: ignore
    except HTTPTimeoutError as e:
        assert isinstance(e, HTTPTimeoutError)
        assert e.code == 599
        assert str(e) == "foo"



# Generated at 2022-06-22 04:18:36.155504
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    SimpleAsyncHTTPClient.initialize(
        max_clients=10,
        hostname_mapping=None,
        max_buffer_size=104857600,
        resolver=None,
        defaults=None,
        max_header_size=None,
        max_body_size=None
    )
    SimpleAsyncHTTPClient.close()
