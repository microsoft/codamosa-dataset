

# Generated at 2022-06-22 04:17:44.237308
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass


# Generated at 2022-06-22 04:17:47.687673
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    exc = HTTPTimeoutError("my timeout")
    assert exc.code == 599
    assert str(exc) == "my timeout"


if version_info >= (3, 4):
    from asyncio import TimeoutError
else:
    TimeoutError = HTTPTimeoutError



# Generated at 2022-06-22 04:17:58.748731
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPClient

    from tornado.escape import utf8
    from tornado.escape import _unicode
    from tornado import gen, version
    from tornado.httpclient import (
        HTTPResponse,
        HTTPError,
        AsyncHTTPClient,
        main,
        _RequestProxy,
        HTTPRequest,
    )
    from tornado import httputil
    from tornado.http1connection import HTTP1Connection, HTTP1ConnectionParameters
    from tornado.ioloop import IOLoop
    from tornado.iostream import StreamClosedError, IOStream

# Generated at 2022-06-22 04:18:01.924404
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # this function tests the on_connection_close method of class HTTPClient
    # we don't test on_connection_close() because it is used for backword
    # compatibility with legacy code.
    pass


# Generated at 2022-06-22 04:18:03.173889
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    AsyncHTTPClient(force_instance=True)


# Generated at 2022-06-22 04:18:13.161691
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    import tornado
    import time
    from tornado.httpclient import HTTPRequest
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    AsyncIOMainLoop().install()  # Install the asyncio event loop.
    StartTime = time.time()
    async def async_main():
        http_client = SimpleAsyncHTTPClient()
        request = HTTPRequest("http://localhost/")
        response = await http_client.fetch(request)
        print("TEST passed.")
    loop = asyncio.get_event_loop()
    loop.create_task(async_main())
    loop.run_forever()



# Generated at 2022-06-22 04:18:16.759238
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = httputil.ResponseStartLine("version", "code", "reason")
    headers = httputil.HTTPHeaders()

    inst = _HTTPConnection(None, None, None)
    inst.headers_received(first_line, headers)

    assert inst.code == "code"



# Generated at 2022-06-22 04:18:18.438761
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError("foo")
    except HTTPStreamClosedError:
        pass



# Generated at 2022-06-22 04:18:21.823594
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    ___
    class HTTPStreamClosedErrorTester(HTTPStreamClosedError):
        def __init__(self, message):
            super().__init__(message)

# Generated at 2022-06-22 04:18:32.770808
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    """Created on Mon Feb  4 09:27:11 2019 by:
        
                        _HTTPConnection().run
        
    """
    body_producer = (lambda x: None)
    auth_mode = "basic"
    allow_nonstandard_methods = False
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"
    expect_100_continue = False
    body = b"somebytes"
    decompress_response = True
    io_loop = IOLoop()
    io_loop.run_sync(_HTTPConnection().run,io_loop=io_loop)
    return
        

# Generated at 2022-06-22 04:21:41.871320
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError('some_message')
    assert e.__str__() == 'some_message'
    e = HTTPStreamClosedError('')
    assert e.__str__() == 'Stream closed'
    e = HTTPStreamClosedError(None)
    assert e.__str__() == 'Stream closed'


# Generated at 2022-06-22 04:21:46.296987
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    def test(self, chunk: bytes) -> None:
        if self._should_follow_redirect():
            # We're going to follow a redirect so just discard the body.
            return 0
        if self.request.streaming_callback is not None:
            self.request.streaming_callback(chunk)
        else:
            self.chunks.append(chunk)

# Generated at 2022-06-22 04:21:50.790455
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    httpclient.AsyncHTTPClient.configure(None, defaults=dict(max_clients=256))
    client = httpclient.AsyncHTTPClient()

    def handle_request(response):
        assert response.code == 200
        assert response.headers["Content-Type"] == "text/html"
        data = response.buffer.read()
        assert b"Welcome to Tornado" in data
        io_loop.stop()

    io_loop = ioloop.IOLoop.current()
    io_loop.add_callback(
        client.fetch,
        httpclient.HTTPRequest("http://www.google.com/"),
        handle_request,
    )
    io_loop.start()



# Generated at 2022-06-22 04:21:51.450174
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass

# Generated at 2022-06-22 04:21:58.323989
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    err = HTTPStreamClosedError("message")
    assert isinstance(err, HTTPError)
    assert str(err) == "message"
    err = HTTPStreamClosedError(None)
    assert isinstance(err, HTTPError)
    assert str(err) == "Stream closed"

if typing.TYPE_CHECKING:
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from tornado.httpclient import AsyncHTTPClient  # noqa: F401



# Generated at 2022-06-22 04:22:03.409259
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    http_client = HTTPClient()
    request = HTTPRequest(url='http://www.google.com')
    http_client.fetch(request, raise_error=False)

# Generated at 2022-06-22 04:22:13.031387
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    
    http = _HTTPConnection()
    http.request = mock.MagicMock()
    http.request.expect_100_continue = True
    http.request.follow_redirects = False
    http.request.max_redirects = 10
    http.request.method = "get"
    http.request.original_request = mock.MagicMock()
    http.request.original_request.method = "get"
    http.request.url = "https://www.httpbin.org/"
    http.request.body = None
    http.request.headers = httputil.HTTPHeaders()
    http.request.headers["Location"] = "https://www.httpbin.org/get"
    http.request.header_callback = mock.MagicMock()
    http.headers = httputil.HTTPHeaders()

# Generated at 2022-06-22 04:22:20.808767
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    try:
        io_loop = IOLoop()
        io_loop.make_current()
        # test if the construction is correct
        http_connection = _HTTPConnection(io_loop, "localhost", 443, None)
        assert http_connection.io_loop is io_loop
        assert http_connection.host == "localhost"
        assert http_connection.port == 443
        assert http_connection.ssl_options is None
        # test if the method __repr__ is correct
        assert str(http_connection) == "_HTTPConnection(io_loop, host='localhost', port=443, ssl_options=None)"
        assert repr(http_connection) == str(http_connection)
    finally:
        io_loop.close()


# Generated at 2022-06-22 04:22:25.817706
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    '''
    Unit test for method fetch_impl of class SimpleAsyncHTTPClient
    '''
    request = HTTPRequest("http://example.com/")
    callback = lambda :None
    cls = SimpleAsyncHTTPClient(io_loop=IOLoop())
    cls.fetch_impl(request, callback)


# Generated at 2022-06-22 04:22:28.860891
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    with pytest.raises(TypeError):
        _HTTPConnection.data_received(handler)


# Inheritors of this class should define an async_fetch_impl method.