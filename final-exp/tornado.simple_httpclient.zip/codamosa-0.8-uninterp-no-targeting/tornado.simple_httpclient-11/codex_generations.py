

# Generated at 2022-06-22 04:17:50.451786
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-22 04:18:00.123451
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    rq = HTTPRequest(url="http://127.0.0.1:8888/test")
    rq.follow_redirects = False
    rq.max_redirects = 0
    rq.validate_cert = False
    rq.proxy_host = None
    rq.proxy_port = None
    rq.allow_nonstandard_methods = False
    rq.expect_100_continue = False
    rq.decompress_response = False
    h = _HTTPConnection(rq, client=None, on_headers_callback=None)
    h.request = rq

# Generated at 2022-06-22 04:18:01.837394
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    h = HTTPTimeoutError("Timeout")
    assert str(h) == "Timeout"



# Generated at 2022-06-22 04:18:13.204700
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    from copy import copy
    from tornado import testing
    from tornado.httpclient import HTTPTimeoutError
    # Test the method '__str__' of class 'HTTPTimeoutError' with error
    def gen_test_HTTPTimeoutError___str___with_error(message):
        gen_log.debug("Start to test: HTTPTimeoutError.__str__('{}')".format(message))
        with testing.gen_test(print_exception_stack=True) as t:
            error = HTTPTimeoutError(message)
            try:
                assert t.assertEqual(error.__str__(), message)
            except Exception as e:
                gen_log.error("Fail to test: HTTPTimeoutError.__str__('{}') [expect: {}] [real: {}]".format(message, message, error.__str__()))
                raise

# Generated at 2022-06-22 04:18:14.034138
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    import pytest

    assert False

# Generated at 2022-06-22 04:18:23.573963
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port
    import tornado.platform.asyncio
    import asyncio

    class TempTest(AsyncHTTPTestCase):
        def get_app(self):
            # type: () -> tornado.web.Application
            return tornado.web.Application()

        @tornado.testing.gen_test
        def test_simple_fetch(self):
            f_server = self.get_http_server()
            port = f_server._socket.getsockname()[1]
            response = yield self.http_client.fetch(
                "http://127.0.0.1:{}".format(port)
            )
            self.assertEqual(response.code, 200)

    _ioloop = IOLoop.current()

    tcp_server = _ioloop

# Generated at 2022-06-22 04:18:28.534527
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert HTTPStreamClosedError("").__str__() == "Stream closed"
    assert HTTPStreamClosedError("No message").__str__() == "No message"
    return



# Generated at 2022-06-22 04:18:32.948655
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    conn = _HTTPConnection(
        host="127.0.0.1", port=8080, request=HTTPRequest(url="http://www.example.com")
    )

    assert(conn.parsed.netloc == "127.0.0.1:8080")
    assert(conn.parsed.scheme == "http")



# Generated at 2022-06-22 04:18:33.859413
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    c = _HTTPConnection()

# Generated at 2022-06-22 04:18:38.072800
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    io_loop = IOLoop()
    io_loop.make_current()
    c = AsyncHTTPClient(io_loop)
    req = HTTPRequest(url='http://google.com')
    req.proxy_host = '127.0.0.1'
    req.proxy_port = '8080'
    c.fetch(req)
    io_loop.run_sync(c.fetch)
    #io_loop.close()
    del c
    io_loop.close()

# Generated at 2022-06-22 04:25:08.880253
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    resp = HTTPTimeoutError(message='Timeout')
    assert str(resp) == 'Timeout'


# Generated at 2022-06-22 04:25:09.752468
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-22 04:25:12.562908
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert str(HTTPTimeoutError('')) == 'Timeout'
    assert str(HTTPTimeoutError('timeout')) == 'timeout'



# Generated at 2022-06-22 04:25:23.173222
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Create a mock context object, and patch the request
    ctx = MagicMock()
    ctx.request = MagicMock(
        follow_redirects=True, max_redirects=1, url="http://example.com"
    )
    ctx.request.headers = {
        "Location": "http://redirected.com",
    }
    ctx.code = 301
    ctx.headers = {
        "Location": "http://redirected.com",
    }
    # Patch the response
    response = MagicMock()
    response.code = 301
    response.reason = "OK"
    response.headers = {
        "Location": "http://redirected.com",
    }
    # Call the target function
    ctx.headers_received(response, response.headers)
   

# Generated at 2022-06-22 04:25:27.892791
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Simple test for method 'finish' of class '_HTTPConnection'
    client = AsyncHTTPClient()
    response = client.fetch('http://google.com/')
    assert response.code == 200
    response.buffer.seek(0)
    assert b'google' in response.buffer.read()

if __name__ == '__main__':
    test__HTTPConnection_finish()

# Generated at 2022-06-22 04:25:36.936978
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import unittest

    class MyTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return

        @gen_test
        def test_initialize(self):
            http_client = gen.SimpleAsyncHTTPClient(max_clients=10)
            assert isinstance(http_client, SimpleAsyncHTTPClient)
            http_client.close()

    unittest.main()

# Generated at 2022-06-22 04:25:45.327784
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    req_headers = httputil.HTTPHeaders()
    req_headers["Host"] = "localhost"
    req_headers["Accept-Encoding"] = "gzip"
    req_headers["Content-Type"] = "application/x-www-form-urlencoded"
    req_headers["Content-Length"] = "11"
    req_headers["User-Agent"] = "Tornado/4.5.2"

    req_path = "/hello"
    req_start_line = httputil.RequestStartLine("GET", req_path, "HTTP/1.1")
    stream = IOStream(Mock())

    c = _HTTPConnection(
        stream,
        "localhost",
        443,
        True,
        HTTP1ConnectionParameters(no_keep_alive=True),
        Mock(),
    )

   

# Generated at 2022-06-22 04:25:55.529715
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # setUp
    self     = object()
    self.code = None
    self.reason = None
    self.headers = None
    self.request = object()
    self.request.expect_100_continue = False
    first_line = 'first_line'
    headers = 'headers'

    # _HTTPConnection's method headers_received when self.request.expect_100_continue is False
    self.headers_received(first_line, headers)
    assert self.code == first_line.code
    assert self.reason == first_line.reason
    assert self.headers == headers

    # _HTTPConnection's method headers_received when self.request.expect_100_continue is False
    # and self.headers is None
    self.headers_received(first_line, None)
    assert self.code == first_line

# Generated at 2022-06-22 04:26:00.371609
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from tornado.httpserver import HTTPServer
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    #asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    with HTTPServer() as server:
        server.listen(8889)
        pass


# Generated at 2022-06-22 04:26:07.824983
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    stream = MagicMock(io.IOBase)
    parsed = urllib.parse.urlparse("http://www.example.com/")
    request = HTTPRequest("http://www.example.com/", streaming_callback=None)
    client = AsyncHTTPClient()
    http_client = _HTTPConnection(stream, parsed, request, client)
    chunk = b"test_data_received"
    http_client.data_received(chunk)
    assert len(http_client.chunks) == 1
    assert http_client.chunks[0] == chunk
