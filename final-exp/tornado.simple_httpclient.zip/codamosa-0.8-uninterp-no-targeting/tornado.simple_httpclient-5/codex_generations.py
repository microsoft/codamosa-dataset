

# Generated at 2022-06-22 04:17:40.022018
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # N.B.: tests for _HTTPConnection attributes are in AsyncHTTPClientTestCase,
    # since those depend on the global state of the class.
    # test_set_close_callback is in AsyncHTTPConnectionTestCase.
    # test_key_file is in SimpleAsyncHTTPClientTestCase.
    test = AsyncHTTPClientTestCase()
    test.parsed = urllib.parse.urlparse("http://www.google.com/")
    test.stream = IOStream(socket.socket())
    test.response = _HTTPConnection(test.io_loop, test.parsed, test.stream, None, None)
    test.response.request = HTTPRequest("http://www.google.com/")
    test.response.code = 200

# Generated at 2022-06-22 04:17:41.224788
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    return


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 04:17:42.370600
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # _HTTPConnection.finish(self)
    pass

# Generated at 2022-06-22 04:17:43.030464
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass #TODO



# Generated at 2022-06-22 04:17:44.236953
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import pytest

    with pytest.raises(Exception):
        _HTTPConnection()

# Generated at 2022-06-22 04:17:45.512681
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError('Stream closed')
    assert error.code == 599
    assert error.message == 'Stream closed'


# Generated at 2022-06-22 04:17:50.439070
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError()
    except Exception as e:
        assert type(e) == HTTPStreamClosedError
        assert e.code == 599



# Generated at 2022-06-22 04:17:52.912430
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError(message="Stream closed")
    assert str(error) == "Stream closed"
    assert error.status_code == 599



# Generated at 2022-06-22 04:17:54.245595
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    pass # TODO: construct object of type SimpleAsyncHTTPClient



# Generated at 2022-06-22 04:17:57.354952
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError("message")
    assert error.status_code == 599
    assert error.message == "message"
    assert str(error) == "message"


# Generated at 2022-06-22 04:18:40.289864
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    request = HTTPRequest()
    assert request is not None
    assert request.get_full_url() == 'http://localhost/'
    assert request.get_header('User-agent') == 'Python-urllib/3.6'
    assert request.get_method() == 'GET'
    assert request.get_type() == None
    assert request.has_header('User-agent') == True
    assert request.has_header('user-agent') == True
    assert request.set_proxy('http://proxy.example.com') is None
    assert request.get_method() == 'GET'
    assert request.get_selector() == '/'
    assert request.get_type() == None
    assert request.get_origin_req_host() == None
    assert request.get_selector() == '/'

# Generated at 2022-06-22 04:18:45.449508
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    chunks = []

# Generated at 2022-06-22 04:18:52.959707
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError(None)
    except HTTPStreamClosedError as e:
        assert e.message is None
        assert str(e) == "Stream closed"
    except Exception:
        assert False
    try:
        raise HTTPStreamClosedError('')
    except HTTPStreamClosedError as e:
        assert e.message is None
        assert str(e) == "Stream closed"
    except Exception:
        assert False
    try:
        raise HTTPStreamClosedError('hello')
    except HTTPStreamClosedError as e:
        assert e.message == 'hello'
        assert str(e) == 'hello'
    except Exception:
        assert False



# Generated at 2022-06-22 04:18:58.564051
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import tornado.httpserver

    class Server(object):
        def __init__(self, io_loop):
            self.io_loop = io_loop
            sock, port = bind_unused_port()
            self.io_loop.add_callback(self.start, sock, port)
            self.port = port

        def start(self, sock, port):
            self.http_server = tornado.httpserver.HTTPServer(
                RequestHandler, io_loop=self.io_loop, ssl_options={
                    "certfile": self.get_ssl_cert('testcert.pem'),
                    "keyfile": self.get_ssl_cert('testkey.pem'),
                })
            self.http_server.add_socket(sock)

        def stop(self):
            self.http_server.stop

# Generated at 2022-06-22 04:19:01.268140
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    conn = _HTTPConnection(object(), object())
    headers = httputil.HTTPHeaders({"Content-Type": "text/html; charset=UTF-8"})
    conn.headers_received(httputil.ResponseStartLine("HTTP/1.1", 200, "OK"), headers)

    assert conn.headers == headers
    assert conn.code == 200
    assert conn.reason == "OK"
    assert not conn._should_follow_redirect()



# Generated at 2022-06-22 04:19:08.739600
# Unit test for constructor of class HTTPTimeoutError

# Generated at 2022-06-22 04:19:10.533891
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    # __str__()
    assert True



# Generated at 2022-06-22 04:19:12.223512
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    assert SimpleAsyncHTTPClient().max_clients == 10



# Generated at 2022-06-22 04:19:15.134405
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    err: HTTPStreamClosedError = HTTPStreamClosedError("Stream closed")
    assert err.__str__() == "Stream closed"

# Generated at 2022-06-22 04:19:25.886004
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        async def test_data_received(self):
            from tornado.http1connection import _HTTPConnection

            c = _HTTPConnection("127.0.0.1", 80)
            c.chunks = []
            c.request = object()
            c.request.streaming_callback = MagicMock()
            c.request.streaming_callback.return_value = to_asyncio_future(None)
            await c.data_received(b"1")
            self.assertEqual(c.chunks, [])
            c.request.streaming_callback.assert_called_once_with(b"1")
           

# Generated at 2022-06-22 04:20:09.998208
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    global _HTTPConnection  # type: ignore
    client = AsyncHTTPClient()
    request = HTTPRequest("https://www.google.com")
    client._httpclient._connect_to_host(
        "127.0.0.1", 8888, request, lambda x: x  # type: ignore
    )
    request = HTTPRequest("http://www.google.com")
    client._httpclient._connect_to_host(
        "127.0.0.1", 8888, request, lambda x: x  # type: ignore
    )



# Generated at 2022-06-22 04:20:22.456963
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Test that a AsyncHTTPClient can be constructed
    client = SimpleAsyncHTTPClient()
    assert not client.closed
    client.close()
    assert client.closed
    assert isinstance(client.queue, collections.deque)
    assert isinstance(client.active, dict)
    assert isinstance(client.waiting, dict)
    assert client.max_buffer_size == 104857600
    assert isinstance(client.resolver, Resolver)
    assert isinstance(client.tcp_client, TCPClient)

    # Test that passing the max_clients parameter works
    client = SimpleAsyncHTTPClient(max_clients=42)
    assert client.max_clients == 42
    client.close()

    # Test that passing the hostname_mapping parameter works

# Generated at 2022-06-22 04:20:23.904281
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    http_client = SimpleAsyncHTTPClient()
    http_client.close()


# Generated at 2022-06-22 04:20:26.929573
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    global _HTTPConnection
    def test():
        global _HTTPConnection
        assert _HTTPConnection is not None
    test()

# Generated at 2022-06-22 04:20:28.358418
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    print("Testing SimpleHTTPClient")
    SimpleAsyncHTTPClient()
    

# Generated at 2022-06-22 04:20:39.270374
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    '''
    class SimpleAsyncHTTPClient(AsyncHTTPClient):
        '''
    max_clients = 10
    hostname_mapping = None
    max_buffer_size = 104857600
    resolver = None
    defaults = None
    max_header_size = None
    max_body_size = None

    http_client = SimpleAsyncHTTPClient()
    http_client.initialize(max_clients,hostname_mapping,max_buffer_size,resolver,defaults,max_header_size,max_body_size)

    assert(http_client.max_clients == max_clients)
    assert(http_client.max_buffer_size == max_buffer_size)
    assert(http_client.max_header_size == max_header_size)

# Generated at 2022-06-22 04:20:41.486880
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection_test.test__HTTPConnection_finish()


# Generated at 2022-06-22 04:20:43.621189
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    ins = HTTPTimeoutError("")
    r = str(ins)
    assert r is None, r


# Generated at 2022-06-22 04:20:44.205120
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-22 04:20:52.570124
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    from tornado.test.util import unittest
    from tornado.test.httpclient_test import skip_if_no_ipv6
    from tornado.httpclient import HTTPRequest

    class SimpleAsyncHTTPClientTestCase(unittest.TestCase):
        def test_consturctor(self):
            SimpleAsyncHTTPClient()

    # Unit test for method fetch_impl
    class SimpleAsyncHTTPClientFetchTestCase(unittest.TestCase):
        def setUp(self):
            self.http_client = SimpleAsyncHTTPClient()

        def tearDown(self):
            self.http_client.close()

        def test_fetch_impl_get(self):
            url = "http://localhost:8888/hello"
            http_request = HTTPRequest(url)

# Generated at 2022-06-22 04:21:35.075352
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():

    # class reference for mock
    class Test():
        def __init__(self):
            self.stream = Mock()
        
    # mock
    stream = Mock()
    stream.error = Exception()
    test = Test()
    test.final_callback = Mock()
    
    # call target method
    test._HTTPConnection.on_connection_close(test)

    # assert
    assert test.stream.close.called


# Generated at 2022-06-22 04:21:38.312762
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    response = HTTPStreamClosedError('Stream closed')
    assert response.message == 'Stream closed'
    assert str(response) == 'Stream closed'
# End of test_HTTPStreamClosedError___str__


# Generated at 2022-06-22 04:21:47.276607
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    url = "https://www.baidu.com/s?wd=tornado"
    request = HTTPRequest(url, method="GET")
    client = HTTPClient()
    http_connection = _HTTPConnection(request, client, io_loop=IOLoop.current())
    assert http_connection._sockaddr is None
    assert http_connection.request == request
    assert http_connection.client == client
    assert http_connection.io_loop == IOLoop.current()
    assert http_connection.final_callback is None
    assert http_connection.headers is None
    assert http_connection.code is None
    assert http_connection.chunks is None
    assert http_connection.start_time is None
    assert http_connection.release_callback is None

# Generated at 2022-06-22 04:21:53.061826
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    def fun(a: int, b:str, **kwargs: int) -> None:
        print(a, b, kwargs)
    fun(1, "a", a=2, b=3)
    #client = SimpleAsyncHTTPClient()
    #client.initialize()


# Generated at 2022-06-22 04:21:57.515563
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    """Unit test for constructor of class SimpleAsyncHTTPClient.

    The class needs to be imported for the constructor to be added to
    the class.
    """
    async_client = SimpleAsyncHTTPClient()
    assert async_client is not None


# Generated at 2022-06-22 04:22:10.177793
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    max_clients = 10
    hostname_mapping: Optional[Dict[str, str]] = None
    max_buffer_size = 104857600
    resolver: Optional[Resolver] = None
    defaults: Optional[Dict[str, Any]] = None
    max_header_size: Optional[int] = None
    max_body_size: Optional[int] = None

# Generated at 2022-06-22 04:22:16.864518
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    err = HTTPStreamClosedError(None)
    assert str(err) == "Stream closed"
    err = HTTPStreamClosedError("")
    assert str(err) == "Stream closed"
    err = HTTPStreamClosedError("some message")
    assert str(err) == "some message"



# Generated at 2022-06-22 04:22:19.825571
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    client = httpclient.AsyncHTTPClient()
    client.fetch("http://example.com", callback=lambda x: None)



# Generated at 2022-06-22 04:22:31.406966
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    fetch_impl = SimpleAsyncHTTPClient.fetch_impl
    request = HTTPRequest('https://api.example.com/')
    request.connect_timeout = 1
    request.request_timeout = 1
    fs = []
    def cb(response):
        pass
    SimpleAsyncHTTPClient.initialize()
    fetch_impl(request, cb)
    assert len(SimpleAsyncHTTPClient.queue) == 1
    assert len(SimpleAsyncHTTPClient.active) == 0
    assert len(SimpleAsyncHTTPClient.waiting) == 1
    fetch_impl(request, cb)
    assert len(SimpleAsyncHTTPClient.queue) == 2
    assert len(SimpleAsyncHTTPClient.active) == 0
    assert len(SimpleAsyncHTTPClient.waiting) == 2
    SimpleAsyncHTTPClient.io_loop.time = lambda: 0


# Generated at 2022-06-22 04:22:35.747153
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Expecting exception: AttributeError
    error_message = "Cannot use headers_received method, no instance of _HTTPConnection created"
    try:
        _HTTPConnection.headers_received(None, None, None)
    except Exception as err:
        if str(err) == error_message:
            return True
        else:
            raise
    return False

# Generated at 2022-06-22 04:23:59.352000
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert str(HTTPStreamClosedError("Stream closed")) == "Stream closed"
    assert str(HTTPStreamClosedError("")) == "Stream closed"
    assert str(HTTPStreamClosedError("Lorem ipsum")) == "Lorem ipsum"
    assert str(HTTPStreamClosedError(None)) == "Stream closed"



# Generated at 2022-06-22 04:24:03.050987
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    _HTTPTimeoutError___str__("HTTPTimeoutError(\"message\")",
                "message")


# Generated at 2022-06-22 04:24:03.645255
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-22 04:24:07.566295
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    client = httpclient.AsyncHTTPClient()
    f = client.fetch('https://baidu.com')
    # TODO: Implement test
    print(f.result())


# Generated at 2022-06-22 04:24:09.889146
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    obj = HTTPTimeoutError("")
    assert str(obj) == "Timeout", "str(obj) != Timeout"


# Generated at 2022-06-22 04:24:12.174622
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    if sys.version_info >= (3, 7):
        client = SimpleAsyncHTTPClient()
        assert "SimpleAsyncHTTPClient" in repr(client)


# Generated at 2022-06-22 04:24:15.579936
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Verify that SimpleAsyncHTTPClient.fetch_impl works correctly
    # SimpleAsyncHTTPClient.fetch_impl(object, functools.partial, functools.partial)
    # unit test for method fetch_impl of class SimpleAsyncHTTPClient
    return None

# Generated at 2022-06-22 04:24:19.197936
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Create an instance of class _HTTPConnection
    http_connection = SimpleHTTPClient()
    first_line = first_line
    headers = headers

    # Test the method
    http_connection.headers_received(first_line, headers)
    pass


# Generated at 2022-06-22 04:24:23.663774
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert str(HTTPTimeoutError("test message")) == "test message"
    assert str(HTTPTimeoutError("")) == "Timeout"


# Kill the warning about HTTP1Connection not being a new-style class
HTTP1Connection = HTTP1Connection



# Generated at 2022-06-22 04:24:35.547630
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-22 04:26:10.296550
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    """
    "_HTTPConnection"
    """

# Generated at 2022-06-22 04:26:17.098578
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from tornado.ioloop import IOLoop
    from tornado.testing import gen_test, ExpectLog
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.concurrent import Future

    io_loop = IOLoop()
    io_loop.make_current()

    async def f():
        response = Future()
        client = AsyncHTTPClient(io_loop=io_loop)
        client._fetch_impl = MockHTTPConnection(io_loop, True,
                                                response,
                                                raise_error=False)

        client.fetch(HTTPRequest("http://www.google.com",
                                 follow_redirects=True,
                                 max_redirects=1),
                     callback=lambda r: response.set_result(r),
                     raise_error=False)

# Generated at 2022-06-22 04:26:19.288588
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    conn = _HTTPConnection(None, None)
    assert conn != None, "type is not _HTTPConnection"


# Generated at 2022-06-22 04:26:21.204143
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    msg = 'Stream closed'
    e = HTTPStreamClosedError(msg)
    print(repr(e))
    # Output:
    # HTTP 599: Stream closed

    print(e)
    # Output:
    # Stream closed

if typing.TYPE_CHECKING:
    from typing import Deque, Tuple, List  # noqa: F401



# Generated at 2022-06-22 04:26:23.409287
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    message = 'Stream closed'
    http_stream_closed_error = HTTPStreamClosedError(message)
    assert str(http_stream_closed_error) == message


# Generated at 2022-06-22 04:26:28.288437
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    from tornado.platform.asyncio import to_asyncio_future
    from typing import Dict, Any
    from tornado.httpclient import HTTPRequest

    def test_streaming_callback(chunk: bytes) -> None:
        pass

    def test_final_callback(response):
        pass
    # The definition of _HTTPConnection
    request = HTTPRequest(method="GET", url="http://www.google.com/")
    parsed = urllib.parse.urlparse(request.url)
    request.headers = httputil.HTTPHeaders({"User-Agent": "Mozilla/5.0"})
    request.streaming_callback = test_streaming_callback
    request.auth_username = None
    request.auth_password = None
    request.proxy_username = None
    request.proxy_password = None

# Generated at 2022-06-22 04:26:31.289945
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert HTTPTimeoutError("abc").__str__() == "abc"
    assert HTTPTimeoutError("").__str__() == "Timeout"



# Generated at 2022-06-22 04:26:36.560260
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError()
    assert error.code == 599
    assert error.message == "Stream closed"
    assert str(error) == "Stream closed"
    error = HTTPStreamClosedError("Stream closed")
    assert error.code == 599
    assert error.message == "Stream closed"
    assert str(error) == "Stream closed"
    error = HTTPStreamClosedError(message = "Stream closed")
    assert error.code == 599
    assert error.message == "Stream closed"
    assert str(error) == "Stream closed"


# Generated at 2022-06-22 04:26:47.660850
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    class Mock_request:
        def __init__(self) -> None:
            self.method = "GET"
            self.request = self
            self.max_redirects = 3
            self.url = "www.google.com"
            self.headers = {}
            self.follow_redirects = True
            self.original_request = self
    class Mock_client:
        def __init__(self) -> None:
            self.fetch = Mock()
    class Mock_final_callback:
        def __init__(self) -> None:
            self.result = None
            self.assert_called_once_with = Mock()
    class Mock_HTTPResponse:
        def __init__(self, request: Mock_request) -> None:
            self.request = request

    http_connection = _HTTP