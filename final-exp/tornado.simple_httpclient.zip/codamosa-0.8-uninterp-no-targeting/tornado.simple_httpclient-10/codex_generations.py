

# Generated at 2022-06-22 04:17:41.804055
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado import httputil
    from tornado.log import gen_log
    from tornado.tcpclient import TCPClient
    import collections
    import functools
    import socket

    def _handle_request(
        self,
        request: HTTPRequest,
        release_callback: Callable[[], None],
        final_callback: Callable[[HTTPResponse], None],
    ) -> None:
        self._connection_class()(
            self,
            request,
            release_callback,
            final_callback,
            self.max_buffer_size,
            self.tcp_client,
            self.max_header_size,
            self.max_body_size,
        )

    # NOTE: This code is originally from tornado.httpclient.py:SimpleAsyncHTTPClient
    # this code is changed to adapt to the

# Generated at 2022-06-22 04:17:51.492133
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    from tornado.httputil import HTTPHeaders as _HTTPHeaders
    from tornado.httputil import ResponseStartLine as _ResponseStartLine
    from tornado import gen as _gen
    from tornado.httpclient import HTTPRequest as _HTTPRequest
    from tornado.httpclient import HTTPError as _HTTPError
    from tornado.httpclient import HTTPResponse as _HTTPResponse
    from tornado.httpclient import AsyncHTTPClient as _AsyncHTTPClient
    from tornado.httpclient import SimpleAsyncHTTPClient as _SimpleAsyncHTTPClient
    from tornado.httpclient import HTTPTimeoutError as _HTTPTimeoutError
    from tornado.httpclient import HTTPStreamClosedError as _HTTPStreamClosedError
    from tornado import ioloop as _ioloop
    from tornado import httputil as _httputil
    from tornado import platform as _platform

# Generated at 2022-06-22 04:17:56.388035
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    ## Init
    parser = MockHeadParser()
    stream = MockStream("")
    client = MockClient('example.com',80)
    request = MockHTTPRequest()
    request.headers = {}
    request.url = ""

    async def callback(chunk):
        pass
    request.streaming_callback = callback
    request.max_redirects = 100
    request.follow_redirects = True
    request.method = "GET"
    
    ## Call function
    conn = _HTTPConnection(client, request, parser, stream, io_loop=None, on_host=None)
    conn._get_ssl_options = lambda x: None
    
    testStr01 = "HTTP/1.1 301 Moved Permanently"
    testStr02 = "Location: http://www.iana.org/domains/example/"

# Generated at 2022-06-22 04:18:00.663934
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    args = ["message", "599"]
    assert repr(HTTPStreamClosedError(*args)) == "HTTPStreamClosedError(599, message=" + repr(args[0]) + ")"



# Generated at 2022-06-22 04:18:01.967475
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # Constructor of class SimpleAsyncHTTPClient
    http_client = SimpleAsyncHTTPClient()

# Generated at 2022-06-22 04:18:05.940224
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    io_loop = NullIOLoop()
    client = HTTPClient(io_loop)

    class _FakeConnection(object):
        def close(self):
            pass

    _FakeConnection.stream = _FakeConnection()
    connection = _HTTPConnection(_FakeConnection, client, _FakeConnection.stream, None)
    connection.on_connection_close()
    
    


# Generated at 2022-06-22 04:18:08.565373
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    ex = HTTPStreamClosedError("something")
    assert str(ex) == "something"
    assert ex.code == 599
    assert ex.message == "something"



# Generated at 2022-06-22 04:18:16.238689
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    from tornado.stack_context import ExceptionStackContext

    class MockHTTPResponse(Structure):
        code = 0

    class MockIOStream(Structure):
        def set_close_callback(self, callback: Callable[[], None]) -> None:
            setattr(self, "set_close_callback", callback)

    class MockHTTP1Connection(Structure):
        def read_response(self, foo: "_HTTPConnection") -> None:
            pass

    class MockRequest(Structure):
        streaming_callback = Callable[[bytes], None]

    class MockClient(Structure):
        def fetch(self, req: "MockRequest", raise_error: bool = True) -> Callable:
            return lambda f: None


# Generated at 2022-06-22 04:18:22.295705
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError("hi")
    except HTTPStreamClosedError as e:
        pass

_DEFAULT_CA_CERTS = "/etc/ssl/certs/ca-certificates.crt"

if version.startswith("4."):
    HTTPError = HTTPError
else:
    # In Tornado 5, HTTPError is a class that can be extended
    HTTPError = HTTPError  # type: ignore # type: ignore # type: ignore



# Generated at 2022-06-22 04:18:23.748635
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
	from httpclient import HTTPClient, AsyncHTTPClient, HTTPResponse, HTTPRequest, HTTPError

# Generated at 2022-06-22 04:19:17.497098
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from unittest.mock import Mock, ANY
    mock_self = Mock(SimpleAsyncHTTPClient)
    mock_self.__class__ = SimpleAsyncHTTPClient
    mock_self.initialize.__class__ = SimpleAsyncHTTPClient.initialize
    def mock_HTTPConnection__init__(http1connection_self, *args, **kwargs):
        raise NotImplementedError
    HTTPConnection.__init__ = mock_HTTPConnection__init__
    mock_self.close.__class__ = SimpleAsyncHTTPClient.close
    def mock_TCPClient__init__(tcpclient_self, *args, **kwargs):
        raise NotImplementedError
    TCPClient.__init__ = mock_TCPClient__init__
    mock_self.max_clients = Mock()
    mock_self.queue = Mock()


# Generated at 2022-06-22 04:19:21.312578
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # constructor test
    # initialized property test
    client = SimpleAsyncHTTPClient()
    assert client.initialized == True
    client.close()
    assert client.initialized == False
    # close method test
    client = SimpleAsyncHTTPClient()
    client.close()
    assert client.closed == True


# Generated at 2022-06-22 04:19:27.053966
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    connection = _HTTPConnection(None, None)
    connection._handle_exception = MagicMock(return_value=True)
    connection.stream = MagicMock()
    connection.stream.error = AttributeError
    connection.on_connection_close()
    connection._handle_exception.assert_called_once_with(AttributeError)


# Generated at 2022-06-22 04:19:30.383226
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _HTTPConnection(None, None).on_connection_close()

# Generated at 2022-06-22 04:19:31.571853
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass


# Generated at 2022-06-22 04:19:32.232450
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    ...


# Generated at 2022-06-22 04:19:37.258506
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    httpclient_ = mock.Mock()
    io_loop_ = mock.Mock()
    request_ = mock.Mock()
    _sockaddr_ = mock.Mock()
    parent_()
    http_client = _HTTPConnection(
        httpclient_, io_loop_, request_, _sockaddr_, parent_,
    )
    chunk = b'\x00\x00'
    result = http_client.data_received(chunk)
    httpclient_.assert_called_once_with()
    assert result == None


# Generated at 2022-06-22 04:19:44.900920
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    client = AsyncHTTPClient()
    res = client.fetch(
        HTTPRequest(
            url="https://login.wx.qq.com/jslogin?appid=wx782c26e4c19acffb&redirect_uri=https%3A%2F%2Fwx.qq.com%2Fcgi-bin%2Fmmwebwx-bin%2Fwebwxnewloginpage&fun=new&lang=zh_CN",
            validate_cert=False
        )
    )
    print(res)
    return res



# Generated at 2022-06-22 04:19:49.104786
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    h = HTTPStreamClosedError('message')
    assert h.__str__() == 'message' or h.__str__() == 'Stream closed'



# Generated at 2022-06-22 04:20:00.646894
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import pytest
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import urllib.parse
    import types
    import os
    import sys

    # should be replaced with test context or something
    import http.client
    import ssl
    import warnings
    import urllib.parse

    class SimpleCookie(dict):
        """A dict subclass for storing a key=value cookie."""

        def __init__(self, name=None, value=None, **kwargs):
            super().__init__(**kwargs)
            if name is not None:
                self[name] = value


# Generated at 2022-06-22 04:21:23.458070
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # <SKIP>
    pass
    
    
    

# Generated at 2022-06-22 04:21:33.025832
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert client.max_buffer_size == 104857600
    assert client.tcp_client.resolver.mapping == {}
    assert client.io_loop is None
    assert client.force_instance is False
    assert client.defaults == {}
    assert client.max_clients == 10
    assert client.max_header_size is None
    assert client.max_body_size is None
    assert client.queue == collections.deque()
    assert client.active == {}
    assert client.waiting == {}


# Definition of class _HTTPConnection

# Generated at 2022-06-22 04:21:42.827515
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    s = StreamMock()
    connection = HTTP1Connection(s.io, True, HTTP1ConnectionParameters(), None)
    client = AsyncHTTPClient(io_loop=IOLoop.current())
    request = HTTPRequest("http://example.com/foo", connect_timeout=0.1)
    response = _HTTPConnection(
        client=client,
        request=request,
        io_loop=IOLoop.current(),
        final_callback=lambda x: x,
        release_callback=lambda: None,
        max_header_size=None,
        max_body_size=None,
    )
    message = "Connection closed"
    assert_raises_message(
        HTTPStreamClosedError, message, response.on_connection_close
    )

# Generated at 2022-06-22 04:21:53.670234
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    async def test():
        global_settings = Globals()
        global_settings.user_settings = Settings(configs={})
        global_settings.trace_endpoint = None
        global_settings.record_origin = ""
        global_settings.record_transport = None
        global_settings.max_timeout = 0.0
        io_loop = IOLoop()

        # HTTPClient
        conn = HTTPConnection(
            io_loop=io_loop,
            max_header_size=32,
            max_body_size=10000,
            # allow_nonstandard_methods=False,
            # decompress_response=False,
        )


# Generated at 2022-06-22 04:22:02.360958
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import HTTPRequest, HTTPResponse, AsyncHTTPClient

    class MyHTTPClient(AsyncHTTPClient):
        def __init__(self, io_loop=None, **kwargs) -> None:
            super().__init__(io_loop=io_loop, **kwargs)

        def fetch_impl(
            self, request: HTTPRequest, callback: Callable[[HTTPResponse], None]
        ) -> None:
            raise NotImplementedError()

    io_loop = asyncio.get_event_loop()
    client = MyHTTPClient(io_loop=io_loop)
    stream = unittest.mock.Mock()
    stream.closed = False
    stream.error = None
    first_line = htt

# Generated at 2022-06-22 04:22:03.098742
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    pass



# Generated at 2022-06-22 04:22:06.183194
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    """Unit test for method run of class _HTTPConnection"""
    raise unittest.SkipTest("Test not implemented")



# Generated at 2022-06-22 04:22:08.700377
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    """Test case for 'SimpleAsyncHTTPClient.initialize'
    """
    # Test all variations
    pass # TODO: implement your test here



# Generated at 2022-06-22 04:22:15.652336
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():

    # Pass
    first_line = httputil.ResponseStartLine(b"200 OK", b"HTTP/1.1")
    headers = httputil.HTTPHeaders()
    assert isinstance(first_line, httputil.ResponseStartLine)
    assert isinstance(headers, httputil.HTTPHeaders)

    # Pass
    first_line = httputil.RequestStartLine(b"GET", b"/", b"HTTP/1.1")
    headers = httputil.HTTPHeaders()
    assert isinstance(first_line, httputil.RequestStartLine)
    assert isinstance(headers, httputil.HTTPHeaders)

    # Pass
    first_line = httputil.RequestStartLine(b"GET", b"/", b"HTTP/1.1")
    headers = httputil.HTTP

# Generated at 2022-06-22 04:22:16.864535
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():

    self = SimpleAsyncHTTPClient()

    self.close()

    return

# Generated at 2022-06-22 04:26:32.810230
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.httpclient import HTTPClient, Response
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPRequest
    from tornado.httpclient import HTTPError
    from tornado.testing import AsyncHTTPTestCase, ExpectLog
    from tornado.web import Application, RequestHandler
    io_loop = AsyncIOMainLoop()
    io_loop.make_current()
    app = Application([])
    io_loop._init_logging()
    io_loop.set_blocking_log_threshold(0.5)

# Generated at 2022-06-22 04:26:38.230235
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    #Test with uninitialized object
    exc = HTTPStreamClosedError()
    assert 'HTTPStreamClosedError' in str(exc)
    assert 'Stream closed' in str(exc)

    #Test with initialized object
    exc = HTTPStreamClosedError(message='hello')
    assert 'HTTPStreamClosedError' in str(exc)
    assert 'hello' in str(exc)
    assert 'Stream closed' not in str(exc)


# Generated at 2022-06-22 04:26:40.292158
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    obj = SimpleAsyncHTTPClient()
    assert isinstance(obj, SimpleAsyncHTTPClient)



# Generated at 2022-06-22 04:26:43.504406
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _HTTPConnection(None, None, None, None, None)
    _HTTPConnection(None, None, None, None, None, True)


# Generated at 2022-06-22 04:26:44.484411
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass



# Generated at 2022-06-22 04:26:48.287067
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    http_client._HTTPConnection.__init__ = _HTTPConnection__init__
    http_client._HTTPConnection.__init__(None, client, request)
    http_client._HTTPConnection.data_received(None, b'dummy_chunk')
    assert http_client._HTTPConnection.chunks == [b'dummy_chunk']
