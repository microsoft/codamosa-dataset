

# Generated at 2022-06-22 04:17:31.113813
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    msg = "test"
    e = HTTPTimeoutError(msg)
    assert e.code == 599
    assert str(e) == msg

# Fake socket object with a few methods stubbed out.  Used to test
# the error-handling behavior of AsyncHTTPClient without having to
# actually connect to a server, or force the timeout to expire.

# Generated at 2022-06-22 04:17:33.716883
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("!")
    except HTTPTimeoutError as e:
        assert e.status_code == 599
        assert e.message == "!"
        assert str(e) == "!"

_DEFAULT_CA_CERTS = None



# Generated at 2022-06-22 04:17:38.814440
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():# Unit test for method finish of class _HTTPConnection
    request = SimpleRequest("/", method="POST")
    callback_called = False

    def callback(response):
        nonlocal callback_called
        assert response.code == 303
        assert response.headers
        assert response.body is None
        callback_called = True

    connection = _HTTPConnection(SimpleAsyncHTTPClient(), request, callback)
    connection.start_time = time.time()
    connection.start_wall_time = time.time()
    connection.chunks = []
    connection.final_callback = callback
    connection.headers = httputil.HTTPHeaders()
    connection.headers["Location"] = "/foo"
    connection.code = 303
    connection.reason = "See Other"
    assert connection.final_callback
    connection.finish()
    assert callback_called




# Generated at 2022-06-22 04:17:44.310024
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    print("Test for SimpleAsyncHTTPClient.initialize")
    max_clients = 10
    hostname_mapping = {'www.baidu.com':'123.125.114.144', 'www.sogou.com':'123.125.114.144'}
    max_buffer_size = 104857600
    resolver = Resolver()
    defaults = {'ssl_options':_client_ssl_defaults}
    max_header_size = 100*1024*1024
    max_body_size = 100*1024*1024
    SimpleAsyncHTTPClient.initialize(max_clients, 
                                    hostname_mapping, 
                                    max_buffer_size, 
                                    resolver, 
                                    defaults,
                                    max_header_size,
                                    max_body_size)




# Generated at 2022-06-22 04:17:45.596596
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("Timeout")
    assert e.args == (599, "Timeout")
    assert str(e) == "Timeout"



# Generated at 2022-06-22 04:17:46.307945
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    pass #TODO


# Generated at 2022-06-22 04:17:52.683720
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
	from tornado.httpclient import HTTPStreamClosedError

	# setup
	message = str()
	http_stream_closed_error = HTTPStreamClosedError(message)
	excepted = str()
	# go

	actual = http_stream_closed_error.__str__()
	assert actual == excepted



# Generated at 2022-06-22 04:17:54.732044
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    stream_closed_error = HTTPStreamClosedError("Stream Closed")
    assert str(stream_closed_error) == "Stream Closed"


# Generated at 2022-06-22 04:18:03.540177
# Unit test for constructor of class _HTTPConnection

# Generated at 2022-06-22 04:18:11.587588
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    try:
        # Object instance of class SimpleAsyncHTTPClient
        self_instance = simpleasynchttpclient.SimpleAsyncHTTPClient()

        # Call method close with arguments of self_instance
        self_instance.close()

        # Assertion success
        print("Assertion success")
    except AssertionError:
        # Assertion failure
        print("Assertion failure")
    # Exception has occurred
    except:
        # Print error message
        print(sys.exc_info()[1])


# Generated at 2022-06-22 04:18:52.285171
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    import unittest
    from types import TracebackType
    from typing import Optional, Type

    class TestSimpleAsyncHTTPClient(unittest.TestCase):
        def test_SimpleAsyncHTTPClient(self) -> None:
            max_clients = 5
            hostname_mapping = {"a.example.com": "1.2.3.4", "b.example.com": "::1"}
            max_buffer_size = 100
            # OverrideResolver return a resolver object
            resolver = OverrideResolver(mapping=hostname_mapping)
            # SimpleAsyncHTTPClient constructor method

# Generated at 2022-06-22 04:18:52.925649
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # TODO
    pass

# Generated at 2022-06-22 04:18:56.817280
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    ex = HTTPStreamClosedError(message="message")
    ex.message = "message"
    assert ex.__str__() == "message"
    ex.message = None
    assert ex.__str__() == "Stream closed"



# Generated at 2022-06-22 04:19:07.168956
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient(resolver=None, max_clients=10,
                    hostname_mapping=None, max_buffer_size=104857600,
                    defaults=None, max_header_size=None, max_body_size=None)
    client.initialize(hostname_mapping=None, max_clients=10,
                      max_buffer_size=104857600, resolver=None,
                      defaults=None, max_header_size=None, max_body_size=None)
    client.close()
    client.fetch_impl(request=HTTPRequest(url='http://www.baidu.com/'), callback=lambda x: None)
    client._process_queue()
    client._connection_class()

# Generated at 2022-06-22 04:19:10.533388
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # __str__ -> str
    assert isinstance(HTTPStreamClosedError(message=None).__str__(), str)

# Generated at 2022-06-22 04:19:18.062666
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    http_client = AsyncHTTPClient()
    # get the method object
    obj = http_client._HTTPConnection(
        httpclient.HTTPRequest(url="http://www.google.com"),
        functools.partial(http_client._on_proxy_response, None),
        http_client.io_loop,
    )
    func = obj.run
    # There's no api to set the attribute on the instance yet.
    #obj.key = value
    # call the method
    func()


# Generated at 2022-06-22 04:19:19.678173
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient(io_loop = IOLoop.current())
    client.close()



# Generated at 2022-06-22 04:19:22.815010
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    request = HTTPRequest('https://www.baidu.com')
    ret_val = SimpleAsyncHTTPClient().fetch_impl(request, None)
    assert ret_val is None


# Generated at 2022-06-22 04:19:28.824290
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():

    # Test result
    result_fut: Future[str] = Future()

    async def test_func():
        # Test
        error = HTTPTimeoutError("Timeout")

        # Test assertion
        result_fut.set_result(error.__str__())

    asyncio.ensure_future(test_func())

    return result_fut



# Generated at 2022-06-22 04:19:30.443957
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass

# Generated at 2022-06-22 04:20:08.835855
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    err = HTTPTimeoutError('Test message')
    assert err.code == 599
    assert str(err) == 'Test message'
    err = HTTPTimeoutError('')
    assert err.code == 599
    assert str(err) == 'Timeout'


# Generated at 2022-06-22 04:20:10.092645
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    HTTPTimeoutError('xyz').__str__()


# Generated at 2022-06-22 04:20:22.645781
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    import sys
    import pytest
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    import aiomysql
    import tornado.ioloop
    from tornado.concurrent import Future
    import tornado.stack_context
    import tornado.iostream

    from tornado.httpclient import AsyncHTTPClient

    from . import server
    from . import test_utils

    from tornado.httpclient import HTTPClient, main

    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPTimeoutError

    from _pytest.monkeypatch import monkeypatch

    from tornado.util import _unicode
    from tornado.iostream import IOStream

   

# Generated at 2022-06-22 04:20:29.845746
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():

    # Test 1: test constructor of class HTTPStreamClosedError with None as the param
    try:
        # Raises AttributeError as the param is None
        e = HTTPStreamClosedError(None)
        assert(False)
    except AttributeError as e:
        assert(True)

    # Test 2: test constructor of class HTTPStreamClosedError with empty string as the param
    try:
        e = HTTPStreamClosedError('')
        assert(False)
    except AttributeError as e:
        assert(True)

    # Test 3: test constructor of class HTTPStreamClosedError with valid string as the param
    try:
        e = HTTPStreamClosedError('test')
        assert(True)
    except AttributeError as e:
        assert(False)


# Generated at 2022-06-22 04:20:33.489756
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass


_VALID_SOURCE_ADDRESS = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")



# Generated at 2022-06-22 04:20:42.741577
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def test_basics():
        async def f():
            responses = []

            def handle_response(response):
                if isinstance(response, HTTPResponse):
                    responses.append(response)
                else:
                    responses.append(response)

            # Create the server so we know what port it's listening on
            server = HTTPServer()
            server.listen(0)
            self.io_loop.add_callback(server.stop)
            self.wait()

            client = HTTPClient()

            # First request to the server, it should return the
            # requested path in the response.

# Generated at 2022-06-22 04:20:44.703290
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    test_obj = HTTPStreamClosedError("")
    result = test_obj.__str__()

    assert result == "Stream closed"



# Generated at 2022-06-22 04:20:49.025308
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import tornado
    import tornado.gen
    httpclient = tornado.httpclient.AsyncHTTPClient()
    @tornado.gen.coroutine
    def main():
        response = yield httpclient.fetch("http://www.w3schools.com")
        print(response.body)

    tornado.ioloop.IOLoop.current().run_sync(main)

# Generated at 2022-06-22 04:20:50.088643
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Line 378
    assert True



# Generated at 2022-06-22 04:21:00.422371
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    print("Test _HTTPConnection")
    stream = IOStream(socket.socket())
    url = "https://www.google.com"
    request = HTTPRequest(url)
    client = HTTPClient()
    host, port = httputil._split_host_and_port(url, 443)
    connection = _HTTPConnection(
        request, sockaddr=(host, port), stream=stream, client=client
    )
    assert connection.port == 443
    assert connection.scheme == "https"
    assert connection.sockaddr == (host, port)
    assert connection.start_time is not None



# Generated at 2022-06-22 04:21:39.701544
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # simple_async_httpclient_test.py
    # test_method__str__for_HTTPStreamClosedError(self):
    # self.assertEqual(HTTPStreamClosedError().__str__(), 'Stream closed')
    # self.assertTrue(HTTPStreamClosedError('foo').__str__(), 'foo')
    assert HTTPStreamClosedError().__str__() == 'Stream closed'
    assert HTTPStreamClosedError('foo').__str__() == 'foo'



# Generated at 2022-06-22 04:21:41.130712
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # TODO: use mock
    raise NotImplementedError()

# Generated at 2022-06-22 04:21:51.921076
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """ Unit test for method headers_received of class _HTTPConnection """

    # Create an HTTPConnection instance and set its io_loop to
    # current io_loop
    http_connection = _HTTPConnection(
        None,
        None,
        Version(5, 0, 32224),
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        True,
    )
    http_connection.io_loop = IOLoop.current()

    # Create an HTTPRequest object
    request = HTTPRequest("http://localhost:8888")

    # Create an HTTP1ConnectionParameters
    max_header_size = 65536
    max_body_size = 1048576
    decompress = True

# Generated at 2022-06-22 04:21:53.970215
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    _HTTPConnection = HTTP1Connection

# Generated at 2022-06-22 04:22:00.327384
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """
    Tests for _HTTPConnection.headers_received
    """
    from tornado.httputil import HTTPHeaders

    res = _HTTPConnection()

    req = _RequestProxy()
    res.request = req

    first_line = {'protocol': 'HTTP', 'version': '2.0', 'code': 200}
    headers = HTTPHeaders()
    headers['Content-Type'] = 'text/html'

    res.headers_received(first_line, headers)

    assert True

# Generated at 2022-06-22 04:22:12.251709
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient

# Generated at 2022-06-22 04:22:16.241090
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    client.initialize()
    client.close()


# Generated at 2022-06-22 04:22:19.555006
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    request = HTTPRequest("www.github.com")
    _HTTPConnection(request, 3005, "127.0.0.1", "https", 3005)

# Generated at 2022-06-22 04:22:31.379065
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():

    asyncio.set_event_loop(None)
    io_loop = IOLoop()
    io_loop.make_current()


# Generated at 2022-06-22 04:22:37.482387
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import tornado.testing
    import tornado.web

    class RequestHandler(tornado.web.RequestHandler):
        def initialize(self, response):
            self.response = response

        def get(self):
            self.write(self.response)

    app = tornado.web.Application([(r"/", RequestHandler, dict(response="hello"))])
    with tornado.testing.AsyncHTTPClient(app) as client:
        request = HTTPRequest("http://127.0.0.1:%s/" % app.port)
        response = client.fetch(request)
        print(response.result())

if __name__ == "__main__":
    test__HTTPConnection()

# Generated at 2022-06-22 04:25:20.108066
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    conn = _HTTPConnection('request', 'io_loop', 'final_callback')
    conn.stream = 'stream'
    conn.parsed = namedtuple('parsed', 'host port path query scheme')
    conn.parsed.host = 'host'
    conn.parsed.port = 'port'
    conn.parsed.path = 'path'
    conn.parsed.query = 'query'
    conn.parsed.scheme = 'scheme'
    conn.client = namedtuple('client', '_HTTPConnection connection_pool')
    conn.client._HTTPConnection = namedtuple(
        '_HTTPConnection', 'host key certificate cert_reqs ssl_options')
    conn.client._HTTPConnection.host = 'host'
    conn.client._HTTPConnection.key = 'key'

# Generated at 2022-06-22 04:25:29.415521
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():

    # __init__() can be called as classmethod or instance method.
    SimpleAsyncHTTPClient  # type: Type[SimpleAsyncHTTPClient]

    # Instance method.
    http_client = SimpleAsyncHTTPClient()
    assert http_client.max_clients == 10
    assert http_client.queue == collections.deque()
    assert http_client.active == {}
    assert http_client.waiting == {}
    assert http_client.max_buffer_size == 104857600
    assert http_client.max_clients == 10
    assert http_client.max_header_size is None
    assert http_client.max_body_size is None
    assert isinstance(http_client.resolver, Resolver)
    assert http_client.own_resolver

# Generated at 2022-06-22 04:25:34.133156
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    assert HTTPTimeoutError("foo").message == "foo"
    assert HTTPTimeoutError("foo").code == 599
    assert HTTPTimeoutError("foo").response is None



# Generated at 2022-06-22 04:25:36.894132
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    err = HTTPTimeoutError('test')
    assert err.status_code == 599
    assert err.message == 'test'
    assert str(err) == 'test'



# Generated at 2022-06-22 04:25:41.825897
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    """Unit test for method fetch_impl of class SimpleAsyncHTTPClient"""
    request = tornado.httpclient.HTTPRequest("127.0.0.1")
    callback = lambda x: None
    client = SimpleAsyncHTTPClient()
    client.initialize(max_clients=1000)
    client.fetch_impl(request, callback)



# Generated at 2022-06-22 04:25:47.232939
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    err = HTTPTimeoutError("some message")
    # Error code 599 is used for timeout
    assert err.code == 599
    # str(err) returns error message or "Timeout" if no message set
    assert str(err) in ("some message", "Timeout")


# Generated at 2022-06-22 04:25:56.596004
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    class dummy_HTTP1Connection(object):
        def __init__(self, *args, **kwargs):
            pass
        def write_headers(self, *args, **kwargs) -> None:
            pass
        def read_response(self, *args, **kwargs) -> None:
            pass
    stream = object()
    request = object()
    headers = object()
    chunks = [object()]
    data = b"".join(chunks)
    class dummy_HTTPResponse(object):
        def __init__(
            self,
            request, code, reason=None, headers=None, request_time=None,
            start_time=None, buffer=None, effective_url=None
        ):
            pass


# Generated at 2022-06-22 04:26:03.174711
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    from tornado.testing import AsyncHTTPTestCase

    class _HTTPConnectionTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application()

    example_com = "http://www.example.com/"
    _httpConnectionTest = _HTTPConnectionTest()
    try:
        _httpConnectionTest.fetch(example_com)
    except:
        pass
    finally:
        _httpConnectionTest.stop()


# Generated at 2022-06-22 04:26:04.350293
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert str(HTTPTimeoutError("Timeout")) == "Timeout"


# Generated at 2022-06-22 04:26:06.266872
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError('Stream closed')
    except HTTPStreamClosedError as e:
        assert e.code == 599



# Generated at 2022-06-22 04:26:35.462251
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    io_loop = IOLoop()
    conn = _HTTPConnection(
        io_loop=io_loop,
        request=object(),
        parsed=object(),
        max_header_size=object(),
        max_body_size=object(),
        release_callback=object(),
        final_callback=object(),
    )

# Generated at 2022-06-22 04:26:39.388759
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    r = HTTPStreamClosedError("This is a HTTPStreamClosedError")
    assert r.__str__()=="This is a HTTPStreamClosedError"

# Generated at 2022-06-22 04:26:46.250079
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import time
    from tornado.httpclient import HTTPRequest, HTTPResponse
    httpclient = SimpleAsyncHTTPClient()
    def callback(response: HTTPResponse) -> None:
        print(response)
        httpclient.stop()

    httpclient.fetch_impl(
            HTTPRequest('http://www.baidu.com', method='GET',
                        request_timeout=20, connect_timeout=20),
            callback=callback
    )
    httpclient.start()
