

# Generated at 2022-06-22 04:17:51.861011
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Create an instance of the class
    httpclient = SimpleAsyncHTTPClient()
    # Class method of the class
    HTTPRequest()
    # Create an instance of the class
    httpresponse = HTTPResponse()
    # Create function definition
    def callback(param):
        return param
    # Call instance method
    httpclient.fetch_impl(httpresponse, callback)


if sys.version_info >= (3, 5):
    from typing import AsyncGenerator, AsyncIterator  # noqa: F401
    from tornado.httpclient import HTTPRequest  # noqa: F401


# It's hard to get the typing right for these async methods since
# they don't return the exact type returned by the wrapped Python
# method.
AsyncGenerator = typing.AsyncGenerator
AsyncIterator = typing.AsyncIterator



# Generated at 2022-06-22 04:17:55.085523
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    stream = dummy_stream()
    client = HTTPClient()
    stream.close()
    response = _HTTPConnection(client, client.io_loop, client._fetch_impl, dummy_req)
    result = response.on_connection_close()

# Generated at 2022-06-22 04:17:57.156963
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    error = HTTPStreamClosedError(message="")
    s = error.__str__()
    assert (s == "Stream closed")



# Generated at 2022-06-22 04:18:03.328691
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    strm = None
    with _HTTPConnection(strm) as _hc:
        # Should raise an exception when given wrong parameters.
        try:
            _hc.data_received()
        except TypeError:
            assert True
        else:
            assert False
        try:
            _hc.data_received(chunk=None)
        except TypeError:
            assert True
        else:
            assert False
        # Should run without exception
        _hc.data_received(chunk=b'')


# Generated at 2022-06-22 04:18:05.609871
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Implicitly tested by test_HTTPError
    pass



# Generated at 2022-06-22 04:18:11.883288
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    async def test(i: int) -> None:
        client = SimpleAsyncHTTPClient()
        assert isinstance(client, AsyncHTTPClient)
        client.close()
        assert client.tcp_client == None
        if i == 0:
            raise gen.Return(None)
    ioloop = IOLoop()
    ioloop.run_sync(functools.partial(test, 0))
    ioloop.close()


# Generated at 2022-06-22 04:18:18.997803
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Should raise the error
    connection = _HTTPConnection(None, None, None, None, None, None, None)
    connection.stream = StreamClosedError()
    connection.stream.error = HTTPTimeoutError("Timeout")
    connection.final_callback = Mock()
    connection.on_connection_close()
    assert connection.final_callback.call_count == 1

    # Should not raise the error
    connection = _HTTPConnection(None, None, None, None, None, None, None)
    connection.final_callback = None
    connection.stream.error = HTTPTimeoutError("Timeout")
    connection.on_connection_close()
    assert connection.stream.error.args == ("Timeout",)

    # Should not raise the error
    connection = _HTTPConnection(None, None, None, None, None, None, None)

# Generated at 2022-06-22 04:18:21.974313
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    with pytest.raises(HTTPTimeoutError) as excinfo:
        raise HTTPTimeoutError("Timeout")
    assert str(excinfo.value) == "Timeout"


# Generated at 2022-06-22 04:18:23.102598
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert HTTPStreamClosedError("").__str__() == ""



# Generated at 2022-06-22 04:18:26.987007
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    obj = _HTTPConnection()
    obj.run()
    pass

# Generated at 2022-06-22 04:20:00.499562
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # NOTE: This unit test is not comprehensive
    client = SimpleAsyncHTTPClient(io_loop=IOLoop.current())
    request = HTTPRequest("/")
    chunks = [] # type: List[bytes]
    request.streaming_callback = lambda chunk: chunks.append(chunk)
    conn = _HTTPConnection(client, request, client._make_fetch_future(request),
                           client._prepare_request(request),
                           client._parse_url(request.url))
    conn.data_received(b"data")
    assert chunks == [b"data"]
    conn.data_received(b"more data")
    assert chunks == [b"data", b"more data"]

# Generated at 2022-06-22 04:20:02.693363
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    c = _HTTPConnection()
    c.on_connection_close()



# Generated at 2022-06-22 04:20:11.786335
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado.options import define, options, parse_command_line

    define("test", type=str)
    define("port", type=int)

    import requests

    url = "http://localhost:8765"

    @gen.coroutine
    def f():
        params = {"arg": "value"}
        response = yield AsyncHTTPClient().fetch(url, method="POST", body=params)
        print(response.body)
        return response

    parse_command_line(args=["--test=aaa"])
    if options.test:
        print(options.test)
    print(options.port)

    # IOLoop().run_sync(f)
    print(f())



# Generated at 2022-06-22 04:20:16.961943
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    http_client = SimpleAsyncHTTPClient()
    assert isinstance(http_client, SimpleAsyncHTTPClient)
    assert repr(http_client) == "<SimpleAsyncHTTPClient>"



# Generated at 2022-06-22 04:20:19.011132
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    HTTPStreamClosedError("Stream closed")


# Generated at 2022-06-22 04:20:27.448762
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    """Test for method run of class _HTTPConnection"""
    if sys.version_info >= (3, 8) and not (await tornado.platform.asyncio.AsyncIOMainLoop().is_running()):
        pytest.skip("asyncio event loop incompatible with Python < 3.8")
    stream = _FakeIOStream()
    request = HTTPRequest("https://example.com", method="POST", body="hello")
    client = _HTTPClient(HTTPRequest("https://example.com"))
    conn = _HTTPConnection(client, request)
    with pytest.raises(HTTPTimeoutError):
        await conn._run(stream)

# Generated at 2022-06-22 04:20:35.152506
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.escape import native_str
    from tornado.netutil import Resolver, OverrideResolver, _client_ssl_defaults
    from tornado.tcpclient import TCPClient
    from typing import Any, Dict, Optional, Union

    max_clients: int = 10
    hostname_mapping: Optional[Dict[str, str]] = None
    max_buffer_size: int = 104857600
    resolver: Optional[Resolver] = None
    defaults: Optional[Dict[str, Any]] = None
    max_header_size: Optional[int] = None
    max_body_size: Optional[int] = None

    # Type check: (int, Optional[Dict[str, str]], int, Optional[Resolver], Optional[Dict[str, Any]], Optional[int], Optional[int]) ->

# Generated at 2022-06-22 04:20:36.044152
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    pass



# Generated at 2022-06-22 04:20:37.492541
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass # TODO

test__HTTPConnection_on_connection_close()

# Generated at 2022-06-22 04:20:39.953422
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    """Unit test for method __str__ of class HTTPTimeoutError"""
    #TODO: Needs implementing!!!
    pass



# Generated at 2022-06-22 04:21:17.686408
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    exc = HTTPStreamClosedError("Stream closed")
    assert exc.code == 599
    assert str(exc) == "Stream closed"



# Generated at 2022-06-22 04:21:22.279592
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    """
    test function for method __str__ of class HTTPStreamClosedError
    """
    error = HTTPStreamClosedError("Failed to get response")
    assert error.__str__() == "Stream closed"

    error = HTTPStreamClosedError("")
    assert error.__str__() == "Stream closed"


# Generated at 2022-06-22 04:21:23.408222
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection.run()


# Generated at 2022-06-22 04:21:28.780546
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("boom")
    except HTTPTimeoutError:
        pass

    try:
        raise HTTPTimeoutError("boom")
    except HTTPError as e:
        assert str(e) == "boom"



# Generated at 2022-06-22 04:21:32.860193
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    def callback(response):
        print(response)
    http = SimpleAsyncHTTPClient(io_loop=IOLoop(), max_clients=1)
    http.fetch(HTTPRequest("http://www.baidu.com"), callback=callback)
    # IOLoop.instance().start()


# Generated at 2022-06-22 04:21:36.063443
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # SimpleAsyncHTTPClient().fetch_impl()
    # TODO: (Aurelien) Please, implement this unit test
    assert False == True



# Generated at 2022-06-22 04:21:37.633928
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-22 04:21:44.739109
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    async def main():
        request = HTTPRequest("http://www.google.com/")

        proxy = {}
        config = _HTTPConnection(proxy, "http://www.google.com", request, None)

        assert config.request == request
        assert config.proxy == proxy
        assert config.netloc == "www.google.com:80"
        assert config.path == "/"
        assert config.parsed == urllib.parse.urlsplit("http://www.google.com/")

    event_loop = asyncio.get_event_loop()
    event_loop.run_until_complete(main())

# Generated at 2022-06-22 04:21:46.440549
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    message = "Stream closed"
    exc = HTTPStreamClosedError(message)
    assert exc.__str__() == message



# Generated at 2022-06-22 04:21:47.204961
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    obj = HTTPTimeoutError(message)
    pass


# Generated at 2022-06-22 04:22:43.959979
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Skip test on windows, not relevant
    if sys.platform == 'win32':
        raise unittest.SkipTest('simple_httpclient is not supported on windows')

    http_client = SimpleAsyncHTTPClient()
    assert http_client.max_clients == 10
    assert http_client.queue == collections.deque([])
    assert http_client.active == {}
    assert http_client.waiting == {}
    assert http_client.max_buffer_size == 104857600
    assert http_client.max_header_size == None
    assert http_client.max_body_size == None

    # Test the case where the given max_buffer_size is a negative number
    http_client = SimpleAsyncHTTPClient(max_buffer_size=-1)
    assert http_client.max_clients == 10
    assert http

# Generated at 2022-06-22 04:22:47.837400
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    t1 = HTTPTimeoutError('Timeout')
    assert t1.code == 599
    assert str(t1) == 'Timeout'



# Generated at 2022-06-22 04:22:49.588722
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass



# Generated at 2022-06-22 04:22:55.505996
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    try:
        import ssl
    except ImportError:
        ssl = None
    if ssl is None:
        return
    conn = _HTTPConnection(
        host='www.baidu.com',
        port=443,
        ssl_options=_client_ssl_defaults,
        max_body_size=None,
        max_header_size=None,
        decompress=False,
        request_timeout=None,
        connect_timeout=10,
        on_connect_callback = _on_connect_callback
    )
    conn.start()

# Generated at 2022-06-22 04:22:59.164602
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    bs = BasicStaticServer()
    bs.start()
    bs.add_page("/", "<b>Hello</b>")
    req = HTTPRequest(
        "http://127.0.0.1:%d/" % bs.get_port(),
        method="GET",
        headers={},
        connect_timeout=0.001,
        request_timeout=0.001,
    )
    httpcon = _HTTPConnection(req)
    assert isinstance(httpcon, _HTTPConnection)

# Generated at 2022-06-22 04:23:00.926675
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    client = AsyncHTTPClient()
    request = HTTPRequest('http://localhost:8000/')
    conn = _HTTPConnection(client, request, client.max_clients)
    response = conn.run()
test__HTTPConnection_run()


# Generated at 2022-06-22 04:23:05.383553
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    obj = SimpleAsyncHTTPClient()
    request = httpclient.HTTPRequest("http://www.google.com/")
    def callback(f): pass
    obj.fetch_impl(request, callback)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 04:23:09.321774
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError("Stream closed")
    except HTTPStreamClosedError as e:
        assert str(e) == "Stream closed"


# Generated at 2022-06-22 04:23:19.748251
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def echo_streaming_callback(data):
        print('echo streaming callback: {}'.format(data))
    def echo_header_callback(data):
        print('callback header: {}'.format(data))

# Generated at 2022-06-22 04:23:23.317239
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    e = HTTPStreamClosedError("bar")
    assert e.message == "bar"
    assert e.status_code == 599
    error_output = "<HTTP 599: Stream closed>"
    assert str(e) == error_output

HTTPErrorType = Optional[Type[HTTPError]]



# Generated at 2022-06-22 04:24:55.693186
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    e = HTTPTimeoutError("Timeout")
    assert str(e) == "Timeout"

test_HTTPTimeoutError_encoding = "test_HTTPTimeoutError_encoding"
if test_HTTPTimeoutError_encoding:
    def test_HTTPTimeoutError___str__():
        e = HTTPTimeoutError("Timeout".encode("utf-8"))
        assert str(e) == "Timeout"


# Generated at 2022-06-22 04:25:01.521028
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    def test_HTTPTimeoutError_constructor():
        error = HTTPTimeoutError(message="Time out")
        assert error.code == 599
        assert error.message == "Time out"
        assert str(error) == "Time out"


if version.__version__ < "6":
    # save AsyncHTTPClient._DEFAULT_MAX_CLIENT_KEY_SIZE so it can be used without
    # creating an AsyncHTTPClient instance
    _DEFAULT_MAX_CLIENT_KEY_SIZE = AsyncHTTPClient._DEFAULT_MAX_CLIENT_KEY_SIZE
    _DEFAULT_MAX_CLIENT_CERTS_SIZE = AsyncHTTPClient._DEFAULT_MAX_CLIENT_CERTS_SIZE
else:
    _DEFAULT_MAX_CLIENT_KEY_SIZE = AsyncHTTPClient.key_size
    _

# Generated at 2022-06-22 04:25:05.013341
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__(): # unit test for class HTTPStreamClosedError method __str__
    error = HTTPStreamClosedError('Stream closed')
    assert error.__str__() == "Stream closed"



# Generated at 2022-06-22 04:25:06.381109
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection_run()
# Module level function begin

# Generated at 2022-06-22 04:25:16.757142
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    print(client.max_clients)
    # 10
    print(client.queue)
    # deque([])
    print(client.active)
    # {}
    print(client.waiting)
    # {}
    print(client.max_buffer_size)
    # 104857600
    print(client.max_header_size)
    # None
    print(client.max_body_size)
    # None


# Generated at 2022-06-22 04:25:19.447832
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    e = HTTPTimeoutError('timeout')
    print(e.code)
    print(e.message)
    print(str(e))



# Generated at 2022-06-22 04:25:21.491693
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    instance = HTTPStreamClosedError()
    assert isinstance(instance.__str__(), str)


# Generated at 2022-06-22 04:25:31.737705
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("Timeout")
    except HTTPTimeoutError as e:
        assert e.code == 599
        assert str(e) == "Timeout"
        assert e.response == None

if sys.platform.startswith("linux"):
    try:
        import tornado.netutil
        import tornado.platform.caresresolver
    except ImportError:
        pass
    else:
        Resolver.configure("tornado.netutil.ThreadedResolver")
        if "tornado.caresresolver" not in Resolver.name:
            Resolver.configure(
                "tornado.platform.caresresolver.CaresResolver"
            )

__all__ = ["HTTPClient", "HTTPRequest", "HTTPError", "HTTPResponse"]

# TODO: bind to a

# Generated at 2022-06-22 04:25:33.959425
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    client.initialize()
    client.close()

# Generated at 2022-06-22 04:25:36.729585
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    error = HTTPStreamClosedError('Stream closed')
    assert error.__str__() == 'Stream closed', f'Invalid value. get={error.__str__()}'
