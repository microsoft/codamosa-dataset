

# Generated at 2022-06-22 04:17:38.144951
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    main()

# Generated at 2022-06-22 04:17:39.604586
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # args = (first_line, headers,)
    # expected = NotImplementedError
    raise NotImplementedError

# Generated at 2022-06-22 04:17:45.735069
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # _HTTPConnection_finish_test.py
    import unittest
    import asyncio
    from tornado.httpclient import AsyncHTTPClient, HTTPClientError, HTTPRequest


    class DummyConnection(object):
        def __init__(self, request):
            self.request = request


    class Response(object):
        def __init__(self):
            self.request = None
            self.code = None
            self.reason = None
            self.headers = None
            self.effective_url = None
            self.buffer = None


    class HTTPConnectionTest(unittest.TestCase):
        def get_new_ioloop(self):
            return asyncio.new_event_loop()

        def test_finish(self):
            request = HTTPRequest(url="http://example.com/foo")
           

# Generated at 2022-06-22 04:17:50.684207
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Test the case when location header is not set, it should not raise an error

    class ResponseStartLine(httputil.ResponseStartLine):
        def __init__(self):
            pass

        def __repr__(self):
            return "<ResponseStartLine>"

        def startswith(self, _):
            return True

    class RequestProxy(object):
        def __init__(self, request):
            self.request = request
        def __getattr__(self, name):
            return getattr(self.request, name)

    class Request(object):
        def __init__(self):
            self.max_redirects = 1

    class Headers(dict):
        def get(self, _):
            return None


# Generated at 2022-06-22 04:17:52.319623
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # This test is implemented in fetch_impl of class SimpleAsyncHTTPClient
    # This is a stub
    pass

# Generated at 2022-06-22 04:18:01.696389
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Make sure that _HTTPConnection.run uses the given
    # streaming_callback and final_callback
    def streaming_callback(chunk):
        s.append(chunk)

    def final_callback(response):
        f.append(response)

    req = HTTPRequest("http://localhost:9999/")

    s = []
    f = []
    conn = _HTTPConnection(
        req,
        streaming_callback,
        final_callback,
        SimpleIOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM)),
        "localhost",
        9999,
        {}
    )
    conn.chunks.append(b"chunk1")
    conn.chunks.append(b"chunk2")
    conn.code = "code"
    conn.final_callback = None
    conn

# Generated at 2022-06-22 04:18:02.912073
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # data_received is tested in test_client.py
    pass



# Generated at 2022-06-22 04:18:04.313364
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Testing method close of class SimpleAsyncHTTPClient
    pass



# Generated at 2022-06-22 04:18:16.179101
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    import tornado.testing
    import tornado.concurrent
    import tornado.escape
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import test.test_httpserver
    import unittest
    import zlib
    import io
    import socket
    import time
    import weakref
    import ssl
    import os
    import gzip
    import threading
    import asyncio
    import concurrent.futures
    import email.parser
    import email.message
    import email.policy
    import urllib.parse
    import email.utils
    import inspect
    import sys
    import random

# Generated at 2022-06-22 04:18:17.903687
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    with pytest.raises(HTTPTimeoutError):
        _HTTPConnection(None, None, None, 1, None, None, None, None, None)

# Generated at 2022-06-22 04:19:02.316138
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass

_client_ssl_defaults = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
_client_ssl_defaults.set_default_verify_paths()
_client_ssl_defaults.verify_mode = ssl.CERT_REQUIRED
_client_ssl_defaults.check_hostname = True

# Generated at 2022-06-22 04:19:05.270978
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    def test(err): err.__str__() == "Stream closed"
    err = HTTPStreamClosedError("")
    assert test(err)
    err = HTTPStreamClosedError("RandomMessage")
    assert not test(err)



# Generated at 2022-06-22 04:19:18.150612
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    def test_method(
        url: str,
        method: str,
        expected_start_line: str,
        expected_headers: Dict[str, str],
        expected_body: str,
    ) -> None:
        print("Testing AsyncHTTPClient._HTTPConnection.__init__")
        io_loop = ioloop.IOLoop.current()
        # Makes AsyncHTTPClient._HTTPConnection.__init__ callable
        _HTTPConnection._initialize()

        request = HTTPRequest(
            url,
            method=method,
            headers={"X-Header": "value"},
            auth_username="Aladdin",
            auth_password="open sesame",
            auth_mode="basic",
            body="body",
        )

# Generated at 2022-06-22 04:19:30.859796
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    class MockStream(object):
        def __init__(self, data: bytes) -> None:
            self._data = data

        def read_bytes(self, count: Optional[int] = None) -> bytes:
            if count is None:
                count = len(self._data)
            chunk = self._data[:count]
            self._data = self._data[count:]
            return chunk

    class MockHTTPClient(object):
        def __init__(self):
            self.response = ""

        def fetch(self, *args: str) -> Any:
            return self.response

    def mock_header_callback(string: str) -> None:
        print(string)

    def mock_streaming_callback(chunk: bytes) -> None:
        print(chunk)


# Generated at 2022-06-22 04:19:35.188834
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    c = _HTTPConnection(
        request=AsyncHTTPRequest("GET", "http://localhost/", connect_timeout=1),
        stream=IOStream(socket.socket()),
        release_callback=None,
        final_callback=lambda info: info,
        io_loop=IOLoop.current(),
    )
    c.on_connection_close()



# Generated at 2022-06-22 04:19:39.353165
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    t = HTTPStreamClosedError('Stream closed')
    assert repr(t).startswith("<HTTPStreamClosedError 599>")
    assert str(t) == 'Stream closed'


# Generated at 2022-06-22 04:19:40.347256
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    asyclient = SimpleAsyncHTTPClient()

# Generated at 2022-06-22 04:19:42.202908
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    return


# Generated at 2022-06-22 04:19:45.210967
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    SimpleAsyncHTTPClient(max_clients=100, max_buffer_size=100100100, max_header_size=100100100, max_body_size=100100100)
    SimpleAsyncHTTPClient(defaults={"proxy_host": "127.0.0.1"})



# Generated at 2022-06-22 04:19:58.977180
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.tcpserver import TCPServer
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port, gen_test
    from tornado.test.util import unittest

    class DummyConnection(object):
        def __init__(self) -> None:
            self.stream = IOStream(socket.socket(), io_loop=IOLoop.current())
            self.stream.set_close_callback(self.on_connection_close)

        def on_connection_close(self) -> None:
            pass

    class _HTTPConnectionTest(unittest.TestCase):
        def setUp(self) -> None:
            self.io_loop = IOLoop()
            self

# Generated at 2022-06-22 04:20:43.783067
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():

    # parameters
    request = HTTPRequest(None)
    callback = lambda http_response: None

    # test
    client = SimpleAsyncHTTPClient(1)
    client.fetch_impl(request, callback)
    # end test


# Generated at 2022-06-22 04:20:52.291404
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def coro(self):
        if self.request.connect_timeout:
            timeout = (
                self.start_time
                + self.request.connect_timeout
                - self.io_loop.time()
            )
            if timeout < 0:
                self._timeout = None
                raise HTTPTimeoutError("Connection timed out")
            else:
                self._timeout = self.io_loop.add_timeout(
                    self.start_time + self.request.connect_timeout,
                    functools.partial(self._on_timeout, "while connecting"),
                )
        if self.request.request_timeout:
            timeout = (
                self.start_time
                + self.request.request_timeout
                - self.io_loop.time()
            )
            if timeout < 0:
                self._timeout = None
               

# Generated at 2022-06-22 04:20:57.681994
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from tornado.testing import gen_test, AsyncHTTPTestCase
    from tornado.testing import AsyncTestCase

    from tornado.web import RequestHandler
    import tornado.web
    import logging
    import sys
    import tracemalloc
    from functools import partial

    import tornado.httpclient
    import tornado.httputil
    import tornado.web

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    class HelloApplication(tornado.web.Application):
        def __init__(self):
            handlers = [
                (r"/", MainHandler),
            ]
            super(HelloApplication, self).__init__(handlers)


# Generated at 2022-06-22 04:21:08.515872
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    pass

_DEFAULT_SUPPORTED_METHODS = ("GET", "HEAD", "POST", "PUT", "DELETE", "PATCH")
_SUPPORTED_METHODS_HEADER = "Accept, Cache-Control, Connection, Content-Length, Content-MD5, Content-Type, Date, Expect, From, If-Match, If-Modified-Since, If-None-Match, If-Range, If-Unmodified-Since, Max-Forwards, Pragma, Proxy-Authorization, Range, TE, Trailer, Transfer-Encoding, Upgrade, User-Agent, Via"
_SUPPORTED_METHODS = set(_DEFAULT_SUPPORTED_METHODS)
_METHODS_WITH_BODY = set(("POST", "PATCH", "PUT"))

# Generated at 2022-06-22 04:21:14.764943
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    req = httpclient.HTTPRequest('www.google.com', method='GET')
    client = httpclient.AsyncHTTPClient()
    # Create an instance of _HTTPConnection class
    obj = httpclient._HTTPConnection(client, req, False, 5, 10)
    result = obj.data_received(b'chunk')
    assert result is None


# Generated at 2022-06-22 04:21:22.405408
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    url = "http://www.google.com/"
    req = HTTPRequest(url)
    f = _HTTPConnection(req, SimpleAsyncHTTPClient(), "127.0.0.1", 80, io_loop=IOLoop())
    # f.headers is not of type httputil.HTTPHeaders
    assert f.headers is None
    f.finish()
    # f.headers is of type httputil.HTTPHeaders
    assert isinstance(f.headers, httputil.HTTPHeaders)



# Generated at 2022-06-22 04:21:30.574721
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError("Test error")
    except HTTPStreamClosedError as e:
        assert(e.code == 599)
        assert(e.message == "Test error")
        assert(e.__str__() == "Test error")


ft = typing.ForwardRef("Future[HTTPResponse]")
ResponseFuture = typing.TypeVar("ResponseFuture", bound=ft)
Request = Union[HTTPRequest, str]



# Generated at 2022-06-22 04:21:32.526772
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    _HTTPConnection(None, None, None, None, None).data_received(None)



# Generated at 2022-06-22 04:21:37.620692
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from tornado.httpclient import HTTPRequest
    import tornado.ioloop
    request = HTTPRequest('http://example.com/')
    connection = _HTTPConnection(request, None)
    connection.io_loop = tornado.ioloop.IOLoop.current()
    with pytest.raises(tornado.httpclient.HTTPError) as excinfo:
        connection.run()
    assert "You must use AsyncHTTPClient to fetch this URL: example.com" in str(excinfo.value)

# Generated at 2022-06-22 04:21:46.100481
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    m = Mock()
    def mock_data_received(chunk):
        return m(chunk)
    with patch("tornado.httpclient.HTTPClient._HTTPConnection._should_follow_redirect", side_effect=["False", "True"]):
        with patch("tornado.httpclient.HTTPClient._HTTPConnection.request.streaming_callback", side_effect=[mock_data_received, "None"]):
            hc = HTTPClient._HTTPConnection("request", HTTP1Connection("stream", True, "params", "sockaddr"), "sockaddr", ["chunks"])
            hc.data_received("chunk")
            hc.data_received("chunk2")
    assert m.call_args == call("chunk")
