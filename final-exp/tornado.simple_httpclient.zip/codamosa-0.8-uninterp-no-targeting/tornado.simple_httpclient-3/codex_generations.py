

# Generated at 2022-06-22 04:17:56.737054
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    def test():
        e = HTTPStreamClosedError("")
        assert str(e) == "Stream closed"



# Generated at 2022-06-22 04:18:05.607155
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    """Test for method finish of class _HTTPConnection"""
    httpclient = HTTPClient()
    request = HTTPRequest("http://example.com")
    connection = httpclient._create_connection(IOStream(socket.socket(), None))
    connection._http_client = httpclient
    connection._request = request
    chunks = []
    def assert_chunks(chunk):
        chunks.append(chunk)

    httpclient.fetch(request, _RequestProxy(request=request, httpclient=httpclient))
    connection.chunks = [b'data']
    connection.request = _RequestProxy(request=request, httpclient=httpclient)
    connection.code = 200
    connection.httpclient = httpclient

# Generated at 2022-06-22 04:18:10.101765
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    import six
    import string
    assert isinstance(HTTPResponse.__str__(HTTPTimeoutError('')), six.string_types)
    assert isinstance(HTTPResponse.__str__(HTTPTimeoutError('a')), six.string_types)

# Generated at 2022-06-22 04:18:15.545456
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    from tornado.httpclient import HTTPStreamClosedError
    from tornado import testing
    import unittest

    class HTTPStreamClosedErrorTest(testing.AsyncTestCase):
        def test___str__(self):
            self.assertEqual(
                str(HTTPStreamClosedError("Stream closed")),
                "Stream closed",
            )
    unittest.main()

# Generated at 2022-06-22 04:18:16.112096
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-22 04:18:25.067125
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    test_client = SimpleAsyncHTTPClient()
    proxy_test_url = 'http://www.linkedin.com/'


# Generated at 2022-06-22 04:18:28.160887
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
  pass

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 04:18:36.166389
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    global application
    global HTTPClient
    global HTTPStreamClosedError
    global HTTPTimeoutError
    global HTTPResponse
    global IOLoop
    global IOStream
    global URLError
    global URLSpec
    global _HTTPConnection
    global _RequestProxy
    global _UrlRequest
    global argument_tuple
    global httputil
    global httputil_HTTPServerConnectionDelegate
    global httputil_HTTPServerRequest
    global httputil_HTTPServerResponse
    global httputil_HTTPHeaders
    global httputil_HTTPOutputError
    global httputil_HTTPMessageDelegate
    global httputil_HTTPRequest
    global httputil_HTTPResponse
    global httputil_HTTPResponseStartLine
    global httputil_HTTPServerConnection


# Generated at 2022-06-22 04:18:36.646470
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-22 04:18:49.199778
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    exc = HTTPStreamClosedError('Stream closed')
    assert exc.code == 599
    assert exc.message == 'Stream closed'


# Generated at 2022-06-22 04:20:01.846653
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = httputil.ResponseStartLine('test_code', 'test_reason', 'test_version')
    headers = httputil.HTTPHeaders()
    _NODELETE = 1

# Generated at 2022-06-22 04:20:11.883553
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    SimpleAsyncHTTPClient(io_loop=IOLoop.current())
    SimpleAsyncHTTPClient(max_clients=20, io_loop=IOLoop.current())
    SimpleAsyncHTTPClient(defaults={"request_timeout": 20}, io_loop=IOLoop.current())
    hostname_mapping = {"www.facebook.com": "127.0.0.1"}
    SimpleAsyncHTTPClient(hostname_mapping=hostname_mapping, io_loop=IOLoop.current())
    SimpleAsyncHTTPClient(max_buffer_size=1024, io_loop=IOLoop.current())
    SimpleAsyncHTTPClient(
        resolver=Resolver(), io_loop=IOLoop.current()
    )  # TODO: need a test for OverrideResolver



# Generated at 2022-06-22 04:20:20.583575
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    """
    Test initialize method of class SimpleAsyncHTTPClient
    """
    simplehttpclient = SimpleAsyncHTTPClient()
    assert simplehttpclient.tcp_client != None
    assert simplehttpclient.max_clients == 10
    assert simplehttpclient.max_buffer_size == 104857600
    assert simplehttpclient.max_header_size == None
    assert simplehttpclient.max_body_size == None


# Generated at 2022-06-22 04:20:24.563123
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError("error message")
    except Exception as e:
        assert e.code == 599


# Type alias used in the type annotations.
# This is used because "Optional" is not valid in a type annotation.
_T = typing.TypeVar("_T")



# Generated at 2022-06-22 04:20:27.447968
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    # type: () -> None
    error = HTTPTimeoutError("")
    assert isinstance(error.__str__(), str)


# Generated at 2022-06-22 04:20:38.565504
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():

    # Create a new class instance.
    http_timeout_error__1 = HTTPTimeoutError(message="Timeout")

    # Check the __str__ function
    assert http_timeout_error__1.__str__() == "Timeout"
    return None


_DEFAULT_CA_CERTS = (
    os.path.dirname(os.path.abspath(__file__)) + "/ca-certificates.crt"
)


# Generated at 2022-06-22 04:20:49.066275
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import tornado.testing
    import tornado.web
    import tornado.platform.asyncio
    import asyncio

    class HelloHandler(tornado.web.RequestHandler):
        def get(self):
            self.write('Hello world!')

    async def post(self):
        response = await self.application.http_client.fetch(
            'http://localhost:%d/' % self.get_http_port(),
            method='POST',
            body='name=Chris',
            headers={'Content-Type': self.get_argument('content_type', 'text/plain')},
            request_timeout=3600)
        self.write(str(response.code)
    + ' ' + tornado.escape.native_str(response.headers['Content-Type'])
    + '\n' + response.body)


# Generated at 2022-06-22 04:20:49.912705
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    _HTTPConnection()

# Generated at 2022-06-22 04:20:51.662516
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    stream = mock.MagicMock()
    _HTTPConnection.on_connection_close(self)
    assert self.final_callback



# Generated at 2022-06-22 04:20:53.858541
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass

 

# Generated at 2022-06-22 04:21:59.095391
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    def __str__(message):
        http_timeout_error = HTTPTimeoutError(message)
        return str(http_timeout_error)
    assert __str__("") == "Timeout"
    assert __str__("abc") == "abc"



# Generated at 2022-06-22 04:22:05.920688
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    SimpleAsyncHTTPClient(max_clients=10, hostname_mapping=None, max_buffer_size=104857600, resolver=None, defaults=None, max_header_size=None, max_body_size=None)


# Generated at 2022-06-22 04:22:14.060710
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    http_client = HTTPClient()
    mock_request: Mock = MagicMock(spec=HTTPRequest)
    mock_start_wall_time: Mock = MagicMock(spec=int)
    mock_start_time: Mock = MagicMock(spec=float)
    mock_io_loop: Mock = MagicMock(spec=IOLoop)
    mock_io_stream: Mock = MagicMock(spec=IOStream)
    mock_sock: Mock = MagicMock(spec=socket)
    mock_sockaddr: Mock = MagicMock(spec=Tuple)
    mock_parsed = MagicMock(spec=ParseResult)
    mock_func = MagicMock()

# Generated at 2022-06-22 04:22:18.591234
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import os

    application = Application([])
    application.listen(8888)
    client = AsyncHTTPClient(application)
    response = client.fetch("http://www.google.com/")
    assert response.code == 200
    application.stop()

# Generated at 2022-06-22 04:22:30.761865
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    from typing import Optional
    # Test case 1, __str__ without assigning object variable message.
    e1 = HTTPTimeoutError.__new__(HTTPTimeoutError)
    e1.args = ()
    e1.__init__()
    expected_string = "Timeout"
    actual_string = str(e1)
    # Test case 2, __str__ with assigned object variable message.
    e2 = HTTPTimeoutError.__new__(HTTPTimeoutError)
    e2.args = ("Timeout occurs.")
    e2.message = "Timeout occurs."
    e2.__init__(e2.message)
    expected_string = "Timeout occurs."
    actual_string = str(e2)
    # The output of both test cases should be the same.
    assert actual_string == expected_string


# Generated at 2022-06-22 04:22:35.142192
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    cli = SimpleAsyncHTTPClient()
    cli.close()

# Generated at 2022-06-22 04:22:35.945188
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # self, chunk: bytes
    pass

# Generated at 2022-06-22 04:22:38.493010
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    class TestSimpleAsyncHTTPClient(SimpleAsyncHTTPClient):
        pass

    client = TestSimpleAsyncHTTPClient()
    assert isinstance(client, TestSimpleAsyncHTTPClient)



# Generated at 2022-06-22 04:22:40.586816
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError("message")
    assert str(e) == "message"



# Generated at 2022-06-22 04:22:42.219172
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    e = HTTPTimeoutError('Timeout')
    assert str(e) == 'Timeout'


# Generated at 2022-06-22 04:23:58.771983
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    request = HTTPRequest("", "", None, None)
    final_callback = lambda x: x
    stream = None
    io_loop = IOLoop()
    release_callback = lambda: x
    http_connection = _HTTPConnection(
            request,
            final_callback, 
            stream, 
            io_loop, 
            release_callback
    )
    
    raised = False
    def test():
        nonlocal raised
        raised = True
    try:
        http_connection.on_connection_close()
    except Exception as e:
        test()
    
    assert raised
    

# Generated at 2022-06-22 04:24:11.190730
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():

    class _HTTPConnection_finish_Helper(HTTPClient):
        def __init__(self):
            self.request = None

    helper = _HTTPConnection_finish_Helper()
    helper.final_callback = None
    helper.request = _RequestProxy(None, None)
    helper.request.request = _RequestProxy(None, None)
    helper.request.request.url = "http://example.com/hello"
    helper.request.max_redirects = 1
    helper.request.method = "POST"
    helper.request.headers = {"Content-Type": "application/json"}
    helper.headers = {"Location": "http://example.com/hello2"}
    helper.chunks = []
    helper.code = 303
    helper.reason = "Redirect"

    helper.finish()

    helper.code

# Generated at 2022-06-22 04:24:12.026474
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    HTTPStreamClosedError(message=None)



# Generated at 2022-06-22 04:24:14.183537
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # There is no way to instantiate an IOStream without binding it to a socket
    # In test_client_fetch_future we are testing it without any socket
    # binding
    assert False

# Generated at 2022-06-22 04:24:25.726189
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from tornado.httpclient import HTTPError
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase
    from tornado.test.util import unittest, skipOnTravis
    from tornado.web import RequestHandler, Application
    import tornado.version
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPServerRequest
    import tornado.ioloop
    import tornado.platform.auto
    import uuid
    import http
    import functools
    import traceback
    import io
    import types
    import socket
    import sys
    import pprint
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.tcpserver
    import tornado.testing
    import tornado.testing
    import tornado.test.httpclient_test

# Generated at 2022-06-22 04:24:27.335632
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    a = SimpleAsyncHTTPClient()



# Generated at 2022-06-22 04:24:32.502618
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    """Basic test for class _HTTPConnection.
    """
    class MockStream():
        """Mock of tornado.iostream.IOStream.
        """
        def __init__(self):
            pass

        def read_until(self, delimiter, callback) -> None:
            """Mock of tornado.iostream.IOStream.read_until.
            """
            pass

        def write(self, data, callback) -> None:
            """Mock of tornado.iostream.IOStream.write.
            """
            pass

        def read_bytes(self, num_bytes, callback, streaming_callback=None) -> None:
            """Mock of tornado.iostream.IOStream.read_bytes.
            """
            pass


# Generated at 2022-06-22 04:24:40.415440
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    instance = _HTTPConnection()
    arg = 0
    _ = instance.data_received(arg)


async def execute(
    request: HTTPRequest,
    future: Future[HTTPResponse],
    release_callback: Optional[Callable[[], None]],
) -> None:
    try:
        client = _HTTPClient()
        client.fetch_impl(request, future, release_callback=release_callback)
    except Exception:
        if future.done():
            return
        future.set_exception(sys.exc_info())



# Generated at 2022-06-22 04:24:50.960797
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-22 04:24:52.181270
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    body = "Stream closed"
    assert str(HTTPStreamClosedError(body)) == body



# Generated at 2022-06-22 04:26:33.350110
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass

# Generated at 2022-06-22 04:26:34.176173
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-22 04:26:35.534164
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("TEST")
    assert e.code == 599
    assert e.response is None



# Generated at 2022-06-22 04:26:46.940599
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient