

# Generated at 2022-06-22 15:41:04.525308
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    loop = IOLoop()
    asyncio.set_event_loop(loop)
    resp = '''HTTP/1.1 200 OK
Content-Type: text/html; charset=UTF-8
Content-Length: 7
Date: Tue, 09 Jun 2020 15:36:19 GMT
Server: TornadoServer/6.0.4

'''
    stream1 = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0), loop)
    stream1.set_close_callback(stream1.close)
    stream1.connect(("localhost", 8080), callback=stream1.close)
    stream1.write(resp.encode())
    connection = _HTTPConnection(None, stream1, ("127.0.0.1", 9922), None, None, None)
    connection.on_

# Generated at 2022-06-22 15:41:16.295598
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import pytest
    import collections
    import functools
    import re
    import typing
    import urllib.parse
    import types
    import socket
    import ssl
    import sys
    from io import BytesIO
    import time
    import base64
    from tornado.escape import _unicode
    from tornado import gen, version
    from tornado.httpclient import (
        HTTPResponse,
        HTTPError,
        AsyncHTTPClient,
        main,
        _RequestProxy,
        HTTPRequest,
    )
    from tornado import httputil
    from tornado.http1connection import HTTP1Connection, HTTP1ConnectionParameters
    from tornado.ioloop import IOLoop
    from tornado.iostream import StreamClosedError, IOStream

# Generated at 2022-06-22 15:41:18.552231
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # TODO: implement this
    print("test_SimpleAsyncHTTPClient_close")    


# Generated at 2022-06-22 15:41:30.904278
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    import pytest
    from . import HTTPRequest
    from .httpclient import AsyncHTTPClient
    from .httputil import HTTPHeaders
    from .http1connection import HTTP1Connection
    from .http1connection import HTTP1ConnectionParameters
    from .utils import _RequestProxy
    import httputil
    from tornado.netutil import ssl_options_to_context
    import socket
    import ssl
    import errno
    import unittest
    import warnings
    import tempfile
    import os
    import tornado.platform.auto
    n_clients = 0

    class Server(object):
        def __init__(self, http_version: str) -> None:
            self.http_version = http_version
            self.wrap_ssl = False


# Generated at 2022-06-22 15:41:41.676682
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # self = _HTTPConnection()
    if self.final_callback:
        self._remove_timeout()
        if self.stream.error:
            raise self.stream.error
        try:
            raise HTTPStreamClosedError("Connection closed")
        except HTTPStreamClosedError:
            self._handle_exception(*sys.exc_info())

    else:
        # If our callback has already been called, we are probably
        # catching an exception that is not caused by us but rather
        # some child of our callback. Rather than drop it on the floor,
        # pass it along, unless it's just the stream being closed.
        return isinstance(value, StreamClosedError)

    self.stream.close()


# Generated at 2022-06-22 15:41:45.140809
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    def _():
        return
    _HTTPConnection._handle_exception = _
    _HTTPConnection().on_connection_close()
test__HTTPConnection_on_connection_close()

# Generated at 2022-06-22 15:41:47.226911
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    client = SimpleAsyncHTTPClient()
    request = HTTPRequest("http://example.com/")
    # the first line is a response status line.
    first_line = httputil.ResponseStartLine("1.1", 200, "")
    headers_received(client, request, first_line, [])

# Generated at 2022-06-22 15:41:47.990674
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-22 15:41:48.725411
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-22 15:41:52.981197
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    client.close()

# Generated at 2022-06-22 15:44:03.999562
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    try:
        from tornado.util import b
    except ImportError:
        from tornado.escape import utf8 as b
    _unicode = str

    io_loop = IOLoop.current()

    @gen.coroutine
    def fetch_test_url(**kwargs: object) -> HTTPResponse:
        client = SimpleAsyncHTTPClient(io_loop=io_loop, **kwargs)
        response = yield client.fetch("http://127.0.0.1:%d/hello" % port)
        raise gen.Return(response)


# Generated at 2022-06-22 15:44:09.492876
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():

    def f(self):
        self.close()

    get_SimpleAsyncHTTPClient_close(f)
    # TODO
    #  pass

# Generated at 2022-06-22 15:44:14.164111
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    print("\n\n")
    print("------ test __HTTPConnection.run ------")

    r = SimpleAsyncHTTPClient()
    r.fetch("http://www.google.com", lambda r: print(r.body))
    r.io_loop.stop()
    r.io_loop.start()

test__HTTPConnection_run()


# Generated at 2022-06-22 15:44:14.727258
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-22 15:44:20.590687
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    HTTPTimeoutError = MyHTTPError = __import__('HTTPTimeoutError').__getattr__('HTTPTimeoutError')
    self = HTTPTimeoutError(message="Message")
    assert self.__str__() == "Message"
    assert isinstance(self.__str__(), (str,))


# Generated at 2022-06-22 15:44:29.562032
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = httputil.ResponseStartLine('HTTP',1,'Ok')
    headers = {'Location':'foo'}
    request_1 = HTTPRequest('http://www.foo.com', method='GET')
    request_2 = HTTPRequest('http://www.foo.com', method='GET', follow_redirects=True)
    request_2.max_redirects = 1

    # test when should not follow
    http_connection_1 = _HTTPConnection(request_1)
    http_connection_1.headers_received(first_line, headers)
    assert http_connection_1._should_follow_redirect() == False
    
    # test when should follow
    http_connection_2 = _HTTPConnection(request_2)
    http_connection_2.headers_received(first_line, headers)
   

# Generated at 2022-06-22 15:44:32.048068
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    r"""
    .. testcode::
        :hide:
        a = SimpleAsyncHTTPClient()
        
    """
    pass

# Generated at 2022-06-22 15:44:36.793802
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    KEY = 'data_received'
    client = tornado.httpclient.AsyncHTTPClient()
    response = client.fetch('https://www.google.com/')
    assert response.status_code == 200
    assert response.body
    html = response.body.decode()
    assert KEY in html


# Generated at 2022-06-22 15:44:44.693749
# Unit test for method run of class _HTTPConnection

# Generated at 2022-06-22 15:44:56.205934
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    @gen.coroutine
    def f():
        raise gen.Return(42)
    c = SimpleAsyncHTTPClient(io_loop=f.gen.io_loop)
    @gen.coroutine
    def callback(r):
        return True

    request = HTTPRequest('http://www.tornadoweb.org/')
    request.connect_timeout = 5
    request.request_timeout = 5
    assert c.queue == deque([])
    assert c.waiting == {}
    assert c.active == {}
    result = c.fetch_impl(request, callback)
    # assert
    assert len(c.queue) == 1
    assert len(c.waiting) == 1
    assert len(c.active) == 0

# Generated at 2022-06-22 15:46:10.107696
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    import mock
    import pytest
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.options
    import tornado.simple_httpclient
    import tornado.testing
    import tornado.test.util
    import tornado.web
    import types
    import zmq
    import zmq.utils.strtypes

    class CallbackCounter(object):
        def __init__(self):
            self.counter = 0

        def __call__(self):
            self.counter += 1

    class StreamingHandler(tornado.web.RequestHandler):
        def initialize(
            self, response_data: bytes, status_code: int, headers: dict
        ) -> None:
            self.response_data = response_data
            self.status_code = status_code
            self.headers

# Generated at 2022-06-22 15:46:17.117633
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import tornado.ioloop
    import tornado.testing
    import unittest
    import urllib
    import urllib.parse
    
    
    class _TestHTTPConnection(unittest.TestCase):
        # _get_url is overridden in each test case to return
        # the URL to fetch. Subclasses can replace it with a
        # classmethod to make the test use different URLs.
        def _get_url(self):
            return "http://localhost/"
    
        def _fetch(self, url, **kwargs):
            self.http_client.fetch(url, self.stop, **kwargs)
            return self.wait()
    
        def setUp(self):
            super(_TestHTTPConnection, self).setUp()

# Generated at 2022-06-22 15:46:22.142658
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from tornado.platform.asyncio import AsyncIOCertTestCase, AsyncIOTestCase
    from tornado.test.util import unittest_run_loop
    import unittest
    import asyncio
    import certifi
    import ssl
    import sys
    if sys.version_info < (3, 6):
        raise unittest.SkipTest(
            "Python 3.6+ required for asyncio tests on Windows"
        )
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.test.util
    import tornado.httpclient
    import tornado.httputil
    import tornado.escape
    import tornado.ioloop
    import tornado.netutil
    import tornado.simple_httpclient
    import tornado.tcpclient
    import tornado.tcpserver

# Generated at 2022-06-22 15:46:23.616164
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert str(HTTPTimeoutError("Timeout"))=="Timeout"


# Generated at 2022-06-22 15:46:26.162255
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert HTTPStreamClosedError(message='timeout').__str__() == 'timeout'
    assert HTTPStreamClosedError(message=None).__str__() == 'Stream closed'



# Generated at 2022-06-22 15:46:30.807244
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    client=AsyncHTTPClient()
    request=HTTPRequest(url="http://www.google.com")
    connection=_HTTPConnection(client, request, lambda : None)
    connection.request=_RequestProxy(request, None)
    connection.code=200
    connection.reason=""
    connection.headers={"Location": "http://www.yahoo.com"}
    connection.chunks=[b"a", b"b"]
    connection.io_loop=IOLoop()
    connection.io_loop.time=lambda : 123
    connection.start_time=123
    connection.start_wall_time=123
    connection.final_callback=lambda response: \
        print(response.code)

# Generated at 2022-06-22 15:46:33.596590
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    req = httpclient.HTTPRequest(url="http://www.google.com/")
    _HTTPConnection(req, io_loop=IOLoop())


# Generated at 2022-06-22 15:46:42.288629
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    import io
    import socket
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing
    import tornado.testing

# Generated at 2022-06-22 15:46:46.506792
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    data = b"0123456789" * 1000
    chunk_size = [None]

    def streaming_callback(chunk):
        if chunk_size[0] is None:
            chunk_size[0] = len(chunk)
        else:
            assert len(chunk) == chunk_size[0]

    def body_producer(write):
        for i in range(0, len(data), chunk_size[0]):
            write(data[i : i + chunk_size[0]])

    request = HTTPRequest(
        "http://localhost:8888/streaming", streaming_callback=streaming_callback
    )
    request.body = data

    # Send a request with pre-buffered data

# Generated at 2022-06-22 15:46:47.803867
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    with SimpleAsyncHTTPClient(max_clients=10) as client:
        pass
    assert client.max_clients == 10



# Generated at 2022-06-22 15:48:03.085691
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    import tornado
    import tornado.testing
    import tornado.web
    import tornado.httpserver
    import tornado.httpclient
    import tornado.iostream
    import tornado.tcpserver
    import tornado.netutil
    import tornado.locks
    import tornado.options
    import tornado.platform.asyncio
    import unittest
    import zmq
    import zmq.asyncio
    import zmq.decorators
    import zmq.eventloop
    import zmq.eventloop.ioloop
    import zmq.eventloop.zmqstream
    import zmq.log.handlers
    import zmq.ssh
    import zmq.utils.strtypes
    import zmq.utils.win32
    import typing
    import functools
    import contextlib
   

# Generated at 2022-06-22 15:48:06.004849
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # See if body_producer aborts the request properly
    def dummy_body_producer():
        raise RuntimeError

    class DummyRequest:
        body_producer = dummy_body_producer
        streaming_callback = None

    client = AsyncHTTPClient()
    client.fetch(DummyRequest())



# Generated at 2022-06-22 15:48:07.625407
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    httpclient._HTTPConnection.on_connection_close()

# Generated at 2022-06-22 15:48:17.816097
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado.httpclient import HTTPResponse, HTTPRequest, HTTPClient
    from tornado.simple_httpclient import _HTTPConnection
    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase
    from tornado.httpserver import HTTPServer
    from tornado.netutil import bind_sockets
    from tornado.httpserver import HTTPServer
    from tornado.web import Application, RequestHandler
    from tornado.ioloop import IOLoop
    import tornado.web
    import unittest

    class MainHandler(RequestHandler):
        def get(self):
            self.write("Hello, world")

        def post(self):
            self.write("Hello, world")

        def head(self):
            self.write("Hello, world")

    def get_app():
        return Application([("/", MainHandler)])


# Generated at 2022-06-22 15:48:27.876394
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def _fake_resolve(host, port, af=None, callback=None):
        return [(af or socket.AF_INET, (host, port or 80), 0, "")]

    def _fake_bind_sockets(port, address=None, family=0, backlog=128, flags=None):
        return ["sock"]

    def _fake_resolve_future(host, port, af=None):
        return "resolve_future"

    def _fake_socket_options(sock, options):
        return "socket_options"

    def _fake_connect_future(sock, address):
        return "connect_future"

    def _fake_stream(socket_options=None, max_buffer_size=None):
        return "stream"


# Generated at 2022-06-22 15:48:34.072095
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    import asyncio
    import time
    io_loop = asyncio.get_event_loop()
    http_conn = _HTTPConnection('127.0.0.1', '80')
    start_time = time.time()
    def final_callback(f):
        print(f)
        print(time.time() - start_time)
        io_loop.stop()
    http_conn.final_callback = final_callback
    http_conn.connection = http_conn._create_connection(io_loop.create_connection(lambda: http_conn, host = '127.0.0.1', port = 80))
    http_conn.connection.write_headers(httputil.RequestStartLine('GET', '/', ''), httputil.HTTPHeaders({}))
    http_conn.connection.finish()
    io_

# Generated at 2022-06-22 15:48:41.843998
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Test callback
    def cb(response):
        assert response.code == 301
        assert response.reason == "Moved Permanently"
        assert response.headers["Location"] == "http://example.com/new-uri"
        assert response.body == b""

    # Test following redirect
    def test_1(self):
        self.code = 301
        self.headers = httputil.HTTPHeaders({"Location": "http://example.com/new-uri"})
        self.request.follow_redirects = True
        self.request.max_redirects = 1
        self.final_callback = cb
        self.finish()

    run_test(test_1)

    # Test not following redirect
    def test_2(self):
        self.code = 301
        self.headers = httput

# Generated at 2022-06-22 15:48:43.226688
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    return None
    # TODO: implement this unit test



# Generated at 2022-06-22 15:48:52.220253
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado import stack_context
    from tornado.httputil import format_timestamp
    from tornado.httpclient import HTTPConnection, _RequestProxy
    from tornado.httputil import parse_timestamp

    io_loop = IOLoop()
    io_loop.make_current()
    io_loop.set_blocking_log_threshold(1)
    stack_context.stack_context_delegate_class = stack_context._StackContext
    io_loop.clear_instance()
    io_loop.time = lambda: 0
    io_loop.add_callback = lambda x: x()
    io_loop.add_future = lambda x, c: c(x)
    io_loop.handle_callback_exception = lambda _: None

# Generated at 2022-06-22 15:48:52.796603
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass

# Generated at 2022-06-22 15:49:39.574253
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    request = HTTPRequest(url='http://localhost:80/', connect_timeout=0)
    callback = functools.partial()
    simpleAsyncHttpClient = SimpleAsyncHTTPClient()
    simpleAsyncHttpClient.fetch_impl(request, callback)
    # Unit test for method close of class SimpleAsyncHTTPClient

# Generated at 2022-06-22 15:49:49.974190
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Create a SimpleAsyncHTTPClient:
    ioloop = IOLoop.current()
    client = SimpleAsyncHTTPClient(io_loop=ioloop)
    # Create a fake HTTP connection:
    class FakeHTTPConnection(object):
        _header_callback = None
        _data_callback = None
        _final_callback = None
        _data = []
        _closed = False

        def __init__(self):
            pass

        def close(self):
            self._closed = True

        def request(
            self,
            method,
            url,
            body=None,
            headers={},
            header_callback=None,
            data_callback=None,
            final_callback=None
        ):
            self._header_callback = header_callback
            self._data_callback = data_callback
            self._final_

# Generated at 2022-06-22 15:49:51.613797
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    x = _HTTPConnection("","",None)
    x.start()


# Generated at 2022-06-22 15:50:03.183303
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from tornado.httputil import HTTPHeaders
    from tornado.httpclient import HTTPResponse
    request = HTTPRequest("url")
    request.method = "method"
    stream = Mock()
    code = None
    reason = None
    proxy_host = None
    proxy_port = None
    headers = HTTPHeaders()
    chunks = []
    reason = None
    io_loop = Mock()
    io_loop.time.return_value = 0.0
    final_callback = Mock()
    final_callback.return_value = None