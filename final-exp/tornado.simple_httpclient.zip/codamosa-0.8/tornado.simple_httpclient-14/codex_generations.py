

# Generated at 2022-06-22 15:40:47.790945
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    try:
        raise HTTPStreamClosedError("Message")
    except Exception as e:
        assert str(e) == "Message"
        assert repr(e) == "HTTPStreamClosedError(599, 'Message')"
test_HTTPStreamClosedError___str__()


# Generated at 2022-06-22 15:41:01.134739
# Unit test for method data_received of class _HTTPConnection

# Generated at 2022-06-22 15:41:03.814940
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    async def _test_SimpleAsyncHTTPClient_close():
        pass
    # not implemented yet

# Generated at 2022-06-22 15:41:15.268209
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Create an object of HTTP1ConnectionParameters with default values
    param = HTTP1ConnectionParameters()
    # Create an object of SimpleAsyncHTTPClient
    client = SimpleAsyncHTTPClient(io_loop=IOLoop())
    # Get a reference to the resolver object
    resolver = client.resolver
    # Construct and send HTTP request to fetch the web page
    client.fetch("http://example.com", request_timeout=5)

    # Fetch the response for the request sent.
    client.fetch_impl(request="", callback=lambda x: x)
    # Close the resolver
    client.close()
    # Get the TCPClient object in use, else return None. 
    tcp_client = client.tcp_client

    # Get the queue containing the requests that are waiting to be fetched.

# Generated at 2022-06-22 15:41:25.127514
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Given a _HTTPConnection object
    http_connection = _HTTPConnection(client=client(), io_loop=io_loop.IOLoop.current())
    http_connection.request = _RequestProxy(
        client=client(),
        request=httpclient.HTTPRequest(url="http://example.com"),
        io_loop=io_loop.IOLoop.current(),
    )
    # Calling on_connection_close raises an exception
    #  AssertionError: Expected to raise, didn't
    assert raises(
        AssertionError,
        http_connection.on_connection_close,
    )


# Generated at 2022-06-22 15:41:35.367180
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    """
    SimpleAsyncHTTPClient.close

    If the resolver was not provided, it should be closed.
    If the resolver was provided, it should not be closed.
    """
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import to_tornado_future
    async with AsyncHTTPClient() as client:
        await to_tornado_future(client.close())

    assert client.resolver.closed

    dummy_resolver = "dummy"
    async with AsyncHTTPClient(resolver=dummy_resolver) as client:
        await to_tornado_future(client.close())

    assert not client.resolver.closed



# Generated at 2022-06-22 15:41:42.560683
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # _HTTPConnection_headers_received()
    # Test a valid call to _HTTPConnection_headers_received()
    fake_first_line = httputil.ResponseStartLine("HTTP/1.1", 200, "OK")
    fake_headers = httputil.HTTPHeaders({'Content-Type': 'text/plain'})
    f = _HTTPConnection(HTTPRequest())
    assert f.headers_received(fake_first_line, fake_headers)

# Generated at 2022-06-22 15:41:54.972292
# Unit test for method finish of class _HTTPConnection

# Generated at 2022-06-22 15:42:01.532174
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():

    # set up http object for unit testing
    parsed = httputil.url_concat("http://localhost:8888", {"x": "y"})

# Generated at 2022-06-22 15:42:11.393194
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import tornado.ioloop
    from tornado.httputil import HTTPHeaders
    from tornado import httpclient
    ''' Test for correct fetch of a simple request and return
        of a HTTPResponse object with correct attributes.
    '''
    ioloop = tornado.ioloop.IOLoop.instance()
    ioloop.install()
    timeout = 100
    client = SimpleAsyncHTTPClient(max_clients=100)
    class TestResponse(object):
        def __init__(self, url):
            self.code = 200
            self.body = b'Hello'
            self.headers = HTTPHeaders({'content-length': '5', 'Transfer-Encoding': 'chunked'})
            self.request = httpclient.HTTPRequest(url)
