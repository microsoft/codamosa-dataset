

# Generated at 2022-06-22 15:41:36.449595
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass





# Generated at 2022-06-22 15:41:48.914978
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    if not hasattr(HTTPClient, "_HTTPConnection"):
        return

    # Create an instace of HTTPRequest class.
    request = mock.MagicMock()
    request.body = b"body"
    request.headers = {'key': 'value'}
    request.url = 'url'
    request.method = 'method'
    # Create an instace of HTTPClient class.
    client = mock.MagicMock()
    client.fetch.return_value = "response"
    # Create an instace of _HTTPConnection class.
    http_connection = HTTPClient._HTTPConnection(client, request)
    # Create an instace of HTTPResponse class.
    http_response = mock.MagicMock()
    http_response.code = 'code'

# Generated at 2022-06-22 15:41:51.209094
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # test _HTTPConnection.data_received method
    pass



# Generated at 2022-06-22 15:41:52.679918
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass # TODO



# Generated at 2022-06-22 15:41:59.126721
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    req = HTTPRequest("/")
    client = SimpleAsyncHTTPClient()
    conn = _HTTPConnection(client, req, client.io_loop)

    conn.code = 200
    conn.chunks = b"chunk"
    conn.request.follow_redirects = False
    conn.request.streaming_callback = None
    conn.final_callback = None
    
    conn.finish()

    assert conn.code == 200
    assert conn.chunks == b"chunk"
    assert conn.request.follow_redirects == False
    assert conn.request.streaming_callback == None
    assert conn.final_callback == None


# Generated at 2022-06-22 15:41:59.693252
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass



# Generated at 2022-06-22 15:42:01.404985
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    request = HTTPRequest("http://foobar.com/", streaming_callback=StreamingHTTPClient()._on_chunk, release_callback=StreamingHTTPClient()._release)
    _HTTPConnection(request)



# Generated at 2022-06-22 15:42:04.733367
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    """
    close [source]
    Closes all pending connections.
    """
    pass

# Generated at 2022-06-22 15:42:09.611693
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    async def coro(self, response, code, reason=None, headers=None, buffer=None):
        # TODO: Should assert that the last chunk was processed
        if self.final_callback is None:
            return

        assert code is not None
        assert not isinstance(code, httputil.ResponseStartLine)
        self.code = code
        self.reason = reason
        self.headers = headers
        self.buffer = buffer
        if self._should_follow_redirect():
            assert isinstance(self.request, _RequestProxy)
            new_request = copy.copy(self.request.request)
            new_request.url = urllib.parse.urljoin(
                self.request.url, self.headers["Location"]
            )
            new_request.max_redirects = self.request.max_red

# Generated at 2022-06-22 15:42:10.445523
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # _HTTPConnection.on_connection_close()
    pass



# Generated at 2022-06-22 15:43:01.606431
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # _HTTPConnection.headers_received() is tested in test_httputil.py
    pass

# Generated at 2022-06-22 15:43:12.184119
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    max_clients = 8
    hostname_mapping = {'localhost': '127.0.0.1'}
    max_buffer_size = 1048576
    resolver = Resolver()
    defaults = {'name': 'nonexistent'}
    max_header_size = 1048576
    max_body_size = 16777216
    simpleAsyncHTTPClient = SimpleAsyncHTTPClient()
    simpleAsyncHTTPClient.initialize(
        max_clients=max_clients,
        hostname_mapping=hostname_mapping,
        max_buffer_size=max_buffer_size,
        resolver=resolver,
        defaults=defaults,
        max_header_size=max_header_size,
        max_body_size=max_body_size
    )

# Generated at 2022-06-22 15:43:19.769473
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    asyncio.set_event_loop(None)
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    client = AsyncHTTPClient(loop=loop)
    request = HTTPRequest(url='http://127.0.0.1:8888/redirect')
    request.follow_redirects=False
    response = _HTTPConnection(client, request, _HTTPConnectionParameters(), None, None, None)
    response.code = 302
    response.headers = httputil.HTTPHeaders()
    response.headers['Location'] = 'http://127.0.0.1:8888/redirect'
    response.final_callback = functools.partial(response._run_callback, HTTPResponse(None, None, None, None, None, None, None, None))

# Generated at 2022-06-22 15:43:24.431700
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():

    # Instantiation
    _httpconnection = _HTTPConnection()

    # Testing parameter 'self'
    # Testing method finish of class _HTTPConnection
    # No exception should be raised
    assert True



# Generated at 2022-06-22 15:43:30.013694
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    class MockStream(object):
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    class MockRequest(object):
        def __init__(self):
            self.headers = {}
            self.max_redirects = 10
            self.method = "POST"
            self.url = "https://example.org"
            self.final_callback = None
            self.follow_redirects = True

    http_client = _HTTPConnection(None, _RequestProxy(MockRequest()), None, None, None)
    http_client.request.header_callback = None
    http_client.request.streaming_callback = None
    http_client.request.method = "GET"
    http_client.request.follow_redirects = False
    http

# Generated at 2022-06-22 15:43:31.282414
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    assert len(SimpleAsyncHTTPClient) > 0



# Generated at 2022-06-22 15:43:32.170363
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass



# Generated at 2022-06-22 15:43:33.350897
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    None

# Generated at 2022-06-22 15:43:34.164186
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-22 15:43:38.723765
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    conn = _HTTPConnection(None)
    conn._create_connection(None)
    conn._get_ssl_options(None)
    conn._on_timeout(None)
    conn._remove_timeout()
    conn.on_connection_close()
    conn.headers_received(None, None)



# Generated at 2022-06-22 15:45:23.057997
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient(io_loop=IOLoop())
    client.tcp_client.close()
    client.resolver.close()
    client.close()



# Generated at 2022-06-22 15:45:27.065192
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    _max_buffer_size: int = 104857600
    _max_header_size: int = None
    _max_body_size: int = None
    sahc = SimpleAsyncHTTPClient(
        max_buffer_size=_max_buffer_size,
        max_header_size=_max_header_size,
        max_body_size=_max_body_size
    )
    try:
        sahc.close()
    except Exception as e:
        print(e)
test_SimpleAsyncHTTPClient_close()


# Generated at 2022-06-22 15:45:32.650834
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():

    # Arrange
    @gen.coroutine
    def coroutine():
        pass
    
    # Act
    c = SimpleAsyncHTTPClient()

# Generated at 2022-06-22 15:45:35.282670
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    setting = "Timeout"
    return_value = HTTPTimeoutError(setting).__str__()
    assert return_value == setting



# Generated at 2022-06-22 15:45:42.274061
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    stream = object()

    client = object()
    io_loop = object()
    request = object()
    parsed = object()
    release_callback = object()
    final_callback = object()

    def fake_handle_exception(*args):
        return True

    def fake_run_callback(response):
        pass

    def fake_on_connection_close():
        pass

    connection = _HTTPConnection(
        client,
        io_loop,
        request,
        parsed,
        release_callback,
        final_callback,
    )
    connection._handle_exception = fake_handle_exception
    connection._run_callback = fake_run

# Generated at 2022-06-22 15:45:48.300234
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    request = HTTPRequest(
        url="http://www.google.com"
    )
    client = HTTPClient()
    connection = _HTTPConnection(client, request)

    class Dummy(object):
        def __init__(self):
            self.error = HTTPError(599)

    connection.stream = Dummy()

    connection.final_callback = None
    connection.on_connection_close()

# Generated at 2022-06-22 15:45:59.681342
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # initialize
    _HTTPConnection = HTTPClient()._HTTPConnection

# Generated at 2022-06-22 15:46:04.086778
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = httputil.ResponseStartLine(200, 'OK', 'HTTP/1.1')
    headers = httputil.HTTPHeaders(Location='http://www.google.com')
    http = _HTTPConnection()
    http.request.follow_redirects = True
    http.headers_received(first_line, headers)
    assert http.code == 301

# Generated at 2022-06-22 15:46:06.224247
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    self = HTTPStreamClosedError("")
    r = str(self)
    assert r == 'Stream closed'

# Generated at 2022-06-22 15:46:13.832104
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    url = 'http://localhost:8080'
    client = HTTPClient()
    connection = _HTTPConnection(client, url)
    assert connection.client == client
    assert connection.io_loop == IOLoop.current()
    assert connection.request == None
    assert connection.parsed == {}
    assert connection.stream == None
    assert connection.code == None
    assert connection.headers == None
    assert connection.chunks == []
    assert connection.final_callback == None
    assert connection.start_time == None
    assert connection.connect_timeout == CONNECT_TIMEOUT
    assert connection.request_timeout == REQUEST_TIMEOUT
    assert connection.max_header_size == MAX_HEADER_SIZE
    assert connection.max_body_size == MAX_BODY_SIZE
    assert connection._sockaddr == None