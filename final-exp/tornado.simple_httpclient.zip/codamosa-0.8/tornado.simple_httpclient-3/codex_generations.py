

# Generated at 2022-06-22 15:40:56.110511
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    req = httpclient.HTTPRequest("http://localhost:80/")
    conn = _HTTPConnection(req)
    assert conn.request == req
    assert conn.start_time == conn.io_loop.time()
    assert conn.start_wall_time == time.time()
    assert conn.final_callback is None
    assert conn.code is None
    assert conn.headers is None
    assert conn.chunks == []
    assert conn.stream is None

    conn.io_loop = None
    with pytest.raises(AssertionError):
        conn.close()


# Generated at 2022-06-22 15:41:04.502478
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    http_client = SimpleAsyncHTTPClient()
    http_client.initialize(
        max_clients=10,
        hostname_mapping={},
        max_buffer_size=104857600,
        resolver=None,
        defaults={},
        max_header_size=None,
        max_body_size=None,
    )

# Generated at 2022-06-22 15:41:16.249240
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    io_loop = IOLoop.current()
    client = AsyncHTTPClient(io_loop=io_loop, force_instance=True)
    response = _HTTPConnection(
        client,
        URLSpec("http://127.0.0.1/"),
        'GET',
        HTTPRequest(
            "http://127.0.0.1/",
            follow_redirects=False,
            max_redirects=10,
            user_agent="Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0",
        ),
        final_callback=lambda response: client._on_response(response, None),
        release_callback=lambda: None,
    )


# Generated at 2022-06-22 15:41:27.724018
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    ioloop = asyncio_adapter.IOLoop() # type: Dict[str, Any]
    client = SimpleAsyncHTTPClient()
    assert isinstance(client, SimpleAsyncHTTPClient)
    expect_resolver = client.resolver
    expect_max_buffer_size = 104857600
    expect_own_resolver = True
    assert client.tcp_client.resolver == expect_resolver
    assert client.max_buffer_size == expect_max_buffer_size
    assert client.own_resolver == expect_own_resolver
    assert client.max_clients == 10
    assert client.tcp_client.io_loop is ioloop
    client.close()
    ioloop.close()

# Generated at 2022-06-22 15:41:28.104832
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-22 15:41:33.987339
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """Test for method headers_received of class _HTTPConnection"""
    conn = _HTTPConnection()
    conn.request = HTTPRequest(url = "www.example.com")
    first_line = httputil.ResponseStartLine(300, "OK", "HTTP/1.1")
    conn.headers_received(first_line, headers={"Location": "www.google.com"})
    # NB: There is no function attributes, properties or methods in the
    # target class with the same name.
    assert not hasattr(conn, "first_line")
    assert not hasattr(conn, "request")
    assert not hasattr(conn, "headers")

# Generated at 2022-06-22 15:41:41.563756
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    """
    SimpleAsyncHTTPClient.close() assertion test
    """
    ioloop = IOLoop()
    io_loop = ioloop.instance()
    async_http_client = SimpleAsyncHTTPClient(io_loop=io_loop)
    try:
        async_http_client.close()
    except Exception as err:
        print("Unexpected exception: %s" % str(err))
        assert False
    return

# Generated at 2022-06-22 15:41:54.293737
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    stream = magicmock.MagicMock()
    request = _RequestProxy(magicmock.MagicMock(), None)
    http_client = magicmock.MagicMock()
    max_header_size = magicmock.MagicMock()
    max_body_size = magicmock.MagicMock()
    callback = magicmock.MagicMock()
    
    m = _HTTPConnection(stream, request, http_client, max_header_size, max_body_size, callback)

    m.data_received(b'abcd')
    m._should_follow_redirect.return_value = True
    m.data_received(b'abcd')
    m._should_follow_redirect = False
    m.request.streaming_callback = lambda x: None

# Generated at 2022-06-22 15:41:55.422125
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    pass


# Generated at 2022-06-22 15:42:07.107455
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado import testing
    import unittest
    import threading
    import functools
    import tornado.concurrent
    import httplib
    class TestSimpleAsyncHTTPClient(AsyncHTTPClient):
        def initialize(self, io_loop=None, max_clients=10,
                       defaults=None, **kwargs):
            super(TestSimpleAsyncHTTPClient, self).initialize(
                io_loop=io_loop, max_clients=max_clients,
                defaults=defaults, **kwargs)
            self._counter = 0
            self._async_client = None
            self.host_is_ok = functools.partial(self.host_is_ok, host_is_ok=True)

# Generated at 2022-06-22 15:48:15.011882
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    method = _HTTPConnection
    inst = method('method')
    inst.code = None
    inst.final_callback = None
    inst.chunks = []
    assert inst.finish() == None
    assert inst._on_end_request() == None
    assert inst.final_callback == None


# Generated at 2022-06-22 15:48:16.917794
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    error = HTTPTimeoutError("Timeout")
    assert error.__str__() == "Timeout"


# Generated at 2022-06-22 15:48:18.209161
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # _HTTPConnection.finish(self)
    pass

# Generated at 2022-06-22 15:48:28.090952
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    @gen_test
    async def test_run(self, mock_stream, mock_headers_received, mock_connection):
        mock_headers_received.side_effect = [
            gen.maybe_future(None),
            gen.maybe_future(None),
        ]
        self.request.body_producer = None
        self.request.expect_100_continue = False
        con = self._create_connection(mock_stream)
        con.write_headers(None, None)
        con.finish = Mock()

        await self.run()

        self.assertTrue(mock_stream.set_nodelay.called)
        self.assertTrue(mock_stream.set_close_callback.called)
        self.assertTrue(mock_stream.connect.called)

        # headers

# Generated at 2022-06-22 15:48:35.102429
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    __tracebackhide__ = True
    # This is just a smoke test; the HTTP client code is mostly tested
    # through AsyncHTTPTestCase.
    ioloop = IOLoop()
    ioloop.make_current()
    with contextlib.closing(HTTPClient()) as client:
        client.fetch("https://github.com", callback=ioloop.stop)
        ioloop.start()



# Generated at 2022-06-22 15:48:36.732340
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError(message=None)
    assert e.__str__() == "Stream closed"



# Generated at 2022-06-22 15:48:37.622317
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass 



# Generated at 2022-06-22 15:48:40.136910
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _HTTPConnection_on_connection_close = getattr(_HTTPConnection, "on_connection_close", None)
    assert _HTTPConnection_on_connection_close is not None



# Generated at 2022-06-22 15:48:43.849857
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Setup
    message = "message"

    # Action
    obj = HTTPStreamClosedError(message)

    # Assert
    assert obj.message == message
    assert str(obj) == message

# Generated at 2022-06-22 15:48:46.854492
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    client = SimpleAsyncHTTPClient()
    request = HTTPRequest("https://httpbin.org/get")
    callback = lambda x: print("this is a callback function")
    client.fetch_impl(request, callback)
