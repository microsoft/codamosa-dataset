

# Generated at 2022-06-22 15:40:58.581830
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    http_client = SimpleAsyncHTTPClient()
    http_client.close()
    http_client.tcp_client.close()
    assert True

# Generated at 2022-06-22 15:40:59.240183
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    pass

# Generated at 2022-06-22 15:41:01.440791
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient

    @gen.coroutine
    def go():
        client = AsyncHTTPClient()
        r = yield client.fetch('http://www.google.com')
        return r.body



# Generated at 2022-06-22 15:41:03.521934
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Implementation of fetch_impl of class SimpleAsyncHTTPClient
    pass


# Generated at 2022-06-22 15:41:14.964162
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    future = tornado.concurrent.Future()
    response = tornado.concurrent.Future()
    io_loop = tornado.ioloop.IOLoop()
    request = tornado.httpclient.HTTPRequest(url='http://www.google.com', body=None)
    gen_log.info("Unit test for _HTTPConnection.on_connection_close")
    http_client = _HTTPClient()
    http_client.fetch(request, callback = lambda response: response)
    stream = tornado.iostream.IOStream(socket.socket(), io_loop=io_loop)
    connection = _HTTPConnection(
        stream = stream,
        request = request,
        client = http_client,
        release_callback = lambda: None,
        final_callback = None,
        io_loop = io_loop
    )

    # set the

# Generated at 2022-06-22 15:41:27.471091
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    class DummyResolver(Resolver):
        async def resolve(self, host: str, port: int) -> List[Tuple[str, int]]:
            return [("0.0.0.0", port)]
    
    # Create an Async HTTP Client
    client = AsyncHTTPClient(
        max_header_size=1024000,
        max_body_size=1024000,
        connect_timeout=5,
        request_timeout=5,
        resolver=DummyResolver()
    )
    io_loop = IOLoop.current()
    stream = IOStream(socket.socket(), io_loop=io_loop)

    # Constructor of _HTTPConnection
    http_connection = _HTTPConnection(client, io_loop, stream, "localhost", 8080, None)

    # Unit test for method _create_

# Generated at 2022-06-22 15:41:35.099729
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    request = HTTPRequest(url="www.example.com")
    http_client = HTTPClient()
    connection = _HTTPConnection(
        http_client, request,
        final_callback=lambda x: None, release_callback=lambda: None
    )
    connection._handle_exception = lambda *args: False
    with mock.patch.object(connection.stream, "close") as mocked_close:
        connection.on_connection_close()
        mocked_close.assert_called_once_with()

# Generated at 2022-06-22 15:41:38.863051
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    # given
    err: HTTPTimeoutError = HTTPTimeoutError('hi')
    # when
    s: str = err.__str__()
    # then
    assert s == err.message or "Timeout"



# Generated at 2022-06-22 15:41:51.908672
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    import io
    import sys
    import unittest
    import zlib

    try:
        import ssl
    except ImportError:
        ssl = None

    from tornado.concurrent import Future
    from tornado.httputil import HTTPServerRequest
    from tornado.testing import AsyncHTTPTestCase, AsyncTestCase, ExpectLog, gen_test
    from tornado.test.util import unittest

    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler
    from tornado import gen

    from tornado.netutil import Resolver

    def ws_test_server(ws_handler):
        class WSTestHandler(WebSocketHandler):
            def check_origin(self, origin):
                return True

            def open(self):
                pass


# Generated at 2022-06-22 15:41:59.923078
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado.testing import AsyncHTTPTestCase, ExpectLog, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.httputil import HTTPHeaders
    import sys
    import socket

    def check_header_and_body(response: HTTPResponse, check_body: bool = False) -> None:
        print(response.headers)
        print(response.error)

    class HelloHandler(RequestHandler):
        def get(self):
            print(self.request)
            print(self.request.headers)
            self.set_status(202)
            self.write("hello")

    class HelloProxy(RequestHandler):
        def get(self):
            print(self.request)
            print(self.request.headers)
            self.set_status(202)
            self.write("hello")