

# Generated at 2022-06-22 15:40:55.207316
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.httpserver import HTTPServer

    from tornado.httpclient import HTTPRequest, AsyncHTTPClient, HTTPError
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_sockets
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port

    class HelloWorldRequestHandler(RequestHandler):
        def get(self):
            self.write('Hello world!')

    class MyTestCase(AsyncHTTPTestCase):
        def get_app(self):
            return Application([('/', HelloWorldRequestHandler)])

        def test_simple(self):
            response = self.fetch('/')
            self.assertEqual(response.code, 200)
            self.assertEqual(response.body, b'Hello world!')


# Generated at 2022-06-22 15:41:08.985618
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import unittest.mock as mock

    def make_mock_response(
        status_code: int = 200,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[bytes] = None,
        reason: Optional[str] = None,
        effective_url: Optional[str] = None,
    ) -> HTTPResponse:
        return HTTPResponse(
            mock.MagicMock(spec=HTTPRequest),
            status_code,
            reason=reason,
            headers=Headers(headers or {}),
            body=body,
            effective_url=effective_url,
        )


# Generated at 2022-06-22 15:41:21.602606
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    """Test if method close of class SimpleAsyncHTTPClient works properly
    """

    # mock the IOLoop
    class IOLoopMock(object):

        def __init__(self):
            pass

        def close(self):
            pass

    ioloop_mock = IOLoopMock()
    ioloop_mock.time = time.time

    # mock the TCPClient
    class TCPClientMock(object):

        def __init__(self):
            pass

        def close(self):
            pass

    tcp_client_mock = TCPClientMock()

    # mock the Resolver
    class ResolverMock(object):

        def __init__(self):
            pass

        def close(self):
            pass

    resolver_mock = ResolverMock()

    # instantiate the As

# Generated at 2022-06-22 15:41:26.185619
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Test if _HTTPConnection helper class is handled well
    request = HTTPRequest('','')
    callback = lambda x: print(x)
    conn = _HTTPConnection(request=request,
                           headers_received=callback,
                           release_callback=callback)
    conn.headers_received('', '')
    assert True

# Generated at 2022-06-22 15:41:32.881993
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    import tornado.ioloop
    from tornado.iostream import IOStream
    from tornado.iostream import SSLIOStream
    from tornado.tcpclient import TCPClient
    from tornado.tcpserver import TCPServer
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.http1connection import HTTP1Connection
    from tornado import platform
    import socket
    import ssl
    import re
    import unittest
    import unittest.mock
    import weakref
    import functools
    import asyncio



# Generated at 2022-06-22 15:41:40.868432
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.escape import utf8
    # Make a GET request.
    response = yield AsyncHTTPClient().fetch("http://www.google.com/")
    assert response.code == 200
    assert response.headers['Content-Type'] == 'text/html; charset=ISO-8859-1'
    assert utf8(b'<title>') in response.body
test__HTTPConnection_data_received()

# Generated at 2022-06-22 15:41:53.769311
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado.http1connection import _JsonDecoder
    from tornado.http1connection import _HTTPConnection
    from tornado.http1connection import _HTTPConnectionParameters
    from tornado.iostream import IOStream
    import tornado
    import io
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    import socket
    import ssl
    loop = tornado.ioloop.IOLoop.current()

# Generated at 2022-06-22 15:41:54.847979
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass


# Generated at 2022-06-22 15:41:57.101631
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    http = HTTPClient()
    fetch = http.fetch('http://www.google.com/', method="GET")
    print(fetch)


# Generated at 2022-06-22 15:41:58.272414
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():

    def _go(self, *args, **kwargs):
        pass



# Generated at 2022-06-22 15:42:31.744338
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    ...

# Generated at 2022-06-22 15:42:33.668353
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simpleasynchttpclient = SimpleAsyncHTTPClient()
    simpleasynchttpclient.close()
    pass


# Generated at 2022-06-22 15:42:34.930123
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    client = SimpleAsyncHTTPClient()
    req = HTTPRequest("http://localhost:9999/hello")
    resp = client._fetch_impl(req, raise_error=True)

# Generated at 2022-06-22 15:42:45.096520
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    import tornado.httpclient
    import logging
    # Test HTTP client.
    # Test default max_clients.
    a = AsyncHTTPClient()
    assert a.max_clients == 10

    # Test client construction with max_clients.
    a = AsyncHTTPClient(max_clients=42)
    assert a.max_clients == 42

    # Test client with resolver.
    a = AsyncHTTPClient(resolver=tornado.netutil.Resolver())

    # Test client with hostname_mapping.
    a = AsyncHTTPClient(hostname_mapping={'yelp.com': '127.0.0.1'})

    # Test client with max_clients and hostname_mapping.

# Generated at 2022-06-22 15:42:46.990141
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from nbclient.httpclient import _HTTPConnection
    from tornado.ioloop import IOLoop
    ioloop = IOLoop()
    a = _HTTPConnection(lambda: None, None, None, 8888)
    a.on_connection_close()


# Generated at 2022-06-22 15:42:49.223106
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    inst = SimpleAsyncHTTPClient()
    assert isinstance(inst, AsyncHTTPClient)
    assert isinstance(inst, HTTPClient)
    assert inst.close() is None
    assert isinstance(inst, AsyncHTTPClient)
    assert isinstance(inst, HTTPClient)



# Generated at 2022-06-22 15:42:51.732118
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    url = "http://example.com/"
    request = HTTPRequest(url)
    client = HTTPClient()
    final_callback = lambda response: response
    connection = _HTTPConnection(
        client, request, final_callback, client.io_loop
    )
    res = connection.data_received(b'sample data')
    assert res is None

# Generated at 2022-06-22 15:42:52.385739
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass


# Generated at 2022-06-22 15:42:59.477974
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado import escape
    from tornado import httpclient
    from tornado import httputil

    class MockAsyncHTTPClient(SimpleAsyncHTTPClient):
        def __init__(self):
            self.requests = []
            super().__init__()

        def _handle_request(self, request, release_callback, final_callback):
            self.requests.append(request)

    class MockResponse(object):
        def __init__(self, code, body):
            self.code = code
            self.body = body
            self.time_info = {}
            self.error = None
            self.request = None

    def mock_fetch(url):
        if url == "http://localhost/1":
            return MockResponse(200, "hello")

# Generated at 2022-06-22 15:43:09.246158
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # __main__.HTTPClient client, object first_line, object headers
    # object __main__._HTTPConnection mock_self = <__main__._HTTPConnection object at 0x0000000003EBBD30>
    # object httputil.ResponseStartLine first_line = ResponseStartLine(code=200, reason='OK')
    # object httputil.HTTPHeaders headers = HTTPHeaders({'Date': 'Wed, 16 Oct 2019 21:21:54 GMT', 'Content-Type': 'text/html', 'Transfer-Encoding': 'chunked', 'Connection': 'close', 'Server': 'Python/3.7 aiohttp/3.5.4'})
    return None


# Generated at 2022-06-22 15:44:19.651207
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    class MockStream(object):
        def set_close_callback(self, callback):
            pass

        def read_until_close(self, callback, streaming_callback):
            pass

    url = "http://example.com/foo"
    request = HTTPRequest(url)
    _http_client = AsyncHTTPClient()  # type: ignore
    _http_client.fetch(request)
    conn = _HTTPConnection(
        client=_http_client,
        request=request,
        stream=MockStream(),
        final_callback=None,
        start_time=None,
        timeout_time=None,
        release_callback=None,
    )
    first_line = httputil.ResponseStartLine("GET", url, "")
    headers = httputil.HTTPHeaders({"Location": "/"})


# Generated at 2022-06-22 15:44:20.263308
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__(): pass



# Generated at 2022-06-22 15:44:20.770637
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass


# Generated at 2022-06-22 15:44:24.527389
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    data = {'message': 'Hello, world'}
    response = Mock()
    response.body = json.dumps(data).encode("utf8")
    response.code = 200

    http_client = Mock()
    http_client.fetch = Mock(return_value=response)

    # Run the test against this function
    @gen.coroutine
    def f():
        client = SimpleAsyncHTTPClient()
        yield client.fetch("http://friendfeed.com/", method="POST")

    # Run the client
    gen.run_test(f)

    # Check the response
    http_client.fetch.assert_called_with("http://friendfeed.com/", method="POST")
    assert data == json.loads(response.body.decode())



# Generated at 2022-06-22 15:44:28.320315
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    async_http_client = SimpleAsyncHTTPClient()
    async_http_client.close()

    class FakeTcpClient(object):
        def close(self):
            pass

    async_http_client.tcp_client = FakeTcpClient()
    async_http_client.close()



# Generated at 2022-06-22 15:44:29.592837
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-22 15:44:34.274043
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # mock the instance
    client = SimpleAsyncHTTPClient()
    # request = HTTPRequest()
    # callback = Callable[[HTTPResponse], None]
    request = "request"
    callback = "callback"
    client.fetch_impl(request, callback)



# Generated at 2022-06-22 15:44:43.238019
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web

    class HelloHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("hello world")

    class SimpleIOLoop(tornado.ioloop.IOLoop):
        def initialize(self, impl: "tornado.platform.asyncio.AsyncIOMainLoop") -> None:
            self.asyncio_loop = impl.asyncio_loop

    class AsyncIOMainLoop(tornado.platform.asyncio.AsyncIOMainLoop):
        def initialize(
            self, io_loop: Optional["tornado.ioloop.IOLoop"] = None, **kwargs: Any
        ) -> None:
            self.io_loop = io_loop

# Generated at 2022-06-22 15:44:44.513369
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert HTTPStreamClosedError().__str__() == "Stream closed"


# Generated at 2022-06-22 15:44:51.195165
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    request = HTTPRequest(
        method='GET',
        url='https://127.0.0.1:8080/',
    )
    http_client = AsyncHTTPClient()
    response = http_client.fetch(request)
    assert isinstance(response, HTTPResponse)
    assert response.code == 200
    assert response.body == b'Hello world!'


# Generated at 2022-06-22 15:49:29.411274
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection.test__HTTPConnection_run()

# Generated at 2022-06-22 15:49:38.829103
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    """
    Test _HTTPConnection.run with httpbin.org as destination.

    """
    # Create request and response objects
    request = HTTPRequest(url='http://httpbin.org/get')
    response = HTTPResponse(request, 200, reason="OK", headers=None, request_time=1.0, start_time=2.0, buffer=BytesIO(b""), effective_url="http://httpbin.org/get")
    # Create a _HTTPConnection instance
    http_client = AsyncHTTPClient()
    stream = HTTP1Connection(http_client.stream, True, HTTP1ConnectionParameters(False, 8192, 8192, False), None)

# Generated at 2022-06-22 15:49:49.838046
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    """_HTTPConnection.finish"""
    from tornado.httputil import HTTPServerRequest
    from tornado.simple_httpclient import _HTTPConnection
    from tornado.testing import AsyncHTTPTestCase, AsyncHTTPSTestCase, bind_unused_port
    import socket
    import tornado.netutil

    class DummyHTTPConnection(object):
        def __init__(self, connection: "_HTTPConnection") -> None:
            self.connection = connection

    class DummyHTTPStream(object):
        def __init__(self, connection: "_HTTPConnection") -> None:
            self.connection = connection

        def close(self) -> None:
            pass


# Generated at 2022-06-22 15:49:55.876955
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    """Unit test for method run of class _HTTPConnection."""
    mock_response_code = mock.Mock()
    mock_response_code.return_value = 200
    mock_body = mock.Mock()
    mock_body.return_value = "YWJjMTIzIT8kKiYoKSctPUB+"
    mock_headers = mock.Mock()
    mock_headers.return_value = "YWJjMTIzIT8kKiYoKSctPUB+"
    mock_request = mock.Mock()
    mock_request.return_value.headers = {"Accept": "YWJjMTIzIT8kKiYoKSctPUB+"}
    mock_request.return_value.code = mock_response_code
    mock_request.return_value.body = mock_

# Generated at 2022-06-22 15:50:05.517134
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from .httpclient import HTTPRequest, HTTPError
    from .websocket import websocket_connect
    import base64
    import socket
    import ssl
    import sys
    import types
    import unittest
    import urllib
    import uuid
    import zlib

    from tornado.escape import utf8
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import IOStream, SSLIOStream, StreamClosedError
    from tornado import netutil
    from tornado.tcpserver import TCPServer
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port
    from tornado.test.util import unittest, skipOnTravis
    from tornado.util import b, bytes_type, import_object, raise_exc_info