

# Generated at 2022-06-24 09:09:40.810873
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # type: ()-> None
    class SimpleAsyncHTTPClientImpl(SimpleAsyncHTTPClient):
        pass

    client = SimpleAsyncHTTPClientImpl(io_loop=IOLoop())
    assert isinstance(client, SimpleAsyncHTTPClient)
    assert isinstance(client, AsyncHTTPClient)
    assert isinstance(client.tcp_client, TCPClient)
    assert client.conn_params.max_header_size == httputil.DEFAULT_MAX_HEADER_SIZE
    assert client.max_buffer_size == 104857600
    client.close()


# This is a class for unit test only. It does not validate header at all.

# Generated at 2022-06-24 09:09:41.439221
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-24 09:09:42.800380
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert client.max_clients == 10
    assert client.queue == collections.deque()
    assert client.active == {}

# Generated at 2022-06-24 09:09:47.440042
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    err_msg = "Test message"
    exc = HTTPStreamClosedError(err_msg)
    assert str(exc) == err_msg
    assert exc.code == 599
    assert exc.message == err_msg



# Generated at 2022-06-24 09:09:52.167714
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    class DummyConnection:
        def __init__(self, request: httpclient.HTTPRequest) -> None:
            self.request = request
            self.connected = False
            self.request_closed = False
            self.closed = False
            self.expected_close = False

        def is_connected(self) -> bool:
            return self.connected

        def write_headers(self, start_line: httputil.RequestStartLine, headers: httputil.HTTPHeaders) -> None:
            pass

        def write(self, chunk: bytes) -> None:
            pass

        def finish(self) -> None:
            pass

        def finish_request(self) -> None:
            assert not self.request_closed
            self.request_closed = True


# Generated at 2022-06-24 09:09:52.974472
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    assert True

# Generated at 2022-06-24 09:09:53.521663
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    pass



# Generated at 2022-06-24 09:10:06.358401
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import sys
    import logging
    import functools

    # Data used to run the method
    def write(self, chunk):
        pass

    def set_nodelay(self, nodelay):
        pass

    def set_close_callback(self, callback):
        pass

    def close(self):
        pass

    # Patch for testing
    def test_patch(HTTP1Connection, _HTTPConnection):
        temp_obj = _HTTPConnection()
        temp_obj.connection = HTTP1Connection
        temp_obj.finished = False
        temp_obj.final_callback = None
        temp_obj.release_callback = functools.partial(write, None)
        temp_obj.request = object()
        temp_obj.stream = object()
        temp_obj.stream.set_nodelay = set_n

# Generated at 2022-06-24 09:10:07.256811
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    a=SimpleAsyncHTTPClient()
    a.close()

# Generated at 2022-06-24 09:10:09.514415
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass # TODO


# Generated at 2022-06-24 09:10:16.730254
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    if version.major == 5 and version.minor == 1:
        with pytest.raises(AssertionError):
            client = SimpleAsyncHTTPClient()

# Generated at 2022-06-24 09:10:28.264874
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import netutil
    from tornado import gen
    from tornado import httputil
    from tornado import iostream
    from tornado import stack_context
    result = None
    result2 = None
    result3 = None
    result4 = None
    result5 = None
    result6 = None
    def callback(future):
        result = future.result()
        if (isinstance((result), HTTPResponse)):
            self.assertEqual((result).code, 200)
        self.assertEqual((result).body, b"hello")
        self.assertEqual(result2, b"")
        self.assertEqual(result3, b"")
        self.assertEqual(result4, b"")
        self.assertEqual(result5, [])
        self.assertEqual(result6, [])


# Generated at 2022-06-24 09:10:30.311762
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    obj = HTTPStreamClosedError(message="")
    obj.__str__()



# Generated at 2022-06-24 09:10:33.430094
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error1 = HTTPStreamClosedError('Stream closed')
    assert error1.code == 599
    assert error1.message == 'Stream closed'


# Generated at 2022-06-24 09:10:34.840502
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert str(HTTPTimeoutError("t")) == "t"



# Generated at 2022-06-24 09:10:36.122570
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    client = HTTPClient()
    client._HTTPConnection(client.io_loop, None, None, None, None)

# Generated at 2022-06-24 09:10:38.477291
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    httpclient_testcase._TestHTTPClient(
        _HTTPConnection,
        support_connect=True,
        support_close_connection=True,
    ).test_data_received()

# Generated at 2022-06-24 09:10:39.029570
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-24 09:10:43.040274
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError("Stream closed")
    assert error.code == 599
    assert error.message == "Stream closed"
    assert str(error) == "Stream closed"


# Generated at 2022-06-24 09:10:48.259211
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    hsce = HTTPStreamClosedError("Stream closed")
    print(type(hsce))
    print(hsce)


# Fetch future implementing the interface of `.AsyncHTTPClient`.
# It is used by `.SimpleAsyncHTTPClient` for fetching and for tests.  It is
# not part of the public API and is subject to change without notice.

# Generated at 2022-06-24 09:10:57.032676
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert HTTPTimeoutError("Timeout").__str__() == "Timeout"

if sys.platform == "win32":
    import errno
    import msvcrt

    def set_close_exec(fd: int) -> None:
        try:
            flags = msvcrt.get_osfhandle(fd)
            flags |= os.O_CLOEXEC
            msvcrt.set_osfhandle(fd, flags)
        except (AttributeError, ValueError):
            pass

    def set_nonblocking(fd: int) -> None:
        """Sets a file descriptor to non-blocking mode."""
        import os


# Generated at 2022-06-24 09:10:58.924907
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import json
    async def async_func():
        res = await self.fetch(url)
        data = json.loads(res.body.decode())
        return data

    result = self.io_loop.run_sync(async_func)

# Generated at 2022-06-24 09:11:02.581222
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    msg = "This is a message"
    err = HTTPTimeoutError(msg)
    assert str(err) == msg


# Generated at 2022-06-24 09:11:08.521160
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():

    client = SimpleAsyncHTTPClient()
    # use of unassigned attribute
    assert client.max_clients == 10
    assert client.queue == collections.deque()
    assert client.active == {}
    assert client.waiting == {}
    assert client.max_buffer_size == 104857600
    assert client.max_header_size == max_header_size
    assert client.max_body_size == max_body_size





# Generated at 2022-06-24 09:11:11.065785
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    #
    # Create an instance of class SimpleAsyncHTTPClient and test if method close works
    #

    # Define message
    message = "Constructor should not raise exception"

    # Construct an instance of the tested class
    client = SimpleAsyncHTTPClient()
    
    # Call method / function under test
    # Note: the method does not return anything
    client.close()


# Generated at 2022-06-24 09:11:21.648952
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    tornado.ioloop.IOLoop.configure('tornado.platform.asyncio.AsyncIOLoop')
    loop = asyncio.get_event_loop()
    conn = _HTTPConnection(
        HTTPRequest(method="GET", url="http://localhost:8888", connect_timeout=0.1),
        loop,
        lambda: "")
    async def test():
        resp = conn.run()
        print(resp)
        return resp
    try:
        resp = loop.run_until_complete(test())
        assert resp.code == 599
    finally:
        loop.close()

if __name__ == "__main__":
    test__HTTPConnection_run()

# Generated at 2022-06-24 09:11:23.770113
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # ensure the client can be closed before it does anything
    client = SimpleAsyncHTTPClient()
    client.close()



# Generated at 2022-06-24 09:11:27.978903
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # request_data = 
    # request_data_len: int = 
    # chunk: bytes = 
    pass


# Generated at 2022-06-24 09:11:30.621511
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert str(HTTPTimeoutError("test")) == "test"
    assert str(HTTPTimeoutError("")) == "Timeout"
    assert HTTPTimeoutError("").code == 599



# Generated at 2022-06-24 09:11:33.919842
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    io_loop = IOLoop()
    request = HTTPRequest("GET", "http://www.baidu.com")
    conn = _HTTPConnection(request, io_loop, "localhost", 8888, None)
    assert request and isinstance(conn, _HTTPConnection)
    io_loop.close()


# Generated at 2022-06-24 09:11:36.004947
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # create SimpleAsyncHTTPClient instance
    instance = SimpleAsyncHTTPClient()
    # check it works
    instance.close()
    # check it works
    instance.close()

# Generated at 2022-06-24 09:11:36.874141
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    s = SimpleAsyncHTTPClient()



# Generated at 2022-06-24 09:11:48.487266
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():

    import unittest
    import unittest.mock as mock
    import concurrent.futures
    import random

    import tornado.testing
    import tornado.httpclient

    class TestSimpleAsyncHTTPClient(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestSimpleAsyncHTTPClient, self).setUp()
            self.tr = mock.Mock()
            # Note that responses with a 599 status code will be
            # treated as errors even if the request was successful.
            self.tr.read_until_regex.side_effect = [
                b"HTTP/1.1",
                b"HTTP/1.0 599 ",
                b"1234",
                b"\r\n",
                b"\r\n",
            ]
            self.tr.write.side_effect

# Generated at 2022-06-24 09:11:50.089100
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    with pytest.raises(Exception):
        # TODO: implement this unit test.
        assert False



# Generated at 2022-06-24 09:11:58.327088
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Tests that _HTTPConnection is initialized correctly
    max_header_size = 10
    max_body_size = 0
    decompress = True
    parameters = HTTP1ConnectionParameters(
        max_header_size=max_header_size, max_body_size=max_body_size, decompress=decompress
    )
    stream = None
    address = None
    conn = _HTTPConnection(stream, address, parameters)
    assert conn.no_keep_alive
    assert conn.max_header_size == max_header_size
    assert conn.max_body_size == max_body_size
    assert conn.decompress_response == decompress
    assert not conn.header_complete
    assert conn.header_fragment is None
    assert conn.chunk_size is None

# Generated at 2022-06-24 09:11:58.950954
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    pass



# Generated at 2022-06-24 09:12:00.554799
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    """Unit test for the constructor of class HTTPTimeoutError.
    """
    err = HTTPTimeoutError('')
    assert err.code == 599
    assert err.message == ''
    err = HTTPTimeoutError('test-message')
    assert err.code == 599
    assert err.message == 'test-message'



# Generated at 2022-06-24 09:12:02.387379
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    a = HTTPStreamClosedError("Timeout")
    assert str(a) == 'Timeout'


# Generated at 2022-06-24 09:12:03.887265
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass  # TODO: implement your test here


# Generated at 2022-06-24 09:12:11.761823
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    # constructor of class HTTPStreamClosedError
    from tornado import httpserver
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient, HTTPStreamClosedError
    from tornado import ioloop, gen
    from tornado.testing import AsyncHTTPTestCase, gen_test
    class MyHandler(httpserver.HTTPRequestHandler):
        def get(self):
            self.write("ssss")
    class MyTest(AsyncHTTPTestCase):
        def get_app(self):
            return httpserver.HTTPServer(MyHandler)    
        @gen_test
        def test_get(self):
            with self.assertRaises(HTTPStreamClosedError):
                response = yield AsyncHTTPClient().fetch("http://localhost:%d/abc" % self.get_http_port())
    MyTest().test_get()



# Generated at 2022-06-24 09:12:14.283721
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    error = HTTPStreamClosedError(None)
    assert error.__str__() == 'Stream closed'


# Generated at 2022-06-24 09:12:16.445473
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    message = "Stream closed"
    try:
        raise HTTPStreamClosedError(message)
    except HTTPStreamClosedError as e:
        assert str(e) == message



# Generated at 2022-06-24 09:12:17.042307
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-24 09:12:26.614239
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    try:
        request = None
        client = None
        final_callback = None
        error_callback = None
        connection = _HTTPConnection(
            request,
            client,
            final_callback,
            error_callback,
            user_agent=None,
            connect_timeout=20,
            request_timeout=20,
            max_header_size=None,
            max_body_size=None,
            max_buffer_size=0,
            proxy_host=None,
            proxy_port=None,
            proxy_username=None,
            proxy_password=None,
            allow_ipv6=True,
        )
        connection.finish()
    except Exception:
        print(traceback.format_exc())

# Generated at 2022-06-24 09:12:34.401437
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    request = HTTPRequest(url='http://httpbin.org/get')
    response = HTTPResponse(request, 0)
    start_line = httputil.ResponseStartLine(1, 2, 3)
    headers = httputil.HTTPHeaders()
    start = time.time()

    http = _HTTPConnection(request, start_line, headers, response, start, start)
    http.request = request
    http.code = 200
    http.reason = "OK"
    http.headers = headers

    headers_received = http.headers_received(start_line, headers)
    # assert isinstance(headers_received, Future)



# Generated at 2022-06-24 09:12:46.340115
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    http_client = AsyncHTTPClient()
    data_received_data = ["Test"]

    def callback(data):
        data_received_data.append(data)

    class HTTPRequestMock(object):
        def __init__(self, url, **kwargs):
            self.url = url
            for key, value in kwargs.items():
                setattr(self, key, value)

    http_client.headers_received(
        httputil.ResponseStartLine(200, "OK", "HTTP/1.1"),
        httputil.HTTPHeaders(),
    )
    http_client.data_received(b"Test")
    http_client.finish()

# Generated at 2022-06-24 09:12:50.028056
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    client = SimpleAsyncHTTPClient()
    assert client.defaults == {}
    defaults = {"headers": {"foo": "bar"}}
    client = SimpleAsyncHTTPClient(defaults)
    assert client.defaults == defaults



# Generated at 2022-06-24 09:12:52.823275
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("time out")
    str(e)

# 599 is a code that will never be used by an actual HTTP server,
# so we can use it to identify this fake response.
_TORNADO_EXCEPTIONS = {599: HTTPTimeoutError}

DefaultResolver = Resolver



# Generated at 2022-06-24 09:12:58.759973
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # 事前処理
    # テスト対象をインスタンス化
    client = SimpleAsyncHTTPClient()
    # テスト変数を定義
    request = HTTPRequest(connect_timeout=0.1, request_timeout=0.1)
    callback = lambda x: None
    # テスト実行
    result = client.fetch_impl(request, callback)
    # 結果検証
    # 結果検証
    assert isinstance(result, None)

# Generated at 2022-06-24 09:13:03.545834
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado import stack_context
    io_loop = stack_context.NullContext().wrap(IOLoop())
    client = SimpleAsyncHTTPClient()
    io_loop.make_current()
    io_loop.clear_instance()
    client.close()
    io_loop.close()



# Generated at 2022-06-24 09:13:12.453304
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    import random
    import io
    from tornado.httpclient import HTTPClientError, HTTPStreamClosedError

    class MyHTTPStreamClosedError(HTTPStreamClosedError):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return repr(self.value)

    def a():
        try:
            http_client_error = HTTPClientError(random.randint(1,2))
            http_stream_closed_error = HTTPStreamClosedError('did not expect to get here')
            raise MyHTTPStreamClosedError(http_client_error)
        except MyHTTPStreamClosedError as e:
            print('error type: {}'.format(type(e)))
            print('error object: {}'.format(e))

# Generated at 2022-06-24 09:13:17.790051
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    print("[TEST] test_SimpleAsyncHTTPClient_fetch_impl")
    # TODO: 生成一个简单实例:
    instance_http_client = SimpleAsyncHTTPClient()
    # TODO: 利用生成的实例调用函数fetch_impl:
    instance_http_client.fetch_impl(None, None)



# Generated at 2022-06-24 09:13:29.759727
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """test__HTTPConnection_headers_received"""
    import asyncio
    import sys

    # Create a test HTTPClient instance
    client = HTTPClient()
    # Create a test IOStream instance
    stream = asyncio.StreamReader()
    # Create a test HTTPRequest instance
    request = HTTPRequest(url="http://localhost:8080/")
    # Create a test _HTTPConnection instance
    connector = _HTTPConnection(client, stream, request, 0.5, 1024, 1024, None, None)


# Generated at 2022-06-24 09:13:36.031324
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    from tornado.test.util import unittest 
    from tornado.httpclient import HTTPStreamClosedError
    import re
    # Create an instance of the class we are testing.
    expect = 'Stream closed'
    obj = HTTPStreamClosedError(expect)
    # Run the method we are testing.
    actual = str(obj)
    # Check the result.
    assert actual == expect, f'actual: {actual}'



# Generated at 2022-06-24 09:13:39.252464
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert str(HTTPTimeoutError("Error")) == "Error"  # type: ignore

# The tag which is the "Request-Id" header.
TAG_REQUEST_ID = "tag=tornado%2Frequest_id"



# Generated at 2022-06-24 09:13:40.866061
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    from tornado.testing import gen_test, AsyncTestCase

    HTTPTimeoutError("Timeout").__str__()



# Generated at 2022-06-24 09:13:44.040877
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient
    client = AsyncHTTPClient(max_clients=1)
    client.close()
    assert True



# Generated at 2022-06-24 09:13:48.480194
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    try:
        obj = SimpleAsyncHTTPClient()
    except Exception as exception:
        # initialization of SimpleAsyncHTTPClient
        raise exception
    finally:
        # cleaning up the objects created during initialization
        try:
            del obj
        except Exception as e:
            pass



# Generated at 2022-06-24 09:13:51.977454
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("test message")
    assert error.args == (599, "test message")
    assert str(error) == "test message"



# Generated at 2022-06-24 09:13:52.580756
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    assert True == True


# Generated at 2022-06-24 09:13:57.457318
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Test that a request receives the data
    buffer = BytesIO()
    callback = lambda x: buffer.write(x)
    request = HTTPRequest("/test")
    request.streaming_callback = callback
    connection = _HTTPConnection(request, lambda: None)
    data = b"abc"
    connection.data_received(data)
    assert buffer.getvalue() == data
# Test that a request with no streaming_callback does not receive the data
    buffer = BytesIO()
    callback = lambda x: buffer.write(x)
    request = HTTPRequest("/test")
    connection = _HTTPConnection(request, lambda: None)
    connection.data_received(data)
    assert buffer.getvalue() == b""

# Generated at 2022-06-24 09:14:02.887257
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    t = HTTPTimeoutError("detail")
    assert t.code == 599
    assert t.response is None
    assert t.request is None
    assert t.message == "detail"
    assert str(t) == "detail"



# Generated at 2022-06-24 09:14:09.030567
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    client_class = _HTTPConnection
    client = client_class(
        request=None,
        final_callback=None,
        release_callback=None,
        io_loop=None,
        max_header_size=None,
        max_body_size=None,
    )
    try:
        client.run()
    except:
        pass



# Generated at 2022-06-24 09:14:10.845953
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    asyncio.get_event_loop().run_until_complete(SimpleAsyncHTTPClient().close())



# Generated at 2022-06-24 09:14:17.901798
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    con = SimpleAsyncHTTPClient()
    assert con.max_clients == 10
    assert con.queue == collections.deque()
    assert con.active == {}
    assert con.waiting == {}
    assert con.max_buffer_size == 104857600
    assert con.max_header_size is None
    assert con.max_body_size is None
    assert con.resolver is not None
    assert con.own_resolver is True
    assert con.tcp_client is not None


# Generated at 2022-06-24 09:14:24.577898
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    with pytest.raises(AssertionError):
        HTTPTimeoutError(message=1)
    with pytest.raises(AssertionError):
        assert HTTPTimeoutError(message="") is not None
    with pytest.raises(HTTPError):
        raise HTTPTimeoutError(message="")
    with pytest.raises(HTTPError):
        raise HTTPTimeoutError(message="")



# Generated at 2022-06-24 09:14:27.885500
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    err = HTTPStreamClosedError()
    err.message = "Stream closed"
    assert err.__str__() == "Stream closed"
    err.message = None
    assert err.__str__() == "Stream closed"


# Generated at 2022-06-24 09:14:30.204265
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("Timeout")
    assert "Timeout" == str(error)
    assert 599 == error.code



# Generated at 2022-06-24 09:14:34.611507
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
  try:
    h = _HTTPConnection(None, None, None, None, None, None)
    h.on_connection_close()
  except Exception as err:
    return str(err)
  return ''


# Generated at 2022-06-24 09:14:36.207727
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError()
    except HTTPTimeoutError as e:
        assert e.code == 599
        assert str(e) == "Timeout"


# Generated at 2022-06-24 09:14:38.469990
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    r = HTTPStreamClosedError(message="Stream closed")
    assert str(r) == "Stream closed"



# Generated at 2022-06-24 09:14:46.515237
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    def check_instance(obj, cls):
        assert(isinstance(obj, cls))

    resp = Mock()
    resp.code = 200
    resp.headers = httputil.HTTPHeaders()

    io_loop = IOLoop()
    io_loop.make_current()
    stream = IOStream(socket.socket(), io_loop)
    client = AsyncHTTPClient(io_loop=io_loop)

    conn = _HTTPConnection(
        client,
        resp,
        "google.com",
        443,
        stream,
        False,
        io_loop,
        start_time=time.time(),
        start_wall_time=time.time(),
        max_header_size=10000,
        max_body_size=10000,
    )


# Generated at 2022-06-24 09:14:55.612750
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    async def test_me():
        from tornado.platform.asyncio import to_asyncio_future
        from tornado.tcpserver import TCPServer
        from tornado.ioloop import IOLoop
        from tornado.platform.asyncio import to_tornado_future
        import io
        import logging
        import unittest
        import socket
        import sys

        sys.stderr = io.StringIO()
        logging.basicConfig(level=logging.DEBUG)
        io_loop = IOLoop.current()
        class Handler(object):
            def __init__(self, socket, address):
                self.socket = socket
                self.address = address

# Generated at 2022-06-24 09:14:56.211205
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-24 09:14:57.954794
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    data_received = _HTTPConnection.data_received
    self = MagicMock()
    chunk = b''
    data_received(self, chunk)
test__HTTPConnection_data_received()

# Generated at 2022-06-24 09:15:04.314839
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Error raised by SimpleAsyncHTTPClient when the underlying stream is closed.

    # When a more specific exception is available (such as `ConnectionResetError`),
    # it may be raised instead of this one.

    # For historical reasons, this is a subclass of `.HTTPClientError`
    # which simulates a response code of 599.

    # .. versionadded:: 5.1
    return



# Generated at 2022-06-24 09:15:10.058307
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    stream = mock.Mock()
    self = _HTTPConnection(
        stream, "http://example.com/foo/bar", "GET", {}, None, None, None,
        False, False, None, 10, None, None, None, None, None, None
    )
    mock_chunk = mock.Mock()
    self.data_received(mock_chunk)
    assert self.chunks == [mock_chunk]


# Generated at 2022-06-24 09:15:18.744078
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    '''
    Test for method data_received of class _HTTPConnection
    '''

    import tornado.httpclient

    # Test for using json format.
    # Get the JSON formatter class.
    try:
        # Import the module
        from tornado.log import JsonFormatter
    except:
        formatter = tornado.log.gen_log.logging.Formatter()
    else:
        # Instantiate the formatter class
        formatter = JsonFormatter()
    finally:
        import logging
        import tornado

        # Create a logger
        logger = logging.getLogger('tornado.application')

        # Create a handler which writes INFO messages or higher to the sys.stderr
        logger_handler = logging.StreamHandler()
        logger_handler.setFormatter(formatter)

# Generated at 2022-06-24 09:15:20.014544
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    return

# Generated at 2022-06-24 09:15:21.013340
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-24 09:15:22.303818
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError('foo').code == 599


# Generated at 2022-06-24 09:15:31.963724
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    obj = _HTTPConnection(None, None, None)
    obj._should_follow_redirect = mock.Mock(return_value=True)
    obj.headers = {}
    obj.code = 301
    obj.headers["Location"] = "http://2048.com/scoreboard"
    obj.request = mock.Mock()
    obj.request.method = "GET"
    obj.request.max_redirects = 1
    obj.final_callback = mock.Mock()
    obj.start_time = 0
    obj.start_wall_time = 0
    obj._on_end_request = mock.Mock()
    obj.headers = {}
    obj.headers["Location"] = "http://2048.com/scoreboard"
    obj.finish()

# Generated at 2022-06-24 09:15:42.517866
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    connect_function = Mock()
    class DummyHTTPResponse_observer:
        pass
    for (request, response) in [
        ({'url': 'http://bla.com',
        'method': 'GET'},
        HTTPResponse(request, 200, body='OK', headers={'Content-Type': 'text/plain'})),
    ]:
        httpclient = HTTPClient()

# Generated at 2022-06-24 09:15:51.462768
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import pytest
    from tornado.httpclient import _RequestProxy

    class MockRequest:
        def __init__(self, method, url, request=None):
            self.method = method
            self.url = url
            self.request = request
            self.headers = {"Host": "example.com"}
            self.max_redirects = 100
            self.follow_redirects = True

    http_conn = _HTTPConnection(io_loop=io_loop, client=client, request=None)
    http_conn.code = 200
    assert http_conn.finish() is None
    http_conn.code = 303
    req = MockRequest(method="POST", url="https://tornadoweb.org")

    req_proxy = _RequestProxy(req, "https://tornadoweb.org")

# Generated at 2022-06-24 09:16:04.493187
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Test data_received of class _HTTPConnection
    request = httpclient._RequestProxy(mock.Mock(), mock.Mock())
    response = MockHTTPResponse(request, 200, None, None, None, None)
    response.code = None
    response.request.follow_redirects = True
    response.headers = None
    response.request.max_redirects = 0
    response.request.streaming_callback = mock.Mock()
    response.chunks = None
    response.request.original_request = response.request
    with mock.patch('tornado.gen.ObjectDict') as mock_gen_ObjectDict,\
         mock.patch('tornado.httpclient.AsyncHTTPClient') as mock_AsyncHTTPClient:
        chunk = b'chunk'

# Generated at 2022-06-24 09:16:05.276818
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-24 09:16:17.267998
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    import os
    import simple_httpclient
    import tornado.ioloop
    import tornado.simple_httpclient

    # setup
    io_loop = tornado.ioloop.IOLoop.current()
    # there is a single global IOLoop that can be fetched with
    # IOLoop.current() or IOLoop.instance()
    client = tornado.simple_httpclient.SimpleAsyncHTTPClient(io_loop=io_loop)
    # The client closes itself on exit, so we need to create a new one
    # for each test.
    # AsyncHTTPClient is a shared resource, and only a single instance
    # may exist at a time, unless the force_instance=True argument is used.
    # The force_instance=True argument may be used to suppress this behavior.

# Generated at 2022-06-24 09:16:20.996168
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    try:
        HTTPClient()
        assert False
    except TypeError as e:
        assert str(e) == "__init__() missing 1 required positional argument: 'io_loop'"
    HTTPClient(None)


# Generated at 2022-06-24 09:16:29.656331
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    simple_client = SimpleAsyncHTTPClient()
    assert simple_client.max_clients == 10
    assert simple_client.max_buffer_size == 104857600

    simple_client = SimpleAsyncHTTPClient(max_clients=100)
    assert simple_client.max_clients == 100
    assert simple_client.max_buffer_size == 104857600


# Generated at 2022-06-24 09:16:34.914161
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
  from tornado import ioloop
  from tornado.httpclient import HTTPRequest, AsyncHTTPClient

  def handle_response(response):
    print('---------handle_response----------')
    print(response.request.body)
    print("code: "  + str(response.code))
    print("headers: " + str(response.headers))
    print("body: " + str(response.body))

  def test_body_callback():
    def handle_chunk(chunk):
      print("chunk: " + str(chunk))
    return handle_chunk

  url = "https://www.baidu.com/"

  request = HTTPRequest(url,
                        method='GET')

  client = AsyncHTTPClient()
  client.fetch(request, handle_response, raise_error=False)

# Generated at 2022-06-24 09:16:36.996945
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Test SimpleAsyncHTTPClient.fetch_impl
    # SimpleAsyncHTTPClient.fetch_impl(request, callback)
    pass


# Generated at 2022-06-24 09:16:44.049854
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    __tracebackhide__ = True
    # Code to execute the example.
    # Begin example
    from tornado import gen

    import tornado.httpclient

    async def main():
        client = tornado.httpclient.AsyncHTTPClient()
        request = tornado.httpclient.HTTPRequest("http://www.google.com/")
        response = await client.fetch(request)
        print(response.headers)
        print(response.body)

    tornado.ioloop.IOLoop.current().run_sync(main)



# Generated at 2022-06-24 09:16:45.819116
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Test to verify close() closes the client
    client = SimpleAsyncHTTPClient()
    client.close()
    return True

# Generated at 2022-06-24 09:16:49.012138
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    obj = SimpleAsyncHTTPClient()
    # HTTPRequest request, Callable[[HTTPResponse], None] callback
    raise NotImplementedError()


# Generated at 2022-06-24 09:17:00.095362
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    __str__ = HTTPStreamClosedError("message").__str__
    assert __str__() == "Stream closed"

if sys.platform != "win32":
    import errno
    import ssl
    import certifi
    import urllib3._collections

    _DEFAULT_CA_CERTS = certifi.where()
    _SSLCertificateError = ssl.CertificateError
else:
    import urllib3.contrib.pyopenssl

    urllib3.contrib.pyopenssl.inject_into_urllib3()
    _DEFAULT_CA_CERTS = None
    _SSLCertificateError = urllib3.exceptions.SSLError

try:
    import urllib3
except ImportError:
    urllib3 = None

_DE

# Generated at 2022-06-24 09:17:11.568630
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    client = SimpleAsyncHTTPClient()
    request = HTTPRequest(
        url="http://www.google.com",
        validate_cert=False,
    )
    connect_future = client._ResolverAdapter().resolve(request.url)
    data = connect_future.result()

    ioloop = IOLoop.current()
    sockets = AsyncIOMainLoop(ioloop)

    ssl_options = client._get_ssl_options(request.url)
    if request.proxy_host:
        raise NotImplementedError()

    # Testing for _HTTPConnection
    stream = TCPClient(
        socket_options=sockets,
        ssl_options=ssl_options,
        max_buffer_size=client.max_buffer_size,
    ).connect(data)

# Generated at 2022-06-24 09:17:13.364755
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass # TODO: write this unit test


# Generated at 2022-06-24 09:17:14.078464
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass



# Generated at 2022-06-24 09:17:14.806545
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass



# Generated at 2022-06-24 09:17:26.506601
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    stream = DummyIOStream()
    async def coro() -> None:
        pass
    test = _HTTPConnection(stream, coro, "127.0.0.1", 80)
    first_line = httputil.ResponseStartLine(200, "ok", "")
    headers = httputil.HTTPHeaders()
    test.headers_received(first_line, headers)
    assert test.code == 200
    assert test.reason == "ok"
    assert test.headers is headers

# Generated at 2022-06-24 09:17:29.777524
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():  # type: ()->None
    c = SimpleAsyncHTTPClient()
    assert isinstance(c, SimpleAsyncHTTPClient)
    print("Test Passed!")



# Generated at 2022-06-24 09:17:32.374916
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    instance1 = HTTPTimeoutError("Timeout")
    actual = str(instance1)
    expected = "Timeout"
    assert actual == expected, actual

# Generated at 2022-06-24 09:17:44.638068
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Prepare parameters
    request = HTTPRequest(url="https://www.example.com/")

    # Test with a certification file
    _HTTPConnection(request)
    _HTTPConnection(request, client_cert_path="client_cert.pem")

    # Test with a certification key
    _HTTPConnection(request, client_key=b"client_key")

    try:
        # Test with an invalid client_key
        _HTTPConnection(request, client_key=b"invalid_client_key")
        assert False, "Should have failed with an exception"
    except ValueError:
        pass

    # Test with a valid ssl.SSLContext
    context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    _HTTPConnection(request, ssl_options=context)


# Generated at 2022-06-24 09:17:58.143188
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    url = "http://localhost/example"
    # Test _HTTPConnection.finish()
    # 1. Test when redirect
    io_loop = IOLoop()
    # Test with request.follow_redirects is True
    # 1. Test when require redirect, response code is in (301, 302, 303, 307, 308)
    # 1. Test when code is in (301, 302, 303, 307, 308)
    # 1. Test when code is in [301, 302, 303, 307, 308]
    # 1. Test when code is 301
    # 1. Test when code is 302
    # 1. Test when code is 303
    # 1. Test when code is 307
    # 1. Test when code is 308
    # 2. Test when headers is not None
    # 2. Test when headers is not None
    # 3. Test when

# Generated at 2022-06-24 09:18:00.475411
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    stream_closed_error = HTTPStreamClosedError("Stream closed")
    assert str(stream_closed_error) == "Stream closed"



# Generated at 2022-06-24 09:18:09.598602
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    try:
        max_clients = 1
        hostname_mapping = {'www.weibo.com': '127.0.0.1'}
        max_buffer_size = 1024
        resolver = Resolver()
        defaults = {'body': 'hello world'}
        max_header_size = 1024
        max_body_size = 1024
        instance = SimpleAsyncHTTPClient()
        instance.initialize(max_clients=max_clients, hostname_mapping=hostname_mapping, max_buffer_size=max_buffer_size, resolver=resolver, defaults=defaults, max_header_size=max_header_size, max_body_size=max_body_size)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 09:18:22.026006
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # setup
    io_loop =  mock.Mock()
    connection = _HTTPConnection(io_loop)
    request = mock.Mock()
    request.auth_mode = None
    request.max_buffer_size = None
    request.expect_100_continue = False
    request.follow_redirects = True
    request.max_redirects = 5
    request.user_agent = "Mozilla/5.0"
    request.header_callback = None
    request.streaming_callback = None
    request.request_timeout = None
    request.validate_cert = True
    request.ca_certs = None
    request.allow_nonstandard_methods = False
    request.client_cert = None
    request.client_key = None
    request.decompress_response = False
   

# Generated at 2022-06-24 09:18:32.993343
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # verifiy that the test harness is operating
    assert 1 == 1
    # test for method fetch_impl

    # instantiate a SimpleAsyncHTTPClient object
    # first argument is max_clients which means the maximum number of concurrent requests
    # second argument is hostname_mapping which is a dictionary mapping hostnames to IP addresses and can be used to make local DNS changes when modifying system-wide settings like /etc/hosts is not possible or desirable
    # third argument is max_buffer_size which is the number of bytes that can be read into memory at once.
    # fourth argument is resolver which is an Resolver instance
    # fifth argument is defaults which is a dictionary of default values for new Request objects
    mySimpleAsyncHTTPClient = SimpleAsyncHTTPClient(10, {}, 104857600, None, None)
    assert mySimpleAsyncHTTPClient.max_clients

# Generated at 2022-06-24 09:18:40.686656
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    '''
        void finish()
    '''

    def _():
        pass

    def _():
        pass

    def _():
        pass

    def _():
        pass

    def _(response: HTTPResponse) -> None:
        assert isinstance(response, HTTPResponse)

    def _():
        pass

    import typing
    import asyncio
    from tornado.httpclient import AsyncHTTPClient
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    AsyncIOMainLoop().install()
    io_loop = asyncio.get_event_loop()


# Generated at 2022-06-24 09:18:52.616718
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("foo")
    assert e.code == 599
    assert str(e) == "foo"
    assert e.response is None

# test protocol constants
original_defaults = _client_ssl_defaults.copy()  # type: Dict[str, str]

if sys.version_info < (3, 2):
    if hasattr(ssl, "PROTOCOL_SSLv3"):
        _client_ssl_defaults["ssl_version"] = ssl.PROTOCOL_SSLv3

# On some versions of PyOpenSSL, ssl_options doesn't allow PROTOCOL_SSLv2 to be
# passed in, so we need to filter it out

# Generated at 2022-06-24 09:19:01.518128
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    http_con = _HTTPConnection(
        io_loop = None
        , conn = None
        , host = None
        , port = None
        , proxy_host = None
        , proxy_port = None
        , proxy_username = None
        , proxy_password = None
        , proxy_auth_mode = None
        , validate_cert = None
        , ca_certs = None
        , max_header_size = None
        , max_body_size = None
        , request = None
        , connect_timeout = None
        , read_timeout = None
        , release_callback = None
        , final_callback = None
        , streaming_callback = None
        , header_callback = None
        , conn_cache = None
        , chunk_size = None
    )
    assert http_con._should_follow_redirect

# Generated at 2022-06-24 09:19:02.814442
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # testing parameter: self
    pass


# Generated at 2022-06-24 09:19:03.813824
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass



# Generated at 2022-06-24 09:19:06.958158
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Test 1:
    with raised(HTTPStreamClosedError, reason="correct"):
        raise HTTPStreamClosedError()
    # Test 2:
    with raised(HTTPStreamClosedError, reason="correct"):
        raise HTTPStreamClosedError("Some message")



# Generated at 2022-06-24 09:19:12.352906
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    print("TEST test_SimpleAsyncHTTPClient_close := ", end='')
    class TestAsyncHTTPClient(SimpleAsyncHTTPClient):
        pass
    io_loop = IOLoop()
    io_loop.make_current()
    io_loop.run_sync(lambda: TestAsyncHTTPClient().close())
    print("OK")



# Generated at 2022-06-24 09:19:23.439245
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-24 09:19:33.843092
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.httpclient_test import HTTPClientCommonTestCase, AsyncTestCase
    from tornado.test.util import unittest
    from tornado.test.httpclient_test import skipOnTravis, ExpectLog
    cls = SimpleAsyncHTTPClient
    # type: ignore