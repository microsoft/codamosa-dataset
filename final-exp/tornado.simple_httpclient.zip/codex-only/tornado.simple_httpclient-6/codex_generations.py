

# Generated at 2022-06-24 09:09:31.660064
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try: raise HTTPStreamClosedError("Stream closed")
    except HTTPStreamClosedError as e: pass


# Generated at 2022-06-24 09:09:32.717361
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    cls = _HTTPConnection
    # Not implemented for this class
    return

# Generated at 2022-06-24 09:09:34.509869
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert h.__str__() == "Stream closed"



# Generated at 2022-06-24 09:09:35.584507
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass



# Generated at 2022-06-24 09:09:36.938569
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
	# should also test_should_follow_redirect
	pass 

# Generated at 2022-06-24 09:09:48.462201
# Unit test for method run of class _HTTPConnection

# Generated at 2022-06-24 09:09:50.596528
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    client_demo = HTTPClient()
    request_demo = HTTPRequest("https://www.baidu.com/",method = 'GET')
    http_connection_demo = client_demo._HTTPConnection(request_demo)
    http_connection_demo.run()


# Generated at 2022-06-24 09:09:59.471492
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("Test timeout")
    assert error.code == 599
    assert str(error) == "Test timeout"

# Type alias for the three types of callback
# Type of the callback
CallbackType = Callable[[Union[HTTPResponse, Exception]], None]
# Type of the the error callback
ErrorCallbackType = Callable[[Exception], None]
# Type of the the streaming callback; used with streaming_callback
StreamCallbackType = Callable[[bytes], None]

_DEFAULT_CA_CERTS = None
_DEFAULT_CLIENT_KEY = None
_DEFAULT_CLIENT_CERT = None


# Generated at 2022-06-24 09:10:00.839427
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    assert SimpleAsyncHTTPClient()



# Generated at 2022-06-24 09:10:10.712132
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import unittest
    import mock as mock
    import tornado.iostream as iostream
    import tornado.tcpclient as tcpclient
    import tornado.ioloop as ioloop

    class UnitTest(unittest.TestCase):

        def test_HTTPConnection(self):
            io_loop = ioloop.IOLoop.current()

            possible_addresses_sequence = [
                [("127.0.0.1", "8080")],
                [("127.0.0.1", "8081")],
            ]
            mock_tcpclient_instance = mock.Mock()
            mock_tcpclient_instance.connect.side_effect = possible_addresses_sequence
            with mock.patch.object(tcpclient, 'TCPClient') as mock_tcpclient:
                mock_tcp

# Generated at 2022-06-24 09:10:16.544321
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    stream = IOStream()
    headers = httputil.HTTPHeaders()
    start_line = httputil.ResponseStartLine("GET", "/path", "HTTP/1.1")
    connection = _HTTPConnection(stream)
    connection.headers_received(start_line, headers)
    assert connection.chunks == []
    # noinspection PyUnusedLocal
    def streaming_callback(chunk: bytes) -> None:
        pass
    connection.request.streaming_callback = streaming_callback
    connection.data_received(b'Hello')
    # noinspection PyTypeChecker
    connection.data_received(b'World')
    assert connection.chunks == []
    # noinspection PyTypeChecker
    connection.data_received(b'')
    assert connection.chunks == []



# Generated at 2022-06-24 09:10:20.811599
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    req = HTTPRequest(url='http://www.res.com', method='GET')
    conn = _HTTPConnection(req, None, None, None)
    conn.on_connection_close()
    assert conn.final_callback is None



# Generated at 2022-06-24 09:10:30.401845
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    c = _HTTPConnection(None)  # type: ignore
    assert c.max_header_size == _DEFAULT_MAX_HEADER_SIZE
    assert c.max_body_size == 10000
    assert not c.decompress
    assert not c.no_keep_alive
    assert c.ipv6

    c = _HTTPConnection(None, max_header_size=2, max_body_size=3, decompress=True)
    assert c.max_header_size == 2
    assert c.max_body_size == 3
    assert c.decompress

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 09:10:32.230083
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    conn_obj = _HTTPConnection(HTTPRequest('https://httpbin.org/ip'))
    assert conn_obj.max_header_size == 65536

# Generated at 2022-06-24 09:10:40.663603
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # default value
    e = HTTPStreamClosedError()
    assert isinstance(e, HTTPStreamClosedError)
    assert isinstance(e, HTTPError)
    assert str(e) == "Stream closed"
    assert e.message is None
    assert e.status_code == 599
    assert e.reason == "Stream closed"
    assert e.response is None
    assert e.response_time is None
    # specified value
    e = HTTPStreamClosedError("message")
    assert isinstance(e, HTTPStreamClosedError)
    assert isinstance(e, HTTPError)
    assert str(e) == "message"
    assert e.message == "message"
    assert e.status_code == 599
    assert e.reason == "message"
    assert e.response is None
    assert e.response_time

# Generated at 2022-06-24 09:10:50.740009
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    #call method _HTTPConnection.headers_received
    http_client = AsyncHTTPClient()
    parsed = urllib.parse.urlparse("https://www.baidu.com")
    request = HTTPRequest("https://www.baidu.com")
    conn = http_client._HTTPConnection(request, parsed, "", "", "", "")
    first_line = ResponseStartLine("HTTP/1.1", 200, 'OK')
    headers = HTTPHeaders({'Content-Type': 'text/html'})
    # TODO: headers_received(self, first_line, headers)
    # conn.headers_received(first_line, headers)



# Generated at 2022-06-24 09:10:52.962063
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError('a message')
    assert 'a message' == str(error)
    assert 599 == error.code



# Generated at 2022-06-24 09:10:58.256479
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    async def setup(client: HTTPClient):
        """
        Create a mocked client, and a mocked response.
        """
        class MockStream:
            def __init__(self):
                self.socket = MockSocket()

            def close(self):
                pass

        class MockSocket(object):
            def getsockname(self):
                return "127.0.0.1", 888
            def settimeout(self, timeout):
                pass
            def setblocking(self, flag):
                pass
            def set_nodelay(self, flag):
                pass

        stream = MockStream()
        if client.request.method == "POST":
            request_body = b"foo=bar"
        elif client.request.method == "GET":
            request_body = None
        client.request.body = request_body


# Generated at 2022-06-24 09:11:02.378961
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert HTTPTimeoutError('str').__str__() == "str"
    assert HTTPTimeoutError('').__str__() == "Timeout"


# Generated at 2022-06-24 09:11:05.416855
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    http_client = HTTPClient()
    with pytest.raises(ValueError):
        http_client._create_request("http://www.google.com/",method="GET")


# Generated at 2022-06-24 09:11:07.443444
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    """test_HTTPTimeoutError"""
    assert HTTPTimeoutError("").code == 599 # type: ignore


# Generated at 2022-06-24 09:11:08.522236
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass

    

# Generated at 2022-06-24 09:11:16.847899
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    from tornado.escape import to_unicode
    import random
    import string
    import sys
    import types
    message = ''.join([random.choice(string.printable) for x in range(random.randint(5, 100))])
    obj = HTTPStreamClosedError(message)
    obj_str = to_unicode(obj)  # type: ignore
    assert isinstance(obj_str, str)
    assert message == obj_str
    assert obj_str == str(obj)
    assert obj_str == obj.__str__()
    return obj_str



# Generated at 2022-06-24 09:11:18.125440
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    print("test__HTTPConnection_on_connection_close()")
    # TODO write this method
    print("method not implemented, skipping test")



# Generated at 2022-06-24 09:11:20.257222
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    asyncio.set_event_loop(asyncio.new_event_loop())
    client = SimpleAsyncHTTPClient()


# Generated at 2022-06-24 09:11:28.369122
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    assert HTTPTimeoutError.__init__.__annotations__ \
        == dict(  # type: ignore
            message=str,
        )
    assert HTTPTimeoutError.__str__.__annotations__ == dict()
    assert HTTPTimeoutError().__class__ == HTTPTimeoutError
    assert str(HTTPTimeoutError('foo')) == 'foo'
    assert str(HTTPTimeoutError(None)) == 'Timeout'


STREAM_CHUNK_SIZE = 65536



# Generated at 2022-06-24 09:11:32.078402
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """Unit test for _HTTPConnection.headers_received"""
    first_line_value = "HTTP/1.1 200 OK"
    headers_value = None
    self = _HTTPConnection(None, None, None)
    self.headers_received(first_line_value, headers_value)




# Generated at 2022-06-24 09:11:34.233959
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    start_time = end_time = 1
    result = _HTTPConnection(start_time, end_time).run()
    assert result is None
import sys

# Generated at 2022-06-24 09:11:41.460961
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    r = Mock()
    r.url = "html"
    o = Mock()
    o.url = "html"
    r.original_request = o
    r.method = "GET"
    r.max_redirects = 1
    h = Mock()
    h.get.return_value = True
    response = HTTPResponse(
        r,
        301,
        reason=getattr(h, "reason", None),
        headers=h,
        request_time=0.001,
        start_time=0.002,
        buffer=BytesIO(b"a"),
        effective_url="html",
    )
    c = Mock()
    c.fetch.return_value = response
    t = Mock()
    t.add_done_callback.return_value = None
    f = Mock

# Generated at 2022-06-24 09:11:44.357663
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    x = HTTPTimeoutError("msg")
    str(x)



# Generated at 2022-06-24 09:11:52.286169
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    '''
        def initialize(  # type: ignore
        self,
        max_clients: int = 10,
        hostname_mapping: Optional[Dict[str, str]] = None,
        max_buffer_size: int = 104857600,
        resolver: Optional[Resolver] = None,
        defaults: Optional[Dict[str, Any]] = None,
    ) -> None:
    '''
    _instance = SimpleAsyncHTTPClient()
    assert isinstance(_instance, SimpleAsyncHTTPClient)


# Generated at 2022-06-24 09:11:54.918905
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    obj = HTTPStreamClosedError()
    assert str(obj) == 'Stream closed'
    obj = HTTPStreamClosedError(message="message")
    assert str(obj) == 'message'



# Generated at 2022-06-24 09:12:05.591079
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    good_url = 'http://localhost:5000/'
    bad_url = 'http://localhost:5100/'
    html_body = '<b>Hello World</b>'

    class MyHandler(RequestHandler):
        @gen.coroutine
        def get(self):
            self.write(html_body)

    app = Application([('/', MyHandler)])

    # test on a good url
    server = HTTPServer(app)
    server.listen(5000)

    io_loop = IOLoop.current()

    #c = _HTTPConnection(io_loop, good_url, method='GET')
    #c.run()

    io_loop.run_sync(lambda: _HTTPConnection(io_loop, good_url, method='GET'))



# Generated at 2022-06-24 09:12:09.821968
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    print("\ntest_HTTPTimeoutError")
    # Test __str__ method of class HTTPTimeoutError
    err = HTTPTimeoutError("test timeout")
    print("err:", err)
#test_HTTPTimeoutError___str__()



# Generated at 2022-06-24 09:12:16.702626
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("Timeout")
    except HTTPError as e:
        assert e
        assert e.code == 599
        assert e.response == None
    try:
        raise HTTPTimeoutError("Timeout", request=HTTPRequest("/foo"))
    except HTTPError as e:
        assert e
        assert e.code == 599
        assert isinstance(e.request, HTTPRequest)
        assert e.request.url == "/foo"
        assert e.response == None


# Generated at 2022-06-24 09:12:17.692038
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass



# Generated at 2022-06-24 09:12:18.621874
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass



# Generated at 2022-06-24 09:12:29.344769
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    chunk = '11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111'
    response = HTTPResponse()
    class _Test(object):
        def _remove_timeout(self):
            pass
        def _run_callback(self, response):
            assert response == response

# Generated at 2022-06-24 09:12:37.521062
# Unit test for method run of class _HTTPConnection

# Generated at 2022-06-24 09:12:43.264046
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    client = SimpleAsyncHTTPClient()
    client.initialize(max_clients=1, hostname_mapping=3, max_buffer_size=1, resolver=3, defaults={}, max_header_size=3, max_body_size=2)
    assert True


# Generated at 2022-06-24 09:12:46.589973
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError("Stream closed")
    except Exception as e:
        assert e.code == 599
        assert "HTTP 599: Stream closed" == str(e)
        assert "Stream closed" == e.message



# Generated at 2022-06-24 09:12:48.842025
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    message = "test"
    exception = HTTPStreamClosedError(message)
    assert exception.message == message
    assert str(exception) == "test"


# Generated at 2022-06-24 09:12:49.766557
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():

    def __str__(self):
        pass



# Generated at 2022-06-24 09:12:52.828838
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    def func(x):
        assert x == 599
        assert type(x) is int
        return "Timeout"
    m = func
    sut = HTTPTimeoutError(message=m)
    assert sut.__str__() == "Timeout"


# Generated at 2022-06-24 09:12:56.662707
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    HTTPStreamClosedError_instance = HTTPStreamClosedError(message = None)
    assert HTTPStreamClosedError_instance.__str__() == 'Stream closed'


# Generated at 2022-06-24 09:12:58.986504
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("test")
    assert e.code == 599
    assert str(e) == "test"

_DEFAULT_CA_CERTS = "/etc/ssl/certs/ca-certificates.crt"



# Generated at 2022-06-24 09:13:07.668244
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    data_received(
        web.client_tests.AsyncHTTPClientTestCase.get_request("/"),
        "HTTP/1.0 200 OK\r\nHeader: foo\r\n\r\n1",
    )
    headers_received(
        web.client_tests.AsyncHTTPClientTestCase.get_request("/"),
        httputil.ResponseStartLine("HTTP/1.0", 200, "OK"),
        httputil.HTTPHeaders({"header": "foo"}),
    )
    # TODO: test data_received and headers_received's exception handling


# Tests for class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:13:10.568335
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    hsce = HTTPStreamClosedError("my error message")
    assert str(hsce) == "my error message"
    hsce2 = HTTPStreamClosedError(None)
    assert str(hsce2) == "Stream closed"



# Generated at 2022-06-24 09:13:15.118785
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    client.close() # nothing


"""HTTPConnection-based AsyncHTTPClient implementation.

This class implements an HTTP 1.1 client on top of Tornado's IOStreams.
Some features found in the curl-based AsyncHTTPClient are not yet
supported.  In particular, proxies are not supported, connections are not
reused, and callers cannot select the network interface to be used.
"""



# Generated at 2022-06-24 09:13:16.276744
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    http_connection = _HTTPConnection()
    assert http_connection is not None

# Generated at 2022-06-24 09:13:21.631161
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    cls = HTTPStreamClosedError("Stream closed")
    assert cls.code == 599
    assert cls.message == "Stream closed"
    assert isinstance(cls, HTTPError)
    assert isinstance(cls, Exception)



# Generated at 2022-06-24 09:13:24.391034
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    """Test for initialize for SimpleAsyncHTTPClient"""
    client = SimpleAsyncHTTPClient()

# Generated at 2022-06-24 09:13:34.483416
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    def test():
        from tornado.testing import gen_test
        from tornado.httpclient import AsyncHTTPClient
        from tornado.test.httpclient_test import HTTPClientCommonTestCase, get_unused_port
        import socket
        import ssl
        import sys
        import unittest
        import uber_rides.session
        import uber_rides.client
        import urllib.parse
        
        if sys.version_info[0] == 3:
            unittest.TestCase.assertRaisesRegex = unittest.TestCase.assertRaisesRegexp
        
        # test closing a simple async http client
        # reset state in case we're running repeated tests (like with autoreload)
        uber_rides.session._config.clear()
        
        # use a local ssl server for testing
        test

# Generated at 2022-06-24 09:13:35.158980
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    headers_received(Request, Response)

# Generated at 2022-06-24 09:13:43.871356
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    conn = _HTTPConnection()
    assert conn.code == None
    conn.code = 200
    conn.request.original_request = "request"
    conn.final_callback = True
    assert conn.chunks == []
    assert conn.request.method == "POST"
    assert conn.request.max_redirects == None
    conn.finish()
    assert conn.url == "http://www.google.com"
    assert conn.io_loop.time() == 1536372321.419116
    assert conn.headers is None
    assert conn.code == 200
    assert conn.start_wall_time == 1536372321.417095
    assert conn.request.allow_nonstandard_methods == False
    assert conn.request.validate_cert == True

# Generated at 2022-06-24 09:13:45.021702
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():

    # _HTTPConnection.run
    assert True

# Generated at 2022-06-24 09:13:56.215398
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from tornado.httputil import _RequestProxy

    conn = _HTTPConnection(None, None, None, None, None, None, None)
    conn.code = None
    conn.request.follow_redirects = True
    conn.request.max_redirects = None
    conn.request.original_request = None
    conn.request.url = "http://127.0.0.1:8000"
    conn.request.method = "GET"
    conn.request.body = None
    conn.request.headers = {"Host": "127.0.0.1:8000"}
    conn.headers = {"Location": "http://127.0.0.1:8000/foo"}
    conn.final_callback = None

    msg = "Expected assertion error: Cannot have `max_redirects` be None"

# Generated at 2022-06-24 09:13:58.104268
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    io_loop = IOLoop()
    io_loop.make_current()
    io_loop.run_sync(functools.partial(close, SimpleAsyncHTTPClient()))



# Generated at 2022-06-24 09:13:59.304084
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    e = HTTPTimeoutError("Timeout")
    s = e.__str__()
    assert s == "Timeout"



# Generated at 2022-06-24 09:14:00.510858
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass

# Generated at 2022-06-24 09:14:12.338381
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # _HTTPConnection.data_received(chunk: bytes) -> None

    import tornado
    import tornado.httpclient
    import tornado.httputil
    import tornado.iostream
    import tornado.log
    import tornado.testing
    import tornado.web
    import tornado.websocket
    from tornado.concurrent import Future
    import tornado.platform.asyncio
    import asyncio
    import concurrent
    import functools
    import logging
    import time

    async def async_test_data_received():
        # await
        web_server_port = 8888
        handler = Handler()
        server = HTTPServer(make_app())
        #server = tornado.httpserver.HTTPServer(make_app())
        #await server.listen(web_server_port)

# Generated at 2022-06-24 09:14:17.772845
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    request = HTTPRequest(url="http://example.com/")
    conn = _HTTPConnection(request, None)
    assert(conn.request == request)
    assert(conn.release_callback == None)
    assert(conn.final_callback == None)
    assert(conn.io_loop == IOLoop.current())


# Generated at 2022-06-24 09:14:23.772311
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    httpconnection = _HTTPConnection(
        _HTTPRequest('1.1', 'GET', '/', headers={}, body=''), None, None, None
    )
    assert isinstance(httpconnection.request, _HTTPRequest)
    assert httpconnection.code is None
    assert httpconnection.reason is None
    assert httpconnection.headers is None
    assert httpconnection.chunks == []

    mock_io_loop = mock.Mock()
    mock_stream = mock.Mock()
    httpconnection = _HTTPConnection(
        _HTTPRequest('1.1', 'GET', '/', headers={}, body=''),
        'www.google.com',
        mock_io_loop,
        mock_stream,
    )
    assert httpconnection.io_loop is mock_io_loop
    assert httpconnection.stream is mock_stream
   

# Generated at 2022-06-24 09:14:27.305616
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    args = (
        httputil.ResponseStartLine('HTTP/1.1','200','OK'),
        httputil.HTTPHeaders(),
    )
    obj = AsyncHTTPClient()._HTTPConnection(None, None, None, None, None)
    obj.headers_received(*args)
    return None



# Generated at 2022-06-24 09:14:35.672847
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    """Unit test for constructor of class SimpleAsyncHTTPClient."""
    instance = SimpleAsyncHTTPClient()
    assert isinstance(instance, SimpleAsyncHTTPClient)
    assert isinstance(instance.max_clients, int)
    assert isinstance(instance.queue, collections.deque)
    assert isinstance(instance.active, dict)
    assert isinstance(instance.waiting, dict)
    assert isinstance(instance.max_buffer_size, int)
    assert isinstance(instance.max_header_size, int)
    assert isinstance(instance.max_body_size, int)
    assert isinstance(instance.resolver, Resolver)
    assert isinstance(instance.own_resolver, bool)
    assert isinstance(instance.tcp_client, TCPClient)

# Generated at 2022-06-24 09:14:37.211581
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    c = _HTTPConnection(HTTPResponse())

# Generated at 2022-06-24 09:14:39.426761
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    err = HTTPTimeoutError('Timeout')
    assert err.__str__() == 'Timeout'

# Generated at 2022-06-24 09:14:42.454736
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    client = tornado.simple_httpclient.SimpleAsyncHTTPClient()
    args = tornado.testing.gen_test(
        client.fetch("http://example.com")
    )
    client.close()
    client = tornado.simple_httpclient.SimpleAsyncHTTPClient()
    assert True == False, "Test not implemented"

# Generated at 2022-06-24 09:14:44.936607
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    def _():
        a=HTTPTimeoutError("Hello")
        b=a.__str__()
        assert b=="Hello"
_()

# Generated at 2022-06-24 09:14:54.128492
# Unit test for method on_connection_close of class _HTTPConnection

# Generated at 2022-06-24 09:14:58.588906
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    try:
        assert isinstance(
            SimpleAsyncHTTPClient(
                max_clients=20, hostname_mapping={}, max_buffer_size=2048, defaults={}
            ),
            SimpleAsyncHTTPClient,
        )
    except Exception as e:
        assert False, "Constructor of class SimpleAsyncHTTPClient failed"



# Generated at 2022-06-24 09:15:04.567865
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # TODO: Need to make this work for connectionless cases too,
    # as in test_client.
    req = HTTPRequest(url="http://example.com/")
    conn = _HTTPConnection(None, req, None, None, None)
    stream = mock.Mock()
    conn.stream = stream
    conn.on_connection_close()
    stream.close.assert_called_with()

# Generated at 2022-06-24 09:15:13.829655
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    conf = {'response': {'code': '200'},
            'request': {'uri': 'http://some-uri.com'}}

# Generated at 2022-06-24 09:15:15.540118
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert isinstance(client, SimpleAsyncHTTPClient)


# Generated at 2022-06-24 09:15:18.480836
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    request = HTTPRequest('GET', 'http://example.com')
    callback = None
    client = SimpleAsyncHTTPClient(None)
    client.fetch_impl(request, callback)


# Generated at 2022-06-24 09:15:21.176805
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    io_loop = IOLoop()
    io_loop.make_current()
    client = AsyncHTTPClient(io_loop=io_loop)
    request = HTTPRequest("http://example.com")
    connection = _HTTPConnection(client, request, io_loop)
    connection.data_received(b"foo")
    io_loop.close()



# Generated at 2022-06-24 09:15:31.119753
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """
    Async HTTP client implementation.
    """

    # path to the certificate file
    cacert = os.path.join(
        os.path.dirname(__file__), "tornado", "test", "certs", "ca.crt"
    )

    # test host name
    test_host = "www.google.com"

    # test url
    url = "https://{}/".format(test_host)

    # create a connection
    stream = IOStream()
    connection = _HTTPConnection(HTTPResponse(), stream)

    # fill header and code
    headers = httputil.HTTPHeaders()
    headers.add(name="Location", value="http://example.com")
    code = 301

# Generated at 2022-06-24 09:15:37.480958
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    obj1 = HTTPStreamClosedError(None)
    obj2 = HTTPStreamClosedError('')
    obj3 = HTTPStreamClosedError('abc')
    assert obj1.__str__() == 'Stream closed'
    assert obj2.__str__() == 'Stream closed'
    assert obj3.__str__() == 'abc'


# Generated at 2022-06-24 09:15:42.212262
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError()
    except (HTTPStreamClosedError, HTTPError) as e:
        assert e.code == 599
    else:
        assert False, "HTTPStreamClosedError not raised"


# Generated at 2022-06-24 09:15:51.266193
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado.httpclient import HTTPRequest
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    loop = asyncio.get_event_loop()
    def callback(response):
        return response
    request = HTTPRequest(url='http://www.baidu.com',method='GET')
    http_client = SimpleAsyncHTTPClient()
    timeout_handle = loop.call_later(0.01,http_client._on_timeout, object(), 'in request queue')
    def on_timeout(self, key: object, info: Optional[str] = None):
        loop.remove_timeout(timeout_handle)
        if key in self.waiting:
            request, callback, timeout_handle = self.waiting[key]
            self.queue

# Generated at 2022-06-24 09:15:55.351527
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("Foo")
    except HTTPTimeoutError as e:
        assert e.__str__() == "Foo"


# Generated at 2022-06-24 09:16:06.129669
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def _test():
        # Create the mock object for class HTTP1Connection
        mock_connection = mock.Mock(spec=HTTP1Connection)
        mock_connection.stream.closed.return_value = False
        mock_connection.stream.socket.fileno.return_value = None
        # Create the mock object for class HTTPRequest
        mock_request = mock.Mock(spec=HTTPRequest)
        mock_request.body_producer = None
        mock_request.ca_certs = None
        mock_request.client_cert = None
        mock_request.client_key = None
        mock_request.auth_username = None
        mock_request.auth_mode = None
        mock_request.auth_password = None
        mock_request.prepare_curl_callback = None
        mock_request.proxy_password = None

# Generated at 2022-06-24 09:16:18.234412
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    http_client = AsyncHTTPClient()
    http_request = HTTPRequest('http://127.0.0.1:8081/my/url', method='GET')
    connection = _HTTPConnection(client=http_client, request=http_request,
                                 release_callback=None, final_callback=None,
                                 io_loop=IOLoop(), start_time=None, request_timeout=None)
    connection.stream = IOLoopStream(None)
    connection.code = 303
    connection.request = _RequestProxy(connection.request, connection.request.url)
    connection.headers = httputil.HTTPHeaders()
    connection.headers.add(
        'Location', 'http://127.0.0.1:8081/my/new/url')
    connection.chunks = [b'Some data']


# Generated at 2022-06-24 09:16:22.114859
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError(message='test message')
    except HTTPError as e:
        assert e.code == 599
        assert e.message == 'test message'
    else:
        raise AssertionError('except must catch HTTPError')


# Generated at 2022-06-24 09:16:29.687559
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    import asyncio
    import concurrent.futures
    import functools
    import logging
    import sys
    import asynctest
    import unittest

    class Resolver(asyncio.AbstractResolver):
        """Resolver that resolves everything to localhost"""

        def __init__(self, loop=None):
            self.loop = loop
            self.record_types = [
                "A",
                "AAAA",
                "CNAME",
                "MX",
                "NAPTR",
                "NS",
                "PTR",
                "SOA",
                "SRV",
                "TXT",
            ]


# Generated at 2022-06-24 09:16:37.702383
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    e = HTTPTimeoutError("timeout!")
    assert e.code == 599
    assert str(e) == "timeout!"

_DEFAULT_CA_CERTS = None  # type: str

# The ssl module was added in py26.  If we're using py25 or lower,
# use the bundled certificate authority certificates (the ones from
# Mozilla).  Note that this left out the Equifax Secure CA certificate
# which has been revoked, but it's unclear if we care.
_DEFAULT_CA_CERTS = os.path.join(os.path.dirname(__file__), "cacerts.txt")

# The CurlAsyncHTTPClient class has been moved to tornado.curl_httpclient
# for the benefit of those who need to use curl but don't want to add
#

# Generated at 2022-06-24 09:16:39.512300
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    err = HTTPTimeoutError("Timeout")
    assert str(err) == "Timeout"



# Generated at 2022-06-24 09:16:42.029262
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    h = HTTPTimeoutError("this is the message")
    assert h.code == 599
    assert h.message == "this is the message"
    assert str(h) == "this is the message"


# Generated at 2022-06-24 09:16:49.429548
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # test for __init__, _create_connection
    client = AsyncHTTPClient(io_loop=io_loop)

# Generated at 2022-06-24 09:16:56.679880
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # validate_cert=True
    connection = HTTP1Connection(
        None, True, HTTP1ConnectionParameters(), None, ssl_options=_client_ssl_defaults
    )
    assert connection.should_verify_cert

    # validate_cert=False
    connection = HTTP1Connection(
        None, False, HTTP1ConnectionParameters(), None, ssl_options=_client_ssl_defaults
    )
    assert not connection.should_verify_cert



# Generated at 2022-06-24 09:17:00.621115
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    client = httpclient.AsyncHTTPClient()
    request = httpclient.HTTPRequest("http://www.tornadoweb.org/", method='GET')
    client.fetch(request)
    #AssertionError: call_later() called in _HTTPConnection.on_connection_close(). This must be called in the event loop



# Generated at 2022-06-24 09:17:02.116070
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    err = HTTPStreamClosedError("Stream closed")
    assert err.code == 599


# Generated at 2022-06-24 09:17:04.757498
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    err = HTTPTimeoutError("my message")
# class HTTPTimeoutError


# Generated at 2022-06-24 09:17:10.815818
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    print ("Testing HTTPTimeoutError.__str__")
    x = HTTPTimeoutError("")
    y = str(x)
    print ("y: {}".format(y))
    #assert (y == "Timeout")
    x = HTTPTimeoutError("Hello World!")
    y = str(x)
    print ("y: {}".format(y))
    #assert (y == "Hello World!")

# Generated at 2022-06-24 09:17:22.269524
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # SimpleAsyncHTTPClient  Unit test for method close of class SimpleAsyncHTTPClient
    if (sys.version_info < (3, 6)):
        return
    E_SimpleAsyncHTTPClient = SimpleAsyncHTTPClient()
    E_SimpleAsyncHTTPClient.close()
    # check that is sub class of AsyncHTTPClient
    assert issubclass(SimpleAsyncHTTPClient, AsyncHTTPClient)
    # check that is an instance of AsyncHTTPClient
    assert isinstance(E_SimpleAsyncHTTPClient, AsyncHTTPClient)
    # check that is an instance of SimpleAsyncHTTPClient
    assert isinstance(E_SimpleAsyncHTTPClient, SimpleAsyncHTTPClient)
    # check that is an instance of Object
    assert isinstance(E_SimpleAsyncHTTPClient, Object)
    assert type(E_SimpleAsyncHTTPClient) is SimpleAsyncHTTPClient
    return

# Generated at 2022-06-24 09:17:24.467755
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():

    assert HTTPStreamClosedError("test").__str__() == "test"



# Generated at 2022-06-24 09:17:30.117448
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert client.max_clients == 10
    assert client.queue is not None
    assert client.active is not None
    assert client.waiting is not None
    assert client.max_buffer_size == 104857600
    assert client.max_header_size is None
    assert client.max_body_size is None



# Generated at 2022-06-24 09:17:32.946521
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("Timeout")
    assert error.status_code == 599
    assert error.message == "Timeout"


# Generated at 2022-06-24 09:17:36.167899
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError('Stream closed')
    except Exception as e:
        assert e.message == 'Stream closed'
        assert e.code == 599



# Generated at 2022-06-24 09:17:41.505325
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    io_loop = IOLoop()
    io_loop.make_current()
    stream = IOStream(socket.socket(), io_loop=io_loop)
    conn = _HTTPConnection(stream)
    assert(conn.stream == stream)
    assert(conn.io_loop == io_loop)

# Generated at 2022-06-24 09:17:43.533937
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # TODO: Add test cases
    pass


# Generated at 2022-06-24 09:17:51.580084
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # self = _HTTPConnection(object, object, object, object)
    self.final_callback = None
    self._handle_exception = mock.Mock(side_effect=None)
    self.stream.error = mock.MagicMock(side_effect=Exception())
    self.stream.close = mock.Mock(side_effect=None)
    self._HTTPConnection__on_connection_close()
    self._handle_exception.assert_called_once()

# Generated at 2022-06-24 09:18:01.550956
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Check _HTTPConnection.headers_received works as designed
    from tornado.http1connection import HTTP1Connection
    from tornado.ioloop import IOLoop
    from tornado.netutil import TCPServer
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port, gen_test
    from tornado.web import RequestHandler, Application
    from tornado.websocket import WebSocketHandler

    class HelloHandler(RequestHandler):
        @gen_test
        async def get(self):
            await self.flush()

    async def run_client(url):
        response = await SimpleAsyncHTTPClient().fetch(url)
        return response.headers["X-Foo"]


# Generated at 2022-06-24 09:18:10.573439
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import asyncio
    from tornado.testing import AsyncTestCase

    class _Test_HTTPConnection(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.stream = IOStream(socket.socket(), io_loop=self.io_loop)
            self.stream.set_close_callback(self._on_close)

# Generated at 2022-06-24 09:18:14.397470
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("a")
    assert e.code == 599
    assert e.message == "a"
    assert str(e) == "a"



# Generated at 2022-06-24 09:18:25.450921
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    tornado.testing.gen_test(
        unittest.TestCase,
        _HTTPConnection,
        body=b"Test",
        data_chunk=b"TestDataChunk",
        ssl_options=ssl.SSLContext(),
        tls_enabled=True,
        tls_max_version="TLSv1",
        tls_min_version=ssl.PROTOCOL_TLS,
        code=200,
        reason="OK",
        expected_chunk=b"TestDataChunk",
        expected_response_code=200,
        expected_response_reason="OK",
    )

# Generated at 2022-06-24 09:18:28.418662
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Instanciation of object
    obj = _HTTPConnection()
    # Call of tested method
    obj.on_connection_close()
    # Tests
    assert True == True # TODO: may fail le 04/07/2018

# Generated at 2022-06-24 09:18:29.151230
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass

# Generated at 2022-06-24 09:18:31.498610
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("Time Out")
    assert repr(error) == str(error)
    # assert repr(error) == "HTTPTimeoutError: 599 Time Out"



# Generated at 2022-06-24 09:18:33.489399
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    assert _HTTPConnection.headers_received() == "headers_received is not implemented"


# Generated at 2022-06-24 09:18:36.274951
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    from tornado.escape import to_unicode
    assert isinstance(to_unicode(HTTPTimeoutError(None)), str)
    assert isinstance(to_unicode(HTTPTimeoutError('msg')), str)


# Generated at 2022-06-24 09:18:39.693291
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert str(HTTPTimeoutError("message")) == "message"
    assert str(HTTPTimeoutError("")) == "Timeout"
    assert str(HTTPTimeoutError(None)) == "Timeout"


# Generated at 2022-06-24 09:18:51.716611
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    """Test for method finish of class _HTTPConnection"""
    self = _HTTPConnection(request, client, final_callback, self._release)
    assert self.code is not None
    data = b''.join(self.chunks)
    self._remove_timeout()
    original_request = getattr(self.request, 'original_request', self.request)
    if self._should_follow_redirect():
        assert isinstance(self.request, _RequestProxy)
        new_request = copy.copy(self.request.request)
        new_request.url = urllib.parse.urljoin(self.request.url, self.headers['Location'])
        new_request.max_redirects = self.request.max_redirects - 1
        del new_request.headers['Host']

# Generated at 2022-06-24 09:18:56.415976
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httputil import HTTPHeaders
    assert HTTPTimeoutError("").__str__() == "Timeout"
    assert HTTPTimeoutError("Hello").__str__() == "Hello"

# Generated at 2022-06-24 09:18:57.149442
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    assert True

# Generated at 2022-06-24 09:18:58.892045
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # unit test for tornado.simple_httpclient.SimpleAsyncHTTPClient.initialize
    pass

# Generated at 2022-06-24 09:19:01.585162
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    request = HTTPRequest(url="http://www.test.com")
    timeout = HTTPTimeoutError(request=request, message="test", source="test_source")
    assert timeout.message == "test"
    assert timeout.source == "test_source"
    assert timeout.request is request



# Generated at 2022-06-24 09:19:06.095748
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    obj = None
    try:
        obj = HTTPStreamClosedError("abc")
    except Exception as e:
        print("Error: ", e)
    if isinstance(obj, Exception):
        print(type(obj))
        print("Message: ", obj.message)
        print("Str: ", obj.__str__())


# Generated at 2022-06-24 09:19:16.700258
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # _HTTPConnection mock
    class _HTTPConnectionMock:
        def __init__(self):
            self.__data_received_calls = []

        def _should_follow_redirect(self):
            return False

        def _run_callback(self, first_line, headers):
            self.__data_received_calls.append({"first_line": first_line, "headers": headers})

        def data_received(self, first_line, headers):
            self._data_received(first_line, headers)

        def assert_data_received_calls_equal(self, other):
            assert len(self.__data_received_calls) == len(other.__data_received_calls)

# Generated at 2022-06-24 09:19:22.184153
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Set up mock objects
    request_args = SimpleNamespace(method="GET", url="/", follow_redirects=True, request_timeout=10)
    request_args.headers = {}
    request_args.auth_username = None
    request_args.auth_password = None
    request_args.user_agent = None
    request_args.validate_cert = True
    request_args.ca_certs = None
    request_args.allow_ipv6 = False
    request_args.client_cert = None
    request_args.body_producer = None
    request_args.streaming_callback = None
    request_args.header_callback = None
    request_args.prepare_curl_callback = None
    request_args.proxy_host = None
    request_args.proxy_port = None

# Generated at 2022-06-24 09:19:23.704601
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    data_received(self, chunk)


# Generated at 2022-06-24 09:19:25.335420
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    http_conn = _HTTPConnection()
    assert http_conn != None

# Generated at 2022-06-24 09:19:27.797742
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError("Stream closed")
    assert error.code == 599
    assert error.message == "Stream closed"



# Generated at 2022-06-24 09:19:38.418885
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    queue = (
        collections.deque()
    )  # type: Deque[Tuple[object, HTTPRequest, Callable[[HTTPResponse], None]]]
    active = (
        {}
    )  # type: Dict[object, Tuple[HTTPRequest, Callable[[HTTPResponse], None]]]
    waiting = (
        {}
    )  # type: Dict[object, Tuple[HTTPRequest, Callable[[HTTPResponse], None], object]]

    assert client.max_clients == 10
    assert client.queue == queue
    assert client.active == active
    assert client.waiting == waiting
    assert client.max_body_size == 104857600
    assert client.max_header_size is None

