

# Generated at 2022-06-24 09:09:35.143703
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    with pytest.raises(HTTPTimeoutError):
        http_client._HTTPConnection(None).on_connection_close()

# Generated at 2022-06-24 09:09:37.479194
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert str(HTTPTimeoutError("message"))=="message"
    assert str(HTTPTimeoutError(""))=="Timeout"

# class SimpleAsyncHTTPClient(AsyncHTTPClient):

# Generated at 2022-06-24 09:09:47.100270
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    c = SimpleAsyncHTTPClient()
    c = SimpleAsyncHTTPClient(max_clients=20)
    c = SimpleAsyncHTTPClient(hostname_mapping={'localhost': '127.0.0.1'})
    c = SimpleAsyncHTTPClient(max_buffer_size=2048)
    c = SimpleAsyncHTTPClient(resolver=Resolver())
    c = SimpleAsyncHTTPClient(defaults={'method': 'POST'})
    c = SimpleAsyncHTTPClient(max_header_size=8192)
    c = SimpleAsyncHTTPClient(max_body_size=4096)
    c.close()


# Generated at 2022-06-24 09:09:55.170830
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # _HTTPConnection: Called when the underlying IOStream is closed.

    # Make sure that when the connection is closed and our final_callback
    # has been called, we don't call it again.
    stream = mock.Mock()
    stream.socket.fileno.return_value = 3
    stream.error = None
    stream.closed.return_value = True
    c = _HTTPConnection(stream)
    c.final_callback = mock.Mock()
    c.on_connection_close()
    c.final_callback.assert_called_with(
        HTTPResponse(
            None,
            599,
            error=HTTPStreamClosedError("Stream closed"),
            request_time=0,
            start_time=0,
        )
    )

    # If the final_callback is None, we should get

# Generated at 2022-06-24 09:09:59.212327
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    with pytest.raises(HTTPTimeoutError) as exc_info:
        raise HTTPTimeoutError("Timeout")
    assert str(exc_info.value) == "Timeout"



# Generated at 2022-06-24 09:10:05.206117
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError(message='message test')
    except HTTPStreamClosedError as err:
        assert err.code == 599
        assert err.message == 'message test'
        assert 'HTTPStreamClosedError(message=message test)' == str(err)
        assert err.response is None



# Generated at 2022-06-24 09:10:06.223665
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass


# Generated at 2022-06-24 09:10:10.808163
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    err = HTTPStreamClosedError('I am a message.')
    assert err.code == 599
    assert err.message == 'I am a message.'
    assert str(err) == 'I am a message.'


# Generated at 2022-06-24 09:10:22.805893
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    simple_http_client = SimpleAsyncHTTPClient()
    assert simple_http_client.max_clients == 10
    assert simple_http_client.queue != []
    assert simple_http_client.active != {}
    assert simple_http_client.waiting != {}
    assert simple_http_client.max_buffer_size == 104857600

    # Test the function of closing the client, the first step is to define a new client
    simple_http_client_ = SimpleAsyncHTTPClient()
    simple_http_client_.close()
    # If the client is closed, the function of the client returns none
    assert simple_http_client_.queue == None
    assert simple_http_client_.active == None
    assert simple_http_client_.waiting == None



# Generated at 2022-06-24 09:10:32.641731
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    err = HTTPTimeoutError('asd')
    assert err.code == 599
    assert err.message == 'asd'
    assert err.response == None


if sys.platform == "win32":
    # On Windows, calling stream.read_until will never return until the
    # stream is closed, so we can't use read_until to implement read_until_close
    # and read_until_eof.  Instead we have to use the socket directly.
    def _read_to_eof(stream):
        # type: (IOStream) -> bytes
        chunk = stream.socket.recv(4096)
        if not chunk:
            return b"", True
        return chunk, False
else:
    def _read_to_eof(stream):
        # type: (IOStream) -> bytes
        return stream.read

# Generated at 2022-06-24 09:10:40.021373
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import tornado.testing
    import tornado.http1connection

    f = tornado.http1connection._HTTPConnection.headers_received
    request = MagicMock()
    request.follow_redirects = False
    request.header_callback = None
    parsed = MagicMock()
    parsed.host = "tornado.com"
    request.parsed = parsed
    request.request_timeout = None
    caller = MagicMock()
    response_start_line = MagicMock()
    response_start_line.code = 200
    headers = MagicMock()
    headers.get_all = MagicMock()
    headers.get_all.return_value = [("Cookie", "user=foo")]
    caller.headers = headers
    f(caller, response_start_line, headers)
    assert caller.code == 200

# Generated at 2022-06-24 09:10:51.827054
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import tornado
    import tornado.httpclient
    import tornado.escape
    import functools

    class _FakeClient(tornado.httpclient.HTTPClient):
        def __init__(
            self,
            io_loop: tornado.ioloop.IOLoop,
            response: tornado.httputil.HTTPResponse,
            request_time: float = 0,
        ) -> None:
            tornado.httpclient.HTTPClient.__init__(self, io_loop=io_loop)
            self._response = response
            self._request_time = request_time
            self._io_loop = io_loop

        def _on_request_callback(self, response: tornado.httputil.HTTPResponse) -> None:
            if self._response:
                self._response.rethrow()
                self.io

# Generated at 2022-06-24 09:10:52.559063
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    assert 1 == 1



# Generated at 2022-06-24 09:10:57.323534
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.netutil import bind_sockets
    from tornado.testing import AsyncHTTPTestCase, bind_unused_port
    from tornado.web import RequestHandler, Application
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-24 09:10:59.829464
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    httpclient = SimpleAsyncHTTPClient()
    pass  # todo



# Generated at 2022-06-24 09:11:00.772430
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    __tracebackhide__ = True

    # This is a placeholder for a test.
    assert True

# Generated at 2022-06-24 09:11:01.538802
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    HTTPTimeoutError("test message")


# Copy from httpclient

# Generated at 2022-06-24 09:11:04.595475
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Use the io_loop from an existing AsyncHTTPClient
    from tornado.simple_httpclient import _HTTPConnection
    conn = _HTTPConnection(AsyncHTTPClient().io_loop)
    print(conn)



# Generated at 2022-06-24 09:11:16.047046
# Unit test for method finish of class _HTTPConnection

# Generated at 2022-06-24 09:11:18.573261
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

AsciiDict = Dict[str, str]
ConnectionDelegate = Callable[[], None]
_DEFAULT_CA_CERTS = ssl.get_default_verify_paths()[0]



# Generated at 2022-06-24 09:11:19.302046
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert str(HTTPStreamClosedError("message")) == "message"


# Generated at 2022-06-24 09:11:23.197704
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Init
    A = SimpleAsyncHTTPClient()
    callback = lambda: None
    request = HTTPRequest("url")
    # Execute
    A.fetch_impl(request, callback)


# Generated at 2022-06-24 09:11:31.312556
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    http_timeout_error = HTTPTimeoutError('my message')
    assert isinstance(http_timeout_error, HTTPTimeoutError)
    # __str__ of superclass HTTPError is called
    assert str(http_timeout_error) == 'HTTP 599: my message'
    http_timeout_error_without_message = HTTPTimeoutError('')
    # __str__ of superclass HTTPError is called without message
    assert str(http_timeout_error_without_message) == 'HTTP 599'



# Generated at 2022-06-24 09:11:38.655090
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from tornado.httpclient import HTTPRequest

    parser = MockRequestParser()

    class MockHTTP1Connection(HTTP1Connection):
        def write_headers(
            self,
            start_line: httputil.RequestStartLine,
            headers: httputil.HTTPHeaders,
        ) -> None:
            pass

    request = HTTPRequest("http://localhost/")
    http_connection = _HTTPConnection(
        request,
        parser,
        MockHTTP1Connection,
        io_loop=IOLoop(),
        max_header_size=16000,
        max_body_size=16000,
        final_callback=lambda x: None,
        release_callback=lambda: None,
    )
    http_connection.code = 301

# Generated at 2022-06-24 09:11:47.581040
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    from io import StringIO
    from tornado.log import access_log, LogFormatter

    # defaults
    log_file = StringIO()
    formatter = LogFormatter()
    handler = logging.StreamHandler(log_file)
    handler.setFormatter(formatter)
    access_log.addHandler(handler)
    access_log.setLevel(logging.DEBUG)
    handler.setLevel(logging.DEBUG)

    e = HTTPTimeoutError("")
    if e.__str__() != "Timeout":
        pass
    else:
        assert False



# Generated at 2022-06-24 09:11:51.616324
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    http_client = SimpleAsyncHTTPClient()
    print(type(http_client))
    assert(isinstance(http_client, SimpleAsyncHTTPClient))
    assert(isinstance(http_client, AsyncHTTPClient))
    assert(isinstance(http_client, object))



# Generated at 2022-06-24 09:11:54.588227
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    client = HTTPClient()
    request = HTTPRequest("http://google.com")
    http_conn = HTTPClient._HTTPConnection(client, request, lambda: None, None)
    http_conn.run()

# Generated at 2022-06-24 09:11:57.401862
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    error = HTTPTimeoutError("Timeout")
    assert str(error) == "Timeout"


# Generated at 2022-06-24 09:11:58.855881
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # TODO
    print("Not implemented")


# Generated at 2022-06-24 09:12:08.667266
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    io_loop = IOLoop.current()
    io_loop.make_current()
    client = SimpleAsyncHTTPClient(io_loop=io_loop, force_instance=True)
    gen_log.info(client.closed)
    client.close()
    gen_log.info(client.closed)

    # Unit test for method fetch_impl of class SimpleAsyncHTTPClient
    def test_SimpleAsyncHTTPClient_fetch_impl():
        io_loop = IOLoop.current()
        io_loop.make_current()
        client = SimpleAsyncHTTPClient(io_loop=io_loop, force_instance=True)
        request = HTTPRequest(
            url="http://api.example.com/",
            request_timeout=60.0,
            connect_timeout=60.0
        )

# Generated at 2022-06-24 09:12:10.172603
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError()
    assert isinstance(e.__str__(), str)


# Generated at 2022-06-24 09:12:15.719028
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    ioloop = IOLoop.current()
    c = SimpleAsyncHTTPClient()
    assert c.max_clients == 10
    c = SimpleAsyncHTTPClient(max_clients=11)
    assert c.max_clients == 11
    c.close()
    ioloop.close(all_fds=True)


# Generated at 2022-06-24 09:12:16.702055
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # Dummy
    pass


# Generated at 2022-06-24 09:12:21.866860
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    _test = HTTPStreamClosedError(message="Stream closed")
    _test_repr_expected = "Stream closed"
    _test_repr_actual = repr(_test)
    assert _test_repr_actual == _test_repr_expected, "{0} != {1}".format(
        _test_repr_actual, _test_repr_expected
    )



# Generated at 2022-06-24 09:12:24.526597
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    request=HTTPRequest()
    callback={}
    a=SimpleAsyncHTTPClient()
    a.fetch_impl(request,callback)


# Generated at 2022-06-24 09:12:34.244485
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    def check_request(request: HTTPRequest):
        print(request.proxy_host)
        print(request.proxy_port)
        print(request.proxy_username)
        print(request.proxy_password)
        print(request.proxy_auth_mode)
        print(request.auth_username)
        print(request.auth_password)
        print(request.allow_nonstandard_methods)
        print(request.body)
        print(request.method)
        print(request.url)
        print(request.validate_cert)
        print(request.ca_certs)
        print(request.user_agent)
        print(request.auth_mode)
        print(request.auth_mode)
        print(request.follow_redirects)
        print(request.max_redirects)
       

# Generated at 2022-06-24 09:12:36.776825
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    """Test for method test_HTTPTimeoutError___str___."""
    assert HTTPTimeoutError("").__str__() == "Timeout"


# Generated at 2022-06-24 09:12:47.942595
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import logging
    from unittest import mock
    from typing import Iterator
    import tornado
    import tornado.iostream
    import tornado.tcpserver
    from .concurrent import Future
    from .http1connection import HTTP1Connection
    from .httputil import HTTPHeaders
    from .netutil import bind_sockets, add_accept_handler, ssl_options_to_context

    logging.basicConfig(level=logging.INFO)
    _server_sock, _ = bind_sockets(0, family=socket.AF_INET)
    _server = tornado.tcpserver.TCPServer()
    add_accept_handler(_server_sock, _server.handle_stream, None, None, IOStream)


# Generated at 2022-06-24 09:12:50.944089
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # HTTPClient.initialize(self, defaults=None, force_instance=False)
    # HTTPClient.close(self)
    # Method close of class SimpleAsyncHTTPClient
    # closed = True
    return



# Generated at 2022-06-24 09:12:52.974590
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    msg = "Timeout"
    error = HTTPTimeoutError(msg)
    assert error.code == 599
    assert error.message == msg
    assert str(error) == msg


# Generated at 2022-06-24 09:12:54.858537
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    httpStreamClosedError = HTTPStreamClosedError("Stream closed")
    assert httpStreamClosedError.code == 599
    assert httpStreamClosedError.message == "Stream closed"



# Generated at 2022-06-24 09:13:05.962136
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """_HTTPConnection.headers_received unit test."""
# Import the module under test and create a mock HTTPConnection instance

    from tornado.httpclient import _HTTPConnection


# Generated at 2022-06-24 09:13:12.048555
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    print('Test SimpleAsyncHTTPClient initialize')
    http_client = SimpleAsyncHTTPClient()
    http_client.initialize()
    assert http_client.max_clients == 10
    assert http_client.queue == collections.deque()
    assert http_client.active == {}
    assert http_client.waiting == {}
    assert http_client.max_buffer_size == 104857600
    assert http_client.max_header_size is None
    assert http_client.max_body_size is None
    http_client.close()
    print('Pass\n')


# Generated at 2022-06-24 09:13:20.231496
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import socket
    import ssl
    import sys
    import unittest
    import unittest.mock

    try:
        import curio
    except ImportError:
        curio = None

    import tornado.ioloop
    import tornado.iostream
    import tornado.netutil
    import tornado.testing
    import tornado.web

    from tornado.testing import AsyncHTTPTestCase

    io_loop = None

    class MockSocket(socket.socket):
        def __init__(self, sock):
            self._sock = sock

        def __getattr__(self, item):
            return getattr(self._sock, item)

        def makefile(self, mode, *args):
            return mock.MagicMock()


# Generated at 2022-06-24 09:13:23.485814
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():

    # create the _HTTPConnection
    # mock the stream
    # call the function to test
    
    return

# Generated at 2022-06-24 09:13:25.118270
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    raise NotImplementedError()

# Generated at 2022-06-24 09:13:29.417065
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    HTTPStreamClosedError("Stream closed").__str__()


# Generated at 2022-06-24 09:13:30.428413
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass



# Generated at 2022-06-24 09:13:40.781728
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado.escape import utf8
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.iostream import IOStream
    from tornado import testing
    import unittest
    import functools
    import socket
    import ssl
    import sys
    import tornado
    import threading

    class MockHTTPConnection(object):

        def __init__(self, client, resolver, io_loop, context=None, **kwargs):
            self.client = client
            self.resolver = resolver
            self.io_loop = tornado.ioloop.IOLoop.current()

        def close(self):
            pass


# Generated at 2022-06-24 09:13:41.332262
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass



# Generated at 2022-06-24 09:13:51.521119
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    #
    # __HTTPConnection._HTTPConnection__on_connection_close()
    #
    future = asyncio.Future()
    assert not future.done()

    class Stream:

        error = None

        def close(self) -> None:
            future.set_result(None)
            return None

    http_client = AsyncHTTPClient()
    http_client._HTTPConnection__on_connection_close(Stream())
    assert future.done()


if __name__ == "__main__":
    import logging

    logging.basicConfig(level=logging.DEBUG)
    IOLoop.current().run_sync(main)

# Generated at 2022-06-24 09:13:54.114538
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError("message").code == 599
    assert HTTPTimeoutError("message").message == "Timeout"
    assert str(HTTPTimeoutError("message")) == "Timeout"



# Generated at 2022-06-24 09:13:55.115911
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection.run()

# Generated at 2022-06-24 09:14:01.716945
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    client = AsyncHTTPClient(io_loop=IOLoop.instance())
    client._fetch_impl = _FetchImpl(client)
    response = Response()
    for _ in range(client._fetch_impl._max_clients):
        client._fetch_impl._queue.put_nowait(response)

# Generated at 2022-06-24 09:14:05.383505
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    # Create a new instance of HTTPTimeoutError
    test_HTTPTimeoutError = HTTPTimeoutError()

    # Test __str__ method
    assert test_HTTPTimeoutError.__str__() == "Timeout"


# Generated at 2022-06-24 09:14:10.424094
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    def func(self):
        return "Test for method __str__ of class HTTPStreamClosedError"
    Test = type("Test", (HTTPStreamClosedError,), {"__str__": func})
    test = Test("test")
    assert test.__str__() == "Test for method __str__ of class HTTPStreamClosedError"



# Generated at 2022-06-24 09:14:12.824915
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # AsyncHTTPClient.initialize(self, force_instance=False, defaults=None) -> None
    pass

# Generated at 2022-06-24 09:14:14.395321
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError("abc").message == "abc"


# Generated at 2022-06-24 09:14:25.009879
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    # type: () -> None
    e = HTTPStreamClosedError("test error")
    assert e.code == 599
    assert e.reason == "test error"
    e = HTTPStreamClosedError("")
    assert e.code == 599
    assert e.reason == "Stream closed"

_DEFAULT_CA_CERTS = "/etc/ssl/certs/ca-certificates.crt"

DEFAULT_MAX_CLIENT_CONNECTIONS = 512

CONNECTION_IDLE_TIMEOUT = 60.0

HTTPTimeouts = collections.namedtuple(
    "HTTPTimeouts", ("connect_timeout", "request_timeout")
)

HTTPTimeouts.__new__.__defaults__ = (20.0, 20.0)


# Generated at 2022-06-24 09:14:26.012211
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    HTTPTimeoutError('test_HTTPTimeoutError')



# Generated at 2022-06-24 09:14:28.469832
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    message = "some strange message"
    err = HTTPStreamClosedError(message)
    assert err.message == message
    assert str(err) == message


# Generated at 2022-06-24 09:14:32.684538
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Test for method initialize( ... )
    # This tests the SimpleAsyncHTTPClient.initialize() method.
    global test_SimpleAsyncHTTPClient_initialize_called
    test_SimpleAsyncHTTPClient_initialize_called = True

# Generated at 2022-06-24 09:14:37.533899
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    args = {"url": "www.google.com", "method": "GET"}
    kwargs = {"body": "asdf", "headers": {"key": "value"}, "auth_username": "bob"}
    req = HTTPRequest(**args, **kwargs)
    client = AsyncHTTPClient(force_instance=True)
    conn = _HTTPConnection(req, client, client.io_loop)
    conn.code = 200
    conn.headers = {"key": "value"}
    conn.chunks = [b"1", b"2"]
    conn.request = req
    conn.finish()
    assert conn.request.body == "asdf"
    assert conn.request.headers["key"] == "value"
    assert conn.request.auth_username == "bob"
    assert conn.code == 200
   

# Generated at 2022-06-24 09:14:41.140497
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    ioloop = tornado.ioloop.IOLoop.current()
    client = SimpleAsyncHTTPClient(io_loop=ioloop)
    req = tornado.httpclient.HTTPRequest(
        "http://www.tornadoweb.org/en/stable/",
        method="GET",
        headers={"Content-Type": "application/json"},
        body="""{"username": "test", "password": "pass"}""",
    )
    client.fetch(
        req, lambda response: ioloop.stop()
    )
    ioloop.start()

# Generated at 2022-06-24 09:14:43.284235
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    s_http_client = SimpleAsyncHTTPClient(io_loop=IOLoop())
    s_http_client.close()


# Generated at 2022-06-24 09:14:47.853334
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    hc = AsyncHTTPClient(force_instance=True)
    conn = _HTTPConnection(hc, "http://www.tornadoweb.org", 80, HTTPRequest("/"))
    print(conn.run())

# Generated at 2022-06-24 09:14:50.719742
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e=HTTPStreamClosedError("Stream closed")
    assert str(e)=="Stream closed"



# Generated at 2022-06-24 09:14:57.935734
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = httputil.ResponseStartLine("HTTP/1.1", 200, "OK")
    headers = httputil.HTTPHeaders()
    headers["Location"] = None  # type: ignore
    connection = _HTTPConnection(
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        False,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
    )
    connection.headers_received(first_line, headers)
    assert connection.code == 200



# Generated at 2022-06-24 09:14:59.706777
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    method = HTTP1Connection._HTTPConnection.data_received
    assert method is not None

# Generated at 2022-06-24 09:15:05.115861
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # Create a SimpleAsyncHTTPClient instance, by calling its constructor
    # with no arguments
    # Assert that the max_clients attribute of this instance is 10, by calling
    # its assert_equal() method and passing 10 as its argument
    assert_equal(SimpleAsyncHTTPClient().max_clients, 10)



# Generated at 2022-06-24 09:15:06.824812
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    timeout_error = SimpleAsyncHTTPClient()
    assert isinstance(timeout_error, HTTPTimeoutError)



# Generated at 2022-06-24 09:15:09.867099
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        e = HTTPStreamClosedError()
    except Exception:
        assert True
    else:
        assert False
    try:
        e = HTTPStreamClosedError("Stream closed")
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-24 09:15:18.617909
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    instance = _HTTPConnection()
    instance.code = "301"
    instance.request = _RequestProxy()
    instance.request.max_redirects = 2
    instance.request.url = ""
    instance.headers = {"Location": ""}
    instance.client = HTTPClient()
    instance.final_callback = ""
    instance.io_loop = IOLoop()
    instance.request.url = ""
    instance.chunks = []
    instance.reason = "hello"
    instance.request.request = HTTPRequest()
    instance.start_wall_time = ""
    instance.start_time = ""
    instance.request.request.method = "POST"
    instance.request.request.body = None

# Generated at 2022-06-24 09:15:27.793258
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():

    # set the instance state
    request = object()
    final_callback = object()
    _connect_future = object()
    release_callback = object()
    io_loop = object()
    max_header_size = object()
    max_body_size = object()
    release_callback = object()
    try:
        self = _HTTPConnection(request, final_callback,release_callback, io_loop, max_header_size, max_body_size,self._connect_future)
    except Exception:
        self = _HTTPConnection(request, final_callback)
    first_line = object()
    headers = object()
    # method invocation
    self.headers_received(first_line, headers)



# Generated at 2022-06-24 09:15:32.940980
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    httpConnection = _HTTPConnection('key', 'value', 10, 1)
    assert httpConnection.key == 'key'
    assert httpConnection.value == 'value'
    assert httpConnection.pending == 10
    assert httpConnection.max_pending == 1

# Generated at 2022-06-24 09:15:43.680412
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    mock_self = mock.Mock(spec=_HTTPConnection)
    mock_self.request = mock.Mock(spec=HTTPRequest)
    mock_self.request.headers = mock.Mock(spec=httputil.HTTPHeaders)
    mock_self._timeout = None
    mock_self.final_callback = None
    mock_self.release_callback = None
    mock_self.start_time = None
    mock_self.start_wall_time = None
    mock_self.io_loop = mock.Mock()
    mock_self.io_loop.time.return_value = 0
    mock_self.max_header_size = None
    mock_self.max_body_size = None
    mock_self.chunks = None
    mock_self.code = None

# Generated at 2022-06-24 09:15:51.782412
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # 
    # Test SimpleAsyncHTTPClient.initialize()
    # 
    client = SimpleAsyncHTTPClient()
    assert isinstance(client, SimpleAsyncHTTPClient), "Expected an instance of `SimpleAsyncHTTPClient`"
    assert isinstance(client, AsyncHTTPClient), "Expected an instance of `AsyncHTTPClient`"
    assert client.max_clients == 10, "Expected max_clients == 10"
    assert client.max_buffer_size == 104857600, "Expected max_buffer_size == 104857600"
    assert client.max_header_size == 100000000, "Expected max_header_size == 100000000"
    assert client.max_body_size == 100000000, "Expected max_body_size == 100000000"
    # 

# Generated at 2022-06-24 09:15:53.877010
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass


# Generated at 2022-06-24 09:15:59.415744
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import functools
    from tornado.httputil import HTTPHeaders, HTTP1ConnectionParameters, HTTP1Connection
    from tornado.iostream import IOStream
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import mock_sockname
    from tornado.test.util import unittest
    from tornado.simple_httpclient import (
        _HTTPConnection,
        HTTPError,
        HTTPRequest,
        HTTPResponse,
        _RequestProxy,
    )


    def fake_start_connecting(self, **kwargs: str) -> None:
        pass


    class FakeConnection(HTTP1Connection):
        """A version of HTTP1Connection that doesn't try to connect."""


# Generated at 2022-06-24 09:16:08.415533
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    self = _HTTPConnection(None, object, object, object, object, object, object)
    self.redo_callback = object
    self.final_callback = object
    self.code = object
    self.request = object
    self.request.follow_redirects = object
    self.request.max_redirects = object
    self.headers = object
    self.headers.get = lambda x: object
    self.headers['Location'] = object
    self.request.url = object
    self.request.method = object
    self.client = object
    self.client.fetch = lambda *args, **kwargs: object
    self.request.original_request = object
    self.final_callback = object
    self.final_callback = object
    self._release = lambda: object

# Generated at 2022-06-24 09:16:20.607786
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    class MockStream(object):
        def close(self):
            pass


# Generated at 2022-06-24 09:16:30.456000
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    stream = IOStream(socket.socket(), io_loop=IOLoop.instance())
    stream.set_close_callback(noop)
    object = _HTTPConnection(stream, None, None, None, None)
    first_line = httputil.ResponseStartLine(100, "100", "")
    headers = httputil.HTTPHeaders()
    f = object.headers_received(first_line, headers)
    IOLoop.instance().add_callback(lambda: IOLoop.instance().stop())
    IOLoop.instance().start()
    gen_testcase.assert_true(isinstance(f, Future))
    gen_testcase.assert_true(isinstance(f.result(), None))
    gen_testcase.assert_equal(object.code, 100)

# Generated at 2022-06-24 09:16:32.970231
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    exc = HTTPTimeoutError('Foo')
    assert "Foo" in str(exc)
    assert exc.code == 599


# we don't want to log these DNS failures, but we do want to log
# connection failures, which have a different error code
_CONNECT_ERRNO = 101 if version[0] >= "5" else 1



# Generated at 2022-06-24 09:16:37.040721
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    req_timeout = 10
    clnt = SimpleAsyncHTTPClient()
    clnt.close()
    try:
        clnt.fetch("http://localhost:9999/foo", request_timeout=req_timeout)
    except Exception as ex1:
        assert ex1.__str__() == "HTTP 599: Timeout"



# Generated at 2022-06-24 09:16:46.605451
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from .utils import unittest
    from . import httputil
    from . import httpclient
    from . import test
    from . import ioloop
    from . import netutil

    from .httputil import HTTPMessageDelegate
    from .iostream import IOStream
    from .iostream import StreamClosedError

    def handle_stream_failure(future):
        msg = future.exception()
        if not isinstance(msg, StreamClosedError):
            raise msg

    class TestError(Exception):
        pass

    class HTTPConnectionTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = test.make_test_loop()
            self.stream = IOStream(socket.socket(), io_loop=self.io_loop)
            self.stream.set_

# Generated at 2022-06-24 09:16:49.511150
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    # type: () -> None
    try:
        raise HTTPStreamClosedError(u'Stream closed')
    except HTTPStreamClosedError as e:
        assert e.code == 599


# Generated at 2022-06-24 09:16:55.187001
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Get an IOStream instance
    stream = _test_io_stream(io.BytesIO(b""), io.BytesIO(b""))

    # Create a HTTP1Connection instance to test
    http_connection = _HTTPConnection(stream)

    # Execute method run of class _HTTPConnection
    # TODO: support timeouts
    http_connection.run()

# Generated at 2022-06-24 09:17:01.259964
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    """Unit test for constructor of class SimpleAsyncHTTPClient"""
    try:
        httpclient = SimpleAsyncHTTPClient()
    except Exception as ex:
        assert False, \
            "Failed to create instance of SimpleAsyncHTTPClient, exception was %s" % ex
    try:
        httpclient.initialize(max_clients=10)
    except Exception as ex:
        assert False, "Failed to initialize http client, exception was %s" % ex


# Generated at 2022-06-24 09:17:03.812770
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Test case:
    # Called with no args
    def test_case1() -> None:

        # Test case: initialize
        SimpleAsyncHTTPClient().initialize()
# Test cases for class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:17:05.158347
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    x = HTTPStreamClosedError("test")
    x.__str__()


# Generated at 2022-06-24 09:17:13.152586
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    """Test for method finish of class _HTTPConnection."""
    def _stub_do_method():
        __result = None
        __exception = NotImplementedError()
        return __result, __exception, __result

    def _stub_assert_follow_redirect():
        __result = None
        __exception = NotImplementedError()
        return __result, __exception, __result

    def _stub_original_request(request):
        __result = None
        __exception = NotImplementedError()
        return request, __exception, __result

    def _stub_add_done_callback(f):
        __result = None
        __exception = NotImplementedError()
        return __result, __exception, __result

    def _stub_result(response):
        __

# Generated at 2022-06-24 09:17:24.567474
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Test that _HTTPConnection.data_received() passes data to the callbacks
    # passed to the constructor, and that they see the data in the order it's
    # received.
    chunks = []
    callback = lambda b: chunks.append(b)
    c = _HTTPConnection(
        _HTTPConnectionParameters(
            method="GET",
            host="example.com",
            port=80,
            headers=None,
            request_timeout=10,
        )
    )
    c.data_received(b"hello ")
    c.data_received(b"world")
    c.data_received(b"!")
    c.data_received(b"")
    assert chunks == [b"hello ", b"world", b"!"]



# Generated at 2022-06-24 09:17:33.759406
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    stream = StubIOStream(io_loop.IOLoop.current())
    request = HTTPRequest('', streaming_callback=None)
    connection = _HTTPConnection(stream, request)
    connection.code = 200
    connection.headers = ''
    connection.chunks = BytesIO(b'hello world')
    connection.request.url = 'www.test.com'
    connection.final_callback = lambda x: print('final callback', x)
    connection.request.original_request = request
    connection.start_time = time()
    connection.start_wall_time = time()
    connection.request.follow_redirects = True
    connection.request.max_redirects = 1
    connection.request.method = 'POST'
    connection.reason = 'success'
    connection.finish()



# Generated at 2022-06-24 09:17:45.857222
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    print("\nStart test_finish of class _HTTPConnection")
    if do1==1:
        if not isinstance(True, bool):
            raise TypeError("must provide bool, got None")
    if do2==1:
        if not isinstance(None, bool):
            raise TypeError("must provide bool, got None")
    if do3==1:
        if not isinstance("hello", bool):
            raise TypeError("must provide bool, got None")
    if do4==1:
        if not isinstance(3.4, bool):
            raise TypeError("must provide bool, got None")
    if do5==1:
        if not isinstance(1, bool):
            raise TypeError("must provide bool, got None")

# Generated at 2022-06-24 09:17:50.155558
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    def f():
        """Unit test for method __str__ of class HTTPTimeoutError"""
        HTTPTimeoutError("").__str__()
        HTTPTimeoutError("message").__str__()
    f()


# Generated at 2022-06-24 09:17:52.776961
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    a = HTTPStreamClosedError("asdasd")
    assert a.message == "asdasd"


# Generated at 2022-06-24 09:17:56.745181
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert "message" in HTTPTimeoutError.__init__.__code__.co_varnames
    error = HTTPTimeoutError(message="message")
    assert error.code == 599
    assert error.message == "message"
    assert str(error) == "message"


# Generated at 2022-06-24 09:17:59.368946
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    timeout_error = HTTPTimeoutError("Timeout")
    assert str(timeout_error) == "Timeout"



# Generated at 2022-06-24 09:18:00.412469
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass

# Generated at 2022-06-24 09:18:02.990902
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    '''Test SimpleAsyncHTTPClient.close(self)  '''
    pass



# Generated at 2022-06-24 09:18:05.919597
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # HTTPConnectionTestCase is a subclass of AsyncHTTPTestCase.
    request = httpclient.HTTPRequest(url='/path?arg=value')
    http_client = httpclient.HTTPClient()
    http_client.fetch('/', callback=check_response)

# Test for class HTTPResponse

# Generated at 2022-06-24 09:18:07.580335
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
  assert True # TODO: implement your test here


# Generated at 2022-06-24 09:18:19.967914
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    import asyncio
    loop = asyncio.get_event_loop()
    loop.run_until_complete(finish_unit_test())

async def finish_unit_test():
    # Body is empty, so we should get None
    stream = object()
    chunks = object()
    client = object()
    request = object()
    code = object()
    reason = object()
    headers = object()
    final_callback = object()
    release_callback = object()
    c = _HTTPConnection(stream, client, request, final_callback, release_callback, chunks)
    c.code = code
    c.reason = reason
    c.headers = headers

# Generated at 2022-06-24 09:18:22.610361
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # No need to test the headers_received method as it comes from the
    # IResponseStartLineDelegate protocol
    pass

# Generated at 2022-06-24 09:18:25.153805
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_http_client = SimpleAsyncHTTPClient()
    simple_async_http_client.close()



# Generated at 2022-06-24 09:18:26.563966
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    pass # TODO: construct object for test


# Generated at 2022-06-24 09:18:33.127085
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    instance = SimpleAsyncHTTPClient()
    assert isinstance(instance, SimpleAsyncHTTPClient)
    instance.close()
    assert instance._connections == {}
    assert instance._defaults == {}
    assert instance.io_loop == IOLoop.current()
    assert instance.max_clients == 10
    assert instance.resolver == Resolver()
    assert instance.tcp_client == TCPClient(resolver=instance.resolver)

# Generated at 2022-06-24 09:18:36.754706
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("Timeout")
    except HTTPTimeoutError as e:
        assert(isinstance(e, HTTPError))
        assert(e.message == "Timeout")
        assert(e.code == 599)
        assert(str(e) == "Timeout")



# Generated at 2022-06-24 09:18:39.432799
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    instance = HTTPStreamClosedError(message='')
    assert _unicode(instance) == ''

# Generated at 2022-06-24 09:18:42.964296
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Test result of HTTPStreamClosedError.__str__()
    assert HTTPStreamClosedError("message").__str__() == "message" or "Stream closed"


# Generated at 2022-06-24 09:18:54.040856
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    request = HTTPRequest(url="http://www.google.com")
    client = HTTPClient()
    response = HTTPResponse(request, 200)
    connection = _HTTPConnection(client, request)
    connection.code = response.code
    connection.reason = response.reason
    connection.headers = response.headers
    connection.chunks = [b"data"]
    original_request = getattr(request, "original_request", request)
    original_request.original_request = None
    connection.request = original_request
    final_callback = connection.final_callback = MagicMock()
    connection._release = MagicMock()
    connection.client = MagicMock()
    connection.headers = connection.headers = MagicMock(return_value=["location"])
    connection.code = 301

# Generated at 2022-06-24 09:19:04.813769
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    error = HTTPTimeoutError('message')
    assert str(error) == 'message'
    error = HTTPTimeoutError('message2')
    assert str(error) == 'message2'
    error = HTTPTimeoutError('message3')
    assert str(error) == 'message3'
    error = HTTPTimeoutError('')
    assert str(error) == ''
    error = HTTPTimeoutError('')
    assert str(error) == ''
    error = HTTPTimeoutError('')
    assert str(error) == ''
    error = HTTPTimeoutError('')
    assert str(error) == ''
    error = HTTPTimeoutError('')
    assert str(error) == ''
    error = HTTPTimeoutError('')
    assert str(error) == ''
    error = HTTPTimeoutError('')
    assert str(error) == ''

# Generated at 2022-06-24 09:19:15.981200
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    state = {}
    class _MockHTTPConnection(object):
        def __init__(self):
            self.state = state

        def data_received(self):
            self.state['data_received'] = True
            return None

        def finish(self):
            self.state['finish'] = True
            return None
    _MockHTTPConnection().finish()
    # Test callable return type
    assert type(_MockHTTPConnection().finish()) is None
    # Test return value
    assert state['finish'] is True
    assert not 'data_received' in state
    state = {}
    class _MockHTTPConnection(object):
        def __init__(self):
            self.state = state

        def data_received(self):
            self.state['data_received'] = True
            return None


# Generated at 2022-06-24 09:19:17.961759
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass


# Generated at 2022-06-24 09:19:18.700129
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-24 09:19:30.061936
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    conn = _HTTPConnection(True, None, None, None, None)
    assert conn.request.method == "GET"
    assert conn.request.url == "http://localhost/"
    assert conn.request.body is None
    assert conn.request.auth_username is None
    assert conn.request.auth_password is None
    assert conn.request.headers == httputil.HTTPHeaders()
    assert conn.request.connect_timeout == 20.0
    assert conn.request.request_timeout == 20.0
    assert conn.request.if_modified_since is None
    assert conn.request.follow_redirects is True
    assert conn.request.max_redirects is None
    assert conn.request.user_agent is None
    assert conn.request.use_gzip is True
    assert conn.request.network_interface

# Generated at 2022-06-24 09:19:33.268715
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    exc = HTTPStreamClosedError(message="Stream closed")
    assert exc.code == 599
    assert exc.message == "Stream closed"
    assert str(exc) == "Stream closed"

_DEFAULT_CA_CERTS = None

