

# Generated at 2022-06-24 09:09:38.731489
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def on_response(response):
        self.stop(response)

    client = HTTPClient()
    try:
        response = client.fetch("http://www.google.com/", on_response)
    except HTTPClientError as e:
        self.fail("HTTP error: %s" % e)

    self.wait()
    self.assertEqual(response.code, 200)
    self.assertEqual(response.body, b"")
    self.assertTrue(response.effective_url, "http://www.google.com/")
    self.assertEqual(response.request_time, 0)

    try:
        response = client.fetch("http://www.google.com/")
    except HTTPClientError as e:
        self.fail("HTTP error: %s" % e)

# Generated at 2022-06-24 09:09:43.883897
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    class request:
        class original_request:
            url = None
            class headers:
                def get(this) -> None:
                    return None
            follow_redirects = None
            max_redirects = None
        streaming_callback = None
        header_callback = None
        method = None
    self = _HTTPConnection(None, None, None, None, None, None, None, None,
                           None, None, None, None, None, None, None, None,
                           None, None)
    self.request = request
    self.code = None
    self.headers = None
    self.chunks = []
    httpclient._HTTPConnection.headers_received(self, None, None)
    self.final_callback = (lambda response: None)
    self.code = None
    self.headers = None
   

# Generated at 2022-06-24 09:09:53.595731
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.concurrent import Future
    from tornado import gen
    from tornado.httpclient import HTTPResponse
    from tornado.testing import AsyncHTTPTestCase, ExpectLog, bind_unused_port
    from tornado.test.util import unittest
    # TODO: the tests in this file are terrible and can only test the
    # happy path of SimpleAsyncHTTPClient.  they should be moved to a
    # new test file that uses a stub server (and they should be
    # converted to use AsyncHTTPTestCase, since they are testing
    # asynchronous code).
    request = HTTPRequest("http://www.google.com/")

    @gen.coroutine
    def f():
        response = yield http_client.fetch(request)
        raise gen.Return(response)


# Generated at 2022-06-24 09:09:56.937813
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    class obj:
        value = None
    o = obj()
    o.value = HTTPStreamClosedError("aa")
    str(o.value)



# Generated at 2022-06-24 09:10:08.535561
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    class MockHTTPClient(object):
        def __init__(self):
            self.max_clients = 4
            self.queue = None
            self.max_buffer_size = None
            self.defaults = None

    request = TestingHTTPRequest(
        "GET", "http://localhost:80/", headers={"Accept-Encoding": "gzip"}
    )
    class MockStream(object):
        def set_nodelay(self, x):
            pass
    stream = MockStream()
    sockaddr = None
    io_loop = Mock()
    io_loop.time.return_value = 10
    class MockHTTP1Connection(object):
        def __init__(self):
            self.stream = None
            self.params = None

    http1_connection = MockHTTP1Connection()
    http1_connection

# Generated at 2022-06-24 09:10:13.829531
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    message = "message"
    obj = HTTPTimeoutError(message)
    str(obj)
    message = "message"
    obj = HTTPTimeoutError(message)
    str(obj)


# These classes are used internally and should not be referenced directly.
# They are included here so the interfaces can be clearly documented.
# Tests for internal classes are at the end of this module.



# Generated at 2022-06-24 09:10:18.747218
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Test for SimpleAsyncHTTPClient
    asyncio = mock.Mock()

    resolver = mock.Mock()
    defaults = mock.Mock()

    test_client = SimpleAsyncHTTPClient(asyncio)
    test_client.initialize(max_clients=10, resolver=resolver, defaults=defaults)

    assert test_client.max_clients == 10
    assert test_client.queue == collections.deque()
    assert test_client.active == {}
    assert test_client.waiting == {}
    assert test_client.max_buffer_size == 104857600
    assert test_client.max_header_size == None
    assert test_client.max_body_size == None

    assert test_client.resolver == resolver
    assert test_client.own_resolver == False

   

# Generated at 2022-06-24 09:10:20.600538
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _HTTPConnection.on_connection_close(None)


# Generated at 2022-06-24 09:10:27.462447
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    chunk = b'helloworld'
    data = b'helloworld'
    dataReceived = lambda self, arg: data.replace(arg, b"")
    print(data)
    print(dataReceived)
    first_line = httputil.ResponseStartLine('3', '3', '3')
    headers = httputil.HTTPHeaders()
    headers.add('', '')
    _HTTPConnection.headers_received(None, first_line, headers)


# Generated at 2022-06-24 09:10:30.847618
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError('An error is raised.')
    except HTTPStreamClosedError as err:
        assert str(err) == 'An error is raised.'


# Generated at 2022-06-24 09:10:38.508677
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    @gen.coroutine
    def fetch_coroutine() -> HTTPResponse:
        client = SimpleAsyncHTTPClient()
        assert client._dispatcher is not None
        assert client.queue is not None
        assert client.max_buffer_size is not None
        assert client.io_loop is not None
        assert client.resolver is not None
        assert client.own_resolver is not None
        assert client.tcp_client is not None
        assert client.max_header_size is not None
        assert client.max_body_size is not None
        fetch_future = client.fetch("/")
        assert fetch_future is not None
        fetch_response = yield fetch_future
        assert fetch_response.code == 200
        assert client.active is not None
        assert client.waiting is not None
        assert client

# Generated at 2022-06-24 09:10:49.810891
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    class _DummySSLIOStream():
        def __init__(self, *args, **kwargs):
            pass
    
    class _DummyIOStream():
        def __init__(self, *args, **kwargs):
            pass

    class _DummyConnectionParameters():
        def __init__(self, *args, **kwargs):
            pass

    class _DummyCurlAsyncHTTPClient():
        def __init__(self, *args, **kwargs):
            pass

    class StreamClosedError(Exception):
        pass

    class _DummyStream():
        def __init__(self, *args, **kwargs):
            pass
        def set_close_callback(self, *args, **kwargs):
            pass

# Generated at 2022-06-24 09:10:51.245301
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    message = 'message'
    error = HTTPStreamClosedError(message)
    assert error.message == message
    assert str(error) == message


# Generated at 2022-06-24 09:10:56.669532
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    stream = FakeIOStream()
    client = HTTPClient()

# Generated at 2022-06-24 09:10:57.800897
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient(io_loop=IOLoop())
    client.close()
    client.close()



# Generated at 2022-06-24 09:10:58.266896
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    pass

# Generated at 2022-06-24 09:11:05.179910
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    request = httpclient.HTTPRequest("http://example.com/")
    conn = _HTTPConnection(request, client=None, final_callback=None,
                           io_loop=IOLoop.current())
    stream = object()
    stream.error = None
    conn.stream = stream
    conn.on_connection_close()
    assert True


# Generated at 2022-06-24 09:11:16.569277
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    from tornado.httpclient import _HTTPConnection
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPRequest
    from tornado.httputil import HTTPResponse

    request = HTTPRequest("")
    request.max_redirects = 0
    request.follow_redirects = False
    _HTTPConnection(request,  10.0,  None, None)
    #  we should define the response
    response = HTTPResponse(request,  101,  reason='dummy-reason', 
                                            headers=HTTPHeaders(), 
                                            request_time=0, 
                                            start_time=0.0, 
                                            buffer=None, 
                                            effective_url='')
    
    
    
    
    
    
    
    


# Generated at 2022-06-24 09:11:19.236320
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert isinstance(client, AsyncHTTPClient)
    assert isinstance(client, SimpleAsyncHTTPClient)



# Generated at 2022-06-24 09:11:20.581750
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    pass # TODO



# Generated at 2022-06-24 09:11:24.069708
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError("Stream closed")
    assert error.code == 599
    assert error.message == "Stream closed"
    assert str(error) == "Stream closed"

# Generated at 2022-06-24 09:11:30.659081
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    """
    Test the initializer of class SimpleAsyncHTTPClient
    that initializes the given instance of SimpleAsyncHTTPClient
    """
    ioloop = IOLoop()
    client = SimpleAsyncHTTPClient()
    client.initialize(max_clients=10,resolver=None)
    client.close()
    ioloop.close()

# Generated at 2022-06-24 09:11:33.069032
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Test for __HTTPConnection_run
    client = httpclient.AsyncHTTPClient()
    client.fetch("http://example.com/foo/bar", raise_error=False)

# Generated at 2022-06-24 09:11:33.955704
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass # TODO: implement your test here


# Generated at 2022-06-24 09:11:36.077324
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    test_connection = _HTTPConnection(None, None, None)
    test_stream = IOStream(socket.socket())
    test_connection.run(test_stream)



# Generated at 2022-06-24 09:11:39.532281
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import tornado.httputil
    import tornado.gen
    import tornado.simple_httpclient
    import tornado.escape
    
    
    
    
    
    
    

# Generated at 2022-06-24 09:11:41.506658
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # test method initialize of class SimpleAsyncHTTPClient with normal params
    # TODO find way to solve
    pass


# Generated at 2022-06-24 09:11:53.894259
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():


    class MySimpleAsyncHTTPClient(SimpleAsyncHTTPClient):
        def initialize(self, **kwargs):
            super().initialize(**kwargs)
    client = MySimpleAsyncHTTPClient(max_clients=10, max_buffer_size=104857600)
    assert client.max_clients == 10
    assert client.max_buffer_size == 104857600
    assert len(client.tcp_client.resolver.mapping) == 0
    assert client.own_resolver == True
    client.close()
    client = MySimpleAsyncHTTPClient(max_clients=10, max_buffer_size=104857600, hostname_mapping={'www.baidu.com':'111.13.101.208'})

# Generated at 2022-06-24 09:11:56.380426
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass # TODO


# Generated at 2022-06-24 09:12:06.702066
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    global orig_HTTPConnection
    method = orig_HTTPConnection.headers_received
    # Setup mock objects
    global client_fetch_callbacks
    client_fetch_callbacks = []
    global mock_result
    mock_result = None
    def mock_inner_method(request):
        nonlocal mock_result
        mock_result = request
        return mock_result
    global mock_Client_fetch
    mock_Client_fetch = mock.MagicMock(side_effect=mock_inner_method)
    global mock_client_fetch_callback
    mock_client_fetch_callback = mock.MagicMock()
    client_fetch_callbacks.append(mock_client_fetch_callback)
    global mock_HTTPRequest
    mock_HTTPRequest = mock.MagicMock()
    global mock_

# Generated at 2022-06-24 09:12:19.269386
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import LogTrapTestCase
    from tornado.testing import bind_unused_port
    from tornado.testing import ExpectLog
    import subprocess
    import socket
    import cherrypy
    import logging
    import wsgiref.simple_server
    import base64
    import time
    import urllib.parse
    import unittest
    import shutil
    import os
    import re
    import io
    import sys
    
    
    
    class SimpleHTTPConnection(tornado.httpclient.HTTPConnection):
        "A simple HTTPConnection that supports only GET and POST."

# Generated at 2022-06-24 09:12:22.180542
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    try:
        raise HTTPStreamClosedError("Test")
    except HTTPStreamClosedError as e:
        assert str(e) == "Test"



# Generated at 2022-06-24 09:12:26.219660
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    client = SimpleAsyncHTTPClient(io_loop = None)
    request = HTTPRequest(url = 'https://www.example.com/', body = 'some_body')
    callback = None
    client.fetch_impl(request, callback)


# Generated at 2022-06-24 09:12:35.638890
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    conn = _HTTPConnection(na, na, na, na)
    assert conn.io_loop is not None
    assert conn.client is not None
    assert conn.request is not None, "_HTTPConnection.request must be set"
    assert conn.start_time is not None, "_HTTPConnection.start_time must be set"
    assert (
        conn.start_wall_time is not None
    ), "_HTTPConnection.start_wall_time must be set"
    assert (
        conn.final_callback is not None
    ), "_HTTPConnection.final_callback must be set"
    assert (
        conn.release_callback is not None
    ), "_HTTPConnection.release_callback must be set"
    assert conn.parsed is not None, "_HTTPConnection.parsed must be set"

# Generated at 2022-06-24 09:12:44.000981
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    ssl_options = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=None)
    http_conn = _HTTPConnection(
        connect_timeout=1.0,
        ssl_options=ssl_options,
        max_header_size=1,
    )
    assert http_conn.connect_timeout == 1.0
    assert http_conn.ssl_options == ssl_options
    assert http_conn.max_header_size == 1


# Generated at 2022-06-24 09:12:47.186691
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = "hello"
    headers = "world"
    x = _HTTPConnection(None, None, None)
    x.headers_received(first_line, headers)
    assert x.headers_received(first_line, headers) == None


# Generated at 2022-06-24 09:12:48.344299
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    ioloop = IOLoop.current()
    http_client = SimpleAsyncHTTPClient()
    http_client.initialize(io_loop=ioloop)

# Generated at 2022-06-24 09:12:56.143874
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import RequestHandler
    class MockRequestHandler(RequestHandler):
        def get(self):
            self.write('hello, world')
        def post(self):
            self.write('hello world, post')
    class HTTPResponse:
        def __init__(self, request, code=None, headers=None, reason=None, error=None):
            self.request = request
            self.code = code
            self.headers = headers
            self.reason = reason
            self.error = error
    class _RequestProxy:
        def __init__(self, request, url, max_redirects):
            self.request = request
            self.url = url
            self.max_redirects = max_redirects

# Generated at 2022-06-24 09:13:00.630743
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    import unittest

    class SimpleAsyncHTTPClient_initialize_Test(unittest.TestCase):
        def test_SimpleAsyncHTTPClient_initialize(self):
            self.assertEqual(None, None)

# Generated at 2022-06-24 09:13:06.171443
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # Test that SimpleAsyncHTTPClient receives the expected arguments
    SimpleAsyncHTTPClient(io_loop=None, force_instance=None,
                          max_clients=None, hostname_mapping=None,
                          max_buffer_size=None,
                          resolver=None, defaults=None,
                          max_header_size=None, max_body_size=None)


# Generated at 2022-06-24 09:13:08.903502
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    if sys.version_info >= (3, 6):
        assert (
            "Stream closed" == str(HTTPStreamClosedError(""))
        ), "str(HTTPStreamClosedException) failed"


# Generated at 2022-06-24 09:13:17.476439
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    """
    You can use this method as a unit test for _HTTPConnection.run
    """
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import bind_unused_port

    from tornado.ioloop import IOLoop

    from tornado import httpclient

    from tornado.log import logging

    io_loop = IOLoop.current()

    import logging

    logging.basicConfig(filename="test_log.txt", level=logging.DEBUG)

    # ##
    # class AsyncHTTPTestCase
    #
    # This class can be used to run an `AsyncHTTPClient` self. AsyncHTTPClient.fetch() tests
    # in a `tornado.testing.AsyncTestCase` subclass.
    #
    # Subclasses must override `get_app()` to return the
    # `tornado.httpserver

# Generated at 2022-06-24 09:13:29.673165
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Usually, a mock is used for the first parameter of the decorated
    # function. However, in this case _HTTPConnection is an inner class of
    # SimpleAsyncHTTPClient, so a mock of SimpleAsyncHTTPClient is required.
    mock_self = MagicMock()
    request = HTTPRequest(url="http://www.google.com")
    mock_self.request = request
    headers = httputil.HTTPHeaders()
    headers.add("Content-Type", "text/html")
    headers.add("Location", "/")
    first_line = httputil.ResponseStartLine("HTTP/1.1", 302, "Found")
    return_value = _HTTPConnection.headers_received(mock_self, first_line, headers)
    print(return_value)

if __name__ == "__main__":
    test__

# Generated at 2022-06-24 09:13:35.979398
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    import asyncio
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    io_loop = tornado.platform.asyncio.AsyncIOMainLoop().current()
    asyncio.set_event_loop(io_loop.asyncio_loop)

    client = SimpleAsyncHTTPClient(io_loop)
    client.close()
    client.close()


# Generated at 2022-06-24 09:13:37.828967
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    err = HTTPStreamClosedError("test")
    err.__str__() == "test"


# Generated at 2022-06-24 09:13:46.031559
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    x1 = HTTPStreamClosedError('HTTPStreamClosedError message')
    assert isinstance(x1, HTTPStreamClosedError)
    assert x1.code == 599
    assert x1.message == 'HTTPStreamClosedError message'
    assert str(x1) == 'HTTPStreamClosedError message'
    x2 = HTTPStreamClosedError(None)
    assert isinstance(x2, HTTPStreamClosedError)
    assert x2.code == 599
    assert x2.message is None
    assert str(x2) == 'Stream closed'

# Classes for parsing and rendering HTTP headers.
# These classes are designed for speed rather than flexibility,
# since they are called on every request and response.

# Generated at 2022-06-24 09:13:56.882019
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import tornado.iostream
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import asyncio
    async def _test_callback(client):
        response = await client.fetch("http://localhost:%d/" % port)
        assert response.code == 200
    if tornado.platform.asyncio._is_event_loop_initialized():
        with pytest.raises(RuntimeError):
            tornado.platform.asyncio.AsyncIOMainLoop().install()
    asyncio_loop = asyncio.get_event_loop()
    app = tornado.web.Application()
    http_server = tornado.httpserver.HTTPServer(app)
    sock, port = tornado.testing.bind_unused_port()

# Generated at 2022-06-24 09:13:59.731232
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert HTTPStreamClosedError("Stream closed").__str__() == "Stream closed"
# Test the function __str__ of class HTTPStreamClosedError

# Generated at 2022-06-24 09:14:05.327265
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError
    except HTTPStreamClosedError as e:
        assert e.status_code == 599


# Header encoding (see RFC 5987)
_RFC5987_RE = re.compile(r"^([^']*)'([^']*)'(.*)$")



# Generated at 2022-06-24 09:14:09.859388
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():  # type: ignore
    import tornado.testing
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import tornado.platform.asyncio

    AsyncIOMainLoop().install()
    io_loop = tornado.platform.asyncio.AsyncIOMainLoop().current()
    AsyncHTTPClient.configure(
        "tornado.curl_httpclient.CurlAsyncHTTPClient", max_clients=20
    )
    client = AsyncHTTPClient(max_clients=10)
    client.close()
    # Install simple http client
    AsyncHTTPClient.configure(
        "tornado.simple_httpclient.SimpleAsyncHTTPClient", max_clients=20
    )
    client = AsyncHTTPClient(max_clients=10)


# Generated at 2022-06-24 09:14:17.530113
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    if not hasattr(_HTTPConnection, '_HTTPConnection__HTTPConnection_finish'):
        raise SkipTest('Method not defined')
    else:
        response = HTTPResponse(request=Request, code=int, reason=str, headers=HTTPHeaders, request_time=float, start_time=float, buffer=file, effective_url=str)
        _HTTPConnection._HTTPConnection__HTTPConnection_finish(self=_HTTPConnection, code=int)
        test.assert_equal(type(response), HTTPResponse)

# Generated at 2022-06-24 09:14:19.621429
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    fetch_impl()



# Generated at 2022-06-24 09:14:22.076556
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    try:
        client = SimpleAsyncHTTPClient()
        print(client)
        pass
    except:
        pass

# Generated at 2022-06-24 09:14:24.780497
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    """Tests for SimpleAsyncHTTPClient.close()"""
    # Test for SimpleAsyncHTTPClient.close()
    # SimpleAsyncHTTPClient.close()
    pass



# Generated at 2022-06-24 09:14:32.591123
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado.httpclient import AsyncHTTPClient
    from tornado.httpclient import HTTPRequest
    from tornado import gen
    import tornado
    import os
    import sys

    @gen.coroutine
    def go():
        client = AsyncHTTPClient()
        url = 'http://www.meetup.com/python-tornado/members/'
        response = yield client.fetch(url)
        print("got response %s" % response.body)
    if __name__ == '__main__':
        import tornado.ioloop
        loop = tornado.ioloop.IOLoop.instance()
        loop.run_sync(go)



# Generated at 2022-06-24 09:14:37.510696
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    mock_self = _HTTPConnection()
    mock_self.code = mock.Mock()
    mock_self.chunks = mock.Mock()
    mock_self.request = mock.Mock()
    mock_self.request.max_redirects = None
    mock_self.request.method = mock.Mock()
    mock_self.request.url = None
    mock_self.request.body = mock.Mock()
    mock_self.final_callback = mock.Mock()
    mock_self._run_callback = mock.Mock()
    mock_self._on_end_request = mock.Mock()
    mock_self.headers = mock.Mock()
    mock_self.headers.get = mock.Mock(return_value=True)
    mock_self.code = 301
    mock_

# Generated at 2022-06-24 09:14:47.817148
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado.httputil import HTTPMessageDelegate
    from tornado.queues import Queue, PriorityQueue, LifoQueue
    import unittest
    import unittest.mock
    import io
    import sys

    class MockRequest(object):
        def __init__(
            self,
            start_time: float,
            connect_timeout: Optional[float],
            request_timeout: Optional[float]
        ) -> None:
            self.start_time = start_time
            self.connect_timeout = connect_timeout
            self.request_timeout = request_timeout


# Generated at 2022-06-24 09:14:51.987430
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    client = SimpleAsyncHTTPClient(max_clients=1024, max_buffer_size=1048567)
    assert client.max_clients == 1024
    assert client.max_buffer_size == 1048567



# Generated at 2022-06-24 09:14:52.576465
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass

# Generated at 2022-06-24 09:14:57.509646
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # request = HTTPRequest("http://www.google.com/")
    io_loop = IOLoop.current()
    # def callback(response):
    #     print(response.code)
    #     print(response.body)
    #     io_loop.stop()
    async_client = SimpleAsyncHTTPClient()
    # async_client.fetch_impl(request, callback)
    io_loop.start()

test_SimpleAsyncHTTPClient_fetch_impl()

# Generated at 2022-06-24 09:15:01.758108
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    request = HTTPRequest('https://www.baidu.com')
    callback = lambda response:None
    client = SimpleAsyncHTTPClient()
    client.fetch_impl(request,callback)
test_SimpleAsyncHTTPClient_fetch_impl()

# Generated at 2022-06-24 09:15:08.040887
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    counter = 0
    while counter < 3:
        try:
            import tornado.httpclient
            import tornado.testing
            break
        except ImportError:
            counter += 1
            continue
    else:
        return # Don't run the tests if tornado isn't installed
    
    class TestHTTPClient(_HTTPClient):
        def _get_ssl_options(
                self, scheme: str
        ) -> Union[None, Dict[str, Any], ssl.SSLContext]:
            if scheme == "https":
                if self.request.ssl_options is not None:
                    return self.request.ssl_options
                # If we are using the defaults, don't construct a
                # new SSLContext.

# Generated at 2022-06-24 09:15:10.789509
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError("")
    # self.assertEqual(expected, e.__str__())
    assert e.__str__() == "Stream closed"  # TODO: implementation of test not found



# Generated at 2022-06-24 09:15:22.171288
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    response = HTTPResponse(_HTTPRequestImpl(url="http://localhost:8000", headers={}),
                            headers=httputil.HTTPHeaders(),
                            buffer=BytesIO(b"hello"),
                            request_time=0,
                            code=200,
                            effective_url="http://localhost:8000")

# Generated at 2022-06-24 09:15:23.538667
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass
# Test for method close of class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:15:32.995913
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _test_client = HTTPClient(force_instance=True)

# Generated at 2022-06-24 09:15:33.650445
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    SimpleAsyncHTTPClient()

# Generated at 2022-06-24 09:15:38.445587
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    request = HTTPRequest("GET", "http://example.com/")
    request.final_callback = lambda x: x
    stream = IOStream(None)
    conn = _HTTPConnection(request, stream, None, None, None)
    conn.on_connection_close()


# Generated at 2022-06-24 09:15:39.425266
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass


# Generated at 2022-06-24 09:15:43.187198
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError("Test Error")
    assert error.code == 599
    assert str(error) == "Test Error"



# Generated at 2022-06-24 09:15:44.429889
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    #
    #pass
    pass

# Generated at 2022-06-24 09:15:52.240813
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    with mock.patch(
        "tornado.simple_httpclient.HTTPResponse"
    ) as HTTPResponse_mock, mock.patch(
        "tornado.simple_httpclient._RequestProxy"
    ) as _RequestProxy_mock, mock.patch(
        "tornado.httpclient.HTTPStreamClosedError"
    ) as HTTPStreamClosedError_mock:
        _HTTPConnection_mock = mock.MagicMock()
        HTTPResponse_mock.return_value = mock.MagicMock()
        _RequestProxy_mock.return_value = mock.MagicMock()
        HTTPStreamClosedError_mock.return_value = mock.MagicMock()
        chunks = []

# Generated at 2022-06-24 09:15:54.633393
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None

    HTTPTimeoutError("")


# Generated at 2022-06-24 09:15:59.727603
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Test with a object of type IOColoop, some object of type
    # integer, some object of type dictionary, some object of type
    # integer and some object of type dictionary
    client = SimpleAsyncHTTPClient()
    client.initialize(max_clients=10)

# Generated at 2022-06-24 09:16:06.342236
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    __str__: Callable[[HTTPTimeoutError], str]
    # Base case for method _HTTPClientConnection_finish(): when the client
    # connection cannot be prepared, the result should be a ConnectionError
    obj = HTTPTimeoutError(message="test_HTTPTimeoutError___str__")
    __str__ = obj.__str__
    assert(__str__(obj) == 'test_HTTPTimeoutError___str__')
    obj = HTTPTimeoutError(message=None)
    __str__ = obj.__str__
    assert(__str__(obj) == 'Timeout')


# Generated at 2022-06-24 09:16:18.499626
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Test HTTPClient.fetch()
    TARGET_URL = "http://www.google.com/"

    async def test_fetch():
        response = await AsyncHTTPClient().fetch(TARGET_URL)
        assert isinstance(response, HTTPResponse)
        assert response.code == 200
        assert response.body

    # Test HTTPClient.fetch() with raise_error=False
    async def test_fetch_no_raise():
        response = await AsyncHTTPClient().fetch(TARGET_URL, raise_error=False)
        assert isinstance(response, HTTPResponse)
        assert response.code == 200
        assert response.body


# Generated at 2022-06-24 09:16:28.286816
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Test SimpleAsyncHTTPClient class's method fetch_impl
    h = HTTPStreamClosedError("error")
    s = SimpleAsyncHTTPClient()
    assert h.code == 599
    assert isinstance(h, HTTPError)
    h1 = HTTPTimeoutError("error")
    assert h1.code == 599
    assert isinstance(h1, HTTPError)
    # Test the body of method fetch_impl:
    # check the status of parameters
    # check the types of parameters
    with pytest.raises(AssertionError):
        s.fetch_impl(None, None)
    # check the length of parameters
    with pytest.raises(AssertionError):
        s.fetch_impl(None, 1)
    with pytest.raises(AssertionError):
        s.fetch_impl

# Generated at 2022-06-24 09:16:36.772337
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    with tb.run_with_async_loop() as loop:
        # Create a mock object of the class HTTPConnection
        mock_connection = mock.Mock()
        # Configure the mock object of the class HTTPConnection
        mock_connection._handle_exception.return_value = None
        mock_connection._timeout = None
        mock_connection.connection = None
        mock_connection.final_callback = None
        mock_connection.io_loop = loop
        mock_connection.max_header_size = 65536
        mock_connection.max_body_size = 2097152
        mock_connection.parsed = urlparse(
            "http://localhost:8888/v1/convert?key=API_KEY", scheme="http"
        )

# Generated at 2022-06-24 09:16:39.278376
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    exc = HTTPStreamClosedError('Test')
    result = str(exc)
    # assert result == 'Test'
    assert result == 'Stream closed'


# Generated at 2022-06-24 09:16:46.234289
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    with pytest.raises(AttributeError):
        print("start test")
        # class SimpleAsyncHTTPClient.fetch_impl(request, callback)
        from tornado.httpclient import AsyncHTTPClient, HTTPRequest


        def handle_request(response):
            if response.error:
                print("Error:", response.error)
            else:
                print(response.body)


        http_client = AsyncHTTPClient()
        http_client.fetch("http://www.tornadoweb.org/en/stable/", handle_request)
        print("end test")

# Generated at 2022-06-24 09:16:57.735322
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado import testing, httpclient
    import concurrent.futures

    # In this test, we execute a request and verify that the response is
    # processed properly. We also modify the request after execution, to
    # ensure that the request object is not modified by the HTTP client.
    def test_callback(response):
        self.assertEqual(response.code, 200)
        self.assertEqual(response.body, b"hello world")
        self.assertIsInstance(response.error, concurrent.futures.TimeoutError)
        self.assertEqual(request.url, "https://www.google.com/")

    request = httpclient.HTTPRequest("https://www.google.com/")
    self.http_client.fetch(request, test_callback)
    request.url = "https://www.google.com/"



# Generated at 2022-06-24 09:16:59.396548
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # type: () -> None
    class MySimpleAsyncHTTPClient(SimpleAsyncHTTPClient):
        pass

    MySimpleAsyncHTTPClient()



# Generated at 2022-06-24 09:17:07.351426
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # _HTTPConnection.finish() is tested in test_client.py
    # here we test that _HTTPConnection.finish() sets the `HTTPResponse.buffer` attribute
    import tornado.testing
    import tornado.web
    import tornado.ioloop # type: ignore
    import tornado.httpserver # type: ignore

    class HelloHandler(tornado.web.RequestHandler):
        def get(self):
            self.write('Hello, world')

    class FinishTestHandler(tornado.web.RequestHandler):
        def initialize(self, **kwargs):
            self.fetch_future = kwargs['fetch_future']
            self.fetch_future.set_result((self.get_body_argument('url'), self.request))

        async def get(self):
            url, request = await self.fetch_

# Generated at 2022-06-24 09:17:17.881425
# Unit test for method __str__ of class HTTPStreamClosedError

# Generated at 2022-06-24 09:17:26.144013
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    error1 = HTTPTimeoutError("test")
    assert isinstance(error1, HTTPClientError)
    assert error1.code == 599
    assert error1.message == "test"
    assert str(error1) == "test"

    error2 = HTTPTimeoutError(None)
    assert isinstance(error2, HTTPClientError)
    assert error2.code == 599
    assert error2.message == None
    assert str(error2) == "Timeout"



# Generated at 2022-06-24 09:17:28.669628
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    simple_async_client = SimpleAsyncHTTPClient()
    return simple_async_client


# Generated at 2022-06-24 09:17:29.385140
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-24 09:17:36.470700
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    def _data_received(self, chunk: bytes) -> None:
        if self._should_follow_redirect():
            return
        if self.request.streaming_callback is not None:
            self.request.streaming_callback(chunk)
        else:
            self.chunks.append(chunk)

    _HTTPConnection._data_received(_HTTPConnection, bytes(b"Hello World"))

# TODO: Test me



# Generated at 2022-06-24 09:17:48.947188
# Unit test for constructor of class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:17:51.638862
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():

    test = SimpleAsyncHTTPClient()
    with pytest.raises(NotImplementedError):
        test.close()

# Generated at 2022-06-24 09:17:52.964981
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("Timeout")
    except Exception as e:
        assert str(e) == "Timeout"


# Generated at 2022-06-24 09:18:03.093739
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    err = HTTPStreamClosedError("e")
    assert err.code == 599

# from typing import Deque, Tuple
# from types import TracebackType
# from tornado.httpclient import HTTPTimeoutError
# from tornado.ioloop import IOLoop
# from tornado.iostream import IOStream, StreamClosedError
# from tornado.netutil import Resolver, is_valid_ip, _client_ssl_defaults
# from tornado.simple_httpclient import (HTTPError, HTTPStreamClosedError,
#                                        _NonHTTPExceptionMixin,
#                                        _HTTPConnectionParameters,
#                                        _HostDelegationMixin)



# Generated at 2022-06-24 09:18:07.697096
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("Some message")
    assert e.code == 599
    assert e.msg == e.message == "Some message"
    assert str(e) == "Some message"

    e = HTTPTimeoutError(None)
    assert e.code == 599
    assert e.msg == e.message == None

    assert str(e) == "Timeout"



# Generated at 2022-06-24 09:18:10.952917
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    new_exc = HTTPStreamClosedError("New HTTPStreamClosedError")
    # assert isinstance(new_exc, HTTPClientError)
    assert new_exc.code == 599



# Generated at 2022-06-24 09:18:12.870615
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    http_client = SimpleAsyncHTTPClient()
    assert isinstance(http_client, SimpleAsyncHTTPClient)


# Generated at 2022-06-24 09:18:19.804760
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():  # type: ignore
    stream = IOStream(socket.socket(), io_loop=IOLoop.current())
    conn = _HTTPConnection(stream, "127.0.0.1", 443)
    print(conn.__dict__)
    assert conn.stream == stream
    assert conn.stream.socket.gettimeout() == 0
    assert conn.stream.socket.getpeername() == ("127.0.0.1", 443)

test__HTTPConnection()

# Generated at 2022-06-24 09:18:26.868476
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """
    Test if the headers_received method maps the correct data to the correct attribute.
    """
    connection = _HTTPConnection()
    headers = httputil.HTTPHeaders()
    headers['key'] = 'value'
    response_start_line = httputil.ResponseStartLine(200, 'OK', '')
    connection.request.header_callback({'key':'value'})
    connection.headers_received(response_start_line, headers)
    assert connection.headers['key'] == 'value'


# Generated at 2022-06-24 09:18:33.634248
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Create required objects
        # Create a AsyncHTTPClient instance
        client = AsyncHTTPClient()
        # Create a tornado.httputil.HTTPRequest instance
        request = tornado.httputil.HTTPRequest('http://google.com')
        # Create a tornado.httputil.HTTPResponse instance
        response = tornado.httputil.HTTPResponse(request, 200)
        # Create a tempfile instance
        file = tempfile.TemporaryFile()
        # Create a tornado.iostream.IOStream instance
        stream = tornado.iostream.IOStream(file)
        # Create a tornado.ioloop.IOLoop instance
        io_loop = tornado.ioloop.IOLoop.current()
        # Create a functools.partial instance
        final_callback = functools.partial(response)


# Generated at 2022-06-24 09:18:36.275952
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    e = HTTPStreamClosedError('test Stream closed')
    assert e.message == 'test Stream closed'
    assert e.code == 599
    assert str(e) == 'test Stream closed'


# Generated at 2022-06-24 09:18:48.754281
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    class _HTTPConnection:
        """A single HTTP connection to a server.

        We don't support multiplexing several requests on a single connection
        because it would complicate the logic too much for the expected
        gain (usually none except for very expensive connections like SSL).

        If the ``stream`` argument is not none, we assume it is a fully-formed
        HTTP1ConnectionParameters that contains the HTTPConnection instance
        and the SSL options for the connection.
        """


# Generated at 2022-06-24 09:18:49.785627
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    pass  # TODO

# Generated at 2022-06-24 09:18:59.771926
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    a=_HTTPConnection("a", 1, 2, 3)
    a.code=4
    a.request=SimpleNamespace(follow_redirects=True, max_redirects=2)
    a.headers=SimpleNamespace(get="d")
    a.on_connection_close=MagicMock()
    a.final_callback=MagicMock()
    a.request=SimpleNamespace(url="a")
    a._run_callback=MagicMock()
    a.request.original_request=SimpleNamespace(method="d")
    a._on_end_request=MagicMock()
    a.request.streaming_callback=MagicMock()
    a._remove_timeout=MagicMock()

    a.finish()

    a.request.follow_redirects=False

# Generated at 2022-06-24 09:19:00.798363
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert HTTPTimeoutError(message="Timeout").__str__() == "Timeout"


# Generated at 2022-06-24 09:19:01.926846
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    ex = HTTPTimeoutError(message="Some message")
    assert ex.__str__() == "Some message"

# Generated at 2022-06-24 09:19:03.449078
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # codepath of constructor
    SimpleAsyncHTTPClient()



# Generated at 2022-06-24 09:19:04.769672
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    return client


# Generated at 2022-06-24 09:19:11.148222
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    import unittest

    # TODO: need to refactor _HTTPConnection, the tests are not useful

    class Test__HTTPConnection(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_on_connection_close(self):
            pass



# Generated at 2022-06-24 09:19:20.113637
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Note: The unit test is disabled for now.
    # As for the topic of unit test for private method,
    # see https://stackoverflow.com/questions/1896918/running-unittest-with-typical-test-directory-structure
    return

    class MockAsyncHTTPClient(SimpleAsyncHTTPClient):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.waiting = {}
            self.queue = collections.deque()

        def _handle_request(self, *args, **kwargs):
            print("_handle_request")

        def _release_fetch(self, key: object) -> None:
            del self.active[key]
            self._process_queue()

    http_client = MockAsyncHTTPClient()

# Generated at 2022-06-24 09:19:21.714610
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection._should_follow_redirect()


# Generated at 2022-06-24 09:19:32.564741
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # init fixtures
    io_loop = IOLoop()
    request = HTTPRequest(url="http://www.example.com")
    client = HTTPClient()
    stream = IOStream(socket.socket(), io_loop=io_loop)
    final_callback = lambda x: x
    release_callback = lambda: None
    start_time = io_loop.time()
    start_wall_time = io_loop.time()
    if not hasattr(socket, "AF_UNIX") or socket.AF_UNIX is None:
        _sockaddr = socket.getaddrinfo("www.google.com", 80, 0, 0, socket.SOL_TCP)[
            0
        ][4]
    else:
        _sockaddr = None