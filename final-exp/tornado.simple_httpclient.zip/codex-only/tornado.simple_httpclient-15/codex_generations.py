

# Generated at 2022-06-24 09:09:31.533121
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    if typing.TYPE_CHECKING:
        self = SimpleAsyncHTTPClient()
        self.close()



# Generated at 2022-06-24 09:09:35.142546
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    obj = SimpleAsyncHTTPClient()
    assert obj is not None

# get_cls_to_constructor of class AsyncHTTPClient

# Generated at 2022-06-24 09:09:38.137858
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # that it performs the correct returning
    try:
        raise HTTPStreamClosedError(message='error message')
    except HTTPStreamClosedError as error:
        assert str(error) == "Stream closed"

# Generated at 2022-06-24 09:09:39.061541
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    e = HTTPStreamClosedError('oops')



# Generated at 2022-06-24 09:09:50.308004
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():

    #
    # Test case insutance for _HTTPConnection.run method - Asynchronous HTTP client
    #
    class Test_HTTPConnection_run(AsyncHTTPClientTestCase):

        #
        # Test running _HTTPConnection class attributes
        #
        def test_run(self):
            code = 200
            headers = {"Content-Length": "0"}
            # create mock response class
            response = Mock(
                code=code, headers=headers, request_time=0, start_time=0, time_info={}
            )
            # create mock request class

# Generated at 2022-06-24 09:09:52.705341
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # test parameters
    request = HTTPRequest()
    callback = None

    # object initialization
    obj = SimpleAsyncHTTPClient()

    # test execution
    obj.fetch_impl(request, callback)

# Generated at 2022-06-24 09:10:05.445741
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # The callable method will be called with the correct arguments:
    # 1st argument is the HTTPConnection instance

    # Global vars that will be used by the mocked function
    global CALLED_WITH_ARG
    global CALLED_WITH_KWARG
    global CALLED_TIMES

    # The method to be mocked
    def on_connection_close(self):
        pass

    # The mock object
    c = Mock()
    c.on_connection_close = on_connection_close

    # The argument
    arg = type("arg", (object,), {})()

    # The call
    c.on_connection_close(arg)

    # The assertions
    assert c.on_connection_close.call_count == 1

# Generated at 2022-06-24 09:10:08.255593
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    request = HTTPRequest("http://localhost")
    conn = _HTTPConnection(request, None, None)
    conn.final_callback = mock.MagicMock()
    conn.stream.close = mock.MagicMock()
    conn.stream.error = None
    conn.on_connection_close()
    conn.final_callback.assert_called_once_with(mock.ANY)
    conn.stream.close.assert_called_once()


# Generated at 2022-06-24 09:10:14.874366
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():

    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    import tornado, time

    def handle_response(response):
        if response.error:
            print("Error: %s" % response.error)
        else:
            print(response.body)

    request = HTTPRequest("https://www.google.com/?q=ubuntu",
                          request_timeout=10)
    http_client = AsyncHTTPClient()
    http_client.fetch(request, handle_response)

    tornado.ioloop.IOLoop.instance().start()

if __name__ == '__main__':
    test__HTTPConnection_run()

# Generated at 2022-06-24 09:10:17.421108
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert isinstance(client, SimpleAsyncHTTPClient)


# Generated at 2022-06-24 09:10:21.830397
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # self = _HTTPConnection(
    #     use_gzip=None,
    #     stream=None,
    #     release_callback=None,
    #     final_callback=None,
    #     io_loop=None,
    #     max_buffer_size=None,
    #     connect_timeout=None,
    #     read_timeout=None,
    #     _connect_future=None,
    #     _sockaddr=None,
    # )
    # first_line = httputil.ResponseStartLine(self.request.method, req_path, "")
    # (first_line, headers) = ()
    pass



# Generated at 2022-06-24 09:10:26.794680
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    with pytest.raises(AssertionError):
        _HTTPConnection.on_connection_close(self = None)
    # TODO: build test


# Generated at 2022-06-24 09:10:32.263969
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    if True:
        instance = object.__new__(_HTTPConnection)
        instance.__init__(None,None,None,None,None,None)
    else:
        instance = _HTTPConnection(None,None,None,None,None,None)
    instance.code = None
    return instance.finish()

# Generated at 2022-06-24 09:10:35.686973
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    try:
        (x1, x2) = (1, 2)
        assert x1 == x2
    except Exception as ex:
        print(ex)

    try:
        (x3, x4) = (1, 2, 3)
        assert x3 == x4
    except Exception as ex:
        print(ex)


# Generated at 2022-06-24 09:10:36.689053
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-24 09:10:42.610119
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    class FakeAuth(object):
        pass

    fake_socket = FakeSocket()

    class FakeStream(IOStream):
        def __init__(self, io_loop: IOLoop, socket: "socket.socket") -> None:
            IOStream.__init__(self, socket=socket, io_loop=io_loop)
            self.socket = socket

        def reading(self) -> bool:
            return True

        def closed(self) -> bool:
            return False

        def close(self) -> None:
            pass

        def fileno(self) -> int:
            return fake_socket.fileno()

        def set_close_callback(self, callback: Callable[[], None]) -> None:
            self.close_callback = callback


# Generated at 2022-06-24 09:10:43.118466
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    http_client = SimpleAsyncHTTPClient()


# Generated at 2022-06-24 09:10:53.350093
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    
    # Create an instance of class object IOStream
    _HTTPConnection.stream_=IOStream

    # Create an instance of class object HTTP1Connection
    _HTTPConnection.HTTP1Connection_class=HTTP1Connection

    # Create an instance of class object HTTPClient
    _HTTPConnection.HTTPClient_class=HTTPClient

    # Create an instance of class object Request
    _HTTPConnection.Request_class=Request

    # Create an instance of class object HTTPError
    _HTTPConnection.HTTPError_class=HTTPError

    # Create an instance of class object HTTPTimeoutError
    _HTTPConnection.HTTPTimeoutError_class=HTTPTimeoutError

    # Create an instance of class object HTTPStreamClosedError
    _HTTPConnection.HTTPStreamClosedError_class=HTTPStreamClosedError

    # Create an instance of class object Future

# Generated at 2022-06-24 09:10:54.378376
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert isinstance(client, SimpleAsyncHTTPClient)


# Generated at 2022-06-24 09:10:57.828178
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    client = SimpleAsyncHTTPClient()
    client.initialize()
    assert (client.max_clients == 10)
    assert (client.queue == collections.deque())
    assert (client.active == {})
    assert (client.waiting == {})
    assert (client.max_buffer_size == 104857600)
    assert (client.tcp_client.max_buffer_size == 104857600)
    assert (client.resolver.key_prefix == '')



# Generated at 2022-06-24 09:11:09.912289
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import logging
    import asyncio
    import http.client
    import logging
    import unittest
    import sys

    import tornado.platform.asyncio
    try:
        from concurrent.futures import ThreadPoolExecutor
    except ImportError:
        ThreadPoolExecutor = None
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado import gen
    from tornado.stack_context import ExceptionStackContext
    from tornado.testing import AsyncHTTPTestCase, LogTrapTestCase, bind_unused_port
    from tornado.test.util import unittest

    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.testing import AsyncTestCase, SkipTest, bind_unused_port
    from tornado.test.util import unittest
    from tornado.test.util import skipOn

# Generated at 2022-06-24 09:11:12.604912
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("message")
    assert error.code == 599
    assert str(error) == "message"



# Generated at 2022-06-24 09:11:24.410012
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    http_client = HTTPClient(io_loop=IOLoop())

# Generated at 2022-06-24 09:11:28.728922
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    nb_client = SimpleAsyncHTTPClient()
    nb_client.fetch_impl("http://www.google.com", "test callback")


# Generated at 2022-06-24 09:11:31.119837
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    """Unit test for method _HTTPConnection.data_received
    """
    self = example_object()
    chunk = example_data()
    # call method
    self.data_received(chunk)



# Generated at 2022-06-24 09:11:31.934967
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    HTTPTimeoutError("timeout")



# Generated at 2022-06-24 09:11:33.683983
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():

    http_client = SimpleAsyncHTTPClient()
    # todo: no way to test
    http_client.close()



# Generated at 2022-06-24 09:11:40.775305
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import log
    import tornado.ioloop

# Generated at 2022-06-24 09:11:42.718668
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    err = HTTPTimeoutError('abc')
    assert err.message == 'abc'
    assert err.code == 599
    assert str(err) == 'abc'



# Generated at 2022-06-24 09:11:48.378032
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    ex = HTTPTimeoutError("Test")
    assert ex.code == 599
    assert str(ex) == "Test"
    assert ex.message == "Test"
    assert ex.log_message == "Test"
    assert ex.response is None


# alias for backwards compatibility
TimeoutError = HTTPTimeoutError



# Generated at 2022-06-24 09:11:49.637571
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    HTTPStreamClosedError("Stream closed").__str__()


# Generated at 2022-06-24 09:11:54.626855
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    # Create an instance
    err = HTTPStreamClosedError("Test message")
    # Access properties
    assert (err.code == 599)      # type: ignore
    assert (err.message == "Test message")        # type: ignore
    assert (err.response is None)         # type: ignore
    assert (err.request is None)          # type: ignore



# Generated at 2022-06-24 09:11:59.098949
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    message = 'Stream closed'
    e = HTTPStreamClosedError(message)
    assert _unicode(e) == _unicode(message) or _unicode(e) == _unicode(HTTPStreamClosedError.__doc__)

# Generated at 2022-06-24 09:12:00.956413
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    err = HTTPTimeoutError("Timeout")
    assert str(err) == "Timeout"



# Generated at 2022-06-24 09:12:06.392519
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    io_loop = IOLoop()
    io_loop.make_current()
    # call without argument
    io_loop.run()
    # call with argument
    io_loop.run(loglevel='error')
    # call with argument
    io_loop.run(raise_system_exceptions=False)
    # call with argument
    io_loop.run(timeout_func=None)


# Generated at 2022-06-24 09:12:11.078010
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    io_loop = IOLoop()
    client = SimpleAsyncHTTPClient(io_loop=io_loop)
    def test_callback(arg1):
        nonlocal count
        count += 1
    count = 0
    request = HTTPRequest(url="http://localhost:8888/test.json") # type: ignore
    client.fetch_impl(request, test_callback)
    assert count == 1
test_SimpleAsyncHTTPClient_fetch_impl()


# Generated at 2022-06-24 09:12:19.275016
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    """Test the method fetch_impl of SimpleAsyncHTTPClient class."""
    print("Unit test for SimpleAsyncHTTPClient method fetch_impl")
    requests_queue = collections.deque()
    requests_active = {}
    requests_waiting = {}
    client = SimpleAsyncHTTPClient(max_clients=10,
                                                max_buffer_size=104857600,
                                                max_header_size=None,
                                                max_body_size=None)

# Generated at 2022-06-24 09:12:23.727070
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    parsed = _parse_url('http://example.com:80/foo?bar=baz#quux')
    assert parsed.path == '/foo'
    assert parsed.query == 'bar=baz'
    assert parsed.fragment == 'quux'



# Generated at 2022-06-24 09:12:32.958009
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    conn = _HTTPConnection(None, 0, None, None, None)
    assert conn.io_loop is None
    assert conn.release_callback is None
    assert conn.final_callback is None
    assert conn.start_time is None
    assert conn.parsed is None
    assert conn.request is None
    assert conn.chunks is None
    assert conn.stream is None
    assert conn.code is None
    assert conn._timeout is None
    assert conn.max_header_size == 8192
    assert conn.max_body_size == 104857600
    assert conn.start_wall_time is None
    assert conn.headers is None
    assert conn.chunks is None
    assert conn.reason is None



# Generated at 2022-06-24 09:12:35.241859
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    async def test_coroutine():
        pass
    assert False  # TODO: implement your test here

# Generated at 2022-06-24 09:12:36.033259
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-24 09:12:47.308164
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    import asyncio
    import functools
    import io
    import logging
    import ssl
    import sys
    import tornado.testing
    import tornado.web
    from tornado.iostream import IOStream
    from tornado.netutil import _client_ssl_defaults
    from tornado.httpclient import _URL
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import HTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPError
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import _HTTPConnection
    from tornado.httputil import HTTPMessageDelegate
    from tornado.httputil import HTTPHeaders

# Generated at 2022-06-24 09:12:55.330755
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # 测试__str__是否正常工作
    error = HTTPStreamClosedError("")
    assert error.message == ""
    assert error.code == 599
    assert isinstance(error.args, tuple)
    assert error.__str__() == "Stream closed"
    # 测试__str__是否正常工作
    error = HTTPStreamClosedError("this is message")
    assert error.message == "this is message"
    assert error.code == 599
    assert isinstance(error.args, tuple)
    assert error.__str__() == "this is message"


# The following classes implement an HTTP/1.1 client on top of Tornado's
# IOStreams.  Our HTTPConnection is exposed to end-users as
# SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:12:57.864076
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Given:
    pass



# Generated at 2022-06-24 09:13:05.440363
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # type: () -> None
    simple = SimpleAsyncHTTPClient()
    assert simple.close() is None
    assert simple.fetch_impl(HTTPRequest(url="http://test"), lambda x: None) is None
    assert simple.initialize() is None
    assert simple.io_loop is None
    assert simple.max_buffer_size == 104857600
    assert simple.max_clients == 10
    assert simple.own_resolver is True
    assert simple.queue is None
    assert simple.resolver is None
    assert simple.tcp_client == None
    assert simple.waiting is None



# Generated at 2022-06-24 09:13:06.748864
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    # type: () -> None
    class MyAsyncHTTPClient(SimpleAsyncHTTPClient):
        pass
    MyAsyncHTTPClient(io_loop=IOLoop.current())



# Generated at 2022-06-24 09:13:15.470374
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import asyncio
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver
    import tornado.platform.asyncio

    io_loop = asyncio.get_event_loop()
    tornado.platform.asyncio.AsyncIOMainLoop().install()

    class MainHandler(tornado.web.RequestHandler):
        def get(self):
            self.write("Hello, world")

    def main():
        app = tornado.web.Application([(r"/", MainHandler)])
        http_server = tornado.httpserver.HTTPServer(app)
        http_server.bind(9000)
        http_server.start()
        io_loop.run_forever()

    def client_test():
        client = tornado.httpclient.AsyncHTTPClient()
        request = tornado.httpclient.HTTP

# Generated at 2022-06-24 09:13:18.884407
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    SimpleAsyncHTTPClient(
        max_clients=10,
        hostname_mapping=None,
        max_buffer_size=104857600,
        resolver=None,
        defaults=None,
        max_header_size=None,
        max_body_size=None
    )



# Generated at 2022-06-24 09:13:27.101779
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    import asyncio

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)    
    client = SimpleAsyncHTTPClient()
    request = HTTPRequest("http://www.google.com/")
    for i in range(4):
        future = client.fetch(request)
        response = loop.run_until_complete(future)
        print(response)

test__HTTPConnection_run()


# Generated at 2022-06-24 09:13:29.371125
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    http_client = SimpleAsyncHTTPClient()


# Generated at 2022-06-24 09:13:35.150118
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.log import gen_log
    from tornado.ioloop import IOLoop
    from tornado.httpclient import HTTPRequest
    from tornado.options import define, options, parse_config_file
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.auto import set_close_exec
    from tornado.util import b

    define("foo", type=str)
    define("bar", type=str)
    parse_config_file(StringIO("foo: hello\nbar: goodbye\n"))

    request = HTTPRequest("/")
    sock, port = bind_unused_port()
    set_close_exec(sock.fileno())
    client = SimpleAsyncHTTPClient()
    client.initialize(max_clients=20)
    io_loop = IOLoop.current()


# Generated at 2022-06-24 09:13:39.729912
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    message = "test_message"
    exception: HTTPTimeoutError = HTTPTimeoutError(message)
    assert exception.code == 599
    assert exception.message == message
    assert str(exception) == message

_DEFAULT_CA_CERTS = _client_ssl_defaults.get("ca_certs")



# Generated at 2022-06-24 09:13:50.840142
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.concurrent import Future
    from tornado.concurrent import chain_future
    from tornado import gen
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado import ioloop
    from tornado.iostream import IOStream
    from tornado.simple_httpclient import _DEFAULT_CA_CERTS
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.test.util import unittest
    from tornado.web import RequestHandler, Application, asynchronous
    from tornado.websocket import WebSocketHandler
    import base64
    import socket
    import ssl
    from tornado.httpclient import HTTPRequest
    from tornado.util import Configurable
    from typing import Dict, Any, Callable, Optional, Type, Union
    from types import TracebackType

# Generated at 2022-06-24 09:13:52.641031
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    #
    # todo: auto test

    return


# Generated at 2022-06-24 09:13:57.881984
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    args = []  # type: List[Any]
    if len(args) == 0:
        # No constructors provided; skip test
        return
    # Pick a random constructor
    import random

    constructor = random.choice(args)
    # Create an instance of HTTPRequest
    self = HTTPRequest(*constructor[0], **constructor[1])
    # Create an instance of httputil.HTTPHeaders
    headers = httputil.HTTPHeaders()
    if len(headers) == 0:
        # No constructors provided; skip test
        return
    # Pick a random constructor
    import random

    constructor = random.choice(headers)
    # Create an instance of httputil.HTTPHeaders
    headers = httputil.HTTPHeaders(*constructor[0], **constructor[1])
    # Create an instance of httput

# Generated at 2022-06-24 09:14:06.336103
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # __str__() -> str
    # |  Return the message, followed by "(%d)" % self.code if self.code
    # |  is not None else ""
    assert HTTPStreamClosedError("").__str__() == "Stream closed"
    assert HTTPStreamClosedError("").__str__() == "Stream closed"
    assert HTTPStreamClosedError("m").__str__() == "m"
    assert HTTPStreamClosedError("m").__str__() == "m"


# Generated at 2022-06-24 09:14:17.486061
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # type: () -> None
    stream = IOStream(socket.socket())
    client = HTTPClient()
    request = HTTPRequest(url='http://example.com')
    connection = _HTTPConnection(client, request, stream)
    assert isinstance(connection, _HTTPConnection)
    assert connection.request == request
    assert connection.stream == stream
    assert connection.final_callback == client._on_close
    assert connection.release_callback == stream.release
    assert connection.max_header_size == client.max_header_size
    assert connection.max_body_size == client.max_body_size
    assert connection.parsed.host == request.host
    assert connection.parsed.scheme == request.protocol
    assert connection.parsed.path == request.path

# Generated at 2022-06-24 09:14:20.926759
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():

    # Test no attribute message
    t = tornado.httpclient.HTTPTimeoutError()
    assert [t.__str__() == "Timeout"]

    # Test with attribute message
    t = tornado.httpclient.HTTPTimeoutError(message="test message")
    assert [t.__str__() == "test message"]


# Generated at 2022-06-24 09:14:22.023191
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # _HTTPConnection.on_connection_close()
    pass


# Generated at 2022-06-24 09:14:24.161403
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    message = 'Timeout'
    error = HTTPTimeoutError(message)
    assert str(error) == message


# Generated at 2022-06-24 09:14:27.798604
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # get attributes of class SimpleAsyncHTTPClient
    attrs = vars(SimpleAsyncHTTPClient)
    assert "close" in attrs
    # get close method
    _close = SimpleAsyncHTTPClient.close
    assert isinstance(_close, Callable)

# Generated at 2022-06-24 09:14:39.427692
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Test _HTTPConnection.__init__() with no arguments
    conn = _HTTPConnection(None, None, None, None)
    assert conn.final_callback is None
    assert conn.client is None
    assert conn.request is None
    assert conn.io_loop is ioloop.IOLoop.current()
    # Test _HTTPConnection.__init__() with arguments
    conn = _HTTPConnection(
        TestHTTPClient(),
        TestHTTPRequest(),
        ioloop.IOLoop.current(),  # type: ignore
        partial(TestHTTPClient.release_callback, TestHTTPClient()),
    )
    assert conn.final_callback is None
    assert conn.client is TestHTTPClient()
    assert conn.request is TestHTTPRequest()
    assert conn.io_loop is ioloop.IOLoop.current()
   

# Generated at 2022-06-24 09:14:41.151561
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    http_client = AsyncHTTPClient(io_loop=IOLoop())
    http_client.fetch("http://example.com")
    IOLoop.current().close()

# Generated at 2022-06-24 09:14:42.324589
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError('timeout test')
    assert isinstance(error, HTTPTimeoutError)
    assert error.code == 599
    assert str(error) == 'timeout test'



# Generated at 2022-06-24 09:14:51.414301
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    stream = None
    try:
        stream = IOStream(None)
    except Exception:
        stream = None
    assert stream is not None
    request = HTTPRequest(url="http://example.com", streaming_callback=None)
    http_client = AsyncHTTPClient()
    client = _HTTPConnection(http_client, request, 8, stream, None, None, None)
    client.code = 200
    client.chunks.append(b"test__HTTPConnection_finish")
    client.final_callback = None
    client.request.max_redirects = None
    client.request.follow_redirects = None
    client.headers = None
    from mock import patch

    with patch("tornado.httpclient._HTTPConnection.headers_received") as mock:
        mock.return_value = None
        client.fin

# Generated at 2022-06-24 09:14:52.305712
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    assert False, "TODO"



# Generated at 2022-06-24 09:14:59.344852
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    client = SimpleAsyncHTTPClient()
    client.initialize(max_clients=10)
    request = HTTPRequest('http://localhost:8080/')
    client.fetch_impl(request, None)

##########################################################################
# _ProxyRequestProxy, ProxyConnectHTTPConnection, _ProxyHTTPConnection
# _ProxyHTTPConnectionDelegate
##########################################################################
try:
    # Python 3.5+
    _HAS_SNI = ssl.HAS_SNI
except AttributeError:
    _HAS_SNI = False

if typing.TYPE_CHECKING:
    from typing import Protocol
else:
    # python < 3.5
    Protocol = object



# Generated at 2022-06-24 09:15:03.827760
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
	
	# HTTPRequest object
	request = HTTPRequest(
		url="http://www.google.com",
		headers={
			"Accept-Language":"en-US,en;q=0.5",
			"User-Agent":"Mozilla/5.0",
		},
	)
	
	# IOStream object
	stream = IOStream(socket.socket(socket.AF_INET,socket.SOCK_STREAM),io_loop=IOLoop.current())
	
	# _HTTPConnection object
	timeout = None
	connect_timeout = 30
	max_header_size = None
	max_body_size = None
	proxy_host = None
	proxy_port = None
	proxy_username = None
	proxy_password = None
	proxy_auth_mode = None
	

# Generated at 2022-06-24 09:15:06.735379
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    """Test method __str__ of class HTTPTimeoutError."""
    assert HTTPTimeoutError("Timeout").__str__() == "Timeout"
    assert HTTPTimeoutError("").__str__() == ""



# Generated at 2022-06-24 09:15:08.029280
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    msg = "Timeout"
    assert str(HTTPTimeoutError(msg)) == msg



# Generated at 2022-06-24 09:15:08.699850
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-24 09:15:19.406208
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    def callback(resp):
        a = 1
    request = HTTPRequest(url='http://www.qq.com', method='GET')
    client = SimpleAsyncHTTPClient()
    client.fetch_impl(request, callback)

# Generated at 2022-06-24 09:15:22.664834
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("timeout")
    except HTTPError as e:
        assert e.code == 599
        assert str(e) == "timeout"



# Generated at 2022-06-24 09:15:28.380135
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    # Test for __str__ method of class HTTPTimeoutError
    # Constructor for HTTPTimeoutError
    class HTTPTimeoutError_Extended(HTTPTimeoutError):
        pass
    err = HTTPTimeoutError(message="timeout")
    assert(str(err) == "timeout")
    err_extended = HTTPTimeoutError_Extended(message="timeout")
    assert(str(err_extended) == "timeout")


# Generated at 2022-06-24 09:15:40.648027
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import asyncio
    from tornado.testing import gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future
    from tornado.httpclient import HTTPRequest
    from tornado import gen
    from tornado.http1connection import HTTP1ConnectionParameters
    from tornado.web import Application, RequestHandler
    from tornado.websocket import WebSocketHandler, WebSocketError
    from tornado.log import access_log, app_log, gen_log, access_log, gen_log
    import tornado

    import sys
    import os
    import unittest
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    from PyTest.PyTestHighLevel.tornadoweb import TornadoWeb

# Generated at 2022-06-24 09:15:43.707166
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    #test for closing the object
    uut = SimpleAsyncHTTPClient()
    uut.close()
    return True


# Generated at 2022-06-24 09:15:48.484835
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # pylint: disable=protected-access
    e = HTTPTimeoutError('my message')
    assert str(e) == 'my message'
    assert e.code == 599
    assert e.response is None
    assert e.request is None



# Generated at 2022-06-24 09:15:56.556477
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import unittest
    import unittest.mock as mock
    import tornado.httpclient as httpclient

# Generated at 2022-06-24 09:16:00.218575
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError(msg='test-msg')
    except HTTPStreamClosedError as e:
        assert str(e) == 'test-msg'


# Generated at 2022-06-24 09:16:04.142639
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
# <SKIP>
    # Create a fake IOStream object
    stream = IOStream()
    # Create a _HTTPConnection object
    conn = _HTTPConnection(stream)
    # Call method run on the _HTTPConnection object
    conn.run()
# </SKIP>


# Generated at 2022-06-24 09:16:10.102713
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    tornado_client = SimpleAsyncHTTPClient(
        max_clients=10,
        hostname_mapping={},
        max_buffer_size=104857600,
        resolver=None,
        defaults=None,
        max_header_size=None,
        max_body_size=None
    )
    tornado_client.fetch("http://www.google.com")


# Generated at 2022-06-24 09:16:13.945178
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    inst = _HTTPConnection()
    inst.on_connection_close()
    assert inst._HTTPConnection_on_connection_close_called == 1
    assert inst.on_connection_close_called == 1

# Generated at 2022-06-24 09:16:20.117452
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    conn = _HTTPConnection(HTTPRequest('http://example.com'),
                           'http://example.com',
                           io_loop=IOLoop())
    conn.io_loop = io_loop = IOLoop()
    io_loop.make_current()
    io_loop.run_sync(conn.run)
    assert conn.request.url == 'http://example.com'


# Generated at 2022-06-24 09:16:29.836974
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    import io
    import socket
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import _HTTPConnection
    from tornado.iostream import IOStream
    from tornado.testing import bind_unused_port

    sock, port = bind_unused_port()
    stream = IOStream(socket.socket(), io_loop=io_loop())
    stream.connect(("localhost", port), server_hostname="localhost")
    req = HTTPRequest("GET", "http://www.google.com")
    con = _HTTPConnection(req, stream, "127.0.0.1", io_loop())
    assert con.final_callback is not None
    stream.close()
    con.on_connection_close()
    assert con.final_callback is None

# Generated at 2022-06-24 09:16:37.849571
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado import ioloop
    from tornado import testing
    from tornado.http1connection import HTTP1ConnectionParameters
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.simple_httpclient import _RequestProxy
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import bind_unused_port
    from tornado.testing import main
    from tornado.testing import StartTornadoDebugModeMixin, AsyncTestCase
    from tornado.testing import _NotAThread
    from tornado.testing import gen_test

    class HTTPConnectionTest(AsyncTestCase, StartTornadoDebugModeMixin):
        def setUp(self):
            super().setUp()
            self.stream = ioloop.IOLoop.current().create_future()
           

# Generated at 2022-06-24 09:16:38.900091
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()



# Generated at 2022-06-24 09:16:47.544715
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    data = common.RandomData()
    data.check_all_types = False
    #first_line = generate_HTTPResponseStartLine(data)
    #headers    = generate_HTTPHeaders(data)
    request = HTTPRequest(url="https://www.google.com")
    httpclient = HTTPClient()
    c = httpclient._HTTPConnection(request, io_loop=IOLoop(), max_header_size=65536, max_body_size=1000000000)
    first_line = httputil.ResponseStartLine(200, "OK", "HTTP/1.1")

# Generated at 2022-06-24 09:16:51.970018
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    req = HTTPRequest("http://www.example.com")
    client = HTTPClient()
    stream = IOStream(socket.socket(), io_loop=IOLoop.current())
    connection = client._HTTPConnection(client, req, stream)
    connection.run()
    pass



# Generated at 2022-06-24 09:17:02.606096
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from tornado import httpserver
    from tornado import iostream
    from tornado import netutil
    from tornado import testing

    class DummyHTTP1Connection(HTTP1Connection):
        def __init__(self, stream: IOStream, address_family: socket.AddressFamily) -> None:
            self.stream = stream
            self.address_family = address_family

        def write_headers(self, start_line: httputil.RequestStartLine, headers: httputil.HTTPHeaders) -> None:
            raise NotImplementedError

        def write(self, chunk: bytes) -> None:
            raise NotImplementedError

        def finish(self) -> None:
            raise NotImplementedError

        def read_response(self, request: _HTTPConnection) -> None:
            raise NotImplementedError



# Generated at 2022-06-24 09:17:09.299599
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    from tornado import ioloop

    def _handle_request(response):
        print("get a response!")

    http_client = SimpleAsyncHTTPClient()
    http_client.fetch(
        "http://www.baidu.com", _handle_request, request_timeout=5,
    )

    ioloop.IOLoop.instance().start()



# Generated at 2022-06-24 09:17:16.397556
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError("timed out").code == 599


_DEFAULT = object()
_DEFAULT_CA_CERTS = None
_DEFAULT_CA_CERTS_PATH = None
_DEFAULT_TIMEOUT = 20.0

_TYPE_INT = type(0)

# Generated at 2022-06-24 09:17:28.721376
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.stack_context import NullContext

    def mock_init(self):
        self._initialize = True

    def mock_close(self):
        self._closed = True

    old_init = TCPClient.__init__
    old_close = TCPClient.close
    TCPClient.__init__ = mock_init
    TCPClient.close = mock_close

    try:
        http_client = SimpleAsyncHTTPClient()
        http_client.initialize()
        assert http_client._initialize

    finally:
        TCPClient.__init__ = old_init
        TCPClient.close = old_close

    def read_from_socket(fd, n):
        if fd == 1:
            raise IOError()

# Generated at 2022-06-24 09:17:29.429251
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass

# Generated at 2022-06-24 09:17:42.002703
# Unit test for method finish of class _HTTPConnection

# Generated at 2022-06-24 09:17:44.741668
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # tests for method close of class SimpleAsyncHTTPClient
    # existence of method close of class SimpleAsyncHTTPClient
    assert isinstance(SimpleAsyncHTTPClient.close, Callable)

# Generated at 2022-06-24 09:17:52.722348
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    @gen.coroutine
    def test_coroutine_close():
        # SimpleAsyncHTTPClient can be closed while pending
        # requests remain.  These are aborted (with a connection reset).
        http_client = SimpleAsyncHTTPClient(force_instance=True)
        yield http_client.fetch("http://www.google.com")
        http_client.close()

    IOLoop.current().run_sync(test_coroutine_close)

# Generated at 2022-06-24 09:18:04.842743
# Unit test for method data_received of class _HTTPConnection

# Generated at 2022-06-24 09:18:10.146524
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    stream = IOStream(socket.socket(), io_loop=IOLoop.current())
    sockaddr = ("", 0)
    connection = HTTP1Connection(
        stream,
        True,
        HTTP1ConnectionParameters(
            no_keep_alive=True,
            max_header_size=4096,
            max_body_size=None,
            decompress=False,
        ),
        sockaddr,
    )
    # At this moment, _HTTPConnection has not been executed and _run_request() method
    # of EventualResult instance has not been called, so the status of the instance
    # is "result".
    assert connection.status == "result"
    # There is no response at this moment, so HTTP_REQUEST will not be found.
    assert connection.delegate.delegate is None


# Generated at 2022-06-24 09:18:15.879459
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    with pytest.raises(TornadoHTTPClientError):
        http_client = AsyncHTTPClient()
        request = HTTPRequest("http://127.0.0.1:8080/", method="GET")
        http_client._fetch_impl(request, None, None, None)

# Generated at 2022-06-24 09:18:26.650974
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from tornado.iostream import IOStream
    from tornado.testing import AsyncHTTPTestCase, get_unused_port, bind_unused_port
    from tornado.tcpserver import TCPServer
    from tornado.httpserver import HTTPServer
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import tornado.http1connection
    from tornado.httputil import HTTPServerRequest
    from tornado.iostream import IOStream
    from tornado.iostream import SSLIOStream
    from tornado.stack_context import ExceptionStackContext
    from tornado.tcpserver import TCPServer
    from tornado.testing import AsyncHTTPTestCase, get_unused_port, bind_unused_port
    from tornado.test.util import unittest
    from tornado.util import b
    from tornado.web import Application, RequestHandler


# Generated at 2022-06-24 09:18:30.074929
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    HTTPStreamClosedError(None).__str__()
    HTTPStreamClosedError('').__str__()
    HTTPStreamClosedError('string message').__str__()



# Generated at 2022-06-24 09:18:37.267120
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    content = 'Hello World'
    first_line = httputil.StatusLine('HTTP/1.1', 200, 'OK')
    headers = httputil.HTTPHeaders(Content_Type="text/html")
    chunk = 'Hello World'
    data = [b'Hello World']
    _HTTPConnection.headers_received(first_line, headers)
    _HTTPConnection.data_received(chunk)
    _HTTPConnection.data_received = mock.MagicMock(return_value = data)
    assert _HTTPConnection.data_received() == data

# Generated at 2022-06-24 09:18:47.337769
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    '''
    Unit test for method run of class _HTTPConnection
    '''
    h = _HTTPConnection()
    # test result when req_info, stream and on_connect are none
    h.run(None, None, None)
    assert h is not None
    # test result when req_info, stream and on_connect are not none
    req_info = {'host': 'host', 'port': 0}
    stream = IOStream(socket.socket())
    on_connect = lambda: None
    h.run(req_info, stream, on_connect)
    assert h is not None

# Generated at 2022-06-24 09:18:50.063298
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    message = 'Stream closed'
    ex = HTTPStreamClosedError(message)
    assert ex.__str__() == 'Stream closed'
    pass



# Generated at 2022-06-24 09:18:59.901793
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    import uuid
    import json
    import base64
    import hmac
    import hashlib
    from urllib.parse import quote as _q
    from urllib.parse import urlencode as _urlencode
    from urllib.parse import urlparse, parse_qs
    from io import BytesIO
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import HTTPError
    from tornado.util import b, bytes_type
    from tornado.httputil import (
        HTTPHeaders,
        HTTPFile,
    )

# Generated at 2022-06-24 09:19:02.663610
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    exc = HTTPTimeoutError("timeout message")
    assert exc.code == 599
    assert exc.message == "timeout message"
    assert str(exc) == "timeout message"



# Generated at 2022-06-24 09:19:04.408863
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    from tornado.httpclient import HTTPStreamClosedError
    HTTPStreamClosedError().__str__()


# Generated at 2022-06-24 09:19:09.509016
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    conn = _HTTPConnection(
		object,
		object,
		object,
		object,
		object,
		object,
	)
	
    conn.on_connection_close()

# Generated at 2022-06-24 09:19:12.674023
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    fetch_impl=SimpleAsyncHTTPClient.fetch_impl
    callback=lambda x:0
    fetch_impl(request_obj,callback)
    assert callback(HTTPResponse(request_obj))==0
#################################################################

# Generated at 2022-06-24 09:19:18.412241
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    err = HTTPStreamClosedError("test err")
    assert _unicode(err) == "test err"
    assert err.args == ("test err",)
    err2 = HTTPStreamClosedError()
    err3 = HTTPStreamClosedError("err", "args")
    assert err2.message == "Stream closed"
    assert err3.message == "err"

_DEFAULT_CA_CERTS = "/etc/ssl/certs/ca-certificates.crt"

_VALID_SOURCE_ADDRESS = re.compile(r"\A\d+\..*\Z")



# Generated at 2022-06-24 09:19:20.459419
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    obj = HTTPStreamClosedError('message')
    assert str(obj) == 'message'


# Generated at 2022-06-24 09:19:22.376738
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    client = SimpleAsyncHTTPClient()
    assert isinstance(client._waiting, (dict))

# Generated at 2022-06-24 09:19:33.220530
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    http_client = SimpleAsyncHTTPClient()
    request = HTTPRequest("http://127.0.0.1/")

    def callback(response):
        pass

    # For SimpleAsyncHTTPClient.fetch_impl, request and callback are always given
    # And the method fetch_impl will default timeout_handle to None
    http_client.fetch_impl(request, callback)


_DEFAULT_CA_CERTS = os.path.join(os.path.dirname(__file__), "cacerts.txt")
_DEFAULT_CA_CERTS_GIT = os.path.join(os.path.dirname(__file__), "cacerts-git.txt")