

# Generated at 2022-06-24 09:09:40.719394
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    #         self,
    #         first_line: Union[httputil.ResponseStartLine, httputil.RequestStartLine],
    #         headers: httputil.HTTPHeaders,
    #     ) -> None:
    app = web.Application()
    client = AsyncHTTPClient(app)
    h = _HTTPConnection(client, HTTPRequest("http://www.example.com/"), None)
    h.headers_received(("https://www.example.com", 200, "OK"), httputil.HTTPHeaders({"Location": "https://www.example.com/other"}))
    if h._should_follow_redirect():
        pass

# Generated at 2022-06-24 09:09:51.831843
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Test _HTTPConnection._on_connection_close
    # Setup
    conn = _HTTPConnection()
    conn._handle_exception = Mock()

    conn._should_follow_redirect = Mock()
    conn._should_follow_redirect.return_value = False

    conn.final_callback = Mock()
    conn.final_callback.return_value = None

    conn.stream = Mock()
    conn.stream.error = None

    # Execute
    conn.on_connection_close()
    # Verify
    conn.final_callback.assert_called_with(
        HTTPResponse(
            request=None,
            code=599,
            error=HTTPStreamClosedError(message="Stream closed"),
            request_time=None,
            start_time=None,
        )
    )
    conn._handle

# Generated at 2022-06-24 09:10:04.382920
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    with pytest.raises(UnsupportedBrowser), mock.patch('tornado.httpclient.HTTPRequest') as mock_HTTPRequest:
        mock_HTTPRequest.return_value = mock
        mock.body_producer = None
        mock.follow_redirects = False
        mock.max_redirects = None
        mock.header_callback = None
        mock.streaming_callback = None
        mock.chunk_size = None
        mock.release_callback = None
        mock.request_timeout = None
        mock.connect_timeout = None
        mock.validate_cert = True
        mock.ca_certs = None
        mock.client_cert = None
        mock.client_key = None
        mock.ssl_options = None
        mock.proxy_host = None
        mock.proxy_port = None
        mock

# Generated at 2022-06-24 09:10:05.583794
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError("abc").__str__() == "abc"
    assert HTTPTimeoutError("").__str__() == "Timeout"



# Generated at 2022-06-24 09:10:13.029756
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    parse_url = urllib.parse.urlparse('http://localhost/path')
    request = HTTPRequest('http://localhost/path', uri='http://localhost/path', method='GET')
    ComunicationWithServer = CommunicationWithServer('nodename', 'http://localhost/path', 'GET', request, parse_url)
    ComunicationWithServer.test_test_test()
    return request

test_SimpleAsyncHTTPClient_fetch_impl()



# Generated at 2022-06-24 09:10:19.312534
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    key = object()
    self.queue.append((key, request, callback))
    assert request.connect_timeout is not None
    assert request.request_timeout is not None
    timeout_handle = None
    if len(self.active) >= self.max_clients:
        timeout = (
            min(request.connect_timeout, request.request_timeout)
            or request.connect_timeout
            or request.request_timeout
        )  # min but skip zero
        if timeout:
            timeout_handle = self.io_loop.add_timeout(
                self.io_loop.time() + timeout,
                functools.partial(self._on_timeout, key, "in request queue"),
            )
    self.waiting[key] = (request, callback, timeout_handle)
    self._process_queue()

# Generated at 2022-06-24 09:10:20.970518
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert HTTPStreamClosedError("abc").__str__() == "abc"



# Generated at 2022-06-24 09:10:31.705083
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    class Request(HTTPRequest):
        """A single HTTP request."""
        def __init__(self, *args, **kwargs):
            self.max_header_size = kwargs.pop('max_header_size', None)
            super(Request, self).__init__(*args, **kwargs)

        def copy(self):
            copy = super(Request, self).copy()
            # For some strange reason, we don't copy the max_header_size.
            # Not sure if this is OK.
            # copy.max_header_size = self.max_header_size
            return copy

    # TODO: there is something fishy about the way we are calling this method.
    # for now, just skip it.
    return

    # method fetch_impl of class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:10:32.747163
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _HTTPConnection(HTTPResponse(), [], True)



# Generated at 2022-06-24 09:10:40.105511
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    request = mock.Mock(spec=HTTPRequest)
    request.follow_redirects = True
    request.max_redirects = 1
    request.request = request
    request.original_request = request
    request.url = "https://www.abv.bg"
    request.method = "GET"
    request.body = bytes([1, 2, 3])
    request.headers = httputil.HTTPHeaders()
    request.headers["Host"] = "abv.bg"
    client = mock.Mock(spec=SimpleAsyncHTTPClient)
    connection = _HTTPConnection(client, request, mock.Mock(), mock.Mock())
    connection.code = 301
    connection.headers = httputil.HTTPHeaders()
    connection.headers["Location"] = "abv.bg"

# Generated at 2022-06-24 09:10:44.841416
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # test initialize
    #
    # SimpleAsyncHTTPClient.initialize is the constructor of class SimpleAsyncHTTPClient
    
    
    
    
    
    
    
    
    
    
    
    
    pass

# Generated at 2022-06-24 09:10:54.807241
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():# pragma: no cover
    mock_resolver = mock.Mock()
    mock_resolver.resolve.return_value = "0.0.0.0", 80
    mock_client_opts = mock.Mock()
    mock_client_opts.max_header_size = 1 << 20
    mock_client_opts.max_body_size = 5 << 20
    mock_client_opts.resolver = mock_resolver
    mock_client_opts.default_host = "0.0.0.0"
    mock_client_opts.io_loop = mock.Mock()
    mock_client_opts.request_timeout = None
    mock_client_opts.connect_timeout = None
    mock_client_opts.follow_redirects = True
    mock_client_opts

# Generated at 2022-06-24 09:10:55.776391
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    with pytest.raises(HTTPError):
        HTTPStreamClosedError()


# Generated at 2022-06-24 09:10:56.956932
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    err = HTTPTimeoutError('msg')
    assert str(err) == 'Timeout'


# Generated at 2022-06-24 09:10:57.358510
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass



# Generated at 2022-06-24 09:11:09.820672
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado.iostream import IOStream
    io_loop = IOLoop()
    io_loop.make_current()
    io_stream = IOStream(socket.socket(), io_loop=io_loop)
    io_stream.connect(("www.google.com", 80), callback=lambda:None)
    io_stream.write(b"GET / HTTP/1.0\r\nHost: www.google.com\r\n\r\n")
    io_stream.read_until(b"\r\n\r\n", lambda data: print(data))
    requests = []
    def handle_request(request):
        requests.append(request)

# Generated at 2022-06-24 09:11:15.764160
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    e = HTTPStreamClosedError()
    assert e.code == 599
    assert e.message == ''
    assert str(e) == 'Stream closed'
    e = HTTPStreamClosedError('hahaha')
    assert e.code == 599
    assert e.message == 'hahaha'
    assert str(e) == 'hahaha'


# Generated at 2022-06-24 09:11:28.082955
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:11:35.828753
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # _HTTPConnection()
    http_request = HTTPRequest(url="url")
    connection = _HTTPConnection(request=http_request)
    print("finish(): ", connection.finish())

    # _HTTPConnection(
    #     object, object, object, object, object, object, object, object, object)
    http_request = HTTPRequest(url="url")
    connection = _HTTPConnection(
        client=None,
        request=http_request,
        stream=None,
        release_callback=None,
        final_callback=None,
        max_header_size=None,
        max_body_size=None,
        host_connections=None,
    )
    print("finish(): ", connection.finish())



# Generated at 2022-06-24 09:11:38.191562
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    e = HTTPStreamClosedError("This is an error")
    assert e.message =="This is an error"
    assert e.code == 599


# Generated at 2022-06-24 09:11:45.027074
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    http_client = SimpleAsyncHTTPClient()
    http_client.initialize()
    assert isinstance(http_client.max_clients, int)
    assert http_client.max_clients == 10
    assert isinstance(http_client.queue, collections.deque)
    assert isinstance(http_client.active, dict)
    assert isinstance(http_client.waiting, dict)
    assert isinstance(http_client.max_buffer_size, int)
    assert http_client.max_buffer_size == 104857600
    assert isinstance(http_client.resolver, Resolver)
    assert isinstance(http_client.tcp_client, TCPClient)
    http_client.initialize(max_clients = 1)
    assert isinstance(http_client.max_clients, int)
   

# Generated at 2022-06-24 09:11:55.516667
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    pass

    # test case 1
    # request object consists of method, url, body, headers,
    # allow_nonstandard_methods, request_timeout, streaming_callback,
    # header_callback, prepare_curl_callback, proxy_host, proxy_port,
    # proxy_username, proxy_password, connect_timeout, auth_username,
    # auth_password, auth_mode, user_agent, use_gzip, network_interface,
    # validate_cert, ca_certs, allow_ipv6

    # test case 2
    # request object consists of method, url, body, headers,
    # allow_nonstandard_methods, request_timeout, streaming_callback,
    # header_callback, prepare_curl_callback, proxy_host, proxy_port,
    # proxy_username, proxy_password, connect_

# Generated at 2022-06-24 09:11:57.398861
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # _HTTPConnection().finish()
    # TODO
    pass

# Generated at 2022-06-24 09:11:58.087909
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    AsyncHTTPClient()



# Generated at 2022-06-24 09:12:07.051456
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    print("-" * 50)
    print("Testing _HTTPConnection constructor")
    io_loop = IOLoop.current()
    io_loop.run_sync(_test__HTTPConnection)
    print("Done")
    print("-" * 50)


async def _test__HTTPConnection():
    try:
        conn = _HTTPConnection(
            "www.google.com",
            80,
            None,
            None,
            headers=httputil.HTTPHeaders(),
            timeout=None,
            max_buffer_size=None,
        )
    except Exception as e:
        print("Failed")
        print(e)
    else:
        print("Passed")



# Generated at 2022-06-24 09:12:15.307974
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Initalize a instance of SimpleAsyncHTTPClient
    s = SimpleAsyncHTTPClient()
    # Set parameters for fetch_impl
    request = HTTPRequest('http://www.google.com')
    callback = HTTPResponse
    # Call fetch_impl to do something
    try:
        s.fetch_impl(request, callback)
        assert True
    except:
        assert False


# Generated at 2022-06-24 09:12:18.301068
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    response = None
    if response == None:
        raise HTTPError(500)
    headers = None
    if headers == None:
        raise HTTPError(500)
    test._HTTPConnection_run(response, headers)


# Generated at 2022-06-24 09:12:29.004527
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    class MockStream(object):
        def __init__(self, *args, **kwargs):
            pass
        def close(self, *args, **kwargs):
            pass
    stream = MockStream()
    chunks = []
    origin_chunks = []
    origin_request = object()
    request = object()
    request.original_request = origin_request
    connection = _HTTPConnection(
        stream=stream,
        request=request,
        final_callback=None,
        release_callback=None,
        chunks=chunks,
        start_time=time.time(),
        io_loop=object(),
        max_header_size=0,
        max_body_size=0,
        decompress=False)
    connection.request.original_request = origin_request

# Generated at 2022-06-24 09:12:31.226669
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    error = HTTPStreamClosedError("message")
    error.__str__()
    error.message = None
    error.__str__()



# Generated at 2022-06-24 09:12:33.552603
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    try:
        test_client = SimpleAsyncHTTPClient()
        test_client.close()
        return True
    except:  # noqa: E722
        return False



# Generated at 2022-06-24 09:12:36.829819
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Given
    client = SimpleAsyncHTTPClient()

    # When
    client.close()

    # Then
    assert client.queue
    assert client.active
    assert client.waiting



# Generated at 2022-06-24 09:12:41.364131
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    assert HTTPTimeoutError("foo")
    assert str(HTTPTimeoutError("foo")) == "foo"
    assert str(HTTPTimeoutError(message="foo")) == "foo"



# Generated at 2022-06-24 09:12:42.786202
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _HTTPConnection(None, None, None)



# Generated at 2022-06-24 09:12:51.465109
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado.httpclient import HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import _encode_body
    import tornado.gen
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import AsyncHTTPClient
    from tornado.test.gen_test import unittest
    import tornado.testing
    import tornado.util
    import tornado.web
    import logging
    import io
    import json
    import os
    import base64
    import sys
    import types

    class PostHandler(tornado.web.RequestHandler):
        def post(self):
            self.set_header("Content-Type", "application/json")

# Generated at 2022-06-24 09:12:55.696230
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("Test Error")
    assert error.code == 599
    assert error.message == "Test Error"
    assert isinstance(error, HTTPError)
    assert str(error) == "Test Error"



# Generated at 2022-06-24 09:12:58.714013
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    http_connection = _HTTPConnection(None)
    assert http_connection


# Generated at 2022-06-24 09:13:00.856082
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    connection = _HTTPConnection(None, None)
    connection.start()
    assert connection.stream is not None
    assert connection.code == 0
    assert connection.headers is None


# Generated at 2022-06-24 09:13:03.282805
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    """
    This test case is from *tornado/test/httpclient_test.py*
    """


# Generated at 2022-06-24 09:13:05.854928
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    err = HTTPTimeoutError("Timeout")
    assert err.code == 599
    assert err.message == "Timeout"
    assert str(err) == "Timeout"



# Generated at 2022-06-24 09:13:14.592034
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from tornado.testing import AsyncHTTPTestCase, gen_test
    from tornado.httpclient import AsyncHTTPClient
    import logging
    import six
    from unittest import mock

    """
    path('/', views.home, name='home'),
    path('/chat/<str:room_name>/', views.room, name='room'),
    path('/<str:room_name>/<str:username>/', views.receive_message),
    path('/<str:room_name>/<str:username>/message/', views.MessageView.as_view()),
    """
    class TestOnConnectionClose(AsyncHTTPTestCase):
        def get_app(self):
            from django.contrib import admin
            from tornado_test_app import urls as test_app_urls

# Generated at 2022-06-24 09:13:20.115345
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    test_initialize_1 = SimpleAsyncHTTPClient()
    assert test_initialize_1.max_buffer_size == 104857600
    assert test_initialize_1.max_header_size == None
    assert test_initialize_1.max_body_size == None
    assert test_initialize_1.max_clients == 10
    assert test_initialize_1.queue == collections.deque([])
    assert test_initialize_1.active == {}
    assert test_initialize_1.waiting == {}


# Generated at 2022-06-24 09:13:25.641891
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    with closing(Configurable_HTTPClient(config_dict={"max_clients": 30})) as client:
        client._HTTPConnection_init(None, None, None, None)
        client.on_connection_close()


# Generated at 2022-06-24 09:13:27.811697
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    http_connection = _HTTPConnection()
    assert(isinstance(http_connection, _HTTPConnection))


# Generated at 2022-06-24 09:13:38.982311
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import unittest
    import urllib.parse
    from unittest import mock

    from tornado import concurrent
    from tornado.testing import AsyncHTTPTestCase, AsyncHTTPSTestCase, bind_unused_port, gen_test
    from tornado.test.util import unittest, skipOnTravis, skipOnAppEngine, skipIfNoIPv6
    from tornado.web import RequestHandler, Application
    from tornado.websocket import WebSocketHandler

    test_url = '/test'

    class TestHandler(RequestHandler):
        @gen.coroutine
        def get(self):
            self.write('hello')
            yield gen.sleep(0.1)
            self.finish()

    class TestWebSocketHandler(WebSocketHandler):
        def open(self):
            self.write_message('hello')


# Generated at 2022-06-24 09:13:39.901489
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass


# Generated at 2022-06-24 09:13:41.830686
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # _HTTPConnection.headers_received(first_line, headers)
    assert False # TODO: implement your test here


# Generated at 2022-06-24 09:13:52.544565
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    HTTPTimeoutError("Timeout")


if sys.version_info >= (3, 7):
    from typing import Final

    # Mentioned in the docs, but not in tornado.concurrent's public API
    # in 3.7.
    Future = typing.cast(Final, typing.Any)
else:  # pragma: no cover
    from typing import _FutureAlias

    Future = _FutureAlias

# Mentioned in the docs, but not in tornado.iostream's public API in 3.7.
_IOStream = typing.cast(Final, IOStream)

POSIX = (os.name == 'posix')
WINDOWS = (os.name == 'nt')



# Generated at 2022-06-24 09:13:56.294481
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Test when max_clients is less than 0 or equal to 0 or greater than 0
    try:
        SimpleAsyncHTTPClient()
    except ValueError:
        pass
    SimpleAsyncHTTPClient(max_clients = 10)
    SimpleAsyncHTTPClient(max_clients = 100)


# Generated at 2022-06-24 09:14:02.719885
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import argparse
    import logging
    import sys
    from tornado.httpclient import _HTTPConnection
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import _RequestProxy
    from tornado.iostream import IOStream
    from tornado.iostream import SSLIOStream
    from tornado.netutil import ssl_options_to_context
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import bind_unused_port
    from tornado.testing import get_unused_port
    from tornado.testing import requires_host
    from tornado.testing import unittest
    from tornado.testing import gen_test
    from tornado.util import b
    from tornado.util import _unicode
    from tornado.util import bytes_

# Generated at 2022-06-24 09:14:08.472716
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    def mock_client():
        conn = _HTTPConnection("google.com", 443, 8080, ssl_options=None)
        assert conn._sockaddr == ("google.com", 443, 8080)

    io_loop = IOLoop.current()
    io_loop.run_sync(mock_client)



# Generated at 2022-06-24 09:14:10.542321
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError('http stream closed')
    except Exception as e:
        assert e.code == 599 and e.message == 'http stream closed'


# Generated at 2022-06-24 09:14:13.431404
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # _HTTPConnection = self.HTTPConnection()
    # self.assertEqual(_HTTPConnection.finish(), None)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 09:14:22.346052
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Test with no arguments
    try:
        tornado.simple_httpclient.SimpleAsyncHTTPClient().fetch_impl();
    except TypeError as err:
        assert(err.args[0] == "fetch_impl() missing 2 required positional arguments: 'request' and 'callback'")
    # Test with one argument
    try:
        tornado.simple_httpclient.SimpleAsyncHTTPClient().fetch_impl(1);
    except TypeError as err:
        assert(err.args[0] == "fetch_impl() missing 1 required positional argument: 'callback'")
    # Test with two arguments

# Generated at 2022-06-24 09:14:32.390359
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-24 09:14:34.032676
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    obj = SimpleAsyncHTTPClient()
    obj.initialize()

# Generated at 2022-06-24 09:14:35.299716
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    """

    """
    pass


# Generated at 2022-06-24 09:14:40.243977
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    async def async_func(self):
        # Create the test bed for headers_received method
        self.first_line = "HTTP/1.1 302 Found"
        self.headers = {"Location" : "http://www.google.com"}
        self.code = 302
        self.request.follow_redirects = True
        self.request.max_redirects = 2

        # Call the method under test
        await self.headers_received(self.first_line, self.headers)

        # Assertion
        self.assertEqual(self.code, 302)
        self.assertEqual(self.reason, "Found")
        self.assertEqual(self.headers.get("Location"), "http://www.google.com")
        self.assertEqual(self.request.max_redirects, 1)
       

# Generated at 2022-06-24 09:14:49.446361
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.ioloop import IOLoop
    from tornado.tcpclient import TCPClient
    from tornado.log import app_log

    class FakeAsyncHTTPClient(AsyncHTTPClient):

        def __init__(self, io_loop, tcp_client, resolver):
            super().__init__(io_loop=io_loop, resolver=resolver)
            self.tcp_client = tcp_client

    ioloop = IOLoop()
    tcp_client = TCPClient()
    http_client = FakeAsyncHTTPClient(ioloop, tcp_client, None)

    app_log.info("fetching")
    req = HTTPRequest(url="https://www.google.com/")

# Generated at 2022-06-24 09:14:50.129412
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass

# Generated at 2022-06-24 09:14:59.080958
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    client = SimpleAsyncHTTPClient()
    assert client.max_clients == 10
    assert client.queue == collections.deque()
    assert client.active == {}
    assert client.waiting == {}
    assert client.max_buffer_size == 104857600
    assert client.max_header_size == None
    assert client.max_body_size == 104857600
    assert type(client.resolver) == tornado.netutil.Resolver
    assert client.own_resolver == True
    assert type(client.tcp_client) == tornado.tcpclient.TCPClient
    assert type(client.tcp_client.resolver) == tornado.netutil.Resolver
    assert client.tcp_client.resolver.resolver == client.resolver


# Generated at 2022-06-24 09:15:07.518328
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    handler = SimpleAsyncHTTPClient()
    handler._on_timeout= lambda *args: None
    request = HTTPRequest(
        url=f"http://{handler.host}:{handler.port}/",
        validate_cert=True,
    )
    http_client = _HTTPConnection(
        client=handler, request=request, release_callback=None,
        io_loop=IOLoop(), max_header_size=None, max_body_size=None,
        start_time=0, final_callback=None,
    )
    http_client._remove_timeout = lambda: None #
    http_client.code = 301
    http_client.request.max_redirects = 1
    http_client.headers = httputil.HTTPHeaders()

# Generated at 2022-06-24 09:15:09.345416
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # TODO: If you want to implement a test, remove this line.
    pass

# Generated at 2022-06-24 09:15:09.933044
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    pass



# Generated at 2022-06-24 09:15:11.631146
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
	error = HTTPTimeoutError('errorMsg')
	assert str(error) == 'errorMsg'
# test done


# Generated at 2022-06-24 09:15:23.127781
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPConnection

    def test_redirect(self):
        # Don't follow 30x unless requested.
        response = self.fetch("/redirect", follow_redirects=False)
        self.assertEqual(response.code, 302)
        response = self.fetch("/redirect", follow_redirects=True)
        self.assertEqual(response.code, 200)
        self.assertEqual(response.headers["Content-Type"], "text/plain")
        self.assertEqual(response.body, b"This is the final destination.")
    AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")
    client = As

# Generated at 2022-06-24 09:15:25.297488
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError(message="")
    assert str(e) == "Stream closed"


# Generated at 2022-06-24 09:15:25.993449
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass

# Generated at 2022-06-24 09:15:34.410412
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from tornado import testing
    from tornado.testing import bind_unused_port, ExpectLog
    from tornado.httpclient import AsyncHTTPClient, HTTPError
    from tornado.httputil import HTTPHeaders
    from tornado.httputil import HTTPConnectionParameters
    from tornado.iostream import _ERRNO_CONNRESET

    # Close the connection explicitly rather than waiting for it.
    io_loop = IOLoop.current()


# Generated at 2022-06-24 09:15:35.158265
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-24 09:15:46.646168
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # async def
    from pprint import pprint
    from tornado.httpclient import HTTPRequest, HTTPResponse
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio
    from unittest import mock
    import socket
    import ssl
    import functools
    import contextlib
    import typing
    import os
    import requests

    def test_handle_request(async_client):
        """
        Test the _handle_request method of the SimpleAsyncHTTPClient class
        """
        with contextlib.ExitStack() as stack:
            key = object()
            async_client.active[key] = (
                None,
                None,
            )  # type: typing.Dict[object, typing.Tuple[HTTPRequest, Callable

# Generated at 2022-06-24 09:15:50.976826
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    """
    def close(self):
        super().close()
        if self.own_resolver:
            self.resolver.close()
        self.tcp_client.close()
    """
    pass


# Generated at 2022-06-24 09:15:57.423844
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
  request = HTTPRequest(url=_unicode('/'), validate_cert=False)
  client = SimpleAsyncHTTPClient()
  fetch_impl = _HTTPConnection(client, request, lambda: None, lambda: None)
  # Original implementation:
  #
  #   if self.final_callback is not None:
  #       message = "Connection closed"
  #       if self.stream.error:
  #           raise self.stream.error
  #       try:
  #           raise HTTPStreamClosedError(message)
  #       except HTTPStreamClosedError:
  #           self._handle_exception(*sys.exc_info())
  #
  # Test with simple implementation of error.

# Generated at 2022-06-24 09:16:04.687371
# Unit test for method on_connection_close of class _HTTPConnection

# Generated at 2022-06-24 09:16:06.963456
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    inst = HTTPTimeoutError("Foo")
    result = str(inst)
    assert result == 'Foo'


# Generated at 2022-06-24 09:16:08.772292
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    result = HTTPStreamClosedError(message="Test message")
    assert result == "Test message"



# Generated at 2022-06-24 09:16:10.570634
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    """
    Test _HTTPConnection.finish
    """
    # [TODO]
    pass

# Generated at 2022-06-24 09:16:13.171968
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Make sure that close() does not raise an exception
    client = SimpleAsyncHTTPClient(force_instance=True)
    client.close()

# Generated at 2022-06-24 09:16:23.723100
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def check(body: str, **kwargs) -> None:
        def on_response(response: HTTPResponse) -> None:
            if response.error:
                raise response.error
            assert response.body == body
            self.stop()

        req = HTTPRequest(http_client.HTTPServer.get_url("/echo"), **kwargs)
        http_client.AsyncHTTPClient().fetch(req, on_response)
        self.wait()

    def test_default():
        check("foo=bar", method="POST", body="foo=bar")

    def test_chunked_encoding():
        check(
            "foo=bar",
            method="POST",
            body="foo=bar",
            headers={"Transfer-Encoding": "chunked"},
        )


# Generated at 2022-06-24 09:16:26.828885
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    assert _HTTPConnection(
        None, None, None, None, None, None
    ).release_callback == None

# Generated at 2022-06-24 09:16:27.429434
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

# Generated at 2022-06-24 09:16:28.684579
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError("").message == "Timeout"


# Generated at 2022-06-24 09:16:30.056397
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    _ = HTTPStreamClosedError("Stream closed").__str__()
    pass



# Generated at 2022-06-24 09:16:37.894803
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("error message")
    assert error.code == 599
    assert error.message == "error message"
    assert str(error) == "error message"

if sys.platform == "win32":  # pragma: nocover
    try:
        # Python 3
        import winreg
    except ImportError:
        # Python 2
        import _winreg as winreg  # type: ignore

    _PROXY_TYPES = {
        winreg.HKEY_CURRENT_USER: "HKEY_CURRENT_USER",
        winreg.HKEY_LOCAL_MACHINE: "HKEY_LOCAL_MACHINE",
    }

    _HTTP_PROXY_KEY = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"

# Generated at 2022-06-24 09:16:39.322698
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    obj = HTTPTimeoutError('foo')
    print(obj)


# Generated at 2022-06-24 09:16:47.674962
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    http_client = HTTPClient()
    http_client.fetch(HTTPRequest(url="https://www.google.co.kr", proxy_host="proxy_host", proxy_port=888, proxy_username="proxy_username", proxy_password="proxy_password", proxy_auth_mode="", connect_timeout=10.0, request_timeout=20.0, follow_redirects=True, max_redirects=20, user_agent=None, use_gzip=None, network_interface=None, streaming_callback=None, header_callback=None, decompress_response=False, proxy_headers=None, auth_username="auth_username", auth_password="auth_password", auth_mode=""))


if __name__ == '__main__':
    test__HTTPConnection_finish()

# Generated at 2022-06-24 09:16:50.996676
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # self.assertTrue(hasattr(self.TestHandler, 'get'))
    # assert  hasattr(self.TestHandler, 'get')
    client = SimpleAsyncHTTPClient(force_instance=True)
    client.close()



# Generated at 2022-06-24 09:16:55.348517
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    # TODO: Find a better way to test this one
    ev = HTTPTimeoutError("timeout")
    if str(ev) == "Timeout":
        print("Success")
    else:
        raise TypeError("Failed")



# Generated at 2022-06-24 09:16:56.000831
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    pass


# Generated at 2022-06-24 09:16:57.971409
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    a = HTTPTimeoutError("m")
    assert a.__str__() is "m"



# Generated at 2022-06-24 09:17:06.422383
# Unit test for method on_connection_close of class _HTTPConnection

# Generated at 2022-06-24 09:17:09.211225
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    # type: (...) -> None
    err = HTTPTimeoutError('some message')
    s = str(err)
    assert s == 'some message' or s == 'Timeout'



# Generated at 2022-06-24 09:17:11.838712
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    assert HTTPStreamClosedError(None).__str__() == "Stream closed"
    assert HTTPStreamClosedError('Failed to connect.').__str__() == "Failed to connect."


# Generated at 2022-06-24 09:17:23.495888
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    import io
    import unittest
    import tornado
    class test_HTTPConnection(unittest.TestCase):
        def test_data_received(self):
            self.Chunks = [b"1", b"2", b"3", b"4", b"5", b"6", b"7", b"8", b"9", b"0"]
            test_stream = io.BytesIO(b"1234567890")
            client = HTTPClient()
            client._AsyncHTTPClient__connections["key"] = _HTTPConnection(
                client,
                test_stream,
                client,
                client.io_loop,
                "http://localhost/",
                "key",
                {}
            )
            client._AsyncHTTPClient__connections["key"].chunks = []
            client._AsyncHTTPClient__connections

# Generated at 2022-06-24 09:17:33.210096
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    method = AsyncHTTPClient.fetch_impl
    # self.max_clients = max_clients
    # self.queue = (
    #     collections.deque()
    # )  # type: Deque[Tuple[object, HTTPRequest, Callable[[HTTPResponse], None]]]
    # self.active = (
    #     {}
    # )  # type: Dict[object, Tuple[HTTPRequest, Callable[[HTTPResponse], None]]]
    # self.waiting = (
    #     {}
    # )  # type: Dict[object, Tuple[HTTPRequest, Callable[[HTTPResponse], None], object]]
    # self.max_buffer_size = max_buffer_size
    # self.max_header_size = max_header_size
    #

# Generated at 2022-06-24 09:17:37.779801
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    exc = HTTPStreamClosedError("Stream Closed")
    assert exc.message == "Stream Closed"
    assert exc.code == 599
    assert exc.status_code == 599
    assert isinstance(exc.response, HTTPResponse)


# Generated at 2022-06-24 09:17:42.935382
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    # fmt: off
    # Constructor of class HTTPStreamClosedError can accept a string message as parameter.
    # fmt: on
    message = "Stream closed"
    error = HTTPStreamClosedError(message)
    assert error.code == 599
    assert error.message == message
    assert str(error) == message


# Generated at 2022-06-24 09:17:47.712209
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # 如果初始化消息message为空，则输出为Stream closed
    obj = HTTPStreamClosedError('')
    assert repr(obj) == '599: Stream closed'
    # 否则输出为message
    obj2 = HTTPStreamClosedError('error')
    assert repr(obj2) == '599: error'


if typing.TYPE_CHECKING:
    from typing import Optional

    # Subset of socket.error arguments that should be retried.
    SocketErrorArgs = Tuple[
        int, str, Optional[str], Optional[int], Optional[int], Optional[str], Optional[str]
    ]



# Generated at 2022-06-24 09:18:00.420019
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    mocked_client_class = Mock()
    mocked_client_class.max_header_size = 1024

    mocked_request_class = Mock()
    mocked_request_class.url = "www.test.com"
    mocked_request_class.method = "GET"
    mocked_request_class.headers = "test_headers"
    mocked_request_class.body = "test_body"
    mocked_request_class.auth_username = "admin"
    mocked_request_class.auth_password = "password"
    mocked_request_class.auth_mode = "basic"
    mocked_request_class.user_agent = "test_user_agent"
    mocked_request_class.validate_cert = "test_validate_cert"

# Generated at 2022-06-24 09:18:03.038816
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import tornado.httpclient
    tornado.httpclient.AsyncHTTPClient = SimpleAsyncHTTPClient


# Generated at 2022-06-24 09:18:11.031092
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from . import httpclient
    from . import parsers
    from . import utils
    from . import httputil
    from . import client
    import functools
    import io
    from . import auth
    from . import _iostream_clients
    from . import io
    from . import netutil
    from . import ssl
    import sys
    import typing
    import typing_extensions
    import ssl
    import tornado.iostream
    import tornado.stack_context
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import unittest

    #from tornado.http1connection import HTTP1ConnectionParameters
    #from tornado.platform.auto import set_close_exec
    #from tornado.iostream import IOStream
    #from tornado.simple_httpclient import SimpleAsyncHTTP

# Generated at 2022-06-24 09:18:12.312412
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    http_client = SimpleAsyncHTTPClient()
    http_client.initialize()


# Generated at 2022-06-24 09:18:24.096687
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    class MockLogger:
        def __init__(self) -> None:
            self.logs = []

        def info(self, *args) -> None:
            self.logs.append(args)

    class MockStream(object):
        def __init__(self) -> None:
            self.closed = False

        def close(self) -> None:
            self.closed = True

    class MockRequest(object):
        def __init__(self) -> None:
            self.url = ""
            self.max_redirects = 0
            self.headers = httputil.HTTPHeaders({"User-Agent": ""})
            self.follow_redirects = True
            self.streaming_callback = None


# Generated at 2022-06-24 09:18:33.937807
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    client_conn = _HTTPConnection(
        HTTPClient(), HTTPRequest("GET", "http://127.0.0.1:2345"), None
    )
    assert client_conn.client == HTTPClient()
    assert client_conn.request == HTTPRequest("GET", "http://127.0.0.1:2345")
    assert client_conn.stream is None
    assert client_conn.start_time == 0.0
    assert client_conn._timeout is None
    assert client_conn.code is None
    assert client_conn.reason == None
    assert client_conn.headers == None
    assert client_conn.chunks == []
    assert client_conn.final_callback == None
    assert client_conn.release_callback == None
    assert client_conn.io_loop == IOLoop.current()
    assert client_conn

# Generated at 2022-06-24 09:18:38.271912
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    '''Test case for HTTPStreamClosedError class in simple_httpclient.py'''
    errMsg = "Failed to execute HTTP request: Stream closed"
    errObj = HTTPStreamClosedError(errMsg)

    if not (errObj.code == 599 and str(errObj) == errMsg):
        print("Test for HTTPStreamClosedError failed")


# Generated at 2022-06-24 09:18:39.985275
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection.finish(None)


# Generated at 2022-06-24 09:18:43.188835
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError('Timeout')
    assert str(error) == 'Timeout'
    assert error.code == 599


# Generated at 2022-06-24 09:18:54.275051
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    chunk = b"chunk"
    self = _HTTPConnection(request_proxy, client, io_loop, sock)
    assert self.request.streaming_callback is not None

    def assert_streaming_callback(chunk: bytes) -> None:
        if type(self) is _HTTPConnection:
            # The first time it is called, assert the chunk value
            assert chunk == b"chunk"
            # The second time it is called, raise an exception
            self.request.streaming_callback = None
        elif type(self.request) is _RequestProxy:
            # The first time it is called, assert the chunk value
            assert chunk == b"chunk"
            # The second time it is called, raise an exception
            self.request.streaming_callback = None
        else:
            assert False

# Generated at 2022-06-24 09:18:57.000206
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError(): # real signature unknown; restored from __doc__
    """ test_HTTPStreamClosedError() -> None """
    pass

# classes


# Generated at 2022-06-24 09:18:58.757340
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    http_timeout_error = HTTPTimeoutError('Timeout')
    assert http_timeout_error.code == 599



# Generated at 2022-06-24 09:19:08.083130
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    stream = IOStream(socket.socket(), io_loop=IOLoop.current())
    request = HTTPRequest(url='test', method='test')
    client = HTTPClient(io_loop=IOLoop.current(), force_instance=True)
    instance = _HTTPConnection(
        request,
        client,
        self.io_loop,
        self._release,
        self.final_callback,
        self._sockaddr,
        self.max_header_size,
        self.max_body_size,
        self.start_time,
        self.start_wall_time,
    )
    instance.stream = stream
    instance.final_callback = 'test'
    instance.on_connection_close()
    assert isinstance(instance.stream.error, HTTPStreamClosedError)
    assert instance.stream



# Generated at 2022-06-24 09:19:11.141762
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    return # SKIP


# Generated at 2022-06-24 09:19:14.830299
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass #TODO: implement your test here



# Generated at 2022-06-24 09:19:15.347385
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    pass



# Generated at 2022-06-24 09:19:16.276397
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass



# Generated at 2022-06-24 09:19:28.615312
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """test__HTTPConnection_headers_received()"""
    # test_headers_received
    async def _(stream: "IOStream") -> None:
        # get rid of the test HTTP proxy
        if httputil.ProxyInfo.in_use():
            httputil.ProxyInfo.in_use(False)

        httputil.HTTPConnection.default_headers = httputil.HTTPHeaders({"foo": "bar"})
        request = HTTPRequest(url="http://example.com/path")
        conn = _HTTPConnection(
            stream,
            request,
            client=None,
            io_loop=IOLoop(),
            max_header_size=None,
            max_body_size=None,
        )
        conn.start()

# Generated at 2022-06-24 09:19:29.675607
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass



# Generated at 2022-06-24 09:19:33.997092
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    url = "http://www.baidu.com"
    request = HTTPRequest(url)
    asyncHTTPClient = SimpleAsyncHTTPClient()
    asyncHTTPClient.initialize(max_clients=10)
    asyncHTTPClient.fetch_impl(request, print)
    asyncHTTPClient.close()
    