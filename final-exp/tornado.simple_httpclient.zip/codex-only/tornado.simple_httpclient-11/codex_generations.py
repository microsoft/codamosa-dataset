

# Generated at 2022-06-24 09:09:34.702126
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    req = HTTPRequest(
        url="http://test",
        method="GET",
        connect_timeout=1,
        request_timeout=1,
        follow_redirects=False,
        max_redirects=0,
        decompress_response=False,
    )
    client = AsyncHTTPClient()
    conn = _HTTPConnection(
        client,
        req,
        lambda: None,
        lambda: None,
        lambda: None,
        client.io_loop,
    )
    conn.headers_received(
        httputil.ResponseStartLine(200, "OK"),
        httputil.HTTPHeaders({"Status": "200 OK"}),
    )
    assert conn.code == 200

# Generated at 2022-06-24 09:09:36.460613
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert HTTPTimeoutError("test").code == 599
    assert str(HTTPTimeoutError("test")) == "test"



# Generated at 2022-06-24 09:09:47.861357
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    assert str(HTTPTimeoutError("foo")) == "foo"
    assert str(HTTPTimeoutError("")) == "Timeout"
    assert str(HTTPTimeoutError(None)) == "Timeout"

if sys.version_info >= (3, 7):
    # Most of the time we don't want to type-check the httpclient module,
    # but it's useful to do so during development.
    try:
        from typing import Protocol  # noqa
    except ImportError:
        from typing_extensions import Protocol  # type: ignore
    else:
        from typing import final  # noqa


    class _HTTP1ClientDelegate(Protocol):
        def start_request(self, request: HTTPRequest, conn: HTTP1Connection) -> None:
            ...


# Generated at 2022-06-24 09:09:49.265676
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    io_loop = IOLoop.current()
    client = SimpleAsyncHTTPClient(io_loop=io_loop, max_clients=5)
    assert client.max_clients == 5


# Generated at 2022-06-24 09:09:49.889809
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
  pass


# Generated at 2022-06-24 09:09:51.092901
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    obj = HTTPTimeoutError("")
    test = str(obj)
    del obj
    return None



# Generated at 2022-06-24 09:10:03.625811
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from tornado.testing import bind_unused_port
    from tornado.testing import ExpectLog
    from tornado.testing import gen_test
    from tornado.testing import get_unused_port
    from tornado.testing import LogTrapTestCase
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.web import Application
    from tornado.web import RequestHandler
    import pytest
    from unittest.mock import patch
    
    # --
    class MyHandler(RequestHandler):
        async def get(self):
            pass
    # --

# Generated at 2022-06-24 09:10:05.303696
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # SimpleAsyncHTTPClient.fetch_impl(request, callback)
    pass



# Generated at 2022-06-24 09:10:10.505641
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    try:
        raise HTTPStreamClosedError("Stream Closed")
    except HTTPError as err:
        assert err.code == 599
        assert str(err) == "Stream Closed"
    else:
        assert False



# Generated at 2022-06-24 09:10:14.800342
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError("Xiao mi mi")
    assert error.message == "Xiao mi mi"

if sys.version_info < (3, 0):
    HTTPTimeoutError.__str__ = lambda x: str(x.message)


# These classes are used by _ConfigurableHTTPConnection, but they are not
# used in the default implementation of AsyncHTTPClient.  The declarations
# are here to help typecheckers.

# Generated at 2022-06-24 09:10:18.942662
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    try:
        _HTTPConnection.run()
    except Error as e:
        print(e.code)
        print(e.message)
        print(e.error)
test__HTTPConnection_run()

# Generated at 2022-06-24 09:10:30.485059
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():

    # Test case data
    response = None
    error = None
    url = None
    method = None
    httplib = None
    buffer = None
    headers = None
    follow_redirects = None
    max_redirects = None
    user_agent = None
    connect_timeout = None
    request_timeout = None
    if_modified_since = None
    network_interface = None
    streaming_callback = None
    header_callback = None
    prepare_curl_callback = None
    proxy_host = None
    proxy_port = None
    proxy_username = None
    proxy_password = None
    allow_nonstandard_methods = None
    validate_cert = None
    ca_certs = None
    allow_ipv6 = None
    client_key = None
    client_cert = None


# Generated at 2022-06-24 09:10:38.190737
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    http_client = SimpleAsyncHTTPClient()
    assert http_client.max_clients == 10
    assert http_client.queue == collections.deque()
    assert http_client.active == {}
    assert http_client.waiting == {}
    assert http_client.max_buffer_size == 104857600
    assert http_client.max_header_size == None
    assert http_client.max_body_size == None
    assert type(http_client.resolver) is Resolver
    assert http_client.own_resolver == True
    assert isinstance(http_client.tcp_client, TCPClient)



# Generated at 2022-06-24 09:10:40.058024
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("timeout")
    except HTTPError as e:
        assert e.code == 599
        assert str(e) == "timeout"



# Generated at 2022-06-24 09:10:44.376882
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    e = HTTPTimeoutError('')
    assert e.__str__() == 'Timeout'
    e = HTTPTimeoutError('abc')
    assert e.__str__() == 'abc'

# Generated at 2022-06-24 09:10:46.471624
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    s = "Stream closed"
    obj = HTTPStreamClosedError(s)
    assert str(obj) == s



# Generated at 2022-06-24 09:10:50.696310
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    try:
        raise HTTPTimeoutError("timeout")
    except HTTPClientError as e:
        assert e.code == 599
        assert str(e) == "timeout"
    else:
        assert False, "Didn't raise HTTPClientError"


# Generated at 2022-06-24 09:10:56.527599
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # _HTTPConnection.data_received()
    from functools import partial
    from httpclient.client import _HTTPConnection
    from tornado import gen

    def test_body_callback(chunk):
        pass

    request = HTTPRequest("http://localhost", streaming_callback=test_body_callback)
    x = _HTTPConnection(request, partial(gen.sleep, 0.001), None, None)
    x.data_received("1")
    x.data_received("2")
    x.data_received("3")



# Generated at 2022-06-24 09:11:01.818604
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    hse = HTTPStreamClosedError("connection closed")
    assert hse.code == 599
    assert hse.response is None
    assert hse.message == "Stream closed"
    assert str(hse) == "Stream closed"


# Generated at 2022-06-24 09:11:12.605581
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    from io import StringIO
    from tornado.testing import AsyncHTTPTestCase, gen_test
    import tornado.http1connection
    import tornado.httpserver
    import tornado.netutil
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import asyncio
    import uuid
    import sys
    import contextlib
    import gc

    class MainHandler(tornado.web.RequestHandler):
        async def get(self):
            self.write("Hello, world")

    class Application(tornado.web.Application):
        def __init__(self):
            handlers = [(r"/", MainHandler)]
            settings = dict()
            super(Application, self).__init__(handlers, **settings)


# Generated at 2022-06-24 09:11:15.601898
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    assert HTTPTimeoutError("Timeout").__str__() in (
        "Timeout",
        "Exception: Timeout",  # previous return value
    )


# Generated at 2022-06-24 09:11:19.506678
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    print("")
    print("test_SimpleAsyncHTTPClient_close started")
    client = SimpleAsyncHTTPClient()
    client.close()
    print("test_SimpleAsyncHTTPClient_close completed")
test_SimpleAsyncHTTPClient_close()


# Generated at 2022-06-24 09:11:30.749093
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import tornado.httpserver
    import tornado.platform.asyncio
    import tornado.testing
    import asyncio

    async def test(http_client):
        response = await http_client.fetch("http://www.tornadoweb.org/")
        assert response.code == 200
        assert response.body == b"hello"

    def get_http_server():
        return tornado.httpserver.HTTPServer(
            tornado.web.RequestHandler,
            io_loop=tornado.platform.asyncio.AsyncIOLoop(),
        )

    def get_http_client():
        return tornado.httpclient.AsyncHTTPClient(
            io_loop=tornado.platform.asyncio.AsyncIOLoop()
        )

    io_loop = asyncio.new_event_loop()


# Generated at 2022-06-24 09:11:38.106890
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    import unittest
    import warnings
    from tornado.util import _assert_not_warned

    class HTTPTimeoutErrorTest(unittest.TestCase):
        def test_constructor(self):
            e = HTTPTimeoutError('something')
            self.assertEqual(str(e), 'Timeout')
            e = HTTPTimeoutError()
            self.assertEqual(str(e), 'Timeout')

        def test_code_deprecated(self):
            e = HTTPTimeoutError()
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                self.assertEqual(e.code, 599)
            self.assertEqual(len(w), 1)
            self.assertTrue(issubclass(w[0].category, DeprecationWarning))
            self.assertIn

# Generated at 2022-06-24 09:11:44.137793
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    url = 'http://example.com'
    request = HTTPRequest(url, method='GET', headers={},
                          allow_nonstandard_methods=False,
                          follow_redirects=True,
                          )
    #
    client = SimpleAsyncHTTPClient()
    #client.initialize(max_clients=10, max_buffer_size=104857600,
    #                  hostname_mapping=None, resolver=None, defaults=None,
    #                  max_header_size=None, max_body_size=None,
    #                  )
    #
    #
    client.fetch_impl(request, None)



# Generated at 2022-06-24 09:11:54.960207
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    from tornado.httpserver import _HTTPConnection
    http_connection = _HTTPConnection(
        stream=None,
        start_time=0,
        parsed=urlparse.urlparse(""),
        request_timeout=0,
        io_loop=None,
        max_header_size=0,
        max_body_size=0,
        max_buffer_size=0,
        client=None,
        release_callback=None,
        final_callback=None,
        sockaddr=None,
    )
    http_connection.headers = None
    http_connection.request = None
    http_connection.chunks = None
    chunk = None
    http_connection.request = Mock()
    http_connection.headers = Mock()
    http_connection.chunks = Mock()
    http_connection.chunks.append = Mock

# Generated at 2022-06-24 09:11:56.242418
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    pass

# Generated at 2022-06-24 09:12:02.693225
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    httpclient = SimpleAsyncHTTPClient()
    assert httpclient.max_clients == 10
    assert httpclient.queue.__len__() == 0
    assert httpclient.active == {}
    assert httpclient.waiting == {}
    assert httpclient.max_buffer_size == 104857600
    assert httpclient.max_header_size is None
    assert httpclient.max_body_size is None
    assert isinstance(httpclient.tcp_client, TCPClient)



# Generated at 2022-06-24 09:12:04.525112
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    client.close()
    assert client.closed


# Generated at 2022-06-24 09:12:11.512093
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    err = HTTPTimeoutError("message")
    assert str(err) == "message"
    err = HTTPTimeoutError("")
    assert str(err) == "Timeout"
    err = HTTPTimeoutError(None)
    assert str(err) == "Timeout"


# This is a sentinel object passed as a callback argument to
# HTTP1ConnectionDelegate.__call__ to indicate that the request should
# be retried.  It may raise a subclass of RetryRequest to alter the
# retry behavior (e.g. RetryRequest(5) to retry the request with
# 5 seconds of backoff).  The caller must generally check for this
# value after each network operation to avoid a dangling reference to
# the HTTP1ConnectionDelegate       

# Generated at 2022-06-24 09:12:14.249001
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError(None)
    print(e, e.code, e.message)



# Generated at 2022-06-24 09:12:15.502593
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection.finish()
    pass



# Generated at 2022-06-24 09:12:16.083492
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass

# Generated at 2022-06-24 09:12:23.774191
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Client setup
    # Check for specific method of returned object
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    # Test method in base class
    pass

# Generated at 2022-06-24 09:12:25.964864
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    obj = HTTPTimeoutError("abc")
    assert obj.code == 599
    assert obj.message == "abc"


# Generated at 2022-06-24 09:12:32.113626
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    client = HTTPClient()
    request = HTTPRequest("http://www.example.com",
                          method="GET")
    host, port, ssl_option = client._parse_host_port(
        request.url,
        443,
        ssl_options=None,
    )
    io_loop = IOLoop.current()
    conn = _HTTPConnection(request, host, port, ssl_option, io_loop,
                           client, 1048576, 1048576)
    assert isinstance(conn, _HTTPConnection)


# Generated at 2022-06-24 09:12:38.997619
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    request = httpclient.HTTPRequest(
        url = 'http://www.stdurl.org/post',
        method = 'POST',
        body = b'***',
    )
    client = httpclient.AsyncHTTPClient()
    future0 = client.fetch(request)
    client_gen0 = client._fetch_impl(request)
    future1 = next(client_gen0)
    future1.set_result(None)
    future2 = next(client_gen0)
    future2.set_result(None)
    future3 = next(client_gen0)
    future3.set_result(None)
    client_gen0.send(None)
    future4 = next(client_gen0)
    future4.set_result(None)
    future5 = next(client_gen0)
   

# Generated at 2022-06-24 09:12:48.799773
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # 1, AsyncHTTPClient.__init__(self, force_instance=True, **kwargs)
    # 2, AsyncHTTPClient.initialize(self, defaults=None)
    request = HTTPRequest("http://www.google.com.hk/")
    assert request.url == "http://www.google.com.hk/"

    # 3, SimpleAsyncHTTPClient.initialize(self, max_clients=10, hostname_mapping=None, max_buffer_size=104857600, resolver=None, defaults=None, max_header_size=None, max_body_size=None)
    request = HTTPRequest("http://www.google.com.hk/")
    test_client = SimpleAsyncHTTPClient()
    assert test_client.max_clients == 10
    assert test_client.queue

# Generated at 2022-06-24 09:12:51.385393
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    e = HTTPStreamClosedError('Connection reset by peer')
    assert e.message == 'Connection reset by peer'
    assert e.code == 599
    assert len(str(e)) >= 18


# Generated at 2022-06-24 09:12:52.886188
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    err = HTTPTimeoutError("Timeout")
    assert err.code == 599
    assert str(err) == "Timeout"



# Generated at 2022-06-24 09:12:59.996866
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    print("Unit test for method finish of class _HTTPConnection")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    # Create an _HTTPConnection
    http_client = AsyncHTTPClient()
    req = HTTPRequest("http://www.baidu.com")
    http_conn = http_client._HTTPConnection(req, AsyncHTTPClient(), None)
    # Fake the property: code
    http_conn.code = 404
    # Fake the property: reason
    http_conn.reason = "Not Found"
    # Fake the property: headers
    http_conn.headers = httputil.HTTPHeaders()
    # Fake the property: chunks
    http_conn.chunks = []

    http_conn.finish()
    return


# Generated at 2022-06-24 09:13:10.199933
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    import pytest
    from tornado.testing import AsyncHTTPTestCase, gen_test

    class MyHTTPTest(AsyncHTTPTestCase):
        def get_app(self):
            from tornado.web import Application
            from tornado.ioloop import IOLoop

            self.io_loop = IOLoop.current()
            self.io_loop.make_current()
            self.stream = None
            self.connection = None
            self.read_response = None

            async def _read_response(self):
                self.stream = stream
                self.connection = _HTTPConnection(
                    self, stream, self.request, self.final_callback, self._on_timeout
                )
                await self.connection.read_response(self)


# Generated at 2022-06-24 09:13:11.976291
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError("HTTPStreamClosedError")
    assert e.__str__() == "HTTPStreamClosedError"


# Generated at 2022-06-24 09:13:17.987529
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # test_SimpleAsyncHTTPClient_fetch_impl()
    #   -> SimpleAsyncHTTPClient._handle_request()
    #      -> _HTTPConnection
    #         -> _HTTPResponseStartLine
    #         -> SimpleAsyncHTTPClient._release_fetch()
    #         -> SimpleAsyncHTTPClient._process_queue()
    #   -> SimpleAsyncHTTPClient._remove_timeout()
    #   -> SimpleAsyncHTTPClient._release_fetch()
    # ...
    # TODO: check if HTTPError is thrown.
    pass


# Generated at 2022-06-24 09:13:20.660030
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    obj = HTTPStreamClosedError('msg')
    obj.message = None

# Generated at 2022-06-24 09:13:30.788435
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    io_loop = IOLoop._current  # type: ignore

    def test_stream_close(self) -> None:
        self.close()  # type: ignore

    def test_stream_read_until(self, delimiter: bytes) -> bytes:
        raise NotImplementedError()

    response_body = b"HTTP/1.1 200 OK\r\n\r\nHello"
    response_parts = [
        response_body[:4],
        response_body[4:9],
        response_body[9:15],
        response_body[15:],
    ]
    request_completed = [False]

    def mock_stream_read_until(delimiter: bytes) -> bytes:
        response = response_parts.pop(0)
        if not response_parts:
            request_completed

# Generated at 2022-06-24 09:13:41.117682
# Unit test for method close of class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:13:53.272966
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient

# Generated at 2022-06-24 09:13:54.798594
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    he = HTTPStreamClosedError("Stream closed")
    assert he.code == 599
    print(he.message)
    print(str(he))


# Generated at 2022-06-24 09:13:59.570962
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    def fetch_impl(self, request, callback):
        key = object()
        self.queue.append((key, request, callback))
        assert request.connect_timeout is not None
        assert request.request_timeout is not None
        timeout_handle = None
        if len(self.active) >= self.max_clients:
            timeout = (
                min(request.connect_timeout, request.request_timeout)
                or request.connect_timeout
                or request.request_timeout
            )  # min but skip zero
            if timeout:
                timeout_handle = self.io_loop.add_timeout(
                    self.io_loop.time() + timeout,
                    functools.partial(self._on_timeout, key, "in request queue"),
                )

# Generated at 2022-06-24 09:14:11.856994
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    class MockChunk(object):
        def __init__(self,  **kwargs):
            self.value = kwargs

    class MockHeaders(object):
        def __init__(self,  **kwargs):
            self.value = kwargs

    class MockResponseStartLine(object):
        def __init__(self,  **kwargs):
            self.value = kwargs

    class MockHTTPRequest(object):
        def __init__(self,  **kwargs):
            self.value = kwargs

    class MockIOStream(object):
        def __init__(self,  **kwargs):
            self.value = kwargs

    class MockIOLoop(object):
        def __init__(self,  **kwargs):
            self.value = kwargs

    chunk = MockCh

# Generated at 2022-06-24 09:14:14.865569
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    http_stream_closed_error = HTTPStreamClosedError(message='message')
    assert http_stream_closed_error.__str__() == 'message'

# Generated at 2022-06-24 09:14:17.044929
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    e = HTTPTimeoutError("Timeout")
    assert e.code == 599
    assert str(e) == "Timeout"
    assert e.response == None



# Generated at 2022-06-24 09:14:17.686781
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__(): pass


# Generated at 2022-06-24 09:14:18.951560
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    raise HTTPTimeoutError("Timed out")


# Generated at 2022-06-24 09:14:21.433264
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    e = HTTPStreamClosedError("test http stream closed error")
    print(e)
    return e



# Generated at 2022-06-24 09:14:23.060666
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    error = HTTPStreamClosedError()
    assert error


# Generated at 2022-06-24 09:14:25.011230
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    obj = HTTPTimeoutError('f')
    assert obj.__str__() == ('Timeout' if obj.message is None else obj.message)



# Generated at 2022-06-24 09:14:35.590107
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    ##################################################################
    # Setup
    #
    # The test doesn't mock _HTTPConnection.stream.write() because it
    # wants to test the connection object interacting with an IOStream
    # implementation, hence the need to actually have an IOStream
    # implementation.  In the default configuration this means the
    # socket module, but a mock implementation can be provided by
    # passing in the optional io_loop argument.  The same goes for
    # IOStream.read_until_close()
    io_loop = None
    ca_certs = None
    validate_cert = True
    client_key = None
    client_cert = None
    proxy_host = None
    proxy_port = None
    proxy_username = None
    proxy_password = None
    proxy_auth_mode = None
    allow_ipv6 = True
    _

# Generated at 2022-06-24 09:14:46.345001
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado.httpclient import HTTPRequest, HTTPResponse
    from tornado.simple_httpclient import _HTTPConnection
    from tornado.httpclient import _RequestProxy
    from tornado.httputil import RequestStartLine
    import tornado.iostream
    import tornado.platform.asyncio
    import tornado.testing
    
    def dummy_function(arg1: bytes, arg2: httputil.HTTPHeaders) -> None:
        pass
    
    def dummy_exception_raising_function(arg1: bytes, arg2: httputil.HTTPHeaders) -> None:
        raise Exception()
    
    import _io
    import unittest
    class FakeResponse(object):
        def __init__(self, headers) -> None:
            self.headers = headers
            self.code = None

# Generated at 2022-06-24 09:14:57.069646
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    import tornado.testing
    from tornado.test.util import unittest

    # Sends a simple request and checks that the data_received method is called
    # with the expected chunks
    class TestDataReceived(unittest.AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.http_client = HTTPClient()
            self.http_client._HTTPConnection_data_received_called = []
            self.http_client._HTTPConnection_data_received_called_with = []
            self.server = tornado.testing.AsyncHTTPTestCase.HTTPServer(
                # Allows to get the request and send a response
                lambda request: Response(request, response_body='1')
            )


# Generated at 2022-06-24 09:15:07.552800
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import HTTPResponse
    import copy
    import urllib.parse

    code = 1
    reason = 1
    headers = 1
    original_request = 1
    buffer = 1
    result = 1
    response = HTTPResponse(
        original_request,
        code,
        reason=getattr(reason, "reason", None),
        headers=headers,
        request_time=result.io_loop.time() - result.start_time,
        start_time=result.start_wall_time,
        buffer=buffer,
        effective_url=original_request.url,
    )
    response_new = result._run_callback(response)
    assert response_new is None

# Generated at 2022-06-24 09:15:18.529971
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # TODO: parametrize
    import socket
    import unittest
    import tornado.gen
    import tornado.httpclient
    import tornado.httpserver
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class PostHandler(tornado.web.RequestHandler):
        def post(self):
            self.write("ok")

    class PostExceptionHandler(tornado.web.RequestHandler):
        def post(self):
            raise Exception("exception")

    class EchoWebSocket(tornado.websocket.WebSocketHandler):
        def open(self):
            self.write_message("opened")

        def on_message(self, message):
            self.write_message(message)

        def on_close(self):
            self.close()


# Generated at 2022-06-24 09:15:29.439799
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # HTTPConnection.close()
    key = object()
    self.queue.append((key, request, callback))
    assert request.connect_timeout is not None
    assert request.request_timeout is not None
    timeout_handle = None
    if len(self.active) >= self.max_clients:
        timeout = (
            min(request.connect_timeout, request.request_timeout)
            or request.connect_timeout
            or request.request_timeout
        )  # min but skip zero
        if timeout:
            timeout_handle = self.io_loop.add_timeout(
                self.io_loop.time() + timeout,
                functools.partial(self._on_timeout, key, "in request queue"),
            )
    self.waiting[key] = (request, callback, timeout_handle)
    self

# Generated at 2022-06-24 09:15:32.330888
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
  a = SimpleAsyncHTTPClient()
  a.fetch()
  a.close()



# Generated at 2022-06-24 09:15:37.983233
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    obj = HTTPStreamClosedError(message="Stream closed")
    assert isinstance(obj, HTTPStreamClosedError)
    assert str(obj) == "Stream closed"
    obj = HTTPStreamClosedError(message="")
    assert isinstance(obj, HTTPStreamClosedError)
    assert str(obj) == "Stream closed"



# Generated at 2022-06-24 09:15:39.675928
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    e = HTTPStreamClosedError()
    _ = str(e)
# _test()



# Generated at 2022-06-24 09:15:45.814355
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # instance
    instance = _HTTPConnection(None, None, None, None)
    # test
    with pytest.raises(HTTPStreamClosedError) as excinfo:
        instance.on_connection_close()
    excinfo.match(r"Connection closed")
    assert excinfo.type is HTTPStreamClosedError

# Generated at 2022-06-24 09:15:50.606677
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    stream_closed_error = HTTPStreamClosedError()
    assert str(stream_closed_error) == 'Stream closed'
    stream_closed_error = HTTPStreamClosedError('Stream closed with errors')
    assert str(stream_closed_error) == 'Stream closed with errors'
    stream_closed_error = HTTPStreamClosedError('Stream closed with errors')
    assert stream_closed_error.__str__() == 'Stream closed with errors'



# Generated at 2022-06-24 09:15:51.316188
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass

# Generated at 2022-06-24 09:15:58.765726
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    sce = HTTPStreamClosedError("some text")
    assert(sce.code == 599)
    assert(sce.message == "some text")   # not "Stream closed"
    assert(str(sce) == "some text")      # not "Stream closed"


httpclient_logger = logging.getLogger("tornado.curl_httpclient")



# Generated at 2022-06-24 09:16:01.615844
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    o = HTTPStreamClosedError('message')
    r = o.__str__()
    assert r != None
    # assert r == 'message'


# Generated at 2022-06-24 09:16:10.061792
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    io_loop = None
    max_clients = 0
    hostname_mapping = {}
    max_buffer_size = 0
    resolver = None
    defaults = {}
    max_header_size = None
    max_body_size = None
    a = SimpleAsyncHTTPClient(io_loop, max_clients, hostname_mapping, max_buffer_size, resolver, defaults, max_header_size, max_body_size)
    try:
        a.close()
    except:
        pass
    try:
        a.close()
        assert True
    except HTTPStreamClosedError:
        assert False
    try:
        a.close()
        assert True
    except IOError:
        assert False

# Generated at 2022-06-24 09:16:21.748893
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Request callback testing
    request = HTTPRequest(url="http://www.google.com")
    callback = lambda x: (x, print(x))

    # Test for when function fetch_impl is called and argument request is an instance of class HTTPRequest
    if isinstance(request, HTTPRequest):
        # Tests for the first if statement in the function
        if request.connect_timeout is None:
            pass
        # Tests for the second if statement in the function
        elif request.request_timeout is None:
            pass
        else:
            # Tests for the first if in the else statement in the function
            if len(self.active) >= self.max_clients:
                pass
            else:
                # Tests for the first if statement in the else statement in the else statement
                if request.connect_timeout is not None:
                    pass
               

# Generated at 2022-06-24 09:16:32.991167
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    self = _HTTPConnection(HTTPResponse(HTTPRequest(url=""), code=301, headers=None), io_loop=None)
    self._handle_exception = lambda *args: True
    req = HTTPRequest(url="https://www.google.com/", follow_redirects=True)
    headers = httputil.HTTPHeaders({"Location": "https://www.tornadoweb.org/"})
    resp_line = httputil.ResponseStartLine(code=301, reason="redirect", version="HTTP/1.1")
    # test
    self.headers_received(resp_line, headers)
    return self



# Generated at 2022-06-24 09:16:34.390922
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    error = HTTPTimeoutError('boom')
    assert error.message == 'boom'
    assert error.code == 599



# Generated at 2022-06-24 09:16:36.502311
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # This unit test is currently not being run.
    # TODO: Add unit tests for this class.
    pass

# Generated at 2022-06-24 09:16:41.724809
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    http = SimpleAsyncHTTPClient()
    assert http.max_clients == 10
    assert http.queue == collections.deque()
    assert http.active == {}
    assert http.waiting == {}
    assert http.max_buffer_size == 104857600
    assert http.max_header_size is None
    assert http.max_body_size is None
 

# Generated at 2022-06-24 09:16:44.250614
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
    # type: () -> None
    e = HTTPTimeoutError('Testing')
    assert e.code == 599
    assert str(e) == 'Testing'

_DEFAULT_CA_CERTS = None
_DEFAULT_CA_CERTS_PATH = None



# Generated at 2022-06-24 09:16:50.536874
# Unit test for constructor of class HTTPTimeoutError
def test_HTTPTimeoutError():
  try:
    raise HTTPTimeoutError('this is a test message')
  except HTTPTimeoutError as e:
    assert e.code == 599
    assert e.message == 'this is a test message'
    assert str(e) == 'this is a test message'

# Override this constant in your program or tests to get the old behavior
# of always closing connections after each request.  This only affects HTTP1
# connections.
GLOBAL_CLOSE_CONNECTION = False



# Generated at 2022-06-24 09:16:54.629433
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    err = HTTPTimeoutError(message="message")
    assert err.message == "message"
    assert str(err) == "message"
    err2 = HTTPTimeoutError(message="")
    assert str(err2) == "Timeout"


# Generated at 2022-06-24 09:17:04.265084
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    with patch('tornado.httpclient.tornado.iostream.StreamClosedError',
               new=Mock(return_value=StreamClosedError('Stream closed'))):
        response = HTTPResponse(url=Mock(),
                                request=Mock(),
                                code=599,
                                request_time=1,
                                buffer=BytesIO(),
                                effective_url=Mock())

# Generated at 2022-06-24 09:17:15.675176
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    httpc = _HTTPConnection()
    assert isinstance(httpc, _HTTPConnection)
    assert not hasattr(httpc, "connection")
    assert not hasattr(httpc, "code")
    assert not hasattr(httpc, "reason")
    assert not hasattr(httpc, "headers")
    assert not hasattr(httpc, "chunks")
    assert not hasattr(httpc, "stream")
    assert not hasattr(httpc, "final_callback")
    assert not hasattr(httpc, "start_time")
    assert not hasattr(httpc, "start_wall_time")
    assert not hasattr(httpc, "request")
    assert not hasattr(httpc, "client")
    assert not hasattr(httpc, "io_loop")

# Generated at 2022-06-24 09:17:16.747142
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass



# Generated at 2022-06-24 09:17:29.192515
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # The test _HTTPConnection instance
    test_connection = _HTTPConnection()

    # Test attributes
    assert test_connection.code is None
    assert test_connection.request is None
    assert test_connection.stream is None
    assert test_connection.chunks == []
    assert test_connection.headers is None
    assert test_connection.reason is None
    assert test_connection.conn_params == HTTP1ConnectionParameters(
        max_header_size=8192, no_keep_alive=True
    )
    assert test_connection.io_loop is None
    assert test_connection.client is None
    assert test_connection.max_header_size == 8192
    assert test_connection.max_body_size == 104857600
    assert test_connection.final_callback is None

# Generated at 2022-06-24 09:17:30.828543
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    """ unit test for method headers_received of class _HTTPConnection """
    pass


# Generated at 2022-06-24 09:17:41.842888
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    # Test the exception of close before initialization.
    if version.major >= 5:
        with pytest.raises(RuntimeError):
            client.close()
    # Test the exception of close after initialization.
    client.initialize()
    client.close()
    if version.major >= 5:
        with pytest.raises(RuntimeError):
            client.close()
    # Test the exception of close after initialization.
    client.initialize()
    client.close()
    if version.major >= 5:
        with pytest.raises(RuntimeError):
            client.close()
    client.close()


# Generated at 2022-06-24 09:17:54.445670
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    content = "This is body"
    io_loop = IOLoop()

    def _write_body(data):
        if data is None:
            return
        data = httputil.encode_body(data)
        stream.write(data)

    # Mock an HTTP request
    stream = IOStream(socket.socket(), io_loop=io_loop)
    stream.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    req = HTTPRequest("http://127.0.0.1:10000/")
    req.streaming_callback = None
    req.body_producer = _write_body
    req.body = None
    req.headers = httputil.HTTPHeaders()
    req.headers["Content-Length"] = str(len(content))

# Generated at 2022-06-24 09:17:58.869084
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass
    



# Generated at 2022-06-24 09:18:01.313997
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    http_timeout_error = HTTPTimeoutError(message=None)
    assert str(http_timeout_error) == 'Timeout'



# Generated at 2022-06-24 09:18:10.517105
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    from pytornado.util import resolve_ipv6_address
    from test.util import run_until, is_closesocket_available
    from pytornado.httpclient import _HTTPConnection, HTTPClient
    from pytornado.escape import native_str
    from pytornado.util import b, bytes_type
    IP = resolve_ipv6_address("localhost")
    PORT = 8001
    class MockStream(IOStream):
        def __init__(self, sock: socket.socket, **kwargs: Any) -> None:
            self.socket = sock
            super().__init__(sock=sock, io_loop=IOLoop(), **kwargs)
        def close(self) -> None:
            if is_closesocket_available():
                self.socket.close()
            

# Generated at 2022-06-24 09:18:13.264307
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    error = HTTPTimeoutError("Timeout")
    assert str(error) == "Timeout"


# Generated at 2022-06-24 09:18:24.617488
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Init
    import io
    import logging
    import signal
    import time
    import tornado.ioloop
    import tornado.netutil
    from tornado.iostream import IOStream
    from tornado.platform.auto import set_close_exec
    from tornado.netutil import ssl_wrap_socket
    from tornado.testing import AsyncTestCase, bind_unused_port, ExpectLog
    from tornado.test.util import unittest, skipBefore35
    from tornado.tcpserver import TCPServer
    from tornado.test.httpclient_test import (
        _TestHTTPConnection,
        _TestHTTPConnection2,
        _TestHTTPConnectionClosedCleanly,
    )
    from tornado.test.util import unittest, skipBefore35
    from tornado.web import RequestHandler, Application, HTTPError
    import tornado.web

# Generated at 2022-06-24 09:18:26.650747
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    with pytest.raises(HTTPStreamClosedError):
        raise HTTPStreamClosedError('Stream closed')


# Generated at 2022-06-24 09:18:28.797501
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    pass


# Generated at 2022-06-24 09:18:38.080393
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    instance = HTTPTimeoutError("message")
    assert isinstance(instance, HTTPError)
    assert isinstance(instance.code, int)
    assert instance.code == 599
    assert isinstance(instance.message, str)
    assert instance.message == "message"
    assert str(instance) == "message"
    assert repr(instance) == "HTTPTimeoutError(599, 'message')"
    # other cases
    assert HTTPTimeoutError("").__str__() == "Timeout"
    assert HTTPTimeoutError(None).__str__() == "Timeout"
    # object attributes
    assert hasattr(instance, "code")
    assert isinstance(instance.code, int)
    assert hasattr(instance, "message")
    assert isinstance(instance.message, str)
    assert hasattr(instance, "response")
    assert instance.response

# Generated at 2022-06-24 09:18:44.953528
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Create a mock class
    class MockStri:
        def __init__(self, message: str) -> None: pass
        @property
        def message(self): return None

    # Create the object
    obj = HTTPStreamClosedError("")
    
    # Call method __str__
    ret = obj.__str__()
    assert ret is not None
    assert ret is not None



# Generated at 2022-06-24 09:18:46.807987
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    conn = _HTTPConnection()
    conn.run()

# Generated at 2022-06-24 09:18:51.296662
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # _HTTPConnection: method data_received
    # self.io_loop.remove_timeout(self._timeout)
    pass


# _HTTPConnection: method headers_received
async def test__HTTPConnection_headers_received():
    # _HTTPConnection: method headers_received
    pass



# Generated at 2022-06-24 09:18:52.393199
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection.run()

# Generated at 2022-06-24 09:18:54.317717
# Unit test for constructor of class HTTPStreamClosedError
def test_HTTPStreamClosedError():
    err = HTTPStreamClosedError("Stream closed")
    assert err.code == 599



# Generated at 2022-06-24 09:19:02.374532
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    from tornado.httputil import HTTPHeaders, HTTPMessageDelegate
    from tornado.iostream import IOStream
    from tornado import testing
    import logging
    import socket
    import tempfile
    import unittest
    from unittest import mock

    # TODO: Fix this test.
    raise unittest.SkipTest("fix this test")

    class Mock(object):

        def __init__(self) -> None:
            pass

        def __getattr__(
            self, name: str
        ) -> Union[None, Callable]:
            if name.startswith("_") or not name.endswith("_"):
                return None
            return self._mock


# Generated at 2022-06-24 09:19:13.137087
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from typing import Coroutine, Any, Dict, Union
    from tornado.ioloop import IOLoop
    from tornado.netutil import Resolver
    from tornado.tcpclient import TCPClient
    from tornado.iostream import IOStream, StreamClosedError

    import pytest

    _HTTPConnection._handle_exception = _handle_exception
    _HTTPConnection._release = _release
    _HTTPConnection.final_callback = None  # type: ignore

    stream = StreamClosedError()
    client = TCPClient(resolver=Resolver())
    request = HTTPRequest(url="https://www.yahoo.com", validate_cert=True)
    client._create_connection = _create_connection
    connection = _HTTPConnection(client, request, stream)
    connection.on_connection_close()
    assert connection.final_callback is None

# Generated at 2022-06-24 09:19:17.350795
# Unit test for constructor of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient():
    assert SimpleAsyncHTTPClient(
        max_clients=10, hostname_mapping={}, max_buffer_size=104857600, resolver=None, defaults={}, max_header_size=None, max_body_size=None
    )


_DEFAULT_CA_CERTS = pkg_resources.resource_filename("certifi", "cacert.pem")



# Generated at 2022-06-24 09:19:28.981754
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    io_loop = IOLoop()
    io_loop.make_current()
    request = HTTPRequest('http://example.com/')
    final_callback = lambda result: result
    http_connection = _HTTPConnection(
        io_loop,
        request,
        final_callback,
        None,
        0,
        '127.0.0.1',
    )
    http_connection.stream = mock.MagicMock()
    http_connection.request.raise_error = False
    
    # Ensure that we raise the stream's real error if it exists.
    http_connection.stream.error = IOError()
    try:
        http_connection.on_connection_close()
    except IOError:
        pass
    else:
        assert False, "Exception should have been raised"
    
    # Ensure that a HTTP