

# Generated at 2022-06-26 08:41:54.769187
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client_00 = SimpleAsyncHTTPClient()
    max_clients_00 = 10
    hostname_mapping_00 = None
    max_buffer_size_00 = 104857600
    resolver_00 = None
    defaults_00 = None
    max_header_size_00 = None
    max_body_size_00 = None
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:42:06.783791
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Test case header
    test_case_info = {"name": sys._getframe().f_code.co_name, "status": "running"}
    print("BEGIN {name}".format(**test_case_info))
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.initialize()
    assert len(simple_async_h_t_t_p_client_0.active) == 0
    assert len(simple_async_h_t_t_p_client_0.queue) == 0
    assert len(simple_async_h_t_t_p_client_0.waiting) == 0
    request_0 = HTTPRequest("www.google.com")
    callback_0

# Generated at 2022-06-26 08:42:13.396522
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Test case data
    state = 0
    def cb(f):
        return f.result()
    # Call the method (execution starts here)
    _HTTPConnection.run(cb)
    # Check the results
    assert state == 1
    # Additional tests


# Generated at 2022-06-26 08:42:21.679031
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_request_1 = HTTPRequest(url='', method='POST')
    proxies_2 = {'https': '', 'http': ''}
    simple_async_h_t_t_p_client_0._HTTPConnection(http_request_1, proxies_2)
    final_callback_3 = object()
    start_time_4 = object()
    code_5 = object()
    chunks_6 = object()
    reason_7 = object()
    headers_8 = object()
    simple_async_h_t_t_p_client_0._HTTPConnection.finish(final_callback_3, start_time_4, code_5, chunks_6, reason_7, headers_8)

# Unit

# Generated at 2022-06-26 08:42:29.527039
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client = SimpleAsyncHTTPClient()
    max_clients = 10
    hostname_mapping = dict()
    max_buffer_size = 104857600
    resolver = Resolver()
    defaults = dict()
    max_header_size = None
    max_body_size = None
    simple_async_h_t_t_p_client.initialize(max_clients, hostname_mapping, max_buffer_size, resolver, defaults, max_header_size, max_body_size)


# Generated at 2022-06-26 08:42:41.910407
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:42:43.767265
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    test_case_0()


# Generated at 2022-06-26 08:42:45.235077
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    assert 1 == 1


# Generated at 2022-06-26 08:42:55.969661
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

    # Call method fetch_impl of class SimpleAsyncHTTPClient

    # Create a dummy request object

# Generated at 2022-06-26 08:42:58.073658
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = None
    headers = None
    _HTTPConnection.headers_received(first_line, headers)


# Generated at 2022-06-26 08:43:53.638680
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    class Test:
        async def main(self):
            h_t_t_p_client_0 = SimpleAsyncHTTPClient()
            h_t_t_p_client_0.initialize()
    test = Test()
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(test.main())
    finally:
        loop.close()


# Generated at 2022-06-26 08:44:02.646548
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    def method_of_class__HTTPConnection_data_received(self, arg_0 : bytes) -> None:
        if self._should_follow_redirect():
            return
        if self.request.streaming_callback is not None:
            self.request.streaming_callback(arg_0)
        else:
            self.chunks.append(arg_0)
        pass
    pass


# Generated at 2022-06-26 08:44:10.207422
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'The value of log_rotate_mode option should be '
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()


# Generated at 2022-06-26 08:44:22.729694
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = 'The value of log_rotate_mode option should be '
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_

# Generated at 2022-06-26 08:44:24.584794
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    test_case_0()


# Generated at 2022-06-26 08:44:38.025412
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    h_t_t_p_request_0 = HTTPRequest(url=str(), headers=dict(), validate_cert=bool())
    _h_t_t_p_connection_0 = _HTTPConnection(h_t_t_p_request_0, start_time=0.0, io_loop=IOLoop(), max_header_size=64, max_body_size=None, final_callback=Callable(test_case_0), release_callback=Callable(test_case_0))
    chunks_0 = [b'\x00']
    _h_t_t_p_connection_0.chunks = chunks_0
    _h_t_t_p_connection_0.code = 100
    headers_0 = httputil.HTTPHeaders()
    _h_t_t_p_connection_0

# Generated at 2022-06-26 08:44:41.839319
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    client.close()
    assert SimpleAsyncHTTPClient() == client


# Generated at 2022-06-26 08:44:50.812380
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    tsl_options_1 = {}
    str_1 = './default.conf'
    confFile_1 = str_1
    conf_1 = ConfigParser.ConfigParser()
    conf_1.read(confFile_1)
    str_2 = 'log'
    str_3 = 'log_file'
    str_4 = conf_1.get(str_2, str_3)
    str_5 = str_4
    sys.stdout = open(str_5, 'w')
    str_6 = 'log'
    str_7 = 'log_rotate_mode'
    str_8 = conf_1.get(str_6, str_7)
    str_9 = 'size'
    str_8 = str_8 == str_9
    bool_0 = str_8

# Generated at 2022-06-26 08:44:56.511984
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Test initialize function of class SimpleAsyncHTTPClient
    # Test class SimpleAsyncHTTPClient, each code branch and path
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 08:45:03.651614
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # define params
    hostname_mapping = None

    # init client object
    simple_async_http_client_0 = SimpleAsyncHTTPClient(hostname_mapping)
    # method call
    simple_async_http_client_0.close()


# Generated at 2022-06-26 08:48:20.633437
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # expected arguments
    chunk = None

    # test case 0
    test_case_0()


# Generated at 2022-06-26 08:48:23.859381
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    try:
        test_case_0()
    except Exception as e:
        print('[ERROR]', e.__str__())


# Generated at 2022-06-26 08:48:31.232539
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    resolver__0 = Resolver()
    simple_async_http_client__0 = SimpleAsyncHTTPClient(
        resolver=resolver__0)
    defaults__0 = dict()
    max_header_size__0 = int()
    max_body_size__0 = int()
    simple_async_http_client__0.initialize(defaults=defaults__0,
        max_header_size=max_header_size__0, max_body_size=max_body_size__0)



# Generated at 2022-06-26 08:48:42.636505
# Unit test for method finish of class _HTTPConnection

# Generated at 2022-06-26 08:48:47.340599
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Create an object of class _HTTPConnection
    _HTTPConnection_run_http_connection_0 = _HTTPConnection(object(), object(), object(), object(), object())
    # Call method run of _HTTPConnection with argument request
    _HTTPConnection_run_http_connection_0.run(object())

# Generated at 2022-06-26 08:48:49.073565
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # TODO
    try:
        pass
    except Exception as e:
        raise e


# Generated at 2022-06-26 08:48:59.808552
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = 'The value of log_rotate_mode option should be '
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    # Create http_connection
    http_connection_0 = _HTTPConnection()

    try:
        headers_received_0 = http_connection_0.headers_received(None, None, None)
        headers_received_0.__next__()
    except StopIteration:
        pass
    except HTTPTimeoutError as e:
        error = e


# Generated at 2022-06-26 08:49:03.827547
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    HTTPResponse_0 = HTTPResponse('The value of log_rotate_mode option should be ')
    io_loop_0 = IOLoop()
    _HTTPConnection_run_0 = _HTTPConnection(io_loop_0, HTTPResponse_0)
    try:
        _HTTPConnection_run_0.run('The value of log_rotate_mode option should be ')
    except HTTPTimeoutError:
        pass
    except:
        pass


# Generated at 2022-06-26 08:49:10.091059
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    try:
        str_1 = 'The value of log_rotate_mode option should be '
        h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
        str_2 = h_t_t_p_timeout_error_1.__str__()
        assert False
    except HTTPTimeoutError as e:
        assert "HTTPTimeoutError" in repr(e)
        assert "The value of log_rotate_mode option should be " in repr(e)


# Generated at 2022-06-26 08:49:14.695697
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    test_case_0()
