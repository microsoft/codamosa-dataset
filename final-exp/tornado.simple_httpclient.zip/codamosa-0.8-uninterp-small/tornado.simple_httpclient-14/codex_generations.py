

# Generated at 2022-06-26 08:41:46.150445
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    http_connection_0 = _HTTPConnection(
        '%(A-\r\xcc\x9a2\xdd)\\', dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), None, dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict()
    )

# Generated at 2022-06-26 08:41:58.943408
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    def mock_on_response(self, __hint, __args, __kwargs):
        pass
    _HTTPConnection.on_response = mock_on_response
    httpclient_0 = HTTPClient()
    http_request_0 = httpclient_0.fetch('http://127.0.0.1')
    http_connection_0 = _HTTPConnection(http_request_0, httpclient_0, None, None)
    http_response_headers_0 = httputil.HTTPHeaders()
    http_response_start_line_0 = httputil.ResponseStartLine('', '', '')
    http_connection_0.headers_received(http_response_start_line_0, http_response_headers_0)


# Generated at 2022-06-26 08:42:00.241982
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    https_client = AsyncHTTPClient(force_instance=True)

# check none

# Generated at 2022-06-26 08:42:04.864091
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # TODO: Add tests for async and await?
    str_0 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError(str_1)
    str_2 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_2 = HTTPStreamClosedError(str_2)
    str_3 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_3 = HTTPStreamClosedError(str_3)
    # TODO: Implement this test?


# Generated at 2022-06-26 08:42:06.598627
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    assert True


# Generated at 2022-06-26 08:42:16.887631
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # The following call to _HTTPConnection() is fine because stream.error is None in this case
    _http_connection_0 = _HTTPConnection(None)
    _http_connection_0.on_connection_close()
    str_0 = 'vA<_r.\n'
    stream_closed_error_0 = StreamClosedError(str_0)
    _http_connection_0.stream.error = stream_closed_error_0
    # The following call to _HTTPConnection() will raise a StreamClosedError
    _http_connection_0 = _HTTPConnection(None)
    _http_connection_0.on_connection_close()

# Generated at 2022-06-26 08:42:27.020984
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError(str_1)
    h_t_t_p_stream_closed_error_0.close()
    h_t_t_p_stream_closed_error_1.close()



# Generated at 2022-06-26 08:42:35.789759
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    str_0 = 'fkJV\x1bN\r'
    http1_connection_parameters_0 = HTTP1ConnectionParameters()
    stream_0 = IOStream()
    int_0 = 522132759
    _http_connection_0 = _HTTPConnection(stream_0, int_0, http1_connection_parameters_0, str_0)


# Generated at 2022-06-26 08:42:43.512125
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = 'N<t+OZV9'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = '!N@I$"v'
    h_t_t_p_stream_closed_error_0.__init__(str_1)
    
    setattr(h_t_t_p_stream_closed_error_0, 'message', str_0)
    str_2 = h_t_t_p_stream_closed_error_0.__str__()
    str_3 = '!N@I$"v'
    assert str_2 == str_3
    
    str_4 = '+NQC^'
    h_t_t_p_stream_closed_error_0.__

# Generated at 2022-06-26 08:42:55.182909
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    returns = [
        HTTPStreamClosedError(HTTPStreamClosedError),
        HTTPTimeoutError(HTTPTimeoutError),
        HTTPStreamClosedError(HTTPStreamClosedError),
        HTTPTimeoutError(HTTPTimeoutError),
        HTTPStreamClosedError(HTTPStreamClosedError),
        HTTPTimeoutError(HTTPTimeoutError),
        HTTPStreamClosedError(HTTPStreamClosedError),
        HTTPTimeoutError(HTTPTimeoutError),
        HTTPStreamClosedError(HTTPStreamClosedError),
        HTTPTimeoutError(HTTPTimeoutError),
    ]

# Generated at 2022-06-26 08:43:55.065561
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    http_client_impl_0 = HTTPClientImpl()
    httputil_headers_0 = httputil.HTTPHeaders()
    httputil_request_start_line_0 = httputil.RequestStartLine('GET', 'http://www.google.com/', 'HTTP/1.1')
    http_client_impl_0.headers_received(httputil_request_start_line_0, httputil_headers_0)
    httputil_response_start_line_0 = httputil.ResponseStartLine('GET', 'http://www.google.com/', 'HTTP/1.1')
    http_client_impl_0.headers_received(httputil_response_start_line_0, httputil_headers_0)


# Generated at 2022-06-26 08:44:05.103095
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    _http_connection_0 = _HTTPConnection()
    str_0 = "b`P`o\t\x0e\x1e"
    httputil_request_start_line_0 = httputil.RequestStartLine(str_0, '\x0e', "\x17-F\x12")
    httputil_http_headers_0 = httputil.HTTPHeaders.parse(str_0)
    _http_connection_0.headers_received(httputil_request_start_line_0, httputil_http_headers_0)


# Generated at 2022-06-26 08:44:18.173894
# Unit test for method on_connection_close of class _HTTPConnection

# Generated at 2022-06-26 08:44:21.374978
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    c_0 = _HTTPConnection(httputil.HTTPHeaders(), 'bV7AOm')
    c_0.headers_received()


# Generated at 2022-06-26 08:44:25.742781
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    h_t_t_p_connection_0 = _HTTPConnection(None, None, None, None, None)
    # Test expect: None

    h_t_t_p_connection_0.on_connection_close()


# Generated at 2022-06-26 08:44:33.401685
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = '20180827'
    asyncio_stream_closed_error_0 = AsyncioStreamClosedError(str_1)


# Generated at 2022-06-26 08:44:41.695106
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    '''Unit test for method on_connection_close of class _HTTPConnection'''
    str_0 = '4#qp\x7fhcj'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    i_o_stream_0 = IOStream(None)
    d_k_a_z_i_p_HTTPClientConnection_0 = d_k_a_z_i_p_HTTPClientConnection(i_o_stream_0)
    d_k_a_z_i_p__HTTPConnection_0 = d_k_a_z_i_p__HTTPConnection(i_o_stream_0, h_t_t_p_request_0, d_k_a_z_i_p_HTTPClientConnection_0)
    d_k_a_z

# Generated at 2022-06-26 08:44:49.688539
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = 'pzf\x0e`X'
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()
    str_1 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    int_0 = simple_async_h_t_t_p_client_0._remove_timeout(h_t_t_p_stream_closed_error_0)


# Generated at 2022-06-26 08:45:00.123007
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Setup
    code_0 = 599
    method_0 = 'POST'
    request_0 = HTTPRequest(method_0, 'https://www.python.org/', '/')
    str_0 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    stream_0 = IOStream(1, 1)
    # Exercise
    h_t_t_p_connection_0 = _HTTPConnection(code_0, request_0, stream_0)
    h_t_t_p_connection_0.on_connection_close()
    pass


# Generated at 2022-06-26 08:45:09.025168
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    if True:
        str_0 = 'kJQ!xM\n'
        h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
        int_0 = 72
        http_response_0 = HTTPResponse(h_t_t_p_stream_closed_error_0, int_0)


# Generated at 2022-06-26 08:46:45.029599
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    print("Test: _HTTPConnection.run")
    _http_connection_0 = _HTTPConnection()
    print("Unit test completed")


# Generated at 2022-06-26 08:46:47.695347
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    test_case_0()



# Generated at 2022-06-26 08:47:01.097504
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    def test_body_producer_function():
        pass

    str_0 = '1O\x02'
    httputil_request_start_line_0 = httputil.RequestStartLine(str_0, str_0, str_0)
    dict_0 = dict()
    httputil_http_headers_0 = httputil.HTTPHeaders(dict_0)
    httputil_http_request_0 = httputil.HTTPRequest(httputil_http_headers_0, httputil_request_start_line_0)
    dict_1 = dict()
    httputil_http_headers_1 = httputil.HTTPHeaders(dict_1)

# Generated at 2022-06-26 08:47:15.030153
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    httputil_response_start_line_0 = httputil.ResponseStartLine('GET', 'OK', 'HTTP/1.1')
    httputil_http_headers_0 = httputil.HTTPHeaders()
    httputil_http_headers_0['Host'] = 'Content-Type'
    httputil_http_headers_0['Location'] = 'Content-Length'
    httputil_http_headers_0['Connection'] = 'Content-Length'
    httputil_http_headers_0['Date'] = 'Content-Type'
    httputil_http_headers_0['Content-Type'] = 'Content-Type'
    httputil_http_headers_0['Content-Length'] = 'Content-Length'
    httputil_http_headers_0['Content-Length'] = 'Content-Type'

# Generated at 2022-06-26 08:47:26.947425
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    '''
    Unit test for method finish of class _HTTPConnection
    '''
    print('\n#### _HTTPConnection.finish test')

    http_timeout_error_0 = HTTPTimeoutError('Timeout')
    bytes_0 = b'Connection closed'
    str_0 = 'Connection closed'
    http_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(bytes_0)
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError(bytes_0)
    type_0 = (type(None), type(None), type(None))
    type_1 = (type(None), type(None))
    type_2 = (type(None), type(None))


# Generated at 2022-06-26 08:47:28.762974
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    test_case_0()



# Generated at 2022-06-26 08:47:41.515596
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    max_clients_0 = 281
    hostname_mapping_0 = dict()
    max_buffer_size_0 = 622
    resolver_0 = None # TODO
    defaults_0 = dict()
    max_header_size_0 = 873
    max_body_size_0 = 334
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient(max_clients_0, hostname_mapping_0, max_buffer_size_0, resolver_0, defaults_0, max_header_size_0, max_body_size_0)
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:47:50.132931
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = 'kJQ!xM\n'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_request_0 = HTTPRequest()
    def callback_0(http_response_0):
        pass
    simple_async_h_t_t_p_client_0.fetch_impl(http_request_0, callback_0)


# Generated at 2022-06-26 08:48:05.526036
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Initialization and setup code
    max_clients_0 : int = 10
    int_0 = 104857600
    max_buffer_size_0 : int = int_0
    resolver_0 = None
    defaults_0 = None
    max_header_size_0 = None
    max_body_size_0 = None
    simpleasynchttpclient_0 = SimpleAsyncHTTPClient()
    simpleasynchttpclient_0.initialize(max_clients_0, hostname_mapping=None, max_buffer_size=max_buffer_size_0, resolver=resolver_0, defaults=defaults_0, max_header_size=max_header_size_0, max_body_size=max_body_size_0)
    url_0 = 'http://example.com/'
   

# Generated at 2022-06-26 08:48:09.484877
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    args = ()
    kwargs = {}
    simple_async_http_client_0 = SimpleAsyncHTTPClient(*args, **kwargs)
    simple_async_http_client_0.close()
