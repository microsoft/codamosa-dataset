

# Generated at 2022-06-26 08:42:06.793726
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    test_case_0()

__all__ = [
    "HTTPTimeoutError",
    "HTTPStreamClosedError",
    "SimpleAsyncHTTPClient",
    "SimpleAsyncHTTPClient",
    "SimpleAsyncHTTPClient",
    "SimpleAsyncHTTPClient",
]

# This doesn't work in Python 3 because of the "yield from" in
# get_response.
# TODO: it might be better to just make this into a superclass of
# simple_httpclient.  We can't expose any of the conn methods, but
# the complexity is manageable.
#
# class _HTTPConnection(object):
#    def __init__(self, request, client, release_callback,
#                 io_loop=None, params={}):
#        self.request = request
#        self.client = client
#        self.release_callback

# Generated at 2022-06-26 08:42:13.568297
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = '3#YmHiC'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()


# Generated at 2022-06-26 08:42:15.803855
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'v^jD}c;f,'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)


# Generated at 2022-06-26 08:42:29.369566
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = ';Fp?U_$6'
    string_0 = str_0.capitalize()
    str_1 = '-Y&i;sz'
    h_t_t_p_headers_0 = httputil.HTTPHeaders({str_1:string_0})
    key_values_0 = {'a':'b'}
    h_t_t_p_headers_1 = httputil.HTTPHeaders(key_values_0)
    str_2 = 'Fyb.@[O'
    string_1 = str_2.upper()
    str_3 = 'D}6mHv]l'
    h_t_t_p_headers_2 = httputil.HTTPHeaders({str_3:string_1})

# Generated at 2022-06-26 08:42:41.821716
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 't{'
    int_0 = 9
    str_1 = ''
    str_2 = 'W'
    str_3 = 'S'
    int_1 = 2
    str_4 = '%|Z'
    any_0 = ()
    any_1 = ()
    client_0 = AsyncHTTPClient()
    stream_0 = IOStream()
    http_request_0 = HTTPRequest(str_0)
    _http_connection_0 = _HTTPConnection(client_0, stream_0, http_request_0, int_0, any_1)
    headers_received_0 = httputil.HTTPHeaders(any_0)
    setattr(_http_connection_0, 'code', int_1)
    setattr(_http_connection_0, 'reason', str_1)

# Generated at 2022-06-26 08:42:54.348810
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'v^jD}c;f,'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    h_t_t_p_client_request_0 = HTTPClientRequest()
    h_t_t_p_client_request_0.method = 'GET'
    h_t_t_p_client_request_0.url = 'http://www.google.com/'
    h_t_t_p_client_request_0.headers = {'Host': 'www.google.com'}
    h_t_t_p_client_connection_0 = _HTTPConnection(h_t_t_p_client_request_0)
    h_t_t_p_client_connection_0.code = 300
    h_

# Generated at 2022-06-26 08:42:56.188518
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Create a SimpleAsyncHTTPClient
    http_client_0 = SimpleAsyncHTTPClient()
    http_client_0.close()


# Generated at 2022-06-26 08:42:58.345605
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _http_connection_0 = _HTTPConnection()


# Generated at 2022-06-26 08:43:06.293913
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    print("Testing method data_received of class _HTTPConnection")
    stream_0 = IOStream()
    http_connection_0 = HTTP1Connection(stream_0, True, HTTP1ConnectionParameters(), None)
    chunk_0 = ''.encode()
    http_connection_0.data_received(chunk_0)


# Generated at 2022-06-26 08:43:14.415485
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError('P')
    str_0 = 'j'
    str_1 = 'i'
    str_2 = 'k'
    str_3 = 'h'
    str_4 = 'g'
    str_5 = 'f'
    str_6 = 'e'
    str_7 = 'd'
    str_8 = 'c'
    str_9 = 'b'
    str_10 = 'a'
    assert_equals(str_10, str_9)


# Generated at 2022-06-26 08:44:15.178598
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.initialize()


# Generated at 2022-06-26 08:44:22.340160
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # AsyncHTTPClient.initialize(max_clients=10, hostname_mapping=None, max_buffer_size=104857600, resolver=None, defaults=None, max_header_size=None, max_body_size=None)
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 08:44:25.351456
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    print('testing class _HTTPConnection')
    test_case_0()

if __name__ == '__main__':
    test__HTTPConnection()

# Generated at 2022-06-26 08:44:38.348225
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    t_e_s_t_h_t_t_p_connection_0 = _HTTPConnection()
    t_e_s_t_h_t_t_p_connection_0.data_received(test_bytes_0)
    t_e_s_t_h_t_t_p_connection_0.data_received(test_bytes_1)


# Generated at 2022-06-26 08:44:41.321905
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    h_t_t_p_connection_0 = _HTTPConnection()


# Generated at 2022-06-26 08:44:42.925438
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    test_case_0()


# Generated at 2022-06-26 08:44:45.197819
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _HTTPConnection().on_connection_close()


# Generated at 2022-06-26 08:44:47.105565
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.run()


# Generated at 2022-06-26 08:45:00.029385
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    print("Testing _HTTPConnection headers_received()")

    h_t_t_p_connection_0 = _HTTPConnection()

    result = h_t_t_p_connection_0.headers_received(None, None)

    # Unit test for method _write_body of class _HTTPConnection
    def test__HTTPConnection__write_body():
        print("Testing _HTTPConnection _write_body()")

        h_t_t_p_connection_0 = _HTTPConnection()
        print(h_t_t_p_connection_0.parsed.port)

        result = h_t_t_p_connection_0.headers_received(None, None)

        # Unit test for method _run_callback of class _HTTPConnection

# Generated at 2022-06-26 08:45:04.085773
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    h_t_t_p_connection_0 = _HTTPConnection()
    result = h_t_t_p_connection_0.headers_received()
    assert result is None


# Generated at 2022-06-26 08:46:03.963240
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    h_t_t_p_connection_1 = _HTTPConnection()
    h_t_t_p_connection_1.on_connection_close()


# Generated at 2022-06-26 08:46:17.007171
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    from tornado.iostream import StreamClosedError
    from tornado.http1connection import _HTTPRequest
    from typing import Optional, Tuple, Type

    for case in test_data:
        h_t_t_p_connection_0 = _HTTPConnection()
        h_t_t_p_connection_0.request = _HTTPRequest()
        h_t_t_p_connection_0._handle_exception = _HTTPConnection._handle_exception
        h_t_t_p_connection_0.on_connection_close = _HTTPConnection.on_connection_close
        h_t_t_p_connection_0.io_loop = object()
        h_t_t_p_connection_0.final_callback = callable()
        h_t_t_p_connection_0.strea = object()


# Generated at 2022-06-26 08:46:22.162024
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    h_t_t_p_connection_0 = _HTTPConnection()
    # assert some stuff
    h_t_t_p_connection_0.finish()
    # assert some more stuff

# Generated at 2022-06-26 08:46:29.265161
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client = SimpleAsyncHTTPClient()
    max_clients = 10
    hostname_mapping = None
    max_buffer_size = 104857600
    resolver = None
    defaults = None
    max_header_size = None
    max_body_size = None
    simple_async_h_t_t_p_client.initialize(max_clients, hostname_mapping, max_buffer_size, resolver, defaults, max_header_size, max_body_size)


# Generated at 2022-06-26 08:46:32.586157
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    i_o_loop_0 = IOLoop()
    h_t_t_p_request__0 = HTTPRequest()
    l_a_m_b_d_0 = lambda h_t_t_p_response_0: None
    l_a_m_b_d_1 = lambda: None

    # h_t_t_p_client_0 = SimpleAsyncHTTPClient()


# Generated at 2022-06-26 08:46:34.701468
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    client = SimpleAsyncHTTPClient()
    client.close()


# Generated at 2022-06-26 08:46:38.787129
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Unit test for method data_received of class _HTTPConnection
    h_t_t_p_connection_0 = _HTTPConnection()
    chunk = 0
    h_t_t_p_connection_0.data_received(chunk)


# Generated at 2022-06-26 08:46:48.442193
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Setup
    h_t_t_p_connection_0 = _HTTPConnection()
    # Teardown
    try:
        h_t_t_p_connection_0.finish()
    except Exception as exception_0:
        print("Exception while calling _HTTPConnection.finish()")
        print("  -> exception: ", exception_0)
        # Expected
        assert str(exception_0) == "AssertionError"
        return
    raise Exception("expected exception")


# Generated at 2022-06-26 08:46:59.777580
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    http_client = SimpleAsyncHTTPClient()
    http_client.queue.append(('key', 'request', 'callback'))
    http_client.active['key'] = ('request', 'callback')
    http_client.waiting['key'] = ('request', 'callback', 'timeout_handle')
    
    # call the method
    http_client._process_queue()
    
    assert http_client.queue == collections.deque()
    assert http_client.active == {'key': ('request', 'callback')}
    assert http_client.waiting == {}
    

# Generated at 2022-06-26 08:47:14.306100
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():

    # Parameter types
    max_clients_0 = 10
    hostname_mapping_0 = None
    max_buffer_size_0 = 104857600
    resolver_0 = None
    defaults_0 = None
    max_header_size_0 = None
    max_body_size_0 = None

    # Default values for the parameters
    # Expected exception: TypeError
    def test_SimpleAsyncHTTPClient_initialize_0() -> None:
        simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
        simple_async_h_t_t_p_client_0.initialize(max_clients=max_clients_0)
        assert True


# Generated at 2022-06-26 08:49:25.575511
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    h_t_t_p_connection_0 = _HTTPConnection()
    # h_t_t_p_connection_0.initialize()
    h_t_t_p_connection_0.initialize(
        max_body_size=512,
        max_buffer_size=2560,
        max_clients=10,
        max_header_size=512,
    )
    h_t_t_p_connection_0.initialize(max_body_size=512, max_clients=10)
    h_t_t_p_connection_0.initialize(max_buffer_size=2560, max_clients=10)
    h_t_t_p_connection_0.initialize(max_buffer_size=2560, max_body_size=512)
    h_t

# Generated at 2022-06-26 08:49:27.435590
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    h_t_t_p_connection_0 = _HTTPConnection()


# Generated at 2022-06-26 08:49:31.246641
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.on_connection_close()


# Generated at 2022-06-26 08:49:44.252599
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.chunks = [b'']
    h_t_t_p_connection_0.code = 200
    h_t_t_p_connection_0.final_callback = None
    h_t_t_p_connection_0.headers = None
    h_t_t_p_connection_0.io_loop = None
    h_t_t_p_connection_0.request = None
    h_t_t_p_connection_0.stream = None
    # mocks
    h_t_t_p_connection_0.chunks.append(b'')
    h_t_t_p_connection_0.request.follow_redirects = True
    h_t

# Generated at 2022-06-26 08:49:48.185927
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.finish()


# Generated at 2022-06-26 08:49:49.268146
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    pass


# Generated at 2022-06-26 08:49:52.705805
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.data_received(chunk=bytes())


# Generated at 2022-06-26 08:49:56.698564
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    h_t_t_p_connection_0 = _HTTPConnection()
    chunk_1 = "string"
    # test method data_received
    h_t_t_p_connection_0.data_received(chunk_1)


# Generated at 2022-06-26 08:49:58.589588
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    h_t_t_p_connection_0 = _HTTPConnection()
    test_case_0()

# Generated at 2022-06-26 08:50:02.716105
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_case_0())
    loop.close()

if __name__ == "__main__":
    test_case_0()