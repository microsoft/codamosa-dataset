

# Generated at 2022-06-26 08:41:28.405423
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    tuple_0 = (1.229, 0.0, 1.229)
    _HTTPConnection(*tuple_0)



# Generated at 2022-06-26 08:41:31.320165
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass

if __name__ == "__main__":
    test_case_0()
    test__HTTPConnection_on_connection_close()

# Generated at 2022-06-26 08:41:33.913101
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    _HTTPConnection = _HTTPConnection()
    chunk = bytes()


# Generated at 2022-06-26 08:41:40.675082
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    http_time_out_error_0 = HTTPTimeoutError(string_0)
    http_time_out_error_0.__str__()
    http_time_out_error_1 = HTTPTimeoutError(string_1)
    http_time_out_error_1.__str__()


# Generated at 2022-06-26 08:41:48.770054
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    request_0 = HTTPRequest()
    _HTTPConnection_0 = _HTTPConnection(simple_async_h_t_t_p_client_0, request_0)
    _HTTPConnection_0.finish()


# Generated at 2022-06-26 08:41:53.322239
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass


# Generated at 2022-06-26 08:42:03.083514
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    fut = Future()

    def release_callback():
        fut.set_result(None)

    stream = IOStream(socket.socket())
    stream.connect(
        ("www.google.com", 80),
        lambda: stream.write(b"GET / HTTP/1.0\r\n\r\n"),
        io_loop=IOLoop.current(),
    )


# Generated at 2022-06-26 08:42:07.694558
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:42:18.342371
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_1.defaults = simple_async_h_t_t_p_client_0.defaults
    simple_async_h_t_t_p_client_2 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_2.defaults = simple_async_h_t_t_p_client_1.defaults
    simple_async_h_t_t_p_client_3 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:42:22.013566
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()
    # simple_async_h_t_t_p_client_0 is a SimpleAsyncHTTPClient
    # self._remove_timeout is a private method
    # However, you can access it by calling the method through the base class
    # simple_async_h_t_t_p_client_0.remove_timeout is a private method
    simple_async_h_t_t_p_client_0._remove_timeout("")
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:43:02.209688
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Init some variables
    str_1 = 'M'
    httputil_request_start_line_1 = httputil.RequestStartLine(str_1, None, None)
    str_2 = '*I'
    httputil_http_headers_1 = httputil.HTTPHeaders()
    stream_io_stream_0 = IOStream(None, None, None)
    obj_0_http_connection_1 = _HTTPConnection(stream_io_stream_0)
    obj_0_http_connection_1.final_callback = None
    obj_0_http_connection_1.request = None
    obj_0_http_connection_1.headers_received(
        httputil_request_start_line_1, httputil_http_headers_1)
    # Call method _HTTPConnection.fin

# Generated at 2022-06-26 08:43:05.228690
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    this = _HTTPConnection()
    this.on_connection_close()


# Generated at 2022-06-26 08:43:08.812478
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

# Generated at 2022-06-26 08:43:18.049749
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    io_loop_0 = IOLoop(make_current=False)
    io_stream_0 = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0), io_loop_0, NULL, 1048576, 1048576)
    http_client_0 = HTTPClient()
    http_client_0.io_loop = io_loop_0
    http_client_0._connect_future = Future()
    http_client_0._connect_future = NULL
    http_client_0._connecting = 0
    http_client_0.max_clients = 512

# Generated at 2022-06-26 08:43:24.889416
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Run unit test for _HTTPConnection.headers_received

    http_request_0 = HTTPRequest('http://127.0.0.1:8080/test')

    http_connection_0 = HTTPClientConnection(http_request_0)

    h_t_t_p_response_start_line_0 = HTTPStartLine('http://127.0.0.1:8080/test', 'GET', 'HTTP/1.1')
    h_t_t_p_header_0 = HTTPHeader(h_t_t_p_response_start_line_0)

    await http_connection_0.headers_received(h_t_t_p_response_start_line_0, h_t_t_p_header_0)
    # Make sure the unit test is valid

# Generated at 2022-06-26 08:43:33.740759
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'j'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    i_o_stream_0 = IOStream(h_t_t_p_timeout_error_0)
    int_0 = 3
    int_1 = -26
    io_loop_0 = IOLoop()
    httpclient_0 = HTTPClient(i_o_stream_0, int_0, int_1, io_loop_0)
    int_2 = 60
    int_3 = -91
    int_4 = -48
    str_1 = 's'
    httpclient_0._HTTPConnection(int_2, int_3, int_4, str_1)

# Generated at 2022-06-26 08:43:45.486691
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    assert h_t_t_p_timeout_error_0.__class__ == HTTPTimeoutError
    assert h_t_t_p_timeout_error_0.__doc__ == 'HTTPTimeoutError(*args, **kwargs)'
    assert h_t_t_p_timeout_error_0.__dict__ == {'args': ('*I',), '_args': ('*I',)}
    assert h_t_t_p_timeout_error_0.__module__ == '__main__'
    assert h_t_t_p_timeout_error_0.__str__() == '*I'

# Generated at 2022-06-26 08:43:53.264453
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # initialize(self,max_clients=10,hostname_mapping=None,max_buffer_size=104857600,resolver=None,defaults=None,max_header_size=None,max_body_size=None)
    # Close the `.AsyncHTTPClient` and free any resources used.
    #
    # .. versionadded:: 4.1
    async def example():
        pass


# Generated at 2022-06-26 08:44:03.102605
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    _http_connection_0 = _HTTPConnection()
    try:
        _http_connection_0._on_timeout()
    except HTTPTimeoutError:
        pass
    try:
        _http_connection_0._on_timeout(h_t_t_p_timeout_error_0)
    except HTTPTimeoutError:
        pass


# Generated at 2022-06-26 08:44:16.223256
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    i_o_loop_0 = IOLoop.current()
    client_0 = HTTPClient(i_o_loop_0, force_instance=True)
    address_0 = 'localhost:8090'
    # TODO: Replace with a valid url string.
    url_0 = 'http://localhost:8090/hello'
    request_0 = HTTPRequest(url_0, 'GET')
    # TODO: Replace with a test real socket adress.
    sock_address_0 = ('localhost', 8090)
    http_connection_0 = _HTTPConnection(client_0, address_0, request_0, sock_address_0, i_o_loop_0)


# Generated at 2022-06-26 08:45:00.419694
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    if (not sys.platform.startswith('win')):
        base_context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
        base_context.load_cert_chain(
            '/etc/ssl/certs/ca-certificates.crt',
            keyfile=None,
            password=None,
        )
        _client_ssl_defaults = base_context
    else:
        _client_ssl_defaults = None
    io_loop = IOLoop.current()
    io_loop.make_current()
    io_loop = io_loop

# Generated at 2022-06-26 08:45:04.652178
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '*C'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)


# Generated at 2022-06-26 08:45:13.995821
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = '#'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    str_2 = '*I'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_2)
    str_3 = '*I'
    h_t_t_p_timeout_error_3 = HTTPTimeoutError(str_3)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_0['c'] = dict_1
    dict_2['c'] = dict_0

# Generated at 2022-06-26 08:45:21.639225
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_1 = '&Y'
    obj_0 = _HTTPConnectionHandler(str_1)
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    obj_0.stream.error = h_t_t_p_timeout_error_1
    obj_0.final_callback = lambda: print('Callback')
    obj_0.on_connection_close()


# Generated at 2022-06-26 08:45:33.878264
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    import tornado.iostream

# Generated at 2022-06-26 08:45:45.050778
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = r'K'
    str_1 = 's'

# Generated at 2022-06-26 08:45:55.106643
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    io_loop = IOLoop()
    io_loop.make_current()
    stream = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0), io_loop=io_loop)
    request = HTTPRequest('http://localhost/', method='GET')
    h_t_t_p_client = AsyncHTTPClient(io_loop=io_loop)

# Generated at 2022-06-26 08:45:59.910006
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:46:07.122528
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    _http_connection_0 = _HTTPConnection()
    _http_connection_1 = _HTTPConnection()

# Generated at 2022-06-26 08:46:17.838407
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = 'd'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    str_2 = 'jj'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_2)
    str_3 = '5S'
    h_t_t_p_timeout_error_3 = HTTPTimeoutError(str_3)
    str_4 = 'YK'
    h_t_t_p_timeout_error_4 = HTTPTimeoutError(str_4)
    str_5 = 'lK'

# Generated at 2022-06-26 08:48:24.930880
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = 'GET'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['headers'] = dict_1
    dict_2 = dict()
    dict_0['request_timeout'] = dict_2
    str_1 = '^g'
    dict_1['User-Agent'] = str_1
    str_2 = '{(k'
    dict_1['Accept-Encoding'] = str_2
    str_3 = 'Connection: close\r\nAccept-Encoding: gzip\r\nUser-Agent: tornado/3.2.2\r\nHost: 127.0.0.1:8888\r\nAccept-Encoding: identity\r\n'
    dict_2['header_string'] = str_3
    dict_3 = dict()
   

# Generated at 2022-06-26 08:48:31.431236
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    try:
        _HTTPConnection(None).on_connection_close()
    except StreamClosedError as exception_instance:
        return

    raise AssertionError(
        "Expected call to function 'on_connection_close' of class "
        "'_HTTPConnection' to raise an exception of type 'StreamClosedError' but no "
        "exception was raised"
    )


# Generated at 2022-06-26 08:48:36.470783
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '*I'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_0 = h_t_t_p_stream_closed_error_0.__str__()
    test_case_0()
    test_HTTPStreamClosedError___str__()

# Generated at 2022-06-26 08:48:40.353052
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # _HTTPConnection.run()
    _HTTPConnection_0_run_0(HTTP1Connection(None, True, None, None))
    _HTTPConnection_0_run_1(HTTP1Connection(None, True, None, None))


# Generated at 2022-06-26 08:48:42.679836
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _httpconnection_0 = _HTTPConnection()
    _httpconnection_0.on_connection_close()


# Generated at 2022-06-26 08:48:46.487075
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Initialize HTTPConnection instance
    # http_connection_0 = _HTTPConnection()
    # Test 'run' of class _HTTPConnection
    # http_connection_0.run()
    pass


# Generated at 2022-06-26 08:48:48.785091
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = 'I'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)


# Generated at 2022-06-26 08:48:58.244253
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    with pytest.raises(HTTPTimeoutError):
        _h_t_t_p_connection_0 = _HTTPConnection(request=None)
        _h_t_t_p_connection_0.run()
    _h_t_t_p_connection_1 = _HTTPConnection(request=None)
    with pytest.raises(HTTPTimeoutError):
        _h_t_t_p_connection_1.run()
    with pytest.raises(HTTPTimeoutError):
        _h_t_t_p_connection_1.run()


# Generated at 2022-06-26 08:49:08.038382
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    m_e_t_h_o_d_0 = 'POST'
    str_0 = 'y\x03%'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()

# Generated at 2022-06-26 08:49:09.089192
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # TODO: incomplete test
    assert True


# Generated at 2022-06-26 08:49:48.958996
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    assert h_t_t_p_timeout_error_0.__str__() == '*I', "Method __str__ of class HTTPTimeoutError. Got " + str(
        h_t_t_p_timeout_error_0.__str__()) + ", expected " + '*I'


# Generated at 2022-06-26 08:50:01.216647
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    # Create a mock object for io_loop
    io_loop_0 = mock.Mock()
    # Create a mock object for stream
    stream_0 = mock.Mock()
    # Create an instance of class _HTTPConnection
    _http_connection_0 = _HTTPConnection(io_loop_0, stream_0)
    # Set stream to an expected value
    stream_0.set_close_callback.return_value = None
    # Set stream to an expected value
    stream_0.connect.return_value = None
    _http_connection_0.stream = stream_0
    # Call _HTTPConnection.run
    # _HTTPConnection.run()
    _http_connection_0

# Generated at 2022-06-26 08:50:12.420257
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    r_e_q_u_e_s_t_0 = HTTPRequest("http://www.google.com/")
    h_t_t_p_request_0 = HTTPRequest("http://www.google.com/", 'POST')
    h_t_t_p_request_1 = HTTPRequest("http://www.google.com/", 'POST')
    h_t_t_p_request_2 = HTTPRequest("http://www.google.com/", 'POST')
    h_t_t_p_request_3 = HTTPRequest("http://www.google.com/", 'POST')
    h_t_t_p_request_4 = HTTPRequest("http://www.google.com/", 'POST')

# Generated at 2022-06-26 08:50:15.088166
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = 'D'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    result_0 = h_t_t_p_stream_closed_error_0.__str__()


# Generated at 2022-06-26 08:50:15.894941
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Test with all valid values
    pass


# Generated at 2022-06-26 08:50:20.080578
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = '*M'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_stream_closed_error_0)


# Generated at 2022-06-26 08:50:30.383836
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    try:
        test_case_0()
    except HTTPStreamClosedError:
        print("HTTPStreamClosedError")
    except HTTPTimeoutError:
        print("HTTPTimeoutError")
    except HTTPError:
        print("HTTPError")

# Library unit test:
HTTPRequest('GET', 'http://0.0.0.0:64646/get', {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'})


# Generated at 2022-06-26 08:50:32.689603
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    """test method on_connection_close of _HTTPConnection"""



# Generated at 2022-06-26 08:50:40.723178
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    def p_func(arg0:HTTPRequest, arg1:Callable[[HTTPResponse], None]):
        print('arg0: ')
        print(arg1)
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    str_0 = '*I'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

# Generated at 2022-06-26 08:50:42.932726
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '*I'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
