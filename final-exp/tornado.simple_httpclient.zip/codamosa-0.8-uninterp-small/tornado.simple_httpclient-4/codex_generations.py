

# Generated at 2022-06-26 08:41:36.823591
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_0 = '__main__'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_0 = '__main__'
    h_t_t_p_client_error_0 = HTTPClientError(str_0)
    str_0 = '__main__'
    h_t_t_p_error_0 = HTTPError(str_0)
    str_0 = 'SimpleAsyncHTTPClient:release_fetch() was called, but we are not waiting for a key. Check your release_callback logic.'
    assert_exception(str_0, AssertionError)

# Generated at 2022-06-26 08:41:45.965640
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    print('********************************************************')
    print('Test for method fetch_impl of class SimpleAsyncHTTPClient')
    # Test for normal case (1)
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    print('--------------------------------------------------')
    # Test for normal case (2)
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    print('--------------------------------------------------')

    # Test for normal case (3)
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    print('********************************************************')


# Generated at 2022-06-26 08:41:54.589378
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Setup
    max_clients_0 = 10
    hostname_mapping_0 = {}
    max_buffer_size_0 = 104857600
    resolver_0 = Resolver()
    defaults_0 = {}
    max_header_size_0 = None
    max_body_size_0 = None
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    simple_async_http_client_0.initialize(max_clients_0, hostname_mapping_0, max_buffer_size_0, resolver_0, defaults_0, max_header_size_0, max_body_size_0)


# Generated at 2022-06-26 08:42:00.569392
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    resolver_arg_2 = Resolver()
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    test_SimpleAsyncHTTPClient_initialize_case_0()


# Generated at 2022-06-26 08:42:15.529696
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = 'headers_received'
    str_2 = '__main__'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_2)
    d_i_c_0 = dict()
    d_i_c_1 = dict()
    d_i_c_2 = dict()

# Generated at 2022-06-26 08:42:29.352819
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    settings_0 = {}
    h_t_t_p_client_1 = HTTPClient(settings_0)
    h_e_a_d_request_1 = HTTPRequest("GET", h_t_t_p_client_1._DEFAULT_CA_CERTS, "http://localhost:8080/")
    h_e_a_d_request_1._unicode_url = "http://localhost:8080/"
    h_e_a_d_request_1.headers = {"Host": "localhost:8080"}
    h_e_a_d_request_1.auth_mode = "basic"
    h_e_a_d_request_1.headers

# Generated at 2022-06-26 08:42:31.024604
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass


# Generated at 2022-06-26 08:42:42.379991
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import httptools
    class _HTTPConnection(httptools.HTTPConnection):
        def __init__(self, stream, addr, client) -> None:
            self.stream = stream
            self.addr = addr
            self.client = client
            self.handshake_ok = False
            self.buffer = bytearray()
            self.start_time = self.client.io_loop.time()
            self.stream.set_close_callback(self.on_connection_close)
            self.protocol = httptools.HttpResponseParser(self)
            self.stream.read_until_close(
                self.streaming_callback or self.body_callback,
                self.on_connection_close,
            )

        def on_connection_close(self):
            self._release()
            message = "Connection closed"

# Generated at 2022-06-26 08:42:54.680646
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    unit_test_max_header_size = 0
    unit_test_max_body_size = 0
    unit_test_io_loop = IOStream(None, None)
    unit_test_request = HTTPRequest(None, None, None, None)
    unit_test_connection_info = None
    unit_test__http_connection = _HTTPConnection(None, None, unit_test_max_header_size, unit_test_max_body_size, unit_test_io_loop, unit_test_request, unit_test_connection_info)
    unit_test__http_connection._on_timeout(None)
    unit_test__http_connection._remove_timeout()
    unit_test__http_connection._create_connection(unit_test_io_loop)
    unit_test__http_connection._get_ssl_options

# Generated at 2022-06-26 08:42:59.002550
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    print(str_1)

test_HTTPTimeoutError___str__()

# Generated at 2022-06-26 08:43:40.317594
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = '__main__'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    str_2 = '__main__'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_2)
    str_3 = '__main__'
    h_t_t_p_timeout_error_3 = HTTPTimeoutError(str_3)
    str_4 = '__main__'
    h_t_t_p_timeout_error_4 = HTTPTimeoutError(str_4)
    str_5 = '__main__'
    h_t_t_p_timeout_error_

# Generated at 2022-06-26 08:43:41.611804
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass


# Generated at 2022-06-26 08:43:55.100284
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    resolver_0 = Resolver()
    name_0 = '__main__'
    type_0 = type(name_0)
    dict_0 = {type_0(name_0):type_0}
    resolver_1 = OverrideResolver(resolver=resolver_0,mapping=dict_0)
    tcp_client_0 = TCPClient(resolver=resolver_1)
    bytes_0 = b'\x80\x00\x00\x00\x00\x00\x00\x00'
    ptr_0 = id(bytes_0)
    int_0 = (ptr_0 << 3) ^ (ptr_0 >> 59)
    int_1 = int_0 >> 8
    int_2 = int_1 ^ int_0

# Generated at 2022-06-26 08:43:58.226966
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    str_0 = '__main__'
    _HTTPConnection(str_0)


# Generated at 2022-06-26 08:44:07.043909
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    i_o_loop_0 = IOLoop.current()
    request_0 = HTTPRequest('http://localhost:8888/', None, None, None, None, None, None, False, None, None, None, None, None, None, None, None, None, True, None, None, None, None, None, None, None, None, None, None, None)
    response_future_0 = http_client._HTTPConnection(i_o_loop_0, request_0, None, None, None, None, False)
    response_future_0.run()


# Generated at 2022-06-26 08:44:13.508355
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '__main__'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    assert h_t_t_p_stream_closed_error_0.__str__() == str_0


# Generated at 2022-06-26 08:44:26.860807
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    resolver_0 = Resolver()
    h_t_t_p_timeout_error_0 = HTTPTimeoutError('__main__')
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError('__main__')
    key_0 = object()
    str_0 = '__main__'
    resolver_1 = Resolver()
    h_t_t_p_timeout_error_1 = HTTPTimeoutError('__main__')
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError('__main__')
    key_1 = object()
    str_1 = '__main__'
    resolver_2 = Resolver()
    h_t_t_p_timeout_error_2 = HTTPTimeoutError('__main__')
    h_

# Generated at 2022-06-26 08:44:29.140334
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    test_case_0()


# Generated at 2022-06-26 08:44:33.051225
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '__main__'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)


# Generated at 2022-06-26 08:44:41.584712
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    stream_0 = IOStream()
    url_0 = 'http://opensource.apple.com/tarballs/libdispatch/libdispatch-104.30.1.tar.gz'
    parsed_url_0 = urlparse(url_0)
    e_t_ag_0 = '4af0e4f7-8264-636d-6bdf-6e31e6eb67d6-2'
    i_n_m_e_m_0 = 0
    d_s_s_0 = False
    i_o_loop_0 = IOLoop()
    method_0 = 'HEAD'
    d_s_s_1 = False
    s_s_0 = True
    d_s_s_2 = False
    d_s_s_3 = False
    d_s_

# Generated at 2022-06-26 08:47:12.344735
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    i_o_loop_0 = IOLoop.current()
    dict_0 = {}
    dict_1 = {}
    simpleasynchttpclient_0 = SimpleAsyncHTTPClient(i_o_loop=i_o_loop_0, defaults=dict_0, resolver=dict_1, allow_ipv6=False)
    simpleasynchttpclient_0.close()


# Generated at 2022-06-26 08:47:23.571061
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    request_0 = HTTPRequest()
    response_start_line_0 = httputil.ResponseStartLine(str(), str(), str())
    h_t_t_p_headers_0 = httputil.HTTPHeaders()
    h_t_t_p_client_connection_0 = _HTTPConnection(request_0, IOLoop(), None)
    h_t_t_p_client_connection_0.headers_received(response_start_line_0, h_t_t_p_headers_0)


# Generated at 2022-06-26 08:47:28.157029
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)


# Generated at 2022-06-26 08:47:31.087474
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    return None


# Generated at 2022-06-26 08:47:39.878032
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    str_2 = h_t_t_p_timeout_error_0.message or "Timeout"
    assert str_1 == str_2


# Generated at 2022-06-26 08:47:48.764592
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    import asyncio
    import functools

    def test_coro():
        return h_t_t_p_timeout_error_0

    loop = asyncio.get_event_loop()
    task = loop.create_task(test_coro())
    # task.cancel()
    try:
        loop.run_until_complete(task)
    finally:
        loop.close()



# Generated at 2022-06-26 08:47:50.424333
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass
    # on_connection_close()


# Generated at 2022-06-26 08:48:05.672082
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = '__main__'
    int_0 = 256
    lst_0 = []
    str_1 = '__main__'
    int_1 = 256
    dict_0 = {}
    str_2 = '__main__'
    str_3 = '__main__'
    int_2 = 75
    float_0 = 10.0
    str_4 = '__main__'
    str_5 = '__main__'
    bool_0 = False
    str_6 = '__main__'
    int_3 = 256
    dict_1 = {}
    str_7 = '__main__'
    int_4 = 75
    str_8 = '__main__'
    str_9 = '__main__'
    int_5 = 75

# Generated at 2022-06-26 08:48:11.728842
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    i_o_loop_0 = IOLoop()
    request_0 = HTTPRequest('http://www.google.com')
    http_client_impl_0 = _HTTPConnection(request_0, i_o_loop_0)
    http_client_impl_0.on_connection_close()

# lint_ignore=E1101,R0915

# Generated at 2022-06-26 08:48:22.577248
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = '__main__'
    str_1 = '__main__'
    str_2 = '__main__'
    tuple_0 = ()
    tuple_1 = ()
    from tornado import concurrent
    from tornado import httputil
    from tornado import iostream
    from tornado import netutil
    from tornado import stack_context
    from tornado import testing
    from tornado.curl_httpclient import CurlAsyncHTTPClient
    from tornado.escape import utf8
    from tornado.httpclient import HTTPResponse, HTTPRequest, HTTPClient
    from tornado.httputil import HTTPHeaders
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado.netutil import Resolver
    from tornado.simple_httpclient import _RequestProxy, HTTPError

# Generated at 2022-06-26 08:49:16.637166
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    pass


# Generated at 2022-06-26 08:49:30.849405
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = 'asyncio'
    str_2 = 'Future'
    str_3 = '__getattr__'
    str_4 = 'set_result'
    str_5 = 'False'
    str_6 = 'Expected future to be done'
    str_7 = 'request'
    str_8 = 'Expected future to be done'
    str_9 = 'request'
    str_10 = 'raise_error'
    str_11 = 'Expected future to be done'
    str_12 = 'request'
    str_13 = 'asyncio'
    str_14 = 'CancelledError'

# Generated at 2022-06-26 08:49:34.066422
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection_0 = _HTTPConnection(HTTP1Connection(),('127.0.0.1', 8080))
    _HTTPConnection_0.run()


# Generated at 2022-06-26 08:49:38.499351
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()


# Generated at 2022-06-26 08:49:41.977626
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    #print("Testing _HTTPConnection")
    #print("data_received()")
    #print("no test")
    pass


# Generated at 2022-06-26 08:49:54.246016
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import io
    import json
    import tornado.httpclient
    import tornado.httputil
    import tornado.ioloop
    import unittest
    import io
    import tornado.gen
    import tornado.tcpclient
    import tornado.testing

    @tornado.gen.coroutine
    def main():
        client = tornado.httpclient.AsyncHTTPClient(force_executor = True)
        response = yield client.fetch('https://api.ipify.org/?format=json')
        print(json.loads(response.body))

    try:
        tornado.ioloop.IOLoop.current().run_sync(main)
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    print()
    print('Unit Testing')
    test_case_0()
    test__HTTPConnection

# Generated at 2022-06-26 08:50:06.970356
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = '__main__'
    c_l_i_e_n_t_0 = AsyncHTTPClient()
    h_t_t_p_request_0 = HTTPRequest(str_0,connect_timeout=None,request_timeout=None,proxy_host=None)
    _HTTPConnection_0 = c_l_i_e_n_t_0.fetch(h_t_t_p_request_0)
    chunk = ""
    _HTTPConnection_0.data_received(chunk)
    print(_HTTPConnection_0.code)
    print(_HTTPConnection_0.reason)
    print(_HTTPConnection_0.headers)
    print(_HTTPConnection_0.chunks)
    print(_HTTPConnection_0.request)
    print(_HTTPConnection_0.io_loop)
    print

# Generated at 2022-06-26 08:50:15.512815
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    io_loop_0 = IOLoop()
    str_1 = '__main__'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    str_2 = '__main__'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_2)
    str_3 = '__main__'
    h_t_t_p_timeout_error_3 = HTTPTimeoutError(str_3)
    str_4 = '__main__'
    h_t_t_p_timeout_error_4 = HTTPTimeoutError(str_4)
    str_5 = '__main__'
   

# Generated at 2022-06-26 08:50:18.673696
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)


# Generated at 2022-06-26 08:50:23.404219
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = '__main__'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    str_2 = '__main__'
    h_t_t_p_client_error_0 = HTTPClientError(str_2)
    str_3 = '__main__'
    h_t_t_p_server_error_0 = HTTPServerError(str_3)
    str_4 = '__main__'
    h_t_t_p_error_0 = HTTPError(str_4)
    str_5 = '__main__'
    h_t_t_p_error_1