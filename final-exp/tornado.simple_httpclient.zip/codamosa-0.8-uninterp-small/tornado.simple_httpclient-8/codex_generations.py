

# Generated at 2022-06-26 08:41:43.994169
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():

    # Construct HTTP response object.
    self = simple_async_h_t_t_p_client_0
    request = HTTPRequest("GET", "http://www.google.com")
    # self.headers = None
    self.code = 200
    data = ""
    response = HTTPResponse(
        request,
        self.code,
        reason=getattr(self, "reason", None),
        headers=self.headers,
        request_time=self.io_loop.time() - self.start_time,
        start_time=self.start_wall_time,
        buffer=BytesIO(data),
        effective_url=self.request.url,
    )

    # Unit test for method finish of class _HTTPConnection
    test__HTTPConnection_finish_1(self, request, response)



# Generated at 2022-06-26 08:41:52.307508
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

    connection_0 = simple_async_h_t_t_p_client_0._HTTPConnection()

    connection_0.run('GET', 'http://127.0.0.1:8080/')

if __name__ == '__main__':
    test_case_0()
    test__HTTPConnection_run()

# Generated at 2022-06-26 08:42:04.347212
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Create a new instance of SimpleAsyncHTTPClient
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()

    # Create a new instance of HTTPRequest
    http_request_0 = HTTPRequest('http://www.google.com/', 'GET')

    def callback_0(http_response_0: object) -> None:
        pass

    # Call method fetch_impl of SimpleAsyncHTTPClient with arguments request and callback
    simple_async_h_t_t_p_client_1.fetch_impl(http_request_0, callback_0)


# Generated at 2022-06-26 08:42:11.742202
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()
    c = _HTTPConnection(simple_async_h_t_t_p_client_1)
    assert c.final_callback is not None
    c.on_connection_close()


# Generated at 2022-06-26 08:42:17.436875
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    request_0 = HTTPRequest(url='http://www.example.com')
    callback_0 = lambda arg: arg
    expected_0 = None
    simple_async_h_t_t_p_client_0.fetch_impl(request_0, callback_0)


# Generated at 2022-06-26 08:42:27.825168
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    data = BytesIO()
    response = HTTPResponse(None, None, None, None, None, data, None) # type: Any
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPConnection(False, None, None)
    simple_async_h_t_t_p_client_0.code = None
    simple_async_h_t_t_p_client_0.chunks = [data]
    response_0 = simple_async_h_t_t_p_client_0.finish()
    assert response == response_0

# Generated at 2022-06-26 08:42:41.326455
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    class _TestCls(_HTTPConnection):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            self.args = args
            self.kwargs = kwargs
            self._final_callback = None
            self._io_loop = None
            self._request = None
            self._response = None
            self._start_time: float = 0.0
            self._start_wall_time: float = 0.0
            self.code: int = 0
            self.connection: httputil.HTTP1Connection
            self.final_callback: Callable[[_ResponseProxy], None]
            self.headers: httputil.HTTPHeaders
            self.io_loop: ioloop.IOLoop
            self.parsed: urllib.parse.SplitResult

# Generated at 2022-06-26 08:42:44.413369
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()


# Generated at 2022-06-26 08:42:50.741439
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():

    resolver_0 = Resolver()
    hostname_mapping_0 = dict()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.initialize(100, hostname_mapping_0, 104857600, resolver_0)


# Generated at 2022-06-26 08:43:00.582681
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    from httpclient import _HTTPConnection
    from httpclient import _HTTPResponseDelegate
    from tornado.tcpclient import TCPClient
    from tornado import testing

    test = testing.AsyncTestCase()
    io_loop = test.get_new_ioloop()

    test_url = "http://example.com/"
    test_data = b"Hello World"
    test_body = b"Hello World"

    class _HTTPResponseDelegateImpl(_HTTPResponseDelegate):
        chunks = []  # type: List[bytes]

        def headers_received(self, *args: Any, **kwargs: Any) -> None:
            pass

        def finish(self) -> None:
            pass


# Generated at 2022-06-26 08:43:44.457499
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError('\x11\x1fcl\x03\t\x1a^')
    str_2 = h_t_t_p_stream_closed_error_1.__str__()


# Generated at 2022-06-26 08:43:54.073734
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    coroutine_4 = null()
    coroutine_1 = null()
    h_t_t_p_connection_parameters_0 = HTTP1ConnectionParameters(True, 1000, None, True, False, False)
    h_t_t_p_client_connection_0 = _HTTPConnection(coroutine_1, coroutine_4, h_t_t_p_connection_parameters_0)
    print(h_t_t_p_client_connection_0)


# Generated at 2022-06-26 08:44:07.194376
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = 'I=7iQ8=KTe\x0bxG'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    str_5 = h_t_t_p_timeout_error_0.message
    if str_5 is None:
        pass
    else:
        if len(str_5) == 0:
            pass
        else:
            # pass
            str_6 = 'I=7iQ8=KTe\x0bxG'
            h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_6)
            str_8 = h_t_t_p_timeout_error_0.__str

# Generated at 2022-06-26 08:44:14.733552
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = 'I=7iQ8=KTe\x0bxG'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    assert str_1 == str_0    
    

# Generated at 2022-06-26 08:44:19.990501
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Initalize objects
    c_r_q_0 = HTTPClient._HTTPConnection(None, None)

    # Call test function
    c_r_q_0._on_connection_close()


# Generated at 2022-06-26 08:44:29.314229
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    h_t_t_p_timeout_error_0 = HTTPTimeoutError('I=7iQ8=KTe\x0bxG')
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError('ce#Iw$]{=\t')
    simpleAsyncHTTPClient_0 = SimpleAsyncHTTPClient(15, {'3s1': 'c1', '3s0': 'c0'}, 104857600, Resolver(), {'K': 'x'}, 100, 100)
    simpleAsyncHTTPClient_0.initialize(15, {'3s1': 'c1', '3s0': 'c0'}, 104857600, Resolver(), {'K': 'x'}, 100, 100)
    simpleAsyncHTTPClient_0.close()


# Generated at 2022-06-26 08:44:39.689121
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    s_t_r_1 = 'I=7iQ8=KTe\x0bxG'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(s_t_r_1)
    s_t_r_2 = h_t_t_p_timeout_error_0.__str__()
    h_t_t_p_request_0 = HTTPRequest(str_1)
    h_t_t_p_client_0 = AsyncHTTPClient()
    h_t_t_p_response_0 = h_t_t_p_client_0.fetch(h_t_t_p_request_0, raise_error=False)
    h_t_t_p_connection_0 = h_t_t_p_response_0.result()
   

# Generated at 2022-06-26 08:44:50.136466
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = ';6m'
    int_0 = -1
    int_1 = -1
    int_2 = -1
    str_1 = 'cIU\x1d'
    int_3 = -3
    int_4 = 3
    int_5 = 2
    str_2 = ''
    int_6 = -1
    int_7 = -1
    int_8 = 10
    int_9 = -2
    int_10 = 2
    int_11 = -1
    int_12 = 3
    int_13 = -1
    int_14 = -1
    int_15 = -1
    int_16 = 10
    int_17 = 2
    str_3 = ''
    int_18 = 1
    int_19 = 10
    str_4 = 'S'


# Generated at 2022-06-26 08:45:01.550129
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    print("Testing fetch_impl")
    dict_0: Dict[str, str]
    h_t_t_p_request_0 = HTTPRequest()
    def callback_0(h_t_t_p_response_0: HTTPResponse) -> None:
        pass
    def test_0():
        print("Testing fetch_impl with arguments")
        dict_0 = dict()
        http_timeout_error_0 = HTTPTimeoutError('error')
        http_stream_closed_error_0 = HTTPStreamClosedError('error')
        h_t_t_p_request_0 = HTTPRequest(url='url')
        http_request_0 = h_t_t_p_request_0
        h_t_t_p_request_0.body = bytes()
        method_0 = 'method'


# Generated at 2022-06-26 08:45:11.025916
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    bytes_0 = b'\x0c'
    ssl_options_0 = None
    str_0 = 'ndo6\x08<4C,\x1f'
    str_1 = '\x1b\x10\x10\x01\x0b'
    str_2 = '\x1b\x10\x10\x01\x0b'
    str_3 = '\x1b\x10\x10\x01\x0b'
    str_4 = '\x1b\x10\x10\x01\x0b'
    str_5 = '6\x08<4C,\x1f'
    str_obj_0 = (str_1, str_2, str_3, str_4)

# Generated at 2022-06-26 08:45:51.292057
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Test whether the method raises any exceptions
    # Test whether the method returns anything
    pass


# Generated at 2022-06-26 08:45:57.551828
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection_0 = _HTTPConnection()
    str_0 = _HTTPConnection_0.run()
    # The returned string contains a random number, hence, it is not possible to
    # test  for the exact return value.
    _HTTPConnection_0.run()

# Generated at 2022-06-26 08:46:05.616368
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = 'jE!EW=\x0b'
    str_1 = 'jE!EW=\x0b'
    h_t_t_p_head_ers_0 = httputil.HTTPHeaders()
    h_t_t_p_request_start_line_0 = httputil.RequestStartLine('POST', str_1, 'HTTP/1.0')
    _HTTPConnection(str_0, 0, None, None, None, None, True).headers_received(h_t_t_p_request_start_line_0, h_t_t_p_head_ers_0)
    sys_exit_0 = SystemExit

# Generated at 2022-06-26 08:46:10.779098
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    h_t_t_p_1_0_conn_0 = HTTP1Connection(None, False, None)
    h_t_t_p_1_0_conn_0.run()


# Generated at 2022-06-26 08:46:16.621403
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = 'I=7iQ8=KTe\x0bxG'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    i_o_http_5 = SimpleAsyncHTTPClient()
    i_o_http_5.close()
    i_o_http_6 = SimpleAsyncHTTPClient()
    i_o_http_6.close()


# Generated at 2022-06-26 08:46:20.606693
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection_0 = _HTTPConnection(None, None)
    _HTTPConnection_0.finish()


# Generated at 2022-06-26 08:46:26.802857
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Test for correct error on close
    # Test that connection is closed
    i_o_stream_0 = IOStream(socket.socket())
    h_t_t_p_client_connection_0 = _HTTPConnection(i_o_stream_0)
    h_t_t_p_client_connection_0.on_connection_close()



# Generated at 2022-06-26 08:46:39.883225
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    from tornado import httpclient
    from tornado import httputil

    str_0 = 'rs#\x1bkh>\x0c'
    h_t_t_p_connection_0 = _HTTPConnection(None)
    h_t_t_p_connection_0.start(None, None)

    str_1 = 'rE}r\x02\x1e9'
    h_t_t_p_request_0 = httpclient.HTTPRequest(str_1, None, None)
    str_2 = 'zK\x0cR\x08\x00\xc8'
    h_t_t_p_connection_0.write_headers(h_t_t_p_request_0, httputil.HTTPHeaders({str_2: None}))

# Generated at 2022-06-26 08:46:44.964622
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:46:53.603526
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    str_0 = '2c6U^I'
    int_0 = -1
    bytes_0 = bytes(str_0, 'utf-8')
    ip_addr_1 = IPNetwork(bytes_0).ip
    w_a_r_n_i_n_g_5_0 = DeprecationWarning(str_0)
    c_o_n_n_e_c_t_i_o_n_time_out_error_0 = ConnectionTimeoutError(str_0)
    str_1 = (str_0 * 4) + str_0
    str_2 = (str_0 + str_1) * 2
    tuple_0 = (str_2, )
    str_3 = ", ".join(tuple_0)
    h_t_t_p_timeout_error_0 = HTTP

# Generated at 2022-06-26 08:48:14.886676
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    max_clients_0 = 7
    resolver_1 = Resolver()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient(resolver_1)
    simple_async_h_t_t_p_client_0.initialize(max_clients_0)


# Generated at 2022-06-26 08:48:21.012355
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    resolver_0 = Resolver()
    dict_0 = {}
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    simple_async_http_client_0.close()
    simple_async_http_client_0.initialize(hostname_mapping=dict_0, resolver=resolver_0)
    simple_async_http_client_0.close()


# Generated at 2022-06-26 08:48:30.034230
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = 'I=7iQ8=KTe\x0bxG'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    expected_output_0 = str_0
    if h_t_t_p_timeout_error_0:
        str_1 = h_t_t_p_timeout_error_0.__str__()
        assert expected_output_0 == str_1
    else:
        h_t_t_p_timeout_error_0.__str__()


# Generated at 2022-06-26 08:48:37.027497
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Create the object
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    # Create a simple HTTPRequest
    http_request_0 = HTTPRequest('http://127.0.0.1:8080/')
    # Define the callback
    def _callback(response: HTTPResponse) -> None:
        pass
    # Call the method
    simple_async_http_client_0.fetch_impl(http_request_0, _callback)


# Generated at 2022-06-26 08:48:48.258322
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-26 08:49:00.795382
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = '=Mt}/SQ]0e\x15RYf'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    str_2 = '\x1bI8M2[V]X'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_2)
    str_3 = h_t_t_p_timeout_error_1.__str__()
    str_4 = '+D,W`&X['
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_4)
    str_5 = h_t_t_p_timeout_error_2.__str

# Generated at 2022-06-26 08:49:04.574627
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = 'I=7iQ8=KTe\x0bxG'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()



# Generated at 2022-06-26 08:49:06.216357
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _http_connection = None
    _http_connection.on_connection_close()


# Generated at 2022-06-26 08:49:22.703220
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'I=7iQ8=KTe\x0bxG'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    str_2 = 'jJ:_'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_2)
    str_3 = h_t_t_p_timeout_error_1.__str__()
    str_4 = '6U\x0c}X\x0b'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_4)
    str_5 = h_t_t_p_timeout_error_2.__str__()


# Generated at 2022-06-26 08:49:23.947328
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass
