

# Generated at 2022-06-26 08:41:59.491420
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # First test: headers_received called with first_line of type HTTPRequestStartLine,
    # headers of type HTTPHeaders, test expected call to callback with argument type HTTPHeaders
    # Testing argument type HTTPHeaders
    header_callback_called = [False]
    def header_callback(arg):
        header_callback_called[0] = True
        assert(isinstance(arg, str))
    first_line = HTTPRequestStartLine([], "", "")
    headers = HTTPHeaders()
    fake_headers = FakeHeaders()
    fake_first_line = FakeFirstLine()
    fake_headers.callback = header_callback
    fake_first_line.callback = header_callback
    fake_headers.injected_exception = None
    fake_first_line.injected_exception = None
    fake_headers.injected

# Generated at 2022-06-26 08:42:03.606245
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:42:16.978968
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    response_line, headers, data = b"HTTP/1.0 200 OK\r\n\r\n", {} ,b"test_case_data_1"
    response_line, headers, data = b"HTTP/1.0 404 Not Found\r\n\r\n", {} ,b"test_case_data_2"
    response_line, headers, data = b"HTTP/1.0 301 Moved Permanently\r\n"
    def _mock_request_get_host(self):
        return "www.tornadoweb.org"
    def _mock_request_get_origin_req_host(self):
        return "localhost:8080"
    def _mock_request_get_path(self):
        return "/"

# Generated at 2022-06-26 08:42:29.537688
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    http_client0 = SimpleAsyncHTTPClient()
# Initializing the following variables:
    chunk0 = b''

# Invoke method on target object
    http_client0.stream.set_close_callback(_HTTPConnection.on_connection_close)
    _HTTPConnection.data_received(chunk0)

    chunk1 = b'\x00\x00\x00\x00'

# Invoke method on target object
    _HTTPConnection.data_received(chunk1)

    chunk2 = b'\x02\x01\x01\x00\x05\x01\x01\xff\x01\x00\x00\xff\xff'

# Invoke method on target object
    _HTTPConnection.data_received(chunk2)


# Generated at 2022-06-26 08:42:32.425158
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Simple test to see if the method can be called without errors
    http_conn = _HTTPConnection(None, None, None, None, None, None, None, None, None, None)
    http_conn.finish()


# Generated at 2022-06-26 08:42:42.773269
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    request_0 = HTTPRequest()
    error_0 = Failure()
    code_0 = 0
    reason_0 = "TEST"
    headers_0 = HTTPHeaders()
    start_header_time_0 = 0
    stream_0 = IOStream()
    _HTTPConnection_0 = _HTTPConnection(request_0, simple_async_h_t_t_p_client_0, error_0, code_0, reason_0, headers_0, start_header_time_0, stream_0, SimpleAsyncHTTPClient())
    _HTTPConnection_0.finish()
    assert _HTTPConnection_0.code == 0
    assert _HTTPConnection_0.reason == "TEST"


# Generated at 2022-06-26 08:42:52.354047
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    assert simple_async_h_t_t_p_client_0 is not None
    f_0 = simple_async_h_t_t_p_client_0.fetch('https://client1.example.com:2053/path/to/hello.txt')
    assert f_0 is not None

if __name__ == "__main__":
    """
    # Test case 0
    test_case_0()

    # Test function run of class _HTTPConnection
    test__HTTPConnection_run()
    """
    test_case_0()

# Generated at 2022-06-26 08:43:00.182358
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    io_loop_0 = simple_async_h_t_t_p_client_0.io_loop
    request_0 = HTTPRequest('http://localhost/')
    http_conn_0 = _HTTPConnection(request_0, io_loop_0)

    assert isinstance(http_conn_0.release_callback, Callable[[], None])


if __name__ == '__main__':
    import dotenv
    dotenv.load_dotenv()

    test_case_0()
    test__HTTPConnection()

# Generated at 2022-06-26 08:43:05.923554
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0._HTTPConnection.finish()


# Generated at 2022-06-26 08:43:16.593707
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    stream_0 = IOStream()
    sockaddr_0 = socket.gethostbyname("tornado.org")
    parameters_0 = HTTP1ConnectionParameters(
        no_keep_alive=True, max_header_size=16280, max_body_size=1048064, decompress=True
    )
    http_connection_0 = _HTTPConnection(
        stream_0,
        True,
        parameters_0,
        sockaddr_0,
        simple_async_h_t_t_p_client_0=simple_async_h_t_t_p_client_0,
    )
    assert http_connection_0.context == None
    assert http_connection_0.stream == stream_0

# Generated at 2022-06-26 08:43:52.797002
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()


# Generated at 2022-06-26 08:44:01.018355
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    httpclient_0 = _HTTPConnection(simple_async_h_t_t_p_client_0, "", "", 0)
    chunk = b"R PgsgZ"
    httpclient_0.data_received(chunk)


# Generated at 2022-06-26 08:44:02.597533
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass


# Generated at 2022-06-26 08:44:13.269383
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    stream_0 = SocketIOStream()
    s_s_l_options_0 = simple_async_h_t_t_p_client_0._get_ssl_options("http")
    _HTTPConnection(
        simple_async_h_t_t_p_client_0, stream_0, s_s_l_options_0, "http")


# Generated at 2022-06-26 08:44:15.090332
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection_0 = _HTTPConnection()
    _HTTPConnection_0.finish()


# Generated at 2022-06-26 08:44:27.778664
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    import tornado.ioloop
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    i_o_loop_0 = tornado.ioloop.IOLoop.current()
    request_0 = HTTPRequest(url=str(),headers=None)
    request_0.header_callback = None
    request_0.follow_redirects = True
    request_0.max_redirects = None
    request_0.user_agent = None
    request_0.connect_timeout = None
    request_0.request_timeout = None
    request_0.if_modified_since = None
    request_0.streaming_callback = None
    request_0.header_callback = None
    request_0.allow_nonstandard_methods = False
    request_0.validate_cert

# Generated at 2022-06-26 08:44:36.154065
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection_run_0 = _HTTPConnection()
    _HTTPConnection_run_0.set_running_callback(_HTTPConnection_run_0.on_connection_close)
    _HTTPConnection_run_0.set_running_callback(_HTTPConnection_run_0.on_connection_close)
    _HTTPConnection_run_0.set_running_callback(_HTTPConnection_run_0.on_connection_close)


# Generated at 2022-06-26 08:44:45.273794
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Initialize test objects.
    request = HTTPRequest()
    callback = lambda x: x
    # Test the method.
    asyncio_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    asyncio_h_t_t_p_client_0.fetch_impl(request, callback)
    # Assert the results.


# Generated at 2022-06-26 08:44:48.628363
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_connection__http_connection_0 = _HTTPConnection(None, None, None, None, None)
    http_connection__http_connection_0.on_connection_close()
    assert True


# Generated at 2022-06-26 08:44:58.345502
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    #  str() of a ``HTTPTimeoutError`` should return the empty string if its message is ``None``.
    simple_async_h_t_t_p_client_0.timeout_error = HTTPTimeoutError("HTTPTimeoutError")
    assert simple_async_h_t_t_p_client_0.timeout_error.__str__() == ""

#  str() of a ``HTTPTimeoutError`` should return its message if its message is not ``None``.

# Generated at 2022-06-26 08:45:34.272282
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    assert 0 == sys._getframe().f_lineno


# Generated at 2022-06-26 08:45:39.197698
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Create an instance of _HTTPConnection
    f_0 = _HTTPConnection(object, object)
    # Call on_connection_close method
    f_0.on_connection_close()


# Generated at 2022-06-26 08:45:47.419512
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = 'T]'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    dict_0 = dict()
    dict_0[str()] = None
    dict_0[None] = bytes()
    dict_0[str()] = float()
    dict_0[str()] = None
    dict_0[str()] = dict_0
    dict_0[str()] = dict_0
    dict_0[str()] = str()
    dict_0[str()] = dict_0
    dict_0[str()] = dict_0
    dict_0[dict_0] = dict_0
    str_1 = ';T]w%<'
    dict_0[str_1] = dict_0

# Generated at 2022-06-26 08:45:52.463050
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = 'n'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    x = h_t_t_p_timeout_error_0.__str__()
    assert x == 'n'

HTTP1ConnectionParameters.decode_headers = True


# Generated at 2022-06-26 08:46:05.122310
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    import socket
    import ssl
    import time
    import urllib.parse
    import httplib

    import tornado.gen
    import tornado.httpserver
    import tornado.testing
    import tornado.web
    import tornado.netutil
    import tornado.httpclient
    from tornado import httputil

    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import _RequestProxy
    from tornado.httpclient import HTTPTimeoutError
    from tornado.httpclient import HTTPResponse
    from tornado.httpclient import HTTPStreamClosedError
    from tornado.httpclient import HTTPRequest
    from tornado.httpclient import HTTPResponse
    from tornado.netutil import _client_ssl_defaults


# Generated at 2022-06-26 08:46:07.655747
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    connection = test_connection_0()
    return connection

# Generated at 2022-06-26 08:46:17.995744
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = '<rGCOFV2RS:r'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    d_i_c_t_0 = {}
    h_t_t_p_request_proxy_0 = _RequestProxy(d_i_c_t_0)
    s_e_t_0 = set()
    d_i_c_t_1 = {}
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_request_proxy_0, 0, reason=s_e_t_0, headers=d_i_c_t_1, request_time=0, start_time=0, buffer=None, effective_url='')

# Generated at 2022-06-26 08:46:29.152608
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():

    str_1 = '<rGCOFV2RS:r'
    max_header_size_0 = 548776404
    max_buffer_size_1 = 102571396
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_2 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_1.initialize(max_buffer_size_1,max_header_size_0)
    simple_async_h_t_t_p_client_2.close()


# Generated at 2022-06-26 08:46:32.531792
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    h_t_t_p_request_0 = HTTPRequest('http://localhost/', 'GET')
    simple_async_http_client_0 = SimpleAsyncHTTPClient(h_t_t_p_request_0)
    simple_async_http_client_0.close()
    test_case_0()

if __name__ == '__main__':
    test_SimpleAsyncHTTPClient_initialize()

# Generated at 2022-06-26 08:46:38.897553
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '<rGCOFV2RS:r'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = h_t_t_p_stream_closed_error_0.__str__()
    #assert str_1 == 'Stream closed'
    ################################################################


# Generated at 2022-06-26 08:47:26.126529
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = 'B'
#    str_1 = '4{b[|QHTVIPz^'
    str_2 = 'eWq3\/T'
    str_3 = 'jx\%0'
    str_4 = 'U6'
    str_5 = '\%c'
    str_6 = '\%b'
    str_7 = '\#f'
    str_8 = '\%'
    str_9 = '\#e'
    str_10 = '\%i'
    str_11 = '<rGCOFV2RS:r'
    str_12 = 'B'
    str_13 = 'L'
    str_14 = 'JX'
    str_15 = 'B'
    str_16 = 'Jh'
    str_

# Generated at 2022-06-26 08:47:40.973969
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Try to instantiate an object with wrong number of arguments
    test_str = 'test_str'
    test_io_loop = IOLoop()
    test_io_stream = IOStream(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
    try:
        arg_0 = 'http://www.google.com'
        arg_1 = 'GET'
        arg_2 = test_io_loop
        arg_3 = test_io_stream
        arg_4 = test_str
        obj = _HTTPConnection(arg_0, arg_1, arg_2, arg_3, arg_4)
        test_0 = False
    except:
        test_0 = True
    if not test_0:
        raise ValueError('Failed test #0')

# Generated at 2022-06-26 08:47:52.147572
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    http_timeout_error_0 = HTTPTimeoutError('<QKG|<-L2:G>')
    str_0 = ')'
    str_1 = 'KSLvT8T;]y'
    str_2 = ':'
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_request_0, int_0, error=http_timeout_error_0)

# Generated at 2022-06-26 08:48:02.384966
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    req = HTTPRequest('http://www.tornadoweb.org/', 'GET', headers={'Host': 'www.tornadoweb.org'})
    clt = HTTPClient(io_loop=IOLoop.current())
    conn = _HTTPConnection(req, clt, final_callback=lambda x: print(x))
    ftr = conn.run()
    IOLoop.current().run_sync(lambda: ftr)


# Generated at 2022-06-26 08:48:09.768001
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    r_e_q_u_e_s_t_0 = HTTPRequest('http://172.16.0.6:8080/', 'GET')
    r_e_q_u_e_s_t_0.max_buffer_size = 104857600
    @gen.coroutine
    def h_t_t_p_client_0(r_e_q_u_e_s_t_0):
        h_t_t_p_client_1 = SimpleAsyncHTTPClient()
        h_t_t_p_client_1.initialize()
        h_t_t_p_response_0 = yield h_t_t_p_client_1.fetch(r_e_q_u_e_s_t_0)
        h_t_t_p_stream_closed_

# Generated at 2022-06-26 08:48:21.735018
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    str_0 = ';kfNuZi4D8'
    str_1 = 'from'
    str_2 = 'hWgE3q@'
    str_3 = 'exfW"QV1.u'
    int_0 = 442
    int_1 = 11
    str_4 = 'tPG1^]12x'
    str_5 = 'from'
    str_6 = 'hWgE3q@'
    str_7 = 'exfW"QV1.u'
    int_2 = 442
    int_3 = 11
    str_8 = 'tPG1^]12x'
    str_9 = 'from'
    str_10 = 'hWgE3q@'

# Generated at 2022-06-26 08:48:28.081850
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    """Unit test for method on_connection_close of class _HTTPConnection"""
    io_loop_0 = None
    try:
        _httpconnection_0 = _HTTPConnection((io_loop_0))
        # Call the method under test
        _httpconnection_0.on_connection_close()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 08:48:36.092752
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = '<rGCOFV2RS:r'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 08:48:41.016301
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '<rGCOFV2RS:r'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = h_t_t_p_stream_closed_error_0.__str__()
    assert str_1 == str_0

# Generated at 2022-06-26 08:48:46.539058
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # fetch_impl is a method of SimpleAsyncHTTPClient
    str_0 = 'c'
    http_request_0 = HTTPRequest(str_0)
    callable_0 = test_case_0
    int_1 = SimpleAsyncHTTPClient.fetch_impl(http_request_0, callable_0)


# Generated at 2022-06-26 08:49:32.733660
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    class Test_HTTPConnection_headers_received_class_0(object):
        def __init__(self):
            self.final_callback = None
            self.code = None
            self.first_line = httputil.ResponseStartLine("", "", "")
            self.headers = httputil.HTTPHeaders()
            self.request = None
            self.io_loop = IOLoop()

        def _should_follow_redirect(self) -> bool:
            return False

    test__http_connection_headers_received_0 = Test_HTTPConnection_headers_received_class_0()
    test__http_connection_headers_received_0.code = 200
    test__http_connection_headers_received_0._should_follow_redirect()
    test__http_connection_headers_received_0.code = 100


# Generated at 2022-06-26 08:49:45.717340
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    max_clients_0 = 10
    # max_clients_0 is the number of concurrent requests that can be
    # in progress; when this limit is reached additional requests will be
    # queued. Note that time spent waiting in this queue still counts
    # against the ``request_timeout``.

    hostname_mapping_0 = None
    # hostname_mapping_0 is a dictionary mapping hostnames to IP addresses.
    # It can be used to make local DNS changes when modifying system-wide
    # settings like ``/etc/hosts`` is not possible or desirable (e.g. in
    # unittests).

    max_buffer_size_0 = 104857600
    resolver_0 = None
    # TCPClient could create a Resolver for us, but we have to do it
    # ourselves to support hostname_mapping

# Generated at 2022-06-26 08:49:57.897880
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_3 = 'UUXHXtF0f4'
    h_t_t_p_response_start_line_0 = httputil.ResponseStartLine(
        200, '<LnC:', 'http'
    )

    # Classify the expected instance type of h_t_t_p_response_start_line_0
    cls_name_0 = type(h_t_t_p_response_start_line_0).__name__
    if ((cls_name_0 == 'RequestStartLine') or (cls_name_0 == 'ResponseStartLine')):
        # The expected instance type is httputil.StartLine
        assert True
    else:
        # The expected instance type is not httputil.StartLine
        assert False

    h_t_t_p_headers_0

# Generated at 2022-06-26 08:49:59.117761
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    test_case_0()



# Generated at 2022-06-26 08:50:11.180140
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Test with a single request and do not raise error
    url = "http://www.google.com"
    io_loop = IOLoop.current()
    request = HTTPRequest(url, streaming_callback=_TestHTTPConnection_run.test_case_0)
    h_t_t_p_connection_0 = _HTTPConnection(io_loop, request, None)
    h_t_t_p_connection_0.run()
    assert True

    # Test with a single request and raise error
    url = "http://www.google.com"
    io_loop = IOLoop.current()
    request = HTTPRequest(url, streaming_callback=_TestHTTPConnection_run.test_case_1)
    h_t_t_p_connection_1 = _HTTPConnection(io_loop, request, None)
   

# Generated at 2022-06-26 08:50:14.851584
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    h_t_t_p_error_0 = HTTPError(int_0, message=str_0)
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()
    # TODO: make a test case


# Generated at 2022-06-26 08:50:17.267792
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-26 08:50:21.922935
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = 'cx_pK6W8]'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    assert(str_0 == str_1)


# Generated at 2022-06-26 08:50:34.733239
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    http_request_0 = HTTPRequest('http://www.tornadoweb.org/')
    str_0 = '1\x1a\x0b\x1b\x0c\x1e\x1f\x19\x1a\x1d\x13\x17\x19\x1c\x1a\x1a'
    http_client_error_0 = HTTPClientError(str_0)
    str_1 = 'roR@n74lTT'
    response = HTTPResponse(http_request_0, 599, error=http_client_error_0, request_time=0, )
    #simple_async_http_client_0 = SimpleAsyncHTTPClient(max_clients=2.0)
    simple_async_http_client_0 = SimpleAsyncHTTP

# Generated at 2022-06-26 08:50:38.954200
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    executor_0 = ThreadPoolExecutor(2)
    io_loop_0 = IOLoop.current()
    io_loop_0.set_default_executor(executor_0)
    io_loop_0.run_sync(test_case_0)


if __name__ == "__main__":
    test_case_0()