

# Generated at 2022-06-26 08:41:45.083130
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():

    # Create an instance of SimpleAsyncHTTPClient
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

    # Calling SimpleAsyncHTTPClient constructor with parameters max_clients and hostname_mapping, default values of max_buffer_size, resolver and defaults, and parameters max_header_size and max_body_size
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient(10, {'host_name':'host_ip'}, 104857600, Resolver(), {}, 1024, 104857600)

    # Calling SimpleAsyncHTTPClient constructor with parameters max_clients and hostname_mapping, default values of max_buffer_size, resolver and defaults, and parameters max_header_size and max_body_size
    simple_async_h_t_t

# Generated at 2022-06-26 08:41:52.952980
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    i_o_l_o_o_p_0 = IOLoop()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    request_0 = HTTPRequest("http://www.example.com/", method='GET')
    callback_0 = lambda x_0=None: (None)
    simple_async_h_t_t_p_client_0.fetch_impl(request_0, callback_0)


# Generated at 2022-06-26 08:41:58.542016
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:42:04.568888
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    # Enforce method name
    httpclient = simple_async_h_t_t_p_client_0.fetch("http://test.com")
    http_client = httpclient.start()
    http_client.finish()
    # Enforce method name
    http_client._HTTPConnection_finish()


# Generated at 2022-06-26 08:42:11.276685
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.on_connection_close()

if __name__ == "__main__":
    test_case_0()
    test__HTTPConnection_on_connection_close()

# Generated at 2022-06-26 08:42:18.231697
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    host, port, request, final_callback, release_callback, start_time, key, he  = "", "", "", "", "", "", "", ""
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    handle = simple_async_h_t_t_p_client_0._HTTPConnection(host, port, request, final_callback, release_callback, start_time, key, he)



# Generated at 2022-06-26 08:42:25.597826
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_con = _HTTPConnection(Request(HTTPRequest()), object(), object())
    http_con.final_callback = object()
    http_con.stream = object()
    http_con.on_connection_close()


# Generated at 2022-06-26 08:42:30.871098
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:42:38.070199
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    arg_0 = None
    _HTTPConnection_0 = _HTTPConnection()
    _HTTPConnection_0.on_connection_close(arg_0)
    _HTTPConnection_0.on_connection_close()
    pass


# Generated at 2022-06-26 08:42:44.941534
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    class _HTTPConnection():
        def __init__(self: '_HTTPConnection',
                     stream: IOStream,
                     params: 'HTTP1ConnectionParameters',
                     address: Tuple[str, Optional[int]],
                     max_buffer_size: int,
                     delegate: '_HTTPConnectionDelegate') -> None:
            pass

    max_buffer_size = 1024
    address = ('', None)
    params = HTTP1ConnectionParameters()
    delegate = _HTTPConnectionDelegate(None, None, None, None)
    stream = IOStream(None, None, None)

    simple_async_h_t_t_p_client_0 = _HTTPConnection(stream, params, address,
                                                    max_buffer_size, delegate)


# Generated at 2022-06-26 08:45:00.054792
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():

    import sys

    import tornado.httpclient

    class SimpleAsyncHTTPClient(tornado.httpclient.AsyncHTTPClient):

        def get(self, url: str) -> "Future[tornado.httpclient.HTTPResponse]":
            return self.fetch(tornado.httpclient.HTTPRequest(url))

        def fetch(self, request: "tornado.httpclient.HTTPRequest") -> "Future[tornado.httpclient.HTTPResponse]":
            # SimpleAsyncHTTPClient's constructor is private, so forgive it its sins.
            # pylint: disable=protected-access
            return SimpleAsyncHTTPClient._fetch(self, request, raise_error=True)


# Generated at 2022-06-26 08:45:04.396856
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    f = (lambda: None)
    chunk = b''
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0._HTTPConnection.data_received(chunk)



# Generated at 2022-06-26 08:45:09.937840
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_timeout_error_0 = HTTPTimeoutError('')
    http_timeout_error_0.__str__()


# Generated at 2022-06-26 08:45:23.075688
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # testcase-0
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    stream_0 = IOStream(socket=None, io_loop=None, max_buffer_size=None,
                        read_chunk_size=None)

# Generated at 2022-06-26 08:45:24.897812
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection.finish()


# Generated at 2022-06-26 08:45:34.978255
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():

    from tornado.concurrent import Future

    from tornado.http1connection import HTTP1ConnectionParameters
    from tornado.iostream import IOStream

    from tornado.log import gen_log

    import contextlib
    import signal
    import unittest

    from tornado.testing import AsyncTestCase, bind_unused_port

    # signal.set_wakeup_fd is not implemented on Windows or App Engine.
    # signal.set_wakeup_fd is not in python 3.2 on CentOS 6.
    skip = (
        (sys.platform == "win32")
        or ("App Engine" in os.environ.get("SERVER_SOFTWARE", ""))
        or not hasattr(signal, "set_wakeup_fd")
    )


# Generated at 2022-06-26 08:45:45.366222
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_request_0 = HTTPRequest('GET', 'https://example.com/')
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()
    http_request_1 = HTTPRequest('GET', 'https://example.com/', connect_timeout=123.0)
    simple_async_h_t_t_p_client_2 = SimpleAsyncHTTPClient()
    http_request_2 = HTTPRequest('GET', 'https://example.com/', request_timeout=123.0)
    simple_async_h_t_t_p_client_3 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:45:51.937352
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    _h_t_t_p_connection_0 = _HTTPConnection(simple_async_h_t_t_p_client_0, None)
    _h_t_t_p_connection_0.on_connection_close()


# Generated at 2022-06-26 08:45:59.371782
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    try:
        h_t_t_p_timeout_error_test_0 = HTTPTimeoutError(message = 'Timeout')
        h_t_t_p_timeout_error_test_0.__str__()
    except Exception:
        print('Exception caught in __str__() method of SimpleAsyncHTTPClient class')


# Generated at 2022-06-26 08:46:02.866957
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    message = "abc"
    http_timeout_error_0 = HTTPTimeoutError(message)
    assert http_timeout_error_0.__str__() == message


# Generated at 2022-06-26 08:46:39.786755
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    u_r_l_0 = 'http://127.0.0.1:8080'
    m_e_t_h_o_d_0 = 'GET'
    h_e_a_d_e_r_s_0 = {}
    u_r_l_0 = http_util.url_concat(u_r_l_0, {})
    http_request_0 = HTTPRequest(u_r_l_0, method=m_e_t_h_o_d_0, headers=h_e_a_d_e_r_s_0)
    http_response_0 = HTTPResponse(request=http_request_0)
    def callback(http_response): pass
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:46:46.038835
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    i_o_loop_0 = module_0.IOLoop()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    assert simple_async_h_t_t_p_client_0.close() is None


# Generated at 2022-06-26 08:46:50.374463
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    if __name__ == '__main__':
        print('Unit test for method finish of class _HTTPConnection')
        i_o_loop_0 = module_0.IOLoop()
        simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
        test_case_0()

# Generated at 2022-06-26 08:46:52.910517
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    i_o_loop_0 = module_0.IOLoop()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0._HTTPConnection_finish()


# Generated at 2022-06-26 08:46:55.054833
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # TODO write unit test for method _HTTPConnection.run
    pass


# Generated at 2022-06-26 08:47:01.388594
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Test first argument
    chunk = None
    
    
    
    
    
    
    

    i_o_loop_0 = module_0.IOLoop()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0._HTTPConnection.data_received(chunk)



# Generated at 2022-06-26 08:47:15.110187
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    i_o_loop_0 = module_0.IOLoop()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:47:26.991877
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    chunk_0 = b'b'
    chunk_1 = b'\x80J\x80\x0b\x00\x13\x00\x16\x00\x00\x005\x01\x00\x00\x8bN\x84\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    chunk_2 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0b\x00\x00\x00\x00E'

# Generated at 2022-06-26 08:47:29.250452
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    module_0.IOLoop.current().stop()


# Generated at 2022-06-26 08:47:33.181643
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    http_stream_closed_error_0 = HTTPStreamClosedError("Stream closed")
    str_0 = str(http_stream_closed_error_0)
    assert(str_0 == "Stream closed")
