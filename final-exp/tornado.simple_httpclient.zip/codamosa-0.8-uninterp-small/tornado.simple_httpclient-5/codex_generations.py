

# Generated at 2022-06-26 08:41:33.901488
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _http_connection = _HTTPConnection()


# Generated at 2022-06-26 08:41:36.073322
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _HTTPConnection_0 = _HTTPConnection()
    _HTTPConnection_0.finish()


# Generated at 2022-06-26 08:41:45.927102
# Unit test for method run of class _HTTPConnection

# Generated at 2022-06-26 08:41:55.002733
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    io_loop_0 = IOLoop()
    io_loop_0.make_current()
    http_client_0 = SimpleAsyncHTTPClient()
    http_client_0.configure('127.0.0.1', port=8888)
    http_client_0.stream_request(HTTPRequest(method='GET', url='http://127.0.0.1:8888/'))
    #return 'Tests Successful!'


# Generated at 2022-06-26 08:42:06.867684
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.initialize(59)
    simple_async_h_t_t_p_client_0.close()
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_1.initialize(hostname_mapping={'host': 'host'}, max_clients=25)
    simple_async_h_t_t_p_client_1.close()
    simple_async_h_t_t_p_client_2 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_2.initial

# Generated at 2022-06-26 08:42:15.743421
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0._HTTPConnection()
    #Test case for _HTTPConnection.run
    exp_res = None
    assert exp_res == simple_async_h_t_t_p_client_0._HTTPConnection().run()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:42:19.535743
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()



# Generated at 2022-06-26 08:42:26.648926
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    response_start_line = httputil.ResponseStartLine("HTTP/1.1", 200, "OK")
    headers = httputil.HTTPHeaders({"Location": "/"})

    http_connection = _HTTPConnection()
    http_connection.headers_received(response_start_line, headers)
    http_connection.finish()
    pass


# Generated at 2022-06-26 08:42:29.542526
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-26 08:42:35.094357
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    sockaddr = ("127.0.0.1", 80)
    stream = IOStream()
    with pytest.raises(HTTPError):
        _HTTPConnection(stream, sockaddr)
