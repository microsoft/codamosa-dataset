

# Generated at 2022-06-26 08:42:01.329867
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Assigning a _RequestProxy object to local variable 'request_proxy_0'
    request_proxy_0 = _RequestProxy(
        request = None,
        final_callback = None,
        release_callback = None,
        streaming_callback = None,
        header_callback = None,
    )
    # Assigning a _HTTP1Connection object to local variable '_http1connection_0'
    _http1connection_0 = _HTTP1Connection(
        stream = request_proxy_0,
        tls_parameters = None,
        ssl_options = None,
        max_header_size = 0,
        max_body_size = 0,
    )
    # Calling method on_connection_close of _HTTPConnection instance _http1connection_0
    _http1connection_0.on_connection_close()

#

# Generated at 2022-06-26 08:42:07.055820
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _h_t_t_p_connection_0 = _HTTPConnection(None, None, None, None, None, None)
    _h_t_t_p_connection_0.finish()

assignment_0 = None #type: Optional[SimpleAsyncHTTPClient]


# Generated at 2022-06-26 08:42:15.210854
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    url = '/'
    host = 'localhost'
    port = 8888
    request = HTTPRequest(url,)
    host_header = 'Host'
    headers = {host_header : host,}
    stream = IOStream(socket.socket())
    _HTTPConnection_0 = _HTTPConnection(request, host, port, headers, stream,)
    _HTTPConnection_0.finish()


# Generated at 2022-06-26 08:42:28.028888
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    request = _RequestProxy()
    code = 200
    reason = httputil.HTTPHeaders()
    headers = httputil.HTTPHeaders()
    request_time = 1
    start_time = 1
    buffer = BytesIO()
    effective_url = '/'
    h_t_t_p_response_0 = HTTPResponse(
        request, code, reason=reason, headers=headers,
        request_time=request_time, start_time=start_time,
        buffer=buffer, effective_url=effective_url)
    _HTTPConnection.finish(h_t_t_p_response_0)


# Generated at 2022-06-26 08:42:41.390716
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    import asyncio
    dict_0 = {"max_clients": 5}
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient(**dict_0)
    http_request_0 = HTTPRequest(**dict_0)

# Generated at 2022-06-26 08:42:45.641542
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    message = "message"
    http_stream_closed_error_0 = HTTPStreamClosedError(message)
    http_stream_closed_error_0.__str__()


# Generated at 2022-06-26 08:42:49.895186
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    _HTTPConnection_0 = _HTTPConnection(**None)
    _HTTPConnection_0.data_received(b'\x00\x00\x00\x00', length=4, total_length=4, chunk_start=0, chunk_end=4, offset=0)


# Generated at 2022-06-26 08:42:53.941475
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # Initialize test cases
    dict_0 = {}
    self_0 = _HTTPConnection(dict_0)
    # Execute test case method
    test_case_0()


# Generated at 2022-06-26 08:42:59.034983
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Test for corner case where a web page is not found
    # (returns 404 HTTP error code)
    try:
        response = urllib.request.urlopen('http://127.0.0.1:8888/')
    except urllib.error.HTTPError as e:
        if e.code == 404:
            assert True
            return
    assert False


# Generated at 2022-06-26 08:43:07.894982
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    dict_0 = None
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient(**dict_0)
    _HTTPConnection_0 = _HTTPConnection(simple_async_h_t_t_p_client_0)
    bytes_0 = b''
    _HTTPConnection_0.data_received(bytes_0)


# Generated at 2022-06-26 08:44:17.884651
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    print("Start testing method run of class _HTTPConnection")
    f = Future()
    f.set_result(True)  # simulate an asynchronous response
    s = StreamClosedError(5, 'test_reason')  # simulate a StreamClosedError
    t = HTTPStreamClosedError('test_reason')  # simulate a HTTPStreamClosedError

# Generated at 2022-06-26 08:44:28.512177
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    a_0 = _HTTPConnection()
    test1 = isinstance(a_0, HTTPClientConnection)
    test2 = isinstance(a_0, object)
    test3 = isinstance(a_0, _HTTPConnection)
    test4 = isinstance(a_0, _HTTPConnection)
    test5 = isinstance(a_0, _HTTPConnection)
    assert test1 == True
    assert test2 == True
    assert test3 == True
    assert test4 == True
    assert test5 == True

    b_0 = _HTTPConnection(a_0)
    test1 = isinstance(b_0, HTTPClientConnection)
    test2 = isinstance(b_0, object)
    test3 = isinstance(b_0, _HTTPConnection)
    test4 = isinstance(b_0, _HTTPConnection)


# Generated at 2022-06-26 08:44:30.770028
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Replace 'pass' with your test code.
    pass


# Generated at 2022-06-26 08:44:37.509828
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # set up
    result = None
    str_0 = 'http://127.0.0.1:8888/'
    request = HTTPRequest(url=str_0)
    http_conn = _HTTPConnection(request, io_loop=None)
    # testing
    result = http_conn.data_received(chunk=bytes())
    # tear down
    assert result == None, 'Return value mismatch'


# Generated at 2022-06-26 08:44:49.659186
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient

# Generated at 2022-06-26 08:45:00.064495
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    print("\n------ Test Method SimpleAsyncHTTPClient.fetch_impl")
    client = SimpleAsyncHTTPClient()
    url = "http://127.0.0.1:8888"
    method = "GET"
    headers = None
    body = None
    request = HTTPRequest(url, method, headers, body)
    release_callback = functools.partial(client._release_fetch, None)
    final_callback = functools.partial(client._release_fetch, None)
    client._handle_request(request, release_callback, final_callback)
    print("Test method _handle_request")
test_SimpleAsyncHTTPClient_fetch_impl()

# Generated at 2022-06-26 08:45:02.222988
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    client = SimpleAsyncHTTPClient()
    client.initialize()


# Generated at 2022-06-26 08:45:13.330597
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    __SQLITE_FILE__ = "test.db3"
    con = sqlite3.connect(__SQLITE_FILE__)
    if con is None:
        raise Exception("Can not open database file: " + __SQLITE_FILE__)
    cur = con.cursor()
    res_sql = cur.execute("SELECT * FROM test_case")
    res = res_sql.fetchall()
    for row in res:
        case_id = row[0]
        case_url = row[1]
        case_name = row[2]
        case_desc = row[3]
        case_status = row[4]
        case_ok = row[5]
        if case_status != 1:
            continue
        url = case_url

# Generated at 2022-06-26 08:45:15.146571
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    asyncio.run(test_case_0())

# Generated at 2022-06-26 08:45:25.060160
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    def expected_0_fallback():
        client = SimpleAsyncHTTPClient()

        resolver = OverrideResolver(resolver=client.resolver, mapping=None)

        expected_0_fallback_impl(client=client, resolver=resolver)

        return

    @gen.coroutine
    def expected_0_fallback_impl(client: SimpleAsyncHTTPClient, resolver: OverrideResolver):
        assert isinstance(client, SimpleAsyncHTTPClient)
        assert isinstance(resolver, OverrideResolver)
        test_case_0()

    expected_0_fallback()

    def expected_1_fallback():
        client = SimpleAsyncHTTPClient()

        resolver = OverrideResolver(resolver=client.resolver, mapping={'example.com': '127.0.0.1'})

        expected

# Generated at 2022-06-26 08:46:25.599773
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _HTTPConnection_0 = _HTTPConnection()
    test__HTTPConnection_on_connection_close_0 = _HTTPConnection_0.on_connection_close()
    assert test__HTTPConnection_on_connection_close_0 is None


# Generated at 2022-06-26 08:46:37.861933
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    max_buff_size_0 = 1
    dict_0 = {'0_key': 0}
    dict_1 = {'1_key': 1}
    resolver_0 = Resolver()
    defaults_0 = {'0_key': 0}
    max_header_size_0 = 1
    max_body_size_0 = 1
    int_0 = 1
    obj_0 = SimpleAsyncHTTPClient()
    obj_0.initialize(int_0, dict_0, max_buff_size_0, resolver_0, defaults_0, max_header_size_0, max_body_size_0)


# Generated at 2022-06-26 08:46:50.245939
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    max_clients_0 = 24
    hostname_mapping_0 = {}
    max_buffer_size_0 = 100
    resolver_0 = None
    defaults_0 = {}
    max_header_size_0 = 100
    max_body_size_0 = 100
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    simple_async_http_client_0.initialize(max_clients_0, hostname_mapping_0, max_buffer_size_0, resolver_0, defaults_0, max_header_size_0, max_body_size_0)

if __name__ == '__main__':
    test_case_0()

    # Unit test for method initialize of class SimpleAsyncHTTPClient
    test_SimpleAsyncHTTPClient_initialize()

# Generated at 2022-06-26 08:46:53.062641
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass


# Generated at 2022-06-26 08:47:02.265679
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    '''
    TASK:
    1. Set value for h_t_t_p_connection_0
    2. Pass in h_t_t_p_connection_0 to finish method to get void value
    3. Set boolean value to check if void value is passed in
    4. Set code to void value and return void value
    '''
    # TASK: Set value for h_t_t_p_connection_0
    h_t_t_p_connection_0 = _HTTPConnection(None)
    # TASK: Pass in h_t_t_p_connection_0 to finish method to get void value
    void_value = h_t_t_p_connection_0.finish()
    # TASK: Set boolean value to check if void value is passed in
    bool_0 = void_value

# Generated at 2022-06-26 08:47:09.538022
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    h_t_t_p_timeout_error_0.close()


# Generated at 2022-06-26 08:47:19.129827
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    try:
        inst_0 = _HTTPConnection(str_0, int_0, h_t_t_p_1_client_conn_params_0)
        assert isinstance(inst_0, _HTTPConnection)
        str_0 = '__main__'
        int_0 = 0
        h_t_t_p_1_client_conn_params_0 = HTTP1ConnectionParameters()
        inst_0 = _HTTPConnection(str_0, int_0, h_t_t_p_1_client_conn_params_0)
        assert isinstance(inst_0, _HTTPConnection)
    except Exception:
        exc_type, exc_value, exc_traceback = sys.exc_info()

# Generated at 2022-06-26 08:47:28.335289
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    int_arg_0 = 0
    dict_arg_0 = {}
    int_arg_1 = 0
    dict_arg_1 = {}
    str_arg_0 = '__main__'
    dict_arg_2 = {}
    dict_arg_3 = {}
    # Call the method directly
    async_http_client_0 = SimpleAsyncHTTPClient(
        int_arg_0, dict_arg_0, int_arg_1, dict_arg_1, str_arg_0, dict_arg_2, dict_arg_3
    )
    async_http_client_0.close()



# Generated at 2022-06-26 08:47:41.989251
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    if str_1:
        pass
    else:
        str_1 = 'Fail'

__all__ = [
    "SimpleAsyncHTTPClient",
    "SimpleAsyncHTTPClient",
    "HTTPTimeoutError",
    "HTTPTimeoutError",
]

if version >= "4.0":
    import typing  # noqa
    if typing.TYPE_CHECKING:
        __all__ += [
            "SimpleAsyncHTTPClient",
        ]


HttpResponse = HTTPResponse
Request = HTTPRequest



# Generated at 2022-06-26 08:47:47.925450
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    func_1 = test_case_0
    _HTTPConnection._HTTPConnection.run(func_1)

if __name__ == '__main__':
    print('[+] Running test')
    test_case_0()
    test__HTTPConnection_run()
    print('[+] Done')

# Generated at 2022-06-26 08:49:40.513674
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    pass


# Generated at 2022-06-26 08:49:43.578613
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    print('Testing SimpleAsyncHTTPClient.initialize()')
    async_http_client_0 = SimpleAsyncHTTPClient()
    async_http_client_0.initialize(10)



# Generated at 2022-06-26 08:49:44.935813
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    data_0 = '__main__'
    http_connection_0 = _HTTPConnection(data_0)


# Generated at 2022-06-26 08:49:57.387082
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_2 = '__main__'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_2)
    str_1 = '__main__'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    str_0 = '__main__'
    h_t_t_p_response_0 = HTTPResponse(
        str_0,
        3456,
        error=h_t_t_p_stream_closed_error_0,
        request_time=0.1234567890,
    )
    h_t_t_p_connection_parameters_0 = HTTP1ConnectionParameters()
    str_0 = '__main__'
    h_t_t_p_1_connection_0

# Generated at 2022-06-26 08:50:05.836985
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_1 = '__main__'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    str_0 = h_t_t_p_stream_closed_error_0.__str__()
    # Simplified assert for test_case_1
    assert str_0 == str_1 
    # Simplified assert for test_case_2
    assert str_0 == str_1 



# Generated at 2022-06-26 08:50:10.915588
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    dict_0 = dict()
    h_t_t_p_request_0 = HTTPRequest(dict_0, True)
    callable_0 = test_case_0
    s_a_h_c_0 = SimpleAsyncHTTPClient()
    s_a_h_c_0.fetch_impl(h_t_t_p_request_0, callable_0)


# Generated at 2022-06-26 08:50:17.777402
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    import io
    import sys
    imp.reload(sys)

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        s_a_h_c_0 = SimpleAsyncHTTPClient()
        s_a_h_c_0.close()
        # If the test run successfully, print 'Test Run Successfully' to the
        # standard output stream. If the test failed, print the exception
        # followed by 'Test Failed'
        result = out.getvalue()
        if (len(result) == 0):
            print("Test Run Successfully")
        else:
            sys.stdout = saved_stdout
            raise Exception(result)
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-26 08:50:18.819872
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    return True


# Generated at 2022-06-26 08:50:20.667789
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    addr = ('127.0.0.1', 80 )
    _connection = _HTTPConnection(addr)
    asyncio.get_event_loop().run_until_complete(_connection.start())
    _connection.headers_received()


# Generated at 2022-06-26 08:50:21.386647
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass
