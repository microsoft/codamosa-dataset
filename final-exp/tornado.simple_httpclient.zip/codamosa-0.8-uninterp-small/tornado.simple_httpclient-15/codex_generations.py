

# Generated at 2022-06-26 08:41:42.931007
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _sockaddr = "client.example.com"
    _max_header_size = 4096
    _max_body_size = 134217728
    _io_loop = "client.example.com"
    _request = httpclient_HTTPRequest("http://www.google.com/")
    with unittest.mock.patch("tornado.simple_httpclient._impl"):
        with unittest.mock.patch("tornado.escape"):
            _stream = httpclient_HTTPResponse(
                _request,
                301,
                headers={"Location": "http://www.example.com/"},
                request_time=0.01,
                start_time=0.01,
            )

# Generated at 2022-06-26 08:41:48.856815
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Setup
    _h_t_t_p_connection_0 = _HTTPConnection()
    chunk = b'chunk'
    # Test 1
    _h_t_t_p_connection_0.data_received(chunk)
    return


# Generated at 2022-06-26 08:41:52.853222
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    assert True

# Generated at 2022-06-26 08:42:02.702941
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Setup
    _HTTPConnection_data_received_0 = _HTTPConnection()
    _HTTPConnection_data_received_0.code = None
    _HTTPConnection_data_received_0.final_callback = None
    _HTTPConnection_data_received_0.headers = None
    _HTTPConnection_data_received_0.io_loop = None
    _HTTPConnection_data_received_0.max_header_size = None
    _HTTPConnection_data_received_0.max_body_size = None
    _HTTPConnection_data_received_0.parsed = None
    _HTTPConnection_data_received_0.request = None
    _HTTPConnection_data_received_0.start_time = None
    _HTTPConnection_data_received_0.start_wall_time = None
    _HTTPConnection_data_received_

# Generated at 2022-06-26 08:42:07.229880
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:42:10.088942
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    httpclient._HTTPConnection().on_connection_close()


# Generated at 2022-06-26 08:42:12.898665
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()


# Generated at 2022-06-26 08:42:19.476646
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Declare a SimpleAsyncHTTPClient object
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    # Declare a HTTPRequest object
    h_t_t_p_request_0 = HTTPRequest("http://www.g.cn/")
    # Call method fetch_impl of class SimpleAsyncHTTPClient with arguments simple_async_h_t_t_p_client_0, h_t_t_p_request_0 and simple_async_h_t_t_p_client_0._release_fetch
    simple_async_h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, simple_async_h_t_t_p_client_0._release_fetch)
    

# Generated at 2022-06-26 08:42:23.796644
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()

# Generated at 2022-06-26 08:42:29.863756
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    method_0 = _HTTPConnection()
    method_0.finish()


# Generated at 2022-06-26 08:43:14.917367
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    http_client_0 = HTTPClient(timeout=1)
    assert isinstance(http_client_0, HTTPClient)
    http_client_0.fetch("http://www.a.com/")
    request_0 = HTTPRequest("http://www.b.com/", method="GET")
    http_client_0.fetch(request_0)
    on_error_0 = _on_error
    callback_0 = _callback
    http_client_0.fetch("http://www.b.com/", on_error_0, callback_0)
    http_client_0.fetch("http://www.b.com/", callback_0)
    http_client_0.fetch("http://www.b.com/", raise_error=True)

# Generated at 2022-06-26 08:43:28.181193
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Make an object of class SimpleAsyncHTTPClient
    # Get a mock for class IOLoop
    i_o_loop_1 = mock.Mock(resolver=Resolver())
    # Make an object of class SimpleAsyncHTTPClient
    simple_async_http_client_2 = SimpleAsyncHTTPClient(i_o_loop_1)
    # Call method close of class SimpleAsyncHTTPClient with parameter i_o_loop_1
    simple_async_http_client_2.close()
    simple_async_http_client_2.wait_for_close()
    # Assert that method close of class SimpleAsyncHTTPClient was called with parameter i_o_loop_1
    assert simple_async_http_client_2.close.call_args == mock.call(i_o_loop_1)


# Generated at 2022-06-26 08:43:35.502012
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    max_clients_0 = random.randint(0, 9223372036854775807)
    hostname_mapping_0 = {}
    max_buffer_size_0 = random.randint(0, 9223372036854775807)
    resolver_0 = _http1connection_HTTP1ConnectionParameters()
    defaults_0 = {}
    max_header_size_0 = random.randint(0, 9223372036854775807)
    max_body_size_0 = random.randint(0, 9223372036854775807)
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:43:41.202509
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    str_0 = 'r:ma134\n|#=nG>s"ff'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = '<Ddo|Y+-k5l5\x7fbxE'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    str_2 = 'D9I0!\x0bS=N|?f|GZ'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_2)
    str_3 = '"mY1>\x1a\x0f\x02y-\x7f}'

# Generated at 2022-06-26 08:43:44.223330
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection_0 = _HTTPConnection(None, None, None, None)
    _HTTPConnection_0.start()


# Generated at 2022-06-26 08:43:48.780064
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    stream = IOStream()
    addr = ("localhost", 80)
    http1_connection_0 = _HTTPConnection(stream, addr)


# Generated at 2022-06-26 08:43:50.512624
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    assert True


# Generated at 2022-06-26 08:43:56.538125
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line_0 = httputil.ResponseStartLine('', '', '')
    headers_0 = httputil.HTTPHeaders()
    _httpconnection_0 = _HTTPConnection(first_line_0, headers_0)
    str_0 = 'r:ma134\n|#=nG>s"ff'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    _httpconnection_0.on_timeout(h_t_t_p_timeout_error_0)


# Generated at 2022-06-26 08:44:08.050292
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    con_0 = SimpleAsyncHTTPClient()
    con_1 = SimpleAsyncHTTPClient()
    con_2 = SimpleAsyncHTTPClient()
    con_3 = SimpleAsyncHTTPClient()
    con_4 = SimpleAsyncHTTPClient()
    con_5 = SimpleAsyncHTTPClient()
    con_6 = SimpleAsyncHTTPClient()
    con_7 = SimpleAsyncHTTPClient()
    str_0 = '.'
    ioloop_0 = IOLoop()
    ioloop_1 = IOLoop(str_0)
    ioloop_2 = IOLoop(str_0)
    hostname_mapping_0 = {}
    resolver_0 = Resolver()
    hostname_mapping_1 = {}
    resolver_1 = Resolver()
    hostname_mapping_2 = {}

# Generated at 2022-06-26 08:44:10.119556
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Test to check creation of a HTTPConnection object.
    test_case_0()


# Generated at 2022-06-26 08:45:20.508637
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = '6S#ZlH'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    __http_connection_0 = _HTTPConnection()
    __http_connection_0.on_connection_close()



# Generated at 2022-06-26 08:45:31.158526
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    http_1_connection_0 = HTTP1Connection(
        stream,
        True,
        HTTP1ConnectionParameters(
            no_keep_alive=True,
            max_header_size=max_header_size,
            max_body_size=max_body_size,
            decompress=bool(request.decompress_response),
        ),
        sockaddr,
    )
    # Call method under test
    _HTTPConnection.headers_received(http_1_connection_0, first_line, headers)


# Generated at 2022-06-26 08:45:44.100870
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = '"+?!`0J*E'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    b_y_t_e_s_i_o_1 = BytesIO()
    str_1 = '*'
    str_2 = 'y82N]S'
    str_3 = 'n/p`'
    str_4 = '\x03hb'

# Generated at 2022-06-26 08:45:50.355315
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = 'r:ma134\n|#=nG>s"ff'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    class_0 = _HTTPConnection()
    h_t_t_p_request_0 = HTTPRequest(
        h_t_t_pclientconnection_0.connection, 'https://www.google.com/', method='GET'
    )
    class_0.request = h_t_t_p_request_0
    class_0.io_loop = h_t_t_pclientconnection_0.io_loop
    class_0.max_header_size = h_t_t_pclientconnection_0.max_header_size
    class_0.max_body_size = h_t_t_pclient

# Generated at 2022-06-26 08:45:57.101188
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    """test_SimpleAsyncHTTPClient_fetch_impl"""
    form_data_0 = {}
    h_t_t_p_request_0 = HTTPRequest('http://127.0.0.1:80', 'GET', headers=None, body=form_data_0)
    callback_0 = functools.partial(test_SimpleAsyncHTTPClient_fetch_impl_helper_0, h_t_t_p_request_0)
    async_h_t_t_p_client_0 = SimpleAsyncHTTPClient(io_loop=None, force_instance=False)
    async_h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, callback_0)


# Generated at 2022-06-26 08:46:03.655131
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # SimpleAsyncHTTPClient.__init__(max_clients=10, hostname_mapping=None, max_buffer_size=104857600, resolver=None, defaults=None, max_header_size=None, max_body_size=None)
    # SimpleAsyncHTTPClient.fetch_impl(request=None, callback=None)
    pass


# Generated at 2022-06-26 08:46:09.568707
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Create a SimpleAsyncHTTPClient object
    simple_async_http_client_0: SimpleAsyncHTTPClient = SimpleAsyncHTTPClient()
    # Close the SimpleAsyncHTTPClient object
    simple_async_http_client_0.close()


# Generated at 2022-06-26 08:46:18.517133
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = 'r:ma134\n|#=nG>s"ff'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    i_o_stream_0 = IOStream()
    str_1 = 'r:ma134\n|#=nG>s"ff'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    i_o_stream_0 = IOStream()
    str_2 = 'r:ma134\n|#=nG>s"ff'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_2)
    i_o_stream_0 = IOStream()

# Generated at 2022-06-26 08:46:29.743868
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    a_s_y_n_c_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    a_s_y_n_c_h_t_t_p_client_0.max_clients = 2
    a_s_y_n_c_h_t_t_p_client_0.io_loop = IOLoop()
    a_s_y_n_c_h_t_t_p_client_0.max_buffer_size = 5
    a_s_y_n_c_h_t_t_p_client_0.resolver = Resolver()
    a_s_y_n_c_h_t_t_p_client_0.queue = collections.deque()
    a_s_y_n_c_h_t_t

# Generated at 2022-06-26 08:46:41.380253
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    def test_method_0():
        str_0 = '&M>@{H!n.aQ)b'
        int_0 = 3
        str_1 = 'B*S$z#_7v;8$'
        str_2 = '4uA*6MhhU6\x7f'