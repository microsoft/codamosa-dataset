

# Generated at 2022-06-26 08:41:44.372811
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    global _HTTPConnection_run_counter
    _HTTPConnection_run_counter += 1
    if _HTTPConnection_run_counter == 1:
        _HTTPConnection_run_counter = 0
        return simple_async_h_t_t_p_client_0.SimpleAsyncHTTPClient__HTTPConnection48_49_run(
            simple_async_h_t_t_p_client_0.SimpleAsyncHTTPClient__HTTPConnection48_49,
            simple_async_h_t_t_p_client_0.SimpleAsyncHTTPClient__HTTPConnection48_49,
        )
    if _HTTPConnection_run_counter == 2:
        _HTTPConnection_run_counter = 0

# Generated at 2022-06-26 08:41:48.919829
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_3 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_3.close()


# Generated at 2022-06-26 08:41:53.042416
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_connection_0 = _HTTPConnection(simple_async_h_t_t_p_client_0)
    http_connection_0.finish()


# Generated at 2022-06-26 08:41:57.155698
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    class Test_HTTPConnection(BaseHTTPClientConnection):
        def finish(self) -> None:
            pass
    test_h_t_t_p_connection_0 = Test_HTTPConnection()
    test_h_t_t_p_connection_0.finish()


# Generated at 2022-06-26 08:42:03.709424
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    # IOStream.close is deliberately not patched for unit testing.
    # We rely on close only being used with the _MockIOStream below.
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:42:07.116671
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    SimpleAsyncHTTPClient_fetch_impl_0 = SimpleAsyncHTTPClient()
    request_0 = HTTPRequest()
    callback_0 = lambda: None
    try:
        SimpleAsyncHTTPClient_fetch_impl_0.fetch_impl(request_0, callback_0)
    except Exception:
        pass


# Generated at 2022-06-26 08:42:16.550307
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    message = 'xGst6W'
    http_stream_closed_error_0 = HTTPStreamClosedError(message)
    # Begin with test of method __str__ of class HTTPStreamClosedError
    message = '5K5o5'
    http_stream_closed_error_1 = HTTPStreamClosedError(message)
    str_0 = http_stream_closed_error_1.__str__()
    assert str_0 == message


# Generated at 2022-06-26 08:42:19.198049
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Replace 'pass' for your actual test
    assert True == True



# Generated at 2022-06-26 08:42:24.033932
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

    simple_async_h_t_t_p_client_0.close()



# Generated at 2022-06-26 08:42:31.450875
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    import tornado.httpserver
    import tornado.httputil
    import tornado.iostream
    import tornado.netutil
    import tornado.process
    import tornado.simple_httpclient
    import tornado.tcpserver
    from tornado.httpserver import HTTPServer
    from tornado.iostream import IOStream
    from tornado.netutil import TCPServer
    from tornado.simple_httpclient import _HTTPConnection
    from tornado.tcpserver import TCPServer
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future
    import ssl
    ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)

    COROUTINE = to_asyncio_future()
    ST

# Generated at 2022-06-26 08:43:11.955357
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():

    # HTTPConnection._close_if_requested()
    pass


# Generated at 2022-06-26 08:43:19.583588
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    str_0 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    if (re.match(str_0, h_t_t_p_timeout_error_0.__str__()) != None):
        return "Pass"
    else:
        return "Fail"


# Generated at 2022-06-26 08:43:32.181535
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = '<B@\x06\x0e\x06\x08\x02U'
    int_0 = parse_int(str_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_

# Generated at 2022-06-26 08:43:44.999930
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    max_clients_0 = 67

# Generated at 2022-06-26 08:43:45.814595
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    test_case_0()


# Generated at 2022-06-26 08:43:56.054919
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    max_clients_0 = int(39)
    hostname_mapping_0 = dict()
    max_buffer_size_0 = int(87)
    resolver_0 = Resolver()
    defaults_0 = dict()
    max_header_size_0 = int(94)
    max_body_size_0 = int(22)
    simpleasynchttpclient_0 = SimpleAsyncHTTPClient()
    simpleasynchttpclient_0.initialize(max_clients_0, hostname_mapping_0, max_buffer_size_0, resolver_0, defaults_0, max_header_size_0, max_body_size_0)


# Generated at 2022-06-26 08:43:57.756394
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass


# Generated at 2022-06-26 08:43:58.718472
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    pass


# Generated at 2022-06-26 08:44:08.944927
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_1 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)

    def release_callback():
        return None

    def final_callback(response):
        pass
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    if (simple_async_h_t_t_p_client_0):
        str_2 = 'Gz\t-g`\x0cy;fsf3<|~'
        h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_2)

# Generated at 2022-06-26 08:44:19.488767
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = 'v\x0b|\x18\x15\x7f\x0f\x7f`\x03\x7f\x17\x15\x1b\x0f\x17\x5b\x05\x07\x1f\x19\x5f\x05\x1b+x\x13`'
    http_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = '"\x0f\x15\x7f\x0f\x7f`\x03\x7f\x17\x15\x1b\x0f\x17\x5b\x05\x07\x1f\x19\x5f\x05\x1b+x\x13`'
    http_

# Generated at 2022-06-26 08:45:00.991961
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _HTTPConnection(object(), object(), object(), object(), object())


# Generated at 2022-06-26 08:45:12.463793
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    class_0 = _HTTPConnection
    # Tested method is on_connection_close
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError('_')
    this = class_0()
    this.final_callback = None
    this.stream = h_t_t_p_stream_closed_error_0
    ifaces.transition_to(this.stream, 'closed')
    this._handle_exception(type(h_t_t_p_stream_closed_error_0), h_t_t_p_stream_closed_error_0, None)
    this.stream.error = None
    this.on_connection_close()
    this.on_connection_close()


# Generated at 2022-06-26 08:45:19.011425
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _httpconnection_0 = _HTTPConnection('Q?', 'wUquBZ\x0b$X_?D', '5S~rw\x0bK;\x7f', 62)
    _httpconnection_0.on_connection_close()



# Generated at 2022-06-26 08:45:29.002395
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    resolver_0 = Resolver()
    hostname_mapping_0 = collections.OrderedDict()
    defaults_0 = collections.OrderedDict()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.initialize(hostname_mapping_0, defaults_0, resolver_0)


# Generated at 2022-06-26 08:45:36.017963
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    str_2 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError(str_2)
    h_t_t_p_request_0 = HTTPRequest('http://www.httprequest.com/z0')
    h_t_t_p_response_

# Generated at 2022-06-26 08:45:45.770788
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = 'MD~/<f5\x0c\x1aFeky}'
    h_t_t_p_connection_closed_error_0 = HTTPConnectionClosedError(str_1)
    str_2 = 'jF\x0c\x0a\x1eA5`5\x1a\x1aFeky}'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_2)

# Generated at 2022-06-26 08:45:48.543733
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Test argument type
    with pytest.raises(TypeError):
        _HTTPConnection(None, None, None, None, None)
    with pytest.raises(TypeError):
        _HTTPConnection(None, None, None, None, None, None)


# Generated at 2022-06-26 08:45:51.642961
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = '1r'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)


# Generated at 2022-06-26 08:46:04.814055
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    int_0 = 355
    h_t_t_p_request_0 = HTTPRequest('http://www.example.com', 'GET', None, None, None)
    dict_0 = {}
    dict_0['max_clients'] = int_0
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(None)
    h_t_t_p_response_0 = HTTPResponse(h_t_t_p_request_0, None, None, None)
    def callback_0(callback_0_arg):
        return
    dict_0['max_buffer_size'] = dict_0['max_clients']
    dict_0['max_body_size'] = dict_0['max_clients']

# Generated at 2022-06-26 08:46:08.565025
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    try:
        _http_connection_case_0()
        pass
    except Exception as e:
        print(e)
        pass


# Generated at 2022-06-26 08:47:30.129365
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = httputil.ResponseStartLine('', '', '')
    headers = httputil.HTTPHeaders()
    headers_received('', first_line, headers)


# Generated at 2022-06-26 08:47:40.766753
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = 'Gz\t-g`\x0cy;fsf3<|~'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    assert (h_t_t_p_timeout_error_0 == h_t_t_p_timeout_error_1)


# Generated at 2022-06-26 08:47:51.980437
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    s_a_h_c_0 = SimpleAsyncHTTPClient()
    s_a_h_c_0.close()
    s_a_h_c_0 = SimpleAsyncHTTPClient(
        max_clients=10,
        hostname_mapping=None,
        max_buffer_size=104857600,
        resolver=None,
        defaults=None,
        max_header_size=None,
        max_body_size=None,
    )
    s_a_h_c_0.close()

# Generated at 2022-06-26 08:47:53.872659
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    if __verbose__: print_function(test__HTTPConnection_headers_received)

    _HTTPConnection(None)


# Generated at 2022-06-26 08:48:07.781583
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    s_a_h_c_0 = SimpleAsyncHTTPClient()
    def http_response_0(h_t_t_p_response_0):
        pass

# Generated at 2022-06-26 08:48:20.768531
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    start_line_0 = httputil.ResponseStartLine('', '', '')
    headers_0 = httputil.HTTPHeaders()

# Generated at 2022-06-26 08:48:32.455714
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = '1I,O5\x19\x0f\x19\t\x1c\x1dv'
    http_request_0 = HTTPRequest(str_0)

    def http_response_0(http_response_1: HTTPResponse) -> None:
        str_1 = 'AQ\x1a'
        str_2 = '\x0f6Dd\x1bG\x0c,K\x1b4\x13\x065'
        gen_log.debug(str_1, str_2)

    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    simple_async_http_client_0.fetch_impl(http_request_0, http_response_0)
    simple_async_http_client_

# Generated at 2022-06-26 08:48:38.394085
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    req = HTTPRequest("http://localhost/", method="GET")
    conn = _HTTPConnection(req, 0.1, Future(), Future())
    if req.allow_nonstandard_methods or req.method not in ("GET", "HEAD", "POST", "PUT", "DELETE"):
       raise ValueError("unknown method %s", req.method)


# Generated at 2022-06-26 08:48:49.179035
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    class DummySimpleAsyncHTTPClient(SimpleAsyncHTTPClient):
        def __init__(self):
            super().__init__()
            self.dummy_tcp_client = DummyTCPClient()
            self.dummy_tcp_client.is_closed = False

        def _connection_class(self):
            return _HTTPConnection

        def _handle_request(self, request, release_callback, final_callback):
            return None

        def _release_fetch(self, key):
            return None

        def _remove_timeout(self, key):
            return None

        def _on_timeout(self, key, info=None):
            return None

    dummy_simple_async_http_client = DummySimpleAsyncHTTPClient()
    dummy_simple_async_http_client.tcp_client = dummy_

# Generated at 2022-06-26 08:49:01.740394
# Unit test for method close of class SimpleAsyncHTTPClient