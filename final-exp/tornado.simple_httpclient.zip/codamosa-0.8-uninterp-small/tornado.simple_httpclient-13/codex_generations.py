

# Generated at 2022-06-26 08:41:27.610834
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    raise NotImplementedError


# Generated at 2022-06-26 08:41:31.488307
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    request = HTTPRequest('http://localhost:8000/')
    callback = lambda x: x
    simple_async_h_t_t_p_client_0.fetch_impl(request, callback)



# Generated at 2022-06-26 08:41:33.381218
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass


# Generated at 2022-06-26 08:41:43.894226
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # print("\n===========================================")
    # print("Start running test_HTTPStreamClosedError___str__...")
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_stream_closed_error_0 = simple_async_h_t_t_p_client_0.HTTPStreamClosedError("")
    # print("The result of executing ___str___ on http_stream_closed_error_0 is: " + http_stream_closed_error_0.__str__())
    # print("Finish running test_HTTPStreamClosedError___str__.")
    # print("===========================================")


# Generated at 2022-06-26 08:41:52.233210
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    _HTTPConnection_0 = _HTTPConnection(
        future=None,
        stream=None,
        release_callback=None,
        client=None,
        final_callback=None,
        start_time=0.0,
        _sockaddr=None,
        max_header_size=None,
        max_body_size=None,
        io_loop=None,
    )
    _HTTPConnection_0.run()


# Generated at 2022-06-26 08:42:01.400070
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Initialization
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    request = HTTPRequest()
    callback = lambda : None
    # Unit test
    try:
        simple_async_h_t_t_p_client_0.fetch_impl(request,callback)
    except Exception:
        pass


# Generated at 2022-06-26 08:42:15.920035
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    class async_http_client_en_0:

        def __init__(self, ):
            self.http_version = 'HTTP/1.1'
            self.code = 200
            self.reason = 'OK'
            self.headers = {'Server': 'CERN/3.0 libwww/2.17',
                            'Date': 'Tue, 18 Nov 2008 16:02:25 GMT',
                            'Content-Type': 'text/html'}
            self.effective_url = 'http://tornadoweb.org/'
            self.request_time = 1.24e-06
            self.body = 'I could not agree more.'

        def rewind(self, ):
            pass

# Generated at 2022-06-26 08:42:17.493546
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _http_connection_0 = _HTTPConnection()


# Generated at 2022-06-26 08:42:29.651333
# Unit test for method run of class _HTTPConnection

# Generated at 2022-06-26 08:42:38.888769
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    print("===== test_method_finish =====")
    s = IOStream(socket.socket(), io_loop=IOLoop.current())
    c = _HTTPConnection(s, object(), object(), object(), object())
    try:
        c.finish()
        assert False
    except:
        pass
    c.code = None
    assert c.code == None
    c.headers = object()
    c.chunks = []
    c.finish()


# Generated at 2022-06-26 08:43:24.841888
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = '{t+;a9d!_t$y!\x0b~\x04%c8s'
    httputil_request_start_line_0 = httputil.RequestStartLine(str_0, '/gqsY6aH', 'HTTP/1.0')
    h_t_t_p_headers_0 = httputil.HTTPHeaders({'Content-Type': 'b'})
    str_1 = '{t+;a9d!_t$y!\x0b~\x04%c8s'
    httputil_request_start_line_1 = httputil.RequestStartLine(str_1, '/gqsY6aH', 'HTTP/1.1')
    h_t_t_p_headers_1 = httputil.HTTPHeaders

# Generated at 2022-06-26 08:43:37.962359
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Create a mock for class IOStream
    class IOStreamMock:
        def __init__(self, return_value: bool):
            self.return_value = return_value

        def set_nodelay(self, arg0: bool) -> bool:
            return self.return_value

    # Create a mock for class HTTP1ConnectionParameters
    class HTTP1ConnectionParametersMock:
        def __init__(self, decompress: bool = False):
            self.decompress = decompress

    # Create a mock for class HTTP1Connection
    class HTTP1ConnectionMock:
        def __init__(self, return_value: bool):
            self.return_value = return_value


# Generated at 2022-06-26 08:43:44.385025
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    i_o_loop_0 = IOLoop()
    resolver_0 = Resolver()
    tcp_client_0 = TCPClient(resolver=resolver_0)
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient(max_clients=64, resolver=resolver_0)
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:43:56.537951
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.initialize(10)
    str_0 = 'I\x1d\x14\t\x0f\x06\x06\x07\x00'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()
    i_o_loop_0 = IOLoop()
    tcp_client_0 = TCPClient(resolver=simple_async_h_t_t_p_client_0.resolver)
    simple_async_h_t_t_p_client_0.tcp_

# Generated at 2022-06-26 08:44:08.065936
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = '\'h4.`)#b\x7f%c;|n'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    assert h_t_t_p_timeout_error_0
    str_1 = 'k[pT(u?q\\9@B'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_1)
    assert h_t_t_p_timeout_error_2

# Generated at 2022-06-26 08:44:15.436503
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    simple_async_h_t_t_p_client = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client.initialize(max_clients=10, hostname_mapping=None, max_buffer_size=104857600, resolver=None, defaults=None, max_header_size=None, max_body_size=None)


# Generated at 2022-06-26 08:44:27.906026
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    # Create a HTTPRequest object
    method_0 = 'GET'
    str_0 = 'http://www.google.com'
    h_t_t_p_request_0 = HTTPRequest(url=str_0, method=method_0)
    # Initialize a SimpleAsyncHTTPClient object
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    # Create a HTTPRequest object
    method_1 = 'GET'
    str_1 = 'http://www.google.com'
    h_t_t_p_request_1 = HTTPRequest(url=str_1, method=method_1)
    # Initialize a SimpleAsyncHTTPClient object
    simple_async_h_t_t_p_client_1 = SimpleAsyncHTTPClient()
    # Create a HTTPRequest object

# Generated at 2022-06-26 08:44:39.259157
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = ',bur.:vc3#p!\x0b%`W.}#'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_request_1 = HTTPRequest(str_0)
    def func_0(x_0):
        pass
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_

# Generated at 2022-06-26 08:44:41.765332
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    # Test when final_callback = None
    pass


# Generated at 2022-06-26 08:44:51.685087
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    first_line = httputil.RequestStartLine('GET', '/', 'HTTP/1.1')

# Generated at 2022-06-26 08:46:16.621660
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    test_case_0()


# Generated at 2022-06-26 08:46:21.772938
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    # Constructor with argument "max_clients"
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 08:46:31.382160
# Unit test for method data_received of class _HTTPConnection

# Generated at 2022-06-26 08:46:42.180736
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-26 08:46:51.402150
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    bytes_0 = bytearray(10)
    bytes_0[0] = 114
    bytes_0[1] = 101
    bytes_0[2] = 97
    bytes_0[3] = 115
    bytes_0[4] = 111
    bytes_0[5] = 110
    bytes_0[6] = 61
    bytes_0[7] = 0
    bytes_0[8] = 0
    bytes_0[9] = 0
    h_t_t_p_1_connection_parameters_0 = HTTP1ConnectionParameters(False, 0, 0, True)
    str_0 = 'GET /_utils/ HTTP/1.1'
    t_u_p_l_e_0 = (0, 0, 0)
    h_t_t_p_headers_0 = httput

# Generated at 2022-06-26 08:46:59.344728
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    try:
        simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
        request_0 = HTTPRequest('http://pyflakes.org/')
        simple_async_h_t_t_p_client_0.fetch_impl(request_0, (lambda h_t_t_p_response_0: None))
    except Exception:
        None


# Generated at 2022-06-26 08:47:07.593580
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    data = [(1,1,1),(2,2,2)]
    headers = [(1,2),(3,4)]
    http_connection_0 = _HTTPConnection(data)
    http_connection_0._run_callback(object())


# Generated at 2022-06-26 08:47:18.177867
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    stream_0 = IOStream()
    httpclient_0 = HTTPClient()
    http_request_0 = HTTPRequest('http://www.google.com/search?q=python')
    _HTTPConnection_0 = _HTTPConnection(stream_0, httpclient_0, http_request_0, None, None, 10)
    _HTTPConnection_0.request = http_request_0
    _HTTPConnection_0.request.follow_redirects = True
    _HTTPConnection_0.request.max_redirects = 0
    _HTTPConnection_0.request.max_redirects = 1
    _HTTPConnection_0.request.max_redirects = 2
    _HTTPConnection_0.request.max_redirects = 3

# Generated at 2022-06-26 08:47:27.294373
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    _httputil_response_start_line_0 = httputil.ResponseStartLine(int_0, str_0, str_1)
    http1connection_0 = HTTP1Connection(stream_0, true, http1connectionparameters_0, tuple_0)
    _httpconnection_0 = _HTTPConnection(client_0, http1connection_0, httprequest_0, _httputil_response_start_line_0, test__HTTPConnection_finish.headers_received, test__HTTPConnection_finish, int_0, stream_0, function_0, function_1, function_2)
    _httpconnection_0.finish()


# Generated at 2022-06-26 08:47:41.887477
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = 'p\x12\x13\x0eo\x1d\x0c\x12\t\x1a\x1b\x0f'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()

# Generated at 2022-06-26 08:48:45.277061
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_2 = "@X~?P\x7f_g&h\x7f"
    chunk_0 = chunk_0 + str_2
    h_t_t_p_connection_0._HTTPConnection.data_received(chunk_0)


# Generated at 2022-06-26 08:48:56.988161
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    httpclient_0 = HTTPClient()
    h_t_t_p_request_0 = HTTPRequest(url='http://127.0.0.1:5000/auth/login', method='POST', headers={'Host': '127.0.0.1:5000'}, body=h_t_t_p_client_session_0.request.body, connect_timeout=10, request_timeout=10)
    h_t_t_p_client_session_0 = HTTPClientSession(httpclient_0, h_t_t_p_request_0)
    h_t_t_p_client_session_0.on_connection_close()

# Function that returns the value 'h_t_t_p_client_session_0'

# Generated at 2022-06-26 08:49:06.968691
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    temp_arg_0 = "http://127.0.0.1:8888/"
    http_request_0 = HTTPRequest(temp_arg_0)
    temp_arg_1 = None
    temp_arg_2 = None
    temp_arg_3 = None
    temp_arg_4 = None
    temp_arg_5 = None
    temp_arg_6 = None
    _http_connection_0 = _HTTPConnection(http_request_0, temp_arg_1, temp_arg_2, temp_arg_3, temp_arg_4, temp_arg_5, temp_arg_6)
    temp_arg_0 = None
    _http_connection_0.run(temp_arg_0)
    _result = _http_connection_0.release_callback


# Generated at 2022-06-26 08:49:15.081492
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    io_loop_0 = IOLoop()
    io_loop_0.make_current()
    simple_async_http_client_0 = SimpleAsyncHTTPClient()
    simple_async_http_client_0.initialize()
    simple_async_http_client_0.close()


# Generated at 2022-06-26 08:49:29.553600
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = '\x01\xa3\x0c\xed\xc9\x0e'
    h_t_t_p_request_0 = HTTPRequest(str_0, 'I1:XK\t')
    str_1 = '\x81\xb4\x14\xe2\x1e\xfe\xc9\x89\xdf\x12\xad\x8c\x1a\xaa\xb1\xd5\x9d\x89\xab\x0b'

# Generated at 2022-06-26 08:49:38.076406
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '03\x17sF6U\x02\x1a\x19|X\x0c\x0c!E\x06\x1d\x07\x1c\\'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = h_t_t_p_stream_closed_error_0.__str__()



# Generated at 2022-06-26 08:49:43.659201
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '<\x17\x14X\x01\x1f\x1em'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = h_t_t_p_stream_closed_error_0.__str__()



# Generated at 2022-06-26 08:49:51.080560
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = ' {!r}'
    str_1 = ',bur.:vc3#p!\x0b%`W.}#'
    str_2 = 'Stream closed'
    http_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    str_0 = http_stream_closed_error_0.__str__()
    assert(str_0 == str_2)


# Generated at 2022-06-26 08:49:56.145923
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = ',bur.:vc3#p!\x0b%`W.}#'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    str_1 = h_t_t_p_timeout_error_0.__str__()


# Generated at 2022-06-26 08:50:01.068982
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Prepare
    str_0 = 'J\x1f\\'
    str_1 = 'U'
    str_2 = '3\x1c\x17/'
    h_t_t_p_request_0 = HTTPRequest(str_0, headers=str_1)
    h_t_t_p_request_1 = HTTPRequest(str_0, headers=str_1)
    client_0 = HTTPClient(h_t_t_p_request_0)
    client_1 = HTTPClient(h_t_t_p_request_1)
    h_t_t_p_request_2 = HTTPRequest(str_0, headers=str_1)