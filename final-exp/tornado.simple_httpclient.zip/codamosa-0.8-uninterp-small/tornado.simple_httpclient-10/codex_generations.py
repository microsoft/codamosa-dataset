

# Generated at 2022-06-26 08:41:51.073279
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    class _HTTPConnection_1():
        def data_received(self, data: bytes) -> None:
            pass

    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    _HTTPConnection_1.data_received("a"*150000)


# Generated at 2022-06-26 08:41:54.262569
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _HTTPConnection_0 = _HTTPConnection()
    _HTTPConnection_0.on_connection_close()


# Generated at 2022-06-26 08:42:02.310952
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    print('\nTest for method data_received of class _HTTPConnection')
    try:
        simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
        # Unit test for _HTTPConnection's data_received
        http_connection_0 = _HTTPConnection(simple_async_h_t_t_p_client_0)
        http_connection_0.data_received(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    except:
        pass
    finally:
        simple_async_h_t_t_p_client_0.close()



# Generated at 2022-06-26 08:42:06.142231
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.finish()


# Generated at 2022-06-26 08:42:07.152814
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    pass


# Generated at 2022-06-26 08:42:18.179750
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    connection_0 = _HTTPConnection(None, None, None, None)
    connection_0._HTTPConnection__chunks.append(b'')
    connection_0._HTTPConnection__start_time = time.time()
    connection_0._HTTPConnection__request.request_time = time.time()
    connection_0._HTTPConnection__start_wall_time = time.time()
    connection_0._HTTPConnection__request.ca_certs = 'ca.crt'
    connection_0._HTTPConnection__request.url = 'http://www.google.com'
    connection_0._HTTPConnection__request.proxy_host = 'www.google.com'
    connection_0._HTTPConnection__request.proxy_port = 80
    connection_0._HTTPConnection__request.proxy_username = 'None'
    connection_0._HTTPConnection__request

# Generated at 2022-06-26 08:42:21.837947
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    http_connection_0 = _HTTPConnection(None, 'connection', None, None)
    http_connection_0.on_connection_close()

    # Unit test for method write_headers of class _HTTPConnection
    def test__HTTPConnection_write_headers():
        http_connection_0 = _HTTPConnection(None, 'connection', None, None)
        http_connection_0.write_headers(None, None)


# Generated at 2022-06-26 08:42:25.770477
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    h_t_t_p_timeout_error_0 = HTTPTimeoutError("")
    h_t_t_p_timeout_error_0.__str__()



# Generated at 2022-06-26 08:42:36.511945
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    stream: IOStream  = IOStream()
    sock_addr: Tuple  = ("127.0.0.1", 8888)
    http_1_connection: HTTP1Connection = _HTTPConnection(stream, True, HTTP1ConnectionParameters(no_keep_alive=True, max_header_size=8192, max_body_size=104857600, decompress=True), sock_addr)
    assert http_1_connection.stream == stream
    assert http_1_connection.no_keep_alive == True
    assert http_1_connection.should_close == True
    assert http_1_connection.params.no_keep_alive == True
    assert http_1_connection.params.max_header_size == 8192
    assert http_1_connection.params.max_body_size == 104857600
   

# Generated at 2022-06-26 08:42:38.445241
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    stream: IOStream = IOStream()
    _HTTPConnection(stream, _sockaddr)


# Generated at 2022-06-26 08:43:44.826597
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    f_1 = Future()
    f_1.set_result(None)
    # test with Future of IOLoop instance
    _HTTPConnection.run(f_1)
    # test with Future of _ResponseStartLine instance
    _HTTPConnection.run(f_1, 'body')
    # test with Future of _ResponseStartLine instance and 'transfer_encoding' equal
    # to 'chunked'
    _HTTPConnection.run(f_1, 'body', True)
    # test with Future of _ResponseStartLine instance and 'transfer_encoding' not
    # equal to 'chunked'
    _HTTPConnection.run(f_1, 'body', False)
    # test with Future of _ResponseStartLine instance and 'transfer_encoding'
    # equal to 'chunked'

# Generated at 2022-06-26 08:43:56.609721
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    stream_0 = IOStream()
    h_t_t_p_request_0 = HTTPRequest('url_0', 'POST')
    h_t_t_p_request_1 = HTTPRequest('url_1', 'POST')
    h_t_t_p_request_2 = HTTPRequest('url_2', 'POST')
    h_t_t_p_client_0 = HTTPClient()
    h_t_t_p_client_1 = HTTPClient()
    h_t_t_p_client_2 = HTTPClient()
    h_t_t_p_connection_0 = _HTTPConnection(h_t_t_p_client_0, h_t_t_p_request_0, stream_0)

# Generated at 2022-06-26 08:44:00.655693
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '<>'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_0 = ''
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError(str_0)
    str_0 = 'n'
    h_t_t_p_stream_closed_error_2 = HTTPStreamClosedError(str_0)
    str_0 = 'U6GvY'
    h_t_t_p_stream_closed_error_3 = HTTPStreamClosedError(str_0)
    str_0 = 'G^f?'
    h_t_t_p_stream_closed_error_4 = HTTPStreamClosedError(str_0)

# Generated at 2022-06-26 08:44:05.342213
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = 'hr !'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    h_t_t_p_stream_closed_error_0_str_0 = h_t_t_p_stream_closed_error_0.__str__()


# Generated at 2022-06-26 08:44:10.208740
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = 'U6Z&'
    str_1 = 'g1vW&D'
    assert test_case_0() == None


# Generated at 2022-06-26 08:44:16.139578
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    _HTTPConnection.run(h_t_t_p_timeout_error_0)


if __name__ == "__main__":
    test_case_0()
    test__HTTPConnection_run()

# Generated at 2022-06-26 08:44:18.737241
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    pass


# Generated at 2022-06-26 08:44:24.206627
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    arg = HTTPRequest('https://example.com', 'GET')
    # _HTTPConnection(HTTPRequest('https://example.com', 'GET'), _HTTPConnectionParameters(), None, None, None).run()

if __name__ == '__main__':
    test__HTTPConnection_run()

# Generated at 2022-06-26 08:44:28.753745
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)


# Generated at 2022-06-26 08:44:34.214000
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    # create instance
    str_0 = '|a`=y~)'
    http1connection_0 = _HTTPConnection(str_0)
    # call method
    http1connection_0.finish()


# Generated at 2022-06-26 08:45:32.159205
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '>tz1|QW'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    # Init argument for call
    str_1 = 's4?4x}j'
    test_param_0 = h_t_t_p_stream_closed_error_0.__str__(str_1)
    assert test_param_0 is None, test_param_0


# Generated at 2022-06-26 08:45:39.419280
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    s_a_h_c_0 = SimpleAsyncHTTPClient()
    h_t_t_p_request_0 = HTTPRequest(str_0)
    f_0 = test_case_0
    s_a_h_c_0.fetch_impl(h_t_t_p_request_0, f_0)



# Generated at 2022-06-26 08:45:47.525272
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    sockaddr_0, _h_t_t_p_connection_0, str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8, str_9, str_10, str_11, str_12, str_13, str_14, str_15, str_16, str_17, str_18, str_19, str_20, str_21, str_22, str_23, str_24, str_25, str_26, str_27, str_28, str_29, str_30, str_31, str_32, str_33, str_34, str_35, str_36, str_37, str_38, str_39, str_40, str_41, str_42, str_43, str_44,

# Generated at 2022-06-26 08:45:57.867402
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = 'h?4&"%=4f<'
    str_1 = 'X5U{'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    _HTTPConnection.on_connection_close(h_t_t_p_timeout_error_1)
    _HTTPConnection._handle_exception(None, h_t_t_p_timeout_error_0, None)
    _HTTPConnection.on_connection_close(h_t_t_p_timeout_error_0)
    _HTTPConnection._handle_exception(None, h_t_t_p_timeout_error_1, None)

# Generated at 2022-06-26 08:46:01.333189
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    h_t_t_p_connection_0 = _HTTPConnection()
    h_t_t_p_connection_0.finish()


# Generated at 2022-06-26 08:46:05.211912
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = '$V'
    _66 = 'VNf,T'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_50 = h_t_t_p_stream_closed_error_0.__str__()
    assert str_50 == _66


# Generated at 2022-06-26 08:46:17.332599
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    conn_0 = _HTTPConnection(
        ('', 0), urlparse('http://google.com/'), client_key=None, client_cert=None,
        max_body_size=1024, ssl_options=None
    )
    stream_0 = IOStream(0)
    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    conn_0._handle_exception(HTTPTimeoutError, h_t_t_p_timeout_error_0, None)
    str_1 = 'g1vW&D'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)

# Generated at 2022-06-26 08:46:23.063199
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    # Example to test _HTTPConnection().run
    '''
    request = HTTPRequest(url='https://www.google.com', method='HEAD')
    _HTTPConnection(request, Client()).run()
    '''


# Generated at 2022-06-26 08:46:26.118001
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = 'T'
    _http_connection = _HTTPConnection(str_0,None)
    _http_connection.run()


# Generated at 2022-06-26 08:46:36.375906
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = '0bDd8'
    str_1 = 'w0'
    str_2 = 't'
    str_3 = 'p'
    str_4 = '%'
    io_stream_0 = IOStream(str_0, str_1, str_2, str_3, str_4)
    _http_connection_0 = _HTTPConnection(io_stream_0)
    _http_connection_0.run(True)


# Generated at 2022-06-26 08:47:42.352856
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    int_0 = 9111
    str_0 = 'E7`f*'
    str_1 = 'G)@'
    str_2 = 'Kb1Q'
    bytes_0 = bytes((66, 66, 35, 35, 35))
    _HTTPConnection_0 = _HTTPConnection(io_loop=io_loop_0, sockaddr=bytes_0)
    _HTTPConnection_0.code = int_0
    _HTTPConnection_0.request = HTTPRequest(url=str_0, headers=None, body=str_1)
    _HTTPConnection_0.reason = str_2
    _HTTPConnection_0.chunks = [str_1, str_1]
    _HTTPConnection_0.headers = None
    _HTTPConnection_0.final_callback = None
    _HTTPConnection_0.release_

# Generated at 2022-06-26 08:47:52.890413
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    int_0 = 0
    h_t_t_p_timeout_error_0.code = int_0
    str_1 = 'eqn)p@YX'
    h_t_t_p_timeout_error_0.reason = str_1
    hash_map_0 = {}
    h_t_t_p_response_0 = HTTPResponse(
        h_t_t_p_timeout_error_0,
        int_0,
        reason=str_1,
        headers=hash_map_0)
    #  Creation of _HTTPConnection object
    #  Assignmnet of h_t_t_p_response_

# Generated at 2022-06-26 08:48:01.686279
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)
    # The following statement throw an exception of type 'KeyError'
    h_t_t_p_timeout_error_0.__getitem__(0)


# Generated at 2022-06-26 08:48:03.329298
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    fun_0_0 = SimpleAsyncHTTPClient()
    fun_0_0.close()


# Generated at 2022-06-26 08:48:10.045735
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _h_t_t_p_connection_0 = _HTTPConnection()
    print('Unit test for constructor of class _HTTPConnection')
    print('Type of "_h_t_t_p_connection_0" is %s' % type(_h_t_t_p_connection_0))
    print('Value of "_h_t_t_p_connection_0" is %s' % _h_t_t_p_connection_0)
    assert(type(_h_t_t_p_connection_0) == _HTTPConnection)

if __name__ == '__main__':
    print("Running unit tests for")
    print(os.path.basename(__file__))
    print("")
    test_case_0()
    test__HTTPConnection()

# Generated at 2022-06-26 08:48:21.829448
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = 'g1vW&D'
    http_timeout_error_0 = HTTPTimeoutError(str_0)
    dict_0 = dict()
    dict_0['key'] = 'YU6~8]f"'
    dict_0['num'] = 3
    dict_0['flag'] = True
    dict_0['list'] = [1,1,1,1]

# Generated at 2022-06-26 08:48:23.904887
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    request_0 = HTTPRequest('/', 'GET', {})
    # pass


# Generated at 2022-06-26 08:48:35.434784
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    str_0 = 'he6Uv9Q#F'
    d_i_c_t_defaults_0 = {'connect_timeout': 0.2926506687717799, 'max_redirects': 0, 'request_timeout': 0.011836507013598682, 'proxy_host': '', 'proxy_port': 0, 'proxy_username': '', 'proxy_password': ''}
    h_t_t_p_request_0 = HTTPRequest(str_0, 'DELETE', 'body', {'User-agent': 'Tornado/1.1'}, None, 0, 10, 'proxy_host', 'proxy_username', 'proxy_password', 0, 'proxy_port', d_i_c_t_defaults_0, 'validate_cert')
    simple_async_h

# Generated at 2022-06-26 08:48:36.793393
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _http_connection_0 = _HTTPConnection()


# Generated at 2022-06-26 08:48:48.146373
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    print('Starting _HTTPConnection_data_received...')

    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    str_0 = 'g1vW&D'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_0)

    str_0 = 'g1vW&D'

# Generated at 2022-06-26 08:49:43.323409
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Initialize class SimpleAsyncHTTPClient before testing method fetch_impl
    pass


# Generated at 2022-06-26 08:49:47.376913
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()


# Generated at 2022-06-26 08:49:59.118298
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = '9X,)tL0MZX3qll<.aOb.&'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)
    str_1 = 'r5Q5W'
    h_t_t_p_stream_closed_error_1 = HTTPStreamClosedError(str_1)
    str_2 = '{1rOX'
    h_t_t_p_stream_closed_error_1.real_error = ValueError(str_2)
    str_3 = 'G8@Q%'
    h_t_t_p_stream_closed_error_3 = HTTPStreamClosedError(str_3)
    str_4 = 'D;T!f'
    h_t_t_p_stream

# Generated at 2022-06-26 08:50:11.227394
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'i|`bFg9X'
    h_t_t_p_request_0 = HTTPRequest(str_0)
    h_t_t_p_connection_0 = _HTTPConnection(h_t_t_p_request_0)
    h_t_t_p_connection_0.io_loop = None
    h_t_t_p_connection_0.stream = None
    h_t_t_p_connection_0.code = 479
    h_t_t_p_connection_0.chunks = None
    h_t_t_p_connection_0.reason = None
    h_t_t_p_connection_0.headers = None
    h_t_t_p_connection_0.start_time = 0.89821298225088

# Generated at 2022-06-26 08:50:17.999366
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    print("Starting test of test__HTTPConnection_headers_received")
    data_0 = random.randint(0, 9223372036854775807)
    data_1 = random.randint(0, 9223372036854775807)
    data_2 = random.randint(0, 9223372036854775807)
    response_start_line_0 = httputil.ResponseStartLine(data_0,data_1,data_2)
    i_o_stream_0 = IOStream()
    str_0 = 'g1vW&D'
    httputil_http_headers_0 = httputil.HTTPHeaders(str_0)
    _HTTPConnection_0 = _HTTPConnection(i_o_stream_0)

# Generated at 2022-06-26 08:50:22.302845
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    str_0 = 'a?5'
    h_t_t_p_stream_closed_error_0 = HTTPStreamClosedError(str_0)

    try:
        _str = h_t_t_p_stream_closed_error_0.__str__()
    except Exception as e:
        raise e


# Generated at 2022-06-26 08:50:31.303246
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    bool_0 = bool()
    bool_1 = bool()
    bytes_0 = bytes(8)
    httputil_http_connection_parameters_0 = httputil.HTTPConnectionParameters(
        bool_0, bool_1, bytes_0
    )
    str_0 = str()
    str_1 = str()
    httputil__http_connection = httputil._HTTPConnection(
        httputil_http_connection_parameters_0, str_0, str_1
    )


# Generated at 2022-06-26 08:50:40.482160
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    int_0 = 0
    str_1 = 'localhost'
    int_2 = -1570412050
    str_3 = '5m0d3r'
    str_4 = '0'
    int_5 = 1570412050
    str_6 = 'A'
    str_7 = 'B'
    str_8 = 'C'
    str_9 = 'D'
    str_10 = 'E'
    str_11 = 'F'
    str_12 = 'G'
    str_13 = 'H'
    int_14 = -428
    str_15 = 'I'
    str_16 = 'J'
    str_17 = 'K'
    int_18 = 428
    str_19 = 'L'
    str_20 = 'M'

# Generated at 2022-06-26 08:50:47.349227
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    int_0 = 0
    int_1 = 2
    h_t_t_p_request_0 = HTTPRequest('GET', '/', body='')
    str_0 = 'g1vW&D'
    coro_0 = create_connection(IOStream, None, None, None, None)
    ssl_options_0 = h_t_t_p_request_0.ssl_options
    h_t_t_p_connection_parameters_0 = HTTP1ConnectionParameters(None, None, False)
    h_t_t_p_connection_0 = _HTTPConnection(int_0, int_1, coro_0, ssl_options_0, h_t_t_p_connection_parameters_0)