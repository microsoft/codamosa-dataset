

# Generated at 2022-06-26 08:42:16.487275
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    # Call method fetch_impl of the class SimpleAsyncHTTPClient
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    request_0 = HTTPRequest('http://www.baidu.com')
    callback_0 = lambda : None
    simple_async_h_t_t_p_client_0.fetch_impl(request_0, callback_0)
################################################################################


# Generated at 2022-06-26 08:42:26.606637
# Unit test for method __str__ of class HTTPTimeoutError
def test_HTTPTimeoutError___str__():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_timeout_error_0 = HTTPTimeoutError("")
    # No coverage
    try:
        str_0 = http_timeout_error_0.__str__()
        # No coverage
        # No coverage
    except Exception as e:
        # No coverage
        # No coverage
        # No coverage
        # No coverage
        raise e
        # No coverage
    # No coverage
    # No coverage


# Generated at 2022-06-26 08:42:40.561122
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    global _HTTPConnection_run
    parser = http1connection.HttpParser()
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")
    parser.execute(b"")


# Generated at 2022-06-26 08:42:52.964547
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    # Test 1:
    test_class_attribute_stream_0 = IOStream(socket.socket())
    test_class_attribute_sockname_0 = ''
    test_class_attribute_ssl_options_0 = SSLOption()
    simple_async_h_t_t_p_client_instance = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_instance._HTTPConnection(test_class_attribute_stream_0,
                                                         test_class_attribute_sockname_0,
                                                         test_class_attribute_ssl_options_0)

    # Test 2:
    test_class_attribute_stream_1 = IOStream(socket.socket())
    test_class_attribute_sockname_1 = 'localhost'
    test_class_attribute_ssl_options_1

# Generated at 2022-06-26 08:42:56.108707
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    

# Generated at 2022-06-26 08:43:02.154417
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # nothing to do
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    _HTTPConnection_data_received = _HTTPConnection(
        simple_async_h_t_t_p_client_0,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
    )
    chunk = b"Chunk"
    _HTTPConnection

# Generated at 2022-06-26 08:43:14.602900
# Unit test for method headers_received of class _HTTPConnection

# Generated at 2022-06-26 08:43:19.428907
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Test the HTTPStreamClosedError class constructor and the magic method __str__
    http_stream_closed_error_0 = HTTPStreamClosedError('Error Message')
    assert str(http_stream_closed_error_0) == 'Error Message'



# Generated at 2022-06-26 08:43:25.184197
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    http_connection = simple_async_h_t_t_p_client_0._HTTPConnection(None)
    http_connection.finish()

# Generated at 2022-06-26 08:43:29.650641
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:44:32.932760
# Unit test for constructor of class _HTTPConnection
def test__HTTPConnection():
    _http_connection_1 = _HTTPConnection(None, None, None, None)


# Generated at 2022-06-26 08:44:35.328218
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    class_1 = SimpleAsyncHTTPClient()
    class_1.close()


# Generated at 2022-06-26 08:44:48.838178
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    from tornado import gen
    from tornado.httpclient import AsyncHTTPClient, HTTPRequest

    h_t_t_p_request_0 = HTTPRequest('http://www.google.com/')

    def simple_httpclient_initialize_fetch_callback(http_response_0 : HTTPResponse) -> None:
        str_0 = ''
        assert http_response_0
        assert isinstance(http_response_0, HTTPResponse)

    @gen.coroutine
    def simple_httpclient_initialize_fetch_coroutine_0():
        simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()

# Generated at 2022-06-26 08:45:00.765595
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    str_2 = 'POST'
    str_3 = 'http://127.0.0.1:5000'
    h_t_t_p_request_0 = HTTPRequest(url=str_3, method=str_2)
    float_0 = 0.0
    h_t_t_p_connection_0 = _HTTPConnection(request=h_t_t_p_request_0, start_time=float_0, final_callback=None, release_callback=None)

# Generated at 2022-06-26 08:45:02.292587
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    # Test code here
    pass

# Generated at 2022-06-26 08:45:05.415266
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    test_case = _HTTPConnection(None, None, None, None, None, None, None, None, None)
    test_case.data_received(None)


# Generated at 2022-06-26 08:45:06.196624
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    test_case_0()


# Generated at 2022-06-26 08:45:13.573519
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    h_t_t_p_response_0 = HTTPResponse(
        _request_proxy_0,
        int_0,
        reason=getattr(httpclient_0._HTTPConnection, 'reason', None),
        headers=httpclient_0._HTTPConnection.headers,
        request_time=httpclient_0._HTTPConnection.io_loop.time() - httpclient_0._HTTPConnection.start_time,
        start_time=httpclient_0._HTTPConnection.start_wall_time,
        buffer=bytes_io_0,
        effective_url=httpclient_0._HTTPConnection.request.url,
    )


# Generated at 2022-06-26 08:45:18.200829
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    _HTTPConnection_0 = _HTTPConnection
    request_0 = HTTPRequest()
    callback_0 = functools.partial(test_case_0)


# Generated at 2022-06-26 08:45:23.921098
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    # Setup
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    method_result = None
    first_line = 'fake'
    headers = 'fake'

    # Call method
    try:
        method_result = h_t_t_p_timeout_error_0.headers_received(first_line, headers)
    except Exception as err:
        print(err)


# Generated at 2022-06-26 08:46:28.027587
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    simple_httpclient = SimpleAsyncHTTPClient()
    
    # Call method on_connection_close
    simple_httpclient._HTTPConnection.on_connection_close()


# Generated at 2022-06-26 08:46:29.100921
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    _HTTPConnection._HTTPConnection.headers_received()


# Generated at 2022-06-26 08:46:40.732895
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    """Unit test for method close of class SimpleAsyncHTTPClient"""
    # Test case 0
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    # Test case 1
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_1)
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.close()
    # Test case 2
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_

# Generated at 2022-06-26 08:46:50.933490
# Unit test for method close of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_close():
    max_clients_0 = 0
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    defaults_0 = {
    }
    resolver_0 = Resolver()
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient(max_clients=max_clients_0, max_buffer_size=int_0, max_header_size=int_1, max_body_size=int_2, resolver=resolver_0, defaults=defaults_0)
    http_req_0 = HTTPRequest('GET', 'http://localhost/')
    assert resolver_0 is not None
    assert simple_async_h_t_t_p_client_0 is not None

# Generated at 2022-06-26 08:47:01.347396
# Unit test for method fetch_impl of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_fetch_impl():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    str_2 = 'async'
    h_t_t_p_request_0 = HTTPRequest(str_2)
    class_0 = HTTPResponse
    func_0 = lambda arg_0: None
    simple_async_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    simple_async_h_t_t_p_client_0.fetch_impl(h_t_t_p_request_0, func_0)


# Generated at 2022-06-26 08:47:11.552425
# Unit test for method __str__ of class HTTPStreamClosedError
def test_HTTPStreamClosedError___str__():
    # Initialization of the exception
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    http_stream_closed_error_0 = HTTPStreamClosedError(str_1)
    
    # Call the method __str__
    str_2 = http_stream_closed_error_0.__str__()
    assert str_2 == str_1



# Generated at 2022-06-26 08:47:25.438316
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    s_t_r_2 = "tornado.simple_httpclient"
    class_0 = _HTTPConnection
    method_1 = class_0.on_connection_close
    def method_2(self_0, arg_2) -> None:
        str_2 = 'tornado.simple_httpclient'
        s_t_r_3 = "tornado.simple_httpclient"
        class_1 = _HTTPConnection
        method_3 = class_1.finish
        method_4 = class_1.on_connection_close
        method_5 = class_1.headers_received
        method_6 = class_1.on_connection_close
        method_7 = class_1.on_headers

# Generated at 2022-06-26 08:47:40.181594
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    method_0 = _HTTPConnection()
    fake_client_0 = FakeAsyncHTTPClient()
    h_t_t_p_request_0 = HTTPRequest(url='http://127.0.0.1:80')
    h_t_t_p_request_0.client_cert=(1,2)
    h_t_t_p_request_0.decompress_response=True
    h_t_t_p_request_0.max_buffer_size=34
    h_t_t_p_request_0.proxy_password='myproxy'
    h_t_t_p_request_0.proxy_username='myproxy'
    h_t_t_p_request_0.ssl_options={}

# Generated at 2022-06-26 08:47:45.124937
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = 'GET'
    str_1 = 'tornado.http1connection'
    str_2 = ''
    int_0 = 1
    proxy_host = 'localhost'
    proxy_port = 8080
    str_3 = ''
    len_0 = 2
    str_4 = 'Connection: close\r\n'
    str_5 = 'Proxy-Connection: close\r\n'
    str_6 = 'arg'
    str_7 = 'tornado.httputil'
    str_8 = '\r\n'
    str_9 = ''
    str_10 = 'Host: localhost:8080\r\n'
    str_11 = 'Content-Length: 0\r\n'

# Generated at 2022-06-26 08:47:53.984855
# Unit test for method headers_received of class _HTTPConnection
def test__HTTPConnection_headers_received():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    def test_method_headers_received_0(self, first_line: Union[httputil.ResponseStartLine, httputil.RequestStartLine], headers: httputil.HTTPHeaders) -> None:
        str_0 = ''
        str_1 = 'tornado.simple_httpclient'
        h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
        assert first_line.code == 100
        data_received_0(chunk)
    test_method_headers_received_0(first_line, headers)

# Generated at 2022-06-26 08:50:02.973042
# Unit test for method finish of class _HTTPConnection
def test__HTTPConnection_finish():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    int_0 = 2
    str_2 = 'http://localhost:9001/'
    bool_0 = False
    h_t_t_p_response_1 = HTTPResponse('http://localhost:9001/', int_0, str_0, 0.0, start_time=0.0)
    h_t_t_p_request_0 = HTTPRequest(str_2, connect_timeout=0.0, request_timeout=0.0)
    h_t_t_p_request_0.follow_redirects = False
    h_t_t_p_request_0.max_redirects = int_0
    h_t_t_p_request_0.proxy_host = str_

# Generated at 2022-06-26 08:50:09.677519
# Unit test for method on_connection_close of class _HTTPConnection
def test__HTTPConnection_on_connection_close():
    _HTTPConnection_on_connection_close_var = _HTTPConnection(
        _HTTPConnectionParameters(
            no_keep_alive=True,
            max_header_size=8192,
            decompress=False,
            max_body_size=1048576,
        ),
        None,
    )
    _HTTPConnection_on_connection_close_var.on_connection_close()


# Generated at 2022-06-26 08:50:17.039543
# Unit test for method run of class _HTTPConnection
def test__HTTPConnection_run():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    str_2 = ''
    str_3 = 'tornado.simple_httpclient'
    str_4 = ''
    str_5 = 'tornado.simple_httpclient'
    str_6 = ''
    str_7 = 'tornado.simple_httpclient'
    str_8 = ''
    str_9 = 'tornado.simple_httpclient'
    str_10 = ''
    str_11 = 'tornado.simple_httpclient'
    str_12 = ''
    str_13 = 'tornado.simple_httpclient'
    str_14 = ''
    str_15 = 'tornado.simple_httpclient'
    str_16 = ''
    str_17 = 'tornado.simple_httpclient'
   

# Generated at 2022-06-26 08:50:21.375229
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    print(h_t_t_p_timeout_error_0.__cause__)

# Generated at 2022-06-26 08:50:34.512297
# Unit test for method data_received of class _HTTPConnection
def test__HTTPConnection_data_received():
    str_0 = ''
    str_1 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_0 = HTTPTimeoutError(str_1)
    str_2 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_1 = HTTPTimeoutError(str_2)
    str_3 = ''
    str_4 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_2 = HTTPTimeoutError(str_4)
    str_5 = ''
    str_6 = 'tornado.simple_httpclient'
    h_t_t_p_timeout_error_3 = HTTPTimeoutError(str_6)
    str_7 = 'tornado.simple_httpclient'
    h_t_t_

# Generated at 2022-06-26 08:50:41.554472
# Unit test for method initialize of class SimpleAsyncHTTPClient
def test_SimpleAsyncHTTPClient_initialize():
    asy_h_t_t_p_client_0 = SimpleAsyncHTTPClient()
    int_1 = 5
    int_2 = 5
    int_3 = 5
    # test_resolver = Resolver()
    int_4 = 5
    int_5 = 5
    asy_h_t_t_p_client_0.initialize(max_clients=int_1, max_buffer_size=int_2, max_header_size=int_3, max_body_size=int_4)
    asy_h_t_t_p_client_0.max_clients = int_5
    int_0 = asy_h_t_t_p_client_0.max_clients
    bool_0 = int_0 == int_1
