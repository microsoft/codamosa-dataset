

# Generated at 2022-06-20 18:40:58.208719
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-20 18:41:00.704529
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    package_manager = CLIMgr()
    assert package_manager.is_available() is False
    assert package_manager._cli is None

# Generated at 2022-06-20 18:41:03.069494
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert hasattr(PkgMgr, 'list_installed')
    assert callable(PkgMgr.list_installed)


# Generated at 2022-06-20 18:41:07.285780
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pmgr = PkgMgr()
    assert hasattr(pmgr, 'list_installed')
    assert callable(pmgr.list_installed)


# Generated at 2022-06-20 18:41:11.883626
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'

    tlm = TestLibMgr()
    assert tlm.is_available() == True

    import sys
    sys.modules['os'] = None
    assert tlm.is_available() == False

# Generated at 2022-06-20 18:41:17.755958
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class DummyPkgMgr(PkgMgr):

        def get_package_details(self, package):
            return {}

    PkgMgr = DummyPkgMgr()
    result = PkgMgr.get_package_details("")
    if not isinstance(result, dict):
        raise AssertionError("get_package_details should return a dictionary")


# Generated at 2022-06-20 18:41:20.753571
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_CLIMgr = CLIMgr()
    assert test_CLIMgr is not None


# Generated at 2022-06-20 18:41:23.357611
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    result = obj.is_available()
    assert result is None, "Test has failed"


# Generated at 2022-06-20 18:41:24.111468
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr() is not None

# Generated at 2022-06-20 18:41:28.737345
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create a basic class to test against
    class Test_LibMgr(LibMgr):
        LIB = 'foo'

    # Make sure we have the basic class
    assert issubclass(Test_LibMgr, LibMgr), "class definition is not a subclass of LibMgr"

    # Make sure that is_available returns expected results
    assert Test_LibMgr().is_available() is False, "is_available does not return expected result"



# Generated at 2022-06-20 18:41:33.322455
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-20 18:41:43.697359
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.package.osquery_packages import OSQueryPackage
    from ansible.module_utils.package.osquery import OSQuery
    module = AnsibleModule(argument_spec={})
    list_pms = ['osquery']

    pm = PkgMgr()
    osquery = OSQuery()
    osquery_package = OSQueryPackage()
    test_pms = [pm, osquery, osquery_package]
    
    for pm in test_pms:
        if pm.__class__.__name__.lower() in list_pms:
            pm.is_available()
        else:
            continue

    module.exit_json(changed=False)

# Generated at 2022-06-20 18:41:50.101841
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class mock_class(PkgMgr):
        def __init__(self):
            pass

        @abstractmethod
        def is_available(self):
            pass

        @abstractmethod
        def list_installed(self):
            pass

        @abstractmethod
        def get_package_details(self):
            pass

    assert mock_class().get_packages() == {}

# Generated at 2022-06-20 18:41:51.502958
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class TestPkgMgr:
        pass
    test = PkgMgr()

# Generated at 2022-06-20 18:41:54.783716
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.pkg_mgr import dpkg
    test_obj = dpkg.DPKGMgr()
    assert test_obj.is_available() == True, "Did not find dpkg"


# Generated at 2022-06-20 18:41:59.268328
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class PkgMgrTest(CLIMgr):
        CLI = 'invalid_cli'

    pkg_mgr = PkgMgrTest()

    assert pkg_mgr.is_available() == False


# Generated at 2022-06-20 18:42:03.791451
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        cm = CLIMgr()
        cm.CLI = 'ls'
        assert cm.is_available() == True
        cm.CLI = 'dosomething'
        assert cm.is_available() == False
    except:
        assert False

# Generated at 2022-06-20 18:42:06.055419
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli_mgr = CLIMgr()
    cli_mgr.CLI = 'pip'
    assert cli_mgr.is_available()


# Generated at 2022-06-20 18:42:08.631005
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert obj.is_available() == False


# Generated at 2022-06-20 18:42:11.220937
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Test(LibMgr):
        LIB = "test"
    p = Test()
    assert p.LIB == "test"

# Generated at 2022-06-20 18:42:17.386108
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details is PkgMgr.get_package_details, "Abstract method not overriden by derived class"


# Generated at 2022-06-20 18:42:23.682810
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr import get_all_pkg_managers
    from mock import patch
    from tempfile import NamedTemporaryFile, TemporaryDirectory
    import os

    with TemporaryDirectory(prefix='ansible_pkg_mgr_unit_test_') as tmp_dir:
        test_cli = "test_cli"
        test_cli_path = os.path.join(tmp_dir, test_cli)
        with open(test_cli_path, 'w') as f:
            f.write('#!/bin/sh\necho "test_cli"\n')
        os.chmod(test_cli_path, 0o777)


# Generated at 2022-06-20 18:42:25.252263
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr


# Generated at 2022-06-20 18:42:25.912453
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-20 18:42:27.549348
# Unit test for constructor of class LibMgr
def test_LibMgr():
    t = LibMgr()
    assert t


# Generated at 2022-06-20 18:42:29.893166
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available is PkgMgr.is_available


# Generated at 2022-06-20 18:42:38.533802
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.virtual.pip import Pip
    from ansible.module_utils.facts.virtual.composer import Composer
    from ansible.module_utils.facts.virtual.gems import Gems
    from ansible.module_utils.facts.virtual.npm import Npm
    from ansible.module_utils.facts.virtual.pecl import Pecl
    from ansible.module_utils.facts.virtual.pipenv import Pipenv
    from ansible.module_utils.facts.virtual.poetry import Poetry
    from ansible.module_utils.facts.virtual.bundler import Bundler


# Generated at 2022-06-20 18:42:40.035298
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    my_pkg_mgr = PkgMgr()
    out = my_pkg_mgr.get_packages()
    assert out == {}, 'get_packages failed with the given input'
    print('Test 1 Passed: get_packages !')


# Generated at 2022-06-20 18:42:45.108112
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'echo'

    pkg_mgr = TestCLIMgr()
    # check with any binary
    assert pkg_mgr.is_available()
    # check with invalid path
    pkg_mgr.CLI = "/bin/invalid_path"
    assert not pkg_mgr.is_available()

# Generated at 2022-06-20 18:42:53.501016
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from . import yum, apt, fw
    print('\nTest is_availabe of class LibMgr.')
    yum_list = ['yum']
    apt_list = ['apt']
    unavail_list = ['unavailable', 'Unavailable']
    assert all(yum.is_available() for yum in yum_list)
    assert all(apt.is_available() for apt in apt_list)
    assert all(not fw.is_available() for fw in unavail_list)



# Generated at 2022-06-20 18:43:02.841247
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    mgr.CLI = 'ansible'
    assert mgr.is_available()

# Generated at 2022-06-20 18:43:09.078536
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class DummyPkgMgr(PkgMgr):
        def __init__(self):
            super(DummyPkgMgr, self).__init__()

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    dummy_pkg_mgr = DummyPkgMgr()

    # get_package_details() doesn't support keyword arguments
    with pytest.raises(TypeError):
        dummy_pkg_mgr.get_package_details(name='foo')


# Generated at 2022-06-20 18:43:18.962917
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible_collections.ansible.community.plugins.module_utils.facts.packaging.pkg_mgr import get_all_pkg_managers
    test_class = get_all_pkg_managers()['yumpkg']
    test_package = 'sgdisk'
    assert test_class().get_package_details(test_package) == {
        'name': 'sgdisk',
        'source': 'yumpkg',
        'version': {'full': '1.1.0-1.fc26', 'major': '1', 'minor': '1', 'build': '0', 'revision': '1', 'flags': 'fc26'}
    }
    test_class = get_all_pkg_managers()['dpkgpkg']
    test_package = 'dpkg'
    assert test

# Generated at 2022-06-20 18:43:22.921932
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MyCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    assert MyCLIMgr().is_available() == False

# Unit tests for class LibMgr

# Generated at 2022-06-20 18:43:24.239769
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert hasattr(lm, 'is_available')

# Generated at 2022-06-20 18:43:25.184185
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()


# Generated at 2022-06-20 18:43:26.535115
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-20 18:43:31.607412
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_managers = get_all_pkg_managers()
    assert 'dnf' in all_managers
    assert 'apt' in all_managers
    assert 'yum' in all_managers
    assert 'zypper' in all_managers
    assert 'apt' in all_managers.keys()
    assert 'yum' in all_managers.keys()


# Unit test to show that get_all_pkg_managers returns instances of the relevant class

# Generated at 2022-06-20 18:43:39.472303
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            pass
        def is_available(self):
            return True
        def list_installed(self):
            pass
        def get_package_details(self):
            pass
    pkgmgr = TestPkgMgr()
    assert pkgmgr.is_available() == True


# Generated at 2022-06-20 18:43:40.513977
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-20 18:43:55.966966
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert(p.__class__.__name__ == 'PkgMgr')

# Generated at 2022-06-20 18:43:56.712634
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() is False


# Generated at 2022-06-20 18:43:57.779350
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class mock_LibMgr(LibMgr):
        LIB = 'fakelib'
    packages = mock_LibMgr()
    assert packages.LIB == 'fakelib'


# Generated at 2022-06-20 18:44:00.375497
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test for empty string
    package = ""
    pkg_mgr = PkgMgr()
    pkg_mgr.get_package_details(package)


# Generated at 2022-06-20 18:44:06.623526
# Unit test for method get_packages of class PkgMgr

# Generated at 2022-06-20 18:44:13.920870
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import unittest
    import mock
    class TestLibMgr(LibMgr):
        def __init__(self,lib):
            self.LIB = lib
            super(TestLibMgr, self).__init__()
    class Test(unittest.TestCase):
        def test_LibMgr_is_available(self):
            tlm = TestLibMgr('test_module')
            self.assertFalse(tlm.is_available())
            tlm = TestLibMgr('mock')
            self.assertTrue(tlm.is_available())
    unittest.main()


# Generated at 2022-06-20 18:44:16.371453
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class LibPkgMgr(LibMgr):
        LIB = 'yum'

    assert LibPkgMgr.__bases__ == (LibMgr,)


# Generated at 2022-06-20 18:44:17.226838
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # TODO
    pass


# Generated at 2022-06-20 18:44:27.386073
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # This is a very strange way to test this function, but it works!
    pkg_mgr = get_all_pkg_managers()
    assert pkg_mgr['yumpkg'].__name__.lower() == 'yumpkg'
    assert pkg_mgr['dnfpkg'].__name__.lower() == 'dnfpkg'
    assert pkg_mgr['zyppkg'].__name__.lower() == 'zyppkg'
    assert pkg_mgr['aptpkg'].__name__.lower() == 'aptpkg'
    assert pkg_mgr['apkpkg'].__name__.lower() == 'apkpkg'
    assert pkg_mgr['pacmanpkg'].__name__.lower() == 'pacmanpkg'

# Generated at 2022-06-20 18:44:29.451406
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    dummy_CLMgr = CLIMgr()
    assert dummy_CLMgr._cli == None


# Generated at 2022-06-20 18:44:57.706884
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pi = PkgMgr
    assert pi.is_available is True

# Generated at 2022-06-20 18:45:00.582112
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'imports'

    test_lib_mgr = TestLibMgr()
    assert test_lib_mgr.is_available() == True


# Generated at 2022-06-20 18:45:08.247562
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MyPkgMgr(PkgMgr):
        def list_installed(self):
            return ['a', 'b', 'c']

        def get_package_details(self, package):
            return {'name': package,
                    'source': self.__class__.__name__.lower()}

    pkg_mgr = MyPkgMgr()
    pkg_mgr.is_available()
    pkgs = pkg_mgr.get_packages()
    assert pkgs['a'][0]['name'] == 'a'
    assert pkgs['b'][0]['name'] == 'b'
    assert pkgs['c'][0]['name'] == 'c'

# Generated at 2022-06-20 18:45:09.206349
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm is not None


# Generated at 2022-06-20 18:45:12.239050
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()
    assert isinstance(pkg_mgrs, dict)
    assert len(pkg_mgrs) > 1

# Generated at 2022-06-20 18:45:18.760753
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert 'portage' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'apt' in pkg_managers
    assert 'apt_rpm' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'ebuild' in pkg_managers

# Generated at 2022-06-20 18:45:28.117240
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def __init__(self):
            super(PkgMgrTest, self).__init__()
        def is_available(self):
            return True
        def list_installed(self):
            return ["testpackage"]
        def get_package_details(self, package):
            return {"name": "testpackage", "version": "1.1.1", "source": "test"}
    pkgmgr = PkgMgrTest()
    assert pkgmgr.get_package_details("testpackage") == {"name": "testpackage", "version": "1.1.1", "source": "test"}


# Generated at 2022-06-20 18:45:33.956381
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common.process import get_bin_path
    all_pkg_managers = get_all_pkg_managers()
    for key in all_pkg_managers:
        if all_pkg_managers[key].CLI is not None:
            get_bin_path(all_pkg_managers[key].CLI)
        elif all_pkg_managers[key].LIB is not None:
            __import__(all_pkg_managers[key].LIB)

# Generated at 2022-06-20 18:45:44.150035
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.types import MappingWithListValues
    import pytest

    pkg = PkgMgr()

    # list_installed should be an abstract method
    with pytest.raises(TypeError):
        pkg.list_installed()

    # get_package_details should be an abstract method
    with pytest.raises(TypeError):
        pkg.get_package_details("package_name")

    # get_packages should return an instance of type MappingWithListValues
    result = pkg.get_packages()
    assert type(result) is MappingWithListValues

    # get_packages should return a dictionary with a key as string, and a list of dictionaries as value

# Generated at 2022-06-20 18:45:49.336102
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()
    # Check that there are package managers returned
    assert pkg_mgrs
    # Check that each returned package manager is an instance of the PkgMgr class.
    for pkg_mgr in pkg_mgrs:
        assert isinstance(pkg_mgrs[pkg_mgr](), PkgMgr)

# Generated at 2022-06-20 18:46:47.301158
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert isinstance(p, PkgMgr)



# Generated at 2022-06-20 18:46:47.944325
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-20 18:46:51.127115
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    try:
        pm.get_package_details()
    except Exception as e:
        assert str(e) == "Can't instantiate abstract class PkgMgr with abstract methods get_package_details"



# Generated at 2022-06-20 18:46:55.438425
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mgr = PkgMgr()
    assert 'get_packages' in dir(pkg_mgr)
    pkg_mgr.get_packages()
    assert isinstance(pkg_mgr.get_packages(), dict)
    assert 'list_installed' not in dir(pkg_mgr)


# Generated at 2022-06-20 18:46:58.747414
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr1 = PkgMgr()
    assert isinstance(pkg_mgr1, PkgMgr)


# Generated at 2022-06-20 18:46:59.668530
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None


# Generated at 2022-06-20 18:47:02.322093
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.common.process import get_bin_path
    sub = CLIMgr()
    value = sub.CLI = 'test'
    try:
        sub.is_available()
    except ValueError:
        sub.CLI = None
        assert value is 'test'



# Generated at 2022-06-20 18:47:03.656727
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Lib(LibMgr):
        LIB = "lib"
    l = Lib()
    assert l._lib is None


# Generated at 2022-06-20 18:47:05.004240
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    assert isinstance(mgr, object)



# Generated at 2022-06-20 18:47:07.966709
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    test_pkg_mgr = PkgMgr()
    assert(test_pkg_mgr.list_installed() == None)
    assert(test_pkg_mgr.get_package_details('test_pkg') == None)
    assert(test_pkg_mgr.get_packages() == {})


# Generated at 2022-06-20 18:49:41.274220
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.facts.collector.pkg_managers.pip import PipMgr

    p = PipMgr()
    assert p._lib == None
    assert p.is_available()
    assert p._lib != None


# Generated at 2022-06-20 18:49:44.895257
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Create a dummy class and test it returns the correct value
    class CLIMgr_test(CLIMgr):
        CLI = "bin"

    assert CLIMgr_test().is_available() == True

# Generated at 2022-06-20 18:49:47.794783
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    for manager in get_all_pkg_managers():
        pm = get_all_pkg_managers()[manager]()
        pm.is_available()
        pm.list_installed()



# Generated at 2022-06-20 18:49:48.625666
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert issubclass(PkgMgr, object)

# Generated at 2022-06-20 18:49:52.803793
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    Unit test for method is_available of class CLIMgr
    """
    from ansible.module_utils.common.process import get_bin_path
    cli = 'apt-get'
    cli_mgr = CLIMgr()
    cli_mgr.CLI = cli
    assert cli_mgr.is_available()



# Generated at 2022-06-20 18:49:54.619517
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Unit test for method is_available of class PkgMgr
    pkg = PkgMgr()
    print((pkg.is_available()))


# Generated at 2022-06-20 18:49:56.543838
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)
    assert len(get_all_pkg_managers()) > 0
    assert get_all_pkg_managers()['redhat']

# Generated at 2022-06-20 18:50:05.281003
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # FIXME: update CLI part, because having CLI in Ansible's module_utils is not right (unittest is not passing)
    '''
    import test.unit.module_utils.software_rng as software_rng
    pkg_mgr = CLIMgr()
    pkg_mgr.CLI = 'ansible'
    assert(pkg_mgr.is_available() is True)
    '''
    pkg_mgr = CLIMgr()
    pkg_mgr.CLI = 'ansible'
    assert(pkg_mgr.is_available() is True)


# Generated at 2022-06-20 18:50:10.908810
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.facts import gather_subset
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    
    result = gather_subset(['all', 'pkg_mgr'])
    pkg_mgr = CLIMgr()
    assert pkg_mgr.is_available() == True
    pkg_mgr.CLI = 'xxxx'
    assert pkg_mgr.is_available() == False

# Generated at 2022-06-20 18:50:13.752851
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {}

    dpm = DummyPkgMgr()
    assert dpm.is_available() == True