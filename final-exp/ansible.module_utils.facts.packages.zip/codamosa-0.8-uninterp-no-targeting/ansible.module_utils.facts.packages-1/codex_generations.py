

# Generated at 2022-06-20 18:40:49.564290
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Test Case1: PkgMgr()
    assert PkgMgr().list_installed() == None


# Generated at 2022-06-20 18:40:59.099230
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class FakePkgMgr(PkgMgr):
        def list_installed(self):
            return ['fake-package-1.0.0', 'fake-package-2.0.0']

        def get_package_details(self, package):
            package_details = {}
            package_details['name'] = 'fake-package'
            package_details['version'] = '0.0.0'
            return package_details

    pkgmgr = FakePkgMgr()
    output = pkgmgr.list_installed()
    assert output == ['fake-package-1.0.0', 'fake-package-2.0.0']


# Generated at 2022-06-20 18:41:00.339919
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()

# Generated at 2022-06-20 18:41:01.796906
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-20 18:41:10.029689
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    data = get_all_pkg_managers()
    assert isinstance(data, dict)
    assert "yumpkgmgr" in data
    assert "dnfpkgmgr" in data
    assert "debpkgmgr" in data
    assert "dnfpkgmgr" in data
    assert "apkpkgmgr" in data
    assert "portspkgmgr" in data
    assert "finkpkgmgr" in data
    assert "portagepkgmgr" in data
    assert "npkgmgr" in data
    for i in data:
        assert isinstance(data[i], type)



# Generated at 2022-06-20 18:41:20.585988
# Unit test for constructor of class LibMgr
def test_LibMgr():

# Test that it actually exists
    lm = LibMgr()
    assert lm

# Test that it contains attribute LIB
    print(lm.LIB)

# Test that is_available is implemented
# And returns False for not implemented
    available = lm.is_available()
    assert available == False

# Test that is_available is implemented
# And returns _lib.__name__ for not implemented
    available = lm.is_available()
    assert available == lm._lib.__name__

# Test that list_installed is implemented
# And returns False for not implemented
    installed = lm.list_installed()
    assert installed == False

# Test that get_package_details is implemented
# And returns False for not implemented
    package_details = lm.get_package_details()
    assert package_details == False

# Generated at 2022-06-20 18:41:26.706621
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class DummyPkgMgr(PkgMgr):

        _packages = [
            # format: {'name': 'name', 'version': 'version', 'source': 'utils/pkg_mgr.py'}
            # ...
        ]

        def is_available(self):
            return True

        def list_installed(self):
            return self._packages

        def get_package_details(self, package):
            return package

    dummy = DummyPkgMgr()
    assert dummy.get_packages()

# Generated at 2022-06-20 18:41:28.796998
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert hasattr(CLIMgr, '__init__')
    assert callable(getattr(CLIMgr, '__init__'))
    assert isinstance(CLIMgr.__init__, object)


# Generated at 2022-06-20 18:41:30.445747
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkgmgr_instance = CLIMgr()
    assert(pkgmgr_instance is not None)

# Generated at 2022-06-20 18:41:31.007705
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass

# Generated at 2022-06-20 18:41:37.333218
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj.is_available() == False


# Generated at 2022-06-20 18:41:37.927660
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pass

# Generated at 2022-06-20 18:41:39.111544
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass


# Generated at 2022-06-20 18:41:40.162057
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr

# Generated at 2022-06-20 18:41:53.465282
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class ExamplePkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            if package == 'test':
                return {'name': 'test', 'version': '1.1.0'}
            else:
                return None

    test_pkg_mgr = ExamplePkgMgr()
    assert test_pkg_mgr.is_available() is True
    assert test_pkg_mgr.list_installed() == []
    assert test_pkg_mgr.get_package_details('test') == {'version': '1.1.0', 'name': 'test', 'source': 'examplepkgmgr'}
    assert test_pkg_mgr.get_packages() == {}


# Generated at 2022-06-20 18:41:56.070041
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestC(CLIMgr):
        CLI = 'test_CLI'
    p = TestC()
    assert p.is_available() == False


# Generated at 2022-06-20 18:41:57.248648
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pass

# Generated at 2022-06-20 18:41:58.718752
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
  raise NotImplementedError()


# Generated at 2022-06-20 18:42:00.435728
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert not obj.is_available()



# Generated at 2022-06-20 18:42:08.075119
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common._utils import get_all_subclasses
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    import os

    for obj in get_all_subclasses(CLIMgr):
        if obj not in (CLIMgr,):
            pkg_mgr = obj()
            try:
                cli = get_bin_path(pkg_mgr.CLI)
            except ValueError:
                cli = False
            assert pkg_mgr.is_available() == cli

# Generated at 2022-06-20 18:42:21.575121
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from . import homebrew
    from . import pkg
    from . import rpm
    from . import apt

    from ansible.module_utils.common._collections_compat import MutableMapping

    for pkg_mgr in [pkg.PkgMgr(), homebrew.Homebrew(), rpm.RPM(), apt.Apt()]:
        for k, v in pkg_mgr.get_packages().items():
            assert isinstance(k, str)
            assert isinstance(v, list)
            for i in v:
                assert isinstance(i, MutableMapping)

# Generated at 2022-06-20 18:42:22.490027
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-20 18:42:26.799925
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    sys.modules['pkg_resources'] = None
    pm = LibMgr()
    assert not pm.is_available()

    sys.modules['pkg_resources'] = object
    pm = LibMgr()
    assert pm.is_available()



# Generated at 2022-06-20 18:42:28.593993
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr() is not None



# Generated at 2022-06-20 18:42:37.893284
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-20 18:42:48.655362
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_managers = get_all_pkg_managers()
    assert('apk' in pkg_managers)
    assert('apt' in pkg_managers)
    assert('dnf' in pkg_managers)
    assert('zypper' in pkg_managers)
    assert('pacman' in pkg_managers)
    assert('yum' in pkg_managers)
    assert('portage' in pkg_managers)
    assert('win32_mgr' in pkg_managers)
    assert('pip' in pkg_managers)
    assert('pip' in pkg_managers)
    assert('gem' in pkg_managers)
    assert('rpm' in pkg_managers)
    assert('npm' in pkg_managers)

# Generated at 2022-06-20 18:42:58.985848
# Unit test for constructor of class PkgMgr

# Generated at 2022-06-20 18:43:00.051182
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-20 18:43:01.057274
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-20 18:43:07.056346
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class DerivedPkgMgr(PkgMgr):
        def list_installed(self):
            # This method should return a list of installed packages, each list item will be passed to get_package_details
            pass
    import pytest
    with pytest.raises(TypeError) as excinfo:
        assert DerivedPkgMgr()
    assert "Can't instantiate abstract class DerivedPkgMgr with abstract methods is_available" in str(excinfo.value)


# Generated at 2022-06-20 18:43:23.706256
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert not cli._cli

# Generated at 2022-06-20 18:43:32.227893
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    conf = get_all_pkg_managers()
    assert 'apt' in conf
    assert 'apt_pkg' in conf
    assert 'apt_get' in conf
    assert 'aptitude' in conf
    assert 'apk' in conf
    assert 'dnf' in conf
    assert 'yum' in conf
    assert 'zypper' in conf
    assert 'up2date' in conf
    assert 'portage' in conf
    assert 'gentoolkit' in conf
    assert 'pacman' in conf
    assert 'pkgng' in conf
    assert 'pkg' in conf
    assert 'pip' in conf
    assert 'pip2' in conf
    assert 'pip3' in conf
    assert 'gem' in conf
    assert 'go' in conf
    assert 'npm' in conf

# Generated at 2022-06-20 18:43:35.666124
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    test_pkg_mgr = PkgMgr()
    assert isinstance(test_pkg_mgr, PkgMgr)



# Generated at 2022-06-20 18:43:37.833536
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert(type(get_all_pkg_managers()) == dict)
    assert(len(get_all_pkg_managers()) > 0)

# Generated at 2022-06-20 18:43:39.936550
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr.CLI == None
    assert mgr._cli == None



# Generated at 2022-06-20 18:43:48.477302
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    #Method is_available() should return whether the PkgMgr is available or not
    #For this test we will test the is_available method of class PkgMgr's Subclass: LibMgr

    #Testing when Method is_available() should return False
    class TestLibMgr(LibMgr):
        LIB = 'python3'
        def __init__(self):
            super(TestLibMgr, self).__init__()
    test_libmgr_obj = TestLibMgr()
    assert test_libmgr_obj.is_available() == False

    #Testing when Method is_available() should return True
    class TestLibMgr(LibMgr):
        LIB = 'ansible.module_utils.basic'
        def __init__(self):
            super(TestLibMgr, self).__init__()


# Generated at 2022-06-20 18:43:59.387363
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.net_tools import parse_version
    from ansible.module_utils.common._utils import compare_generic

    class TestPkgMgr(LibMgr):

        LIB = 'ansible.module_utils.facts.system.test_pkgmgr'

        def list_installed(self):
            return filter(None, self._lib.test_sorted_list_installed())

        def get_package_details(self, package):
            return self._lib.test_package_details(package)

    pkgmgr = TestPkgMgr()
    packages = pkgmgr.get_packages()

# Generated at 2022-06-20 18:44:09.216017
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class MockPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [
                '/usr/local/bin/docker',
                '/usr/local/bin/docker-compose',
                '/usr/local/bin/docker-machine',
                '/usr/local/bin/docker.io',
            ]

        def get_package_details(self, package):
            return {'name': package.split('/')[-1], 'version': '1.2.3'}

    pm = MockPkgMgr()

    packages = pm.get_packages()

    assert 'docker' in packages
    assert 'docker-compose' in packages
    assert 'docker-machine' in packages
    assert 'docker.io' in packages


# Generated at 2022-06-20 18:44:17.619171
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class _PkgMgr(PkgMgr):

        def __init__(self):
            self._pkg = list()

        def is_available(self):
            return True

        def list_installed(self):
            return self._pkg

        def get_package_details(self, package):
            return {'name': package}

    packages = ['test1', 'test2', 'test3', 'test1', 'test3']

# Generated at 2022-06-20 18:44:20.932607
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    x = PkgMgr()
    # This will return AttributeError which needs to be handled at calling end
    print(x.list_installed())


# Generated at 2022-06-20 18:44:54.803491
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    """Check if CliMgr class can be instantiated"""
    assert CLIMgr is not None


# Generated at 2022-06-20 18:44:55.407117
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pass

# Generated at 2022-06-20 18:44:57.786587
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_CLIMgr = CLIMgr()
    assert test_CLIMgr.is_available() == False


# Generated at 2022-06-20 18:45:00.626489
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_test(LibMgr):
        LIB = 'nonexistent.lib'

    pm = LibMgr_test()
    assert pm.is_available() == False


# Generated at 2022-06-20 18:45:04.494273
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    class PkgMgr_test_PkgMgr_list_installed(PkgMgr):

        def list_installed(self):

            return []

    pm = PkgMgr_test_PkgMgr_list_installed()
    x = pm.list_installed()



# Generated at 2022-06-20 18:45:07.704385
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import pytest
    p = CLIMgr()
    assert p.is_available() is False
    assert p._cli is None



# Generated at 2022-06-20 18:45:10.845954
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class Apt(CLIMgr):
        CLI = 'apt-get'
    package = Apt()
    assert package._cli is None

# Generated at 2022-06-20 18:45:17.536012
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''
    Test for class CLIMgr is_available
    '''
    print("Start unit test for class CLIMgr is_available")
    # This module doesn't rely on any third party libraries
    # just depends on system python version and ansible version
    # So no need to do any mockup testing.
    if syspyver < '3':
        assert(str(CLIMgr('ps').is_available())) == 'True'
    else:
        assert(str(CLIMgr('ps').is_available())) == 'False'
    print("End unit test for class CLIMgr is_available")

# Generated at 2022-06-20 18:45:28.165060
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):
        def __init__(self):
            pass
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    # Check if get_package_details method is defined
    pkg_mgr = TestPkgMgr()
    assert callable(getattr(pkg_mgr, 'get_package_details', None))

    # Check if get_package_details method does not raise AttributeError
    assert not hasattr(pkg_mgr, 'package')
    assert hasattr(pkg_mgr, 'get_package_details')
    pkg_mgr.get_package_details(None)

# Generated at 2022-06-20 18:45:36.478369
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import json
    import os
    import sys
    import tempfile
    import unittest
    from ansible.module_utils.ansible_release import __version__ as ansible_release_version
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import configparser

    class TestPkgMgr(PkgMgr):
        def __init__(self, package_dict):
            super(TestPkgMgr, self).__init__()
            self.package_dict = package_dict
        def is_available(self):
            return True
        def list_installed(self):
            return self.package_dict.keys()
        def get_package_details(self, package):
            return self.package_dict[package]


# Generated at 2022-06-20 18:46:50.063866
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    a = LibMgr()
    a.LIB = "os"
    a.is_available()
    try:
        a.LIB = "test"
        a.is_available()
        assert False
    except ImportError:
        assert True



# Generated at 2022-06-20 18:46:51.344617
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    test_pm = PkgMgr()
    assert test_pm

# Generated at 2022-06-20 18:46:53.517775
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'cant_import_this'

    assert TestLibMgr().is_available() == False


# Generated at 2022-06-20 18:47:01.229488
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class NoPkg(PkgMgr):
        def __init__(self): pass
        def is_available(self): return True
        def list_installed(self): return []
        def get_package_details(self, package): return {'name': 'no-package', 'version': '1.0'}
    assert NoPkg().get_packages() == {'no-package': [{'name': 'no-package', 'version': '1.0', 'source': 'nopkg'}]}
    class NoName(PkgMgr):
        def __init__(self): pass
        def is_available(self): return True
        def list_installed(self): return ['no-name']
        def get_package_details(self, package): return {'version': '1.0'}
    assert NoName().get

# Generated at 2022-06-20 18:47:05.453284
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class InstalledPkg(PkgMgr):
        def list_installed(self):
            return ["dummy_installed_package"]

        def get_package_details(self, package):
            return {"name": "dummy_installed_package", "version": "1.0.0"}
    assert InstalledPkg().list_installed() == ["dummy_installed_package"]


# Generated at 2022-06-20 18:47:13.523723
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        import pkg_resources
    except ImportError:
        raise AssertionError('pkg_resources is not installed')
    try:
        list = pkg_resources.get_distribution('pkg_mgr_test').version
    except pkg_resources.DistributionNotFound:
        raise AssertionError('pkg_mgr_test is not installed')
    assert(list == ['1.0'])


# Generated at 2022-06-20 18:47:14.713963
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert not CLIMgr().is_available()


# Generated at 2022-06-20 18:47:23.848377
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.common.pycompat24 import get_exception
    try:
        # BSD like systems have pkg_info
        mgr = CLIMgr()
        mgr.CLI = 'pkg_info'
        assert mgr.CLI == 'pkg_info'
        assert mgr.is_available()
        # most Linux systems don't have pkg_info
        mgr = CLIMgr()
        mgr.CLI = 'does_not_exist'
        assert mgr.CLI == 'does_not_exist'
        assert mgr.is_available() == False
    except AssertionError:
        raise AssertionError(get_exception())

# Generated at 2022-06-20 18:47:28.414326
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    """Unit test for constructor of PkgMgr class."""

    pm = PkgMgr()

    assert(pm.is_available() == NotImplemented)
    assert(pm.list_installed() == NotImplemented)
    assert(pm.get_package_details('abcd') == NotImplemented)

# Generated at 2022-06-20 18:47:29.278504
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()


# Generated at 2022-06-20 18:50:24.567947
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    assert not a.is_available()



# Generated at 2022-06-20 18:50:26.032510
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    climgr = CLIMgr()
    assert climgr._cli == None

# Generated at 2022-06-20 18:50:35.206883
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class PkgMgrSimple(PkgMgr):
        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass
    # Test with failing list_installed
    try:
        pkg = type('pkg', (PkgMgrSimple,), {'list_installed': lambda self: 1/0})()
        result = pkg.is_available()
        assert not result
    except ZeroDivisionError:
        pass
    # Test with correct dummy
    pkg = type('pkg', (PkgMgrSimple,), {'list_installed': lambda self: []})()
    result = pkg.is_available()
    assert result


# Generated at 2022-06-20 18:50:38.184143
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    isinstance(mgr, PkgMgr)
    assert mgr.is_available() == False
    assert mgr.list_installed() == None
    assert mgr.get_package_details(None) == None
    assert mgr.get_packages() == None

# Generated at 2022-06-20 18:50:41.710296
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestClass(LibMgr):
        LIB = 'pip'

        def list_installed(self):
            import pip
            return [{"name":dist.project_name, "version":dist.version} for dist in pip.get_installed_distributions()]

    t = TestClass()
    assert t.is_available()
    packages = t.list_installed()

    assert next(iter(packages))['name'] == 'pip'
