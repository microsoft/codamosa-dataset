

# Generated at 2022-06-20 18:40:48.915271
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pass


# Generated at 2022-06-20 18:40:51.009605
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkg_mg = PkgMgr()
    result = pkg_mg.get_packages()
    assert result == {}

# Generated at 2022-06-20 18:40:53.424111
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class FakeCLIMgr(CLIMgr):
        CLI = 'nonExistantCommand'

    assert not FakeCLIMgr().is_available()

# Generated at 2022-06-20 18:40:55.635251
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.list_installed() is None


# Generated at 2022-06-20 18:40:57.493242
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr


# Generated at 2022-06-20 18:41:05.070125
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestMgr(PkgMgr):
        def __init__(self, pkg_details):
            self.pkg_details = pkg_details

        def is_available(self):
            return True

        def get_package_details(self, package):
            return self.pkg_details

        def list_installed(self):
            return ["test"]

    pkg_details = {'name': 'test', 'version': '1.0'}
    mgr = TestMgr(pkg_details)
    assert pkg_details in mgr.get_packages().values()

# Generated at 2022-06-20 18:41:06.551001
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
  pm = PkgMgr()
  assert(pm != None)



# Generated at 2022-06-20 18:41:07.630754
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    PkgMgr()

# Generated at 2022-06-20 18:41:10.230212
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    test_obj = PkgMgr()
    assert test_obj.is_available() == NotImplemented


# Generated at 2022-06-20 18:41:12.621364
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_class = LibMgr()
    assert test_class.is_available() == False



# Generated at 2022-06-20 18:41:18.607786
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr.is_available() == False
    assert libmgr._lib == None


# Generated at 2022-06-20 18:41:20.197747
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert True


# Generated at 2022-06-20 18:41:24.546006
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test_obj_1 = CLIMgr()
    test_obj_1.CLI = 'python'
    assert test_obj_1.is_available() == True
    test_obj_1.CLI = 'python_dummy_value'
    assert test_obj_1.is_available() == False



# Generated at 2022-06-20 18:41:31.064930
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_mgrs = get_all_pkg_managers()

    assert 'dnf' in pkg_mgrs
    assert 'yum' in pkg_mgrs
    assert 'portage' in pkg_mgrs
    assert 'pip' in pkg_mgrs
    assert 'apk' in pkg_mgrs
    assert 'apt' in pkg_mgrs
    assert 'pkgng' in pkg_mgrs
    assert 'pkg5' in pkg_mgrs
    assert 'gem' in pkg_mgrs
    assert 'easyinstall' in pkg_mgrs
    assert 'zypper' in pkg_mgrs
    assert 'pacman' in pkg_mgrs
    assert 'gazer' in pkg_mgrs
   

# Generated at 2022-06-20 18:41:40.638298
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class PkgMgr__is_available(PkgMgr):
        def is_available(self):
            pass

    class CLIMgr__is_available(CLIMgr):
        def is_available(self):
            pass

    class LibMgr__is_available(LibMgr):
        def is_available(self):
            pass

    a = PkgMgr__is_available()
    assert a.is_available() == None
    a = CLIMgr__is_available()
    assert a.is_available() == None
    a = LibMgr__is_available()
    assert a.is_available() == None


# Generated at 2022-06-20 18:41:50.001815
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    expected = ['apt', 'dpkg', 'apk', 'apm', 'apt_rpm', 'cabal', 'composer', 'dnf', 'dnf_yum', 'gem', 'npm', 'packagekit', 'pacman', 'pkgng', 'portage', 'port_pkg', 'pip', 'pkgin', 'pkgutil', 'port_dmg', 'rpm', 'rpm_pulp', 'snap', 'yum', 'zypper']
    actual = get_all_pkg_managers()
    for package_manager in expected:
        assert package_manager in actual

# Generated at 2022-06-20 18:41:51.401731
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm


# Generated at 2022-06-20 18:41:58.307754
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    test CLIMgr.is_available
    """
    class DummyMgr(CLIMgr):
        CLI = 'dummy'

    dm = DummyMgr()
    assert dm.is_available() is False
    assert dm._cli is None

    from os import environ
    oldpath = environ['PATH']

# Generated at 2022-06-20 18:41:59.267326
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
  assert CLIMgr().__class__ == CLIMgr

# Generated at 2022-06-20 18:42:01.241895
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().is_available() == False


# Generated at 2022-06-20 18:42:12.746593
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_class = LibMgr()
    test_class.LIB = 'os'
    assert(test_class.is_available() == True)
    test_class.LIB = 'fakelib'
    assert(test_class.is_available() == False)


# Generated at 2022-06-20 18:42:19.075902
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgmgr = CLIMgr()
    pkgmgr.CLI = 'yum'
    assert pkgmgr.is_available()

    pkgmgr.CLI = 'apt-get'
    assert pkgmgr.is_available()

    pkgmgr.CLI = 'zypper'
    assert pkgmgr.is_available()

    pkgmgr.CLI = 'dnf'
    assert pkgmgr.is_available()


# Generated at 2022-06-20 18:42:22.365352
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for (name, obj) in get_all_pkg_managers().items():
        print(name, 'is', obj().is_available() and 'available' or 'not available')



# Generated at 2022-06-20 18:42:33.627790
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import os
    import sys
    import json
    import unittest

    class DummyPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['package_a', 'package_b', 'package_c']

        def get_package_details(self, package):
            return {'name': package, 'version': 'latest', 'arch': 'x86_64'}


# Generated at 2022-06-20 18:42:41.862184
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    test_pkg_managers = get_all_pkg_managers()

    for pkg_manager in test_pkg_managers:
        assert pkg_manager in ('apt_pkg', 'yum_pkg', 'dnf_pkg', 'zypper_pkg', 'portage_pkg', 'apk_pkg', 'pacman_pkg', 'pkgng_pkg', 'pkgin_pkg', 'homebrew_pkg', 'freebsd_pkg', 'urpmi_pkg', 'eopkg_pkg')


# Generated at 2022-06-20 18:42:43.681159
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    fakeObj1 = PkgMgr()
    assert fakeObj1 is not None


# Generated at 2022-06-20 18:42:45.425556
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgMgr = PkgMgr()
    assert not pkgMgr.is_available()


# Generated at 2022-06-20 18:42:46.159471
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert True


# Generated at 2022-06-20 18:42:58.189099
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    from ansible.module_utils.facts.system.pkg_mgr import CLIMgr
    from ansible.module_utils.facts.system.pkg_mgr.lib_yum import LibYum
    from ansible.module_utils.facts.system.pkg_mgr.cli_yum import CLIYum
    pkg_mgr_test_object = PkgMgr()
    pkg_detail_test_object = LibMgr()
    libmgr_test_object = LibYum()
    climgr_test_object = CLIYum()
    # tests for method get_packages of class PkgMgr

# Generated at 2022-06-20 18:43:01.109142
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    class TestCLIMgr(CLIMgr):
        CLI = None
    tcm = TestCLIMgr()
    assert isinstance(tcm, CLIMgr)


# Generated at 2022-06-20 18:43:16.911363
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    p = PkgMgr()
    p.list_installed()

# Generated at 2022-06-20 18:43:22.649795
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    assert CLIMgr().is_available() == False
    os.environ['PATH'] = ''.join([os.environ['PATH'], ':', os.path.dirname(os.path.realpath(__file__))])
    assert CLIMgr().is_available() == True


# Generated at 2022-06-20 18:43:25.292758
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr = PkgMgr()
    package={}
    try:
        pkgmgr.get_package_details(package)
    except NotImplementedError:
        pass
    except:
        raise
    else:
        raise Exception("Exception not raised for PkgMgr.get_package_details")


# Generated at 2022-06-20 18:43:25.718380
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass

# Generated at 2022-06-20 18:43:32.190013
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        from collections import namedtuple
    except ImportError:
        run_test = False

    if run_test:
        InstalledPackage = namedtuple('InstalledPackage', ['name', 'version', 'arch'])
        pm = PkgMgr()
        packages = pm.list_installed()
        assert isinstance(packages, list)
        for package in packages:
            assert isinstance(package, InstalledPackage)
            assert isinstance(package.name, str)
            assert isinstance(package.version, str)
            assert isinstance(package.arch, str)

# Generated at 2022-06-20 18:43:39.535728
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers() == {'apt': None, 'apk': None, 'dnf': None, 'emerge': None, 'freebsd_pkg': None, 'pkg5': None, 'pacman': None, 'pkgng': None, 'portage': None, 'pip': None, 'portinstall': None, 'swdepot': None, 'swinstall': None, 'xbps': None, 'yum': None, 'zypper': None, 'homebrew': None}

# Generated at 2022-06-20 18:43:40.943013
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available() == None


# Generated at 2022-06-20 18:43:49.073436
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import unittest
    import sys
    import mock

    class MyPkgMgrTest(PkgMgr):
        def __init__(self):
            self.packages = {}
            self.packages_list = []
            self.packages_details = []
            super(MyPkgMgrTest, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.packages_list

        def get_package_details(self, package):
            return self.packages_details[self.packages_list.index(package)]

    class CLIMgrTest(CLIMgr):
        pass

    class LibMgrTest(LibMgr):
        pass

    # Mock class for subprocess

# Generated at 2022-06-20 18:43:59.772109
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-20 18:44:03.206272
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._utils import get_all_subclasses
    LibMgrSubClasses = get_all_subclasses(LibMgr)
    for obj in LibMgrSubClasses:
        if obj not in (CLIMgr, LibMgr):
            assert obj().is_available() is not None


# Generated at 2022-06-20 18:44:35.847369
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgrs = PkgMgr.__subclasses__()
    for pkg_mgr in pkg_mgrs:
        try:
            p = pkg_mgr()
            p.is_available()
        except:
            assert(False)

# Generated at 2022-06-20 18:44:37.977006
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        pass
    pm = TestLibMgr()
    assert not pm.is_available()


# Generated at 2022-06-20 18:44:39.087234
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()


# Generated at 2022-06-20 18:44:40.597153
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm

# Generated at 2022-06-20 18:44:41.886895
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-20 18:44:43.038741
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False

# Generated at 2022-06-20 18:44:45.689065
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class DummyPkgMgr(PkgMgr):
        pass
    dummy_pkg_mgr = DummyPkgMgr()
    assert(dummy_pkg_mgr)


# Generated at 2022-06-20 18:44:51.165229
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkg(PkgMgr):
        def list_installed(self):
            return ['test.pkg']
        def get_package_details(self, package):
            return {'name': 'test.pkg', 'version': '1.0.0'}

    test_pkg = TestPkg()
    result = test_pkg.get_package_details('test.pkg')
    assert result == {'name': 'test.pkg', 'version': '1.0.0'}
    assert 'source' in result


# Generated at 2022-06-20 18:44:54.191974
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
        pkg_mgr = PkgMgr()
        data = pkg_mgr.list_installed()
        assert data is not None


# Generated at 2022-06-20 18:44:56.659367
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class TestCLIMgr(CLIMgr):
        CLI = 'ls'

    a = TestCLIMgr()
    assert a.is_available() == True


# Generated at 2022-06-20 18:45:59.985980
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details == PkgMgr.get_package_details, "Method get_package_details is not abstract"


# Generated at 2022-06-20 18:46:06.751279
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    #Create a test object
    test_obj = CLIMgr()
    #Assign a value to the CLI variable
    test_obj.CLI = 'ruby'
    #Assert the value returned by the is_available method
    assert test_obj.is_available() == True
    #Assign a different value to the CLI variable
    test_obj.CLI = 'pip'
    #Assert the value returned by the is_available method
    assert test_obj.is_available() == False


# Generated at 2022-06-20 18:46:12.355285
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class MockCLIMgr(CLIMgr):
        CLI = 'test'
    # CLI is available
    mocker.patch('ansible.module_utils.common._utils.get_bin_path', return_value='test')
    m = MockCLIMgr()
    assert m.is_available() is True
    # CLI is not available
    mocker.patch('ansible.module_utils.common._utils.get_bin_path', side_effect=ValueError)
    m = MockCLIMgr()
    assert m.is_available() is False

# Generated at 2022-06-20 18:46:23.442819
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class A(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return ['package_A','package_B','package_C','package_A','package_B','package_A']
        def get_package_details(self, package):
            return {'name': package, 'version': '2.0'}

    class B(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return ['package_A','package_B','package_C','package_A','package_B','package_A']
        def get_package_details(self, package):
            return {'name': package, 'version': '2.0'}
    packages = A().get_packages()

# Generated at 2022-06-20 18:46:32.440078
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import u
    import subprocess
    devnull = subprocess.DEVNULL

    class TstLibMgr(LibMgr):
        LIB = 'os'

    tst_lib_mgr = TstLibMgr()
    # Make sure is_available returns False when subprocess.DEVNULL is None
    devnull_bak = subprocess.DEVNULL
    subprocess.DEVNULL = None
    assert not tst_lib_mgr.is_available()
    # Make sure is_available returns False when check_output fails to return
    # with the error code of the command it tried to run

# Generated at 2022-06-20 18:46:35.109087
# Unit test for constructor of class LibMgr
def test_LibMgr():
    a = LibMgr()
    assert a._lib == None, "Unexpected value found for _lib"
    assert a.LIB == None, "Unexpected value found for CLI"


# Generated at 2022-06-20 18:46:42.502675
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr = CLIMgr()

    # Empty CLI variable
    if 'climgr_cli' in pkg_mgr.__dict__:
        del pkg_mgr.__dict__['climgr_cli']
    if 'CLI' in pkg_mgr.__class__.__dict__:
        del pkg_mgr.__class__.__dict__['CLI']
    assert not pkg_mgr.is_available()

    # CLI present in instance var
    pkg_mgr.__dict__['climgr_cli'] = 'cli'
    assert pkg_mgr.is_available()

    # CLI present in class var
    del pkg_mgr.__dict__['climgr_cli']

# Generated at 2022-06-20 18:46:43.971729
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False


# Generated at 2022-06-20 18:46:46.074452
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr = CLIMgr()
    assert(pkg_mgr.__class__.__name__ == 'CLIMgr')


# Generated at 2022-06-20 18:46:47.108808
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    p = CLIMgr()
    assert p

# Generated at 2022-06-20 18:49:27.785500
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pm = CLIMgr()
    assert pm.is_available() is False

# Generated at 2022-06-20 18:49:37.739464
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class testPkgMgr:
        def __init__(self):
            self.pkg_list = []
            self.pkg_info = {}

        def list_installed(self):
            return self.pkg_list

        def get_package_details(self, package):
            return self.pkg_info[package]

    class PkgMgrNullInstance(PkgMgr):
        def __init__(self):
            self.lib = testPkgMgr()

        def is_available(self):
            return True

        def list_installed(self):
            return self.lib.list_installed()

        def get_package_details(self, package):
            return self.lib.get_package_details(package)

    # The following test cases have been designed to test all the possible
    # combinations for the get_packages method



# Generated at 2022-06-20 18:49:39.627342
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    ans = PkgMgr()
    try:
        ans.is_available()
    except NotImplementedError:
        return True
    return False


# Generated at 2022-06-20 18:49:41.306700
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers) == 0, "Test did not expect any package managers"



# Generated at 2022-06-20 18:49:43.851011
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    try:
        res = pm.get_package_details
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-20 18:49:45.961356
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert isinstance(cm, CLIMgr)

# Generated at 2022-06-20 18:49:47.315171
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-20 18:49:54.535239
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    results = get_all_pkg_managers()
    import platform
    import os
    if platform.system() == 'FreeBSD':
        assert 'bsd_pkg' in results
        assert 'pkgng' in results
        if os.path.exists('/usr/sbin/pkg'):
            assert 'pkgng' in results
        else:
            assert 'bsd_pkg' in results
    elif platform.system() == 'Darwin':
        assert 'macports' in results
        assert 'homebrew' in results
        assert 'packagemgr' in results

# Generated at 2022-06-20 18:49:55.519345
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # If this function is called it means that the test passed
    assert True

# Generated at 2022-06-20 18:49:57.467564
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

