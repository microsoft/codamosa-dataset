

# Generated at 2022-06-20 18:40:57.578730
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.collector.pkg_mgrs.dpkg import Dpkg
    dpkg = Dpkg()
    def get_bin_path(name):
        if name == 'dpkg':
            return True
        raise ValueError

    import pytest
    pytest.importorskip('apt')
    with pytest.raises(ValueError):
        print(dpkg.is_available())
    with pytest.raises(ImportError):
        dpkg.LIB = 'apt'
        dpkg.is_available()
    dpkg.get_bin_path = get_bin_path
    print(dpkg.is_available())

# Generated at 2022-06-20 18:40:59.045624
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed is not None


# Generated at 2022-06-20 18:41:03.274888
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    test1 = CLIMgr()
    test1._cli = 'this.does.not.exist'
    test2 = CLIMgr()
    test2._cli = True

    assert test1.is_available() is False
    assert test2.is_available() is True


# Generated at 2022-06-20 18:41:16.198646
# Unit test for method is_available of class PkgMgr

# Generated at 2022-06-20 18:41:22.203348
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.legacy_packaging.superclass import PkgMgr

    import pytest

    class DummyPkgMgr(PkgMgr):
        def list_installed(self):
            return ['dummy']

        def is_available(self):
            return True

    pkg = DummyPkgMgr()

    with pytest.raises(NotImplementedError):
        pkg.get_package_details('package')


# Generated at 2022-06-20 18:41:23.440640
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert None, 'Not implemented'


# Generated at 2022-06-20 18:41:24.462797
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    result = PkgMgr()
    assert result is not None

# Generated at 2022-06-20 18:41:26.818590
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    package_mgr = PkgMgr()
    assert not package_mgr.get_packages()


if __name__ == '__main__':
    test_PkgMgr_get_packages()

# Generated at 2022-06-20 18:41:29.551856
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    test_CLIMgr_is_available - create a new CLIMgr object and assert
    that the is_available method returns True
    :return: None
    """
    pkg_cli = CLIMgr()
    assert pkg_cli.is_available()



# Generated at 2022-06-20 18:41:32.499739
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    class PackageManager(CLIMgr):
        CLI = 'apt'

    pkg = PackageManager()
    assert pkg.CLI == 'apt'
    assert pkg._cli is None


# Generated at 2022-06-20 18:41:38.274987
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert 'list_installed' in dir(PkgMgr)


# Generated at 2022-06-20 18:41:46.651511
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class PkgMgrTest(PkgMgr):

        def list_installed(self):
            return ['pkg1', 'pkg2']

        def get_package_details(self, package):
            return dict(name=package, version='0.0.1')

    pkg_mgr = PkgMgrTest()
    assert pkg_mgr.list_installed() == ['pkg1', 'pkg2']
    assert pkg_mgr.get_packages() == {'pkg1': [{'name': 'pkg1', 'source': 'pkgmgrtest', 'version': '0.0.1'}],
                                      'pkg2': [{'name': 'pkg2', 'source': 'pkgmgrtest', 'version': '0.0.1'}]}


# Generated at 2022-06-20 18:41:53.318352
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    assert not issubclass(PkgMgr, object)
    assert isinstance(PkgMgr, type)
    assert PkgMgr.__name__ == 'PkgMgr'
    assert PkgMgr.__bases__ == (object,)
    p = PkgMgr()
    assert not hasattr(p, 'is_available')
    assert not hasattr(p, 'list_installed')
    assert not hasattr(p, 'get_package_details')



# Generated at 2022-06-20 18:41:57.207201
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.python import platform
    lm = LibMgr()
    assert(lm._lib is None)
    lm.is_available()
    assert(lm._lib is not None)


# Generated at 2022-06-20 18:42:02.094495
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys

    class FakePkgMgr(LibMgr):
        LIB = 'sys'

    fake_pkg = FakePkgMgr()

    assert fake_pkg.is_available() == True
    assert fake_pkg._lib == sys


# Generated at 2022-06-20 18:42:04.323784
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    assert pm.get_package_details(None) is None

# Generated at 2022-06-20 18:42:06.539888
# Unit test for constructor of class LibMgr
def test_LibMgr():
    mgr = LibMgr()

    assert mgr.__class__.__name__ == 'LibMgr'
    assert mgr._lib is None


# Generated at 2022-06-20 18:42:08.504256
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-20 18:42:09.079406
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert 0 == 0

# Generated at 2022-06-20 18:42:12.167206
# Unit test for constructor of class LibMgr
def test_LibMgr():
    mgr = LibMgr()
    assert mgr._lib is None
    assert mgr.LIB is None
    assert mgr.is_available() is False


# Generated at 2022-06-20 18:42:22.802552
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    all_pkg_managers = get_all_pkg_managers()
    assert len(all_pkg_managers) >= 1
    assert 'apt' in all_pkg_managers

# Generated at 2022-06-20 18:42:24.086082
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert pkg

# Generated at 2022-06-20 18:42:27.979905
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'testCLI'

    pkg_mgr = TestCLIMgr()
    assert pkg_mgr.CLI == 'testCLI'


# Generated at 2022-06-20 18:42:30.095039
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert obj.is_available() == True


# Generated at 2022-06-20 18:42:32.353977
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_module_list = [{}, {}]
    for module in test_module_list:
        assert isinstance(module, dict)

# Generated at 2022-06-20 18:42:33.673516
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)

# Generated at 2022-06-20 18:42:42.302888
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pytest
    from ansible.module_utils.facts.packages.pkg_mgr import PkgMgr
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['test', 'test']
        def get_package_details(self, package):
            return {}

    pkg_mgr = TestPkgMgr()
    results = pkg_mgr.get_packages()

    assert len(results['test']) == 2


# Generated at 2022-06-20 18:42:43.960615
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert isinstance(pkg_managers, dict)
    assert 'yum' in pkg_managers.keys()

# Generated at 2022-06-20 18:42:51.877493
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):
        def list_installed(self):
            return ["package1", "package2"]
        def get_package_details(self, package):
            if package == "package1":
                return {"name": "package1", "version": "1.0", "source": "Test"}
            if package == "package2":
                return {"name": "package2", "version": "2.0", "source": "Test"}
    manager = MockPkgMgr()
    packages = manager.get_packages()
    assert packages["package1"][0] == {"name": "package1", "version": "1.0", "source": "Test"}
    assert packages["package2"][0] == {"name": "package2", "version": "2.0", "source": "Test"}

# Generated at 2022-06-20 18:42:53.203682
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    test_PkgMgr = PkgMgr()
    return True

# Generated at 2022-06-20 18:43:10.458634
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-20 18:43:13.782837
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class TestLibMgr(LibMgr):

        LIB = 'sys'

    libmgr = TestLibMgr()
    assert libmgr.is_available()


# Generated at 2022-06-20 18:43:15.346144
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert isinstance(pkg,object)
test_PkgMgr()

# Generated at 2022-06-20 18:43:20.073006
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    PackageMgr = PkgMgr()
    PackageMgr.name = "python-pandas"
    PackageMgr.version = "0.19.2-2"
    PackageMgr.source = "apt"
    MockPkgMgr = PkgMgr()
    assert MockPkgMgr.get_package_details(PackageMgr) == {'name': 'python-pandas', 'version': '0.19.2-2', 'source': 'apt'}

# Generated at 2022-06-20 18:43:24.875433
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestPkgMgr(CLIMgr):
        CLI = 'ansible-test-cli'
    try:
        get_bin_path('ansible-test-cli')
    except ValueError:
        pass
    assert not TestPkgMgr().is_available()



# Generated at 2022-06-20 18:43:29.615518
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lib = LibMgr()

    lib.LIB = 'unittest.case'
    assert lib.is_available() == True

    lib.LIB = 'unittest.testcase'
    assert lib.is_available() == False

    module.exit_json(changed=False)



# Generated at 2022-06-20 18:43:30.461803
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass


# Generated at 2022-06-20 18:43:35.921671
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    try:
        class PkgMgr_test(PkgMgr):
            pass
        test = PkgMgr_test()
        test.is_available()
    except Exception as e:
        self.fail(f'Failed to use is_available of PkgMgr: {e}')


# Generated at 2022-06-20 18:43:36.986717
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()



# Generated at 2022-06-20 18:43:38.373254
# Unit test for constructor of class LibMgr
def test_LibMgr():
    foo = LibMgr()
    assert foo is not None


# Generated at 2022-06-20 18:44:18.552871
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.package_manager.pip import PipMgr
    from ansible.module_utils.facts.package_manager.yum import YumMgr
    from ansible.module_utils.facts.package_manager.apt import AptMgr
    #Check get_packages method without checking availability of package manager
    pip_mgr_get_package = PipMgr.get_packages(PipMgr)
    yum_mgr_get_package = YumMgr.get_packages(YumMgr)
    apt_mgr_get_package = AptMgr.get_packages(AptMgr)
    #Check get_packages method with checking availability of package manager
    pip_mgr_get_package_check_available = PipMgr().get_packages()
    yum_mgr

# Generated at 2022-06-20 18:44:20.521282
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    # Create object of PkgMgr
    pm = PkgMgr()

# Generated at 2022-06-20 18:44:26.130548
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    expected_type_error = False
    expected_value_error = False
    actual_results = False
    try:
        actual_results = PkgMgr.is_available(PkgMgr)
    except TypeError:
        expected_type_error = True
    except ValueError:
        expected_value_error = True
    assert expected_type_error == True
    assert expected_value_error == False
    assert actual_results == False
    

# Generated at 2022-06-20 18:44:33.710291
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''
    Test the method is_available of class CLIMgr
    '''
    from ansible.module_utils.common.compat import HAS_YUM
    from ansible.module_utils.yum import YumMgr as Yum
    if HAS_YUM:
        climgr = Yum()
        assert climgr.is_available()
    else:
        climgr = CLIMgr()
        assert not climgr.is_available()


# Generated at 2022-06-20 18:44:36.913014
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.facts.collector.pkg_mgrs import CLIMgr
    import pytest
    mgr = CLIMgr()
    with pytest.raises(TypeError):
        mgr.is_available()

# Generated at 2022-06-20 18:44:38.679577
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() == 0


# Generated at 2022-06-20 18:44:40.977032
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libMgr = LibMgr()
    assert isinstance(libMgr, LibMgr)


# Generated at 2022-06-20 18:44:42.458139
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr.is_available(LibMgr) == False


# Generated at 2022-06-20 18:44:50.856034
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    # Define stub methods for abstract classes
    def list_installed(self):
        packages = ['libstdc++-4.8-dev', 'libc6-i386']
        return packages

    def get_package_details(self, package):
        package_details = {'name': 'libstdc++-4.8-dev', 'version': '4.8.4-2ubuntu1~14.04.3'}
        return package_details

    # Assign stub methods to abstract clas
    PkgMgr.list_installed = list_installed
    PkgMgr.get_package_details = get_package_details

    # Create object of class PkgMgr
    obj_pkgmgr_is_available = PkgMgr()

    # Check object type

# Generated at 2022-06-20 18:45:01.578695
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['a', 'b', 'c', 'a', 'b']

        def get_package_details(self, package):
            return {'name': package, 'version': package}

    pm = PkgMgrTest()
    packages = pm.get_packages()

    assert packages['a'] == [{'name': 'a', 'version': 'a', 'source': 'pkgmgrtest'}, {'name': 'a', 'version': 'a', 'source': 'pkgmgrtest'}]
    assert packages['b'] == [{'name': 'b', 'version': 'b', 'source': 'pkgmgrtest'}, {'name': 'b', 'version': 'b', 'source': 'pkgmgrtest'}]

# Generated at 2022-06-20 18:46:09.899822
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() is False


# Generated at 2022-06-20 18:46:13.639042
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    libmgr = LibMgr()
    assert libmgr.is_available() == False

# Test the get_packages method

# Generated at 2022-06-20 18:46:15.842931
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    global PkgMgr
    pm = PkgMgr()
    assert pm.is_available() == "NotImplemented"


# Generated at 2022-06-20 18:46:22.219095
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    found, missing = list(), list()
    for pkg_mgr in ('dnf', 'dpkg', 'gem', 'mock', 'pip', 'pkg', 'port', 'yum'):
        if pkg_mgr in get_all_pkg_managers():
            found.append(pkg_mgr)
        else:
            missing.append(pkg_mgr)
    assert not missing, '{0} are missing'.format(missing)
    assert len(found) > 0, '{0} are missing'.format(found)


# Generated at 2022-06-20 18:46:23.916721
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestClass(PkgMgr):
        def list_installed(self):
            pass
    testclass = TestClass()


# Generated at 2022-06-20 18:46:27.778261
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class MockedPkgMgr(PkgMgr):
        def list_installed(self):
            return "list_installed"

        def get_package_details(self, package):
            return "get_package_details"

    mock = MockedPkgMgr()
    assert mock.list_installed() == "list_installed"


# Generated at 2022-06-20 18:46:28.583084
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()


# Generated at 2022-06-20 18:46:29.899536
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import doctest
    doctest.testmod(PkgMgr)

# Generated at 2022-06-20 18:46:30.772204
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr is not None

# Generated at 2022-06-20 18:46:31.952668
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr() is not None

# Generated at 2022-06-20 18:49:26.993392
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr.get_package_details()==false


# Generated at 2022-06-20 18:49:35.699405
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self._pkgs = ['p1', 'p2']
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self._pkgs

        def get_package_details(self, package):
            return {'name': package}


    pkgmgr = TestPkgMgr()
    packages = pkgmgr.get_packages()
    assert len(packages) == 2
    assert 'p1' in packages
    assert 'p2' in packages

# Generated at 2022-06-20 18:49:40.289739
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgr(PkgMgr):
        def list_installed(self):
            return ['nano']

        def get_package_details(self, package):
            return {'name': 'nano', 'version': '3.2'}

    assert PkgMgr().get_packages() == {'nano': [{'name': 'nano', 'version': '3.2', 'source': 'pkgmgr'}]}


# Generated at 2022-06-20 18:49:45.625876
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    pkg_mgr = TestPkgMgr()
    assert pkg_mgr.is_available() == False


# Generated at 2022-06-20 18:49:47.987004
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    mgr = CLIMgr()
    assert mgr.list_installed() == None, "Class CLIMgr has not implemented the method list_installed."


# Generated at 2022-06-20 18:49:55.791612
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    # patch AnsibleModule Class
    basic.AnsibleModule = basic.AnsibleModuleMock
    pm = CLIMgr()

    class Dummy(CLIMgr):
        CLI = 'zsh'

    mock_module = basic.AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['present', 'absent']),
            pkg=dict(required=True),
        ),
        supports_check_mode=True,
    )

    mock_module.params = ImmutableDict(
        state='absent',
        pkg='httpd',
    )

    mock_module

# Generated at 2022-06-20 18:49:56.873814
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    a = LibMgr()
    assert a.is_available() == True


# Generated at 2022-06-20 18:50:07.702321
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgr_mock(PkgMgr):
        def __init__(self):
            super(PkgMgr_mock, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            package_details = {}
            package_details['name'] = package
            package_details['version'] = '1.0'
            package_details['release'] = '1.el7'
            return package_details

    pm = PkgMgr_mock()
    assert pm.get_package_details('bash') == {'name': 'bash', 'version': '1.0', 'release': '1.el7', 'source': 'pkgmgr_mock'}

# Generated at 2022-06-20 18:50:10.221766
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_LibMgr = LibMgr()
    result = test_LibMgr.is_available()
    assert type(result) is bool


# Generated at 2022-06-20 18:50:11.303988
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert p
