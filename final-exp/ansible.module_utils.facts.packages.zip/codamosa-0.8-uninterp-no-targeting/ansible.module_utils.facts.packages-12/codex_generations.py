

# Generated at 2022-06-20 18:40:48.268387
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'getpass'

    pkg = TestLibMgr()
    assert pkg.is_available() is True


# Generated at 2022-06-20 18:40:51.218024
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr.CLI is None
    assert mgr._cli is None
    assert mgr.is_available() is False


# Generated at 2022-06-20 18:40:53.227219
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_obj = CLIMgr()
    assert test_obj is not None


# Generated at 2022-06-20 18:40:57.704847
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    assert(a.CLI == None)
    assert(a._cli == None)


# Generated at 2022-06-20 18:41:07.377225
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._ast import PyCF_ONLY_AST
    import ast
    import sys
    import tempfile
    import shutil
    import os

    code = """
    class MyLibMgr(LibMgr):
        LIB = 'some_lib'
    """

    tmp_path = tempfile.mkdtemp()

# Generated at 2022-06-20 18:41:16.506420
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    package1 = {
        'name': 'test',
        'version': 'version'
    }
    package2 = {
        'name': 'test2',
        'version': 'version2'
    }

    class MyPkgMgr(PkgMgr):

        def list_installed(self):
            return [package1, package2]

        def get_package_details(self, package):
            return package

    x = MyPkgMgr()
    assert x.get_packages() == {
        'test': [package1],
        'test2': [package2],
    }

# Generated at 2022-06-20 18:41:23.838234
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = 'ls'

    # Create an instance of the class TestLibMgr
    test_lib_mgr = TestLibMgr()
    # Check if test_lib_mgr object is of type TestLibMgr
    assert type(test_lib_mgr) == TestLibMgr
    # Check if __init__ function got executed
    assert test_lib_mgr._lib is None
    # Check if the class is of type PkgMgr
    assert issubclass(TestLibMgr, PkgMgr)
    # Check if the class is of type LibMgr
    assert issubclass(TestLibMgr,LibMgr)


# Generated at 2022-06-20 18:41:33.765367
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-20 18:41:40.142969
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    package = "example_package"
    assert type(pkg_mgr.is_available()) is bool
    assert type(pkg_mgr.list_installed()) is list
    assert type(pkg_mgr.get_package_details(package=package)) is dict
    assert type(pkg_mgr.get_packages()) is dict


# Generated at 2022-06-20 18:41:52.112232
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_obj = PkgMgr()

    # Test with empty list of installed packages.
    test_obj.list_installed = lambda: []
    test_obj.get_package_details = lambda pkg: {'name': pkg, 'installed_version': '1.0'}
    assert test_obj.get_packages() == {}

    # Test with one package that is installed
    test_obj.list_installed = lambda: ['package1']
    test_obj.get_package_details = lambda pkg: {'name': pkg, 'installed_version': '1.0'}
    assert test_obj.get_packages() == {'package1': [{'name': 'package1', 'installed_version': '1.0', 'source': 'pkgmgr'}]}

    # Test with one package installed in two versions


# Generated at 2022-06-20 18:42:00.378656
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    try:
        pm = PkgMgr()
        assert False, "PkgMgr is an abstract class and shouldn't be instantiated"
    except TypeError:
        pass


# Generated at 2022-06-20 18:42:02.093211
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False


# Generated at 2022-06-20 18:42:06.316686
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr(),"The class PkgMgr should be defined."
    assert not PkgMgr().get_package_details("whatever")
    assert PkgMgr().get_package_details("whatever") == {}
    assert PkgMgr().get_package_details("whatever") == None


# Generated at 2022-06-20 18:42:13.934956
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = ['APT', 'Yum', 'Dnf', 'Pacman', 'Pkgng', 'Portage', 'Apk', 'Eopkg', 'DNF', 'Pkg', 'Emerge', 'Pkg5', 'Pkgin', 'Brew', 'Port', 'Pkgutil', 'Pacman', 'Yum', 'Yast2']
    for i in pkgmgr:
        pm = get_all_pkg_managers()[i]()
        assert pm.is_available() == True

# Generated at 2022-06-20 18:42:17.214725
# Unit test for constructor of class LibMgr
def test_LibMgr():
    l = LibMgr()
    l.LIB = 'os'
    assert l.is_available() is True
    l.LIB = 'puppet'
    assert l.is_available() is False


# Generated at 2022-06-20 18:42:23.599657
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    # Create a dict to represent the argument specification for the module
    argument_spec = dict(
        name=dict(required=True),
        state=dict(choices=['latest'], default='latest')
    )

    # Instantiate ansible module object
    am = AnsibleModule(argument_spec=argument_spec)

    # import package manager
    test_pm = PkgMgr()

    # Throw exception without overriding list_installed
    with am.assertRaises(NotImplementedError):
        test_pm.list_installed()

    # Override list_installed
    def test_list_installed():
        return ['a', 'b']

    test_pm.list_installed = test_list_installed

    # Ass

# Generated at 2022-06-20 18:42:25.559109
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    pkgMgr = PkgMgr()
    pkgMgr.list_installed()


# Generated at 2022-06-20 18:42:31.708592
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # PkgMgr is an abstract class and not implemented directly, this tests if a subclasses
    # get_package_details method overwrites the abstract method
    class TestPkgMgr(PkgMgr):
        pass

    tpm = TestPkgMgr()
    try:
        tpm.get_package_details(None)
    except NotImplementedError:
        return True
    return False


# Generated at 2022-06-20 18:42:33.579889
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    h = CLIMgr()
    assert(h._cli is None)
    assert(h.CLI is None)

# Generated at 2022-06-20 18:42:35.181977
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    is_available = PkgMgr().is_available()
    assert is_available is True


# Generated at 2022-06-20 18:42:42.159548
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    """ Can we get all package managers? """
    result = get_all_pkg_managers()
    assert isinstance(result, dict)
    assert len(result) > 0

# Generated at 2022-06-20 18:42:44.402863
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        __import__('yum')
        found = True
    except ImportError:
        found = False
    assert found == True



# Generated at 2022-06-20 18:42:46.450129
# Unit test for constructor of class LibMgr
def test_LibMgr():
    manager = LibMgr()
    assert manager.LIB is None
    assert manager._lib is None
# End unit test


# Generated at 2022-06-20 18:42:51.535963
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert get_all_pkg_managers()['apt'].get_packages()['openssh-server'][0]['version'] == '1:7.2p2-4ubuntu2.7'

# Generated at 2022-06-20 18:42:52.882177
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgMgr = PkgMgr()


# Generated at 2022-06-20 18:43:02.113670
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """
    tests for method is_available of class PkgMgr.
    """
    pkg_mgr = PkgMgr
    is_available = PkgMgr.is_available
    assert is_available.__name__ == 'is_available'
    assert is_available.__doc__.strip() == 'This method is supposed to return True/False if the package manager is currently installed/usable\n        It can also \'prep\' the required systems in the process of detecting availability'
    assert is_available.__module__ == 'ansible.module_utils.common.pkg_mgr'
    assert is_available(pkg_mgr) == True


# Generated at 2022-06-20 18:43:04.200407
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj._cli is None
    assert obj.CLI is None


# Generated at 2022-06-20 18:43:15.710602
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers) == 10 or len(pkg_managers) == 12, "Number of package managers changed"

    assert 'fpm' in pkg_managers, "FMPMgr not found in package managers"
    assert 'apt' in pkg_managers, "APTMgr not found in package managers"
    assert 'apk' in pkg_managers, "APKMgr not found in package managers"
    assert 'yum' in pkg_managers, "YUMMgr not found in package managers"
    assert 'dnf' in pkg_managers, "DNFMgr not found in package managers"
    assert 'zypper' in pkg_managers, "ZypperMgr not found in package managers"

# Generated at 2022-06-20 18:43:23.613514
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True


# Generated at 2022-06-20 18:43:31.890326
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common.compat import Mock

# Generated at 2022-06-20 18:43:45.625081
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    def get_all_pkg_managers(self):
        return [self.Apt(), self.Yum()]

    def list_installed(self):
        return ['package1', 'package2', 'package1']

    def get_package_details(self, package):
        return {'name': package, 'version': package}

    PkgMgr.get_all_pkg_managers = get_all_pkg_managers
    PkgMgr.list_installed = list_installed
    PkgMgr.get_package_details = get_package_details


    PkgMgr = PkgMgr()
    packages = PkgMgr.get_packages()

# Generated at 2022-06-20 18:43:46.428717
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass



# Generated at 2022-06-20 18:43:55.966441
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common._collections_compat import Mapping
    
    python_bin = get_bin_path("python")
    if python_bin is None:
        # Not an error during testing as python is not required
        python_bin = get_bin_path("python3")
    
    class Test_LibMgr(LibMgr):
        LIB = "os"
    
    obj = Test_LibMgr()
    assert obj.is_available() == True
    assert isinstance(obj._lib, Mapping)
    

# Generated at 2022-06-20 18:44:04.138269
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.common.process import get_bin_path

    try:
        from ansible.module_utils._text import to_native
    except ImportError:
        from ansible.module_utils.basic import to_native

    p = CLIMgr()

    assert(p.is_available() == False)
    assert(p.get_package_details() == None)

    p = CLIMgr()

    p.CLI = "ansible_fake_cli"
    assert(p.is_available() == True)

    try:
        p.get_package_details()
    except ValueError as e:
        print(to_native(e))
        assert(True)

    assert(p.get_package_details() == None)


# Generated at 2022-06-20 18:44:13.260037
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["a", "b"]

        def get_package_details(self, pkg):
            return {"name": pkg, "version": "1.0"}

    tpm = TestPkgMgr()
    assert type(tpm.get_packages()) == dict
    assert sorted(list(tpm.get_packages().keys())) == sorted(["a", "b"])
    assert sorted(list(tpm.get_packages().values())) == sorted([[{"name": "a", "version": "1.0", "source": "testpkgmgr"}], [{"name": "b", "version": "1.0", "source": "testpkgmgr"}]])

# Generated at 2022-06-20 18:44:15.728437
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
  expected_obj_type = '<class \'ansible.module_utils.facts.virtual.CLIMgr\'>'
  assert str(type(CLIMgr())) == expected_obj_type

# Generated at 2022-06-20 18:44:17.082019
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class PkgMgrTest(PkgMgr):
        pass
    assert PkgMgr() == None

# Generated at 2022-06-20 18:44:20.379858
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    mgr = LibMgr()
    mgr.LIB = "test_lib"
    assert mgr.is_available() == False


# Generated at 2022-06-20 18:44:27.415263
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class Child(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return [1, 2, 3]

        def get_package_details(self, package):
            return {'name': 'name', 'version': 'version'}

    test = Child()

    assert test.get_packages() == {'name': [{'name': 'name', 'version': 'version', 'source': 'Child'}, {'name': 'name', 'version': 'version', 'source': 'Child'}, {'name': 'name', 'version': 'version', 'source': 'Child'}]}

# Generated at 2022-06-20 18:44:30.761171
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr.solaris import PkginMgr
    pm = PkginMgr()
    assert pm.is_available() == False



# Generated at 2022-06-20 18:44:41.786668
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    curr_pkg_mgr = PkgMgr()
    assert curr_pkg_mgr.get_package_details('none') is None


# Generated at 2022-06-20 18:44:50.507898
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class get_packages_PkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['a', 'b', 'c']
        def get_package_details(self, package):
            if package == 'a':
                return {'name': 'a', 'version': '1.0'}
            if package == 'b':
                return {'name': 'b', 'version': '2.0'}
            if package == 'c':
                return {'name': 'b', 'version': '3.0'}

    pkgmgr = get_packages_PkgMgr()

# Generated at 2022-06-20 18:44:54.504791
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    try:
        pkg_mgr = PkgMgr()
        assert pkg_mgr
    except TypeError:
        assert True


# Generated at 2022-06-20 18:45:03.336201
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common._utils import gimme_a_dict
    f = PkgMgr()
    f.list_installed = lambda: ['package_one', 'package_two']
    f.get_package_details = lambda x: gimme_a_dict(name=x, version='1.2.3')
    result = f.get_packages()
    expected = {
        'package_one': [{
            'name': 'package_one',
            'version': '1.2.3',
            'source': 'pkg_mgr',
        }],
        'package_two': [{
            'name': 'package_two',
            'version': '1.2.3',
            'source': 'pkg_mgr',
        }],
    }

# Generated at 2022-06-20 18:45:05.714967
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    pm = PkgMgr()
    try:
        result = pm.get_package_details('python')
    except NotImplementedError:
        result = 'NotImplementedError exception caught'
    return result


# Generated at 2022-06-20 18:45:07.725285
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class LibMgrX(LibMgr):
        LIB = 'xyz'

    m = LibMgrX()
    assert m._lib is None
    assert m.is_available() is False



# Generated at 2022-06-20 18:45:09.988201
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    with pytest.raises(TypeError):
        cli = PkgMgr()

# Generated at 2022-06-20 18:45:16.157603
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Test when import is successful
    assert ('libraries', 'importlib') in get_all_pkg_managers().items()

    test_LibMgr_is_available_obj = get_all_pkg_managers()['importlib']()
    assert test_LibMgr_is_available_obj.is_available()

    # Test when import unsuccessful
    test_LibMgr_is_available_obj.LIB = 'random'
    assert test_LibMgr_is_available_obj.is_available() is False


# Generated at 2022-06-20 18:45:20.641698
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        import packaging
        mngr = get_all_pkg_managers()['pipmgr']
        assert(mngr.is_available())
    except ImportError:
        print("Cannot test module 'packaging'."
              "To fix this, install package 'packaging'.")


# Generated at 2022-06-20 18:45:25.255630
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Initialize a dummy class
    class dummy():
        pass
    dummy_instance = dummy()
    return_dict = {}
    
    # Test the method
    assert(PkgMgr.get_package_details(dummy_instance, return_dict) is return_dict)


# Generated at 2022-06-20 18:45:45.627977
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    results = get_all_pkg_managers()
    assert isinstance(results, dict), "Result should be of type dict"
    assert len(results) >= 1, "Result should have at least 1 package manager"

# Generated at 2022-06-20 18:45:50.623049
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    class TestPkgMgrSubclass(PkgMgr):
        def __init__(self):
            self.installed_packages_list = ['test_package', 'test_package2']
            super(TestPkgMgrSubclass, self).__init__()

        def list_installed(self):
            return self.installed_packages_list

    assert TestPkgMgrSubclass().list_installed() == ['test_package', 'test_package2']



# Generated at 2022-06-20 18:45:52.436567
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # TODO: implement unit test
    assert 1 == 1


# Generated at 2022-06-20 18:45:56.000520
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pm = PkgMgr()
    installed_packages = pm.get_packages()
    # The class PkgMgr is abstract, so we should get a NotImplementedError
    assert installed_packages == None


# Generated at 2022-06-20 18:46:07.139761
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_native
    import os
    import tempfile
    test_file=tempfile.NamedTemporaryFile()
    path = to_bytes(os.path.abspath(test_file.name))
    test_object=CLIMgr()
    test_object._cli=path
    if isinstance(path, bytes):
        path = path.decode('utf-8')
    try:
        # is_available of CLIMgr returns True if CLI exists
        assert test_object.is_available() == True
        # Remove CLI and is_available of CLIMgr should return False
        os.remove(path)
        assert test_object.is_available() == False
    except:
        raise

# Generated at 2022-06-20 18:46:08.029019
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert False


# Generated at 2022-06-20 18:46:10.851738
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # get all subclasses of class PkgMgr
    implementations = [cls() for cls in get_all_subclasses(PkgMgr)]
    for impl in implementations:
        print(impl)
        assert(impl.is_available())

# Generated at 2022-06-20 18:46:21.425198
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Create an instance of the class 'LibMgr'
    test_subject = LibMgr()
    # Get the current value of the attribute '_lib'
    current_method_value = getattr(test_subject, "_lib")
    # Validate that the current value is None
    assert current_method_value == None
    # Assing a new value to the '_lib' attribute
    setattr(LibMgr, "_lib", "something")
    # Execute the method is_available and capture the result
    execute_method_result = test_subject.is_available()
    # Get the current value of the attribute '_lib'
    current_method_value = getattr(test_subject, "_lib")
    # Validate that the current value is not None
    assert current_method_value != None
    # Validate the result of the

# Generated at 2022-06-20 18:46:23.442049
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg=LibMgr()
    assert pkg
    assert isinstance(pkg, PkgMgr)


# Generated at 2022-06-20 18:46:26.788543
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert isinstance(pkg_mgrs, dict)
    assert len(pkg_mgrs) > 1
    for name in pkg_mgrs:
        assert isinstance(name, str)

# Generated at 2022-06-20 18:47:06.001692
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import shutil
    import tempfile
    import types

    # Save actual CLI executable so restore later
    find = get_bin_path('find')
    if not find:
        return

    # Create fake CLI executable
    fake_cli = tempfile.NamedTemporaryFile(prefix='package-test-cli')
    shutil.copy(find, fake_cli.name)

    # Parameter to instantiate the class
    cli = "find"

    # Unit test return value of constructor

# Generated at 2022-06-20 18:47:10.090079
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class FakePkgMgr(PkgMgr):

        def is_available(self):
            return

        def list_installed(self):
            return ['test_package_0.0.1', 'test_package_0.0.2']

        def get_package_details(self, package):
            package_details = {}
            splitted_package = package.split('_')
            package_details['name'] = splitted_package[0]
            package_details['version'] = splitted_package[1]
            return package_details

    test_pkgmgr = FakePkgMgr()
    installed_pkgs = test_pkgmgr.get_packages()
    assert 'test_package' in installed_pkgs
    assert len(installed_pkgs['test_package']) == 2


# Generated at 2022-06-20 18:47:18.896667
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def list_installed(self):
            return ['glu', 'glut']

        def get_package_details(self, package):
            return {'name': package, 'version': '3.1'}

    installed_packages = {'glu': [{'name': 'glu', 'version': '3.1', 'source': 'testpkgmgr'}],
                          'glut': [{'name': 'glut', 'version': '3.1', 'source': 'testpkgmgr'}]}
    tpm = TestPkgMgr()
    assert tpm.get_packages() == installed_packages, "The get_packages function does not return the expected result"

# Generated at 2022-06-20 18:47:25.736032
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    expected = {'status': 'success', 'reason': 'test'}
    class InstalledMock(LibMgr):
        def is_available(self):
            return True

    class NotInstalledMock(LibMgr):
        def is_available(self):
            return False

    installed = InstalledMock()
    not_installed = NotInstalledMock()
    assert installed.is_available() == True
    assert not_installed.is_available() == False


# Generated at 2022-06-20 18:47:33.901286
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Unit test to test method is_available of class PkgMgr
    # This class is an abstract class, so we can test only the method of the class.
    # For more details refer: https://stackoverflow.com/questions/1024847/add-a-method-to-an-existing-object-instance
    class SubTestPkgMgr(PkgMgr):
        def is_available(self):
            return True
    mgr = SubTestPkgMgr()
    assert mgr.is_available() is True


# Unit tests for class LibMgr

# Generated at 2022-06-20 18:47:35.686484
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pass



# Generated at 2022-06-20 18:47:36.330033
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr

# Generated at 2022-06-20 18:47:44.790071
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ['Package_1-1.0', 'Package_2-2.0', 'Package_2-2.1', 'Package_3-1.0']
        def get_package_details(self, package):
            split_package = package.split('-')
            return {'name': split_package[0], 'version': split_package[1]}

    package_manager = PkgMgrTest()


# Generated at 2022-06-20 18:47:48.421660
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class DummyPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['foo', 'bar']

        def get_package_details(self, package):
            return {
                'name': package,
                'version': '1.0.0'
            }

    pkg_mgr = DummyPkgMgr()
    result = pkg_mgr.get_packages()
    assert result == {'foo': [{'name': 'foo', 'version': '1.0.0', 'source': 'dummypkgmgr'}],
                      'bar': [{'name': 'bar', 'version': '1.0.0', 'source': 'dummypkgmgr'}]}

# Generated at 2022-06-20 18:47:57.970480
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    for pkg in get_all_pkg_managers():
        module = get_all_pkg_managers()[pkg]
        module = module()
        if module.is_available():
            for pkg in module.list_installed():
                print(module.get_package_details(pkg))
            # if module.PACKAGE_MANAGER == 'pacman':
            #     print(module.get_package_details('linux'))
            #     print(module.get_package_details('linux3'))
            #     print(module.get_package_details('pacman'))
            #     print(module.get_package_details('systemd'))
            #     print(module.get_package_details('linux-lts'))
            #     print(module.get_package_details('linux-lts'

# Generated at 2022-06-20 18:49:35.100635
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_dict = {"name" : "test_package", "version" : "1.0", "source" : "test_pkg_mgr"}
    assert pkg_dict == PkgMgr().get_package_details("test_package")

# Generated at 2022-06-20 18:49:40.837054
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.facts import cap_facts

    class TestCLIMgr(CLIMgr):
        CLI = 'test'
    def test_func(x):
        cap_facts['ansible_facts']['test'] = x
        return cap_facts['ansible_facts']['test']

    cap_facts['ansible_facts']['test'] = 'Not_Exists'
    assert not TestCLIMgr().is_available()

    cap_facts['ansible_facts']['test'] = test_func('Exists')
    assert TestCLIMgr().is_available()

# Generated at 2022-06-20 18:49:51.250461
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):
        def __init__(self):
            self.list_installed_val = None
            self.get_package_details_val = None
            super(MockPkgMgr, self).__init__()

        def list_installed(self):
            return self.list_installed_val

        def get_package_details(self, package):
            return self.get_package_details_val

    manager = MockPkgMgr()
    manager.list_installed_val = ['package1', 'package2']
    manager.get_package_details_val = {'name': 'name1', 'version': 'version1'}


# Generated at 2022-06-20 18:49:52.048943
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers()

# Generated at 2022-06-20 18:49:55.290945
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import mock
    MyMgr = type('MyMgr', (PkgMgr,), {
        "__doc__": PkgMgr.__doc__,
        "is_available": lambda self: True
    })
    # Create instance
    mgr = MyMgr()
    assert mgr.is_available() is True

# Generated at 2022-06-20 18:49:58.560010
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class MockPkgMgr(PkgMgr):
        def list_installed(self):
            return ["a_package","another_package"]
        def get_package_details(self,package):
            return {"name":package}
    pkg_mgr = MockPkgMgr()
    assert pkg_mgr.get_packages() == {'a_package': [{'name': 'a_package'}], 'another_package': [{'name': 'another_package'}]}

# Generated at 2022-06-20 18:50:02.822704
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    l = LibMgr()
    l.LIB = "json"
    assert l.is_available() == True
    l.LIB = "json_not_exists"
    assert l.is_available() == False


# Generated at 2022-06-20 18:50:07.224246
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmgr_a = PkgMgr()
    try:
        pkgmgr_a.get_package_details('abc')
    except NotImplementedError as e:
        print('NotImplementedError: %s' % e)
    except RuntimeError as e:
        print('RuntimeError: %s' % e)


# Generated at 2022-06-20 18:50:08.048719
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    _pm = PkgMgr()



# Generated at 2022-06-20 18:50:09.909286
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libMgr = LibMgr()
    assert libMgr._lib == None
