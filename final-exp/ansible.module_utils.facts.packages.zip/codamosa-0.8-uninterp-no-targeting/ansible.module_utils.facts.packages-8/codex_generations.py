

# Generated at 2022-06-20 18:40:52.220981
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_get_packages_Test(PkgMgr):
        def is_available(self):
            return True
        def get_package_details(self, package):
            return {
                'name': package,
                'version': '1.0',
                'source': 'test'
            }
        def list_installed(self):
            return ['dummy_package_1', 'dummy_package_2']
    result = PkgMgr_get_packages_Test().get_packages()
    # Expected value: {'dummy_package_1': [{'name': 'dummy_package_1', 'version': '1.0', 'source': 'test'}], 'dummy_package_2': [{'name': 'dummy_package_2', 'version': '1.0', 'source

# Generated at 2022-06-20 18:41:03.373361
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers) > 0
    assert 'rpm' in pkg_managers
    assert 'deb' in pkg_managers
    assert 'homebrew' in pkg_managers
    assert 'macports' in pkg_managers
    assert 'emerge' in pkg_managers
    assert 'pkgutil' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'pkg_info' in pkg_managers
    assert 'pip' in pkg_managers
    assert 'gem' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'yum' in pkg_managers

# Generated at 2022-06-20 18:41:09.717847
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    results = get_all_pkg_managers()
    assert 'apt' in results
    assert 'yum' in results
    assert 'dnf' in results
    assert 'zypper' in results
    assert 'pacman' in results
    assert 'portage' in results
    assert 'apk' in results
    assert 'emerge' in results

# Generated at 2022-06-20 18:41:16.867572
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Create an instance of PkgMgr's subclass, e.g. CLIMgr
    pkg_mgr = CLIMgr()
    # Assert that list_installed method raises a NotImplementedError
    try:
        pkg_mgr.list_installed()
        raise AssertionError('{0} is not implemented'.format(pkg_mgr.__class__.__name__))
    except NotImplementedError:
        pass


# Generated at 2022-06-20 18:41:25.927061
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from distutils.version import LooseVersion
    from ansible.module_utils._text import to_native

    package_manager_classes = get_all_pkg_managers()
    for name, class_name in package_manager_classes.items():
        package_manager = class_name()
        if package_manager.is_available():
            package_details_list = package_manager.get_packages()
            assert all([isinstance(package_details['name'], to_native(str))
                        and isinstance(package_details['version'], LooseVersion)
                        for package in package_details_list.values()
                        for package_details in package])

# Generated at 2022-06-20 18:41:27.842366
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    instance = PkgMgr()
    # for abstract method, can only use as parameter of isinstance()
    assert isinstance(instance, PkgMgr)



# Generated at 2022-06-20 18:41:29.277009
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    asser = CLIMgr()
    assert asser is not None

# Generated at 2022-06-20 18:41:33.617325
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass_pkgs = ['vim', 'apt', 'sysvinit']
    fail_pkgs = ['yum', 'apt-get', 'rpm', 'dpkg']
    expected_("test_PkgMgr_list_installed", True, pass_pkgs, fail_pkgs)


# Generated at 2022-06-20 18:41:35.929959
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    yum_mgr = CLIMgr()
    assert yum_mgr.is_available() == False


# Generated at 2022-06-20 18:41:38.135355
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # unit test for method is_available of class PkgMgr
    assert(1 == 1)

# Generated at 2022-06-20 18:41:42.254663
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass



# Generated at 2022-06-20 18:41:44.459587
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert hasattr(PkgMgr, 'list_installed')


# Generated at 2022-06-20 18:41:48.545249
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.package_manager import PkgMgr

    pkg=PkgMgr()
    result = pkg.is_available()
    assert result == False


# Generated at 2022-06-20 18:41:57.044230
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class FakePkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['a', 'b', 'c']

        def get_package_details(self, package):
            if package == 'a':
                return {'name': 'somename', 'version': '1.0', 'source': 'somesource'}
            elif package == 'b':
                return {'name': 'somename'}
            elif package == 'c':
                return {'name': 'somename', 'version': '2.0'}

    fake_pkgmgr = FakePkgMgr()
    packages = fake_pkgmgr.get_packages()

    assert 'somename' in packages[0]

# Generated at 2022-06-20 18:42:07.703177
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    import unittest

    class MockPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['pkg1', 'pkg2', 'pkg3']

        def get_package_details(self, package):
            if package == 'pkg1':
                return {'name': 'pkg1', 'version': '1.0.0', 'source': 'foo'}
            if package == 'pkg2':
                return {'name': 'pkg2', 'version': '1.0.1'}
            if package == 'pkg3':
                return {'name': 'pkg3', 'version': '1.0.2'}


# Generated at 2022-06-20 18:42:10.937157
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    # Instantiate class PkgMgr, check if __init__ function is called.
    # init function of PkgMgr class is empty
    pm = PkgMgr()
    #return pm

# Generated at 2022-06-20 18:42:11.642374
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    PkgMgr()

# Generated at 2022-06-20 18:42:19.688117
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    global PkgMgr

    class PkgMgr(PkgMgr):
        pass

    class Test1(PkgMgr):
        pass

    class Test2(PkgMgr):
        pass

    class Test3(Test1):
        pass

    assert len(get_all_pkg_managers().keys()) == 2
    assert 'test1' in get_all_pkg_managers().keys()
    assert 'test2' in get_all_pkg_managers().keys()
    assert isinstance(get_all_pkg_managers()['test1'](), Test1)
    assert isinstance(get_all_pkg_managers()['test2'](), Test2)

# Generated at 2022-06-20 18:42:30.819092
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import distribution as distribution_fact

    d = Distribution()
    d.name = 'test'
    class TestMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['test.test', 'test.test2']

        def get_package_details(self, package):
            return dict(name=package.split('.')[1], version=package.split('.')[0])


# Generated at 2022-06-20 18:42:32.929906
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # is_available should return either True or False
    assert CLIMgr().is_available() in (True, False)



# Generated at 2022-06-20 18:42:43.823254
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class CLIMgr_Test(CLIMgr):
        CLI = 'test'

    assert CLIMgr_Test.CLI == 'test'
    CLIMgr_Test_object = CLIMgr_Test()
    assert CLIMgr_Test_object._cli is None


# Generated at 2022-06-20 18:42:44.461051
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-20 18:42:49.310171
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg_mgr = LibMgr()
    assert pkg_mgr.LIB is None
    assert pkg_mgr._lib is None
    assert pkg_mgr.is_available() is False


# Generated at 2022-06-20 18:42:59.620856
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import os
    try:
        import syslog
    except ImportError:
        # need to mock syslog
        class syslog:
            class syslog:
                def __init__(self):
                    pass
                def closelog(self):
                    pass
                def openlog(self, *args):
                    pass
                def is_open(self):
                    return False
                def log(self, *args):
                    pass
                def setlogmask(self, *args):
                    pass
                def __call__(self, *args):
                    pass
                def __enter__(self):
                    return self
                def __exit__(self, type, value, traceback):
                    pass

# Generated at 2022-06-20 18:43:02.112706
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_class = LibMgr()
    assert test_class._lib is None



# Generated at 2022-06-20 18:43:05.573252
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestPkgMgr(CLIMgr):
        CLI = 'test_CLIMgr_is_available'
    test_pkg_mgr = TestPkgMgr()
    assert not test_pkg_mgr.is_available()



# Generated at 2022-06-20 18:43:11.853939
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            return ['pkg1', 'pkg2']

    dummy_package_manager = DummyPkgMgr()
    assert len(dummy_package_manager.list_installed()) == 2


# Generated at 2022-06-20 18:43:14.540064
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class mock_CLIMgr(CLIMgr):
        CLI = 'mock'

    c = mock_CLIMgr()
    assert c.is_available() is False

# Generated at 2022-06-20 18:43:17.117901
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers.keys()) > 1
    assert 'yumpm' in pkg_managers.keys()

# Generated at 2022-06-20 18:43:18.911320
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert PkgMgr().get_package_details('test') == None


# Generated at 2022-06-20 18:43:34.616256
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    p = PkgMgr()
    assert(p)

# Generated at 2022-06-20 18:43:37.916982
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class PkgMgrTest(PkgMgr):
        @staticmethod
        def is_available():
            return False

    mgr = PkgMgrTest()
    assert mgr.is_available() is False


# Generated at 2022-06-20 18:43:41.039690
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'ansible_pkg_mgrs_lib'
    lm = TestLibMgr()
    assert lm.is_available() is True
    assert lm._lib is not None

# Generated at 2022-06-20 18:43:47.687327
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'my_package_manager'

    path = '/usr/bin/my_package_manager'
    assert TestCLIMgr().is_available() is False, 'error in CLIMgr.is_available: without path should fail with False'

    import module_utils.common.process
    module_utils.common.process.get_bin_path = lambda x: path
    assert TestCLIMgr().is_available() is True, 'error in CLIMgr.is_available: with path should succeed with True'
    del module_utils.common.process

# Generated at 2022-06-20 18:43:58.862794
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2', 'package3', 'package3']

        def get_package_details(self, package):
            return {'name': package}

    TestPkgMgr_obj = TestPkgMgr()
    TestPkgMgr_obj_result = TestPkgMgr_obj.get_packages()

    assert TestPkgMgr_obj_result == {'package1': [{'name': 'package1'}], 'package2': [{'name': 'package2'}], 'package3': [{'name': 'package3'}, {'name': 'package3'}]}

# Generated at 2022-06-20 18:44:00.253587
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    res = PkgMgr().is_available()
    assert res == False

# Generated at 2022-06-20 18:44:08.028326
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    import json
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.package.pkg_managers.apt import AptFactCollector
    from ansible.module_utils.facts.collectors.package.pkg_managers.apk import ApkFactCollector
    from ansible.module_utils.facts.collectors.package.pkg_managers.dnf import DnfFactCollector
    from ansible.module_utils.facts.collectors.package.pkg_managers.pkg import PkgFactCollector

# Generated at 2022-06-20 18:44:11.045549
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """Test if method list_installed of class PkgMgr exists"""
    try:
        PkgMgr.list_installed(PkgMgr)
    except AttributeError:
        return False
    else:
        return True


# Generated at 2022-06-20 18:44:12.560168
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class_object = LibMgr()
    assert class_object.is_available() is False

# Generated at 2022-06-20 18:44:19.923840
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    def is_available(pm):
        try:
            return pm().is_available()
        except Exception:
            return False

    # Test that the Python package manager works
    assert(is_available(PkgMgr))

    # Test that the Python package manager using the abstract method list_installed works
    class PkgMgr_list_installed(PkgMgr):
        def list_installed(self):
            return []
    assert(is_available(PkgMgr_list_installed))

    # Test that the Python package manager using the abstract method get_package_details works
    class PkgMgr_get_package_details(PkgMgr):
        def get_package_details(self, package):
            return {'name':'test', 'version':'test', 'source':'test'}

# Generated at 2022-06-20 18:44:49.030851
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert not PkgMgr().is_available()


# Generated at 2022-06-20 18:44:55.278719
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    #no exception expected
    class ExTestPkgMgr(PkgMgr):
        def is_available(self):
            pass
    t = ExTestPkgMgr()
    try:
        t.is_available()
    except:
        assert False


# Generated at 2022-06-20 18:45:01.398970
# Unit test for constructor of class LibMgr
def test_LibMgr():
    from ansible.module_utils.common.collections import ImmutableDict
    class Foo(LibMgr):
        LIB = 'bar'

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return ImmutableDict({'name': 'foo', 'version': '1.2'})
    foo = Foo()
    assert foo.LIB == 'bar'
    assert foo._lib is None


# Generated at 2022-06-20 18:45:03.190941
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class LibMgrTest(LibMgr):
        LIB = "test"

    LibMgrTest()



# Generated at 2022-06-20 18:45:04.741554
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    is_instance = isinstance(get_all_pkg_managers(), dict)
    assert is_instance is True

# Generated at 2022-06-20 18:45:06.200699
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    assert a.CLI == None
    assert a._cli == None


# Generated at 2022-06-20 18:45:07.395331
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    assert c is not None
    assert c._cli is None

# Generated at 2022-06-20 18:45:11.533845
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return ["foo", "bar"]

        def get_package_details(self, package):
            return {"name": package, "version": "0.0.0", "source": "my_pkg_mgr"}

    pmt = PkgMgrTest()
    packages = pmt.get_packages()
    assert(len(packages) == 2)
    assert("foo" in packages)
    assert("bar" in packages)

# Generated at 2022-06-20 18:45:13.081447
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgr_Test_class(CLIMgr):
        CLI = 'python3'
    assert CLIMgr_Test_class().is_available()

# Generated at 2022-06-20 18:45:17.738523
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    """
    Test function for method get_package_details of class PkgMgr.
    """
    # Test the correct operation of the method get_package_details of class PkgMgr,
    # when it is executed with a correct parameter (valid package name)
    pkg = "openssl"
    pkg_mgr = PkgMgr()
    assert pkg_mgr.get_package_details(pkg) == None

# Generated at 2022-06-20 18:46:19.700308
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'

    test_cli = TestCLIMgr()
    assert test_cli.is_available() == True

# Generated at 2022-06-20 18:46:20.929243
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplementedError


# Generated at 2022-06-20 18:46:22.094435
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() is False


# Generated at 2022-06-20 18:46:23.804683
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.facts.collector import CLIMgr

    cm = CLIMgr()
    assert cm._cli is None

# Generated at 2022-06-20 18:46:24.288565
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-20 18:46:26.136820
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        a = LibMgr()
    except:
        assert False
    assert True


# Generated at 2022-06-20 18:46:32.948540
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # This is just a test to make sure we discover all the classes
    pkg_managers = get_all_pkg_managers()
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'portage' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'opkg' in pkg_managers
    assert 'eopkg' in pkg_managers
    assert 'pkgin' in pkg_managers
    assert 'pkg' in pkg_managers


# Generated at 2022-06-20 18:46:34.060595
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_mgr = CLIMgr()

    assert(test_mgr is not None)


# Generated at 2022-06-20 18:46:39.396132
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Here we define an ad-hoc implementation of LibMgr used only for
    # unittesting purposes
    class MyLibMgr(LibMgr):
        LIB = 're'

    manager = MyLibMgr()
    assert manager.is_available()



# Generated at 2022-06-20 18:46:41.417993
# Unit test for constructor of class LibMgr
def test_LibMgr():
    p = LibMgr()

    assert p.LIB is None

# Generated at 2022-06-20 18:49:22.265470
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrMock(PkgMgr):
        def __init__(self):
            super(PkgMgrMock, self).__init__()
            self.packages = [
                {'name': 'foo', 'version': '1.0.0'},
                {'name': 'bar', 'version': '1.0.0'},
                {'name': 'foo', 'version': '2.0.0'},
                {'name': 'baz', 'version': '1.0.0'},
            ]

        def is_available(self):
            return True

        def get_package_details(self, package):
            return package

        def list_installed(self):
            return self.packages

    pkg_mgr = PkgMgrMock()
    assert pkg_mgr

# Generated at 2022-06-20 18:49:27.703001
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Instance of class PkgMgr
    class fake_pkg_mgr_class(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['foo', 'bar']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    mgr = fake_pkg_mgr_class()
    # call get_packages method
    packages = mgr.get_packages()
    assert len(packages) == 2
    assert 'foo' in packages
    assert 'bar' in packages
    assert packages['foo'][0]['name'] == 'foo'
    assert packages['foo'][0]['version'] == '1.0'

# Generated at 2022-06-20 18:49:29.115575
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    get_all_pkg_managers().values()
    pass



# Generated at 2022-06-20 18:49:33.181555
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class TestPkgMgr(CLIMgr):
        CLI = 'test_package_manager'

    test_package_manager = TestPkgMgr()

    assert test_package_manager.is_available() == False



# Generated at 2022-06-20 18:49:34.825303
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert obj.is_available() is None


# Generated at 2022-06-20 18:49:37.318043
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class LibMgr_test(LibMgr):
        LIB = 'os'

    libmgr_test = LibMgr_test()
    assert libmgr_test.is_available()


# Generated at 2022-06-20 18:49:38.694855
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_mgr = LibMgr()
    assert test_mgr._lib is None


# Generated at 2022-06-20 18:49:42.888537
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    success_test_data = {
        'some-program': '/usr/bin/some-program',
        'some-program-which-does-not-exist': ValueError
    }
    for test_path, expected in success_test_data.items():
        class CLIMgr_Ima_Mock():
            CLI = test_path
        instance = CLIMgr_Ima_Mock()
        if expected == ValueError:
            assert not instance.is_available()
        else:
            assert instance.is_available()
            assert instance._cli == expected

# Generated at 2022-06-20 18:49:45.060777
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj is not None


# Generated at 2022-06-20 18:49:54.535592
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # Testing the PkgMgr.get_packages method

    pkg_manager_list = get_all_pkg_managers()

    # Testing all Package managers that do not need to be installed on the host
    for manager_name, manager in (manager for manager in pkg_manager_list.items() if manager[1]().is_available()):
        installed_packages = manager().get_packages()
        for package_name, package_list in installed_packages.items():
            for package in package_list:
                assert 'name' in package and 'version' in package and 'source' in package, \
                    'The Package %s of Package manager %s is missing required metadata.' % (package, manager_name)