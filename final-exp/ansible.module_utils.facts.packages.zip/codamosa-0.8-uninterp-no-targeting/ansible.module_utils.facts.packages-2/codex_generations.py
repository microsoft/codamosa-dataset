

# Generated at 2022-06-20 18:40:49.229211
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.packages.apt import AptFactCollector

    package_manager_count = len(get_all_pkg_managers())
    assert package_manager_count >= 6

    AptFactCollector.CLI = '/true'
    get_bin_path = lambda x: '/true'

    package_manager_count = len(get_all_pkg_managers())
    assert package_manager_count == 1

# Generated at 2022-06-20 18:41:00.600674
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class mgr(CLIMgr):
        CLI = 'test_mgr'
    mgr_obj = mgr()

    #CLI is present in PATH, is_available should return True'
    def test_is_available_true():
        try:
            get_bin_path_mock = MagicMock(return_value='test_mgr')
            mgr.get_bin_path = get_bin_path_mock
            assert mgr_obj.is_available()
        except Exception:
            assert False

        #CLI is not present in PATH, is_available should return False'

# Generated at 2022-06-20 18:41:01.426849
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr is LibMgr()


# Generated at 2022-06-20 18:41:02.966545
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr.is_available()


# Generated at 2022-06-20 18:41:10.076690
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts.system.pkg_mgr import createPkgMgr

    test_mgr = createPkgMgr('dnf', 'fedora', '24')
    test_mgr.get_package_details('passwd')
    assert test_mgr.get_package_details('passwd')['name'] == 'passwd'

# Generated at 2022-06-20 18:41:11.830959
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert issubclass(PkgMgr, object)


# Generated at 2022-06-20 18:41:18.490757
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # given a valid class named TestPkgMgr that inherits from LibMgr,
    # when is_available method is called, then return value must be kind of True or False
    # and the reference self._lib is not None
    class TestPkgMgr(LibMgr):
        LIB = 'sys'
    pkgmgr = TestPkgMgr()
    assert type(pkgmgr.is_available()) is bool
    assert pkgmgr._lib is not None


# Generated at 2022-06-20 18:41:25.654854
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    example_testing = dict()
    example_testing['abstact'] = PkgMgr
    example_testing['libmgr'] = LibMgr
    example_testing['climgr'] = CLIMgr
    example_testing['cli_package'] = CLIPkg
    example_testing['lib_package'] = CLIPkg
    example_testing['ios_package'] = CLIPkg
    example_testing['ios_facts'] = CLIPkg
    assert get_all_pkg_managers() == example_testing

# Generated at 2022-06-20 18:41:26.962244
# Unit test for constructor of class LibMgr
def test_LibMgr():
    a = LibMgr()
    assert a._lib == None


# Generated at 2022-06-20 18:41:28.517760
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    assert mgr

# Generated at 2022-06-20 18:41:35.133696
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr.__name__ == "CLIMgr"
    assert CLIMgr.__bases__ == (PkgMgr,)

# Generated at 2022-06-20 18:41:45.296310
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common import get_all_pkg_managers
    from ansible.module_utils.common.collections import ImmutableDict

# Generated at 2022-06-20 18:41:50.610441
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    class LibMgr_test_is_available(LibMgr):
        LIB = 'ansible.module_utils.basic'
    libmgr_test_is_available = LibMgr_test_is_available()
    assert libmgr_test_is_available.is_available()


# Generated at 2022-06-20 18:41:58.311400
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = [
        "AptPkgMgr",
        "FreeBsdPkgMgr",
        "PkgUtilMgr",
        "PortagePkgMgr",
        "YumPkgMgr",
    ]
    for k, v in get_all_pkg_managers().items():
        assert v.__name__ in pkg_managers
        del pkg_managers[pkg_managers.index(v.__name__)]

    assert len(pkg_managers) == 0

# Generated at 2022-06-20 18:42:00.023250
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr is not None

# Generated at 2022-06-20 18:42:08.874385
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def __init__(self):
            self.packages = {
                "package1": [{'name': 'package1', 'first': 'value1', 'last': 'value1'}, {'name': 'package1', 'first': 'value2', 'last': 'value2'}],
                "package2": [{'name': 'package2', 'first': 'value3', 'last': 'value3'}, {'name': 'package2', 'first': 'value4', 'last': 'value4'}],
            }
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            # Getting keys from the class attribute packages
            return list(self.packages.keys())

# Generated at 2022-06-20 18:42:13.385680
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class TestCLIMgr(CLIMgr):
        CLI = "test_test"
        def list_installed(self):
            return [1]
        def get_package_details(self, package):
            return {"name": package, "version": 1}

    assert TestCLIMgr().is_available()

# Generated at 2022-06-20 18:42:14.415637
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()


# Generated at 2022-06-20 18:42:22.400241
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.collectors import pkg_mgr_rpm
    from ansible.module_utils.facts.collectors import pkg_mgr_apt
    from ansible.module_utils.facts.collectors import pkg_mgr_yum
    from ansible.module_utils.facts.collectors import pkg_mgr_zypper
    from ansible.module_utils.facts.collectors import pkg_mgr_pkgng
    from ansible.module_utils.facts.collectors import pkg_mgr_apk
    pkg_mgr_rpm_instance = pkg_mgr_rpm.RpmMgr()
    pkg_mgr_apt_instance = pkg_mgr_apt.AptMgr()
    pkg_mgr_yum_instance = p

# Generated at 2022-06-20 18:42:24.033513
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
  assert CLIMgr().is_available() == False


# Generated at 2022-06-20 18:42:30.718369
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    assert pm.get_package_details("package") == {}

# Generated at 2022-06-20 18:42:32.231702
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    result = CLIMgr().is_available()
    assert result == False

# Generated at 2022-06-20 18:42:34.608716
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    def test():
        if PkgMgr not in get_all_pkg_managers():
            raise TypeError('PkgMgr not in package managers')

    test()



# Generated at 2022-06-20 18:42:35.925634
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()


# Generated at 2022-06-20 18:42:36.878144
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm

# Generated at 2022-06-20 18:42:39.895710
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    CLI = 'ls'
    obj = CLIMgr()
    obj.CLI = CLI



# Generated at 2022-06-20 18:42:49.342378
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    import sys
    import types

    class ApmPkgMgr(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    class ApmLibMgr(LibMgr):
        LIB = "libyaml"

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    class ApmCLIMgr(CLIMgr):
        CLI = "apm"

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    # check Function
    pkg_managers = get_all_pkg_managers()
    assert(isinstance(pkg_managers, dict))
   

# Generated at 2022-06-20 18:42:59.667333
# Unit test for function get_all_pkg_managers

# Generated at 2022-06-20 18:43:03.677089
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # Test Exception handling
    class TestMgr(LibMgr):
        # Test Exception handling
        LIB = "not_available"

    my = TestMgr()
    my.is_available()
    return my


# Generated at 2022-06-20 18:43:06.527572
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestMgr(CLIMgr):
        CLI = 'test_cli'
    test = TestMgr()
    test.is_available()
    assert isinstance(test._cli, str)
    assert test._cli == 'test_cli'

# Generated at 2022-06-20 18:43:16.994547
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().__class__.__name__ is "LibMgr"


# Generated at 2022-06-20 18:43:20.635291
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.software_management.pkg_managers.yum import LibYum
    l = LibYum()
    assert l.is_available() == False


# Generated at 2022-06-20 18:43:30.479671
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [1,2,3]
        
        def get_package_details(self, package):
            return {'name': package, 'version': '1.1'}
    pmgr = PkgMgrTest()
    result = pmgr.get_packages()

# Generated at 2022-06-20 18:43:41.804448
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestMgr(PkgMgr):

        def __init__(self):
            self.installed_packages = [{'name':'test1', 'version':'1.0'}, {'name':'test2', 'version':'2.0'}]
            super(TestMgr, self).__init__()

        def is_available(self):
            return True

        def list_installed(self):
            return self.installed_packages

        def get_package_details(self, package):
            return package

    test_mgr = TestMgr()
    assert test_mgr.get_packages() == {'test1':[{'name':'test1', 'version':'1.0'}], 'test2':[{'name':'test2', 'version':'2.0'}]}

# Generated at 2022-06-20 18:43:49.522186
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    import unittest

    from ansible.module_utils.common.process import get_bin_path

    class FakePkgMgr(PkgMgr):

        def is_available(self):

            self.found = True

        def list_installed(self):
            self.issued_call = True
            return ['pkg1', 'pkg2', 'pkg3']

        def get_package_details(self, package):

            return {'name': package}

    class MyTest(unittest.TestCase):
        def test_PkgMgr_list_installed(self):

            pkg = FakePkgMgr()
            pkg.is_available()
            self.assertTrue(pkg.found, 'is_available should return true')

# Generated at 2022-06-20 18:43:51.396939
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr._lib == None, "Constructor of class LibMgr failed to initialize attribute _lib with None"

# Generated at 2022-06-20 18:43:55.917959
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    args = dict(
        CLI='apt',
    )
    obj = CLIMgr()
    cli = obj.CLI
    assert isinstance(cli,str)
    assert cli == args['CLI']
    assert obj.is_available() is True


# Generated at 2022-06-20 18:44:01.153081
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # Case where the library is present
    class MyLibMgr(LibMgr):
        LIB = "os"
    manager = MyLibMgr()
    assert(manager.is_available())

    # Case where the library is not present
    class MyLibMgr(LibMgr):
        LIB = "mylib"
    manager = MyLibMgr()
    assert(not manager.is_available())


# Generated at 2022-06-20 18:44:07.068020
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible_collections.ansible.community.plugins.module_utils.distro import BaseDistro, Distro

    mock_distro_info = {'family': '', 'release': '', 'codename': '', 'id': '', 'like': ''}

    class MockDistro(Distro):

        def __init__(self, name, release, version, id, like=None, lib=None):
            super(MockDistro, self).__init__()
            self.name = name
            self.release = release
            self.version_tuple = version
            self.id = id

# Generated at 2022-06-20 18:44:14.988868
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    '''The method list_installed should return a list'''
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['a', 'b']
        def get_package_details(self, package):
            # This takes a 'package' item and returns a dictionary with the package information, name and version are minimal requirements
            return {'name': package}
    tpm = TestPkgMgr()
    result = tpm.list_installed()
    assert type(result) == list
    assert result[0] == 'a'
    assert result[1] == 'b'


# Generated at 2022-06-20 18:44:36.223068
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class MockPkgMgr(PkgMgr):
        def is_available(self):
            return True

    pkg_mgr = MockPkgMgr()
    assert pkg_mgr.is_available()


# Generated at 2022-06-20 18:44:36.954307
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
  pass

# Generated at 2022-06-20 18:44:38.728910
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_obj = CLIMgr()
    assert test_obj.CLI is None


# Generated at 2022-06-20 18:44:45.071310
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        pass

    # Test with an ephemeral subclass
    TestLibMgr.LIB = 'ansible.module_utils.six'
    mgr = TestLibMgr()
    assert mgr.is_available() == True

    TestLibMgr.LIB = 'ansible.module_utils.pyNoise'
    mgr = TestLibMgr()
    assert mgr.is_available() == False


# Generated at 2022-06-20 18:44:46.349953
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr.is_available(LibMgr) == True


# Generated at 2022-06-20 18:44:47.842241
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    x = LibMgr()  # TODO: Set up mock library
    assert x.is_available()


# Generated at 2022-06-20 18:44:56.445592
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """ is_available method should be overridden.
    It should either return True, or return False if an error occurs.
    An exception should not be raised.
    """
    try:
        PkgMgr().is_available()
    except NotImplementedError:
        pass
    except Exception as e:
        assert False, 'is_available must raise NotImplementedError, not {}'.format(e.__class__)
    else:
        assert False, 'is_available must raise NotImplementedError'

# Generated at 2022-06-20 18:45:00.167817
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    try:
        obj._lib = __import__("apt")
    except:
        obj._lib = None
    if obj._lib is None:
        assert obj.is_available() is False
    else:
        assert obj.is_available() is True


# Generated at 2022-06-20 18:45:08.739007
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    subs = {}
    class MockPkgMgr(PkgMgr):
        def list_installed(self):
            subs.setdefault('list_installed', 0)
            subs['list_installed'] += 1
            return ['a', 'b-1.0', 'a-2.0', 'b-2.0']
        def get_package_details(self, package):
            subs.setdefault('get_package_details', 0)
            subs['get_package_details'] += 1
            return {'name': package.split('-', 1)[0], 'version': package.split('-', 1)[1]}
    pkg_mgr = MockPkgMgr()
    pkgs = pkg_mgr.get_packages()
    assert 'a' in pkgs

# Generated at 2022-06-20 18:45:19.361527
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.facts.pkg_mgr.yumpkg import YumPkg

    class PkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ["package1-1.0", "package2-2.0", "package1-3.0"]

        def get_package_details(self, package):
            return {"name": package.split("-")[0], "version": package.split("-")[1]}

    pkgmgr = PkgMgr()
    packages = pkgmgr.get_packages()

# Generated at 2022-06-20 18:45:59.697708
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available()  is False


# Generated at 2022-06-20 18:46:00.558064
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    assert False, "This is only a stub"

# Generated at 2022-06-20 18:46:02.507323
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_obj = PkgMgr()
    assert test_obj.get_packages() == {}


# Generated at 2022-06-20 18:46:11.779657
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class TestPkgMgr(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            return ['one', 'two', 'three', 'three', 'three']

        def get_package_details(self, package):
            # each item in list_installed will be passed to this method
            details = {}
            details['name'] = package
            details['version'] = "1.0"
            return details

    tpmg = TestPkgMgr()
    packages = tpmg.get_packages()
    assert len(packages) == 3
    assert len(packages['one']) == 1
    assert len(packages['two']) == 1
    assert len(packages['three']) == 3

# Generated at 2022-06-20 18:46:14.735523
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    result = LibMgr.is_available()
    assert (result == True)


# Generated at 2022-06-20 18:46:16.100899
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert pkg is not None


# Generated at 2022-06-20 18:46:18.864976
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    """
    Test that get_all_pkg_managers returns all classes inherited
    from PkgMgr
    """
    assert isinstance(get_all_pkg_managers(), dict)
    asse

# Generated at 2022-06-20 18:46:27.251878
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    try:
        from ansible.module_utils.common._utils import get_all_subclasses
        from ansible.module_utils.common.collections import ImmutableDict
    except ImportError:
        pass
    class A(PkgMgr):  # This class is not inherited from CLIMgr and LibMgr class
        pass
    class B(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return package
    objA = A()
    d = {'name': 'A', 'version': '1.0', 'source': 'A'}

# Generated at 2022-06-20 18:46:33.869250
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class MyCLI(CLIMgr):

        CLI = 'mycli'

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package}

    class MyLib(LibMgr):

        LIB = 'mylib'

        def list_installed(self):
            return ['package3', 'package4']

        def get_package_details(self, package):
            return {'name': package}


# Generated at 2022-06-20 18:46:37.216013
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj._lib == None

# Generated at 2022-06-20 18:48:05.346809
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm is not None


# Generated at 2022-06-20 18:48:10.393439
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class testmgr(PkgMgr):
        def __init__(self):
            super(testmgr, self).__init__()
            self.installed = {'A':1, 'B':2, 'C':3}
            pass

        def is_available(self):
            return self.installed
            pass

        def list_installed(self):
            return self.installed
            pass

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    mgr = testmgr()
    packages = mgr.list_installed()
    ret = 1
    if mgr.installed == packages:
        ret = 0
    return ret


# Generated at 2022-06-20 18:48:14.057326
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_mgr = CLIMgr()
    assert test_mgr._cli is None


# Generated at 2022-06-20 18:48:16.878942
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    pm.list_installed = lambda: ["a"]
    pm.get_package_details = lambda pkg: {"name": pkg}
    assert pm.get_packages() == {"a": [{"name": "a", "source": "pkgmgr"}]}

# Generated at 2022-06-20 18:48:27.531034
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    # test case 1
    import ansible.module_utils.common.process
    class TestClass:
        def get_bin_path(self, bin):
            return "test-path"
    ansible.module_utils.common.process.get_bin_path = TestClass()
    from ansible.module_utils.common._collections_compat import MutableMapping
    class TestClass2(MutableMapping):
        def __init__(self, *args, **kwargs):
            self.__dict__.update(*args, **kwargs)
        def __getitem__(self, key):
            return self.__dict__[key]
        def __setitem__(self, key, value):
            self.__dict__[key] = value

# Generated at 2022-06-20 18:48:31.811443
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    pkgmgr = PkgMgr()
    package = {}
    package_details = pkgmgr.get_package_details(package)
    assert package_details == package


# Generated at 2022-06-20 18:48:33.400773
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgMgr = PkgMgr()
    assert pkgMgr


# Generated at 2022-06-20 18:48:35.229538
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()
    assert obj.__class__.__name__ == 'PkgMgr'

# Generated at 2022-06-20 18:48:40.537408
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class TestMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ["package1"]
        def get_package_details(self, package):
            return {"name": "package1", "version": {"full": "1.0.0"}}

    pkg_mgr = TestMgr()
    packages = pkg_mgr.get_packages()
    assert packages["package1"][0]["version"]["full"] == "1.0.0"

# Generated at 2022-06-20 18:48:44.129475
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import sys
    sys.modules['__main__'].__file__ = 'test_dict'
    try:
        pkgmgr = PkgMgr()
        assert pkgmgr.is_available() == False
    except AttributeError:
        pass
    finally:
        del sys.modules['__main__']