

# Generated at 2022-06-20 18:40:49.037704
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgmgr = CLIMgr()
    if pkgmgr.is_available():
        return True
    else:
        return False

# Generated at 2022-06-20 18:41:00.394599
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class test_pkg_mgr(PkgMgr):
        def list_installed(self):
            return ['test_1', 'test_2']
        def get_package_details(self, package):
            if package == 'test_1':
                pkg_details = dict()
                pkg_details['name'] = 'test_1'
                pkg_details['version'] = '1.0-1'
                return pkg_details
            elif package == 'test_2':
                pkg_details = dict()
                pkg_details['name'] = 'test_2'
                pkg_details['version'] = '2.0-1'
                return pkg_details
    tpm = test_pkg_mgr()
    inst_pkgs = tpm.get_packages()

# Generated at 2022-06-20 18:41:01.450864
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    c._cli = "test"
    assert c._cli == "test"

# Generated at 2022-06-20 18:41:08.083877
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    def mock_get_bin_path(arg):
        if arg == "foo":
            return "bar"
        raise ValueError

    class TestCLIMgr(CLIMgr):
        CLI = "foo"

    # test CLI is found
    t = TestCLIMgr()
    t.get_bin_path = mock_get_bin_path
    assert t.is_available()
    # test CLI is not found
    def mock_get_bin_path(arg):
        raise ValueError
    t.get_bin_path = mock_get_bin_path
    assert not t.is_available()

# Generated at 2022-06-20 18:41:10.596108
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr = CLIMgr()
    assert not pkg_mgr.is_available()



# Generated at 2022-06-20 18:41:17.392970
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = '__nonexistent_cli__'
    # Check that is_available returns False for a non-existing CLI
    c = CLIMgrTest()
    assert c.is_available() is False
    # Check that is_available returns True for an existing CLI
    class CLIMgrTest2(CLIMgr):
        CLI = 'echo'
    c = CLIMgrTest2()
    assert c.is_available() is True

# Generated at 2022-06-20 18:41:20.595034
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    aaaa = PkgMgr()
    aaaa.list_installed()


# Generated at 2022-06-20 18:41:29.108114
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    def mocked_get_package_details(self,package):
        return {'name': 'test_package', 'version': '1.0.0'}

    from ansible.module_utils.common.ansible_collector import AnsibleCollectorShellModule
    from ansible.module_utils.parsing.convert_bool import boolean

    import pytest


# Generated at 2022-06-20 18:41:33.120594
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    packages = {
        'package_manager': 'dpkg',
        'name': 'python3-yaml',
        'version': '3.11-3'
    }
    assert packages['version'] == PkgMgr.get_package_details(packages['name'])

# Generated at 2022-06-20 18:41:35.643141
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    mgrs = get_all_pkg_managers()
    for pkg_mgr in mgrs:
        if mgrs[pkg_mgr]().is_available():
            mgrs[pkg_mgr]().list_installed()

# Generated at 2022-06-20 18:41:40.831026
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    pm.is_available()


# Generated at 2022-06-20 18:41:45.894312
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    test_class_names = ['CLIMgr', 'LibMgr', 'PkgMgr']
    test_classes = get_all_pkg_managers().values()
    for test_class in test_classes:
        assert test_class.__name__ in test_class_names

# Generated at 2022-06-20 18:41:54.611585
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.system.pkg_mgr import LibMgr
    class TestLibMgr(LibMgr):
        LIB = 'test_lib'

    tlm = TestLibMgr()

    if tlm.is_available():
        assert False, 'Failed to detect unavailable lib'

    if tlm._lib is not None:
        assert False, 'Failed to prep lib'

    import sys
    sys.modules['test_lib'] = 'test_lib'

    assert tlm.is_available(), 'Failed to detect available lib'

    assert tlm._lib is not None, 'Failed to prep lib'



# Generated at 2022-06-20 18:42:06.573641
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import tempfile
    import shutil

    # Provide a default value for PATH so we don't have to check it in the test
    with tempfile.TemporaryDirectory() as tmpdir:
        os.environ['PATH'] = tmpdir
        # Create an empty script file to simulate an executable
        script_path = os.path.join(tmpdir, 'example-script')
        open(script_path, 'w').close()

    # Make sure the script file is executable
    os.chmod(script_path, 0o755)

    # Test that the script is found
    manager = CLIMgr()
    assert manager.is_available()

    # Test that the script isn't found
    os.unlink(script_path)
    assert not manager.is_available()

    os.environ.pop('PATH')

# Generated at 2022-06-20 18:42:08.548839
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass



# Generated at 2022-06-20 18:42:11.124966
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg = LibMgr()
    assert pkg.is_available() is False
    print('Test for constructor of class LibMgr')


# Generated at 2022-06-20 18:42:12.876678
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg = PkgMgr()
    assert pkg.is_available() == NotImplementedError

# Generated at 2022-06-20 18:42:15.804242
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'
    test = TestCLIMgr()
    if test.is_available():
        return False
    return True

# Generated at 2022-06-20 18:42:22.875927
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # None of these should raise an exception

    from ansible.module_utils.common.collections import ImmutableDict

    pmgrs = get_all_pkg_managers()

    assert 'apt' in pmgrs
    assert 'apt' in pmgrs
    assert pmgrs['apt'].CLI == 'apt-get'

    assert 'yum' in pmgrs
    assert 'yum' in pmgrs
    assert pmgrs['yum'].CLI == 'yum'

    assert 'dnf' in pmgrs
    assert 'dnf' in pmgrs
    assert pmgrs['dnf'].CLI == 'dnf'

    assert 'zypper' in pmgrs
    assert 'zypper' in pmgrs

# Generated at 2022-06-20 18:42:26.704263
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Test(LibMgr):
        LIB = 'ansible.module_utils.facts.packages.dpkg'

    test1 = Test()
    assert test1._lib is None
    assert test1.is_available() is False



# Generated at 2022-06-20 18:42:45.841581
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_subclass(PkgMgr):
        def list_installed(self):
            return ['one', 'two']
        def get_package_details(self, package):
            if package == 'one':
                return {'name': 'one', 'version': '2.0.0', 'source': 'subclass'}
            else:
                return {'name': 'two', 'version': '3.3.3', 'source': 'subclass'}

    pm = PkgMgr_subclass()
    res = pm.get_packages()

# Generated at 2022-06-20 18:42:46.628222
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-20 18:42:53.081106
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    from ansible.module_utils.facts import get_distribution, get_distribution_release, get_distribution_version

    distro = get_distribution()
    release = get_distribution_release()
    version = get_distribution_version()
    distro_lower = distro.lower()

    pkg_mgrs = get_all_pkg_managers()
    # print(distro_lower)
    # print(pkg_mgrs)
    if distro_lower in pkg_mgrs:
        print(pkg_mgrs[distro_lower])
        print (pkg_mgrs[distro_lower].is_available())
    else:
        print("Distribution not supported")


# Generated at 2022-06-20 18:42:58.110604
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import unittest

    class TestCLIMgr(unittest.TestCase):
        def test_constructor(self):
            cli = CLIMgr()
            self.assertRaises(NotImplementedError, cli.is_available)

    return unittest.TestLoader().loadTestsFromTestCase(TestCLIMgr)


# Generated at 2022-06-20 18:43:01.054825
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        class PkgMgrLib(LibMgr):
            LIB = 'os'
        assert True
    except:
        assert False


# Generated at 2022-06-20 18:43:03.480803
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg = PkgMgr()
    pkg_list = pkg.list_installed()


# Generated at 2022-06-20 18:43:06.634478
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    Mgr = PkgMgr()
    assert Mgr.is_available() == False
    Managers = [PkgMgr(), CLIMgr(), LibMgr()]
    for Manager in Managers:
        assert Manager.is_available() == False


# Generated at 2022-06-20 18:43:08.863804
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    from ansible.module_utils.common.data_structures import CLIMgr
    obj = CLIMgr()

# Generated at 2022-06-20 18:43:10.309317
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available()


# Generated at 2022-06-20 18:43:14.370685
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert type(pkg_managers) is dict
    assert pkg_managers is not {}
    assert u'nixpkgs' in pkg_managers

# Generated at 2022-06-20 18:43:30.309535
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    x = PkgMgr()
    x.list_installed()


# Generated at 2022-06-20 18:43:37.735480
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import os
    import subprocess
    from ansible.module_utils.six.moves import builtins

    class LibMgr_Test(LibMgr):
        LIB = 'testlib'

    def test_import(name):
        fullpath = os.path.dirname(os.path.abspath(__file__))
        sys.path.append(fullpath)
        try:
            fp, pathname, description = imp.find_module(name)
            return imp.load_module(name, fp, pathname, description)
        except:
            return None

    builtins_open = open
    def open(name, mode='r', buffering=-1):
        if name == '/usr/lib/python/site-packages/testlib/__init__.py':
            return builtins_open

# Generated at 2022-06-20 18:43:46.784155
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from pprint import pprint
    from ansible.module_utils.remote_management.yum import Yum
    from ansible.module_utils.remote_management.apt import Apt
    from ansible.module_utils.remote_management.zypper import Zypper
    from ansible.module_utils.remote_management.dnf import Dnf
    from ansible.module_utils.remote_management.pacman import Pacman

    print("get_packages for Yum")
    pprint(Yum().get_packages())
    print("get_packages for Apt")
    pprint(Apt().get_packages())
    print("get_packages for Zypper")
    pprint(Zypper().get_packages())
    print("get_packages for Pacman")
    pprint(Pacman().get_packages())

# Generated at 2022-06-20 18:43:49.316914
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class_cli = CLIMgr()
    assert class_cli.is_available() == False

# Generated at 2022-06-20 18:43:49.900326
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False

# Generated at 2022-06-20 18:43:51.072131
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert get_all_pkg_managers().has_key('climgr') == True

# Generated at 2022-06-20 18:43:52.607950
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    assert pm.is_available() == False


# Generated at 2022-06-20 18:43:54.825073
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib = LibMgr()
    assert lib._lib == None


# Generated at 2022-06-20 18:43:57.959566
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    try:
        pm = CLIMgr()
        pm.is_available()
        assert False
    except NotImplementedError:
        assert True
    except:
        assert False


# Generated at 2022-06-20 18:44:00.132495
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    lm = LibMgr()
    lm.LIB = 'os'
    assert lm.is_available()


# Generated at 2022-06-20 18:44:31.098973
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cmd_mgr = CLIMgr()
    assert cmd_mgr

# Generated at 2022-06-20 18:44:33.799693
# Unit test for constructor of class LibMgr
def test_LibMgr():

    class Apt(LibMgr):

        LIB = 'apt'

    apt = Apt()

    assert apt.LIB == 'apt'


# Generated at 2022-06-20 18:44:36.996465
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class LibMgrTest(LibMgr):
        LIB = 'fakelib'
    libmgr = LibMgrTest()
    assert libmgr.LIB == 'fakelib'
    assert isinstance(libmgr, LibMgr)


# Generated at 2022-06-20 18:44:38.378111
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # Test to see if method list_installed of class PkgMgr works
    assert True

# Generated at 2022-06-20 18:44:40.348807
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert isinstance(PkgMgr(), PkgMgr)


# Generated at 2022-06-20 18:44:40.815465
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-20 18:44:43.667943
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_test(LibMgr):
        LIB = "lib"
    libmgr = LibMgr_test()
    assert libmgr.is_available() == True


# Generated at 2022-06-20 18:44:44.611780
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    clm = CLIMgr()
    assert clm

# Generated at 2022-06-20 18:44:50.889902
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os
    import shutil
    import tempfile

    _, tmp_file = tempfile.mkstemp()
    file_name = os.path.split(tmp_file)[1]
    os.chmod(tmp_file, 0o755)

    class MockCLIMgr(CLIMgr):
        CLI = file_name

    cm = MockCLIMgr()
    assert cm.is_available()
    os.chmod(tmp_file, 0o000)
    assert not cm.is_available()

    os.remove(tmp_file)
    shutil.rmtree(tempfile.gettempdir())

# Generated at 2022-06-20 18:44:57.145336
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    unique_managers = get_all_pkg_managers()
    assert 'rpmpkgmgr' in unique_managers and 'dpkgpkgmgr' in unique_managers and 'apkgmgr' in unique_managers
    assert 'metapkgmgr' not in unique_managers and 'pkgmgr' not in unique_managers and 'pkg_mgr' not in unique_managers



# Generated at 2022-06-20 18:46:01.228984
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available(CLIMgr()) == True

# Generated at 2022-06-20 18:46:02.854143
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() is None


# Generated at 2022-06-20 18:46:05.371376
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class DummyCLI(CLIMgr):
        CLI = 'dummy'
    assert DummyCLI().is_available() == False

# Generated at 2022-06-20 18:46:06.405286
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass


# Generated at 2022-06-20 18:46:12.813139
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    all_pkg_managers = get_all_pkg_managers()
    assert all_pkg_managers is not None, 'get_all_pkg_managers() did not return a dictionary'
    for key in all_pkg_managers.keys():
        assert key.lower() in all_pkg_managers, "get_all_pkg_managers() returned a package manager '%s' with an invalid key" % key
        assert isinstance(all_pkg_managers[key], PkgMgr), "get_all_pkg_managers() returned a package manager '%s' which is not a subclass of PkgMgr" % key

# Generated at 2022-06-20 18:46:15.223886
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Create an instance of CLIMgr
    obj = CLIMgr()
    # Try to get binary path of executable 'true'
    assert obj.is_available()



# Generated at 2022-06-20 18:46:18.655162
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def get_package_details(self, package):
            return {'name': 'httpd'}
    assert PkgMgrTest().get_package_details('') == {'name': 'httpd'}

# Generated at 2022-06-20 18:46:20.566871
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    target = LibMgr()
    target.LIB = 'os'
    assert target.is_available() is True


# Generated at 2022-06-20 18:46:22.356427
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr is not None
    assert libmgr._lib is None


# Generated at 2022-06-20 18:46:24.974423
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import ansible.module_utils.common.process

    pkg_object = ansible.module_utils.common.process.PkgMgr

    assert pkg_object.is_available() == False



# Generated at 2022-06-20 18:49:00.528528
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class Test(LibMgr):
        LIB = 'test'

    assert Test().LIB == 'test'


# Generated at 2022-06-20 18:49:01.926098
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class MockCLIMgr(CLIMgr):
        CLI = 'test_cli'
    mock_cli_mgr = MockCLIMgr()
    assert mock_cli_mgr

# Generated at 2022-06-20 18:49:11.214117
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    import pytest
    from ansible.module_utils.common.compat.tests.tools.test_ruamel_yaml import get_all_pkg_managers
    from ansible.module_utils.common.compat.tests.tools.test_distro_resource_facts import get_package_info
    pkg_mgrs = get_all_pkg_managers()
    pkgmgr = pkg_mgrs['pip']
    package = get_package_info()
    info = pkgmgr.get_package_details(package)

    assert(info is not None)
    assert(package['name'] == 'ansible.module_utils.basic')
    return




# Generated at 2022-06-20 18:49:13.627851
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'TestCLIMgr'
    cli_mgr = TestCLIMgr()
    cli_mgr.is_available()
    return cli_mgr._cli

# Generated at 2022-06-20 18:49:15.166479
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import sys
    pkgMgr = PkgMgr()
    assert pkgMgr.list_installed() is None

# Generated at 2022-06-20 18:49:17.978222
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    """ Check if get_package_details method
        of PkgMgr class works as expected.
    """
    obj = PkgMgr()
    assert not obj.get_package_details('package')


# Generated at 2022-06-20 18:49:21.336510
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    pkgMgrInst = PkgMgr()
    assert pkgMgrInst.is_available() == False
    assert pkgMgrInst.get_packages() == {'name': [{'name': 'name', 'version': 'version', 'source': 'pkgmgr'}]}


# Generated at 2022-06-20 18:49:27.128172
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    arg1 = ["ssh", "ntp", "ntp"]
    arg2 = {"ssh": [{"source": "homebrew", "version": "7.8p1", "name": "ssh"}], "ntp": [{"source": "homebrew", "version": "4.2.8p8", "name": "ntp"}, {"source": "homebrew", "version": "4.2.8p4", "name": "ntp"}]}
    test_PkgMgr = PkgMgr()
    test_PkgMgr.is_available = lambda: True
    test_PkgMgr.list_installed = lambda: arg1
    def f3(arg):
        if arg == "ntp":
            return {"source": "homebrew", "version": "4.2.8p8", "name": "ntp"}

# Generated at 2022-06-20 18:49:36.135034
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert set(pkg_mgrs.keys()) == set(['pip', 'yum', 'gem', 'apt', 'rpm'])
    assert pkg_mgrs['pip'].__name__ == 'Pip'
    assert pkg_mgrs['yum'].__name__ == 'Yum'
    assert pkg_mgrs['gem'].__name__ == 'Gem'
    assert pkg_mgrs['apt'].__name__ == 'Apt'
    assert pkg_mgrs['rpm'].__name__ == 'Rpm'


# Generated at 2022-06-20 18:49:36.975257
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass
