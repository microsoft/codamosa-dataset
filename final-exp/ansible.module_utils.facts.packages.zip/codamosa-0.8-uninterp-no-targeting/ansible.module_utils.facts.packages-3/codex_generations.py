

# Generated at 2022-06-20 18:40:48.825996
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    # Expect _cli to be None
    assert mgr._cli == None
    # Expect CLIMgr.is_available() method to return False
    assert mgr.is_available() == False

if __name__ == '__main__':
    test_CLIMgr()

# Generated at 2022-06-20 18:40:50.907101
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libMgr = LibMgr()
    assert libMgr._lib is None


# Generated at 2022-06-20 18:41:02.127688
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrWhat(PkgMgr):
        def __init__(self):
            pass
        def is_available(self):
            return True
        def list_installed(self):
            return ["package1", "package2"]
        def get_package_details(self, package):
            return {
                "name": package,
                "version": "1"
            }
    p = PkgMgrWhat()
    result = p.get_packages()
    assert "package1" in result
    assert "package2" in result
    assert len(result["package1"]) == 1
    assert len(result["package2"]) == 1
    assert result["package1"][0]["version"] == "1"
    assert result["package2"][0]["version"] == "1"

# Generated at 2022-06-20 18:41:07.378841
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    lm = LibMgr()
    sys.modules['lib_module'] = None
    assert lm.is_available() == True


# Generated at 2022-06-20 18:41:17.297778
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # config module
    config_module = {
        "name": "config",
        "version": "1.2.3.4",
        "architecture": "x86_64",
        "release": "2",
        "source": "yum"
    }
    
    # config class
    class ConfigMgr(PkgMgr):

        def list_installed(self):
            pass

        def get_package_details(self, package):
            return config_module

    # create new object from class
    config_obj = ConfigMgr()
    # assert that get_package_details returns config_module
    assert config_obj.get_package_details() == config_module

# Generated at 2022-06-20 18:41:19.474976
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm

# Generated at 2022-06-20 18:41:20.250179
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-20 18:41:23.270635
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    pkg_mgr = CLIMgr()
    # Unit test for is_available() method of CLIMgr instance
    assert pkg_mgr.is_available() == False

# Generated at 2022-06-20 18:41:30.338756
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

        from ansible.module_utils.common._collections_compat import Mapping
        import json

        pkg_mgrs = get_all_pkg_managers()
        assert isinstance(pkg_mgrs, Mapping)


        # Verify we can get the installed packages list for each package manager
        for key in pkg_mgrs.keys():
            pkg_mgr = pkg_mgrs[key]()
            if pkg_mgr.is_available():
                installed_packages = pkg_mgr.get_packages()
                assert isinstance(installed_packages, Mapping)
                # Verify we can get the installed packages list for each package manager
                for package in installed_packages:
                    package_details = installed_packages[package]
                    assert isinstance(package_details, list)

        # Loop all

# Generated at 2022-06-20 18:41:32.189541
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() is False

# Generated at 2022-06-20 18:41:43.381248
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    test_package = {'name': 'test',
                    'version': '1.0.0'}

    class TestClass(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [test_package['name']]

        def get_package_details(self, package):
            if package == test_package['name']:
                return test_package
            return {}

    t = TestClass()
    assert t.get_packages() == {'test': [test_package]}

# Generated at 2022-06-20 18:41:47.012886
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    # Tests the constructor of CLIMgr - the __init__() method
    import types
    assert isinstance(CLIMgr.__init__, types.FunctionType)


# Generated at 2022-06-20 18:41:53.593707
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts import default_collectors
    PkgMgr_details = default_collectors['pkg_mgr_details']
    pkg_mgr = PkgMgr_details.get_package_details('xinetd')
    assert pkg_mgr == {'status': 'unpacked', 'version': '2.3.15-2ubuntu1.1', 'release': '2ubuntu1.1', 'name': 'xinetd', 'source': 'dpkg'}

# Generated at 2022-06-20 18:41:54.748678
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert type(cm) is not None

# Generated at 2022-06-20 18:41:56.269544
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available() == False


# Generated at 2022-06-20 18:42:07.572489
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    result = get_all_pkg_managers()
    assert isinstance(result, dict), "returned value is not a dict"
    assert 'apt' in result, "apt package manager not found in dict"
    assert 'yum' in result, "yum package manager not found in dict"
    assert 'dnf' in result, "dnf package manager not found in dict"
    assert 'zypper' in result, "zypper package manager not found in dict"
    assert 'pacman' in result, "pacman package manager not found in dict"
    assert 'portage' in result, "portage package manager not found in dict"
    assert 'macports' in result, "macports package manager not found in dict"
    assert 'homebrew' in result, "homebrew package manager not found in dict"

# Generated at 2022-06-20 18:42:09.593219
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkgmgr = PkgMgr()
    assert pkgmgr.list_installed() == []

# Generated at 2022-06-20 18:42:16.074516
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return [1, 2]
        def get_package_details(self, package):
            return {'name': 3}
    p = PkgMgrTest()
    installed_packages = {}
    installed_packages = p.get_packages()
    assert installed_packages == {3: [{'name': 3}, {'name': 3}]}

# Generated at 2022-06-20 18:42:26.345703
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # mock the base class
    class Base(object):
        __name__ = 'LibMgr'

        def __init__(self):
            pass

        def is_available(self):
            pass
    # mock the _LibMgr class
    class _LibMgr(LibMgr):
        def __init__(self):
            pass
    # mock the __import__ method
    def _import__(self, module):
        raise ImportError

    original_import = __import__
    try:
        __import__ = _import__
        mock_libmgr = _LibMgr()
        assert not mock_libmgr.is_available()
    except Exception as e:  # noqa
        raise
    finally:
        __import__ = original_import


# Generated at 2022-06-20 18:42:27.072054
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-20 18:42:35.460619
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert isinstance(CLIMgr(), CLIMgr)


# Generated at 2022-06-20 18:42:37.106757
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    cliMgr = CLIMgr()
    assert(cliMgr.CLI == None)

# Generated at 2022-06-20 18:42:48.220452
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class FakePkgMgr(PkgMgr):
        def __init__(self):
            self.installed_packages = {
                'a': [{'name': 'a', 'version': '1.0'}, {'name': 'a', 'version': '1.1'}],
                'b': [{'name': 'b', 'version': '2.0'}],
                'c': [{'name': 'c', 'version': '3.0'}]
            }
            self.list_called = False

        def is_available(self):
            return True

        def list_installed(self):
            self.list_called = True
            return self.installed_packages.keys()

        def get_package_details(self, package):
            return self.installed_packages[package][0]

    f

# Generated at 2022-06-20 18:42:49.498407
# Unit test for constructor of class LibMgr
def test_LibMgr():
    x = LibMgr()


# Generated at 2022-06-20 18:42:50.976820
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    a = LibMgr()
    assert a is not None


# Generated at 2022-06-20 18:42:54.430160
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # test_obj = PkgMgr()
    # assert isinstance(test_obj.get_packages(), dict)
    # TODO Add test coverage for get_packages() method
    pass

# Generated at 2022-06-20 18:43:03.294794
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Arrange
    class MockPkgMgr(PkgMgr):
        def __init__(self):
            super(MockPkgMgr, self).__init__()
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    mock_package = "package_name 1.2.3"
    mock_pkg_mgr = MockPkgMgr()

    # Act
    mock_pkg_mgr.get_package_details(mock_package)

    # Assert: no exception raised

# Generated at 2022-06-20 18:43:07.877717
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    #executables = ['cargo', 'freebsd-version', 'pkg', 'pip', 'pip3', 'port', 'rpm', 'yum']
    executables = ['pip3', 'pip', 'rpm', 'yum']
    for exe in executables:
        cli = CLIMgr()
        cli.CLI = exe
        assert cli.is_available()
        del cli


# Generated at 2022-06-20 18:43:11.759804
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_cli'

    instance = TestCLIMgr()
    assert instance.is_available() is False
    assert instance._cli is None


# Generated at 2022-06-20 18:43:13.351305
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    return pm.get_package_details()

# Generated at 2022-06-20 18:43:30.824104
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    from ansible.module_utils.gathering.pkg_mgrs import PkgMgr
    p = PkgMgr()
    assert p.list_installed() == NotImplemented


# Generated at 2022-06-20 18:43:37.735250
# Unit test for method is_available of class LibMgr

# Generated at 2022-06-20 18:43:46.976806
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgrs = get_all_pkg_managers()
    assert isinstance(pkg_mgrs, dict)
    assert len(pkg_mgrs) > 0
    for pkg_mgr in pkg_mgrs.values():
        assert issubclass(pkg_mgr, PkgMgr)
        pkg_mgr_inst = pkg_mgr()
        assert isinstance(pkg_mgr_inst, PkgMgr)
        assert isinstance(pkg_mgr_inst.is_available(), bool)
        if pkg_mgr_inst.is_available():
            assert isinstance(pkg_mgr_inst.list_installed(), list)
            assert isinstance(pkg_mgr_inst.get_package_details('test'), dict)

# Generated at 2022-06-20 18:43:58.824664
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class GoodPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['p1', 'p2']

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}

    class BadPkgMgr(GoodPkgMgr):
        def list_installed(self):
            return None

    class RaisesPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            raise ValueError

        def get_package_details(self, package):
            return {'name': package, 'version': '1.0'}


# Generated at 2022-06-20 18:44:02.887898
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = get_all_pkg_managers()
    for pkg_mgr_name, pkg_mgr_cls in pkg_mgr.items():
        try:
            pkg_obj = pkg_mgr_cls()
            pkg_obj.is_available()
        except:
            return False

    return True


# Generated at 2022-06-20 18:44:05.235497
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()

    assert cm._cli is None
    assert not cm.is_available()


# Generated at 2022-06-20 18:44:14.673192
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    """ Test the get_all_pkg_managers function. """

    # Test that it returns the list of package managers
    assert(set(get_all_pkg_managers().keys()) == set(('apt', 'yum', 'yum_rhnplugin', 'dnf', 'zypper', 'pacman', 'portage', 'apk', 'eopkg', 'pip', 'pkgin', 'pkgin_freebsd', 'pkgng', 'pkg_freebsd', 'chocolatey')))

    # Test that it can't be called from an object
    from ansible.module_utils.basic import AnsibleModule
    ts = AnsibleModule({}, supports_check_mode=True)
    ts.fail_json.side_effect = Exception("self.fail_json should not have been called")
    ts.exit_json

# Generated at 2022-06-20 18:44:15.528854
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    obj = PkgMgr()


# Generated at 2022-06-20 18:44:21.690315
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgrTest(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            if package == 'package1':
                return {'name': 'package1', 'version': '1.0'}
            elif package == 'package2':
                return {'name': 'package2', 'version': '2.0'}

    pkg_mgr_test = PkgMgrTest()

# Generated at 2022-06-20 18:44:25.152869
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    Base = PkgMgr
    class TestPkgMgr(Base):
        def is_available(self):
            return True

        def list_installed(self):
            return []

        def get_package_details(self, package):
            return dict()

    test_pkg_mgr = TestPkgMgr()

    assert isinstance(test_pkg_mgr.list_installed(), list), "list_installed() of PkgMgr should return a list"

# Generated at 2022-06-20 18:44:59.516939
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # This is really more of an integration test that happens to only call a single function.
    # It is dependent on all of the PkgMgr subclasses being available, otherwise the fail is actually a false positive

    pkg_managers = get_all_pkg_managers()
    for pkg_mgr_name in ['yum', 'apt', 'apk']:
        assert pkg_mgr_name in pkg_managers



# Generated at 2022-06-20 18:45:01.199569
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()
    assert pkg_mgr is not None


# Generated at 2022-06-20 18:45:05.966798
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    class PkgMgrTester(PkgMgr):

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    try:
        o = PkgMgrTester()
        raise AssertionError("Can't instantiate abstract base class PkgMgr")
    except TypeError:
        pass

# Generated at 2022-06-20 18:45:15.461710
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class PkgMgrTest(PkgMgr):
        def __init__(self):
            super(PkgMgrTest, self).__init__()
            self.legacy = True

        def is_available(self):
            return True

        def list_installed(self):
            return ['package']

        def get_package_details(self, package):
            return {"name": "new", "version": "1.0.0"}

    pkg = PkgMgrTest()
    assert pkg.is_available()
    assert pkg.list_installed() == ['package']
    assert pkg.get_package_details('package') == {"name": "new", "version": "1.0.0"}

# Generated at 2022-06-20 18:45:18.996895
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers_list = get_all_pkg_managers()
    assert isinstance(pkg_managers_list, dict)
    # the list should have at least one entry
    assert len(pkg_managers_list) > 0

# Generated at 2022-06-20 18:45:20.951339
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed(None) == None, 'list_installed should return None'


# Generated at 2022-06-20 18:45:24.733274
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    import inspect
    assert(len(get_all_pkg_managers()) > 5)
    for pkg in get_all_pkg_managers():
        assert(inspect.isclass(get_all_pkg_managers()[pkg]))

# Generated at 2022-06-20 18:45:27.610387
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    """
    Test the 'is_available' method for the LibMgr class
    """
    assert LibMgr().is_available() == False


# Generated at 2022-06-20 18:45:36.165811
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = "test_test"
    CLIMgrTest_cli = CLIMgrTest()
    test_test = get_bin_path("test_test")
    ret = CLIMgrTest_cli.is_available()
    assert (ret == True and CLIMgrTest_cli._cli == test_test)
    if not ret:
        return
    ret = CLIMgrTest_cli.is_available()
    assert (ret == True and CLIMgrTest_cli._cli == test_test)
    test_test_fake = "test_test"
    if not test_test_fake.endswith(".py") and not test_test_fake.endswith(".pyc"):
        test_test_fake = test_test_fake + ".py"
    CLIM

# Generated at 2022-06-20 18:45:37.987493
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'test_CLIMgr'
    test = TestCLIMgr()
    assert(test._cli is None)


# Generated at 2022-06-20 18:46:42.010085
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass



# Generated at 2022-06-20 18:46:44.368898
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert 'yum' in get_all_pkg_managers()
    assert 'apt' in get_all_pkg_managers()

# Generated at 2022-06-20 18:46:46.895911
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestCLIMgr(CLIMgr):
        CLI = 'command'

    test_cli_mgr = TestCLIMgr()
    assert(test_cli_mgr.CLI)

# Generated at 2022-06-20 18:46:49.472877
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class TestClass(CLIMgr):
        CLI = 'cli_class_test'

    assert TestClass().CLI == 'cli_class_test'


# Generated at 2022-06-20 18:46:54.071850
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import time

    class FakeLibMgr(LibMgr):

        LIB = "time"

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    lib_mgr = FakeLibMgr()
    assert lib_mgr.is_available()
    assert isinstance(lib_mgr._lib, type(time))


# Generated at 2022-06-20 18:46:55.285849
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert not obj.is_available()


# Generated at 2022-06-20 18:46:57.054939
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm

# Generated at 2022-06-20 18:47:01.933653
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    from ansible.module_utils.common import package_facts

    mgrs = get_all_pkg_managers()
    for mgr in mgrs:
        assert mgr in package_facts.PackageManagerFactCollector._pkg_mgrs
        assert mgrs[mgr] == package_facts.PackageManagerFactCollector._pkg_mgrs[mgr]

# Generated at 2022-06-20 18:47:02.753076
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass


# Generated at 2022-06-20 18:47:04.154828
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    package_manager = PkgMgr()
    assert package_manager is not None


# Generated at 2022-06-20 18:49:56.630974
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_get_packages(PkgMgr):

        def __init__(self):
            self.packages = [{'n':'pkg1','v':'1.0'}, {'n':'pkg1','v':'1.1'}, {'n':'pkg2','v':'2.0'}]
            super(PkgMgr_get_packages, self).__init__()

        def list_installed(self):
            return self.packages

        def get_package_details(self, package):
            return package

    pkg=PkgMgr_get_packages()

# Generated at 2022-06-20 18:50:00.717786
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    mgr = PkgMgr()
    assert mgr.is_available() == NotImplementedError 


# Generated at 2022-06-20 18:50:02.665997
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    try:
        pkgmgr = PkgMgr()
        pkgmgr.list_installed()
    except NotImplementedError:
        pass

# Generated at 2022-06-20 18:50:04.155504
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    mgr = PkgMgr()
    assert mgr.is_available() == NotImplemented

# Generated at 2022-06-20 18:50:05.814364
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()
    assert(isinstance(mgr, PkgMgr))


# Generated at 2022-06-20 18:50:13.680222
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.get_package_details('mypackage_1.2.3-4') == {'name': 'mypackage', 'version': '1.2.3-4'}
    assert pkg_mgr.get_package_details('mypackage-1.2.3-4') == {'name': 'mypackage', 'version': '1.2.3-4'}
    assert pkg_mgr.get_package_details('mypackage-1.2.3') == {'name': 'mypackage', 'version': '1.2.3'}
    assert pkg_mgr.get_package_details('mypackage-1.2') == {'name': 'mypackage', 'version': '1.2'}
    assert pkg_m

# Generated at 2022-06-20 18:50:15.110264
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    if get_all_pkg_managers() == {}:
        raise Exception("No package managers found")


# Generated at 2022-06-20 18:50:17.152101
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import pprint
    print(pprint.pformat(__import__('yum').Yum().get_package_details('yum-utils')))

# Generated at 2022-06-20 18:50:22.422950
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    import subprocess
    class TestLibMgr(LibMgr):
        LIB = 'subprocess'
    try:
        subprocess.run('foo')
    except AttributeError:
        # Not on python 3.5
        return
    pkg_mgr = TestLibMgr()
    assert pkg_mgr.is_available() is True


# Generated at 2022-06-20 18:50:29.885679
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    import sys
    if sys.version_info >= (3, 0):
        from importlib import reload

    try:
        import ansible.module_utils.common.pkg_mgr.deb
        reload(ansible.module_utils.common.pkg_mgr.deb)
    except ImportError:
        pass

    pm_dict = get_all_pkg_managers()
    if sys.version_info >= (3, 0):
        from ansible.module_utils.common.pkg_mgr.deb import DPKGMgr
    else:
        from deb import DPKGMgr
    assert type(pm_dict['dpkgmgr']) == type(DPKGMgr)