

# Generated at 2022-06-20 18:40:48.854778
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass

# Generated at 2022-06-20 18:40:50.958516
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    obj = LibMgr()
    assert obj.is_available() == True


# Generated at 2022-06-20 18:40:53.774604
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import os
    import tempfile
    import shutil

    class TestPkgMgr(LibMgr):

        LIB = 'test_module'


# Generated at 2022-06-20 18:40:57.577134
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    package = {'name':'ansible'}
    package_details = pkg_mgr.get_package_details(package)
    assert package_details['name'] == package['name']

# Generated at 2022-06-20 18:41:02.076072
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._utils import get_all_subclasses
    lm = None
    libmgr_list = []
    # validate only one instance of LibMgr class
    for obj in get_all_subclasses(LibMgr):
        if issubclass(obj, LibMgr):
            lm = obj()
            libmgr_list.append(lm)
    assert len(libmgr_list) == 1, "Test failed, Multiple instance of LibMgr found"
    # case1 - library is present, returns true
    lm.LIB = "platform"
    is_available_result = lm.is_available()
    assert is_available_result == True, "Test failed for case1: Library present, is_available method returning false"
    # case2 - library is not present, returns false

# Generated at 2022-06-20 18:41:04.261210
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class A(LibMgr):
        LIB = "os"
    a = A()
    print(a.is_available())



# Generated at 2022-06-20 18:41:09.815443
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # let's try with an existing python module
    lm = LibMgr()
    lm.LIB = 'os'
    assert lm.is_available() == True
    # now let's try with a non-existent python module
    lm.LIB = 'bla'
    assert lm.is_available() == False


# Generated at 2022-06-20 18:41:12.467443
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TClass(LibMgr):
        LIB = 'os'
    c = TClass()
    assert c.is_available()


# Generated at 2022-06-20 18:41:18.608713
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """
    Test if is_available of PkgMgr class is working as
    expected
    """

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    pkgmgr = TestPkgMgr()
    assert pkgmgr.is_available() is None


# Generated at 2022-06-20 18:41:20.146816
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg = PkgMgr()
    assert type(pkg) is PkgMgr


# Generated at 2022-06-20 18:41:26.255097
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()

    assert pkg_mgr != None

# Generated at 2022-06-20 18:41:31.953826
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # Get all package managers
    pkg_mgrs = get_all_pkg_managers()

    # Make sure the dict returned is not empty and has the 'apt' package manager
    assert pkg_mgrs
    assert 'apt' in pkg_mgrs
    assert pkg_mgrs['apt'].__name__ == 'Apt'
    assert pkg_mgrs['apt'].__module__ == 'ansible.module_utils.facts.collector.system.pkg_mgr'

    # Make sure the dict returned is not empty and has the 'dnf' package manager
    assert 'dnf' in pkg_mgrs
    assert pkg_mgrs['dnf'].__name__ == 'Dnf'

# Generated at 2022-06-20 18:41:33.566807
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available()


# Generated at 2022-06-20 18:41:34.506112
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-20 18:41:44.982014
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    import imp
    import pytest

    def _test_is_available(lib=None):
        class _testLibMgr(LibMgr):
            LIB = lib
        t = _testLibMgr()
        return t.is_available()

    # test import of system installed module
    assert _test_is_available('platform')

    # test import of module installed with pip
    import pip
    pip_install = pip.main(['install','-q','--user','ansible-test'])
    assert _test_is_available('ansible_test')

    # test if a not installed module raises an ImportError
    with pytest.raises(ImportError):
        _test_is_available('not_installed_module')

    # test if the module from a directory can be imported
    import tempfile

# Generated at 2022-06-20 18:41:47.433100
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert(PkgMgr.is_available())
    return True



# Generated at 2022-06-20 18:41:51.142260
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pm = PkgMgr()
    # This method is supposed to return True/False if the package manager is currently installed/usable
    # It can also 'prep' the required systems in the process of detecting availability
    assert pm.is_available()


# Generated at 2022-06-20 18:41:52.111317
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pass
    # TODO: Write unit test

# Generated at 2022-06-20 18:41:55.798132
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    def get_bin_path(arg):
        return arg
    CLIMgr.get_bin_path = get_bin_path
    CLIMgr.CLI = 'testpath'
    import sys

# Generated at 2022-06-20 18:42:07.232244
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return [
                {'name': 'nss', 'version': '3.17-1.el6'},
                {'name': 'nss', 'version': '3.18-1.el6'}
            ]

        def get_package_details(self, package):
            return package

    dum = DummyPkgMgr()
    packages = dum.get_packages()

    assert type(packages) == dict
    assert 'nss' in packages
    assert len(packages['nss']) == 2

    for package in packages:
        assert sorted(['name', 'version']) == sorted(packages[package][0])


# Generated at 2022-06-20 18:42:26.190342
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    from ansible.module_utils.common.text.converters import to_text

    cli_mgr = CLIMgr()
    lib_mgr = LibMgr()

    # Testing with a mock class for cli package manager
    class MockCLIMgr(CLIMgr):

        def list_installed(self):
            return [{'name': 'test_pkg'}]

        def get_package_details(self, package):
            return {'name': 'test_pkg', 'version': '1.0'}

    mock_cli_mgr = MockCLIMgr()
    assert mock_cli_mgr.__class__.list_installed()[0]['name'] == 'test_pkg'

# Generated at 2022-06-20 18:42:30.718468
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class DummyClassLibMgr(LibMgr):
        LIB = 'super.dummy.lib'

    dummy = DummyClassLibMgr()
    assert dummy._lib is None

    # check is_availble
    assert dummy.is_available() is False


# Generated at 2022-06-20 18:42:31.501866
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    o = PkgMgr()


# Generated at 2022-06-20 18:42:32.622346
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    obj = CLIMgr()
    assert obj

# Generated at 2022-06-20 18:42:40.050585
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    class PkgMgr_test(PkgMgr):
        expected_pkgs = {'test': [{'source': 'test',
                                   'version': '1.1.2',
                                   'name': 'test',
                                   'release': '1'},
                                  {'source': 'test',
                                   'version': '1.2.2',
                                   'name': 'test',
                                   'release': '1'}]}

        def list_installed(self):
            return ['test']

        def get_package_details(self, package):
            return {'source': 'test',
                    'version': '1.1.2',
                    'name': 'test',
                    'release': '1'}

    test_pkg_mgr = PkgMgr_test()
    pkgs = test_

# Generated at 2022-06-20 18:42:41.115616
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class _CLIMgr(CLIMgr):
        CLI = "ls"

    instance = _CLIMgr()
    assert instance.CLI == "ls"
    assert instance._cli is None

# Generated at 2022-06-20 18:42:43.779201
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class PkgMgr(LibMgr):
        LIB = 'os'
    manager = PkgMgr()
    assert manager.is_available() == True


# Generated at 2022-06-20 18:42:45.541308
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkgs = get_all_pkg_managers()
    assert isinstance(pkgs, dict)
    assert 'apt' in pkgs
    assert 'yum' in pkgs
    assert issubclass(pkgs['apt'], PkgMgr)

# Generated at 2022-06-20 18:42:47.855083
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Test_LibMgr(LibMgr):
        LIB = 'json'

    assert Test_LibMgr().is_available() is True


# Generated at 2022-06-20 18:42:50.731252
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkg_mgr = LibMgr()
    assert pkg_mgr.is_available() is False


# Generated at 2022-06-20 18:43:17.547255
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    # Create mock config object
    class TestConfig():

        def __init__(self):
            self.sysctl_path = '/usr/bin/sysctl'

    class TestLibMgr(LibMgr):

        LIB = 'ansible.module_utils.facts.system.sysctl'

    # Test with a real lib
    tl = TestLibMgr()
    assert tl.is_available()

    # Test with a fake lib
    class TestLibMgr2(LibMgr):

        LIB = 'ansible.module_utils.facts.system.fakelib'

    tl2 = TestLibMgr2()
    assert not tl2.is_available()


# Generated at 2022-06-20 18:43:19.036407
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-20 18:43:21.051231
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cliMgr = CLIMgr();
    assert cliMgr.is_available() == True

# Generated at 2022-06-20 18:43:25.006384
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    lib_mgr = PkgMgr()
    cli_mgr = PkgMgr()
    assert lib_mgr.is_available() == False
    assert cli_mgr.is_available() == False


# Generated at 2022-06-20 18:43:26.707774
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    libmgr = LibMgr()
    assert libmgr.is_available() == False


# Generated at 2022-06-20 18:43:29.615535
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    _libmgr = LibMgr()
    _libmgr.LIB = 'shutil'
    _libmgr.is_available()
    assert _libmgr._lib is not None
    return 0


# Generated at 2022-06-20 18:43:31.894396
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    mgr = get_all_pkg_managers()
    assert 'apt' in mgr.keys()
    assert 'pip' in mgr.keys()
    assert 'dnf' in mgr.keys()
    assert 'yum' in mgr.keys()

# Generated at 2022-06-20 18:43:37.735176
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class DummyLibMgr(LibMgr):
        LIB='ansible.module_utils.facts.system.pkg_mgr.pip'

    pkg_mgr = DummyLibMgr()
    assert isinstance(pkg_mgr,LibMgr)


# Generated at 2022-06-20 18:43:38.696623
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr()

# Generated at 2022-06-20 18:43:44.666331
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class FalseClass(PkgMgr):
        def is_available(self):
            return False
    class TrueClass(PkgMgr):
        def is_available(self):
            return True

    # init objects
    FalseClass_old = FalseClass()
    TrueClass_old = TrueClass()

    # check if the results are as expected
    assert FalseClass_old.is_available() == False
    assert TrueClass_old.is_available() == True


# Generated at 2022-06-20 18:44:25.505647
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Create an instance of PkgMgr
    p = PkgMgr()
    # Check the method is_available throws an exception
    try:
        p.is_available()
        # If it doesn't you should probably add a test (unit) here
    except NotImplementedError:
        pass
    except:
        # If a different exception is raised fail
        assert False
    # Success
    assert True


# Generated at 2022-06-20 18:44:31.054196
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkgmanagers = get_all_pkg_managers()
    valid_package_name_list = []
    for key in pkgmanagers.keys():
        if pkgmanagers[key].is_available():
            valid_package_name_list = valid_package_name_list + list(pkgmanagers[key].get_packages().keys())
    for key in pkgmanagers.keys():
        if pkgmanagers[key].is_available():
            for package_name in valid_package_name_list:
                package_details = pkgmanagers[key].get_package_details(package_name)
                assert isinstance(package_details, dict), \
                "The package manager " + key + " get_package_details should return a dictionary!"

# Generated at 2022-06-20 18:44:32.104656
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-20 18:44:33.185758
# Unit test for constructor of class LibMgr
def test_LibMgr():
    manager = LibMgr()
    assert(manager)

# Generated at 2022-06-20 18:44:34.572308
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert pm.list_installed() is None
    assert pm.get_package_details({}) is None
    assert pm.get_packages() is None


# Generated at 2022-06-20 18:44:42.689488
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from six.moves import mock

    # PkgMgr (abstract) class
    with mock.patch.object(PkgMgr, 'list_installed', return_value=['fake_package']):
        with mock.patch.object(PkgMgr, 'get_package_details', return_value={'name': 'fake_package', 'version': '1.2.3'}):
            pm = PkgMgr()
            result = pm.get_packages()
            assert result == {'fake_package': [{'name': 'fake_package', 'version': '1.2.3'}]}

# Generated at 2022-06-20 18:44:44.988696
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_CLI = 'ansible'
    test_cli = CLIMgr()
    test_cli.CLI = test_CLI
    test_cli.is_available() == False

# Generated at 2022-06-20 18:44:46.600403
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class test(PkgMgr):
        pass

    obj = test()
    assert(obj)

# Generated at 2022-06-20 18:44:50.822745
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class DummyPackage(object):
        pass

    class DummyMgr(PkgMgr):
        def get_package_details(self, package):
            pkg = DummyPackage()
            pkg.name = 'Dummy'
            pkg.version = '1.0.0'
            return pkg

    assert isinstance(DummyMgr().get_package_details(None), DummyPackage)

# Generated at 2022-06-20 18:44:53.371711
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert CLIMgr().is_available() is False


# Generated at 2022-06-20 18:46:09.669521
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        __import__('foo')
        return True
    except ImportError:
        pass


# Generated at 2022-06-20 18:46:11.228250
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) > 0

# Generated at 2022-06-20 18:46:13.587146
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    print("Not implemented!")


# Generated at 2022-06-20 18:46:21.666797
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    import os
    import platform

    mgr_class_name = os.path.splitext(os.path.basename(__file__))[0]
    if mgr_class_name == '__init__':
        mgr_class_name = 'PkgMgr'
    mgr = globals()[mgr_class_name]
    if isinstance(mgr, type) and issubclass(mgr, PkgMgr):
        if (platform.system().lower() == mgr.OS.lower()):
            mgr = mgr()
            availability = mgr.is_available()
            print(mgr_class_name + '.is_available() returned: ' + str(availability))

# Generated at 2022-06-20 18:46:29.823055
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class PkgMgr_test(PkgMgr):

        def __init__(self):

            self._cli = None
            super(PkgMgr, self).__init__()

        def is_available(self):

            self._cli = get_bin_path("notexisting")
            return True

    class PkgMgr_test_subclass(PkgMgr_test):

        pass

    test_pkg_mgr = PkgMgr_test()
    assert test_pkg_mgr.is_available() == True

    test_pkg_mgr_subclass = PkgMgr_test_subclass()
    assert test_pkg_mgr_subclass.is_available() == True

# Generated at 2022-06-20 18:46:38.704328
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import unittest
    import shutil
    import tempfile
    from os.path import join
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Dummy path for the unit test
    DUMMY_PATH = 'dummy_path'

    # Create a temp directory, touch a dummy executable file, add the directory to the PATH
    # and set this as the environment for the unit test
    temp_dir = tempfile.mkdtemp()
    file_path = join(temp_dir, DUMMY_PATH)
    open(file_path, 'a').close()
    os.chmod(file_path, 0o777)

    options = basic.AnsibleModule(argument_spec={})

# Generated at 2022-06-20 18:46:49.520045
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for pkg_mgr in list(get_all_pkg_managers().values()):
        if isinstance(pkg_mgr, LibMgr):
            import mock
            with mock.patch(pkg_mgr.LIB, autospec=True) as mock_lib:
                assert pkg_mgr().is_available() == True
                pkg_mgr.LIB = None
                assert pkg_mgr().is_available() == False
        elif isinstance(pkg_mgr, CLIMgr):
            import mock
            with mock.patch('ansible.module_utils.common._utils.get_bin_path', autospec=True) as mock_get_bin_path:
                mock_get_bin_path.return_value = True
                assert pkg_mgr().is_available() == True
                pkg_

# Generated at 2022-06-20 18:46:57.316429
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.package.os import OSMgr
    from ansible.module_utils.package.helper import PkgModuleHelper
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.package import package_merged

    package_mgr = OSMgr()
    if not package_mgr.is_available():
        raise Exception("OSMgr is not available")
    pkg_helper = PkgModuleHelper(package_mgr)
    package_mgr.install_package('shelltest')
    installed_packages = pkg_helper.get_packages()
    package_merged = package_merged(installed_packages)
    assert "shelltest" in package_merged
    assert "0.1" in package_merged['shelltest']

# Generated at 2022-06-20 18:46:59.459951
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg_mgr = PkgMgr()
    assert pkg_mgr.is_available() is False

# Generated at 2022-06-20 18:47:05.197552
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common.compat import mock

    expected = 'python-apt'

    mock_module_name = 'ansible.module_utils.common.compat.mock'
    if mock_module_name in sys.modules:
        del sys.modules[mock_module_name]

    with mock.patch('__builtin__.__import__') as __import__:
        import_mock = mock.Mock()
        import_mock.Error = ImportError
        __import__.side_effect = import_mock
        res = vars(PkgMgr)['LibMgr'].is_available(vars(PkgMgr)['LibMgr'], expected)
        assert res == True



# Generated at 2022-06-20 18:50:23.102244
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # if there are no packages, is_available should return False
    class MyPkgMgr(PkgMgr):
        def list_installed():
            return []
        def get_package_details():
            pass
    assert not MyPkgMgr().is_available()
    # if there are packages, is_available should return True
    class MyPkgMgr(PkgMgr):
        def list_installed():
            return ['package1']
        def get_package_details():
            pass
    assert MyPkgMgr().is_available()


# Generated at 2022-06-20 18:50:24.292994
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr().is_available() is NotImplemented


# Generated at 2022-06-20 18:50:30.456057
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    Unit test for method is_available of class CLIMgr
    """
    # if CLI is defined as a command, it should return true
    test_class_cli = TestCLIMgr('test')
    assert test_class_cli.is_available() == True

    # if CLI is undefined, it should return false
    test_class_cli = TestCLIMgr()
    assert test_class_cli.is_available() == False

# A class for testing method is_available of class CLIMgr

# Generated at 2022-06-20 18:50:37.990893
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # case 1
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    obj = TestPkgMgr()
    assert obj.is_available()

    # case 2
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return False
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    obj = TestPkgMgr()
    assert not obj.is_available()


# Generated at 2022-06-20 18:50:40.942032
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class MockPkgMgr(PkgMgr):
        def __init__(self):
            super(MockPkgMgr, self).__init__()

    mock_pkg_mgr = MockPkgMgr()
    assert mock_pkg_mgr.get_package_details("package") == dict()


# Generated at 2022-06-20 18:50:45.425196
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """
    Test method is_available of class CLIMgr
    """

    # Test with existing CLI
    class TestCLIMgr(CLIMgr):
        CLI = 'ls'

    assert TestCLIMgr().is_available() is True

    # Test with non-existing CLI
    class TestCLIMgr(CLIMgr):
        CLI = 'no_exist_ls'

    assert TestCLIMgr().is_available() is False