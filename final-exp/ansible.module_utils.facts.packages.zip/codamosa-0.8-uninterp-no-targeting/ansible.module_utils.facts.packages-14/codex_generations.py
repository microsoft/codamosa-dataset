

# Generated at 2022-06-20 18:40:58.549081
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_managers = get_all_pkg_managers()
    assert 'pkgin' in pkg_managers
    assert 'pkgutil' in pkg_managers
    assert 'pkg' in pkg_managers
    assert 'yum' in pkg_managers
    assert 'zypper' in pkg_managers
    assert 'aptget' in pkg_managers
    assert 'dnf' in pkg_managers
    assert 'eopkg' in pkg_managers
    assert 'pacman' in pkg_managers
    assert 'pkgng' in pkg_managers
    assert 'apk' in pkg_managers
    assert 'dpkg' in pkg_managers
    assert 'pkg5' in pkg_managers
    assert 'swpkg' in pkg_managers

# Generated at 2022-06-20 18:40:59.743292
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    PkgMgr().get_packages()

# Generated at 2022-06-20 18:41:01.694641
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib = LibMgr()
    assert lib._lib is None, "lib._lib should be None"


# Generated at 2022-06-20 18:41:04.290779
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    obj = PkgMgr()
    return_dict = obj.get_package_details(package=None)
    assert return_dict == {}


# Generated at 2022-06-20 18:41:07.838594
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    exception_raised = False
    try:
        dummy = pm.get_package_details("")
    except NotImplementedError:
        exception_rais

# Generated at 2022-06-20 18:41:16.967370
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_ = LibMgr()
    assert not hasattr(lib_, "LIB")
    assert not hasattr(lib_, "_lib")
    for method in (lib_.is_available, lib_.list_installed, lib_.get_package_details, lib_.get_packages):
        assert method.__module__ == "ansible.module_utils.facts.pkginfo"
    assert type(lib_.is_available()) == bool
    assert callable(lib_.list_installed)
    assert callable(lib_.get_package_details)
    assert callable(lib_.get_packages)


# Generated at 2022-06-20 18:41:20.753604
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class TestPkgMgr(PkgMgr):
        pass

    tpm = TestPkgMgr()

    assert isinstance(tpm, TestPkgMgr)

# Generated at 2022-06-20 18:41:24.341048
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    g = get_all_pkg_managers()
    for package in g.values():
        print(package.is_available())

if __name__ == '__main__':
    test_PkgMgr_is_available()

# Generated at 2022-06-20 18:41:26.112982
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    test_pkg_mgr = PkgMgr()
    assert False == test_pkg_mgr.is_available()


# Generated at 2022-06-20 18:41:29.642034
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Basic test to verify the method is_available exists
    mgr = PkgMgr()
    assert hasattr(mgr, 'is_available')


# Generated at 2022-06-20 18:41:39.112290
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    test_PkgMgr_get_package_details.out1 = {'name': 'firefox', 'version': '52.8.0'}
    assert test_PkgMgr_get_package_details.out1 == {'name': 'firefox', 'version': '52.8.0'}


# Generated at 2022-06-20 18:41:47.745560
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    # class PkgMgr is abstract, so create a dummy class to test it
    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return [{
                "name": "foo",
                "version": "1.0"
            }, {
                "name": "bar",
                "version": "2.0"
            }, {
                "name": "foo",
                "version": "3.0"
            }]
        def get_package_details(self, package):
            return package
    dummy_pm = DummyPkgMgr()
    packages = dummy_pm.get_packages()

# Generated at 2022-06-20 18:41:48.742636
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    mgr = PkgMgr()


# Generated at 2022-06-20 18:41:57.157868
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils.common.os import get_platform
    from ansible.module_utils.common import platform_by_distro
    from distutils.version import LooseVersion

    platform_system = get_platform().system()

    if platform_system == 'Darwin':
        from ansible.module_utils.fact_compression import CLIMgr as zip_cli
        test_cli = zip_cli()
        assert test_cli.is_available()

    elif platform_system == 'Linux':
        import re
        d = platform_by_distro()['distribution']

# Generated at 2022-06-20 18:41:58.675264
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-20 18:42:03.942229
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class TestLibMgr(LibMgr):
        LIB = 'os'

    assert(TestLibMgr().is_available())

    class TestLibMgr(LibMgr):
        LIB = 'zzz_i_dont_exist'

    assert(not TestLibMgr().is_available())


# Generated at 2022-06-20 18:42:05.549788
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert get_all_pkg_managers() is not None
    assert PkgMgr is not None

# Generated at 2022-06-20 18:42:12.393543
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._utils import get_all_subclasses
    for cls in get_all_subclasses(LibMgr):
        if cls.__dict__.get('LIB'):
            lib = cls()
            try:
                __import__(lib.LIB)
            except ImportError:
                pass
            else:
                is_available = lib.is_available()
                assert is_available



# Generated at 2022-06-20 18:42:13.341797
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-20 18:42:21.819826
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import os
    import sys
    import subprocess

    # call pip freeze in shell to list all pip packages
    # and store the output in variable pip_packages
    pip_packages = subprocess.check_output(["pip3", "freeze"])
    pip_packages_str = pip_packages.decode(encoding='UTF-8')

    # split pip_packages to a list and save it in variable pip_packages_list
    pip_packages_list = pip_packages_str.split('\n')

    # call dnf list installed in shell to list all rpm packages
    # and store the output in variable rpm_packages
    rpm_packages = subprocess.check_output(["dnf", "list", "installed"])
    rpm_packages_str = rpm_packages.decode(encoding='UTF-8')

    # split

# Generated at 2022-06-20 18:42:34.000573
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    class PkgMgrTest(PkgMgr):

        def is_available(self):
            return False

        def list_installed(self):
            return ['test']

        def get_package_details(self, package):
            return {}

    p = PkgMgrTest()
    assert p.is_available() == False

# Generated at 2022-06-20 18:42:34.898956
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr() is not None


# Generated at 2022-06-20 18:42:36.788337
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()
    assert len(pkg_managers.keys()) > 0

# Generated at 2022-06-20 18:42:47.273485
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    for name, obj in get_all_pkg_managers().items():
        if isinstance(obj, LibMgr):
            try:
                if obj().is_available():
                    print('%s: is_available() success' % name)
                else:
                    print('%s: is_available() failure' % name)
            except:
                print('%s: is_available() failure' % name)
        if isinstance(obj, CLIMgr):
            try:
                if obj().is_available():
                    print('%s: is_available() success' % name)
                else:
                    print('%s: is_available() failure' % name)
            except:
                print('%s: is_available() failure' % name)

# Generated at 2022-06-20 18:42:53.551421
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrClass(PkgMgr):
        def list_installed(self):
            return []
    class SubPkgMgrClass(PkgMgrClass):
        pass
    p = PkgMgrClass()
    assert p.list_installed() == []
    p2 = SubPkgMgrClass()
    assert p2.list_installed() == []

# Generated at 2022-06-20 18:42:54.520313
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert True



# Generated at 2022-06-20 18:42:58.026650
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = basic.AnsibleArguments({})
    test_pkgMgr = CLIMgr()
    assert test_pkgMgr.is_available() == False

# Generated at 2022-06-20 18:43:00.867337
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestClass(LibMgr):
        LIB = 'math'
    t = TestClass()
    assert t.is_available() == True


# Generated at 2022-06-20 18:43:04.109227
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    for name, pkg_mgr in get_all_pkg_managers().items():
        assert(name == pkg_mgr.__name__.lower())

# Generated at 2022-06-20 18:43:05.984436
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test with a bad return value
    a = PkgMgr()
    assert a.get_package_details("") is None


# Generated at 2022-06-20 18:43:14.846058
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr()

# Generated at 2022-06-20 18:43:21.884220
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    #The class PkgMgr does not have an implementation for the method list_installed
    #So, PkgMgr instance cannot be created.
    #So, let us try to create a subsclass of PkgMgr class
    class CLIMgrTest(CLIMgr):
        # Subclass should have the same method list_installed as the parent class
        def list_installed(self):
            return ['package1','package2']

    cliMgrTest = CLIMgrTest()
    # is_available method should return Ture if the package is available.
    assert cliMgrTest.is_available()
    #If the package is available, then the list_installed method should return a list of installed packages.
    assert cliMgrTest.list_installed() == ['package1','package2']


# Generated at 2022-06-20 18:43:22.265672
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pass

# Generated at 2022-06-20 18:43:22.794518
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr()


# Generated at 2022-06-20 18:43:23.380022
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    mgr = PkgMgr()

# Generated at 2022-06-20 18:43:23.970524
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    assert False, "This class shouldn't be used directly"

# Generated at 2022-06-20 18:43:26.450626
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert PkgMgr is not None
    assert PkgMgr.is_available is not None
    assert PkgMgr.list_installed is not None
    assert PkgMgr.get_package_details is not None
    assert PkgMgr.get_packages is not None

# Generated at 2022-06-20 18:43:29.040401
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        LIB = "test_module"

    p = TestLibMgr()
    assert p.is_available() == False
    assert p._lib is None


# Generated at 2022-06-20 18:43:31.133783
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    class TestClass(CLIMgr):
        CLI = None
    if TestClass().is_available() == False:
        return True
    return False


# Generated at 2022-06-20 18:43:42.602310
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    try:
        __import__('rpm')
        sys_has_rpm = True
    except ImportError:
        sys_has_rpm = False
    try:
        from functools import lru_cache
    except ImportError:
        lru_cache = None
    try:
        from importlib import reload
    except ImportError:
        reload = None

    class MockLibMgr(LibMgr):
        LIB = 'rpm'


# Generated at 2022-06-20 18:43:59.865874
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cli = CLIMgr()
    assert cli._cli is None


# Generated at 2022-06-20 18:44:07.385705
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common import get_all_subclasses
    classes = get_all_subclasses(LibMgr)
    for cls in classes:
        if cls.__name__ in ('PIPMgr', 'RPMMgr', 'GemMgr'):
            class_object = cls()
            assert class_object.is_available() is None, 'test failed for '+cls.__name__
        else:
            class_object = cls()
            assert class_object.is_available() is False, 'test failed for '+cls.__name__


# Generated at 2022-06-20 18:44:09.133386
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    assert(a.is_available() == False)

# Generated at 2022-06-20 18:44:12.640270
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.common._collections_compat import MutableMapping
    mgr = PkgMgr()
    assert type(mgr.is_available()) is bool, "result is of incorrect type"
    assert type(mgr.get_packages()) is MutableMapping, "result is of incorrect type"

# Generated at 2022-06-20 18:44:19.976030
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common._utils import get_all_subclasses
    import json
    import pytest

    pm_all = dict([(obj.__name__.lower(), obj) for obj in get_all_subclasses(PkgMgr) if obj not in (CLIMgr, LibMgr)])
    pm_all_names = sorted(pm_all.keys())
    pm_pass = json.loads(pytest.config.getoption('--pm_pass'))
    pm_fail = json.loads(pytest.config.getoption('--pm_fail'))
    pm_pass_ignore = json.loads(pytest.config.getoption('--pm_pass_ignore'))
    pm_fail_ignore = json.loads(pytest.config.getoption('--pm_fail_ignore'))
    pm

# Generated at 2022-06-20 18:44:21.600820
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert PkgMgr.list_installed() == NotImplemented


# Generated at 2022-06-20 18:44:22.398972
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    assert False # TODO: implement your test here


# Generated at 2022-06-20 18:44:23.461912
# Unit test for constructor of class LibMgr
def test_LibMgr():
    libmgr = LibMgr()
    assert libmgr is not None


# Generated at 2022-06-20 18:44:32.648634
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    """ Test of method 'is_available' of class CLIMgr
    """
    class CLIMgrTest(CLIMgr):
        CLI = 'fake_cli'
        def __init__(self):
            super(CLIMgrTest, self).__init__()
    from ansible.module_utils.six import PY3
    from mock import patch
    if PY3:
        import builtins
        builtins_name = 'builtins'
    else:
        builtins_name = '__builtin__'
    with patch('%s.open' % builtins_name) as mock_open,\
         patch('%s.get_bin_path' % builtins_name) as mocked_get_bin_path:
        cli_mgr_test = CLIMgrTest()

# Generated at 2022-06-20 18:44:34.163691
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkgmgr = LibMgr()
    assert pkgmgr


# Generated at 2022-06-20 18:45:08.833329
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgrTest(CLIMgr):
        CLI = 'true'

    mgr = CLIMgrTest()
    assert mgr.is_available()

    class CLIMgrTest(CLIMgr):
        CLI = 'false'

    mgr = CLIMgrTest()
    assert not mgr.is_available()

# Generated at 2022-06-20 18:45:13.944197
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_managers = get_all_pkg_managers()
    for manager in pkg_managers:
        pkg_mgr_obj = pkg_managers[manager]()
        if pkg_mgr_obj.is_available():
            assert pkg_mgr_obj.list_installed()



# Generated at 2022-06-20 18:45:14.821252
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    assert isinstance(CLIMgr(), CLIMgr)
    assert issubclass(CLIMgr, PkgMgr)

# Generated at 2022-06-20 18:45:16.752324
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pkg_mgr = PkgMgr()
    result = pkg_mgr.list_installed()
    assert result is None


# Generated at 2022-06-20 18:45:28.023237
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import sys
    #saved_sys_modules = sys.modules.copy()

# Generated at 2022-06-20 18:45:35.311172
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    #import sys
    #sys.path.append('/home/gym/Desktop/Lazis/ansible/lib/ansible/module_utils/')

    class TestCLIMgr(CLIMgr):
        CLI = 'python'
        def list_installed(self):
            return ['abracadabra']
        def get_package_details(self, package):
            return {'name': 'abracadabra', 'version': '0.0.01'}

    test = TestCLIMgr()
    print(test.is_available())
    print(test.get_packages())

if __name__ == '__main__':
    test_CLIMgr()

# Generated at 2022-06-20 18:45:36.875517
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    x = CLIMgr()
    assert x._cli is None


# Generated at 2022-06-20 18:45:39.998712
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # If a package manager is installed the test should pass, otherwise it should fail
    try:
        assert (get_all_pkg_managers())
    except AssertionError:
        # fail
        assert False

# Generated at 2022-06-20 18:45:47.600649
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['test1', 'test2']

        def get_package_details(self, package):
            return {'name': 'test', 'version': '1.0'}

    package_manager = TestPkgMgr()
    packages = package_manager.get_packages()
    assert packages['test'][0]['name'] == 'test'

# Generated at 2022-06-20 18:45:50.955812
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    # Testing on a windows machine
    print("Testing is_available of class CLIMgr on windows machine")
    candy = CLIMgr()
    candy.CLI = 'date'
    if candy.is_available():
        print("Test passed")

if __name__ == "__main__":
    test_CLIMgr_is_available()

# Generated at 2022-06-20 18:47:00.099361
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkgmgr=CLIMgr()
    assert pkgmgr.is_available() == False
    pkgmgr.CLI = 'dpkg'
    assert pkgmgr.is_available() == True
    pkgmgr.CLI = 'foo'
    assert pkgmgr.is_available() == False


# Generated at 2022-06-20 18:47:01.076325
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    assert PkgMgr.is_available(PkgMgr)


# Generated at 2022-06-20 18:47:03.154505
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    from ansible.module_utils.common.modules.package import PkgMgr

    pkg_mgr_test_obj = PkgMgr()
    assert pkg_mgr_test_obj.is_available() == NotImplementedError

# Generated at 2022-06-20 18:47:05.004141
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    import python_rpmmodule

    mgr = python_rpmmodule.PyYum()
    assert mgr.is_available()


# Generated at 2022-06-20 18:47:06.358609
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert LibMgr().is_available() == False
    assert LibMgr()._lib == None


# Generated at 2022-06-20 18:47:09.706087
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    obj = PkgMgr()
    try:
        res = obj.is_available()
    except NotImplementedError:
        assert True
        return
    assert False, "This method should have thrown an exception"



# Generated at 2022-06-20 18:47:11.624479
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    instance = PkgMgr()
    assert instance.list_installed() == None


# Generated at 2022-06-20 18:47:13.868375
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)


# Generated at 2022-06-20 18:47:17.432917
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            super(PkgMgr, self).__init__()

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self):
            pass

    pkgmgr = TestPkgMgr()
    assert pkgmgr.is_available() is True


# Generated at 2022-06-20 18:47:29.245514
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    mgr = PkgMgr()
    assert mgr.get_packages() == {}, 'expected empty dictionary'
    mgr.list_installed = lambda : ['foo']
    mgr.get_package_details = lambda x: {'name': x, 'version': '1.0'}
    assert mgr.get_packages() == {'foo': [{'name': 'foo', 'version': '1.0', 'source': 'pkgmgr'}]}, 'expected foo'
    mgr.list_installed = lambda : ['foo', 'bar', 'foo']

# Generated at 2022-06-20 18:50:31.457156
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    pkg_mgr = CLIMgr()
    pkg_mgr.CLI = 'fake_cmd'
    assert pkg_mgr.is_available() == False
    pkg_mgr.CLI = 'emacs'
    assert pkg_mgr.is_available() == True

# Generated at 2022-06-20 18:50:39.142550
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types


# Generated at 2022-06-20 18:50:43.770602
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    for pkg_mgr in get_all_pkg_managers().values():
        if isinstance(pkg_mgr, CLIMgr):
            if pkg_mgr().is_available():
                assert(pkg_mgr()._cli is not None)
            else:
                assert(pkg_mgr()._cli is None)
