

# Generated at 2022-06-20 18:40:49.822248
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()
    assert isinstance(pkg_mgr, PkgMgr) is True

# Generated at 2022-06-20 18:40:51.064642
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass


# Generated at 2022-06-20 18:41:02.283182
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            self._lib = None
            super(TestPkgMgr, self).__init__()

        def is_available(self):
            found = False
            try:
                self._lib = __import__(self.LIB)
                found = True
            except ImportError:
                pass
            return found

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    class TestLibMgr(LibMgr):
        LIB = 'test'

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    class TestCLIMgr(CLIMgr):
        CLI = 'test'


# Generated at 2022-06-20 18:41:04.846054
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert LibMgr()


# Generated at 2022-06-20 18:41:16.865843
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    import unittest
    import os
    import json
    import pytest

    if not __name__ == '__main__':
        pytest.main(["-x", os.path.realpath(__file__)])

    class TestPkgMgrInstance(PkgMgr):
        import os
        import json

        def is_available(self):
            found = False
            try:
                with open("test_data.json", "r") as json_file:
                    self.pkg_data = json.load(json_file)
                found = True
            except:
                pass

            return found

        def list_installed(self):
            return list(self.pkg_data.keys())

    class TestPkgMgr(unittest.TestCase):
        def setUp(self):
            self.test_pkg

# Generated at 2022-06-20 18:41:21.787248
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # We have to test the availability of each individual package manager.
    # Ideally we'd like to follow the path of the package manager, but that would
    # add a lot of work.
    # For now, the test is rather simplistic, but at least it tests the path
    package_managers = get_all_pkg_managers()
    for pm in package_managers:
        obj = package_managers[pm]()
        assert obj.is_available() == False

# Generated at 2022-06-20 18:41:29.867571
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # collect all package manager names
    all_pkg_managers = get_all_pkg_managers().keys()

    # check that expected package managers are there
    assert 'apt' in all_pkg_managers
    assert 'apk' in all_pkg_managers
    assert 'dnf' in all_pkg_managers
    assert 'yum' in all_pkg_managers
    assert 'zypper' in all_pkg_managers
    assert 'portage' in all_pkg_managers
    assert 'pkgng' in all_pkg_managers
    assert 'pip' in all_pkg_managers
    assert 'gem' in all_pkg_managers
    assert 'npm' in all_pkg_managers
    assert 'composer' in all_pkg_managers
    assert 'go' in all_

# Generated at 2022-06-20 18:41:31.170626
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    assert (PkgMgr.get_package_details('foo') == None)

# Generated at 2022-06-20 18:41:42.653371
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    '''test_CLIMgr_is_available'''
    from unittest.mock import MagicMock
    from ansibullbot.wrappers.detect_pkg_mgrs import CLIMgr
    from ansibullbot.wrappers.detect_pkg_mgrs import get_bin_path

    def mock_get_bin_path(command):
        return "test_bin_path"

    class TestCLIMgr(CLIMgr):
        '''TestCLIMgr'''
        CLI = "dummy"

    test_class = TestCLIMgr()
    test_class._cli = None
    assert test_class.is_available() == False

    get_bin_path = MagicMock(side_effect=mock_get_bin_path)

# Generated at 2022-06-20 18:41:47.538473
# Unit test for constructor of class PkgMgr
def test_PkgMgr():

    pkg = PkgMgr()
    assert pkg

    assert not hasattr(pkg, 'is_available')
    assert not hasattr(pkg, 'list_installed')
    assert not hasattr(pkg, 'get_package_details')

# Generated at 2022-06-20 18:41:53.075714
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkgmgr = PkgMgr()
    assert pkgmgr is not None


# Generated at 2022-06-20 18:41:56.270235
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    #Test Setup
    # None

    #Test Execution
    package_managers = get_all_pkg_managers()

    #Test Assertions
    #assert isinstance(package_managers, dict)

    #Test TearDown
    #None

# Generated at 2022-06-20 18:41:58.718854
# Unit test for constructor of class LibMgr
def test_LibMgr():

    l = LibMgr()
    assert l is not None


# Generated at 2022-06-20 18:42:00.435888
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert LibMgr()._lib is None


# Generated at 2022-06-20 18:42:02.141848
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli = CLIMgr()
    assert cli.is_available() == False

# Generated at 2022-06-20 18:42:03.651336
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    c = CLIMgr()
    assert c is not None

# Generated at 2022-06-20 18:42:04.998644
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-20 18:42:06.444948
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_class = CLIMgr()
    assert test_class._cli == None


# Generated at 2022-06-20 18:42:12.707912
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg_managers = get_all_pkg_managers()

    assert all(issubclass(pkg_managers[pkg_manager], PkgMgr) for pkg_manager in pkg_managers)
    assert all(pkg_mgr not in pkg_managers for pkg_mgr in ('PkgMgr', 'LibMgr', 'CLIMgr'))

# Generated at 2022-06-20 18:42:13.978675
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lm = LibMgr()
    assert lm._lib is None


# Generated at 2022-06-20 18:42:23.258513
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert obj is not None



# Generated at 2022-06-20 18:42:25.557551
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # TODO: Implement unit test for method PkgMgr.get_packages
    # AssertionError: Not implemented
    pass


# Generated at 2022-06-20 18:42:29.336503
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    cm = CLIMgr()
    assert cm is not None
    assert type(cm) == CLIMgr
    assert isinstance(cm, PkgMgr)
    assert isinstance(cm, object)


# Generated at 2022-06-20 18:42:33.177408
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """Test the availability of any pkg manager"""

    pkg_mgr = get_all_pkg_managers()
    for pkg in pkg_mgr:
        assert pkg_mgr[pkg]().is_available() is not None


# Generated at 2022-06-20 18:42:40.365042
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    from ansible.module_utils.common.process import get_bin_path, get_distribution
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import iteritems, string_types


# Generated at 2022-06-20 18:42:42.207158
# Unit test for constructor of class LibMgr
def test_LibMgr():
    pkgmgr = LibMgr()
    assert pkgmgr._lib is None


# Generated at 2022-06-20 18:42:50.844723
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # pylint: disable=bare-except

    # Check if 'PkgMgr' is not in get_all_pkg_managers()
    for pkg_mgr in get_all_pkg_managers().values():
        if pkg_mgr.__name__.lower() == 'pkgmgr':
            raise AssertionError("class 'PkgMgr' is not an implementation of 'PkgMgr'")

    # Check if 'CLIMgr' is not in get_all_pkg_managers()
    for pkg_mgr in get_all_pkg_managers().values():
        if pkg_mgr.__name__.lower() == 'climgr':
            raise AssertionError("class 'CLIMgr' is not an implementation of 'PkgMgr'")

    # Check if 'LibM

# Generated at 2022-06-20 18:42:53.078359
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert isinstance(get_all_pkg_managers(), dict)
    assert get_all_pkg_managers()

# Generated at 2022-06-20 18:42:57.040974
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            return []
    test_pmgr = PkgMgrTest()
    pkgs = test_pmgr.list_installed()
    assert isinstance(pkgs, list)

# Generated at 2022-06-20 18:42:59.023237
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    assert LibMgr().is_available() == False
    assert isinstance(LibMgr().is_available(), bool)


# Generated at 2022-06-20 18:43:15.228474
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pass

# Generated at 2022-06-20 18:43:19.487153
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():

    class testPkgMgr(PkgMgr):
        def list_installed(self):
            return [1,2,3]
        def get_package_details(self, package):
            return {'name': package, 'version': package}

    tMgr = testPkgMgr()
    result = tMgr.list_installed()
    assert result==[1,2,3]


# Generated at 2022-06-20 18:43:29.776829
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    # Test 1 - Check that the method is_available returns false when called
    # on an instance of class PkgMgr
    pm = PkgMgr()
    assert pm.is_available() == False

    # Test 2 - Check that the method is_available returns false when called
    # on an instance of class CLIMgr
    cli = CLIMgr()
    assert cli.is_available() == False

    # Test 3 - Check that the method is_available returns false when called
    # on an instance of class LibMgr
    lib = LibMgr()
    assert lib.is_available() == False

    # Test 4 - Check that the method is_available returns true when called
    # on an instance of class CLIMgr after initializing the _cli attribute
    cli = CLIMgr()
    cli._cli = True

# Generated at 2022-06-20 18:43:31.888343
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    # unit test for method list_installed of class PkgMgr
    assert PkgMgr.list_installed() != None


# Generated at 2022-06-20 18:43:40.435878
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def is_available(self):
            return True

        def list_installed(self):
            return ['test_package', 'test_package2']

        def get_package_details(self, package):
            return {'name': 'test_package'}

    pkg_mgr = TestPkgMgr()
    result = pkg_mgr.get_packages()
    assert result == {'test_package': [{'name': 'test_package', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-20 18:43:44.823914
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class DummyPkgMgr(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            pass

    dpm = DummyPkgMgr()
    assert dpm.is_available() is None


# Generated at 2022-06-20 18:43:55.971813
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class Mock_PkgMgr(PkgMgr):
        def __init__(self):
            self.installed = []

        def is_available(self):
            super(Mock_PkgMgr, self).is_available()
            return True

        def list_installed(self):
            super(Mock_PkgMgr, self).list_installed()
            return self.installed

        def get_package_details(self, package):
            super(Mock_PkgMgr, self).get_package_details(package)
            return dict(name=package)

    mock_PkgMgr = Mock_PkgMgr()
    mock_PkgMgr.installed = ["python"]
    # test_pk_mgr = PkgMgr()

# Generated at 2022-06-20 18:44:02.442997
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():

    class TestPkgMgr(PkgMgr):

        @staticmethod
        def list_installed():

            return ['foo-1.0', 'bar-1.1', 'baz-1.0', 'baz-1.0-1.el5']

        @staticmethod
        def get_package_details(package):

            details = {}
            details['name'] = package.split('-')[0]
            details['version'] = package.split('-')[1]
            return details

    test_obj = TestPkgMgr()

# Generated at 2022-06-20 18:44:04.661296
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cMgr = CLIMgr()
    assert not cMgr.is_available()

# Generated at 2022-06-20 18:44:05.680300
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pass


# Generated at 2022-06-20 18:44:41.193047
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pm = PkgMgr()
    assert not pm.is_available()
    assert not pm.list_installed()
    assert not pm.get_package_details("sdkfjhsekdjfh")
    assert not pm.get_packages()


# Unit Test for constructor of Class LibMgr

# Generated at 2022-06-20 18:44:43.707623
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class Test(LibMgr):
        LIB = 'ansible.module_utils.basic'
    t = Test()
    assert t.is_available()


# Generated at 2022-06-20 18:44:45.329164
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pm = PkgMgr()
    assert not pm.list_installed()



# Generated at 2022-06-20 18:44:52.759051
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    pkg = get_all_pkg_managers()
    assert pkg['aix_software_repository']
    assert pkg['apt']
    assert pkg['apk']
    assert pkg['apt_rpm']
    assert pkg['yumpkg5']
    assert pkg['yumpkg']
    assert pkg['zypperpkg']
    assert pkg['yum']
    assert pkg['dnf']
    assert pkg['portage']
    assert pkg['pkgin']
    assert pkg['pkg5']
    assert pkg['pkg_ng']
    assert pkg['pkg']
    assert pkg['swlist']
    assert pkg['swupd']
    assert pkg['urpm']
    assert pkg['urpmipkg']
    assert pkg['xbps']


# Generated at 2022-06-20 18:45:02.165956
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):

        def __init__(self):

            self.packages = ['package1', 'package2']
            self.packages_details = {}

        def is_available(self):
            return True

        def list_installed(self):
            return self.packages

        def get_package_details(self, package):
            package_details = self.packages_details[package]
            package_details['source'] = self.__class__.__name__.lower()
            return package_details

    pkg_mgr = TestPkgMgr()
    pkg_mgr.packages_details['package1'] = {
        'name': 'package1',
        'version': '1.0',
    }

# Generated at 2022-06-20 18:45:03.617045
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    assert len(get_all_pkg_managers()) >= 0

# Generated at 2022-06-20 18:45:05.153382
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    package_manager = CLIMgr()
    assert package_manager._cli is None


# Generated at 2022-06-20 18:45:08.211874
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    installed_package_managers = set()
    for name, obj in get_all_pkg_managers().items():
        if obj().is_available():
            installed_package_managers.add(name)
    assert installed_package_managers


# Generated at 2022-06-20 18:45:11.248340
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgr_test(PkgMgr):
        def is_available(self):
            pass
        def list_installed(self):
            pass
        def get_package_details(self, package):
            return package
    expect = 'unit_test'
    result = PkgMgr_test().get_package_details(expect)
    assert result == expect

# Generated at 2022-06-20 18:45:20.987157
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    p = PkgMgr()
    p.list_installed = lambda: ['A', 'B', 'C']
    d = {
        'A': {'name': 'A', 'version': '1'},
        'B': {'name': 'B', 'version': '2'},
        'C': {'name': 'C', 'version': '3'},
    }
    p.get_package_details = lambda x: d[x]
    for name in ['D', 'B', 'A']:
        p1 = p.get_package_details(name)
        p2 = p.get_packages()[name][0]
        assert p1['name'] == p2['name']
        assert p1['version'] == p2['version']

# Generated at 2022-06-20 18:46:30.365423
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_managers = get_all_pkg_managers()

    assert type(pkg_managers) == dict
    assert len(pkg_managers) >= 1
    assert 'apt' in pkg_managers
    assert 'yum' in pkg_managers

# Generated at 2022-06-20 18:46:31.866508
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    # Test init
    assert PkgMgr()



# Generated at 2022-06-20 18:46:33.490444
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert LibMgr().__class__.__name__ == 'LibMgr'


# Generated at 2022-06-20 18:46:41.389007
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from distutils.util import strtobool
    import platform
    import sys
    import os.path
    # is_available of libmgr class should return True/False if the python module is installed or not.
    # When we call module, the path of the module will be added in sys.path
    module_path = os.path.dirname(__file__)
    module_name = 'ansible.module_utils.basic'
    sys.path.append(module_path)
    # We have to delete the entry, as it has been added to sys.path
    del sys.path[-1]
    try:
        module = __import__(module_name)
        assert module.basic.__name__ == 'ansible.module_utils.basic'
    except ImportError:
        platform_dist = platform.dist()
       

# Generated at 2022-06-20 18:46:45.755773
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgr(object):

        def list_installed(self):
            # This method should return a list of installed packages, each list item will be passed to get_package_details
            pass

    print(get_all_pkg_managers().get('apt').list_installed())


# Generated at 2022-06-20 18:46:54.826721
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    from ansible.module_utils.common.collections import ImmutableDict
    pk = PkgMgr()
    assert not isinstance(pk, PkgMgr)
    pk = PkgMgr.__new__(PkgMgr)
    assert isinstance(pk, PkgMgr)
    assert PkgMgr.__doc__ is not None
    assert pk.is_available.__doc__ is not None
    assert pk.list_installed.__doc__ is not None
    assert pk.get_package_details.__doc__ is not None
    assert pk.get_packages.__doc__ is not None
    pk.__dict__ = ImmutableDict({"is_available": lambda: 0})

# Generated at 2022-06-20 18:46:56.998382
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    sut = PkgMgr()
    package = {}
    result = sut.get_package_details(package)
    assert result == {'name':'None', 'version':'None'}


# Generated at 2022-06-20 18:47:01.255444
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    cli_mgr = CLIMgr()
    cli_mgr.CLI = 'iconv'
    assert cli_mgr.is_available()
    cli_mgr.CLI = 'jksdkljklj'
    assert not cli_mgr.is_available()

# Generated at 2022-06-20 18:47:01.818103
# Unit test for constructor of class LibMgr
def test_LibMgr():

    assert LibMgr()

# Generated at 2022-06-20 18:47:02.334831
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    pass

# Generated at 2022-06-20 18:49:56.198106
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    # Note: These unit tests rely on the pacman and RPM package managers
    #       being available on the testing machine.

    # Create the object
    pac_mgr = get_all_pkg_managers()['pacman']()
    rpm_mgr = get_all_pkg_managers()['rpm']()

    # Run the test
    pac_pkgs = pac_mgr.get_packages()
    rpm_pkgs = rpm_mgr.get_packages()

    assert 'pacman' in pac_pkgs['pacman']
    assert 'pacman' in rpm_pkgs['pacman']
    assert 'pacman-mirrorlist' in rpm_pkgs['pacman-mirrorlist']
    assert 'pacman-mirrorlist' not in pac_pkgs['pacman-mirrorlist']

# Generated at 2022-06-20 18:50:01.441846
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    from ansible.module_utils.facts.pkg_mgr import LibMgr
    lib = LibMgr()
    lib.LIB = 'curl'
    assert lib.is_available()


# Generated at 2022-06-20 18:50:10.148327
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class TestCLIMgr(CLIMgr):
        def __init__(self, path):
            self.CLI = path
            super(TestCLIMgr, self).__init__()
    real_get_bin_path = get_bin_path

    def mock_get_bin_path(value):
        return value

    get_bin_path = mock_get_bin_path
    test_cli_mgr_true = TestCLIMgr('./fake_program')
    assert test_cli_mgr_true.is_available() is True

    test_cli_mgr_false = TestCLIMgr('/tmp/does/not/exist')
    assert test_cli_mgr_false.is_available() is False
    get_bin_path = real_get_bin_path

# Generated at 2022-06-20 18:50:15.627785
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    from ansible.module_utils.common.collections import ImmutableDict
    test_case = []
    test_case.append(ImmutableDict(name='test_package_1', version='1.1', source='test_source'))
    test_case.append(ImmutableDict(name='test_package_1', version='1.2', source='test_source'))
    test_case.append(ImmutableDict(name='test_package_2', version='2.1', source='test_source'))
    test_case.append(ImmutableDict(name='test_package_2', version='2.2', source='test_source'))
    test_case.append(ImmutableDict(name='test_package_2', version='2.3', source='test_source'))
    test_

# Generated at 2022-06-20 18:50:23.394831
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    class A(PkgMgr):
        def is_available(self):
            return False
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return {}

    class B(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return []
        def get_package_details(self, package):
            return {}

    x = A()
    y = B()

    assert x.is_available() == False
    assert y.is_available() == True


# Generated at 2022-06-20 18:50:25.783849
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    # Test filter
    assert isinstance(get_all_pkg_managers()['cli'], CLIMgr)
    assert isinstance(get_all_pkg_managers()['lib'], LibMgr)

# Generated at 2022-06-20 18:50:26.760497
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkg = PkgMgr()
    assert pkg.is_available() == None


# Generated at 2022-06-20 18:50:32.480017
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    import pytest
    class CLIMgrTest(CLIMgr):
        CLI = 'true'
    assert CLIMgrTest().is_available() is True
    assert CLIMgrTest()._cli == 'true'
    class CLIMgrTest2(CLIMgr):
        CLI = 'false'
    assert CLIMgrTest2().is_available() is False

# Generated at 2022-06-20 18:50:35.382997
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """
    This function tests the output of list_installed method of
    class PkgMgr.
    """
    test_object = PkgMgr()
    result = test_object.list_installed()
    assert isinstance(result, list)


# Generated at 2022-06-20 18:50:40.235492
# Unit test for constructor of class LibMgr
def test_LibMgr():
    lib_mgr = LibMgr()
    assert lib_mgr._lib is None
# end of test_LibMgr --------------------------------------------------------------

