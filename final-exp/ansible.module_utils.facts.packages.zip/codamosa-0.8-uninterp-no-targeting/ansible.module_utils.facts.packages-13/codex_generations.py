

# Generated at 2022-06-20 18:40:49.202883
# Unit test for constructor of class LibMgr
def test_LibMgr():

    mock_object = LibMgr()
    assert mock_object._lib == None



# Generated at 2022-06-20 18:40:51.705558
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():

    assert isinstance(get_all_pkg_managers(), dict)
    assert 'yumpkgmgr' in get_all_pkg_managers()

# Generated at 2022-06-20 18:40:54.052487
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    pkgmgr = PkgMgr()
    assert pkgmgr.is_available() == NotImplementedError


# Generated at 2022-06-20 18:41:04.909027
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    class PkgMgrSubclass(PkgMgr):
        def list_installed(self):
            return ['test_package1', 'test_package2']
        def get_package_details(self, package):
            if package == 'test_package1':
                return { 'name' : 'test_package1' , 'version' : '1.0' }
            elif package == 'test_package2':
                return { 'name' : 'test_package1' , 'version' : '1.1' }
    pkgmgr = PkgMgrSubclass()

# Generated at 2022-06-20 18:41:16.917417
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    class Dummy1(PkgMgr):
        def is_available(self):
            return False
        def list_installed(self):
            return ['package1', 'package2']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.1.1'}
    class Dummy2(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['package3', 'package4']
        def get_package_details(self, package):
            return {'name': package, 'version': '1.1.1'}
    test_obj = PkgMgr()
    test_obj1 = Dummy1()
    test_obj2 = Dummy2()
    assert not test_obj.is_available

# Generated at 2022-06-20 18:41:17.860208
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    return



# Generated at 2022-06-20 18:41:20.802085
# Unit test for constructor of class LibMgr
def test_LibMgr():
    cli_mgr = LibMgr()
    assert cli_mgr._lib == None


# Generated at 2022-06-20 18:41:26.298906
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class TestPkgMgr(PkgMgr):
        def __init__(self):
            pass

        def is_available(self):
            pass

        def list_installed(self):
            pass

        def get_package_details(self, package):
            pass

    t = TestPkgMgr()
    # check if the method is implemented
    assert callable(getattr(t, 'list_installed', None))


# Generated at 2022-06-20 18:41:29.879725
# Unit test for constructor of class LibMgr
def test_LibMgr():
    try:
        class One(LibMgr):
            LIB = 'os'
        x = One()
    except NameError:
        pass
    else:
        raise AssertionError('NameError not raised')
    class Two(LibMgr):
        LIB = 'ansible.module_utils.six'
    y = Two()
    assert y


# Generated at 2022-06-20 18:41:31.507958
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    test_class = LibMgr()
    assert test_class.is_available() != True


# Generated at 2022-06-20 18:41:37.867599
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class test_LibMgr(LibMgr):
        LIB = 'lib'

    assert test_LibMgr()._lib is None


# Generated at 2022-06-20 18:41:44.652186
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    """
    @pytest.mark.parametrize("self,package,want", [
        (PkgMgr(), {'name': 'python', 'version': '2.7.12'}, {'name': 'python', 'version': '2.7.12'}),
    ])
    def test_PkgMgr_get_package_details(self, package, want):
        assert self.get_package_details(package) == want
    """
    # test not passable without implementation of abstractmethod
    pass

# Generated at 2022-06-20 18:41:51.496785
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    # Test case 1: Expect to get Exception
    test_pkgmgr_obj = PkgMgr()
    try:
        test_pkgmgr_obj.get_package_details("test_package")
    except Exception as err:
        #Expected Exception
        return
    # Expected Exception not raised, Test case failed
    raise Exception("Expected Exception not raised in Test case 1")


# Generated at 2022-06-20 18:41:53.060831
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test_libmgr = LibMgr()

    assert(test_libmgr != None)


# Generated at 2022-06-20 18:41:55.876563
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    class _CLIMgr(CLIMgr):
        CLI = '_CLIMgr'
    assert _CLIMgr().is_available() == False

# vim: set et ts=4 sw=4 tw=79:

# Generated at 2022-06-20 18:41:56.749330
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-20 18:42:07.098250
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():

    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

        def list_installed(self):
            return ['package1', 'package2']

        def get_package_details(self, package):
            return {'name': package, 'version': '0.0.1', 'source': 'testpkgmgr'}
    assert TestPkgMgr().get_packages() == {'package1': [{'name': 'package1', 'version': '0.0.1', 'source': 'testpkgmgr'}],
                                           'package2': [{'name': 'package2', 'version': '0.0.1', 'source': 'testpkgmgr'}]}

# Generated at 2022-06-20 18:42:09.212062
# Unit test for constructor of class LibMgr
def test_LibMgr():
    test = LibMgr()
    test.LIB = 'test'



# Generated at 2022-06-20 18:42:13.723425
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    dnf_mgr = CLIMgr()
    # dnf_mgr.is_available is supposed to return True if the package manager is currently installed/usable
    assert dnf_mgr.is_available() is True, 'Expected that dnf_mgr.is_available() would return true.'

# Generated at 2022-06-20 18:42:19.611781
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class ConcretePkgMgr(PkgMgr):
        def is_available(self):
            return True
        def list_installed(self):
            return ['hello']
        def get_package_details(self, package):
            return {'name': 'hello', 'version': 'world'}
    concrete_pkg_mgr = ConcretePkgMgr()
    assert concrete_pkg_mgr.list_installed() == ['hello']


# Generated at 2022-06-20 18:42:29.992256
# Unit test for constructor of class LibMgr
def test_LibMgr():
    # class LibMgr has no __init__
    # assert __init__ is not None
    assert issubclass(LibMgr, PkgMgr)


# Generated at 2022-06-20 18:42:30.889233
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pass

# Generated at 2022-06-20 18:42:34.559685
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    managers = get_all_pkg_managers()
    assert isinstance(managers, dict)
    assert len(managers) > 0
    assert 'gem' in managers
    assert 'npm' in managers
    assert 'pip' in managers
    assert 'yum' in managers

# Generated at 2022-06-20 18:42:36.969101
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    is_available_result = CLIMgr.is_available(self)
    assert(isinstance(is_available_result, bool))

# Generated at 2022-06-20 18:42:48.100209
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():

    mgr_class_list = get_all_subclasses(PkgMgr)
    mgr_instance_list = [cls() for cls in mgr_class_list]

    # available managers should return True
    for mgr in mgr_instance_list:
        if mgr.is_available() is not True:
            msg = 'manager {0} returned False for is_available'.format(mgr.__class__)
            raise AssertionError(msg)
    
    # unavailable managers should return False
    class FakePkgMgr(PkgMgr):

        def is_available(self):
            return False

    fake_mgr = FakePkgMgr()

# Generated at 2022-06-20 18:42:50.783025
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr.CLI is None
    assert mgr._cli is None


# Generated at 2022-06-20 18:42:55.253538
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    class CLIMgr(PkgMgr):
        CLI = None

    pm = CLIMgr()
    pm.CLI = "test_cli"
    assert pm.is_available() == True
    pm.CLI = "test_cli2"
    assert pm.is_available() == False



# Generated at 2022-06-20 18:42:56.242267
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False


# Generated at 2022-06-20 18:42:57.334167
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    package = PkgMgr()
    return package

# Generated at 2022-06-20 18:43:04.389147
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):

        def __init__(self):
            self.name = str("test")

        def is_available(self):
            return True
        
        def list_installed(self):
            return [self.name]

        def get_package_details(self, package):
            return None
    
    p = PkgMgrTest()
    assert p.list_installed() == [p.name]


# Generated at 2022-06-20 18:43:19.800916
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pass


# Generated at 2022-06-20 18:43:26.162207
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    pkg_mgr_dict = get_all_pkg_managers()
    assert CLIMgr.__name__.lower() not in pkg_mgr_dict
    assert LibMgr.__name__.lower() not in pkg_mgr_dict
    assert 'apt' in pkg_mgr_dict
    assert 'dnf' in pkg_mgr_dict
    assert 'yum' in pkg_mgr_dict

# Generated at 2022-06-20 18:43:27.472769
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert(CLIMgr.is_available(CLIMgr()) == False)

# Generated at 2022-06-20 18:43:30.326124
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    x = PkgMgr()
    assert x.is_available() is NotImplementedError
    assert x.list_installed() is NotImplementedError
    assert x.get_package_details() is NotImplementedError

# Generated at 2022-06-20 18:43:31.813364
# Unit test for constructor of class CLIMgr
def test_CLIMgr():

    obj = CLIMgr()
    assert obj._cli == None


# Generated at 2022-06-20 18:43:33.669127
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr.is_available() == False

# Generated at 2022-06-20 18:43:35.055655
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    assert callable(PkgMgr)

# Generated at 2022-06-20 18:43:42.504380
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    # mocking to import library _collections_abc which is required
    # to import library collections.abc
    import sys
    try:
        import _collections_abc  # noqa
        sys.modules['_collections_abc'] = _collections_abc
    except ImportError:
        pass

    class LibMgrSub(LibMgr):

        LIB = 'collections.abc'

    libMgrSub = LibMgrSub()
    # testing if _collections_abc is imported or not
    assert libMgrSub.is_available() == True


# Generated at 2022-06-20 18:43:47.422688
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():

    class CLIMgr_is_available(CLIMgr):
        CLI = 'apt-get'

    def mock_get_bin_path(cli):
        if cli == 'apt-get':
            raise ValueError
        else:
            return True

    c = CLIMgr_is_available()
    c.get_bin_path = mock_get_bin_path

    c.is_available()
    c._cli == None
    assert c.is_available()



# Generated at 2022-06-20 18:43:51.898403
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    import os

    os.environ["PATH"] = "/bin:/usr/bin"
    assert CLIMgr().is_available() == True

    os.environ["PATH"] = "/usr/bin"
    assert CLIMgr().is_available() == False


# Generated at 2022-06-20 18:44:23.669550
# Unit test for method is_available of class PkgMgr
def test_PkgMgr_is_available():
    """
    Unit test of class PkgMgr is_available
    """
    class TestPkgMgr(PkgMgr):
        def is_available(self):
            return True

    assert TestPkgMgr().is_available() is True


# Generated at 2022-06-20 18:44:28.217728
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    expected_dict = {'name': 'erlang', 'version': '20.3.3-1.el7', 'source': 'rpm'}
    # rpm and yum packages differ in the name of the package
    assert expected_dict == rpm.get_package_details(('erlang', '20.3.3-1.el7')) or expected_dict == yum.get_package_details(('erlang', '20.3.3-1.el7'))

# Generated at 2022-06-20 18:44:31.417118
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    class LibMgr_test(LibMgr):
        LIB = 'os'
    libmgr_test = LibMgr_test()
    assert libmgr_test.is_available()


# Generated at 2022-06-20 18:44:34.765223
# Unit test for constructor of class LibMgr
def test_LibMgr():
    assert issubclass(LibMgr, PkgMgr)
    assert LibMgr().is_available() is False
    assert isinstance(LibMgr().get_packages(), dict)


# Generated at 2022-06-20 18:44:36.344233
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pkg_mgr = PkgMgr()
    assert pkg_mgr != None


# Generated at 2022-06-20 18:44:40.784744
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert (mgr.is_available() == False)
    # TODO: If this test runs from a control node that has python installed, then a better test would be:
    # assert (mgr.is_available() == True)




# Generated at 2022-06-20 18:44:42.031872
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    a = CLIMgr()
    assert a._cli is None


# Generated at 2022-06-20 18:44:44.876037
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    """
    Test list_installed of class PkgMgr
    """
    # Test that it is a abstract method
    assert callable(PkgMgr.list_installed)


# Generated at 2022-06-20 18:44:45.784195
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    package_manager_obj = PkgMgr()

# Generated at 2022-06-20 18:44:47.596055
# Unit test for method is_available of class PkgMgr

# Generated at 2022-06-20 18:45:46.813092
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    assert False, "Test not implemented"


# Generated at 2022-06-20 18:45:48.485165
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    mgr = CLIMgr()
    assert mgr.is_available()== False

# Generated at 2022-06-20 18:45:53.790235
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():

    from ansible.module_utils.common.utils import get_all_subclasses
    for PkgScls in get_all_subclasses(LibMgr):
        if PkgScls.LIB:
            lib_instance = PkgScls()
            assert lib_instance.is_available()
    assert True


# Generated at 2022-06-20 18:45:58.668597
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_cli = "test_CLIMgr"
    pkg_cli = CLIMgr()
    pkg_cli.CLI = test_cli
    assert test_cli == pkg_cli.CLI
    assert None == pkg_cli._cli


# Generated at 2022-06-20 18:46:01.536684
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    try:
        pm.get_package_details("ansible")
    except NotImplementedError:
        pass
    else:
        assert 0, "Expected NotImplementedError"


# Generated at 2022-06-20 18:46:08.152205
# Unit test for method get_packages of class PkgMgr
def test_PkgMgr_get_packages():
    yum = CLIMgr()
    yum.list_installed = lambda: ['/etc/yum.repos.d/file', '/etc/yum.repos.d/file1', '/etc/yum.repos.d/file2']
    yum.get_package_details = lambda x: {'name': 'dummy', 'version': 'latest'}
    packages = yum.get_packages()
    assert isinstance(packages, dict)

# Generated at 2022-06-20 18:46:09.787963
# Unit test for method is_available of class LibMgr
def test_LibMgr_is_available():
    pkg = LibMgr()
    assert pkg.is_available() == False


# Generated at 2022-06-20 18:46:15.843119
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    class PkgMgrTest(PkgMgr):
        def list_installed(self):
            pass

        def get_package_details(self):
            pass

    cl = PkgMgrTest()
    try:
        cl.list_installed()
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-20 18:46:20.270205
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    CLIMgr_Example = CLIMgr()
    CLIMgr_Example.CLI = 'ls'
    assert CLIMgr_Example.is_available() == True

    CLIMgr_Example = CLIMgr()
    CLIMgr_Example.CLI = 'lsfgfh'
    assert CLIMgr_Example.is_available() == False



# Generated at 2022-06-20 18:46:21.998985
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pm = PkgMgr()
    try:
        pm.get_package_details()
        assert False, "Failed to fail"
    except NotImplementedError:
        assert True


# Generated at 2022-06-20 18:48:59.516175
# Unit test for method list_installed of class PkgMgr
def test_PkgMgr_list_installed():
    import sys
    import os
    import unittest

    test_dir = os.path.dirname(__file__)
    sys.path.insert(0, test_dir)

    class TestClass(object):
        def __new__(cls):
            return object.__new__(cls)

    class TestPkgMgr(TestClass, PkgMgr):
        def list_installed(self):
            return []

        def get_package_details(self, package):
            return {'name': 'hello', 'version': '0.1'}

    class TestCLIMgr(TestClass, CLIMgr):
        CLI = "any_binary"

        def list_installed(self):
            return []


# Generated at 2022-06-20 18:49:00.549019
# Unit test for method is_available of class CLIMgr
def test_CLIMgr_is_available():
    assert CLIMgr().is_available() == False, "Check is CLIMgr().is_available() is False"

# Generated at 2022-06-20 18:49:05.801972
# Unit test for constructor of class LibMgr
def test_LibMgr():
    class TestLibMgr(LibMgr):
        def list_installed(self):
            return "a"
        def get_package_details(self, package):
            return "b"
    test_object = TestLibMgr()
    assert isinstance(test_object, PkgMgr)
    assert isinstance(test_object, LibMgr)
    assert test_object._lib is None


# Generated at 2022-06-20 18:49:08.521838
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    # test that get_all_pkg_managers return is a dictionary
    assert isinstance(get_all_pkg_managers(), dict)
    # test that the return is not empty
    assert get_all_pkg_managers()

# Generated at 2022-06-20 18:49:11.022565
# Unit test for method get_package_details of class PkgMgr
def test_PkgMgr_get_package_details():
    pkg_mgr = PkgMgr()
    if pkg_mgr.is_available():
        pkg_mgr.get_package_details({'name': 'python'})

# Generated at 2022-06-20 18:49:12.646928
# Unit test for constructor of class CLIMgr
def test_CLIMgr():
    test_cli_mgr = CLIMgr()
    test_cli_mgr.CLI = None
    assert test_cli_mgr._cli == None

# Generated at 2022-06-20 18:49:14.726061
# Unit test for constructor of class LibMgr
def test_LibMgr():
    obj = LibMgr()
    assert isinstance(obj, LibMgr)
    assert isinstance(obj, PkgMgr)
    assert isinstance(obj, object)


# Generated at 2022-06-20 18:49:16.173846
# Unit test for function get_all_pkg_managers
def test_get_all_pkg_managers():
    data = get_all_pkg_managers()
    assert len(data) == 2

# Generated at 2022-06-20 18:49:17.212202
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    manager=PkgMgr()
    assert manager is not None


# Generated at 2022-06-20 18:49:17.981642
# Unit test for constructor of class PkgMgr
def test_PkgMgr():
    pass